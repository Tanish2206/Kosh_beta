/* Invented alerts for the test run: every name, number, account and reference here is made up. Each text is written
   from the wording the engine's rules read (engine.js RULES and the SMS reader), so it reads as the bank's would. */
'use strict';

// mail alerts
const MAIL = [
  { id: 'm-hdfc-upi', from: 'alerts@hdfcbank.net', date: '2026-10-02T10:00:00+05:30', subject: 'View: Account update for your HDFC Bank A/c',
    text: 'Dear Customer, Rs.250.00 has been debited from account 4821 to VPA blinkit@icici BLINKIT on 02-10-26. Your UPI transaction reference number is 629512345678.' },
  { id: 'm-icici-card', from: 'credit_cards@icicibank.com', date: '2026-10-03T10:00:00+05:30', subject: 'Transaction alert for your ICICI Bank Credit Card',
    text: 'Dear Customer, Your ICICI Bank Credit Card XX1234 has been used for a transaction of INR 1,499.00 on Oct 03, 2026 at 08:15:22. Info: SWIGGY. The Available Credit Limit on your card is INR 50,000.00' },
  { id: 'm-axis-card', from: 'alerts@axisbank.com', date: '2026-10-04T10:00:00+05:30', subject: 'Transaction alert',
    text: 'INR 799.00 was spent on your Axis Bank Credit Card no. XX5678 at AMAZON PAY on 04-10-2026 at 12:10:11 IST.' },
];

// SMS, as the phone's shortcut hands them over
const SMS = [
  { id: 's-hdfc-sent', chan: 'sms', from: 'AX-HDFCBK-S', date: '2026-10-05T09:12:00+05:30', subject: '',
    text: 'Sent Rs.250.00 From HDFC Bank A/C *4821 To BLINKIT On 05/10/26 Ref 629512345679 Not You? Call 18002586161/SMS BLOCK UPI to 7308080808' },
  { id: 's-icici-spent', chan: 'sms', from: 'VM-ICICIB-S', date: '2026-10-06T09:12:00+05:30', subject: '',
    text: 'INR 1,200.00 spent using ICICI Bank Card XX1234 on 06-Oct-26 on ZOMATO. Avl Limit: INR 48,800.00. If not you, call 1800 2662/SMS BLOCK 1234 to 9215676766.' },
  { id: 's-sbi-upi', chan: 'sms', from: 'JD-SBIUPI-S', date: '2026-10-07T09:12:00+05:30', subject: '',
    text: 'Dear UPI user A/C X9876 debited by 120.0 on date 07Oct26 trf to CHAI POINT Refno 629812345670. If not u? call 1800111109. -SBI' },
  { id: 's-kotak-in', chan: 'sms', from: 'VK-KOTAKB-S', date: '2026-10-08T09:12:00+05:30', subject: '',
    text: 'Received Rs.5000.00 in your Kotak Bank a/c X3456 from RAHUL EXAMPLE on 08-10-26. UPI Ref:629912345671.' },
  { id: 's-otp', chan: 'sms', from: 'VM-HDFCBK-S', date: '2026-10-08T09:12:00+05:30', subject: '', text: 'Your OTP for transaction is 482913. Do not share.' },
  { id: 's-promo', chan: 'sms', from: 'VM-HDFCBK-S', date: '2026-10-08T09:12:00+05:30', subject: '', text: 'Get flat 10% cashback up to Rs.500 on your HDFC Bank Credit Card this festive season. T&C apply.' },
];

// an SMS template with blanks, for the dedupe cases
function hdfcSent(id, amt, day, time, to, ref) {
  return { id: id, chan: 'sms', from: 'AX-HDFCBK-S', date: '2026-10-' + day + 'T' + time + ':00+05:30', subject: '',
    text: 'Sent Rs.' + amt.toFixed(2) + ' From HDFC Bank A/C *4821 To ' + to + ' On ' + day + '/10/26' + (ref ? ' Ref ' + ref : '') + ' Not You? Call 18002586161/SMS BLOCK UPI to 7308080808' };
}

module.exports = { MAIL, SMS, hdfcSent };
