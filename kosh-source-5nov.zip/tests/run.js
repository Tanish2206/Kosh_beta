/* kosh engine safety net: node tests/run.js [--accept] [--only=name,name] [--verbose]

   Loads Kosh/engine.js as the phone does (plain functions, no network) and runs it over small invented fixtures for
   the paths money depends on: reading alerts (mail and SMS), folding two tellings of one payment into one (dedupe),
   setting statement lines against alerts, a statement's own figures adding up (stmtCheck, through parseDoc), and the
   build's snapshot. Each case gives a small projection of what the engine said; it is compared with the one kept in
   tests/golden.json, so a change that moves money anywhere is named, with what moved. --accept keeps today's
   projections as the golden ones (after a change meant to read better: say which in the commit).

   Plain Node, no packages. Exits 1 when anything differs or throws. Nothing here is anyone's real data. */
'use strict';
const fs = require('fs');
const path = require('path');
// (KOSH_ENGINE=<file>: another engine.js, to see what a change moved against the one before it)
const E = require(process.env.KOSH_ENGINE ? path.resolve(process.env.KOSH_ENGINE) : path.join(__dirname, '..', 'Kosh', 'engine.js'));
const F = require('./fixtures/alerts.js');

const args = process.argv.slice(2);
const ACCEPT = args.includes('--accept');
const VERBOSE = args.includes('--verbose');
const ONLY = (args.find((a) => a.startsWith('--only=')) || '').slice(7).split(',').filter(Boolean);
const GOLDEN = path.join(__dirname, 'golden.json');
const golden = fs.existsSync(GOLDEN) ? JSON.parse(fs.readFileSync(GOLDEN, 'utf8')) : {};

const cases = [];
function test(name, fn, opts) { cases.push({ name, fn, golden: !opts || opts.golden !== false }); }
function eq(a, b, what) { const x = JSON.stringify(a), y = JSON.stringify(b); if (x !== y) throw new Error((what || 'value') + ': expected ' + y + ', got ' + x); }
function ok(c, what) { if (!c) throw new Error(what || 'assertion failed'); }

/* ------------------------------------------------------------ projections: what each case is judged by */
const PARSE_KEYS = ['kind', 'rule', 'dir', 'amt', 'date', 'instr', 'last4', 'inst', 'party', 'vpa', 'ref', 'mode'];
function pick(o, keys) { const out = {}; keys.forEach((k) => { if (o && o[k] !== undefined && o[k] !== '') out[k] = o[k]; }); return out; }
function rec(m) { return Object.assign({}, E.parse(m), { id: m.id }); }
const TX_KEYS = ['id', 'd', 'a', 'k', 'm', 'c', 's', 'card', 'src', 'vpa', 'told', 'lr'];
function txOf(snap) { return (snap.tx || []).map((t) => pick(t, TX_KEYS)).sort((a, b) => (a.d + a.id).localeCompare(b.d + b.id)); }
const RECON_KEYS = ['src', 'inst', 'instr', 'last4', 'lines', 'matched', 'filled', 'added', 'skipped', 'held', 'ok', 'extra'];
function reconOf(snap) { return (snap.recon || []).map((r) => pick(r, RECON_KEYS)); }
function monthsOf(snap) { return (snap.months || []).map((m) => ({ m: m.m, total: m.total, payments: m.payments, cats: (m.cats || []).map((c) => c.cat + ':' + c.v) })); }
const PROF = { today: '2026-10-31', name: 'Test Person' };
function build(records, extra) { return E.build(records, Object.assign({}, PROF, extra || {})); }
function doc(text, kind, from, title) { return JSON.parse(E.parseDocJSON(text, kind, from || '', title || '', '', '2026-11-01')); }
function docOf(o) { return { kind: o.kind, check: o.check && { ok: o.check.ok, read: o.check.read, stated: o.check.stated, fixed: o.check.fixed }, cover: o.cover, last4: o.last4, from: o.from, to: o.to, rows: (o.rows || []).map((r) => r.date + ' ' + r.dir + ' ' + r.amt + (r.chk ? ' chk' : '')) }; }

/* ------------------------------------------------------------ 1. alerts read */
F.MAIL.concat(F.SMS).forEach((m) => test('parse/' + m.id, () => pick(E.parse(m), PARSE_KEYS)));
test('parse/sms-not-money', () => {
  // a code and an offer are never payments (privacy: the phone keeps nothing of them)
  ['s-otp', 's-promo'].forEach((id) => { const r = E.parse(F.SMS.find((m) => m.id === id)); ok(r.kind !== 'txn', id + ' read as a payment'); });
  return true;
});

/* ------------------------------------------------------------ 2. dedupe: one payment told twice is one */
test('dedupe/mail-and-sms-same-ref', () => {
  const a = F.MAIL[0], b = F.hdfcSent('s-dup-1', 250, '02', '10:01', 'BLINKIT', '629512345678');
  return txOf(build([rec(a), rec(b)]));
});
test('dedupe/two-teas-no-ref', () => txOf(build([rec(F.hdfcSent('s-tea-1', 100, '12', '10:00', 'TEA STALL', '')), rec(F.hdfcSent('s-tea-2', 100, '12', '10:30', 'TEA STALL', ''))])));
test('dedupe/same-sms-twice', () => {
  const m = F.hdfcSent('s-twice-1', 640, '13', '11:00', 'EXAMPLE MART', '629500000001');
  return txOf(build([rec(m), rec(Object.assign({}, m, { id: 's-twice-2', date: '2026-10-13T11:02:00+05:30' }))]));
});
test('dedupe/same-sum-two-refs', () => txOf(build([rec(F.hdfcSent('s-ref-1', 300, '14', '12:00', 'EXAMPLE MART', '629500000002')), rec(F.hdfcSent('s-ref-2', 300, '14', '12:00', 'EXAMPLE MART', '629500000003'))])));

/* ------------------------------------------------------------ 3. statement lines against alerts */
const HDFC_ACCT = { from: 'alerts@hdfcbank.net', inst: 'HDFC', instr: 'account', last4: '4821', periodFrom: '2026-10-01', periodTo: '2026-10-31', ok: true };
function stmt(src, rows, extra) { return Object.assign({ src: src }, HDFC_ACCT, extra || {}, { rows: rows }); }
test('stmt/basic-match-and-add', () => {
  const snap = build([rec(F.MAIL[0]), rec(F.SMS[0])], { statements: [stmt('st-basic', [
    { date: '2026-10-02', amt: 250, dir: 'out', desc: 'UPI-BLINKIT-blinkit@icici-ICIC0000001-629512345678-UPI' },
    { date: '2026-10-05', amt: 250, dir: 'out', desc: 'UPI-BLINKIT-blinkit@icici-ICIC0000001-629512345679-UPI' },
    { date: '2026-10-10', amt: 999, dir: 'out', desc: 'UPI-NETFLIX-netflix@hdfcbank-HDFC0000001-629512345690-UPI' }])] });
  return { tx: txOf(snap), recon: reconOf(snap) };
});
test('stmt/not-reconciled-holds-new-lines', () => {
  // a statement whose figures don't add up fills in, but adds nothing of its own
  const snap = build([rec(F.MAIL[0])], { statements: [stmt('st-bad', [
    { date: '2026-10-02', amt: 250, dir: 'out', desc: 'UPI-BLINKIT-blinkit@icici-629512345678' },
    { date: '2026-10-11', amt: 450, dir: 'out', desc: 'UPI-EXAMPLE CAFE-cafe@okaxis-629512345691' }], { ok: false })] });
  return { tx: txOf(snap), recon: reconOf(snap) };
});
test('stmt/crossed-payees', () => {
  // two ₹500 payments, each posted a day or two late: the lines name their payees; the nearest date alone crosses them
  const snap = build([rec(F.hdfcSent('s-uber', 500, '02', '09:00', 'UBER INDIA', '')), rec(F.hdfcSent('s-swiggy', 500, '04', '20:00', 'SWIGGY', ''))], { statements: [stmt('st-cross', [
    { date: '2026-10-04', amt: 500, dir: 'out', desc: 'UPI-UBER INDIA SYSTEMS PVT LTD-uber@axisbank-UTIB0000001-UPI' },
    { date: '2026-10-05', amt: 500, dir: 'out', desc: 'UPI-SWIGGY LIMITED-swiggy@icici-ICIC0000001-UPI' }])] });
  return { tx: txOf(snap), recon: reconOf(snap) };
});
test('stmt/ref-decides', () => {
  // two ₹300 payments to one payee a day apart: the reference each line prints says which alert it is
  const snap = build([rec(F.hdfcSent('s-ra', 300, '09', '09:00', 'EXAMPLE STORE', '629500000011')), rec(F.hdfcSent('s-rb', 300, '10', '09:00', 'EXAMPLE STORE', '629500000012'))], { statements: [stmt('st-ref', [
    { date: '2026-10-10', amt: 300, dir: 'out', desc: 'UPI/629500000011/EXAMPLE STORE/storea@okhdfcbank' },
    { date: '2026-10-11', amt: 300, dir: 'out', desc: 'UPI/629500000012/EXAMPLE STORE/storeb@okhdfcbank' }])] });
  return { tx: txOf(snap), recon: reconOf(snap) };
});
test('stmt/weak-pair-stays-apart', () => {
  // four days apart, ₹1 off, and two different payees: not the same payment
  const snap = build([rec(F.hdfcSent('s-weak', 700, '01', '09:00', 'ZOMATO', ''))], { statements: [stmt('st-weak', [
    { date: '2026-10-05', amt: 701, dir: 'out', desc: 'UPI-RAHUL EXAMPLE-rahul@oksbi-SBIN0000001-UPI' }])] });
  return { tx: txOf(snap), recon: reconOf(snap) };
});
test('stmt/same-day-close-sum-still-matches', () => {
  // the bank's narration names the payee differently from the alert: the same day and sum is still the one payment
  const snap = build([rec(F.hdfcSent('s-diff', 1180, '15', '09:00', 'EXAMPLE TELECOM', ''))], { statements: [stmt('st-diff', [
    { date: '2026-10-15', amt: 1180, dir: 'out', desc: 'BIL/ONL/000222333/BBPS PAYMENT/812345678' }])] });
  return { tx: txOf(snap), recon: reconOf(snap) };
});
test('stmt/second-copy-adds-nothing', () => {
  const rows = [{ date: '2026-10-10', amt: 999, dir: 'out', desc: 'UPI-NETFLIX-netflix@hdfcbank-HDFC0000001-629512345690-UPI' }];
  const snap = build([], { statements: [stmt('st-c1', rows), stmt('st-c2', rows)] });
  return { tx: txOf(snap), recon: reconOf(snap) };
});

/* ------------------------------------------------------------ 4. a statement's own figures (parseDoc › stmtCheck) */
const STMT_OK = ['EXAMPLE BANK LTD', 'Statement of Account', 'Account No: XXXXXXXX4821', 'Statement period: 01/10/2026 to 31/10/2026', 'Opening Balance : 10,000.00',
  'Date       Narration                                    Withdrawal     Deposit      Balance',
  '02/10/2026 UPI-BLINKIT-blinkit@icici-629512345678       250.00                      9,750.00',
  '05/10/2026 UPI-BLINKIT-blinkit@icici-629512345679       250.00                      9,500.00',
  '08/10/2026 NEFT-ACME PAYROLL SERVICES                                 50,000.00    59,500.00',
  '10/10/2026 UPI-NETFLIX-netflix@hdfcbank-629512345690    999.00                     58,501.00',
  'Closing Balance : 58,501.00'].join('\n');
test('doc/stmt-reconciles', () => docOf(doc(STMT_OK, 'stmt', 'alerts@hdfcbank.net', 'Account statement')));
test('doc/stmt-missing-line', () => docOf(doc(STMT_OK.replace(/^05\/10\/2026.*\n/m, ''), 'stmt', 'alerts@hdfcbank.net', 'Account statement')));
test('doc/stmt-bad-closing', () => docOf(doc(STMT_OK.replace('Closing Balance : 58,501.00', 'Closing Balance : 57,501.00'), 'stmt', 'alerts@hdfcbank.net', 'Account statement')));
test('doc/fixtures-dir', () => {
  // the scorecard's own fixtures (reader/stmt-score.js) read the same way every run
  const dir = path.join(__dirname, 'fixtures', 'stmt');
  if (!fs.existsSync(dir)) return null;
  return fs.readdirSync(dir).filter((f) => /\.json$/.test(f) && !/\.gold\.json$/.test(f) && !/ratchet\.json$/.test(f)).sort().map((f) => {
    const x = JSON.parse(fs.readFileSync(path.join(dir, f), 'utf8'));
    return [f, docOf(JSON.parse(E.parseDocJSON(x.text, x.kind || 'stmt', x.from || '', x.title || '', x.grid || '', x.sent || '')))];
  });
});

test('doc/scorecard-ratchet', () => {
  // the scorecard runs over the same fixtures and its ratchet holds (a reading that stops adding up fails here too)
  const r = require('child_process').spawnSync(process.execPath, [path.join(__dirname, '..', 'reader', 'stmt-score.js'), path.join(__dirname, 'fixtures', 'stmt'), '--ratchet'], { encoding: 'utf8' });
  ok(r.status === 0, 'stmt-score.js --ratchet exited ' + r.status + ':\n' + r.stdout + r.stderr);
  return JSON.parse(/^SCORE (.*)$/m.exec(r.stdout)[1]);
});

/* ------------------------------------------------------------ 5. the build's snapshot from a handful of records */
test('build/snapshot', () => {
  const recs = F.MAIL.concat(F.SMS).map(rec);
  const snap = build(recs, { statements: [stmt('st-snap', [{ date: '2026-10-10', amt: 999, dir: 'out', desc: 'UPI-NETFLIX-netflix@hdfcbank-629512345690' }])] });
  return { tx: txOf(snap), months: monthsOf(snap), recon: reconOf(snap), dups: (snap.dups || []).length };
});
test('build/buildJSON-roundtrip', () => {
  // the phone's own door: text in, text out, the same snapshot
  const recs = F.MAIL.map(rec);
  const a = txOf(JSON.parse(E.buildJSON(JSON.stringify(recs), JSON.stringify(PROF), 'test-1')));
  eq(a, txOf(build(recs)), 'buildJSON vs build');
  return a.length;
});
test('build/learned-category-carries', () => {
  // you filed one Swiggy payment as Groceries for all its payments: the next one by that name is filed so too
  const a = rec(F.hdfcSent('s-l1', 410, '16', '19:00', 'SWIGGY LIMITED', '629500000021'));
  const b = rec(F.hdfcSent('s-l2', 520, '20', '19:00', 'SWIGGY LIMITED', '629500000022'));
  return txOf(build([a, b], { overrides: { 's-l1': { c: 'Groceries', s: 'Quick commerce' } } }));
});
test('build/learned-category-fuzzy-name', () => {
  // the same shop told by a card's alert under its gateway's name ("SWIGGY*BLR"): filed as you filed "Swiggy Limited"
  const a = rec(F.hdfcSent('s-f1', 410, '16', '19:00', 'SWIGGY LIMITED', '629500000031'));
  const b = rec({ id: 'm-f2', from: 'credit_cards@icicibank.com', date: '2026-10-21T10:00:00+05:30', subject: 'Transaction alert for your ICICI Bank Credit Card',
    text: 'Dear Customer, Your ICICI Bank Credit Card XX1234 has been used for a transaction of INR 640.00 on Oct 21, 2026 at 20:15:22. Info: SWIGGY*BLR. The Available Credit Limit on your card is INR 50,000.00' });
  const c = rec(F.hdfcSent('s-f3', 300, '22', '19:00', 'RAHUL EXAMPLE', '629500000033'));
  return txOf(build([a, b, c], { overrides: { 's-f1': { c: 'Groceries', s: 'Quick commerce' } } }));
});

test('build/learned-fuzzy-not-for-people', () => {
  // a person filed as family: another person of the same first name is not filed so (only the same name carries),
  // and a shop that merely starts the same ("Swiggy Instamart" beside "Swiggy Limited") keeps its own reading
  const a = rec(F.hdfcSent('s-p1', 2000, '16', '19:00', 'RAHUL SHARMA', '629500000041'));
  const b = rec(F.hdfcSent('s-p2', 1500, '20', '19:00', 'RAHUL VERMA', '629500000042'));
  const c = rec(F.hdfcSent('s-p3', 410, '17', '19:00', 'SWIGGY LIMITED', '629500000043'));
  const d = rec(F.hdfcSent('s-p4', 380, '21', '19:00', 'SWIGGY INSTAMART', '629500000044'));
  return txOf(build([a, b, c, d], { overrides: { 's-p1': { c: 'Family Support' }, 's-p3': { c: 'Shopping', s: 'Online' } } }));
});

/* ------------------------------------------------------------ 5b. statement layout templates (templates-5nov; unit tests, no golden)
   An invented bank's statement drawn as the phone hands it over (its text, and its words with where they sit): Date,
   Narration, Withdrawal and Deposit columns, no running balance, so which way a line went is only where its figure sits.
   Read whole once, it leaves its layout; next month's, its header mangled, missing or the page moved, is read by it. */
function tplInr(v) { const p = Math.abs(v).toFixed(2).split('.'); let i = p[0]; const last = i.slice(-3), rest = i.slice(0, -3); return (rest ? rest.replace(/\B(?=(\d{2})+(?!\d))/g, ',') + ',' : '') + last + '.' + p[1]; }
function tplStmt(o) {
  const dx = o.dx || 0, cw = 7, P = Object.assign({ date: 40, desc: 130, out: 620, in: 750, bal: 880 }, o.pos || {}), lines = [], text = [];
  let y = 20, bal = o.opening;
  const word = (x0, t) => ({ x0: x0 + dx, x1: x0 + dx + t.length * cw, t });
  const words = (x0, s) => { const out = []; let x = x0; s.split(' ').forEach((t) => { out.push(word(x, t)); x += (t.length + 1) * cw; }); return out; };
  const right = (x1, s) => { const ws = words(0, s), wid = ws[ws.length - 1].x1 - dx; return ws.map((w) => ({ x0: w.x0 + x1 - wid, x1: w.x1 + x1 - wid, t: w.t })); };
  const push = (ws) => { ws.sort((a, b) => a.x0 - b.x0); lines.push({ y, w: ws }); y += 12; text.push(ws.map((w) => w.t).join('   ')); };
  push(words(40, 'EXAMPLE BANK LTD'));
  push(words(40, 'Account No: XXXXXXXX' + (o.l4 || '4821')));
  push(words(40, 'Statement period: ' + o.period));
  push(words(40, 'Opening Balance : ' + tplInr(bal)));
  const H = o.header === undefined ? ['Date', 'Narration', 'Withdrawal', 'Deposit'] : o.header;
  const outX = o.swap ? P.in : P.out, inX = o.swap ? P.out : P.in;
  if (H.length) push([].concat(words(P.date, H[0]), words(P.desc, H[1]), right(outX, H[2]), right(inX, H[3]), H[4] ? right(P.bal, H[4]) : []));
  o.rows.forEach((r) => {
    bal = Math.round((bal + (r[3] === 'in' ? r[2] : -r[2])) * 100) / 100;
    push([word(P.date, r[0])].concat(words(P.desc, r[1]), right(r[3] === 'in' ? inX : outX, tplInr(r[2])), o.bal ? right(P.bal, tplInr(bal)) : []));
  });
  push(words(40, 'Closing Balance : ' + tplInr(bal)));
  return { text: text.join('\n'), grid: 'grid1\n' + lines.map((l) => '1,' + l.y + '\t' + l.w.map((w) => w.x0 + ',' + w.x1 + ',' + w.t).join('\t')).join('\n') };
}
const TPL_FROM = 'statements@examplebank.co.in';
const TPL_ROWS = (m) => [[`02/${m}/2026`, 'UPI-EXAMPLE MART-mart@okaxis-629500000101', 250, 'out'], [`05/${m}/2026`, 'TRANSFER EXAMPLE TRADERS', 4000, 'in'],
  [`08/${m}/2026`, 'ATM WDL EXAMPLE NAGAR', 2000, 'out'], [`12/${m}/2026`, 'IMPS-EXAMPLE PERSON-0000123', 1500, 'in'], [`20/${m}/2026`, 'UPI-EXAMPLE CAFE-cafe@okhdfc-629500000102', 480, 'out']];
const tplOct = () => tplStmt({ period: '01/10/2026 to 31/10/2026', opening: 10000, rows: TPL_ROWS('10') });
const tplNov = (o) => tplStmt(Object.assign({ period: '01/11/2026 to 30/11/2026', opening: 12770, rows: TPL_ROWS('11') }, o || {}));
function tplRead(x, T, from) { return JSON.parse(E.parseDocJSON(x.text, 'stmt', from || TPL_FROM, 'Account statement', x.grid, '2026-12-01', T ? JSON.stringify(T) : '')); }
// what one reading changes in the templates, applied (as the phone keeps them: LiveSession+Statements › StmtTemplates)
function tplKeep(T, parsed, x, from) {
  const ch = JSON.parse(E.docTemplatesUpdateJSON(JSON.stringify(T), JSON.stringify(parsed), x.text, 'stmt', from || TPL_FROM, 'Account statement', x.grid, '2026-12-01'));
  const next = Object.assign({}, T);
  Object.keys(ch).forEach((k) => { if (ch[k] === null) delete next[k]; else next[k] = ch[k]; });
  return next;
}
const tplDirs = (o) => (o.rows || []).map((r) => r.date.slice(8) + r.dir + r.amt).join(' ');
const TPL_WANT = '02out250 05in4000 08out2000 12in1500 20out480';
function tplLearnt() { const x = tplOct(), o = tplRead(x); ok(o.check.ok === true, 'october adds up by its header'); return tplKeep({}, o, x); }
if (E.docTemplatesUpdateJSON) {
  test('tpl/learn-from-reconciled', () => {
    const T = tplLearnt(), keys = Object.keys(T);
    eq(keys.length, 1, 'one template');
    const t = T[keys[0]];
    eq(t.cols.map((c) => c.cat), ['date', 'desc', 'debit', 'credit'], 'columns');
    eq([t.src, t.dfmt, t.sign, t.order, t.open, t.close, t.stale], ['header', 'n/n/y', 'columns', 'asc', 'opening balance', 'closing balance', false], 'layout');
    ok(t.fam === 'examplebank.co.in|stmt' && keys[0].indexOf(t.fam + '|') === 0, 'keyed by domain and kind');
    ok(!/4821/.test(JSON.stringify(T)), 'the account\'s digits are never kept');
    ok(!/EXAMPLE MART|629500000101|4,000/.test(JSON.stringify(T)), 'nothing of the lines is kept');
    // a statement that doesn't add up teaches nothing
    const bad = tplOct(); bad.text = bad.text.replace(/Closing Balance : [\d,.]+/, 'Closing Balance : 99.00'); bad.grid = bad.grid.replace(/(Closing\tBalance[^\n]*?,):\t[^\n]*/, '$1:');
    eq(Object.keys(JSON.parse(E.docTemplatesUpdateJSON('{}', JSON.stringify(tplRead({ text: bad.text, grid: '' })), bad.text, 'stmt', TPL_FROM, '', '', ''))).length, 0, 'not learnt from one that does not add up');
    return true;
  }, { golden: false });
  test('tpl/mangled-header-read-by-template', () => {
    const T = tplLearnt(), x = tplNov({ header: ['Dat e', 'Narr ation', 'Withdr awal', 'Depo sit'] });
    const g = tplRead(x);
    ok(g.check.ok !== true, 'the readers alone don\'t read it (' + g.check.note + ')');
    const o = tplRead(x, T);
    ok(o.check.ok === true, 'read by its template: ' + o.check.note);
    eq(tplDirs(o), TPL_WANT, 'each line, the right way');
    eq([o.tpl.via, o.tpl.hit === Object.keys(T)[0]], ['exact', true], 'its own template');
    const T2 = tplKeep(T, o, x), t2 = T2[Object.keys(T)[0]];
    eq([t2.hits, t2.fails, t2.src], [1, 0, 'header'], 'a hit counted; the layout as it was learnt');
    return true;
  }, { golden: false });
  test('tpl/no-header-page-moved', () => {
    const T = tplLearnt(), x = tplNov({ header: [], dx: 37 });
    ok(tplRead(x).check.ok !== true, 'the readers alone don\'t read it');
    const o = tplRead(x, T);
    ok(o.check.ok === true, 'read by its template, moved: ' + o.check.note);
    eq(tplDirs(o), TPL_WANT, 'each line, the right way');
    return true;
  }, { golden: false });
  test('tpl/columns-moved-found-by-header-words', () => {
    // learnt from a header kosh's column names don't know (read line by line, by its running balance), then next month the
    // money columns moved apart from the date: the header's own words say where they went
    const H = ['Txn On', 'Particulars Of Txn', 'Money Spent', 'Money Got', 'Running Total'];
    const x1 = tplStmt({ period: '01/10/2026 to 31/10/2026', opening: 10000, rows: TPL_ROWS('10'), header: H, bal: true });
    const o1 = tplRead(x1);
    ok(o1.check.ok === true && !o1.byColumns, 'october read line by line');
    const T = tplKeep({}, o1, x1), t = T[Object.keys(T)[0]];
    eq([t.src, t.cols.map((c) => c.cat).join(' ')], ['lines', 'date desc debit credit balance'], 'learnt from where its lines sat');
    eq(t.cols.filter((c) => c.cat === 'debit')[0].t, 'Money Spent', 'the column\'s own name');
    const x2 = tplNov({ header: H, bal: true, pos: { out: 700, in: 830, bal: 960 } });
    const cols = E.lib.tplByTokens(E.lib.gridOf(x2.grid), t);
    ok(cols && Math.abs(cols.filter((c) => c.cat === 'credit')[0].x1 - 830) <= 2 && Math.abs(cols.filter((c) => c.cat === 'date')[0].x0 - 40) <= 2, 'columns found by their names');
    const o2 = tplRead(x2, T);
    eq([o2.check.ok, o2.tpl.via, tplDirs(o2)], [true, 'exact', TPL_WANT], 'read by its template');
    return true;
  }, { golden: false });
  test('tpl/misfit-falls-back', () => {
    // the bank swapped its money columns and renamed them: the template reads it wrong (its columns where they were, its
    // header's words nowhere), so the readers read it as without one
    // (each header name is drawn over its own figures: Debit over the money out, now the right-hand column)
    const T = tplLearnt(), key = Object.keys(T)[0], x = tplNov({ swap: true, header: ['Txn Date', 'Description', 'Debit', 'Credit'] });
    const plain = tplRead(x), o = tplRead(x, T);
    ok(plain.check.ok === true, 'the readers read it');
    eq(o.tpl.tried, [key], 'its template was tried');
    eq(o.tpl.hit, '', 'and not kept');
    const o0 = Object.assign({}, o); delete o0.tpl;
    eq(o0, plain, 'the reading is the readers\' own, unchanged');
    // the layout as it is now is learnt instead
    const T2 = tplKeep(T, o, x);
    eq([T2[key].cols.map((c) => c.cat).join(' '), T2[key].fails], ['date desc credit debit', 0], 'taught again');
    // and a template from a sender that isn't this one is never tried
    const other = tplRead(tplNov({ header: [] }), { 'otherbank.com|stmt|-': T[key] });
    ok(!other.tpl || !other.tpl.tried.length, 'another sender\'s template untried');
    return true;
  }, { golden: false });
  test('tpl/stale-after-three', () => {
    // its money columns swapped and no header at all: nothing reads it; its template fails three statements running and is stale
    let T = tplLearnt();
    const key = Object.keys(T)[0], x = tplNov({ swap: true, header: [] });
    for (let i = 1; i <= 3; i++) {
      const o = tplRead(x, T);
      ok(o.check.ok !== true && o.tpl.tried[0] === key, 'tried and failed ' + i);
      T = tplKeep(T, o, x);
      eq([T[key].fails, T[key].stale], [i, i >= 3], 'fails ' + i);
    }
    eq(tplRead(x, T).tpl.tried, [], 'a stale template is tried no more');
    // a statement that adds up teaches it again
    const y = tplNov(), oy = tplRead(y, T);
    ok(oy.check.ok === true, 'a clean month');
    T = tplKeep(T, oy, y);
    eq([T[key].stale, T[key].fails], [false, 0], 'fresh again');
    return true;
  }, { golden: false });
  test('tpl/family-other-account', () => {
    // the same bank's statement for another account (another last four), its header mangled: the readers fail, the
    // bank's template for the first account reads it, and the second account keeps its own from then on
    const T = tplLearnt(), x = tplNov({ l4: '7710', header: ['Dat e', 'Narr ation', 'Withdr awal', 'Depo sit'] });
    ok(tplRead(x).check.ok !== true, 'the readers alone don\'t read it');
    const o = tplRead(x, T);
    eq([o.check.ok, o.tpl.via, tplDirs(o)], [true, 'family', TPL_WANT], 'read by the bank\'s other template');
    const T2 = tplKeep(T, o, x);
    eq(Object.keys(T2).length, 2, 'the second account has its own now');
    ok(T2[o.tpl.key] && T2[o.tpl.key].fam === T[Object.keys(T)[0]].fam, 'of the same family');
    return true;
  }, { golden: false });
}

/* ------------------------------------------------------------ 6. the payee helpers (unit tests, no golden) */
if (E.lib.payeeCanon) {
  test('payee/canon', () => {
    const C = E.lib.payeeCanon;
    eq(C('PAYU*SWIGGY'), 'swiggy', 'gateway prefix');
    eq(C('Swiggy Ltd'), 'swiggy', 'company tail');
    eq(C('SWIGGY*BLR'), 'swiggy', 'city tail');
    eq(C('RAZ*EXAMPLE FOODS PVT LTD'), 'example foods', 'razorpay prefix');
    eq(C('UBER INDIA SYSTEMS PVT LTD'), 'uber', 'pvt ltd and the company words');
    eq(C('blinkit@icici'), 'blinkit', 'upi handle');
    eq(C('BHARATPE.90012345678@fbpe'), '', 'bharatpe merchant id only');
    eq(C('EXAMPLE MART STORE 1234 MUMBAI'), 'example mart', 'store number and city');
    eq(C('CCAVENUE-EXAMPLE TRAVELS'), 'example travels', 'ccavenue');
    return true;
  }, { golden: false });
  test('payee/sim', () => {
    const S = E.lib.payeeSim;
    ok(S('Swiggy Ltd', 'SWIGGY*BLR') >= 0.99, 'same shop');
    ok(S('UBER INDIA SYSTEMS PVT LTD', 'UBER INDIA') >= 0.6, 'uber long and short');
    ok(S('ZOMATO', 'RAHUL EXAMPLE') < 0.15, 'two payees');
    ok(S('Rahul Sharma', 'Rahul Verma') < 0.8, 'two people of one first name');
    eq(S('', 'SWIGGY'), 0, 'nothing to compare');
    return true;
  }, { golden: false });
}

/* ------------------------------------------------------------ run */
let fail = 0, changed = 0, n = 0;
const next = Object.assign({}, golden);
for (const c of cases) {
  if (ONLY.length && !ONLY.some((o) => c.name.indexOf(o) === 0)) continue;
  n++;
  let got;
  try { got = c.fn(); } catch (e) { fail++; console.log('FAIL  ' + c.name + '\n      ' + (e && e.stack ? e.stack.split('\n').slice(0, 3).join('\n      ') : e)); continue; }
  if (!c.golden) { if (VERBOSE) console.log('ok    ' + c.name); continue; }
  const s = JSON.stringify(got);
  if (!(c.name in golden)) { next[c.name] = got; changed++; console.log((ACCEPT ? 'new   ' : 'NEW   ') + c.name + (VERBOSE ? '  ' + s : '')); if (!ACCEPT) fail++; continue; }
  if (JSON.stringify(golden[c.name]) !== s) {
    changed++; next[c.name] = got;
    console.log((ACCEPT ? 'took  ' : 'DIFF  ') + c.name + '\n      was ' + JSON.stringify(golden[c.name]) + '\n      now ' + s);
    if (!ACCEPT) fail++;
    continue;
  }
  if (VERBOSE) console.log('ok    ' + c.name);
}
if (ACCEPT && changed) fs.writeFileSync(GOLDEN, JSON.stringify(next, null, 1) + '\n');
console.log((fail ? 'FAILED ' : 'passed ') + (n - fail) + '/' + n + (changed ? ' (' + changed + (ACCEPT ? ' golden taken)' : ' differ from golden: --accept after checking)') : ''));
process.exit(fail ? 1 : 0);
