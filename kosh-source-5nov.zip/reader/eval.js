/* kosh reader scoreboard.
   node reader/eval.js <dir> [--detail] [--only=cards,banks] [--legacy] [--json=out.json] [--pred=<dir>] [--ratchet [--accept]]

   --ratchet: the mails read perfectly are remembered in <dir>/ratchet.json (beside the mail, never in the repo); a
   change that makes one of them read wrong is named, with what went wrong, and the run fails. --accept remembers
   today's set (after a change that reads more right). The last line, SCORE {...}, is what the repo's scoreboard
   records (engine-test/scores.js --record --corpus='<that json>'): counts only, nothing from the mail.

   <dir> holds pairs of files: <name>.json (mails: {id, from, date, subject, text, html?, attachments?}) and
   <name>.gold.json ([{id, events, notes}], events in reader/DESIGN.md's shapes). Real mail is kept outside the repo;
   the repo's own invented fixtures live in reader/fixtures.

   Scores, for the new reader and (with --legacy) the engine's old parse(): events found per type, field accuracy
   on the events found, events that aren't in the mail at all (false), and whole mails read right. Senders are
   split in two by a hash of their domain: "dev" is what rules were built against, "hold" was kept back, so its
   score is the score on mail the reader has never been tuned to. */
'use strict';
const fs = require('fs');
const path = require('path');
const KOSH = path.join(__dirname, '..', 'Kosh');
const E = require(path.join(KOSH, 'engine.js'));
const R = require(path.join(KOSH, 'reader.js'));
require(path.join(KOSH, 'knowledge.js'));

const args = process.argv.slice(2);
const dir = args.find((a) => !a.startsWith('--'));
const DETAIL = args.includes('--detail');
const LEGACY = args.includes('--legacy');
const ONLY = (args.find((a) => a.startsWith('--only=')) || '').slice(7).split(',').filter(Boolean);
const SPLIT = (args.find((a) => a.startsWith('--split=')) || '--split=all').slice(8);
const JSON_OUT = (args.find((a) => a.startsWith('--json=')) || '').slice(7);
// --book=self: one book, mail read oldest first, each reading learnt (what the phone does);
// --book=teach: each mail read with a book taught the labels of every other mail from its sender (one label per
// template is all a teacher gives: Claude once, or a correction)
const BOOK = (args.find((a) => a.startsWith('--book=')) || '').slice(7);
// --pred=<dir>: score another reader's answers instead (<dir>/<name>.pred.json: [{id, events}], e.g. an LLM's), its
// masked numbers (••1234) put back from the mail itself, as the phone would
const PRED = (args.find((a) => a.startsWith('--pred=')) || '').slice(7);
const PREDS = {};
if (PRED) for (const f of fs.readdirSync(PRED).filter((x) => x.endsWith('.pred.json'))) for (const p of JSON.parse(fs.readFileSync(path.join(PRED, f), 'utf8'))) PREDS[p.id] = p.events || [];
function unmasked(events, m) {
  const hay = (m.subject || '') + ' ' + (m.text || '') + ' ' + (m.html ? E.lib.htmlLines(m.html) : '');
  // the tokens masking could have shortened: a word with digits (an id, a UTR), or digits in groups (a card number)
  // (and every bare run of 8+ digits, as a UTR inside "UPI/P2A/<utr>/NAME" is masked on its own)
  const toks = (hay.match(/[A-Za-z0-9][A-Za-z0-9\/_-]{5,}|\d[\d -]{6,}\d/g) || []).concat(hay.match(/\d{8,}/g) || []).map((t) => t.trim());
  const back = (v) => {
    if (typeof v !== 'string' || v.indexOf('••') < 0) return v;
    const exact = toks.find((t) => E.redact(t) === v);
    if (exact) return exact;
    // the masked number inside a longer answer ("UTR ••1056"): each masked piece put back
    return v.replace(/[A-Za-z0-9\/_-]*••\d{4}/g, (piece) => toks.find((t) => E.redact(t) === piece) || piece);
  };
  const fix = (o) => { for (const k of Object.keys(o)) { if (o[k] && typeof o[k] === 'object') fix(o[k]); else o[k] = back(o[k]); } return o; };
  return (events || []).map((e) => fix(JSON.parse(JSON.stringify(e))));
}
if (!dir) { console.error('usage: node reader/eval.js <dir> [--detail] [--legacy] [--only=a,b] [--split=dev|hold|all]'); process.exit(2); }

const { domainOf, splitOf, fuzzy, instKey, near, FIELDS, get, fieldScore, pair, lc } = require('./score-lib.js');

/* the old reader's record said as events, to score it on the same footing */
function legacyEvents(r) {
  const via = { kind: r.instr === 'card' ? 'card' : r.instr === 'account' ? 'account' : r.instr === 'wallet' ? 'wallet' : 'other', inst: r.inst, last4: r.last4 };
  switch (r.kind) {
    case 'txn': return [{ type: 'move', dir: r.dir, amt: r.amt, date: r.date, via, party: r.party }];
    case 'confirm': return [{ type: 'move', dir: r.dir || 'out', amt: r.amt, date: r.date, via, party: r.party }];
    case 'statement': return [{ type: 'statement', total: r.amt, min: r.min, due: r.due, via }];
    case 'policy': return [{ type: 'policy', action: 'paid', insurer: r.insurer, policyNo: r.last4, premium: r.premium, cover: r.cover }];
    case 'deposit': return [{ type: 'deposit', action: r.depEvent, amt: r.amt, no: r.depNo, rate: r.rate, mat: r.mat, matAmt: r.matAmt, inst: r.inst }];
    case 'investment': return r.rule === 'dividend' ? [{ type: 'dividend', amt: r.amt, company: r.party, date: r.date }] : [{ type: 'ipo', action: 'allotted', amt: r.amt, company: r.party }];
    case 'bill': return [{ type: r.rule === 'mandate-upcoming' || r.rule === 'si-upcoming' ? 'mandate' : 'due', action: 'upcoming', what: 'bill', amt: r.amt, due: r.due, date: r.due }];
    default: return [{ type: 'noise' }];
  }
}

const files = fs.readdirSync(dir).filter((f) => f.endsWith('.gold.json')).map((f) => f.replace(/\.gold\.json$/, '')).filter((n) => !ONLY.length || ONLY.includes(n));
const tally = {};
function T(key) { return tally[key] || (tally[key] = { mails: 0, perfect: 0, types: {}, extra: {}, invented: 0, ms: 0 }); }
const details = [];
const WRONG = [];   // each mail not read perfectly, for --json
const all = [];
for (const name of files) {
  const mails = JSON.parse(fs.readFileSync(path.join(dir, name + '.json'), 'utf8'));
  const gold = JSON.parse(fs.readFileSync(path.join(dir, name + '.gold.json'), 'utf8'));
  const byId = new Map(gold.map((g) => [g.id, g]));
  for (const m of mails) if (byId.get(m.id)) all.push({ name, m, g: byId.get(m.id) });
}
const toMsg = (m) => ({ id: m.id, from: m.from, date: m.date, subject: m.subject, text: m.text || '', html: m.html || '', attachments: (m.attachments || []).map((a) => (typeof a === 'string' ? { filename: a } : a)) });
if (BOOK) all.sort((a, b) => String(a.m.date).localeCompare(String(b.m.date)));
const selfBook = BOOK === 'self' ? R.newBook() : null;
const domOf = (m) => domainOf(m.from);
{
  for (const { name, m, g } of all) {
    const sp = splitOf(m.from);
    if (SPLIT !== 'all' && sp !== SPLIT) continue;
    const msg = { id: m.id, from: m.from, date: m.date, subject: m.subject, text: m.text || '', html: m.html || '', attachments: (m.attachments || []).map((a) => (typeof a === 'string' ? { filename: a } : a)) };
    const t0 = process.hrtime.bigint();
    let pred;
    try {
      if (PRED) { if (!PREDS[m.id]) continue; pred = unmasked(PREDS[m.id], m); }
      else if (LEGACY) pred = legacyEvents(E.parse(msg));
      else if (BOOK === 'self') pred = R.read(msg, { book: selfBook }).events;
      else if (BOOK === 'teach') {
        const book = R.newBook();
        all.forEach((o) => { if (o.m.id !== m.id && domOf(o.m) === domOf(m)) R.teach(book, toMsg(o.m), o.g.events.filter((e) => !e.unsure)); });
        pred = R.read(msg, { book, learn: false }).events;
      } else if (BOOK === 'only') {
        // the book alone, as if the reader had read nothing: only mail whose template another mail taught is scored
        const book = R.newBook();
        all.forEach((o) => { if (o.m.id !== m.id && domOf(o.m) === domOf(m)) R.teach(book, toMsg(o.m), o.g.events.filter((e) => !e.unsure)); });
        const L = R.learning.bookFind(book, R.fingerprint(msg));
        if (!L) continue;
        pred = R.learning.applyBook(L, R.docOf(msg), [], { otp: false, failed: false });
      } else pred = R.read(msg).events;
    } catch (e) { pred = [{ type: 'error', msg: String(e && e.stack || e) }]; }
    const ms = Number(process.hrtime.bigint() - t0) / 1e6;
    const gev = g.events.filter((e) => !e.unsure);
    const unsure = g.events.filter((e) => e.unsure);
    const goldMain = gev.filter((e) => e.type !== 'noise' && e.type !== 'account');
    // noise is right when the gold mail has nothing but noise (and maybe an account) and the reader says nothing else
    const predMain = pred.filter((e) => e.type !== 'noise' && e.type !== 'account');
    const { pairs, extra } = pair(predMain, goldMain);
    const extraReal = extra.filter((p) => !unsure.some((u) => u.type === p.type && fieldScore(p, u).ok >= Math.max(1, fieldScore(p, u).n - 1)));
    const acc = [T('all'), T(sp), T(name)];
    let perfect = true;
    const notes = [];
    for (const x of acc) { x.mails++; x.ms += ms; }
    if (!goldMain.length) {
      // nothing certain in the mail: right if the reader says nothing, or only what the uncertain gold events say
      const ok = !predMain.length || (unsure.length && predMain.every((p) => unsure.some((u) => u.type === p.type && fieldScore(p, u).ok >= Math.max(1, fieldScore(p, u).n - 1))));
      for (const x of acc) { const ty = x.types.noise || (x.types.noise = { gold: 0, found: 0, fields: 0, fieldsOk: 0 }); ty.gold++; if (ok) ty.found++; }
      if (!ok) { perfect = false; notes.push('should be noise: got ' + predMain.map((p) => p.type).join(',')); }
    }
    for (const pr of pairs) {
      for (const x of acc) {
        const ty = x.types[pr.g.type] || (x.types[pr.g.type] = { gold: 0, found: 0, fields: 0, fieldsOk: 0 });
        ty.gold++;
        if (pr.p) { ty.found++; ty.fields += pr.res.n; ty.fieldsOk += pr.res.ok; }
      }
      if (!pr.p) { perfect = false; notes.push(`missed ${pr.g.type} ${JSON.stringify(pr.g)}`); }
      else if (pr.res.bad.length) { perfect = false; notes.push(`${pr.g.type}: ${pr.res.bad.join('; ')}`); }
    }
    for (const p of extraReal) {
      for (const x of acc) x.extra[p.type] = (x.extra[p.type] || 0) + 1;
      perfect = false; notes.push(`extra ${p.type} ${JSON.stringify(p).slice(0, 200)}`);
    }
    // a figure the reader gives that isn't printed in the mail at all
    const text = (m.subject + ' ' + (m.text || '') + ' ' + (m.html || '') + ' ' + (m.html ? E.lib.htmlLines(m.html) : '')).replace(/,/g, '');
    for (const p of pred) for (const k of ['amt', 'total', 'min', 'premium', 'cover', 'matAmt']) {
      const v = p[k];
      if (typeof v === 'number' && v > 0) {
        const s1 = String(v), s2 = v.toFixed(2), s3 = Number.isInteger(v) ? String(v) : '';
        const lakh = /\b(?:lakh|lac|crore|cr)\b/i.test(text);
        if (!text.includes(s1) && !text.includes(s2) && !(s3 && text.includes(s3)) && !lakh) { for (const x of acc) x.invented++; perfect = false; notes.push(`invented ${k}=${v}`); }
      }
    }
    if (perfect) for (const x of acc) x.perfect++;
    else WRONG.push({ id: m.id, set: name, split: sp, notes });
    if (!perfect && (DETAIL && (SPLIT !== 'all' || sp === 'dev'))) details.push(`[${name}] ${m.from} | ${m.subject.slice(0, 70)}\n   ${notes.join('\n   ')}\n   pred: ${JSON.stringify(pred).slice(0, 600)}`);
  }
}
function line(key) {
  const x = tally[key];
  if (!x) return;
  let g = 0, f = 0, fl = 0, flok = 0;
  const per = Object.keys(x.types).sort().map((t) => { const y = x.types[t]; g += y.gold; f += y.found; fl += y.fields; flok += y.fieldsOk; return `${t} ${y.found}/${y.gold}${y.fields ? ' f' + Math.round(100 * y.fieldsOk / y.fields) + '%' : ''}`; }).join('  ');
  const ex = Object.keys(x.extra).map((t) => `${t}:${x.extra[t]}`).join(' ');
  console.log(`${key.padEnd(8)} mails ${x.mails}  perfect ${x.perfect} (${Math.round(100 * x.perfect / x.mails)}%)  events ${f}/${g} (${Math.round(100 * f / Math.max(1, g))}%)  fields ${Math.round(100 * flok / Math.max(1, fl))}%  false ${Object.values(x.extra).reduce((a, b) => a + b, 0)}${ex ? ' [' + ex + ']' : ''}  invented ${x.invented}  ${(x.ms / x.mails).toFixed(1)}ms/mail`);
  console.log('         ' + per);
}
if (DETAIL) details.forEach((d) => console.log(d + '\n'));
console.log(LEGACY ? '== old reader (engine.parse)' : '== new reader');
['all', 'dev', 'hold'].concat(files).forEach(line);
if (JSON_OUT) fs.writeFileSync(JSON_OUT, JSON.stringify(Object.assign({}, tally, { wrong: WRONG }), null, 1));
// the score in one line: whole mails read right and events found, overall and on the senders never tuned to (hold)
const sum = (key) => { const x = tally[key]; if (!x) return null; let g = 0, f = 0; Object.keys(x.types).forEach((t) => { g += x.types[t].gold; f += x.types[t].found; }); const ex = Object.values(x.extra).reduce((a, b) => a + b, 0); return { mails: x.mails, perfect: x.perfect, events: f, of: g, false: ex, invented: x.invented }; };
const SCORE = { all: sum('all'), hold: sum('hold') };
files.forEach((n) => { SCORE[n] = sum(n); });
if (args.includes('--ratchet') && !LEGACY && !PRED && !BOOK && SPLIT === 'all') {
  const rfile = path.join(dir, 'ratchet.json');
  const perfectNow = all.map((x) => x.m.id).filter((id) => !WRONG.some((w) => w.id === id));
  if (args.includes('--accept') || !fs.existsSync(rfile)) {
    fs.writeFileSync(rfile, JSON.stringify(perfectNow.sort(), null, 1) + '\n');
    console.log('corpus ratchet accepted: ' + perfectNow.length + ' mails read right');
  } else {
    const was = JSON.parse(fs.readFileSync(rfile, 'utf8'));
    const broke = WRONG.filter((w) => was.indexOf(w.id) >= 0);
    const gained = perfectNow.filter((id) => was.indexOf(id) < 0).length;
    if (broke.length) {
      console.log('✗ corpus ratchet: ' + broke.length + ' mails read right before and don\'t now:');
      broke.forEach((w) => { const m = all.find((x) => x.m.id === w.id).m; console.log('  [' + w.set + '] ' + m.from + ' | ' + String(m.subject).slice(0, 70) + '\n     ' + w.notes.join('\n     ')); });
      process.exitCode = 1;
    } else console.log('corpus ratchet ok: ' + perfectNow.length + ' right (was ' + was.length + (gained ? ', +' + gained + ': --ratchet --accept' : '') + ')');
  }
}
console.log('SCORE ' + JSON.stringify(SCORE));
