/* kosh statement scorecard.
   node reader/stmt-score.js <dir> [--detail] [--json=out.json] [--ratchet [--accept]]

   <dir> holds statements as the phone hands them to the engine: <name>.json, the arguments of parseDocJSON
   ({text, kind, from, title, grid, sent}: kind "stmt" or "cardstmt", grid the words with where they sit, "" when
   there is none), or <name>.txt, the text alone (kind "cardstmt" when the name says card, else "stmt"). Beside one, a
   <name>.gold.json ({rows: [{date, amt, dir}]}) is what the statement really lists, and its lines are scored against
   it. reader/STMT-SCORE.md says how to dump real ones from the phone; real statements are kept outside the repo (the
   repo's own invented ones are tests/fixtures/stmt).

   Per bank and per sender: statements whose own figures add up (stmtCheck: opening + lines = closing, or a card's
   summary), the printed dated lines read (cover.read of cover.dated), lines found, how many needed a repair (a line
   set right by the statement's own totals), and with gold, line precision and recall by date, amount and direction.

   --ratchet: the statements that add up are remembered in <dir>/stmt-ratchet.json (beside them, never in the repo);
   a change that leaves one of them not adding up, or reads fewer of its gold lines, is named and the run fails.
   --accept remembers today's (after a change that reads more). The last line, SCORE {...}, is counts only: nothing
   from the statements themselves. */
'use strict';
const fs = require('fs');
const path = require('path');
// (KOSH_ENGINE=<file>: another engine.js, to see what a change moved against the one before it)
const E = require(process.env.KOSH_ENGINE ? path.resolve(process.env.KOSH_ENGINE) : path.join(__dirname, '..', 'Kosh', 'engine.js'));
// the sender's own domain: "alerts.sbi.co.in" is sbi.co.in, "credit_cards@icicibank.com" icicibank.com
function senderOf(from) {
  const m = /<([^>]+)>/.exec(from || ''), e = (m ? m[1] : from || '').toLowerCase().trim(), d = (e.split('@')[1] || '').split('.');
  return d.slice(/^(?:co|gov|org|net|ac|com)$/.test(d[d.length - 2] || '') && d.length >= 3 ? -3 : -2).join('.');
}

const args = process.argv.slice(2);
const dir = args.find((a) => !a.startsWith('--'));
const DETAIL = args.includes('--detail');
const JSON_OUT = (args.find((a) => a.startsWith('--json=')) || '').slice(7);
if (!dir) { console.error('usage: node reader/stmt-score.js <dir> [--detail] [--json=out.json] [--ratchet [--accept]]'); process.exit(2); }

function inputOf(file) {
  const full = path.join(dir, file);
  if (/\.txt$/.test(file)) return { text: fs.readFileSync(full, 'utf8'), kind: /card/i.test(file) ? 'cardstmt' : 'stmt', from: '', title: file, grid: '', sent: '' };
  const x = JSON.parse(fs.readFileSync(full, 'utf8'));
  return { text: String(x.text || ''), kind: x.kind || 'stmt', from: x.from || '', title: x.title || '', grid: x.grid || '', sent: x.sent || '' };
}
// a line as gold and reading both say it: its day, sum to the paisa and direction
// (the sum kept in paise, so 249.999 and 250 aren't two sums by a float's whim; shown in rupees)
const lineKey = (r) => String(r.date || '') + ' ' + (r.dir === 'in' ? 'in' : 'out') + ' ₹' + (Math.round(+r.amt * 100) / 100).toFixed(2);
function matchLines(read, gold) {
  const left = {};
  gold.forEach((g) => { const k = lineKey(g); left[k] = (left[k] || 0) + 1; });
  let hit = 0;
  const extra = [];
  read.forEach((r) => { const k = lineKey(r); if (left[k] > 0) { left[k]--; hit++; } else extra.push(k); });
  const missed = [];
  Object.keys(left).forEach((k) => { for (let i = 0; i < left[k]; i++) missed.push(k); });
  return { hit, extra, missed };
}

const files = fs.readdirSync(dir).filter((f) => (/\.json$/.test(f) && !/\.gold\.json$/.test(f) && !/ratchet\.json$/.test(f)) || /\.txt$/.test(f)).sort();
const results = [];
const reads = [];   // (each statement's input and reading, for the templates run below)
for (const f of files) {
  const name = f.replace(/\.(?:json|txt)$/, '');
  const inp = inputOf(f);
  let o, err = '';
  const t0 = Date.now();
  try { o = JSON.parse(E.parseDocJSON(inp.text, inp.kind, inp.from, inp.title, inp.grid, inp.sent)); } catch (e) { err = String(e && e.message || e); o = {}; }
  const ms = Date.now() - t0;
  const ins = E.institution(inp.from || '');
  const rows = o.rows || [];
  const res = { name, bank: ins ? ins.short : '(unknown)', sender: senderOf(inp.from) || '(none)', kind: inp.kind, err, ms,
    ok: o.check ? o.check.ok : null, note: o.check ? o.check.note : '', fixed: !!(o.check && o.check.fixed),
    dated: o.cover ? o.cover.dated : null, read: o.cover ? o.cover.read : rows.length, rows: rows.length, sure: rows.filter((r) => r.chk).length };
  const gfile = path.join(dir, name + '.gold.json');
  if (fs.existsSync(gfile)) {
    const gold = (JSON.parse(fs.readFileSync(gfile, 'utf8')).rows || []);
    const m = matchLines(rows, gold);
    Object.assign(res, { gold: gold.length, hit: m.hit, extra: m.extra, missed: m.missed });
  }
  results.push(res);
  reads.push({ inp, o, sender: res.sender });
}

/* ------------------------------------------------------------ the scorecard */
const pct = (a, b) => (b ? (100 * a / b).toFixed(1) + '%' : '–');
function tally(list) {
  const t = { n: list.length, ok: 0, bad: 0, unknown: 0, dated: 0, read: 0, rows: 0, fixed: 0, gold: 0, hit: 0, found: 0, err: 0 };
  list.forEach((r) => {
    if (r.err) t.err++;
    if (r.ok === true) t.ok++; else if (r.ok === false) t.bad++; else t.unknown++;
    if (r.dated != null) { t.dated += r.dated; t.read += Math.min(r.read, r.dated); }
    t.rows += r.rows; if (r.fixed) t.fixed++;
    if (r.gold != null) { t.gold += r.gold; t.hit += r.hit; t.found += r.rows; }
  });
  return t;
}
function line(label, t) {
  const pr = t.gold ? '  lines P ' + pct(t.hit, t.found) + ' R ' + pct(t.hit, t.gold) : '';
  console.log(label.padEnd(28) + ' ' + String(t.n).padStart(3) + ' stmts  adds up ' + pct(t.ok, t.n).padStart(6) + ' (' + t.ok + ' ok, ' + t.bad + ' not, ' + t.unknown + ' can\'t tell)' +
    '  covered ' + pct(t.read, t.dated).padStart(6) + '  rows ' + t.rows + '  repaired ' + t.fixed + pr + (t.err ? '  THREW ' + t.err : ''));
}
const groups = (key) => { const g = {}; results.forEach((r) => { (g[r[key]] = g[r[key]] || []).push(r); }); return g; };
console.log('== statements: ' + dir);
line('all', tally(results));
console.log('-- by bank');
const byBank = groups('bank');
Object.keys(byBank).sort().forEach((k) => line('  ' + k, tally(byBank[k])));
console.log('-- by sender');
const bySender = groups('sender');
Object.keys(bySender).sort().forEach((k) => line('  ' + k, tally(bySender[k])));
if (DETAIL) {
  console.log('-- each');
  results.forEach((r) => {
    console.log('  ' + r.name + ' [' + r.bank + ', ' + r.kind + '] ' + (r.ok === true ? 'adds up' : r.ok === false ? 'DOES NOT add up' : 'can\'t tell') + (r.fixed ? ' (repaired)' : '') +
      ' · ' + r.read + '/' + r.dated + ' dated lines read · ' + r.ms + ' ms' + (r.err ? ' · THREW ' + r.err : '') + '\n     ' + r.note +
      (r.gold != null ? '\n     gold ' + r.hit + '/' + r.gold + (r.missed.length ? ' · missed ' + r.missed.join(', ') : '') + (r.extra.length ? ' · not in gold ' + r.extra.join(', ') : '') : ''));
  });
}
if (JSON_OUT) fs.writeFileSync(JSON_OUT, JSON.stringify(results, null, 1));

/* ------------------------------------------------------------ the ratchet */
if (args.includes('--ratchet')) {
  const rfile = path.join(dir, 'stmt-ratchet.json');
  const now = {};
  results.forEach((r) => { now[r.name] = { ok: r.ok === true, hit: r.hit == null ? null : r.hit }; });
  if (args.includes('--accept') || !fs.existsSync(rfile)) {
    fs.writeFileSync(rfile, JSON.stringify(now, null, 1) + '\n');
    console.log('statement ratchet accepted: ' + results.filter((r) => r.ok === true).length + ' of ' + results.length + ' add up');
  } else {
    const was = JSON.parse(fs.readFileSync(rfile, 'utf8'));
    const broke = [];
    Object.keys(was).forEach((n) => {
      const a = was[n], b = now[n];
      if (!b) return;   // (a statement taken out of the folder is no regression)
      if (a.ok && !b.ok) broke.push(n + ': added up before, doesn\'t now (' + (results.find((r) => r.name === n) || {}).note + ')');
      else if (a.hit != null && b.hit != null && b.hit < a.hit) broke.push(n + ': ' + b.hit + ' gold lines read, was ' + a.hit);
    });
    const okWas = Object.keys(was).filter((n) => was[n].ok && now[n]).length, okNow = results.filter((r) => r.ok === true).length;
    if (broke.length) {
      console.log('✗ statement ratchet: ' + broke.length + ' read worse than before:');
      broke.forEach((b) => console.log('  ' + b));
      process.exitCode = 1;
    } else console.log('statement ratchet ok: ' + okNow + ' add up (was ' + okWas + (okNow > okWas ? ': --ratchet --accept to keep' : '') + ')');
  }
}
/* ------------------------------------------------------------ layout templates (engine.js › templates-5nov)
   Each statement that adds up leaves its sender's layout (docTemplatesUpdate). Every statement is then read again with
   its own template (a template must read back the statement it came from: "self") and with the templates its sender's
   other statements left, as next month's statement would be ("next"): how many were tried, kept (they added up), and
   rescued (the readers alone didn't add them up, the template did). Counts only. */
const tplT = { learnt: 0, self: 0, selfHit: 0, tried: 0, hit: 0, family: 0, rescued: 0 };
if (E.docTemplatesUpdate) {
  const learnt = reads.map((r) => { try { return E.docTemplatesUpdate({}, r.o, r.inp) || {}; } catch (e) { return {}; } });
  const readWith = (r, T) => { try { return JSON.parse(E.parseDocJSON(r.inp.text, r.inp.kind, r.inp.from, r.inp.title, r.inp.grid, r.inp.sent, JSON.stringify(T))); } catch (e) { return {}; } };
  const bySenderT = {};
  reads.forEach((r, i) => {
    const res = results[i], own = learnt[i], st = bySenderT[r.sender] = bySenderT[r.sender] || { learnt: 0, selfHit: 0, tried: 0, hit: 0, rescued: 0 };
    res.tpl = '';
    if (Object.keys(own).length) {
      tplT.learnt++; st.learnt++; tplT.self++;
      const o = readWith(r, own);
      if (o.tpl && o.tpl.hit) { tplT.selfHit++; st.selfHit++; res.tpl = 'learnt, reads itself back'; } else res.tpl = 'learnt, DOES NOT read itself back';
    }
    const others = {};
    reads.forEach((q, j) => { if (j !== i && q.sender === r.sender) Object.assign(others, learnt[j]); });
    if (!Object.keys(others).length) return;
    const o = readWith(r, others);
    if (!o.tpl || !o.tpl.tried.length) return;
    tplT.tried++; st.tried++;
    if (o.tpl.hit) {
      tplT.hit++; st.hit++; if (o.tpl.via === 'family') tplT.family++;
      if (!(r.o.check && r.o.check.ok === true)) { tplT.rescued++; st.rescued++; }
      res.tpl += (res.tpl ? '; ' : '') + 'read by ' + (o.tpl.via === 'family' ? 'a sibling account\'s' : 'an earlier') + ' template';
    } else res.tpl += (res.tpl ? '; ' : '') + 'a template was tried and didn\'t add up';
  });
  console.log('-- templates (learnt from statements that add up; "next": read by the other statements\' templates)');
  console.log('all'.padEnd(28) + ' learnt ' + tplT.learnt + ' (reads itself back ' + tplT.selfHit + ')  next: tried ' + tplT.tried + ', kept ' + tplT.hit + ' (' + tplT.family + ' by a sibling account), rescued ' + tplT.rescued);
  Object.keys(bySenderT).sort().forEach((k) => { const t = bySenderT[k]; if (t.learnt || t.tried) console.log(('  ' + k).padEnd(28) + ' learnt ' + t.learnt + ' (back ' + t.selfHit + ')  next: tried ' + t.tried + ', kept ' + t.hit + ', rescued ' + t.rescued); });
  if (DETAIL) results.forEach((r) => { if (r.tpl) console.log('  ' + r.name + ': ' + r.tpl); });
}
const all = tally(results);
console.log('SCORE ' + JSON.stringify({ stmts: all.n, ok: all.ok, not: all.bad, unknown: all.unknown, dated: all.dated, read: all.read, rows: all.rows, repaired: all.fixed, gold: all.gold, hit: all.hit, found: all.found, threw: all.err }));
console.log('TEMPLATES ' + JSON.stringify(tplT));
