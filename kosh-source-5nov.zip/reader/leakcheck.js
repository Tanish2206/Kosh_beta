/* node reader/leakcheck.js <corpus dir> <file>...

   Test mail must be invented. This finds, in the given files (the engine-test suites), every figure, code or
   last-four that also appears in the real labelled mail: amounts with paise ("5127.00"), numbers of 4+ digits,
   and codes mixing letters and 5+ digits. Run it on the Mac (where the mail lives) before committing new cases;
   it prints the file, line and the shared token, never the mail. Exits 1 when anything is shared. Common
   figures (round amounts, short numbers, invented runs like 1234 or 7777) are ignored; a masked last four counts
   only when the real mail masks the same four. */
'use strict';
const fs = require('fs');
const path = require('path');
const [dir, ...files] = process.argv.slice(2);
if (!dir || !files.length) { console.error('usage: node reader/leakcheck.js <corpus dir> <file>...'); process.exit(2); }
const real = new Set(), realL4 = new Set();
// distinctive tokens only: amounts that aren't round (₹5,127.00, ₹911.08), long numbers (6+ digits), codes mixing
// capitals and 5+ digits; a masked last four only against the real mail's masked last fours
const grab = (t) => (String(t || '').replace(/(\d),(?=\d)/g, '$1').match(/\b\d+\.\d{2}\b|\b\d{6,}\b|\b(?=[A-Z0-9]*\d{5})(?=[A-Z0-9]*[A-Z])[A-Z0-9]{6,}\b/g) || [])
  .filter((x) => !/^\d+\.\d{2}$/.test(x) || (+x >= 10 && !/\.(?:00|50|99|49)$/.test(x)) || (+x >= 1000 && !/(?:00|50|99|49)\.\d\d$/.test(x)));
const masked = (t) => (String(t || '').match(/(?:x{2,}|\*{2,}|•{2,}|\.{3,}\s?)(\d{4})\b/gi) || []).map((m) => m.slice(-4));
fs.readdirSync(dir).filter((f) => f.endsWith('.json') && !f.endsWith('.gold.json') && !/^(?:CHANGES|ratchet)/.test(f)).forEach((f) => {
  const arr = JSON.parse(fs.readFileSync(path.join(dir, f), 'utf8'));
  if (Array.isArray(arr)) arr.forEach((m) => { const t = (m.subject || '') + ' ' + (m.text || '') + ' ' + (m.html || ''); grab(t).forEach((x) => real.add(x)); masked(t).forEach((x) => realL4.add(x)); });
});
// (public numbers that are not anyone's: helplines, help-article codes, the 9876543210 placeholder)
const PUBLIC = /^(?:1800\d+|1860\d+|HT\d{6}|9876543210)$/;
const boring = (x) => PUBLIC.test(x) || /^(\d)\1+$/.test(x) || /^(?:1234|2345|0000|9999)/.test(x) || /0{4,}/.test(x);
let n = 0;
files.forEach((f) => fs.readFileSync(f, 'utf8').split('\n').forEach((ln, i) => {
  const hits = [...new Set(grab(ln))].filter((x) => real.has(x) && !boring(x));
  masked(ln).forEach((d) => { if (!boring(d) && realL4.has(d)) hits.push('••' + d); });
  if (hits.length) { n++; console.log(path.basename(f) + ':' + (i + 1) + '  ' + [...new Set(hits)].join(' ')); }
}));
console.log(n ? n + ' line(s) share figures with real mail' : 'no figures shared with real mail');
process.exitCode = n ? 1 : 0;
