/* node reader/diff-runs.js <corpus dir> <before.json> <after.json>

   Two scoreboard runs of the same labelled mail (reader/eval.js --json=...), compared mail by mail: which mails a
   change made wrong, which it made right, and which stayed wrong but read differently (better or worse). The ratchet
   (eval.js --ratchet) only guards the mails that were right; this shows everything a change touched. Prints the
   sender and subject of each, so run it where the mail lives (the Mac), never into the repo. */
'use strict';
const fs = require('fs');
const path = require('path');
const [dir, a, b] = process.argv.slice(2);
if (!dir || !a || !b) { console.error('usage: node reader/diff-runs.js <corpus dir> <before.json> <after.json>'); process.exit(2); }
const was = new Map(JSON.parse(fs.readFileSync(a, 'utf8')).wrong.map((w) => [w.id, w.notes.join(' | ')]));
const now = new Map(JSON.parse(fs.readFileSync(b, 'utf8')).wrong.map((w) => [w.id, w.notes.join(' | ')]));
const mail = {};
fs.readdirSync(dir).filter((f) => f.endsWith('.json') && !f.endsWith('.gold.json') && !/^(?:CHANGES|ratchet)/.test(f)).forEach((f) => {
  const arr = JSON.parse(fs.readFileSync(path.join(dir, f), 'utf8'));
  if (Array.isArray(arr)) arr.forEach((m) => { mail[m.id] = { set: f.replace(/\.json$/, ''), m }; });
});
const name = (id) => { const x = mail[id]; return x ? '[' + x.set + '] ' + x.m.from + ' | ' + String(x.m.subject).slice(0, 70) : id; };
const out = { wrong: [], right: [], changed: [] };
now.forEach((n, id) => { if (!was.has(id)) out.wrong.push(id); else if (was.get(id) !== n) out.changed.push(id); });
was.forEach((w, id) => { if (!now.has(id)) out.right.push(id); });
console.log('newly wrong ' + out.wrong.length + ' · newly right ' + out.right.length + ' · read differently ' + out.changed.length);
out.wrong.forEach((id) => console.log('✗ ' + name(id) + '\n     ' + now.get(id).slice(0, 400)));
out.right.forEach((id) => console.log('✓ ' + name(id)));
out.changed.forEach((id) => console.log('~ ' + name(id) + '\n     was: ' + was.get(id).slice(0, 300) + '\n     now: ' + now.get(id).slice(0, 300)));
process.exitCode = out.wrong.length ? 1 : 0;
