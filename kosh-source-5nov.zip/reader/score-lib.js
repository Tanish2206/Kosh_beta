/* What the scoreboard (eval.js) and the calibration (calibrate.js) share: how a reading is matched to its labels.
   Senders are split by a hash of their domain into "dev" (rules are built against it) and "hold" (kept back). */
'use strict';
function domainOf(from) { const m = /<([^>]+)>/.exec(from || ''); const e = (m ? m[1] : from || '').toLowerCase().trim(); return (e.split('@')[1] || '').split('.').slice(-2).join('.'); }
function h(s) { let x = 0; for (const c of s) x = (x * 31 + c.charCodeAt(0)) >>> 0; return x; }
function splitOf(from) { return h(domainOf(from)) % 3 === 0 ? 'hold' : 'dev'; }

const lc = (s) => String(s == null ? '' : s).toLowerCase();
const words = (s) => lc(s).replace(/[^a-z0-9 ]+/g, ' ').split(/\s+/).filter((w) => w.length >= 3 && !/^(?:the|and|for|limited|ltd|private|pvt|india|bank|card|plan|fund|direct|growth)$/.test(w));
function fuzzy(a, b) {
  if (!a || !b) return false;
  const A = lc(a).replace(/[^a-z0-9]/g, ''), B = lc(b).replace(/[^a-z0-9]/g, '');
  if (A && B && (A.includes(B) || B.includes(A))) return true;
  const wa = words(a), wb = words(b);
  return wa.some((w) => wb.includes(w));
}
const INST_ALIAS = { 'au bank': 'au', 'au small finance bank': 'au', 'sbi card': 'sbicard', 'american express': 'amex', 'federal bank': 'federal', 'hdfc bank': 'hdfc', 'axis bank': 'axis', 'kotak mahindra bank': 'kotak', 'yes bank': 'yes', 'yes': 'yes', 'icici bank': 'icici', 'indusind bank': 'indusind', 'catholic syrian bank': 'csb', 'csb bank': 'csb', 'citibank': 'citi', 'citi bank': 'citi', 'rbl bank': 'rbl', 'idfc first': 'idfc', 'idfc first bank': 'idfc' };
const instKey = (s) => { const l = lc(s).trim(); return INST_ALIAS[l] || l.replace(/\s+bank$/, ''); };
const near = (a, b) => typeof a === 'number' && typeof b === 'number' && Math.abs(a - b) < 0.011;

/* the fields checked per type: [name, getter, compare] — a field is only checked when gold has it */
const FIELDS = {
  move: [['dir'], ['amt', near], ['date'], ['via.kind', (p, g, P, G) => p === g || (g === 'card' && G.via && G.via.debit && p === 'account')], ['via.last4', (p, g) => !!p && (p.endsWith(g) || g.endsWith(p))], ['via.inst', (p, g, P, G) => instKey(p) === instKey(g) || (G.via && G.via.kind === 'wallet' && fuzzy(p, g))], ['party', fuzzy], ['ref']],
  statement: [['total', near], ['min', near], ['due'], ['via.last4', (p, g) => !!p && (p.endsWith(g) || g.endsWith(p))], ['via.inst', (p, g) => instKey(p) === instKey(g)]],
  due: [['what'], ['amt', near], ['due']],
  order: [['order'], ['status'], ['total', near]],
  expect: [['what'], ['dir'], ['amt', near], ['by'], ['on']],
  mandate: [['action'], ['amt', near], ['date']],
  ipo: [['action'], ['shares', near], ['amt', near], ['company', fuzzy]],
  dividend: [['amt', near], ['company', fuzzy], ['date']],
  deposit: [['action'], ['amt', near], ['no'], ['rate', near], ['mat'], ['matAmt', near]],
  policy: [['action'], ['insurer', fuzzy], ['policyNo'], ['premium', near], ['cover', near], ['due']],
  fund: [['action'], ['amt', near], ['scheme', fuzzy]],
  trade: [['side'], ['qty', near], ['isin']],
  balance: [['amt', near]],
  account: [['step'], ['via.last4', (p, g) => !!p && (p.endsWith(g) || g.endsWith(p))]],
  noise: [],
};
const get = (o, k) => k.split('.').reduce((x, p) => (x == null ? undefined : x[p]), o);
function fieldScore(p, g) {
  const fs = FIELDS[g.type] || [];
  let ok = 0, n = 0; const bad = [];
  for (const [k, cmp] of fs) {
    const gv = get(g, k);
    if (gv === undefined || gv === null || gv === '') continue;
    n++;
    const pv = get(p, k);
    const good = cmp ? cmp(pv, gv, p, g) : pv === gv;
    if (good) ok++; else bad.push(`${k}: want ${JSON.stringify(gv)} got ${JSON.stringify(pv)}`);
  }
  return { ok, n, bad };
}
/* the best pairing of predicted to gold events of the same type (greedy on field agreement) */
function pair(pred, gold) {
  const used = new Set(), out = [];
  gold.forEach((g, gi) => {
    let best = -1, bs = -1, bres = null;
    pred.forEach((p, pi) => {
      if (used.has(pi) || p.type !== g.type) return;
      const r = fieldScore(p, g);
      const s = r.n ? r.ok / r.n : 1;
      if (s > bs) { bs = s; best = pi; bres = r; }
    });
    if (best >= 0) { used.add(best); out.push({ g, p: pred[best], res: bres }); } else out.push({ g, p: null, res: null });
  });
  const extra = pred.filter((p, pi) => !used.has(pi));
  return { pairs: out, extra };
}


module.exports = { domainOf, splitOf, fuzzy, instKey, near, FIELDS, get, fieldScore, pair, lc };
