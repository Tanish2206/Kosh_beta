# Statement scorecard

`node reader/stmt-score.js <dir> [--detail] [--json=out.json] [--ratchet [--accept]]`

Runs the engine's statement reader (`parseDoc`, through `parseDocJSON`) over every statement in `<dir>` and
reports, overall, per bank and per sender:

- **adds up**: the statement's own figures check out (`check.ok`, from `stmtCheck`: opening balance plus the
  lines comes to the closing balance, or a card's lines come to the summary it prints). "can't tell" is a
  statement that prints nothing to check against.
- **covered**: printed lines with a date and an amount (`cover.dated`) that were read as lines (`cover.read`).
- **rows** found, and **repaired**: statements that only add up after one line was set right by their own totals
  (`check.fixed`).
- with a `<name>.gold.json` beside a statement: line **precision and recall**, a line being its date, its sum to
  the paisa and its direction.

`--ratchet` remembers which statements add up (and how many gold lines each reads) in `<dir>/stmt-ratchet.json`;
a later run where one of them stops adding up, or reads fewer gold lines, names it and exits 1. `--accept` keeps
the new set after a change that reads more. The last line, `SCORE {...}`, is counts only.

The repo's invented examples are in `tests/fixtures/stmt` (`node tests/run.js` runs the scorecard over them).
Real statements never go in the repo: keep them in a folder outside it.

## Input files

Each statement is `<name>.json`, the six arguments `parseDocJSON` takes, as the phone passes them:

```json
{ "text": "…the pages' text…", "kind": "stmt", "from": "alerts@examplebank.com",
  "title": "Account statement", "grid": "grid1\n1,120\t80,140,02/10/2026\t…", "sent": "2026-11-01" }
```

- `kind` is `stmt` (a bank account) or `cardstmt` (a credit card).
- `grid` is every word with where it sits (`grid1`, then `page,y<TAB>x0,x1,word<TAB>…` per line, thousandths of
  the page); `""` when there is none, and the statement is read by its lines alone.
- `<name>.txt` works too: the text only (kind `cardstmt` when the file name says card).

Gold, optional: `<name>.gold.json` = `{ "rows": [ { "date": "2026-10-02", "amt": 250, "dir": "out" }, … ] }`.

## Dumping real statements from the phone

The text and grid come from **`DocText.read(_:)`** (Kosh/Documents.swift), which returns `Read.rows` (the text)
and `Read.grid`. The app keeps them as one string, the grid after `DocText.gridSep`. **`applyDoc(kind:text:from:title:source:sent:owner:key:part:)`**
(Kosh/LiveSession+Statements.swift) splits it again with `DocText.split(_:)` and, for each variant of the body
(split on `DocUnlock.alt`), calls `parseDocJSON` with `[variant, kind, from, title, grid, sent]`.

That call is the place to dump from. A debug-only hook there would write one JSON file per call, with exactly
those six values under the keys above, into the app's Documents folder. You then copy the folder off the
device (Finder › the iPhone › Files, or Xcode › Devices › Download Container) to a folder outside the repo, and
run the scorecard on it. These are real statements, with account numbers, names and payees: keep them on your
machine, and never commit them or the `.json` the scorecard writes with `--json`.

To write a gold file, open the statement PDF and list its lines (date, amount, in or out). Even ten statements
with gold, from the banks you use, show which layouts are read only in part.
