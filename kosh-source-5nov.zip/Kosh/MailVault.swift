import Foundation
import CryptoKit

// MARK: - The money mail, sealed on this phone
//
// Each email kosh reads is kept on this phone, sealed with a key that lives only in this phone's Keychain
// (AES-GCM, compressed first). When kosh's rules learn something new, it reads its own copy again instead of
// asking the inbox (Google allows about 300 emails a minute; this is thousands a second), and a statement it
// opened once is read again from its text without downloading or unlocking it. Nothing here leaves the phone,
// nothing else can open it, and Erase removes the files and the key together.

enum MailVault {
    /// where the sealed copies live. Made (and kept off backups) once, not on every look: this is asked for about a
    /// dozen times a mail, on the main thread, and two directory calls and an attribute write each time froze the
    /// screens for seconds through a re-read of thousands. Erase (here or kosh's own) says it must be made again.
    static var folder: URL {
        dirLock.lock(); defer { dirLock.unlock() }
        if !dirMade {
            var u = base
            try? FileManager.default.createDirectory(at: u, withIntermediateDirectories: true)
            // the sealed mail and papers can be fetched again from the inbox: they stay off backups
            var v = URLResourceValues(); v.isExcludedFromBackup = true
            try? u.setResourceValues(v)
            dirMade = true
        }
        return base
    }
    private static let base: URL = LiveSession.folder.appendingPathComponent("vault", isDirectory: true)
    private static let dirLock = NSLock()
    nonisolated(unsafe) private static var dirMade = false
    /// the folder is gone (Erase removed it, or kosh's whole folder): the next look makes it again
    static func folderGone() { dirLock.lock(); dirMade = false; dirLock.unlock() }
    private static let keyName = "vault.key"
    private static let lock = NSLock()
    nonisolated(unsafe) private static var cached: SymmetricKey?
    /// writes go one at a time, off the main thread
    private static let queue = DispatchQueue(label: "kosh.vault", qos: .utility)

    /// the key, made the first time; nil while the Keychain is locked (then nothing is written or read)
    private static func key() -> SymmetricKey? {
        lock.lock(); defer { lock.unlock() }
        if let k = cached { return k }
        let saved = Keychain.get(keyName)
        if let saved, let d = Data(base64Encoded: saved), d.count == 32 {
            cached = SymmetricKey(data: d)
            return cached
        }
        // a new key only when there's none: one the Keychain can't read yet (the phone not unlocked since it
        // started) is waited for, or every copy sealed with it would be lost
        guard saved != nil || Keychain.missing(keyName) else { return nil }
        let k = SymmetricKey(size: .bits256)
        let raw = k.withUnsafeBytes { Data($0) }
        Keychain.set(raw.base64EncodedString(), for: keyName)
        // the Keychain may be locked (kosh woke before the phone was first unlocked): a key it couldn't keep isn't used
        guard Keychain.get(keyName) == raw.base64EncodedString() else { return nil }
        cached = k
        return k
    }

    private static func name(_ id: String) -> String {
        String(id.unicodeScalars.map { CharacterSet.alphanumerics.contains($0) || $0 == "-" ? Character($0) : "_" }) + "-" + String(UInt32(truncatingIfNeeded: LiveSession.stable(id)), radix: 36)
    }
    private static func mailURL(_ id: String) -> URL { folder.appendingPathComponent(name(id) + ".mail") }
    private static func textURL(_ key: String) -> URL { folder.appendingPathComponent("doc-" + name(key) + ".text") }

    private static func seal(_ data: Data) -> Data? {
        guard let k = key(), let packed = try? (data as NSData).compressed(using: .lzfse) as Data,
              let box = try? AES.GCM.seal(packed, using: k) else { return nil }
        return box.combined
    }
    private static func open(_ data: Data) -> Data? {
        guard let k = key(), let box = try? AES.GCM.SealedBox(combined: data), let packed = try? AES.GCM.open(box, using: k) else { return nil }
        return try? (packed as NSData).decompressed(using: .lzfse) as Data
    }

    /// keep an email as kosh read it: as much of it as a first read sees (MailMsg's limits), so reading it again from
    /// here reads exactly what the first read did
    static func put(_ m: MailMsg, id: String) {
        var x = m
        x.text = String(x.text.prefix(MailMsg.textLimit))
        x.html = String(x.html.prefix(MailMsg.htmlLimit))
        let kept = x
        queue.async {
            // (the mail in its head, so a later kosh knows the shape it was kept in: SavedFormat)
            guard let d = try? JSONEncoder().encode(kept), let sealed = seal(SavedFormat.seal(d, .mail)) else { return }
            try? sealed.write(to: mailURL(id), options: [.atomic, LiveSession.protection])
        }
    }
    /// the same, written before this returns (an SMS is read into the ledger right after it is kept); false when it
    /// couldn't be sealed or written (the Keychain or the files not readable yet): the caller holds it (AlertIntake.hold)
    @discardableResult
    static func putNow(_ m: MailMsg, id: String) -> Bool {
        queue.sync {
            guard let d = try? JSONEncoder().encode(m), let sealed = seal(SavedFormat.seal(d, .mail)) else { return false }
            return (try? sealed.write(to: mailURL(id), options: [.atomic, LiveSession.protection])) != nil
        }
    }
    /// one kept message gone (an SMS that turned out not to be a payment)
    static func drop(_ id: String) {
        queue.async { try? FileManager.default.removeItem(at: mailURL(id)) }
    }
    static func get(_ id: String) -> MailMsg? {
        guard let d = try? Data(contentsOf: mailURL(id)), let raw = open(d) else { return nil }
        // (kept by any kosh, in any shape: SavedFormat)
        return try? SavedFormat.decode(MailMsg.self, raw, .mail).value
    }
    static func has(_ id: String) -> Bool { FileManager.default.fileExists(atPath: mailURL(id).path) }

    /// a statement's text, as opened: read again later without downloading or unlocking it
    static func putText(_ text: String, key k: String) {
        queue.async {
            guard let sealed = seal(Data(text.utf8)) else { return }
            try? sealed.write(to: textURL(k), options: [.atomic, LiveSession.protection])
        }
    }
    static func getText(_ k: String) -> String? {
        guard let d = try? Data(contentsOf: textURL(k)), let raw = open(d) else { return nil }
        return String(data: raw, encoding: .utf8)
    }

    /// how many emails are kept, and the space they take
    static func size() -> (count: Int, bytes: Int) {
        let fm = FileManager.default
        guard let items = try? fm.contentsOfDirectory(at: folder, includingPropertiesForKeys: [.fileSizeKey]) else { return (0, 0) }
        var n = 0, b = 0
        for u in items {
            if u.pathExtension == "mail" { n += 1 }
            b += (try? u.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0
        }
        return (n, b)
    }

    /// everything kept, and the key: gone for good
    static func erase() {
        queue.sync {}
        try? FileManager.default.removeItem(at: base)
        folderGone()
        lock.lock(); cached = nil; lock.unlock()
        Keychain.set(nil, for: keyName)
    }
}
