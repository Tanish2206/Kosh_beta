import SwiftUI

// MARK: - Trips found in the mail, looked over before they're chapters
//
// The bookings in the mail make a trip (trips.js): where and when from the flights, trains and stays, the payments
// that booked them, and what was spent around it that looks like the trip's (food and stays there, cabs, forex bought
// the month before). The sheet lists every one of those, each ticked and yours to untick, with what the ticked ones
// come to and the days they run over; one tap makes it a chapter and files them, "Not a trip" never offers it again.

enum DraftWords {
    /// its days with their year, as a trip's dates are said away from the calendar: "3 – 7 Mar 2026"
    static func span(_ a: String, _ b: String) -> String {
        if a.isEmpty { return "" }
        if b.isEmpty || b == a { return Day.fmt(a, "d MMM yyyy") }
        if a.prefix(7) == b.prefix(7) { return Day.fmt(a, "d") + " – " + Day.fmt(b, "d MMM yyyy") }
        if a.prefix(4) == b.prefix(4) { return Day.fmt(a, "d MMM") + " – " + Day.fmt(b, "d MMM yyyy") }
        return Day.fmt(a, "d MMM yyyy") + " – " + Day.fmt(b, "d MMM yyyy")
    }
    /// what the bookings were: "2 flights and a stay, from Kochi"
    static func booked(_ d: TripDraft) -> String {
        let k: [String: Int] = d.kinds ?? [:]
        var parts: [String] = []
        for (key, one, many) in [("flight", "a flight", "flights"), ("train", "a train", "trains"), ("bus", "a bus", "buses"), ("stay", "a stay", "stays")] {
            if let n = k[key], n > 0 { parts.append(n == 1 ? one : String(n) + " " + many) }
        }
        let list: String = parts.isEmpty ? "bookings" : Words.list(parts)
        let from: String = (d.home ?? "").isEmpty ? "" : ", from " + (d.home ?? "")
        return Words.cap(list) + from
    }
    /// everything offered with it, and the days it ran over: "₹36,300 over 4 payments, 1 Feb – 6 Mar 2026"
    static func offered(_ d: TripDraft) -> String {
        let n: Int = d.pay.count + (d.near ?? []).count
        if n == 0 { return "No payments found for it yet." }
        let total: Double = d.paid + (d.nearPaid ?? 0)
        let count: String = n == 1 ? "1 payment" : String(n) + " payments"
        let days: String = span(d.payFrom ?? d.from, d.payTo ?? d.to)
        return Fmt.rupees(total) + " over " + count + ", " + days
    }
}

/// a found trip's sheet, from wherever it's offered; the chapter it becomes opens once the sheet has gone
struct TripDraftPresenter: ViewModifier {
    @Environment(Store.self) private var store
    @Binding var draft: TripDraft?
    @State private var opened: String? = nil
    func body(content: Content) -> some View {
        content
            .sheet(item: $draft, onDismiss: {
                if let id = opened {
                    opened = nil
                    store.push(.chapter(id))
                }
            }) { d in
                TripDraftSheet(draft: d, made: { id in opened = id })
                    .environment(store)
                    .presentationDragIndicator(.visible)
            }
    }
}

struct TripDraftSheet: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    let draft: TripDraft
    /// the chapter it became
    var made: ((String) -> Void)? = nil
    /// what it offers, looked up once when the sheet opens (the payments don't change under an open sheet)
    @State private var rows: [Txn] = []
    @State private var loaded = false
    /// the payments you unticked
    @State private var off: Set<String> = []

    var body: some View {
        let picked: [Txn] = rows.filter { !off.contains($0.id) }
        let total: Double = picked.reduce(0) { $0 + $1.a }
        let days: [String] = picked.map { $0.od ?? $0.d }.sorted()
        let booked: Set<String> = Set(draft.pay)
        let bookedRows: [Txn] = rows.filter { booked.contains($0.id) }
        let beforeRows: [Txn] = rows.filter { !booked.contains($0.id) && ($0.od ?? $0.d) < draft.from }
        let thereRows: [Txn] = rows.filter { !booked.contains($0.id) && ($0.od ?? $0.d) >= draft.from }
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 0) {
                    head
                    VStack(alignment: .leading, spacing: 2) {
                        Text(Fmt.rupees(total))
                            .font(.system(.largeTitle, design: .serif, weight: .bold))
                            .contentTransition(.numericText(value: total))
                            .privacySensitive()
                        Text(Self.totalLine(picked.count, of: rows.count, days: days))
                            .font(.subheadline).foregroundStyle(.secondary)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                    .padding(.top, 22)
                    .animation(Motion.base, value: off)
                    if rows.isEmpty && loaded {
                        Text("kosh found the bookings but no payments for them yet. Make it a chapter and what's spent on its days goes in on its own.")
                            .font(.subheadline).foregroundStyle(.secondary)
                            .fixedSize(horizontal: false, vertical: true)
                            .padding(.top, 16)
                    }
                    group("What booked it", bookedRows)
                    group("Forex, the month before", beforeRows)
                    group("On its days", thereRows)
                    if !rows.isEmpty {
                        Text("Untick anything that wasn't part of it: it stays out of this chapter and any other.")
                            .font(.footnote).foregroundStyle(.secondary)
                            .fixedSize(horizontal: false, vertical: true)
                            .padding(.top, 18)
                    }
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 24)
            }
            .scrollIndicators(.hidden)
            .safeAreaInset(edge: .bottom, spacing: 0) { actions(picked.count) }
            .navigationTitle("Found in your mail")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Close") { dismiss() } }
            }
        }
        .sensoryFeedback(.selection, trigger: off)
        .onAppear {
            guard !loaded else { return }
            loaded = true
            rows = store.draftRows(draft)
        }
    }

    /// where and when, from the bookings, under the trip's stamp
    var head: some View {
        let kind: String = ChapterKinds.kind(forSym: "airplane", event: false)
        let art: StampArt = Stamps.custom(title: draft.place, kind: kind, fam: .journey, from: draft.from, ink: Color(hex: "#FF9500").mix(with: .black, by: 0.22))
        let nights: Int = Day.between(draft.from, draft.to)
        let length: String = nights <= 0 ? "a day" : TripWhen.days(nights + 1)
        return HStack(alignment: .top, spacing: 12) {
            VStack(alignment: .leading, spacing: 0) {
                Eyebrow(text: "From your bookings", color: Color.kosh)
                Text(draft.name + "?")
                    .font(.system(.title, design: .serif, weight: .semibold))
                    .fixedSize(horizontal: false, vertical: true)
                    .padding(.top, 5)
                Text(DraftWords.span(draft.from, draft.to) + " · " + length)
                    .font(.subheadline).foregroundStyle(.secondary).padding(.top, 3)
                Text(DraftWords.booked(draft))
                    .font(.subheadline).foregroundStyle(.secondary).padding(.top, 1)
            }
            Spacer(minLength: 0)
            StampView(art: art, size: 84, rotation: 6, dashed: true)
        }
        .padding(.top, 8)
    }

    @ViewBuilder func group(_ title: String, _ xs: [Txn]) -> some View {
        if !xs.isEmpty {
            VStack(alignment: .leading, spacing: 10) {
                Text(title).font(.system(.title3, design: .serif, weight: .semibold))
                VStack(spacing: 14) {
                    ForEach(xs) { t in row(t) }
                }
                .card(14)
            }
            .padding(.top, 26)
        }
    }

    func row(_ t: Txn) -> some View {
        let on: Bool = !off.contains(t.id)
        let when: String = Day.fmt(t.od ?? t.d, "EEE d MMM")
        return Button {
            withAnimation(Motion.quick) {
                if on { off.insert(t.id) } else { off.remove(t.id) }
            }
        } label: {
            HStack(spacing: 12) {
                Image(systemName: on ? "checkmark.circle.fill" : "circle")
                    .font(.title3)
                    .foregroundStyle(on ? Color.kosh : Color.secondary)
                    .contentTransition(.symbolEffect(.replace))
                IconTile(symbol: t.sym, color: store.color(for: t), size: 32)
                VStack(alignment: .leading, spacing: 1) {
                    Text(t.m).font(.subheadline.weight(.semibold)).foregroundStyle(Color.primary).lineLimit(1)
                    Text(store.catLine(t) + " · " + when).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                }
                Spacer(minLength: 8)
                Text(Fmt.rupees(t.a)).font(.subheadline.weight(.semibold)).monospacedDigit()
                    .foregroundStyle(on ? Color.primary : Color.secondary)
                    .strikethrough(!on)
                    .privacySensitive()
            }
            .contentShape(Rectangle())
        }
        .buttonStyle(.press)
        .accessibilityAddTraits(on ? .isSelected : [])
        .accessibilityHint(on ? "Ticked: goes in the chapter" : "Unticked: stays out")
    }

    func actions(_ n: Int) -> some View {
        VStack(spacing: 10) {
            Button {
                let id: String = store.startDraft(draft, skip: off)
                // (only a chapter that was made opens: the bundled snapshots make none)
                if store.live != nil { made?(id) }
                dismiss()
            } label: {
                Text(Self.makeLine(n))
                    .font(.body.weight(.semibold))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 4)
            }
            .buttonStyle(.glassProminent).koshFilled()
            .controlSize(.large)
            Button("Not a trip") {
                withAnimation(Motion.open) { store.live?.dropTripDraft(draft.id) }
                dismiss()
            }
            .font(.subheadline.weight(.semibold))
            .foregroundStyle(.secondary)
        }
        .padding(.horizontal, 24)
        .padding(.top, 12)
        .padding(.bottom, 8)
        .background(.bar)
    }

    /// "4 of 6 payments ticked, paid 1 Feb – 6 Mar 2026"
    static func totalLine(_ n: Int, of all: Int, days: [String]) -> String {
        if all == 0 { return "Nothing paid for it yet" }
        if n == 0 { return "Nothing ticked: the chapter starts empty" }
        var count: String = String(n) + " of " + String(all) + " payments"
        if n == all { count = n == 1 ? "1 payment" : "All " + String(n) + " payments" }
        let span: String = DraftWords.span(days.first ?? "", days.last ?? "")
        return count + " ticked, paid " + span
    }
    static func makeLine(_ n: Int) -> String {
        if n == 0 { return "Make this a chapter" }
        if n == 1 { return "Make this a chapter, with 1 payment" }
        return "Make this a chapter, with " + String(n) + " payments"
    }
}

/// a found trip in the list of every chapter: tap to look it over
struct TripDraftRow: View {
    let draft: TripDraft
    var body: some View {
        HStack(spacing: 12) {
            IconTile(symbol: "envelope.badge", color: Color.kosh, size: 38)
            VStack(alignment: .leading, spacing: 2) {
                Text(draft.name + "?").font(.body.weight(.semibold)).lineLimit(1)
                Text(DraftWords.span(draft.from, draft.to) + " · " + DraftWords.booked(draft))
                    .font(.caption).foregroundStyle(.secondary).lineLimit(1)
                Text(DraftWords.offered(draft)).font(.caption).foregroundStyle(.secondary).lineLimit(1).privacySensitive()
            }
            Spacer(minLength: 8)
            Image(systemName: "chevron.right").font(.footnote.weight(.semibold)).foregroundStyle(.tertiary)
        }
        .contentShape(Rectangle())
    }
}
