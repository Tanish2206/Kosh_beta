import SwiftUI

// MARK: - Insurance › Payments: what falls due, in a range you pick
//
// Opened from the home's "Up next › Timeline" (Route.cover("Payments")). A range (7 days, 30 days, this month, three
// months, six), what falls due in it and what the known premiums add up to, the next six months by kind, a runway from
// today to the range's end with a dot for each premium sized by its amount, then month by month every premium. All of
// it from the build's premiums ahead (InsTimeline, InsuranceModel.swift); a premium with no figure is listed, never ₹0.

struct InsPaymentsPage: View {
    @Environment(Store.self) private var store
    @State private var range: InsRange = .d30
    var body: some View {
        let home: InsHome = store.insuranceHome
        let t: InsTimeline = InsTimeline.make(home.next, today: store.snap.today, range: range)
        ScrollView {
            VStack(alignment: .leading, spacing: 0) {
                ObsidianChips(items: InsRange.allCases.map { ($0, $0.label) }, picked: $range)
                InsPayHead(t: t).padding(.top, 30)
                InsSixMonths(t: t).padding(.top, 26)
                InsRunway(t: t).padding(.top, 12)
                if t.items.isEmpty {
                    VStack(spacing: 6) {
                        Text("Nothing due. Enjoy the quiet.").font(.system(size: 16, weight: .medium)).foregroundStyle(Obsidian.ink)
                        Text(range == .m6 ? "No premium or renewal falls in the next six months." : "Widen the range to see what is coming.")
                            .font(.system(size: 13)).foregroundStyle(Obsidian.ink3)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 32).padding(.horizontal, 20)
                    .overlay(RoundedRectangle(cornerRadius: 24, style: .continuous).strokeBorder(Color.white.opacity(0.14), style: StrokeStyle(lineWidth: 1, dash: [4, 4])))
                    .padding(.top, 40)
                }
                ForEach(t.groups) { (g: InsMonthGroup) in InsPayMonth(g: g).padding(.top, 30) }
            }
            .padding(.horizontal, 20)
            .padding(.top, 8)
            .padding(.bottom, 40)
            .animation(Motion.base, value: range)
        }
        .navigationTitle("Payments")
        .toolbarTitleDisplayMode(.large)
        .obsidianPage(aura: Obsidian.savings)
    }
}

/// the range's head: what it covers, its total, and a line on it
struct InsPayHead: View {
    @Environment(Store.self) private var store
    let t: InsTimeline
    static func head(_ t: InsTimeline, today: String) -> String {
        switch t.range {
        case .d7: return "Due in the next 7 days"
        case .d30: return "Due in the next 30 days"
        case .m1: return "Due in " + Day.fmt(today, "MMMM")
        default:
            return "Due " + Day.fmt(today, "MMMM") + " – " + Day.fmt(t.end, "MMMM")
        }
    }
    var body: some View {
        let n: Int = t.items.count
        let pays: String = n == 1 ? "1 payment" : "\(n) payments"
        let auto: String = t.auto > 0 ? " · \(t.auto) on autopay" : ""
        let big: String = t.largest.map { (d: InsDue) -> String in
            let name: String = InsBook.policy(store, d.a.policy).map { InsBook.name($0) } ?? (d.a.name.isEmpty ? d.a.insurer : d.a.name)
            return " Largest is " + name + " at " + Fmt.rupees(d.a.amt) + "."
        } ?? ""
        let unknown: String = t.unknown > 0 ? " " + Words.cap(Words.number(t.unknown)) + (t.unknown == 1 ? " has" : " have") + " no figure yet." : ""
        let line: String = n == 0 ? "Nothing falls in this window." : pays + auto + "." + big + unknown
        VStack(alignment: .leading, spacing: 0) {
            Text(Self.head(t, today: store.snap.today)).caption()
            Text(Fmt.rupees(t.total)).font(.system(size: 56, weight: .semibold)).monospacedDigit().tracking(-2.5).foregroundStyle(Obsidian.ink)
                .lineLimit(1).minimumScaleFactor(0.5).padding(.top, 10).privacySensitive()
                .contentTransition(.numericText())
            Text(line).font(.system(size: 13.5)).foregroundStyle(Obsidian.ink2).fixedSize(horizontal: false, vertical: true).padding(.top, 12)
        }
        .accessibilityElement(children: .combine)
    }
}

/// the next six months, each a stack of its kinds; the months the range doesn't reach dimmed
struct InsSixMonths: View {
    let t: InsTimeline
    var body: some View {
        let count: String = t.sixN == 1 ? "1 payment" : "\(t.sixN) payments"
        VStack(alignment: .leading, spacing: 14) {
            HStack(alignment: .firstTextBaseline) {
                Text("Next six months").font(.system(size: 13, weight: .medium)).foregroundStyle(Obsidian.ink)
                Spacer(minLength: 8)
                Text(Fmt.rupees(t.sixTotal) + " · " + count).font(.system(size: 11, design: .monospaced)).monospacedDigit().foregroundStyle(Obsidian.ink3).privacySensitive()
            }
            HStack(alignment: .bottom, spacing: 10) {
                ForEach(t.bars) { (b: InsMonthBar) in InsMonthStack(b: b, top: t.barMax) }
            }
            .frame(height: 104)
            HStack(spacing: 10) {
                ForEach(t.bars) { (b: InsMonthBar) in
                    VStack(spacing: 2) {
                        Text(Day.fmt(b.m + "-01", "MMM")).font(.system(size: 11, design: .monospaced)).foregroundStyle(Obsidian.ink2)
                        Text(b.total > 0 ? Fmt.short(b.total) : "—").font(.system(size: 10.5, design: .monospaced)).monospacedDigit().foregroundStyle(Obsidian.ink3).lineLimit(1).minimumScaleFactor(0.7)
                    }
                    .frame(maxWidth: .infinity)
                    .opacity(b.inRange ? 1 : 0.22)
                }
            }
        }
        .obsidianCard(24, padding: 16)
        .privacySensitive()
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("Next six months: " + t.bars.map { Day.fmt($0.m + "-01", "MMMM") + " " + Fmt.words($0.total) }.joined(separator: ", "))
    }
}

struct InsMonthStack: View {
    let b: InsMonthBar
    let top: Double
    var body: some View {
        VStack(spacing: 2) {
            Spacer(minLength: 0)
            ForEach(Array(b.parts.reversed().enumerated()), id: \.offset) { pair in
                let h: CGFloat = top > 0 ? max(3, CGFloat(pair.element.amt / top) * 100) : 0
                RoundedRectangle(cornerRadius: 5, style: .continuous).fill(InsLook.color(pair.element.kind)).frame(height: h)
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .opacity(b.inRange ? 1 : 0.22)
        .animation(Motion.open, value: b.inRange)
    }
}

/// from today to the range's end: a dot for each premium, sized by its amount, in its kind's colour
struct InsRunway: View {
    @Environment(Store.self) private var store
    let t: InsTimeline
    var body: some View {
        let top: Double = t.items.map(\.a.amt).max() ?? 1
        let endWord: String = t.range == .m1 || t.range == .m3 || t.range == .m6 ? "End of " + Day.fmt(t.end, "MMM") : Day.fmt(t.end, "d MMM")
        VStack(spacing: 0) {
            GeometryReader { geo in
                let w: CGFloat = geo.size.width
                ZStack(alignment: .leading) {
                    LinearGradient(colors: [Color.white.opacity(0.35), Color.white.opacity(0.06)], startPoint: .leading, endPoint: .trailing).frame(height: 1)
                    RoundedRectangle(cornerRadius: 1).fill(Obsidian.ink).frame(width: 2, height: 17)
                    ForEach(t.items.sorted { $0.a.amt > $1.a.amt }) { (d: InsDue) in
                        let s: CGFloat = CGFloat(10 + (d.known ? (d.a.amt / max(1, top)).squareRoot() * 20 : 0))
                        let x: CGFloat = w * CGFloat(min(0.97, max(0.03, Double(max(0, d.days)) / Double(t.span))))
                        Circle().fill(InsLook.color(d.kind)).frame(width: s, height: s)
                            .overlay(Circle().strokeBorder(Obsidian.card, lineWidth: 2))
                            .shadow(color: InsLook.color(d.kind).opacity(0.55), radius: 9)
                            .position(x: x, y: 27)
                    }
                }
                .frame(height: 54)
            }
            .frame(height: 54)
            HStack {
                Text("Today · " + Day.fmt(store.snap.today, "d MMM"))
                Spacer()
                Text(endWord)
            }
            .font(.system(size: 10.5, design: .monospaced)).foregroundStyle(Obsidian.ink3)
        }
        .obsidianCard(24, padding: 16)
        .accessibilityHidden(true)
    }
}

/// a month of premiums: its name and total, then each on a rail by its day
struct InsPayMonth: View {
    let g: InsMonthGroup
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(alignment: .firstTextBaseline) {
                Text(Day.fmt(g.m + "-01", "MMMM yyyy")).font(.system(size: 17, weight: .semibold)).foregroundStyle(Obsidian.ink).accessibilityAddTraits(.isHeader)
                Spacer(minLength: 8)
                Text(Fmt.rupees(g.total) + " · \(g.items.count)").font(.system(size: 12, design: .monospaced)).monospacedDigit().foregroundStyle(Obsidian.ink2).privacySensitive()
            }
            ZStack(alignment: .topLeading) {
                Rectangle().fill(Color.white.opacity(0.09)).frame(width: 1).padding(.leading, 59).padding(.vertical, 14)
                VStack(spacing: 0) {
                    ForEach(g.items) { (d: InsDue) in InsPayRow(d: d) }
                }
            }
        }
    }
}

struct InsPayRow: View {
    @Environment(Store.self) private var store
    let d: InsDue
    var body: some View {
        let p: Policy? = InsBook.policy(store, d.a.policy)
        let name: String = p.map { InsBook.name($0) } ?? (d.a.name.isEmpty ? d.a.insurer : d.a.name)
        let sub: String = [InsLook.person(store, d.a.owner), d.every].filter { !$0.isEmpty }.joined(separator: " · ")
        let tint: Color = InsLook.color(d.kind)
        Button { store.push(.policy(d.a.policy)) } label: {
            HStack(spacing: 0) {
                VStack(alignment: .trailing, spacing: 4) {
                    Text(Day.fmt(d.a.date, "d")).font(.system(size: 22, weight: .semibold)).monospacedDigit().tracking(-0.6).foregroundStyle(Obsidian.ink)
                    Text(Day.fmt(d.a.date, "EEE")).caption()
                }
                .frame(width: 44, alignment: .trailing)
                Circle().fill(tint).frame(width: 11, height: 11)
                    .overlay(Circle().stroke(Obsidian.bg, lineWidth: 4))
                    .shadow(color: tint.opacity(0.55), radius: 8)
                    .frame(width: 30)
                HStack(spacing: 10) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(name).font(.system(size: 14.5, weight: .medium)).foregroundStyle(Obsidian.ink).lineLimit(1)
                        HStack(spacing: 6) {
                            Text(sub).font(.system(size: 12)).foregroundStyle(Obsidian.ink3).lineLimit(1)
                            if d.auto { InsAutoTag() }
                        }
                    }
                    Spacer(minLength: 4)
                    VStack(alignment: .trailing, spacing: 4) {
                        if d.known {
                            Text(Fmt.rupees(d.a.amt)).font(.system(size: 15, weight: .semibold)).monospacedDigit().foregroundStyle(Obsidian.ink).privacySensitive()
                        } else {
                            Text(d.a.noAmt == "locked" ? "Paper locked" : "Not known").font(.system(size: 12)).foregroundStyle(Obsidian.ink3)
                        }
                        Text(InsLook.when(d.days)).font(.system(size: 11, design: .monospaced)).foregroundStyle(InsLook.whenColor(d.days))
                    }
                }
                .padding(.horizontal, 14).padding(.vertical, 13)
                .background(Obsidian.card, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).strokeBorder(Obsidian.cardBorder, lineWidth: 1))
            }
            .padding(.vertical, 5)
            .contentShape(Rectangle())
        }
        .buttonStyle(.press)
        .accessibilityElement(children: .combine)
    }
}
