import SwiftUI
import Charts

struct RouteDestination: View {
    let route: Route
    let zoom: Namespace.ID?
    var body: some View {
        // the main tabs keep their title on the top row (inline large); a page pushed from them that doesn't say
        // otherwise keeps the large title under the back button it always had
        switch route {
        case .month(let m):
            if let zoom {
                MonthDetail(m: m).navigationTransition(.zoom(sourceID: m, in: zoom)).toolbarTitleDisplayMode(.large)
            } else {
                MonthDetail(m: m).toolbarTitleDisplayMode(.large)
            }
        case .holdings(let k): HoldingsView(cls: k).toolbarTitleDisplayMode(.large)
        case .category(let c, let m): CategoryView(cat: c, month: m).toolbarTitleDisplayMode(.large)
        case .committee(let id): CommitteePage(id: id).toolbarTitleDisplayMode(.large)
        case .policy(let id): InsPolicyScreen(id: id)
        case .module(let t): ModulePage(tab: t)
        case .account(let id): AccountPage(id: id)
        case .refunds: RefundsPage().toolbarTitleDisplayMode(.large)
        case .repeats: RecurringView().navigationTitle("Repeats").toolbarTitleDisplayMode(.large)
        case .trips: TripsPage().toolbarTitleDisplayMode(.large)
        case .trip(let id): ChapterPage(id: id)
        case .chapter(let id):
            if let zoom {
                ChapterPage(id: id).navigationTransition(.zoom(sourceID: id, in: zoom))
            } else {
                ChapterPage(id: id)
            }
        case .chapterPayments(let id): ChapterPayments(id: id)
        case .chapterGroup(let id): ChapterGroupPage(id: id)
        case .shop(let id): ShopPage(id: id)
        case .find: LedgerFind()
        case .platform(let name, let cat, let span): PlatformPage(name: name, cat: cat, span: span)
        case .calendar: CalendarView().navigationTitle("Calendar").toolbarTitleDisplayMode(.large)
        case .deposit(let id): DepositPage(id: id)
        case .ppf(let id): PPFAccountPage(id: id)
        case .cover(let part): InsurancePart(part: part)
        case .details(let who): DetailsPage(person: who.isEmpty ? nil : who)
        case .dividends: DividendsBook().toolbarTitleDisplayMode(.large)
        case .maturities: DepositDatesPage().toolbarTitleDisplayMode(.large)
        case .review: MonthReviewPage().toolbarTitleDisplayMode(.large)
        case .wealthFunds: WealthFunds()
        case .wealthDeposits: WealthDeposits()
        case .persona: PersonaPage().toolbarTitleDisplayMode(.large)
        case .lifeEvent(let id): LifeEventPage(id: id)
        case .personaTrip(let id): PersonaTripPage(id: id)
        case .personaPerson(let key): PersonaPersonPage(key: key)
        case .personaHabit(let k): PersonaHabitPage(k: k)
        case .payments(let title, let sub, let ids): PaymentsPage(title: title, sub: sub, ids: ids)
        case .homes: HomesPage().toolbarTitleDisplayMode(.large)
        case .home(let id): HomePage(id: id).toolbarTitleDisplayMode(.large)
        case .billKind(let k): BillKindPage(k: k).toolbarTitleDisplayMode(.large)
        }
    }
}

// MARK: - One month, opened out of its card

struct MonthDetail: View {
    @Environment(Store.self) private var store
    let m: String
    @State private var selDay: Int?
    @State private var shown: Double = 0

    var body: some View {
        if let mo = store.month(m) {
            content(mo)
        } else {
            ContentUnavailableView("No such month", systemImage: "calendar")
        }
    }

    func heading(_ mo: MonthInfo) -> String {
        guard let d = selDay else { return mo.live ? "Spent so far" : "Spent in \(mo.name)" }
        let act = store.actualPoints(mo)
        if d <= act.count { return "Spent by \(d) \(mo.short)" }
        return "kosh expects by \(d) \(mo.short)"
    }

    func subline(_ mo: MonthInfo) -> String {
        if let d = selDay {
            if let p = mo.prev, let pm = store.month(p), d <= pm.cum.count {
                return "\(pm.short) had \(Fmt.rupees(pm.cum[d - 1])) by then"
            }
            return ""
        }
        if mo.live { return "kosh expects \(Fmt.rupees(store.likelyNow)) · usual \(Fmt.rupees(store.snap.fc.usual))" }
        if let p = mo.prev { return "\(mo.payments) payments · \(Day.monthName(p)) was \(Fmt.rupees(mo.prevTotal))" }
        return "\(mo.payments) payments"
    }

    @ViewBuilder func content(_ mo: MonthInfo) -> some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 26) {
                VStack(alignment: .leading, spacing: 4) {
                    Text(heading(mo))
                        .font(.subheadline.weight(.medium))
                        .foregroundStyle(.secondary)
                        .contentTransition(.opacity)
                    Text(Fmt.rupees(shown))
                        .font(.system(size: 54, weight: .bold, design: .rounded))
                        .contentTransition(.numericText(value: shown))
                        .privacySensitive()
                    Text(subline(mo))
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .privacySensitive()
                    if selDay == nil { TripMonthLine(m: mo.m).padding(.top, 6) }
                }
                MonthChart(mo: mo, sel: $selDay)
                    .frame(height: 230)
                HStack(spacing: 16) {
                    Legend(color: Color.primary, label: mo.short)
                    if mo.live { Legend(color: Color.kosh, label: "kosh's forecast", dashed: true) }
                    if let p = mo.prev { Legend(color: Color.gray.opacity(0.5), label: Day.monthShort(p)) }
                }
                .font(.caption)
                .foregroundStyle(.secondary)
                Text("Touch and hold the line to see any day.")
                    .font(.footnote)
                    .foregroundStyle(.tertiary)
                    .padding(.top, -14)

                PaceSection(mo: mo)
                BigOnes(mo: mo)

                Button {
                    store.ledgerMonth = mo.m
                    store.txSub = .all
                    store.open(.transactions)
                } label: {
                    Label("All \(store.spendCount(mo.m)) payments in the ledger", systemImage: "list.bullet")
                        .font(.body.weight(.semibold))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 6)
                }
                .buttonStyle(.glass)
                .controlSize(.large)
            }
            .padding(.horizontal, 20)
            .padding(.bottom, 30)
        }
        .navigationTitle(mo.name)
        .onAppear {
            shown = 0
            withAnimation(Motion.reveal.delay(0.15)) { shown = store.total(of: mo) }
        }
        .onChange(of: selDay) { _, d in
            withAnimation(Motion.base) {
                shown = d.map { store.value(mo, $0) } ?? store.total(of: mo)
            }
        }
        .sensoryFeedback(.selection, trigger: selDay)
    }
}

struct Legend: View {
    let color: Color
    let label: String
    var dashed = false
    var body: some View {
        HStack(spacing: 6) {
            Capsule()
                .fill(dashed ? Color.clear : color)
                .overlay(dashed ? Capsule().stroke(color, style: StrokeStyle(lineWidth: 2, dash: [2, 3])) : nil)
                .frame(width: 16, height: 3)
            Text(label)
        }
    }
}

struct MonthChart: View {
    @Environment(Store.self) private var store
    let mo: MonthInfo
    /// what VoiceOver says of the month's line (MiniChart on Home says the same)
    static func spoken(_ mo: MonthInfo, pts: [DayV], prev: [DayV]) -> String {
        let now: Double = pts.last?.v ?? 0
        let day: Int = pts.last?.day ?? 0
        var said: String = "Spending through " + mo.name + ": " + Fmt.rupees(now) + (mo.live ? " by day " + String(day) : "")
        if let then = prev.first(where: { $0.day == day }) ?? prev.last, then.v > 0 {
            said += "; " + Fmt.rupees(then.v) + " by the same day the month before"
        }
        return said
    }
    @Binding var sel: Int?
    @State private var reveal: CGFloat = 0

    var body: some View {
        let pts = store.actualPoints(mo)
        let prev = store.prevPoints(mo)
        let fc = mo.live ? store.forecastPoints() : []
        let band = mo.live ? store.bandPoints() : []
        Chart {
            ForEach(prev) { p in
                LineMark(x: .value("Day", p.day), y: .value("Amount", p.v), series: .value("Series", "previous"))
                    .foregroundStyle(Color.gray.opacity(0.4))
                    .lineStyle(StrokeStyle(lineWidth: 1.5))
                    .interpolationMethod(.monotone)
            }
            ForEach(band) { b in
                AreaMark(x: .value("Day", b.day), yStart: .value("Low", b.lo), yEnd: .value("High", b.hi))
                    .foregroundStyle(Color.kosh.opacity(0.12))
                    .interpolationMethod(.monotone)
            }
            ForEach(fc) { p in
                LineMark(x: .value("Day", p.day), y: .value("Amount", p.v), series: .value("Series", "forecast"))
                    .foregroundStyle(Color.kosh)
                    .lineStyle(StrokeStyle(lineWidth: 2.2, lineCap: .round, dash: [1, 5]))
                    .interpolationMethod(.monotone)
            }
            ForEach(pts) { p in
                LineMark(x: .value("Day", p.day), y: .value("Amount", p.v), series: .value("Series", "actual"))
                    .foregroundStyle(Color.primary)
                    .lineStyle(StrokeStyle(lineWidth: 2.8, lineCap: .round, lineJoin: .round))
                    .interpolationMethod(.monotone)
            }
            if mo.live {
                RuleMark(y: .value("Envelopes", store.snap.fc.budget))
                    .foregroundStyle(Color.orange.opacity(0.75))
                    .lineStyle(StrokeStyle(lineWidth: 1, dash: [3, 4]))
                    .annotation(position: .top, alignment: .leading) {
                        Text("Envelopes \(Fmt.short(store.snap.fc.budget))")
                            .font(.caption2.weight(.semibold))
                            .foregroundStyle(Color.orange)
                            .privacySensitive()
                    }
            }
            if let sel {
                RuleMark(x: .value("Day", sel))
                    .foregroundStyle(Color.secondary.opacity(0.5))
                    .lineStyle(StrokeStyle(lineWidth: 1))
                    .annotation(position: .top, overflowResolution: .init(x: .fit(to: .chart), y: .disabled)) {
                        Text("\(sel) \(mo.short)")
                            .font(.caption.weight(.semibold))
                            .padding(.horizontal, 8).padding(.vertical, 4)
                            .glassEffect(.regular, in: .capsule)
                    }
                PointMark(x: .value("Day", sel), y: .value("Amount", store.value(mo, sel)))
                    .foregroundStyle(sel <= pts.count ? Color.primary : Color.kosh)
                    .symbolSize(80)
            }
        }
        .chartXScale(domain: 1...mo.days)
        .chartYScale(domain: 0...store.chartMax(mo))
        .chartXSelection(value: $sel)
        .chartLegend(.hidden)
        .chartYAxis {
            AxisMarks(position: .trailing, values: .automatic(desiredCount: 4)) { value in
                AxisGridLine().foregroundStyle(Color.hairline)
                AxisValueLabel {
                    if let v = value.as(Double.self) { Text(Fmt.short(v)).privacySensitive() }
                }
            }
        }
        .chartXAxis {
            AxisMarks(values: [1, 15, mo.days]) { value in
                AxisValueLabel {
                    if let d = value.as(Int.self) { Text("\(d) \(mo.short)") }
                }
            }
        }
        .mask(alignment: .leading) {
            GeometryReader { g in Rectangle().frame(width: g.size.width * reveal) }
        }
        .onAppear { withAnimation(Motion.reveal.delay(0.3)) { reveal = 1 } }
        .accessibilityElement(children: .ignore)
        .spokenFigures(Self.spoken(mo, pts: pts, prev: prev), hidden: "Spending through " + mo.name + ", day by day")
    }
}

// MARK: - Where it went

struct PaceSection: View {
    @Environment(Store.self) private var store
    let mo: MonthInfo

    struct Item: Identifiable {
        let cat: String; let sym: String; let color: Color; let value: Double; let soFar: Double; let likely: Double; let usual: Double
        var id: String { cat }
    }

    var items: [Item] {
        if mo.live {
            return store.snap.fc.cats.map {
                Item(cat: $0.cat, sym: $0.sym, color: Color(hex: $0.color), value: $0.likely, soFar: $0.sofar, likely: $0.likely, usual: $0.usual)
            }
            .sorted { max($0.value, $0.usual) > max($1.value, $1.usual) }
            .prefix(7).map { $0 }
        }
        return mo.cats.prefix(7).map {
            Item(cat: $0.cat, sym: $0.sym, color: Color(hex: $0.color), value: $0.v, soFar: $0.v, likely: $0.v, usual: $0.prev)
        }
    }

    func note(_ it: Item) -> (String, Color) {
        let vs = mo.live ? "usual" : (mo.prev.map { Day.monthShort($0) } ?? "")
        if mo.prev == nil && !mo.live { return ("\(Fmt.pct(it.value / max(1, mo.total))) of \(mo.short)", Color.secondary) }
        if it.usual <= 0 { return (mo.live ? "new this month" : "new", Color.secondary) }
        let d = it.value / it.usual - 1
        if abs(d) < 0.06 { return (mo.live ? "as usual" : "same as \(vs)", Color.secondary) }
        return ("\(d > 0 ? "+" : "−")\(Fmt.pct(abs(d))) vs \(vs)", d > 0.15 ? Color.orange : (d < -0.15 ? Color.green : Color.secondary))
    }

    var body: some View {
        let list = items
        let scale = max(1, list.map { max($0.likely, $0.usual) }.max() ?? 1)
        VStack(alignment: .leading, spacing: 12) {
            SectionHeader(title: mo.live ? "Where it is going" : "Where it went", n: 1)
            RowsCard(items: list, inset: 56) { it in
                let n = note(it)
                Button {
                    store.push(.category(it.cat, mo.m))
                } label: {
                    PaceRow(sym: it.sym, color: it.color, name: it.cat, value: it.value, soFar: it.soFar, likely: it.likely, usual: it.usual,
                            scale: scale, note: n.0, noteColor: n.1, live: mo.live)
                }
                .buttonStyle(.press)
            }
            if mo.live {
                HStack(spacing: 14) {
                    Legend(color: Color.kosh, label: "so far")
                    Legend(color: Color.kosh.opacity(0.3), label: "likely by month end")
                    HStack(spacing: 6) { Capsule().fill(Color.primary).frame(width: 2, height: 10); Text("your usual") }
                }
                .font(.caption)
                .foregroundStyle(.secondary)
            }
        }
    }
}

struct PaceRow: View {
    let sym: String; let color: Color; let name: String
    let value: Double; let soFar: Double; let likely: Double; let usual: Double; let scale: Double
    let note: String; let noteColor: Color; let live: Bool
    @State private var grow = false

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            IconTile(symbol: sym, color: color, size: 30)
            VStack(alignment: .leading, spacing: 6) {
                HStack {
                    Text(name).font(.body.weight(.medium)).foregroundStyle(Color.primary)
                    Spacer()
                    Text(Fmt.rupees(value)).font(.body.weight(.semibold)).monospacedDigit().foregroundStyle(Color.primary).privacySensitive()
                }
                GeometryReader { g in
                    let w = g.size.width
                    ZStack(alignment: .leading) {
                        Capsule().fill(Color.primary.opacity(0.07))
                        if live {
                            Capsule().fill(color.opacity(0.3)).frame(width: grow ? w * CGFloat(min(1, max(0, likely / scale))) : 0)
                        }
                        Capsule().fill(color).frame(width: grow ? w * CGFloat(min(1, max(0, soFar / scale))) : 0)
                        if usual > 0 {
                            Capsule().fill(Color.primary).frame(width: 2, height: 12).offset(x: w * CGFloat(min(1, usual / scale)) - 1)
                        }
                    }
                }
                .frame(height: 6)
                Text(note).font(.caption).foregroundStyle(noteColor)
            }
        }
        .contentShape(Rectangle())
        .onAppear { withAnimation(Motion.reveal.delay(0.15)) { grow = true } }
    }
}

struct BigOnes: View {
    @Environment(Store.self) private var store
    let mo: MonthInfo
    var body: some View {
        let big = Array(store.txs(in: mo.m).filter { $0.sp }.sorted { $0.a > $1.a }.prefix(4))
        if !big.isEmpty {
            VStack(alignment: .leading, spacing: 12) {
                SectionHeader(title: "The big ones", n: 2)
                RowsCard(items: big, inset: 62) { t in TxRow(t: t, when: Day.short(t.d)) }
            }
        }
    }
}

// MARK: - One category across the months

struct CategoryView: View {
    @Environment(Store.self) private var store
    let cat: String
    let month: String
    @State private var sel: String = ""

    struct Bar: Identifiable { let m: String; let short: String; let v: Double; let likely: Double; var id: String { m } }

    var bars: [Bar] {
        let now: FcCat? = store.snap.fc.cats.first { $0.cat == cat }
        // the last twelve months, one bar each (a month's short name repeats across years, so each bar is keyed by
        // its month, and named on the axis)
        return Array(store.snap.months.reversed().suffix(12)).map { (mo: MonthInfo) -> Bar in
            let v: Double
            if let mine = store.spentCats(mo) { v = mine.first { $0.cat == cat }?.v ?? 0 }
            else if mo.live { v = now?.sofar ?? 0 }
            else if let c = mo.cats.first(where: { $0.cat == cat }) { v = c.v }
            else { v = store.catsSpent(mo)[cat] ?? 0 }
            let likely: Double = mo.live && store.who == .family ? (now?.likely ?? v) : v
            return Bar(m: mo.m, short: mo.short, v: v, likely: max(v, likely))
        }
    }

    var body: some View {
        let chosen = sel.isEmpty ? month : sel
        let rows = store.txs(in: chosen).filter { $0.sp && $0.c == cat }
        let color = store.catColor(cat)
        List {
            Section {
                let list: [Bar] = bars
                Chart(list) { b in
                    if b.m == store.snap.cm && b.likely > b.v {
                        BarMark(x: .value("Month", b.m), yStart: .value("So far", b.v), yEnd: .value("Likely", b.likely))
                            .foregroundStyle(color.opacity(0.22))
                            .cornerRadius(6)
                    }
                    BarMark(x: .value("Month", b.m), y: .value("Spent", b.v))
                        .foregroundStyle(b.m == chosen ? color : color.opacity(0.3))
                        .cornerRadius(6)
                        // only the month picked says its figure, so nothing crowds
                        .annotation(position: .top, spacing: 4) {
                            if b.m == chosen {
                                Text(Fmt.short(b.m == store.snap.cm ? b.likely : b.v))
                                    .font(.caption.weight(.bold))
                                    .foregroundStyle(color)
                                    .padding(.horizontal, 6).padding(.vertical, 2)
                                    .background(color.opacity(0.12), in: Capsule())
                                    .fixedSize()
                                    .privacySensitive()
                            }
                        }
                }
                .chartYAxis(.hidden)
                .chartXAxis {
                    AxisMarks(values: list.map(\.m)) { v in
                        AxisValueLabel {
                            if let m = v.as(String.self) {
                                Text(list.first { $0.m == m }?.short ?? "")
                                    .font(.caption2.weight(m == chosen ? .bold : .regular))
                                    .foregroundStyle(m == chosen ? Color.primary : Color.secondary)
                            }
                        }
                    }
                }
                .chartXSelection(value: Binding(get: { nil as String? }, set: { s in
                    if let s, list.contains(where: { $0.m == s }) { withAnimation(Motion.base) { sel = s } }
                }))
                .frame(height: 180)
                .padding(.vertical, 8)
                .accessibilityElement(children: .ignore)
                .spokenFigures(cat + " over the last " + SpokenWords.count(list.count, "month", "months") + ", " + SpokenWords.highest(list.map { (m: $0.m, v: $0.v) }),
                               hidden: cat + " over the last " + SpokenWords.count(list.count, "month", "months"))
            } footer: {
                Text("Tap a month to see its payments.")
            }
            Section(Day.monthName(chosen)) {
                if rows.isEmpty {
                    Text("Nothing in \(cat) in \(Day.monthName(chosen)).").foregroundStyle(.secondary)
                } else {
                    ForEach(rows) { t in TxRow(t: t, when: Day.short(t.d)) }
                }
            }
        }
        .navigationTitle(cat)
        .sensoryFeedback(.selection, trigger: sel)
    }
}
