import Foundation
import Observation
import UIKit
import Network

// MARK: - LiveSession: the AI pass: kosh-reader on the phone, Apple Intelligence, or Claude with your key
// (split out of LiveSession+Reading.swift, 30 Oct 2026; its stored state stays in the class in LiveSession.swift)

extension LiveSession {
    // MARK: the AI pass: kosh-reader on the phone, or Claude with your key

    var aiReady: Bool { aiMode == "apple" ? AppleBrain.available : aiMode == "reader" ? KoshReader.available : aiMode == "claude" ? (claudeReady || ClaudeReads.route() != nil) : false }

    /// what reads the mail the rules can't when you haven't chosen: Apple Intelligence where this phone has it,
    /// kosh-reader where it's on the phone, else the rules alone. Worked out at each launch until you pick one
    /// (Settings › Reading saves your pick, and it is never changed for you).
    static var defaultAIMode: String { AppleBrain.available ? "apple" : KoshReader.available ? "reader" : "off" }

    var aiName: String { aiMode == "claude" ? "Smart reading" : aiMode == "apple" ? "Apple Intelligence" : "kosh-reader" }
    /// the reading bar's title while the AI pass runs
    var aiReadingTitle: String { aiMode == "claude" ? "Smart reading at work" : aiName + " is reading" }

    @MainActor

    func aiPass() async {
        if aiMode == "claude" { await claudePass() } else if aiMode == "reader" || aiMode == "apple" { await readerPass() }
    }

    /// kosh-reader, one email at a time on this phone. Its answer is checked against the email
    /// (engine.checkReader) before it counts; anything it names that isn't printed makes it "not sure".
    @MainActor

    func readerPass() async {
        let apple = aiMode == "apple" && AppleBrain.available
        guard apple || KoshReader.available, !running || phase == .done || phase == .failed || phase == .idle else {
            // (Apple Intelligence chosen but not ready here, and no kosh-reader to stand in: say why)
            if aiMode == "apple" && !AppleBrain.available && !running { message = AppleBrain.unavailableReason }
            return
        }
        var todo: [String] = []
        var unknown = Set<String>()
        for i in records.indices {
            let r = records[i]
            if r.claude != nil || r.check?.status == "unsure" { continue }
            if r.kind == "unknown", r.text != nil || r.html != nil { todo.append(r.id); unknown.insert(r.id); continue }
            if r.check?.status == "pending" {
                if checkMode == "all" || (checkMode == "some" && Self.stable(r.id) % 5 == 0) { todo.append(r.id) }
                else { records[i].check = Check(status: "skipped", fields: []); records[i].text = nil; records[i].html = nil }
            }
        }
        if todo.isEmpty {
            if plans["reader"] != nil { plans["reader"] = nil; writePlans() }
            return
        }
        // the emails the rules couldn't read first: those are the ones you're waiting on
        let unknownFirst = todo.filter { unknown.contains($0) } + todo.filter { !unknown.contains($0) }
        // a pass that was cut short carries on: what it had read counts, so the bar goes on from there ("18 of 250")
        let carried = plan("reader")
        let base = carried?.done ?? 0
        phase = .claude
        message = nil
        claudeTotal = base + unknownFirst.count
        claudeDone = base
        plans["reader"] = ReadingPlan(job: "reader", accounts: allAccounts, total: claudeTotal, done: base)
        writePlans()
        if carried != nil { pickUp("reader") }
        KeepGoing.shared.begin(aiReadingTitle)
        defer { KeepGoing.shared.end() }
        stretchSeen = true
        // the model stays loaded for this pass, and is let go when it ends (unless another pass still reads with it)
        if !apple { KoshReader.shared.hold() }
        defer { if !apple { KoshReader.shared.letGo() } }
        if apple {
            readerName = "Apple Intelligence"
        } else {
            do { try await Task.detached { try KoshReader.shared.load() }.value } catch {
                message = error.localizedDescription; phase = .done
                plans["reader"] = nil; writePlans()
                return
            }
            readerName = KoshReader.shared.modelName
        }
        if !apple { KoshReader.shared.resetStats() }
        pausedForHeat = false
        // stopped part-way (warm, off screen, out of time): the plan stays and the pass carries on later
        var cut = false
        // an email as the reader is given it: the mail kosh kept, and the engine's prompt text for it
        func prep(_ id: String) -> (MailMsg, String)? {
            guard let r = records.first(where: { $0.id == id }) else { return nil }
            let msg = MailMsg(id: r.id, from: r.from ?? "", date: (r.sent ?? Self.today) + "T00:00:00Z", subject: r.subject ?? "", text: r.text ?? "", html: r.html ?? "")
            guard let pj = try? Engine.shared.call("localPromptJSON", [JSONText.encode(msg), "1800"]),
                  let pd = pj.data(using: .utf8), let pobj = try? JSONSerialization.jsonObject(with: pd) as? [String: Any],
                  let input = pobj["prompt"] as? String else { return nil }
            return (msg, input)
        }
        var ahead: [String: Result<String, Error>] = [:]
        for (k, id) in unknownFirst.enumerated() {
            // gentle on the phone: never once it's getting hot
            if !Self.coolEnough() { pausedForHeat = true; message = (apple ? "Apple Intelligence" : "kosh-reader") + " paused: the phone is warm. It carries on when it cools."; cut = true; break }
            // with kosh off screen only while iOS carries the work (on the Lock Screen, or a catch-up it gave time for)
            if !KeepGoing.shared.mayRun { cut = true; break }
            // (warm but not hot: a breather before each read, once per batch for kosh-reader)
            let fair = ProcessInfo.processInfo.thermalState == .fair
            if fair && (apple || ahead[id] == nil) { try? await Task.sleep(for: .milliseconds(600)) }
            guard let i = records.firstIndex(where: { $0.id == id }) else { continue }
            guard let (msg, input) = prep(id) else { continue }
            // kosh-reader reads the next few emails side by side (KoshReader.lanes): their answers wait here
            if !apple && ahead[id] == nil {
                let wave = unknownFirst[k...].prefix(KoshReader.lanes).compactMap { wid in prep(wid).map { (wid, $0.1) } }
                let ins = wave.map(\.1)
                let got = await Task.detached(priority: .utility) { KoshReader.shared.readMany(ins) }.value
                for (n, w) in wave.enumerated() where n < got.count { ahead[w.0] = got[n] }
            }
            let raw: String
            do {
                if apple { raw = try await AppleBrain.readMailEvents(input) }
                else if let pre = ahead.removeValue(forKey: id) { raw = try pre.get() }
                else { raw = try await Task.detached(priority: .utility) { try KoshReader.shared.read(input) }.value }
            } catch KoshReader.Failure.tooLong {
                // (an email too long for the reader's window stays for the rules or Claude; the pass goes on)
                claudeDone = base + k + 1; plans["reader"]?.done = claudeDone; continue
            } catch AppleBrain.Failure.stopped(let why) {
                // Apple's model went away or iOS is holding kosh back: the plan stays, and the pass carries on later
                message = why; cut = true; break
            } catch {
                // Apple's model declines some emails (its safety rules); that one stays for you to read
                if apple { claudeDone = base + k + 1; plans["reader"]?.done = claudeDone; continue }
                message = "kosh-reader stopped: \(error.localizedDescription)"; break
            }
            var cl: Reading? = nil
            // no events at all is the model saying "not money"; on mail that looks like money (a sum, or a debit, credit or
            // UPI word, and no one-time code) that's more likely a miss than the truth, and as noise the mail's text would
            // be thrown away (applyAI). So it is "not sure": the text stays for a later reader.
            let saidNothing = raw.hasPrefix("{\"events\"") && Self.noEvents(raw)
            if saidNothing && AlertIntake.looksLikeMoney(input) {
                if let out = try? Engine.shared.call("fromClaudeJSON", [JSONText.encode(msg), #"{"kind":"unsure"}"#, apple ? "apple" : "reader"]) {
                    cl = Reading.fromEngine(out)
                }
            }
            // kosh-reader v4 and Apple Intelligence answer in events: checked as Claude's answers are (every amount printed
            // in the mail), then the mail read again with them beside the rules (engine › withClaude, marked lr: the
            // rules' reading stands)
            else if raw.hasPrefix("{\"events\""),
               let aj = try? Engine.shared.call("readerAnswerJSON", [raw, JSONText.encode(msg)]),
               let ad = aj.data(using: .utf8), let ao = try? JSONSerialization.jsonObject(with: ad) as? [String: Any] {
                if let evs = ao["events"] as? [Any], JSONSerialization.isValidJSONObject(evs),
                   let ed = try? JSONSerialization.data(withJSONObject: evs), let es = String(data: ed, encoding: .utf8) {
                    var withEv = msg
                    withEv.cl = es
                    if let out = try? Engine.shared.call("parseJSON", [JSONText.encode(withEv)]), var rd = Reading.fromEngine(out) {
                        rd.id = msg.id
                        cl = rd
                    }
                } else if let out = try? Engine.shared.call("fromClaudeJSON", [JSONText.encode(msg), #"{"kind":"unsure"}"#, apple ? "apple" : "reader"]) {
                    cl = Reading.fromEngine(out)
                }
            } else if let checked = try? Engine.shared.call("readerCheckJSON", [input, raw]),
                      let out = try? Engine.shared.call("fromClaudeJSON", [JSONText.encode(msg), checked, apple ? "apple" : "reader"]) {
                cl = Reading.fromEngine(out)
            }
            guard let cl else { continue }
            // where the record is now (mail may have been read in alongside)
            guard let j = recordIndex(id, hint: i) else { continue }
            applyAI(cl, at: j)
            claudeDone = base + k + 1
            stretchRead += 1
            plans["reader"]?.done = claudeDone
            checkpoint(1)
            if (k + 1) % 20 == 0 && readingBuildDue(every: 0) { lastRebuild = Date(); rebuildSoon() }
        }
        if cut { interrupted.insert("reader") } else { plans["reader"] = nil }
        // how fast it read, said on the Reading screen (and per email in Xcode's console)
        if !apple, message == nil, let s = KoshReader.shared.summary() { message = s }
        save()
        writePlans()
        rebuildSoon()
        phase = .done
    }

    /// a reader's answer in events with none in it ({"events":[]})
    static func noEvents(_ raw: String) -> Bool {
        guard let d = raw.data(using: .utf8), let o = try? JSONSerialization.jsonObject(with: d) as? [String: Any],
              let evs = o["events"] as? [Any] else { return false }
        return evs.isEmpty
    }

    /// nominal or fair: fine to think. serious or critical: stop and let the phone cool.
    static func coolEnough() -> Bool {
        let t = ProcessInfo.processInfo.thermalState
        return t == .nominal || t == .fair
    }

    /// what any reader (kosh-reader or Claude) said about one email, next to what the rules said
    @MainActor

    func applyAI(_ cl: Reading, at i: Int) {
        var r = records[i]
        r.claude = ReadingBox(cl)
        if r.kind == "unknown" {
            if cl.kind != "unknown" && cl.kind != "noise" { r.use = "claude" }
            r.check = Check(status: cl.kind == "noise" ? "noise" : cl.kind == "unknown" ? "unsure" : "claude", fields: [])
            if cl.kind == "noise" { r.text = nil; r.html = nil }
        } else {
            var plain = r
            plain.claude = nil; plain.text = nil; plain.html = nil
            if cl.kind == "unknown" {
                r.check = Check(status: "unsure", fields: [])
            } else {
                let diff = (try? JSONText.decode([String].self, try Engine.shared.call("compareJSON", [JSONText.encode(plain), JSONText.encode(cl)]))) ?? []
                r.check = Check(status: diff.isEmpty ? "agree" : "differ", fields: diff)
                if diff.isEmpty { r.text = nil; r.html = nil }
            }
        }
        records[i] = r
    }

    // MARK: Claude reads every money mail: ClaudeReads.swift

    /// a stable number for a string (which mail falls in "one in five")
    static func stable(_ s: String) -> Int { s.utf8.reduce(7) { ($0 &* 31 &+ Int($1)) & 0x7fffffff } }
}
