import SwiftUI
import Charts

// MARK: - Repeats: what comes back every month, by kind; the month day by day; what's next

/// a kind of repeat: its name, its short name, its colour
struct RepeatKind: Identifiable {
    let id: String
    let title: String
    let short: String
    let color: Color

    static let all: [RepeatKind] = [
        RepeatKind(id: "emi", title: "Loans and EMIs", short: "EMIs", color: Color(hex: "#5E5CE6")),
        RepeatKind(id: "staff", title: "Household help", short: "Help", color: Color(hex: "#FF6482")),
        RepeatKind(id: "bill", title: "Bills", short: "Bills", color: Color(hex: "#FF9F0A")),
        RepeatKind(id: "sub", title: "Subscriptions", short: "Subscriptions", color: Color(hex: "#AF52DE")),
        RepeatKind(id: "sip", title: "Investments", short: "SIPs", color: Color(hex: "#34C759")),
        // a committee's instalments (a chit fund, a BC): their own kind, never an SIP
        RepeatKind(id: "committee", title: "Committees", short: "Committees", color: Color(hex: "#A2845E")),
        RepeatKind(id: "other", title: "Everything else", short: "Other", color: Color(hex: "#30B0C7")),
    ]
    /// the engine's kind, with help and anything else sorted out
    static func of(_ r: Recurring) -> String {
        switch r.kind {
        case "emi", "bill", "sub", "sip", "staff", "committee": return r.kind
        default: return "other"
        }
    }
    static func find(_ id: String) -> RepeatKind { all.first { $0.id == id } ?? all[all.count - 1] }
    /// what fits inside the ring
    var tiny: String { id == "sub" ? "Subs" : id == "committee" ? "Chits" : short }
}

enum RepeatInk {
    static let indigo = Color(light: "#4B49C8", dark: "#A9A7FF")
    static let slate = Color(light: "#55546B", dark: "#B4B3C9")
    static let grey = Color(light: "#6B6B73", dark: "#98989F")
}

/// a repeat as this month sees it
struct RepeatNow {
    let r: Recurring
    let today: String
    var cm: String { String(today.prefix(7)) }
    var lapsed: Bool { !(r.lapsed ?? "").isEmpty }
    /// you said you cancelled it
    var cancelled: Bool { !(r.gone ?? "").isEmpty }
    /// its cycle in months: 1, 3, 6 or 12
    var per: Int { max(1, r.per ?? 1) }
    /// it comes every month, or it comes this month (a yearly one in its month)
    var thisMonth: Bool { !lapsed && (per == 1 || paid || due) }
    /// it already went this month
    var paid: Bool { !lapsed && (r.last ?? "").hasPrefix(cm) }
    /// it's still to come this month
    var due: Bool { !lapsed && !paid && r.date.hasPrefix(cm) }
    /// the day of the month it goes
    var day: Int {
        let src: String = paid ? (r.last ?? r.date) : r.date
        return Int(src.suffix(2)) ?? 1
    }
    var kind: RepeatKind { RepeatKind.find(RepeatKind.of(r)) }
    /// "15th of every month · auto-debit", "Yearly · next 2 Oct"
    var line: String {
        var s: String = ordinal(day) + " of every month"
        if per > 1 { s = (per == 12 ? "Yearly" : per == 6 ? "Every six months" : "Every three months") + " · next " + Day.fmt(r.date, "d MMM") }
        else if r.kind == "bill" && (r.seen ?? 0) > 0 && r.cat == "Bills" && ["Electricity", "Water", "Gas"].contains(r.sub ?? "") { s = "Around the " + ordinal(day) + " · varies" }
        let how: String = Self.how(r.via ?? "")
        return how.isEmpty ? s : s + " · " + how
    }
    static func how(_ md: String) -> String {
        switch md {
        case "auto": return "auto-debit"
        case "card": return "card"
        case "upi": return "UPI"
        case "cash": return "cash"
        case "wallet": return "wallet"
        case "transfer": return "bank transfer"
        default: return ""
        }
    }
}

struct RecurringView: View {
    @Environment(Store.self) private var store
    /// a repeat opened: its payments, and what you can say about it
    @State private var open: Recurring?

    var body: some View {
        let today: String = store.snap.today
        // whoever is shown: their repeats
        let all: [RepeatNow] = store.snap.recurring.filter { store.who.owns($0.o ?? "me") }.map { RepeatNow(r: $0, today: today) }
        // what goes this month: every monthly one, and a longer one in its month
        let live: [RepeatNow] = all.filter { $0.thisMonth }
        ScrollView {
            VStack(alignment: .leading, spacing: 26) {
                if all.isEmpty {
                    ContentUnavailableView("No repeats yet", systemImage: "arrow.triangle.2.circlepath",
                                           description: Text("Payments that come back each month, at about the same amount, show here once kosh has seen them twice."))
                        .padding(.top, 40)
                } else {
                    PlanStack(.txRepeats, spacing: 26) { id in
                        switch id {
                        case "hero": RepeatsHero(items: live)
                        case "days": RepeatDays(items: live, today: today)
                        case "next": RepeatNext(items: live, today: today)
                        case "usual":
                            VStack(alignment: .leading, spacing: 12) {
                                Text("The usual suspects").font(.system(.title2, weight: .bold))
                                ForEach(RepeatKind.all) { k in
                                    let rows: [RepeatNow] = all.filter { RepeatKind.of($0.r) == k.id }
                                    if !rows.isEmpty { RepeatGroup(kind: k, rows: rows) { open = $0 } }
                                }
                                RepeatsSetAside()
                            }
                        default: EmptyView()
                        }
                    }
                }
            }
            .padding(.horizontal, 20)
            .padding(.top, 14)
            .padding(.bottom, 36)
        }
        .sheet(item: $open) { r in RepeatSheet(r: r).closesForAsk().environment(store).presentationDetents([.medium, .large]) }
    }
}

/// what comes back each month, a ring of what it's made of, and how much of it has gone this month
struct RepeatsHero: View {
    @Environment(Store.self) private var store
    let items: [RepeatNow]
    @State private var grown = false

    struct Slice: Identifiable { let id: String; let kind: RepeatKind; let v: Double }

    var body: some View {
        let total: Double = items.reduce(0) { $0 + $1.r.amount }
        let slices: [Slice] = RepeatKind.all.compactMap { (k: RepeatKind) -> Slice? in
            let v: Double = items.filter { RepeatKind.of($0.r) == k.id }.reduce(0) { $0 + $1.r.amount }
            return v > 0 ? Slice(id: k.id, kind: k, v: v) : nil
        }.sorted { $0.v > $1.v }
        let gone: Double = items.filter { $0.paid }.reduce(0) { $0 + $1.r.amount }
        let toGo: Double = max(0, total - gone)
        VStack(alignment: .leading, spacing: 16) {
            HStack(alignment: .center, spacing: 12) {
                VStack(alignment: .leading, spacing: 2) {
                    Text(items.contains { $0.per > 1 } ? "On autopilot this month" : "On autopilot every month").font(.system(.footnote, weight: .semibold)).foregroundStyle(RepeatInk.indigo)
                    Text(Fmt.rupees(total))
                        .scaledFont(size: 40, weight: .bold, design: .rounded, relativeTo: .largeTitle).monospacedDigit()
                        .lineLimit(1).minimumScaleFactor(0.6)
                        .privacySensitive()
                    Text(items.count == 1 ? "One payment that never ghosts you" : Words.cap(Words.number(items.count)) + " payments that never ghost you")
                        .font(.system(.footnote)).foregroundStyle(RepeatInk.slate)
                }
                Spacer(minLength: 4)
                if let top = slices.first, total > 0 {
                    KindRing(slices: slices, total: total, top: top)
                }
            }
            WrapRow(spacing: 6, lineSpacing: 6) {
                ForEach(slices) { s in
                    HStack(spacing: 6) {
                        Circle().fill(s.kind.color).frame(width: 7, height: 7)
                        Text(s.kind.short).fontWeight(.semibold)
                        Text(Fmt.short(s.v)).foregroundStyle(RepeatInk.slate).monospacedDigit().privacySensitive()
                    }
                    .font(.system(.caption))
                    .padding(.horizontal, 10)
                    .frame(minHeight: 28)
                    .background(Color.lift(0.8), in: Capsule())
                }
            }
            VStack(alignment: .leading, spacing: 8) {
                GeometryReader { g in
                    ZStack(alignment: .leading) {
                        Capsule().fill(Color(hex: "#5E5CE6").opacity(0.12))
                        Capsule()
                            .fill(LinearGradient(colors: [Color(hex: "#8B89F0"), Color(hex: "#5E5CE6")], startPoint: .leading, endPoint: .trailing))
                            .frame(width: total > 0 ? max(gone > 0 ? 8 : 0, g.size.width * CGFloat(gone / total) * (grown ? 1 : 0.03)) : 0)
                    }
                }
                .frame(height: 10)
                HStack {
                    Text("\(Text(Fmt.rupees(gone)).fontWeight(.semibold).foregroundStyle(Color.primary)) out the door")
                    Spacer(minLength: 6)
                    Text("\(Text(Fmt.rupees(toGo)).fontWeight(.semibold).foregroundStyle(Color.primary)) still in the queue")
                }
                .font(.system(.footnote))
                .foregroundStyle(RepeatInk.slate)
                .monospacedDigit()
                .privacySensitive()
            }
        }
        .padding(20)
        .background(
            LinearGradient(colors: [Color(light: "#E9E8FF", dark: "#262448"), Color(light: "#F4F3FF", dark: "#1D1C33"), Color(light: "#FDFDFF", dark: "#17171F")], startPoint: .topLeading, endPoint: .bottomTrailing),
            in: RoundedRectangle(cornerRadius: 28, style: .continuous)
        )
        .overlay(RoundedRectangle(cornerRadius: 28, style: .continuous).strokeBorder(Color(hex: "#5E5CE6").opacity(0.16), lineWidth: 0.5))
        .onAppear { withAnimation(Motion.reveal.delay(0.1)) { grown = true } }
    }
}

/// a ring split by kind, the biggest kind's share in the middle
struct KindRing: View {
    let slices: [RepeatsHero.Slice]
    let total: Double
    let top: RepeatsHero.Slice
    @State private var shown = false
    var body: some View {
        let gap: Double = slices.count > 1 ? 0.012 : 0
        ZStack {
            Circle().stroke(Color(hex: "#5E5CE6").opacity(0.1), lineWidth: 9)
            ForEach(Array(slices.enumerated()), id: \.element.id) { i, s in
                let from: Double = slices.prefix(i).reduce(0) { $0 + $1.v } / total
                let to: Double = from + s.v / total
                Circle()
                    .trim(from: CGFloat(from + gap), to: CGFloat(max(from + gap, (shown ? to : from) - gap)))
                    .stroke(s.kind.color, style: StrokeStyle(lineWidth: 9, lineCap: .round))
                    .rotationEffect(.degrees(-90))
            }
            VStack(spacing: 2) {
                Text(Fmt.pct(top.v / total)).font(.system(size: 19, weight: .bold, design: .rounded)).monospacedDigit()
                Text(top.kind.tiny.uppercased()).font(.system(size: 9, weight: .bold)).tracking(0.4).foregroundStyle(RepeatInk.indigo).lineLimit(1).minimumScaleFactor(0.7)
            }
            .padding(.horizontal, 14)
        }
        .frame(width: 84, height: 84)
        .onAppear { withAnimation(Motion.reveal.delay(0.15)) { shown = true } }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("\(top.kind.title) are \(Fmt.pct(top.v / total)) of it")
    }
}

/// the month as a line of days: a circle for each repeat on its day, filled once it has gone, bigger for bigger
struct RepeatDays: View {
    let items: [RepeatNow]
    let today: String

    struct Dot: Identifiable { let id: String; let day: Int; let r: CGFloat; let color: Color; let paid: Bool; let amount: Double; var y: CGFloat }

    var body: some View {
        let cm: String = String(today.prefix(7))
        let dim: Int = Day.daysIn(cm)
        let todayN: Int = Int(today.suffix(2)) ?? 1
        let shown: [RepeatNow] = items.filter { $0.paid || $0.due }
        let top: Double = max(1, shown.map(\.r.amount).max() ?? 1)
        let dots: [Dot] = Self.place(shown.map { x in
            Dot(id: x.r.id, day: min(dim, x.day), r: 4.5 + 13.5 * CGFloat((x.r.amount / top).squareRoot()), color: x.kind.color, paid: x.paid, amount: x.r.amount, y: 0)
        }, dim: dim)
        let tagged: Set<String> = Set(dots.sorted { $0.amount > $1.amount }.prefix(2).map(\.id))
        VStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .firstTextBaseline) {
                Text(Day.monthName(cm) + "’s debit diary").font(.system(.title2, weight: .bold))
                    .lineLimit(1).minimumScaleFactor(0.8)
                Spacer(minLength: 8)
                Text(comingLine(items)).font(.subheadline).foregroundStyle(.secondary).lineLimit(1)
            }
            VStack(alignment: .leading, spacing: 6) {
                GeometryReader { g in
                    let w: CGFloat = g.size.width
                    let x: (Int) -> CGFloat = { d in 8 + (w - 16) * CGFloat(d - 1) / CGFloat(max(1, dim - 1)) }
                    let tx: CGFloat = x(todayN)
                    ZStack(alignment: .topLeading) {
                        RoundedRectangle(cornerRadius: 10, style: .continuous).fill(Color(hex: "#5E5CE6").opacity(0.06))
                            .frame(width: tx, height: 80).offset(y: 12)
                        Rectangle().fill(Color.rule.opacity(0.18)).frame(width: w - 12, height: 0.5).offset(x: 6, y: 92)
                        Path { p in p.move(to: CGPoint(x: tx, y: 6)); p.addLine(to: CGPoint(x: tx, y: 96)) }
                            .stroke(Color.kosh, style: StrokeStyle(lineWidth: 1.5, dash: [3, 3]))
                        Text("TODAY").font(.system(.caption2, weight: .bold)).tracking(0.4).foregroundStyle(Color.kosh)
                            .fixedSize()
                            .offset(x: min(tx + 5, w - 44), y: 0)
                        let labels: [String: CGPoint] = Self.labelSpots(dots.filter { tagged.contains($0.id) }, all: dots, x: x, w: w)
                        ForEach(dots) { d in
                            Circle()
                                .fill(d.paid ? d.color : d.color.opacity(0.22))
                                .overlay(Circle().strokeBorder(d.color, lineWidth: d.paid ? 0 : 1.6))
                                .frame(width: d.r * 2, height: d.r * 2)
                                .position(x: x(d.day), y: d.y)
                        }
                        ForEach(dots.filter { labels[$0.id] != nil }) { d in
                            Text(Fmt.short(d.amount)).font(.system(.caption2, design: .rounded, weight: .bold)).monospacedDigit()
                                .foregroundStyle(RepeatInk.indigo)
                                .fixedSize()
                                .position(labels[d.id] ?? .zero)
                                .privacySensitive()
                        }
                    }
                }
                .frame(height: 112)
                GeometryReader { g in
                    let w: CGFloat = g.size.width
                    let mon: String = Day.fmt(cm + "-01", "MMM")
                    // the month's first and last day carry its name; today in blue; 15 and 22 between
                    let marks: [Int] = Array(Set([1, 15, 22, dim, todayN])).sorted()
                    ZStack(alignment: .topLeading) {
                        ForEach(marks, id: \.self) { d in
                            let edge: Bool = d == 1 || d == dim
                            let label: String = edge && d != todayN ? String(d) + " " + mon : String(d)
                            let px: CGFloat = 8 + (w - 16) * CGFloat(d - 1) / CGFloat(max(1, dim - 1))
                            Text(label)
                                .font(.system(.caption2, design: .rounded, weight: d == todayN ? Font.Weight.bold : Font.Weight.regular))
                                .foregroundStyle(d == todayN ? Color.kosh : Color(hex: "#8E8E96"))
                                .fixedSize()
                                .position(x: d == 1 && d != todayN ? max(px, 16) : d == dim && d != todayN ? min(px, w - 18) : px, y: 7)
                                .opacity(d != todayN && abs(d - todayN) < (edge ? 4 : 3) ? 0 : 1)
                        }
                    }
                }
                .frame(height: 14)
                HStack(spacing: 18) {
                    HStack(spacing: 5) { Circle().fill(RepeatInk.grey).frame(width: 9, height: 9); Text("paid") }
                    HStack(spacing: 5) { Circle().strokeBorder(RepeatInk.grey, lineWidth: 1.5).frame(width: 9, height: 9); Text("coming up") }
                }
                .font(.system(.caption))
                .foregroundStyle(RepeatInk.grey)
                .frame(maxWidth: .infinity)
                .padding(.top, 8)
                .lineLimit(1)
            }
            .padding(16)
            .insightCard(26)
        }
    }

    /// the line beside the heading: what's still to come this month, in a few words
    func comingLine(_ items: [RepeatNow]) -> String {
        let n: Int = items.filter { $0.due && !$0.paid }.count
        if items.isEmpty { return "" }
        if n == 0 { return "all paid up" }
        return n == 1 ? "1 still to come" : String(n) + " still to come"
    }

    /// where each amount sits: above its circle, unless that would land on another circle or another amount,
    /// then below it
    static func labelSpots(_ tagged: [Dot], all: [Dot], x: (Int) -> CGFloat, w: CGFloat) -> [String: CGPoint] {
        var out: [String: CGPoint] = [:]
        var taken: [CGRect] = []
        for d in tagged.sorted(by: { $0.amount > $1.amount }) {
            let cx: CGFloat = min(max(x(d.day), 24), w - 24)
            let above = CGPoint(x: cx, y: d.y - d.r - 9)
            let below = CGPoint(x: cx, y: d.y + d.r + 9)
            func box(_ p: CGPoint) -> CGRect { CGRect(x: p.x - 20, y: p.y - 7, width: 40, height: 14) }
            func free(_ p: CGPoint) -> Bool {
                let b: CGRect = box(p)
                if taken.contains(where: { $0.intersects(b) }) { return false }
                return !all.contains { o in o.id != d.id && b.intersects(CGRect(x: x(o.day) - o.r, y: o.y - o.r, width: o.r * 2, height: o.r * 2)) }
            }
            let spot: CGPoint = free(above) || !free(below) ? above : below
            taken.append(box(spot))
            out[d.id] = spot
        }
        return out
    }

    /// on the line around the middle, nudged up or down where circles a few days apart would touch
    static func place(_ dots: [Dot], dim: Int) -> [Dot] {
        var out: [Dot] = []
        let sorted: [Dot] = dots.sorted { $0.day != $1.day ? $0.day < $1.day : $0.r > $1.r }
        let mid: CGFloat = 62
        let unit: CGFloat = 300 / CGFloat(max(1, dim - 1))   // about a day's width on a phone
        for var d in sorted {
            var y: CGFloat = mid
            var step: Int = 0
            func clash(_ y: CGFloat) -> Bool {
                out.contains { o in
                    let dx: CGFloat = CGFloat(abs(o.day - d.day)) * unit
                    let dy: CGFloat = abs(o.y - y)
                    return (dx * dx + dy * dy).squareRoot() < o.r + d.r + 1.5
                }
            }
            while clash(y) && step < 8 {
                step += 1
                let k: CGFloat = CGFloat((step + 1) / 2) * 9
                y = mid + (step % 2 == 1 ? -k : k)
            }
            d.y = min(max(y, d.r + 14), 90 - d.r)
            out.append(d)
        }
        return out
    }
}

/// the next few, a card each, in a row you can scroll
struct RepeatNext: View {
    let items: [RepeatNow]
    let today: String
    var body: some View {
        let next: [RepeatNow] = items.filter { $0.r.date >= today }.sorted { $0.r.date < $1.r.date }.prefix(8).map { $0 }
        if !next.isEmpty {
            VStack(alignment: .leading, spacing: 12) {
                Text("Knocking soon").font(.system(.title2, weight: .bold))
                ScrollView(.horizontal) {
                    HStack(spacing: 10) {
                        ForEach(next, id: \.r.id) { x in card(x) }
                    }
                    .padding(.horizontal, 20)
                }
                .scrollIndicators(.hidden)
                .padding(.horizontal, -20)
            }
        }
    }
    func card(_ x: RepeatNow) -> some View {
        let days: Int = Day.between(today, x.r.date)
        let when: String = days <= 0 ? "today" : days == 1 ? "tomorrow" : "in " + String(days) + " days"
        return VStack(alignment: .leading, spacing: 10) {
            HStack {
                Image(systemName: x.r.sym.isEmpty ? "arrow.triangle.2.circlepath" : x.r.sym)
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundStyle(x.kind.color)
                    .frame(width: 34, height: 34)
                    .background(x.kind.color.opacity(0.16), in: RoundedRectangle(cornerRadius: 11, style: .continuous))
                Spacer(minLength: 4)
                Text(when).font(.system(.caption, weight: .bold)).foregroundStyle(days <= 2 ? Color.kosh : RepeatInk.grey)
            }
            VStack(alignment: .leading, spacing: 1) {
                Text(x.r.name).font(.system(.subheadline, weight: .semibold)).lineLimit(1)
                Text(Day.fmt(x.r.date, "EEE d MMM")).font(.system(.caption)).foregroundStyle(RepeatInk.grey)
            }
            Text(Fmt.rupees(x.r.amount)).font(.system(.title3, design: .rounded, weight: .bold)).monospacedDigit().privacySensitive()
        }
        .padding(14)
        .frame(width: 148, alignment: .leading)
        .insightCard(22)
    }
}

/// one kind: its colour, what it adds up to, and each repeat in it
struct RepeatGroup: View {
    let kind: RepeatKind
    let rows: [RepeatNow]
    var tap: (Recurring) -> Void = { _ in }
    var body: some View {
        let live: [RepeatNow] = rows.filter { !$0.lapsed }.sorted { $0.r.monthly > $1.r.monthly }
        let gone: [RepeatNow] = rows.filter { $0.lapsed }
        VStack(spacing: 0) {
            HStack(spacing: 10) {
                Circle().fill(kind.color).frame(width: 10, height: 10)
                Text(kind.title).font(.system(.subheadline, weight: .bold))
                Spacer(minLength: 6)
                // a month's worth: a yearly one counts a twelfth
                Text(Fmt.rupees(live.reduce(0) { $0 + $1.r.monthly })).font(.system(.subheadline, design: .rounded, weight: .semibold)).monospacedDigit().privacySensitive()
            }
            .padding(.top, 12).padding(.bottom, 10)
            ForEach(live + gone, id: \.r.id) { x in
                Rectangle().fill(Color.rule.opacity(0.13)).frame(height: 0.5)
                Button { tap(x.r) } label: { RepeatRow(x: x) }
                    .buttonStyle(.press)
                    .accessibilityHint("Shows its payments")
            }
        }
        .padding(.horizontal, 16)
        .padding(.top, 6)
        .padding(.bottom, 8)
        .insightCard(26)
    }
}

struct RepeatRow: View {
    let x: RepeatNow
    var body: some View {
        let k: RepeatKind = x.kind
        HStack(spacing: 12) {
            Image(systemName: x.r.sym.isEmpty ? "arrow.triangle.2.circlepath" : x.r.sym)
                .font(.system(size: 16, weight: .semibold))
                .foregroundStyle(x.lapsed ? RepeatInk.grey : k.color)
                .frame(width: 38, height: 38)
                .background((x.lapsed ? Color.rule.opacity(0.08) : k.color.opacity(0.14)), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
            VStack(alignment: .leading, spacing: 2) {
                Text(x.r.name).font(.system(.subheadline, weight: .medium)).lineLimit(1)
                HStack(spacing: 6) {
                    if x.cancelled, let g = x.r.gone {
                        tag("You cancelled it " + Day.fmt(g, "d MMM"), sym: "xmark.circle", ink: Color(light: "#4A4A52", dark: "#AEAEB5"), wash: Color.rule.opacity(0.1))
                    } else if x.lapsed, let l = x.r.lapsed {
                        tag("Not seen since " + Day.fmt(l, "d MMM"), sym: "pause.circle", ink: Color(light: "#4A4A52", dark: "#AEAEB5"), wash: Color.rule.opacity(0.1))
                    } else {
                        if let up = x.r.rise, let from = x.r.riseFrom, up > 0 {
                            Text(ordinal(x.day)).foregroundStyle(RepeatInk.grey)
                            tag("Up " + Fmt.rupees(up) + " from " + Fmt.rupees(from), sym: "arrow.up.right", ink: RentInk.dueDeep, wash: RentInk.due.opacity(0.16))
                        } else {
                            Text(x.line).foregroundStyle(RepeatInk.grey).lineLimit(1)
                        }
                        if x.paid {
                            HStack(spacing: 3) {
                                Image(systemName: "checkmark").font(.system(size: 9.5, weight: .bold))
                                Text("paid")
                            }
                            .fontWeight(.semibold)
                            .foregroundStyle(RentInk.goodDeep)
                            .layoutPriority(1)
                        }
                    }
                }
                .font(.system(.caption))
            }
            Spacer(minLength: 6)
            Text(Fmt.rupees(x.r.amount))
                .font(.system(.subheadline, design: .rounded, weight: .semibold)).monospacedDigit()
                .strikethrough(x.lapsed)
                .privacySensitive()
        }
        .padding(.vertical, 10)
        .opacity(x.lapsed ? 0.55 : 1)
    }
    func tag(_ text: String, sym: String, ink: Color, wash: Color) -> some View {
        HStack(spacing: 3) {
            Image(systemName: sym).font(.system(size: 9.5, weight: .bold))
            Text(text).lineLimit(1)
        }
        .font(.system(.caption2, weight: .semibold))
        .foregroundStyle(ink)
        .padding(.horizontal, 7)
        .frame(minHeight: 20)
        .background(wash, in: Capsule())
        .privacySensitive()
    }
}

// MARK: - One repeat: its payments, and what you can say about it

struct RepeatSheet: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    @Environment(\.askKosh) private var askKosh
    let r: Recurring

    struct Bar: Identifiable { let id: String; let d: String; let a: Double }

    var body: some View {
        let x = RepeatNow(r: store.snap.recurring.first { $0.id == r.id } ?? r, today: store.snap.today)
        let ids: Set<String> = Set(r.ids ?? [])
        let rows: [Txn] = store.tx.filter { ids.contains($0.id) }.sorted { $0.d > $1.d }
        let bars: [Bar] = rows.reversed().map { Bar(id: $0.id, d: $0.d, a: $0.a) }
        NavigationStack {
            List {
                Section {
                    VStack(alignment: .leading, spacing: 10) {
                        HStack(spacing: 12) {
                            IconTile(symbol: r.sym.isEmpty ? "arrow.triangle.2.circlepath" : r.sym, color: x.kind.color, size: 44)
                            VStack(alignment: .leading, spacing: 2) {
                                Text(r.name).font(.headline).lineLimit(2)
                                Text(x.cancelled ? "You said you cancelled it" : x.lapsed ? "Not seen since " + Day.fmt(r.lapsed ?? "", "d MMM") : x.line)
                                    .font(.subheadline).foregroundStyle(.secondary)
                            }
                        }
                        HStack(alignment: .firstTextBaseline, spacing: 6) {
                            Text(Fmt.rupees(r.amount)).font(.system(.title, design: .rounded, weight: .bold)).privacySensitive()
                            if x.per > 1 { Text("· " + Fmt.rupees(r.monthly) + " a month").font(.subheadline).foregroundStyle(.secondary).privacySensitive() }
                        }
                        if let up = r.rise, let from = r.riseFrom, up > 0 {
                            Label("Up " + Fmt.rupees(up) + " since it was " + Fmt.rupees(from), systemImage: "arrow.up.right")
                                .font(.footnote.weight(.semibold)).foregroundStyle(RentInk.dueDeep)
                        }
                        if bars.count >= 2 {
                            Chart(bars) { b in
                                BarMark(x: .value("When", b.d), y: .value("Amount", b.a))
                                    .foregroundStyle(x.kind.color.gradient)
                                    .cornerRadius(4)
                            }
                            .chartXAxis(.hidden)
                            .chartYAxis(.hidden)
                            .frame(height: 70)
                            .padding(.top, 4)
                            .accessibilityElement(children: .ignore)
                            .spokenFigures("Its last " + SpokenWords.count(bars.count, "payment", "payments") + ", " + SpokenWords.range(bars.map(\.a)),
                                           hidden: "Its last " + SpokenWords.count(bars.count, "payment", "payments"))
                        }
                    }
                    .listRowBackground(Color.clear)
                }
                Section {
                    ForEach(rows) { t in TxRow(t: t, when: Day.short(t.d)).allowsHitTesting(false) }
                    if rows.isEmpty { Text("Its payments are older than what the ledger shows.").font(.footnote).foregroundStyle(.secondary) }
                } header: {
                    Text(rows.count == 1 ? "Its payment" : "Its \(rows.count) payments")
                }
                // a subscription kosh knows: how to cancel it, where and with a mail drafted (Plan.swift)
                if !x.cancelled && store.snap.plan?.subs.subs.contains(where: { $0.id == r.id }) == true {
                    Section { RepeatCancelRow(id: r.id) } footer: { Text("kosh shows you where and drafts the mail; you cancel it yourself.") }
                }
                if let live = store.live {
                    Section {
                        if x.cancelled {
                            Button { live.markRepeat(r.id, nil) } label: { Label("It’s still going", systemImage: "arrow.uturn.backward") }
                        } else {
                            Button { live.markRepeat(r.id, "gone:" + store.snap.today) } label: { Label("I cancelled it", systemImage: "xmark.circle") }
                        }
                        Button(role: .destructive) {
                            live.markRepeat(r.id, "no")
                            dismiss()
                        } label: { Label("It isn’t a repeat", systemImage: "minus.circle") }
                    } footer: {
                        Text(x.cancelled ? "If it charges you again, kosh shows it as a repeat again." : "Cancelled: it stops counting in what’s due and on autopilot, and comes back if it charges you again. Not a repeat: kosh stops treating these payments as one.")
                    }
                }
                Section {
                    Button {
                        let about: String = "Tell me about my " + r.name + " payments"
                        let seed: String = about + ": how much in a year, whether it has gone up, and when it comes next."
                        if let askKosh { askKosh(seed) } else { store.openAsk(seed) }
                    } label: { Label("Ask kosh about it", systemImage: "sparkles") }
                }
            }
            .listStyle(.insetGrouped)
            .navigationTitle("")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } } }
        }
    }
}

/// the repeats you said aren't repeats, each a tap from coming back
struct RepeatsSetAside: View {
    @Environment(Store.self) private var store
    @State private var shown = false
    var body: some View {
        let off: [RepeatOff] = store.snap.recurringOff ?? []
        if !off.isEmpty, let live = store.live {
            VStack(alignment: .leading, spacing: 8) {
                Button { withAnimation(Motion.open) { shown.toggle() } } label: {
                    HStack {
                        Text(off.count == 1 ? "One you said isn’t a repeat" : "\(off.count) you said aren’t repeats").font(.subheadline.weight(.semibold))
                        Spacer()
                        Image(systemName: shown ? "chevron.up" : "chevron.down").font(.caption.weight(.bold))
                    }
                    .foregroundStyle(.secondary)
                }
                .buttonStyle(.press)
                if shown {
                    ForEach(off) { o in
                        HStack {
                            Text(o.name).lineLimit(1)
                            Spacer()
                            Button("It is one") { live.markRepeat(o.id, nil) }.font(.subheadline.weight(.semibold))
                        }
                        .padding(.vertical, 4)
                    }
                }
            }
            .padding(16)
            .insightCard(22)
        }
    }
}

// MARK: - Repeats inside Insights

/// Insights' Repeats section (31 Oct: Repeats moved here from its own Transactions sub-tab): what goes out on its own
/// this month, and the way to every repeat
struct InsightsRepeats: View {
    @Environment(Store.self) private var store

    var body: some View {
        let today: String = store.snap.today
        let all: [RepeatNow] = store.snap.recurring.filter { store.who.owns($0.o ?? "me") }.map { RepeatNow(r: $0, today: today) }
        let live: [RepeatNow] = all.filter { $0.thisMonth }
        VStack(alignment: .leading, spacing: 12) {
            Button {
                store.push(.repeats)
            } label: {
                HStack(spacing: 6) {
                    Text("Repeats").font(.system(.title2, weight: .bold)).foregroundStyle(.primary)
                    Image(systemName: "chevron.right").font(.system(.subheadline, weight: .bold)).foregroundStyle(.secondary)
                    Spacer(minLength: 0)
                    Text(all.count == 1 ? "1 repeat" : String(all.count) + " repeats")
                        .font(.system(.subheadline, weight: .semibold)).foregroundStyle(.secondary)
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(.press)
            .accessibilityHint("Opens every payment that comes back each month")
            if live.isEmpty {
                Text("Payments that come back each month, at about the same amount, show here once kosh has seen them twice.")
                    .font(.subheadline).foregroundStyle(.secondary)
            } else {
                RepeatsHero(items: live)
            }
        }
    }
}
