import Foundation
import UserNotifications
import WebKit

/// What Erase removes beyond kosh's own folder and keys: the feedback notes and their screenshots, the diagnostics and
/// training files written for sharing, the reminders on the Lock Screen and in Notification Centre, and the cookies the
/// property-tax and EPF portals left in kosh's browser
enum EraseExtras {
    @MainActor
    static func run() {
        let fm = FileManager.default
        let support = fm.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        // the notes go from the screen too, so nothing writes them back
        FeedbackBook.shared.notes = []
        try? fm.removeItem(at: support.appendingPathComponent("kosh-feedback", isDirectory: true))
        FeedbackBook.folderGone()
        let tmp = fm.temporaryDirectory
        for name in (try? fm.contentsOfDirectory(atPath: tmp.path)) ?? [] where name.hasPrefix("kosh") {
            try? fm.removeItem(at: tmp.appendingPathComponent(name))
        }
        let center = UNUserNotificationCenter.current()
        center.removeAllPendingNotificationRequests()
        center.removeAllDeliveredNotifications()
        WKWebsiteDataStore.default().removeData(ofTypes: WKWebsiteDataStore.allWebsiteDataTypes(), modifiedSince: .distantPast) {}
    }
}

/// Every key kosh writes in the phone's defaults, by its prefix, and the few that outlast Erase. One list: a new key
/// either starts with one of these and goes with Erase, or is named below as the phone's own preference.
///
/// Everything kosh keeps on files lives in LiveSession.folder (the ledger, the profile, the sealed mail, statements,
/// photos, decisions, claims, prices, fees, layouts, icons), the feedback folder and the temporary folder
/// (EraseExtras), the app group (the widgets' feed, WFStore), and the Keychain (eraseAll names each key).
enum KoshDefaults {
    /// beta. the beta's reading and what you set for it (inboxes, rules, the gold price, how it counts, CRED's account)
    /// agent. Ask kosh and Claude (its service and model, the payees asked about)
    /// kosh. what you noticed, hushed and snoozed, the setup card, the sample household's additions
    /// home. Home's folds and ranges, and the name it calls you; plan. how each tab's sections are arranged
    /// watch. what kosh noticed that you marked done; decide. the rates the five years run at; brief. the briefings
    /// quota. pw. cas. limits and reader versions; cards. accts. ins. shops. bills. vouchers. chapters. upclose. intro.
    /// what each screen was left showing (vouchers used, bills shut, which card or account)
    /// alerts. Payments by SMS: the messages waiting to be read, the words seen lately, and the log of what was
    /// dropped and from which sender (until 30 Oct these outlived Erase); find. Find's recent searches
    static let prefixes: [String] = ["beta.", "agent.", "kosh.", "home.", "plan.", "watch.", "decide.", "brief.", "quota.", "pw.", "cas.",
                                     "cards.", "accts.", "ins.", "shops.", "bills.", "vouchers.", "chapters.", "upclose.", "intro.", "alerts.", "find."]
    /// the phone's own preferences for the app, none of them money or names: the lock, Hide amounts, the tab bar, the
    /// bank icons, reminders on or off. (Appearance and the widgets' choices are in the app group, and stay too.)
    static let outlast: Set<String> = ["kosh.lock", "kosh.lock.reset.v2", "kosh.faceid", "kosh.hidden", "kosh.tabs", "kosh.tabs.icons",
                                       "kosh.slots", "kosh.chapters.tab", "kosh.icons", "kosh.reminders"]

    /// Erase: every key kosh wrote goes, but the phone's preferences
    static func erase(_ ud: UserDefaults) {
        let all: [String] = Array(ud.dictionaryRepresentation().keys)
        for k in all where !outlast.contains(k) && prefixes.contains(where: { k.hasPrefix($0) }) {
            ud.removeObject(forKey: k)
        }
    }
}
