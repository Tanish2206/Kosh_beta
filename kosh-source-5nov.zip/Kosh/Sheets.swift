import SwiftUI

// MARK: - One payment

struct TxSheet: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    @Environment(\.askKosh) private var askKosh
    let id: String
    /// opened from a swipe, straight at its category or its chapter: done once that's picked
    let quick: Bool
    @State private var note = ""
    @State private var path: [String]
    @State private var refundEditing = false
    /// "all payments to this payee, or just this one?", asked once the change is made
    @State private var asking = false
    /// what was answered while this sheet is open, by field ("c", "f"): a sub-category picked next isn't asked again
    @State private var answered: [String: Bool] = [:]
    /// how many times and how much to this payee, worked out once (not on every tap)
    @State private var history: (count: Int, total: Double)? = nil

    init(id: String, start: String? = nil) {
        self.id = id
        self.quick = start != nil
        _path = State(initialValue: start.map { [$0] } ?? [])
    }

    var body: some View {
        NavigationStack(path: $path) {
            Group {
                if let t = store.txn(id) {
                    // (type-erased: the sheet's whole page as one generic type overflowed the stack in Debug builds)
                    AnyView(form(t))
                } else {
                    ContentUnavailableView("Gone", systemImage: "tray")
                }
            }
            .navigationDestination(for: String.self) { key in
                if key == "cats" || key == "catsFind" {
                    CategoryPicker(id: id, path: $path, find: key == "catsFind")
                } else if key == "trip" {
                    TripPicker(id: id, path: $path)
                } else {
                    SubPicker(id: id, cat: String(key.dropFirst(4)), path: $path)
                }
            }
        }
        // Done floats over every page of the sheet (the category list, a search, the keyboard up), so it's never gone
        .overlay(alignment: .topTrailing) {
            Button {
                store.setNote(id, note)
                dismiss()
            } label: {
                Text("Done").font(.body.weight(.semibold)).padding(.horizontal, 6).frame(minHeight: 36)
            }
            .buttonStyle(.glass)
            .padding(.top, 12)
            .padding(.trailing, 16)
            .accessibilityHint("Saves and closes the payment")
        }
        .presentationDetents(quick ? [.large] : [.medium, .large])
        .onAppear { store.txStart = nil }
        // from a swipe: picked, so done (after the question, if there is one)
        .onChange(of: path) { old, new in
            if quick && new.isEmpty && !old.isEmpty && store.applyAsk?.tx != id { dismiss() }
        }
        .task(id: store.applyAsk?.id) {
            guard let a = store.applyAsk, a.tx == id else { return }
            if let all = answered[a.field] {
                if all { store.applyToAll(a, quiet: true) } else { store.applyAsk = nil }
                return
            }
            try? await Task.sleep(for: .milliseconds(350))
            asking = true
        }
        .confirmationDialog(store.applyAsk.map(ApplyAskWords.title) ?? "",
                            isPresented: $asking, titleVisibility: .visible, presenting: store.applyAsk) { a in
            Button(ApplyAskWords.all(a)) { answered[a.field] = true; store.applyToAll(a) }
            Button("Just this one", role: .cancel) { answered[a.field] = false; store.applyAsk = nil }
        } message: { a in
            Text(ApplyAskWords.message(a))
        }
        .onChange(of: asking) { _, on in
            if !on {
                store.applyAsk = nil
                if quick { dismiss() }
            }
        }
        .modifier(UndoBar(lift: 24))
    }

    static func way(_ t: Txn) -> String {
        if let w = PayWay.line(t) { return w }
        return t.card.isEmpty ? "—" : t.card
    }
    /// where it came from, and how its category was decided
    static func source(_ t: Txn) -> String {
        var from: String = "From a bank alert."
        if t.src == "bill" { from = "Booked from your bills; replaced when the bank debit arrives." }
        else if t.src == "manual" { from = "Added by hand on this phone." }
        else if t.src == "statement" { from = "From your bank’s statement; no alert came for it." }
        var how: String = ""
        if let ls = t.ls, ls.count == 10 { how = " Filed like the payment to this payee you filed on " + Day.fmt(ls, "d MMM") + ", about the same sum." }
        else if t.lr == true { how = " Tagged the way you tagged earlier payments to this payee." }
        else if t.g && !t.u { how = " The category is kosh’s guess until you confirm it." }
        return from + how
    }
    /// one scrolling page, not a Form: the hero runs edge to edge under the Done button, and changes move views
    /// inside a stack (which animates smoothly) instead of resizing list rows (which iOS cross-fades)
    func form(_ t: Txn) -> some View {
        let source: String = Self.source(t)
        let live: Bool = store.live != nil
        let spendLike: Bool = (t.k == "out" || t.k == "prepaid") && t.refOf == nil
        let splittable: Bool = live && t.k == "out" && t.partOf == nil && t.refOf == nil
        return ScrollView {
            VStack(spacing: 0) {
                PaymentHeader(t: t)
                AnyView(VStack(alignment: .leading, spacing: 20) {
                    // 1. what it was: one tap on a category, its sub-category, whom it was for, a note
                    VStack(alignment: .leading, spacing: 14) {
                        if t.u {
                            Text("What was it?").font(.headline).padding(.horizontal, 4)
                        }
                        TagChips(t: t, find: { path.append("catsFind") }) { path.append("cats") }
                            .padding(.horizontal, -16)
                        // money in filed as rent, or proposed as a tenant's: whose rent it is (RentTag.swift)
                        if live && (t.k == "in" || t.dr == "in") && t.partOf == nil && (t.c == "Rent received" || t.rt != nil) {
                            RentFrom(t: t)
                                .transition(.opacity)
                        }
                        if t.k == "out" {
                            Picker("For", selection: Binding(get: { store.txn(id)?.f ?? "" }, set: { store.setFor(id, $0) })) {
                                Text("Me").tag("me")
                                Text(live ? "Family" : "Mom").tag("mom")
                                Text("Home").tag("home")
                                Text("Work").tag("work")
                            }
                            .pickerStyle(.segmented)
                        }
                        TextField("Add a note", text: $note, axis: .vertical)
                            .lineLimit(1...4)
                            .padding(.horizontal, 16)
                            .padding(.vertical, 13)
                            .background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                        if t.u {
                            SheetFootnote("Pick what it was. Every payment to this payee follows, if you want.")
                        }
                    }
                    // what the order was: what was bought, what the bill printed, its tags, its mails (OrderViews.swift)
                    if let o = store.order(t) {
                        OrderCard(t: t, o: o)
                    }
                    // a bill paid: where, for what, from where, and whether the bank confirmed it (BillLoop.swift)
                    BillLoopSlot(t: t)
                    // 2. whether it counts: one button
                    if live && spendLike {
                        VStack(alignment: .leading, spacing: 8) {
                            CountRow(t: t)
                        }
                    }
                    // money that came in: whether it counts as money in
                    if live && (t.dr == "in" || t.k == "in") && t.refOf == nil && t.partOf == nil {
                        VStack(alignment: .leading, spacing: 8) {
                            InCountRow(t: t)
                        }
                    }
                    // a payment through an app (CRED): which of your accounts it really left
                    if live, let app = store.railOf(t) {
                        PaidFromCard(t: t, app: app)
                    }
                    // the same sum a few days either side: this one told twice?
                    let twins: [Txn] = store.twins(of: t)
                    if !twins.isEmpty {
                        TwiceCard(t: t, twins: twins) { dismiss() }
                    }
                    // 3. who shared it: how many, equal or not
                    if splittable {
                        VStack(alignment: .leading, spacing: 8) {
                            SheetCard {
                                VStack(alignment: .leading, spacing: 14) {
                                    QuickSplit(t: t) {
                                        store.setNote(id, note)
                                        store.sheet = .split(t.id)
                                    }
                                }
                                .padding(16)
                            }
                            SheetFootnote(store.shares(of: t.id).isEmpty ? "Their shares leave your spending and wait under Owed to you, with a reminder you can send." : "Marked paid when it comes in, or tick it here.")
                        }
                    }
                    if t.partOf != nil {
                        SheetCard {
                            Label(SplitWords.part(t, store), systemImage: "square.split.2x1")
                                .foregroundStyle(.secondary)
                                .padding(16)
                            Divider().padding(.leading, 52)
                            Button(role: .destructive) {
                                store.resetCharge(t.id)
                                dismiss()
                            } label: { Label("Merge it back", systemImage: "arrow.uturn.backward") }
                            .buttonStyle(SheetRowStyle())
                        }
                    }
                    if live && t.dr == "out" && t.partOf == nil, let r = store.refund(t.id) {
                        RefundCard(t: t, r: r, editing: $refundEditing)
                    }
                    if live && t.dr == "in" {
                        // money someone paid back says whose share it was; any other credit can be a refund
                        if (t.paysBack ?? []).isEmpty {
                            RefundLinkCard(t: t)
                        } else {
                            PaidBackCard(t: t)
                        }
                    }
                    // the rest: its chapter, a refund to expect, its history, and a question for Ask kosh
                    VStack(alignment: .leading, spacing: 8) {
                        SheetCard {
                            if live && (t.dr == "out" || t.tr != nil) {
                                NavigationLink(value: "trip") {
                                    let trip: TripInfo? = store.trip(t.tr)
                                    HStack(spacing: 12) {
                                        Label("Chapter", systemImage: "book.closed").foregroundStyle(Color.primary)
                                        Spacer(minLength: 8)
                                        if let trip {
                                            Image(systemName: trip.sym).foregroundStyle(trip.tint)
                                            Text(trip.name).lineLimit(1).foregroundStyle(.secondary)
                                        } else {
                                            Text("None").foregroundStyle(.secondary)
                                        }
                                        Image(systemName: "chevron.right").font(.footnote.weight(.semibold)).foregroundStyle(.tertiary)
                                    }
                                }
                                .buttonStyle(SheetRowStyle())
                                Divider().padding(.leading, 52)
                            }
                            if live && t.dr == "out" && t.partOf == nil && store.refund(t.id) == nil {
                                Button { refundEditing = true } label: {
                                    Label("Expecting a refund", systemImage: "arrow.uturn.backward.circle")
                                }
                                .buttonStyle(SheetRowStyle())
                                Divider().padding(.leading, 52)
                            }
                            if let h = history, h.count > 1 {
                                Button {
                                    store.setNote(id, note)
                                    var q = FindQuery()
                                    q.text = t.m
                                    store.findPreset = q
                                    dismiss()
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) { store.push(.find) }
                                } label: {
                                    HStack(spacing: 12) {
                                        Label("Every payment to \(t.m)", systemImage: "list.bullet").lineLimit(1).foregroundStyle(Color.primary)
                                        Spacer(minLength: 8)
                                        Text("\(h.count) times, \(Fmt.rupees(h.total))").foregroundStyle(.secondary).privacySensitive()
                                    }
                                }
                                .buttonStyle(SheetRowStyle())
                                Divider().padding(.leading, 52)
                            }
                            // the mail it was read from, and "this isn't a payment"
                            if live, t.src == "gmail" || t.src.isEmpty {
                                let mailID: String = String(t.id.split(separator: "#").first ?? Substring(t.id))
                                // (every mail of its order: the placed, paid, shipped, delivered and fee-invoice mails it is one payment of)
                                let mails: [String] = store.orderMailIDs(t)
                                if store.live?.records.contains(where: { $0.id == mailID }) == true {
                                    Button {
                                        store.setNote(id, note)
                                        dismiss()
                                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) { store.betaSheet = .source(SourceRef(title: t.m, mails: mails, type: "move")) }
                                    } label: {
                                        HStack(spacing: 12) {
                                            Label("Where kosh read this", systemImage: "envelope.open").foregroundStyle(Color.primary)
                                            Spacer(minLength: 8)
                                            if mails.count > 1 { Text(String(mails.count) + " mails").foregroundStyle(.secondary) }
                                        }
                                    }
                                    .buttonStyle(SheetRowStyle())
                                    Divider().padding(.leading, 52)
                                }
                            }
                            Button {
                                store.setNote(id, note)
                                let way: String = t.k == "in" ? "from " : "to "
                                let what: String = "Tell me about the " + Fmt.rupees(t.a) + " " + way + t.m
                                let when: String = " on " + Day.fmt(t.d, "d MMM yyyy")
                                let seed: String = what + when + ": what it was, how often I pay them, and anything worth knowing."
                                if let askKosh { askKosh(seed) } else { store.openAsk(seed) }
                            } label: {
                                Label("Ask kosh about this", systemImage: "sparkles")
                            }
                            .buttonStyle(SheetRowStyle())
                        }
                        SheetFootnote(source)
                    }
                }
                .padding(.horizontal, 16)
                .padding(.top, 20)
                .padding(.bottom, 36))
            }
        }
        .scrollIndicators(.hidden)
        .scrollDismissesKeyboard(.interactively)
        .ignoresSafeArea(edges: .top)
        .background(Color(uiColor: .systemBackground))
        .navigationTitle("")
        .navigationBarTitleDisplayMode(.inline)
        .toolbarBackground(.hidden, for: .navigationBar)
        .sheet(isPresented: $refundEditing) {
            RefundSheet(t: t).presentationDetents([.medium, .large])
        }
        .onAppear {
            note = t.n
            if history == nil {
                let m: String = t.m.lowercased()
                var count: Int = 0, total: Double = 0
                for x in store.tx where x.k == t.k && x.m.lowercased() == m { count += 1; total += x.a }
                history = (count, total)
            }
        }
        // a note is kept however the sheet is closed
        .onDisappear { if note != (store.txn(id)?.n ?? t.n) { store.setNote(id, note) } }
    }
}

/// a rounded group on a payment's sheet, like a grouped list's section
struct SheetCard<Content: View>: View {
    let content: Content
    init(@ViewBuilder content: () -> Content) { self.content = content() }
    var body: some View {
        VStack(alignment: .leading, spacing: 0) { content }
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
    }
}

/// a tappable row in a SheetCard: full width, list-row height, a soft highlight while pressed
struct SheetRowStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .frame(maxWidth: .infinity, minHeight: 50, alignment: .leading)
            .padding(.horizontal, 16)
            .contentShape(Rectangle())
            .background(configuration.isPressed ? Color.primary.opacity(0.08) : Color.clear)
    }
}

/// the small print under a card
struct SheetFootnote: View {
    let text: String
    init(_ text: String) { self.text = text }
    var body: some View {
        Text(text).font(.footnote).foregroundStyle(.secondary).padding(.horizontal, 6).fixedSize(horizontal: false, vertical: true)
    }
}

/// the refund part of a payment's sheet, as a card
struct RefundCard: View {
    @Environment(Store.self) private var store
    let t: Txn
    let r: RefundInfo
    @Binding var editing: Bool
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Refund").font(.headline).padding(.horizontal, 4)
            SheetCard {
                RefundStatus(r: r, today: store.snap.today)
                    .padding(16)
                Divider().padding(.leading, 52)
                if r.state != "back" {
                    Button { store.refundBack(t.id, true) } label: { Label("It came back", systemImage: "checkmark.circle") }
                        .buttonStyle(SheetRowStyle())
                    Divider().padding(.leading, 52)
                } else if r.manual {
                    Button { store.refundBack(t.id, false) } label: { Label("It hasn't come back yet", systemImage: "arrow.uturn.backward") }
                        .buttonStyle(SheetRowStyle())
                    Divider().padding(.leading, 52)
                }
                Button { editing = true } label: { Label("Change amount or date", systemImage: "pencil") }
                    .buttonStyle(SheetRowStyle())
                Divider().padding(.leading, 52)
                Button(role: .destructive) { store.stopRefund(t.id) } label: { Label("Not expecting a refund", systemImage: "xmark.circle") }
                    .buttonStyle(SheetRowStyle())
                    .foregroundStyle(Color.red)
            }
            SheetFootnote("What comes back leaves this payment's spending, in the month you paid; the credit itself isn't counted as income.")
        }
    }
}

/// on a credit someone paid back with, as a card: whose share it settled, and a way to say it wasn't
struct PaidBackCard: View {
    @Environment(Store.self) private var store
    let t: Txn
    var body: some View {
        let ids: [String] = t.paysBack ?? []
        let shares: [OwedItem] = store.owed.filter { ids.contains($0.id) }
        let who: String = shares.first.map { String($0.name.split(separator: " ").first ?? "") } ?? ""
        VStack(alignment: .leading, spacing: 8) {
            Text("Paid back").font(.headline).padding(.horizontal, 4)
            SheetCard {
                ForEach(shares) { o in
                    HStack(spacing: 12) {
                        Text(o.name)
                        Spacer(minLength: 8)
                        Text(o.title + " · " + Fmt.rupees(o.amount)).lineLimit(1).foregroundStyle(.secondary).privacySensitive()
                    }
                    .frame(minHeight: 50)
                    .padding(.horizontal, 16)
                    Divider().padding(.leading, 16)
                }
                Button(role: .destructive) {
                    withAnimation(Motion.open) { store.notPaidBack(t.id) }
                } label: {
                    Label("Not a payback", systemImage: "xmark.circle")
                }
                .buttonStyle(SheetRowStyle())
                .foregroundStyle(Color.red)
            }
            SheetFootnote("Matched to what " + (who.isEmpty ? "they" : who) + " owed you: settled under Owed to you, and not counted as income.")
        }
    }
}

/// on a credit, as a card: the payment it refunds, or which one it might
struct RefundLinkCard: View {
    @Environment(Store.self) private var store
    let t: Txn
    var body: some View {
        if let of = t.refOf, let p = store.txn(of) {
            VStack(alignment: .leading, spacing: 8) {
                SheetCard {
                    HStack(spacing: 12) {
                        Text("Refund for")
                        Spacer(minLength: 8)
                        Text(p.m + " · " + Day.fmt(p.od ?? p.d, "d MMM")).lineLimit(1).foregroundStyle(.secondary)
                    }
                    .frame(minHeight: 50)
                    .padding(.horizontal, 16)
                    Divider().padding(.leading, 16)
                    Button(role: .destructive) { store.linkRefund(credit: t.id, to: nil) } label: {
                        Label("Not a refund", systemImage: "xmark.circle")
                    }
                    .buttonStyle(SheetRowStyle())
                    .foregroundStyle(Color.red)
                }
                SheetFootnote("Set against that payment: its spending is lower by this much, and this isn't counted as income.")
            }
        } else {
            let cands: [Txn] = store.refundCandidates(for: t)
            if !cands.isEmpty {
                VStack(alignment: .leading, spacing: 8) {
                    SheetCard {
                        Menu {
                            ForEach(cands) { p in
                                Button(RefundLinkSection.label(p)) { store.linkRefund(credit: t.id, to: p.id) }
                            }
                        } label: {
                            Label("This is a refund for…", systemImage: "arrow.uturn.backward.circle")
                                .frame(maxWidth: .infinity, minHeight: 50, alignment: .leading)
                                .padding(.horizontal, 16)
                                .contentShape(Rectangle())
                        }
                    }
                    SheetFootnote("Set it against the payment it pays back: that payment's spending drops, and this isn't counted as income.")
                }
            }
        }
    }
}

struct CategoryPicker: View {
    @Environment(Store.self) private var store
    let id: String
    @Binding var path: [String]
    /// opened from the search button: the field is ready to type in
    var find: Bool = false
    @State private var query = ""
    @FocusState private var searching: Bool

    struct Hit: Identifiable, Hashable { let c: String; let s: String; var id: String { c + "|" + s } }
    /// the heading over gift cards and wallet top-ups (a title on screen, never saved)
    static let parkedTitle: String = "Saved to spend later"

    /// the kinds of category, in the order that suits this payment: money in first for a credit
    var groups: [(String, [String])] {
        let isIn = store.txn(id)?.k == "in"
        let spend = ("Spending", store.categories(kind: "spend"))
        let parked = (Self.parkedTitle, store.categories(kind: "prepaid"))
        let moved = ("Moved, not spent", store.categories(kind: "move"))
        let income = ("Money in", store.categories(kind: "income"))
        return (isIn ? [income, moved, spend, parked] : [spend, parked, moved, income]).filter { !$0.1.isEmpty }
    }
    var all: [String] { groups.flatMap(\.1) }

    /// every category and sub-category whose name has what you typed
    var hits: [Hit] {
        let q = query.trimmingCharacters(in: .whitespaces).lowercased()
        guard !q.isEmpty else { return [] }
        var out: [Hit] = []
        for c in all {
            if c.lowercased().contains(q) { out.append(Hit(c: c, s: "")) }
            for s in store.snap.cats[c]?.subs ?? [] where s.lowercased().contains(q) { out.append(Hit(c: c, s: s)) }
        }
        return out
    }

    func pick(_ c: String, _ s: String) {
        store.setCategory(id, c, s)
        path = []
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 28) {
                // the search sits on the page itself, under the title, so the sheet's own buttons stay put
                HStack(spacing: 8) {
                    Image(systemName: "magnifyingglass").foregroundStyle(.secondary)
                    TextField("Fuel, rent, gift card…", text: $query)
                        .focused($searching)
                        .submitLabel(.search)
                        .autocorrectionDisabled()
                        .textInputAutocapitalization(.never)
                    if !query.isEmpty {
                        Button { query = "" } label: { Image(systemName: "xmark.circle.fill").foregroundStyle(.tertiary) }
                            .buttonStyle(.press)
                            .accessibilityLabel("Clear the search")
                    }
                }
                .padding(.horizontal, 14)
                .frame(height: 44)
                .background(Color(uiColor: .secondarySystemBackground), in: Capsule())
                if query.trimmingCharacters(in: .whitespaces).isEmpty {
                    if let t = store.txn(id), !t.c.isEmpty {
                        HStack(spacing: 10) {
                            Image(systemName: store.symbol(t.c)).font(.footnote.weight(.semibold)).foregroundStyle(store.catColor(t.c))
                            Text(t.s.isEmpty ? t.c : "\(t.c) · \(t.s)").font(.subheadline.weight(.medium))
                            Spacer()
                            Text("now").font(.caption).foregroundStyle(.secondary)
                        }
                        .padding(.horizontal, 14).padding(.vertical, 11)
                        .background(store.catColor(t.c).opacity(0.1), in: Capsule())
                    }
                    ForEach(groups, id: \.0) { g in
                        VStack(alignment: .leading, spacing: 14) {
                            Text(g.0).font(.footnote.weight(.semibold)).foregroundStyle(.secondary).textCase(.uppercase).padding(.leading, 4)
                            LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 6), count: 4), alignment: .center, spacing: 20) {
                                ForEach(g.1, id: \.self) { c in cell(c) }
                            }
                            if g.0 == Self.parkedTitle {
                                Text("Gift cards and wallet top-ups aren't spending until you spend them. To count them when you top up, turn that on in Settings › How kosh counts.")
                                    .font(.caption).foregroundStyle(.secondary).padding(.horizontal, 4)
                            }
                        }
                    }
                } else {
                    results
                }
            }
            .padding(.horizontal, 20)
            .padding(.top, 8)
            .padding(.bottom, 30)
        }
        .scrollDismissesKeyboard(.interactively)
        .onAppear { if find { DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) { searching = true } } }
        .navigationTitle("Category")
        .navigationBarTitleDisplayMode(.inline)
    }

    /// a category as Apple draws an app: a round, coloured icon with its name under it
    func cell(_ c: String) -> some View {
        let subs = store.snap.cats[c]?.subs ?? []
        let on = store.txn(id)?.c == c
        let col = store.catColor(c)
        return Button {
            if subs.isEmpty { pick(c, "") } else { path.append("cat:" + c) }
        } label: {
            VStack(spacing: 7) {
                Image(systemName: store.symbol(c))
                    .font(.system(size: 21, weight: .semibold))
                    .foregroundStyle(.white)
                    .frame(width: 54, height: 54)
                    .background(col.gradient, in: Circle())
                    .overlay(Circle().stroke(col, lineWidth: on ? 2.5 : 0).padding(-4))
                Text(c)
                    .font(.caption)
                    .foregroundStyle(Color.primary)
                    .multilineTextAlignment(.center)
                    .lineLimit(2)
                    .minimumScaleFactor(0.85)
                    .frame(height: 30, alignment: .top)
            }
            .frame(maxWidth: .infinity)
            .contentShape(Rectangle())
        }
        .buttonStyle(.press)
        .accessibilityLabel(c + (on ? ", chosen" : ""))
    }

    @ViewBuilder var results: some View {
        let list = hits
        VStack(spacing: 0) {
            ForEach(Array(list.enumerated()), id: \.element.id) { i, h in
                if i > 0 { Divider().padding(.leading, 58) }
                Button { pick(h.c, h.s) } label: {
                    HStack(spacing: 14) {
                        Image(systemName: store.symbol(h.c)).font(.system(size: 15, weight: .semibold)).foregroundStyle(.white)
                            .frame(width: 32, height: 32).background(store.catColor(h.c).gradient, in: Circle())
                        VStack(alignment: .leading, spacing: 1) {
                            Text(h.s.isEmpty ? h.c : h.s).foregroundStyle(Color.primary)
                            if !h.s.isEmpty { Text(h.c).font(.caption).foregroundStyle(.secondary) }
                        }
                        Spacer()
                        if store.txn(id)?.c == h.c && (h.s.isEmpty || store.txn(id)?.s == h.s) { Image(systemName: "checkmark").font(.footnote.weight(.bold)).foregroundStyle(Color.kosh) }
                    }
                    .padding(.horizontal, 14).padding(.vertical, 11)
                    .contentShape(Rectangle())
                }
                .buttonStyle(.press)
            }
        }
        .background(Color.surface, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
        // nothing fits: make what you typed a sub-category of the category it's in now
        let typed = query.trimmingCharacters(in: .whitespaces).capitalized
        if let cur = store.txn(id)?.c, !cur.isEmpty, !list.contains(where: { $0.s.lowercased() == typed.lowercased() }) {
            Button { pick(cur, typed) } label: {
                Label("Add “\(typed)” under \(cur)", systemImage: "plus.circle.fill")
                    .font(.subheadline.weight(.semibold))
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(14)
                    .background(Color.kosh.opacity(0.08), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            }
            .buttonStyle(.press)
            .foregroundStyle(Color.kosh)
        }
        if list.isEmpty && store.txn(id)?.c == nil {
            Text("Nothing matches “\(query)”.").font(.subheadline).foregroundStyle(.secondary)
        }
    }
}

struct SubPicker: View {
    @Environment(Store.self) private var store
    let id: String
    let cat: String
    @Binding var path: [String]
    @State private var own = ""

    func pick(_ s: String) {
        store.setCategory(id, cat, s)
        path = []
    }

    var body: some View {
        let col = store.catColor(cat)
        let t = store.txn(id)
        ScrollView {
            VStack(spacing: 22) {
                VStack(spacing: 10) {
                    Image(systemName: store.symbol(cat))
                        .font(.system(size: 30, weight: .semibold)).foregroundStyle(.white)
                        .frame(width: 76, height: 76)
                        .background(col.gradient, in: Circle())
                    Text(cat).font(.title2.weight(.bold))
                }
                .padding(.top, 6)
                Button { pick("") } label: {
                    HStack {
                        Text("Just \(cat)").font(.body.weight(.medium))
                        Spacer()
                        if t?.c == cat && (t?.s ?? "").isEmpty { Image(systemName: "checkmark").font(.footnote.weight(.bold)).foregroundStyle(col) }
                    }
                    .padding(.horizontal, 16).padding(.vertical, 14)
                    .background(Color.surface, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                }
                .buttonStyle(.press)
                LazyVGrid(columns: [GridItem(.flexible(), spacing: 10), GridItem(.flexible(), spacing: 10)], spacing: 10) {
                    ForEach(store.snap.cats[cat]?.subs ?? [], id: \.self) { s in
                        let on = t?.c == cat && t?.s == s
                        Button { pick(s) } label: {
                            HStack(spacing: 6) {
                                Text(s).font(.subheadline.weight(on ? .semibold : .regular)).lineLimit(1).minimumScaleFactor(0.8)
                                Spacer(minLength: 0)
                                if on { Image(systemName: "checkmark").font(.caption.weight(.bold)) }
                            }
                            .foregroundStyle(on ? col : Color.primary)
                            .padding(.horizontal, 14).padding(.vertical, 13)
                            .frame(maxWidth: .infinity)
                            .background(on ? AnyShapeStyle(col.opacity(0.14)) : AnyShapeStyle(Color.surface), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                        }
                        .buttonStyle(.press)
                    }
                }
                HStack(spacing: 10) {
                    TextField("Your own sub-category", text: $own).textInputAutocapitalization(.words)
                    Button("Add") { pick(own.trimmingCharacters(in: .whitespaces)) }
                        .font(.subheadline.weight(.semibold))
                        .disabled(own.trimmingCharacters(in: .whitespaces).isEmpty)
                }
                .padding(.horizontal, 16).padding(.vertical, 13)
                .background(Color.surface, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                Text("If you’ve paid this payee before, kosh asks whether those payments should follow.")
                    .font(.caption).foregroundStyle(.secondary)
            }
            .padding(.horizontal, 20)
            .padding(.bottom, 30)
        }
        .navigationTitle("")
        .navigationBarTitleDisplayMode(.inline)
    }
}

// MARK: - Naming payments: a payee at a time, the ones that cost the most first

struct TagStackSheet: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    @State private var queue: [PayeeGroup] = []
    @State private var index = 0
    @State private var drag: CGSize = .zero
    @State private var named = 0
    @State private var namedPayments = 0
    @State private var flying = false
    /// Claude filing the queue: under way, and what it said
    @State private var claudeBusy = false
    @State private var claudeSaid: String?

    var remaining: Int { max(0, queue.count - index) }
    var paymentsLeft: Int { queue.dropFirst(index).reduce(0) { $0 + $1.rows.count } }

    func advance(_ pick: Suggestion?) {
        guard index < queue.count, !flying else { return }
        let g = queue[index]
        flying = true
        if let pick {
            store.fileGroup(g, pick.c, pick.s)
            named += 1
            namedPayments += g.rows.count
        }
        withAnimation(Motion.open) {
            drag = CGSize(width: pick == nil ? -520 : 520, height: 40)
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
            var tx = Transaction()
            tx.disablesAnimations = true
            withTransaction(tx) { drag = .zero }
            withAnimation(Motion.large) { index += 1 }
            flying = false
        }
    }

    var body: some View {
        VStack(spacing: 14) {
            HStack(alignment: .firstTextBaseline) {
                VStack(alignment: .leading, spacing: 2) {
                    Text(remaining == 0 ? "Done" : remaining == 1 ? "One payee to name" : "\(Words.cap(Words.number(remaining))) payees to name")
                        .font(.title2.weight(.bold))
                        .contentTransition(.numericText())
                    if remaining > 0 {
                        Text("\(paymentsLeft) payment\(paymentsLeft == 1 ? "" : "s") between them. One name files every payment to that payee.")
                            .font(.subheadline).foregroundStyle(.secondary)
                            .contentTransition(.numericText())
                    }
                    if let claudeSaid {
                        Text(claudeSaid).font(.footnote).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                    }
                }
                Spacer()
                Button { dismiss() } label: { Image(systemName: "xmark") }
                    .buttonStyle(.glass)
                    .buttonBorderShape(.circle)
                    .accessibilityLabel("Close")
            }
            // Claude files what it can (known shops, and its likely guesses for you to confirm); the rest stays here
            if KoshAgent.useCloud && remaining > 0 && claudeSaid == nil {
                Button {
                    claudeBusy = true
                    Task { @MainActor in
                        let n = await KoshAgent.nameUnknown(store, now: true)
                        let plural: String = n == 1 ? "" : "s"
                        if n < 0 { claudeSaid = "AI is already filing them; the ones it files leave this list as it goes." }
                        else if n == 0 { claudeSaid = "The AI couldn’t place these: people, or shops it doesn’t know. They’re yours to name." }
                        else { claudeSaid = "AI filed \(n) payee\(plural). Its guesses show as guesses on each payment, to confirm or change." }
                        claudeBusy = false
                        // what Claude filed leaves the cards still to come; the rest stay where they were
                        let filed = KoshAgent.lastFiled
                        if !filed.isEmpty { queue = Array(queue.prefix(index)) + queue.dropFirst(index).filter { !filed.contains($0.id) } }
                    }
                } label: {
                    HStack(spacing: 8) {
                        if claudeBusy { ProgressView().controlSize(.small) } else { Image(systemName: "sparkles") }
                        Text(claudeBusy ? "Filing them with AI…" : "File what AI can")
                    }
                    .frame(maxWidth: .infinity)
                }
                .buttonStyle(.glass)
                .disabled(claudeBusy)
            }
            ProgressView(value: Double(index), total: Double(max(1, queue.count)))
                .tint(Color.green)
                .animation(Motion.open, value: index)
            if index < queue.count {
                ZStack {
                    ForEach(Array(queue.enumerated()).reversed(), id: \.element.id) { i, g in
                        let k = i - index
                        if k >= 0 && k < 3 {
                            TagCard(g: g, suggestions: store.suggestions(for: g), onPick: { advance($0) }, drag: k == 0 ? drag : .zero)
                                .scaleEffect(1 - CGFloat(k) * 0.05)
                                .offset(y: CGFloat(k) * 14)
                                .brightness(Double(k) * -0.03)
                                .zIndex(Double(10 - k))
                                .offset(k == 0 ? drag : .zero)
                                .rotationEffect(.degrees(k == 0 ? Double(drag.width / 18) : 0))
                                .gesture(k == 0 ? DragGesture()
                                    .onChanged { v in drag = v.translation }
                                    .onEnded { v in
                                        let sg = store.suggestions(for: g)
                                        if v.translation.width > 110 || v.predictedEndTranslation.width > 320 { advance(sg.first) }
                                        else if v.translation.width < -110 || v.predictedEndTranslation.width < -320 { advance(nil) }
                                        else { withAnimation(Motion.settle) { drag = .zero } }
                                    } : nil)
                        }
                    }
                }
                .frame(height: 440)
                HStack(spacing: 12) {
                    Button { advance(nil) } label: {
                        Text("Later").frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.glass)
                    Menu {
                        ForEach(store.spendCategories, id: \.self) { c in
                            let subs = store.snap.cats[c]?.subs ?? []
                            if subs.isEmpty {
                                Button(c) { advance(Suggestion(label: c, c: c, s: "", card: "", merchant: "", sym: store.symbol(c))) }
                            } else {
                                Menu(c) {
                                    ForEach(subs, id: \.self) { s in
                                        Button(s) { advance(Suggestion(label: s, c: c, s: s, card: "", merchant: "", sym: store.symbol(c))) }
                                    }
                                }
                            }
                        }
                        Button("My own account") { advance(Suggestion(label: "My own account", c: "Self Transfer", s: "", card: "", merchant: "", sym: store.symbol("Self Transfer"))) }
                    } label: {
                        Text("Something else").frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.glassProminent).koshFilled()
                }
                .controlSize(.large)
                .font(.body.weight(.semibold))
            } else {
                VStack(spacing: 12) {
                    Image(systemName: "checkmark.circle.fill")
                        .font(.system(size: 72))
                        .foregroundStyle(Color.green)
                        .symbolEffect(.bounce, value: index)
                    Text(named > 0 ? "All named" : "All caught up").font(.title.weight(.bold))
                    Text(named > 0 ? "\(Words.cap(Words.number(named))) payee\(named == 1 ? "" : "s"), \(namedPayments) payment\(namedPayments == 1 ? "" : "s") named. New payments to them are named the same way." : "Nothing left to name.")
                        .multilineTextAlignment(.center)
                        .foregroundStyle(.secondary)
                    Button("Close") { dismiss() }
                        .buttonStyle(.glassProminent).koshFilled()
                        .controlSize(.large)
                        .padding(.top, 8)
                }
                .frame(maxHeight: .infinity)
                .transition(.scale(scale: 0.9).combined(with: .opacity))
            }
            Spacer(minLength: 0)
        }
        .padding(20)
        .onAppear { if queue.isEmpty { queue = store.weeklyToName } }
        .sensoryFeedback(.success, trigger: named)
        .sensoryFeedback(.impact(weight: .light), trigger: index)
    }
}

struct TagCard: View {
    @Environment(Store.self) private var store
    let g: PayeeGroup
    let suggestions: [Suggestion]
    let onPick: (Suggestion) -> Void
    let drag: CGSize

    var body: some View {
        let n: Int = g.rows.count
        let latest: Txn = g.rows[0]
        let way: String = PayWay.line(latest) ?? latest.card
        VStack(alignment: .leading, spacing: 10) {
            Text(n == 1 ? Day.short(latest.d) + " · " + way : "\(n) payments since \(Day.short(g.first)) · " + way)
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .lineLimit(1)
            Text(Fmt.rupees(g.total))
                .scaledFont(size: 46, weight: .bold, design: .rounded, relativeTo: .largeTitle)
                .minimumScaleFactor(0.6)
                .lineLimit(1)
                .privacySensitive()
            HStack(spacing: 8) {
                Image(systemName: g.person ? "person.fill" : "storefront.fill").font(.subheadline).foregroundStyle(.secondary)
                Text(g.name).font(.title3.weight(.semibold)).lineLimit(2)
            }
            if let v = g.vpa, !v.isEmpty {
                Text(v).font(.footnote.monospaced()).foregroundStyle(.secondary).lineLimit(1).privacySensitive()
            }
            if n > 1 {
                Text(g.rows.prefix(4).map { Fmt.rupees($0.a) }.joined(separator: " · ") + (n > 4 ? " …" : ""))
                    .font(.footnote).foregroundStyle(.secondary).lineLimit(1).privacySensitive()
            }
            VStack(spacing: 8) {
                ForEach(Array(suggestions.enumerated()), id: \.element.id) { i, s in
                    Button { onPick(s) } label: {
                        HStack(spacing: 10) {
                            IconTile(symbol: s.sym, color: store.catColor(s.c), size: 30)
                            Text(s.label).font(.body.weight(.semibold)).foregroundStyle(Color.primary)
                            Spacer()
                            Text(i == 0 ? "or swipe right" : s.c).font(.caption).foregroundStyle(.secondary)
                        }
                        .padding(.horizontal, 12)
                        .padding(.vertical, 10)
                        .background(Color.raised, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                    }
                    .buttonStyle(.press)
                }
            }
            .padding(.top, 4)
            Spacer(minLength: 0)
            Text(n == 1 ? "Payments like this name no shop. Pick what it was and kosh names the next ones to this payee too."
                 : "Naming it names all \(n) payments to \(g.person ? "them" : "this payee"), and the ones still to come.")
                .font(.footnote)
                .foregroundStyle(.secondary)
        }
        .padding(20)
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
        .background(Color.surface, in: RoundedRectangle(cornerRadius: 32, style: .continuous))
        .overlay(alignment: .topTrailing) {
            Text("Named")
                .font(.headline)
                .foregroundStyle(Color.green)
                .padding(.horizontal, 12).padding(.vertical, 6)
                .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.green, lineWidth: 2))
                .rotationEffect(.degrees(-8))
                .padding(20)
                .opacity(Double(max(0, min(1, drag.width / 90))))
        }
        .overlay(alignment: .topLeading) {
            Text("Later")
                .font(.headline)
                .foregroundStyle(.secondary)
                .padding(.horizontal, 12).padding(.vertical, 6)
                .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.secondary, lineWidth: 2))
                .rotationEffect(.degrees(8))
                .padding(20)
                .opacity(Double(max(0, min(1, -drag.width / 90))))
        }
        .shadow(color: .black.opacity(0.1), radius: 24, y: 12)
    }
}

// MARK: - Quick add

struct AddSheet: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    let preset: String?
    @State private var amount = ""
    @State private var pick: Suggestion?

    var value: Double { TypedAmount.cap(Double(amount) ?? 0) }
    let keys = ["1", "2", "3", "4", "5", "6", "7", "8", "9", ".", "0", "del"]

    var shownAmount: String {
        if amount.isEmpty { return "₹0" }
        let parts = amount.split(separator: ".", omittingEmptySubsequences: false)
        let whole = Fmt.inr(Double(parts.first ?? "0") ?? 0)
        return "₹" + whole + (parts.count > 1 ? "." + parts[1] : "")
    }

    func press(_ k: String) {
        if k == "del" { if !amount.isEmpty { amount.removeLast() }; return }
        if k == "." { if !amount.contains(".") { amount = (amount.isEmpty ? "0" : amount) + "." }; return }
        let next = (amount == "0" ? "" : amount) + k
        if let dot = next.firstIndex(of: "."), next[next.index(after: dot)...].count > 2 { return }
        if (Double(next) ?? 0) > 9_999_999 { return }
        amount = next
    }

    var body: some View {
        let suggestions = store.addSuggestions
        VStack(spacing: 14) {
            HStack {
                Text("Add a spend").font(.title2.weight(.bold))
                Spacer()
                Button { dismiss() } label: { Image(systemName: "xmark") }
                    .buttonStyle(.glass)
                    .buttonBorderShape(.circle)
                    .accessibilityLabel("Close")
            }
            Text(shownAmount)
                .font(.system(size: 64, weight: .bold, design: .rounded))
                .foregroundStyle(amount.isEmpty ? Color.secondary : Color.primary)
                .contentTransition(.numericText())
                .animation(Motion.quick, value: amount)
                .padding(.top, 6)
            Text(pick.map { "\($0.label)\($0.card.isEmpty ? "" : " · " + $0.card) · today" } ?? "Choose what it was")
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .lineLimit(1)
            ScrollView(.horizontal) {
                HStack(spacing: 8) {
                    ForEach(suggestions) { s in
                        let on = pick == s
                        Button {
                            withAnimation(Motion.base) { pick = s }
                        } label: {
                            HStack(spacing: 6) {
                                Image(systemName: s.sym)
                                Text(s.label).lineLimit(1)
                            }
                            .font(.subheadline.weight(.semibold))
                            .padding(.horizontal, 14).padding(.vertical, 9)
                            .foregroundStyle(on ? Color.onKosh : Color.primary)
                            .background(on ? Color.koshFill : Color.surface, in: Capsule())
                        }
                        .buttonStyle(.press)
                    }
                }
            }
            .scrollIndicators(.hidden)
            LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 10), count: 3), spacing: 10) {
                ForEach(keys, id: \.self) { k in
                    Button { press(k) } label: {
                        Group {
                            if k == "del" { Image(systemName: "delete.left") } else { Text(k) }
                        }
                        .font(.system(.title, design: .rounded, weight: .medium))
                        .foregroundStyle(Color.primary)
                        .frame(maxWidth: .infinity)
                        .frame(minHeight: 56)
                        .background(Color.surface, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                    }
                    .buttonStyle(.press)
                    .accessibilityLabel(k == "del" ? "Delete" : k)
                }
            }
            Button {
                guard let p = pick, value > 0 else { return }
                store.addSpend(amount: value, c: p.c, s: p.s, merchant: p.merchant.isEmpty ? p.label : p.merchant, card: p.card)
                dismiss()
            } label: {
                Text(value > 0 ? "Add \(Fmt.rupees(value))" : "Add")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 4)
            }
            .buttonStyle(.glassProminent).koshFilled()
            .controlSize(.large)
            .disabled(!(value > 0 && pick != nil))
        }
        .padding(20)
        .sensoryFeedback(.selection, trigger: amount)
        .onAppear {
            if preset == "fuel" { pick = suggestions.first { $0.label == "Fuel" } }
        }
    }
}

// MARK: - Counted twice?

struct DupsSheet: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            List {
                Section {
                    Text("Each pair is the same sum, the same day, told by two emails. If it was one payment, kosh keeps the bank's line and counts it once.")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .listRowBackground(Color.clear)
                }
                ForEach(store.snap.dups, id: \.key) { d in
                    if !store.dupsDone.contains(d.key) {
                        Section {
                            ForEach(d.ids, id: \.self) { tid in
                                if let t = store.txn(tid) { TxRow(t: t, when: Day.short(t.d)) }
                            }
                            HStack(spacing: 12) {
                                Button("They're two") { withAnimation(Motion.open) { store.resolveDup(d, merge: false) } }
                                    .buttonStyle(.glass)
                                Button("Same payment") { withAnimation(Motion.open) { store.resolveDup(d, merge: true) } }
                                    .buttonStyle(.glassProminent).koshFilled()
                            }
                            .frame(maxWidth: .infinity)
                            .controlSize(.regular)
                        }
                    }
                }
                if store.snap.dups.allSatisfy({ store.dupsDone.contains($0.key) }) {
                    ContentUnavailableView("All sorted", systemImage: "checkmark.circle", description: Text("Nothing is counted twice now."))
                        .listRowBackground(Color.clear)
                }
            }
            .navigationTitle("Counted twice?")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } }
            }
        }
    }
}

// MARK: - "All of them, or just this one?"

/// kosh's question after a payment is filed, in one place (TxSheet, ApplyAskOutside)
enum ApplyAskWords {
    static func title(_ a: ApplyAsk) -> String {
        let n: String = a.others == 1 ? "the other payment" : "the other \(a.others) payments"
        return a.field == "c" ? "File \(n) to \(a.payee) too?" : "Mark \(n) to \(a.payee) too?"
    }
    static func message(_ a: ApplyAsk) -> String {
        a.field == "c" ? "kosh can file every earlier and later payment to \(a.payee) as \(a.label). Nothing else changes unless you say so."
            : "kosh can mark every earlier and later payment to \(a.payee) as for \(a.label). Nothing else changes unless you say so."
    }
    static func all(_ a: ApplyAsk) -> String { "Yes, all \(a.others + 1) payments" }
}

/// the same question where no payment sheet is open (a category set from Find's results): a sheet open asks its own
struct ApplyAskOutside: ViewModifier {
    @Environment(Store.self) private var store
    @State private var asking: Bool = false
    func body(content: Content) -> some View {
        content
            .task(id: store.applyAsk?.id) {
                guard store.applyAsk != nil, store.sheet == nil else { return }
                try? await Task.sleep(for: .milliseconds(250))
                if store.applyAsk != nil && store.sheet == nil { asking = true }
            }
            .confirmationDialog(store.applyAsk.map(ApplyAskWords.title) ?? "", isPresented: $asking, titleVisibility: .visible, presenting: store.applyAsk) { a in
                Button(ApplyAskWords.all(a)) { store.applyToAll(a) }
                Button("Just this one", role: .cancel) { store.applyAsk = nil }
            } message: { a in
                Text(ApplyAskWords.message(a))
            }
            .onChange(of: asking) { _, on in if !on && store.sheet == nil { store.applyAsk = nil } }
    }
}

// MARK: - Undo, for a few seconds after a change

/// the last change ("Filed all 14 payments to Zomato as Food", "Left out of spending") and Undo, floating over the
/// bottom of the screen for six seconds
struct UndoBar: ViewModifier {
    @Environment(Store.self) private var store
    /// how far above the bottom edge it floats (clear of the tab bar on the main screens)
    var lift: CGFloat = 24
    func body(content: Content) -> some View {
        // (over Transactions' select bar when payments are ticked, not on top of it)
        let selecting: Bool = store.ledgerSelecting && store.sheet == nil && store.txSub == .all
        let rise: CGFloat = lift + (selecting ? 64 : 0)
        content.overlay(alignment: .bottom) {
            if let n = store.undoNote {
                HStack(spacing: 12) {
                    Image(systemName: "checkmark.circle.fill").foregroundStyle(Color.green)
                    Text(n.text).font(.subheadline.weight(.medium)).lineLimit(2)
                    Spacer(minLength: 8)
                    Button("Undo") {
                        n.undo()
                        withAnimation(Motion.base) { store.undoNote = nil }
                    }
                    .font(.subheadline.weight(.bold))
                    .foregroundStyle(Color.kosh)
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 12)
                .glassEffect(.regular, in: .capsule)
                .padding(.horizontal, 16)
                .padding(.bottom, rise)
                .transition(.move(edge: .bottom).combined(with: .opacity))
                .task(id: n.id) {
                    try? await Task.sleep(for: .seconds(6))
                    if store.undoNote?.id == n.id { withAnimation(Motion.base) { store.undoNote = nil } }
                }
            }
        }
        .animation(Motion.base, value: store.undoNote?.id)
    }
}

// MARK: - Swiping a payment's row

/// swipe right to file it; swipe left to count it or leave it out (with Undo), or to put it in a chapter
struct TxSwipes: ViewModifier {
    @Environment(Store.self) private var store
    let t: Txn
    func body(content: Content) -> some View {
        if store.live == nil {
            content
        } else {
            let out: Bool = t.k == "out" || t.k == "prepaid" || t.dr == "out"
            let counted: Bool = t.ex == nil && (t.nc ?? "").isEmpty
            content
                .swipeActions(edge: .leading, allowsFullSwipe: true) {
                    Button { store.openTx(t.id, at: "cats") } label: { Label("Category", systemImage: "tag.fill") }
                        .tint(Color.kosh)
                }
                .swipeActions(edge: .trailing, allowsFullSwipe: false) {
                    if !out && t.k == "in" && t.refOf == nil {
                        Button { store.swipeCountIn(t, !counted) } label: {
                            Label(counted ? "Don’t count" : "Count", systemImage: counted ? "eye.slash" : "eye")
                        }
                        .tint(counted ? Color.gray : Color.green)
                    }
                    if out && t.refOf == nil {
                        Button { store.swipeCount(t, !counted) } label: {
                            Label(counted ? "Don’t count" : "Count", systemImage: counted ? "eye.slash" : "eye")
                        }
                        .tint(counted ? Color.gray : Color.green)
                    }
                    if out && t.partOf == nil {
                        Button { store.openTx(t.id, at: "trip") } label: { Label("Chapter", systemImage: "book.pages.fill") }
                            .tint(Color.purple)
                    }
                }
        }
    }
}
