import Foundation
import Network

// MARK: - Inboxes that aren't Gmail
//
// Outlook, Hotmail, Live and Microsoft 365 through Microsoft's sign-in and Graph; Yahoo, iCloud, AOL, Zoho and any
// other mail server through IMAP with an app password. Both only read: Graph with Mail.Read, IMAP with EXAMINE (the
// folder opened read-only) and BODY.PEEK (nothing is marked read). What they bring back is turned into the same
// MailMsg the Gmail reader makes (mailwire.js), so the rules read it the same way.

/// how one inbox is reached
struct MailConfig: Hashable {
    /// "gmail", "microsoft" or "imap"
    var provider: String
    var host: String = ""
    var port: Int = 993
    var login: String = ""
    var isGmail: Bool { provider == "gmail" }
}

/// a mail provider kosh knows how to connect, from mailwire.js (one list for the app and the engine)
struct MailProviderInfo: Decodable, Identifiable, Hashable {
    let id: String
    let name: String
    let sub: String
    let kind: String
    let color: String
    let domains: [String]
    var passwordURL: String? = nil
    var password: String? = nil
    var steps: [String]? = nil

    static let all: [MailProviderInfo] = {
        guard let s = try? Engine.shared.call("providersJSON", []),
              let list = try? JSONText.decode([MailProviderInfo].self, s) else { return [] }
        return list
    }()
    static func of(_ id: String) -> MailProviderInfo? { all.first { $0.id == id } }
}

enum MailError: LocalizedError {
    case closed, timeout, refused(String), login(String), noServer(String), tooBig
    var errorDescription: String? {
        switch self {
        case .closed: return "The mail server closed the connection."
        case .timeout: return "The mail server took too long to answer."
        case .refused(let s): return "The mail server said no: \(s)"
        case .login(let s): return s
        case .noServer(let s): return s
        case .tooBig: return "That email is too big to read on the phone."
        }
    }
}

/// runs `f`, and calls `onTimeout` (which should end whatever `f` waits on) if it isn't done in `seconds`
func withDeadline<T>(_ seconds: Double, onTimeout: @escaping @Sendable () -> Void, _ f: () async throws -> T) async throws -> T {
    let timer = Task { try await Task.sleep(for: .seconds(seconds)); onTimeout() }
    defer { timer.cancel() }
    return try await f()
}

/// a callback that may fire more than once, resumed once
final class Once: @unchecked Sendable {
    private var done = false
    private let lock = NSLock()
    func run(_ f: () -> Void) {
        lock.lock()
        if done { lock.unlock(); return }
        done = true
        lock.unlock()
        f()
    }
}

// MARK: IMAP: one connection, one command at a time

actor IMAPConnection {
    private let conn: NWConnection
    private var buf = Data()
    private var n = 0
    /// the folder open now (read-only) and its UIDVALIDITY
    private(set) var selected: String? = nil
    private(set) var validity: String = "0"
    private(set) var broken = false

    init(host: String, port: Int) {
        let params = NWParameters(tls: NWProtocolTLS.Options(), tcp: NWProtocolTCP.Options())
        conn = NWConnection(host: NWEndpoint.Host(host), port: NWEndpoint.Port(integerLiteral: UInt16(clamping: port)), using: params)
    }

    nonisolated func cancel() { conn.cancel() }

    func open() async throws {
        try await withCheckedThrowingContinuation { (c: CheckedContinuation<Void, Error>) in
            let once = Once()
            conn.stateUpdateHandler = { state in
                switch state {
                case .ready: once.run { c.resume() }
                case .failed(let e): once.run { c.resume(throwing: e) }
                case .waiting(let e): once.run { c.resume(throwing: e) }
                case .cancelled: once.run { c.resume(throwing: MailError.closed) }
                default: break
                }
            }
            conn.start(queue: .global(qos: .utility))
        }
        let greeting = String(decoding: try await line(), as: UTF8.self)
        guard greeting.hasPrefix("* OK") || greeting.hasPrefix("* PREAUTH") else { broken = true; throw MailError.refused(greeting.trimmingCharacters(in: .whitespacesAndNewlines)) }
    }

    private func receive() async throws -> Data {
        try await withCheckedThrowingContinuation { (c: CheckedContinuation<Data, Error>) in
            conn.receive(minimumIncompleteLength: 1, maximumLength: 1 << 16) { data, _, done, error in
                if let error { c.resume(throwing: error); return }
                if let data, !data.isEmpty { c.resume(returning: data); return }
                if done { c.resume(throwing: MailError.closed); return }
                c.resume(returning: Data())
            }
        }
    }

    private static let crlf = Data([13, 10])

    /// one line, CRLF and all
    private func line() async throws -> Data {
        while true {
            if let r = buf.range(of: Self.crlf) {
                let out = buf.subdata(in: buf.startIndex..<r.upperBound)
                buf = buf.subdata(in: r.upperBound..<buf.endIndex)
                return out
            }
            let more = try await receive()
            if more.isEmpty { continue }
            buf.append(more)
            if buf.count > 40_000_000 { broken = true; throw MailError.tooBig }
        }
    }

    /// exactly `count` bytes (a literal)
    private func bytes(_ count: Int) async throws -> Data {
        guard count <= 40_000_000 else { broken = true; throw MailError.tooBig }
        while buf.count < count {
            let more = try await receive()
            buf.append(more)
        }
        let out = buf.subdata(in: buf.startIndex..<(buf.startIndex + count))
        buf = buf.subdata(in: (buf.startIndex + count)..<buf.endIndex)
        return out
    }

    /// "{1234}\r\n" at the end of a line: the size of the literal that follows
    private static func literal(_ l: Data) -> Int? {
        guard l.count >= 4, l[l.endIndex - 3] == UInt8(ascii: "}") else { return nil }
        guard let open = l.lastIndex(of: UInt8(ascii: "{")) else { return nil }
        let digits = String(decoding: l[(open + 1)..<(l.endIndex - 3)], as: UTF8.self).replacingOccurrences(of: "+", with: "")
        return Int(digits)
    }

    private func send(_ s: String) async throws {
        try await withCheckedThrowingContinuation { (c: CheckedContinuation<Void, Error>) in
            conn.send(content: Data(s.utf8), completion: .contentProcessed { e in
                if let e { c.resume(throwing: e) } else { c.resume() }
            })
        }
    }

    /// one command and its whole response, literals and all, up to the tagged OK; a NO or BAD throws
    func command(_ cmd: String) async throws -> Data {
        if broken { throw MailError.closed }
        n += 1
        let tag = "K\(n)"
        let tagged = Data((tag + " ").utf8)
        do {
            try await send(tag + " " + cmd + "\r\n")
            var out = Data()
            var lineStart = true
            while true {
                let l = try await line()
                out.append(l)
                if lineStart && l.starts(with: tagged) {
                    let rest = String(decoding: l.dropFirst(tagged.count), as: UTF8.self).trimmingCharacters(in: .whitespacesAndNewlines)
                    if rest.uppercased().hasPrefix("OK") { return out }
                    throw MailError.refused(rest)
                }
                if let k = Self.literal(l) {
                    out.append(try await bytes(k))
                    lineStart = false
                } else {
                    lineStart = true
                }
            }
        } catch let e as MailError {
            if case .refused = e {} else { broken = true }
            throw e
        } catch {
            broken = true
            throw error
        }
    }

    /// signs in: LOGIN with quoted strings, or AUTHENTICATE PLAIN when the password isn't plain ASCII
    func login(_ user: String, _ password: String) async throws {
        let plain = { (s: String) in s.unicodeScalars.allSatisfy { $0.value >= 32 && $0.value < 127 } }
        if plain(user) && plain(password) {
            _ = try await command("LOGIN " + IMAPMail.quote(user) + " " + IMAPMail.quote(password))
        } else {
            let token = Data(("\u{0}" + user + "\u{0}" + password).utf8).base64EncodedString()
            _ = try await command("AUTHENTICATE PLAIN " + token)
        }
    }

    /// opens a folder read-only (EXAMINE), unless it's open already; its UIDVALIDITY
    @discardableResult
    func examine(_ folder: String) async throws -> String {
        if selected == folder { return validity }
        let r = try await command("EXAMINE " + IMAPMail.quote(folder))
        selected = folder
        validity = (try? Engine.shared.call("imapUIDValidity", [IMAPMail.latin1(r)])) ?? "0"
        return validity
    }

    func logout() async {
        _ = try? await withDeadline(5, onTimeout: { [conn] in conn.cancel() }) { try await command("LOGOUT") }
        conn.cancel()
    }
}

/// one IMAP inbox: where it is and how to sign in
struct IMAPAccount: Hashable, Sendable {
    let host: String
    let port: Int
    let login: String
    let password: String
}

/// an IMAP message id taken apart ("<uidvalidity>.<uid>@<folder>"), and a page of listed headers
private struct IMAPRef: Decodable { let validity: String; let uid: Int; let folder: String }
private struct IMAPWanted: Decodable { let ids: [String]; let seen: Int }
private struct GraphPage: Decodable { let ids: [String]; let seen: Int; let next: String }

enum IMAPMail {
    static func quote(_ s: String) -> String {
        "\"" + s.replacingOccurrences(of: "\\", with: "\\\\").replacingOccurrences(of: "\"", with: "\\\"") + "\""
    }
    /// bytes → a string of one character per byte, which is how mailwire.js reads IMAP
    static func latin1(_ d: Data) -> String { String(data: d, encoding: .isoLatin1) ?? "" }

    /// connected and signed in, or why not
    static func connect(_ a: IMAPAccount) async throws -> IMAPConnection {
        let c = IMAPConnection(host: a.host, port: a.port)
        do {
            try await withDeadline(20, onTimeout: { c.cancel() }) { try await c.open() }
        } catch {
            c.cancel()
            throw MailError.noServer("Couldn’t reach \(a.host). Check the address, or that the phone is online.")
        }
        do {
            try await withDeadline(30, onTimeout: { c.cancel() }) { try await c.login(a.login, a.password) }
        } catch MailError.refused(let why) {
            c.cancel()
            throw MailError.login(why.isEmpty ? "The mail server didn’t accept that password." : "The mail server didn’t accept that password (\(why)).")
        } catch {
            c.cancel()
            throw error
        }
        return c
    }

    /// signs in and lists the folders: proof that kosh can read this inbox
    static func verify(_ a: IMAPAccount) async throws -> [String] {
        let c = try await connect(a)
        defer { Task { await c.logout() } }
        let r = try await withDeadline(30, onTimeout: { c.cancel() }) { try await c.command("LIST \"\" \"*\"") }
        let folders = (try? JSONText.decode([String].self, try Engine.shared.call("imapFoldersJSON", [latin1(r)]))) ?? []
        guard !folders.isEmpty else { throw MailError.noServer("Signed in, but no folders came back.") }
        return folders
    }

    /// Every email in the window worth reading, across the inbox's folders (never Sent, Spam or Trash): senders and
    /// subjects first, a few hundred at a time, then only the money mail is fetched in full later.
    static func list(_ a: IMAPAccount, after: String, before: String?, counting: (@MainActor (Int) -> Void)? = nil) async throws -> [String] {
        let c = try await connect(a)
        defer { Task { await c.logout() } }
        let lr = try await withDeadline(30, onTimeout: { c.cancel() }) { try await c.command("LIST \"\" \"*\"") }
        let folders = (try? JSONText.decode([String].self, try Engine.shared.call("imapFoldersJSON", [latin1(lr)]))) ?? ["INBOX"]
        let search = try Engine.shared.call("imapSearchCommand", [after, before ?? ""])
        var ids: [String] = []
        for f in folders {
            let validity: String
            do { validity = try await withDeadline(30, onTimeout: { c.cancel() }) { try await c.examine(f) } }
            catch MailError.refused { continue }   // a folder that can't be opened is skipped
            let sr = try await withDeadline(60, onTimeout: { c.cancel() }) { try await c.command(search) }
            let uids = (try? JSONText.decode([Int].self, try Engine.shared.call("imapSearchJSON", [latin1(sr)]))) ?? []
            var at = 0
            while at < uids.count {
                let batch = uids[at..<min(at + 250, uids.count)]
                at += batch.count
                let set = batch.map(String.init).joined(separator: ",")
                let hr = try await withDeadline(90, onTimeout: { c.cancel() }) {
                    try await c.command("UID FETCH " + set + " (UID INTERNALDATE BODY.PEEK[HEADER.FIELDS (FROM SUBJECT DATE)])")
                }
                if let w = try? JSONText.decode(IMAPWanted.self, try Engine.shared.call("imapWantedJSON", [latin1(hr), validity, f])) {
                    ids.append(contentsOf: w.ids)
                    if let counting, !w.ids.isEmpty { let k = w.ids.count; await counting(k) }
                }
            }
        }
        return ids
    }

    /// The emails asked for, fetched whole and read into MailMsgs; one whose folder was rebuilt since it was listed
    /// (its UIDVALIDITY changed) is left out.
    static func fetch(_ a: IMAPAccount, ids: [String]) async throws -> [MailMsg] {
        var byFolder: [String: [IMAPRef]] = [:]
        var order: [String] = []
        for id in ids {
            guard let r = try? JSONText.decode(IMAPRef.self, try Engine.shared.call("imapRefJSON", [id])) else { continue }
            if byFolder[r.folder] == nil { order.append(r.folder) }
            byFolder[r.folder, default: []].append(r)
        }
        guard !order.isEmpty else { return [] }
        let c = try await connect(a)
        defer { Task { await c.logout() } }
        var out: [MailMsg] = []
        for f in order {
            let validity = try await withDeadline(30, onTimeout: { c.cancel() }) { try await c.examine(f) }
            let refs = (byFolder[f] ?? []).filter { $0.validity == validity }
            var at = 0
            while at < refs.count {
                let batch = refs[at..<min(at + 5, refs.count)]
                at += batch.count
                let set = batch.map { String($0.uid) }.joined(separator: ",")
                let r = try await withDeadline(120, onTimeout: { c.cancel() }) { try await c.command("UID FETCH " + set + " (UID INTERNALDATE BODY.PEEK[])") }
                if let msgs = try? JSONText.decode([MailMsg].self, try Engine.shared.call("imapMessagesJSON", [latin1(r), validity, f])) {
                    out.append(contentsOf: msgs)
                }
            }
        }
        return out
    }

    /// one attachment's bytes (a statement), by its message id and its part
    static func attachment(_ a: IMAPAccount, id: String, part: String) async throws -> Data {
        guard let r = try? JSONText.decode(IMAPRef.self, try Engine.shared.call("imapRefJSON", [id])) else { throw MailError.closed }
        let c = try await connect(a)
        defer { Task { await c.logout() } }
        _ = try await withDeadline(30, onTimeout: { c.cancel() }) { try await c.examine(r.folder) }
        let resp = try await withDeadline(120, onTimeout: { c.cancel() }) { try await c.command("UID FETCH \(r.uid) (UID BODY.PEEK[])") }
        let bin = try Engine.shared.call("imapPart", [latin1(resp), part])
        guard !bin.isEmpty, let d = bin.data(using: .isoLatin1) else { throw MailError.closed }
        return d
    }
}

// MARK: Microsoft: sign-in (OAuth with PKCE) and Graph, read-only

struct MicrosoftTokens { var access: String; var expires: Date; var refresh: String?; var email: String; var name: String }

enum MicrosoftOAuth {
    static let scopes = "offline_access openid email profile User.Read Mail.Read"
    static let scheme = "koshms"
    static let redirect = "koshms://auth"
    static let base = "https://login.microsoftonline.com/common/oauth2/v2.0/"

    static func authURL(clientID: String, challenge: String, state: String, hint: String?) -> URL {
        var c = URLComponents(string: base + "authorize")!
        var q: [URLQueryItem] = [
            URLQueryItem(name: "client_id", value: clientID),
            URLQueryItem(name: "response_type", value: "code"),
            URLQueryItem(name: "redirect_uri", value: redirect),
            URLQueryItem(name: "response_mode", value: "query"),
            URLQueryItem(name: "scope", value: scopes),
            URLQueryItem(name: "code_challenge", value: challenge),
            URLQueryItem(name: "code_challenge_method", value: "S256"),
            URLQueryItem(name: "state", value: state),
            URLQueryItem(name: "prompt", value: "select_account"),
        ]
        if let hint, !hint.isEmpty { q.append(URLQueryItem(name: "login_hint", value: hint)) }
        c.queryItems = q
        return c.url!
    }

    static func token(_ items: [String: String]) async throws -> [String: Any] {
        var req = URLRequest(url: URL(string: base + "token")!)
        req.httpMethod = "POST"
        req.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        req.httpBody = GoogleOAuth.form(items)
        let (data, resp) = try await URLSession.shared.data(for: req)
        let code = (resp as? HTTPURLResponse)?.statusCode ?? 0
        let json = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] ?? [:]
        guard code == 200 else {
            let why = (json["error_description"] as? String)?.components(separatedBy: "\r\n").first ?? (json["error"] as? String) ?? ""
            if code >= 500 { throw LiveError.busy(3) }
            throw LiveError.signIn("Microsoft said no (\(code)): \(why)")
        }
        return json
    }

    /// the redirect Microsoft sends back → tokens and who signed in
    static func finish(callback: URL, clientID: String, verifier: String, state: String) async throws -> MicrosoftTokens {
        let items = URLComponents(url: callback, resolvingAgainstBaseURL: false)?.queryItems ?? []
        func item(_ n: String) -> String? { items.first { $0.name == n }?.value }
        if let e = item("error") {
            throw LiveError.signIn(e == "access_denied" ? "Sign-in was cancelled." : "Microsoft said: \(item("error_description") ?? e)")
        }
        guard item("state") == state, let code = item("code") else { throw LiveError.signIn("Sign-in didn’t come back as expected. Try again.") }
        let j = try await token(["client_id": clientID, "grant_type": "authorization_code", "code": code, "redirect_uri": redirect,
                                 "code_verifier": verifier, "scope": scopes])
        let c = GoogleOAuth.claims(j["id_token"] as? String)
        let email = ((c["email"] as? String) ?? (c["preferred_username"] as? String) ?? "").lowercased()
        return MicrosoftTokens(access: j["access_token"] as? String ?? "", expires: Date().addingTimeInterval((j["expires_in"] as? Double) ?? 3000),
                               refresh: j["refresh_token"] as? String, email: email, name: c["name"] as? String ?? "")
    }

    /// a fresh access token; Microsoft hands back a new refresh token each time, which replaces the old one
    static func refresh(_ refresh: String, clientID: String) async throws -> (String, Date, String?) {
        let j = try await token(["client_id": clientID, "grant_type": "refresh_token", "refresh_token": refresh, "scope": scopes])
        return (j["access_token"] as? String ?? "", Date().addingTimeInterval((j["expires_in"] as? Double) ?? 3000), j["refresh_token"] as? String)
    }
}

enum Graph {
    static let base = "https://graph.microsoft.com/v1.0/me/"

    static func get(_ url: URL, token: String) async throws -> Data {
        var req = URLRequest(url: url)
        req.setValue("Bearer " + token, forHTTPHeaderField: "Authorization")
        // ids that stay the same when a message is moved between folders
        req.setValue("IdType=\"ImmutableId\"", forHTTPHeaderField: "Prefer")
        req.timeoutInterval = 30
        let (data, resp) = try await URLSession.shared.data(for: req)
        let http = resp as? HTTPURLResponse
        let code = http?.statusCode ?? 0
        if code == 429 || code == 503 || code >= 500 {
            throw LiveError.busy(Double(http?.value(forHTTPHeaderField: "Retry-After") ?? "") ?? 3)
        }
        guard code == 200 else { throw LiveError.http(code, String(data: data.prefix(300), encoding: .utf8) ?? "") }
        return data
    }
    static func url(_ path: String) -> URL { URL(string: path.hasPrefix("https://") ? path : base + path)! }
    static func enc(_ s: String) -> String {
        var allowed = CharacterSet.alphanumerics
        allowed.insert(charactersIn: "-._~")
        return s.addingPercentEncoding(withAllowedCharacters: allowed) ?? s
    }

    /// the folders kosh never reads: Sent, Deleted, Junk, Drafts, Outbox
    static func skipFolders(token: String) async -> [String] {
        var out: [String] = []
        for f in ["sentitems", "deleteditems", "junkemail", "drafts", "outbox"] {
            if let d = try? await get(url("mailFolders/" + f + "?$select=id"), token: token),
               let j = try? JSONSerialization.jsonObject(with: d) as? [String: Any], let id = j["id"] as? String { out.append(id) }
        }
        return out
    }

    /// every email in the window worth reading: senders and subjects listed, a page at a time
    static func list(after: String, before: String?, token: @escaping () async throws -> String, counting: (@MainActor (Int) -> Void)? = nil) async throws -> [String] {
        let first = try await token()
        let skip = await skipFolders(token: first)
        let skipJSON = JSONText.object(skip)
        let filter = try Engine.shared.call("graphFilter", [after, before ?? ""])
        var next: String? = "messages?$filter=" + enc(filter) + "&$select=id,subject,from,sender,parentFolderId&$top=500"
        var ids: [String] = []
        while let n = next {
            let tok = try await token()
            let d = try await LiveSession.retrying { try await get(url(n), token: tok) }
            let p = try JSONText.decode(GraphPage.self, try Engine.shared.call("graphPageJSON", [String(decoding: d, as: UTF8.self), skipJSON]))
            ids.append(contentsOf: p.ids)
            if let counting, !p.ids.isEmpty { let k = p.ids.count; await counting(k) }
            next = p.next.isEmpty ? nil : p.next
        }
        return ids
    }

    static func message(_ id: String, token: String) async throws -> MailMsg {
        let d = try await get(url("messages/" + enc(id) + "?$select=id,subject,from,sender,receivedDateTime,body,hasAttachments"), token: token)
        let j = (try? JSONSerialization.jsonObject(with: d)) as? [String: Any] ?? [:]
        var atts = ""
        if (j["hasAttachments"] as? Bool) == true {
            let listed: Data? = try? await get(url("messages/" + enc(id) + "/attachments?$select=id,name,contentType,size,isInline"), token: token)
            if let listed { atts = String(decoding: listed, as: UTF8.self) }
        }
        return try JSONText.decode(MailMsg.self, try Engine.shared.call("graphMessageJSON", [String(decoding: d, as: UTF8.self), atts]))
    }

    static func attachment(message: String, attachment: String, token: String) async throws -> Data {
        try await get(url("messages/" + enc(message) + "/attachments/" + enc(attachment) + "/$value"), token: token)
    }
}
