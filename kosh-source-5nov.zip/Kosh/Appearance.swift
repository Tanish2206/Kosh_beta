import SwiftUI
import UIKit
import WidgetKit

// MARK: - Appearance: light or dark, the accent, the net worth line
//
// Look holds what Settings › Appearance picked. Color.kosh, .koshFill, .onKosh and .sky (Style.swift) read its
// accent, so every view that draws in them redraws when it changes; LookApplied (on the root, KoshApp.swift)
// sets the tint and puts each window in light, dark, or whatever the phone is.

@Observable
final class Look {
    static let shared: Look = Look()

    private(set) var scheme: KoshScheme
    private(set) var accent: KoshAccent
    private(set) var line: KoshLine
    /// the net worth line's colours flow; off, it sits still (it always does with Reduce Motion)
    private(set) var shimmer: Bool

    init() {
        let d: UserDefaults = KoshLook.defaults
        // kosh was always light: it stays light until someone picks otherwise
        scheme = KoshScheme(rawValue: d.string(forKey: KoshLook.schemeKey) ?? "") ?? .light
        accent = KoshAccent(rawValue: d.string(forKey: KoshLook.accentKey) ?? "") ?? .kosh
        line = KoshLine(rawValue: d.string(forKey: KoshLook.lineKey) ?? "") ?? .accent
        shimmer = d.object(forKey: KoshLook.shimmerKey) as? Bool ?? true
    }

    func pick(scheme s: KoshScheme) {
        guard s != scheme else { return }
        scheme = s
        KoshLook.defaults.set(s.rawValue, forKey: KoshLook.schemeKey)
    }
    func pick(accent a: KoshAccent) {
        guard a != accent else { return }
        accent = a
        KoshLook.defaults.set(a.rawValue, forKey: KoshLook.accentKey)
        // the widgets draw in the accent too
        WidgetCenter.shared.reloadAllTimelines()
    }
    func pick(line l: KoshLine) {
        guard l != line else { return }
        line = l
        KoshLook.defaults.set(l.rawValue, forKey: KoshLook.lineKey)
    }
    func pick(shimmer on: Bool) {
        guard on != shimmer else { return }
        shimmer = on
        KoshLook.defaults.set(on, forKey: KoshLook.shimmerKey)
    }

    /// every window kosh has (sheets included) in the look picked (.unspecified follows the phone), and UIKit's
    /// own controls (alerts, menus) in the accent
    @MainActor
    static func applyStyle(_ s: KoshScheme) {
        let style: UIUserInterfaceStyle = s.style
        let tint: UIColor = UIColor(Look.shared.accent.ink)
        for scene in UIApplication.shared.connectedScenes {
            guard let ws = scene as? UIWindowScene else { continue }
            for w in ws.windows {
                if w.overrideUserInterfaceStyle != style { w.overrideUserInterfaceStyle = style }
                w.tintColor = tint
            }
        }
    }
}

/// on the root: the accent as the tint, and the windows in the look picked
struct LookApplied: ViewModifier {
    func body(content: Content) -> some View {
        let look: Look = Look.shared
        content
            .tint(look.accent.ink)
            .onAppear {
                Look.applyStyle(look.scheme)
                // once more when the window is surely there
                DispatchQueue.main.async { Look.applyStyle(Look.shared.scheme) }
            }
            .onChange(of: look.scheme) { _, s in Look.applyStyle(s) }
            .onChange(of: look.accent) { _, _ in Look.applyStyle(Look.shared.scheme) }
    }
}

extension View {
    /// a filled kosh button (prominent, glass prominent): the accent's fill (kosh blue stays #3B5BFD by night, for 4.5:1
    /// under white). Only Graphite needs its words set: black on its light grey by night. The others keep the
    /// button's own white, dimmed as usual when it's disabled.
    @ViewBuilder func koshFilled() -> some View {
        if Look.shared.accent == .graphite {
            self.tint(Color.koshFill).foregroundStyle(Color.onKosh)
        } else {
            self.tint(Color.koshFill)
        }
    }
}

// MARK: - The net worth line, carrying light

/// A line whose colours flow toward today on a six-second loop, over a soft glow and a wash that fades out;
/// today's point pulses. Still (the gradient where it starts, no pulse) with Reduce Motion or the shimmer off.
struct FlowLine: View {
    /// off while its tab is behind another (kosh keeps visited tabs alive): its animation rests
    @Environment(\.tabActive) private var tabActive
    /// the line's points in this view's own space, left to right
    let pts: [CGPoint]
    /// where the wash under the line fades out
    let base: CGFloat
    /// nil: the line picked in Settings
    var line: KoshLine? = nil
    var lineWidth: CGFloat = 2.8
    var glowWidth: CGFloat = 8
    var blur: CGFloat = 4.2
    /// today's point, at the last point
    var dot: Bool = true
    var dotRadius: CGFloat = 5
    /// the ring round today's point: the colour of what the line sits on
    var ring: Color = Color.surface
    /// false: still, whatever Settings says (a preview not picked)
    var flows: Bool = true

    @Environment(\.colorScheme) private var scheme
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    /// room round the drawing for the glow and the pulse
    static let margin: CGFloat = 22
    static let loopSeconds: Double = 6
    static let pulseSeconds: Double = 2.4

    var body: some View {
        let look: Look = Look.shared
        let kind: KoshLine = line ?? look.line
        let paint: KoshLine.Paint = kind.paint(dark: scheme == .dark, accent: look.accent)
        let moving: Bool = flows && look.shimmer && !reduceMotion
        let curve: Path = Self.curve(pts)
        let area: Path = Self.area(curve, pts: pts, base: base)
        let top: CGFloat = pts.map(\.y).min() ?? 0
        let end: CGPoint? = dot ? pts.last : nil
        let gradient: Gradient = Gradient(stops: paint.stops)
        let dotColor: Color = paint.dotColor
        let ringColor: Color = ring
        let lw: CGFloat = lineWidth
        let gw: CGFloat = glowWidth
        let br: CGFloat = blur
        let dr: CGFloat = dotRadius
        let baseY: CGFloat = base
        TimelineView(.animation(minimumInterval: 1.0 / 30.0, paused: !moving || !tabActive)) { tl in
            let now: Double = moving ? tl.date.timeIntervalSinceReferenceDate : 0
            Canvas { ctx, size in
                let m: CGFloat = Self.margin
                ctx.translateBy(x: m, y: m)
                let w: CGFloat = max(1, size.width - 2 * m)
                // one loop of the colours is a little wider than the line; the gradient is two loops wide and
                // slides one loop toward today every six seconds, so it never shows a seam
                let loop: CGFloat = w * 1.3
                let phase: CGFloat = CGFloat(now.truncatingRemainder(dividingBy: Self.loopSeconds) / Self.loopSeconds)
                let shift: CGFloat = phase * loop
                let shading: GraphicsContext.Shading = .linearGradient(gradient, startPoint: CGPoint(x: -loop + shift, y: 0),
                                                                       endPoint: CGPoint(x: loop + shift, y: 0))
                // the wash under the line, fading to nothing at the base
                if pts.count > 1 {
                    var wash: GraphicsContext = ctx
                    wash.opacity = paint.area
                    wash.drawLayer { l in
                        l.fill(area, with: shading)
                        l.blendMode = .destinationIn
                        let fade: Gradient = Gradient(colors: [Color.black, Color.black.opacity(0)])
                        l.fill(Path(CGRect(x: -m, y: -m, width: size.width, height: size.height)),
                               with: .linearGradient(fade, startPoint: CGPoint(x: 0, y: top), endPoint: CGPoint(x: 0, y: max(top + 1, baseY))))
                    }
                }
                // a soft glow, then the line itself
                var glow: GraphicsContext = ctx
                glow.opacity = paint.glow
                glow.addFilter(.blur(radius: br))
                glow.stroke(curve, with: shading, style: StrokeStyle(lineWidth: gw, lineCap: .round, lineJoin: .round))
                ctx.stroke(curve, with: shading, style: StrokeStyle(lineWidth: lw, lineCap: .round, lineJoin: .round))
                // today's point: a halo, a ping going out from it, and the dot ringed in the card's colour
                if let e = end {
                    func disc(_ r: CGFloat) -> Path { Path(ellipseIn: CGRect(x: e.x - r, y: e.y - r, width: r * 2, height: r * 2)) }
                    ctx.fill(disc(dr * 1.8), with: .color(dotColor.opacity(0.16)))
                    if moving {
                        let k: Double = now.truncatingRemainder(dividingBy: Self.pulseSeconds) / Self.pulseSeconds
                        let eased: Double = 1 - pow(1 - k, 3)
                        let alpha: Double = 0.5 * max(0, 1 - k / 0.75)
                        if alpha > 0 { ctx.fill(disc(dr * CGFloat(1 + 2.2 * eased)), with: .color(dotColor.opacity(alpha))) }
                    }
                    ctx.fill(disc(dr + 1.25), with: .color(ringColor))
                    ctx.fill(disc(dr - 1.25), with: .color(dotColor))
                }
            }
            .padding(-Self.margin)
        }
        .allowsHitTesting(false)
        .accessibilityHidden(true)
    }

    /// a smooth line through the points that never overshoots them (monotone, the way the chart draws its lines)
    static func curve(_ p: [CGPoint]) -> Path {
        var path: Path = Path()
        guard let first = p.first else { return path }
        path.move(to: first)
        let n: Int = p.count
        if n == 1 { return path }
        if n == 2 { path.addLine(to: p[1]); return path }
        var d: [CGFloat] = Array(repeating: 0, count: n - 1)
        for i in 0..<(n - 1) {
            let dx: CGFloat = p[i + 1].x - p[i].x
            d[i] = dx == 0 ? 0 : (p[i + 1].y - p[i].y) / dx
        }
        var t: [CGFloat] = Array(repeating: 0, count: n)
        t[0] = d[0]
        t[n - 1] = d[n - 2]
        for i in 1..<(n - 1) {
            if d[i - 1] * d[i] <= 0 {
                t[i] = 0
            } else {
                let h0: CGFloat = p[i].x - p[i - 1].x
                let h1: CGFloat = p[i + 1].x - p[i].x
                let w1: CGFloat = 2 * h1 + h0
                let w2: CGFloat = h1 + 2 * h0
                t[i] = (w1 + w2) / (w1 / d[i - 1] + w2 / d[i])
            }
        }
        for i in 0..<(n - 1) {
            let h: CGFloat = p[i + 1].x - p[i].x
            let c1: CGPoint = CGPoint(x: p[i].x + h / 3, y: p[i].y + t[i] * h / 3)
            let c2: CGPoint = CGPoint(x: p[i + 1].x - h / 3, y: p[i + 1].y - t[i + 1] * h / 3)
            path.addCurve(to: p[i + 1], control1: c1, control2: c2)
        }
        return path
    }

    /// the line closed down to the base, for the wash under it
    static func area(_ curve: Path, pts: [CGPoint], base: CGFloat) -> Path {
        guard let first = pts.first, let last = pts.last else { return Path() }
        var a: Path = curve
        a.addLine(to: CGPoint(x: last.x, y: base))
        a.addLine(to: CGPoint(x: first.x, y: base))
        a.closeSubpath()
        return a
    }

    /// a year that went well, for the previews: fractions down from the top, left to right
    static let sample: [CGFloat] = [0.86, 0.83, 0.76, 0.79, 0.66, 0.71, 0.62, 0.52, 0.55, 0.45, 0.36, 0.40, 0.28, 0.16]
    static func samplePoints(in size: CGSize, inset: CGFloat = 4) -> [CGPoint] {
        let n: Int = sample.count
        let w: CGFloat = max(1, size.width - inset * 2 - 8)
        let h: CGFloat = max(1, size.height - inset * 2)
        var out: [CGPoint] = []
        for (i, f) in sample.enumerated() {
            out.append(CGPoint(x: inset + w * CGFloat(i) / CGFloat(n - 1), y: inset + h * f))
        }
        return out
    }
}

/// the sample line, filling whatever room it's given
struct FlowLinePreview: View {
    var line: KoshLine? = nil
    var lineWidth: CGFloat = 2.8
    var blur: CGFloat = 3.4
    var dotRadius: CGFloat = 5
    var ring: Color = Color(uiColor: .secondarySystemGroupedBackground)
    var flows: Bool = true
    var body: some View {
        GeometryReader { g in
            FlowLine(pts: FlowLine.samplePoints(in: g.size, inset: dotRadius + 2), base: g.size.height, line: line,
                     lineWidth: lineWidth, glowWidth: lineWidth * 2.8, blur: blur, dotRadius: dotRadius, ring: ring, flows: flows)
        }
    }
}

// MARK: - Settings › Appearance

struct AppearanceSettings: View {
    var body: some View {
        let look: Look = Look.shared
        List {
            Section {
                Picker("Look", selection: Binding(get: { look.scheme }, set: { look.pick(scheme: $0) })) {
                    ForEach(KoshScheme.allCases) { s in Text(s.title).tag(s) }
                }
                .pickerStyle(.segmented)
                .listRowInsets(EdgeInsets(top: 12, leading: 12, bottom: 12, trailing: 12))
            } header: { Text("Look") } footer: {
                Text("Match system goes dark when your phone does, sunset switch included.")
            }

            Section {
                HStack(alignment: .top, spacing: 0) {
                    ForEach(KoshAccent.allCases) { a in
                        AccentSwatch(accent: a, on: a == look.accent) {
                            withAnimation(Motion.base) { look.pick(accent: a) }
                        }
                        .frame(maxWidth: .infinity)
                    }
                }
                .padding(.vertical, 6)
                .sensoryFeedback(.selection, trigger: look.accent)
            } header: { Text("Accent") } footer: {
                Text("Recolours links, switches, the tab you’re on and the net worth line. Money keeps its own colours: green up, red down. Always.")
            }

            Section {
                FlowLinePreview(dotRadius: 5)
                    .frame(height: 64)
                    .padding(.vertical, 8)
                    .accessibilityElement()
                    .accessibilityLabel("Net worth line: " + (look.line == .accent ? "follows the accent" : look.line.name))
                LazyVGrid(columns: [GridItem(.flexible(), spacing: 10), GridItem(.flexible(), spacing: 10), GridItem(.flexible(), spacing: 10)], spacing: 10) {
                    ForEach(KoshLine.allCases) { l in
                        LineSwatch(line: l, on: l == look.line) {
                            withAnimation(Motion.base) { look.pick(line: l) }
                        }
                    }
                }
                .padding(.vertical, 6)
                .sensoryFeedback(.selection, trigger: look.line)
                Toggle("Let it shimmer", isOn: Binding(get: { look.shimmer }, set: { look.pick(shimmer: $0) }))
            } header: { Text("Net worth line") } footer: {
                Text("Too much shimmer before your morning chai? Switch it off and the line sits still. With Reduce Motion on, it always does.")
            }
        }
        .navigationTitle("Appearance")
        .navigationBarTitleDisplayMode(.large)
    }
}

extension KoshAccent {
    /// the tick on a swatch: white on the deep day colours; black on teal, saffron and graphite's lifted night colours
    var tick: Color {
        switch self {
        case .kosh, .rose: return Color.white
        case .teal, .saffron, .graphite: return Color(light: "#FFFFFF", dark: "#000000")
        }
    }
}

/// one accent: its colour in a circle, ringed and ticked when it's the one
struct AccentSwatch: View {
    let accent: KoshAccent
    let on: Bool
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            VStack(spacing: 6) {
                ZStack {
                    Circle().fill(accent.swatch)
                    Circle().strokeBorder(Color.primary.opacity(0.08), lineWidth: 0.5)
                    if on {
                        Image(systemName: "checkmark")
                            .font(.system(size: 14, weight: .bold))
                            .foregroundStyle(accent.tick)
                    }
                }
                .frame(width: 36, height: 36)
                .padding(4)
                .overlay(Circle().strokeBorder(on ? accent.swatch : Color.clear, lineWidth: 2))
                Text(accent.name)
                    .font(.system(.caption2, weight: .semibold))
                    .foregroundStyle(on ? Color.primary : Color.secondary)
                    .lineLimit(1)
                    .minimumScaleFactor(0.8)
            }
            .contentShape(Rectangle())
        }
        .buttonStyle(.press)
        .accessibilityLabel("Accent: " + accent.spoken)
        .accessibilityAddTraits(on ? AccessibilityTraits.isSelected : AccessibilityTraits())
    }
}

/// one net worth line: a small moving preview, its name, ticked when it's the one
struct LineSwatch: View {
    let line: KoshLine
    let on: Bool
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            VStack(spacing: 6) {
                FlowLinePreview(line: line, lineWidth: 2.2, blur: 2.6, dotRadius: 3.5, ring: Color(uiColor: .tertiarySystemGroupedBackground))
                    .frame(height: 34)
                    .padding(.horizontal, 8)
                    .padding(.top, 10)
                HStack(spacing: 4) {
                    if on { Image(systemName: "checkmark.circle.fill").font(.system(.caption2, weight: .bold)).foregroundStyle(Color.kosh) }
                    Text(line.name).font(.system(.caption, weight: .semibold)).lineLimit(1).minimumScaleFactor(0.8)
                }
                .foregroundStyle(on ? Color.primary : Color.secondary)
                .padding(.bottom, 8)
            }
            .frame(maxWidth: .infinity)
            .background(Color(uiColor: .tertiarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous).strokeBorder(on ? Color.kosh : Color.primary.opacity(0.06), lineWidth: on ? 2 : 0.5))
            .contentShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
        }
        .buttonStyle(.press)
        .accessibilityLabel("Net worth line: " + (line == .accent ? "follows the accent" : line.name + ", " + line.blurb))
        .accessibilityAddTraits(on ? AccessibilityTraits.isSelected : AccessibilityTraits())
    }
}
