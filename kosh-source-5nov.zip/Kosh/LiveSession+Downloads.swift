import Foundation
import Observation
import UIKit
import Network

// MARK: - The background downloads (BackgroundMail): what's handed to them, and what comes back
//
// The reads whose mail is listed into windows of Gmail ids (the plans in reading.json) can carry on with kosh off
// screen: their emails go to a background download session, and each that comes back is read here exactly as on
// screen. An email is struck off its window's list only once it's in the records, so one that didn't come stays on
// the list for the next run. While a read on the phone is going through a list (sweep) the list is its to keep: what
// comes back meanwhile is read and noted (readInBackground), and the read on the phone strikes it off, without
// fetching it again, when it gets there.

extension LiveSession {
    /// the reads whose mail is listed as message ids, window by window: what the downloads can carry on
    static func downloadable(_ job: String) -> Bool {
        job == "scan" || job == "backfill" || job == "wallets" || job == "wider" || job == "statements" || job == "older" || job == "missing" || job.hasPrefix("inbox:")
    }

    /// a window, told apart in a few characters (its key can carry a dozen long searches): what a ticket carries
    static func windowTag(_ w: MailWindow) -> String { String(stable(w.key), radix: 36) }

    /// the order reads carry on in (as resumeReading takes them)
    static func readingRank(_ job: String) -> Int {
        let order: [String] = ["reingest", "scan", "statements", "wallets", "wider", "inbox:", "missing", "docs", "backfill", "older", "reader"]
        return order.firstIndex { job == $0 || ($0 == "inbox:" && job.hasPrefix($0)) } ?? order.count
    }

    /// the plans the downloads can take, in the order reads carry on (none that's stale, or listed over other inboxes)
    var downloadPlans: [(job: String, plan: ReadingPlan)] {
        let accounts: [String] = allAccounts
        return plans.filter { Self.downloadable($0.key) && !$0.value.stale && $0.value.accounts == accounts }
            .sorted { Self.readingRank($0.key) < Self.readingRank($1.key) }
            .map { (job: $0.key, plan: $0.value) }
    }

    /// emails on a window's lists not read yet: what the downloads brought back is still listed while a read on the
    /// phone has the list (it strikes them off when it gets there), but it's read
    func unread(_ w: MailWindow) -> Int {
        if readInBackground.isEmpty { return w.remaining }
        var n = 0
        for (acct, list) in w.left {
            let tag: String = inboxTag(acct)
            for id in list where !readInBackground.contains(tag + id) { n += 1 }
        }
        return n
    }

    /// emails still to read in the plans the downloads can take
    var leftToDownload: Int {
        downloadPlans.reduce(0) { n, d in n + d.plan.windows.reduce(0) { $0 + unread($1) } }
    }

    /// the inboxes with mail still to read there
    var inboxesToDownload: [String] {
        var out: [String] = []
        for d in downloadPlans {
            for w in d.plan.windows {
                for (acct, list) in w.left where !list.isEmpty && !out.contains(acct) { out.append(acct) }
            }
        }
        return out
    }

    /// the read the downloads are on, for the Lock Screen: the first with mail still to read, how much of it is still
    /// to read, and the window they're on (the last with mail to read: they take each plan from its far end), for the
    /// year's month
    var downloading: (job: String, plan: ReadingPlan, left: Int, window: MailWindow?)? {
        for d in downloadPlans {
            var left = 0
            var at: MailWindow? = nil
            for w in d.plan.windows {
                let n: Int = unread(w)
                if n > 0 { at = w }
                left += n
            }
            if left > 0 { return (job: d.job, plan: d.plan, left: left, window: at) }
        }
        return nil
    }

    /// The next emails for the downloads, up to `limit`: reads in the order they carry on, each list from its far end
    /// (a read on the phone works from the front), leaving out what's read already or on its way.
    @MainActor
    func downloadPicks(limit: Int, skipping busy: Set<String>) -> [MailTicket] {
        guard loadedFromDisk, signedIn, limit > 0 else { return [] }
        let known: Set<String> = knownIDs
        var out: [MailTicket] = []
        for d in downloadPlans {
            for w in d.plan.windows.reversed() {
                // the background downloads fetch from Gmail; other inboxes are read by the reads on the phone
                for acct in allAccounts where isGmail(acct) {
                    guard let list = w.left[acct], !list.isEmpty else { continue }
                    let tag: String = inboxTag(acct)
                    for id in list.reversed() {
                        let t = MailTicket(job: d.job, key: Self.windowTag(w), acct: acct, id: id)
                        if busy.contains(t.slot) || known.contains(tag + id) { continue }
                        out.append(t)
                        if out.count >= limit { return out }
                    }
                }
            }
        }
        return out
    }

    /// One email the downloads brought back: read like any other (one already read is left alone), and struck off its
    /// list unless a read on the phone has the list now. False if it can't be read in (kosh's files still locked away,
    /// signed out, the inbox gone): it stays on the list.
    @MainActor
    @discardableResult
    func takeDelivered(_ m: MailMsg, _ t: MailTicket) -> Bool {
        guard loadedFromDisk, signedIn, allAccounts.contains(t.acct) else { return false }
        let tag: String = inboxTag(t.acct)
        ingest(m, acct: t.acct, tag: tag)
        readInBackground.insert(tag + t.id)
        stretchRead += 1
        if !sweeping.contains(t.job) { strike(t) }
        return true
    }

    /// an email Gmail no longer has (deleted since it was listed): struck off unread, as a read on the phone does
    @MainActor
    func takeGone(_ t: MailTicket) {
        guard loadedFromDisk, !sweeping.contains(t.job) else { return }
        strike(t)
    }

    /// an email struck off its window's list; the window and its read count on by one
    @MainActor
    func strike(_ t: MailTicket) {
        guard var p = plans[t.job], let i = p.windows.firstIndex(where: { Self.windowTag($0) == t.key }),
              var list = p.windows[i].left[t.acct], let j = list.firstIndex(of: t.id) else { return }
        list.remove(at: j)
        p.windows[i].left[t.acct] = list.isEmpty ? nil : list
        p.windows[i].done += 1
        p.done += 1
        plans[t.job] = p
    }

    /// Emails still on a list that the downloads have read (they came back while a read on the phone had the list, and
    /// it stopped before it got to them): struck off and counted, as that read would have.
    @MainActor
    func strikeRead() {
        guard loadedFromDisk, !readInBackground.isEmpty else { return }
        for (job, p0) in plans where Self.downloadable(job) && !sweeping.contains(job) {
            var p: ReadingPlan = p0
            var n = 0
            for i in p.windows.indices {
                for (acct, list) in p.windows[i].left {
                    let tag: String = inboxTag(acct)
                    let keep: [String] = list.filter { !readInBackground.contains(tag + $0) }
                    guard keep.count != list.count else { continue }
                    p.windows[i].left[acct] = keep.isEmpty ? nil : keep
                    p.windows[i].done += list.count - keep.count
                    n += list.count - keep.count
                }
            }
            if n > 0 {
                p.done += n
                plans[job] = p
            }
        }
    }

    /// what came back, saved: the records first, then where the reading has got to (every ~10 s or 300 emails, or now);
    /// the screens laid out again every 20 s, as for a quiet read, or now
    @MainActor
    func deliveredSaved(_ n: Int, force: Bool = false) {
        checkpoint(n, force: force)
        if force || (n > 0 && readingBuildDue(every: 20)) {
            lastRebuild = Date()
            rebuild()
        }
    }

    /// an access token that lasts at least `minutes` more, for downloads that carry it until they're done
    func lastingToken(_ acct: String, minutes: Double) async throws -> String {
        try await token(acct, lasting: minutes * 60)
    }

    /// the token in hand, if it lasts at least `minutes` more: no network, for the moment kosh leaves the screen
    func heldToken(_ acct: String, minutes: Double) -> String? {
        guard let c = access[acct], c.until > Date().addingTimeInterval(minutes * 60) else { return nil }
        return c.token
    }

    /// how many minutes the token in hand has left (0 if there's none)
    func tokenMinutes(_ acct: String) -> Double {
        guard let c = access[acct] else { return 0 }
        return max(0, c.until.timeIntervalSinceNow / 60)
    }

    /// Gmail refused the token (it ran out early, or was revoked): the next one is fetched afresh
    func forgetToken(_ acct: String) {
        access[acct] = nil
    }
}

/// the readings made side by side (LiveSession.readingsOf), each in its mail's place
final class ReadingsBox: @unchecked Sendable {
    private let lock = NSLock()
    private var rows: [Reading?]
    init(_ n: Int) { rows = Array(repeating: nil, count: n) }
    func put(_ got: [(Int, Reading?)]) { lock.lock(); for (j, r) in got { rows[j] = r }; lock.unlock() }
    var all: [Reading?] { lock.lock(); defer { lock.unlock() }; return rows }
}
