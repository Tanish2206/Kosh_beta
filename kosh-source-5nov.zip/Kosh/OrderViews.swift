import SwiftUI

// MARK: - What an order was, on its payment's sheet; the month in review, in Insights
//
// Every figure is the engine's (engine/21r-build-orders.js; Orders.swift): what the order's mails printed, never worked
// out here. The bill's lines are facts beside the payment; only the payment's own amount counts in any total.
// (Big view expressions are split into typed pieces: the Mac's type checker has failed builds on long ones.)

/// what a payment's order was: what was bought, what it cost as printed, its tags, and the steps kosh read
struct OrderCard: View {
    @Environment(Store.self) private var store
    let t: Txn
    let o: OrdersBook.Order
    @State private var adding: Bool = false
    @State private var typed: String = ""

    var body: some View {
        let foot: String = Self.foot(o)
        VStack(alignment: .leading, spacing: 8) {
            SheetCard {
                VStack(alignment: .leading, spacing: 14) {
                    what
                    bill
                    tags
                    steps
                }
                .padding(16)
            }
            if !foot.isEmpty { SheetFootnote(foot) }
        }
        .alert("Add a tag", isPresented: $adding) {
            TextField("Gift, Diwali, Office…", text: $typed)
            Button("Add") { store.setTag(t.id, typed, on: true); typed = "" }
            Button("Cancel", role: .cancel) { typed = "" }
        } message: {
            Text("A tag you add stays with this payment. A kind of thing (Beauty, Electronics, Fashion, Books, Food, Groceries) is learnt for this payee too.")
        }
    }

    static func day(_ d: String) -> String { Day.fmt(d, "EEE d MMM") }

    /// what it was for: an event, a trip, the items, a gift and whom it went to
    @ViewBuilder var what: some View {
        let items: [PayFacts.Item] = store.payFact(t)?.items ?? []
        VStack(alignment: .leading, spacing: 6) {
            if let s = o.show {
                let line: String = OrderWords.show(s, day: Self.day)
                let sym: String = OrderWords.sym(s.k == "concert" ? "Concert" : s.k == "movie" ? "Movie" : "Event")
                Label(line, systemImage: sym).font(.subheadline.weight(.semibold))
                if let p = s.perf, !p.isEmpty {
                    Text(p).font(.footnote).foregroundStyle(.secondary).padding(.leading, 30)
                }
            }
            if let tr = o.trip, let line = OrderWords.trip(tr, day: Self.day) {
                Label(line, systemImage: "airplane").font(.subheadline.weight(.semibold))
            }
            ForEach(Array(items.prefix(5).enumerated()), id: \.offset) { _, it in
                ItemRow(it: it, food: t.c == "Food & Drinks" || t.c == "Groceries")
            }
            // (the order numbers the items came in)
            if let line = SplitWords.orders(items) {
                Text(line).font(.caption.monospaced()).foregroundStyle(.secondary).textSelection(.enabled).privacySensitive()
            }
            if items.count > 5 {
                Text("and " + String(items.count - 5) + " more").font(.footnote).foregroundStyle(.secondary)
            }
            // (nothing bought in the mail: say why, and where kosh read the payment)
            if items.isEmpty && o.show == nil && o.trip == nil && (o.bill ?? []).isEmpty, let why = OrderWords.noItems(o, payee: t.m) {
                Label(why, systemImage: "envelope").font(.footnote).foregroundStyle(.secondary)
            }
            if o.gift != nil {
                let whom: String? = o.gift?.to
                let to: String = whom.map { " for " + $0 } ?? ""
                Label("A gift" + to, systemImage: "gift").font(.subheadline)
            } else if let to = o.to, !to.isEmpty {
                Label("Delivered to " + to, systemImage: "shippingbox").font(.subheadline)
            }
        }
        .privacySensitive()
    }

    /// what it cost, line by line as the bill printed it
    @ViewBuilder var bill: some View {
        let lines: [OrdersBook.BillLine] = o.bill ?? []
        if !lines.isEmpty {
            VStack(alignment: .leading, spacing: 4) {
                Text("What the bill printed").font(.caption.weight(.semibold)).foregroundStyle(.secondary)
                ForEach(Array(lines.enumerated()), id: \.offset) { _, l in
                    BillRow(l: l)
                }
            }
        }
    }

    /// its tags: kosh's from the mail's words, yours, and what kosh learnt from you; tap one to take it off
    @ViewBuilder var tags: some View {
        let list: [OrdersBook.Tag] = o.tags ?? []
        ScrollView(.horizontal) {
            HStack(spacing: 8) {
                ForEach(list, id: \.t) { tag in
                    TagChip(tag: tag) { store.setTag(t.id, tag.t, on: false) }
                }
                Button { adding = true } label: {
                    Label("Tag", systemImage: "plus").font(.footnote.weight(.semibold))
                        .padding(.horizontal, 10).padding(.vertical, 6)
                        .background(Color.primary.opacity(0.06), in: Capsule())
                }
                .buttonStyle(.press)
                .disabled(store.live == nil)
            }
        }
        .scrollIndicators(.hidden)
    }

    /// the order's story: each mail kosh read of it, oldest first (opened from "Where kosh read this" below)
    @ViewBuilder var steps: some View {
        let mails: [OrdersBook.Mail] = o.mails ?? []
        if mails.count > 1 {
            VStack(alignment: .leading, spacing: 3) {
                Text(String(mails.count) + " mails, one payment").font(.caption.weight(.semibold)).foregroundStyle(.secondary)
                ForEach(mails) { m in
                    OrderStepRow(step: OrderWords.step(m.step), day: Day.fmt(m.d, "d MMM"))
                }
            }
        }
    }

    static func foot(_ o: OrdersBook.Order) -> String {
        var parts: [String] = []
        if !(o.bill ?? []).isEmpty { parts.append("Only what you paid counts in your totals; the lines are what the bill printed.") }
        if (o.bill ?? []).contains(where: { $0.p == 1 }) { parts.append("Lines marked with a page are from the fee’s tax invoice.") }
        if (o.tags ?? []).contains(where: { $0.by == "kosh" }) { parts.append("Tags with a sparkle are kosh’s, from the mail’s own words.") }
        return parts.joined(separator: " ")
    }
}

/// one item bought: "2 × Sample Lash Mascara 3ml  ₹1,500"
struct ItemRow: View {
    let it: PayFacts.Item
    var food: Bool = false
    var body: some View {
        let count: String = (it.q ?? 1) > 1 ? String(it.q ?? 1) + " × " : ""
        let fig: Double? = it.amt ?? it.unit
        let back: Bool = it.ret != nil
        VStack(alignment: .leading, spacing: 2) {
            HStack(alignment: .firstTextBaseline, spacing: 8) {
                Text(count + it.n).font(.subheadline).lineLimit(2).strikethrough(back, color: .secondary).foregroundStyle(back ? Color.secondary : Color.primary)
                Spacer(minLength: 8)
                if let fig { Text(Fmt.rupees(fig) + (it.amt == nil ? " each" : "")).font(.subheadline).foregroundStyle(.secondary).monospacedDigit().strikethrough(back, color: .secondary) }
            }
            if let r = it.ret {
                Label((food ? "Refunded " : "Returned ") + Day.fmt(r, "d MMM") + (it.back.map { " · " + Fmt.rupees($0) + " back" } ?? ""), systemImage: "arrow.uturn.backward")
                    .font(.caption.weight(.semibold)).foregroundStyle(Color.green)
            }
        }
    }
}

/// one line of the bill: a discount with a minus, what was paid in bold, a paper's line with its mark
struct BillRow: View {
    let l: OrdersBook.BillLine
    var body: some View {
        let name: String = OrderWords.billName(l)
        let fig: String = (l.k == "disc" ? "−" : "") + Fmt.rupees(l.amt)
        let paid: Bool = l.k == "paid"
        HStack(spacing: 8) {
            Text(name).font(paid ? .subheadline.weight(.semibold) : .subheadline)
            if l.p == 1 { Image(systemName: "doc.text").font(.caption).foregroundStyle(.secondary) }
            Spacer(minLength: 8)
            Text(fig).font(paid ? .subheadline.weight(.semibold) : .subheadline).monospacedDigit()
                .foregroundStyle(l.k == "disc" ? Color.green : Color.primary)
        }
        .privacySensitive()
    }
}

/// a tag: what it was, its who or where, whose word it is; tap to take it off
struct TagChip: View {
    let tag: OrdersBook.Tag
    let remove: () -> Void
    var body: some View {
        let words: String = tag.t + (tag.w.map { " · " + $0 } ?? "")
        let kosh: Bool = tag.by != "you"
        Button(action: remove) {
            HStack(spacing: 5) {
                Image(systemName: OrderWords.sym(tag.t)).font(.caption)
                Text(words).font(.footnote.weight(.semibold)).lineLimit(1)
                if kosh { Image(systemName: "sparkle").font(.caption2).foregroundStyle(.secondary) }
                Image(systemName: "xmark").font(.caption2.weight(.bold)).foregroundStyle(.secondary)
            }
            .padding(.horizontal, 10).padding(.vertical, 6)
            .background(Color.accentColor.opacity(0.12), in: Capsule())
        }
        .buttonStyle(.press)
        .accessibilityLabel(words + (kosh ? ", kosh’s tag" : ", your tag"))
        .accessibilityHint("Takes the tag off")
    }
}

/// one step of the order's story: "Delivery attempted · 9 Oct"
struct OrderStepRow: View {
    let step: String
    let day: String
    var body: some View {
        HStack(spacing: 8) {
            Circle().fill(Color.secondary.opacity(0.5)).frame(width: 5, height: 5)
            Text(step).font(.footnote)
            Spacer(minLength: 8)
            Text(day).font(.footnote).foregroundStyle(.secondary).monospacedDigit()
        }
    }
}
