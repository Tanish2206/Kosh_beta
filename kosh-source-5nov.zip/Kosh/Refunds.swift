import SwiftUI

// MARK: - How a row counts, and refunds you're waiting for
//
// Any payment can count in the month before or after its own (a bill paid at 11 pm on the last night,
// say), or be kept out of spending and cash flow altogether. A payment you expect money back on is
// marked with how much and by when; kosh watches for the credit, sets it against the payment when it
// lands (its spending drops, in the month you paid, and the credit isn't income), and shows what's
// still owed back on Home and on the calendar until it's in.

/// "How it counts": the month, and whether at all
struct CountSection: View {
    @Environment(Store.self) private var store
    let t: Txn
    var body: some View {
        let real: String = t.od ?? t.d
        let own: String = String(real.prefix(7))
        let months: [String] = Self.months(own: own, cm: store.snap.cm)
        let counted: String = String(t.d.prefix(7))
        let refundCredit: Bool = t.refOf != nil
        Section {
            if !refundCredit {
                Toggle("Count in spending", isOn: Binding(get: { Self.counted(store.txn(t.id)) }, set: { store.setCounted(t.id, $0) }))
            }
            Picker("Counts in", selection: Binding(get: { counted }, set: { m in store.setCountMonth(t.id, m == own ? nil : m) })) {
                ForEach(months, id: \.self) { m in
                    Text(Self.monthLabel(m, own: own)).tag(m)
                }
            }
        } header: {
            Text("How it counts")
        } footer: {
            Text(Self.footer(t))
        }
    }
    static func counted(_ t: Txn?) -> Bool { (t?.ex ?? "").isEmpty && (t?.nc ?? "").isEmpty }
    static func months(own: String, cm: String) -> [String] {
        var out: [String] = [Day.addMonths(own, -1), own]
        let next: String = Day.addMonths(own, 1)
        if next <= cm { out.append(next) }
        return out
    }
    static func monthLabel(_ m: String, own: String) -> String {
        let name: String = Day.fmt(m + "-01", "MMMM yyyy")
        return m == own ? name + " · its own" : name
    }
    static func footer(_ t: Txn) -> String {
        switch t.nc ?? "" {
        case "unnamed": return "kosh couldn't tell what this big payment was, so it waits out of spending: it's often money to your own account or a person. Give it a category, or turn this on to count it as it is."
        case "parked": return "A wallet top-up or gift card counts when you spend from it (Settings › How kosh counts). Turn this on to count this one now."
        case "wallet": return "Paid from a wallet whose top-up already counted (Settings › How kosh counts). Turn this on to count it here as well."
        case "chapter": return "Trips and events are left out of monthly spending (Settings › How kosh counts). Turn this on to count this one in its month."
        case "tax": return "Income tax, advance tax and GST are taxes you owe, not spending, so they are left out of spending totals. Your cash flow still has them. Turn this on to count this one."
        default: break
        }
        if let od = t.od {
            return "Paid " + Day.fmt(od, "d MMMM") + ", counted in " + Day.monthName(String(t.d.prefix(7))) + "'s spending and cash flow. Your bank balance still has it on the day it happened."
        }
        return "A payment made late on a month's last night, or a bill that belongs to the next month, can count where it belongs. Left out, it stays in the list but out of every total."
    }
}

/// a refund's standing: what's still to come, what came back and when, and how far along it is
struct RefundStatus: View {
    let r: RefundInfo
    let today: String
    var body: some View {
        let done: Bool = r.state == "back"
        let tint: Color = Self.tint(r.state)
        let share: Double = r.exp > 0 ? min(1, r.back / r.exp) : 0
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 12) {
                Image(systemName: done ? "checkmark" : "arrow.uturn.backward")
                    .font(.system(size: 15, weight: .bold))
                    .foregroundStyle(tint)
                    .frame(width: 34, height: 34)
                    .background(tint.opacity(0.14), in: Circle())
                VStack(alignment: .leading, spacing: 1) {
                    Text(Self.title(r)).font(.body.weight(.semibold)).privacySensitive()
                    Text(Self.line(r, today: today)).font(.footnote).foregroundStyle(r.state == "late" ? Color.orange : Color.secondary)
                        .fixedSize(horizontal: false, vertical: true).privacySensitive()
                }
            }
            GeometryReader { g in
                ZStack(alignment: .leading) {
                    Capsule().fill(tint.opacity(0.14))
                    Capsule().fill(tint.gradient).frame(width: max(4, g.size.width * CGFloat(share)))
                }
            }
            .frame(height: 5)
        }
        .padding(.vertical, 4)
    }
    static func tint(_ state: String) -> Color {
        switch state {
        case "back": return Color.green
        case "late": return Color.orange
        default: return Color.kosh
        }
    }
    static func title(_ r: RefundInfo) -> String {
        if r.state == "back" { return Fmt.rupees(r.exp) + " came back" }
        return Fmt.rupees(r.left) + " to come back"
    }
    static func line(_ r: RefundInfo, today: String) -> String {
        var bits: [String] = []
        if r.state == "back" {
            if r.manual && r.credits.isEmpty { bits.append("You marked it back") }
            else if let last = r.credits.last { bits.append("Last of it on " + Day.fmt(last.d, "d MMM")) }
        } else {
            if r.back > 0 { bits.append(Fmt.rupees(r.back) + " back so far") }
            if !r.by.isEmpty {
                bits.append(r.state == "late" ? "expected by " + Day.fmt(r.by, "d MMM") + ", not back yet" : "expected by " + Day.fmt(r.by, "d MMM"))
            } else {
                let days: Int = Day.cal.dateComponents([.day], from: Day.date(r.d), to: Day.date(today)).day ?? 0
                bits.append(days <= 0 ? "paid today" : "paid " + String(days) + (days == 1 ? " day ago" : " days ago"))
            }
        }
        if !r.note.isEmpty { bits.append(r.note) }
        return bits.joined(separator: " · ")
    }
}

/// how much comes back, by when, and a note to find it by
struct RefundSheet: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    let t: Txn
    @State private var amount: String = ""
    @State private var dated = false
    @State private var by = Date()
    @State private var note = ""
    var body: some View {
        let paid: Double = store.refund(t.id)?.a ?? (t.full ?? t.a)
        NavigationStack {
            Form {
                Section {
                    HStack(spacing: 4) {
                        Text("₹").foregroundStyle(.secondary)
                        TextField("Amount", text: $amount).keyboardType(.decimalPad)
                    }
                } header: {
                    Text("How much comes back")
                } footer: {
                    Text("Of \(Fmt.rupees(paid)) paid to \(t.m). Part of it is fine: a returned item from a bigger order.")
                        .privacySensitive()
                }
                Section {
                    Toggle("Expected by a date", isOn: $dated)
                    if dated { DatePicker("By", selection: $by, displayedComponents: .date) }
                    TextField("Note: order number, ticket", text: $note)
                } footer: {
                    Text("Past that date it shows as late, on Home and on the calendar.")
                }
            }
            .navigationTitle("Refund")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") { save(paid) }.disabled(Self.value(amount) <= 0)
                }
            }
            // its own sheet over the payment's: it hides its figures itself (the field you type in stays readable)
            .redacted(reason: store.hidden ? .privacy : [])
            .onAppear { load(paid) }
        }
    }
    func load(_ paid: Double) {
        let r: RefundInfo? = store.refund(t.id)
        amount = Fmt.trim(r?.exp ?? paid, 2)
        note = r?.note ?? ""
        if let r, !r.by.isEmpty {
            dated = true
            by = Day.date(r.by)
        } else {
            by = Day.date(Day.add(store.snap.today, 14))
        }
    }
    func save(_ paid: Double) {
        let v: Double = min(Self.value(amount), paid)
        let day: String? = dated ? Day.iso(by) : nil
        store.expectRefund(t.id, amount: v, by: day, note: note.trimmingCharacters(in: .whitespacesAndNewlines))
        dismiss()
    }
    static func value(_ s: String) -> Double { Double(s.replacingOccurrences(of: ",", with: "").trimmingCharacters(in: .whitespaces)) ?? 0 }
}

/// on a credit: the payment it refunds, or which one it might
struct RefundLinkSection: View {
    @Environment(Store.self) private var store
    let t: Txn
    var body: some View {
        if let of = t.refOf, let p = store.txn(of) {
            Section {
                LabeledContent("Refund for") {
                    Text(p.m + " · " + Day.fmt(p.od ?? p.d, "d MMM")).lineLimit(1)
                }
                Button(role: .destructive) { store.linkRefund(credit: t.id, to: nil) } label: {
                    Label("Not a refund", systemImage: "xmark.circle")
                }
            } header: {
                Text("Refund")
            } footer: {
                Text("Set against that payment: its spending is lower by this much, and this isn't counted as income.")
            }
        } else {
            let cands: [Txn] = store.refundCandidates(for: t)
            if !cands.isEmpty {
                Section {
                    Menu {
                        ForEach(cands) { p in
                            Button(Self.label(p)) { store.linkRefund(credit: t.id, to: p.id) }
                        }
                    } label: {
                        Label("This is a refund for…", systemImage: "arrow.uturn.backward.circle")
                    }
                } footer: {
                    Text("Set it against the payment it pays back: that payment's spending drops, and this isn't counted as income.")
                }
            }
        }
    }
    static func label(_ p: Txn) -> String {
        p.m + " · " + Fmt.rupees(p.full ?? p.a) + " · " + Day.fmt(p.od ?? p.d, "d MMM")
    }
}

/// Home: what's owed back, the biggest few
struct RefundsCard: View {
    @Environment(Store.self) private var store
    var body: some View {
        let waiting: [RefundInfo] = store.refundsWaiting
        let total: Double = waiting.reduce(0) { $0 + $1.left }
        let late: Int = waiting.filter { $0.state == "late" }.count
        if !waiting.isEmpty {
            VStack(alignment: .leading, spacing: 12) {
                SectionHeader(title: "Expected back", action: "All", onAction: { store.push(.refunds) })
                Button { store.push(.refunds) } label: {
                    VStack(alignment: .leading, spacing: 12) {
                        HStack(alignment: .firstTextBaseline, spacing: 8) {
                            Text(Fmt.rupees(total)).font(.system(.title, design: .rounded, weight: .bold)).monospacedDigit().privacySensitive()
                            Text(Self.countLine(waiting.count, late: late)).font(.subheadline).foregroundStyle(late > 0 ? Color.orange : Color.secondary)
                        }
                        ForEach(Array(waiting.prefix(3))) { r in
                            RefundRow(r: r, today: store.snap.today)
                        }
                    }
                    .foregroundStyle(Color.primary)
                    .card(16)
                }
                .buttonStyle(.press)
            }
        }
    }
    static func countLine(_ n: Int, late: Int) -> String {
        let base: String = n == 1 ? "1 refund" : String(n) + " refunds"
        if late == 0 { return base }
        return base + " · " + String(late) + " late"
    }
}

struct RefundRow: View {
    let r: RefundInfo
    let today: String
    var body: some View {
        let tint: Color = RefundStatus.tint(r.state)
        HStack(spacing: 12) {
            Image(systemName: r.state == "back" ? "checkmark" : "arrow.uturn.backward")
                .font(.system(size: 12, weight: .bold))
                .foregroundStyle(tint)
                .frame(width: 30, height: 30)
                .background(tint.opacity(0.14), in: Circle())
            VStack(alignment: .leading, spacing: 1) {
                Text(r.m).font(.subheadline.weight(.semibold)).lineLimit(1)
                Text(RefundStatus.line(r, today: today)).font(.caption).foregroundStyle(r.state == "late" ? Color.orange : Color.secondary).lineLimit(1)
            }
            Spacer(minLength: 8)
            Text(Fmt.rupees(r.state == "back" ? r.exp : r.left)).font(.subheadline.weight(.semibold)).monospacedDigit().privacySensitive()
        }
    }
}

/// every refund: still to come, then those that came back
struct RefundsPage: View {
    @Environment(Store.self) private var store
    var body: some View {
        let all: [RefundInfo] = (store.snap.refunds ?? []).filter { store.who.owns($0.o) }
        let waiting: [RefundInfo] = all.filter { $0.state != "back" }
        let back: [RefundInfo] = all.filter { $0.state == "back" }
        List {
            Section {
                VStack(alignment: .leading, spacing: 2) {
                    Text(Fmt.rupees(waiting.reduce(0) { $0 + $1.left }))
                        .font(.system(size: 40, weight: .bold, design: .rounded)).monospacedDigit().privacySensitive()
                    Text(waiting.isEmpty ? "Nothing waiting to come back" : "still to come back").font(.subheadline).foregroundStyle(.secondary)
                }
                .listRowBackground(Color.clear)
            }
            if !waiting.isEmpty {
                Section("Waiting") {
                    ForEach(waiting) { r in
                        Button { store.sheet = .tx(r.id) } label: { RefundRow(r: r, today: store.snap.today).foregroundStyle(Color.primary) }
                    }
                }
            }
            if !back.isEmpty {
                Section("Came back") {
                    ForEach(back.prefix(20)) { r in
                        Button { store.sheet = .tx(r.id) } label: { RefundRow(r: r, today: store.snap.today).foregroundStyle(Color.primary) }
                    }
                }
            }
            Section {} footer: {
                Text("Mark a payment “Expecting a refund” from its sheet. kosh sets the refund against it when it lands in your mail: a refund from the same shop, or one of exactly what's still due.")
            }
        }
        .listStyle(.insetGrouped)
        .navigationTitle("Refunds")
    }
}
