import SwiftUI

// MARK: - A chapter's own page
//
// Laid out like a chapter in a book: a cover in its colour, with its stamp, its number, its name and what it
// cost; then numbered parts: at a glance, against the budget, booked ahead and spent there, where it went, day by
// day, where you were, the biggest payments, who was in it, what stood out, the month with it and without it,
// and every payment. One of your own reads from its payments and opens them in Transactions.

struct ChapterPage: View {
    @Environment(Store.self) private var store
    @Environment(\.chapterRouter) private var router
    let id: String
    @State private var scrolled = false
    @State private var editing = false
    /// the split, being sent to the family
    @State private var splitting = false

    var body: some View {
        if id == ChaptersAll.id && router == nil {
            // "All chapters", pushed from the notebook: the timeline of them all
            ChaptersTimeline()
        } else if router?.samplesOnly != true && store.trip(id) == nil && ChapterSamples.chapter(id) == nil {
            // deleted (from a payment's sheet, say) while its page was open: it says so, never shows a sample
            ContentUnavailableView("This chapter is gone", systemImage: "book.closed",
                                   description: Text("Its payments are back to ordinary spending."))
        } else {
            page
        }
    }

    @ViewBuilder private var page: some View {
        let st: ChapterStory = store.chapterStory(id, samplesOnly: router?.samplesOnly == true)
        let parts: [ChapterPart] = ChapterPart.list(st)
        ScrollView {
            VStack(alignment: .leading, spacing: 0) {
                ChapterCover(story: st)
                VStack(alignment: .leading, spacing: 0) {
                    ForEach(Array(parts.enumerated()), id: \.element) { i, p in
                        ChapterPartView(part: p, n: i + 1, story: st)
                            .padding(.top, i == 0 ? 26 : 40)
                    }
                }
                .padding(.horizontal, 22)
                .padding(.bottom, 40)
            }
        }
        .scrollIndicators(.hidden)
        .background(Color(uiColor: .systemBackground))
        .onScrollGeometryChange(for: Bool.self) { g in
            g.contentOffset.y + g.contentInsets.top > 240
        } action: { _, v in
            withAnimation(Motion.base) { scrolled = v }
        }
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .principal) {
                Text(st.chapter.title).font(.headline).lineLimit(1).opacity(scrolled ? 1 : 0)
            }
            ToolbarItemGroup(placement: .topBarTrailing) {
                if st.trip != nil {
                    // one of your own: its total in a line, or the split for the family
                    Menu {
                        ShareLink(item: st.share) { Label("Share the total", systemImage: "text.quote") }
                        Button { splitting = true } label: { Label("Share the split", systemImage: "person.2") }
                    } label: {
                        Image(systemName: "square.and.arrow.up")
                    }
                    .accessibilityLabel("Share")
                    Button("Edit") { editing = true }
                } else {
                    ShareLink(item: st.share) { Image(systemName: "square.and.arrow.up") }
                        .accessibilityLabel("Share")
                }
            }
        }
        .sheet(isPresented: $editing) { TripEditor(editing: id, fromPage: true) }
        .sheet(isPresented: $splitting) { SplitShareSheet(id: id).environment(store).presentationDragIndicator(.visible) }
    }
}

enum ChapterPart: Hashable {
    case glance, budget, ahead, lines, bars, places, gifts, biggest, people, split, stood, compare, payments

    static func list(_ st: ChapterStory) -> [ChapterPart] {
        var out: [ChapterPart] = [.glance]
        if st.budget > 0 { out.append(.budget) }
        if st.ahead > 0 && st.there > 0 { out.append(.ahead) }
        if !st.lines.isEmpty { out.append(.lines) }
        if st.bars.count > 1 { out.append(.bars) }
        if !st.places.isEmpty { out.append(.places) }
        if !st.gifts.isEmpty { out.append(.gifts) }
        if !st.biggest.isEmpty || !st.topIDs.isEmpty { out.append(.biggest) }
        if !st.people.isEmpty { out.append(.people) }
        // one of your own with money in it: who paid, who owes whom, and sending it to the family
        if st.trip != nil && st.spent > 0 { out.append(.split) }
        if !st.features.isEmpty { out.append(.stood) }
        if !st.month.isEmpty && (st.withIt > 0 || st.without > 0) { out.append(.compare) }
        out.append(.payments)
        return out
    }
}

/// a part's heading: its number, then its name in the book face
struct PartTitle: View {
    let n: Int
    let text: String
    var body: some View {
        HStack(alignment: .firstTextBaseline, spacing: 10) {
            Text(String(format: "%02d", n))
                .font(.system(.footnote, design: .monospaced, weight: .semibold))
                .foregroundStyle(.secondary)
            Text(text).font(.system(.title2, design: .serif, weight: .semibold))
        }
        .accessibilityElement(children: .combine)
        .accessibilityAddTraits(.isHeader)
    }
}

struct ChapterPartView: View {
    @Environment(Store.self) private var store
    @Environment(\.chapterRouter) private var router
    let part: ChapterPart
    let n: Int
    let story: ChapterStory

    /// onto the demo's own stack when there is one, else the tab's
    func go(_ r: Route) {
        if let router { router.push(r) } else { store.push(r) }
    }

    var body: some View {
        switch part {
        case .glance:
            VStack(alignment: .leading, spacing: 16) {
                PartTitle(n: n, text: "At a glance")
                FigureGrid(figures: story.figures)
            }
        case .budget:
            VStack(alignment: .leading, spacing: 16) {
                PartTitle(n: n, text: "Against the budget")
                BudgetMeter(spent: story.spent, budget: story.budget, ink: story.chapter.inkColor, future: story.chapter.from > store.snap.today)
            }
        case .ahead:
            let journey: Bool = story.chapter.fam == .journey
            VStack(alignment: .leading, spacing: 16) {
                PartTitle(n: n, text: journey ? "Booked ahead, spent there" : "Paid ahead, and on the days")
                AheadThere(ahead: story.ahead, there: story.there, ink: story.chapter.inkColor, thereLabel: journey ? "There" : "On the days")
                if !story.chapter.lead.isEmpty {
                    Text("The first payment ahead went out on \(Day.fmt(story.chapter.lead, "d MMMM")), \(Day.between(story.chapter.lead, story.chapter.from)) days before it began.")
                        .font(.footnote).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                }
            }
        case .lines:
            LinesSection(story: story, n: n)
        case .bars:
            BarsSection(story: story, n: n).modifier(Reveal())
        case .places:
            VStack(alignment: .leading, spacing: 12) {
                PartTitle(n: n, text: "Where you were")
                PlacesList(places: story.places, ink: story.chapter.inkColor)
            }
        case .gifts:
            VStack(alignment: .leading, spacing: 8) {
                PartTitle(n: n, text: "Gifts that came in")
                PayList(rows: story.gifts)
            }
            .modifier(Reveal())
        case .biggest:
            VStack(alignment: .leading, spacing: 8) {
                PartTitle(n: n, text: "Biggest payments")
                if story.topIDs.isEmpty {
                    PayList(rows: story.biggest)
                } else {
                    VStack(spacing: 14) {
                        ForEach(story.topIDs, id: \.self) { tid in
                            if let t = store.txn(tid) { TxRow(t: t, when: Day.short(t.od ?? t.d), showTrip: false) }
                        }
                    }
                    .card(14)
                    .padding(.top, 6)
                }
            }
            .modifier(Reveal())
        case .people:
            VStack(alignment: .leading, spacing: 4) {
                PartTitle(n: n, text: "Who was in it")
                PeopleRow(story: story) { go(.chapterGroup(story.chapter.id)) }
            }
        case .split:
            if let id = story.trip { ChapterSplitPart(id: id, n: n) }
        case .stood:
            VStack(alignment: .leading, spacing: 22) {
                PartTitle(n: n, text: "What stood out")
                ForEach(Array(story.features.enumerated()), id: \.element.id) { i, f in
                    FeatureRow(f: f).modifier(Reveal(delay: Motion.stagger(i)))
                }
            }
        case .compare:
            VStack(alignment: .leading, spacing: 16) {
                PartTitle(n: n, text: "With it, and without it")
                WithWithout(story: story)
            }
            .modifier(Reveal())
        case .payments:
            VStack(alignment: .leading, spacing: 14) {
                PartTitle(n: n, text: "Every payment")
                if let id = story.trip, let trip = store.trip(id) {
                    RealPayments(trip: trip)
                } else {
                    SamplePayments(story: story)
                }
            }
        }
    }
}

// MARK: the cover

struct ChapterCover: View {
    let story: ChapterStory
    @Environment(\.colorScheme) private var scheme
    @Environment(Store.self) private var store

    var body: some View {
        let c: Chapter = story.chapter
        let ink: Color = c.inkColor.ink(scheme)
        let eyebrow: String = "CHAPTER " + String(format: "%02d", story.number) + " · " + c.famName.uppercased() + (c.sample ? " · SAMPLE" : "")
        let line2: String = story.who.isEmpty ? c.dates : c.dates + " · " + story.who
        VStack(alignment: .leading, spacing: 0) {
            // the stamps sit a little up into the bar's own room, so the cover stays under half the screen
            GeometryReader { g in
                let w: CGFloat = g.size.width
                ZStack(alignment: .topLeading) {
                    LandingStamp(art: c.art, size: 122, rotation: c.rot, dashed: c.draft, delay: 0.2)
                        .position(x: story.stamps.isEmpty ? w * 0.6 : w * 0.4, y: 72)
                    ForEach(Array(story.stamps.enumerated()), id: \.element.id) { i, s in
                        LandingStamp(key: s.key, size: s.size * 0.8, rotation: s.rot, delay: 0.4 + Double(i) * 0.14)
                            .position(x: w * s.x, y: 140 * s.y + 4)
                    }
                    Ribbon().fill(ink)
                        .frame(width: 16, height: 108)
                        .offset(x: 62, y: -58)
                        .shadow(color: Color.black.opacity(0.12), radius: 2, y: 1)
                }
            }
            .frame(height: 140)
            .padding(.top, -30)

            Text(eyebrow)
                .font(.system(.caption2, weight: .semibold))
                .tracking(1.3)
                .foregroundStyle(ink)
            Text(c.title)
                .font(.system(.title, design: .serif, weight: .semibold))
                .fixedSize(horizontal: false, vertical: true)
                .padding(.top, 4)
            if !story.place.isEmpty {
                Text(story.place).font(.system(.subheadline)).foregroundStyle(.secondary).padding(.top, 3)
            }
            Text(line2).font(.system(.subheadline)).foregroundStyle(.secondary).padding(.top, 1)
            HStack(alignment: .firstTextBaseline, spacing: 8) {
                Text(Fmt.rupees(story.spent))
                    .font(.system(.largeTitle, design: .serif, weight: .bold))
                    .minimumScaleFactor(0.6)
                    .lineLimit(1)
                    .privacySensitive()
                Text(Self.caption(story, today: store.snap.today)).font(.subheadline).foregroundStyle(.secondary)
            }
            .padding(.top, 12)
            let chips: [String] = Self.chips(story, today: store.snap.today)
            if !chips.isEmpty {
                HStack(spacing: 8) {
                    ForEach(chips, id: \.self) { t in
                        Text(t).font(.system(.caption, weight: .semibold))
                            .foregroundStyle(ink)
                            .padding(.horizontal, 11).padding(.vertical, 6)
                            .background(ink.opacity(0.1), in: Capsule())
                    }
                }
                .padding(.top, 10)
            }
        }
        .padding(.horizontal, 22)
        .padding(.bottom, 20)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(alignment: .bottom) {
            // the wash runs up under the bar and beyond, so a pull down shows more of it
            c.wash(scheme).frame(height: 1600)
        }
    }

    static func caption(_ st: ChapterStory, today: String) -> String {
        let c: Chapter = st.chapter
        if c.draft { return "paid ahead" }
        if c.from > today { return "so far" }
        if c.to >= today { return "so far" }
        return "spent"
    }

    static func chips(_ st: ChapterStory, today: String) -> [String] {
        var out: [String] = []
        let b: String = ChapterCard.badge(st.chapter, today)
        if !b.isEmpty { out.append(b) }
        if st.budget > 0 && st.spent > st.budget && !out.contains("Over budget") { out.append("Over budget") }
        if st.budget > 0 && st.spent <= st.budget && st.chapter.to < today { out.append("Under budget") }
        return Array(out.prefix(2))
    }
}

// MARK: the parts

struct FigureGrid: View {
    let figures: [ChapterStory.Figure]
    var body: some View {
        LazyVGrid(columns: [GridItem(.flexible(), spacing: 10), GridItem(.flexible(), spacing: 10)], spacing: 10) {
            ForEach(Array(figures.enumerated()), id: \.element.id) { i, f in
                VStack(alignment: .leading, spacing: 3) {
                    Text(f.value)
                        .font(.system(.title2, design: .rounded, weight: .bold))
                        .lineLimit(1).minimumScaleFactor(0.6)
                        .privacySensitive()
                    Text(f.label).font(.footnote).foregroundStyle(.secondary).lineLimit(1)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal, 16).padding(.vertical, 14)
                .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).strokeBorder(Color.primary.opacity(0.06), lineWidth: 0.5))
                .modifier(Reveal(delay: Motion.stagger(i)))
            }
        }
    }
}

/// what's spent against the budget: the line's end is the budget, anything past it in red
struct BudgetMeter: View {
    let spent: Double
    let budget: Double
    let ink: Color
    let future: Bool
    @State private var grown = false
    var body: some View {
        let over: Bool = spent > budget
        let top: Double = max(spent, budget, 1)
        let red: Color = Color(hex: "#C2412D")
        let green: Color = Color(hex: "#2E7D4F")
        VStack(alignment: .leading, spacing: 10) {
            Text(Self.line(spent, budget, future))
                .font(.system(.body, weight: .semibold))
                .foregroundStyle(over ? red : Color.primary)
                .privacySensitive()
            GeometryReader { g in
                let w: CGFloat = g.size.width
                let inW: CGFloat = w * CGFloat(min(spent, budget) / top)
                let outW: CGFloat = over ? w * CGFloat((spent - budget) / top) : 0
                ZStack(alignment: .leading) {
                    Capsule().fill(Color.primary.opacity(0.07))
                    HStack(spacing: 2) {
                        Capsule().fill(over ? ink : (future ? ink : green)).frame(width: grown ? max(6, inW) : 6)
                        if over { Capsule().fill(red).frame(width: grown ? outW : 0) }
                    }
                    Rectangle().fill(Color.primary).frame(width: 2, height: 18).offset(x: w * CGFloat(budget / top) - 1)
                }
            }
            .frame(height: 10)
            HStack {
                Text("Spent " + Fmt.words(spent)).font(.caption).foregroundStyle(.secondary)
                Spacer()
                Text("Budget " + Fmt.words(budget)).font(.caption.weight(.semibold))
            }
            .privacySensitive()
        }
        .onScrollVisibilityChange(threshold: 0.4) { v in
            if v && !grown { withAnimation(Motion.reveal) { grown = true } }
        }
    }
    static func line(_ spent: Double, _ budget: Double, _ future: Bool) -> String {
        if spent > budget { return Fmt.rupees(spent - budget) + " over the " + Fmt.words(budget) + " budget" }
        if future { return Fmt.rupees(budget - spent) + " left of " + Fmt.rupees(budget) }
        return Fmt.rupees(budget - spent) + " under the " + Fmt.words(budget) + " budget"
    }
}

struct AheadThere: View {
    let ahead: Double
    let there: Double
    let ink: Color
    var thereLabel: String = "There"
    @State private var grown = false
    var body: some View {
        let total: Double = max(1, ahead + there)
        let a: Double = ahead / total
        VStack(alignment: .leading, spacing: 0) {
            GeometryReader { g in
                HStack(spacing: 3) {
                    Capsule().fill(Color.primary).frame(width: grown ? max(0, (g.size.width - 3) * a) : 0)
                    Capsule().fill(ink).frame(width: grown ? max(0, (g.size.width - 3) * (1 - a)) : 0)
                }
            }
            .frame(height: 10)
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 3) {
                    Label { Text("Ahead · " + Fmt.pct(a)) } icon: { Circle().fill(Color.primary).frame(width: 8, height: 8) }
                        .font(.subheadline).foregroundStyle(.secondary)
                    Text(Fmt.rupees(ahead)).font(.system(.body, weight: .semibold)).privacySensitive()
                }
                Spacer()
                VStack(alignment: .trailing, spacing: 3) {
                    Label { Text(thereLabel + " · " + Fmt.pct(1 - a)) } icon: { Circle().fill(ink).frame(width: 8, height: 8) }
                        .font(.subheadline).foregroundStyle(.secondary)
                    Text(Fmt.rupees(there)).font(.system(.body, weight: .semibold)).privacySensitive()
                }
            }
            .padding(.top, 12)
        }
        .onScrollVisibilityChange(threshold: 0.4) { v in
            if v && !grown { withAnimation(Motion.reveal) { grown = true } }
        }
    }
}

struct LinesSection: View {
    let story: ChapterStory
    let n: Int
    @State private var grown = false
    var body: some View {
        let top: Double = story.lines.map { max($0.amount, $0.planned) }.max() ?? 1
        let ink: Color = story.chapter.inkColor
        VStack(alignment: .leading, spacing: 0) {
            HStack(alignment: .firstTextBaseline) {
                PartTitle(n: n, text: story.linesTitle)
                Spacer()
                if story.planned {
                    HStack(spacing: 6) {
                        Rectangle().fill(Color.primary).frame(width: 2, height: 12)
                        Text("planned").font(.caption)
                    }
                    .foregroundStyle(.secondary)
                }
            }
            VStack(spacing: 18) {
                ForEach(Array(story.lines.enumerated()), id: \.element.id) { i, l in
                    LineRow(line: l, top: top, planned: story.planned, ink: ink, grown: grown)
                        .animation(Motion.reveal.delay(Motion.stagger(i)), value: grown)
                }
            }
            .padding(.top, 18)
        }
        .onScrollVisibilityChange(threshold: 0.25) { v in
            if v && !grown { grown = true }
        }
    }
}

struct LineRow: View {
    let line: ChapterStory.Line
    let top: Double
    let planned: Bool
    let ink: Color
    let grown: Bool
    var body: some View {
        let hasPlan: Bool = planned && line.planned > 0
        let over: Bool = hasPlan && line.amount > line.planned
        let diff: Double = abs(line.amount - line.planned)
        let note: String = hasPlan ? (line.amount == 0 ? "not yet" : Fmt.words(diff) + (over ? " over" : " under")) : line.share
        let noteInk: Color = hasPlan ? (over ? Color(hex: "#C2412D") : Color(hex: "#2E7D4F")) : Color.secondary
        VStack(alignment: .leading, spacing: 8) {
            HStack(alignment: .firstTextBaseline) {
                Text(line.name).font(.system(.subheadline))
                Spacer(minLength: 8)
                Text(note).font(.system(.caption, weight: hasPlan ? .semibold : .regular)).foregroundStyle(line.amount == 0 ? Color.secondary : noteInk)
                Text(Fmt.rupees(line.amount)).font(.system(.subheadline, weight: .semibold)).privacySensitive()
            }
            GeometryReader { g in
                let w: CGFloat = g.size.width
                let full: CGFloat = w * CGFloat(line.amount / max(1, top)) * (grown ? 1 : 0)
                ZStack(alignment: .leading) {
                    Capsule().fill(Color.primary.opacity(0.07))
                    if hasPlan {
                        Capsule().fill(over ? Color(hex: "#C2412D") : Color.primary).frame(width: full)
                        Rectangle().fill(Color.primary).frame(width: 2, height: 12).offset(x: w * CGFloat(line.planned / max(1, top)) - 1)
                    } else {
                        let aheadShare: CGFloat = CGFloat(line.ahead / max(1, line.amount))
                        HStack(spacing: 0) {
                            Capsule().fill(Color.primary).frame(width: full * aheadShare)
                            Capsule().fill(ink).frame(width: full * (1 - aheadShare))
                        }
                    }
                }
            }
            .frame(height: 4)
        }
    }
}

struct BarsSection: View {
    let story: ChapterStory
    let n: Int
    @State private var sel: Int
    @State private var grown = false
    static let H: CGFloat = 120

    init(story: ChapterStory, n: Int) {
        self.story = story
        self.n = n
        let best: Int = story.bars.indices.max(by: { story.bars[$0].value < story.bars[$1].value }) ?? 0
        _sel = State(initialValue: best)
    }

    var body: some View {
        let top: Double = max(1, story.bars.map(\.value).max() ?? 1)
        let b: ChapterStory.Bar = story.bars[min(sel, story.bars.count - 1)]
        let count: Int = story.bars.count
        let ink: Color = story.chapter.inkColor
        VStack(alignment: .leading, spacing: 0) {
            PartTitle(n: n, text: story.barsTitle)
            Text(b.title).font(.subheadline).foregroundStyle(.secondary).padding(.top, 8).contentTransition(.opacity)
            HStack(alignment: .firstTextBaseline, spacing: 8) {
                Text(Fmt.rupees(b.value)).font(.system(.title2, weight: .semibold))
                    .contentTransition(.numericText(value: b.value)).privacySensitive()
                Text(b.note).font(.subheadline).foregroundStyle(.secondary).lineLimit(1).contentTransition(.opacity)
            }
            .padding(.top, 2)
            GeometryReader { g in
                let gap: CGFloat = count > 16 ? 3 : count > 8 ? 5 : 12
                let unit: CGFloat = max(2, (g.size.width - gap * CGFloat(count - 1)) / CGFloat(max(1, count)))
                VStack(alignment: .leading, spacing: 8) {
                    ZStack(alignment: .topLeading) {
                        if story.average > 0 {
                            let y: CGFloat = Self.H - CGFloat(story.average / top) * Self.H
                            Path { p in p.move(to: CGPoint(x: 0, y: y)); p.addLine(to: CGPoint(x: g.size.width, y: y)) }
                                .stroke(Color.secondary.opacity(0.6), style: StrokeStyle(lineWidth: 1, dash: [3, 3]))
                            Text("avg " + Fmt.rupees(story.average)).font(.system(.caption2, weight: .medium)).foregroundStyle(.secondary)
                                .frame(width: g.size.width, alignment: .trailing)
                                .offset(y: y - 15)
                        }
                        HStack(alignment: .bottom, spacing: gap) {
                            ForEach(Array(story.bars.enumerated()), id: \.element.id) { i, bar in
                                BarColumn(bar: bar, on: i == sel, ink: ink, height: grown ? CGFloat(bar.value / top) * Self.H : 4, width: unit, showLabel: count <= 16 || i % 3 == 0) {
                                    withAnimation(Motion.base) { sel = i }
                                }
                                .animation(Motion.reveal.delay(Motion.stagger(i)), value: grown)
                            }
                        }
                        .frame(height: Self.H + 20, alignment: .bottom)
                    }
                    if !story.bands.isEmpty {
                        HStack(spacing: gap) {
                            ForEach(story.bands) { band in
                                VStack(alignment: .leading, spacing: 5) {
                                    Rectangle().fill(Color.primary).frame(height: 1.5)
                                    Text(band.name).font(.system(.caption, weight: .semibold))
                                }
                                .frame(width: unit * CGFloat(band.span) + gap * CGFloat(band.span - 1))
                            }
                        }
                    }
                }
            }
            .frame(height: Self.H + 20 + (story.bands.isEmpty ? 0 : 30))
            .padding(.top, 16)
        }
        .sensoryFeedback(.selection, trigger: sel)
        .onScrollVisibilityChange(threshold: 0.3) { v in
            if v && !grown { grown = true }
        }
    }
}

struct BarColumn: View {
    let bar: ChapterStory.Bar
    let on: Bool
    let ink: Color
    let height: CGFloat
    let width: CGFloat
    let showLabel: Bool
    let tap: () -> Void
    var body: some View {
        Button(action: tap) {
            VStack(spacing: 6) {
                RoundedRectangle(cornerRadius: min(6, width / 3), style: .continuous)
                    .fill(on ? ink : Color.primary.opacity(0.14))
                    .frame(width: width, height: max(4, height))
                Text(showLabel ? bar.label : " ")
                    .font(.system(.caption2, weight: .semibold))
                    .foregroundStyle(on ? Color.primary : Color.secondary)
                    .lineLimit(1)
                    .fixedSize()
            }
            .frame(width: width)
            .contentShape(Rectangle())
        }
        .buttonStyle(.press)
        .spokenFigures(bar.title + ", " + Fmt.rupees(bar.value), hidden: bar.title)
    }
}

/// where the days went: each place, its days, what it cost
struct PlacesList: View {
    let places: [ChapterStory.Place]
    let ink: Color
    @State private var grown = false
    var body: some View {
        let top: Double = max(1, places.map(\.amount).max() ?? 1)
        VStack(spacing: 0) {
            ForEach(Array(places.enumerated()), id: \.element.id) { i, p in
                HStack(spacing: 14) {
                    Text(String(i + 1))
                        .font(.system(size: 13, weight: .bold, design: .rounded))
                        .foregroundStyle(ink)
                        .frame(width: 28, height: 28)
                        .overlay(Circle().strokeBorder(ink.opacity(0.5), lineWidth: 1.2))
                    VStack(alignment: .leading, spacing: 6) {
                        HStack(alignment: .firstTextBaseline) {
                            Text(p.name).font(.system(.callout, design: .serif, weight: .semibold))
                            Text(p.days == 1 ? "1 day" : String(p.days) + " days").font(.footnote).foregroundStyle(.secondary)
                            Spacer()
                            Text(Fmt.rupees(p.amount)).font(.system(.subheadline, weight: .semibold)).privacySensitive()
                        }
                        GeometryReader { g in
                            Capsule().fill(ink.opacity(0.85)).frame(width: grown ? g.size.width * CGFloat(p.amount / top) : 0)
                        }
                        .frame(height: 4)
                    }
                }
                .padding(.vertical, 12)
                .animation(Motion.reveal.delay(Motion.stagger(i)), value: grown)
                if i < places.count - 1 { Rule() }
            }
        }
        .onScrollVisibilityChange(threshold: 0.3) { v in if v && !grown { grown = true } }
    }
}

struct PayList: View {
    let rows: [ChapterStory.Pay]
    var body: some View {
        VStack(spacing: 0) {
            ForEach(Array(rows.enumerated()), id: \.element.id) { i, r in
                HStack(spacing: 14) {
                    KindTile(kind: r.kind, size: 44)
                    VStack(alignment: .leading, spacing: 1) {
                        Text(r.name).font(.system(.subheadline, weight: .semibold)).oneLineUnlessLarge()
                        Text(r.note).font(.footnote).foregroundStyle(.secondary)
                    }
                    Spacer(minLength: 8)
                    Text(r.amount).font(.system(.subheadline, weight: .semibold)).privacySensitive()
                }
                .padding(.vertical, 13)
                if i < rows.count - 1 { Rule() }
            }
        }
    }
}

/// the month it fell in, with it and without it, beside an ordinary month
struct WithWithout: View {
    let story: ChapterStory
    @State private var grown = false
    var body: some View {
        let rows: [(String, Double, Color)] = Self.rows(story)
        let top: Double = max(1, rows.map(\.1).max() ?? 1)
        VStack(alignment: .leading, spacing: 14) {
            Text(story.month).font(.subheadline.weight(.semibold)).foregroundStyle(.secondary)
            ForEach(Array(rows.enumerated()), id: \.offset) { i, r in
                VStack(alignment: .leading, spacing: 6) {
                    HStack {
                        Text(r.0).font(.system(.subheadline))
                        Spacer()
                        Text(Fmt.rupees(r.1)).font(.system(.subheadline, weight: .semibold)).privacySensitive()
                    }
                    GeometryReader { g in
                        Capsule().fill(r.2).frame(width: grown ? max(6, g.size.width * CGFloat(r.1 / top)) : 6)
                    }
                    .frame(height: 8)
                }
                .animation(Motion.reveal.delay(Motion.stagger(i)), value: grown)
            }
            if !story.footnote.isEmpty {
                Text(story.footnote).font(.subheadline).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                    .padding(.top, 2)
            }
        }
        .onScrollVisibilityChange(threshold: 0.3) { v in if v && !grown { grown = true } }
    }
    static func rows(_ st: ChapterStory) -> [(String, Double, Color)] {
        var out: [(String, Double, Color)] = [
            ("With " + st.chapter.title, st.withIt, st.chapter.inkColor),
            ("Without it", st.without, Color.primary)
        ]
        if st.usual > 0 { out.append(("An ordinary month", st.usual, Color.secondary.opacity(0.45))) }
        return out
    }
}

/// the first payments of a sample, and the way to all of them
struct SamplePayments: View {
    @Environment(Store.self) private var store
    @Environment(\.chapterRouter) private var router
    let story: ChapterStory
    var body: some View {
        let groups: [PayGroup] = ChapterSamples.payments(story.chapter.id)
        VStack(alignment: .leading, spacing: 0) {
            ForEach(Array(groups.prefix(2))) { g in
                PayGroupView(g: g, more: false)
            }
            Button {
                if let router { router.push(.chapterPayments(story.chapter.id)) } else { store.push(.chapterPayments(story.chapter.id)) }
            } label: {
                Text("See all " + String(max(story.payments, groups.reduce(0) { $0 + $1.rows.count })) + " payments")
                    .font(.system(.callout, weight: .semibold))
                    .foregroundStyle(Color.primary)
                    .frame(maxWidth: .infinity)
                    .frame(minHeight: 50)
                    .background(Color(uiColor: .secondarySystemFill), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
            }
            .buttonStyle(PulsePress())
            .padding(.top, 20)
        }
    }
}

/// one of your own: kosh's guesses to keep, bookings that might belong, then its payments day by day
struct RealPayments: View {
    @Environment(Store.self) private var store
    let trip: TripInfo
    @State private var all = false
    var body: some View {
        let groups: [DayGroup] = TripPage.byDay(store.tripRows(trip.id))
        let shown: [DayGroup] = all ? groups : Array(groups.prefix(6))
        VStack(alignment: .leading, spacing: 16) {
            if trip.guesses > 0 { TripGuessNote(trip: trip) }
            TripMaybe(trip: trip)
            Button { store.showInLedger(trip.id) } label: {
                HStack(spacing: 10) {
                    Image(systemName: "list.bullet.rectangle.portrait")
                    Text("Open in Transactions")
                    Spacer()
                    Text(trip.n == 1 ? "1 payment" : String(trip.n) + " payments").foregroundStyle(.secondary)
                    Image(systemName: "chevron.right").font(.footnote.weight(.semibold)).foregroundStyle(.tertiary)
                }
                .font(.system(.subheadline, weight: .semibold))
                .foregroundStyle(Color.primary)
                .padding(.horizontal, 16)
                .frame(minHeight: 50)
                .background(Color(uiColor: .secondarySystemFill), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
            }
            .buttonStyle(PulsePress())
            if groups.isEmpty {
                Text(trip.auto ? "Nothing yet. What's spent on its days comes in on its own; add anything else from a payment's sheet, under Chapter." : "Nothing yet. Add payments from their sheets, under Chapter.")
                    .font(.subheadline).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            }
            ForEach(shown) { g in
                VStack(alignment: .leading, spacing: 10) {
                    HStack {
                        Text(TripPayments.dayTitle(g.day, trip: trip)).font(.subheadline.weight(.semibold))
                        Spacer()
                        Text(Fmt.rupees(g.total)).font(.subheadline.weight(.semibold)).monospacedDigit().foregroundStyle(.secondary).privacySensitive()
                    }
                    VStack(spacing: 14) {
                        ForEach(g.items) { t in
                            TxRow(t: t, when: t.t.isEmpty ? "" : Day.time12(t.t), showTrip: false)
                                .contextMenu {
                                    Button(role: .destructive) { store.setTrip(t.id, "none") } label: {
                                        Label("Take out of " + trip.name, systemImage: "minus.circle")
                                    }
                                }
                        }
                    }
                    .card(14)
                }
            }
            if groups.count > shown.count {
                Button { withAnimation(Motion.open) { all = true } } label: {
                    Text("Show all " + String(groups.count) + " days").font(.subheadline.weight(.semibold)).underline()
                }
                .buttonStyle(.press)
            }
        }
    }
}

struct Rule: View {
    var body: some View { Rectangle().fill(Color.primary.opacity(0.09)).frame(height: 0.5) }
}

/// a section heading, as the rest of Chapters has them
struct SectionTitle: View {
    let text: String
    var body: some View { Text(text).font(.system(.title2, design: .serif, weight: .semibold)) }
}

/// comes up into place the first time it's scrolled to
struct Reveal: ViewModifier {
    var delay: Double = 0
    @State private var seen = false
    @Environment(\.accessibilityReduceMotion) private var still
    func body(content: Content) -> some View {
        content
            .opacity(seen || still ? 1 : 0)
            .offset(y: seen || still ? 0 : 22)
            .onScrollVisibilityChange(threshold: 0.15) { v in
                if v && !seen { withAnimation(Motion.reveal.delay(delay)) { seen = true } }
            }
    }
}

struct StatCell: View {
    let value: String
    let label: String
    let number: Double
    var body: some View {
        VStack(spacing: 2) {
            Text(value).font(.system(.title3, weight: .semibold)).tracking(-0.3)
                .contentTransition(.numericText(value: number))
                .privacySensitive()
            Text(label).font(.system(.caption))
        }
        .frame(maxWidth: .infinity)
    }
}

struct PeopleRow: View {
    let story: ChapterStory
    let open: () -> Void
    var body: some View {
        Button { if story.groupLink { open() } } label: {
            HStack(spacing: 16) {
                HStack(spacing: -12) {
                    ForEach(story.people) { a in
                        Text(a.initial)
                            .font(.system(size: a.initial.count > 1 ? 12 : 14, weight: .bold))
                            .foregroundStyle(Color(hex: a.fg))
                            .frame(width: 40, height: 40)
                            .background(Color(hex: a.color), in: Circle())
                            .overlay(Circle().stroke(Color(uiColor: .systemBackground), lineWidth: 2.5))
                    }
                }
                VStack(alignment: .leading, spacing: 2) {
                    Text(story.peopleTitle).font(.system(.callout, weight: .semibold)).foregroundStyle(Color.primary)
                    Text(story.peopleSub).font(.subheadline).foregroundStyle(.secondary).privacySensitive()
                }
                Spacer(minLength: 8)
                if story.groupLink {
                    Image(systemName: "chevron.right").font(.system(.subheadline, weight: .semibold)).foregroundStyle(Color.primary)
                }
            }
            .padding(.vertical, 14)
            .contentShape(Rectangle())
        }
        .buttonStyle(PulsePress())
    }
}

struct FeatureRow: View {
    let f: ChapterStory.Feature
    var body: some View {
        HStack(alignment: .top, spacing: 20) {
            Image(systemName: f.symbol)
                .font(.system(size: 24, weight: .light))
                .frame(width: 28)
            VStack(alignment: .leading, spacing: 3) {
                Text(f.title).font(.system(.callout, weight: .semibold)).privacySensitive()
                Text(f.sub).font(.subheadline).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            }
        }
    }
}

// MARK: one of your own, told from its payments

extension Store {
    func chapterStory(_ id: String) -> ChapterStory {
        if let t = trip(id) { return realStory(t) }
        return ChapterSamples.story(id)
    }

    /// in the demo, the samples only: never one of your trips, even one that happens to share an id
    func chapterStory(_ id: String, samplesOnly: Bool) -> ChapterStory {
        samplesOnly ? ChapterSamples.story(id) : chapterStory(id)
    }

    func realStory(_ t: TripInfo) -> ChapterStory {
        let ch: Chapter = chapterItem(t)
        var st = ChapterStory(chapter: ch)
        st.trip = t.id
        let mine: [Chapter] = chapterItems(samples: false).sorted { $0.pin < $1.pin }
        st.number = (mine.firstIndex { $0.id == t.id } ?? 0) + 1
        st.place = t.note
        st.spent = t.total
        st.budget = t.budget
        if t.before > 0 && t.before < t.total {
            st.ahead = t.before
            st.there = t.total - t.before
        }
        let sum: Double = max(1, t.cats.reduce(0) { $0 + $1.v })
        st.lines = t.cats.map { ChapterStory.Line(name: $0.cat, amount: $0.v, share: String(Int(safe: ($0.v / sum * 100).rounded())) + "%") }

        let rows: [Txn] = tripRows(t.id).filter { $0.sp || $0.ev == true }
        let ownDays = t.from.isEmpty ? t.byDay : t.byDay.filter { $0.d >= t.from }
        if ownDays.count > 1 && ownDays.count <= 45 {
            st.barsTitle = "Day by day"
            st.bars = ownDays.map { d in
                ChapterStory.Bar(label: Day.fmt(d.d, "d"), title: Day.fmt(d.d, "EEE d MMM"), value: d.v, note: Self.topName(rows, d.d))
            }
            let dayTotal: Double = ownDays.reduce(0) { $0 + $1.v }
            st.average = (dayTotal / Double(ownDays.count)).rounded()
        } else if t.months.count > 1 {
            st.barsTitle = "Month by month"
            st.bars = t.months.map { m in
                ChapterStory.Bar(label: Day.monthShort(m.m), title: Day.fmt(m.m + "-01", "MMMM yyyy"), value: m.v, note: "")
            }
        }
        st.topIDs = Array(rows.sorted { $0.a > $1.a }.prefix(5).map(\.id))

        var figs: [ChapterStory.Figure] = [.init(value: Fmt.rupees(t.total), label: t.state == "now" ? "so far" : t.state == "soon" ? "paid ahead" : "spent")]
        if t.days > 1 { figs.append(.init(value: String(t.days), label: "days")) }
        if t.days > 1 && t.total > 0 {
            figs.append(.init(value: Fmt.rupees(((t.total - t.before) / Double(t.days)).rounded()), label: "a day there"))
        }
        figs.append(.init(value: String(t.n), label: "payments"))
        if t.rx > 0 { figs.append(.init(value: Fmt.words(t.rx), label: "to come back")) }
        st.figures = figs

        var feats: [ChapterStory.Feature] = []
        if t.guesses > 0 {
            feats.append(.init(symbol: "sparkles", title: (t.guesses == 1 ? "1 payment" : String(t.guesses) + " payments") + " put in by their dates",
                               sub: "kosh's guess. Press and hold any that wasn't part of it, below, to take it out."))
        }
        if t.before > 0 {
            feats.append(.init(symbol: "ticket", title: Fmt.rupees(t.before) + " paid before it began", sub: "Bookings made ahead, counted in the chapter."))
        }
        if t.rx > 0 {
            feats.append(.init(symbol: "arrow.uturn.backward", title: Fmt.rupees(t.rx) + " coming back", sub: "Refunds kosh is still waiting for."))
        }
        if let top = t.cats.first, t.total > 0 {
            feats.append(.init(symbol: top.sym, title: top.cat + " took the most", sub: Fmt.rupees(top.v) + ", " + String(Int(safe: (top.v / t.total * 100).rounded())) + "% of it."))
        }
        st.features = feats

        if t.people.count > 1 {
            let palette: [String] = ["#3D63C9", "#E9B04A", "#4E9A72", "#7A1F33", "#5E5CE6"]
            var avatars: [ChapterStory.Avatar] = []
            for (i, p) in t.people.enumerated() {
                let name: String = ownerName(p.o)
                avatars.append(ChapterStory.Avatar(initial: name == "You" ? "You" : String(name.prefix(1)), color: palette[i % palette.count], fg: "#FFFFFF"))
            }
            st.people = avatars
            st.peopleTitle = "Whose money"
            st.peopleSub = t.people.map { ownerName($0.o) + " " + Fmt.words($0.v) }.joined(separator: " · ")
        }

        if let big = t.months.max(by: { $0.v < $1.v }), let mo = month(big.m) {
            let spentThen: Double = self.total(of: mo)
            if everyday {
                st.without = spentThen
                st.withIt = spentThen + big.v
            } else {
                st.withIt = spentThen
                st.without = max(0, spentThen - big.v)
            }
            st.month = Day.fmt(big.m + "-01", "MMMM yyyy")
            st.usual = ordinaryMonth(except: big.m)
            st.footnote = Day.monthName(big.m) + " came to " + Fmt.rupees(st.withIt) + " with " + t.name + ", " + Fmt.rupees(st.without) + " without it."
        }
        st.payments = t.n
        st.share = t.name + ", " + ch.dates + ": " + Fmt.rupees(t.total) + ". Saved in kosh."
        return st
    }

    /// the biggest payment's name on a day
    static func topName(_ rows: [Txn], _ day: String) -> String {
        rows.filter { ($0.od ?? $0.d) == day }.max { $0.a < $1.a }?.m ?? ""
    }

    /// an ordinary month lately: the last six finished months, without what went on chapters
    func ordinaryMonth(except m: String) -> Double {
        let cm: String = snap.cm
        var xs: [Double] = []
        for mo in snap.months where mo.m < cm && mo.m != m {
            let share: TripShare = tripShare(mo.m)
            xs.append(max(0, total(of: mo) - share.inn))
            if xs.count == 6 { break }
        }
        if xs.isEmpty { return 0 }
        return (xs.reduce(0, +) / Double(xs.count)).rounded()
    }
}

// MARK: every payment in a sample

struct ChapterPayments: View {
    @Environment(Store.self) private var store
    @Environment(\.chapterRouter) private var router
    let id: String
    @State private var filter: String = "all"
    @Namespace private var chips

    var body: some View {
        let st: ChapterStory = store.chapterStory(id, samplesOnly: router?.samplesOnly == true)
        let all: [PayGroup] = ChapterSamples.payments(id)
        let groups: [PayGroup] = all.filter { filter == "all" || $0.key == filter }
        ScrollView {
            VStack(alignment: .leading, spacing: 0) {
                Text(st.chapter.title).font(.subheadline).foregroundStyle(.secondary)
                Text("Payments").font(.system(.largeTitle, design: .serif, weight: .semibold)).padding(.top, 2)
                Text("\(st.payments) payments · \(Fmt.rupees(st.spent))\(id == "japan" ? " · in yen where it was yen" : "")")
                    .font(.system(.subheadline)).foregroundStyle(.secondary).padding(.top, 4).privacySensitive()

                ScrollView(.horizontal) {
                    HStack(spacing: 8) {
                        ForEach(ChapterSamples.filters(id), id: \.0) { f in
                            ChipButton(label: f.1, count: f.2, on: filter == f.0, ns: chips) {
                                withAnimation(Motion.large) { filter = f.0 }
                            }
                        }
                    }
                    .padding(.vertical, 4)
                }
                .scrollIndicators(.hidden)
                .padding(.top, 16)

                ForEach(groups) { g in
                    PayGroupView(g: g, more: true)
                        .transition(.asymmetric(insertion: .move(edge: .bottom).combined(with: .opacity), removal: .opacity))
                }
                Text("A sample. In your own chapters, press and hold a payment to take it out, or open them all in Transactions. Its category never changes.")
                    .font(.footnote).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                    .padding(.top, 24)
            }
            .padding(.horizontal, 24)
            .padding(.bottom, 30)
        }
        .scrollIndicators(.hidden)
        .navigationTitle("")
        .navigationBarTitleDisplayMode(.inline)
        .sensoryFeedback(.selection, trigger: filter)
    }
}

struct ChipButton: View {
    let label: String
    let count: String
    let on: Bool
    let ns: Namespace.ID
    let tap: () -> Void
    var body: some View {
        Button(action: tap) {
            HStack(spacing: 6) {
                Text(label).font(.system(.footnote, weight: .semibold))
                Text(count).font(.system(.footnote)).opacity(0.7)
            }
            .foregroundStyle(on ? Color(uiColor: .systemBackground) : Color.primary)
            .padding(.horizontal, 16)
            .frame(minHeight: 36)
            .background {
                if on {
                    Capsule().fill(Color.primary).matchedGeometryEffect(id: "chip", in: ns)
                } else {
                    Capsule().strokeBorder(Color.primary.opacity(0.16), lineWidth: 1)
                }
            }
        }
        .buttonStyle(.press)
        .accessibilityAddTraits(on ? .isSelected : [])
    }
}

struct PayGroupView: View {
    let g: PayGroup
    var more: Bool = true
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack(alignment: .firstTextBaseline) {
                Text(g.title).font(.system(.body, weight: .semibold))
                if !g.place.isEmpty { Text("· " + g.place).font(.subheadline).foregroundStyle(.secondary) }
                Spacer()
                Text(g.total).font(.system(.subheadline, weight: .semibold)).privacySensitive()
            }
            .padding(.top, 22)
            .padding(.bottom, 4)
            ForEach(g.rows) { r in
                HStack(spacing: 14) {
                    KindTile(kind: r.kind, size: 48)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(r.name).font(.system(.subheadline, weight: .semibold)).oneLineUnlessLarge()
                        Text(r.sub).font(.footnote).foregroundStyle(.secondary).lineLimit(1)
                    }
                    Spacer(minLength: 8)
                    VStack(alignment: .trailing, spacing: 1) {
                        Text(r.amount).font(.system(.subheadline, weight: .semibold)).privacySensitive()
                        if !r.fx.isEmpty { Text(r.fx).font(.footnote).foregroundStyle(.secondary).privacySensitive() }
                    }
                }
                .padding(.vertical, 12)
                .overlay(alignment: .bottom) { Rule() }
            }
            if more && !g.more.isEmpty {
                Text(g.more).font(.subheadline.weight(.semibold)).underline().padding(.top, 12)
            }
        }
    }
}

// MARK: the group pass

struct ChapterGroupPage: View {
    @Environment(Store.self) private var store
    @Environment(\.chapterRouter) private var router
    let id: String
    @State private var byDays = false
    @State private var copied = false
    @State private var qr: UIImage? = nil
    @Namespace private var seg

    var body: some View {
        let st: ChapterStory = store.chapterStory(id, samplesOnly: router?.samplesOnly == true)
        let owed: [(String, Double)] = byDays ? ChapterSamples.owedByDays : ChapterSamples.owedEqual
        let back: Double = owed.reduce(0) { $0 + $1.1 }
        ScrollView {
            VStack(alignment: .leading, spacing: 0) {
                GroupPassCard(story: st, qr: qr, copied: $copied)
                SectionTitle(text: "Who's on it").padding(.top, 34)
                VStack(spacing: 0) {
                    ForEach(ChapterSamples.members) { m in
                        HStack(spacing: 14) {
                            Text(String(m.name.prefix(1)))
                                .font(.system(size: 15, weight: .bold))
                                .foregroundStyle(Color(hex: m.fg))
                                .frame(width: 44, height: 44)
                                .background(Color(hex: m.color), in: Circle())
                            VStack(alignment: .leading, spacing: 1) {
                                Text(m.name).font(.system(.callout, weight: .semibold))
                                Text(m.state).font(.subheadline).foregroundStyle(.secondary)
                            }
                            Spacer()
                            VStack(alignment: .trailing, spacing: 1) {
                                Text(m.paid).font(.system(.subheadline, weight: .semibold)).privacySensitive()
                                Text("paid").font(.caption).foregroundStyle(.secondary)
                            }
                        }
                        .padding(.vertical, 12)
                        .overlay(alignment: .bottom) { Rule() }
                        .modifier(Reveal())
                    }
                    ShareLink(item: "Join my chapter on kosh with the code " + ChapterSamples.groupCode + ".") {
                        HStack(spacing: 14) {
                            Image(systemName: "plus").font(.system(size: 16, weight: .semibold))
                                .frame(width: 44, height: 44)
                                .overlay(Circle().strokeBorder(Color.secondary, style: StrokeStyle(lineWidth: 1.5, dash: [4, 3])))
                            Text("Invite someone").font(.system(.callout, weight: .semibold)).underline()
                            Spacer()
                        }
                        .foregroundStyle(Color.primary)
                        .padding(.vertical, 12)
                    }
                }
                .padding(.top, 6)

                Rule().padding(.top, 14)
                SectionTitle(text: "Settle up").padding(.top, 30)
                HStack(spacing: 4) {
                    SegButton(title: "Split equally", on: !byDays, ns: seg) { withAnimation(Motion.large) { byDays = false } }
                    SegButton(title: "By days there", on: byDays, ns: seg) { withAnimation(Motion.large) { byDays = true } }
                }
                .padding(4)
                .background(Color(uiColor: .secondarySystemFill), in: Capsule())
                .padding(.top, 16)
                HStack(spacing: 0) {
                    StatCell(value: "₹7.32L", label: "together", number: 732400)
                    Rectangle().fill(Color.primary.opacity(0.14)).frame(width: 0.5, height: 40)
                    StatCell(value: byDays ? "₹2.03L" : "₹1.83L", label: byDays ? "your share" : "each", number: byDays ? 202600 : 183100)
                    Rectangle().fill(Color.primary.opacity(0.14)).frame(width: 0.5, height: 40)
                    StatCell(value: Fmt.words(back), label: "to you", number: back)
                }
                .padding(.top, 22)
                .animation(Motion.base, value: byDays)
                VStack(spacing: 0) {
                    ForEach(owed, id: \.0) { o in
                        SettleRow(name: o.0, amount: o.1, chapter: st.chapter.title)
                            .transition(.opacity)
                    }
                }
                .padding(.top, 12)
                .animation(Motion.large, value: byDays)

                Rule().padding(.top, 22)
                VStack(alignment: .leading, spacing: 22) {
                    FeatureRow(f: .init(symbol: "eye", title: "Only the chapter is shared", sub: "What each person paid on it, by kind and by day, from their own kosh."))
                    FeatureRow(f: .init(symbol: "lock", title: "Nothing else leaves your phone", sub: "No merchants, no accounts, nothing outside its days."))
                    FeatureRow(f: .init(symbol: "rectangle.portrait.and.arrow.right", title: "Leave any time", sub: "Your numbers leave with you."))
                }
                .padding(.top, 28)
                .modifier(Reveal())
            }
            .padding(.horizontal, 24)
            .padding(.bottom, 30)
        }
        .scrollIndicators(.hidden)
        .navigationTitle("Group pass")
        .navigationBarTitleDisplayMode(.inline)
        .sensoryFeedback(.selection, trigger: byDays)
        .onAppear { if qr == nil { qr = QRMaker.image("kosh://join/" + ChapterSamples.groupCode) } }
    }
}

struct GroupPassCard: View {
    let story: ChapterStory
    let qr: UIImage?
    @Binding var copied: Bool
    @State private var shown = false
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            Text(story.chapter.title).font(.system(.title3, design: .serif, weight: .semibold)).padding(.trailing, 90)
            Text(story.chapter.dates + " · " + story.who).font(.subheadline).foregroundStyle(.secondary).padding(.top, 4)
            HStack {
                Spacer()
                ZStack {
                    RoundedRectangle(cornerRadius: 22, style: .continuous).fill(Color.white)
                    if let qr {
                        Image(uiImage: qr).interpolation(.none).resizable().scaledToFit().padding(16)
                    }
                }
                .frame(width: 204, height: 204)
                .scaleEffect(shown ? 1 : 0.85)
                .opacity(shown ? 1 : 0)
                Spacer()
            }
            .padding(.top, 22)
            Text(ChapterSamples.groupCode.replacingOccurrences(of: "-", with: " · "))
                .font(.system(.footnote, design: .monospaced)).tracking(2)
                .foregroundStyle(.secondary)
                .frame(maxWidth: .infinity)
                .padding(.top, 14)
            Text("Scan in kosh to join. Only between kosh users.")
                .font(.subheadline)
                .frame(maxWidth: .infinity)
                .padding(.top, 6)
            HStack(spacing: 10) {
                ShareLink(item: "Join my chapter on kosh with the code " + ChapterSamples.groupCode + ".") {
                    Text("Share pass").font(.system(.subheadline, weight: .semibold))
                        .foregroundStyle(Color(uiColor: .systemBackground))
                        .frame(maxWidth: .infinity).frame(minHeight: 48)
                        .background(Color.primary, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                }
                .buttonStyle(PulsePress())
                Button {
                    UIPasteboard.general.string = ChapterSamples.groupCode
                    withAnimation(Motion.open) { copied = true }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.6) { withAnimation(Motion.open) { copied = false } }
                } label: {
                    Label(copied ? "Copied" : "Copy code", systemImage: copied ? "checkmark" : "doc.on.doc")
                        .font(.system(.subheadline, weight: .semibold))
                        .foregroundStyle(Color.primary)
                        .contentTransition(.symbolEffect(.replace))
                        .frame(maxWidth: .infinity).frame(minHeight: 48)
                        .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).strokeBorder(Color.primary, lineWidth: 1))
                }
                .buttonStyle(PulsePress())
                .sensoryFeedback(.success, trigger: copied) { _, now in now }
            }
            .padding(.top, 18)
        }
        .padding(24)
        .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 26, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 26, style: .continuous).strokeBorder(Color.primary.opacity(0.1), lineWidth: 1))
        .shadow(color: Color.black.opacity(0.08), radius: 16, y: 6)
        .overlay(alignment: .topTrailing) {
            LandingStamp(art: story.chapter.art, size: 92, rotation: 12, delay: 0.3).offset(x: 6, y: -6)
        }
        .padding(.top, 12)
        .onAppear { withAnimation(Motion.reveal.delay(0.1)) { shown = true } }
    }
}

struct SegButton: View {
    let title: String
    let on: Bool
    let ns: Namespace.ID
    let tap: () -> Void
    var body: some View {
        Button(action: tap) {
            Text(title)
                .font(.system(.footnote, weight: .semibold))
                .foregroundStyle(Color.primary)
                .frame(maxWidth: .infinity)
                .frame(minHeight: 36)
                .background {
                    if on {
                        Capsule().fill(Color(uiColor: .systemBackground))
                            .shadow(color: Color.black.opacity(0.12), radius: 3, y: 1)
                            .matchedGeometryEffect(id: "seg", in: ns)
                    }
                }
        }
        .buttonStyle(.press)
        .accessibilityAddTraits(on ? .isSelected : [])
    }
}

struct SettleRow: View {
    let name: String
    let amount: Double
    let chapter: String
    var body: some View {
        let m: GroupMember? = ChapterSamples.members.first { $0.name == name }
        HStack(spacing: 14) {
            Text(String(name.prefix(1)))
                .font(.system(size: 13, weight: .bold))
                .foregroundStyle(Color(hex: m?.fg ?? "#FFFFFF"))
                .frame(width: 36, height: 36)
                .background(Color(hex: m?.color ?? "#888888"), in: Circle())
            Text("\(Text(name).fontWeight(.semibold)) pays you")
                .font(.system(.subheadline))
            Spacer(minLength: 6)
            Text(Fmt.rupees(amount)).font(.system(.subheadline, weight: .semibold))
                .contentTransition(.numericText(value: amount)).privacySensitive()
            ShareLink(item: "Hi \(name), your share for \(chapter) comes to \(Fmt.rupees(amount)).") {
                Text("Request").font(.system(.footnote, weight: .semibold)).foregroundStyle(Color.primary)
                    .padding(.horizontal, 14).frame(minHeight: 34)
                    .overlay(Capsule().strokeBorder(Color.primary, lineWidth: 1))
            }
            .buttonStyle(PulsePress())
        }
        .padding(.vertical, 12)
        .overlay(alignment: .bottom) { Rule() }
    }
}
