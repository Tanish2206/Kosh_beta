import SwiftUI

// MARK: - When each kind's figures are from
//
// (The Portfolio overview's class cards lived here until Wealth's redesign, 1 Nov 2026: WealthHome draws what it's
// in. What stays is the words for when a kind's figures are from, which Holdings and the funds page read.)

extension Store {
    /// when a kind's figures are from: "Prices of 10 Oct · AMFI" when the day's prices valued them (and how many
    /// are still at their statement's date), else "Updated 3 Oct · from your CAS", the span when its readings are
    /// far apart; and whether it's gone stale (more than 40 days old)
    func classUpdated(_ key: String, _ p: Person) -> (line: String, stale: Bool)? {
        guard var u = classUpdatedBase(key, p) else { return nil }
        // carried on from their statements by the trades and allotments mailed since
        let moved: Int = holdings(p).filter { (h: Holding) -> Bool in h.cls == key && h.roll != nil }.count
        if moved > 0 { u.line += " · " + String(moved) + " updated from mail since" }
        return u
    }

    func classUpdatedBase(_ key: String, _ p: Person) -> (line: String, stale: Bool)? {
        let today: String = snap.today
        if let k = snap.holdAsOf?[p.rawValue]?[key], k.n > 0, !k.pd.isEmpty {
            var line: String = "Prices of " + Self.dateWord(k.pd, today: today)
            if !k.px.isEmpty { line += " · " + k.px }
            // the rest, still at their statements' dates
            let rest: Int = k.of - k.n
            if rest > 0 && !k.st.isEmpty {
                var when: String = Self.dateWord(k.st, today: today)
                if !k.sl.isEmpty && Day.between(k.sl, k.st) > 7 { when = Self.dateWord(k.sl, today: today) + " – " + when }
                line += " · " + String(rest) + " as of " + when
            }
            let oldest: String = rest > 0 && !k.sl.isEmpty ? min(k.sl, k.pd) : k.pd
            return (line, Day.between(oldest, today) > 40)
        }
        let items: [Holding] = holdings(p).filter { $0.cls == key }
        var days: [String] = []
        var vias: Set<String> = []
        var old: Bool = false
        for h in items {
            if let a = h.asOf, a.count >= 10 { days.append(String(a.prefix(10))) }
            // (a deposit kosh follows has no statement day: its last word from the bank, as HoldingAsOf says it)
            else if let f = h.fresh?.d, f.count >= 10 { days.append(String(f.prefix(10))) }
            if let v = h.via, !v.isEmpty { vias.insert(v) }
            if h.fresh?.old == true { old = true }
        }
        guard let newest = days.max(), let oldest = days.min() else { return nil }
        // deposits grow at their rate between mails: only one the build calls old makes the line stale
        if key == "dep" {
            let when: String = Day.between(oldest, newest) > 7 ? Self.dayWord(oldest, today: today) + " – " + Self.dayWord(newest, today: today) : Self.dayWord(newest, today: today)
            return ("Last read " + when, old)
        }
        var line: String = "Updated " + Self.dayWord(newest, today: today)
        if Day.between(oldest, newest) > 7 { line = "Updated " + Self.dayWord(oldest, today: today) + " – " + Self.dayWord(newest, today: today) }
        if vias.count == 1, let v = vias.first {
            if v == "cas" { line += " · from your CAS" }
            if v == "epf" { line += " · from the EPFO passbook" }
        }
        return (line, Day.between(newest, today) > 40)
    }
    /// "31 Aug statement + 2 trades", "bought 18 Sep, after your statement"
    static func rollWords(_ r: Holding.Roll, cls: String, today: String) -> String {
        if r.made == true, r.last.count >= 10 { return "bought " + dateWord(r.last, today: today) + ", since your statement" }
        let noun: String = cls == "stk" ? "trade" : "transaction"
        let moves: String = String(r.n) + " " + noun + (r.n == 1 ? "" : "s")
        guard r.st.count >= 10 else { return "+ " + moves + " since the statement" }
        return dateWord(r.st, today: today) + " statement + " + moves
    }
    static func dayWord(_ d: String, today: String) -> String {
        if d == today { return "today" }
        if d == Day.add(today, -1) { return "yesterday" }
        return dateWord(d, today: today)
    }
    /// "10 Oct", or "10 Oct 2025" in another year
    static func dateWord(_ d: String, today: String) -> String {
        let sameYear: Bool = d.prefix(4) == today.prefix(4)
        return Day.fmt(d, sameYear ? "d MMM" : "d MMM yyyy")
    }
    /// a fund or share still at its statement's figure while others of its kind are at the day's price: "as of 31 Aug"
    func holdingAsOf(_ h: Holding) -> String? {
        // moved since its statement: the statement's day and what's come in the mail since
        if let r = h.roll { return Self.rollWords(r, cls: h.cls, today: snap.today) }
        guard h.px == nil, let a = h.asOf, a.count >= 10, (h.cls == "mf" || h.cls == "stk") else { return nil }
        guard (snap.holdAsOf?["family"]?[h.cls]?.n ?? 0) > 0 else { return nil }
        return "as of " + Self.dateWord(String(a.prefix(10)), today: snap.today)
    }
}

