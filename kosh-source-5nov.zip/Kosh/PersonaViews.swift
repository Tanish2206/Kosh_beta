import SwiftUI

// MARK: - Understanding you (Persona.swift; engine/21t-build-persona.js), in the black look (insights-obsidian, 1 Nov)
// Insights' card and the page. The page: "What kosh noticed" as two to four stat tiles; life events on a timeline with a
// coloured rail and dots (a change of where your parcels go asks "Is this a move?" inline; what kosh read folds under
// one "How kosh knows" row); trips as full-width cards, one a page, with dots; the people your money went to, ranked,
// each once with a bar scaled to the first; habits as four tiles. Every line keeps what it was read from and its dates.

/// Insights' section: a dark card that previews the page
struct PersonaSection: View {
    @Environment(Store.self) private var store
    var body: some View {
        if let p = store.persona {
            let stats: [PersonaWords.Stat] = PersonaWords.stats(p, money: Fmt.rupees, day: { Day.fmt($0, "d MMM yyyy") })
            ObsFeatureCard(caption: "Understanding you", title: "What your mail says about your life", chips: Self.chips(Array(stats.dropFirst())),
                           hint: "Opens what kosh understands about your life from your mail, each line with its evidence", tap: { store.push(.persona) }) {
                if let s = stats.first { PersonaSectionHero(s: s) }
            }
            .privacySensitive()
        } else {
            ObsFeatureCard(caption: "Understanding you", title: "What your mail says about your life", chips: [], tap: { store.push(.persona) }) {
                Text(PersonaWords.empty).font(.subheadline).foregroundStyle(Obsidian.ink2).fixedSize(horizontal: false, vertical: true)
            }
        }
    }
    static func chips(_ stats: [PersonaWords.Stat]) -> [ObsChip] {
        stats.prefix(3).map { (s: PersonaWords.Stat) -> ObsChip in ObsChip(id: s.id, label: s.label, value: s.value, tint: PersonaTint.stat(s.id)) }
    }
}

struct PersonaSectionHero: View {
    let s: PersonaWords.Stat
    var body: some View {
        HStack(alignment: .center, spacing: 12) {
            Image(systemName: s.sym).font(.headline).foregroundStyle(PersonaTint.stat(s.id))
                .frame(width: 40, height: 40).background(PersonaTint.stat(s.id).opacity(0.16), in: Circle())
            VStack(alignment: .leading, spacing: 2) {
                Text(s.value).font(.system(.title3, design: .rounded, weight: .semibold)).foregroundStyle(Obsidian.ink).lineLimit(2).minimumScaleFactor(0.7)
                Text(s.label + (s.sub.isEmpty ? "" : " · " + s.sub)).font(.footnote).foregroundStyle(Obsidian.ink2).fixedSize(horizontal: false, vertical: true)
            }
        }
    }
}

/// the colours the page gives its parts
enum PersonaTint {
    static func stat(_ id: String) -> Color {
        switch id {
        case "event": return InsightsInk.voice
        case "trips": return Obsidian.ulip
        case "people": return InsightsInk.family
        default: return Obsidian.savings
        }
    }
}

/// the page
struct PersonaPage: View {
    @Environment(Store.self) private var store
    var body: some View {
        ObsScroll(title: "Understanding you", inline: false) {
            if let p = store.persona {
                PersonaNoticed(p: p)
                PersonaTimeline(events: p.events ?? [])
                PersonaTrips(trips: p.trips ?? [])
                PersonaPeople(people: p.people ?? [])
                PersonaHabits(habits: p.habits ?? [])
                if let f = p.from, let t = p.to {
                    ObsNote(text: "Read from your mail and payments, " + Day.fmt(f, "d MMM yyyy") + " – " + Day.fmt(t, "d MMM yyyy") + ". Spending here is counted as Insights counts it; money sent to family is moved, not spent. kosh says only what the mail states: never anything about health, beliefs or relationships beyond your household list.")
                }
            } else {
                ObsEmpty(title: "Nothing to say yet", sym: "person.text.rectangle", text: PersonaWords.empty)
            }
        }
    }
}

/// "What kosh noticed": two to four tiles
struct PersonaNoticed: View {
    let p: Persona
    var body: some View {
        let stats: [PersonaWords.Stat] = PersonaWords.stats(p, money: Fmt.rupees, day: { Day.fmt($0, "d MMM yyyy") })
        if !stats.isEmpty {
            ObsHead(text: "What kosh noticed")
            ObsTileGrid {
                ForEach(Array(stats.enumerated()), id: \.element.id) { (pair: EnumeratedSequence<[PersonaWords.Stat]>.Element) in
                    ObsStatTile(label: pair.element.label, value: pair.element.value, sub: pair.element.sub, tint: PersonaTint.stat(pair.element.id), sym: pair.element.sym)
                        .obsArrive(pair.offset)
                }
            }
            .privacySensitive()
        }
    }
}

/// a line of evidence: what it was read from; tap for the mails
struct EvidenceRow: View {
    @Environment(Store.self) private var store
    let e: Persona.Evidence
    let type: String
    static func words(_ line: String) -> String {
        guard let c = line.first else { return line }
        return c.isNumber ? "From " + line : line
    }
    var body: some View {
        let mails: [String] = store.evidenceMails(e)
        Button {
            store.betaSheet = .source(SourceRef(title: "Where kosh read this", mails: mails, type: type))
        } label: {
            HStack(alignment: .firstTextBaseline, spacing: 8) {
                Image(systemName: "doc.text.magnifyingglass").font(.caption).foregroundStyle(Obsidian.ink3)
                Text(Self.words(e.line)).font(.footnote).foregroundStyle(Obsidian.ink2).multilineTextAlignment(.leading).fixedSize(horizontal: false, vertical: true)
                Spacer(minLength: 0)
            }
            .contentShape(Rectangle())
        }
        .buttonStyle(.press)
        .disabled(mails.isEmpty || store.live == nil)
        .privacySensitive()
    }
}

/// "How kosh knows ›": one row; the evidence opens under it (and closes quicker than it opened)
struct PersonaEvidence: View {
    let ev: [Persona.Evidence]
    let type: (Int) -> String
    @State private var open: Bool = false
    var body: some View {
        if !ev.isEmpty {
            VStack(alignment: .leading, spacing: 8) {
                Button { withAnimation(Motion.fold(!open)) { open.toggle() } } label: {
                    HStack(spacing: 6) {
                        Text("How kosh knows").font(.footnote.weight(.semibold)).foregroundStyle(InsightsInk.voice)
                        Image(systemName: "chevron.right").font(.caption2.weight(.bold)).foregroundStyle(InsightsInk.voice)
                            .rotationEffect(.degrees(open ? 90 : 0))
                        Spacer(minLength: 0)
                    }
                    .frame(minHeight: 32)
                    .contentShape(Rectangle())
                }
                .buttonStyle(.press)
                .accessibilityValue(open ? "Open" : "Closed")
                if open {
                    VStack(alignment: .leading, spacing: 8) {
                        ForEach(Array(ev.enumerated()), id: \.offset) { (pair: EnumeratedSequence<[Persona.Evidence]>.Element) in
                            EvidenceRow(e: pair.element, type: type(pair.offset))
                        }
                    }
                    .transition(.opacity.combined(with: .offset(y: -4)))
                }
            }
        }
    }
}

// MARK: life events

struct PersonaTimeline: View {
    let events: [Persona.Event]
    var body: some View {
        if !events.isEmpty {
            ObsHead(text: "Life events", trailing: String(events.count))
            VStack(alignment: .leading, spacing: 0) {
                ForEach(Array(events.enumerated()), id: \.element.id) { (pair: EnumeratedSequence<[Persona.Event]>.Element) in
                    PersonaEventRow(e: pair.element, last: pair.offset == events.count - 1,
                                    next: pair.offset + 1 < events.count ? InsightsInk.event(events[pair.offset + 1].k) : nil)
                        .obsArrive(pair.offset)
                }
            }
            .obsidianCard(24, padding: 18)
        }
    }
}

/// one event on the line: a dot in its colour on the rail, its date, title and what was seen; what was spent around it
/// when that says something; the move question inline; the evidence under one row
struct PersonaEventRow: View {
    @Environment(Store.self) private var store
    let e: Persona.Event
    let last: Bool
    let next: Color?
    static func type(_ k: String) -> String { k == "move" ? "order" : k == "family" ? "policy" : "move" }
    var body: some View {
        let tint: Color = InsightsInk.event(e.k)
        HStack(alignment: .top, spacing: 14) {
            PersonaRail(tint: tint, next: next, last: last)
            VStack(alignment: .leading, spacing: 8) {
                Button { store.push(.lifeEvent(e.id)) } label: { words(tint).contentShape(Rectangle()) }
                    .buttonStyle(.press)
                    .accessibilityHint("Opens this event: what was seen, what was spent around it, and how kosh knows")
                if e.ask == true && store.live != nil { PersonaMoveAsk(id: e.id) }
                PersonaEvidence(ev: e.ev ?? [], type: { (_: Int) -> String in Self.type(e.k) })
            }
            .padding(.bottom, last ? 0 : 22)
        }
        .privacySensitive()
    }
    private func words(_ tint: Color) -> some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(Day.fmt(e.on, "d MMM yyyy")).caption(tint)
            HStack(alignment: .firstTextBaseline) {
                Text(e.title).font(.headline).foregroundStyle(Obsidian.ink).fixedSize(horizontal: false, vertical: true)
                Spacer(minLength: 4)
                Image(systemName: "chevron.right").font(.caption.weight(.bold)).foregroundStyle(Obsidian.ink3)
            }
            Text(e.line).font(.subheadline).foregroundStyle(Obsidian.ink2).multilineTextAlignment(.leading).fixedSize(horizontal: false, vertical: true)
            if let s = e.storyLine, !s.isEmpty {
                Text(s).font(.footnote).foregroundStyle(Obsidian.ink3).multilineTextAlignment(.leading).fixedSize(horizontal: false, vertical: true)
            }
        }
    }
}

/// the rail: a ringed dot in the event's colour, the line down to the next event fading into its colour
struct PersonaRail: View {
    let tint: Color
    let next: Color?
    let last: Bool
    var body: some View {
        VStack(spacing: 0) {
            Circle().fill(tint).frame(width: 10, height: 10)
                .padding(4)
                .overlay(Circle().strokeBorder(tint.opacity(0.35), lineWidth: 1.5))
                .padding(.top, 1)
            if !last {
                LinearGradient(colors: [tint.opacity(0.7), (next ?? tint).opacity(0.7)], startPoint: .top, endPoint: .bottom)
                    .frame(width: 2)
                    .frame(maxHeight: .infinity)
                    .padding(.top, 4)
            }
        }
        .frame(width: 18)
        .accessibilityHidden(true)
    }
}

/// "Is this a move?" on the dark card: No outlined, Yes lit; remembered (prof.moveSaid), so never asked again
struct PersonaMoveAsk: View {
    @Environment(Store.self) private var store
    let id: String
    var body: some View {
        ViewThatFits(in: .horizontal) {
            HStack(spacing: 8) { question; Spacer(minLength: 8); buttons }
            VStack(alignment: .leading, spacing: 10) { question; buttons }
        }
        .padding(12)
        .background(Color.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).strokeBorder(InsightsInk.voice.opacity(0.3), lineWidth: 1))
    }
    private var question: some View {
        HStack(spacing: 8) {
            Image(systemName: "questionmark.bubble").font(.footnote.weight(.semibold)).foregroundStyle(InsightsInk.voice)
            Text("Is this a move?").font(.subheadline.weight(.semibold)).foregroundStyle(Obsidian.ink)
        }
    }
    private var buttons: some View {
        HStack(spacing: 8) {
            Button { store.sayMove(id, false) } label: {
                Text("No").font(.subheadline.weight(.semibold)).foregroundStyle(Obsidian.ink)
                    .padding(.horizontal, 18).frame(minHeight: 44)
                    .overlay(Capsule().strokeBorder(Color.white.opacity(0.25), lineWidth: 1))
                    .contentShape(Capsule())
            }
            .buttonStyle(.press)
            Button { store.sayMove(id, true) } label: {
                Text("Yes, I moved").font(.subheadline.weight(.semibold)).foregroundStyle(Color.black)
                    .padding(.horizontal, 18).frame(minHeight: 44)
                    .background(Obsidian.ink, in: Capsule())
                    .contentShape(Capsule())
            }
            .buttonStyle(.press)
        }
    }
}

// MARK: trips

/// the trips, a card a page with dots under them; a card fills the width, so no neighbour peeks in
struct PersonaTrips: View {
    @Environment(Store.self) private var store
    let trips: [Persona.Trip]
    @State private var page: String?
    @State private var renaming: Persona.Trip?
    @State private var name: String = ""
    var body: some View {
        if !trips.isEmpty {
            ObsHead(text: "Trips", trailing: String(trips.count))
            ScrollView(.horizontal) {
                LazyHStack(alignment: .top, spacing: 12) {
                    ForEach(Array(trips.enumerated()), id: \.element.id) { (pair: EnumeratedSequence<[Persona.Trip]>.Element) in
                        PersonaTripCard(t: pair.element, next: Self.nextDraft(trips, pair.offset), open: { store.push(.personaTrip(pair.element.id)) }, rename: {
                            name = pair.element.name
                            renaming = pair.element
                        })
                        .containerRelativeFrame(.horizontal)
                        .id(pair.element.id)
                    }
                }
                .scrollTargetLayout()
            }
            .scrollTargetBehavior(.viewAligned(limitBehavior: .always))
            .scrollPosition(id: $page)
            .scrollIndicators(.hidden)
            .alert("Name this trip", isPresented: Binding(get: { renaming != nil }, set: { if !$0 { renaming = nil } })) {
                TextField("Name", text: $name)
                Button("Save") { if let t = renaming { store.renameTrip(t.id, name) }; renaming = nil }
                Button("Cancel", role: .cancel) { renaming = nil }
            } message: {
                Text("kosh keeps your name for it.")
            }
            if trips.count > 1 {
                PersonaPageDots(ids: trips.map(\.id), on: page ?? trips.first?.id ?? "")
            }
        }
    }
    /// the drafted trip just before this one in time (the list is newest first), to join with
    static func nextDraft(_ trips: [Persona.Trip], _ i: Int) -> Persona.Trip? {
        guard trips[i].draft == true, i + 1 < trips.count, trips[i + 1].draft == true else { return nil }
        return trips[i + 1]
    }
}

/// the page dots: the one showing long and white
struct PersonaPageDots: View {
    let ids: [String]
    let on: String
    var body: some View {
        HStack(spacing: 6) {
            Spacer(minLength: 0)
            ForEach(ids.prefix(12), id: \.self) { (id: String) in
                Capsule().fill(id == on ? Obsidian.ink : Color.white.opacity(0.2))
                    .frame(width: id == on ? 18 : 6, height: 6)
            }
            Spacer(minLength: 0)
        }
        .animation(Motion.base, value: on)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("Trip " + String((ids.firstIndex(of: on) ?? 0) + 1) + " of " + String(ids.count))
    }
}

/// one trip's card: where and when, the total large, a day's cost, what it went on as one bar
struct PersonaTripCard: View {
    @Environment(Store.self) private var store
    let t: Persona.Trip
    let next: Persona.Trip?
    let open: () -> Void
    let rename: () -> Void
    static func days(_ t: Persona.Trip) -> [String] {
        guard let to = t.to, to > t.from else { return [] }
        var out: [String] = []
        var d: String = Day.add(t.from, 1)
        while d <= to && out.count < 30 { out.append(d); d = Day.add(d, 1) }
        return out
    }
    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(alignment: .top, spacing: 8) {
                Button(action: open) { head }
                    .buttonStyle(.press)
                Spacer(minLength: 4)
                if t.draft == true { actions }
            }
            Button(action: open) { figures }
                .buttonStyle(.press)
            PersonaSplitBar(parts: PersonaWords.split(t))
        }
        .frame(maxWidth: .infinity, alignment: .topLeading)
        .obsidianCard(24, padding: 18)
        .privacySensitive()
    }
    private var head: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(t.draft == true ? "Found in your mail" : "Your chapter").caption(Obsidian.ulip)
            Text(t.place.map { $0.isEmpty ? t.name : $0 } ?? t.name).font(.title3.weight(.semibold)).foregroundStyle(Obsidian.ink).lineLimit(2).multilineTextAlignment(.leading)
            if let pl = t.place, !pl.isEmpty, pl != t.name { Text(t.name).font(.caption).foregroundStyle(Obsidian.ink2).lineLimit(1) }
            Text(DeepWords.range(t.from, t.to)).font(.footnote).foregroundStyle(Obsidian.ink2)
        }
        .contentShape(Rectangle())
    }
    private var figures: some View {
        VStack(alignment: .leading, spacing: 4) {
            if let tot = t.total, tot > 0 { ObsFigure(text: Fmt.rupees(tot), size: 36) }
            Text(PersonaTripCard.perDay(t)).font(.footnote).foregroundStyle(Obsidian.ink2).monospacedDigit()
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .contentShape(Rectangle())
    }
    /// "5 days · ₹8,460 a day"
    static func perDay(_ t: Persona.Trip) -> String {
        var bits: [String] = []
        if let d = t.days, d > 0 { bits.append(String(d) + (d == 1 ? " day" : " days")) }
        if let pd = t.perDay, pd > 0 { bits.append(Fmt.rupees(pd) + " a day") }
        return bits.joined(separator: " · ")
    }
    private var actions: some View {
        Menu {
            Button("Rename", systemImage: "pencil", action: rename)
            if let n = next {
                Button("Join with " + n.name, systemImage: "arrow.triangle.merge") { store.joinTrips(t.id, n.id) }
            }
            let ds: [String] = Self.days(t)
            if !ds.isEmpty {
                Menu("Split from a day", systemImage: "scissors") {
                    ForEach(ds, id: \.self) { (d: String) in
                        Button(Day.fmt(d, "EEE d MMM")) { store.splitTrip(t.id, at: d) }
                    }
                }
            }
            Button("Not a trip", systemImage: "xmark.circle", role: .destructive) { store.live?.dropTripDraft(t.id) }
        } label: {
            Image(systemName: "ellipsis").font(.body.weight(.semibold)).foregroundStyle(Obsidian.ink2)
                .frame(width: 44, height: 44)
                .background(Color.white.opacity(0.06), in: Circle())
        }
        .accessibilityLabel("Change this trip")
    }
}

/// travel, stay, food, other: one bar, a legend under it
struct PersonaSplitBar: View {
    let parts: [PersonaWords.TripPart]
    static func tint(_ k: String) -> Color { InsightsInk.tripPart(k) }
    var body: some View {
        let total: Double = parts.reduce(0) { $0 + $1.v }
        if total > 0 {
            VStack(alignment: .leading, spacing: 10) {
                ObsSegBar(segs: parts.map { (p: PersonaWords.TripPart) -> ObsSegBar.Seg in ObsSegBar.Seg(id: p.k, v: p.v, tint: Self.tint(p.k)) }, height: 10)
                PersonaSplitLegend(parts: parts)
            }
        }
    }
}

struct PersonaSplitLegend: View {
    let parts: [PersonaWords.TripPart]
    var body: some View {
        ObsTileGrid {
            ForEach(parts) { (p: PersonaWords.TripPart) in
                HStack(spacing: 6) {
                    Circle().fill(PersonaSplitBar.tint(p.k)).frame(width: 7, height: 7)
                    Text(PersonaWords.splitName(p.k)).caption()
                    Spacer(minLength: 4)
                    Text(Fmt.rupees(p.v)).font(.caption.weight(.semibold)).foregroundStyle(Obsidian.ink).monospacedDigit().lineLimit(1).minimumScaleFactor(0.7)
                }
            }
        }
    }
}

// MARK: people

struct PersonaPeople: View {
    let people: [Persona.Person]
    /// the kind of mail behind a person's line of evidence (each line is one of their parts, in order)
    static func type(_ w: Persona.Person, _ i: Int) -> String {
        let parts: [Persona.Part] = w.parts ?? []
        guard i < parts.count else { return "move" }
        return parts[i].k == "gift" ? "order" : "move"
    }
    var body: some View {
        if !people.isEmpty {
            let most: Double = max(1, people.map(\.total).max() ?? 1)
            ObsHead(text: "Who your money goes to", trailing: "12 months")
            VStack(alignment: .leading, spacing: 0) {
                ForEach(Array(people.enumerated()), id: \.element.id) { (pair: EnumeratedSequence<[Persona.Person]>.Element) in
                    if pair.offset > 0 { ObsRule(inset: 50).padding(.vertical, 12) }
                    PersonaPersonRow(w: pair.element, rank: pair.offset, share: pair.element.total / most)
                        .obsArrive(pair.offset)
                }
            }
            .obsidianCard(24, padding: 18)
        }
    }
}

/// a person, once: initials, name, what they are and how many times, the amount, a thin bar against the first
struct PersonaPersonRow: View {
    @Environment(Store.self) private var store
    let w: Persona.Person
    let rank: Int
    let share: Double
    var body: some View {
        let tint: Color = rank == 0 ? InsightsInk.family : InsightsInk.kind(rank)
        Button { store.push(.personaPerson(w.key)) } label: {
            HStack(alignment: .top, spacing: 12) {
                ObsAvatar(text: PersonaWords.initials(w.who), tint: tint)
                VStack(alignment: .leading, spacing: 8) {
                    HStack(alignment: .firstTextBaseline, spacing: 8) {
                        VStack(alignment: .leading, spacing: 2) {
                            Text(w.who).font(.subheadline.weight(.semibold)).foregroundStyle(Obsidian.ink).lineLimit(2)
                            Text(PersonaWords.caption(w)).font(.caption).foregroundStyle(Obsidian.ink2).fixedSize(horizontal: false, vertical: true)
                        }
                        Spacer(minLength: 8)
                        Text(w.total > 0 ? Fmt.rupees(w.total) : "Split only").font(.subheadline.weight(.semibold)).monospacedDigit()
                            .foregroundStyle(w.total > 0 ? Obsidian.ink : Obsidian.ink3)
                    }
                    if w.total > 0 { ObsTrack(share: share, tint: tint) }
                }
            }
            .contentShape(Rectangle())
        }
        .buttonStyle(.press)
        .accessibilityHint("Opens what was sent, given and split, with the payments")
        .privacySensitive()
    }
}

// MARK: habits

struct PersonaHabits: View {
    let habits: [Persona.Habit]
    var body: some View {
        if !habits.isEmpty {
            ObsHead(text: "How you spend", trailing: "6 months")
            ObsTileGrid {
                ForEach(Array(habits.enumerated()), id: \.element.id) { (pair: EnumeratedSequence<[Persona.Habit]>.Element) in
                    PersonaHabitTile(h: pair.element).obsArrive(pair.offset)
                }
            }
        }
    }
}

struct PersonaHabitTile: View {
    @Environment(Store.self) private var store
    let h: Persona.Habit
    var body: some View {
        let t: (title: String, value: String, sub: String) = PersonaWords.tile(h, money: Fmt.rupees)
        Button { store.push(.personaHabit(h.k)) } label: {
            ObsStatTile(label: t.title, value: t.value.isEmpty ? t.sub : t.value, sub: t.value.isEmpty ? "" : t.sub, tint: Obsidian.savings, sym: PersonaWords.sym(habit: h.k))
                .contentShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
        }
        .buttonStyle(.press)
        .accessibilityHint("Opens this habit with the payments behind it")
        .privacySensitive()
    }
}
