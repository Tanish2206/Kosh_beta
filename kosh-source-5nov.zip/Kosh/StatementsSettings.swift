import SwiftUI
import UniformTypeIdentifiers

// MARK: - Settings › Statements and papers: every institution's papers, one tap apart
//
// kosh finds statements in the mail and opens them by itself (when you open the app and in the background). This page
// is led by a strip of the institutions that have papers, each chip with its mark and an orange count of what waits
// on you (locked, or not opened yet). "All" puts every locked sender first, each with the one detail its rule still
// needs typed right there, then what kosh couldn't read, then what opens them and where the figures go. Picking an
// institution shows only its papers: locked, not opened yet, couldn't read, then the opened ones by kind and month.
// Which shelf a paper sits on is PaperShelf's rule (the engine's institution for its sender, else Other).

struct StatementsSettings: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    /// presented on its own (a banner's sheet, with Done), or pushed from Settings
    var inSheet: Bool = false
    @State private var needs: [LiveSession.LockedNeed] = []
    @State private var working: Bool = false
    @State private var note: String? = nil
    /// the institution picked in the strip ("" is All)
    @State private var bank: String = ""
    @State private var picking: Bool = false
    @State private var addNote: String? = nil

    /// every kind of paper kosh opens (orders' invoices are left out: they belong to shops, not statements)
    static let kinds: Set<String> = ["cas", "contract", "policy", "cardstmt", "stmt", "society", "payslip", "tax", "fd", "loan", "nps"]

    /// where one kind of statement's figures show up in kosh
    struct Place: Identifiable {
        let id: String          // a key for the row
        let kinds: Set<String>
        let title: String       // what the statements are
        let shows: String       // where their figures appear
        let sym: String
        let go: Destination
    }
    enum Destination { case banks, holdings, debts, insurance, papers, property }

    static let places: [Place] = [
        Place(id: "bank", kinds: ["stmt"], title: "Bank statements", shows: "Each account’s balance and lines, in Transactions › Accounts & cards", sym: "building.columns", go: .banks),
        Place(id: "card", kinds: ["cardstmt"], title: "Card statements", shows: "Checked against your card payments, in Transactions › Accounts & cards", sym: "creditcard", go: .banks),
        Place(id: "cas", kinds: ["cas", "contract", "nps"], title: "Funds, shares and NPS (CAS, contract notes)", shows: "Your holdings and returns, in Wealth › Holdings", sym: "chart.pie", go: .holdings),
        Place(id: "fd", kinds: ["fd"], title: "Deposit advices", shows: "Your fixed deposits, in Wealth › Holdings", sym: "banknote", go: .holdings),
        Place(id: "loan", kinds: ["loan"], title: "Loan statements", shows: "What you owe and the EMI, in Wealth › Debts", sym: "building.columns.fill", go: .debts),
        Place(id: "policy", kinds: ["policy"], title: "Insurance policies", shows: "Cover, premium and renewal, in Insurance", sym: "shield", go: .insurance),
        Place(id: "pay", kinds: ["payslip", "tax"], title: "Payslips and tax forms", shows: "Salary and tax, in Papers", sym: "doc.text", go: .papers),
        Place(id: "society", kinds: ["society"], title: "Housing society bills", shows: "Maintenance, in Property", sym: "house", go: .property),
    ]

    /// what a statement of this kind feeds, in a few words (for the statement lists)
    static func shows(_ kind: String) -> String? {
        places.first { (p: Place) -> Bool in p.kinds.contains(kind) }?.shows
    }

    static func paper(_ i: LiveSession.DocItem) -> ShelfPaper {
        ShelfPaper(id: i.id, inst: i.inst, domain: i.domain, kind: i.kind, state: i.state, unread: i.unread, date: i.date)
    }

    var body: some View {
        List {
            if let live = store.live {
                let items: [LiveSession.DocItem] = live.docItems(kinds: Self.kinds)
                let papers: [ShelfPaper] = items.map(Self.paper)
                let asks: [LiveSession.LockedNeed] = needs + Self.orphans(items, needs)
                let homes: [String: String] = Self.homes(asks, papers)
                let banks: [PaperShelf.Bank] = PaperShelf.banks(papers, extra: Self.extra(asks, homes, papers))
                let picked: PaperShelf.Bank? = banks.first { PaperShelf.key($0.name) == PaperShelf.key(bank) }
                if banks.count > 1 {
                    Section {
                        BankStrip(banks: Self.picks(banks, store), pick: $bank, logos: Self.logos(banks), noun: "papers", badges: true)
                            .listRowInsets(EdgeInsets())
                            .listRowBackground(Color.clear)
                    }
                }
                if let picked {
                    shelf(live, picked, items, papers, homes, asks)
                } else {
                    overview(live, items, banks, asks)
                    lockedAll(homes, asks)
                    UnreadPapersSection()
                    details(live)
                    more(live)
                    wherePart(live, items)
                }
            }
        }
        .settingsPage("Statements and papers")
        .toolbar {
            if inSheet { ToolbarItem(placement: .cancellationAction) { Button("Done") { dismiss() } } }
        }
        .onAppear { refresh() }
    }

    func refresh() {
        needs = store.live?.lockedNeeds() ?? []
    }

    // MARK: Shelves

    /// locked papers no sender's card covers (a file added by hand is kept by its own key): each its own card, so its
    /// password can be typed here too, as the Documents sheet always let it
    static func orphans(_ items: [LiveSession.DocItem], _ needs: [LiveSession.LockedNeed]) -> [LiveSession.LockedNeed] {
        let covered: Set<String> = Set(needs.map(\.id))
        let left: [LiveSession.DocItem] = items.filter { $0.state == "locked" && !covered.contains($0.domain) }
        let by: [String: [LiveSession.DocItem]] = Dictionary(grouping: left, by: { $0.domain })
        return by.keys.sorted().compactMap { (dom: String) -> LiveSession.LockedNeed? in
            guard let xs = by[dom], let first = xs.first else { return nil }
            let hint: String = xs.first { !$0.hint.isEmpty }?.hint ?? ""
            return LiveSession.LockedNeed(id: dom, sender: first.local ? first.file : first.sender, count: xs.count, hint: hint,
                                          need: hint.isEmpty ? "Type its password once below." : "Type the password the email describes, once.",
                                          details: false)
        }
    }

    /// each locked sender's shelf, by its domain
    static func homes(_ needs: [LiveSession.LockedNeed], _ papers: [ShelfPaper]) -> [String: String] {
        var out: [String: String] = [:]
        for n in needs { out[n.id] = PaperShelf.home(ofSender: n.id, named: n.id == LiveSession.epfDomain ? "EPFO" : n.sender, papers) }
        return out
    }
    /// locked senders with no paper among these (a passbook added from Files): still a chip
    static func extra(_ needs: [LiveSession.LockedNeed], _ homes: [String: String], _ papers: [ShelfPaper]) -> [(name: String, locked: Int)] {
        let have: Set<String> = Set(papers.map { PaperShelf.key(PaperShelf.home($0)) })
        return needs.compactMap { (n: LiveSession.LockedNeed) -> (name: String, locked: Int)? in
            let h: String = homes[n.id] ?? PaperShelf.other
            return have.contains(PaperShelf.key(h)) ? nil : (h, n.count)
        }
    }
    /// an institution's colour, as its accounts and cards carry it (grey when kosh holds neither)
    static func color(_ name: String, _ store: Store) -> Color {
        let n: String = name.lowercased()
        if let a = store.snap.accounts.first(where: { $0.bank.lowercased() == n }) { return Color(hex: a.color) }
        if let c = store.snap.cards.first(where: { $0.bank.lowercased() == n }) { return Color(hex: c.color) }
        return Color(hex: "#636366")
    }
    static func picks(_ banks: [PaperShelf.Bank], _ store: Store) -> [BankPick] {
        var color: [String: String] = [:]
        for a in store.snap.accounts { color[a.bank.lowercased()] = a.color }
        for c in store.snap.cards where color[c.bank.lowercased()] == nil { color[c.bank.lowercased()] = c.color }
        return banks.map { (b: PaperShelf.Bank) -> BankPick in
            let other: Bool = PaperShelf.key(b.name) == PaperShelf.key(PaperShelf.other)
            return BankPick(id: b.name, color: color[b.name.lowercased()] ?? "#636366", count: b.total, hint: b.name,
                            badge: b.shut, sym: other ? "tray.full" : "")
        }
    }
    /// every chip a logo, or every chip its initials ("Other" has its own symbol either way)
    static func logos(_ banks: [PaperShelf.Bank]) -> Bool {
        let names: [String] = banks.map(\.name).filter { PaperShelf.key($0) != PaperShelf.key(PaperShelf.other) }
        return names.isEmpty || IconBook.shared.all(names.map { ($0, $0) })
    }

    // MARK: All

    @ViewBuilder func overview(_ live: LiveSession, _ items: [LiveSession.DocItem], _ banks: [PaperShelf.Bank], _ asks: [LiveSession.LockedNeed]) -> some View {
        let locked: Int = items.filter { $0.state == "locked" }.count + Self.extraLocked(asks, items)
        let waiting: Int = items.filter { $0.state.isEmpty }.count
        let unread: Int = items.filter { $0.unread || $0.state == "empty" }.count
        let read: Int = items.filter { $0.state == "read" && !$0.unread }.count
        let head: (figure: String, rest: String) = Self.headline(locked: locked, waiting: waiting, papers: items.count)
        let subline: String = Self.subline(papers: items.count, senders: banks.count, newest: items.map(\.date).max() ?? "")
        Section {
            VStack(alignment: .leading, spacing: 14) {
                VStack(alignment: .leading, spacing: 4) {
                    // (the one number that matters, then what it's out of, muted)
                    (Text(head.figure).foregroundStyle(Color.primary) + Text(head.rest).foregroundStyle(.secondary))
                        .font(.title2.weight(.bold)).monospacedDigit()
                        .fixedSize(horizontal: false, vertical: true)
                    Text(subline)
                        .font(SettingsType.caption).foregroundStyle(.secondary).monospacedDigit()
                        .fixedSize(horizontal: false, vertical: true)
                }
                if !items.isEmpty {
                    SegmentBar(parts: [
                        SegmentBar.Part(id: "read", count: read, color: Color.green, label: "opened"),
                        SegmentBar.Part(id: "locked", count: locked, color: Color.orange, label: "locked"),
                        SegmentBar.Part(id: "waiting", count: waiting, color: Color.kosh, label: "not yet"),
                        SegmentBar.Part(id: "unread", count: unread, color: Color.red, label: "couldn’t read"),
                    ])
                }
            }
            .padding(.vertical, 8)
            if live.readingDocs {
                HStack(spacing: 10) {
                    ProgressView()
                    Text("Opening statements…").font(SettingsType.caption).foregroundStyle(.secondary)
                }
                .frame(minHeight: 44)
            } else if waiting > 0 {
                Button {
                    Task { @MainActor in
                        await live.readDocuments()
                        refresh()
                    }
                } label: { SettingsRow(symbol: "arrow.clockwise", color: Color.kosh, title: "Open them now") }
                .buttonStyle(.press)
            }
        }
    }

    /// the summary's first line, in two tones: the figure that matters ("148 locked") and what it is out of
    static func headline(locked: Int, waiting: Int, papers: Int) -> (figure: String, rest: String) {
        if locked > 0 { return (String(locked) + " locked", " of " + String(papers)) }
        if waiting > 0 { return (String(waiting) + " to open", " of " + String(papers)) }
        return papers == 0 ? ("No papers yet", "") : ("All open", ", " + String(papers) + " papers")
    }
    /// how many senders, and the date of the newest
    static func subline(papers: Int, senders: Int, newest: String) -> String {
        if papers == 0 { return "kosh finds statements in your mail and opens them here." }
        let count: String = String(senders) + " sender" + (senders == 1 ? "" : "s")
        let when: String = newest.isEmpty ? "" : ", newest " + Day.fmt(String(newest.prefix(10)), "d MMM yyyy")
        return count + when
    }

    /// locked passbooks shared in from Files: counted with the locked ones, though they aren't among these kinds
    static func extraLocked(_ needs: [LiveSession.LockedNeed], _ items: [LiveSession.DocItem]) -> Int {
        let doms: Set<String> = Set(items.map(\.domain))
        return needs.filter { !doms.contains($0.id) }.reduce(0) { $0 + $1.count }
    }

    @ViewBuilder func lockedAll(_ homes: [String: String], _ asks: [LiveSession.LockedNeed]) -> some View {
        if !asks.isEmpty {
            let sorted: [LiveSession.LockedNeed] = asks.sorted { (a: LiveSession.LockedNeed, b: LiveSession.LockedNeed) -> Bool in
                let ha: String = homes[a.id] ?? "", hb: String = homes[b.id] ?? ""
                return ha != hb ? ha.localizedCaseInsensitiveCompare(hb) == .orderedAscending : a.sender < b.sender
            }
            Section {
                ForEach(LockedMerge.of(sorted, home: { homes[$0.id] ?? PaperShelf.other }), id: \.key) { (n: LiveSession.LockedNeed) in LockedNeedRow(need: n, home: homes[n.id] ?? PaperShelf.other) { refresh() } }
            } header: {
                SettingsHeader("Locked")
            } footer: {
                Text("A detail you type stays on this phone and opens that sender’s older statements too.")
            }
        }
    }

    @ViewBuilder func details(_ live: LiveSession) -> some View {
        let saved: Bool = PasswordProfile.anySaved
        let locked: Int = live.lockedDocs.count
        Section {
            NavigationLink {
                FamilyUnlockView().onDisappear { refresh() }
            } label: {
                SettingsRow(symbol: "person.2.fill", color: Color.koshFill, title: "Family details", value: saved ? "Saved" : "Not saved")
            }
            if saved && locked > 0 {
                Button {
                    Task { @MainActor in
                        working = true
                        let n: Int = await live.openLockedWithProfile()
                        working = false
                        note = n > 0 ? "Opened \(Words.number(n)) statement\(n == 1 ? "" : "s")." : "Nothing new opened. See what each one needs above."
                        refresh()
                    }
                } label: {
                    if working { HStack(spacing: 8) { ProgressView(); Text("Trying your details…") } }
                    else { SettingsRow(symbol: "lock.open.fill", color: Color.orange, title: "Try my details on the locked ones") }
                }
                .disabled(working)
            }
            if let note { Text(note).font(.footnote).foregroundStyle(.secondary) }
        } header: {
            SettingsHeader("What opens them")
        } footer: {
            Text("Kept in this phone’s Keychain; never sent anywhere.")
        }
    }

    /// adding a paper by hand, and the checks: what kosh may be missing, each statement against kosh's payments,
    /// and what it held back
    @ViewBuilder func more(_ live: LiveSession) -> some View {
        Section {
            Button { picking = true } label: { SettingsRow(symbol: "doc.badge.plus", color: Color(hex: "#007AFF"), title: "Add from Files", caption: "A PDF or spreadsheet") }
                .buttonStyle(.press)
                .fileImporter(isPresented: $picking, allowedContentTypes: [.pdf, .commaSeparatedText, UTType("org.openxmlformats.spreadsheetml.sheet") ?? .spreadsheet, .zip]) { result in
                    if case .success(let url) = result {
                        Task { @MainActor in
                            let d = await live.addLocalDocument(url)
                            addNote = d == nil ? "Couldn’t copy that file." : d!.state == "locked" ? "Added. It’s locked: it’s under Locked above." : "Added and read."
                            refresh()
                        }
                    }
                }
            if let addNote { Text(addNote).font(.footnote).foregroundStyle(.secondary) }
            NavigationLink { StatementChecksPage() } label: {
                SettingsRow(symbol: "checkmark.seal.fill", color: Color(hex: "#34C759"), title: "Checks", caption: "Missing months, payments matched")
            }
        }
    }

    @ViewBuilder func wherePart(_ live: LiveSession, _ items: [LiveSession.DocItem]) -> some View {
        Section {
            ForEach(Self.places) { (p: Place) in
                let n: Int = items.filter { (i: LiveSession.DocItem) -> Bool in p.kinds.contains(i.kind) && i.state == "read" }.count
                Button { go(p.go) } label: {
                    SettingsRow(symbol: p.sym, color: Color.kosh, title: p.title, caption: p.shows, value: n > 0 ? String(n) : "")
                }
                .buttonStyle(.press)
            }
        } header: {
            SettingsHeader("Where the figures go")
        } footer: {
            Text("Tap one to go there.")
        }
    }

    // MARK: One institution

    @ViewBuilder func shelf(_ live: LiveSession, _ b: PaperShelf.Bank, _ items: [LiveSession.DocItem], _ papers: [ShelfPaper], _ homes: [String: String], _ asks: [LiveSession.LockedNeed]) -> some View {
        let mine: [ShelfPaper] = PaperShelf.on(b.name, papers)
        let byID: [String: LiveSession.DocItem] = Dictionary(items.map { ($0.id, $0) }, uniquingKeysWith: { a, _ in a })
        let other: Bool = PaperShelf.key(b.name) == PaperShelf.key(PaperShelf.other)
        let locked: [LiveSession.LockedNeed] = asks.filter { PaperShelf.key(homes[$0.id] ?? PaperShelf.other) == PaperShelf.key(b.name) }
        let waiting: [LiveSession.DocItem] = mine.filter { PaperShelf.pile($0) == .waiting }.compactMap { byID[$0.id] }
        let unread: [LiveSession.DocItem] = mine.filter { PaperShelf.pile($0) == .unread }.compactMap { byID[$0.id] }
        let older: [LiveSession.DocItem] = mine.filter { PaperShelf.pile($0) == .older }.compactMap { byID[$0.id] }
        Section {
            HStack(spacing: 14) {
                if other {
                    IconTile(symbol: "tray.full.fill", color: Color(hex: "#8E8E93"), size: 44)
                } else {
                    InstIcon(name: b.name, color: Self.color(b.name, store), size: 44, hint: b.name)
                }
                VStack(alignment: .leading, spacing: 2) {
                    Text(b.name).font(.title3.weight(.semibold)).lineLimit(2)
                    Text(PaperShelf.line(b)).font(SettingsType.caption).foregroundStyle(.secondary).monospacedDigit().fixedSize(horizontal: false, vertical: true)
                    if !b.newest.isEmpty {
                        Text("Newest " + Day.fmt(String(b.newest.prefix(10)), "d MMM yyyy")).font(SettingsType.caption).foregroundStyle(.secondary)
                    }
                }
            }
            .padding(.vertical, 4)
        } footer: {
            if other { Text("Papers from senders kosh can’t name an institution for, and ones you added from Files.") }
        }
        if !locked.isEmpty {
            Section {
                ForEach(LockedMerge.of(locked, home: { _ in b.name }), id: \.key) { (n: LiveSession.LockedNeed) in LockedNeedRow(need: n, home: b.name) { refresh() } }
            } header: { SettingsHeader("Locked") }
        }
        if !waiting.isEmpty {
            Section {
                ForEach(waiting) { (it: LiveSession.DocItem) in StatementLine(item: it) }
                if live.readingDocs {
                    HStack(spacing: 8) { ProgressView(); Text("Opening statements…").foregroundStyle(.secondary) }
                } else {
                    Button {
                        Task { @MainActor in await live.readDocuments(); refresh() }
                    } label: { Label("Open them now", systemImage: "arrow.clockwise") }
                }
            } header: { SettingsHeader("Not opened yet") }
        }
        if !unread.isEmpty {
            Section {
                ForEach(unread) { (it: LiveSession.DocItem) in StatementLine(item: it) }
                if !live.readingDocs {
                    Button {
                        Task { @MainActor in await live.rereadUnread(); refresh() }
                    } label: { Label("Read them again", systemImage: "text.magnifyingglass") }
                }
            } header: { SettingsHeader("Couldn’t read") } footer: {
                Text("kosh opened these but couldn’t read them. Smart reading (Settings › Reading) can try.")
            }
        }
        ForEach(PaperShelf.opened(mine)) { (k: PaperShelf.KindShelf) in
            Section {
                ForEach(k.months) { (m: PaperShelf.Month) in
                    Text(PaperShelf.monthTitle(m.ym))
                        .font(.footnote.weight(.semibold)).foregroundStyle(.secondary)
                        .listRowSeparator(.hidden, edges: .bottom)
                    ForEach(m.ids, id: \.self) { (id: String) in
                        if let it = byID[id] { StatementLine(item: it) }
                    }
                }
            } header: {
                HStack {
                    Text(k.title)
                    Spacer()
                    Text(String(k.count)).monospacedDigit()
                }
            }
        }
        if !older.isEmpty {
            Section {
                ForEach(older) { (it: LiveSession.DocItem) in StatementLine(item: it) }
            } header: { SettingsHeader("Older copies") } footer: {
                Text("A newer statement from this sender says the same and more, so kosh didn’t open these.")
            }
        }
        if mine.isEmpty && locked.isEmpty {
            Section {
                ContentUnavailableView("Nothing here yet", systemImage: "doc.text", description: Text("Papers from \(b.name) show here as kosh finds them."))
            }
        }
    }

    /// Settings (or this sheet) closes first, then kosh goes to the page those figures are on
    func go(_ d: Destination) {
        if inSheet { store.betaSheet = nil } else { store.sheet = nil }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) {
            switch d {
            case .banks:
                store.txSub = .accounts
                store.open(.transactions)
            case .holdings:
                store.portSub = .investments
                store.open(.portfolio)
            case .debts:
                store.portSub = .loans
                store.open(.portfolio)
            case .insurance:
                store.open(.insurance)
            case .papers:
                store.betaSheet = .papers
            case .property:
                store.open(.property)
            }
        }
    }
}

/// the checks that used to sit only in the Statements sheet: months kosh may be missing, each statement against
/// kosh's payments, and what kosh held back
struct StatementChecksPage: View {
    var body: some View {
        List {
            CoverageSection()
            StatementCheckSection()
            HeldBackSection()
        }
        .navigationTitle("Checks")
        .navigationBarTitleDisplayMode(.inline)
    }
}

/// one locked sender: its mark, one line of what it needs (the email's own words behind Why?), one field for the
/// detail its rule still needs with Unlock beside it, the password itself instead if you'd rather, and "Try saved
/// details"
struct LockedNeedRow: View {
    @Environment(Store.self) private var store
    let need: LiveSession.LockedNeed
    /// the institution it sits under (PaperShelf.home)
    var home: String = ""
    let changed: () -> Void
    @State private var pw: String = ""
    @State private var trying: Bool = false
    @State private var result: String? = nil
    @State private var fieldText: String = ""
    @State private var saving: Bool = false
    /// the password itself, in place of the detail
    @State private var usePassword: Bool = false

    /// the one detail this sender's rule still needs (crn, cid, dob, pan, mobile, pin), or nil
    var field: String? { PaperShelf.field(forNeed: need.need) }

    /// whose detail it is: the likeliest holder of this sender's locked statements (yours unless the mail is
    /// written to someone else in the family)
    /// (the one lockedNeeds worked the need out for, so the words, the box and where it is kept agree)
    var who: String { need.holder }

    @State private var why: Bool = false
    @FocusState private var typing: Bool

    var body: some View {
        let mark: String = home.isEmpty || home == PaperShelf.other ? need.sender : home
        let covers: [LockedCover] = LockedCover.of(store.live, ids: need.ids, holder: need.holder)
        VStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .center, spacing: 12) {
                InstIcon(name: mark, color: StatementsSettings.color(mark, store), size: 36, hint: need.sender)
                    .cornerMark("lock.fill", color: Color.orange, size: 36)
                VStack(alignment: .leading, spacing: 2) {
                    HStack(spacing: 6) {
                        Text(need.sender).font(.body.weight(.semibold)).lineLimit(1)
                        if who != "me" {
                            Text(Details.personName(who, store) + "’s").font(.caption.weight(.semibold)).foregroundStyle(Color.kosh)
                                .padding(.horizontal, 7).padding(.vertical, 2).background(Color.kosh.opacity(0.12), in: Capsule())
                        }
                    }
                    if let r = LockedRecipe.of(need.hint) {
                        Text("Password: " + r).font(.caption).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                    }
                    Text(PaperShelf.need(need.need, whose: who == "me" ? "" : Details.personName(who, store)))
                        .font(.footnote).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                }
                Spacer(minLength: 6)
                Text(String(need.count)).font(.footnote.weight(.bold)).monospacedDigit().foregroundStyle(Color.orange)
                    .padding(.horizontal, 9).padding(.vertical, 3)
                    .background(Color.orange.opacity(0.14), in: Capsule())
                    .accessibilityLabel(String(need.count) + " locked")
            }
            // what it would open: which account's detail this is
            if !covers.isEmpty {
                WrapRow(spacing: 6, lineSpacing: 6) {
                    ForEach(covers) { c in
                        HStack(spacing: 5) {
                            Image(systemName: c.sym).font(.caption2.weight(.semibold))
                            Text(c.label).font(.caption.weight(.medium))
                            Text(String(c.n)).font(.caption).foregroundStyle(.tertiary).monospacedDigit()
                        }
                        .foregroundStyle(.secondary)
                        .padding(.horizontal, 9).frame(minHeight: 26)
                        .background(Color(.tertiarySystemFill), in: Capsule())
                    }
                }
                .accessibilityElement(children: .combine)
                .accessibilityLabel("Opens " + covers.map { $0.label + ", " + String($0.n) }.joined(separator: "; "))
            }
            // one field, its button inside it
            let f: String? = usePassword ? nil : field
            let ok: Bool = f.map { PaperShelf.typed($0, fieldText) != nil } ?? !pw.isEmpty
            let busy: Bool = saving || trying
            HStack(spacing: 8) {
                Group {
                    if let f {
                        TextField(label(f), text: $fieldText)
                            .keyboardType(keyboard(f))
                            .textInputAutocapitalization(f == "pan" || f == "crn" || f == "cid" ? .characters : .never)
                    } else {
                        SecureField(field == nil ? "The statement’s password" : "Password", text: $pw)
                            .textContentType(.password)
                    }
                }
                .font(.body).monospacedDigit()
                .autocorrectionDisabled()
                .focused($typing)
                .submitLabel(.go)
                .onSubmit { if ok && !busy { if let f { save(f) } else { unlock() } } }
                Button { if let f { save(f) } else { unlock() } } label: {
                    ZStack {
                        Image(systemName: "lock.open.fill").font(.system(size: 13, weight: .bold)).opacity(busy ? 0 : 1)
                        if busy { ProgressView().controlSize(.small).tint(Color.onKosh) }
                    }
                    .foregroundStyle(ok ? Color.onKosh : Color.secondary)
                    .frame(width: 34, height: 34)
                    .background(ok ? Color.koshFill : Color(.quaternarySystemFill), in: Circle())
                }
                .buttonStyle(.press)
                .disabled(!ok || busy)
                .accessibilityLabel("Unlock")
            }
            .padding(.leading, 12).padding(.trailing, 5)
            .frame(minHeight: 44)
            .background(Color(.tertiarySystemFill), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).strokeBorder(typing ? Color.kosh.opacity(0.5) : Color.clear, lineWidth: 1))
            .animation(Motion.base, value: typing)
            // the ways out, one quiet line
            let links: [(String, () -> Void)] = linkList()
            if !links.isEmpty {
                HStack(spacing: 0) {
                    ForEach(Array(links.enumerated()), id: \.offset) { i, l in
                        if i > 0 { Text("·").foregroundStyle(.tertiary).padding(.horizontal, 8) }
                        Button(l.0, action: l.1).buttonStyle(.press)
                    }
                }
                .font(.caption.weight(.medium))
                .foregroundStyle(Color.kosh)
            }
            if why && !need.hint.isEmpty {
                Text("The email says: “" + need.hint + "”").font(.caption).foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
                    .transition(.opacity)
            }
            if let result {
                Label(result, systemImage: result.hasPrefix("Opened") ? "checkmark.circle.fill" : "exclamationmark.circle")
                    .font(.caption)
                    .foregroundStyle(result.hasPrefix("Opened") ? Color.green : Color.orange)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .padding(.vertical, 6)
    }

    func linkList() -> [(String, () -> Void)] {
        var out: [(String, () -> Void)] = []
        if field != nil {
            out.append((usePassword ? "Type the " + PaperShelf.fieldWord(field ?? "") : "Use the password", { withAnimation(Motion.base) { usePassword.toggle() } }))
        }
        if PasswordProfile.anySaved && !(saving || trying) { out.append(("Try saved details", { retrySaved() })) }
        if !need.hint.isEmpty { out.append((why ? "Hide the email’s words" : "Why?", { withAnimation(Motion.base) { why.toggle() } })) }
        return out
    }

    func unlock() {
        Task { @MainActor in
            trying = true
            var n: Int = 0
            for id in need.ids { n += await store.live?.unlockSender(id, password: pw) ?? 0 }
            trying = false
            result = n > 0 ? "Opened \(n) statement\(n == 1 ? "" : "s")." : "That didn’t open it."
            if n > 0 {
                pw = ""
                changed()
            }
        }
    }

    func retrySaved() {
        Task { @MainActor in
            saving = true
            let n: Int = await store.live?.openLockedWithProfile() ?? 0
            saving = false
            result = n > 0 ? "Opened \(n) statement\(n == 1 ? "" : "s")." : "Still locked with what’s saved."
            if n > 0 { changed() }
        }
    }

    func label(_ f: String) -> String {
        let whose: String = who == "me" ? "Your " : Details.personName(who, store) + "’s "
        let word: String = PaperShelf.fieldWord(f)
        let what: String = f == "crn" || f == "cid" || f == "pan" || f == "pin" ? word : word.lowercased()
        return whose + what + (f == "dob" ? " (DDMMYYYY)" : "")
    }

    func keyboard(_ f: String) -> UIKeyboardType {
        switch f {
        // (a date of birth goes in as eight digits; an ID opens on the digits with letters a tap away, since some
        // banks' IDs carry letters; a PAN is letters and digits)
        case "dob": return .numberPad
        case "mobile": return .phonePad
        case "pin": return .numberPad
        case "crn", "cid": return .numbersAndPunctuation
        default: return .asciiCapable
        }
    }

    /// keep the detail with the likeliest holder (an ID under the sender's address and the bank's name, as before),
    /// then open what it unlocks
    func save(_ f: String) {
        guard let live = store.live, let v = PaperShelf.typed(f, fieldText) else { return }
        let holder: String = who
        var p: PasswordProfile = PasswordProfile.load(for: holder) ?? PasswordProfile()
        switch f {
        case "dob": p.dob = v
        case "pan": p.pan = v
        case "mobile": p.mobile = v
        case "pin": p.pin = v
        default:
            for id in need.ids { p.ids[id] = v }
            p.ids["bank:" + need.sender.lowercased()] = v
        }
        PasswordProfile.save(p, for: holder)
        Task { @MainActor in
            saving = true
            let n: Int = await live.openLockedWithProfile()
            saving = false
            result = n > 0 ? "Opened \(n) statement\(n == 1 ? "" : "s")." : "Saved. That didn’t open them yet: check the " + PaperShelf.fieldWord(f) + "."
            if n > 0 { fieldText = ""; changed() }
        }
    }
}


/// one ask per bank, detail and person: a sender that mails from two addresses (axisbank.com, then axis.bank.in) asking
/// for the same Customer ID is one ask, its counts added
enum LockedMerge {
    static func of(_ ns: [LiveSession.LockedNeed], home: (LiveSession.LockedNeed) -> String) -> [LiveSession.LockedNeed] {
        var out: [LiveSession.LockedNeed] = []
        var at: [String: Int] = [:]
        for n in ns {
            let h: String = home(n)
            let bank: String = (h.isEmpty || h == PaperShelf.other ? n.sender : h).lowercased()
            let key: String = bank + "|" + n.need.lowercased() + "|" + n.holder
            if let i = at[key] {
                let o = out[i]
                var m = LiveSession.LockedNeed(id: o.id, sender: o.sender, count: o.count + n.count, hint: o.hint.isEmpty ? n.hint : o.hint,
                                               need: o.need, details: o.details || n.details, holder: o.holder)
                m.also = o.also + n.ids
                out[i] = m
            } else {
                at[key] = out.count
                out.append(n)
            }
        }
        return out
    }
}

/// what a locked ask would open, by the account it is about: "Account statements 40", "Atlas card ••88 12"
struct LockedCover: Identifiable, Hashable {
    let label: String
    let sym: String
    let n: Int
    var id: String { label }
    @MainActor static func of(_ live: LiveSession?, ids: [String], holder: String = "") -> [LockedCover] {
        guard let live else { return [] }
        let keys: Set<String> = Set(ids)
        var count: [String: Int] = [:], sym: [String: String] = [:], order: [String] = []
        for r in live.lockedDocs {
            guard let d = r.doc, keys.contains(SenderPasswords.domain(d.from)) || keys.contains(d.from) else { continue }
            if !holder.isEmpty && (live.likelyHolders(r).first ?? "me") != holder { continue }
            let (l, s) = name(r, kind: d.kind)
            if count[l] == nil { order.append(l) }
            count[l, default: 0] += 1
            sym[l] = s
        }
        return order.map { LockedCover(label: $0, sym: sym[$0] ?? "doc.text", n: count[$0] ?? 0) }.sorted { $0.n > $1.n }
    }
    static func name(_ r: Reading, kind: String) -> (String, String) {
        let subj: String = r.subject ?? ""
        let digits: String = {
            if let m = subj.range(of: #"(?i)(?:ending|xx+|••|\*{2,})\s*(\d{2,4})\b"#, options: .regularExpression) {
                return String(subj[m]).filter(\.isNumber)
            }
            return r.last4 ?? ""
        }()
        let tail: String = digits.isEmpty ? "" : " ••" + String(digits.suffix(4))
        let low: String = subj.lowercased()
        if kind == "cardstmt" || low.contains("credit card") {
            // the card's own name from the subject: "Your Axis Bank Atlas Credit Card ending XX88" → "Atlas"
            var nm: String = ""
            if let m = subj.range(of: #"(?i)bank\s+([A-Za-z0-9+ ]{2,24}?)\s+credit card"#, options: .regularExpression) {
                nm = String(subj[m]).replacingOccurrences(of: #"(?i)^bank\s+|\s+credit card$"#, with: "", options: .regularExpression)
            }
            return ((nm.isEmpty ? "Credit card" : nm + " card") + tail, "creditcard")
        }
        if kind == "fd" || low.contains("deposit") { return ("Deposits", "banknote") }
        if kind == "tax" || low.contains("tds") || low.contains("form 16") { return ("Tax papers", "doc.text") }
        if kind == "loan" || low.contains("loan") { return ("Loan" + tail, "house") }
        if kind == "policy" { return ("Policies", "shield") }
        if kind == "cas" { return ("Holdings", "chart.pie") }
        if kind == "stmt" || low.contains("statement") { return ("Account statements" + tail, "building.columns") }
        return ("Other papers", "doc")
    }
}


/// the password's recipe as its mail tells it, in short: "first 4 letters of name (CAPITALS) + date of birth (DDMM)"
@MainActor
enum LockedRecipe {
    static var memo: [String: String] = [:]
    static func of(_ hint: String) -> String? {
        guard !hint.isEmpty else { return nil }
        if let m = memo[hint] { return m.isEmpty ? nil : m }
        var out: [String] = []
        if let s = try? Engine.shared.call("pwPartsJSON", [hint]), let d = s.data(using: .utf8),
           let parts = try? JSONSerialization.jsonObject(with: d) as? [[String]] {
            for alt in parts { for p in alt {
                let w: String = p.replacingOccurrences(of: "Your ", with: "").replacingOccurrences(of: "your ", with: "")
                if !w.isEmpty && !out.contains(w) { out.append(w) }
            } }
        }
        let r: String = out.joined(separator: " + ")
        memo[hint] = r
        return r.isEmpty ? nil : r
    }
}
