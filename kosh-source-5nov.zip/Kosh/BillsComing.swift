import SwiftUI

// MARK: - Card bills: where each comes from, and how they're worded
//
// Where a bill comes from: the card's own row (CardInfo.due, minDue, dueDate, stmtOn, and paid/paidOn for what
// went towards it since), else the agenda's "Card Payments" line for that card (its name starts with the card's
// key, "HDFC card ••1234"). Agenda lines no card claims still show, in the family view. The Cards page (Cards.swift)
// puts each bill on its card's strip and a dot on its day; the Bills segment (below) lists them by when they fall.

/// one card's bill, as the list shows it
struct CardBill: Identifiable, Hashable {
    let id: String
    /// the card's row, when the bill belongs to a card kosh has
    let cardID: String?
    /// "HDFC Regalia ••7710", for reading aloud
    let title: String
    /// "HDFC Regalia", and its last four ("7710", or "" when not known)
    let name: String
    let last: String
    let color: String
    let amount: Double
    let minDue: Double
    let due: String
    let stmtOn: String
    /// what went towards it since the statement, and when
    let paidAmt: Double
    let paidOn: String
    /// paid in full
    let paid: Bool
    /// the day that places it in the stretch: the day it was paid, else its due day
    var pin: String = ""
    /// who says what was paid, when no payment kosh saw does (CardInfo.paidSaid): "issuer" or "you"
    var said: String = ""
}

/// a card with no bill in the stretch, and a word on why
struct QuietCard: Identifiable, Hashable {
    let card: CardInfo
    let note: String
    var id: String { card.id }
}

struct BillBook {
    let today: String
    let start: String
    let end: String
    var bills: [CardBill] = []
    /// due after the stretch ends
    var later: [CardBill] = []
    var quiet: [QuietCard] = []

    static let back: Int = 5
    static let ahead: Int = 25

    init(today: String) {
        self.today = today
        self.start = Day.add(today, -Self.back)
        self.end = Day.add(today, Self.ahead)
    }

    /// in the stretch, or after it; otherwise the word for the quiet list
    mutating func place(_ bill: CardBill) -> String? {
        var b: CardBill = bill
        let paidIn: Bool = b.paid && !b.paidOn.isEmpty && b.paidOn >= start && b.paidOn <= end
        b.pin = paidIn ? b.paidOn : b.due
        if b.pin >= start && b.pin <= end { bills.append(b); return nil }
        if !b.paid && b.due < start && b.due >= Day.add(today, -35) {
            b.pin = start          // late: at the start of the stretch
            bills.append(b)
            return nil
        }
        if !b.paid && b.due > end { later.append(b); return nil }
        if b.paid { return "paid " + Day.fmt(b.paidOn.isEmpty ? b.due : b.paidOn, "d MMM") }
        return "last bill " + Day.fmt(b.due, "d MMM")
    }

    /// a card's latest bill: from its row, else from the agenda's line for it
    static func bill(of c: CardInfo, item: AgendaItem?) -> CardBill? {
        let dd: String = c.dueDate ?? ""
        let amt: Double = c.due ?? 0
        if dd.count == 10 && amt > 0 {
            let stmt: String = c.stmtOn ?? ""
            let pOn: String = c.paidOn ?? ""
            let pAmt: Double = c.paid ?? 0
            let from: String = stmt.isEmpty ? Day.add(dd, -25) : stmt
            let after: Bool = !pOn.isEmpty && pAmt > 0 && pOn >= from
            let full: Bool = after && pAmt >= amt - max(5, amt * 0.01)
            let booked: Bool = (item?.booked ?? false) && item?.date == dd
            var bill: CardBill = CardBill(id: c.id, cardID: c.id, title: CardWords.full(c), name: CardWords.title(c), last: c.last, color: c.color,
                                          amount: amt, minDue: c.minDue ?? 0, due: dd, stmtOn: stmt,
                                          paidAmt: after ? pAmt : 0, paidOn: after ? pOn : "", paid: full || booked)
            if after { bill.said = c.paidSaid ?? "" }
            return bill
        }
        if dd.count == 10 { return nil }   // the statement said nothing is due
        if let a = item, let d = a.date, a.amt > 0 {
            return CardBill(id: c.id, cardID: c.id, title: CardWords.full(c), name: CardWords.title(c), last: c.last, color: c.color,
                            amount: a.amt, minDue: minimum(a.sub), due: d, stmtOn: "", paidAmt: 0, paidOn: "", paid: a.booked)
        }
        return nil
    }
    /// "Minimum ₹910" → 910
    static func minimum(_ sub: String) -> Double {
        guard sub.hasPrefix("Minimum") else { return 0 }
        return Double(sub.filter { $0.isNumber || $0 == "." }) ?? 0
    }
    /// why a card is in the quiet list
    static func quietNote(_ c: CardInfo, spent: Double, today: String) -> String {
        if let w = c.sharesBill, !w.isEmpty { return "billed with ••" + w }
        if let cr = c.credit, cr > 0 { return "in credit " + Fmt.short(cr) }
        if spent > 0 { return Fmt.short(spent) + " spent, bill not out yet" }
        if c.dueDate?.count == 10 && (c.due ?? 0) <= 0 { return "nothing due on its statement" }
        if !c.lastUsed.isEmpty {
            if c.lastUsed >= Day.add(today, -30) { return "last used " + Day.fmt(c.lastUsed, "d MMM") }
            return "last used " + Day.fmt(c.lastUsed, c.lastUsed.prefix(4) == today.prefix(4) ? "MMM" : "MMM yyyy")
        }
        let seen: String = CardWords.seen(c)
        return seen.isEmpty ? "not used yet" : seen
    }
}

extension CardBill {
    func daysLeft(_ today: String) -> Int { Day.between(today, due) }
    /// what is still to pay on it
    var left: Double { paid ? 0 : max(0, amount - paidAmt) }
    /// "in 5 days", "tomorrow", "due today", "3 days late", "paid 5 Oct"
    func when(_ today: String) -> String {
        if paid { return "paid " + Day.fmt(paidOn.isEmpty ? due : paidOn, "d MMM") }
        let n: Int = daysLeft(today)
        if n == 0 { return "due today" }
        if n == 1 { return "tomorrow" }
        if n < 0 { return n == -1 ? "1 day late" : String(-n) + " days late" }
        return "in " + String(n) + " days"
    }
    /// under the card's name, longest first (the row keeps the first that fits): "••7710 · min ₹910",
    /// "••7710 · ₹5,000 paid so far · min ₹910", "••5506 · paid 28 Sep"
    var lines: [String] {
        let tag: String = last.isEmpty ? "" : "••" + last + " · "
        if paid {
            let on: String = "paid " + Day.fmt(paidOn.isEmpty ? due : paidOn, "d MMM")
            return [tag + on, on]
        }
        let least: String = minDue > 0 ? "min " + Fmt.rupees(minDue) : ""
        if paidAmt > 0 {
            let full: String = tag + Fmt.rupees(paidAmt) + " paid so far" + (least.isEmpty ? "" : " · " + least)
            return [full, tag + Fmt.short(paidAmt) + " paid so far", Fmt.short(paidAmt) + " paid so far"]
        }
        if least.isEmpty {
            let base: String = last.isEmpty ? "from your mail" : "••" + last
            return [stmtOn.isEmpty ? base : base + " · statement " + Day.fmt(stmtOn, "d MMM"), base]
        }
        return [tag + least, least]
    }
    func spoken(_ today: String) -> String {
        let day: String = Day.fmt(paid && !paidOn.isEmpty ? paidOn : due, "EEEE d MMMM")
        var state: String = paid ? "paid " + day : "due " + day + ", " + when(today)
        if !paid && minDue > 0 { state += ", minimum " + Fmt.rupees(minDue) }
        if !paid && paidAmt > 0 { state += ", " + Fmt.rupees(paidAmt) + " paid so far" }
        return title + ", " + Fmt.rupees(amount) + ", " + state
    }
}

extension Store {
    /// the bills on these cards for the stretch, the ones due after it, and the cards with none
    func billBook(_ cards: [CardInfo], spend: [String: Double], orphans: Bool) -> BillBook {
        let today: String = snap.today
        var book = BillBook(today: today)
        let agenda: [AgendaItem] = snap.agenda.filter { $0.cat == "Card Payments" && ($0.date ?? "").count == 10 }
        var claimed = Set<String>()
        for c in cards {
            let key: String = c.id.replacingOccurrences(of: " CC ", with: " card ")
            var item: AgendaItem? = nil
            for a in agenda where a.name.hasPrefix(key) {
                claimed.insert(a.id)
                if item == nil || (a.date ?? "") > (item?.date ?? "") { item = a }
            }
            let spent: Double = spend[c.id] ?? 0
            var note: String? = BillBook.quietNote(c, spent: spent, today: today)
            if let b = BillBook.bill(of: c, item: item) {
                note = book.place(b)
                if note != nil && spent > 0 { note = BillBook.quietNote(c, spent: spent, today: today) }
            }
            if let n = note { book.quiet.append(QuietCard(card: c, note: n)) }
        }
        if orphans {
            for a in agenda where !claimed.contains(a.id) && a.amt > 0 {
                guard let d = a.date else { continue }
                let twin: Bool = (book.bills + book.later).contains { $0.due == d && abs($0.amount - a.amt) < 1 }
                if twin { continue }
                let title: String = a.name.hasSuffix(" bill") ? String(a.name.dropLast(5)) : a.name
                let head: String = title.split(separator: " ").first.map(String.init) ?? ""
                let hex: String = cards.first(where: { $0.bank == head })?.color ?? "#636366"
                let b = CardBill(id: "agenda:" + a.id, cardID: nil, title: title, name: title, last: "", color: hex,
                                 amount: a.amt, minDue: BillBook.minimum(a.sub), due: d, stmtOn: "", paidAmt: 0, paidOn: "", paid: a.booked)
                _ = book.place(b)
            }
        }
        book.bills.sort { $0.pin != $1.pin ? $0.pin < $1.pin : $0.amount > $1.amount }
        book.later.sort { $0.due < $1.due }
        book.quiet.sort { a, b in
            let x: Double = spend[a.card.id] ?? 0
            let y: Double = spend[b.card.id] ?? 0
            if x != y { return x > y }
            return a.card.lastUsed != b.card.lastUsed ? a.card.lastUsed > b.card.lastUsed : a.card.id < b.card.id
        }
        return book
    }
}

// MARK: - Days and groups

/// one due day: its bills (still to pay first, biggest first; paid ones at the foot) and what it adds up to
struct BillDay: Identifiable, Hashable {
    let day: String
    let bills: [CardBill]
    var id: String { day }
    var total: Double { bills.reduce(0) { $0 + $1.amount } }
    var left: Double { bills.reduce(0) { $0 + $1.left } }
    var paidN: Int { bills.filter { $0.paid }.count }
    var openN: Int { bills.count - paidN }
    var allPaid: Bool { openN == 0 }
}

extension BillBook {
    /// every bill in the countdown: the stretch's, then the ones due after it
    var all: [CardBill] { bills + later }
    var total: Double { all.reduce(0) { $0 + $1.amount } }
    var left: Double { all.reduce(0) { $0 + $1.left } }

    static func order(_ bs: [CardBill]) -> [CardBill] {
        bs.sorted { a, b in
            if a.paid != b.paid { return !a.paid }
            if a.amount != b.amount { return a.amount > b.amount }
            return a.id < b.id
        }
    }
    static func days(_ bs: [CardBill]) -> [BillDay] {
        let by: [String: [CardBill]] = Dictionary(grouping: bs, by: { $0.due })
        return by.keys.sorted().map { d in BillDay(day: d, bills: order(by[d] ?? [])) }
    }
}

// MARK: - The words

enum BillWords {
    static func bills(_ n: Int) -> String { n == 1 ? "1 bill" : String(n) + " bills" }
    /// "Monday", "Today", "Tomorrow", or "The 18th" when it's more than a week off
    static func dayName(_ d: String, today: String) -> String {
        let n: Int = Day.between(today, d)
        if n == 0 { return "Today" }
        if n == 1 { return "Tomorrow" }
        if n >= 2 && n <= 6 { return Day.fmt(d, "EEEE") }
        return "The " + ordinal(Day.dayNumber(d))
    }
    /// the line under the total: what's urgent, else the big day, else what's next
    static func quip(_ book: BillBook) -> String {
        let today: String = book.today
        let open: [CardBill] = book.all.filter { !$0.paid }
        if open.isEmpty { return book.all.isEmpty ? "" : "All paid up. Your cards are on a well-earned break." }
        let late: [CardBill] = open.filter { $0.daysLeft(today) < 0 }
        if late.count == 1, let b = late.first {
            return b.name + " is " + b.when(today) + ". Pay it before the late fee says hello."
        }
        if late.count > 1 {
            let owed: Double = late.reduce(0) { $0 + $1.left }
            return String(late.count) + " bills are running late, " + Fmt.rupees(owed) + " in all. Those first."
        }
        let days: [BillDay] = BillBook.days(open)
        if let big = days.filter({ $0.openN >= 3 }).max(by: { $0.openN != $1.openN ? $0.openN < $1.openN : $0.day > $1.day }) {
            return dayName(big.day, today: today) + "’s a big one: " + bills(big.openN) + ", " + Fmt.rupees(big.left) + "."
        }
        guard let next = open.min(by: { $0.due != $1.due ? $0.due < $1.due : $0.amount > $1.amount }) else { return "" }
        let n: Int = next.daysLeft(today)
        if n == 0 { return next.name + " wants " + Fmt.rupees(next.left) + " today. Don’t keep it waiting." }
        if n >= 7 { return "Nothing due this week. Breathe easy." }
        return "Next up: " + next.name + ", " + Fmt.rupees(next.left) + " " + next.when(today) + "."
    }
}

/// the countdown's colours: red for late, amber for this week, the accent for later, green for paid
enum BillInk {
    static let late = Color(light: "#C2361F", dark: "#FF8A75")
    static let soon = Color(light: "#A35A00", dark: "#FFB04D")
    static let paid = Color(light: "#1A7A43", dark: "#5FD38A")
    static let tick = Color(light: "#1A7A43", dark: "#30D158")
}

// MARK: - The Bills segment: every card bill by when it falls

/// Accounts & cards › Bills: what's to pay in one figure, then the bills by when they fall (late, the next seven
/// days, later), the ones paid this cycle, and the cards whose statement is on the way. Each group folds to one
/// line (remembered); tap a bill to open its card.
struct CardBillsList: View {
    @Environment(Store.self) private var store
    let go: (String) -> Void
    /// the groups folded to one line (paid ones and statements on the way start folded), kept on the phone and
    /// read into state so folding animates
    @AppStorage("bills.shut") private var saved = "paid,coming"
    @State private var shut: [String]?

    func isShut(_ id: String) -> Bool { (shut ?? saved.split(separator: ",").map(String.init)).contains(id) }
    func toggle(_ id: String) {
        var ids: [String] = shut ?? saved.split(separator: ",").map(String.init)
        let opening: Bool = ids.contains(id)
        if let i = ids.firstIndex(of: id) { ids.remove(at: i) } else { ids.append(id) }
        withAnimation(Fold.motion(opening: opening)) { shut = ids }
        saved = ids.joined(separator: ",")
    }
    struct BillSet: Identifiable {
        let id: String
        let title: String
        let ink: Color
        let bills: [CardBill]
    }

    var body: some View {
        let today: String = store.snap.today
        let cards: [CardInfo] = store.cards
        let spend: [String: Double] = store.cardSpend30(today: today)
        let book: BillBook = store.billBook(cards, spend: spend, orphans: store.who == .family)
        let open: [CardBill] = book.all.filter { !$0.paid && $0.left > 0 }.sorted { $0.due != $1.due ? $0.due < $1.due : $0.left > $1.left }
        let toPay: Double = open.reduce(0) { $0 + $1.left }
        let late: [CardBill] = open.filter { $0.daysLeft(today) < 0 }
        let groups: [BillSet] = [
            BillSet(id: "late", title: "Late", ink: BillInk.late, bills: late),
            BillSet(id: "week", title: "Next 7 days", ink: BillInk.soon, bills: open.filter { (0...7).contains($0.daysLeft(today)) }),
            BillSet(id: "later", title: "Later", ink: Color.secondary, bills: open.filter { $0.daysLeft(today) > 7 }),
            BillSet(id: "paid", title: "Paid this cycle", ink: BillInk.paid, bills: book.all.filter { $0.paid }.sorted { $0.due > $1.due }),
        ].filter { !$0.bills.isEmpty }
        let coming: [CardInfo] = book.quiet.filter { (spend[$0.card.id] ?? 0) > 0 }.map(\.card)
        let line: String = open.isEmpty
            ? (book.all.isEmpty ? "No card bills in your mail yet." : "Nothing to pay. Every bill’s settled.")
            : "due across " + BillWords.bills(open.count) + (late.isEmpty ? "" : (late.count == 1 ? " · pay the late one first" : " · the late ones first"))
        ScrollView {
            VStack(alignment: .leading, spacing: 0) {
                VStack(alignment: .leading, spacing: 2) {
                    Text(Fmt.rupees(toPay))
                        .font(.system(.largeTitle, design: .rounded, weight: .bold)).monospacedDigit()
                        .contentTransition(.numericText(value: toPay))
                        .privacySensitive()
                    Text(line).font(.system(.subheadline)).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                }
                .padding(.horizontal, 4)
                .padding(.top, 6)
                .accessibilityElement(children: .combine)
                ForEach(groups) { g in
                    let total: String = Fmt.rupees(g.bills.reduce(0) { $0 + (g.id == "paid" ? $1.amount : $1.left) })
                    let folded: Bool = isShut(g.id)
                    BillGroupHead(title: g.title, ink: g.ink, figure: total, folded: folded) { toggle(g.id) }
                    Unfold(open: folded) {
                        BillFold(hexes: g.bills.map(\.color), line: BillFold.line(g.bills.map(\.name), count: g.bills.count)) { toggle(g.id) }
                    }
                    Unfold(open: !folded) {
                        VStack(spacing: 0) {
                            ForEach(Array(g.bills.enumerated()), id: \.element.id) { i, b in
                                if i > 0 { RowRule(inset: 70) }
                                BillLine(b: b, today: today) { if let id = b.cardID { go(id) } }
                            }
                        }
                        .background(Color.surface, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                    }
                }
                if !coming.isEmpty {
                    let folded: Bool = isShut("coming")
                    BillGroupHead(title: "Statements on the way", ink: Color.secondary, figure: String(coming.count), folded: folded) { toggle("coming") }
                    Unfold(open: folded) {
                        BillFold(hexes: coming.map(\.color), line: BillFold.line(coming.map { CardWords.title($0) }, count: coming.count, noun: "card")) { toggle("coming") }
                    }
                    Unfold(open: !folded) {
                        VStack(spacing: 0) {
                            ForEach(Array(coming.enumerated()), id: \.element.id) { i, c in
                                if i > 0 { RowRule(inset: 70) }
                                ComingLine(c: c, spent: spend[c.id] ?? 0, today: today) { go(c.id) }
                            }
                        }
                        .background(Color.surface, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                    }
                }
                Text("Tap a bill to open its card. Cards with nothing due stay on Cards, resting.")
                    .font(.system(.footnote)).foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
                    .padding(.horizontal, 4)
                    .padding(.top, 22)
            }
            .padding(.horizontal, 20)
            .padding(.top, 14)
            .padding(.bottom, 40)
        }
    }
}

/// a group's heading: its name in its colour, its figure, and a chevron that folds it
struct BillGroupHead: View {
    let title: String
    let ink: Color
    let figure: String
    let folded: Bool
    let toggle: () -> Void
    var body: some View {
        Button(action: toggle) {
            HStack(alignment: .firstTextBaseline, spacing: 8) {
                Text(title.uppercased()).font(.system(.footnote, weight: .bold)).tracking(0.5).foregroundStyle(ink)
                Spacer(minLength: 8)
                Text(figure).font(.system(.footnote, design: .rounded)).monospacedDigit().foregroundStyle(.secondary).privacySensitive()
                Image(systemName: "chevron.down")
                    .font(.system(.caption2, weight: .bold)).foregroundStyle(.tertiary)
                    .rotationEffect(.degrees(folded ? -90 : 0))
                    .animation(Fold.turn, value: folded)
            }
            .padding(.horizontal, 4)
            .padding(.top, 24)
            .padding(.bottom, 8)
            .contentShape(Rectangle())
        }
        .buttonStyle(.press)
        .accessibilityAddTraits(.isHeader)
        .accessibilityHint(folded ? "Shows its bills" : "Folds it to one line")
    }
}

/// a group, folded: its cards fanned small and who's in it, in a line
struct BillFold: View {
    let hexes: [String]
    let line: String
    let open: () -> Void
    /// "HDFC Regalia, SBI SimplyCLICK and 3 more"
    static func line(_ names: [String], count: Int, noun: String = "bill") -> String {
        let shown: [String] = Array(names.prefix(2))
        let more: Int = count - shown.count
        if more <= 0 { return shown.joined(separator: " and ") }
        return shown.joined(separator: ", ") + " and " + String(more) + " more"
    }
    var body: some View {
        Button(action: open) {
            HStack(spacing: 12) {
                ZStack(alignment: .leading) {
                    ForEach(Array(hexes.prefix(4).enumerated()), id: \.offset) { i, h in
                        MiniCard(hex: h, width: 34)
                            .shadow(color: .black.opacity(0.25), radius: 2, y: 1)
                            .offset(x: CGFloat(i) * 10)
                    }
                }
                .frame(width: 34 + CGFloat(max(0, min(4, hexes.count) - 1)) * 10, alignment: .leading)
                .accessibilityHidden(true)
                Text(line).font(.system(.footnote, weight: .semibold)).lineLimit(1).truncationMode(.tail)
                Spacer(minLength: 4)
            }
            .padding(.vertical, 12)
            .padding(.horizontal, 14)
            .background(Color.surface, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            .contentShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
        }
        .buttonStyle(.press)
        .accessibilityHint("Shows them")
    }
}

/// one bill: its card, what's left (or what was paid), and when
struct BillLine: View {
    let b: CardBill
    let today: String
    let tap: () -> Void
    var body: some View {
        let n: Int = b.daysLeft(today)
        let ink: Color = b.paid ? BillInk.paid : n < 0 ? BillInk.late : n <= 7 ? BillInk.soon : Color.secondary
        let amount: String = Fmt.rupees(b.paid ? b.amount : b.left)
        let when: String = b.paid ? b.when(today) : (n < 0 || n <= 1 ? b.when(today) : Day.fmt(b.due, n <= 6 ? "EEE d MMM" : "d MMM"))
        let sub: String = b.lines.first ?? ""
        Button(action: tap) {
            HStack(spacing: 12) {
                MiniCard(hex: b.color, width: 44)
                VStack(alignment: .leading, spacing: 1) {
                    Text(b.name).font(.system(.subheadline, weight: .semibold)).lineLimit(1)
                    Text(sub).font(.system(.footnote)).foregroundStyle(.secondary).lineLimit(1).privacySensitive()
                }
                Spacer(minLength: 6)
                VStack(alignment: .trailing, spacing: 1) {
                    Text(amount).strikethrough(b.paid, color: Color.secondary)
                        .font(.system(.callout, design: .rounded, weight: .bold)).monospacedDigit()
                        .foregroundStyle(n < 0 && !b.paid ? BillInk.late : Color.primary)
                        .privacySensitive()
                    Text(when).font(.system(.caption, weight: .semibold)).foregroundStyle(ink)
                }
            }
            .padding(.vertical, 12)
            .padding(.horizontal, 14)
            .contentShape(Rectangle())
        }
        .buttonStyle(.press)
        .disabled(b.cardID == nil)
        .spokenFigures(b.spoken(today), hidden: b.title + (b.paid ? ", paid" : ", due " + Day.fmt(b.due, "EEEE d MMMM")))
        .accessibilityHint(b.cardID == nil ? "" : "Opens its card")
    }
}

/// a card with spends whose statement hasn't come yet: what's on it, and when its bill should land
struct ComingLine: View {
    let c: CardInfo
    let spent: Double
    let today: String
    let tap: () -> Void
    var body: some View {
        let next: String? = CardPiles.nextStatement(c, today: today)
        let sub: String = Fmt.rupees(spent) + " in 30 days"
        let when: String = next.map { "around " + Day.fmt($0, "d MMM") } ?? "not out yet"
        Button(action: tap) {
            HStack(spacing: 12) {
                MiniCard(hex: c.color, width: 44)
                VStack(alignment: .leading, spacing: 1) {
                    Text(CardWords.title(c)).font(.system(.subheadline, weight: .semibold)).lineLimit(1)
                    Text(sub).font(.system(.footnote)).foregroundStyle(.secondary).lineLimit(1).privacySensitive()
                }
                Spacer(minLength: 6)
                VStack(alignment: .trailing, spacing: 1) {
                    Text("Statement").font(.system(.footnote, weight: .semibold)).foregroundStyle(.secondary)
                    Text(when).font(.system(.caption, weight: .semibold)).foregroundStyle(.secondary)
                }
            }
            .padding(.vertical, 12)
            .padding(.horizontal, 14)
            .contentShape(Rectangle())
        }
        .buttonStyle(.press)
        .accessibilityHint("Opens its card")
    }
}
