import SwiftUI
import UIKit

// MARK: - The intro: the running drawing, frame by frame
// (split out of KoshIntro.swift, 30 Oct 2026; the beats and what each draws are described there)

// MARK: - The running drawing: state that changes every frame, kept out of SwiftUI's sight

final class IntroSim {
    let g: IntroGraph = IntroGraph.shared
    private(set) var scene: IntroScene?
    private var lastTime: Double?
    private(set) var t: Double = 0
    private(set) var drawT: Double = 0
    private(set) var beatElapsed: Double = 0
    private var beat: Int = 0
    private var story: Int = -1
    private var conv: Double = 0
    private(set) var endT: Double = 0
    private var rot: Double = 0
    private var flapPhase: Double = 0
    private var flapAmp: Double = 0.032
    private var swirlA: Double = 0.045
    private var swirlP: Double = 0
    private var waveA: Double = 1.2
    private var chaos: Double = 0
    private var cometT0: Double = 0
    private var poke: Double = -9
    private var lit: [Double]
    private var em: [Double]
    private var ping: [Double]
    private var ripples: [IntroRipple] = []
    private var sparks: [IntroSpark] = []
    private var spawnAcc: Double = 0
    private var rr: Int = 0
    private var autoRip: Double = 0
    private var cur: [[CGPoint]] = []
    private var frac: [Double] = []
    private var csNow: [Double] = []
    private var boost: [CGFloat] = []
    private var shown: [CGPoint]
    private var vis: [Double]
    private var boxes: [CGRect]
    private var labelDark: Bool? = nil
    private var labels: [(GraphicsContext.ResolvedText, GraphicsContext.ResolvedText)] = []
    private var active: [(p: CGPoint, r: CGFloat, a: CGFloat)] = []
    private var flap: CGFloat = 0
    private var still: Bool = false

    init() {
        let n: Int = IntroGraph.shared.nodes.count
        lit = Array(repeating: 0.1, count: IntroGraph.shared.edges.count)
        em = Array(repeating: 0.3, count: n)
        ping = Array(repeating: 0, count: n)
        shown = Array(repeating: .zero, count: n)
        vis = Array(repeating: 0, count: n)
        boxes = Array(repeating: .null, count: n)
    }

    static let durations: [Double] = [3.2, 3.0, 4.2, 3.2, Double.infinity]

    // MARK: Called from the screen

    /// the short intro opens on the tangle itself, drawing in as it would have on the first beat
    func begin(at b: Int) {
        guard beat < b else { return }
        beat = b
        beatElapsed = 0
        spawnAcc = 0
        story = -1
        if b == 3 { cometT0 = t }
    }

    func enter(beat b: Int) {
        guard b != beat else { return }
        beat = b
        beatElapsed = 0
        spawnAcc = 0
        story = -1
        if b > 0 { drawT = max(drawT, 2.6) }
        if b == 3 { cometT0 = t }
    }

    /// a new look draws itself in again
    func redraw() {
        drawT = 0
        sparks = []
        ripples = []
        cometT0 = t
        scene = nil
    }

    func touch(_ location: CGPoint) {
        guard let sc = scene else { return }
        let p: CGPoint = CGPoint(x: location.x - sc.origin.x, y: location.y - sc.origin.y)
        if onLogo(location) { return }
        addRipple(p, 8)
    }

    func hit(_ location: CGPoint) -> Int? {
        guard let sc = scene, conv < 0.3 else { return nil }
        let p: CGPoint = CGPoint(x: location.x - sc.origin.x, y: location.y - sc.origin.y)
        var best: Int? = nil
        var bd: CGFloat = .greatestFiniteMagnitude
        for i in shown.indices where vis[i] >= 0.5 {
            let d: CGFloat = hypot(p.x - shown[i].x, p.y - shown[i].y)
            if (boxes[i].contains(p) || d < 18) && d < bd {
                bd = d
                best = i
            }
        }
        return best
    }

    func onLogo(_ location: CGPoint) -> Bool {
        guard let sc = scene, beat == 4, endT > 3.6 else { return false }
        let p: CGPoint = CGPoint(x: location.x - sc.origin.x, y: location.y - sc.origin.y)
        return abs(p.x) < sc.logo.tw / 2 && abs(p.y - sc.logo.tcy) < sc.logo.tw / 2
    }

    /// the coin flips and the lid hops; false while the last one is still going
    func pokeLogo() -> Bool {
        guard t - poke > 1 else { return false }
        poke = t
        return true
    }

    // MARK: Step

    private func addRipple(_ p: CGPoint, _ a: CGFloat) {
        if still { return }
        ripples.append(IntroRipple(p: p, a: a, t: t))
        if ripples.count > 9 { ripples.removeFirst() }
    }

    private func storyRoute() -> IntroRoute? {
        guard beat == 2, story >= 0, story < g.story.count else { return nil }
        return g.routes[g.story[story]]
    }

    private func litTarget(_ e: Int, _ i: IntroInput) -> Double {
        if let f = i.focus { return g.edgesOf[f].contains(e) ? 1 : 0.035 }
        switch beat {
        case 0: return g.edges[e].aw ? 0.95 : 0.1
        case 1: return g.edges[e].aw ? 0.26 : 0.95
        case 2:
            if let r = storyRoute(), r.aw == e || r.wp == e { return 1 }
            return 0.16
        case 3: return 0.8
        default: return 0.5
        }
    }

    private func emTarget(_ n: Int, _ i: IntroInput) -> Double {
        if let f = i.focus { return f == n ? 1 : (g.nodesOf[f].contains(n) ? 0.82 : 0.12) }
        let tier: IntroTier = g.nodes[n].tier
        switch beat {
        case 0: return tier == .app ? 1 : (tier == .wallet ? 0.4 : 0.3)
        case 1: return tier == .wallet ? 1 : (tier == .portal ? 0.6 : 0.42)
        case 2:
            if let r = storyRoute(), r.app == n || r.wallet == n || r.portal == n { return 1 }
            return tier == .portal ? 0.5 : 0.3
        case 3: return 0.78
        default: return 0.5
        }
    }

    private func edgeSpark(_ e: Int, _ dur: Double) {
        guard let sc = scene, sc.byEdge[e].count > 1 else { return }
        let s: Int = sc.byEdge[e][1]
        let edge: IntroEdge = g.edges[e]
        sparks.append(IntroSpark(parts: [(strand: s, rev: true)], total: sc.strands[s].pts.count - 1,
                                 tiers: [g.nodes[edge.from].tier, g.nodes[edge.to].tier], t0: t, dur: dur, end: edge.to))
    }

    private func routeSpark(_ ri: Int, _ dur: Double) {
        guard let sc = scene else { return }
        let r: IntroRoute = g.routes[ri]
        guard sc.byEdge[r.aw].count > 2, sc.byEdge[r.wp].count > 2 else { return }
        let a: Int = sc.byEdge[r.aw][1]
        let b: Int = sc.byEdge[r.wp][2]
        let total: Int = sc.strands[a].pts.count + sc.strands[b].pts.count - 2
        sparks.append(IntroSpark(parts: [(strand: a, rev: true), (strand: b, rev: true)], total: total,
                                 tiers: [.app, .wallet, .portal], t0: t, dur: dur, end: r.portal))
    }

    private func spawn(_ dt: Double, _ i: IntroInput) {
        if i.still || conv > 0.05 { return }
        spawnAcc += dt
        if let f = i.focus {
            if spawnAcc > 0.17, let r = g.routesOf[f].randomElement() {
                spawnAcc = 0
                routeSpark(r, 1.5)
            }
            return
        }
        if drawT < 1.6 { return }
        switch beat {
        case 0:
            if spawnAcc > 0.26 {
                spawnAcc = 0
                edgeSpark(g.awEdges[rr % g.awEdges.count], 1.1)
                rr += 1
            }
        case 1:
            if spawnAcc > 0.19 {
                spawnAcc = 0
                edgeSpark(g.wpEdges[rr % g.wpEdges.count], 1.1)
                rr += 1
            }
        case 2:
            if spawnAcc > 0.5, story >= 0, story < g.story.count {
                spawnAcc = 0
                routeSpark(g.story[story], 1.35)
            }
        case 3:
            while spawnAcc > 0.055 {
                spawnAcc -= 0.055
                if sparks.count < 110 { routeSpark(Int.random(in: 0..<g.routes.count), 1.3 + Double.random(in: 0...0.9)) }
            }
            autoRip += dt
            if autoRip > 0.75 {
                autoRip = 0
                addRipple(shown[Int.random(in: 0..<shown.count)], 5)
            }
        default:
            break
        }
    }

    private func step(_ time: Double, _ i: IntroInput) {
        let dt: Double = min(0.05, max(0, time - (lastTime ?? time)))
        lastTime = time
        still = i.still
        t += dt
        enter(beat: i.beat)
        if i.story != story {
            story = i.story
            if beat == 2, i.focus == nil, story >= 0, story < g.story.count, !i.still {
                spawnAcc = 0
                routeSpark(g.story[story], 1.35)
            }
        }
        drawT += i.still ? 10 : dt
        if i.focus == nil && !i.dragging { beatElapsed += dt }
        let target: Double = beat == 4 ? 1 : 0
        let rate: Double = dt / (i.still ? 0.35 : 2.0)
        conv += max(-rate, min(rate, target - conv))
        if beat == 4 { endT += i.still ? 10 : dt } else if conv < 0.02 { endT = 0 }
        rot += dt * 0.11 * conv
        let chaotic: Bool = beat == 3 && i.focus == nil && !i.still
        let flapTarget: Double = i.still ? 0 : (chaotic ? 0.075 : (beat == 4 ? 0 : 0.032))
        flapAmp += (flapTarget - flapAmp) * min(1, dt * 2.5)
        flapPhase += dt * Double.pi * 2 / (chaotic ? 1.5 : 3.4)
        swirlA += ((i.still ? 0 : (chaotic ? 0.13 : 0.045)) - swirlA) * min(1, dt * 2)
        swirlP += dt * (chaotic ? 1.5 : 0.7)
        waveA += ((i.still ? 0 : (chaotic ? 4.2 : 1.2)) - waveA) * min(1, dt * 2.5)
        chaos += ((chaotic ? 1 : 0) - chaos) * min(1, dt * 3)
        for e in lit.indices { lit[e] += (litTarget(e, i) - lit[e]) * min(1, dt * 5) }
        for n in em.indices {
            em[n] += (emTarget(n, i) - em[n]) * min(1, dt * 6)
            ping[n] = max(0, ping[n] - dt * 1.7)
        }
        let now: Double = t
        ripples.removeAll { (r: IntroRipple) -> Bool in now - r.t >= 1.8 }
        var kept: [IntroSpark] = []
        for s in sparks {
            if now - s.t0 < s.dur { kept.append(s) } else { ping[s.end] = 1 }
        }
        sparks = kept
        spawn(dt, i)
    }

    // MARK: Draw

    private func warp(_ p: CGPoint, _ j: Int, _ n: Int, _ seed: Double, _ look: IntroLook, _ lz: (lx: CGFloat, ly: CGFloat, oy: CGFloat)?) -> CGPoint {
        var x: CGFloat = p.x
        var y: CGFloat = p.y
        switch look {
        case .wings:
            if flap != 0 {
                let ax: CGFloat = abs(x)
                x *= 1 - flap
                y -= flap * ax * 0.25
            }
        }
        return CGPoint(x: x, y: y)
    }

    private func rippled(_ p: CGPoint) -> (CGPoint, CGFloat) {
        var x: CGFloat = p.x
        var y: CGFloat = p.y
        var b: CGFloat = 0
        for r in active {
            let dx: CGFloat = x - r.p.x
            let dy: CGFloat = y - r.p.y
            let d: CGFloat = sqrt(dx * dx + dy * dy) + 0.001
            let df: CGFloat = d - r.r
            if df > 66 || df < -66 { continue }
            let k: CGFloat = exp(-df * df / 968) * r.a
            x += dx / d * k
            y += dy / d * k
            b += k
        }
        return (CGPoint(x: x, y: y), b)
    }

    private func poly(_ c: [CGPoint], _ fr: Double) -> Path {
        var p = Path()
        guard c.count > 1, fr > 0 else { return p }
        p.move(to: c[0])
        let m: Double = fr * Double(c.count - 1)
        let full: Int = min(c.count - 1, Int(m))
        if full >= 1 {
            for i in 1...full { p.addLine(to: c[i]) }
        }
        if full < c.count - 1 {
            let f: CGFloat = CGFloat(m - Double(full))
            let a: CGPoint = c[full]
            let b: CGPoint = c[full + 1]
            p.addLine(to: CGPoint(x: a.x + (b.x - a.x) * f, y: a.y + (b.y - a.y) * f))
        }
        return p
    }

    private func sparkAt(_ s: IntroSpark, _ u: Double) -> CGPoint {
        var g: Double = IntroMath.clamp(u) * Double(s.total)
        for (pi, part) in s.parts.enumerated() {
            let c: [CGPoint] = cur[part.strand]
            let segs: Int = c.count - 1
            if g <= Double(segs) || pi == s.parts.count - 1 {
                g = min(g, Double(segs))
                let i: Int = min(segs - 1, Int(g))
                let f: CGFloat = CGFloat(g - Double(i))
                let i0: Int = part.rev ? segs - i : i
                let i1: Int = part.rev ? i0 - 1 : i0 + 1
                return CGPoint(x: c[i0].x + (c[i1].x - c[i0].x) * f, y: c[i0].y + (c[i1].y - c[i0].y) * f)
            }
            g -= Double(segs)
        }
        return .zero
    }

    private func tierAt(_ s: IntroSpark, _ u: Double) -> Color {
        let k: Int = min(s.tiers.count - 1, Int((IntroMath.clamp(u) * Double(s.tiers.count - 1)).rounded()))
        return IntroInk.of(s.tiers[k])
    }

    private func ensureScene(_ size: CGSize, _ look: IntroLook) -> IntroScene {
        if let sc = scene, sc.size == size, sc.look == look { return sc }
        let sc: IntroScene = IntroScene(look: look, size: size)
        scene = sc
        cur = sc.strands.map { (st: IntroStrand) -> [CGPoint] in st.pts }
        frac = Array(repeating: 0, count: sc.strands.count)
        csNow = Array(repeating: 0, count: sc.strands.count)
        boost = Array(repeating: 0, count: sc.strands.count)
        sparks = []
        return sc
    }

    private func ensureLabels(_ ctx: GraphicsContext, _ dark: Bool) {
        if labelDark == dark && labels.count == g.nodes.count { return }
        labelDark = dark
        labels = g.nodes.map { (n: IntroNode) -> (GraphicsContext.ResolvedText, GraphicsContext.ResolvedText) in
            let a: GraphicsContext.ResolvedText = ctx.resolve(Text(n.name).font(.system(size: 9.5, weight: .medium, design: .monospaced)))
            let b: GraphicsContext.ResolvedText = ctx.resolve(Text(n.name).font(.system(size: 9.5, weight: .semibold, design: .monospaced)))
            return (a, b)
        }
    }

    /// one frame: move everything on, then draw it
    func render(_ ctx: inout GraphicsContext, size: CGSize, time: Double, input: IntroInput, dark: Bool) {
        guard size.width > 40, size.height > 80 else { return }
        let sc: IntroScene = ensureScene(size, input.look)
        step(time, input)
        ensureLabels(ctx, dark)
        ctx.translateBy(x: sc.origin.x, y: sc.origin.y)
        let convE: Double = IntroMath.ease(conv)
        let fade: Double = 1 - convE
        flap = input.look == .wings ? CGFloat(flapAmp * (0.5 - 0.5 * cos(flapPhase)) * fade) : 0
        let jit: Double = chaos
        active = []
        for r in ripples {
            let age: Double = t - r.t
            let a: CGFloat = r.a * CGFloat(exp(-age * 2.1))
            if a > 0.15 { active.append((p: r.p, r: CGFloat(330 * age), a: a)) }
        }
        let tg: Double = IntroMath.ease(IntroMath.clamp((endT - 1.7) / 0.85))
        let coinK: Double = IntroMath.ease(IntroMath.clamp((endT - 2.35) / 0.45))
        let ring: CGPoint = CGPoint(x: 0, y: sc.logo.coinY)
        let ringR: CGFloat = sc.logo.r0 + (sc.logo.rc - sc.logo.r0) * CGFloat(tg)
        let logoAlpha: Double = beat == 4 ? 1 : convE

        if fade > 0.005 { drawAmbient(&ctx, sc, fade, dark, input) }
        drawTile(&ctx, sc, logoAlpha, dark)
        drawStrings(&ctx, sc, input, dark, jit: jit, tg: tg, coinK: coinK, ring: ring, ringR: ringR)
        drawLogo(&ctx, sc, logoAlpha)
        if !sparks.isEmpty { drawSparks(&ctx, fade, dark) }
        placeNodes(sc, input, fade)
        if fade > 0.01 { drawNodes(&ctx, sc, input, dark) }
    }

    private func drawAmbient(_ ctx: inout GraphicsContext, _ sc: IntroScene, _ fade: Double, _ dark: Bool, _ i: IntroInput) {
        let ink: Color = Color.primary
        let amb: Double = dark ? 0.075 : 0.06
        switch sc.look {
        case .wings:
            for (ci, ch) in sc.chords.enumerated() {
                let fr: Double = i.still ? 1 : IntroMath.easeOut(IntroMath.clamp((drawT - sc.chordDelay[ci]) / 0.6))
                if fr <= 0 { continue }
                let a0: (CGPoint, CGFloat) = rippled(warp(ch[0], -1, 0, 0, sc.look, nil))
                let a1: (CGPoint, CGFloat) = rippled(warp(ch[1], -1, 0, 0, sc.look, nil))
                let mid: (CGPoint, CGFloat) = rippled(warp(CGPoint(x: (ch[0].x + ch[1].x) / 2, y: (ch[0].y + ch[1].y) / 2), -1, 0, 0, sc.look, nil))
                let cx: CGFloat = 2 * mid.0.x - (a0.0.x + a1.0.x) / 2
                let cy: CGFloat = 2 * mid.0.y - (a0.0.y + a1.0.y) / 2
                var p = Path()
                p.move(to: a0.0)
                p.addQuadCurve(to: a1.0, control: CGPoint(x: cx, y: cy))
                let a: Double = (amb * fr + Double(mid.1) * 0.025) * fade
                if a < 0.004 { continue }
                ctx.stroke(p, with: .color(ink.opacity(a)), lineWidth: 0.6)
            }
            let fr: Double = i.still ? 1 : IntroMath.easeOut(IntroMath.clamp((drawT - 0.2) / 1.5))
            for ol in sc.outlines {
                let pts: [CGPoint] = ol.map { (q: CGPoint) -> CGPoint in rippled(warp(q, -1, 0, 0, sc.look, nil)).0 }
                ctx.stroke(poly(pts, fr), with: .color(ink.opacity(amb * 2.2 * fade)), lineWidth: 0.8)
            }
        }
    }

    private func drawTile(_ ctx: inout GraphicsContext, _ sc: IntroScene, _ alpha: Double, _ dark: Bool) {
        guard endT > 1.9, alpha > 0 else { return }
        let k: Double = IntroMath.easeOut(IntroMath.clamp((endT - 1.95) / 0.8))
        if k <= 0 { return }
        let ts: CGFloat = sc.logo.tw * CGFloat(0.82 + 0.18 * k)
        let rect: CGRect = CGRect(x: -ts / 2, y: sc.logo.tcy - ts / 2, width: ts, height: ts)
        let shape: Path = Path(roundedRect: rect, cornerRadius: ts * 0.2237, style: .continuous)
        var c = ctx
        c.opacity = alpha * k
        c.fill(shape, with: .color(IntroInk.tile))
        if dark { c.stroke(shape, with: .color(Color.white.opacity(0.12)), lineWidth: 1) }
    }

    private func drawStrings(_ ctx: inout GraphicsContext, _ sc: IntroScene, _ i: IntroInput, _ dark: Bool,
                             jit: Double, tg: Double, coinK: Double, ring: CGPoint, ringR: CGFloat) {
        let ink: Color = Color.primary
        let ringInk: Color = Color.primary.mix(with: IntroInk.silver, by: tg)
        let base: Double = dark ? 0.14 : 0.11
        let ringA: Double = (dark ? 0.16 : 0.12) + tg * 0.5
        let lz = sc.lz
        for si in sc.strands.indices {
            let st: IntroStrand = sc.strands[si]
            let fr: Double = i.still ? 1 : IntroMath.easeOut(IntroMath.clamp((drawT - st.delay) / 0.85))
            frac[si] = fr
            if fr <= 0 { continue }
            let cs: Double = IntroMath.ease(IntroMath.clamp((conv - st.cs * 0.35) / 0.65))
            csNow[si] = cs
            // place every point: the look's own motion, the restless beat, the pull to the ring, any ripple
            let n: Int = st.pts.count
            var b: CGFloat = 0
            let rj: Double = st.rj * (1 - tg)
            for j in 0..<n {
                var p: CGPoint = warp(st.pts[j], j, n, st.seed, sc.look, lz)
                if jit > 0 {
                    p.x += CGFloat(sin(t * 9 + Double(j) * 0.8 + st.seed) * jit)
                    p.y += CGFloat(cos(t * 7.3 + Double(j) * 0.7 + st.seed * 1.7) * jit)
                }
                if cs > 0 {
                    let ang: Double = st.a0 + rot + Double(j) / Double(n - 1) * st.span
                    let rr: Double = Double(ringR) + rj + sin(t * 0.9 + st.seed) * 1.2 * cs
                    p.x += (ring.x + CGFloat(cos(ang) * rr) - p.x) * CGFloat(cs)
                    p.y += (ring.y + CGFloat(sin(ang) * rr) - p.y) * CGFloat(cs)
                }
                let q: (CGPoint, CGFloat) = rippled(p)
                cur[si][j] = q.0
                if j == n / 2 { b += q.1 / 9 }
            }
            boost[si] = min(1, b)
            let litV: Double = st.edge >= 0 ? lit[st.edge] : 0
            var a: Double = st.edge < 0 ? (dark ? 0.5 : 0.42) : base * (1 - litV * 0.5)
            a = (a * (1 - cs) + ringA * cs + Double(boost[si]) * 0.3) * (1 - coinK)
            if a < 0.004 { continue }
            ctx.stroke(poly(cur[si], fr), with: .color((cs > 0.5 ? ringInk : ink).opacity(a)), lineWidth: 0.75)
        }
        // antenna tips
        for si in sc.strands.indices where sc.strands[si].edge < 0 && frac[si] > 0.98 {
            let e: CGPoint = cur[si][cur[si].count - 1]
            ctx.fill(Path(ellipseIn: CGRect(x: e.x - 2, y: e.y - 2, width: 4, height: 4)), with: .color(ink.opacity((dark ? 0.7 : 0.6) * (1 - csNow[si]))))
        }
        // the lit colour pass
        if tg >= 1 { return }
        var c = ctx
        c.blendMode = dark ? .plusLighter : .normal
        let lit0: Double = (dark ? 0.46 : 0.72) * (1 - chaos * (dark ? 0.25 : 0.3))
        for (ei, e) in g.edges.enumerated() {
            if lit[ei] < 0.02 { continue }
            let ids: [Int] = sc.byEdge[ei]
            guard ids.count > 1, frac[ids[1]] > 0 else { continue }
            let m: [CGPoint] = cur[ids[1]]
            let shading: GraphicsContext.Shading = .linearGradient(Gradient(colors: [IntroInk.of(g.nodes[e.from].tier), IntroInk.of(g.nodes[e.to].tier)]),
                                                                    startPoint: m[m.count - 1], endPoint: m[0])
            for si in ids where frac[si] > 0 {
                let a: Double = (lit[ei] * lit0 * (1 - 0.55 * csNow[si]) + Double(boost[si]) * 0.25) * (1 - tg)
                if a < 0.01 { continue }
                c.opacity = min(1, a)
                c.stroke(poly(cur[si], frac[si]), with: shading, lineWidth: 1.15)
            }
        }
    }

    private func drawLogo(_ ctx: inout GraphicsContext, _ sc: IntroScene, _ alpha: Double) {
        guard endT > 2.3, alpha > 0 else { return }
        let lg: IntroLogoPlace = sc.logo
        let tt: Double = endT
        let coinK: Double = IntroMath.ease(IntroMath.clamp((tt - 2.35) / 0.45))
        let wl: Double = IntroMath.spring(IntroMath.clamp((tt - 2.6) / 0.75))
        let wr: Double = IntroMath.spring(IntroMath.clamp((tt - 2.72) / 0.75))
        let lidK: Double = IntroMath.spring(IntroMath.clamp((tt - 2.95) / 0.8))
        let lidA: Double = IntroMath.clamp((tt - 2.95) / 0.25)
        let rupK: Double = IntroMath.easeOut(IntroMath.clamp((tt - 3.25) / 0.6))
        let settled: Double = IntroMath.clamp((tt - 4.2) / 0.6)
        let pk: Double = t - poke
        let hop: Double = pk < 0.45 ? sin(Double.pi * pk / 0.45) * 1.4 : 0
        let flip: Double = pk < 1 ? cos(2 * Double.pi * IntroMath.ease(IntroMath.clamp(pk / 0.85))) : 1
        var m = ctx
        m.opacity = alpha
        m.translateBy(x: 0, y: lg.tcy)
        m.scaleBy(x: lg.s, y: lg.s)
        m.translateBy(x: -12, y: -12)
        if coinK > 0 {
            var c = m
            let fx: CGFloat = CGFloat(abs(flip) < 0.001 ? 0.001 : flip)
            c.translateBy(x: IntroMark.coin.x, y: IntroMark.coin.y)
            c.scaleBy(x: fx, y: 1)
            c.translateBy(x: -IntroMark.coin.x, y: -IntroMark.coin.y)
            c.opacity = alpha * coinK
            let r: CGFloat = IntroMark.coinR * CGFloat(0.92 + 0.08 * coinK)
            let disc: CGRect = CGRect(x: IntroMark.coin.x - r, y: IntroMark.coin.y - r, width: r * 2, height: r * 2)
            c.fill(Path(ellipseIn: disc), with: .linearGradient(Gradient(colors: [Color(hex: "#F2F2F2"), Color(hex: "#A8A8A8")]),
                                                                 startPoint: CGPoint(x: disc.minX, y: disc.minY), endPoint: CGPoint(x: disc.maxX, y: disc.maxY)))
            if rupK > 0 && flip > 0 {
                c.opacity = alpha * flip
                c.stroke(IntroMark.rupee.trimmedPath(from: 0, to: CGFloat(rupK)), with: .color(Color(hex: "#3A3A3A").opacity(0.85)),
                         style: StrokeStyle(lineWidth: 0.5, lineCap: .round, lineJoin: .round))
            }
        }
        wall(m, IntroMark.left, wl, 0.42, 0.2, CGPoint(x: 3.5, y: 9.6), CGPoint(x: 8.6, y: 22.2))
        wall(m, IntroMark.right, wr, 0.26, 0.1, CGPoint(x: 20.5, y: 9.6), CGPoint(x: 15.4, y: 22.2))
        if lidA > 0 {
            var l = m
            let bob: Double = sin(t * 1.4) * 0.14 * settled
            l.translateBy(x: 0, y: CGFloat(-(1 - lidK) * 7 - hop + bob))
            l.opacity = alpha * lidA
            l.fill(IntroMark.lid, with: .color(Color.white.opacity(0.5)))
        }
        // a glint across the glass every few seconds, or right after a tap
        let gp: Double = pk < 1.2 ? pk / 1.1 : (settled >= 1 ? (tt - 4.8).truncatingRemainder(dividingBy: 5.2) / 1.1 : 2)
        if gp >= 0 && gp < 1 {
            var gl = m
            gl.clip(to: IntroMark.box)
            let x: CGFloat = CGFloat(-6 + gp * 36)
            let band: Gradient = Gradient(stops: [.init(color: Color.white.opacity(0), location: 0), .init(color: Color.white.opacity(0.35), location: 0.5),
                                                  .init(color: Color.white.opacity(0), location: 1)])
            gl.fill(Path(CGRect(x: -4, y: -4, width: 32, height: 32)), with: .linearGradient(band, startPoint: CGPoint(x: x - 3, y: 0), endPoint: CGPoint(x: x + 3, y: 6)))
        }
        // the word beneath, letter by letter
        let letters: [String] = ["k", "o", "s", "h"]
        let font: Font = .system(size: lg.fs, weight: .bold, design: .rounded)
        var resolved: [GraphicsContext.ResolvedText] = []
        var widths: [CGFloat] = []
        for ch in letters {
            let r: GraphicsContext.ResolvedText = ctx.resolve(Text(ch).font(font).foregroundStyle(Color.primary))
            resolved.append(r)
            widths.append(r.measure(in: CGSize(width: 400, height: 400)).width)
        }
        let track: CGFloat = -lg.fs * 0.03
        var x: CGFloat = -(widths.reduce(0, +) + track * CGFloat(letters.count - 1)) / 2
        for i in letters.indices {
            let k: Double = IntroMath.easeOut(IntroMath.clamp((tt - 3.45 - Double(i) * 0.075) / 0.5))
            if k > 0 {
                var w = ctx
                w.opacity = alpha * k
                w.draw(resolved[i], at: CGPoint(x: x, y: lg.wordY + CGFloat(1 - k) * 9), anchor: .leading)
            }
            x += widths[i] + track
        }
    }

    /// a glass wall rising from its bottom edge
    private func wall(_ ctx: GraphicsContext, _ p: Path, _ k: Double, _ a0: Double, _ a1: Double, _ s: CGPoint, _ e: CGPoint) {
        guard k > 0 else { return }
        var w = ctx
        w.translateBy(x: 0, y: 20.5)
        w.scaleBy(x: 1, y: CGFloat(max(0.001, k)))
        w.translateBy(x: 0, y: -20.5)
        w.fill(p, with: .linearGradient(Gradient(colors: [Color.white.opacity(a0), Color.white.opacity(a1)]), startPoint: s, endPoint: e))
    }

    private func drawSparks(_ ctx: inout GraphicsContext, _ fade: Double, _ dark: Bool) {
        var c = ctx
        c.blendMode = dark ? .plusLighter : .normal
        for s in sparks {
            let raw: Double = (t - s.t0) / s.dur
            let u: Double = IntroMath.easeSine(IntroMath.clamp(raw))
            let alpha: Double = min(1, raw * 6, (1 - raw) * 6) * fade
            if alpha <= 0 { continue }
            let head: CGPoint = sparkAt(s, u)
            var prev: CGPoint = head
            for k in 1...7 {
                let uu: Double = u - Double(k) * 0.02
                if uu < 0 { break }
                let p: CGPoint = sparkAt(s, uu)
                var seg = Path()
                seg.move(to: prev)
                seg.addLine(to: p)
                c.stroke(seg, with: .color(tierAt(s, uu).opacity((1 - Double(k) / 8) * 0.85 * alpha)), lineWidth: CGFloat(2.2 * (1 - Double(k) / 9)))
                prev = p
            }
            let col: Color = tierAt(s, u)
            c.fill(Path(ellipseIn: CGRect(x: head.x - 7, y: head.y - 7, width: 14, height: 14)), with: .color(col.opacity((dark ? 0.28 : 0.16) * alpha)))
            c.fill(Path(ellipseIn: CGRect(x: head.x - 3.5, y: head.y - 3.5, width: 7, height: 7)), with: .color(col.opacity((dark ? 0.45 : 0.3) * alpha)))
            let core: CGFloat = dark ? 1.3 : 1.7
            c.fill(Path(ellipseIn: CGRect(x: head.x - core, y: head.y - core, width: core * 2, height: core * 2)),
                   with: .color((dark ? Color.white : col).opacity(alpha)))
        }
    }

    private func placeNodes(_ sc: IntroScene, _ i: IntroInput, _ fade: Double) {
        let appear: [Double] = i.still ? [1, 1, 1] : [IntroMath.clamp((drawT - 1.15) / 0.5), IntroMath.clamp((drawT - 0.75) / 0.5), IntroMath.clamp((drawT - 0.3) / 0.5)]
        for n in g.nodes.indices {
            shown[n] = rippled(warp(sc.pos[n], -1, 0, 0, sc.look, sc.lz)).0
            vis[n] = appear[g.nodes[n].tier.rawValue] * fade
            boxes[n] = .null
        }
    }

    private func drawNodes(_ ctx: inout GraphicsContext, _ sc: IntroScene, _ i: IntroInput, _ dark: Bool) {
        let page: Color = IntroInk.page
        let muted: Color = IntroInk.muted
        let pulse: Double = sin(t * 4) * 1.5
        // pills: gift-card portals, and wallets wherever the look stacks them
        for n in g.nodes.indices where sc.pill[n] && vis[n] > 0 {
            let node: IntroNode = g.nodes[n]
            let e: Double = em[n]
            let on: Bool = i.focus == n
            let hue: Color = IntroInk.of(node.tier)
            let p: CGPoint = shown[n]
            let rect: CGRect = CGRect(x: p.x - sc.hw[n], y: p.y - sc.hh[n], width: sc.hw[n] * 2, height: sc.hh[n] * 2)
            let shape: Path = Path(roundedRect: rect, cornerRadius: sc.hh[n], style: .continuous)
            var c = ctx
            c.opacity = vis[n]
            c.fill(shape, with: .color(on ? hue : page))
            let ringMix: Double = node.head ? max(e, 0.55) : e
            let edge: Color = on ? hue : muted.mix(with: hue, by: ringMix).opacity(0.22 + 0.6 * e + ping[n] * 0.3)
            c.stroke(shape, with: .color(edge), lineWidth: node.head ? 1.3 : 1)
            if e > 0.6 && !on { c.fill(shape, with: .color(hue.opacity((e - 0.6) * 0.25))) }
            var text: GraphicsContext.ResolvedText = e > 0.7 ? labels[n].1 : labels[n].0
            text.shading = .color(on ? page : muted.mix(with: IntroInk.text(node.tier), by: e).opacity(0.55 + 0.45 * e))
            c.draw(text, at: CGPoint(x: p.x, y: p.y + 0.5), anchor: .center)
            boxes[n] = rect.insetBy(dx: -4, dy: -4)
        }
        // wallets as diamonds (Wings)
        for n in g.nodes.indices where g.nodes[n].tier == .wallet && !sc.pill[n] && vis[n] > 0 {
            let e: Double = em[n]
            let p: CGPoint = shown[n]
            let s: CGFloat = CGFloat(3.8 + e * 1.3)
            var d = Path()
            d.addLines([CGPoint(x: p.x, y: p.y - s), CGPoint(x: p.x + s, y: p.y), CGPoint(x: p.x, y: p.y + s), CGPoint(x: p.x - s, y: p.y)])
            d.closeSubpath()
            var c = ctx
            c.opacity = vis[n]
            c.fill(d, with: .color(page))
            if e > 0.55 { c.fill(d, with: .color(IntroInk.wallet.opacity((e - 0.45) * 0.9))) }
            c.stroke(d, with: .color(muted.mix(with: IntroInk.wallet, by: e).opacity(0.4 + 0.6 * e)), lineWidth: 1.2)
            if ping[n] > 0 || i.focus == n {
                let pr: CGFloat = i.focus == n ? CGFloat(9 + pulse) : s + 2 + CGFloat(1 - ping[n]) * 9
                c.stroke(Path(ellipseIn: CGRect(x: p.x - pr, y: p.y - pr, width: pr * 2, height: pr * 2)),
                         with: .color(IntroInk.wallet.opacity(i.focus == n ? 0.5 : ping[n] * 0.55)), lineWidth: 1)
            }
        }
        // apps as dots
        for n in g.nodes.indices where g.nodes[n].tier == .app && vis[n] > 0 {
            let e: Double = em[n]
            let p: CGPoint = shown[n]
            let r: CGFloat = CGFloat(2.5 + e * 1.3)
            var c = ctx
            c.opacity = vis[n]
            c.fill(Path(ellipseIn: CGRect(x: p.x - r, y: p.y - r, width: r * 2, height: r * 2)), with: .color(muted.mix(with: IntroInk.app, by: e).opacity(0.55 + 0.45 * e)))
            if e > 0.7 || i.focus == n {
                let pr: CGFloat = i.focus == n ? CGFloat(8 + pulse) : r + 3 + CGFloat(sin(t * 3 + Double(p.x) * 0.03))
                c.stroke(Path(ellipseIn: CGRect(x: p.x - pr, y: p.y - pr, width: pr * 2, height: pr * 2)),
                         with: .color(IntroInk.app.opacity(i.focus == n ? 0.55 : 0.3 * e)), lineWidth: 1)
            }
        }
        // labels for everything that isn't a pill, on a soft backdrop so they read over the strings
        let minX: CGFloat = -sc.origin.x + 6
        let maxX: CGFloat = sc.size.width - sc.origin.x - 6
        for n in g.nodes.indices where !sc.pill[n] && vis[n] > 0 {
            let node: IntroNode = g.nodes[n]
            let e: Double = em[n]
            let p: CGPoint = shown[n]
            let w: CGFloat = sc.tw[n]
            var at: CGPoint
            var align: CGFloat = 0     // -1 text ends at the point, 0 centred, 1 text starts at the point
            switch sc.label[n] {
            case .inside:
                continue
            case .below:
                at = CGPoint(x: p.x, y: p.y + 13)
            case .left:
                at = CGPoint(x: p.x - 9, y: p.y)
                align = -1
            case .radial(let c):
                let dx0: CGFloat = sc.pos[n].x - c.x
                let dy0: CGFloat = sc.pos[n].y - c.y
                let d: CGFloat = max(0.001, hypot(dx0, dy0))
                let dx: CGFloat = dx0 / d
                let dy: CGFloat = dy0 / d
                if abs(dx) >= 0.45 {
                    align = dx < 0 ? -1 : 1
                    at = CGPoint(x: p.x + (dx < 0 ? -9 : 9), y: p.y)
                } else {
                    at = CGPoint(x: p.x, y: p.y + (dy < 0 ? -12 : 12))
                }
                if align < 0 && at.x - w < minX {
                    align = 1
                    at.x = p.x + 9
                }
                if align > 0 && at.x + w > maxX {
                    align = -1
                    at.x = p.x - 9
                }
            }
            let x0: CGFloat = align < 0 ? at.x - w : (align > 0 ? at.x : at.x - w / 2)
            let back: CGRect = CGRect(x: x0 - 3, y: at.y - 6.5, width: w + 6, height: 13)
            var c = ctx
            c.fill(Path(roundedRect: back, cornerRadius: 4, style: .continuous), with: .color(page.opacity((dark ? 0.78 : 0.82) * vis[n])))
            var text: GraphicsContext.ResolvedText = e > 0.7 ? labels[n].1 : labels[n].0
            let ink: Color = e > 0.75 ? Color.primary.mix(with: IntroInk.text(node.tier), by: 0.35) : muted.mix(with: Color.primary, by: e)
            text.shading = .color(ink.opacity(vis[n] * (0.38 + 0.62 * e)))
            c.draw(text, at: CGPoint(x: x0, y: at.y), anchor: .leading)
            let left: CGFloat = min(x0, p.x) - 6
            let right: CGFloat = max(x0 + w, p.x) + 6
            let top: CGFloat = min(at.y, p.y) - 9
            boxes[n] = CGRect(x: left, y: top, width: right - left, height: abs(at.y - p.y) + 18)
        }
    }
}
