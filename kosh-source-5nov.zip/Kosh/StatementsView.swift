import SwiftUI
import UniformTypeIdentifiers

// MARK: - Statements: every PDF kosh found for a tab, grouped by sender, one password box each
//
// Portfolio lists CAS statements (NSDL, CDSL, CAMS, KFintech) and contract notes; Insurance lists
// policy schedules and premium receipts. A locked PDF asks for its password right here; kosh keeps
// it for that sender only and opens every other statement from the same sender with it.

struct StatementsSection: View {
    @Environment(Store.self) private var store
    let kinds: Set<String>
    let title: String
    let empty: String
    @State private var picking = false
    @State private var addNote: String?

    struct DocGroup: Identifiable {
        let id: String
        let items: [LiveSession.DocItem]
        var sender: String { items.first?.sender ?? id }
        var locked: [LiveSession.DocItem] { items.filter { $0.state == "locked" } }
        var read: [LiveSession.DocItem] { items.filter { $0.state == "read" } }
        var newest: String { items.map(\.date).max() ?? "" }
    }

    /// locked senders first, then the most recent
    static func grouped(_ items: [LiveSession.DocItem]) -> [DocGroup] {
        let groups: [DocGroup] = Dictionary(grouping: items, by: { $0.domain }).map { DocGroup(id: $0.key, items: $0.value) }
        return groups.sorted { a, b in
            let la = !a.locked.isEmpty, lb = !b.locked.isEmpty
            if la != lb { return la }
            return a.newest > b.newest
        }
    }

    var body: some View {
        if let live = store.live {
            let items = live.docItems(kinds: kinds)
            let groups = Self.grouped(items)
            let locked = items.filter { $0.state == "locked" }.count
            Section {
                if items.isEmpty {
                    Text(empty).font(.subheadline).foregroundStyle(.secondary)
                }
                ForEach(groups) { g in StatementGroupRow(group: g) }
                Button { picking = true } label: { Label("Add a PDF or spreadsheet from Files", systemImage: "doc.badge.plus") }
                    .fileImporter(isPresented: $picking, allowedContentTypes: [.pdf, .commaSeparatedText, UTType("org.openxmlformats.spreadsheetml.sheet") ?? .spreadsheet, .zip]) { result in
                        if case .success(let url) = result {
                            Task { @MainActor in
                                let d = await live.addLocalDocument(url)
                                addNote = d == nil ? "Couldn’t copy that file." : d!.state == "locked" ? "Added. It’s locked: type its password above." : "Added and read."
                            }
                        }
                    }
                if live.readingDocs {
                    HStack(spacing: 8) { ProgressView(); Text("Reading statements…").font(.subheadline).foregroundStyle(.secondary) }
                } else if items.contains(where: { $0.state.isEmpty }) {
                    Button { Task { await live.readDocuments() } } label: { Label("Read them now", systemImage: "arrow.clockwise") }
                }
                if let addNote { Text(addNote).font(.footnote).foregroundStyle(.secondary) }
            } header: {
                HStack {
                    Text(title)
                    Spacer()
                    if locked > 0 { Text("\(locked) locked").foregroundStyle(Color.orange) }
                }
            } footer: {
                Text("kosh opens these on this phone. A password you type is saved on this phone for that sender only, and opens their other statements too.")
            }
        }
    }
}

struct StatementGroupRow: View {
    @Environment(Store.self) private var store
    let group: StatementsSection.DocGroup
    @State private var pw = ""
    @State private var trying = false
    @State private var result: String?
    @State private var open = false

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Button { withAnimation(Fold.motion(opening: !open)) { open.toggle() } } label: {
                HStack(spacing: 12) {
                    InstIcon(name: group.sender, color: Color.gray, plain: true)
                        .cornerMark(group.locked.isEmpty ? (group.read.isEmpty ? "doc" : "checkmark") : "lock.fill",
                                    color: group.locked.isEmpty ? (group.read.isEmpty ? Color.gray : Color.green) : Color.orange, size: 36)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(group.sender).font(.body.weight(.semibold)).lineLimit(1)
                        Text(summary).font(.subheadline).foregroundStyle(.secondary).lineLimit(2)
                    }
                    Spacer(minLength: 6)
                    Image(systemName: "chevron.right").font(.footnote.weight(.semibold)).foregroundStyle(.tertiary)
                        .foldTurn(open, degrees: 90)
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(.press)

            if !group.locked.isEmpty {
                if let hint = group.locked.first(where: { !$0.hint.isEmpty })?.hint {
                    VStack(alignment: .leading, spacing: 4) {
                        Label("The password, as \(group.sender) describes it", systemImage: "key.fill")
                            .font(.caption.weight(.semibold)).foregroundStyle(Color.kosh)
                        Text("“\(hint)”").font(.subheadline).fixedSize(horizontal: false, vertical: true)
                    }
                    .padding(12)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.kosh.opacity(0.08), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                } else {
                    Text("The email doesn’t say how this password is made. kosh tries your saved details; or type it here.")
                        .font(.caption).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                }
                Button { store.betaSheet = .passwords } label: {
                    Label(PasswordProfile.anySaved ? "What this needs, and your saved details" : "Save your details: kosh opens these itself", systemImage: "person.text.rectangle")
                        .font(.subheadline)
                }
                .buttonStyle(.press)
                .foregroundStyle(Color.kosh)
                HStack(spacing: 8) {
                    SecureField("Password", text: $pw)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .textContentType(.password)
                        .padding(10)
                        .background(CardFill(), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                    Button(trying ? "Opening…" : "Open") {
                        Task { @MainActor in
                            trying = true
                            let n = await store.live?.unlockSender(group.id, password: pw) ?? 0
                            trying = false
                            result = n > 0 ? "Opened \(n) statement\(n == 1 ? "" : "s")." : "That didn’t open it. Check the password the sender describes."
                            if n > 0 { pw = "" }
                        }
                    }
                    .buttonStyle(.glassProminent).koshFilled()
                    .disabled(pw.isEmpty || trying)
                }
            }
            if let result { Text(result).font(.caption).foregroundStyle(result.hasPrefix("Opened") ? Color.green : Color.orange) }

            Unfold(open: open) {
                VStack(alignment: .leading, spacing: 10) {
                    ForEach(group.items) { it in StatementLine(item: it) }
                }
                .padding(.leading, 4)
            }
        }
        .padding(.vertical, 4)
    }

    var summary: String {
        let n = group.items.count
        var parts = ["\(n) PDF\(n == 1 ? "" : "s")"]
        if !group.locked.isEmpty { parts.append("\(group.locked.count) need\(group.locked.count == 1 ? "s" : "") a password") }
        if let latest = group.read.first(where: { !$0.note.isEmpty }) { parts.append(latest.note) }
        else if group.locked.isEmpty && group.read.isEmpty, let note = group.items.first(where: { !$0.note.isEmpty })?.note { parts.append(note) }
        return parts.joined(separator: " · ")
    }
}

struct StatementLine: View {
    @Environment(Store.self) private var store
    let item: LiveSession.DocItem
    /// removing a paper added from Files: asked first, since what was read from it goes too
    @State private var asking = false
    var body: some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: sym).foregroundStyle(color).frame(width: 18)
            VStack(alignment: .leading, spacing: 2) {
                Text(item.file).font(.subheadline.weight(.medium)).lineLimit(1)
                HStack(spacing: 6) {
                    if !item.date.isEmpty { Text(Day.short(item.date)) }
                    if item.owner != "me" { Text(store.ownerName(item.owner)).fontWeight(.semibold) }
                    // what it's filed under: investments, insurance, a loan, your details
                    if !filed.isEmpty { Text(filed).foregroundStyle(Color.kosh) }
                    Text(stateText)
                }
                .font(.caption).foregroundStyle(.secondary)
                if !item.note.isEmpty && item.state != "locked" { Text(item.note).font(.caption).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true) }
                // where its figures went, once it's read
                if item.state == "read" && !item.unread, let shows = StatementsSettings.shows(item.kind) {
                    Text("Shows in: " + shows).font(.caption).foregroundStyle(Color.kosh).fixedSize(horizontal: false, vertical: true)
                }
            }
            Spacer(minLength: 0)
            if item.local {
                Button(role: .destructive) { asking = true } label: {
                    Image(systemName: "trash").font(.body)
                        .frame(minWidth: 44, minHeight: 44)
                        .contentShape(Rectangle())
                }
                .buttonStyle(.press)
                .foregroundStyle(Color.red)
                .accessibilityLabel("Remove " + item.file)
                .confirmationDialog("Remove " + item.file + "?", isPresented: $asking, titleVisibility: .visible) {
                    Button("Remove it", role: .destructive) { store.live?.removeLocalDocument(String(item.id.dropFirst(6))) }
                } message: {
                    Text("The copy in kosh goes, with the holdings and policies read from it. The file you added it from stays where it is.")
                }
            }
        }
    }
    var sym: String {
        switch item.state {
        case "read": return "checkmark.circle.fill"
        case "locked": return "lock.fill"
        case "older": return "clock.arrow.circlepath"
        case "empty": return "exclamationmark.triangle.fill"
        default: return "circle.dotted"
        }
    }
    var color: Color {
        switch item.state {
        case "read": return .green
        case "locked": return .orange
        case "empty": return .red
        default: return .secondary
        }
    }
    /// the paper's category once read, else what its kind says it is
    var filed: String { Details.catTitle(item.cat.isEmpty ? Details.catOf(kind: item.kind) : item.cat) }
    var stateText: String {
        switch item.state {
        case "read": return "Read"
        case "locked": return "Locked"
        case "older": return "Older"
        case "empty": return "Couldn’t read"
        default: return "Not opened yet"
        }
    }
}

/// On Portfolio's overview: only when statements are waiting on a password, or none has been found.
/// Once they're read there is nothing to say; it can be put away until something new needs you.
struct StatementsBanner: View {
    @Environment(Store.self) private var store
    let kinds: Set<String>
    let go: () -> Void
    @AppStorage("kosh.statementsBanner.hidden") private var hiddenFor = ""
    var body: some View {
        if let live = store.live {
            let items = live.docItems(kinds: kinds)
            let locked = items.filter { $0.state == "locked" }
            let none = items.isEmpty && store.snap.hold.isEmpty
            // what it's about: when that changes (a new locked statement), it shows again
            let key = none ? "none" : locked.map(\.id).sorted().joined(separator: ",")
            if (none || !locked.isEmpty) && hiddenFor != key {
                HStack(spacing: 12) {
                    Button(action: go) {
                        HStack(spacing: 12) {
                            IconTile(symbol: none ? "doc.text.magnifyingglass" : "lock.doc.fill", color: none ? Color.kosh : Color.orange)
                            VStack(alignment: .leading, spacing: 2) {
                                Text(none ? "Add a CAS statement" : "\(locked.count) statement\(locked.count == 1 ? "" : "s") need\(locked.count == 1 ? "s" : "") a password")
                                    .font(.body.weight(.semibold))
                                Text(none ? "None found in your mail yet. Add one from Files, or ask CAMS, KFintech or NSDL to email it." : "From \(Set(locked.map(\.sender)).sorted().prefix(3).joined(separator: ", ")). Save your details once and kosh opens them, or type the password.")
                                    .font(.subheadline).foregroundStyle(.secondary).lineLimit(2)
                            }
                            Spacer(minLength: 6)
                        }
                        .contentShape(Rectangle())
                    }
                    .buttonStyle(.press)
                    Button {
                        withAnimation(Motion.open) { hiddenFor = key }
                    } label: {
                        Image(systemName: "xmark").font(.footnote.weight(.bold)).foregroundStyle(.secondary)
                            .frame(width: 30, height: 30).background(Color.primary.opacity(0.06), in: Circle())
                    }
                    .buttonStyle(.press)
                    .accessibilityLabel("Hide")
                }
                .padding(14)
                .background(CardFill(), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
                .transition(.opacity)
            }
        }
    }
}

// MARK: - What kosh may be missing
//
// Months a card was used with no statement in the mail (it went to another inbox, or the Promotions tab), quiet
// months on an account busy either side, and senders whose money mail kosh can't read yet. Each has a next step:
// look again for that bank, or teach kosh the sender.
struct CoverageSection: View {
    @Environment(Store.self) private var store
    @State private var gaps: LiveSession.Gaps?
    @State private var looking: String?
    @State private var found: [String: Int] = [:]

    var body: some View {
        if let live = store.live, live.signedIn {
            Section {
                if let g = gaps, g.gaps.isEmpty && g.unread.isEmpty {
                    Label("Every card and account kosh knows has its months in the mail.", systemImage: "checkmark.seal")
                        .font(.subheadline).foregroundStyle(.secondary)
                }
                ForEach(gaps?.gaps ?? [], id: \.self) { gap in gapRow(gap, live) }
                ForEach(gaps?.unread ?? [], id: \.self) { u in unreadRow(u) }
            } header: {
                Text("What kosh may be missing")
            } footer: {
                Text("A card bills every month it’s used, so a missing statement is usually in another inbox or the Promotions tab.")
            }
            // while kosh reads, every hundred emails (not each one); once it's done, at once
            .task(id: live.running ? live.records.count / 100 : live.records.count) { gaps = live.gaps() }
        }
    }

    func gapRow(_ gap: LiveSession.Gaps.Gap, _ live: LiveSession) -> some View {
        let what: String = gap.instr == "card" ? gap.name + " card ••" + gap.last4 : gap.name + " A/c ••" + gap.last4
        let months: String = gap.months.map(Self.month).joined(separator: ", ")
        let line: String = gap.what == "statement" ? "No statement for " + months : "No mail at all in " + months
        let key: String = gap.name + gap.last4
        let note: String = found[key].map { (n: Int) -> String in n > 0 ? "Found \(n) new email" + (n == 1 ? "" : "s") : "Nothing new in this inbox" } ?? line
        return HStack(alignment: .center, spacing: 12) {
            Image(systemName: gap.instr == "card" ? "creditcard" : "building.columns")
                .foregroundStyle(Color.orange).frame(width: 24)
            VStack(alignment: .leading, spacing: 2) {
                Text(what).font(.subheadline.weight(.semibold))
                Text(note)
                    .font(.footnote).foregroundStyle(.secondary)
            }
            Spacer(minLength: 8)
            if looking == key { ProgressView() } else {
                Button("Look again") {
                    looking = key
                    Task { @MainActor in
                        let n: Int = await live.lookAgain(for: gap.name)
                        found[key] = n
                        looking = nil
                        gaps = live.gaps()
                    }
                }
                .font(.footnote.weight(.semibold)).buttonStyle(.bordered).buttonBorderShape(.capsule)
                .disabled(looking != nil || live.lookingFor != nil)
            }
        }
    }

    func unreadRow(_ u: LiveSession.Gaps.Unread) -> some View {
        HStack(alignment: .center, spacing: 12) {
            Image(systemName: "questionmark.circle").foregroundStyle(Color.kosh).frame(width: 24)
            VStack(alignment: .leading, spacing: 2) {
                Text(u.name).font(.subheadline.weight(.semibold))
                Text("\(u.n) email\(u.n == 1 ? "" : "s") kosh can’t read yet").font(.footnote).foregroundStyle(.secondary)
            }
            Spacer(minLength: 8)
            if !u.domain.isEmpty {
                Button("Teach kosh") { store.betaSheet = .tutor(u.domain) }
                    .font(.footnote.weight(.semibold)).buttonStyle(.bordered).buttonBorderShape(.capsule)
            }
        }
    }

    /// "2026-08" → "Aug"; another year's month keeps its year
    static func month(_ ym: String) -> String {
        let names = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
        guard ym.count == 7, let m = Int(ym.suffix(2)), (1...12).contains(m) else { return ym }
        let thisYear = String(LiveSession.today.prefix(4))
        return names[m - 1] + (ym.hasPrefix(thisYear) ? "" : " " + String(ym.prefix(4)))
    }
}

// MARK: - Each statement set against kosh's payments

/// For every card and bank statement kosh opened: how many of its lines match the payments kosh read from the mail,
/// how many only the statement had (kosh added them), and the other way round, the payments kosh counts in that period
/// that the statement doesn't have: told twice, misread, or not posted yet. You look at those and leave out the ones
/// counted twice; kosh never takes one out on its own say.
struct StatementCheckSection: View {
    @Environment(Store.self) private var store
    @State private var open: String?

    var body: some View {
        let all: [Recon] = (store.snap.recon ?? []).filter { $0.lines > 0 || $0.ok == false }
            .sorted { ($0.to ?? $0.sent ?? "") > ($1.to ?? $1.sent ?? "") }
        if let live = store.live, !all.isEmpty {
            let off: Int = all.reduce(0) { $0 + ($1.extra ?? 0) }
            Section {
                ForEach(all.prefix(24)) { r in row(r, live) }
                if live.leftOutCount > 0 {
                    Button("Put back the \(live.leftOutCount) you left out") { live.putBackLeftOut() }
                        .font(.footnote)
                }
            } header: {
                HStack {
                    Text("Checked against your statements")
                    Spacer()
                    if off > 0 { Text("\(off) to look at").foregroundStyle(Color.orange) }
                }
            } footer: {
                Text("Each statement’s lines are matched to the payments kosh read from your mail. Lines only the statement had are added; payments kosh has that the statement doesn’t are shown here for you to look at.")
            }
        }
    }

    func row(_ r: Recon, _ live: LiveSession) -> some View {
        let n = r.extra ?? 0
        let good = r.ok != false && n == 0
        let card = r.instr == "card"
        let name = (r.inst.isEmpty ? "Statement" : r.inst) + (card ? " card" : " A/c") + (r.last4.isEmpty ? "" : " ••" + r.last4)
        let lines = max(0, r.lines - r.skipped)
        var parts: [String] = []
        if r.lines > 0 { parts.append("\(r.matched) of \(lines) lines match kosh’s payments") }
        if r.added > 0 { parts.append("\(r.added) only on the statement, added") }
        if (r.held ?? 0) > 0 { parts.append("\(r.held ?? 0) left out (the statement doesn’t add up)") }
        if n > 0 { parts.append("\(n) kosh has that the statement doesn’t") }
        if r.lines == 0, let note = r.note, !note.isEmpty { parts.append(note) }
        let period: String = {
            guard let f = r.from, let t = r.to, !f.isEmpty, !t.isEmpty else { return r.sent.map { Day.fmt($0, "MMM yyyy") } ?? "" }
            return Day.fmt(f, "d MMM") + " – " + Day.fmt(t, "d MMM yyyy")
        }()
        return VStack(alignment: .leading, spacing: 8) {
            Button { withAnimation(Fold.motion(opening: open != r.id)) { open = open == r.id ? nil : r.id } } label: {
                HStack(alignment: .top, spacing: 12) {
                    Image(systemName: good ? "checkmark.seal.fill" : "exclamationmark.triangle.fill")
                        .foregroundStyle(good ? Color.green : Color.orange).frame(width: 24)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(name).font(.subheadline.weight(.semibold))
                        if !period.isEmpty { Text(period).font(.caption).foregroundStyle(.secondary) }
                        Text(parts.joined(separator: " · ")).font(.footnote).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                    }
                    Spacer(minLength: 6)
                    if n > 0 { Image(systemName: "chevron.right").font(.footnote.weight(.semibold)).foregroundStyle(.tertiary).foldTurn(open == r.id, degrees: 90) }
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(.press)
            if n > 0 {
                Unfold(open: open == r.id) {
                    VStack(alignment: .leading, spacing: 10) {
                        ForEach(r.extras ?? []) { x in extraRow(x, live) }
                        if n > (r.extras ?? []).count { Text("and \(n - (r.extras ?? []).count) more").font(.caption).foregroundStyle(.secondary) }
                    }
                    .padding(.leading, 36)
                }
            }
        }
        .padding(.vertical, 2)
    }

    func extraRow(_ x: ReconExtra, _ live: LiveSession) -> some View {
        HStack(alignment: .center, spacing: 10) {
            VStack(alignment: .leading, spacing: 2) {
                Text((x.dir == "in" ? "+" : "") + Fmt.rupees(x.a) + (x.m.isEmpty ? "" : " · " + x.m)).font(.subheadline).lineLimit(1)
                Text(Day.short(x.d) + " · " + (x.why == "twice" ? "looks counted twice: the statement has it once" : "not on the statement"))
                    .font(.caption).foregroundStyle(x.why == "twice" ? Color.orange : .secondary)
            }
            Spacer(minLength: 6)
            if x.why == "twice" {
                Button("Leave out") { live.leaveOut(x.id) }
                    .font(.footnote.weight(.semibold)).buttonStyle(.bordered).buttonBorderShape(.capsule)
            }
        }
    }
}

/// What kosh's last check kept off every screen and out of every total, and why: said, never silently dropped
struct HeldBackSection: View {
    @Environment(Store.self) private var store
    var body: some View {
        if let h = store.snap.health, h.n > 0 {
            Section {
                ForEach(Array(h.held.prefix(20).enumerated()), id: \.offset) { _, x in
                    VStack(alignment: .leading, spacing: 2) {
                        Text((x.amt ?? 0) > 0 ? Fmt.rupees(x.amt ?? 0) + (x.title.isEmpty ? "" : " · " + x.title) : (x.title.isEmpty ? x.what.capitalized : x.title))
                            .font(.subheadline).lineLimit(1).privacySensitive()
                        Text(Self.why(x)).font(.caption).foregroundStyle(.secondary)
                    }
                }
                if h.n > 20 { Text("and \(h.n - 20) more").font(.caption).foregroundStyle(.secondary) }
            } header: { Text("Held back") } footer: {
                Text("kosh left these out of every screen and total because something about them didn’t hold up.")
            }
        }
    }
    static func why(_ x: Health.Held) -> String {
        let what = x.what == "payment" ? "A payment" : x.what == "holding" ? "A holding" : x.what == "policy" ? "A policy" : "A thread"
        switch x.why {
        case "dated ahead": return what + " dated after tomorrow: a year misread"
        case "no figure": return what + " with no amount kosh could trust"
        case "told twice": return what + " told twice"
        case "no insurer": return what + " that names no insurer"
        case "nothing in it": return what + " with nothing in it"
        case "no name": return what + " with no name"
        default: return what + ": " + x.why
        }
    }
}
