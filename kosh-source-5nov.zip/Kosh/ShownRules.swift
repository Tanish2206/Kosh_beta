import Foundation

// MARK: - What a change you make looks like on the screens, before its build lands
//
// Each rule here is the engine's own rule for that one thing, written again for the one item you tapped, so the screen
// shows at once what the build will show (Store+Shown.swift lays it over the screens until a build that knows of it
// lands). Screen-free: engine-test/shown.js compiles this file with the phone's Snapshot types and holds every rule to
// the engine's build with the same change made, household by household. A rule that can't know what the build will
// say (a policy put back to kosh's own reckoning, a limit handed back to the card's mail) has no rule here: that tap
// waits for its build, as before. Only the item changes; what it adds up into (left to spend, net worth) follows with
// the build.

enum ShownRules {
    /// a bill on the calendar marked paid (prof.paid, engine/21h): paid from now; unmarked, a bill only your mark made
    /// paid is due again
    static func paid(_ s: inout Snapshot, id: String, on: Bool) {
        for i in s.agenda.indices where s.agenda[i].id == id && s.agenda[i].kind == "out" {
            if on {
                if !s.agenda[i].booked { s.agenda[i].booked = true; s.agenda[i].marked = true }
            } else if s.agenda[i].marked == true {
                s.agenda[i].booked = false; s.agenda[i].marked = nil
            }
        }
        // a card's bill by the same key (engine 21d: its billMark): paid in full, by you, today, unless its mail already
        // shows it paid. Taken back, it waits for its build: what went towards it before the mark is the build's to say
        guard on else { return }
        for i in s.cards.indices where s.cards[i].billMark == id {
            let c: CardInfo = s.cards[i]
            let due: Double = c.due ?? 0
            guard due > 0 else { continue }
            let paidOn: String = c.paidOn ?? ""
            let full: Bool = (c.paid ?? 0) >= due - max(5, due * 0.01) && paidOn >= (c.stmtOn ?? "")
            if full { continue }
            s.cards[i].paid = (due * 100).rounded() / 100
            s.cards[i].paidOn = s.today
            s.cards[i].paidSaid = "you"
        }
    }

    /// what you said about a repeat (prof.repeats, engine/21e): "no" moves it to those you said aren't repeats;
    /// "gone:<day>" shows it stopped that day, unless it has come since; nothing takes one you said isn't a repeat off
    /// that list (it is among the repeats again with its build). One you said had stopped and put back waits for its
    /// build: whether it has stopped coming by itself is the build's to say (engine/21e and 21g, with the mail not read
    /// yet), and a blank beats a guess
    static func repeatMark(_ s: inout Snapshot, id: String, mark: String?) {
        if mark == "no" {
            guard let i = s.recurring.firstIndex(where: { (r: Recurring) -> Bool in r.id == id }) else { return }
            let r: Recurring = s.recurring.remove(at: i)
            var off: [RepeatOff] = s.recurringOff ?? []
            if !off.contains(where: { (o: RepeatOff) -> Bool in o.id == id }) { off.append(RepeatOff(id: id, name: r.name, why: "no")) }
            s.recurringOff = off
            return
        }
        if let mark, mark.hasPrefix("gone:") {
            let day: String = String(mark.dropFirst(5))
            for i in s.recurring.indices where s.recurring[i].id == id {
                let last: String = s.recurring[i].last ?? ""
                if !last.isEmpty && last <= day { s.recurring[i].lapsed = last; s.recurring[i].gone = day }
            }
            return
        }
        guard mark == nil else { return }
        s.recurringOff?.removeAll { (o: RepeatOff) -> Bool in o.id == id }
    }

    /// the credit limit you typed for a card (prof.cardLimit, engine/21d): it stands over its mail's; an available
    /// figure above it was from before, and goes
    static func cardLimit(_ s: inout Snapshot, id: String, limit: Double) {
        let lim: Double = limit.rounded()
        guard lim > 0 else { return }
        for i in s.cards.indices where s.cards[i].id == id {
            s.cards[i].limit = lim; s.cards[i].limitSaid = "you"; s.cards[i].limitOn = nil
            if let a = s.cards[i].avail, a > lim + 1 { s.cards[i].avail = nil; s.cards[i].availOn = nil }
        }
    }

    /// a policy you said has ended, or is still running (prof.policyMarks, engine/21f): its standing, in the engine's words
    static func policyMark(_ s: inout Snapshot, key: String, mark: String) {
        guard !key.isEmpty, mark == "ended" || mark == "active" else { return }
        for i in s.policies.indices where s.policies[i].key == key && s.policies[i].status != "renewed" {
            if mark == "ended" {
                s.policies[i].status = "ended"; s.policies[i].statusWhy = "You marked it as no longer running."; s.policies[i].ended = true
            } else {
                s.policies[i].status = "active"; s.policies[i].statusWhy = "You said it is still running."; s.policies[i].ended = nil
            }
        }
    }

    /// "not mine": a policy you hid leaves the list (prof.hiddenPolicies, engine/21f)
    static func hidePolicy(_ s: inout Snapshot, key: String) {
        guard !key.isEmpty else { return }
        s.policies.removeAll { (p: Policy) -> Bool in p.key == key }
    }

    /// someone whose health cover is held where kosh can't see it (prof.healthElsewhere, engine/22): said so only of
    /// someone no policy kosh sees covers
    static func healthElsewhere(_ s: inout Snapshot, id: String, on: Bool) {
        guard var by = s.healthBy else { return }
        for i in by.indices where by[i].id == id {
            by[i].elsewhere = on && by[i].policies.isEmpty ? true : nil
        }
        s.healthBy = by
    }

    /// a draft that isn't a trip isn't offered again (prof.tripDraftsOff, trips.js)
    static func dropDraft(_ s: inout Snapshot, id: String) {
        s.tripDrafts?.removeAll { (d: TripDraft) -> Bool in d.id == id }
    }

    /// a spend you added by hand (LiveSession.addManual's reading): its row as the engine lays one out, in the ledger at
    /// once. What it adds to the month is Store.added's to show until the build counts it. Only a spending kind (the
    /// Add sheet offers no other): money moved or put away is the build's to lay out (a card's bill is a move). The
    /// payee's key (lk, what "every payment to it" goes by) is the build's to make, so it has none until then
    static func manualRow(_ s: Snapshot, id: String, day: String, time: String, merchant: String, amount: Double, card: String, c: String, sub: String) -> Txn? {
        guard let cat = s.cats[c], cat.kind == "spend" else { return nil }
        let way: String = card.isEmpty ? "Cash" : card
        var t = Txn(id: id, d: day, t: time, m: merchant, a: amount, card: way, c: c, s: sub, k: "out", o: "me", f: "", fs: false,
                    n: "", u: false, g: false, src: "manual", sym: cat.symbol, sp: true)
        t.md = card.isEmpty ? "cash" : "card"; t.bk = way; t.dr = "out"
        return t
    }
    static func addRow(_ s: inout Snapshot, _ row: Txn) {
        guard !s.tx.contains(where: { (t: Txn) -> Bool in t.id == row.id }) else { return }
        s.tx.insert(row, at: 0)
    }

    /// a chapter deleted: it leaves the list, and its payments are ordinary spending again (each row asks for its
    /// chapter by id, and finds none)
    static func removeTrip(_ s: inout Snapshot, id: String) {
        s.trips?.removeAll { (t: TripInfo) -> Bool in t.id == id }
    }
}
