import Foundation

// MARK: - A payment's changes stay with the payment, whichever of its twins the build keeps
//
// One payment told twice (the bank's SMS, then its mail minutes later) is one row. The change you made was saved on
// the row shown then: often the SMS. When the mail's row takes its place, the engine carries the change across for
// that build (engine 21a carryChanges) and says so in snap.carried (dropped id → kept id). These move the change, and
// every share split off the payment, onto the kept row for good, so the payment's sheet shows its split, its Chapter
// counts the shares, Undo finds them, and a change made later on the kept row never loses the first one.
//
// Nothing here knows about screens (engine-test/split-links.js compiles it alone with swiftc).

enum SplitLinks {
    /// the row an id stands for now: a dropped twin leads to the row kept in its place (a chain is followed through,
    /// a loop never)
    static func kept(_ id: String, _ carried: [String: String]) -> String {
        var at: String = id
        var seen: Set<String> = [id]
        while let next = carried[at], !next.isEmpty, !seen.contains(next) {
            seen.insert(next)
            at = next
        }
        return at
    }

    /// each payment a share was split off, as the row kept for it
    static func relink(_ txs: [String?], _ carried: [String: String]) -> [String?] {
        txs.map { t in t.map { kept($0, carried) } }
    }

    /// every change saved on a dropped twin moved onto the row kept in its place: the kept row's own fields win, the
    /// twin's fill in the rest (`fill(kept, dropped)`), and the twin's entry goes. Twins taken in the order of their
    /// ids, so the result is the same however the map was read
    static func carry<T>(_ changes: [String: T], _ carried: [String: String], fill: (_ kept: T, _ dropped: T) -> T) -> [String: T] {
        var out: [String: T] = changes
        for from in carried.keys.sorted() {
            guard let moving = out[from] else { continue }
            let to: String = kept(from, carried)
            if to == from { continue }
            out[to] = out[to].map { fill($0, moving) } ?? moving
            out[from] = nil
        }
        return out
    }
}
