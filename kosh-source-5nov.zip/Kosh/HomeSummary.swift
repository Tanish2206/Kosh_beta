import SwiftUI

// MARK: - Also in kosh: the parts that aren't tabs (the month-in-one-look card that lived here was retired on 17 Oct 2026)

/// the parts of kosh that aren't tabs, as one quiet row
struct AlsoInKosh: View {
    @Environment(Store.self) private var store
    var body: some View {
        let more = AppTab.pinnable.filter { !store.tabs.contains($0) }
        if !more.isEmpty {
            ScrollView(.horizontal) {
                HStack(spacing: 8) {
                    ForEach(more) { t in
                        Button { store.open(t) } label: {
                            Label(t.title, systemImage: t.symbol)
                                .font(.footnote.weight(.semibold))
                                .foregroundStyle(Color.primary)
                                .padding(.horizontal, 12).padding(.vertical, 8)
                                .background(Color.surface, in: Capsule())
                        }
                        .buttonStyle(.press)
                    }
                    Button { store.sheet = .tabs } label: {
                        Image(systemName: "slider.horizontal.3")
                            .font(.footnote.weight(.semibold))
                            .foregroundStyle(Color.secondary)
                            .frame(width: 34, height: 34)
                            .background(Color.surface, in: Circle())
                    }
                    .buttonStyle(.press)
                    .accessibilityLabel("Edit the tab bar")
                }
            }
            .scrollIndicators(.hidden)
            .scrollClipDisabled()
        }
    }
}
