import BackgroundTasks
import Foundation
import Network
import Observation
import UIKit

// MARK: - Reading that goes on when kosh isn't on screen, and never starts over
//
// Three ways kosh keeps reading with the screen off:
//  • KeepGoing: when you lock the phone with reading under way, kosh's own Lock Screen entry shows it (ReadingLive),
//    the mail still to read goes to a background download session iOS carries on with (BackgroundMail), and the
//    work on the phone gets the usual half-minute to go on and save.
//  • catch-up: when kosh goes to the background with a read unfinished, iOS is asked for time later (often
//    overnight, on the charger) to carry it on from the email it stopped at; what's left when that time is up goes
//    to the downloads.
//  • refresh: every few hours, a short look at new mail (about 22 seconds), so the ledger is fresh when you open it;
//    a statement it finds is opened in the time left, and by the catch-up if that runs out.
//
// Whatever stops it (kosh closed, the phone locked too long, iOS needing the memory), what was read is saved
// together with what was still to read (reading.json), so the next run picks up where this one stopped.

/// One date window of mail, listed: what's still to read in each inbox
struct MailWindow: Codable, Equatable {
    var after: String
    var before: String? = nil
    var queries: [String]? = nil
    var only: String? = nil
    /// when it was listed: the next read of new mail starts from here, not from when the reading ended
    var listedAt = Date()
    /// account → Gmail message ids still to read, in order
    var left: [String: [String]] = [:]
    /// new emails the listing found, and how many of them are read
    var total = 0
    var done = 0
    /// an inbox that couldn't be listed (its sign-in ran out, say): the window isn't whole
    var failed: String? = nil

    var key: String { Self.key(after: after, before: before, queries: queries, only: only) }
    var remaining: Int { left.values.reduce(0) { $0 + $1.count } }

    static func key(after: String, before: String?, queries: [String]?, only: String?) -> String {
        [after, before ?? "", (queries ?? ["rules"]).joined(separator: "\u{1F}"), only ?? ""].joined(separator: "|")
    }
}

/// What one long read had left when kosh last saved
struct ReadingPlan: Codable, Equatable {
    /// scan · backfill · wallets · statements · inbox:<address> · reingest · reader · docs
    var job: String
    var started = Date()
    /// the inboxes it was planned over: if they change, it's planned again
    var accounts: [String] = []
    /// windows of mail still to read, in the order they're read (a month each while the year fills in)
    var windows: [MailWindow] = []
    /// mail read again with new rules: the records still to go
    var ids: [String]? = nil
    /// the whole job, in emails (or statements, for docs), and how many of them are done
    var total = 0
    var done = 0

    /// older than three days: the mail has moved on, it's listed afresh
    var stale: Bool { Date().timeIntervalSince(started) > 3 * 86400 }
}

/// reading.json
struct ReadingFile: Codable {
    var v = 1
    var plans: [String: ReadingPlan] = [:]
}

// MARK: the internet, for "Waiting for the internet"

@MainActor
@Observable
final class Net {
    static let shared = Net()
    /// the phone has a way out to the internet (Wi-Fi or mobile data)
    private(set) var online = true
    private let monitor = NWPathMonitor()

    private init() {
        monitor.pathUpdateHandler = { path in
            let ok = path.status == .satisfied
            Task { @MainActor in
                if Net.shared.online != ok { Net.shared.online = ok }
            }
        }
        monitor.start(queue: DispatchQueue(label: "kosh.net"))
    }

    /// waits until the phone is back online; false if kosh was asked to stop meanwhile
    func waitOnline() async -> Bool {
        while !online {
            if KeepGoing.shared.stopped { return false }
            try? await Task.sleep(for: .seconds(1))
        }
        return !KeepGoing.shared.stopped
    }
}

// MARK: catch-up and refresh, when iOS gives kosh time in the background

@MainActor
enum BackgroundReading {
    nonisolated static var catchUpID: String { permitted("catchup") }
    nonisolated static var refreshID: String { permitted("refresh") }

    /// the task's name as Info.plist lists it, which iOS only allows: a copy of kosh re-signed under another Apple ID
    /// (a tester's sideloaded build) gets a new bundle id, while the list keeps the one it was built with
    nonisolated static func permitted(_ suffix: String) -> String {
        let listed: [String] = Bundle.main.object(forInfoDictionaryKey: "BGTaskSchedulerPermittedIdentifiers") as? [String] ?? []
        return listed.first { $0.hasSuffix("." + suffix) } ?? ((Bundle.main.bundleIdentifier ?? "app.kosh") + "." + suffix)
    }

    /// once, while kosh launches (before it finishes launching, as iOS requires)
    nonisolated static func register() {
        _ = BGTaskScheduler.shared.register(forTaskWithIdentifier: catchUpID, using: .main) { t in
            MainActor.assumeIsolated { BackgroundReading.catchUp(t) }
        }
        _ = BGTaskScheduler.shared.register(forTaskWithIdentifier: refreshID, using: .main) { t in
            MainActor.assumeIsolated { BackgroundReading.refresh(t) }
        }
    }

    /// kosh is going to the background: time later for a read that isn't finished, and a look at new mail
    static func leaving(_ live: LiveSession?) {
        guard let live, live.signedIn, live.loadedFromDisk else { return }
        // a read unfinished, statements not opened yet, or mail to read again with new rules: time later for it
        // (and a year not yet read back: a first read goes on filling in the year while kosh is away)
        if live.hasPlans || KeepGoing.shared.busy || live.hasUnopenedDocs || live.rulesChanged || !live.yearIn { askForCatchUp() }
        askForRefresh()
    }

    /// before the time goes back to iOS: the build under way finishes (a few seconds at most), and the reminders and
    /// the widgets follow it, so the Lock Screen and the Home Screen show what was just read
    static func settle(_ live: LiveSession) async {
        guard live.loadedFromDisk else { return }
        var waited: Double = 0
        while live.buildPending && !live.holdBuilds && waited < 4 {
            try? await Task.sleep(for: .milliseconds(200))
            waited += 0.2
        }
        Notify.shared.store?.afterBuildNow()
    }

    static func askForCatchUp() {
        let r = BGProcessingTaskRequest(identifier: catchUpID)
        r.requiresNetworkConnectivity = true
        r.requiresExternalPower = false
        try? BGTaskScheduler.shared.submit(r)
    }

    static func askForRefresh() {
        let r = BGAppRefreshTaskRequest(identifier: refreshID)
        r.earliestBeginDate = Date(timeIntervalSinceNow: 4 * 3600)
        try? BGTaskScheduler.shared.submit(r)
    }

    /// a read that was cut short, carried on until iOS wants its time back
    private static func catchUp(_ t: BGTask) {
        guard let live = LiveSession.current else { t.setTaskCompleted(success: false); return }
        let id = ObjectIdentifier(t)
        KeepGoing.shared.woke(t)
        t.expirationHandler = {
            Task { @MainActor in BackgroundReading.timeUp(id) }
        }
        Task { @MainActor in
            live.reloadIfNeeded()
            // the downloads take the far end of what's listed while the phone reads from the front
            if live.loadedFromDisk && live.signedIn { await BackgroundMail.shared.handOff() }
            if live.loadedFromDisk && live.signedIn { await live.resumeReading() }
            // a first read whose last three months aren't in yet (nothing listed for them): those next
            if live.loadedFromDisk && live.signedIn && !KeepGoing.shared.stopped && !live.recentIn && !live.backfilling && !live.running {
                await live.backfill(back: LiveSession.recentDays)
            }
            // statements found and not opened yet get opened here too, so they're read before you next open kosh
            if live.loadedFromDisk && live.signedIn && !KeepGoing.shared.stopped && live.hasUnopenedDocs { await live.readDocuments() }
            // mail read again with new rules (a new kosh), here too rather than at your next open
            if live.loadedFromDisk && !KeepGoing.shared.stopped { await live.reingestIfRulesChanged() }
            // the rest of the year, if it isn't read back yet, in the time left (newest month first, saved month by month)
            if live.loadedFromDisk && live.signedIn && !KeepGoing.shared.stopped && !live.yearIn && !live.backfilling && !live.running { await live.backfill() }
            // the emails the rules couldn't read, by smart reading when it's set up (a network call; the reader on the phone
            // waits for you to open kosh: it needs more memory than iOS gives the background)
            if live.loadedFromDisk && !KeepGoing.shared.stopped && live.aiMode == "claude" && live.aiReady && live.waitingCount > 0 { await live.aiPass() }
            // funds and shares at the day's prices (once a day at most)
            if live.loadedFromDisk && !KeepGoing.shared.stopped { await live.refreshPrices() }
            // work that was already under way when iOS woke kosh carries on too: the task lasts until it ends
            // (or until you open kosh, which carries it on in front)
            while KeepGoing.shared.busy && !KeepGoing.shared.stopped && UIApplication.shared.applicationState != .active {
                try? await Task.sleep(for: .seconds(1))
            }
            await BackgroundReading.settle(live)
            BackgroundReading.wrapUp(id, success: !KeepGoing.shared.stopped)
        }
    }

    /// a short look at new mail, stopped and saved by about 25 seconds (a refresh gets about half a minute)
    private static func refresh(_ t: BGTask) {
        askForRefresh()
        guard let live = LiveSession.current else { t.setTaskCompleted(success: false); return }
        let id = ObjectIdentifier(t)
        KeepGoing.shared.woke(t)
        t.expirationHandler = {
            Task { @MainActor in BackgroundReading.timeUp(id) }
        }
        Task { @MainActor in
            let deadline = Task { @MainActor in
                // 22 seconds: the build after it and the reminders and widgets (settle) fit in what's left
                try? await Task.sleep(for: .seconds(22))
                // with kosh on screen by now, the reading just carries on
                if !Task.isCancelled && UIApplication.shared.applicationState != .active { KeepGoing.shared.stop() }
            }
            live.reloadIfNeeded()
            if live.loadedFromDisk && live.signedIn { await live.quickRead() }
            // a new statement the look at new mail found is opened in the time left (cut short at the deadline, it's
            // carried on by the catch-up, from the statement it stopped at)
            if live.loadedFromDisk && live.signedIn && !KeepGoing.shared.stopped && live.hasUnopenedDocs { await live.readDocuments() }
            // anything already under way when iOS woke kosh gets the rest of the time too
            while KeepGoing.shared.busy && !KeepGoing.shared.stopped && UIApplication.shared.applicationState != .active {
                try? await Task.sleep(for: .seconds(1))
            }
            deadline.cancel()
            await BackgroundReading.settle(live)
            // stopped at the deadline is still a refresh done: what it read is saved, the rest carries on later
            BackgroundReading.wrapUp(id, success: true)
        }
    }

    /// iOS wants its time back: the work stops, what was read is saved with what's left, and more time is asked for
    private static func timeUp(_ id: ObjectIdentifier) {
        guard KeepGoing.shared.isWoken(id) else { return }
        // if you've opened kosh meanwhile, the work goes on in front; otherwise it stops here
        let away = UIApplication.shared.applicationState != .active
        if away { KeepGoing.shared.stop() }
        // no time to wait for a build: the reminders and widgets from what's there now
        Notify.shared.store?.afterBuildNow()
        wrapUp(id, success: false, saved: away)
    }

    /// the task is over (or its time is): save, ask for more time if a read is unfinished, and tell iOS
    private static func wrapUp(_ id: ObjectIdentifier, success: Bool, saved: Bool = false) {
        guard KeepGoing.shared.isWoken(id) else { return }
        if let live = LiveSession.current, live.loadedFromDisk {
            // (stopping saved already)
            if !saved { live.checkpoint(force: true) }
            if live.hasPlans && live.signedIn {
                // with kosh still off screen, what's listed goes on in the downloads after the task ends
                if UIApplication.shared.applicationState != .active { BackgroundMail.shared.handOffNow() }
                askForCatchUp()
            }
        }
        KeepGoing.shared.doneWoken(id, success: success)
        ReadingLive.shared.settle()
    }
}
