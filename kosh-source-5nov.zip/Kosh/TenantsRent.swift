import SwiftUI

// MARK: - Under the street: what follows the camera
//
// On the whole street: this month's rent, in and late, as one bar (and a row per state when there are islands).
// Flown to a state: its rent and a row per property, each flying in to its building. Flown to a building: its rent,
// then a quiet row per tenant (floor, who, rent, where it stands) that opens in place: this month's rent with Mark
// received and a nudge ready to send, the year in twelve windows, the lease, the deposit and the agreement. Floors
// to let sit under the tenants, then the property tax, then the way back out.

/// this month's rent in a word or two, and its inks
enum RentWords {
    /// "Here", "12 days late" ("12d late" when short), "Due 5 Oct", "Not here yet" (no due day known), "From Nov 26"
    static func of(_ u: PropUnit, short: Bool = false) -> (text: String, st: String) {
        guard let n = u.now else { return (short ? "—" : "No rent set", "") }
        let due: String = (n.due ?? "").count == 10 ? Day.fmt(n.due ?? "", "d MMM") : ""
        switch n.st {
        case "booked": return (n.got == "marked" && !short ? "Marked in" : "Here", "booked")
        case "late":
            let d: Int = n.late ?? 0
            if d <= 0 { return ("Late", "late") }
            if short { return (String(d) + "d late", "late") }
            return (d == 1 ? "1 day late" : String(d) + " days late", "late")
        case "due": return (due.isEmpty ? (short ? "Not in" : "Not here yet") : "Due " + due, "due")
        case "upcoming": return (due.isEmpty ? "To come" : "Due " + due, "")
        case "before": return (u.start.isEmpty ? "Not yet" : "From " + Day.fmt(u.start + "-01", "MMM yy"), "")
        default: return (short ? "—" : "Before kosh’s mail", "")
        }
    }
    /// its dot on the page
    static func dot(_ st: String) -> Color {
        switch st {
        case "booked": return RentInk.lit
        case "late": return RentInk.late
        case "due": return RentInk.due
        default: return Color.rule.opacity(0.35)
        }
    }
    /// its words on the page
    static func deep(_ st: String) -> Color { st == "booked" ? RentInk.litDeep : RentInk.deep(st) }
    /// its ink on the dusk tile
    static func night(_ u: PropUnit) -> Color {
        switch StreetLight.of(u) {
        case .paid: return Dusk.gold
        case .late: return Color(hex: "#FF8A75")
        case .due: return Dusk.amber
        case .family: return Dusk.blue
        default: return Dusk.mist
        }
    }
    /// this month's rent in one line, its own dates in it (engine 21h/21q: one figure, one place):
    /// "October: here · ₹12,600 on 28 Oct", "October: ₹6,000 here on 6 Oct · ₹6,600 left · 14 days late",
    /// "November: not here yet · due 5 Nov", "November: not here yet · no due day known yet"
    static func month(_ u: PropUnit) -> String {
        guard let n = u.now else { return "" }
        let mon: String = Day.monthName(n.m) + ": "
        let due: String = (n.due ?? "").count == 10 ? Day.fmt(n.due ?? "", "d MMM") : ""
        let late: Int = n.late ?? 0
        let lateWords: String = late == 1 ? "1 day late" : String(late) + " days late"
        switch n.st {
        case "booked":
            if n.got == "marked" { return mon + "here · marked by you" }
            let amt: Double = (n.fromAmt ?? 0) > 0 ? (n.fromAmt ?? 0) : n.amt
            let on: String = (n.got ?? "").count == 10 ? " on " + Day.fmt(n.got ?? "", "d MMM") : ""
            return mon + "here · " + Fmt.rupees(amt) + on
        case "late", "due":
            var s: String
            if let part = n.part, part > 0 {
                let on: String = (n.partOn ?? "").count == 10 ? " on " + Day.fmt(n.partOn ?? "", "d MMM") : ""
                let left: Double = max(0, n.left ?? (n.amt - part))
                s = mon + Fmt.rupees(part) + " here" + on + " · " + Fmt.rupees(left) + " left"
            } else {
                s = mon + "not here yet"
            }
            if n.st == "late" && late > 0 && !due.isEmpty { return s + " · " + lateWords + " (due " + due + ")" }
            if !due.isEmpty { return s + " · due " + due }
            return s + " · no due day known yet"
        default: return ""
        }
    }
    /// "5th"; from the day you set, what the lease says, the usual day of the rents you tagged, or this month's due date
    static func dueOn(_ u: PropUnit) -> String {
        if let d = u.day, d > 0 { return ordinal(d) }
        if u.dueBy == "usual", let d = u.dueDay, d > 0 { return ordinal(d) + ", usually" }
        if let r = u.pays.range(of: #"\d+(st|nd|rd|th)"#, options: .regularExpression) { return String(u.pays[r]) }
        if let due = u.now?.due, due.count >= 10, let d = Int(due.suffix(2)) { return ordinal(d) }
        return "—"
    }
    /// after "was due on 5 Oct.": how long it's been
    static func lateLine(_ d: Int) -> String {
        if d <= 0 { return "" }
        return d == 1 ? "Just a day ago." : String(d) + " days and counting."
    }
}

/// a whole as one bar of shares: in, due, late (late breathes), the rest
struct RentBar: View {
    struct Part: Identifiable {
        let id: String
        let ink: Color
        let v: Double
        let breathe: Bool
    }
    let parts: [Part]
    var height: CGFloat = 10
    @Environment(\.accessibilityReduceMotion) private var still

    var body: some View {
        GeometryReader { g in
            let total: Double = max(1, parts.reduce(0) { $0 + $1.v })
            HStack(spacing: 3) {
                ForEach(parts) { p in
                    Capsule()
                        .fill(p.ink)
                        .frame(width: shareWidth(g.size.width, gaps: max(0, parts.count - 1), gap: 3, part: p.v, of: total, least: height))
                        .modifier(Breathe(on: p.breathe && !still))
                }
            }
        }
        .frame(height: height)
        .accessibilityHidden(true)
    }
}

/// a late thing breathes
struct Breathe: ViewModifier {
    let on: Bool
    @ViewBuilder func body(content: Content) -> some View {
        if on {
            content.phaseAnimator([1.0, 0.45]) { c, o in c.opacity(o) } animation: { _ in .easeInOut(duration: 1.2) }
        } else {
            content
        }
    }
}

/// "₹42,000 in, of ₹96,000 this month", and its bar
struct MonthIn: View {
    let sums: RentSums
    var body: some View {
        let got: String = Fmt.rupees(sums.received), all: String = Fmt.rupees(sums.expected)
        VStack(alignment: .leading, spacing: 8) {
            Text("\(Text(got).font(.system(.title2, design: .rounded, weight: .heavy)).foregroundStyle(Color.primary)) in, of \(Text(all).fontWeight(.semibold).foregroundStyle(Color.primary)) this month")
                .font(.system(.subheadline)).foregroundStyle(.secondary)
                .monospacedDigit()
                .lineLimit(1).minimumScaleFactor(0.8)
                .privacySensitive()
            RentBar(parts: sums.parts, height: 8)
        }
    }
}

/// the way back out, at the foot of the details
struct BackButton: View {
    let title: String
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.system(.subheadline, weight: .semibold))
                .foregroundStyle(Color.kosh)
                .lineLimit(1)
                .frame(maxWidth: .infinity)
                .frame(minHeight: 48)
                .background(Color.surface, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        }
        .buttonStyle(.press)
    }
}

// MARK: - The whole street

struct RentSummary: View {
    @Environment(Store.self) private var store
    let world: IsoWorld
    let lets: [TenantsView.Let]
    let pickIsle: (String) -> Void
    let late: () -> Void

    var body: some View {
        let s: RentSums = RentSums(lets)
        let month: String = Day.monthName(store.snap.cm) + "’s rent"
        let title: String = world.many ? month + ", across " + String(world.isles.count) + " states" : month
        let got: String = Fmt.rupees(s.received), all: String = Fmt.rupees(s.expected)
        VStack(alignment: .leading, spacing: 12) {
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(.system(.footnote, weight: .semibold)).foregroundStyle(RentInk.peach)
                if s.expected > 0 {
                    Text("\(Text(got).font(.system(.largeTitle, design: .rounded, weight: .heavy)).foregroundStyle(Color.primary)) in, of \(Text(all).fontWeight(.semibold).foregroundStyle(Color.primary))")
                        .font(.system(.subheadline)).foregroundStyle(.secondary)
                        .monospacedDigit()
                        .lineLimit(1).minimumScaleFactor(0.7)
                        .contentTransition(.numericText())
                        .privacySensitive()
                } else {
                    Text("Nothing due this month").font(.system(.title2, weight: .bold))
                }
            }
            .accessibilityElement(children: .combine)
            if s.expected > 0 { RentBar(parts: s.parts, height: 10) }
            HStack(alignment: .top, spacing: 12) {
                SumCell(dot: RentInk.lit, title: "Lit up, in", ink: RentInk.litDeep, amount: s.received, tail: s.paid > 0 ? "from " + String(s.paid) : "none yet")
                if s.late > 0 {
                    Button(action: late) {
                        SumCell(dot: RentInk.late, title: "Glowing red, late", ink: RentInk.lateDeep, amount: s.lateSum, tail: "from " + String(s.late), go: true)
                    }
                    .buttonStyle(.press)
                    .accessibilityHint("Flies to the longest-late rent")
                } else if s.due > 0 {
                    SumCell(dot: RentInk.due, title: "Warming up, due", ink: RentInk.dueDeep, amount: s.dueSum, tail: "from " + String(s.due))
                } else {
                    SumCell(dot: RentInk.late, title: "Glowing red, late", ink: RentInk.lateDeep, amount: 0, tail: "all clear")
                }
            }
            if world.many {
                VStack(spacing: 0) {
                    ForEach(Array(world.isles.enumerated()), id: \.element.id) { i, isle in
                        if i > 0 { RowRule(inset: 14) }
                        StateRow(isle: isle) { pickIsle(isle.id) }
                    }
                }
                .background(Color.surface, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
                .padding(.horizontal, -4)
                .padding(.top, 4)
            }
            Text(world.many ? "Tap a state, or its island, to fly in." : "Tap a building to step inside.")
                .font(.system(.footnote)).foregroundStyle(.secondary)
            LoosePays(title: "Rent not matched to a floor", note: "Credits called rent that kosh couldn’t place on one tenant. If one was a tenant’s, mark that month received on their row.", rows: store.propBook(store.who).rentLoose ?? [])
                .padding(.horizontal, -4)
        }
        .padding(.horizontal, 4)
        .animation(Motion.open, value: s.received)
    }
}

/// one side of the month: its dot and name, and how much from how many
struct SumCell: View {
    let dot: Color
    let title: String
    let ink: Color
    let amount: Double
    let tail: String
    var go: Bool = false

    var body: some View {
        VStack(alignment: .leading, spacing: 3) {
            HStack(spacing: 7) {
                Circle().fill(dot).frame(width: 8, height: 8).shadow(color: dot.opacity(0.7), radius: 3)
                Text(title).lineLimit(1).minimumScaleFactor(0.85)
                if go { Image(systemName: "chevron.right").font(.system(.caption2, weight: .bold)) }
            }
            .font(.system(.footnote, weight: .semibold)).foregroundStyle(ink)
            Text("\(Text(Fmt.rupees(amount)).font(.system(.title3, design: .rounded, weight: .bold)).foregroundStyle(Color.primary)) \(Text(tail).font(.system(.footnote)).foregroundStyle(.secondary))")
                .monospacedDigit()
                .lineLimit(1).minimumScaleFactor(0.75)
                .privacySensitive()
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .contentShape(Rectangle())
        .accessibilityElement(children: .combine)
    }
}

/// a state in the list under the islands: its plate, its share of the month, how it stands
struct StateRow: View {
    let isle: IsoWorld.Isle
    let tap: () -> Void

    var body: some View {
        let s: RentSums = RentSums(isle.lets)
        let st: (String, Color) = Street.status(isle.lets)
        let count: String = "· " + StreetTile.count(isle.houses.count, "property", "properties")
        let got: String = Fmt.rupees(s.received), of: String = "/ " + Fmt.rupees(s.expected)
        Button(action: tap) {
            HStack(spacing: 12) {
                StatePlate(code: isle.code, height: 22)
                VStack(alignment: .leading, spacing: 5) {
                    Text("\(Text(isle.name).font(.system(.callout, weight: .semibold))) \(Text(count).font(.system(.footnote)).foregroundStyle(.secondary))")
                        .lineLimit(1)
                    if s.expected > 0 { RentBar(parts: s.parts, height: 5).frame(maxWidth: 150) }
                }
                Spacer(minLength: 6)
                VStack(alignment: .trailing, spacing: 1) {
                    if s.expected > 0 {
                        Text("\(Text(got).fontWeight(.bold)) \(Text(of).foregroundStyle(.secondary))")
                            .font(.system(.subheadline, design: .rounded)).monospacedDigit()
                            .lineLimit(1).minimumScaleFactor(0.8)
                            .privacySensitive()
                    }
                    Text(st.0).font(.system(.caption, weight: .semibold)).foregroundStyle(st.1)
                }
                Image(systemName: "chevron.right").font(.system(.caption, weight: .semibold)).foregroundStyle(.tertiary)
            }
            .padding(.vertical, 13)
            .padding(.horizontal, 14)
            .contentShape(Rectangle())
        }
        .buttonStyle(.press)
        .accessibilityHint("Flies to this state’s island")
    }
}

// MARK: - A state

struct StateRent: View {
    let isle: IsoWorld.Isle
    let pick: (String) -> Void
    let back: () -> Void

    var body: some View {
        let s: RentSums = RentSums(isle.lets)
        let portal: String = isle.houses.compactMap { $0.p.portalName }.first(where: { !$0.isEmpty }) ?? ""
        let count: String = StreetTile.count(isle.houses.count, "property", "properties")
        let meta: String = portal.isEmpty ? count : count + " · tax to " + portal
        VStack(alignment: .leading, spacing: 14) {
            VStack(alignment: .leading, spacing: 2) {
                Text(isle.name).font(.system(.title2, weight: .bold)).accessibilityAddTraits(.isHeader)
                Text(meta).font(.system(.footnote)).foregroundStyle(.secondary).lineLimit(2)
            }
            .padding(.horizontal, 4)
            if s.expected > 0 { MonthIn(sums: s).padding(.horizontal, 4) }
            VStack(spacing: 0) {
                ForEach(Array(isle.houses.enumerated()), id: \.element.id) { i, h in
                    if i > 0 { RowRule(inset: 64) }
                    PropRow(house: h) { pick(h.id) }
                }
            }
            .background(Color.surface, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
            Text("Tap a property to step inside.").font(.system(.footnote)).foregroundStyle(.secondary).padding(.horizontal, 4)
            BackButton(title: "Back to all states", action: back)
        }
    }
}

/// a property in a state's list: what it is, what's in this month, how it stands
struct PropRow: View {
    let house: StreetHouse
    let tap: () -> Void

    var body: some View {
        let s: RentSums = RentSums(house.lets)
        let st: (String, Color) = house.lets.isEmpty ? (house.empty.isEmpty ? "Nothing let" : "To let", RentInk.grey) : Street.status(house.lets)
        let got: String = Fmt.rupees(s.received), of: String = "/ " + Fmt.rupees(s.expected)
        Button(action: tap) {
            HStack(spacing: 12) {
                PropGlyph(house: house)
                VStack(alignment: .leading, spacing: 1) {
                    Text(Street.name(house.p)).font(.system(.callout, weight: .semibold)).lineLimit(1)
                    Text(Street.meta(house)).font(.system(.footnote)).foregroundStyle(.secondary).lineLimit(1)
                }
                Spacer(minLength: 6)
                VStack(alignment: .trailing, spacing: 1) {
                    if s.expected > 0 {
                        Text("\(Text(got).fontWeight(.bold)) \(Text(of).foregroundStyle(.secondary))")
                            .font(.system(.footnote, design: .rounded)).monospacedDigit()
                            .lineLimit(1).minimumScaleFactor(0.8)
                            .privacySensitive()
                    }
                    Text(st.0).font(.system(.caption, weight: .semibold)).foregroundStyle(st.1)
                }
                Image(systemName: "chevron.right").font(.system(.caption, weight: .semibold)).foregroundStyle(.tertiary)
            }
            .padding(.vertical, 12)
            .padding(.horizontal, 14)
            .contentShape(Rectangle())
        }
        .buttonStyle(.press)
        .accessibilityHint("Flies in to this building")
    }
}

/// a property as a glyph: its kind, washed in how its rent stands
struct PropGlyph: View {
    let house: StreetHouse
    var body: some View {
        let sym: String = {
            switch house.kind {
            case .shop: return "storefront.fill"
            case .house: return "house.fill"
            case .flats: return "building.2.fill"
            case .office: return "building.fill"
            case .plot: return "square.dashed"
            }
        }()
        let late: Bool = house.lets.contains(where: { $0.u.now?.st == "late" })
        let due: Bool = house.lets.contains(where: { $0.u.now?.st == "due" })
        let fine: Bool = !house.lets.isEmpty && house.lets.allSatisfy({ $0.u.now == nil || $0.u.now?.st == "booked" })
        let st: String = late ? "late" : due ? "due" : fine ? "booked" : ""
        Image(systemName: sym)
            .font(.system(size: 16, weight: .semibold))
            .foregroundStyle(RentWords.deep(st))
            .frame(width: 38, height: 38)
            .background(RentWords.dot(st).opacity(st.isEmpty ? 0.3 : 0.2), in: RoundedRectangle(cornerRadius: 11, style: .continuous))
            .accessibilityHidden(true)
    }
}

// MARK: - A building

struct BuildingRent: View {
    @Environment(Store.self) private var store
    let house: StreetHouse
    @Binding var row: String?
    /// where the way back goes: the state, or the street
    let backTo: String
    let back: () -> Void
    static let anchor: String = "tenants.rows"

    var body: some View {
        let s: RentSums = RentSums(house.lets)
        let empty: [PropUnit] = house.empty
        VStack(alignment: .leading, spacing: 14) {
            VStack(alignment: .leading, spacing: 2) {
                Text(Street.name(house.p)).font(.system(.title2, weight: .bold)).lineLimit(2).accessibilityAddTraits(.isHeader)
                Text(Street.meta(house)).font(.system(.footnote)).foregroundStyle(.secondary)
            }
            .padding(.horizontal, 4)
            if s.expected > 0 { MonthIn(sums: s).padding(.horizontal, 4) }
            if house.lets.isEmpty && empty.isEmpty {
                Text(house.p.units.contains { Street.use($0) == "self" } ? "The family lives here. Only gold and red windows are rent." : "Nothing let out here yet.")
                    .font(.system(.subheadline))
                    .foregroundStyle(.secondary)
                    .padding(16)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.surface, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
            } else {
                VStack(spacing: 0) {
                    ForEach(Array(house.lets.enumerated()), id: \.element.id) { i, l in
                        if i > 0 { RowRule(inset: 64) }
                        TenantRow(l: l, open: row == l.id) {
                            withAnimation(Fold.motion(opening: row != l.id)) { row = row == l.id ? nil : l.id }
                        }
                    }
                    ForEach(Array(empty.enumerated()), id: \.offset) { i, u in
                        if i > 0 || !house.lets.isEmpty { RowRule(inset: 64) }
                        VacantRow(p: house.p, u: u)
                    }
                }
                .background(Color.surface, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
                .id(Self.anchor)
            }
            // the building's rent over the twelve months to this one: what was to come in, what came, what was missed
            if let log = house.p.rentLog { PropRentLog(log: log, cm: store.snap.cm) }
            TaxLine(p: house.p)
            BackButton(title: "Back to " + backTo, action: back)
        }
    }
}

/// a floor's short name in a square, washed in how its rent stands
struct FloorBadge: View {
    let p: Prop
    let u: PropUnit
    var body: some View {
        let st: String = u.now?.st ?? ""
        let known: Bool = st == "booked" || st == "late" || st == "due"
        Text(Street.badge(p, u))
            .font(.system(size: 15, weight: .heavy, design: .rounded))
            .lineLimit(1).minimumScaleFactor(0.6)
            .foregroundStyle(RentWords.deep(st))
            .padding(.horizontal, 3)
            .frame(width: 38, height: 38)
            .background(known ? RentWords.dot(st).opacity(0.2) : Color.rule.opacity(0.1), in: RoundedRectangle(cornerRadius: 11, style: .continuous))
            .accessibilityHidden(true)
    }
}

/// a tenant: a quiet row that opens in place
struct TenantRow: View {
    let l: TenantsView.Let
    let open: Bool
    let toggle: () -> Void
    static func anchor(_ id: String) -> String { "tenant|" + id }

    var body: some View {
        let u: PropUnit = l.u
        let word: (text: String, st: String) = RentWords.of(u)
        let who: String = u.tenant.isEmpty ? "Tenant" : u.tenant
        let rent: String = Fmt.rupees(u.rent)
        VStack(alignment: .leading, spacing: 0) {
            Button(action: toggle) {
                HStack(spacing: 12) {
                    FloorBadge(p: l.p, u: u)
                    VStack(alignment: .leading, spacing: 1) {
                        Text(who).font(.system(.callout, weight: .semibold)).lineLimit(1).privacySensitive()
                        Text("\(Text(rent).fontWeight(.semibold).foregroundStyle(Color.primary)) · \(u.label)")
                            .font(.system(.footnote)).foregroundStyle(.secondary)
                            .monospacedDigit()
                            .lineLimit(1)
                            .privacySensitive()
                        // this month's rent: here (how much, which day), or not yet (due when, how late)
                        let month: String = RentWords.month(u)
                        if !month.isEmpty {
                            Text(month)
                                .font(.system(.caption)).foregroundStyle(RentWords.deep(word.st))
                                .monospacedDigit()
                                .lineLimit(2).fixedSize(horizontal: false, vertical: true)
                                .privacySensitive()
                        }
                    }
                    Spacer(minLength: 6)
                    HStack(spacing: 6) {
                        Circle().fill(RentWords.dot(word.st)).frame(width: 8, height: 8)
                            .modifier(Breathe(on: word.st == "late"))
                        Text(word.text).font(.system(.footnote, weight: .semibold)).foregroundStyle(RentWords.deep(word.st)).lineLimit(1)
                    }
                    .fixedSize()
                    Image(systemName: "chevron.down")
                        .font(.system(.caption2, weight: .bold))
                        .foregroundStyle(.tertiary)
                        .foldTurn(open)
                }
                .padding(.vertical, 12)
                .padding(.horizontal, 14)
                .contentShape(Rectangle())
            }
            .buttonStyle(.press)
            .accessibilityElement(children: .combine)
            .accessibilityHint(open ? "Closes their details" : "Opens their details")
            Unfold(open: open) {
                TenantDetail(l: l, close: toggle)
                    .padding(.horizontal, 14)
                    .padding(.top, 2)
                    .padding(.bottom, 16)
            }
        }
        .id(Self.anchor(l.id))
    }
}

/// a tenant's row, opened: the month, the year, the lease, the deposit and the agreement
struct TenantDetail: View {
    @Environment(Store.self) private var store
    let l: TenantsView.Let
    let close: () -> Void
    @State private var nudging = false

    /// the agreement photographed for this floor (older builds kept one for the whole property)
    var docKey: String { "lease:" + l.p.pid + ":" + l.u.code + ":" + String(l.u.idx ?? 0) }
    var oldKey: String { "lease:" + l.p.pid + ":" + l.u.code }

    var body: some View {
        let u: PropUnit = l.u
        let nudge: Nudge? = Nudge.list([l], today: store.snap.today, cm: store.snap.cm).first
        let hasDoc: Bool = !u.doc.isEmpty || store.latest(docKey) != nil || store.latest(oldKey) != nil
        let step: String = !u.change.isEmpty ? "Next rise: " + u.change : (!u.esc.isEmpty ? "Rises " + u.esc : "")
        VStack(alignment: .leading, spacing: 16) {
            if let n = u.now {
                if n.st == "late" || n.st == "due" {
                    OwedNow(l: l, n: n, canNudge: nudge != nil, nudging: $nudging)
                } else {
                    RentStrip(p: l.p, u: u, n: n)
                }
            }
            if let nudge {
                Unfold(open: nudging) {
                    NudgePanel(n: nudge) { withAnimation(Fold.close) { nudging = false } }
                }
            }
            if !u.roll.isEmpty { RentMonths(roll: u.roll, cm: store.snap.cm) }
            if !u.start.isEmpty && !u.end.isEmpty {
                VStack(alignment: .leading, spacing: 8) {
                    Text("Lease").font(.system(.footnote, weight: .semibold)).foregroundStyle(.secondary)
                    LeaseBar(start: u.start, end: u.end, now: store.snap.cm)
                    if !step.isEmpty { Text(step).font(.system(.footnote)).foregroundStyle(.secondary) }
                }
            }
            HStack(spacing: 8) {
                TenantTile(cap: "Deposit", value: u.deposit > 0 ? Fmt.rupees(u.deposit) : "None", tone: u.deposit > 0 ? Color.primary : RentInk.grey, money: true)
                TenantTile(cap: "Due on", value: RentWords.dueOn(u), tone: Color.primary)
                if u.registered {
                    TenantTile(cap: "Agreement", value: "Registered", tone: RentInk.goodDeep)
                } else if hasDoc {
                    TenantTile(cap: "Agreement", value: "Not registered", tone: RentInk.dueDeep)
                } else {
                    Button { store.sheet = .capture(docKey) } label: {
                        TenantTile(cap: "Agreement", value: "Add", tone: Color.kosh)
                    }
                    .buttonStyle(.press)
                    .accessibilityLabel("Add the agreement")
                }
            }
            HStack {
                if store.live != nil {
                    Button { store.betaSheet = .property(l.p.uid ?? l.p.pid) } label: {
                        Label("Edit tenant", systemImage: "pencil").font(.system(.subheadline, weight: .semibold))
                    }
                    .buttonStyle(.press)
                    .foregroundStyle(Color.kosh)
                    .frame(minHeight: 36)
                }
                Spacer(minLength: 8)
                Button("Close", action: close)
                    .buttonStyle(.press)
                    .font(.system(.subheadline, weight: .semibold))
                    .foregroundStyle(.secondary)
                    .frame(minHeight: 36)
            }
        }
        .animation(Motion.open, value: nudging)
    }
}

/// this month's rent still to come in: said plainly, with Mark received and a nudge
struct OwedNow: View {
    @Environment(Store.self) private var store
    let l: TenantsView.Let
    let n: RollMonth
    let canNudge: Bool
    @Binding var nudging: Bool

    var body: some View {
        let late: Bool = n.st == "late"
        let tint: Color = late ? RentInk.late : RentInk.due
        let known: Bool = (n.due ?? "").count == 10
        let day: String = known ? Day.fmt(n.due ?? "", "d MMM") : "its day"
        let lead: String = Self.lead(n, late: late, known: known, day: day)
        let tail: String = late && known ? RentWords.lateLine(n.late ?? 0) : ""
        let line: String = tail.isEmpty ? lead : lead + " " + tail
        VStack(alignment: .leading, spacing: 10) {
            Text(line)
                .font(.system(.subheadline))
                .fixedSize(horizontal: false, vertical: true)
                .privacySensitive()
            HStack(spacing: 8) {
                if store.live != nil {
                    Button {
                        withAnimation(Motion.open) { store.markRent(property: l.p.uid ?? l.p.pid, unit: l.u.idx ?? 0, month: n.m) }
                    } label: {
                        Text("Mark received")
                            .font(.system(.subheadline, weight: .semibold))
                            .lineLimit(1).minimumScaleFactor(0.85)
                            .foregroundStyle(Color(uiColor: .systemBackground))
                            .frame(maxWidth: .infinity)
                            .frame(minHeight: 44)
                            .background(Color.primary, in: RoundedRectangle(cornerRadius: 13, style: .continuous))
                    }
                    .buttonStyle(.press)
                }
                if canNudge {
                    Button {
                        withAnimation(Motion.open) { nudging.toggle() }
                    } label: {
                        Text(nudging ? "Hide the nudge" : "Send a nudge")
                            .font(.system(.subheadline, weight: .semibold))
                            .lineLimit(1).minimumScaleFactor(0.85)
                            .foregroundStyle(Color.primary)
                            .frame(maxWidth: .infinity)
                            .frame(minHeight: 44)
                            .background(Color.raised, in: RoundedRectangle(cornerRadius: 13, style: .continuous))
                    }
                    .buttonStyle(.press)
                }
            }
        }
        .padding(12)
        .background(tint.opacity(0.1), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).strokeBorder(tint.opacity(0.22), lineWidth: 1))
        .sensoryFeedback(.success, trigger: n.st)
    }
}

extension OwedNow {
    /// what's owed this month in a sentence: a part that came and what's left, no day known, or the day it was due
    static func lead(_ n: RollMonth, late: Bool, known: Bool, day: String) -> String {
        let month: String = Day.monthName(n.m) + "’s " + Fmt.rupees(n.amt)
        let part: Double = n.part ?? 0
        if part > 0 {
            let on: String = (n.partOn ?? "").count == 10 ? " on " + Day.fmt(n.partOn ?? "", "d MMM") : ""
            let left: String = Fmt.rupees(max(0, n.left ?? (n.amt - part))) + " left"
            let due: String = known ? (late ? ", due on " : ", due by ") + day : ""
            return Fmt.rupees(part) + " of " + month + " came" + on + "; " + left + due + "."
        }
        if !known { return month + " isn’t here yet. kosh doesn’t know its day: set one under Edit tenant, or tag two months’ rent and kosh learns it." }
        return month + (late ? " was due on " : " is due on ") + day + "."
    }
}

/// the year's rent as twelve windows: gold when it came, amber when it came late, red when it's late, dim to come,
/// an outline before the lease (or before kosh's mail goes back)
struct RentMonths: View {
    let roll: [RollMonth]
    let cm: String

    /// in, but more than two days after its due day
    static func slow(_ r: RollMonth) -> Bool {
        guard r.st == "booked", let g = r.got, g.count == 10, let d = r.due, d.count == 10 else { return false }
        return Day.between(d, g) > 2
    }
    static func fill(_ r: RollMonth) -> Color {
        switch r.st {
        case "booked": return slow(r) ? RentInk.due : RentInk.lit
        case "late": return RentInk.late
        case "due": return RentInk.due.opacity(0.5)
        default: return Color.rule.opacity(0.12)
        }
    }

    var body: some View {
        let paid: Int = roll.filter { $0.st == "booked" }.count
        let late: Int = roll.filter { $0.st == "late" }.count
        let slow: Int = roll.filter(Self.slow).count
        var bits: [String] = []
        if paid > 0 { bits.append(String(paid) + " in") }
        if slow > 0 { bits.append(String(slow) + " came late") }
        if late > 0 { bits.append(String(late) + " late") }
        let note: String = bits.isEmpty ? "nothing in yet" : bits.joined(separator: " · ")
        return VStack(alignment: .leading, spacing: 6) {
            HStack(alignment: .firstTextBaseline) {
                Text("This year").font(.system(.footnote, weight: .semibold)).foregroundStyle(.secondary)
                Spacer(minLength: 6)
                Text(note).font(.system(.caption)).foregroundStyle(.secondary).lineLimit(1)
            }
            HStack(spacing: 4) {
                ForEach(roll) { r in
                    VStack(spacing: 3) {
                        cell(r)
                        Text(String(r.short.prefix(1)))
                            .font(.system(.caption2, weight: r.m == cm ? .bold : .regular))
                            .foregroundStyle(r.m == cm ? Color.primary : Color.secondary)
                    }
                    .frame(maxWidth: .infinity)
                }
            }
            .accessibilityElement(children: .ignore)
            .accessibilityLabel("This year: " + note)
        }
    }

    @ViewBuilder func cell(_ r: RollMonth) -> some View {
        if r.st == "before" || r.st == "nodata" {
            RoundedRectangle(cornerRadius: 4, style: .continuous).strokeBorder(Color.rule.opacity(0.25), lineWidth: 1).frame(height: 20)
        } else {
            RoundedRectangle(cornerRadius: 4, style: .continuous)
                .fill(Self.fill(r))
                .frame(height: 20)
                .overlay {
                    if r.m == cm {
                        RoundedRectangle(cornerRadius: 6, style: .continuous).strokeBorder(Color.primary.opacity(0.45), lineWidth: 1.5).padding(-3)
                    }
                }
        }
    }
}

/// a floor to let, with a way to add its tenant
struct VacantRow: View {
    @Environment(Store.self) private var store
    let p: Prop
    let u: PropUnit
    var body: some View {
        HStack(spacing: 12) {
            FloorBadge(p: p, u: u)
            VStack(alignment: .leading, spacing: 1) {
                Text(u.label.isEmpty ? "A floor" : u.label).font(.system(.callout, weight: .semibold)).lineLimit(1)
                Text("Empty, to let").font(.system(.footnote)).foregroundStyle(.secondary)
            }
            Spacer(minLength: 6)
            if store.live != nil {
                Button("Add a tenant") { store.betaSheet = .property(p.uid ?? p.pid) }
                    .buttonStyle(.press)
                    .font(.system(.footnote, weight: .semibold))
                    .foregroundStyle(Color.kosh)
                    .frame(minHeight: 36)
            }
        }
        .padding(.vertical, 12)
        .padding(.horizontal, 14)
    }
}

/// the property's tax, in a line: what's due and by when (or that nothing is); tap for the Property tax page
struct TaxLine: View {
    @Environment(Store.self) private var store
    let p: Prop
    var body: some View {
        let due: Double = PropertyTaxView.due(p)
        let read: Bool = !(p.portalReadAt ?? "").isEmpty
        // this financial year's tax, where kosh knows anything of it: due, paid, part paid, or no receipt yet
        if due > 0 || read || p.taxNow != nil {
            let said: (value: String, note: String, good: Bool) = Self.words(p, due: due, read: read)
            Button {
                withAnimation(Motion.open) { store.propSub = .tax }
            } label: {
                HStack(spacing: 10) {
                    VStack(alignment: .leading, spacing: 0) {
                        Text("Property tax").font(.system(.footnote, weight: .semibold)).foregroundStyle(.secondary)
                        Text(said.value)
                            .font(.system(.body, design: .rounded, weight: .bold)).monospacedDigit()
                            .privacySensitive()
                    }
                    Spacer(minLength: 6)
                    Text(said.note).font(.system(.footnote, weight: .semibold)).foregroundStyle(due > 0 ? RentInk.dueDeep : (said.good ? RentInk.goodDeep : RentInk.grey))
                    Image(systemName: "chevron.right").font(.system(.caption, weight: .semibold)).foregroundStyle(.tertiary)
                }
                .padding(.vertical, 12)
                .padding(.horizontal, 14)
                .background(Color.surface, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                .contentShape(Rectangle())
            }
            .buttonStyle(.press)
            .accessibilityHint("Opens Property tax")
        }
    }

    /// the figure and the words beside it: what's due and by when; else this year's paid amount, or that no receipt
    /// is found yet. good: known settled (paid this year, or the portal read showing nothing due)
    static func words(_ p: Prop, due: Double, read: Bool) -> (value: String, note: String, good: Bool) {
        if due > 0 { return (Fmt.rupees(due), p.payableTill.isEmpty ? "Due" : "Pay by " + Day.fmt(p.payableTill, "d MMM"), false) }
        guard let n = p.taxNow else { return ("Nothing due", "When last read", read) }
        let fy: String = TaxYearWords.fy(n.fy)
        switch n.st {
        case "paid": return (n.paid > 0 ? Fmt.rupees(n.paid) : "Nothing due", "Paid for " + fy, true)
        case "part": return (Fmt.rupees(n.paid), "Part paid for " + fy, false)
        default: return (read ? "Nothing due" : "Not found", read ? "When last read" : "No receipt for " + fy, read)
        }
    }
}
