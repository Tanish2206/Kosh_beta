/* kosh unlock: a locked zip or a locked Excel workbook, opened on the phone with a password kosh worked out.

   Banks, brokers and fund registrars send some statements as a password-protected zip (a consolidated statement, a
   contract-note bundle) or a password-protected workbook. A locked PDF the phone opens itself (PDFKit); these it
   can't, so this file does, in plain JavaScript (JavaScriptCore has no WebCrypto, and no JIT on the phone):
   - a zip locked the old way (PKWARE's "ZipCrypto") or with WinZip's AES (128, 192 or 256: PBKDF2-SHA1, AES in
     counter mode, an HMAC-SHA1 over what was locked), its entries stored or deflated;
   - a workbook locked by Excel (ECMA-376 agile encryption: a compound file holding EncryptionInfo and the
     EncryptedPackage; the key from a hash of the salt and password spun 100,000 times, AES-CBC in 4096-byte parts).
   Each password kosh worked out is tried in turn, the cheap test first (a zip's check byte, AES's two-byte verifier,
   the workbook's verifier hash), and nothing is taken as opened until it proves itself: a zip entry's CRC or HMAC, the
   workbook's verifier, a zip inside. What opens is handed back as the files inside (a zip) or the workbook as an
   ordinary .xlsx, which the phone reads as it reads any other (DocUnlock, DocTable): one reading, wherever it came from.

   The workbook's spin is the one slow part: ~0.3 s with a JIT, ~12 s without (Node --jitless; the phone runs
   without one). The phone lends its own hash for it (KoshNative.spin, CryptoKit: ~0.05 s); without that (Node, the
   tests) the spin runs here, and gives the same key.

     unlockJSON(b64, file, candidatesJSON)  → { state: 'opened' | 'plain' | 'locked' | 'unreadable', kind: 'zip' |
                                               'xlsx' | '', password, files: [{ name, b64 }], why }
     lockOfJSON(b64, file)                  → { kind, locked, how }: what the file is, and how it is locked
     zipReadsJSON(namesJSON)                → the files of an opened zip to read as statements, in order

   Loaded after engine.js; Swift calls the JSON functions through KoshEngine. */

var KoshUnlock = (function (E) {
  'use strict';

  /* ------------------------------------------------------------ bytes */
  var B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
  var B64I = new Int16Array(256);
  for (var bi = 0; bi < 256; bi++) B64I[bi] = -1;
  for (bi = 0; bi < 64; bi++) B64I[B64.charCodeAt(bi)] = bi;
  B64I[45] = 62; B64I[95] = 63;   // (the URL-safe alphabet too)
  function fromB64(s) {
    s = String(s || '');
    var n = s.length, out = new Uint8Array(Math.floor(n * 3 / 4) + 3), o = 0, acc = 0, bits = 0;
    for (var i = 0; i < n; i++) {
      var v = B64I[s.charCodeAt(i) & 255];
      if (v < 0) continue;
      acc = (acc << 6) | v; bits += 6;
      if (bits >= 8) { bits -= 8; out[o++] = (acc >>> bits) & 255; }
    }
    return out.subarray(0, o);
  }
  function toB64(u) {
    var parts = [], chunk = [];
    for (var i = 0; i < u.length; i += 3) {
      var a = u[i], b = i + 1 < u.length ? u[i + 1] : 0, c = i + 2 < u.length ? u[i + 2] : 0;
      chunk.push(B64[a >> 2] + B64[((a & 3) << 4) | (b >> 4)] + (i + 1 < u.length ? B64[((b & 15) << 2) | (c >> 6)] : '=') + (i + 2 < u.length ? B64[c & 63] : '='));
      if (chunk.length >= 4096) { parts.push(chunk.join('')); chunk = []; }
    }
    parts.push(chunk.join(''));
    return parts.join('');
  }
  function u16(b, i) { return b[i] | (b[i + 1] << 8); }
  function u32(b, i) { return (b[i] | (b[i + 1] << 8) | (b[i + 2] << 16) | (b[i + 3] << 24)) >>> 0; }
  function concat(list) {
    var n = 0, i; for (i = 0; i < list.length; i++) n += list[i].length;
    var out = new Uint8Array(n), o = 0;
    for (i = 0; i < list.length; i++) { out.set(list[i], o); o += list[i].length; }
    return out;
  }
  function utf8(s) {
    var out = [];
    for (var i = 0; i < s.length; i++) {
      var c = s.charCodeAt(i);
      if (c >= 0xD800 && c < 0xDC00 && i + 1 < s.length) { var d = s.charCodeAt(i + 1); if (d >= 0xDC00 && d < 0xE000) { c = 0x10000 + ((c - 0xD800) << 10) + (d - 0xDC00); i++; } }
      if (c < 0x80) out.push(c);
      else if (c < 0x800) out.push(0xC0 | (c >> 6), 0x80 | (c & 63));
      else if (c < 0x10000) out.push(0xE0 | (c >> 12), 0x80 | ((c >> 6) & 63), 0x80 | (c & 63));
      else out.push(0xF0 | (c >> 18), 0x80 | ((c >> 12) & 63), 0x80 | ((c >> 6) & 63), 0x80 | (c & 63));
    }
    return new Uint8Array(out);
  }
  function utf16le(s) { var out = new Uint8Array(s.length * 2); for (var i = 0; i < s.length; i++) { out[2 * i] = s.charCodeAt(i) & 255; out[2 * i + 1] = s.charCodeAt(i) >> 8; } return out; }
  function sameBytes(a, b, n) { if (a.length < n || b.length < n) return false; for (var i = 0; i < n; i++) if (a[i] !== b[i]) return false; return true; }

  /* ------------------------------------------------------------ CRC-32 */
  var CRC = new Int32Array(256);
  for (var ci = 0; ci < 256; ci++) { var cc = ci; for (var ck = 0; ck < 8; ck++) cc = cc & 1 ? 0xEDB88320 ^ (cc >>> 1) : cc >>> 1; CRC[ci] = cc; }
  function crc32(b) { var c = -1; for (var i = 0; i < b.length; i++) c = CRC[(c ^ b[i]) & 255] ^ (c >>> 8); return (c ^ -1) >>> 0; }

  /* ------------------------------------------------------------ inflate (raw deflate, RFC 1951)
     Table-driven: each Huffman table is a lookup by the next bits (symbol << 4 | length). A stream that runs past its
     end, a distance before the start, or a code no table holds is a broken stream: null, never a guess. */
  /* GUARDRAIL what one file may unpack to, in all: a statement is a few megabytes. A zip that says it holds more, or
     turns out to (a "zip bomb": a 200 KB attachment that inflates to gigabytes), is too big to be a statement, and is
     never unpacked past this: it would hold the engine for minutes and run the phone out of memory, again at every
     launch while it waited to be read */
  var MAX_OUT = 64 * 1024 * 1024;
  var LBASE = [3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258];
  var LEXT = [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0];
  var DBASE = [1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577];
  var DEXT = [0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13];
  var CLORDER = [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15];
  function huff(lens, n) {
    var max = 0, i, count = new Int32Array(16), next = new Int32Array(16);
    for (i = 0; i < n; i++) { if (lens[i] > max) max = lens[i]; count[lens[i]]++; }
    if (!max) return { t: new Int32Array(2), bits: 1 };
    count[0] = 0;
    var code = 0;
    for (i = 1; i <= 15; i++) { code = (code + count[i - 1]) << 1; next[i] = code; }
    var size = 1 << max, t = new Int32Array(size);
    for (i = 0; i < n; i++) {
      var L = lens[i]; if (!L) continue;
      var c = next[L]++, r = 0;
      for (var k = 0; k < L; k++) { r = (r << 1) | (c & 1); c >>= 1; }
      for (var j = r; j < size; j += 1 << L) t[j] = (i << 4) | L;
    }
    return { t: t, bits: max };
  }
  var FIXED = null;
  function fixed() {
    if (FIXED) return FIXED;
    var l = new Uint8Array(288), i;
    for (i = 0; i < 144; i++) l[i] = 8; for (; i < 256; i++) l[i] = 9; for (; i < 280; i++) l[i] = 7; for (; i < 288; i++) l[i] = 8;
    var d = new Uint8Array(30); for (i = 0; i < 30; i++) d[i] = 5;
    FIXED = { lit: huff(l, 288), dist: huff(d, 30) };
    return FIXED;
  }
  // (max: the most this stream may unpack to, MAX_OUT unless less is left; a stream that would go past it is null)
  function inflateRaw(src, size, max) {
    max = max > 0 ? Math.min(max, MAX_OUT) : MAX_OUT;
    if (size > max) return null;
    var out = new Uint8Array(size > 0 ? size : Math.min(max, Math.max(1024, src.length * 4))), op = 0;
    var ip = 0, bb = 0, bc = 0, n = src.length, over = 0;
    function need(k) { while (bc < k) { if (ip < n) bb |= src[ip++] << bc; else over++; bc += 8; } }
    function bits(k) { need(k); var v = bb & ((1 << k) - 1); bb >>>= k; bc -= k; return v; }
    function sym(h) { need(h.bits); var e = h.t[bb & ((1 << h.bits) - 1)], L = e & 15; if (!L) return -1; bb >>>= L; bc -= L; return e >> 4; }
    function room(k) { if (op + k <= out.length) return true; if (size > 0 || op + k > max) return false; var o2 = new Uint8Array(Math.min(max, Math.max(out.length * 2, op + k))); o2.set(out); out = o2; return true; }
    var last = 0;
    while (!last) {
      last = bits(1);
      var type = bits(2);
      if (type === 0) {
        bb = 0; bc = 0;
        if (ip + 4 > n) return null;
        var len = src[ip] | (src[ip + 1] << 8), nlen = src[ip + 2] | (src[ip + 3] << 8); ip += 4;
        if ((len ^ 0xFFFF) !== nlen || ip + len > n || !room(len)) return null;
        out.set(src.subarray(ip, ip + len), op); op += len; ip += len;
        continue;
      }
      var lit, dist;
      if (type === 1) { lit = fixed().lit; dist = fixed().dist; }
      else if (type === 2) {
        var hlit = bits(5) + 257, hdist = bits(5) + 1, hclen = bits(4) + 4, i;
        var cl = new Uint8Array(19);
        for (i = 0; i < hclen; i++) cl[CLORDER[i]] = bits(3);
        var ch = huff(cl, 19), ls = new Uint8Array(hlit + hdist);
        for (i = 0; i < hlit + hdist;) {
          var s = sym(ch);
          if (s < 0) return null;
          if (s < 16) ls[i++] = s;
          else {
            var rep = 0, val = 0;
            if (s === 16) { if (!i) return null; val = ls[i - 1]; rep = 3 + bits(2); }
            else if (s === 17) rep = 3 + bits(3);
            else rep = 11 + bits(7);
            if (i + rep > hlit + hdist) return null;
            while (rep--) ls[i++] = val;
          }
        }
        if (!ls[256]) return null;
        lit = huff(ls.subarray(0, hlit), hlit); dist = huff(ls.subarray(hlit), hdist);
      } else return null;
      for (;;) {
        var c = sym(lit);
        if (c < 0 || over > 4) return null;
        if (c < 256) { if (!room(1)) return null; out[op++] = c; continue; }
        if (c === 256) break;
        c -= 257;
        if (c >= 29) return null;
        var L = LBASE[c] + bits(LEXT[c]);
        var dc = sym(dist);
        if (dc < 0 || dc >= 30) return null;
        var D = DBASE[dc] + bits(DEXT[dc]);
        if (D > op || !room(L)) return null;
        for (var q = 0; q < L; q++) { out[op] = out[op - D]; op++; }
      }
      if (over > 4) return null;
    }
    if (size > 0 && op !== size) return null;
    return op === out.length ? out : out.subarray(0, op);
  }

  /* ------------------------------------------------------------ SHA-1, SHA-256, SHA-512 (and SHA-384) */
  var W1 = new Int32Array(80);
  function sha1Block(H, b, o) {
    var w = W1, i;
    for (i = 0; i < 16; i++) w[i] = (b[o + 4 * i] << 24) | (b[o + 4 * i + 1] << 16) | (b[o + 4 * i + 2] << 8) | b[o + 4 * i + 3];
    sha1Words(H);
  }
  function sha1Words(H) {
    var w = W1, i, t;
    for (i = 16; i < 80; i++) { t = w[i - 3] ^ w[i - 8] ^ w[i - 14] ^ w[i - 16]; w[i] = (t << 1) | (t >>> 31); }
    var a = H[0], b = H[1], c = H[2], d = H[3], e = H[4];
    for (i = 0; i < 80; i++) {
      var f, k;
      if (i < 20) { f = (b & c) | (~b & d); k = 0x5A827999; }
      else if (i < 40) { f = b ^ c ^ d; k = 0x6ED9EBA1; }
      else if (i < 60) { f = (b & c) | (b & d) | (c & d); k = 0x8F1BBCDC | 0; }
      else { f = b ^ c ^ d; k = 0xCA62C1D6 | 0; }
      t = (((a << 5) | (a >>> 27)) + f + e + k + w[i]) | 0;
      e = d; d = c; c = (b << 30) | (b >>> 2); b = a; a = t;
    }
    H[0] = (H[0] + a) | 0; H[1] = (H[1] + b) | 0; H[2] = (H[2] + c) | 0; H[3] = (H[3] + d) | 0; H[4] = (H[4] + e) | 0;
  }
  var K256 = new Int32Array([0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
    0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152, 0xa831c66d,
    0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a,
    0x5b9cca4f, 0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2]);
  var W2 = new Int32Array(64);
  function sha256Block(H, b, o) {
    var w = W2, i;
    for (i = 0; i < 16; i++) w[i] = (b[o + 4 * i] << 24) | (b[o + 4 * i + 1] << 16) | (b[o + 4 * i + 2] << 8) | b[o + 4 * i + 3];
    for (i = 16; i < 64; i++) {
      var x = w[i - 15], y = w[i - 2];
      var s0 = ((x >>> 7) | (x << 25)) ^ ((x >>> 18) | (x << 14)) ^ (x >>> 3), s1 = ((y >>> 17) | (y << 15)) ^ ((y >>> 19) | (y << 13)) ^ (y >>> 10);
      w[i] = (w[i - 16] + s0 + w[i - 7] + s1) | 0;
    }
    var a = H[0], bb = H[1], c = H[2], d = H[3], e = H[4], f = H[5], g = H[6], h = H[7];
    for (i = 0; i < 64; i++) {
      var S1 = ((e >>> 6) | (e << 26)) ^ ((e >>> 11) | (e << 21)) ^ ((e >>> 25) | (e << 7)), chh = (e & f) ^ (~e & g);
      var t1 = (h + S1 + chh + K256[i] + w[i]) | 0;
      var S0 = ((a >>> 2) | (a << 30)) ^ ((a >>> 13) | (a << 19)) ^ ((a >>> 22) | (a << 10)), mj = (a & bb) ^ (a & c) ^ (bb & c);
      var t2 = (S0 + mj) | 0;
      h = g; g = f; f = e; e = (d + t1) | 0; d = c; c = bb; bb = a; a = (t1 + t2) | 0;
    }
    H[0] = (H[0] + a) | 0; H[1] = (H[1] + bb) | 0; H[2] = (H[2] + c) | 0; H[3] = (H[3] + d) | 0; H[4] = (H[4] + e) | 0; H[5] = (H[5] + f) | 0; H[6] = (H[6] + g) | 0; H[7] = (H[7] + h) | 0;
  }
  var K512 = new Int32Array([
    0x428a2f98, 0xd728ae22, 0x71374491, 0x23ef65cd, 0xb5c0fbcf, 0xec4d3b2f, 0xe9b5dba5, 0x8189dbbc, 0x3956c25b, 0xf348b538, 0x59f111f1, 0xb605d019, 0x923f82a4, 0xaf194f9b, 0xab1c5ed5, 0xda6d8118,
    0xd807aa98, 0xa3030242, 0x12835b01, 0x45706fbe, 0x243185be, 0x4ee4b28c, 0x550c7dc3, 0xd5ffb4e2, 0x72be5d74, 0xf27b896f, 0x80deb1fe, 0x3b1696b1, 0x9bdc06a7, 0x25c71235, 0xc19bf174, 0xcf692694,
    0xe49b69c1, 0x9ef14ad2, 0xefbe4786, 0x384f25e3, 0x0fc19dc6, 0x8b8cd5b5, 0x240ca1cc, 0x77ac9c65, 0x2de92c6f, 0x592b0275, 0x4a7484aa, 0x6ea6e483, 0x5cb0a9dc, 0xbd41fbd4, 0x76f988da, 0x831153b5,
    0x983e5152, 0xee66dfab, 0xa831c66d, 0x2db43210, 0xb00327c8, 0x98fb213f, 0xbf597fc7, 0xbeef0ee4, 0xc6e00bf3, 0x3da88fc2, 0xd5a79147, 0x930aa725, 0x06ca6351, 0xe003826f, 0x14292967, 0x0a0e6e70,
    0x27b70a85, 0x46d22ffc, 0x2e1b2138, 0x5c26c926, 0x4d2c6dfc, 0x5ac42aed, 0x53380d13, 0x9d95b3df, 0x650a7354, 0x8baf63de, 0x766a0abb, 0x3c77b2a8, 0x81c2c92e, 0x47edaee6, 0x92722c85, 0x1482353b,
    0xa2bfe8a1, 0x4cf10364, 0xa81a664b, 0xbc423001, 0xc24b8b70, 0xd0f89791, 0xc76c51a3, 0x0654be30, 0xd192e819, 0xd6ef5218, 0xd6990624, 0x5565a910, 0xf40e3585, 0x5771202a, 0x106aa070, 0x32bbd1b8,
    0x19a4c116, 0xb8d2d0c8, 0x1e376c08, 0x5141ab53, 0x2748774c, 0xdf8eeb99, 0x34b0bcb5, 0xe19b48a8, 0x391c0cb3, 0xc5c95a63, 0x4ed8aa4a, 0xe3418acb, 0x5b9cca4f, 0x7763e373, 0x682e6ff3, 0xd6b2b8a3,
    0x748f82ee, 0x5defb2fc, 0x78a5636f, 0x43172f60, 0x84c87814, 0xa1f0ab72, 0x8cc70208, 0x1a6439ec, 0x90befffa, 0x23631e28, 0xa4506ceb, 0xde82bde9, 0xbef9a3f7, 0xb2c67915, 0xc67178f2, 0xe372532b,
    0xca273ece, 0xea26619c, 0xd186b8c7, 0x21c0c207, 0xeada7dd6, 0xcde0eb1e, 0xf57d4f7f, 0xee6ed178, 0x06f067aa, 0x72176fba, 0x0a637dc5, 0xa2c898a6, 0x113f9804, 0xbef90dae, 0x1b710b35, 0x131c471b,
    0x28db77f5, 0x23047d84, 0x32caab7b, 0x40c72493, 0x3c9ebe0a, 0x15c9bebc, 0x431d67c4, 0x9c100d4c, 0x4cc5d4be, 0xcb3e42b6, 0x597f299c, 0xfc657e2a, 0x5fcb6fab, 0x3ad6faec, 0x6c44198c, 0x4a475817]);
  var W5 = new Int32Array(160);
  /* one 128-byte block, its 32 words (hi, lo) already in W5[0..31]; H is 16 words (hi, lo) */
  function sha512Words(H) {
    var w = W5, i;
    for (i = 32; i < 160; i += 2) {
      var xh = w[i - 30], xl = w[i - 29];
      var s0h = ((xh >>> 1) | (xl << 31)) ^ ((xh >>> 8) | (xl << 24)) ^ (xh >>> 7);
      var s0l = ((xl >>> 1) | (xh << 31)) ^ ((xl >>> 8) | (xh << 24)) ^ ((xl >>> 7) | (xh << 25));
      xh = w[i - 4]; xl = w[i - 3];
      var s1h = ((xh >>> 19) | (xl << 13)) ^ ((xl >>> 29) | (xh << 3)) ^ (xh >>> 6);
      var s1l = ((xl >>> 19) | (xh << 13)) ^ ((xh >>> 29) | (xl << 3)) ^ ((xl >>> 6) | (xh << 26));
      var lo = (s0l >>> 0) + (s1l >>> 0) + (w[i - 13] >>> 0) + (w[i - 31] >>> 0);
      w[i] = (s0h + s1h + w[i - 14] + w[i - 32] + ((lo / 0x100000000) | 0)) | 0; w[i + 1] = lo | 0;
    }
    var ah = H[0], al = H[1], bh = H[2], bl = H[3], ch = H[4], cl = H[5], dh = H[6], dl = H[7];
    var eh = H[8], el = H[9], fh = H[10], fl = H[11], gh = H[12], gl = H[13], hh = H[14], hl = H[15];
    for (i = 0; i < 160; i += 2) {
      var S1h = ((eh >>> 14) | (el << 18)) ^ ((eh >>> 18) | (el << 14)) ^ ((el >>> 9) | (eh << 23));
      var S1l = ((el >>> 14) | (eh << 18)) ^ ((el >>> 18) | (eh << 14)) ^ ((eh >>> 9) | (el << 23));
      var chh = (eh & fh) ^ (~eh & gh), chl = (el & fl) ^ (~el & gl);
      var t1l = (hl >>> 0) + (S1l >>> 0) + (chl >>> 0) + (K512[i + 1] >>> 0) + (w[i + 1] >>> 0);
      var t1h = (hh + S1h + chh + K512[i] + w[i] + ((t1l / 0x100000000) | 0)) | 0;
      t1l = t1l | 0;
      var S0h = ((ah >>> 28) | (al << 4)) ^ ((al >>> 2) | (ah << 30)) ^ ((al >>> 7) | (ah << 25));
      var S0l = ((al >>> 28) | (ah << 4)) ^ ((ah >>> 2) | (al << 30)) ^ ((ah >>> 7) | (al << 25));
      var mjh = (ah & bh) ^ (ah & ch) ^ (bh & ch), mjl = (al & bl) ^ (al & cl) ^ (bl & cl);
      var t2l = (S0l >>> 0) + (mjl >>> 0);
      var t2h = (S0h + mjh + ((t2l / 0x100000000) | 0)) | 0;
      hh = gh; hl = gl; gh = fh; gl = fl; fh = eh; fl = el;
      var x = (dl >>> 0) + (t1l >>> 0);
      eh = (dh + t1h + ((x / 0x100000000) | 0)) | 0; el = x | 0;
      dh = ch; dl = cl; ch = bh; cl = bl; bh = ah; bl = al;
      x = (t1l >>> 0) + (t2l >>> 0);
      ah = (t1h + t2h + ((x / 0x100000000) | 0)) | 0; al = x | 0;
    }
    var v = [ah, al, bh, bl, ch, cl, dh, dl, eh, el, fh, fl, gh, gl, hh, hl];
    for (i = 0; i < 16; i += 2) { var y = (H[i + 1] >>> 0) + (v[i + 1] >>> 0); H[i] = (H[i] + v[i] + ((y / 0x100000000) | 0)) | 0; H[i + 1] = y | 0; }
  }
  var IV = {
    SHA1: [0x67452301, 0xEFCDAB89, 0x98BADCFE, 0x10325476, 0xC3D2E1F0],
    SHA256: [0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19],
    SHA512: [0x6a09e667, 0xf3bcc908, 0xbb67ae85, 0x84caa73b, 0x3c6ef372, 0xfe94f82b, 0xa54ff53a, 0x5f1d36f1, 0x510e527f, 0xade682d1, 0x9b05688c, 0x2b3e6c1f, 0x1f83d9ab, 0xfb41bd6b, 0x5be0cd19, 0x137e2179],
    SHA384: [0xcbbb9d5d, 0xc1059ed8, 0x629a292a, 0x367cd507, 0x9159015a, 0x3070dd17, 0x152fecd8, 0xf70e5939, 0x67332667, 0xffc00b31, 0x8eb44a87, 0x68581511, 0xdb0c2e0d, 0x64f98fa7, 0x47b5481d, 0xbefa4fa4],
  };
  var HLEN = { SHA1: 20, SHA256: 32, SHA384: 48, SHA512: 64 };
  function hashName(s) { var k = String(s || '').toUpperCase().replace(/[^A-Z0-9]/g, ''); return HLEN[k] ? k : ''; }
  function hash(name, bytes) {
    var big = name === 'SHA512' || name === 'SHA384', bs = big ? 128 : 64, n = bytes.length;
    var total = Math.ceil((n + (big ? 17 : 9)) / bs) * bs, buf = new Uint8Array(total);
    buf.set(bytes); buf[n] = 0x80;
    var bitsHi = Math.floor(n / 0x20000000), bitsLo = (n * 8) >>> 0;
    buf[total - 8] = bitsHi >>> 24; buf[total - 7] = (bitsHi >>> 16) & 255; buf[total - 6] = (bitsHi >>> 8) & 255; buf[total - 5] = bitsHi & 255;
    buf[total - 4] = bitsLo >>> 24; buf[total - 3] = (bitsLo >>> 16) & 255; buf[total - 2] = (bitsLo >>> 8) & 255; buf[total - 1] = bitsLo & 255;
    var H = new Int32Array(IV[name]), o, i;
    for (o = 0; o < total; o += bs) {
      if (name === 'SHA1') sha1Block(H, buf, o);
      else if (name === 'SHA256') sha256Block(H, buf, o);
      else { for (i = 0; i < 32; i++) W5[i] = (buf[o + 4 * i] << 24) | (buf[o + 4 * i + 1] << 16) | (buf[o + 4 * i + 2] << 8) | buf[o + 4 * i + 3]; sha512Words(H); }
    }
    var out = new Uint8Array(HLEN[name]);
    for (i = 0; i < out.length; i++) out[i] = (H[i >> 2] >>> (24 - 8 * (i & 3))) & 255;
    return out;
  }
  /* Excel's spin: H(i, as 4 bytes, and the last hash) a spinCount of times. The phone's own hash when it lends one;
     else here (SHA-512 by a block filled straight from the last hash's words: no bytes, no allocation) */
  function spin(name, h0, count) {
    var N = typeof KoshNative !== 'undefined' && KoshNative && typeof KoshNative.spin === 'function' ? KoshNative : null;
    if (N) { try { var r = fromB64(String(N.spin(name, toB64(h0), count))); if (r.length === HLEN[name]) return r; } catch (e) { /* the hash here */ } }
    var h = h0, i, n;
    if (name !== 'SHA512') {
      var buf = new Uint8Array(4 + h0.length);
      for (n = 0; n < count; n++) { buf[0] = n & 255; buf[1] = (n >>> 8) & 255; buf[2] = (n >>> 16) & 255; buf[3] = n >>> 24; buf.set(h, 4); h = hash(name, buf); }
      return h;
    }
    var H = new Int32Array(16), prev = new Int32Array(16), iv = IV.SHA512;
    for (i = 0; i < 16; i++) prev[i] = (h0[4 * i] << 24) | (h0[4 * i + 1] << 16) | (h0[4 * i + 2] << 8) | h0[4 * i + 3];
    for (n = 0; n < count; n++) {
      W5[0] = ((n & 255) << 24) | (((n >>> 8) & 255) << 16) | (((n >>> 16) & 255) << 8) | (n >>> 24);
      for (i = 0; i < 16; i++) W5[i + 1] = prev[i];
      W5[17] = 0x80000000 | 0; for (i = 18; i < 31; i++) W5[i] = 0; W5[31] = 68 * 8;
      for (i = 0; i < 16; i++) H[i] = iv[i];
      sha512Words(H);
      for (i = 0; i < 16; i++) prev[i] = H[i];
    }
    var out = new Uint8Array(64);
    for (i = 0; i < 64; i++) out[i] = (prev[i >> 2] >>> (24 - 8 * (i & 3))) & 255;
    return out;
  }
  /* HMAC-SHA1 with its two keyed states worked out once (PBKDF2 runs a thousand of them) */
  function hmacSha1State(key) {
    if (key.length > 64) key = hash('SHA1', key);
    var ip = new Uint8Array(64), op = new Uint8Array(64), i;
    for (i = 0; i < 64; i++) { var k = i < key.length ? key[i] : 0; ip[i] = k ^ 0x36; op[i] = k ^ 0x5c; }
    var I = new Int32Array(IV.SHA1), O = new Int32Array(IV.SHA1);
    sha1Block(I, ip, 0); sha1Block(O, op, 0);
    return { I: I, O: O };
  }
  // the HMAC of a 20-byte message (PBKDF2's every round after the first), words in and out
  function hmac20(st, m, out) {
    var H = new Int32Array(st.I), i;
    for (i = 0; i < 5; i++) W1[i] = m[i];
    W1[5] = 0x80000000 | 0; for (i = 6; i < 15; i++) W1[i] = 0; W1[15] = (64 + 20) * 8;
    sha1Words(H);
    var G = new Int32Array(st.O);
    for (i = 0; i < 5; i++) W1[i] = H[i];
    W1[5] = 0x80000000 | 0; for (i = 6; i < 15; i++) W1[i] = 0; W1[15] = (64 + 20) * 8;
    sha1Words(G);
    for (i = 0; i < 5; i++) out[i] = G[i];
  }
  function hmacSha1(st, msg) {
    // (keyed state + message): hashed as one, the keyed block's state standing in for its 64 bytes
    var H = new Int32Array(st.I), n = msg.length, total = Math.ceil((n + 9) / 64) * 64, buf = new Uint8Array(total), i, o;
    buf.set(msg); buf[n] = 0x80;
    var bits = (64 + n) * 8;
    buf[total - 5] = Math.floor(bits / 0x100000000) & 255; buf[total - 4] = bits >>> 24; buf[total - 3] = (bits >>> 16) & 255; buf[total - 2] = (bits >>> 8) & 255; buf[total - 1] = bits & 255;
    for (o = 0; o < total; o += 64) sha1Block(H, buf, o);
    var G = new Int32Array(st.O);
    for (i = 0; i < 5; i++) W1[i] = H[i];
    W1[5] = 0x80000000 | 0; for (i = 6; i < 15; i++) W1[i] = 0; W1[15] = (64 + 20) * 8;
    sha1Words(G);
    var out = new Uint8Array(20);
    for (i = 0; i < 20; i++) out[i] = (G[i >> 2] >>> (24 - 8 * (i & 3))) & 255;
    return out;
  }
  function pbkdf2Sha1(pw, salt, iter, len) {
    var N = typeof KoshNative !== 'undefined' && KoshNative && typeof KoshNative.pbkdf2 === 'function' ? KoshNative : null;
    if (N) { try { var r = fromB64(String(N.pbkdf2(toB64(pw), toB64(salt), iter, len))); if (r.length === len) return r; } catch (e) { /* worked out here */ } }
    var st = hmacSha1State(pw), out = new Uint8Array(len), blocks = Math.ceil(len / 20), U = new Int32Array(5), T = new Int32Array(5), i, j;
    for (var b = 1; b <= blocks; b++) {
      var s = new Uint8Array(salt.length + 4); s.set(salt); s[salt.length] = b >>> 24; s[salt.length + 1] = (b >>> 16) & 255; s[salt.length + 2] = (b >>> 8) & 255; s[salt.length + 3] = b & 255;
      var u1 = hmacSha1(st, s);
      for (i = 0; i < 5; i++) { U[i] = (u1[4 * i] << 24) | (u1[4 * i + 1] << 16) | (u1[4 * i + 2] << 8) | u1[4 * i + 3]; T[i] = U[i]; }
      for (j = 1; j < iter; j++) { hmac20(st, U, U); for (i = 0; i < 5; i++) T[i] ^= U[i]; }
      for (i = 0; i < 20 && (b - 1) * 20 + i < len; i++) out[(b - 1) * 20 + i] = (T[i >> 2] >>> (24 - 8 * (i & 3))) & 255;
    }
    return out;
  }

  /* ------------------------------------------------------------ AES (FIPS-197), 128/192/256, encrypt and decrypt */
  var SB = new Uint8Array(256), SBI = new Uint8Array(256), TE = [new Int32Array(256), new Int32Array(256), new Int32Array(256), new Int32Array(256)], TD = [new Int32Array(256), new Int32Array(256), new Int32Array(256), new Int32Array(256)];
  (function () {
    var d = [], t = [], x, i;
    for (i = 0; i < 256; i++) t[(d[i] = i << 1 ^ (i >> 7) * 283) ^ i] = i;
    for (x = 0, i = 0; !SB[x]; x ^= (d[x] || 1), i = t[i] || 1) {
      var s = i ^ i << 1 ^ i << 2 ^ i << 3 ^ i << 4; s = s >> 8 ^ s & 255 ^ 99;
      SB[x] = s; SBI[s] = x;
      var x2 = d[x], x4 = d[x2], x8 = d[x4];
      var tEnc = d[s] * 0x101 ^ s * 0x1010100, tDec = x8 * 0x1010101 ^ x4 * 0x10001 ^ x2 * 0x101 ^ x * 0x1010100;
      for (var k = 0; k < 4; k++) { TE[k][x] = tEnc = tEnc << 24 ^ tEnc >>> 8; TD[k][s] = tDec = tDec << 24 ^ tDec >>> 8; }
    }
    SB[0] = 99; SBI[99] = 0;
  })();
  function aesKey(key) {
    var kl = key.length; if (kl !== 16 && kl !== 24 && kl !== 32) return null;
    var nk = kl / 4, rounds = nk + 6, n = 4 * (rounds + 1), ek = new Int32Array(n), dk = new Int32Array(n), i, j, t, rcon = 1;
    for (i = 0; i < nk; i++) ek[i] = (key[4 * i] << 24) | (key[4 * i + 1] << 16) | (key[4 * i + 2] << 8) | key[4 * i + 3];
    for (i = nk; i < n; i++) {
      t = ek[i - 1];
      if (i % nk === 0 || (nk === 8 && i % nk === 4)) {
        t = SB[t >>> 24] << 24 ^ SB[t >> 16 & 255] << 16 ^ SB[t >> 8 & 255] << 8 ^ SB[t & 255];
        if (i % nk === 0) { t = t << 8 ^ t >>> 24 ^ rcon << 24; rcon = rcon << 1 ^ (rcon >> 7) * 283; }
      }
      ek[i] = ek[i - nk] ^ t;
    }
    for (j = 0, i = n; i; j++, i--) {
      t = ek[j & 3 ? i : i - 4];
      dk[j] = i <= 4 || j < 4 ? t : TD[0][SB[t >>> 24]] ^ TD[1][SB[t >> 16 & 255]] ^ TD[2][SB[t >> 8 & 255]] ^ TD[3][SB[t & 255]];
    }
    return { ek: ek, dk: dk, rounds: rounds };
  }
  // one block through (enc: the encrypting key and S-box; dec: the decrypting), sjcl's arrangement
  function aesBlock(K, inp, io, out, oo, dec) {
    var key = dec ? K.dk : K.ek, T = dec ? TD : TE, S = dec ? SBI : SB, T0 = T[0], T1 = T[1], T2 = T[2], T3 = T[3];
    var w0 = (inp[io] << 24 | inp[io + 1] << 16 | inp[io + 2] << 8 | inp[io + 3]);
    var w1 = (inp[io + 4] << 24 | inp[io + 5] << 16 | inp[io + 6] << 8 | inp[io + 7]);
    var w2 = (inp[io + 8] << 24 | inp[io + 9] << 16 | inp[io + 10] << 8 | inp[io + 11]);
    var w3 = (inp[io + 12] << 24 | inp[io + 13] << 16 | inp[io + 14] << 8 | inp[io + 15]);
    var a = w0 ^ key[0], b = (dec ? w3 : w1) ^ key[1], c = w2 ^ key[2], d = (dec ? w1 : w3) ^ key[3], kp = 4, i, a2, b2, c2;
    var nInner = K.rounds - 1;
    for (i = 0; i < nInner; i++) {
      a2 = T0[a >>> 24] ^ T1[b >> 16 & 255] ^ T2[c >> 8 & 255] ^ T3[d & 255] ^ key[kp];
      b2 = T0[b >>> 24] ^ T1[c >> 16 & 255] ^ T2[d >> 8 & 255] ^ T3[a & 255] ^ key[kp + 1];
      c2 = T0[c >>> 24] ^ T1[d >> 16 & 255] ^ T2[a >> 8 & 255] ^ T3[b & 255] ^ key[kp + 2];
      d = T0[d >>> 24] ^ T1[a >> 16 & 255] ^ T2[b >> 8 & 255] ^ T3[c & 255] ^ key[kp + 3];
      kp += 4; a = a2; b = b2; c = c2;
    }
    var r = [0, 0, 0, 0];
    for (i = 0; i < 4; i++) {
      r[dec ? 3 & -i : i] = S[a >>> 24] << 24 ^ S[b >> 16 & 255] << 16 ^ S[c >> 8 & 255] << 8 ^ S[d & 255] ^ key[kp++];
      a2 = a; a = b; b = c; c = d; d = a2;
    }
    for (i = 0; i < 4; i++) { var v = r[i]; out[oo + 4 * i] = v >>> 24; out[oo + 4 * i + 1] = (v >>> 16) & 255; out[oo + 4 * i + 2] = (v >>> 8) & 255; out[oo + 4 * i + 3] = v & 255; }
  }
  function aesCbcDecrypt(K, iv, data) {
    var n = data.length - (data.length % 16), out = new Uint8Array(n), prev = iv.slice(0, 16), blk = new Uint8Array(16);
    for (var o = 0; o < n; o += 16) {
      aesBlock(K, data, o, blk, 0, true);
      for (var i = 0; i < 16; i++) { out[o + i] = blk[i] ^ prev[i]; prev[i] = data[o + i]; }
    }
    return out;
  }
  // WinZip's counter mode: a 16-byte counter, little-endian, from 1
  function aesCtrWinZip(K, data) {
    var out = new Uint8Array(data.length), ctr = new Uint8Array(16), ks = new Uint8Array(16), i, o;
    for (o = 0; o < data.length; o += 16) {
      for (i = 0; i < 16; i++) { ctr[i] = (ctr[i] + 1) & 255; if (ctr[i]) break; }
      aesBlock(K, ctr, 0, ks, 0, false);
      var m = Math.min(16, data.length - o);
      for (i = 0; i < m; i++) out[o + i] = data[o + i] ^ ks[i];
    }
    return out;
  }

  /* ------------------------------------------------------------ zip */
  function zipEntries(b) {
    var eocd = -1;
    for (var i = b.length - 22; i >= Math.max(0, b.length - 65557); i--) if (u32(b, i) === 0x06054B50) { eocd = i; break; }
    if (eocd < 0) return null;
    var count = u16(b, eocd + 10), at = u32(b, eocd + 16), out = [], seen = 0;
    // (a zip whose list of files runs short of the count it gives is damaged: never a part of it read as the whole.
    // A zip64 (count or place saturated) is not one kosh reads)
    out.count = count;
    if (count === 0xFFFF || at === 0xFFFFFFFF) { out.damaged = true; return out; }
    for (var k = 0; k < count; k++) {
      if (at + 46 > b.length || u32(b, at) !== 0x02014B50) break;
      seen++;
      var e = { flags: u16(b, at + 8), method: u16(b, at + 10), time: u16(b, at + 12), crc: u32(b, at + 16), csize: u32(b, at + 20), usize: u32(b, at + 24) };
      var nlen = u16(b, at + 28), elen = u16(b, at + 30), clen = u16(b, at + 32), local = u32(b, at + 42);
      if (at + 46 + nlen > b.length) break;
      var nameBytes = b.subarray(at + 46, at + 46 + nlen);
      e.name = e.flags & 0x800 ? TextDecoderLite(nameBytes) : String.fromCharCode.apply(null, Array.prototype.slice.call(nameBytes));
      e.extra = b.subarray(at + 46 + nlen, at + 46 + nlen + elen);
      if (local + 30 <= b.length && u32(b, local) === 0x04034B50) {
        e.data = local + 30 + u16(b, local + 26) + u16(b, local + 28);
        // (the local header's own extra field holds the AES record too, when the central one doesn't)
        if (!e.extra.length) e.extra = b.subarray(local + 30 + u16(b, local + 26), e.data);
      } else e.data = -1;
      if (!/\/$/.test(e.name)) out.push(e);
      at += 46 + nlen + elen + clen;
    }
    if (seen < count) out.damaged = true;
    return out;
  }
  // a UTF-8 name, decoded without TextDecoder (JavaScriptCore may not have one)
  function TextDecoderLite(u) {
    var s = '', i = 0;
    while (i < u.length) {
      var c = u[i++];
      if (c < 0x80) s += String.fromCharCode(c);
      else if (c < 0xE0) s += String.fromCharCode(((c & 31) << 6) | (u[i++] & 63));
      else if (c < 0xF0) s += String.fromCharCode(((c & 15) << 12) | ((u[i++] & 63) << 6) | (u[i++] & 63));
      else { var cp = ((c & 7) << 18) | ((u[i++] & 63) << 12) | ((u[i++] & 63) << 6) | (u[i++] & 63); cp -= 0x10000; s += String.fromCharCode(0xD800 + (cp >> 10), 0xDC00 + (cp & 1023)); }
    }
    return s;
  }
  function aesExtra(extra) {
    for (var i = 0; i + 4 <= extra.length;) {
      var id = u16(extra, i), len = u16(extra, i + 2);
      if (id === 0x9901 && len >= 7) return { version: u16(extra, i + 4), strength: extra[i + 8], method: u16(extra, i + 9) };
      i += 4 + len;
    }
    return null;
  }
  function plainOf(raw, method, usize, left) {
    if (method === 0) return raw.length <= (left > 0 ? left : MAX_OUT) ? raw : null;
    if (method === 8) return inflateRaw(raw, usize, left);
    return null;
  }
  /* one entry opened with one password, or null: proven by its CRC (ZipCrypto, AE-1) or its HMAC (AE-2) */
  function zcKeys(pw) {
    var k = [0x12345678, 0x23456789, 0x34567890];
    for (var i = 0; i < pw.length; i++) zcUpdate(k, pw[i]);
    return k;
  }
  function zcUpdate(k, c) {
    k[0] = CRC[(k[0] ^ c) & 255] ^ (k[0] >>> 8);
    k[1] = (Math.imul((k[1] + (k[0] & 255)) | 0, 134775813) + 1) | 0;
    k[2] = CRC[(k[2] ^ (k[1] >>> 24)) & 255] ^ (k[2] >>> 8);
  }
  function zcDecrypt(k, src) {
    var out = new Uint8Array(src.length);
    for (var i = 0; i < src.length; i++) {
      var t = (k[2] | 2) & 0xFFFF, c = src[i] ^ ((Math.imul(t, t ^ 1) >>> 8) & 255);
      out[i] = c; zcUpdate(k, c);
    }
    return out;
  }
  function openEntry(b, e, pw, quick, left) {
    if (e.data < 0 || e.data + e.csize > b.length) return null;
    var raw = b.subarray(e.data, e.data + e.csize);
    if (!(e.flags & 1)) { var p0 = plainOf(raw, e.method, e.usize, left); return p0 && crc32(p0) === e.crc ? p0 : null; }
    if (e.flags & 0x40) return null;   // PKWARE's "strong encryption": not a lock kosh opens
    var ae = e.method === 99 ? aesExtra(e.extra) : null;
    if (e.method === 99 && !ae) return null;
    if (!ae) {
      if (raw.length < 12) return null;
      var k = zcKeys(pw), head = zcDecrypt(k, raw.subarray(0, 12)), check = head[11];
      // the check byte: the CRC's top byte, or (an entry with its sizes after it) the time's
      if (check !== (e.crc >>> 24) && !((e.flags & 8) && check === ((e.time >>> 8) & 255))) return null;
      if (quick) return true;
      var p1 = plainOf(zcDecrypt(k, raw.subarray(12)), e.method, e.usize, left);
      return p1 && crc32(p1) === e.crc ? p1 : null;
    }
    var kl = ae.strength === 1 ? 16 : ae.strength === 2 ? 24 : ae.strength === 3 ? 32 : 0;
    if (!kl) return null;
    var sl = kl / 2;
    if (raw.length < sl + 12) return null;
    var dk = pbkdf2Sha1(pw, raw.subarray(0, sl), 1000, 2 * kl + 2);
    if (dk[2 * kl] !== raw[sl] || dk[2 * kl + 1] !== raw[sl + 1]) return null;
    var enc = raw.subarray(sl + 2, raw.length - 10), mac = raw.subarray(raw.length - 10);
    if (!sameBytes(hmacSha1(hmacSha1State(dk.subarray(kl, 2 * kl)), enc), mac, 10)) return null;
    if (quick) return true;
    var K = aesKey(dk.subarray(0, kl));
    var p2 = plainOf(aesCtrWinZip(K, enc), ae.method, e.usize, left);
    if (!p2 || (ae.version === 1 && crc32(p2) !== e.crc)) return null;
    return p2;
  }
  var KEEP = /\.(?:pdf|xlsx|csv|xls|txt|html?|xml)$/i;
  function openZip(b, pws) {
    var es = zipEntries(b);
    if (es && es.damaged) return { state: 'unreadable', kind: 'zip', why: 'A damaged zip: ' + es.length + ' of the ' + es.count + ' files it lists could be found' };
    if (!es || !es.length) return { state: 'unreadable', kind: 'zip', why: 'Not a zip kosh can read' };
    var wanted = es.filter(function (e) { return KEEP.test(e.name); });
    if (!wanted.length) wanted = es;
    wanted = wanted.slice(0, 40);
    var says = wanted.reduce(function (n, e) { return n + e.usize; }, 0);
    if (says > MAX_OUT) return { state: 'unreadable', kind: 'zip', why: 'Too big to be a statement: it would unpack to ' + Math.round(says / 1048576) + ' MB' };
    var locked = wanted.filter(function (e) { return e.flags & 1; });
    if (locked.some(function (e) { return e.flags & 0x40; })) return { state: 'unreadable', kind: 'zip', why: 'Locked with PKWARE\'s strong encryption, which kosh can\'t open' };
    var files = [];
    function take(pw) {
      files = [];
      var used = 0;
      for (var i = 0; i < wanted.length; i++) {
        var p = openEntry(b, wanted[i], pw, false, MAX_OUT - used);
        if (!p) return false;
        used += p.length;
        files.push({ name: wanted[i].name, b64: toB64(p) });
      }
      return true;
    }
    if (!locked.length) return take(new Uint8Array(0)) ? { state: 'plain', kind: 'zip', password: '', files: files } : { state: 'unreadable', kind: 'zip', why: 'A zip whose files don\'t add up' };
    // the smallest locked entry is the cheap test of each password
    var probe = locked.slice().sort(function (x, y) { return x.csize - y.csize; })[0];
    for (var c = 0; c < pws.length; c++) {
      var pw = utf8(pws[c]);
      if (!openEntry(b, probe, pw, true)) continue;
      if (take(pw)) return { state: 'opened', kind: 'zip', password: pws[c], files: files };
    }
    return { state: 'locked', kind: 'zip', how: probe.method === 99 ? 'aes' : 'zipcrypto' };
  }

  /* which of a zip's files to read, in order: every statement (a PDF, a workbook, a CSV) that isn't a leaflet riding along
     (terms, an FAQ, a readme, a disclaimer), a statement sent in two formats once (its PDF; else its workbook; else its
     CSV), never a folder, a Mac's resource fork or an old .xls kosh can't open, and at most twelve */
  var LEAFLET = /\b(?:terms|t ?& ?c|tnc|faq|faqs|readme|read me|instructions?|disclaimer|important (?:information|notice)|brochure|guide|help)\b/i;
  function zipReads(names) {
    var rank = function (n) { return /\.pdf$/i.test(n) ? 0 : /\.xlsx$/i.test(n) ? 1 : /\.csv$/i.test(n) ? 2 : 9; };
    var base = function (n) { return String(n).split('/').pop(); };
    var stem = function (n) { return base(n).replace(/\.[a-z0-9]+$/i, '').toLowerCase().replace(/[^a-z0-9]+/g, ''); };
    var keep = {}, order = [];
    (names || []).forEach(function (n) {
      n = String(n || '');
      if (!n || /\/$/.test(n) || /(?:^|\/)__macosx\//i.test(n) || /^\._/.test(base(n)) || rank(n) > 2) return;
      if (LEAFLET.test(base(n).replace(/[_\-.]+/g, ' '))) return;
      var s = stem(n);
      if (!(s in keep)) { keep[s] = n; order.push(s); } else if (rank(n) < rank(keep[s])) keep[s] = n;
    });
    return order.map(function (s) { return keep[s]; }).slice(0, 12);
  }

  /* ------------------------------------------------------------ a compound file (OLE2) and Excel's agile lock */
  var CFB_SIG = [0xD0, 0xCF, 0x11, 0xE0, 0xA1, 0xB1, 0x1A, 0xE1];
  function isCfb(b) { for (var i = 0; i < 8; i++) if (b[i] !== CFB_SIG[i]) return false; return b.length >= 512; }
  function cfbStreams(b) {
    var shift = u16(b, 30), mshift = u16(b, 32), ss = 1 << shift, ms = 1 << mshift;
    if (ss !== 512 && ss !== 4096) return null;
    var nFat = u32(b, 44), dirStart = u32(b, 48), cutoff = u32(b, 56), mfStart = u32(b, 60), nMf = u32(b, 64), difStart = u32(b, 68), nDif = u32(b, 72);
    var END = 0xFFFFFFFE, FREE = 0xFFFFFFFF;
    function sec(id) { return (id + 1) * ss; }
    var fatSecs = [], i;
    for (i = 0; i < 109 && fatSecs.length < nFat; i++) { var s0 = u32(b, 76 + 4 * i); if (s0 !== FREE) fatSecs.push(s0); }
    var dif = difStart, guard = 0;
    while (fatSecs.length < nFat && dif !== END && dif !== FREE && guard++ < nDif + 1) {
      var o = sec(dif); if (o + ss > b.length) return null;
      for (i = 0; i < ss / 4 - 1 && fatSecs.length < nFat; i++) { var s1 = u32(b, o + 4 * i); if (s1 !== FREE) fatSecs.push(s1); }
      dif = u32(b, o + ss - 4);
    }
    var fat = new Uint32Array(fatSecs.length * ss / 4);
    for (i = 0; i < fatSecs.length; i++) { var fo = sec(fatSecs[i]); if (fo + ss > b.length) return null; for (var j = 0; j < ss / 4; j++) fat[i * ss / 4 + j] = u32(b, fo + 4 * j); }
    function chain(start, table, max) {
      var out = [], s = start, g = 0;
      while (s !== END && s !== FREE && s < table.length && g++ < max) { out.push(s); s = table[s]; }
      return out;
    }
    function readChain(start, size) {
      var ids = chain(start, fat, Math.ceil(b.length / ss) + 2), out = new Uint8Array(ids.length * ss);
      for (var k = 0; k < ids.length; k++) { var so = sec(ids[k]); if (so + ss > b.length) return null; out.set(b.subarray(so, so + ss), k * ss); }
      return size >= 0 ? out.subarray(0, Math.min(size, out.length)) : out;
    }
    var dir = readChain(dirStart, -1);
    if (!dir) return null;
    var entries = [];
    for (i = 0; i + 128 <= dir.length; i += 128) {
      var nl = u16(dir, i + 64), type = dir[i + 66];
      if (!type || nl < 2 || nl > 64) continue;
      var name = '';
      for (var q = 0; q < nl - 2; q += 2) name += String.fromCharCode(u16(dir, i + q));
      entries.push({ name: name, type: type, start: u32(dir, i + 116), size: u32(dir, i + 120) });
    }
    var root = entries.filter(function (e) { return e.type === 5; })[0];
    var mini = root ? readChain(root.start, root.size) : null;
    var mfat = null;
    if (nMf && mfStart !== END) { var mb = readChain(mfStart, -1); if (mb) { mfat = new Uint32Array(mb.length / 4); for (i = 0; i < mfat.length; i++) mfat[i] = u32(mb, 4 * i); } }
    function stream(name) {
      var e = entries.filter(function (x) { return x.type === 2 && x.name === name; })[0];
      if (!e) return null;
      if (e.size < cutoff) {
        if (!mini || !mfat) return null;
        var ids = chain(e.start, mfat, mfat.length + 1), out = new Uint8Array(ids.length * ms);
        for (var k = 0; k < ids.length; k++) { var mo = ids[k] * ms; if (mo + ms > mini.length) return null; out.set(mini.subarray(mo, mo + ms), k * ms); }
        return out.subarray(0, e.size);
      }
      return readChain(e.start, e.size);
    }
    return { stream: stream, names: entries.map(function (e) { return e.name; }) };
  }
  function attrs(tag) { var o = {}, m, re = /([A-Za-z]+)="([^"]*)"/g; while ((m = re.exec(tag))) o[m[1]] = m[2]; return o; }
  function agileInfo(info) {
    if (!info || info.length < 8) return null;
    var major = u16(info, 0), minor = u16(info, 2);
    if (!(major === 4 && minor === 4)) return { standard: major >= 2 && major <= 4 && minor === 2 };
    var xml = TextDecoderLite(info.subarray(8));
    var kd = /<(?:\w+:)?keyData\b([^>]*)>/.exec(xml), ek = /<(?:\w+:)?encryptedKey\b([^>]*)>/.exec(xml), di = /<(?:\w+:)?dataIntegrity\b([^>]*)>/.exec(xml);
    if (!kd || !ek) return null;
    var k = attrs(kd[1]), p = attrs(ek[1]), g = di ? attrs(di[1]) : {};
    var r = {
      dataSalt: fromB64(k.saltValue), dataBlock: +k.blockSize || 16, dataKeyBits: +k.keyBits || 256, dataHash: hashName(k.hashAlgorithm), dataCipher: k.cipherAlgorithm || 'AES', dataChain: k.cipherChaining || 'ChainingModeCBC',
      spin: +p.spinCount || 0, salt: fromB64(p.saltValue), block: +p.blockSize || 16, keyBits: +p.keyBits || 256, hash: hashName(p.hashAlgorithm), cipher: p.cipherAlgorithm || 'AES', chain: p.cipherChaining || 'ChainingModeCBC',
      vIn: fromB64(p.encryptedVerifierHashInput), vHash: fromB64(p.encryptedVerifierHashValue), key: fromB64(p.encryptedKeyValue),
      hmacKey: g.encryptedHmacKey ? fromB64(g.encryptedHmacKey) : null, hmacValue: g.encryptedHmacValue ? fromB64(g.encryptedHmacValue) : null,
    };
    if (!r.hash || !r.dataHash || r.cipher !== 'AES' || r.dataCipher !== 'AES' || !/CBC/.test(r.chain + r.dataChain) || r.spin < 1 || r.spin > 10000000) return { odd: true };
    return r;
  }
  function fit(bytes, n, pad) { var out = new Uint8Array(n); for (var i = 0; i < n; i++) out[i] = i < bytes.length ? bytes[i] : pad; return out; }
  var BK_VIN = [0xfe, 0xa7, 0xd2, 0x76, 0x3b, 0x4b, 0x9e, 0x79], BK_VHASH = [0xd7, 0xaa, 0x0f, 0x6d, 0x30, 0x61, 0x34, 0x4e], BK_KEY = [0x14, 0x6e, 0x0b, 0xe7, 0xab, 0xac, 0xd0, 0xd6];
  /* the package's secret key for this password, or null: the verifier proves the password before anything is decrypted */
  function agileKey(a, pw) {
    var h = spin(a.hash, hash(a.hash, concat([a.salt, utf16le(pw)])), a.spin);
    function keyFor(bk) { return aesKey(fit(hash(a.hash, concat([h, new Uint8Array(bk)])), a.keyBits / 8, 0x36)); }
    var iv = fit(a.salt, a.block, 0x36);
    var K1 = keyFor(BK_VIN), K2 = keyFor(BK_VHASH), K3 = keyFor(BK_KEY);
    if (!K1 || !K2 || !K3) return null;
    var vin = aesCbcDecrypt(K1, iv, a.vIn).subarray(0, a.salt.length);
    var vh = aesCbcDecrypt(K2, iv, a.vHash);
    var want = hash(a.hash, vin);
    if (!sameBytes(vh, want, want.length)) return null;
    return aesCbcDecrypt(K3, iv, a.key).subarray(0, a.dataKeyBits / 8);
  }
  // an HMAC with any of the four hashes (the package's integrity check)
  function hmac(name, key, msg) {
    var bs = name === 'SHA512' || name === 'SHA384' ? 128 : 64, i;
    if (key.length > bs) key = hash(name, key);
    var ip = new Uint8Array(bs), op = new Uint8Array(bs);
    for (i = 0; i < bs; i++) { var c = i < key.length ? key[i] : 0; ip[i] = c ^ 0x36; op[i] = c ^ 0x5c; }
    return hash(name, concat([op, hash(name, concat([ip, msg]))]));
  }
  var BK_HKEY = [0x5f, 0xb2, 0xad, 0x01, 0x0c, 0xb9, 0xe1, 0xf6], BK_HVAL = [0xa0, 0x67, 0x7f, 0x02, 0xb2, 0x2c, 0x84, 0x33];
  function agilePackage(a, key, pkg) {
    if (!pkg || pkg.length < 8) return null;
    var size = u32(pkg, 0) + u32(pkg, 4) * 0x100000000, K = aesKey(key);
    if (!K || size > pkg.length) return null;
    /* the package's own check (dataIntegrity): an HMAC over the whole locked package, its key and value locked with the
       package's key. A changed byte anywhere fails it, so a damaged workbook is never read as a statement */
    if (a.hmacKey && a.hmacValue) {
      var hl = HLEN[a.dataHash];
      var hk = aesCbcDecrypt(K, fit(hash(a.dataHash, concat([a.dataSalt, new Uint8Array(BK_HKEY)])), a.dataBlock, 0x36), a.hmacKey).subarray(0, hl);
      var hv = aesCbcDecrypt(K, fit(hash(a.dataHash, concat([a.dataSalt, new Uint8Array(BK_HVAL)])), a.dataBlock, 0x36), a.hmacValue).subarray(0, hl);
      if (!sameBytes(hmac(a.dataHash, hk, pkg), hv, hl)) return null;
    }
    var parts = [], data = pkg.subarray(8);
    for (var seg = 0, o = 0; o < data.length; seg++, o += 4096) {
      var sb = new Uint8Array(4); sb[0] = seg & 255; sb[1] = (seg >>> 8) & 255; sb[2] = (seg >>> 16) & 255; sb[3] = seg >>> 24;
      var iv = fit(hash(a.dataHash, concat([a.dataSalt, sb])), a.dataBlock, 0x36);
      parts.push(aesCbcDecrypt(K, iv, data.subarray(o, Math.min(o + 4096, data.length))));
    }
    var out = concat(parts).subarray(0, size);
    return out.length === size && out[0] === 0x50 && out[1] === 0x4B ? out : null;
  }
  var SPIN_BUDGET = 20000000;
  function openWorkbook(b, pws, file) {
    var cf = cfbStreams(b);
    if (!cf) return { state: 'unreadable', kind: 'xlsx', why: 'Not a workbook kosh can read' };
    var info = cf.stream('EncryptionInfo'), pkg = cf.stream('EncryptedPackage');
    if (!info || !pkg) return { state: 'unreadable', kind: 'xls', why: 'An old .xls workbook, which kosh doesn\'t read' };
    var a = agileInfo(info);
    if (!a || a.odd) return { state: 'unreadable', kind: 'xlsx', why: 'Locked in a way kosh doesn\'t open' };
    if (a.standard) return { state: 'unreadable', kind: 'xlsx', why: 'Locked the Excel 2007 way, which kosh doesn\'t open yet' };
    /* GUARDRAIL without the phone's own hash (KoshNative.spin) each password costs the whole spin here, about 12 s on
       the phone: only the likeliest few are tried then (the sender's saved one and its own rule's come first), never a
       list that would hold the engine for minutes */
    var fast = typeof KoshNative !== 'undefined' && KoshNative && typeof KoshNative.spin === 'function';
    var slowCap = a.spin <= 1000 ? pws.length : 6;
    /* GUARDRAIL and with it, at most SPIN_BUDGET turns in all: Excel spins 100,000 (two hundred passwords' worth), but a
       file may say ten million, and every candidate at that would hold the engine (every screen waits on it) for many
       minutes. The likeliest passwords come first, so the budget only drops the long tail */
    if (fast) slowCap = Math.max(1, Math.floor(SPIN_BUDGET / Math.max(1, a.spin)));
    for (var c = 0; c < pws.length && c < slowCap; c++) {
      var key = agileKey(a, String(pws[c]));
      if (!key) continue;
      var plain = agilePackage(a, key, pkg);
      if (plain) return { state: 'opened', kind: 'xlsx', password: pws[c], files: [{ name: String(file || 'statement.xlsx').replace(/\.xlsm?$|$/i, '.xlsx'), b64: toB64(plain) }] };
      // (the password is proven by a 64-byte verifier: a package that then doesn't check out is a damaged file)
      return { state: 'unreadable', kind: 'xlsx', password: pws[c], why: 'The workbook opened, but what is inside doesn\'t check out (a damaged file)' };
    }
    return { state: 'locked', kind: 'xlsx', how: 'agile', tried: Math.min(pws.length, slowCap) };
  }

  /* ------------------------------------------------------------ what Swift calls */
  function unlock(bytes, file, pws) {
    pws = (pws || []).filter(function (p, i, all) { return typeof p === 'string' && p.length && all.indexOf(p) === i; });
    if (bytes.length >= 4 && bytes[0] === 0x50 && bytes[1] === 0x4B) {
      var z = openZip(bytes, pws);
      // a workbook that is a plain zip: nothing to unlock (DocTable reads it as it is)
      if (z.state === 'plain' && /\.xlsx?$/i.test(file || '')) return { state: 'plain', kind: 'xlsx', password: '', files: [] };
      return z;
    }
    if (isCfb(bytes)) return openWorkbook(bytes, pws, file);
    return { state: 'unreadable', kind: '', why: 'Not a zip or a workbook' };
  }
  function lockOf(bytes) {
    if (bytes.length >= 4 && bytes[0] === 0x50 && bytes[1] === 0x4B) {
      var es = zipEntries(bytes) || [], lk = es.filter(function (e) { return e.flags & 1; });
      return { kind: 'zip', locked: lk.length > 0, how: !lk.length ? '' : lk.some(function (e) { return e.method === 99; }) ? 'aes' : 'zipcrypto' };
    }
    if (isCfb(bytes)) {
      var cf = cfbStreams(bytes), info = cf && cf.stream('EncryptionInfo'), a = info ? agileInfo(info) : null;
      return { kind: info ? 'xlsx' : 'xls', locked: !!info, how: !a ? '' : a.standard ? 'standard' : a.odd ? 'other' : 'agile' };
    }
    return { kind: '', locked: false, how: '' };
  }
  var api = {
    unlockJSON: function (b64, file, candidatesJSON) {
      var pws = []; try { pws = JSON.parse(candidatesJSON || '[]'); } catch (e) { pws = []; }
      try { return JSON.stringify(unlock(fromB64(b64), file, pws)); } catch (e) { return JSON.stringify({ state: 'unreadable', kind: '', why: 'kosh stopped opening it: ' + String(e && e.message || e).slice(0, 80) }); }
    },
    lockOfJSON: function (b64) { try { return JSON.stringify(lockOf(fromB64(b64))); } catch (e) { return JSON.stringify({ kind: '', locked: false, how: '' }); } },
    // the files inside an opened zip to read as statements, in order (LockedFiles.swift DocLocked.openZip)
    zipReadsJSON: function (namesJSON) { var n = []; try { n = JSON.parse(namesJSON || '[]'); } catch (e) { n = []; } return JSON.stringify(zipReads(n)); },
    // for the tests
    unlock: unlock, lockOf: lockOf, zipReads: zipReads, inflateRaw: inflateRaw, crc32: crc32, hash: hash, spin: spin, pbkdf2Sha1: pbkdf2Sha1, aesKey: aesKey, aesBlock: aesBlock,
    aesCbcDecrypt: aesCbcDecrypt, aesCtrWinZip: aesCtrWinZip, fromB64: fromB64, toB64: toB64, utf16le: utf16le,
  };
  if (E) for (var k in api) if (Object.prototype.hasOwnProperty.call(api, k) && /JSON$/.test(k)) E[k] = api[k];
  return api;
})(typeof KoshEngine !== 'undefined' ? KoshEngine : (typeof require === 'function' ? (function () { try { return require('./engine.js'); } catch (e) { return null; } })() : null));
if (typeof module !== 'undefined' && module.exports) module.exports = KoshUnlock;
