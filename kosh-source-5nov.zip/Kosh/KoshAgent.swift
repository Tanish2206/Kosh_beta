import Foundation
import UserNotifications
#if canImport(FoundationModels)
import FoundationModels
#endif

// MARK: - The kosh agent: questions about your money, worked out step by step
//
// The assistant looks things up as many times as a question needs (spending against last month, the bills due
// against the balances, the payments behind a total) with kosh's own tools (agent.js), which run here on the
// ledger. It never adds anything up itself: every figure in its answer has to be one a tool gave (agentCheck), or
// it's asked once to look it up, and otherwise kosh says it in its own words. When you ask it to do something
// (a budget, a category, a reminder, a chapter), it proposes it as a card you confirm.
//
// Who does the thinking:
//   - Claude, in the cloud, when there's a kosh service set up (the Plus plan) or your own Anthropic key. It sees
//     only what the tools hand it: totals, dates, merchant and payee names. Never an email, never a statement.
//   - Apple Intelligence on this phone, with the same tools: nothing leaves the phone.
//   - kosh on its own (agent.js phoneAnswer): it reads the question for what it asks and what it names, works it
//     out from the ledger and says it in plain words, follow-ups included. Always first on the phone; Apple
//     Intelligence takes what it can't place, where the phone has it.

struct AgentStep: Hashable, Identifiable {
    let id = UUID()
    let tool: String
    let label: String
    /// what the lookup found, in kosh's words: the working shown under an answer
    var result: String = ""
}

/// an action the assistant proposes; nothing happens until you tap it
struct AgentProposal: Decodable, Hashable, Identifiable {
    let action: String; let title: String
    var why: String? = nil
    var category: String? = nil; var sub: String? = nil; var merchant: String? = nil; var tx: String? = nil; var count: Int? = nil
    var amount: Double? = nil; var date: String? = nil; var until: String? = nil; var name: String? = nil; var note: String? = nil
    var id: String { action + "|" + title }
}

struct AgentReply {
    var text: String
    var steps: [AgentStep] = []
    var rows: [String] = []
    var proposals: [AgentProposal] = []
    /// every figure in it came from a tool
    var checked = true
    var brain = ""
    /// questions to tap next (the phone's own answers)
    var suggest: [String] = []
    /// what the phone took the question to be, for a follow-up ("and last month?") to carry on from
    var frame: String? = nil
    /// a decision weighed on the household's numbers (decide.js), with its working: drawn as a card under the answer
    var decisions: [Decision] = []
    /// a line about how it was answered ("Claude couldn't be reached, so this phone answered"), shown even when the
    /// answer is a decision's card rather than words
    var notice: String? = nil
}

/// what the tools found while one question was worked out; shared with Apple's tool calls, which run off the main thread
final class AgentTrace: @unchecked Sendable {
    private let lock = NSLock()
    private(set) var texts: [String] = []
    private(set) var rows: [String] = []
    private(set) var proposals: [AgentProposal] = []
    private(set) var steps: [AgentStep] = []
    /// what the decide tool weighed, each with its working
    private(set) var decisions: [Decision] = []
    let ctx: String
    let onStep: @Sendable (AgentStep) -> Void
    init(ctx: String, onStep: @escaping @Sendable (AgentStep) -> Void) { self.ctx = ctx; self.onStep = onStep }

    struct Out: Decodable {
        let text: String; let rows: [String]?
        struct D: Decodable { let proposal: AgentProposal? }
        let data: D?
    }
    /// read on its own, so a decision the phone can't draw never costs the lookup its words
    struct Weighed: Decodable {
        struct D: Decodable { let decision: Decision? }
        let data: D?
    }

    /// one tool, run on the ledger; its words go back to the model
    func run(_ name: String, _ args: [String: Any]) -> String {
        var step = AgentStep(tool: name, label: KoshAgent.label(name, args))
        onStep(step)
        let raw = (try? Engine.shared.call("agentToolJSON", [name, JSONText.object(args), ctx])) ?? ""
        let out = try? JSONText.decode(Out.self, raw)
        let text = out?.text ?? "That lookup failed."
        let weighed: Decision? = name == "decide" ? (try? JSONText.decode(Weighed.self, raw))?.data?.decision : nil
        step.result = text
        lock.lock()
        steps.append(step)
        texts.append(text)
        rows += out?.rows ?? []
        if let p = out?.data?.proposal { proposals.append(p) }
        if let w = weighed { decisions.append(w) }
        lock.unlock()
        return text
    }
}

@MainActor
enum KoshAgent {
    /// "auto" (Claude when it's set up, else this phone), "cloud", or "phone"
    static var mode: String {
        get { UserDefaults.standard.string(forKey: "agent.mode") ?? "auto" }
        set { UserDefaults.standard.set(newValue, forKey: "agent.mode") }
    }
    static var cloudReady: Bool { AgentCloud.config() != nil }
    static var useCloud: Bool { cloudReady && mode != "phone" }
    /// the phone can always answer the questions its words place (agent.js route); Apple Intelligence takes the rest
    static var phoneReady: Bool { true }
    static var brainName: String { useCloud ? "Smart answers" : AppleBrain.available ? "Apple Intelligence" : "kosh, on this phone" }

    /// what a step looked up, in a few words, for the line under the question
    nonisolated static func label(_ name: String, _ a: [String: Any]) -> String {
        let s = { (k: String) -> String in (a[k] as? String) ?? "" }
        switch name {
        case "spending": return "Spending" + (s("category").isEmpty ? "" : " on " + s("category")) + (s("merchant").isEmpty ? "" : " at " + s("merchant"))
        case "breakdown": return "By " + (s("by").isEmpty ? "category" : s("by"))
        case "compare": return "Compared" + (s("category").isEmpty ? "" : " " + s("category"))
        case "trend": return "Month by month" + (s("category").isEmpty ? "" : ", " + s("category"))
        case "cover": return "Balances against what’s due"
        case "whatif": return "Worked out " + (s("kind") == "prepay" ? "prepaying" : s("kind") == "save_for" ? "saving for it" : s("kind").uppercased())
        case "decide":
            switch s("kind") {
            case "prepay": return "Prepaying against investing"
            case "car": return "Cash against a loan"
            case "afford": return "What you can afford"
            case "fd": return "Breaking the FD"
            case "emergency": return "The emergency fund"
            case "card": return "The card’s interest"
            default: return "Weighed it"
            }
        case "transactions": return "Payments" + (s("merchant").isEmpty ? "" : " at " + s("merchant"))
        case "income": return "Money in"
        case "upcoming": return "What’s due"
        case "repeats": return "Repeats"
        case "balances": return "Balances"
        case "wealth": return "Holdings"
        case "insurance": return "Policies"
        case "property": return "Property"
        case "owed": return "Who owes what"
        case "noticed": return "What kosh noticed"
        case "papers": return "Payslips and tax papers"
        case "calc": return "Worked it out"
        case "propose": return "A suggestion"
        default: return name.capitalized
        }
    }

    // MARK: what the tools see: the ledger as it stands

    static func context(_ store: Store) -> String {
        let s = store.snap
        var d: [String: Any] = ["today": s.today]
        // each person with how they're related ("my wife", "Mom"), as the Household screen has it
        d["people"] = s.people.map { ["id": $0.id, "name": $0.name, "full": $0.full, "rel": $0.rel] }
        d["tx"] = store.tx.map { t -> [String: Any] in
            var x: [String: Any] = ["id": t.id, "d": t.d, "t": t.t, "m": t.m, "a": t.a, "c": t.c, "s": t.s, "k": t.k, "sp": t.sp, "card": t.card, "o": t.o, "f": t.f, "n": t.n]
            // a payment that still needs a name ("Show the payments that need a name")
            if t.u { x["u"] = true }
            if let r = t.refunded, r > 0 { x["refunded"] = r }
            if let md = t.md { x["md"] = md }
            if let pf = t.pf { x["pf"] = pf }
            // money that came in on an Investments row (a broker's payout): never counted as money put in
            if t.dr == "in" { x["dr"] = "in" }
            if let tr = t.tr { x["tr"] = tr }
            // money back on a payment (not money in), and a refund kosh couldn't set against one (the spending it comes off)
            if let e = t.ex { x["ex"] = e }
            if let r = t.refOf { x["refOf"] = r }
            if let k = t.nt, let v = t.nta { x["nt"] = k; x["nta"] = v }
            // a charge in another currency on an Indian card ("USD 64.00"): what it was, beside its rupees
            if let v = t.fx { x["fx"] = v }
            // the beat its shop is paid on (PayFacts: "how often do I go to …" reads the build's rhythm, never its own)
            if let rh = s.payFacts?.pay[t.id]?.rh { x["rh"] = rh }
            return x
        }
        // how often each shop is paid and each item bought: its beat, its next day, its usual sum (engine/21o)
        d["rhythms"] = (s.payFacts?.rhythms ?? []).map { r -> [String: Any] in
            var x: [String: Any] = ["id": r.id, "of": r.of, "name": r.name, "every": r.every, "days": r.days, "n": r.n, "last": r.last, "by": r.by, "conf": r.conf]
            if let v = r.next { x["next"] = v }
            if let v = r.usual { x["usual"] = v }
            if r.quiet == true { x["quiet"] = true }
            return x
        }
        // what a travel claim is made from (packs.js), and your company's rules for it
        d["docs"] = (s.docs ?? []).map { $0.json }
        d["claimPolicy"] = ClaimBook.shared.policy.json
        d["accounts"] = s.accounts.map { a -> [String: Any] in
            var x: [String: Any] = ["name": a.name, "bank": a.bank, "last": a.last, "asOf": a.asOf, "owner": a.owner]
            if let b = a.balance { x["balance"] = b }
            // an account with a bank abroad: its currency, and what it last held in it
            if let cy = a.ccy { x["ccy"] = cy; if let v = a.fbal { x["fbal"] = v } }
            // a family business's account (its current account)
            if a.biz == true { x["biz"] = true }
            // what it is and what you named it ("NRE", "Salary a/c"): Ask kosh answers for one kind of account by these
            if !a.kind.isEmpty { x["kind"] = a.kind }
            if let n = a.nick, !n.isEmpty { x["nick"] = n }
            if let t = a.tag, !t.isEmpty { x["tag"] = t }
            return x
        }
        d["cards"] = s.cards.map { c -> [String: Any] in
            var x: [String: Any] = ["name": c.name, "bank": c.bank, "last": c.last, "month": c.month, "last30": c.last30, "lastUsed": c.lastUsed, "owner": c.owner]
            if let v = c.due { x["due"] = v }
            if let v = c.minDue { x["minDue"] = v }
            if let v = c.dueDate { x["dueDate"] = v }
            if let v = c.stmtOn { x["stmtOn"] = v }
            if let v = c.paid { x["paid"] = v }
            if let v = c.paidOn { x["paidOn"] = v }
            if let cy = c.ccy { x["ccy"] = cy }
            if let v = c.product { x["product"] = v }
            return x
        }
        d["wallets"] = s.wallets.map { w -> [String: Any] in var x: [String: Any] = ["name": w.name]; if let b = w.balance { x["balance"] = b }; return x }
        d["agenda"] = s.agenda.compactMap { a -> [String: Any]? in
            guard let day = a.date else { return nil }
            var x: [String: Any] = ["date": day, "name": a.name, "amt": a.amt, "sub": a.sub, "kind": a.kind, "booked": a.booked, "cat": a.cat]
            // a free trial's reminder: the charge it turns into
            if a.trial == true { x["trial"] = true }
            return x
        }
        d["recurring"] = s.recurring.map { r -> [String: Any] in
            var x: [String: Any] = ["name": r.name, "amount": r.amount, "date": r.date, "kind": r.kind, "cat": r.cat, "per": r.per ?? 1, "seen": r.seen ?? 0, "last": r.last ?? ""]
            if let l = r.lapsed { x["lapsed"] = l }
            if let g = r.gone { x["gone"] = g }
            // it costs more than its first charge: by how much, from what
            if let up = r.rise, let was = r.riseFrom { x["rise"] = up; x["riseFrom"] = was }
            return x
        }
        d["policies"] = s.policies.map { ["insurer": $0.insurer, "type": $0.type, "kind": $0.kind ?? "", "cover": $0.cover ?? 0, "premium": $0.premium, "frequency": $0.frequency ?? "", "nextDue": $0.nextDue, "nominee": $0.nominee ?? "",
                                          "status": $0.status ?? "", "statusWhy": $0.statusWhy ?? "", "fundValue": $0.fundValue ?? 0, "ended": $0.isEnded, "insured": $0.insured ?? "",
                                          // whom it covers (household ids), as the policy schedule names them: "who is covered"
                                          "covers": $0.covers ?? []] as [String: Any] }
        // what plan.js worked out: the goals, and the subscriptions (two doing one job, trials about to charge)
        if let plan = s.plan {
            d["goals"] = plan.goals.map { g -> [String: Any] in
                ["name": g.name, "kind": g.kind, "target": g.target, "by": g.by, "who": g.who, "saved": g.saved, "pct": g.pct, "left": g.left,
                 "perMonth": g.perMonth, "months": g.months, "state": g.state, "pace": g.pace, "paceOf": g.paceOf, "eta": g.eta]
            }
            let subs: [[String: Any]] = plan.subs.subs.map { ["name": $0.name, "payee": $0.payee, "amount": $0.amount, "every": $0.every, "monthly": $0.monthly, "yearly": $0.yearly, "next": $0.next] }
            let overlaps: [[String: Any]] = plan.subs.overlaps.map { ["name": $0.name, "names": $0.names, "yearly": $0.yearly] }
            let trials: [[String: Any]] = plan.subs.trials.map { ["name": $0.name, "amt": $0.amt, "every": $0.every, "date": $0.date] }
            d["subs"] = ["subs": subs, "overlaps": overlaps, "trials": trials] as [String: Any]
        }
        // the committees (chit funds, BCs): what's paid in, what's to come, the month to take the pool
        d["committees"] = s.comm.map { c -> [String: Any] in
            var x: [String: Any] = ["name": c.name, "kind": c.kind ?? "", "members": c.members, "face": c.face, "net": c.net, "paid": c.paid, "contributed": c.contributed,
                                    "outstanding": c.outstanding, "left": c.left, "done": c.done, "now": c.now, "taken": c.taken ?? false, "payee": c.payeeName ?? ""]
            if let month = c.draw { x["draw"] = month }
            if let n = (c.rows ?? []).first(where: { $0.st == "due" || $0.st == "ahead" }) { x["next"] = ["m": n.m, "amt": n.amt] as [String: Any] }
            return x
        }
        d["hold"] = store.holdings(.family).map { h -> [String: Any] in
            var x: [String: Any] = ["bank": h.bank, "type": h.type, "cls": h.cls, "amt": h.amt, "rate": h.rate, "person": h.person]
            if let m = h.mat { x["mat"] = m }
            // mat can be the month alone (yyyy-MM); the day, when the advice gave one
            if let d = h.matDay, !d.isEmpty { x["matDay"] = d }
            // what was put in (a deposit's principal, beside what it's worth today)
            if let c = h.cost, c > 0 { x["cost"] = c }
            return x
        }
        // net worth as Home counts it (Store.netWorth): beside the balances, holdings and loans above, the cash at
        // home and the land under the properties
        let cash: Double = store.cashInHand
        if cash > 0 { d["cashInHand"] = cash }
        let land: Double = store.propertyWorth(.family)
        if land > 0 { d["land"] = land }
        d["owed"] = store.owed.map { ["name": $0.name, "title": $0.title, "amount": $0.amount, "dir": $0.dir, "settled": $0.settled, "date": $0.date] as [String: Any] }
        d["props"] = s.prop.props.map { p -> [String: Any] in
            ["name": p.name, "taxDue": p.tax.total > 0 ? p.tax.total : p.demand + p.older,
             "units": p.units.map { u -> [String: Any] in
                 ["tenant": u.tenant, "label": u.label, "rent": u.rent, "state": u.now?.st ?? "",
                  "late": u.roll.filter { $0.st == "late" }.map { ["m": $0.m, "amt": $0.amt, "days": $0.late ?? 0] as [String: Any] }]
             }]
        }
        d["watch"] = (s.watch ?? []).map { ["title": $0.title, "detail": $0.detail, "sev": $0.sev, "rows": $0.rows] as [String: Any] }
        var facts: [[String: Any]] = []
        if let live = store.live {
            for f in live.docFacts {
                var x: [String: Any] = ["k": f.k]
                for (k, v) in [("month", f.month), ("fy", f.fy), ("employer", f.employer), ("payer", f.payer)] { if let v { x[k] = v } }
                for (k, v) in [("gross", f.gross), ("deductions", f.deductions), ("net", f.net), ("pf", f.pf), ("tds", f.tds), ("amount", f.amount), ("stcg", f.stcg), ("ltcg", f.ltcg)] { if let v { x[k] = v } }
                facts.append(x)
            }
            for (fy, g) in live.gainsFY { facts.append(["k": "gains", "fy": fy, "stcg": g.stcg, "ltcg": g.ltcg]) }
        }
        // the TDS the mail itself tells (a client's payment advice, the Form 26AS mail: engine.js taxFacts)
        for f in s.taxFacts ?? [] {
            var x: [String: Any] = ["k": f.k]
            for (k, v) in [("fy", f.fy), ("payer", f.payer), ("src", f.src), ("owner", f.owner)] { if let v { x[k] = v } }
            for (k, v) in [("tds", f.tds), ("amount", f.amount)] { if let v { x[k] = v } }
            facts.append(x)
        }
        d["facts"] = facts
        d["fc"] = ["usual": s.fc.usual, "likely": s.fc.likely, "budget": s.fc.budget, "spent": s.fc.spent, "left": s.fc.left, "d": s.fc.d]
        d["cashflow"] = (s.cashflow ?? []).map { c -> [String: Any] in
            var x: [String: Any] = ["m": c.m, "inn": c.inn, "out": c.out, "inv": c.inv, "kept": c.kept, "live": c.live]
            if let ev = c.ev { x["ev"] = ev }
            if c.noPay == true { x["noPay"] = true }
            return x
        }
        // the loans running (Portfolio › Debts), for weighing a prepayment, an EMI or the cushion (decide)
        d["loans"] = DecideEngine.loansJSON(store)
        // the Refunds list (Home › Genie › Refunds), then the shop's word on refunds kosh can see no payment for:
        // "any refunds pending?" answers from these rows, never from the ledger's credits (engine-test/screens.js)
        d["refunds"] = (s.refunds ?? []).map { refundJSON($0, list: "refunds") } + (s.refundPromises ?? []).map { refundJSON($0, list: "promise") }
        return JSONText.object(d)
    }

    /// one refund row as Ask kosh reads it: what was paid, what is owed back, what came, by when, how far it got
    static func refundJSON(_ r: RefundInfo, list: String) -> [String: Any] {
        var x: [String: Any] = ["list": list, "m": r.m, "d": r.d, "a": r.a, "exp": r.exp, "back": r.back, "by": r.by, "state": r.state, "o": r.o]
        if let v = r.order, !v.isEmpty { x["order"] = v }
        if let v = r.stage { x["stage"] = v }
        return x
    }

    // MARK: one question, start to finish

    static func ask(_ q: String, history: [(q: String, a: String)], prev: String? = nil, store: Store, onStep: @escaping @Sendable (AgentStep) -> Void) async -> AgentReply {
        let ctx = context(store)
        if useCloud, let cfg = AgentCloud.config() {
            do { return try await cloud(q, history: history, store: store, ctx: ctx, cfg: cfg, onStep: onStep) }
            catch {
                // the cloud is out of reach: this phone answers instead, and says why
                if phoneReady {
                    var r = await onPhone(q, history: history, prev: prev, store: store, ctx: ctx, onStep: onStep)
                    let why: String = "Smart answers couldn’t be reached (" + error.localizedDescription + "), so this phone answered."
                    r.text += "\n\n_" + why + "_"
                    r.notice = why
                    return r
                }
                return AgentReply(text: "Smart answers couldn’t be reached: " + error.localizedDescription, checked: false, brain: "Smart answers")
            }
        }
        return await onPhone(q, history: history, prev: prev, store: store, ctx: ctx, onStep: onStep)
    }

    /// Claude, as many lookups as the question needs (at most ten), then the answer; checked against the tools
    static func cloud(_ q: String, history: [(q: String, a: String)], store: Store, ctx: String, cfg: AgentCloud.Config, mode: String = "", onStep: @escaping @Sendable (AgentStep) -> Void) async throws -> AgentReply {
        let trace = AgentTrace(ctx: ctx, onStep: onStep)
        var tools = ((try? JSONSerialization.jsonObject(with: Data(((try? Engine.shared.call("agentToolsJSON", [])) ?? "[]").utf8))) as? [[String: Any]]) ?? []
        // the tools and the instructions are the same every time: Anthropic keeps them warm between questions
        if !tools.isEmpty { tools[tools.count - 1]["cache_control"] = ["type": "ephemeral"] }
        let system = (try? Engine.shared.call("agentSystemText", [store.snap.today, store.live?.firstName ?? "", mode])) ?? ""
        var messages: [[String: Any]] = []
        for h in history.suffix(4) {
            messages.append(["role": "user", "content": h.q])
            messages.append(["role": "assistant", "content": h.a])
        }
        messages.append(["role": "user", "content": q])
        var answer = "", checked = true, retried = false
        for _ in 0..<10 {
            let body: [String: Any] = ["model": cfg.model, "max_tokens": 1500,
                                       "system": [["type": "text", "text": system, "cache_control": ["type": "ephemeral"]]],
                                       "tools": tools, "messages": messages]
            let resp = try await AgentCloud.send(body, cfg)
            let content = resp["content"] as? [[String: Any]] ?? []
            messages.append(["role": "assistant", "content": content])
            let uses = content.filter { ($0["type"] as? String) == "tool_use" }
            if uses.isEmpty {
                answer = content.compactMap { ($0["type"] as? String) == "text" ? $0["text"] as? String : nil }.joined(separator: "\n").trimmingCharacters(in: .whitespacesAndNewlines)
                let bad = Self.unchecked(answer, trace.texts, q)
                if !bad.isEmpty && !retried {
                    retried = true
                    messages.append(["role": "user", "content": "These figures in your answer didn’t come from a tool: " + bad.joined(separator: ", ") + ". Look them up, or use calc for any arithmetic, then answer again."])
                    continue
                }
                checked = bad.isEmpty
                break
            }
            var results: [[String: Any]] = []
            for u in uses {
                let name = u["name"] as? String ?? ""
                let input = u["input"] as? [String: Any] ?? [:]
                let text = trace.run(name, input)
                results.append(["type": "tool_result", "tool_use_id": u["id"] as? String ?? "", "content": text])
            }
            messages.append(["role": "user", "content": results])
        }
        if answer.isEmpty {
            answer = trace.texts.last ?? "I couldn’t work that out. Try asking it another way."
            checked = false
        }
        return AgentReply(text: answer, steps: trace.steps, rows: Array(Set(trace.rows)), proposals: trace.proposals, checked: checked, brain: "Smart answers",
                          decisions: lastOfEach(trace.decisions))
    }

    /// one card a kind of decision: the last time it was weighed (Claude may try a few amounts on the way)
    static func lastOfEach(_ ds: [Decision]) -> [Decision] {
        var out: [Decision] = []
        for d in ds.reversed() where !out.contains(where: { $0.kind == d.kind }) { out.insert(d, at: 0) }
        return out
    }

    /// the figures in an answer that no tool gave
    static func unchecked(_ answer: String, _ texts: [String], _ q: String) -> [String] {
        struct C: Decodable { let ok: Bool; let bad: [String] }
        guard let out = try? Engine.shared.call("agentCheckJSON", [answer, JSONText.encode(texts), q]), let c = try? JSONText.decode(C.self, out) else { return [] }
        return c.ok ? [] : c.bad
    }

    /// On this phone: kosh reads the question itself (what it asks, what it names, and what it carries on from) and
    /// answers in plain words from the ledger, with the working shown and questions to tap next. Apple Intelligence
    /// takes a question kosh can't place, where the phone has it; otherwise kosh says so in a line and offers the
    /// questions nearest the one asked.
    static func onPhone(_ q: String, history: [(q: String, a: String)], prev: String?, store: Store, ctx: String, onStep: @escaping @Sendable (AgentStep) -> Void) async -> AgentReply {
        struct Step: Decodable { let tool: String; let label: String; let result: String? }
        struct Out: Decodable { let understood: Bool; let text: String; let rows: [String]?; let steps: [Step]?; let suggest: [String]?; let proposals: [AgentProposal]? }
        /// read on its own, so a decision the phone can't draw never costs the answer
        struct Weighed: Decodable { let decision: Decision? }
        let opts = JSONText.object(["cloud": cloudReady])
        let raw = (try? Engine.shared.call("agentPhoneJSON", [q, ctx, prev ?? "", opts])) ?? ""
        let out = try? JSONText.decode(Out.self, raw)
        let weighed: Decision? = (try? JSONText.decode(Weighed.self, raw))?.decision
        // the frame as JSON text, untouched, for the next question to carry on from
        let frame: String? = ((try? JSONSerialization.jsonObject(with: Data(raw.utf8))) as? [String: Any]).flatMap { o in
            (o["frame"] as? [String: Any]).map { JSONText.object($0) }
        }
        if let out, out.understood, !out.text.isEmpty {
            let steps = (out.steps ?? []).map { AgentStep(tool: $0.tool, label: $0.label, result: $0.result ?? "") }
            for s in steps { onStep(s) }
            return AgentReply(text: out.text, steps: steps, rows: Array(Set(out.rows ?? [])), proposals: out.proposals ?? [], checked: true, brain: "kosh", suggest: out.suggest ?? [], frame: frame,
                              decisions: weighed.map { [$0] } ?? [])
        }
        #if canImport(FoundationModels)
        if AppleBrain.available {
            let trace = AgentTrace(ctx: ctx, onStep: onStep)
            let instructions = """
            You are kosh, the household money app on this iPhone, answering questions about the household's own money in \
            India. Today is \(store.snap.today). Look every figure up with the tools, more than once if the question needs it; \
            never make up a number, a payee or a date, and use calc for any arithmetic. Write rupees like ₹12,400 or ₹1.2L. \
            Answer in two or three short sentences, plainly, then stop. If the tools don't have it, say so.
            """
            let session = LanguageModelSession(tools: [SpendTool(t: trace), SplitTool(t: trace), PaymentsTool(t: trace), DueTool(t: trace),
                                                       BalanceTool(t: trace), NoticedTool(t: trace), CalcTool(t: trace)], instructions: instructions)
            var prompt = q
            if let last = history.last { prompt = "Earlier you were asked: " + last.q + "\nYou answered: " + last.a + "\n\nNow: " + q }
            do {
                let answer = try await session.respond(to: prompt).content
                let bad = unchecked(answer, trace.texts, q)
                if bad.isEmpty { return AgentReply(text: answer, steps: trace.steps, rows: Array(Set(trace.rows)), proposals: trace.proposals, checked: true, brain: "Apple Intelligence") }
                // its wording named a figure no tool gave: kosh says what it found in its own words
                if let found = trace.texts.last {
                    return AgentReply(text: found, steps: trace.steps, rows: Array(Set(trace.rows)), proposals: trace.proposals, checked: false, brain: "Apple Intelligence")
                }
            } catch {
                // the model couldn't: kosh's own reply below
            }
        }
        #endif
        return AgentReply(text: out?.text.isEmpty == false ? out!.text : "I couldn’t work that out. Try asking it another way.",
                          checked: true, brain: "kosh", suggest: out?.suggest ?? [], frame: frame)
    }

    // MARK: speaking first

    /// Today's brief in kosh's own words: Claude ranks what matters most today from what kosh noticed, what's due
    /// and the month so far, in three short lines. Once a day; nil without Claude.
    static func brief(_ store: Store) async -> String? {
        let ud = UserDefaults.standard
        let day = store.snap.today
        if let t = savedBrief(day) { return t }
        // one try every ten minutes at most: building what Claude is told takes a moment on the phone
        if let at = briefTriedAt, Date().timeIntervalSince(at) < 600 { return nil }
        briefTriedAt = Date()
        guard useCloud, let cfg = AgentCloud.config() else { return nil }
        guard let r = try? await cloud("Brief me for today: what needs my attention, most important first.", history: [], store: store, ctx: context(store), cfg: cfg, mode: "brief", onStep: { _ in }),
              r.checked, !r.text.isEmpty else { return nil }
        // the brief names figures: with kosh beta it's saved in the protected profile, not in plain defaults
        let saved: [String: String] = ["d": day, "t": r.text]
        if let live = store.live {
            // the profile is saved from the main thread, like every other change
            await MainActor.run { live.own.agentBrief = saved; live.save() }
        } else {
            ud.set(saved, forKey: "agent.brief")
        }
        return r.text
    }

    // MARK: filing what the rules couldn't

    /// Payees kosh couldn't place (the "needs a name" queue), filed by Claude a batch of 50 at a time until none are
    /// left (up to 600 a run). Each payee goes once, as kosh learns it (its UPI ID, else its name), with what kosh knows
    /// of it: how it was paid, whether its UPI ID looks like a shop's QR or a person's (never the UPI ID itself), how
    /// many payments, what one usually comes to, the time of day, and whether it comes every month. Your own filings go
    /// with it as examples, so Claude files the way you do. Sure: filed as Claude's. Likely: filed as Claude's guess,
    /// which the row shows for you to confirm. A person, or a shop it can't tell: left for you, and not asked again for
    /// two weeks. Payees whose name is yours or your family's never leave the phone. Returns how many payees it filed
    /// (their ids in lastFiled), or -1 when a pass is already under way.
    @discardableResult
    static func nameUnknown(_ store: Store, now: Bool = false) async -> Int {
        let ud = UserDefaults.standard
        guard now || (ud.object(forKey: "agent.nameUnknown") as? Bool ?? true), useCloud, let cfg = AgentCloud.config(), let live = store.live else { return 0 }
        guard !filing else { return -1 }
        lastFiled = []
        if !now && Date().timeIntervalSince1970 - ud.double(forKey: "agent.namedAt") < 600 { return 0 }
        filing = true
        defer { filing = false }
        ud.set(Date().timeIntervalSince1970, forKey: "agent.namedAt")
        // asked before and left: not again for two weeks
        var asked: [String: Double] = LiveSession.times(.askedPayees)
        let fresh = Date().timeIntervalSince1970 - 14 * 86400
        asked = asked.filter { $0.value > fresh }
        let mine = live.claudeNames.map { $0.lowercased() }.flatMap { $0.split(separator: " ").map(String.init) }.filter { $0.count >= 4 }
        let groups = store.untaggedPayees.filter { g in
            guard asked[g.id] == nil, g.rows.contains(where: { $0.k == "out" }) else { return false }
            let n = g.name.lowercased()
            return !mine.contains { n.contains($0) }
        }
        guard !groups.isEmpty else { return 0 }
        let cats: String = store.snap.cats.filter { $0.value.kind == "spend" || $0.value.kind == "prepaid" }
            .sorted { $0.key < $1.key }.map { $0.key + ": " + $0.value.subs.joined(separator: ", ") }.joined(separator: "\n")
        let examples: String = (store.snap.learned ?? []).filter { p in p.by.isEmpty && !p.c.isEmpty && !mine.contains(where: { w in p.name.lowercased().contains(w) }) }
            .sorted { $0.count > $1.count }.prefix(40)
            .map { (p: LearnedPayee) -> String in
                let sub: String = p.s.isEmpty ? "" : " / " + p.s
                return "- " + p.name + " → " + p.c + sub
            }.joined(separator: "\n")
        let tool: [String: Any] = [
            "name": "file_payees",
            "description": "File each payee under one of kosh's categories, saying how sure you are.",
            "input_schema": ["type": "object", "properties": ["items": ["type": "array", "items": ["type": "object", "properties": [
                "i": ["type": "integer", "description": "The payee's number"],
                "category": ["type": "string"], "sub": ["type": "string"],
                "confidence": ["type": "string", "enum": ["sure", "likely", "unsure"], "description": "sure: a known shop, brand, app or service, or a name that says what it is; likely: the name, the kind of UPI ID, the amounts and timing point one way; unsure: a person or a shop you can't tell"],
                "kind": ["type": "string", "enum": ["shop", "service", "app", "person", "unknown"]]],
                "required": ["i", "category", "confidence"]]]], "required": ["items"]],
        ]
        var filed = 0
        // (the kosh service answers in shorter pieces: half the batch)
        let per = cfg.via == "kosh" ? 25 : 50
        for start in stride(from: 0, to: min(groups.count, 600), by: per) {
            if Task.isCancelled { break }
            let batch = Array(groups[start..<min(start + per, groups.count)])
            let lines: String = batch.enumerated().map { (i: Int, g: PayeeGroup) -> String in "\(i + 1). " + describe(g) }.joined(separator: "\n")
            let habits: String = examples.isEmpty ? "" : "\n\nHow this household files payees itself (follow its habits):\n" + examples
            var prompt: String = "An Indian household's bank and card alerts paid these payees, and kosh couldn't tell what for. File each one under a category and sub-category from this list only, and say how sure you are.\n\n"
            prompt += cats
            prompt += habits
            prompt += "\n\nPayees:\n" + lines
            prompt += "\n\nSure only for a known shop, brand, app or service, or a name that says what it is (\"SHREE BALAJI MEDICAL\" is a pharmacy). Likely when the name, the kind of UPI ID, the amounts and the timing point one way (a person paid the same sum every month is likely domestic help or rent). A person's name with nothing else to go on, or a shop you can't tell: unsure."
            let body: [String: Any] = ["model": cfg.model, "max_tokens": 4000, "tools": [tool], "tool_choice": ["type": "tool", "name": "file_payees"],
                                       "messages": [["role": "user", "content": prompt]]]
            guard let resp = try? await AgentCloud.send(body, cfg),
                  let use = (resp["content"] as? [[String: Any]])?.first(where: { ($0["type"] as? String) == "tool_use" }),
                  let input = use["input"] as? [String: Any], let items = input["items"] as? [[String: Any]] else { break }
            var done = Set<Int>()
            // one save per batch: the filings grouped by what they set
            var sets: [String: (c: String, s: String?, by: String, ids: [String])] = [:]
            for f in items {
                guard let i = f["i"] as? Int, i >= 1, i <= batch.count, let c = f["category"] as? String, cats.contains(c + ":") else { continue }
                let how = f["confidence"] as? String ?? "unsure"
                guard how == "sure" || how == "likely" else { continue }
                let sub = (f["sub"] as? String) ?? ""
                let valid = store.snap.cats[c]?.subs.contains(sub) == true ? sub : ""
                let g = batch[i - 1]
                // one payment taught is the payee taught (the engine's learned payees)
                let by = how == "sure" ? "claude" : "claude-guess"
                if let id = g.rows.first?.id {
                    let key = c + "|" + valid + "|" + by
                    var e = sets[key] ?? (c: c, s: valid.isEmpty ? nil : valid, by: by, ids: [])
                    e.ids.append(id)
                    sets[key] = e
                }
                done.insert(i)
                lastFiled.insert(g.id)
                filed += 1
            }
            for e in sets.values { live.overrideMany(e.ids) { o in o.c = e.c; o.s = e.s; o.by = e.by } }
            let stamp = Date().timeIntervalSince1970
            for (i, g) in batch.enumerated() where !done.contains(i + 1) { asked[g.id] = stamp }
            LiveSession.setTimes(.askedPayees, asked)
            if filed > 0 { live.rebuildSoon() }
        }
        return filed
    }
    /// a Claude filing pass under way (one at a time), and the payees the last one filed
    static var filing = false
    static var briefTriedAt: Date?
    /// today's brief, if one was made today
    static func savedBrief(_ day: String) -> String? {
        let fromDefaults: [String: String]? = UserDefaults.standard.dictionary(forKey: "agent.brief") as? [String: String]
        let saved: [String: String]? = LiveSession.current.map { $0.own.agentBrief } ?? fromDefaults
        guard let saved, saved["d"] == day, let t = saved["t"], !t.isEmpty else { return nil }
        return t
    }
    static var lastFiled: Set<String> = []

    /// one payee for Claude, in a line: its name, how it was paid, what its UPI ID looks like, how many payments, what
    /// one usually comes to, the time of day, and whether it comes every month
    static func describe(_ g: PayeeGroup) -> String {
        let rows = g.rows
        let amts = rows.map(\.a).sorted()
        let usual = amts[amts.count / 2]
        var bits: [String] = [g.name]
        let how = Set(rows.compactMap { $0.md }).sorted().joined(separator: "/")
        if !how.isEmpty { bits.append(how) }
        if let v = g.vpa, !v.isEmpty { bits.append(vpaKind(v)) }
        let lo: Int = Int(safe: amts.first ?? 0), hi: Int = Int(safe: amts.last ?? 0)
        let range: String = lo != hi ? " (₹\(lo)–₹\(hi))" : ""
        let many: String = "\(rows.count) payments, usually ₹\(Int(safe: usual))" + range
        bits.append(rows.count == 1 ? "1 payment ₹\(Int(safe: usual))" : many)
        let hours = rows.compactMap { Int($0.t.prefix(2)) }
        if !hours.isEmpty {
            let h = hours.sorted()[hours.count / 2]
            bits.append(h < 11 ? "mornings" : h < 16 ? "afternoons" : h < 21 ? "evenings" : "late nights")
        }
        let months = Set(rows.map { String($0.d.prefix(7)) })
        let days = rows.compactMap { Int($0.d.suffix(2)) }
        if months.count >= 3, rows.count <= months.count + 1, let lo = days.min(), let hi = days.max(), hi - lo <= 6 { bits.append("every month around day \(days.sorted()[days.count / 2])") }
        return bits.joined(separator: " · ")
    }

    /// what a UPI ID says about who it is, without the ID: a shop's QR, an app's or a business's, or a person's
    static func vpaKind(_ v: String) -> String {
        let l = v.lowercased()
        let handle = l.split(separator: "@").first.map(String.init) ?? l
        if l.range(of: #"^(paytmqr|q\d{6,}|bharatpe|gpay-\d|mab\.|msw|pinelabs|razorpay|rzp|payu|cf\.|cashfree|ezetap|yespay|bqr|upiqr|sbiqr|hdfcqr)"#, options: .regularExpression) != nil
            || l.range(of: #"@(okbizaxis|okbizicici|okbizhdfc|hdfcbank\.merchant|axisb|yesbankltd|pinelabs|razorpay)$"#, options: .regularExpression) != nil { return "a shop's QR" }
        if handle.range(of: #"^\d{10}"#, options: .regularExpression) != nil { return "a person's UPI ID (a phone number)" }
        if handle.range(of: #"(store|mart|medical|pharma|traders|enterprises|services|foods|kirana|dairy|bakery|hotel|restaurant|cafe|fuel|petro|motors)"#, options: .regularExpression) != nil { return "a business's UPI ID" }
        return "a personal-style UPI ID"
    }

    // MARK: doing what you confirmed

    /// what a proposal does once you tap it; a line saying so
    static func perform(_ p: AgentProposal, store: Store) async -> String {
        guard let live = store.live else { return "Only in the beta." }
        switch p.action {
        case "budget":
            let amt = p.amount ?? 0
            if let c = p.category, !c.isEmpty { live.budgets[c] = amt } else { live.budget = amt }
            return "Budget set: " + Fmt.rupees(amt) + ((p.category ?? "").isEmpty ? " a month." : " a month for " + (p.category ?? "") + ".")
        case "recategorize":
            guard let id = p.tx, let c = p.category else { return "Nothing to change." }
            // one payment taught is every payment to that payee, before and after (the engine's learned payees)
            live.override(id) { o in o.c = c; o.s = (p.sub ?? "").isEmpty ? nil : p.sub }
            return (p.merchant ?? "That merchant") + " is filed under " + c + " from now on."
        case "remind":
            guard let date = p.date, let day = Day.parser.date(from: date) else { return "No date to remind you on." }
            guard await Reminders.enable() else { return "Notifications are off for kosh. Turn them on in Settings to get reminders." }
            var comps = Day.cal.dateComponents([.year, .month, .day], from: day)
            comps.hour = 9
            // with kosh locked or the amounts hidden, the reminder keeps its words to itself (Reminders.quiet)
            let quiet: Bool = Reminders.quiet(store)
            let content: UNMutableNotificationContent = quiet ? Reminders.quietReminder() : UNMutableNotificationContent()
            if !quiet {
                content.title = p.note.flatMap { $0.isEmpty ? nil : $0 } ?? "kosh reminder"
                content.body = (p.amount ?? 0) > 0 ? Fmt.rupees(p.amount ?? 0) + (p.why.map { " · " + $0 } ?? "") : (p.why ?? "")
                content.sound = .default
                content.threadIdentifier = "kosh.agent"
            }
            try? await UNUserNotificationCenter.current().add(UNNotificationRequest(identifier: "agent|" + p.id, content: content, trigger: UNCalendarNotificationTrigger(dateMatching: comps, repeats: false)))
            return "I’ll remind you on " + Day.short(date) + "."
        case "pack":
            guard let from = p.date, let to = p.until else { return "A claim needs its days." }
            // Ask closes, and the claim opens in its place
            store.sheet = nil
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) { store.betaSheet = .pack(from + "|" + to) }
            return "Opening the claim."
        case "chapter":
            guard let from = p.date else { return "A chapter needs a first day." }
            let name = (p.name ?? "").isEmpty ? "Trip" : (p.name ?? "Trip")
            live.upsertTrip(UserTrip(id: UUID().uuidString, name: name, kind: "trip", from: from, to: p.until ?? ""))
            return "Chapter started: " + name + "."
        default:
            return "That isn’t something kosh can do yet."
        }
    }
}

// MARK: - Claude, through kosh's own service or your key

enum AgentCloud {
    struct Config { let url: URL; let headers: [String: String]; let model: String; let via: String }

    static func bundled(_ key: String) -> String {
        guard let u = Bundle.main.url(forResource: "beta", withExtension: "json"), let d = try? Data(contentsOf: u),
              let j = try? JSONSerialization.jsonObject(with: d) as? [String: Any] else { return "" }
        return (j[key] as? String) ?? ""
    }

    /// the kosh service (Plus: beta.json agentURL, or Settings) with this phone's pass, else Claude with your own key
    static let askKeyName = "agent.claudeKey"
    static let defaultModel = "claude-opus-5-5"
    struct Choice: Identifiable, Hashable { let id: String; let name: String }
    static let models: [Choice] = [Choice(id: "claude-opus-5-5", name: "Opus 5.5 · smartest"), Choice(id: "claude-sonnet-5-5", name: "Sonnet 5.5 · quicker, cheaper"),
                                   Choice(id: "claude-haiku-5-5", name: "Haiku 5.5 · quickest")]

    /// a one-word call to see that a key works: nil if it does, else what went wrong
    static func check(key: String, model: String) async -> String? {
        guard let u = URL(string: "https://api.anthropic.com/v1/messages") else { return "No address" }
        var req = URLRequest(url: u)
        req.httpMethod = "POST"
        for (k, v) in ["content-type": "application/json", "anthropic-version": "2023-06-01", "x-api-key": key] { req.setValue(v, forHTTPHeaderField: k) }
        req.timeoutInterval = 30
        req.httpBody = try? JSONSerialization.data(withJSONObject: ["model": model, "max_tokens": 1, "messages": [["role": "user", "content": "Hi"]]])
        do {
            let (data, resp) = try await URLSession.shared.data(for: req)
            let code = (resp as? HTTPURLResponse)?.statusCode ?? 0
            if code == 200 { return nil }
            let msg = ((try? JSONSerialization.jsonObject(with: data)) as? [String: Any]).flatMap { ($0["error"] as? [String: Any])?["message"] as? String } ?? ""
            return code == 401 ? "Anthropic didn’t accept that key." : "Anthropic said \(code)" + (msg.isEmpty ? "" : ": " + msg)
        } catch { return error.localizedDescription }
    }

    static func config() -> Config? {
        let model = (UserDefaults.standard.string(forKey: "agent.model") ?? "").isEmpty ? (bundled("agentModel").isEmpty ? defaultModel : bundled("agentModel")) : UserDefaults.standard.string(forKey: "agent.model")!
        let base = (UserDefaults.standard.string(forKey: "agent.url") ?? "").isEmpty ? bundled("agentURL") : (UserDefaults.standard.string(forKey: "agent.url") ?? "")
        if !base.isEmpty, let u = URL(string: base.trimmingCharacters(in: CharacterSet(charactersIn: "/ ")) + "/v1/messages") {
            var h = ["content-type": "application/json", "anthropic-version": "2023-06-01"]
            if let pass = Keychain.get("agent.pass"), !pass.isEmpty { h["authorization"] = "Bearer " + pass }
            return Config(url: u, headers: h, model: model, via: "kosh")
        }
        // your own key: the one for Ask kosh, else the one the mail reader uses
        if let key = Keychain.get(askKeyName) ?? Keychain.get("claude.key"), !key.isEmpty, let u = URL(string: "https://api.anthropic.com/v1/messages") {
            return Config(url: u, headers: ["content-type": "application/json", "anthropic-version": "2023-06-01", "x-api-key": key], model: model, via: "key")
        }
        return nil
    }

    static func send(_ body: [String: Any], _ cfg: Config) async throws -> [String: Any] {
        var req = URLRequest(url: cfg.url)
        req.httpMethod = "POST"
        for (k, v) in cfg.headers { req.setValue(v, forHTTPHeaderField: k) }
        req.timeoutInterval = 120
        req.httpBody = try JSONSerialization.data(withJSONObject: body)
        var wait = 2.0
        for attempt in 0..<3 {
            let (data, resp) = try await URLSession.shared.data(for: req)
            let code = (resp as? HTTPURLResponse)?.statusCode ?? 0
            if code == 200, let j = try JSONSerialization.jsonObject(with: data) as? [String: Any] { return j }
            if code == 401 || code == 403 { throw LiveError.badKey }
            if (code == 429 || code == 529 || code >= 500) && attempt < 2 { try await Task.sleep(for: .seconds(wait)); wait *= 2; continue }
            let msg = ((try? JSONSerialization.jsonObject(with: data)) as? [String: Any]).flatMap { ($0["error"] as? [String: Any])?["message"] as? String } ?? ""
            throw LiveError.http(code, msg)
        }
        throw LiveError.busy(2)
    }
}

// MARK: - Apple Intelligence's tools: the same lookups, through agent.js

#if canImport(FoundationModels)
struct SpendTool: Tool {
    let t: AgentTrace
    let name = "spending"
    let description = "Total spending in a period, optionally one category, merchant or card, with the same length of time before."
    @Generable struct Arguments {
        @Guide(description: "First day YYYY-MM-DD; empty for no limit") var from: String?
        @Guide(description: "Last day YYYY-MM-DD; empty for today") var to: String?
        @Guide(description: "A category such as Food & Drinks, Groceries, Shopping, Travel, Bills; empty for all") var category: String?
        @Guide(description: "Part of a merchant's name; empty for all") var merchant: String?
    }
    func call(arguments a: Arguments) async throws -> String {
        t.run(name, ["from": a.from ?? "", "to": a.to ?? "", "category": a.category ?? "", "merchant": a.merchant ?? ""].filter { !$0.value.isEmpty })
    }
}
struct SplitTool: Tool {
    let t: AgentTrace
    let name = "breakdown"
    let description = "Spending in a period split by category, merchant, card, person or month, biggest first."
    @Generable struct Arguments {
        @Guide(description: "category, merchant, card, person or month") var by: String
        @Guide(description: "First day YYYY-MM-DD; empty for no limit") var from: String?
        @Guide(description: "Last day YYYY-MM-DD; empty for today") var to: String?
    }
    func call(arguments a: Arguments) async throws -> String {
        t.run(name, ["by": a.by, "from": a.from ?? "", "to": a.to ?? ""].filter { !$0.value.isEmpty })
    }
}
struct PaymentsTool: Tool {
    let t: AgentTrace
    let name = "transactions"
    let description = "List payments matching a merchant, category or amount, biggest or newest first."
    @Generable struct Arguments {
        @Guide(description: "Part of a merchant's name; empty for all") var merchant: String?
        @Guide(description: "A category; empty for all") var category: String?
        @Guide(description: "First day YYYY-MM-DD; empty for no limit") var from: String?
        @Guide(description: "amount or date") var sort: String?
    }
    func call(arguments a: Arguments) async throws -> String {
        let out = t.run(name, ["merchant": a.merchant ?? "", "category": a.category ?? "", "from": a.from ?? "", "sort": a.sort ?? "", "limit": "8"].filter { !$0.value.isEmpty })
        return String(out.prefix(1200))
    }
}
struct DueTool: Tool {
    let t: AgentTrace
    let name = "upcoming"
    let description = "Bills, card dues, premiums, EMIs and rent due in the next N days."
    @Generable struct Arguments { @Guide(description: "How many days ahead, such as 7 or 30") var days: Int }
    func call(arguments a: Arguments) async throws -> String { t.run(name, ["days": a.days]) }
}
struct BalanceTool: Tool {
    let t: AgentTrace
    let name = "balances"
    let description = "Bank balances with the date each is from, and cards' spends this month."
    @Generable struct Arguments { @Guide(description: "Leave empty") var note: String? }
    func call(arguments a: Arguments) async throws -> String { String(t.run(name, [:]).prefix(1200)) }
}
struct NoticedTool: Tool {
    let t: AgentTrace
    let name = "noticed"
    let description = "What kosh noticed: fees, double charges, unusual spends, price rises, dues, deposits maturing."
    @Generable struct Arguments { @Guide(description: "Leave empty") var note: String? }
    func call(arguments a: Arguments) async throws -> String { String(t.run(name, [:]).prefix(1200)) }
}
struct CalcTool: Tool {
    let t: AgentTrace
    let name = "calc"
    let description = "Arithmetic: numbers with + - * / and brackets. Use it for every sum, difference or percentage."
    @Generable struct Arguments { @Guide(description: "e.g. (45200 - 38100) / 38100 * 100") var expression: String }
    func call(arguments a: Arguments) async throws -> String { t.run(name, ["expression": a.expression]) }
}
#endif
