import SwiftUI

// MARK: - Onboarding: privacy first, then let the mail do the work

struct OnboardingView: View {
    @Environment(Store.self) private var store
    @State private var step: Step
    @State private var sheet: SheetKind?

    /// the intro opens a fresh setup; the privacy cards replay on their own from Settings
    init(start: Step = .intro) {
        _step = State(initialValue: start)
    }

    enum Step: Int, CaseIterable {
        case intro = -1
        case privacy = 0, signIn, mail, scan, household, review, papers, extras, tabs, done
    }

    func go(_ s: Step) {
        withAnimation(Motion.large) { step = s }
    }

    var body: some View {
        ZStack {
            Color(uiColor: .systemBackground).ignoresSafeArea()
            Group {
                switch step {
                case .intro:
                    IntroView(showcase: store.showcase == .intro) {
                        if store.showcase == .intro { store.showcase = nil } else { go(.privacy) }
                    }
                case .privacy: PrivacyCards(last: store.showcase == .cards ? "Done" : "Get started") {
                    // the beta goes straight to connecting an inbox: the intro and the privacy cards were the welcome
                    if store.showcase == .cards { store.showcase = nil } else { go(store.live != nil ? .mail : .signIn) }
                }
                case .signIn:
                    SignInStep { go(.mail) }
                case .mail:
                    if store.live != nil { LiveMailStep { go(.scan) } } else { MailStep { go(.scan) } }
                case .scan:
                    // the beta: one screen reads, shows what it found and whose it is (household, review and papers
                    // were three more; the papers wait on Home's "Finish setting up"); then what it found, and done
                    if store.live != nil { LiveFoundStep { go(.done) } } else { ScanStep { go(.household) } }
                case .household:
                    HouseholdStep { go(.review) }
                case .review:
                    ReviewStep { go(.extras) }
                case .papers:
                    if store.live != nil { LivePapersStep { go(.extras) } } else { Color.clear.onAppear { go(.extras) } }
                case .extras: ExtrasStep(sheet: $sheet) { go(.tabs) }
                case .tabs: TabsStep { go(.done) }
                case .done:
                    if store.live != nil {
                        // no tab picker: the bar is made from what was found, and Settings › Tab bar changes it
                        LiveDoneStep {
                            if !store.onboarded { store.setTabs(store.foundTabs) }
                            store.tab = .home
                            store.homeSub = .overview
                            store.showcase = nil
                            store.onboarded = true
                        }
                    } else {
                        DoneStep {
                            store.tab = .home
                            store.homeSub = .overview
                            store.showcase = nil
                            store.onboarded = true
                        }
                    }
                }
            }
            .id(step)
            .transition(.asymmetric(insertion: .move(edge: .trailing).combined(with: .opacity),
                                    removal: .move(edge: .leading).combined(with: .opacity)))
        }
        .overlay(alignment: .top) {
            if store.live != nil {
                // the beta's four steps: your privacy, your inboxes, what kosh finds, and done
                let live: [Step] = [.privacy, .mail, .scan, .done]
                if let i = live.firstIndex(of: step), store.showcase != .cards {
                    OnboardingProgress(step: i, of: live.count, canGoBack: i > 0) {
                        if i > 0 { go(live[i - 1]) }
                    }
                }
            } else if step.rawValue >= Step.signIn.rawValue && step != .done {
                OnboardingProgress(step: step.rawValue - 1, of: Step.done.rawValue - 1, canGoBack: step.rawValue - 1 > 0 && step.rawValue - 1 != 2) {
                    if let back = Step(rawValue: step.rawValue - 1), step != .household {
                        go(back)
                    } else if step == .household {
                        go(.mail)
                    }
                }
            }
        }
        .overlay(alignment: .topTrailing) {
            // the intro carries its own close button
            if store.showcase != nil && step != .intro {
                Button {
                    store.showcase = nil
                } label: {
                    Image(systemName: "xmark").font(.body.weight(.semibold))
                }
                .buttonStyle(.glass)
                .buttonBorderShape(.circle)
                .padding(.trailing, 16)
                .padding(.top, 4)
                .accessibilityLabel("Close")
            }
        }
        .sheet(item: $sheet) { kind in
            SheetHost(kind: kind)
                .environment(store)
                .tint(Color.kosh)
        }
        .sensoryFeedback(.impact(weight: .light), trigger: step)
    }
}

struct OnboardingProgress: View {
    let step: Int
    let of: Int
    var canGoBack: Bool = true
    let back: () -> Void
    var body: some View {
        HStack(spacing: 12) {
            Button(action: back) {
                Image(systemName: "chevron.left").font(.body.weight(.semibold))
            }
            .buttonStyle(.glass)
            .buttonBorderShape(.circle)
            .opacity(canGoBack ? 1 : 0)
            .disabled(!canGoBack)
            .accessibilityLabel("Back")
            HStack(spacing: 4) {
                ForEach(0..<of, id: \.self) { i in
                    Capsule()
                        .fill(i <= step ? Color.kosh : Color.primary.opacity(0.1))
                        .frame(height: 4)
                }
            }
            .animation(Motion.open, value: step)
            Color.clear.frame(width: 44, height: 1)
        }
        .padding(.horizontal, 16)
        .padding(.top, 4)
    }
}

/// The big button at the foot of each step
struct StepButton: View {
    let title: String
    var enabled = true
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.headline)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 6)
        }
        .buttonStyle(.glassProminent).koshFilled()
        .controlSize(.large)
        .disabled(!enabled)
        .padding(.horizontal, 24)
        .padding(.bottom, 12)
    }
}

/// A step's title block
struct StepTitle: View {
    let sym: String
    let title: String
    let text: String
    var color: Color = Color.kosh
    @State private var shown = false
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Image(systemName: sym)
                .font(.system(.title, weight: .semibold))
                .foregroundStyle(color.gradient)
                .symbolEffect(.bounce, value: shown)
            Text(title)
                .font(.system(.title, design: .rounded, weight: .bold))
                .fixedSize(horizontal: false, vertical: true)
            Text(text)
                .font(.body)
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .onAppear { shown = true }
    }
}

/// Said plainly whenever the app is pretending
struct TestModeNote: View {
    let text: String
    var body: some View {
        Label(text, systemImage: "testtube.2")
            .font(.footnote)
            .foregroundStyle(.secondary)
            .padding(.horizontal, 12)
            .padding(.vertical, 8)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.yellow.opacity(0.14), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
    }
}

// MARK: 1. Privacy, before anything else: one screen, three promises

struct PrivacyCards: View {
    var last = "Get started"
    let next: () -> Void
    @State private var shown = false

    struct Promise: Identifiable { let id: Int; let sym: String; let color: Color; let title: String; let text: String }
    let promises: [Promise] = [
        Promise(id: 0, sym: "envelope.open.fill", color: Color.orange, title: "Money mail only",
                text: "Bank alerts, card statements, bills, receipts and premiums. Everything else in your inbox is skipped, unread."),
        Promise(id: 1, sym: "lock.shield.fill", color: Color.green, title: "Encrypted, on this phone",
                text: "Your ledger is worked out here and sealed here. Nobody at kosh can open it."),
        Promise(id: 2, sym: "hand.raised.fill", color: Color.sky, title: "Read-only, always",
                text: "No bank password or PIN, ever, and kosh can never move money. Disconnect and erase everything with one switch."),
    ]

    var body: some View {
        VStack(spacing: 0) {
            ScrollView {
                VStack(alignment: .leading, spacing: 26) {
                    StepTitle(sym: "checkmark.shield.fill", title: "Before kosh reads anything",
                              text: "It reads the mail your banks already send you, and turns it into one clear picture of your family’s money.",
                              color: Color.green)
                    VStack(alignment: .leading, spacing: 22) {
                        ForEach(promises) { p in
                            HStack(alignment: .top, spacing: 14) {
                                Image(systemName: p.sym)
                                    .font(.system(size: 20, weight: .semibold))
                                    .foregroundStyle(p.color.gradient)
                                    .frame(width: 44, height: 44)
                                    .background(p.color.opacity(0.14), in: RoundedRectangle(cornerRadius: 13, style: .continuous))
                                VStack(alignment: .leading, spacing: 4) {
                                    Text(p.title).font(.headline)
                                    Text(p.text).font(.subheadline).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                                }
                            }
                            .opacity(shown ? 1 : 0)
                            .offset(y: shown ? 0 : 12)
                            .animation(Motion.reveal.delay(Motion.stagger(p.id, after: 0.12)), value: shown)
                        }
                    }
                }
                .padding(.horizontal, 24)
                .padding(.top, 72)
                .padding(.bottom, 20)
            }
            StepButton(title: last) { next() }
        }
        .onAppear { shown = true }
    }
}

// MARK: 2. Sign in

struct SignInStep: View {
    @Environment(Store.self) private var store
    let next: () -> Void
    @State private var shown = false
    var body: some View {
        VStack(spacing: 0) {
            Spacer()
            VStack(spacing: 14) {
                Text("kosh")
                    .font(.system(size: 64, weight: .heavy, design: .rounded))
                    .foregroundStyle(LinearGradient(colors: [Color.kosh, Color.sky], startPoint: .topLeading, endPoint: .bottomTrailing))
                    .scaleEffect(shown ? 1 : 0.85)
                    .opacity(shown ? 1 : 0)
                Text("One account for the whole household. Your mail fills it in.")
                    .font(.title3)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 32)
            }
            Spacer()
            VStack(spacing: 12) {
                Button(action: next) {
                    HStack(spacing: 8) {
                        Image(systemName: "apple.logo")
                        Text("Sign in with Apple")
                    }
                    .font(.headline)
                    .foregroundStyle(Color(light: Color.white, dark: Color.black))
                    .frame(maxWidth: .infinity)
                    .frame(height: 52)
                    .background(Color(light: Color.black, dark: Color.white), in: Capsule())
                }
                .buttonStyle(.press)
                Button(action: next) {
                    HStack(spacing: 8) {
                        Image(systemName: "envelope.fill")
                        Text("Continue with Google")
                    }
                    .font(.headline)
                    .foregroundStyle(Color.primary)
                    .frame(maxWidth: .infinity)
                    .frame(height: 52)
                    .background(Color.surface, in: Capsule())
                    .overlay(Capsule().stroke(Color.hairline, lineWidth: 1))
                }
                .buttonStyle(.press)
                if Snapshot.hasDemo {
                    Button {
                        store.setDemo(!store.demo)
                    } label: {
                        Label(store.demo ? "Using sample data · switch to yours" : "Explore with sample data",
                              systemImage: store.demo ? "person.crop.circle.badge.checkmark" : "theatermasks")
                            .font(.subheadline.weight(.semibold))
                    }
                    .buttonStyle(.press)
                    .foregroundStyle(Color.kosh)
                    .padding(.top, 4)
                }
                TestModeNote(text: store.demo ? "Sample mode: a made-up household, so you can show kosh to anyone." : "Test mode: sign-in is skipped and nothing leaves this phone.")
                    .padding(.top, 6)
            }
            .padding(.horizontal, 24)
            .padding(.bottom, 16)
        }
        .onAppear { withAnimation(Motion.reveal.delay(0.1)) { shown = true } }
    }
}

// MARK: 3. Gmail permission

struct MailStep: View {
    @Environment(Store.self) private var store
    let next: () -> Void
    @State private var forward = false

    var body: some View {
        VStack(spacing: 0) {
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    StepTitle(sym: "envelope.badge.shield.half.filled", title: "Let kosh read your money mail",
                              text: "One permission sets up almost everything: banks, cards, wallets, EMIs, premiums, rent and committees.")
                    VStack(alignment: .leading, spacing: 0) {
                        MailLine(sym: "checkmark.circle.fill", color: Color.green, text: "Bank and card alerts, statements")
                        MailLine(sym: "checkmark.circle.fill", color: Color.green, text: "Receipts from Amazon Pay, Swiggy, Zomato, Blinkit")
                        MailLine(sym: "checkmark.circle.fill", color: Color.green, text: "Insurance premiums, loan EMIs, rent and tax receipts")
                        Divider().padding(.vertical, 6)
                        MailLine(sym: "xmark.circle.fill", color: Color.secondary, text: "Never your personal mail")
                        MailLine(sym: "xmark.circle.fill", color: Color.secondary, text: "Never sends, deletes or moves a message")
                        MailLine(sym: "xmark.circle.fill", color: Color.secondary, text: "Never sends anything to a kosh server: it’s read on this phone")
                    }
                    .card(16)
                    HStack(alignment: .top, spacing: 10) {
                        Image(systemName: "sparkles").foregroundStyle(Color.kosh)
                        Text("kosh’s own rules read the mail on this phone. Smart reading, which uses AI for the emails the rules can’t read, is off unless you turn it on.")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                    Button {
                        withAnimation(Motion.open) { forward.toggle() }
                    } label: {
                        Label("Rather not connect Gmail?", systemImage: "arrowshape.turn.up.right")
                            .font(.subheadline.weight(.semibold))
                    }
                    .buttonStyle(.press)
                    .foregroundStyle(Color.kosh)
                    if forward {
                        Text("Outlook, Yahoo and iCloud work too, each with its own sign-in. You can also add a statement or a policy by hand.")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                            .card(14)
                            .transition(.opacity.combined(with: .move(edge: .top)))
                    }
                    TestModeNote(text: "Test mode: kosh reads \(store.sourceNote) instead of Gmail.")
                }
                .padding(.horizontal, 24)
                .padding(.top, 72)
                .padding(.bottom, 20)
            }
            StepButton(title: "Connect Gmail", action: next)
        }
    }
}

struct MailLine: View {
    let sym: String
    let color: Color
    let text: String
    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: sym).foregroundStyle(color)
            Text(text).font(.subheadline)
            Spacer(minLength: 0)
        }
        .padding(.vertical, 5)
    }
}

// MARK: 4. The scan: kosh reads, and things appear

struct ScanStep: View {
    @Environment(Store.self) private var store
    let next: () -> Void
    @State private var shown = 0
    @State private var progress: Double = 0
    @State private var finished = false

    let phases = ["Reading bank alerts", "Matching card statements", "Finding wallets", "Spotting EMIs and premiums",
                  "Counting committee instalments", "Linking accounts to people", "Checking for doubles"]

    var body: some View {
        let items = store.snap.scan
        let stats = store.snap.scanStats
        let read = Int(Double(stats.emails) * progress)
        let phase = phases[min(phases.count - 1, Int(progress * Double(phases.count)))]
        VStack(spacing: 0) {
            VStack(spacing: 14) {
                ZStack {
                    Circle().stroke(Color.kosh.opacity(0.12), lineWidth: 8)
                    Circle()
                        .trim(from: 0, to: progress)
                        .stroke(AngularGradient(colors: [Color.kosh, Color.sky, Color.kosh], center: .center),
                                style: StrokeStyle(lineWidth: 8, lineCap: .round))
                        .rotationEffect(.degrees(-90))
                    Image(systemName: finished ? "checkmark" : "sparkles")
                        .font(.system(size: 34, weight: .semibold))
                        .foregroundStyle(finished ? Color.green : Color.kosh)
                        .contentTransition(.symbolEffect(.replace))
                        .symbolEffect(.pulse, options: .repeating, isActive: !finished)
                }
                .frame(width: 112, height: 112)
                Text(finished ? "Found \(items.count) things" : "\(read) emails read")
                    .font(.system(.title, design: .rounded, weight: .bold))
                    .contentTransition(.numericText(value: Double(read)))
                Text(finished ? "From \(stats.emails) emails since \(Day.fmt(stats.from, "d MMMM")), \(stats.months) months." : phase + "…")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .contentTransition(.opacity)
            }
            .padding(.top, 64)
            .padding(.bottom, 18)
            ScrollViewReader { proxy in
                ScrollView {
                    VStack(spacing: 10) {
                        ForEach(Array(items.prefix(shown))) { it in
                            ScanRow(it: it)
                                .id(it.id)
                                .transition(.asymmetric(insertion: .move(edge: .bottom).combined(with: .opacity).combined(with: .scale(scale: 0.95)),
                                                        removal: .opacity))
                        }
                    }
                    .padding(.horizontal, 20)
                    .padding(.bottom, 12)
                }
                .onChange(of: shown) { _, n in
                    if n > 0, n <= items.count {
                        withAnimation(Motion.open) { proxy.scrollTo(items[n - 1].id, anchor: .bottom) }
                    }
                }
            }
            if finished {
                StepButton(title: "Review what kosh found", action: next)
                    .transition(.move(edge: .bottom).combined(with: .opacity))
            } else {
                TestModeNote(text: "Test mode: replaying the scan from \(store.sourceNote).")
                    .padding(.horizontal, 24)
                    .padding(.bottom, 16)
            }
        }
        .sensoryFeedback(.impact(weight: .light), trigger: shown)
        .sensoryFeedback(.success, trigger: finished)
        .task {
            if shown > 0 { return }
            let n = max(1, items.count)
            for i in 0..<items.count {
                try? await Task.sleep(for: .milliseconds(380))
                withAnimation(Motion.large) {
                    shown = i + 1
                }
                withAnimation(Motion.large) {
                    progress = Double(i + 1) / Double(n)
                }
            }
            try? await Task.sleep(for: .milliseconds(400))
            withAnimation(Motion.reveal) { finished = true }
        }
    }
}

struct ScanRow: View {
    let it: ScanItem
    var body: some View {
        HStack(spacing: 12) {
            if it.kind == "bank" {
                InstIcon(name: String(it.id.dropFirst(2)), color: Color(hex: it.color), size: 38)
            } else {
                IconTile(symbol: it.sym, color: Color(hex: it.color), size: 38)
            }
            VStack(alignment: .leading, spacing: 2) {
                Text(it.title).font(.body.weight(.semibold)).lineLimit(1)
                Text(it.detail).font(.subheadline).foregroundStyle(.secondary).lineLimit(1)
            }
            Spacer(minLength: 6)
            if it.kind == "bank" || it.kind == "wallet" {
                Text("\(it.count)")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.secondary)
                    .monospacedDigit()
            }
        }
        .padding(12)
        .background(Color.surface, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
    }
}

// MARK: 5. The household, from the names on the accounts

struct HouseholdStep: View {
    @Environment(Store.self) private var store
    let next: () -> Void
    @State private var off: Set<String> = []
    @State private var extra: [String] = []
    @State private var newName = ""
    @State private var adding = false

    func line(_ p: PersonInfo) -> String {
        let a = store.snap.accounts.filter { $0.owner == p.id }.count
        let c = store.snap.cards.filter { $0.owner == p.id }.count
        let h = store.snap.hold.filter { $0.person == p.id }.count
        var parts: [String] = []
        if a > 0 { parts.append("\(a) account\(a == 1 ? "" : "s")") }
        if c > 0 { parts.append("\(c) card\(c == 1 ? "" : "s")") }
        if h > 0 { parts.append("\(h) holding\(h == 1 ? "" : "s")") }
        return parts.isEmpty ? "Named on records in your mail" : parts.joined(separator: ", ")
    }

    var body: some View {
        VStack(spacing: 0) {
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    StepTitle(sym: "person.2.fill", title: "Who’s in the household?",
                              text: "kosh read the names on statements and alerts and found \(Words.number(store.snap.people.count)) people. Every screen can show the whole family or just one of them.")
                    VStack(spacing: 0) {
                        ForEach(Array(store.snap.people.enumerated()), id: \.element.id) { i, p in
                            if i > 0 { Divider().padding(.leading, 66) }
                            HStack(spacing: 12) {
                                Avatar(name: p.full, color: Color(hex: p.color), size: 42)
                                VStack(alignment: .leading, spacing: 2) {
                                    HStack(spacing: 6) {
                                        Text(p.full).font(.body.weight(.semibold))
                                        Chip(text: p.rel, color: Color(hex: p.color))
                                    }
                                    Text(line(p)).font(.subheadline).foregroundStyle(.secondary)
                                }
                                Spacer()
                                Toggle("", isOn: Binding(get: { !off.contains(p.id) }, set: { v in
                                    if v { _ = off.remove(p.id) } else { _ = off.insert(p.id) }
                                }))
                                    .labelsHidden()
                                    .disabled(p.id == "me")
                            }
                            .padding(.vertical, 10)
                            .padding(.horizontal, 14)
                        }
                        ForEach(extra, id: \.self) { n in
                            Divider().padding(.leading, 66)
                            HStack(spacing: 12) {
                                Avatar(name: n, color: Color.gray, size: 42)
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(n).font(.body.weight(.semibold))
                                    Text("Added by you").font(.subheadline).foregroundStyle(.secondary)
                                }
                                Spacer()
                            }
                            .padding(.vertical, 10)
                            .padding(.horizontal, 14)
                        }
                    }
                    .background(Color.surface, in: RoundedRectangle(cornerRadius: 26, style: .continuous))
                    if adding {
                        HStack {
                            TextField("Name", text: $newName)
                                .textInputAutocapitalization(.words)
                                .padding(12)
                                .background(Color.surface, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                            Button("Add") {
                                let n = newName.trimmingCharacters(in: .whitespaces)
                                if !n.isEmpty { withAnimation(Motion.open) { extra.append(n) } }
                                newName = ""
                                adding = false
                            }
                            .buttonStyle(.glassProminent).koshFilled()
                        }
                    } else {
                        Button {
                            withAnimation(Motion.open) { adding = true }
                        } label: {
                            Label("Add someone kosh missed", systemImage: "person.badge.plus")
                                .font(.subheadline.weight(.semibold))
                        }
                        .buttonStyle(.press)
                        .foregroundStyle(Color.kosh)
                    }
                }
                .padding(.horizontal, 24)
                .padding(.top, 72)
                .padding(.bottom, 20)
            }
            StepButton(title: "That’s us", action: next)
        }
    }
}

// MARK: 6. Review what was found

struct ReviewStep: View {
    @Environment(Store.self) private var store
    let next: () -> Void
    @State private var off: Set<String> = []

    struct Bucket: Identifiable { let id: String; let title: String; let kinds: [String] }
    let groups: [Bucket] = [
        Bucket(id: "banks", title: "Banks and cards", kinds: ["bank"]),
        Bucket(id: "wallets", title: "Wallets", kinds: ["wallet"]),
        Bucket(id: "money", title: "Loans, bills and premiums", kinds: ["loan", "bill", "insurance"]),
        Bucket(id: "wealth", title: "Savings, committees and property", kinds: ["investment", "committee", "property"]),
    ]

    var body: some View {
        let items = store.snap.scan
        let kept = items.filter { !off.contains($0.id) }.count
        VStack(spacing: 0) {
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    StepTitle(sym: "checklist", title: "Here’s what kosh found",
                              text: "Untick anything that isn’t this household’s. You can change it any time in Settings.")
                    HStack(spacing: 10) {
                        CountTile(value: "\(store.snap.accounts.count)", label: "accounts", sym: "building.columns.fill", color: Color.kosh)
                        CountTile(value: "\(store.snap.cards.count)", label: "cards", sym: "creditcard.fill", color: Color.sky)
                        CountTile(value: "\(store.snap.wallets.count)", label: "wallets", sym: "wallet.bifold.fill", color: Color.orange)
                    }
                    ForEach(groups) { g in
                        let rows = items.filter { g.kinds.contains($0.kind) }
                        if !rows.isEmpty {
                            VStack(alignment: .leading, spacing: 10) {
                                Text(g.title).font(.headline)
                                VStack(spacing: 0) {
                                    ForEach(Array(rows.enumerated()), id: \.element.id) { i, it in
                                        if i > 0 { Divider().padding(.leading, 64) }
                                        ReviewRow(it: it, on: !off.contains(it.id)) {
                                            withAnimation(Motion.base) {
                                                if off.contains(it.id) { _ = off.remove(it.id) } else { _ = off.insert(it.id) }
                                            }
                                        }
                                    }
                                }
                                .background(Color.surface, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
                            }
                        }
                    }
                }
                .padding(.horizontal, 24)
                .padding(.top, 72)
                .padding(.bottom, 20)
            }
            StepButton(title: "Looks right · keep \(kept)", action: next)
        }
        .sensoryFeedback(.selection, trigger: off)
    }
}

struct ReviewRow: View {
    let it: ScanItem
    let on: Bool
    let toggle: () -> Void
    var body: some View {
        Button(action: toggle) {
            HStack(spacing: 12) {
                if it.kind == "bank" {
                    InstIcon(name: String(it.id.dropFirst(2)), color: Color(hex: it.color), size: 36)
                } else {
                    IconTile(symbol: it.sym, color: Color(hex: it.color), size: 36)
                }
                VStack(alignment: .leading, spacing: 2) {
                    Text(it.title).font(.body.weight(.medium)).foregroundStyle(Color.primary).lineLimit(1)
                    Text(it.detail).font(.subheadline).foregroundStyle(.secondary).lineLimit(2)
                }
                Spacer(minLength: 6)
                Image(systemName: on ? "checkmark.circle.fill" : "circle")
                    .font(.title3)
                    .foregroundStyle(on ? Color.kosh : Color.secondary)
                    .contentTransition(.symbolEffect(.replace))
            }
            .opacity(on ? 1 : 0.5)
            .padding(.vertical, 10)
            .padding(.horizontal, 14)
            .contentShape(Rectangle())
        }
        .buttonStyle(.press)
    }
}

// MARK: 7. What email can't see

struct ExtrasStep: View {
    @Environment(Store.self) private var store
    @Binding var sheet: SheetKind?
    let next: () -> Void

    struct Extra: Identifiable { let id: String; let sym: String; let color: Color; let title: String; let text: String; let capture: String? }

    var extras: [Extra] {
        var out: [Extra] = [
            Extra(id: "cash", sym: "banknote.fill", color: Color(hex: "#34C759"), title: "Cash in hand", text: "Type what’s at home and in wallets.", capture: "cash"),
        ]
        if let l = store.snap.loans.first(where: { $0.active }) {
            out.append(Extra(id: "loan", sym: "house.fill", color: Color(hex: "#FF3B30"), title: "\(l.name) balance",
                             text: "EMIs show in mail; the balance left doesn’t. Snap a loan statement.", capture: "loan:" + l.id))
        }
        if let p = store.snap.policies.first(where: { !$0.isEnded }) {
            out.append(Extra(id: "policy", sym: "shield.lefthalf.filled", color: Color(hex: "#30B0C7"), title: "Policy details",
                             text: "Cover and policy numbers live in the PDF. Snap the schedule.", capture: "policy:" + p.id))
        }
        out.append(Extra(id: "gold", sym: "seal.fill", color: Color(hex: "#FFB300"), title: "Gold, NPS, post office",
                         text: "Savings that never email you.", capture: "gold"))
        out.append(Extra(id: "owed", sym: "person.2.fill", color: Color(hex: "#FF9500"), title: "Someone who owes you",
                         text: "Money lent to a friend, or a split not settled.", capture: nil))
        return out
    }

    func isDone(_ e: Extra) -> Bool {
        if let c = e.capture { return store.captures.contains { $0.kind == c } }
        return !store.userOwed.isEmpty
    }

    var body: some View {
        VStack(spacing: 0) {
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    StepTitle(sym: "camera.viewfinder", title: "Add what email can’t see",
                              text: "A photo or a number, once. kosh reads photos on this phone. Skip any of these; Home will keep a list.")
                    VStack(spacing: 0) {
                        ForEach(Array(extras.enumerated()), id: \.element.id) { i, e in
                            if i > 0 { Divider().padding(.leading, 64) }
                            HStack(spacing: 12) {
                                IconTile(symbol: e.sym, color: e.color, size: 38)
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(e.title).font(.body.weight(.semibold))
                                    Text(e.text).font(.subheadline).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                                }
                                Spacer(minLength: 6)
                                if isDone(e) {
                                    Image(systemName: "checkmark.circle.fill").font(.title2).foregroundStyle(Color.green)
                                        .transition(.scale.combined(with: .opacity))
                                } else {
                                    Button("Add") {
                                        if let c = e.capture { sheet = .capture(c) } else { sheet = .lend }
                                    }
                                    .buttonStyle(.glass)
                                    .font(.subheadline.weight(.semibold))
                                }
                            }
                            .padding(.vertical, 12)
                            .padding(.horizontal, 14)
                        }
                    }
                    .background(Color.surface, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
                    .animation(Motion.open, value: store.captures)
                }
                .padding(.horizontal, 24)
                .padding(.top, 72)
                .padding(.bottom, 20)
            }
            StepButton(title: "Continue", action: next)
            Button("I’ll do these later", action: next)
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .padding(.bottom, 8)
        }
    }
}

// MARK: 8. Make the tab bar yours

struct TabsStep: View {
    @Environment(Store.self) private var store
    let next: () -> Void
    @State private var picked: [AppTab] = [.transactions, .portfolio, .property, .committees]
    @State private var refused = 0
    @State private var shakes: [AppTab: Int] = [:]

    var suggested: [AppTab] { store.live != nil ? [.transactions, .portfolio, .people, .insurance] : [.transactions, .portfolio, .property, .committees] }

    func why(_ t: AppTab) -> String {
        if store.live != nil {
            switch t {
            case .insurance: return store.snap.policies.isEmpty ? t.blurb : "\(Words.cap(Words.number(store.snap.policies.filter { !$0.isEnded }.count))) policies found"
            default: return t.blurb
            }
        }
        switch t {
        case .property: return "Rent from \(Words.number(store.snap.prop.props.flatMap { $0.units }.filter { $0.rent > 0 }.count)) tenants found"
        case .committees: return "\(Words.cap(Words.number(store.liveCommittees.count))) running"
        case .insurance: return "\(Words.cap(Words.number(store.snap.policies.filter { !$0.isEnded }.count))) policies found"
        case .loans: return "Home loan EMI found"
        default: return t.blurb
        }
    }

    func toggle(_ t: AppTab) {
        if let i = picked.firstIndex(of: t) {
            withAnimation(Motion.base) { _ = picked.remove(at: i) }
            return
        }
        if picked.count >= AppTab.most - 1 {
            refused += 1
            withAnimation(.linear(duration: 0.42)) { shakes[t, default: 0] += 1 }
            return
        }
        withAnimation(Motion.base) { picked.append(t) }
    }

    var body: some View {
        let bar: [AppTab] = [.home] + picked
        let enough: Bool = bar.count >= AppTab.fewest
        VStack(spacing: 0) {
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    StepTitle(sym: "rectangle.3.group.fill", title: "Make the tab bar yours",
                              text: "Home comes first. Pick three to five more, in the order you want them; kosh suggests what it found most of.")
                    VStack(spacing: 10) {
                        ForEach(AppTab.pinnable.filter { $0 != .home }) { t in
                            let on = picked.contains(t)
                            Button { toggle(t) } label: {
                                HStack(spacing: 12) {
                                    IconTile(symbol: t.symbol, color: moduleColor(t), size: 38)
                                    VStack(alignment: .leading, spacing: 2) {
                                        HStack(spacing: 6) {
                                            Text(t.title).font(.body.weight(.semibold)).foregroundStyle(Color.primary)
                                            if suggested.contains(t) { Chip(text: "Suggested") }
                                        }
                                        Text(why(t)).font(.subheadline).foregroundStyle(.secondary)
                                    }
                                    Spacer()
                                    ZStack {
                                        Image(systemName: on ? "checkmark.circle.fill" : "circle")
                                            .font(.title2)
                                            .foregroundStyle(on ? Color.kosh : Color.secondary.opacity(0.5))
                                            .contentTransition(.symbolEffect(.replace))
                                        if on, let i = picked.firstIndex(of: t) {
                                            Text(String(i + 2)).font(.system(size: 10, weight: .bold, design: .rounded))
                                                .foregroundStyle(Color(uiColor: .systemBackground))
                                                .frame(width: 16, height: 16)
                                                .background(Color.primary, in: Circle())
                                                .offset(x: 11, y: -11)
                                                .transition(.scale.combined(with: .opacity))
                                        }
                                    }
                                }
                                .padding(12)
                                .background(Color.surface, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
                                .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).stroke(on ? Color.kosh : Color.clear, lineWidth: 2))
                                .contentShape(Rectangle())
                            }
                            .buttonStyle(.press)
                            .modifier(Shake(shakes: CGFloat(shakes[t] ?? 0)))
                        }
                    }
                    Text("Up to five, the bar shows names under the icons; at six, icons alone. The rest stay one tap away on Home, and Settings › Tab bar changes it any time.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                }
                .padding(.horizontal, 24)
                .padding(.top, 72)
                .padding(.bottom, 20)
            }
            BarSample(tabs: bar, iconsOnly: true)
                .padding(.horizontal, 20)
                .padding(.bottom, 14)
            StepButton(title: enough ? "Use these tabs" : "Pick " + String(AppTab.fewest - bar.count) + " more", enabled: enough) {
                store.setTabs(bar)
                next()
            }
        }
        .sensoryFeedback(.selection, trigger: picked)
        .sensoryFeedback(.warning, trigger: refused)
        .onAppear {
            if store.live != nil && !store.onboarded { picked = suggested }
            else { picked = Array(store.tabs.dropFirst()) }
        }
    }
}

// MARK: 9. Ready

struct DoneStep: View {
    @Environment(Store.self) private var store
    let finish: () -> Void
    @State private var shown = false

    var body: some View {
        let left = store.setupSteps.filter { !$0.done }.count
        VStack(spacing: 0) {
            Spacer()
            VStack(spacing: 18) {
                Image(systemName: "checkmark.circle.fill")
                    .font(.system(size: 92))
                    .foregroundStyle(Color.green.gradient)
                    .symbolEffect(.bounce, value: shown)
                    .scaleEffect(shown ? 1 : 0.6)
                    .opacity(shown ? 1 : 0)
                Text("kosh is ready")
                    .font(.system(.largeTitle, design: .rounded, weight: .bold))
                Text("\(store.snap.scanStats.months) months of the household’s money, sorted. New mail keeps it up to date.")
                    .font(.body)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 32)
                HStack(spacing: 10) {
                    CountTile(value: "\(store.snap.people.count)", label: "people", sym: "person.2.fill", color: Color.orange)
                    CountTile(value: "\(store.snap.accounts.count + store.snap.wallets.count)", label: "accounts", sym: "building.columns.fill", color: Color.kosh)
                    CountTile(value: "\(store.snap.cards.count)", label: "cards", sym: "creditcard.fill", color: Color.sky)
                }
                .padding(.horizontal, 24)
                .padding(.top, 8)
                if left > 0 {
                    Text("\(Words.cap(Words.number(left))) small thing\(left == 1 ? "" : "s") left to add. Home keeps the list.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
            }
            Spacer()
            StepButton(title: "Open kosh", action: finish)
        }
        .onAppear { withAnimation(Motion.reveal.delay(0.15)) { shown = true } }
    }
}
