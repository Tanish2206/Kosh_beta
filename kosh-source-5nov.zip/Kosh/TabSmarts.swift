import SwiftUI

// MARK: - Each tab's one line: what matters today (engine/21p-build-tab-smarts.js, snap.smarts)
//
// The engine works out one plain sentence per tab from figures the tab already shows, and says nothing where the data
// is thin. A tab shows it quietly at its top, in the look of Portfolio's voice line; the history stays below it.

/// what each tab opens on; every part is nil when kosh has nothing sure to say
struct TabSmarts: Decodable, Hashable {
    var insights: [SmartInsight]? = nil
    var portfolio: SmartPortfolio? = nil
    var insurance: SmartInsurance? = nil
    var property: SmartProperty? = nil
    var committees: SmartCommittees? = nil
    var cards: SmartCards? = nil
}

/// Insights, for one person picked (o: "family" or their id): the latest full month, or this month so far once it is
/// already well over, against the usual month (the middle of the full months from `from` to `to`)
struct SmartInsight: Decodable, Hashable {
    let o: String; let m: String; let line: String
    let total: Double; let usual: Double; let diff: Double
    let from: String; let to: String; let n: Int
    var basis: String? = nil
    var live: Bool? = nil
    /// the kind of spending that moved most, and the shop behind most of it
    var cat: String? = nil; var catV: Double? = nil; var catUsual: Double? = nil
    var shop: String? = nil; var shopV: Double? = nil
}

/// Portfolio: since last month's end, the change in what's invested and why; what matures or unlocks within 60 days;
/// a fund or an index held in both a Regular and a Direct plan
struct SmartPortfolio: Decodable, Hashable {
    struct Soon: Decodable, Hashable { let kind: String; let d: String; let title: String; var bank: String? = nil; let amt: Double; let person: String }
    struct Twin: Decodable, Hashable {
        struct Fund: Decodable, Hashable { let name: String; let plan: String; let amt: Double; let person: String }
        let key: String; var index: String? = nil; let regular: Double; let direct: Double; let funds: [Fund]
    }
    let asOf: String; let line: String
    var notes: [String]? = nil
    var since: String? = nil
    var then: Double? = nil; var now: Double? = nil; var change: Double? = nil
    var putIn: Double? = nil; var takenOut: Double? = nil; var matured: Double? = nil; var market: Double? = nil
    var soon: [Soon]? = nil
    var twins: [Twin]? = nil
}

/// Insurance: each person's health, life and vehicle cover kosh can see, the gaps, and the next 90 days of premiums
struct SmartInsurance: Decodable, Hashable {
    struct Who: Decodable, Hashable {
        let id: String; let name: String
        /// covered · elsewhere (you said: an employer's cover) · none
        let health: String; var healthCover: Double? = nil
        let life: String; var lifeCover: Double? = nil
        var earns: Bool? = nil
        /// covered · due · lapsed, when they own a vehicle kosh knows of
        var vehicle: String? = nil
        var gaps: [String]? = nil
    }
    struct Premiums: Decodable, Hashable {
        struct Next: Decodable, Hashable { let policy: String; let insurer: String; let date: String; let amt: Double }
        let from: String; let to: String; let n: Int; let amt: Double; let unknown: Int; let next: Next
    }
    let asOf: String; let line: String
    var notes: [String]? = nil
    let people: [Who]
    var premiums: Premiums? = nil
    /// a running policy whose kind kosh couldn't tell: no gap is said
    var unsure: Bool? = nil
}

/// Property: rent not in three days past its usual day, months behind, leases ending within 60 days
struct SmartProperty: Decodable, Hashable {
    struct Late: Decodable, Hashable {
        let prop: String; let unit: String; let tenant: String; let rent: Double
        var day: Int? = nil; var said: Bool? = nil
        var due: String? = nil; var days: Int? = nil
        var behind: [String]? = nil
        let owed: Double
    }
    struct Ending: Decodable, Hashable { let prop: String; let unit: String; let tenant: String; let rent: Double; let end: String }
    let asOf: String; let month: String; let line: String
    var notes: [String]? = nil
    /// floors let this month, and how many of their rents are in
    let lets: Int; let rentIn: Int
    var late: [Late]? = nil
    var ending: [Ending]? = nil
}

/// Committees: the next turn to take a pot, what's paid in by then, and the rate it works out to against your deposit
struct SmartCommittees: Decodable, Hashable {
    struct Turn: Decodable, Hashable {
        let id: String; let name: String; let turn: String; let paidBy: Double; let pot: Double
        var rate: Double? = nil; var lend: Bool? = nil
    }
    struct Paying: Decodable, Hashable {
        let id: String; let name: String; let left: Int; let outstanding: Double
        var rate: Double? = nil; var lend: Bool? = nil
    }
    struct Deposit: Decodable, Hashable { let rate: Double; let bank: String }
    let asOf: String; let line: String
    var notes: [String]? = nil
    var next: Turn? = nil
    var paying: Paying? = nil
    var fd: Deposit? = nil
}

/// Cards: the card a spend today has longest to pay for, and cards unused for 90 days or more
struct SmartCards: Decodable, Hashable {
    struct Free: Decodable, Hashable { let card: String; let bank: String; let last: String; let owner: String; let stmt: String; let due: String; let days: Int }
    struct Idle: Decodable, Hashable { let card: String; let bank: String; let last: String; let idle: Int; var feeOn: String? = nil; var fee: Double? = nil; var charged: String? = nil }
    let asOf: String; let line: String
    var notes: [String]? = nil
    var free: [Free]? = nil
    /// cards left out today (a statement today or tomorrow, or no recent statement)
    var unsure: Int? = nil
    var idle: [Idle]? = nil
}

extension Store {
    /// Insights' line for whoever is picked
    func smartInsight(_ p: Person) -> SmartInsight? { snap.smarts?.insights?.first { $0.o == p.id } }
}

/// One quiet line at the top of a tab, with at most two notes and a footnote under it. Nothing when there's no line.
struct TabSmartLine: View {
    let line: String
    var notes: [String] = []
    var foot: String? = nil
    var body: some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: "sparkles")
                .foregroundStyle(LinearGradient(colors: [Color.kosh, Color.sky], startPoint: .topLeading, endPoint: .bottomTrailing))
                .accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 5) {
                Text(line)
                    .foregroundStyle(.primary)
                    .fixedSize(horizontal: false, vertical: true)
                ForEach(Array(notes.prefix(2).enumerated()), id: \.offset) { _, n in
                    Text(n).font(.footnote).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                }
                if let foot, !foot.isEmpty {
                    Text(foot).font(.caption).foregroundStyle(.tertiary).fixedSize(horizontal: false, vertical: true)
                }
            }
            Spacer(minLength: 0)
        }
        .font(.subheadline)
        .privacySensitive()
        .padding(16)
        .background(LinearGradient(colors: [Color.kosh.opacity(0.07), Color.sky.opacity(0.05)], startPoint: .topLeading, endPoint: .bottomTrailing),
                    in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        .accessibilityElement(children: .combine)
    }
}
