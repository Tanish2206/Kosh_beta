import SwiftUI

// MARK: - Unlocking the family's statements
//
// A family's papers land in each other's inboxes, each locked with its holder's own details. kosh lists everyone it
// found (you, the household, and the people the locked mail is written to who aren't in the household yet), says
// how many locked statements are each person's and what's still missing, and opens each one with its holder's
// details first. Everything stays in this phone's Keychain (PasswordProfile).

/// the family, and the locked statements each person's details would open
struct FamilyUnlockView: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    var inSheet = false
    @State private var rows: [UnlockPerson] = []

    var body: some View {
        if inSheet { NavigationStack { list } } else { list }
    }

    var list: some View {
        let locked: Int = store.live?.lockedDocs.count ?? 0
        let household: [UnlockPerson] = rows.filter(\.inHousehold)
        let outside: [UnlockPerson] = rows.filter { !$0.inHousehold }
        return ObsidianForm {
            Section {
                Text("Banks, insurers and fund houses lock each person’s statements with that person’s own details, wherever the mail lands. Add them for everyone below. kosh works out whose each statement is from the name it’s written to, and opens it on this phone.")
                    .font(.subheadline).foregroundStyle(.secondary)
                if locked > 0 {
                    Label("\(locked) statement\(locked == 1 ? "" : "s") locked now", systemImage: "lock.fill")
                        .font(.subheadline).foregroundStyle(Color.orange)
                }
            }
            Section {
                ForEach(household) { r in link(r) }
            } header: { Text("Your family") }
            if !outside.isEmpty {
                Section {
                    ForEach(outside) { r in
                        link(r)
                            .swipeActions(edge: .trailing) {
                                Button("Not family", role: .destructive) { store.live?.notFamily(r.id); refresh() }
                                Button("Add") { store.live?.addUnlockPerson(r.id, full: r.name, rel: ""); refresh() }.tint(Color.kosh)
                            }
                    }
                } header: { Text("Also named on locked mail") } footer: {
                    Text("Not in your household yet. Add their details, or swipe to add them to the family or say they aren’t family.")
                }
            }
            if let live = store.live, (locked > 0 && PasswordProfile.anyUsable) || live.unlocking || !live.unlockNote.isEmpty {
                Section {
                    if live.unlocking {
                        HStack(spacing: 12) {
                            ProgressView().frame(width: 24)
                            VStack(alignment: .leading, spacing: 2) {
                                Text("Opening statements").font(.subheadline.weight(.semibold))
                                Text("This runs in the background. You can leave this page.").font(.footnote).foregroundStyle(.secondary)
                            }
                        }
                    } else if locked > 0 && PasswordProfile.anyUsable {
                        Button { live.openLockedInBackground() } label: { Label("Open them now", systemImage: "lock.open") }
                    }
                    if !live.unlocking && !live.unlockNote.isEmpty {
                        Text(live.unlockNote).font(.footnote).foregroundStyle(.secondary)
                    }
                }
                .onChange(of: live.unlocking) { _, on in if !on { refresh() } }
            }
            if locked > 0 {
                Section {
                    NavigationLink { StatementsSettings() } label: { Label("What each sender needs", systemImage: "list.bullet.rectangle") }
                } footer: {
                    Text("Some need a card number or a Customer ID, or a password you type once.")
                }
            }
            Section {} footer: {
                Text("Stored in this phone’s Keychain. Never sent anywhere, never shown in kosh.")
            }
        }
        .navigationTitle("Family details")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            if inSheet { ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } } }
        }
        .onAppear { refresh() }
    }

    func link(_ r: UnlockPerson) -> some View {
        NavigationLink {
            PasswordProfileSheet(inSheet: false, person: r.id, personName: r.name, inHousehold: r.inHousehold)
                .onDisappear { refresh() }
        } label: {
            UnlockPersonRow(person: r)
        }
    }

    func refresh() { rows = store.live?.unlockPeople() ?? [] }
}

struct UnlockPersonRow: View {
    let person: UnlockPerson
    var body: some View {
        let ready: Bool = person.missing.isEmpty
        HStack(spacing: 12) {
            Image(systemName: ready ? "checkmark.circle.fill" : "person.crop.circle.badge.plus")
                .font(.title3)
                .foregroundStyle(ready ? Color.green : Color.kosh)
            VStack(alignment: .leading, spacing: 2) {
                HStack(spacing: 6) {
                    Text(person.name).font(.body.weight(.medium)).lineLimit(1)
                    if !person.rel.isEmpty && person.rel != person.name {
                        Text(person.rel).font(.footnote).foregroundStyle(.secondary).lineLimit(1)
                    }
                }
                Text(detail).font(.footnote).foregroundStyle(.secondary).lineLimit(2)
            }
        }
        .accessibilityElement(children: .combine)
    }

    var detail: String {
        let locked: String = person.locked > 0 ? "\(person.locked) locked" : "None locked now"
        if person.missing.isEmpty { return locked + " · details in" }
        return locked + " · needs " + Words.list(person.missing)
    }
}

/// Home: statements are locked and someone's details are still missing
struct FamilyUnlockCard: View {
    @Environment(Store.self) private var store
    /// put away until this day (yyyy-MM-dd)
    @AppStorage("kosh.unlockCard.until") private var until = ""
    @State private var rows: [UnlockPerson] = []

    var body: some View {
        // (a locked statement whose mail printed nothing to pay waits quietly: no nag for it, CardShelf)
        let quiet: Set<String> = CardShelf.quietIDs(store.snap.stmts ?? [])
        let lockedAll: [Reading] = store.live?.lockedDocs ?? []
        let locked: Int = lockedAll.filter { (r: Reading) -> Bool in !quiet.contains(r.id) }.count
        // (whose locked statements they are; you only when some are yours, or no one's are known)
        let anyKnown: Bool = rows.contains { $0.locked > 0 }
        let need: [UnlockPerson] = rows.filter { !$0.missing.isEmpty && ($0.locked > 0 || ($0.id == "me" && !anyKnown)) }
        let away: Bool = !until.isEmpty && store.snap.today < until
        // (always something on screen, so the people are worked out once the card is reached, card or not)
        VStack(spacing: 0) {
            Color.clear.frame(height: 0)
            if locked > 0 && !need.isEmpty && !away {
                Button { store.betaSheet = .passwords } label: {
                    HStack(alignment: .top, spacing: 12) {
                        Image(systemName: "lock.fill").font(.title3).foregroundStyle(Color.orange)
                        VStack(alignment: .leading, spacing: 4) {
                            Text("\(locked) statement\(locked == 1 ? " is" : "s are") locked")
                                .font(.subheadline.weight(.semibold)).foregroundStyle(Color.primary)
                            Text(line(need))
                                .font(.subheadline).foregroundStyle(.secondary)
                                .fixedSize(horizontal: false, vertical: true)
                                .multilineTextAlignment(.leading)
                        }
                        Spacer(minLength: 4)
                        Image(systemName: "chevron.right").font(.footnote.weight(.semibold)).foregroundStyle(.tertiary).padding(.top, 4)
                    }
                    .padding(14)
                    .background(Color.orange.opacity(0.08), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                    .contentShape(Rectangle())
                }
                .buttonStyle(.press)
                .contextMenu {
                    Button("Remind me next week") { until = Day.add(store.snap.today, 7) }
                }
                .padding(.horizontal, 20)
                .padding(.top, 12)
            }
        }
        .task(id: "\(locked)|\(store.live?.people.count ?? 0)|\(store.snap.today)") { rows = store.live?.unlockPeople() ?? [] }
        .onChange(of: store.betaSheet == nil) { _, closed in if closed { rows = store.live?.unlockPeople() ?? [] } }
    }

    func firstName(_ s: String) -> String { s.split(separator: " ").first.map(String.init) ?? s }

    /// "Add Mohan’s details to open them." / "Add details for 3 people to open them: you, Mohan and Arjun."
    func line(_ need: [UnlockPerson]) -> String {
        if need.count == 1 {
            let whose: String = need[0].id == "me" ? "your" : need[0].name + "’s"
            return "Add " + whose + " details to open them."
        }
        let names: [String] = need.prefix(3).map { (p: UnlockPerson) -> String in p.id == "me" ? "you" : firstName(p.name) }
        let more: String = need.count > 3 ? " and more" : ""
        return "Add details for \(need.count) people to open them: " + Words.list(names) + more + "."
    }
}
