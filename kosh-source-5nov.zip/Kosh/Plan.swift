import SwiftUI
import MessageUI

// MARK: - Plan ahead (plan.js)
//
// Goals (an emergency fund, a joint goal), the salary split you set, a low balance before an auto-debit, and
// subscriptions (a trial about to turn into a charge, two services doing one job, how to cancel). The engine works
// them out (snap.plan); what you set lives in LiveSession.planJSON and goes to the engine as prof.plan.
// A low balance and a trial a day or two away are among what kosh noticed (sev 3), so they ring as the noticed do
// (Reminders); nothing here schedules notifications of its own.

// MARK: what plan.js adds to the snapshot

/// read leniently: a missing or odd field takes its default, so a newer or older engine never breaks the snapshot
private extension KeyedDecodingContainer {
    func planGet<T: Decodable>(_ key: Key, _ fallback: T) -> T { (try? decodeIfPresent(T.self, forKey: key)) ?? fallback }
}

struct PlanInfo: Decodable, Hashable {
    var goals: [GoalInfo] = []
    var suggest: GoalSuggest? = nil
    /// kosh's figure for an emergency fund, offered or not (the editor shows it for one you set)
    var emergency: GoalSuggest? = nil
    var split: SplitInfo? = nil
    var lowbal: [LowBalance] = []
    var subs: SubsInfo = SubsInfo()
    enum CodingKeys: String, CodingKey { case goals, suggest, emergency, split, lowbal, subs }
    init() {}
    init(from d: Decoder) throws {
        let c = try d.container(keyedBy: CodingKeys.self)
        goals = c.planGet(.goals, [])
        suggest = (try? c.decodeIfPresent(GoalSuggest.self, forKey: .suggest)) ?? nil
        emergency = (try? c.decodeIfPresent(GoalSuggest.self, forKey: .emergency)) ?? nil
        split = (try? c.decodeIfPresent(SplitInfo.self, forKey: .split)) ?? nil
        lowbal = c.planGet(.lowbal, [])
        subs = c.planGet(.subs, SubsInfo())
    }
}

/// a goal, worked out: saved against the target, what each month needs, how fast it's been growing
struct GoalInfo: Decodable, Hashable, Identifiable {
    var id = ""; var name = ""; var kind = "custom"; var target: Double = 0; var by = ""; var who = "all"
    var saved: Double = 0; var pct = 0; var left: Double = 0; var auto = false; var manual: Double = 0
    var sources: [GoalSource] = []
    var perMonth: Double = 0; var months: Double = 0
    /// done, on (pace), behind, late (the date went by), open (no date, or kosh can't tell)
    var state = "open"
    /// what it grew by a month lately, and whether that's the goal's own money ("goal") or its kinds' as a whole ("kind")
    var pace: Double = 0; var paceOf = ""
    /// with no date: the month it gets there at that pace
    var eta = ""
    var note = ""
    enum CodingKeys: String, CodingKey { case id, name, kind, target, by, who, saved, pct, left, auto, manual, sources, perMonth, months, state, pace, paceOf, eta, note }
    init(from d: Decoder) throws {
        let c = try d.container(keyedBy: CodingKeys.self)
        id = c.planGet(.id, ""); name = c.planGet(.name, ""); kind = c.planGet(.kind, "custom"); target = c.planGet(.target, 0.0)
        by = c.planGet(.by, ""); who = c.planGet(.who, "all"); saved = c.planGet(.saved, 0.0); pct = c.planGet(.pct, 0)
        left = c.planGet(.left, 0.0); auto = c.planGet(.auto, false); manual = c.planGet(.manual, 0.0); sources = c.planGet(.sources, [])
        perMonth = c.planGet(.perMonth, 0.0); months = c.planGet(.months, 0.0); state = c.planGet(.state, "open")
        pace = c.planGet(.pace, 0.0); paceOf = c.planGet(.paceOf, ""); eta = c.planGet(.eta, ""); note = c.planGet(.note, "")
    }
}

struct GoalSource: Decodable, Hashable {
    var ref = ""; var name = ""; var amt: Double = 0; var asOf = ""; var gone = false; var none = false
    /// its balance is more than a month old; what a whole kind left out ("Leaves out …"); other goals counting it too
    var old = false; var note = ""; var shared: [String] = []
    enum CodingKeys: String, CodingKey { case ref, name, amt, asOf, gone, none, old, note, shared }
    init(from d: Decoder) throws {
        let c = try d.container(keyedBy: CodingKeys.self)
        ref = c.planGet(.ref, ""); name = c.planGet(.name, ""); amt = c.planGet(.amt, 0.0); asOf = c.planGet(.asOf, "")
        gone = c.planGet(.gone, false); none = c.planGet(.none, false)
        old = c.planGet(.old, false); note = c.planGet(.note, ""); shared = c.planGet(.shared, [])
    }
}

/// kosh's emergency fund, before you've set one: six months of what usually goes out, and how it got there
struct GoalSuggest: Decodable, Hashable {
    var name = "Emergency fund"; var target: Double = 0; var months = 6; var monthly: Double = 0; var how = ""
    var saved: Double = 0; var pct = 0; var sources: [String] = []
    enum CodingKeys: String, CodingKey { case name, target, months, monthly, how, saved, pct, sources }
    init(from d: Decoder) throws {
        let c = try d.container(keyedBy: CodingKeys.self)
        name = c.planGet(.name, "Emergency fund"); target = c.planGet(.target, 0.0); months = c.planGet(.months, 6)
        monthly = c.planGet(.monthly, 0.0); how = c.planGet(.how, ""); saved = c.planGet(.saved, 0.0); pct = c.planGet(.pct, 0)
        sources = c.planGet(.sources, [])
    }
}

/// the split you set, laid against the latest salary
struct SplitInfo: Decodable, Hashable {
    var parts: [SplitPart] = []; var planned: Double = 0
    /// running, done, nosalary
    var state = "running"
    var amt: Double = 0; var date = ""; var from: [String] = []; var month = ""; var left: Double = 0
    /// show it on Home: the salary came in the last three weeks
    var open = false
    var note = ""
    enum CodingKeys: String, CodingKey { case parts, planned, state, amt, date, from, month, left, open, note }
    init(from d: Decoder) throws {
        let c = try d.container(keyedBy: CodingKeys.self)
        parts = c.planGet(.parts, []); planned = c.planGet(.planned, 0.0); state = c.planGet(.state, "running")
        amt = c.planGet(.amt, 0.0); date = c.planGet(.date, ""); from = c.planGet(.from, []); month = c.planGet(.month, "")
        left = c.planGet(.left, 0.0); open = c.planGet(.open, false); note = c.planGet(.note, "")
    }
}

struct SplitPart: Decodable, Hashable, Identifiable {
    var id = ""; var name = ""; var kind = "other"; var amt: Double = 0; var paid: Double = 0
    /// done, part, waiting; spending and over for the spending part
    var state = "waiting"
    var ids: [String] = []; var date = ""
    enum CodingKeys: String, CodingKey { case id, name, kind, amt, paid, state, ids, date }
    init(from d: Decoder) throws {
        let c = try d.container(keyedBy: CodingKeys.self)
        id = c.planGet(.id, ""); name = c.planGet(.name, ""); kind = c.planGet(.kind, "other"); amt = c.planGet(.amt, 0.0)
        paid = c.planGet(.paid, 0.0); state = c.planGet(.state, "waiting"); ids = c.planGet(.ids, []); date = c.planGet(.date, "")
    }
}

/// an account whose balance won't cover what's due from it in the next five days
struct LowBalance: Decodable, Hashable, Identifiable {
    struct Due: Decodable, Hashable {
        var name = ""; var date = ""; var amt: Double = 0
        enum CodingKeys: String, CodingKey { case name, date, amt }
        init(from d: Decoder) throws {
            let c = try d.container(keyedBy: CodingKeys.self)
            name = c.planGet(.name, ""); date = c.planGet(.date, ""); amt = c.planGet(.amt, 0.0)
        }
    }
    var acct = ""; var name = ""; var balance: Double = 0; var asOf = ""; var total: Double = 0; var short: Double = 0
    var first = ""; var due: [Due] = []
    /// the auto-debits alone are more than is there: something bounces (else a payment you make yourself is due)
    var bounce = false
    var id: String { acct }
    enum CodingKeys: String, CodingKey { case acct, name, balance, asOf, total, short, first, due, bounce }
    init(from d: Decoder) throws {
        let c = try d.container(keyedBy: CodingKeys.self)
        acct = c.planGet(.acct, ""); name = c.planGet(.name, ""); balance = c.planGet(.balance, 0.0); asOf = c.planGet(.asOf, "")
        total = c.planGet(.total, 0.0); short = c.planGet(.short, 0.0); first = c.planGet(.first, ""); due = c.planGet(.due, [])
        bounce = c.planGet(.bounce, false)
    }
}

struct SubsInfo: Decodable, Hashable {
    var subs: [SubInfo] = []; var overlaps: [SubOverlap] = []; var trials: [TrialInfo] = []
    enum CodingKeys: String, CodingKey { case subs, overlaps, trials }
    init() {}
    init(from d: Decoder) throws {
        let c = try d.container(keyedBy: CodingKeys.self)
        subs = c.planGet(.subs, []); overlaps = c.planGet(.overlaps, []); trials = c.planGet(.trials, [])
    }
}

/// how to cancel: where, the steps, and a mail drafted for you to send (kosh never sends it)
struct CancelHow: Decodable, Hashable {
    struct Mail: Decodable, Hashable {
        var to = ""; var subject = ""; var body = ""
        enum CodingKeys: String, CodingKey { case to, subject, body }
        init() {}
        init(from d: Decoder) throws {
            let c = try d.container(keyedBy: CodingKeys.self)
            to = c.planGet(.to, ""); subject = c.planGet(.subject, ""); body = c.planGet(.body, "")
        }
    }
    /// appstore, playstore, web, email
    var how = "email"
    var steps: [String] = []
    var url = ""
    var mail = Mail()
    enum CodingKeys: String, CodingKey { case how, steps, url, mail }
    init() {}
    init(from d: Decoder) throws {
        let c = try d.container(keyedBy: CodingKeys.self)
        how = c.planGet(.how, "email"); steps = c.planGet(.steps, []); url = c.planGet(.url, ""); mail = c.planGet(.mail, Mail())
    }
}

struct SubInfo: Decodable, Hashable, Identifiable {
    var id = ""; var name = ""; var payee = ""; var amount: Double = 0; var every = "month"
    var monthly: Double = 0; var yearly: Double = 0; var next = ""; var fam: [String] = []
    /// what a bundle includes ("YouTube Music"), and who bills it (appstore, playstore)
    var also = ""; var billed = ""
    var cancel = CancelHow()
    enum CodingKeys: String, CodingKey { case id, name, payee, amount, every, monthly, yearly, next, fam, also, billed, cancel }
    init(from d: Decoder) throws {
        let c = try d.container(keyedBy: CodingKeys.self)
        id = c.planGet(.id, ""); name = c.planGet(.name, ""); payee = c.planGet(.payee, ""); amount = c.planGet(.amount, 0.0)
        every = c.planGet(.every, "month"); monthly = c.planGet(.monthly, 0.0); yearly = c.planGet(.yearly, 0.0)
        next = c.planGet(.next, ""); fam = c.planGet(.fam, []); also = c.planGet(.also, ""); billed = c.planGet(.billed, "")
        cancel = c.planGet(.cancel, CancelHow())
    }
}

/// two or more subscriptions doing one job
struct SubOverlap: Decodable, Hashable, Identifiable {
    var fam = ""; var name = ""; var sev = 1; var ids: [String] = []; var names: [String] = []; var yearly: Double = 0
    var id: String { fam }
    enum CodingKeys: String, CodingKey { case fam, name, sev, ids, names, yearly }
    init(from d: Decoder) throws {
        let c = try d.container(keyedBy: CodingKeys.self)
        fam = c.planGet(.fam, ""); name = c.planGet(.name, ""); sev = c.planGet(.sev, 1); ids = c.planGet(.ids, [])
        names = c.planGet(.names, []); yearly = c.planGet(.yearly, 0.0)
    }
}

/// a free trial about to turn into a charge
struct TrialInfo: Decodable, Hashable, Identifiable {
    var id = ""; var name = ""; var amt: Double = 0; var every = ""; var date = ""
    var cancel = CancelHow()
    enum CodingKeys: String, CodingKey { case id, name, amt, every, date, cancel }
    init(from d: Decoder) throws {
        let c = try d.container(keyedBy: CodingKeys.self)
        id = c.planGet(.id, ""); name = c.planGet(.name, ""); amt = c.planGet(.amt, 0.0); every = c.planGet(.every, "")
        date = c.planGet(.date, ""); cancel = c.planGet(.cancel, CancelHow())
    }
}

// MARK: what you set (LiveSession.planJSON)

struct PlanConfig: Codable, Hashable {
    struct Goal: Codable, Hashable, Identifiable {
        var id: String = "g" + String(Int(Date().timeIntervalSince1970 * 1000))
        var name: String = ""
        /// emergency or custom
        var kind: String = "custom"
        /// 0: kosh's suggestion (an emergency fund)
        var target: Double = 0
        var by: String = ""
        /// all, or a person's id
        var who: String = "all"
        /// a:<account id>, h:<holding id>, c:<kind>
        var sources: [String] = []
        var manual: Double = 0
        var made: String = ""
        enum CodingKeys: String, CodingKey { case id, name, kind, target, by, who, sources, manual, made }
        init(name: String = "", kind: String = "custom", sources: [String] = [], made: String = "") {
            self.name = name; self.kind = kind; self.sources = sources; self.made = made
        }
        // what an older or newer kosh saved: any field missing takes its default
        init(from d: Decoder) throws {
            let c = try d.container(keyedBy: CodingKeys.self)
            id = c.planGet(.id, id); name = c.planGet(.name, ""); kind = c.planGet(.kind, "custom"); target = c.planGet(.target, 0.0)
            by = c.planGet(.by, ""); who = c.planGet(.who, "all"); sources = c.planGet(.sources, []); manual = c.planGet(.manual, 0.0)
            made = c.planGet(.made, "")
        }
    }
    struct Part: Codable, Hashable, Identifiable {
        var id: String = "p" + String(Int(Date().timeIntervalSince1970 * 1000)) + String(Int.random(in: 100...999))
        var name: String = ""
        /// sip, ppf, rent, savings, spending, other
        var kind: String = "sip"
        var amt: Double = 0
        var words: String = ""
        enum CodingKeys: String, CodingKey { case id, name, kind, amt, words }
        init(name: String = "", kind: String = "sip") { self.name = name; self.kind = kind }
        init(from d: Decoder) throws {
            let c = try d.container(keyedBy: CodingKeys.self)
            id = c.planGet(.id, id); name = c.planGet(.name, ""); kind = c.planGet(.kind, "other"); amt = c.planGet(.amt, 0.0)
            words = c.planGet(.words, "")
        }
    }
    struct Split: Codable, Hashable {
        var who: String = ""
        var parts: [Part] = []
        enum CodingKeys: String, CodingKey { case who, parts }
        init() {}
        init(from d: Decoder) throws {
            let c = try d.container(keyedBy: CodingKeys.self)
            who = c.planGet(.who, ""); parts = c.planGet(.parts, [])
        }
    }
    var goals: [Goal] = []
    var split: Split = Split()
    var hideSuggest: Bool = false
    /// a free trial you said you cancelled, and the day you said it (its next reminder brings it back)
    var cancelled: [String: String] = [:]

    enum CodingKeys: String, CodingKey { case goals, split, hideSuggest, cancelled }
    init() {}
    init(from d: Decoder) throws {
        let c = try d.container(keyedBy: CodingKeys.self)
        goals = c.planGet(.goals, []); split = c.planGet(.split, Split()); hideSuggest = c.planGet(.hideSuggest, false)
        cancelled = c.planGet(.cancelled, [:])
    }

    /// what's on this phone now
    static func load(_ store: Store) -> PlanConfig {
        guard let raw = store.live?.planJSON, !raw.isEmpty, let d = raw.data(using: .utf8),
              let c = try? JSONDecoder().decode(PlanConfig.self, from: d) else { return PlanConfig() }
        return c
    }
    /// written back; the engine works the plan out again (LiveSession.planJSON's didSet rebuilds)
    func save(_ store: Store) {
        guard let live = store.live, let d = try? JSONEncoder().encode(self), let s = String(data: d, encoding: .utf8) else { return }
        if live.planJSON != s { live.planJSON = s }
    }
}

// MARK: the look of the plan's pieces

enum PlanInk {
    static func state(_ s: String) -> Color {
        switch s {
        case "done", "on": return Color.green
        case "behind": return Color.orange
        case "late": return Color.red
        default: return Color.kosh
        }
    }
    static func sym(_ kind: String) -> String {
        switch kind {
        case "sip": return "chart.line.uptrend.xyaxis"
        case "ppf": return "building.columns"
        case "rent": return "house"
        case "savings": return "arrow.down.to.line"
        case "spending": return "cart"
        default: return "circle.dashed"
        }
    }
    static func kindName(_ kind: String) -> String {
        switch kind {
        case "sip": return "SIPs and investments"
        case "ppf": return "PPF"
        case "rent": return "Rent"
        case "savings": return "Savings"
        case "spending": return "Spending"
        default: return "Something else"
        }
    }
    static let kinds: [String] = ["sip", "ppf", "rent", "savings", "spending", "other"]
    /// "a month", "every six months": how often a charge comes, as plan.js says it
    static func every(_ e: String) -> String {
        switch e {
        case "month": return "a month"
        case "year": return "a year"
        case "quarter": return "a quarter"
        case "week": return "a week"
        case "six months": return "every six months"
        default: return ""
        }
    }
    /// "Some of this money also counts toward …" in the goal's own words: the goals sharing a source
    static func sharedLine(_ names: [String]) -> String {
        guard let last = names.last else { return "" }
        let list: String = names.count == 1 ? last : names.dropLast().joined(separator: ", ") + " and " + last
        return "Also counted in " + list
    }
}

/// a ring that fills to a share, with what sits in its middle
struct PlanRing<Inner: View>: View {
    let share: Double
    let color: Color
    var line: CGFloat = 5
    @ViewBuilder let inner: Inner
    var body: some View {
        let s: Double = min(1, max(0, share))
        ZStack {
            Circle().stroke(color.opacity(0.15), lineWidth: line)
            Circle()
                .trim(from: 0, to: CGFloat(s))
                .stroke(color, style: StrokeStyle(lineWidth: line, lineCap: .round))
                .rotationEffect(.degrees(-90))
            inner
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(String(Int((s * 100).rounded())) + " percent")
    }
}

/// "On pace", "Behind", "Done", "Date passed", or what each month needs: a goal's state in a small capsule
struct GoalStateChip: View {
    let g: GoalInfo
    var body: some View {
        let text: String = Self.words(g)
        let tint: Color = PlanInk.state(g.state)
        if !text.isEmpty {
            Text(text)
                .font(.caption.weight(.semibold))
                .foregroundStyle(tint)
                .padding(.horizontal, 8).padding(.vertical, 4)
                .background(tint.opacity(0.12), in: Capsule())
                .privacySensitive(g.state == "open" && g.perMonth > 0)
        }
    }
    static func words(_ g: GoalInfo) -> String {
        switch g.state {
        case "done": return "Done"
        case "on": return "On pace"
        case "behind": return "Behind"
        case "late": return "Date passed"
        default:
            // (under a month to go, what's left is what it needs)
            if g.perMonth > 0 && g.months < 1 { return Fmt.short(g.perMonth) + " to go" }
            if g.perMonth > 0 { return Fmt.short(g.perMonth) + " a month" }
            if !g.eta.isEmpty { return "About " + Day.fmt(g.eta + "-01", "MMM yyyy") }
            return ""
        }
    }
}

// MARK: Home: the salary split while the month is young, then your goals (Home's "goals" section)

/// what a plan sheet shows
enum PlanSheet: Identifiable {
    case goals, goal(String), editGoal(PlanConfig.Goal?), split, subs, cancel(String)
    var id: String {
        switch self {
        case .goals: return "goals"
        case .goal(let g): return "goal|" + g
        case .editGoal(let g): return "edit|" + (g?.id ?? "new")
        case .split: return "split"
        case .subs: return "subs"
        case .cancel(let s): return "cancel|" + s
        }
    }
}

/// a plan sheet's own screen, the same wherever it opens from; lists and details sit in their own stack, editors bring theirs
struct PlanSheetView: View {
    let sheet: PlanSheet
    var body: some View {
        Group {
            switch sheet {
            case .goals: NavigationStack { GoalsList(inSheet: true) }
            case .goal(let id): NavigationStack { GoalDetail(id: id, inSheet: true) }
            case .editGoal(let g): GoalEditor(original: g)
            case .split: SplitEditor()
            case .subs: NavigationStack { SubscriptionsList(inSheet: true) }
            case .cancel(let id): NavigationStack { CancelDetail(id: id, inSheet: true) }
            }
        }
        // Ask kosh from anywhere in it (a list's pushed detail too) closes the whole plan sheet first
        .closesForAsk()
    }
}

struct GoalsHomeCard: View {
    @Environment(Store.self) private var store
    @State private var sheet: PlanSheet?

    var body: some View {
        let plan: PlanInfo = store.snap.plan ?? PlanInfo()
        let split: SplitInfo? = plan.split.flatMap { $0.open && $0.state != "nosalary" ? $0 : nil }
        let suggest: GoalSuggest? = store.live != nil ? plan.suggest : nil
        if split != nil || !plan.goals.isEmpty || suggest != nil {
            HomeBlock {
                if let split { SplitCard(split: split) { sheet = .split } }
                if !plan.goals.isEmpty {
                    SectionHeader(title: "Goals", action: "All") { sheet = .goals }
                    VStack(spacing: 0) {
                        ForEach(Array(plan.goals.prefix(3).enumerated()), id: \.element.id) { i, g in
                            if i > 0 { Divider().padding(.leading, 58) }
                            Button { sheet = .goal(g.id) } label: { GoalRow(g: g) }.buttonStyle(.press)
                        }
                    }
                } else if let suggest {
                    SuggestCard(s: suggest) {
                        sheet = .editGoal(PlanConfig.Goal(name: suggest.name, kind: "emergency", sources: suggest.sources, made: store.snap.today))
                    }
                }
            }
            .sheet(item: $sheet) { s in PlanSheetView(sheet: s).environment(store) }
        }
    }
}

/// one goal in a list: its ring, what's saved of what it needs, and how it's going
struct GoalRow: View {
    let g: GoalInfo
    var body: some View {
        let line: String = g.target > 0 ? Fmt.rupees(g.saved) + " of " + Fmt.rupees(g.target) : Fmt.rupees(g.saved) + " so far"
        HStack(spacing: 14) {
            PlanRing(share: Double(g.pct) / 100, color: PlanInk.state(g.state)) {
                if g.state == "done" {
                    Image(systemName: "checkmark").font(.system(size: 14, weight: .bold)).foregroundStyle(Color.green)
                } else {
                    Text(String(g.pct) + "%").font(.system(size: 11, weight: .bold, design: .rounded)).monospacedDigit()
                }
            }
            .frame(width: 44, height: 44)
            VStack(alignment: .leading, spacing: 2) {
                Text(g.name).font(.body.weight(.semibold)).foregroundStyle(Color.primary).lineLimit(1)
                Text(line).font(.subheadline).foregroundStyle(.secondary).monospacedDigit().privacySensitive()
            }
            Spacer(minLength: 8)
            GoalStateChip(g: g)
        }
        .padding(.vertical, 10)
        .contentShape(Rectangle())
        .accessibilityElement(children: .combine)
    }
}

/// kosh's emergency fund, offered once there's spending to measure it by
struct SuggestCard: View {
    @Environment(Store.self) private var store
    let s: GoalSuggest
    let setUp: () -> Void
    var body: some View {
        let pct: Int = min(100, s.pct)
        let covered: Bool = s.pct >= 100
        let lead: String = covered
            ? "Your bank balances already cover six months of what usually goes out. Make it a goal to keep an eye on it."
            : "Money set aside for a job loss, a hospital bill or a repair, without touching your investments."
        VStack(alignment: .leading, spacing: 14) {
            HStack(alignment: .top, spacing: 14) {
                IconTile(symbol: "umbrella.fill", color: Color.kosh, size: 44)
                VStack(alignment: .leading, spacing: 4) {
                    Text("An emergency fund").font(.headline)
                    Text(lead).font(.subheadline).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                }
                Spacer(minLength: 0)
                Button {
                    var c = PlanConfig.load(store)
                    c.hideSuggest = true
                    c.save(store)
                } label: {
                    Image(systemName: "xmark").font(.footnote.weight(.bold)).foregroundStyle(.secondary)
                        .frame(width: 30, height: 30).background(Color.primary.opacity(0.06), in: Circle())
                }
                .buttonStyle(.press)
                .accessibilityLabel("Not now")
            }
            VStack(alignment: .leading, spacing: 6) {
                HStack(alignment: .firstTextBaseline) {
                    Text(Fmt.words(s.target)).font(.system(.title, design: .rounded, weight: .bold)).privacySensitive()
                    Text("· six months").font(.subheadline).foregroundStyle(.secondary)
                    Spacer()
                    Text(String(pct) + "% in your bank").font(.caption.weight(.semibold)).foregroundStyle(.secondary).privacySensitive()
                }
                PlanBar(share: Double(pct) / 100, tint: Color.kosh)
                Text(s.how).font(.footnote).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true).privacySensitive()
            }
            Button(action: setUp) {
                Text("Set it up").font(.body.weight(.semibold)).frame(maxWidth: .infinity)
            }
            .buttonStyle(.glassProminent)
            .controlSize(.large)
        }
        .padding(16)
        .background(Color.surface, in: RoundedRectangle(cornerRadius: 26, style: .continuous))
    }
}

/// a thin bar filled to a share
struct PlanBar: View {
    let share: Double
    let tint: Color
    var height: CGFloat = 6
    var body: some View {
        GeometryReader { geo in
            let w: CGFloat = geo.size.width * CGFloat(min(1, max(0, share)))
            ZStack(alignment: .leading) {
                Capsule().fill(tint.opacity(0.14))
                if share > 0 { Capsule().fill(tint).frame(width: max(height, w)) }
            }
        }
        .frame(height: height)
        .accessibilityHidden(true)
    }
}

// MARK: Goals

/// every goal, kosh's suggestion, and a new one
struct GoalsList: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    var inSheet = false
    @State private var sheet: PlanSheet?
    var body: some View {
        let plan: PlanInfo = store.snap.plan ?? PlanInfo()
        List {
            if plan.goals.isEmpty {
                Section {
                    VStack(alignment: .leading, spacing: 8) {
                        Image(systemName: "target").font(.largeTitle).foregroundStyle(Color.kosh)
                        Text("Something to work towards").font(.headline)
                        Text("A goal adds up the accounts and investments you pick, says what each month needs to get there by a date, and how fast it has been growing.")
                            .font(.subheadline).foregroundStyle(.secondary)
                    }
                    .padding(.vertical, 8)
                }
            } else {
                Section {
                    ForEach(plan.goals) { g in
                        NavigationLink { GoalDetail(id: g.id) } label: { GoalRow(g: g) }
                    }
                }
            }
            if let s = plan.suggest, store.live != nil {
                Section {
                    Button {
                        sheet = .editGoal(PlanConfig.Goal(name: s.name, kind: "emergency", sources: s.sources, made: store.snap.today))
                    } label: {
                        HStack(spacing: 12) {
                            IconTile(symbol: "umbrella.fill", color: Color.kosh, size: 30)
                            VStack(alignment: .leading, spacing: 2) {
                                Text("An emergency fund").foregroundStyle(Color.primary)
                                Text(Fmt.words(s.target) + ", six months of what usually goes out").font(.caption).foregroundStyle(.secondary).privacySensitive()
                            }
                            Spacer()
                            Image(systemName: "plus.circle.fill").foregroundStyle(Color.kosh)
                        }
                    }
                } header: { Text("kosh suggests") }
            }
            if store.live != nil {
                Section {
                    Button { sheet = .editGoal(nil) } label: { Label("New goal", systemImage: "plus") }
                }
            }
        }
        .listStyle(.insetGrouped)
        .navigationTitle("Goals")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar { ToolbarItem(placement: .confirmationAction) { if inSheet { Button("Done") { dismiss() } } } }
        .sheet(item: $sheet) { s in PlanSheetView(sheet: s).environment(store) }
    }
}

/// one goal: how far, what it needs, how it's going, and what it counts
struct GoalDetail: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    @Environment(\.askKosh) private var askKosh
    let id: String
    var inSheet = false
    @State private var editing: PlanSheet?
    /// the goal as you set it, decoded once and again only when the plan itself changes (not on every redraw)
    @State private var spec: PlanConfig.Goal?
    var body: some View {
        let g: GoalInfo? = store.snap.plan?.goals.first { $0.id == id }
        Group {
            if let g {
                List {
                    Section { GoalHero(g: g).listRowBackground(Color.clear) }
                    if !g.note.isEmpty {
                        Section { Text(g.note).font(.subheadline).fixedSize(horizontal: false, vertical: true).privacySensitive() }
                    }
                    GoalFigures(g: g)
                    Section {
                        ForEach(g.sources, id: \.ref) { s in GoalSourceRow(s: s) }
                        if g.manual > 0 { LabeledContent("Elsewhere, as you said", value: Fmt.rupees(g.manual)).privacySensitive() }
                    } header: { Text("What it counts") }
                    Section {
                        Button {
                            let seed: String = "How is my " + g.name + " goal going, and what would get me there sooner?"
                            // every sheet it sits in goes (a pushed detail's own dismiss only goes back to the list), then Ask opens
                            if let askKosh { askKosh(seed) } else { store.openAsk(seed) }
                        } label: { Label("Ask kosh about it", systemImage: "sparkles") }
                    }
                }
                .listStyle(.insetGrouped)
                .navigationTitle(g.name)
            } else {
                ContentUnavailableView("This goal is gone", systemImage: "target", description: Text("It was taken away, or kosh is still working it out."))
            }
        }
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .primaryAction) { if let spec { Button("Edit") { editing = .editGoal(spec) } } }
            ToolbarItem(placement: .confirmationAction) { if inSheet { Button("Done") { dismiss() } } }
        }
        .sheet(item: $editing) { s in PlanSheetView(sheet: s).environment(store) }
        .onAppear(perform: loadSpec)
        .onChange(of: store.live?.planJSON ?? "") { loadSpec() }
    }
    private func loadSpec() {
        spec = store.live != nil ? PlanConfig.load(store).goals.first { $0.id == id } : nil
    }
}

/// a goal's ring, what's saved of what it needs, and its state
struct GoalHero: View {
    let g: GoalInfo
    var body: some View {
        let of: String = g.target > 0 ? "saved of " + Fmt.rupees(g.target) + (g.auto ? ", kosh’s figure" : "") : "saved so far"
        VStack(spacing: 14) {
            PlanRing(share: Double(g.pct) / 100, color: PlanInk.state(g.state), line: 10) {
                VStack(spacing: 0) {
                    Text(String(g.pct) + "%").font(.system(size: 30, weight: .bold, design: .rounded)).monospacedDigit()
                    Text(g.state == "done" ? "there" : "of the way").font(.caption).foregroundStyle(.secondary)
                }
            }
            .frame(width: 140, height: 140)
            .padding(.top, 6)
            VStack(spacing: 4) {
                Text(Fmt.rupees(g.saved)).font(.system(.title, design: .rounded, weight: .bold)).monospacedDigit().privacySensitive()
                Text(of).font(.subheadline).foregroundStyle(.secondary).privacySensitive()
            }
            GoalStateChip(g: g)
        }
        .frame(maxWidth: .infinity)
    }
}

/// what each month needs, by when, how fast it's growing, what's left
struct GoalFigures: View {
    let g: GoalInfo
    var body: some View {
        let paceTitle: String = g.paceOf == "goal" ? "Growing lately" : "Money of these kinds, lately"
        let pace: String = (g.pace < 0 ? "−" : "") + Fmt.rupees(abs(g.pace)) + " a month"
        if g.perMonth > 0 || !g.by.isEmpty || g.pace != 0 || g.left > 0 {
            Section {
                if g.perMonth > 0 && g.months >= 1 { LabeledContent("Each month", value: Fmt.rupees(g.perMonth)).privacySensitive() }
                if !g.by.isEmpty { LabeledContent("By", value: Day.fmt(g.by, "d MMMM yyyy")) }
                if g.pace != 0 { LabeledContent(paceTitle, value: pace).privacySensitive() }
                if g.left > 0 { LabeledContent("Still to go", value: Fmt.rupees(g.left)).privacySensitive() }
            } footer: {
                if g.paceOf == "kind" && g.pace != 0 { Text("How the kinds this goal counts grew as a whole: kosh can’t tell how much of it is for this goal.") }
            }
        }
    }
}

struct GoalSourceRow: View {
    let s: GoalSource
    var body: some View {
        let when: String = s.asOf.isEmpty ? "" : s.old ? "Balance from " + Day.fmt(s.asOf, "d MMM yyyy") + "; it may have changed" : "as of " + Day.fmt(s.asOf, "d MMM")
        let sub: String = s.gone ? "kosh can’t see it any more" : s.none ? "No balance from its mail yet" : when
        HStack {
            VStack(alignment: .leading, spacing: 1) {
                Text(s.name).foregroundStyle(s.gone ? Color.secondary : Color.primary)
                if !sub.isEmpty { Text(sub).font(.caption).foregroundStyle(s.old ? Color.orange : Color.secondary) }
                if !s.note.isEmpty { Text(s.note).font(.caption).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true) }
                if !s.shared.isEmpty { Text(PlanInk.sharedLine(s.shared)).font(.caption).foregroundStyle(.secondary) }
            }
            Spacer()
            Text(Fmt.rupees(s.amt)).monospacedDigit().foregroundStyle(.secondary).privacySensitive()
        }
        .accessibilityElement(children: .combine)
    }
}

/// a goal set or changed: what it's called, how much, by when, whose, and what counts towards it
struct GoalEditor: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    let original: PlanConfig.Goal?
    @State private var g = PlanConfig.Goal()
    @State private var target = ""
    @State private var manual = ""
    @State private var dated = false
    @State private var byDate = Date()
    @State private var loaded = false
    @State private var confirmDelete = false
    /// the goals already saved, read once when the editor opens (not decoded again on every keystroke)
    @State private var savedIDs: Set<String> = []

    struct Kind: Identifiable { let id: String; let title: String }

    var body: some View {
        let isNew: Bool = !savedIDs.contains(g.id)
        // kosh's figure, even once your emergency fund exists (the suggestion itself is offered only before)
        let suggest: GoalSuggest? = store.snap.plan?.emergency ?? store.snap.plan?.suggest
        let figure: Double = suggest?.target ?? 0
        let accounts: [Account] = store.snap.accounts.filter { $0.balance != nil }
        let useKosh: Bool = g.kind == "emergency" && target.isEmpty
        let canSave: Bool = !g.name.trimmingCharacters(in: .whitespaces).isEmpty && (useKosh || (Double(target.filter { $0.isNumber }) ?? 0) > 0)
        NavigationStack {
            Form {
                Section {
                    TextField("A name, like New car or Goa trip", text: $g.name)
                        .textInputAutocapitalization(.sentences)
                }
                Section {
                    if g.kind == "emergency" {
                        Toggle("Use kosh’s figure", isOn: Binding(get: { target.isEmpty }, set: { on in target = on ? "" : (figure > 0 ? String(Int(safe: figure.rounded())) : "") }))
                    }
                    if !useKosh {
                        HStack {
                            Text("₹").foregroundStyle(.secondary)
                            TextField("How much it needs", text: $target).keyboardType(.numberPad)
                        }
                    }
                    Toggle("By a date", isOn: $dated.animation())
                    if dated {
                        DatePicker("By", selection: $byDate, in: Date()..., displayedComponents: .date)
                    }
                } header: { Text("The goal") } footer: {
                    if useKosh, let s = suggest { Text(s.how).privacySensitive() }
                }
                if store.snap.people.count > 1 {
                    Section {
                        Picker("Whose", selection: $g.who) {
                            Text("The household").tag("all")
                            ForEach(store.snap.people) { p in Text(p.name).tag(p.id) }
                        }
                    } footer: { Text("One person’s goal counts only their money.") }
                }
                Section {
                    Toggle("Every bank account", isOn: has("c:bank"))
                    if !g.sources.contains("c:bank") {
                        ForEach(accounts) { a in
                            Toggle(isOn: has("a:" + a.id)) { AccountToggleLabel(a: a) }
                        }
                    }
                    ForEach(kinds) { k in Toggle(k.title, isOn: has("c:" + k.id)) }
                    HStack {
                        Text("Elsewhere")
                        Spacer()
                        Text("₹").foregroundStyle(.secondary)
                        TextField("0", text: $manual).keyboardType(.numberPad).multilineTextAlignment(.trailing).frame(width: 110)
                    }
                } header: { Text("What counts towards it") } footer: {
                    Text("Accounts at their latest balance, investments at their latest value. Elsewhere is money kosh can’t see, like cash or gold at home; it stays as you say until you change it.")
                }
                if !isNew {
                    Section { Button("Delete goal", role: .destructive) { confirmDelete = true } }
                }
            }
            .navigationTitle(isNew ? "New goal" : "Edit goal")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) { Button("Save") { save(); dismiss() }.disabled(!canSave) }
            }
            .confirmationDialog("Delete this goal?", isPresented: $confirmDelete, titleVisibility: .visible) {
                Button("Delete", role: .destructive) {
                    var c = PlanConfig.load(store)
                    c.goals.removeAll { $0.id == g.id }
                    c.save(store)
                    dismiss()
                }
            } message: { Text("Only the goal goes; your accounts and investments stay as they are.") }
            .onAppear(perform: load)
        }
    }

    /// the kinds of investment the household has, to count whole
    private var kinds: [Kind] {
        let have: Set<String> = Set(store.snap.hold.map(\.cls))
        let all: [Kind] = [Kind(id: "dep", title: "Every deposit (FDs, RDs, bonds)"), Kind(id: "mf", title: "Every mutual fund"),
                           Kind(id: "stk", title: "Every share"), Kind(id: "ret", title: "EPF, PPF and NPS"), Kind(id: "gold", title: "Gold")]
        return all.filter { have.contains($0.id) }
    }
    private func has(_ ref: String) -> Binding<Bool> {
        Binding(get: { g.sources.contains(ref) }, set: { on in
            if on {
                if !g.sources.contains(ref) { g.sources.append(ref) }
                // every account counted: the single ones are in it already
                if ref == "c:bank" { g.sources.removeAll { $0.hasPrefix("a:") } }
            } else {
                g.sources.removeAll { $0 == ref }
            }
        })
    }
    private func load() {
        guard !loaded else { return }
        loaded = true
        savedIDs = Set(PlanConfig.load(store).goals.map(\.id))
        // (a new goal counts nothing until you pick: all your bank money counted in every goal would count it twice)
        g = original ?? PlanConfig.Goal(name: "", kind: "custom", sources: [], made: store.snap.today)
        if g.made.isEmpty { g.made = store.snap.today }
        target = g.target > 0 ? String(Int(safe: g.target.rounded())) : ""
        manual = g.manual > 0 ? String(Int(safe: g.manual.rounded())) : ""
        dated = !g.by.isEmpty
        byDate = dated ? Day.date(g.by) : (Day.cal.date(byAdding: .year, value: 1, to: Date()) ?? Date())
    }
    private func save() {
        var c = PlanConfig.load(store)
        var out: PlanConfig.Goal = g
        out.name = g.name.trimmingCharacters(in: .whitespaces)
        out.target = TypedAmount.whole(target) ?? 0
        out.manual = TypedAmount.whole(manual) ?? 0
        out.by = dated ? Day.iso(byDate) : ""
        if let i = c.goals.firstIndex(where: { $0.id == out.id }) { c.goals[i] = out } else { c.goals.append(out) }
        c.save(store)
    }
}

struct AccountToggleLabel: View {
    let a: Account
    var body: some View {
        let name: String = a.last.isEmpty ? a.name : a.name + " ••" + String(a.last.suffix(4))
        VStack(alignment: .leading, spacing: 1) {
            Text(name)
            Text(Fmt.rupees(a.balance ?? 0)).font(.caption).foregroundStyle(.secondary).privacySensitive()
        }
    }
}

// MARK: The salary split

/// this month's salary and where it's going, part by part, while the month is young
struct SplitCard: View {
    @Environment(Store.self) private var store
    let split: SplitInfo
    let edit: () -> Void
    var body: some View {
        // (a salary paid on the last working day of the month before is "your latest", not that month's)
        let thisMonth: Bool = !split.date.isEmpty && split.date.prefix(7) == store.snap.today.prefix(7)
        let title: String = thisMonth ? "This month’s salary" : "Your latest salary"
        let leftLine: String = Fmt.rupees(split.left) + " of it isn’t in the plan."
        VStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .firstTextBaseline) {
                VStack(alignment: .leading, spacing: 2) {
                    Text(title).font(.headline)
                    Text("Came in " + Day.fmt(split.date, "d MMM")).font(.subheadline).foregroundStyle(.secondary)
                }
                Spacer()
                Text(Fmt.rupees(split.amt)).font(.system(.title2, design: .rounded, weight: .bold)).monospacedDigit().privacySensitive()
            }
            VStack(spacing: 0) {
                ForEach(Array(split.parts.enumerated()), id: \.element.id) { i, p in
                    if i > 0 { Divider().padding(.leading, 40) }
                    SplitRow(p: p)
                }
            }
            if split.left > 0 { Text(leftLine).font(.footnote).foregroundStyle(.secondary).privacySensitive() }
            if !split.note.isEmpty {
                Text(split.note).font(.footnote).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true).privacySensitive()
            }
            Button(action: edit) { Text("Change the split").font(.subheadline.weight(.semibold)) }
                .buttonStyle(.glass)
        }
        .padding(16)
        .background(Color.surface, in: RoundedRectangle(cornerRadius: 26, style: .continuous))
    }
}

struct SplitRow: View {
    let p: SplitPart
    var body: some View {
        let spending: Bool = p.kind == "spending"
        let share: Double = p.amt > 0 ? min(1, p.paid / p.amt) : 0
        let tint: Color = p.state == "done" ? Color.green : p.state == "over" ? Color.red : Color.kosh
        let name: String = p.name.isEmpty ? PlanInk.kindName(p.kind) : p.name
        HStack(spacing: 12) {
            ZStack {
                Circle().fill(tint.opacity(0.12))
                Image(systemName: p.state == "done" ? "checkmark" : PlanInk.sym(p.kind))
                    .font(.system(size: 13, weight: .semibold)).foregroundStyle(tint)
            }
            .frame(width: 28, height: 28)
            VStack(alignment: .leading, spacing: 5) {
                HStack {
                    Text(name).font(.subheadline.weight(.semibold))
                    Spacer()
                    Text(stateText).font(.subheadline).foregroundStyle(.secondary).monospacedDigit().privacySensitive()
                }
                if !spending || p.paid > 0 { PlanBar(share: share, tint: tint, height: 4) }
            }
        }
        .padding(.vertical, 9)
        .accessibilityElement(children: .combine)
    }
    private var stateText: String {
        switch p.state {
        case "done": return Fmt.rupees(p.paid)
        case "part", "spending": return Fmt.rupees(p.paid) + " of " + Fmt.rupees(p.amt)
        case "over": return Fmt.rupees(p.paid - p.amt) + " over"
        default: return "Not yet · " + Fmt.rupees(p.amt)
        }
    }
}

/// the split, set once: each part, how much, and words to find it by
struct SplitEditor: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    @State private var split = PlanConfig.Split()
    @State private var amounts: [String: String] = [:]
    @State private var loaded = false
    /// the field being typed in: "<part id>|name", "|amt" or "|words"
    @FocusState private var focus: String?

    var body: some View {
        let salary: SplitInfo? = store.snap.plan?.split
        NavigationStack {
            Form {
                Section {
                    Text("Say once how your salary is shared out. Each month, when it comes in, kosh ticks each part off as the money goes.")
                        .font(.subheadline).foregroundStyle(.secondary)
                    if let s = salary, s.amt > 0 { LabeledContent("Latest salary", value: Fmt.rupees(s.amt)).privacySensitive() }
                }
                if store.snap.people.count > 1 {
                    Section {
                        Picker("Whose salary", selection: $split.who) {
                            Text("Anyone’s").tag("")
                            ForEach(store.snap.people) { p in Text(p.name).tag(p.id) }
                        }
                    }
                }
                ForEach(split.parts.map(\.id), id: \.self) { pid in
                    Section {
                        TextField(PlanInk.kindName(field(pid, \.kind, "sip")), text: text(pid, \.name))
                            .focused($focus, equals: pid + "|name")
                        Picker("Kind", selection: text(pid, \.kind)) {
                            ForEach(PlanInk.kinds, id: \.self) { k in Label(PlanInk.kindName(k), systemImage: PlanInk.sym(k)).tag(k) }
                        }
                        HStack {
                            Text("₹").foregroundStyle(.secondary)
                            TextField("Amount", text: amountBinding(pid)).keyboardType(.numberPad)
                                .focused($focus, equals: pid + "|amt")
                        }
                        if field(pid, \.kind, "sip") != "spending" {
                            TextField("Words in the payee, if kosh should look for them", text: text(pid, \.words))
                                .textInputAutocapitalization(.never)
                                .font(.subheadline)
                                .focused($focus, equals: pid + "|words")
                        }
                        Button("Remove this part", role: .destructive) { remove(pid) }.font(.subheadline)
                    }
                }
                Section {
                    Menu {
                        ForEach(PlanInk.kinds, id: \.self) { k in
                            Button { add(k) } label: { Label(PlanInk.kindName(k), systemImage: PlanInk.sym(k)) }
                        }
                    } label: { Label("Add a part", systemImage: "plus") }
                } footer: {
                    Text("SIPs are found among your investments, PPF by its name, rent by its category, savings as money to your own account or an FD. Words you give find a part by its payee, like “tuition” or a fund’s name.")
                }
            }
            .navigationTitle("Salary split")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) { Button("Save") { save(); dismiss() } }
            }
            .onAppear(perform: load)
        }
    }
    private func amountBinding(_ id: String) -> Binding<String> {
        Binding(get: { amounts[id] ?? "" }, set: { amounts[id] = $0 })
    }
    /// one part's field, found by its id each time (a part removed meanwhile reads as the fallback and takes no writes)
    private func field(_ id: String, _ key: KeyPath<PlanConfig.Part, String>, _ fallback: String) -> String {
        split.parts.first { $0.id == id }?[keyPath: key] ?? fallback
    }
    private func text(_ id: String, _ key: WritableKeyPath<PlanConfig.Part, String>) -> Binding<String> {
        Binding(get: { split.parts.first { $0.id == id }?[keyPath: key] ?? "" },
                set: { v in if let i = split.parts.firstIndex(where: { $0.id == id }) { split.parts[i][keyPath: key] = v } })
    }
    private func add(_ kind: String) { withAnimation(Motion.open) { split.parts.append(PlanConfig.Part(name: "", kind: kind)) } }
    /// the field being typed in lets go first, then the part goes on the next turn (a focused field whose part
    /// vanishes under it would write into nothing, or into the part that slid into its place)
    private func remove(_ id: String) {
        focus = nil
        DispatchQueue.main.async {
            withAnimation(Motion.open) { split.parts.removeAll { $0.id == id } }
            amounts[id] = nil
        }
    }
    private func load() {
        guard !loaded else { return }
        loaded = true
        split = PlanConfig.load(store).split
        for p in split.parts where p.amt > 0 { amounts[p.id] = String(Int(safe: p.amt.rounded())) }
        if split.parts.isEmpty { split.parts = [PlanConfig.Part(name: "", kind: "sip"), PlanConfig.Part(name: "", kind: "spending")] }
    }
    private func save() {
        var c = PlanConfig.load(store)
        var out: PlanConfig.Split = split
        out.parts = split.parts.map { p -> PlanConfig.Part in
            var q: PlanConfig.Part = p
            q.amt = TypedAmount.whole(amounts[p.id] ?? "") ?? 0
            q.name = p.name.trimmingCharacters(in: .whitespaces)
            return q
        }.filter { $0.amt > 0 }
        c.split = out
        c.save(store)
    }
}

// MARK: Subscriptions

/// every subscription, what it comes to in a year, those doing one job, trials about to charge, and how to cancel each
struct SubscriptionsList: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    var inSheet = false
    var body: some View {
        let subs: SubsInfo = store.snap.plan?.subs ?? SubsInfo()
        let yearly: Double = subs.subs.reduce(0) { $0 + $1.yearly }
        let n: Int = subs.subs.count
        let count: String = "a year, on " + Words.number(n) + " subscription" + (n == 1 ? "" : "s")
        let lone: [SubInfo] = subs.subs.filter { s in !subs.overlaps.contains { $0.ids.contains(s.id) } }
        List {
            if subs.subs.isEmpty && subs.trials.isEmpty {
                ContentUnavailableView("No subscriptions yet", systemImage: "repeat.circle", description: Text("Once a subscription has charged you twice, a month apart, it shows here."))
                    .listRowBackground(Color.clear)
            } else if n > 0 {
                Section {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(Fmt.rupees(yearly)).font(.system(.largeTitle, design: .rounded, weight: .bold)).monospacedDigit().privacySensitive()
                        Text(count).font(.subheadline).foregroundStyle(.secondary)
                    }
                    .listRowBackground(Color.clear)
                }
            }
            if !subs.trials.isEmpty {
                Section {
                    ForEach(subs.trials) { t in
                        NavigationLink { CancelDetail(id: t.id) } label: { TrialRow(t: t) }
                    }
                } header: { Text("Free trials about to charge") }
            }
            ForEach(subs.overlaps) { o in
                Section {
                    ForEach(subs.subs.filter { o.ids.contains($0.id) }) { s in
                        NavigationLink { CancelDetail(id: s.id) } label: { SubRow(s: s) }
                    }
                } header: { Text("Doing one job: " + o.name) } footer: {
                    Text("Together " + Fmt.rupees(o.yearly) + " a year. If one does the job, " + (o.ids.count > 2 ? "the others" : "the other") + " can go.").privacySensitive()
                }
            }
            if !lone.isEmpty {
                Section {
                    ForEach(lone) { s in NavigationLink { CancelDetail(id: s.id) } label: { SubRow(s: s) } }
                } header: { Text(subs.overlaps.isEmpty ? "Your subscriptions" : "The rest") }
            }
        }
        .listStyle(.insetGrouped)
        .navigationTitle("Subscriptions")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar { ToolbarItem(placement: .confirmationAction) { if inSheet { Button("Done") { dismiss() } } } }
    }
}

struct SubRow: View {
    let s: SubInfo
    var body: some View {
        let sub: String = !s.also.isEmpty ? "Includes " + s.also : s.next.isEmpty ? "" : "Next " + Day.fmt(s.next, "d MMM")
        HStack(spacing: 12) {
            IconTile(symbol: "repeat", color: Color.kosh, size: 30)
            VStack(alignment: .leading, spacing: 1) {
                Text(s.name)
                if !sub.isEmpty { Text(sub).font(.caption).foregroundStyle(.secondary).lineLimit(1) }
            }
            Spacer()
            VStack(alignment: .trailing, spacing: 1) {
                Text(Fmt.rupees(s.amount)).monospacedDigit().privacySensitive()
                Text(PlanInk.every(s.every)).font(.caption).foregroundStyle(.secondary)
            }
        }
        .accessibilityElement(children: .combine)
    }
}

struct TrialRow: View {
    let t: TrialInfo
    var body: some View {
        let ends: String = t.date.isEmpty ? "Ends soon" : "Ends " + Day.fmt(t.date, "d MMM")
        HStack(spacing: 12) {
            IconTile(symbol: "hourglass", color: Color.orange, size: 30)
            VStack(alignment: .leading, spacing: 1) {
                Text(t.name)
                Text(ends).font(.caption).foregroundStyle(.secondary)
            }
            Spacer()
            if t.amt > 0 { Text("then " + Fmt.rupees(t.amt)).font(.subheadline).foregroundStyle(.secondary).privacySensitive() }
        }
        .accessibilityElement(children: .combine)
    }
}

/// how to cancel one subscription or trial: the steps, the place to do it, and a mail drafted for you to send
struct CancelDetail: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    @Environment(\.openURL) private var openURL
    let id: String
    var inSheet = false
    @State private var writing = false
    @State private var confirm = false
    @ScaledMetric(relativeTo: .subheadline) private var badge: CGFloat = 24

    var body: some View {
        let subs: SubsInfo = store.snap.plan?.subs ?? SubsInfo()
        let sub: SubInfo? = subs.subs.first { $0.id == id }
        let trial: TrialInfo? = subs.trials.first { $0.id == id }
        let name: String = sub?.name ?? trial?.name ?? "this subscription"
        let how: CancelHow = sub?.cancel ?? trial?.cancel ?? CancelHow()
        let line: String = Self.line(sub: sub, trial: trial)
        let place: String = how.how == "appstore" ? "Open your App Store subscriptions" : how.how == "playstore" ? "Open Google Play subscriptions" : "Open " + name + "’s page"
        List {
            Section {
                VStack(alignment: .leading, spacing: 6) {
                    Text("Cancel " + name).font(.title2.weight(.bold))
                    if !line.isEmpty { Text(line).font(.subheadline).foregroundStyle(.secondary).privacySensitive() }
                }
                .listRowBackground(Color.clear)
            }
            Section {
                ForEach(Array(how.steps.enumerated()), id: \.offset) { i, step in
                    HStack(alignment: .firstTextBaseline, spacing: 12) {
                        Text(String(i + 1)).font(.subheadline.weight(.bold)).foregroundStyle(Color.onKosh)
                            .frame(minWidth: badge, minHeight: badge).background(Color.koshFill, in: Circle())
                        Text(step).font(.subheadline).fixedSize(horizontal: false, vertical: true)
                    }
                    .padding(.vertical, 2)
                    .accessibilityElement(children: .combine)
                }
            } header: { Text("How") }
            Section {
                if !how.url.isEmpty, let url = URL(string: how.url) {
                    Button { openURL(url) } label: { Label(place, systemImage: "arrow.up.forward.app") }
                }
                Button { write(how) } label: { Label("Write the cancellation mail", systemImage: "envelope") }
            } footer: { Text("kosh drafts it; you read it and send it from your own mail. kosh never sends anything for you.") }
            if store.live != nil && (sub != nil || trial != nil) {
                Section {
                    Button { confirm = true } label: { Label("I cancelled it", systemImage: "checkmark.circle") }
                        .confirmationDialog("Cancelled " + name + "?", isPresented: $confirm, titleVisibility: .visible) {
                            Button("Yes, it’s cancelled") { cancelled(sub: sub, trial: trial); dismiss() }
                        } message: {
                            Text(trial != nil ? "kosh stops reminding you of this trial. If another reminder comes, it shows again." : "It stops counting in what’s due. If it charges you again, kosh shows it again.")
                        }
                }
            }
        }
        .listStyle(.insetGrouped)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar { ToolbarItem(placement: .confirmationAction) { if inSheet { Button("Done") { dismiss() } } } }
        .sheet(isPresented: $writing) {
            MailComposer(to: how.mail.to, subject: how.mail.subject, text: how.mail.body, files: []) { _ in writing = false }
                .ignoresSafeArea()
        }
    }

    /// "₹119 a month, next on 5 Nov. ₹1,428 a year." or "The trial ends on 24 Oct, then ₹119 a month."
    static func line(sub: SubInfo?, trial: TrialInfo?) -> String {
        if let sub {
            let next: String = sub.next.isEmpty ? "" : ", next on " + Day.fmt(sub.next, "d MMM")
            let every: String = PlanInk.every(sub.every)
            let a: String = Fmt.rupees(sub.amount) + (every.isEmpty ? "" : " " + every) + next + ". "
            return a + Fmt.rupees(sub.yearly) + " a year."
        }
        if let trial {
            let ends: String = trial.date.isEmpty ? "The trial ends soon" : "The trial ends on " + Day.fmt(trial.date, "d MMM")
            let every: String = PlanInk.every(trial.every)
            let then: String = trial.amt > 0 ? ", then " + Fmt.rupees(trial.amt) + (every.isEmpty ? "" : " " + every) + "." : "."
            return ends + then
        }
        return ""
    }

    /// a subscription stops counting (the repeat marked gone); a trial's reminder is set aside till another comes
    private func cancelled(sub: SubInfo?, trial: TrialInfo?) {
        guard let live = store.live else { return }
        if let sub { live.markRepeat(sub.id, "gone:" + store.snap.today); return }
        if let trial {
            var c = PlanConfig.load(store)
            c.cancelled[trial.id] = store.snap.today
            c.save(store)
        }
    }

    /// Mail's own compose sheet when the phone has a mail account, else whichever mail app opens mailto links
    private func write(_ how: CancelHow) {
        if MFMailComposeViewController.canSendMail() { writing = true; return }
        var comps = URLComponents()
        comps.scheme = "mailto"
        comps.path = how.mail.to
        comps.queryItems = [URLQueryItem(name: "subject", value: how.mail.subject), URLQueryItem(name: "body", value: how.mail.body)]
        if let url = comps.url { openURL(url) }
    }
}

/// on what kosh noticed (a trial, two doing one job): a way to each one's cancelling
struct PlanCancelButtons: View {
    @Environment(Store.self) private var store
    let reps: [String]
    @State private var sheet: PlanSheet?
    struct Known: Identifiable { let id: String; let name: String }
    var body: some View {
        let subs: SubsInfo = store.snap.plan?.subs ?? SubsInfo()
        let known: [Known] = reps.compactMap { r -> Known? in
            if let n = subs.subs.first(where: { $0.id == r })?.name { return Known(id: r, name: n) }
            if let n = subs.trials.first(where: { $0.id == r })?.name { return Known(id: r, name: n) }
            return nil
        }
        VStack(alignment: .leading, spacing: 8) {
            ForEach(known) { k in
                Button { sheet = .cancel(k.id) } label: { Label("How to cancel " + k.name, systemImage: "xmark.circle") }
                    .font(.subheadline.weight(.semibold))
                    .buttonStyle(.glass)
            }
        }
        .sheet(item: $sheet) { s in PlanSheetView(sheet: s).environment(store) }
    }
}

/// a subscription's sheet (RepeatSheet): how to cancel it, when kosh knows it's one
struct RepeatCancelRow: View {
    @Environment(Store.self) private var store
    let id: String
    @State private var sheet: PlanSheet?
    var body: some View {
        if store.snap.plan?.subs.subs.contains(where: { $0.id == id }) == true {
            Button { sheet = .cancel(id) } label: { Label("How to cancel it", systemImage: "xmark.circle") }
                .sheet(item: $sheet) { s in PlanSheetView(sheet: s).environment(store) }
        }
    }
}

// MARK: Settings

/// the plan's rows in Settings: goals, the salary split, subscriptions
struct PlanSettingsRows: View {
    @Environment(Store.self) private var store
    @State private var sheet: PlanSheet?
    /// the split's parts, counted when the plan changes rather than decoded on every redraw
    @State private var parts: Int = 0
    var body: some View {
        if store.live != nil {
            let plan: PlanInfo = store.snap.plan ?? PlanInfo()
            let subs: Int = plan.subs.subs.count
            Section {
                NavigationLink { GoalsList() } label: {
                    SettingsRow(symbol: "target", color: Color(hex: "#5E5CE6"), title: "Goals", value: plan.goals.isEmpty ? "None yet" : String(plan.goals.count))
                }
                Button { sheet = .split } label: {
                    HStack(spacing: 6) {
                        SettingsRow(symbol: "chart.pie.fill", color: Color(hex: "#34C759"), title: "Salary split",
                                    value: parts == 0 ? "Not set" : String(parts) + (parts == 1 ? " part" : " parts"))
                        // (it opens a sheet, not a page: the same chevron as its neighbours, so it reads as a row)
                        Image(systemName: "chevron.right").font(.footnote.weight(.semibold)).foregroundStyle(.tertiary)
                    }
                }
                .buttonStyle(.press)
                NavigationLink { SubscriptionsList() } label: {
                    SettingsRow(symbol: "repeat", color: Color(hex: "#FF9500"), title: "Subscriptions", value: subs == 0 ? "None yet" : String(subs))
                }
            } header: { SettingsHeader("Plan ahead") } footer: {
                Text("kosh also warns before an auto-debit meets a short account, and before a free trial starts charging.")
            }
            .sheet(item: $sheet) { s in PlanSheetView(sheet: s).environment(store) }
            .onAppear(perform: countParts)
            .onChange(of: store.live?.planJSON ?? "") { countParts() }
        }
    }
    private func countParts() { parts = PlanConfig.load(store).split.parts.count }
}

/// the plan's notifications, remade after every build (Store.afterBuildNow). A low balance and a trial a day or two away
/// are among what kosh noticed, at "act now", so Reminders rings them once each, keeping the figures to itself when
/// they're hidden; there's nothing for the plan to schedule on its own.
enum PlanNotes {
    @MainActor static func reschedule(_ store: Store) {}
}
