import SwiftUI
import UIKit
import Observation

// MARK: - The store: money between people: owed to you, you owe, settled, the reminder
// (split out of Store.swift, 30 Oct 2026; the stored state stays in the class there)

extension Store {
    // money between people
    /// settled by hand, or by a credit the engine matched to it (settleShares in engine.js: the person's name or UPI
    /// ID, the amount, within 90 days). A credit you've just said wasn't it stops counting at once, before the
    /// rebuild that drops it
    /// Money that came back on a split payment splits the same way (engine shareNow): a share still open is owed at its
    /// figure now, and one paid back at the old figure leaves you owing them the difference, a line of its own under
    /// You owe (SplitBook.afterBack)
    var owed: [OwedItem] {
        var back: [String: PaidBack] = [:]
        for p in snap.paidBack ?? [] { back[p.id] = p }
        var now: [String: Double] = [:]
        for s in snap.shareNow ?? [] { now[s.id] = s.a }
        let refused: Set<String> = Set(userOwed.flatMap { $0.notBy ?? [] })
        var out: [OwedItem] = []
        for o in userOwed + snap.owed {
            var x = o
            var seen: Double? = nil
            if settledIDs.contains(o.id) { x.settled = true }
            else if let p = back[o.id], !refused.contains(p.by) {
                x.settled = true
                x.settledBy = p.by
                x.note = "Came in " + Day.fmt(p.d, "d MMM") + " from " + p.m
                seen = p.a
            }
            let after = SplitBook.afterBack(amount: o.amount, now: now[o.id], settled: x.settled, paid: seen)
            x.amount = after.amount
            // (all of it came back: nothing is owed, and it says why, under Settled)
            if !x.settled && now[o.id] != nil && after.amount < 0.005 {
                x.settled = true
                x.amount = o.amount
                x.note = "Nothing to pay: the payment all came back"
            }
            out.append(x)
            if after.owedBack > 0 {
                let id: String = SplitBook.backID(o.id)
                out.append(OwedItem(id: id, name: o.name, title: "Refund on " + o.title, amount: after.owedBack, date: o.date, dir: "out", kind: "split-back",
                                    settled: settledIDs.contains(id), note: "Their part of the money that came back on " + o.title, tx: o.tx))
            }
        }
        return out
    }
    /// what the engine settles from credits: the money owed to you still open, with a name; the shares split off a
    /// payment that are paid back already (so money back on it is shared out between every share, not only the open
    /// ones); and the credits you said paid none of it back
    static func owedForEngine(_ items: [OwedItem], settled: Set<String>) -> (open: [OwedItem], done: [OwedItem], not: [String]) {
        let open: [OwedItem] = items.filter { $0.dir == "in" && !$0.name.isEmpty && !settled.contains($0.id) }
        let done: [OwedItem] = items.filter { $0.dir == "in" && $0.tx != nil && settled.contains($0.id) }
        var not: [String] = []
        for o in items { for c in o.notBy ?? [] where !not.contains(c) { not.append(c) } }
        return (open, done, not)
    }
    /// the next build sees what's owed as it is now; each change that should show at once rebuilds by itself
    func syncOwed() {
        guard let live else { return }
        let x = Self.owedForEngine(userOwed, settled: settledIDs)
        live.owedOpen = x.open
        live.owedDone = x.done
        live.owedNot = x.not
    }
    var owedToYou: [OwedItem] { owed.filter { !$0.settled && $0.dir == "in" }.sorted { $0.date > $1.date } }
    var youOwe: [OwedItem] { owed.filter { !$0.settled && $0.dir == "out" }.sorted { $0.date > $1.date } }
    var settledOwed: [OwedItem] { owed.filter { $0.settled }.sorted { $0.date > $1.date } }
    var knownNames: [String] {
        var seen: [String] = []
        for o in userOwed where !o.name.isEmpty && !seen.contains(o.name) { seen.append(o.name) }
        return seen
    }
    /// mark it paid back, or open it again. Opening one kosh settled from a credit is "that wasn't it" (Undo)
    func settle(_ id: String, _ on: Bool = true) {
        if !on && !settledIDs.contains(id), let by = owed.first(where: { $0.id == id })?.settledBy {
            notPaidBack(by, share: id)
            return
        }
        if on { settledIDs.insert(id) } else { settledIDs.remove(id) }
        live?.rebuildSoon()
    }
    /// the credit kosh took as money paid back isn't: every share it settled opens again, it's money in again, and
    /// it never settles anything after this
    func notPaidBack(_ credit: String, share: String? = nil) {
        let ids: [String] = share.map { [$0] } ?? (txn(credit)?.paysBack ?? [])
        guard let i = userOwed.firstIndex(where: { ids.contains($0.id) }) else { return }
        var not: [String] = userOwed[i].notBy ?? []
        if !not.contains(credit) { not.append(credit) }
        userOwed[i].notBy = not
        live?.rebuildSoon()
    }
    /// part of it came in: that part is settled, the rest stays open
    func receivePart(_ id: String, _ got: Double) {
        guard let i = userOwed.firstIndex(where: { $0.id == id }), got > 0 else { return }
        let o = userOwed[i]
        // (owed as it is now: less their part of any money that came back on the payment)
        let due: Double = owed.first { $0.id == id }?.amount ?? o.amount
        if got >= due - 0.5 { settle(id); return }
        // (kept in the share's old terms, so taking the money back off again leaves what came in and what's left)
        let part: Double = SplitBook.inOldTerms(got, now: due, was: o.amount)
        userOwed[i].amount = ((o.amount - part) * 100).rounded() / 100
        var done = o
        done.id = UUID().uuidString; done.amount = part; done.date = snap.today; done.settled = true
        done.note = "Part of \(Fmt.rupees(due)) for \(o.title)"
        userOwed.insert(done, at: i + 1)
        settledIDs.insert(done.id)
        live?.rebuildSoon()
    }
    /// can part of it be marked: only what was added on this phone
    func canSplitReceive(_ id: String) -> Bool { userOwed.contains { $0.id == id } }
    func addOwed(name: String, title: String, amount: Double, dir: String, kind: String, note: String) {
        userOwed.insert(OwedItem(id: UUID().uuidString, name: name, title: title, amount: amount, date: snap.today, dir: dir, kind: kind, settled: false, note: note), at: 0)
        live?.rebuildSoon()
    }

    /// a change saved on a payment's twin that the build dropped (the SMS, once its mail came) moves onto the row the
    /// build kept, for good, and so does every share split off it (SplitLinks; the engine says which in snap.carried).
    /// Called after a build once what you added is loaded; nothing moves when nothing was carried
    func carryTwins(_ map: [String: String]?) {
        guard let map, !map.isEmpty else { return }
        if let live {
            let moved: [String: Override] = SplitLinks.carry(live.overrides, map) { kept, dropped in kept.filled(from: dropped) }
            if moved != live.overrides {
                live.overrides = moved
                live.save()
            }
        }
        let was: [String?] = userOwed.map(\.tx)
        let now: [String?] = SplitLinks.relink(was, map)
        if now != was {
            var u: [OwedItem] = userOwed
            for i in u.indices where i < now.count { u[i].tx = now[i] }
            userOwed = u
        }
    }

    /// the shares split off a payment that are paid back already (by hand, or a credit kosh saw), and what they came
    /// to as they were split (before any money came back: the terms the payment's "mine" is kept in)
    func paidShares(_ tx: String) -> (ids: Set<String>, sum: Double) {
        let ids: Set<String> = Set(owed.filter { $0.tx == tx && $0.dir == "in" && $0.settled }.map(\.id))
        let sum: Double = userOwed.filter { ids.contains($0.id) }.reduce(0) { $0 + $1.amount }
        return (ids, SplitBook.paisa(sum))
    }

    /// a share split without names ("2 others") is one line for all of them: each owes their part of it
    static func seats(_ o: OwedItem) -> Int { SplitBook.seats(o.name) }
    /// the reminder: short and kind, how much, what for and when, and a link to pay you in one tap when Settings has
    /// your UPI ID
    func reminder(_ o: OwedItem) -> String {
        let n: Int = Self.seats(o)
        let each: Double = n > 1 ? (o.amount / Double(n)).rounded() : o.amount
        let named: Bool = !o.name.isEmpty && n == 1 && o.name != "Someone"
        let who: String = named ? "Hi " + o.name : "Hi"
        let on: String = Day.fmt(o.date, "d MMM")
        var s: String
        if o.kind == "split" {
            s = who + ", your share of " + o.title + " on " + on + " is " + Fmt.rupees(each) + "."
        } else if o.title.isEmpty || o.title == "Lent" {
            s = who + ", a gentle reminder about the " + Fmt.rupees(each) + " from " + on + "."
        } else {
            s = who + ", a gentle reminder about the " + Fmt.rupees(each) + " for " + o.title + " from " + on + "."
        }
        s += " Thanks!"
        if let link = upiLink(amount: each, note: o.title) { s += "\n\nPay in one tap: " + link }
        return s
    }
    /// a UPI link that opens their payments app with you, the amount and what it's for filled in; nil until Settings
    /// has your UPI ID
    func upiLink(amount: Double, note: String) -> String? {
        let pa: String = upi.trimmingCharacters(in: .whitespacesAndNewlines)
        guard pa.contains("@"), amount > 0, amount.isFinite else { return nil }
        let me: String = snap.people.first { $0.id == "me" }?.full ?? ""
        let am: String = amount == amount.rounded() ? String(Int(safe: amount)) : String(format: "%.2f", amount)
        var safe = CharacterSet.alphanumerics
        safe.insert(charactersIn: "-._~")
        var withAt = safe
        withAt.insert(charactersIn: "@")
        var q: String = "pa=" + (pa.addingPercentEncoding(withAllowedCharacters: withAt) ?? pa)
        if !me.isEmpty && me != "You" { q += "&pn=" + (me.addingPercentEncoding(withAllowedCharacters: safe) ?? me) }
        q += "&am=" + am + "&cu=INR"
        if !note.isEmpty { q += "&tn=" + (String(note.prefix(50)).addingPercentEncoding(withAllowedCharacters: safe) ?? note) }
        return "upi://pay?" + q
    }
    /// the reminder typed into WhatsApp: you pick the chat, and nothing goes until you press send
    func reminderURL(_ o: OwedItem) -> URL? { NudgeWords.whatsapp(reminder(o), phone: nil) }
}

extension Override {
    /// this row's changes with its dropped twin's filling in what this one doesn't say: field by field this one wins,
    /// but what goes together goes together (a category with its sub-category and whose hand filed it; a refund you
    /// marked with its day, note and "came back"), and the payments you said aren't this one come from both. The
    /// engine's twinFill (21a) is the same rule
    func filled(from d: Override) -> Override {
        var o: Override = self
        if c == nil && s == nil && by == nil { o.c = d.c; o.s = d.s; o.by = d.by }
        if f == nil { o.f = d.f }
        if n == nil { o.n = d.n }
        if mine == nil && sb == nil { o.mine = d.mine; o.sb = d.sb }
        if ex == nil { o.ex = d.ex }
        if parts == nil { o.parts = d.parts }
        if cm == nil { o.cm = d.cm }
        if rf == nil && rfBy == nil && rfNote == nil && rfDone == nil { o.rf = d.rf; o.rfBy = d.rfBy; o.rfNote = d.rfNote; o.rfDone = d.rfDone }
        if cnt == nil { o.cnt = d.cnt }
        if rfOf == nil { o.rfOf = d.rfOf }
        if only == nil { o.only = d.only }
        if tr == nil { o.tr = d.tr }
        if dup == nil { o.dup = d.dup }
        let not: [String] = (dupNot ?? []) + (d.dupNot ?? []).filter { !(dupNot ?? []).contains($0) }
        o.dupNot = not.isEmpty ? nil : not
        if from == nil { o.from = d.from }
        return o
    }
}
