import SwiftUI
import UserNotifications

// MARK: - Briefings and decisions (brief.js)
//
// kosh telling you about your money before you ask. The morning briefing: what today and tomorrow ask of you, what
// changed since yesterday (what went out, a salary or a refund that came in), and the one thing kosh noticed that
// most needs you; on Home, and as a notification at the time you pick. The Sunday digest: the week on one screen
// (money in and out, the biggest moves, the category that ran higher than usual, the next seven days, what kosh
// noticed, net worth), and a notification on Sunday morning. Fund fees: what each Regular mutual fund plan costs a
// year, and over ten years, against the Direct plan of the same fund, from the fee lists AMFI publishes (FundFees).
//
// The engine works it all out (snap.brief); this file draws it and rings it. A notification's words come in two
// kinds from the engine: with figures, and quiet (no amount, no name, no card digits). The Lock Screen gets the quiet
// ones unless you turn amounts and names on, and always while amounts are hidden or kosh is locked.

// MARK: what brief.js adds to the snapshot

/// read field by field: anything the phone can't read is left out, never the snapshot with it
struct BriefInfo: Decodable, Hashable {
    /// this morning's briefing (Home shows it all day), and tomorrow morning's from what's in now
    var daily: Briefing? = nil
    var next: Briefing? = nil
    var digest: WeekDigest? = nil
    var fees: FundFeesInfo? = nil
    enum CodingKeys: String, CodingKey { case daily, next, digest, fees }
    init() {}
    init(from d: Decoder) throws {
        let c = try d.container(keyedBy: CodingKeys.self)
        daily = try? c.decodeIfPresent(Briefing.self, forKey: .daily)
        next = try? c.decodeIfPresent(Briefing.self, forKey: .next)
        digest = try? c.decodeIfPresent(WeekDigest.self, forKey: .digest)
        fees = try? c.decodeIfPresent(FundFeesInfo.self, forKey: .fees)
    }
}

/// a payment still to make, from the calendar
struct BriefDue: Decodable, Hashable, Identifiable {
    let name: String; let amt: Double; let date: String; let cat: String; let sym: String; let sub: String
    /// "today" or "tomorrow" (the briefing's own)
    var when: String? = nil
    /// a day kosh learnt from your spending (no bill in the mail): when it usually goes, not a due date
    var learnt: Bool? = nil
    /// the engine's own id: two bills of one biller on one day are two rows
    var key: String? = nil
    var id: String { key ?? (date + "|" + name + "|" + String(Int(safe: amt))) }
    enum CodingKeys: String, CodingKey { case name, amt, date, cat, sym, sub, when, learnt, key = "id" }
}

/// one morning: what's due on the day and the next, yesterday's money, what kosh noticed
struct Briefing: Decodable, Hashable {
    struct Top: Decodable, Hashable { let id: String; let m: String; let a: Double; let sym: String }
    struct Out: Decodable, Hashable { let n: Int; let amt: Double; var top: Top? = nil }
    struct Salary: Decodable, Hashable { let amt: Double; let from: String }
    struct Back: Decodable, Hashable, Identifiable { let id: String; let m: String; let a: Double }
    struct In: Decodable, Hashable { let n: Int; let amt: Double; var salary: Salary? = nil; let refunds: [Back] }
    /// a heads-up, with its line for a notification, said with figures and quietly
    struct Thing: Decodable, Hashable, Identifiable {
        let id: String; let kind: String; let sev: Int; let title: String; let detail: String; let sym: String
        let line: String; let quiet: String
    }
    let day: String; let yday: String
    let out: Out
    let inn: In
    let due: [BriefDue]
    let things: [Thing]
    /// anything worth a notification; and anything apart from what kosh noticed
    let worth: Bool
    var news: Bool? = nil
    /// the briefing in sentences: with figures, and quiet; the first `lead` of them (what's due) always rung
    let lines: [String]; let qlines: [String]
    var lead: Int? = nil
    enum CodingKeys: String, CodingKey { case day, yday, out, inn, due, things, worth, news, lines, qlines, lead }
}

/// one week: Monday to Sunday
struct WeekDigest: Decodable, Hashable {
    struct Move: Decodable, Hashable, Identifiable {
        let id: String; let d: String; let m: String; let a: Double
        /// in or out; and what kind: out (spent), in (earned), back (a refund), people (from a person), invest,
        /// redeem (back from investments)
        let dir: String; let kind: String; let c: String; let sym: String
    }
    struct Grew: Decodable, Hashable { let cat: String; let week: Double; let usual: Double; let more: Double; let sym: String; let color: String }
    struct Seen: Decodable, Hashable, Identifiable { let id: String; let kind: String; let sev: Int; let title: String; let detail: String; let sym: String }
    let from: String; let to: String; let label: String
    /// a Sunday's own week, up to today
    let partial: Bool
    /// spent (less the refunds kosh couldn't tie to their payments, `refunded`), earned, from people, invested
    let out: Double; let outN: Int; let inn: Double; let innN: Int; let people: Double; let invest: Double
    var refunded: Double? = nil
    var redeemed: Double? = nil
    let moves: [Move]
    var grew: Grew? = nil
    let dueFrom: String; let dueTo: String; let due: [BriefDue]; let dueTotal: Double
    let noticed: [Seen]
    /// nothing spent or earned that kosh saw; `other`: what moved without being either (card bills, transfers)
    let quiet: Bool
    var other: Int? = nil
    let title: String; let lines: [String]; let qlines: [String]
}

/// what Regular plans cost against Direct, plan by plan
struct FundFeesInfo: Decodable, Hashable {
    struct Row: Decodable, Hashable, Identifiable {
        let name: String; let amt: Double; let person: String
        /// the two plans' total expense ratios and the gap (percent a year)
        let r: Double; let d: Double; let gap: Double
        /// the extra fee a year, and over ten years at `growth`% a year before fees
        let year: Double; let ten: Double; let kind: String; let growth: Double
        /// one row a plan and a person, however many folios it's in
        var key: String? = nil
        var id: String { key ?? (person + "|" + name) }
        enum CodingKeys: String, CodingKey { case name, amt, person, r, d, gap, year, ten, kind, growth, key = "id" }
    }
    struct Unknown: Decodable, Hashable, Identifiable {
        let name: String; let amt: Double; let person: String
        /// why: "list" (no fee list yet), "none" (not in it), "two" (two schemes of different fees by that name),
        /// "nodirect" (no Direct plan to compare)
        var why: String? = nil
        var key: String? = nil
        var id: String { key ?? (person + "|" + name) }
        enum CodingKeys: String, CodingKey { case name, amt, person, why, key = "id" }
    }
    /// the month of the fees ("September 2026"), when kosh fetched them, and the days AMFI gave them for
    let asOf: String; let at: String
    var onFrom: String? = nil; var onTo: String? = nil
    let rows: [Row]; let unknown: [Unknown]
    let year: Double; let ten: Double
    /// whether kosh has AMFI's lists at all yet
    let fetched: Bool
}

extension Store {
    /// the one thing for the briefing on Home: kosh's most pressing heads-up you haven't snoozed or marked done
    func briefThing(_ b: Briefing) -> Briefing.Thing? {
        let shown: Set<String> = Set(watchShown.map(\.id))
        return b.things.first { shown.contains($0.id) }
    }
    /// news in the briefing apart from what kosh noticed
    func briefNews(_ b: Briefing) -> Bool { b.news ?? (b.out.n > 0 || b.inn.n > 0 || !b.inn.refunds.isEmpty || !b.due.isEmpty) }
    /// the digest that is fresh to read: on Sunday (its own week so far) and on Monday (the week just ended)
    var digestFresh: WeekDigest? {
        guard let d = snap.brief?.digest, !d.quiet else { return nil }
        let today: String = snap.today
        return d.to == today || d.to == Day.add(today, -1) ? d : nil
    }
}

// MARK: - Home: this morning

/// the briefing on Home (the "brief" section of Home's plan): what's due today and tomorrow, yesterday in one line, a
/// salary or refund that landed, the one thing to do, and on Sunday and Monday the week. Put away, it comes back the
/// next morning. A morning whose only news is a heads-up you've snoozed or done shows nothing.
struct BriefHomeCard: View {
    @Environment(Store.self) private var store
    /// the day it was put away (yyyy-MM-dd)
    @AppStorage("brief.card.away") private var away = ""

    var body: some View {
        let today: String = store.snap.today
        let week: WeekDigest? = store.digestFresh
        if let b = store.snap.brief?.daily, b.day == today, away != today,
           store.briefNews(b) || store.briefThing(b) != nil || week != nil {
            HomeBlock {
                BriefCard(b: b, week: week) { withAnimation(Motion.open) { away = today } }
            }
            .transition(.opacity.combined(with: .scale(scale: 0.98, anchor: .top)))
        }
    }
}

private struct BriefCard: View {
    @Environment(Store.self) private var store
    let b: Briefing
    let week: WeekDigest?
    let putAway: () -> Void

    var body: some View {
        let thing: Briefing.Thing? = store.briefThing(b)
        VStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .firstTextBaseline, spacing: 10) {
                Text("This morning").font(.title2.weight(.bold))
                Spacer()
                Text(Day.fmt(b.day, "EEE d MMM")).font(.subheadline).foregroundStyle(.secondary)
                Button(action: putAway) {
                    Image(systemName: "xmark")
                        .font(.caption.weight(.bold))
                        .foregroundStyle(.secondary)
                        .frame(width: 26, height: 26)
                        .background(Color.primary.opacity(0.06), in: Circle())
                        .frame(width: 44, height: 44)
                        .contentShape(Rectangle())
                }
                .buttonStyle(.press)
                .padding(.vertical, -9)
                .accessibilityLabel("Put away until tomorrow")
            }
            VStack(alignment: .leading, spacing: 0) {
                if b.out.n > 0 || b.inn.n > 0 { yesterday.padding(.bottom, 14) }
                rows(thing)
            }
            .card(16)
        }
    }

    /// what went out and came in yesterday, side by side
    var yesterday: some View {
        VStack(alignment: .leading, spacing: 8) {
            Eyebrow(text: "Yesterday")
            HStack(alignment: .top, spacing: 0) {
                if b.out.n > 0 {
                    figure(Fmt.rupees(b.out.amt), b.out.n == 1 ? "out, one payment" : "out, \(b.out.n) payments", ink: Color.primary)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                if b.inn.n > 0 {
                    figure(Fmt.rupees(b.inn.amt), b.inn.salary != nil ? "in, with your salary" : "came in", ink: Color.green)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
            }
        }
        .accessibilityElement(children: .combine)
    }

    func figure(_ value: String, _ caption: String, ink: Color) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(value)
                .font(.system(.title2, design: .rounded, weight: .bold))
                .monospacedDigit()
                .foregroundStyle(ink)
                .lineLimit(1)
                .minimumScaleFactor(0.6)
                .privacySensitive()
            Text(caption).font(.footnote).foregroundStyle(.secondary)
        }
    }

    /// the card's rows, one kind of news each, in the order a morning reads
    enum Item: Identifiable {
        case back(Briefing.Back), due(BriefDue), thing(Briefing.Thing), week(WeekDigest)
        var id: String {
            switch self {
            case .back(let r): return "back|" + r.id
            case .due(let d): return "due|" + d.id
            case .thing(let t): return "thing|" + t.id
            case .week(let w): return "week|" + w.from
            }
        }
    }

    func items(_ thing: Briefing.Thing?) -> [Item] {
        var out: [Item] = b.inn.refunds.prefix(2).map { Item.back($0) }
        out += b.due.prefix(3).map { Item.due($0) }
        if let thing { out.append(.thing(thing)) }
        if let week { out.append(.week(week)) }
        return out
    }

    @ViewBuilder func rows(_ thing: Briefing.Thing?) -> some View {
        let list: [Item] = items(thing)
        if !list.isEmpty && (b.out.n > 0 || b.inn.n > 0) { Divider() }
        ForEach(Array(list.enumerated()), id: \.element.id) { i, item in
            if i > 0 { Divider().padding(.leading, 40) }
            row(item)
        }
    }

    @ViewBuilder func row(_ item: Item) -> some View {
        switch item {
        case .back(let r):
            BriefLine(sym: "arrow.uturn.backward.circle.fill", tint: Color.green, title: "Came back from " + (r.m.isEmpty ? "a refund" : r.m),
                      detail: nil, amount: Fmt.rupees(r.a))
        case .due(let d):
            let when: String = (d.when ?? "") == "today" ? "today" : "tomorrow"
            Button {
                store.calendarDay = d.date
                store.push(.calendar)
            } label: {
                BriefLine(sym: d.sym, tint: store.catColor(d.cat), title: d.name, detail: (d.learnt == true ? "Usually around " : "Due ") + when,
                          amount: Fmt.rupees(d.amt), chevron: true)
            }
            .buttonStyle(.press)
            .accessibilityHint("Opens the day on the calendar")
        case .thing(let t):
            Button { store.betaSheet = .noticed(t.id) } label: { ThingLine(t: t) }
                .buttonStyle(.press)
                .accessibilityHint("Opens what kosh noticed")
        case .week(let w):
            Button { store.betaSheet = .digest } label: {
                BriefLine(sym: "calendar.badge.checkmark", tint: Color.kosh, title: w.partial ? "Your week so far" : "Your week",
                          detail: w.label, amount: nil, chevron: true)
            }
            .buttonStyle(.press)
            .accessibilityHint("Opens the week on one screen")
        }
    }
}

/// a row of the briefing: a tinted symbol, what it is, and its figure
private struct BriefLine: View {
    let sym: String
    let tint: Color
    let title: String
    let detail: String?
    let amount: String?
    var chevron = false

    var body: some View {
        HStack(alignment: .center, spacing: 12) {
            Image(systemName: sym)
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(tint)
                .frame(width: 28, height: 28)
                .background(tint.opacity(0.12), in: RoundedRectangle(cornerRadius: 8, style: .continuous))
            VStack(alignment: .leading, spacing: 1) {
                Text(title).font(.subheadline.weight(.semibold)).foregroundStyle(Color.primary).lineLimit(2)
                if let detail { Text(detail).font(.footnote).foregroundStyle(.secondary).lineLimit(1) }
            }
            Spacer(minLength: 8)
            if let amount {
                Text(amount).font(.subheadline.weight(.semibold)).monospacedDigit().foregroundStyle(Color.primary).privacySensitive()
            }
            if chevron {
                Image(systemName: "chevron.right").font(.caption.weight(.bold)).foregroundStyle(.tertiary)
            }
        }
        .padding(.vertical, 10)
        .contentShape(Rectangle())
        .accessibilityElement(children: .combine)
    }
}

/// the one thing to do: how pressing, in words and colour, and what kosh noticed
private struct ThingLine: View {
    let t: Briefing.Thing
    var tint: Color { t.sev >= 3 ? Color.red : t.sev == 2 ? Color.orange : Color.kosh }
    var level: String { t.sev >= 3 ? "Act now" : t.sev == 2 ? "Worth a look" : "Good to know" }
    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: t.sym)
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(tint)
                .frame(width: 28, height: 28)
                .background(tint.opacity(0.12), in: RoundedRectangle(cornerRadius: 8, style: .continuous))
            VStack(alignment: .leading, spacing: 2) {
                Text(level.uppercased()).font(.caption2.weight(.bold)).tracking(0.6).foregroundStyle(tint)
                Text(t.title).font(.subheadline.weight(.semibold)).foregroundStyle(Color.primary)
                    .fixedSize(horizontal: false, vertical: true)
                    .privacySensitive()
                if !t.detail.isEmpty {
                    Text(t.detail).font(.footnote).foregroundStyle(.secondary).lineLimit(2)
                        .fixedSize(horizontal: false, vertical: true)
                        .privacySensitive()
                }
            }
            Spacer(minLength: 8)
            Image(systemName: "chevron.right").font(.caption.weight(.bold)).foregroundStyle(.tertiary).padding(.top, 6)
        }
        .padding(.vertical, 10)
        .contentShape(Rectangle())
        .accessibilityElement(children: .combine)
    }
}

// MARK: - The Sunday digest

/// the digest as a sheet (from the briefing, the notification, or Settings). Its host leaves amounts showing (forms
/// there must stay editable), so the sheet hides them itself while they're hidden, the fees it opens too.
struct DigestSheet: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            DigestPage()
                .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } } }
        }
        .redacted(reason: store.hidden ? .privacy : [])
    }
}

/// the week on one screen
struct DigestPage: View {
    @Environment(Store.self) private var store

    var body: some View {
        ScrollView {
            if let d = store.snap.brief?.digest {
                VStack(alignment: .leading, spacing: 26) {
                    header(d)
                    if d.quiet { quietWeek(d) } else { money(d) }
                    worth
                    if !d.moves.isEmpty { moves(d) }
                    if let g = d.grew { grew(g) }
                    coming(d)
                    if !d.noticed.isEmpty { noticed(d) }
                    if let f = store.snap.brief?.fees, !f.rows.isEmpty || !f.unknown.isEmpty { fees(f) }
                }
                .padding(.horizontal, 20)
                .padding(.top, 4)
                .padding(.bottom, 32)
            } else {
                ContentUnavailableView("No week yet", systemImage: "calendar",
                                       description: Text("Once kosh has read your mail, the week shows here."))
                    .padding(.top, 80)
            }
        }
        .background(Color(uiColor: .systemBackground))
        .navigationBarTitleDisplayMode(.inline)
    }

    func header(_ d: WeekDigest) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Eyebrow(text: d.partial ? "Your week so far" : "Your week", color: Color.kosh)
            Text(d.label)
                .font(.system(.largeTitle, design: .rounded, weight: .bold))
                .lineLimit(1)
                .minimumScaleFactor(0.7)
            if d.partial {
                Text("Sunday is still going: what comes in today joins it next time kosh reads your mail.")
                    .font(.subheadline).foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .accessibilityElement(children: .combine)
        .accessibilityAddTraits(.isHeader)
    }

    func quietWeek(_ d: WeekDigest) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Label("A quiet week", systemImage: "moon.stars").font(.headline)
            Text(quietLine(d)).font(.subheadline).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
        }
        .card(18)
    }

    /// a week with nothing in it: say why it may be, honestly
    func quietLine(_ d: WeekDigest) -> String {
        let since: Int = LiveSession.daysSince(store.live?.lastScan ?? "")
        if store.live != nil && since > 7 { return "kosh hasn’t read your mail for a while, so this week may be missing what came after. Pull down on Home to read it now." }
        let span: String = Day.fmt(d.from, "d MMM") + " and " + Day.fmt(d.to, "d MMM")
        if (d.other ?? 0) > 0 {
            return "Between " + span + " only card bills, moves between your own accounts or payments you left out went through, and kosh counts none of them as spending or income."
        }
        return "kosh saw no money move between " + span + "."
    }

    func money(_ d: WeekDigest) -> some View {
        let back: Double = d.refunded ?? 0
        var spentSub: String = d.outN == 0 ? "no payments" : d.outN == 1 ? "one payment" : "\(d.outN) payments"
        if d.outN > 0 && back >= 1 { spentSub += ", less " + Fmt.rupees(back) + " back" }
        return VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 10) {
                tile("Spent", Fmt.rupees(d.out), spentSub, ink: Color.primary, subSensitive: back >= 1)
                tile("Came in", Fmt.rupees(d.inn), d.innN == 0 ? "nothing earned" : d.innN == 1 ? "one credit" : "\(d.innN) credits", ink: Color.green)
            }
            if d.people > 0 || d.invest > 0 || (d.redeemed ?? 0) > 0 {
                Text(alsoLine(d)).font(.footnote).foregroundStyle(.secondary).privacySensitive()
            }
        }
    }

    func alsoLine(_ d: WeekDigest) -> String {
        var bits: [String] = []
        if d.invest > 0 { bits.append(Fmt.rupees(d.invest) + " invested") }
        if let r = d.redeemed, r > 0 { bits.append(Fmt.rupees(r) + " back from investments") }
        if d.people > 0 { bits.append(Fmt.rupees(d.people) + " from people, not counted as income") }
        return Words.cap(bits.joined(separator: " · ")) + "."
    }

    func tile(_ label: String, _ value: String, _ sub: String, ink: Color, subSensitive: Bool = false) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(label).font(.subheadline.weight(.medium)).foregroundStyle(.secondary)
            Text(value)
                .font(.system(.title, design: .rounded, weight: .bold))
                .monospacedDigit()
                .foregroundStyle(ink)
                .lineLimit(1)
                .minimumScaleFactor(0.55)
                .privacySensitive()
            Text(sub).font(.footnote).foregroundStyle(.secondary).privacySensitive(subSensitive)
        }
        .card(16)
        .accessibilityElement(children: .combine)
    }

    /// net worth: the figure Home shows, and how it moved since the last month's end kosh has
    @ViewBuilder var worth: some View {
        // (whose money the rest of the app is showing: Home's figure follows the picker, so this one must too)
        let pts: [NWPoint] = store.worthSeries(store.who)
        if pts.count >= 2 {
            let now: Double = store.netWorth(store.who)
            let before: NWPoint = pts[pts.count - 2]
            let change: Double = now - before.v
            let flat: Bool = abs(change) < 1
            let up: Bool = change >= 0
            let since: String = "since " + Day.fmt(Day.monthEnd(before.m), "d MMM")
            HStack(alignment: .firstTextBaseline, spacing: 10) {
                VStack(alignment: .leading, spacing: 2) {
                    Text("Net worth").font(.subheadline.weight(.medium)).foregroundStyle(.secondary)
                    Text(Fmt.signedWords(now))
                        .font(.system(.title2, design: .rounded, weight: .bold))
                        .monospacedDigit()
                        .privacySensitive()
                }
                Spacer()
                VStack(alignment: .trailing, spacing: 2) {
                    if flat {
                        Label("No change", systemImage: "arrow.right").font(.subheadline.weight(.semibold)).foregroundStyle(.secondary)
                    } else {
                        Label(Fmt.words(abs(change)), systemImage: up ? "arrow.up.right" : "arrow.down.right")
                            .font(.subheadline.weight(.semibold))
                            .foregroundStyle(up ? Color.green : Color.red)
                            .privacySensitive()
                    }
                    Text(since).font(.footnote).foregroundStyle(.secondary)
                }
            }
            .card(16)
            // the arrow's direction in words for VoiceOver; the figures only while amounts show
            .accessibilityElement(children: .ignore)
            .accessibilityLabel(worthLabel(now, change, flat: flat, since: since))
        }
    }

    func worthLabel(_ now: Double, _ change: Double, flat: Bool, since: String) -> String {
        let move: String = flat ? "no change" : (change >= 0 ? "up" : "down") + (store.hidden ? "" : " " + Fmt.words(abs(change)))
        return "Net worth" + (store.hidden ? "" : " " + Fmt.signedWords(now)) + ", " + move + " " + since
    }

    func moves(_ d: WeekDigest) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            SectionHeader(title: "Biggest moves")
            VStack(spacing: 0) {
                ForEach(Array(d.moves.enumerated()), id: \.element.id) { i, m in
                    if i > 0 { Divider().padding(.leading, 48) }
                    HStack(spacing: 12) {
                        IconTile(symbol: m.sym.isEmpty ? "circle" : m.sym, color: m.dir == "in" ? Color.green : store.catColor(m.c), size: 34)
                        VStack(alignment: .leading, spacing: 1) {
                            Text(m.m.isEmpty ? m.c : m.m).font(.subheadline.weight(.semibold)).lineLimit(1)
                            Text(Day.fmt(m.d, "EEE d MMM") + " · " + moveWord(m)).font(.footnote).foregroundStyle(.secondary)
                        }
                        Spacer(minLength: 8)
                        Text((m.dir == "in" ? "+" : "") + Fmt.rupees(m.a))
                            .font(.subheadline.weight(.semibold)).monospacedDigit()
                            .foregroundStyle(m.dir == "in" ? Color.green : Color.primary)
                            .privacySensitive()
                    }
                    .padding(.vertical, 9)
                    .accessibilityElement(children: .combine)
                }
            }
            .card(14)
        }
    }

    func moveWord(_ m: WeekDigest.Move) -> String {
        switch m.kind {
        case "invest": return "invested"
        case "redeem": return "back from investments"
        case "back": return "came back, off the spending"
        case "people": return "from a person"
        case "in": return m.c.isEmpty ? "came in" : m.c.lowercased()
        default: return m.c.isEmpty ? "spent" : m.c
        }
    }

    func grew(_ g: WeekDigest.Grew) -> some View {
        let tint: Color = Color(hex: g.color)
        let top: Double = max(g.week, g.usual, 1)
        return VStack(alignment: .leading, spacing: 10) {
            SectionHeader(title: "Higher than usual")
            VStack(alignment: .leading, spacing: 12) {
                HStack(spacing: 12) {
                    IconTile(symbol: g.sym, color: tint, size: 34)
                    VStack(alignment: .leading, spacing: 1) {
                        Text(g.cat).font(.subheadline.weight(.semibold))
                        Text(Fmt.rupees(g.more) + " more than an ordinary week").font(.footnote).foregroundStyle(.secondary).privacySensitive()
                    }
                }
                // the labels make their own column: at large text sizes it takes the room they need, and they wrap
                Grid(alignment: .leading, horizontalSpacing: 10, verticalSpacing: 8) {
                    GridRow {
                        barLabel("This week")
                        bar(g.week, of: top, tint: tint)
                        barValue(g.week)
                    }
                    GridRow {
                        barLabel("Usually")
                        bar(g.usual, of: top, tint: Color.secondary.opacity(0.45))
                        barValue(g.usual)
                    }
                }
                .accessibilityElement(children: .combine)
            }
            .card(16)
        }
    }

    func barLabel(_ s: String) -> some View {
        Text(s).font(.footnote).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
    }

    func bar(_ v: Double, of top: Double, tint: Color) -> some View {
        GeometryReader { geo in
            Capsule().fill(tint).frame(width: max(6, geo.size.width * CGFloat(v / top)))
        }
        .frame(height: 8)
    }

    func barValue(_ v: Double) -> some View {
        Text(Fmt.rupees(v)).font(.footnote.weight(.semibold)).monospacedDigit().gridColumnAlignment(.trailing).privacySensitive()
    }

    @ViewBuilder func coming(_ d: WeekDigest) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            SectionHeader(title: "Next 7 days", detail: d.due.isEmpty ? nil : Fmt.rupees(d.dueTotal))
            if d.due.isEmpty {
                Text("Nothing kosh knows of is due between " + Day.fmt(d.dueFrom, "d MMM") + " and " + Day.fmt(d.dueTo, "d MMM") + ".")
                    .font(.subheadline).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            } else {
                VStack(spacing: 0) {
                    ForEach(Array(d.due.prefix(6).enumerated()), id: \.element.id) { i, x in
                        if i > 0 { Divider().padding(.leading, 48) }
                        HStack(spacing: 12) {
                            IconTile(symbol: x.sym, color: store.catColor(x.cat), size: 34)
                            VStack(alignment: .leading, spacing: 1) {
                                Text(x.name).font(.subheadline.weight(.semibold)).lineLimit(1)
                                Text((x.learnt == true ? "Usually around " : "") + Day.fmt(x.date, "EEEE d MMM")).font(.footnote).foregroundStyle(.secondary)
                            }
                            Spacer(minLength: 8)
                            Text(Fmt.rupees(x.amt)).font(.subheadline.weight(.semibold)).monospacedDigit().privacySensitive()
                        }
                        .padding(.vertical, 9)
                        .accessibilityElement(children: .combine)
                    }
                    if d.due.count > 6 {
                        Text("and \(d.due.count - 6) more on the calendar").font(.footnote).foregroundStyle(.secondary).padding(.top, 6)
                    }
                }
                .card(14)
            }
        }
    }

    func noticed(_ d: WeekDigest) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            SectionHeader(title: "kosh noticed")
            VStack(spacing: 0) {
                ForEach(Array(d.noticed.enumerated()), id: \.element.id) { i, f in
                    if i > 0 { Divider().padding(.leading, 40) }
                    let tint: Color = f.sev >= 3 ? Color.red : f.sev == 2 ? Color.orange : Color.kosh
                    HStack(alignment: .top, spacing: 12) {
                        Image(systemName: f.sym).font(.subheadline.weight(.semibold)).foregroundStyle(tint)
                            .frame(width: 28, height: 28)
                            .background(tint.opacity(0.12), in: RoundedRectangle(cornerRadius: 8, style: .continuous))
                        VStack(alignment: .leading, spacing: 2) {
                            Text(f.title).font(.subheadline.weight(.semibold)).fixedSize(horizontal: false, vertical: true).privacySensitive()
                            if !f.detail.isEmpty {
                                Text(f.detail).font(.footnote).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true).privacySensitive()
                            }
                        }
                        Spacer(minLength: 0)
                    }
                    .padding(.vertical, 9)
                    .accessibilityElement(children: .combine)
                }
            }
            .card(14)
        }
    }

    func fees(_ f: FundFeesInfo) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            SectionHeader(title: "Your investments")
            NavigationLink { FundFeesList() } label: {
                HStack(spacing: 12) {
                    IconTile(symbol: "percent", color: Color.sky, size: 34)
                    VStack(alignment: .leading, spacing: 1) {
                        Text(FundFeesList.headline(f)).font(.subheadline.weight(.semibold)).foregroundStyle(Color.primary)
                            .fixedSize(horizontal: false, vertical: true).privacySensitive()
                        Text("Regular plans against the Direct plans of the same funds").font(.footnote).foregroundStyle(.secondary)
                    }
                    Spacer(minLength: 8)
                    Image(systemName: "chevron.right").font(.caption.weight(.bold)).foregroundStyle(.tertiary)
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(.press)
            .card(16)
        }
    }
}

// MARK: - Fund fees, in rupees

/// each Regular plan: its fee against the Direct plan's, what that costs a year and over ten years; the plans kosh
/// can't work out, said so and why
struct FundFeesList: View {
    @Environment(Store.self) private var store

    /// "About ₹6,600 a year more than Direct", or what's still to come
    static func headline(_ f: FundFeesInfo) -> String {
        if f.year >= 1 { return "About " + Fmt.rupees(Fmt.roundish(f.year)) + " a year more than Direct" + (f.unknown.isEmpty ? "" : ", for the plans in AMFI’s list") }
        if !f.fetched { return "Fees from AMFI’s list arrive once kosh is online" }
        if !f.rows.isEmpty { return f.unknown.isEmpty ? "No extra fee against Direct" : "No extra fee for the plans in AMFI’s list" }
        return "Not worked out from AMFI’s list yet"
    }

    var body: some View {
        let p: Person = store.who
        let f: FundFeesInfo? = store.snap.brief?.fees
        let rows: [FundFeesInfo.Row] = (f?.rows ?? []).filter { p.owns($0.person) }
        let unknown: [FundFeesInfo.Unknown] = (f?.unknown ?? []).filter { p.owns($0.person) }
        let year: Double = rows.reduce(0) { $0 + $1.year }
        let ten: Double = rows.reduce(0) { $0 + $1.ten }
        List {
            Section {
                VStack(alignment: .leading, spacing: 6) {
                    Eyebrow(text: "Regular plans", color: Color.sky)
                    if year >= 1 {
                        Text("About " + Fmt.rupees(Fmt.roundish(year)) + " a year")
                            .font(.system(.title, design: .rounded, weight: .bold))
                            .minimumScaleFactor(0.6).lineLimit(1)
                            .privacySensitive()
                        Text(unknown.isEmpty ? "more than the Direct plans of the same funds would cost, at what they’re worth today."
                                             : "more than the Direct plans would cost, for the plans in AMFI’s list, at what they’re worth today.")
                            .font(.subheadline).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                        if ten >= 1 {
                            Text("About " + Fmt.words(Fmt.roundish(ten)) + " over ten years, if the money stays in.")
                                .font(.subheadline.weight(.semibold)).fixedSize(horizontal: false, vertical: true).privacySensitive()
                        }
                    } else {
                        Text(f.map(Self.headline) ?? "No Regular plans").font(.title3.weight(.bold))
                    }
                }
                .padding(.vertical, 6)
                .listRowBackground(Color.clear)
            }
            if !rows.isEmpty {
                Section {
                    ForEach(rows) { r in row(r, showWho: p == .family) }
                } header: { Text("Each plan") }
            }
            if !unknown.isEmpty {
                Section {
                    ForEach(unknown) { u in
                        VStack(alignment: .leading, spacing: 3) {
                            HStack(alignment: .firstTextBaseline) {
                                Text(HoldingName.pretty(u.name)).font(.subheadline).lineLimit(2)
                                Spacer(minLength: 8)
                                Text(Fmt.words(u.amt)).font(.subheadline).monospacedDigit().foregroundStyle(.secondary).privacySensitive()
                            }
                            if let why = Self.why(u) { Text(why).font(.caption).foregroundStyle(.secondary) }
                        }
                        .accessibilityElement(children: .combine)
                    }
                } header: { Text("Not worked out") } footer: {
                    Text(unknown.allSatisfy { ($0.why ?? "list") == "list" } ? "kosh fetches AMFI’s fee lists once it’s online; these will show then."
                                                                             : "kosh couldn’t tell from AMFI’s list what these cost against a Direct plan, so it doesn’t guess.")
                }
            }
            Section {} footer: { Text(footer(f)) }
        }
        .listStyle(.insetGrouped)
        .navigationTitle("Fund fees")
        .navigationBarTitleDisplayMode(.inline)
    }

    /// why a plan isn't worked out, when there's more to say than "not in the list"
    static func why(_ u: FundFeesInfo.Unknown) -> String? {
        switch u.why ?? "" {
        case "two": return "Two funds in AMFI’s list go by this name, at different fees"
        case "nodirect": return "AMFI lists no Direct plan of it to compare"
        default: return nil
        }
    }

    func row(_ r: FundFeesInfo.Row, showWho: Bool) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(alignment: .firstTextBaseline) {
                Text(HoldingName.pretty(r.name)).font(.subheadline.weight(.semibold)).lineLimit(2)
                Spacer(minLength: 8)
                Text(Fmt.words(r.amt)).font(.subheadline).monospacedDigit().foregroundStyle(.secondary).privacySensitive()
            }
            Text("Regular " + Fmt.trim(r.r, 2) + "% · Direct " + Fmt.trim(r.d, 2) + "% a year")
                .font(.footnote).foregroundStyle(.secondary)
            if r.year >= 1 {
                Text("About " + Fmt.rupees(Fmt.roundish(r.year)) + " a year, " + Fmt.words(Fmt.roundish(r.ten)) + " over ten years")
                    .font(.footnote.weight(.semibold)).privacySensitive()
            } else {
                Text("No extra fee against Direct").font(.footnote.weight(.semibold))
            }
            if showWho {
                Text(r.person == "me" ? "Yours" : store.ownerName(r.person)).font(.caption).foregroundStyle(.tertiary)
            }
        }
        .padding(.vertical, 4)
        .accessibilityElement(children: .combine)
    }

    func footer(_ f: FundFeesInfo?) -> String {
        var s: String = "A Regular plan pays a distributor’s commission out of the fund every year; the Direct plan of the same fund doesn’t. "
        s += "Ten years assumes the money stays in and the fund earns, before fees, 12% a year for equity and equity index funds, 10% for hybrid funds, "
        s += "7% for debt and arbitrage funds, and 9% for others, such as gold or overseas funds. "
        s += "Switching plans is a sale: it can mean capital gains tax and an exit load, so weigh it first. "
        if let f, let to = f.onTo, !to.isEmpty {
            let from: String = f.onFrom ?? ""
            s += from.isEmpty || from == to ? "Fees as AMFI listed them for " + Day.fmt(to, "d MMMM yyyy") + ". "
                                            : "Fees as AMFI listed them between " + Day.fmt(from, "d MMM") + " and " + Day.fmt(to, "d MMM yyyy") + ". "
        } else if let f, !f.asOf.isEmpty {
            s += "Fees from AMFI’s list for " + f.asOf.replacingOccurrences(of: "-", with: " ") + ". "
        }
        s += "To fetch them kosh asks AMFI for the fee lists of the fund houses you hold; nothing else about your money leaves the phone."
        return s
    }
}

// MARK: - Settings

/// the briefings' rows in Settings: the morning briefing and the Sunday digest, each on or off at its time on the
/// phone's clock; whether their notifications carry amounts and names; this week's digest
struct BriefSettingsRows: View {
    @Environment(Store.self) private var store
    @AppStorage(BriefNotes.morningOnKey) private var morningOn = BriefNotes.isOn(BriefNotes.morningOnKey)
    @AppStorage(BriefNotes.morningAtKey) private var morningAt = BriefNotes.morningDefault
    @AppStorage(BriefNotes.sundayOnKey) private var sundayOn = BriefNotes.isOn(BriefNotes.sundayOnKey)
    @AppStorage(BriefNotes.sundayAtKey) private var sundayAt = BriefNotes.sundayDefault
    @AppStorage(BriefNotes.figuresKey) private var figures = false
    @State private var status: UNAuthorizationStatus? = nil

    var body: some View {
        Section {
            TimedToggleRow(symbol: "sun.horizon.fill", color: Color(hex: "#FF9500"), title: "Morning briefing",
                           on: $morningOn, at: time($morningAt))
            TimedToggleRow(symbol: "calendar", color: Color(hex: "#FF3B30"), title: "Sunday digest",
                           on: $sundayOn, at: time($sundayAt))
            Toggle(isOn: $figures) {
                SettingsRow(symbol: "indianrupeesign", color: Color(hex: "#34C759"), title: "Amounts and names")
            }
            if (morningOn || sundayOn) && status == .notDetermined {
                Button("Allow notifications") { Task { await allow() } }
            } else if (morningOn || sundayOn) && status == .denied {
                Button("Turn on notifications in Settings") {
                    if let u = URL(string: UIApplication.openNotificationSettingsURLString) { UIApplication.shared.open(u) }
                }
            }
            NavigationLink { DigestPage() } label: {
                SettingsRow(symbol: "doc.text.magnifyingglass", color: Color(hex: "#007AFF"), title: "This week’s digest")
            }
        } header: { SettingsHeader("Briefings") } footer: {
            Text("Each morning: what’s due, what changed and the one thing to do; on Sunday, the week. With amounts and names off, the Lock Screen shows neither.")
        }
        .task { status = await UNUserNotificationCenter.current().notificationSettings().authorizationStatus }
        .onChange(of: morningOn) { _, _ in BriefNotes.reschedule(store) }
        .onChange(of: morningAt) { _, _ in BriefNotes.reschedule(store) }
        .onChange(of: sundayOn) { _, _ in BriefNotes.reschedule(store) }
        .onChange(of: sundayAt) { _, _ in BriefNotes.reschedule(store) }
        .onChange(of: figures) { _, _ in BriefNotes.reschedule(store) }
    }

    /// minutes after midnight on the phone's clock, as a time of day to pick (TimedToggleRow shows it)
    func time(_ minutes: Binding<Int>) -> Binding<Date> {
        Binding<Date>(
            get: { Calendar.current.date(bySettingHour: minutes.wrappedValue / 60, minute: minutes.wrappedValue % 60, second: 0, of: Date()) ?? Date() },
            set: { d in
                let c = Calendar.current.dateComponents([.hour, .minute], from: d)
                minutes.wrappedValue = (c.hour ?? 8) * 60 + (c.minute ?? 0)
            }
        )
    }

    func allow() async {
        let c = UNUserNotificationCenter.current()
        _ = try? await c.requestAuthorization(options: [.alert, .sound, .badge])
        status = await c.notificationSettings().authorizationStatus
        BriefNotes.reschedule(store)
    }
}

// MARK: - The notifications

/// the morning briefing and the Sunday digest as the phone's own notifications, remade after every build (and when
/// amounts are hidden or kosh is locked): each from what kosh knows at that build, rung at the time you picked on the
/// phone's clock, about India's day that time falls on. A morning with nothing to say rings nothing; what kosh noticed
/// rings once. Quiet words unless you asked for amounts and names, and always while amounts are hidden or kosh is
/// locked.
enum BriefNotes {
    static let morningOnKey = "brief.morning.on"
    static let morningAtKey = "brief.morning.at"
    static let sundayOnKey = "brief.sunday.on"
    static let sundayAtKey = "brief.sunday.at"
    static let figuresKey = "brief.figures"
    /// the heads-ups a morning has rung: id → the morning (India's day) it was set for
    static let rungKey = "brief.rung"
    /// 8:00 and 9:00, in minutes after midnight
    static let morningDefault = 8 * 60
    static let sundayDefault = 9 * 60
    static let morningID = "brief|morning"
    static let sundayID = "brief|sunday"

    /// a briefing is on unless you said otherwise; for someone who turned kosh's reminders off, off until turned on
    static func isOn(_ key: String) -> Bool { UserDefaults.standard.object(forKey: key) as? Bool ?? Reminders.on }

    /// one notification to set: plain values, so it travels to the notification centre's queue as it is; for the
    /// morning, India's day it's for and the heads-up it carries
    struct Spec: Sendable {
        let id: String; let title: String; let body: String; let fire: Date; let quiet: Bool; let open: String
        var day: String = ""; var thing: String? = nil
    }

    @MainActor static func reschedule(_ store: Store) {
        // never from a ledger not read in yet (kosh started while the phone was locked): it would say nothing happened
        if let live = store.live, !live.loadedFromDisk { return }
        let ud = UserDefaults.standard
        let morningAt: Int = ud.object(forKey: morningAtKey) as? Int ?? morningDefault
        let sundayAt: Int = ud.object(forKey: sundayAtKey) as? Int ?? sundayDefault
        let quiet: Bool = Reminders.quiet(store) || !ud.bool(forKey: figuresKey)
        let morningFire: Date = nextFire(at: morningAt)
        let morningDay: String = Day.iso(morningFire)
        var specs: [Spec] = []
        if isOn(morningOnKey), let s = morning(store, fire: morningFire, quiet: quiet) { specs.append(s) }
        if isOn(sundayOnKey), let s = sunday(store, at: sundayAt, quiet: quiet) { specs.append(s) }
        let toSet: [Spec] = specs
        let c = UNUserNotificationCenter.current()
        c.getNotificationSettings { settings in
            c.removePendingNotificationRequests(withIdentifiers: [morningID, sundayID])
            // figures now held back: a briefing on the Lock Screen with figures in it goes
            if quiet {
                c.getDeliveredNotifications { shown in
                    let loud: [String] = shown.filter { $0.request.identifier.hasPrefix("brief|") && ($0.request.content.userInfo["quiet"] as? Bool) != true }.map(\.request.identifier)
                    if !loud.isEmpty { c.removeDeliveredNotifications(withIdentifiers: loud) }
                }
            }
            let ok: Bool = settings.authorizationStatus == .authorized || settings.authorizationStatus == .provisional || settings.authorizationStatus == .ephemeral
            // the heads-up this morning carries, set against that morning, so no later morning rings it again
            let carried: String? = ok ? toSet.first(where: { $0.id == morningID })?.thing : nil
            noteRung(carried, day: morningDay)
            guard ok else { return }
            for s in toSet { c.add(request(s)) }
        }
    }

    static func request(_ s: Spec) -> UNNotificationRequest {
        let content = UNMutableNotificationContent()
        content.title = s.title
        content.body = s.body
        content.sound = .default
        content.threadIdentifier = "kosh.brief"
        content.userInfo = ["quiet": s.quiet, "open": s.open]
        // on the phone's clock, as the time was picked
        let comps: DateComponents = Calendar.current.dateComponents([.year, .month, .day, .hour, .minute], from: s.fire)
        return UNNotificationRequest(identifier: s.id, content: content, trigger: UNCalendarNotificationTrigger(dateMatching: comps, repeats: false))
    }

    /// when a time of day next comes on the phone's clock (on that weekday, given one: 1 is Sunday)
    static func nextFire(at minutes: Int, weekday: Int? = nil, now: Date = Date()) -> Date {
        var c = DateComponents()
        c.hour = minutes / 60; c.minute = minutes % 60; c.second = 0
        c.weekday = weekday
        return Calendar.current.nextDate(after: now, matching: c, matchingPolicy: .nextTime) ?? now.addingTimeInterval(86_400)
    }

    /// the next morning's briefing, for India's day that morning falls on: this morning's while its time is still
    /// ahead, else tomorrow's from what's in now. What's due leads; then the one thing kosh noticed; then the rest,
    /// four sentences in all (more only when more is due)
    @MainActor static func morning(_ store: Store, fire: Date, quiet: Bool) -> Spec? {
        let day: String = Day.iso(fire)
        guard let brief = store.snap.brief else { return nil }
        let found: Briefing? = brief.daily?.day == day ? brief.daily : (brief.next?.day == day ? brief.next : nil)
        guard let b = found, b.worth else { return nil }
        let thing: Briefing.Thing? = ringable(b, store, day: day)
        let lines: [String] = quiet ? b.qlines : b.lines
        let lead: Int = min(max(b.lead ?? 0, 0), lines.count)
        var parts: [String] = Array(lines.prefix(lead))
        if let thing { parts.append(quiet ? thing.quiet : thing.line) }
        parts += lines.dropFirst(lead)
        parts = Array(parts.prefix(max(4, lead + (thing == nil ? 0 : 1))))
        guard !parts.isEmpty else { return nil }
        return Spec(id: morningID, title: "Your morning briefing", body: parts.joined(separator: " "), fire: fire, quiet: quiet, open: "brief", day: day, thing: thing?.id)
    }

    /// the one thing a morning rings: kosh's most pressing heads-up you haven't snoozed or marked done, that no
    /// earlier morning has rung, and that kosh's reminders don't ring on their own (a late fee, a charge twice, what
    /// needs you now: those ring as they come)
    @MainActor static func ringable(_ b: Briefing, _ store: Store, day: String) -> Briefing.Thing? {
        let ud = UserDefaults.standard
        let rung: [String: String] = ud.dictionary(forKey: rungKey) as? [String: String] ?? [:]
        let elsewhere: Set<String> = Set(LiveSession.times(.noticedAt).keys)
        let shown: Set<String> = Set(store.watchShown.map(\.id))
        return b.things.first { t in
            guard shown.contains(t.id), !elsewhere.contains(t.id) else { return false }
            guard let set = rung[t.id] else { return true }
            return set >= day
        }
    }

    /// what the next morning carries: `id`, set for `day`; anything else set for that day (and so never rung) let go,
    /// and what was rung six weeks ago and more forgotten
    static func noteRung(_ id: String?, day: String) {
        let ud = UserDefaults.standard
        let had: [String: String] = ud.dictionary(forKey: rungKey) as? [String: String] ?? [:]
        let oldest: String = Day.add(day, -45)
        var keep: [String: String] = had.filter { $0.value < day && $0.value >= oldest }
        if let id { keep[id] = day }
        if keep != had { ud.set(keep, forKey: rungKey) }
    }

    /// the next Sunday's digest at the time picked on the phone's clock: in its own words when this build made that
    /// Sunday's week (built that Sunday, India's day), else a line that it's ready, since the week isn't over yet
    @MainActor static func sunday(_ store: Store, at minutes: Int, quiet: Bool) -> Spec? {
        let fire: Date = nextFire(at: minutes, weekday: 1)
        let day: String = Day.iso(fire)
        if let d = store.snap.brief?.digest, d.to == day, !d.lines.isEmpty {
            return Spec(id: sundayID, title: d.title, body: (quiet ? d.qlines : d.lines).joined(separator: " "), fire: fire, quiet: quiet, open: "digest", day: day)
        }
        return Spec(id: sundayID, title: "Your week in money", body: "What went out, what came in, and what’s due in the week ahead. Open kosh to read it.",
                    fire: fire, quiet: true, open: "digest", day: day)
    }
}

// MARK: - AMFI's fee lists

/// What each fund's Regular and Direct plans charge. AMFI publishes every scheme's total expense ratio, both plans side
/// by side, day by day, on its site (amfiindia.com › Total Expense Ratio, read through the same API its page uses:
/// /api/populate-mf, /api/populate-ter-month, /api/populate-te-rdata-revised). kosh asks only for the fund houses of
/// the Regular plans you hold, each about once a week (soon for a house not asked before, an hour after one whose ask
/// failed), keeps each scheme's latest figures (fees.json), and hands them to the engine as prof.brief.ter (brief.js
/// works out the rupees). The requests name a fund house and a month, nothing else, over a session that keeps no
/// cookies past Erase. brief.js reads AMFI's answers and decides what to ask and how what comes back joins what kosh
/// had (engine-test/brief.js tests both); this class fetches.
final class FundFees: @unchecked Sendable {
    static let shared = FundFees()

    /// one scheme's fees: its fund house (AMFI's number), name, category, Regular and Direct TER (percent a year), and
    /// the day they're for (yyyy-MM-dd)
    struct Row: Codable, Hashable { var mf: String; var s: String; var cat: String; var r: Double; var d: Double; var on: String }
    struct House: Codable, Hashable { var id: String; var name: String }
    struct Saved: Codable {
        /// the day fees last came, and when kosh last asked for AMFI's list of houses
        var at: String = ""; var tried: Date = .distantPast
        /// the newest month among the fees (yyyy-MM), and, in a file from before, the houses they covered
        var month: String = ""; var houses: [String] = []
        var rows: [Row] = []
        /// AMFI's fund houses, and the day that list was fetched
        var list: [House] = []; var listAt: String = ""
        /// each house: the day its fees last came (or AMFI said it had none yet); when asking it last failed (seconds
        /// since 1970); and the houses whose list was longer than kosh reads at once
        var seen: [String: String]? = nil
        var miss: [String: Double]? = nil
        var cut: [String]? = nil
    }
    /// what brief.js makes of what came back (briefTerMergeJSON)
    private struct Merged: Decodable { var rows: [Row]; var seen: [String: String]; var miss: [String: Double]; var cut: [String]; var at: String; var month: String }
    /// one house's answer for brief.js: rows, none (AMFI has nothing for it yet) or fail
    private struct Got: Encodable { var id: String; var status: String; var rows: [Row] = []; var cut: Bool = false }
    private struct Month: Decodable { var value: String; var name: String; var key: String }
    private struct Page: Decodable { var rows: [Row]; var pages: Int; var n: Int }

    static let site = "https://www.amfiindia.com"
    /// a house's list, a page of 100 at a time, read to this many pages (past it, what came only adds to what kosh had)
    static let pageSize = 100, mostPages = 60
    private let lock = NSLock()
    private var saved = Saved()
    /// what the engine takes, made when the fees change, so a build on the main thread only picks it up
    private var payload: [String: Any]? = nil
    private var loaded = false
    private var running = false
    /// counts up on Erase, so a fetch under way then doesn't write its fees back
    private var gen = 0
    private var session: URLSession = FundFees.makeSession()
    private var url: URL { LiveSession.folder.appendingPathComponent("fees.json") }

    init() { lock.lock(); loadIfNeeded(); lock.unlock() }

    /// no cache, and nothing that outlives the session, which Erase ends
    private static func makeSession() -> URLSession {
        let c = URLSessionConfiguration.ephemeral
        c.urlCache = nil
        c.requestCachePolicy = .reloadIgnoringLocalCacheData
        c.timeoutIntervalForRequest = 45
        return URLSession(configuration: c)
    }

    /// fees.json read in (call with the lock held): kosh may start while the phone is locked, when its files can't
    /// be read yet, so it tries again until it can
    private func loadIfNeeded() {
        guard !loaded else { return }
        if !FileManager.default.fileExists(atPath: url.path) { loaded = true; return }
        guard let d = try? Data(contentsOf: url) else { return }
        loaded = true
        if let s = try? JSONDecoder().decode(Saved.self, from: d) { saved = s; payload = Self.payload(s) }
    }

    private static func payload(_ s: Saved) -> [String: Any]? {
        guard !s.rows.isEmpty else { return nil }
        let rows: [[String: Any]] = s.rows.map { ["mf": $0.mf, "s": $0.s, "cat": $0.cat, "r": $0.r, "d": $0.d, "on": $0.on] }
        return ["month": s.month, "at": s.at, "rows": rows]
    }

    /// what the engine takes as prof.brief.ter
    var forEngine: [String: Any]? {
        lock.lock(); defer { lock.unlock() }
        loadIfNeeded()
        return payload
    }

    /// Erase: the fees go with everything else (which houses they're for says what's held), and the session with them
    func clear() {
        lock.lock()
        saved = Saved(); payload = nil; loaded = true; gen += 1
        let old: URLSession = session
        session = Self.makeSession()
        lock.unlock()
        old.invalidateAndCancel()
        try? FileManager.default.removeItem(at: url)
    }

    /// the plan and option words said after a fund's own name, as brief.js reads them (its TAIL_WORDS: engine-test/
    /// brief.js checks the two lists agree)
    static let tailWords: Set<String> = ["regular", "reg", "rg", "direct", "dir", "plan", "plans", "option", "options", "opt", "growth", "gr", "idcw",
                                         "dividend", "div", "payout", "reinvestment", "reinvest", "bonus", "cumulative", "accumulation", "daily", "weekly",
                                         "fortnightly", "monthly", "quarterly", "halfyearly", "annual", "yearly", "sweep", "transfer", "of", "the"]

    /// a Regular plan by its name: its plan words say Regular, and not Direct ("… Regular Savings Fund - Growth" names
    /// no plan; "… Fund Reg Gr" is a Regular plan)
    static func isRegular(_ name: String) -> Bool {
        let tail: [String] = planWords(name)
        return tail.contains { $0 == "regular" || $0 == "reg" || $0 == "rg" } && !tail.contains { $0 == "direct" || $0 == "dir" }
    }

    /// the run of plan and option words at the end of a fund's name ("- Regular Plan - Growth"), the way brief.js finds it
    static func planWords(_ name: String) -> [String] {
        var s: String = bracketed(name.lowercased())
        if let r = s.range(of: #"\b(?:formerly(?: known as)?|erstwhile)\b.*$"#, options: .regularExpression) { s.replaceSubrange(r, with: " ") }
        let forms: [(String, String)] = [(#"\bincome\s+distribution\s+(?:cum|and)\s+capital\s+withdrawal\b"#, " idcw "), (#"\bhalf[\s-]*yearly\b"#, " halfyearly "),
                                         (#"\bre[\s-]*investment\b"#, " reinvestment "), (#"\bpay[\s-]*out\b"#, " payout ")]
        for (pattern, word) in forms { s = s.replacingOccurrences(of: pattern, with: word, options: .regularExpression) }
        var words: [String] = s.split { !($0.isASCII && ($0.isLetter || $0.isNumber)) }.map(String.init)
        var tail: [String] = []
        while let last = words.last, tailWords.contains(last) { tail.insert(last, at: 0); words.removeLast() }
        return tail
    }

    /// a plan said in brackets ("(Regular Plan)") is the plan; anything else in brackets (an old name) isn't the fund's
    private static func bracketed(_ s: String) -> String {
        var out: String = ""
        var rest: Substring = Substring(s)
        while let open = rest.firstIndex(of: "("), let close = rest[open...].firstIndex(of: ")") {
            out += rest[..<open]
            let inner: String = String(rest[rest.index(after: open)..<close])
            let w: [String] = inner.split { !($0.isASCII && ($0.isLetter || $0.isNumber)) }.map(String.init)
            let plan: Bool = !w.isEmpty && w.allSatisfy { tailWords.contains($0) }
            out += plan ? " " + inner + " " : " "
            rest = rest[rest.index(after: close)...]
        }
        return out + rest
    }

    /// Fetch the fees for the houses of the Regular plans among these funds (their names), the houses that are due.
    /// True when the fees changed, so the screens are laid out again only then.
    func refresh(_ funds: [String]) async -> Bool {
        let regular: [String] = funds.filter(Self.isRegular)
        guard !regular.isEmpty, let started = begin() else { return false }
        let had: Saved = started.saved, era: Int = started.era, session: URLSession = started.session
        var s: Saved = had
        let today: String = LiveSession.today
        let now: Date = Date()
        // AMFI's fund houses: monthly (a failed ask waits an hour)
        if (s.list.isEmpty || LiveSession.daysSince(s.listAt) > 30) && now.timeIntervalSince(s.tried) > 3600 {
            s.tried = now
            if let l = await Self.houses(session), !l.isEmpty { s.list = l; s.listAt = today }
        }
        let ids: [String] = Self.houseIDs(regular, s.list)
        let want: [String] = Self.due(s, ids, today: today, now: now)
        guard !want.isEmpty else { _ = finish(s, era); return false }
        // the newest months AMFI has fees for (this financial year's, else last year's): fewest days to read
        let months: [Month] = await Self.months(today, session)
        var got: [Got] = []
        for id in want {
            // the newest month with fees for this house; one that can't be had (not out yet, or the network) falls
            // to the month before, and the house counts as failed only if nothing came
            var g = Got(id: id, status: months.isEmpty ? "fail" : "none")
            var failed: Bool = false
            for m in months.prefix(2) {
                guard let list = await Self.fees(house: id, month: m.value, session) else { failed = true; continue }
                if list.rows.isEmpty { continue }
                g.status = "rows"; g.rows = list.rows; g.cut = list.cut
                break
            }
            if g.status != "rows" && failed { g.status = "fail" }
            got.append(g)
        }
        guard let m = Self.merged(s, got, today: today, now: now) else { _ = finish(s, era); return false }
        var next: Saved = s
        next.rows = m.rows; next.seen = m.seen; next.miss = m.miss; next.cut = m.cut; next.at = m.at; next.month = m.month
        let changed: Bool = next.rows != had.rows
        return finish(next, era) && changed
    }

    /// the one refresh at a time, with what kosh has and the session to ask with
    private func begin() -> (saved: Saved, era: Int, session: URLSession)? {
        lock.lock(); defer { lock.unlock() }
        if running { return nil }
        running = true
        loadIfNeeded()
        return (saved: saved, era: gen, session: session)
    }
    /// what a refresh came to, saved, unless Erase came first
    private func finish(_ next: Saved, _ era: Int) -> Bool {
        lock.lock()
        running = false
        guard era == gen else { lock.unlock(); return false }
        saved = next
        payload = Self.payload(next)
        lock.unlock()
        if let d = try? JSONEncoder().encode(next) { try? d.write(to: url, options: [.atomic, LiveSession.protection]) }
        return true
    }

    /// the houses of these Regular plans, by AMFI's numbers (brief.js matches the names)
    static func houseIDs(_ names: [String], _ list: [House]) -> [String] {
        guard !list.isEmpty else { return [] }
        let houses: [[String: String]] = list.map { ["mfId": $0.id, "mfName": $0.name] }
        guard let out = try? Engine.builder.call("briefFeesHousesJSON", [JSONText.encode(names), JSONText.encode(houses)]),
              let ids = try? JSONText.decode([String].self, out) else { return [] }
        return ids
    }

    /// which of these houses to ask now (brief.js: never asked, a week since, an hour after a failure)
    private static func due(_ s: Saved, _ ids: [String], today: String, now: Date) -> [String] {
        guard !ids.isEmpty, let out = try? Engine.builder.call("briefTerDueJSON", [JSONText.encode(s), JSONText.encode(ids), today, String(now.timeIntervalSince1970)]),
              let want = try? JSONText.decode([String].self, out) else { return [] }
        return want
    }

    private static func merged(_ s: Saved, _ got: [Got], today: String, now: Date) -> Merged? {
        guard let out = try? Engine.builder.call("briefTerMergeJSON", [JSONText.encode(s), JSONText.encode(got), today, String(now.timeIntervalSince1970)]) else { return nil }
        return try? JSONText.decode(Merged.self, out)
    }

    /// one of AMFI's answers as text (nil when it can't be had)
    private static func text(_ path: String, _ query: [URLQueryItem], _ session: URLSession) async -> String? {
        var comps = URLComponents(string: site + path)
        comps?.queryItems = query.isEmpty ? nil : query
        guard let u = comps?.url else { return nil }
        var req = URLRequest(url: u, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 45)
        req.setValue(Prices.agent, forHTTPHeaderField: "User-Agent")
        req.setValue("application/json, text/plain, */*", forHTTPHeaderField: "Accept")
        req.setValue(site + "/ter-of-mf-schemes", forHTTPHeaderField: "Referer")
        guard let (data, resp) = try? await session.data(for: req), (resp as? HTTPURLResponse)?.statusCode == 200, !data.isEmpty else { return nil }
        return String(data: data, encoding: .utf8)
    }

    /// AMFI's fund houses
    private static func houses(_ session: URLSession) async -> [House]? {
        guard let t = await text("/api/populate-mf", [], session), let out = try? Engine.builder.call("briefTerHousesJSON", [t]) else { return nil }
        return try? JSONText.decode([House].self, out)
    }

    /// the months AMFI has fees for, newest first: this financial year's, then last year's
    private static func months(_ today: String, _ session: URLSession) async -> [Month] {
        let y: Int = Int(today.prefix(4)) ?? 2026
        let m: Int = Int(today.dropFirst(5).prefix(2)) ?? 4
        let fy: Int = m >= 4 ? y : y - 1
        var by: [String: Month] = [:]
        for start in [fy, fy - 1] {
            let q: [URLQueryItem] = [URLQueryItem(name: "year", value: "\(start)-\(start + 1)")]
            guard let t = await text("/api/populate-ter-month", q, session), let out = try? Engine.builder.call("briefTerMonthsJSON", [t, today]),
                  let got = try? JSONText.decode([Month].self, out) else { continue }
            for x in got where by[x.key] == nil { by[x.key] = x }
            if by.count >= 2 { break }
        }
        return by.values.sorted { $0.key > $1.key }
    }

    /// one house's fees for a month, each scheme's latest day, and whether the list ran past what kosh reads at once;
    /// nil when a page couldn't be had or read
    private static func fees(house: String, month: String, _ session: URLSession) async -> (rows: [Row], cut: Bool)? {
        var latest: [String: Row] = [:]
        var page = 1, pages = 0
        while page <= mostPages {
            let q: [URLQueryItem] = [URLQueryItem(name: "MF_ID", value: house), URLQueryItem(name: "Month", value: month),
                                     URLQueryItem(name: "strCat", value: "-1"), URLQueryItem(name: "strType", value: "-1"),
                                     URLQueryItem(name: "page", value: String(page)), URLQueryItem(name: "pageSize", value: String(pageSize))]
            guard let t = await text("/api/populate-te-rdata-revised", q, session),
                  let out = try? Engine.builder.call("briefTerPageJSON", [house, t]),
                  let got = try? JSONText.decode(Page.self, out) else { return nil }
            for r in got.rows {
                let k: String = r.s.lowercased()
                if let had = latest[k], had.on >= r.on { continue }
                latest[k] = r
            }
            if got.pages > 0 { pages = got.pages }
            let more: Bool = pages > 0 ? page < pages : got.n >= pageSize
            if !more { return (latest.values.sorted { $0.s < $1.s }, false) }
            page += 1
        }
        return (latest.values.sorted { $0.s < $1.s }, true)
    }
}
