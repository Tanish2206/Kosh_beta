import Foundation

// MARK: - The four ways one payment is split, each adding up to the paisa
//
// However a split is set up, the arithmetic has the same shape: whoever is left out of this one takes nothing,
// everyone else's part is worked out, and whoever paid takes what is left over. So the parts always come to the
// payment exactly — a rounding paisa lands on the payer, as it does when kosh splits a bill equally — and nothing
// is lost or invented.
//   · Equally       everyone the same
//   · Your share    you slide yours, the others split the rest evenly (then the last of them takes the odd paisa,
//                   since the part you set is the one you asked for)
//   · By shares     someone counts for two; the same numbers read as percentages (2 shares of 4 is half)
//   · Amounts       each person's amount as you say it, and the rest is yours
// A person can be out of one payment without leaving the household: their seat stays, taking nothing.
//
// Nothing here knows about screens, so this is the one place a split's figures come from.

/// how the parts of a split are worked out
enum SplitWay: String, CaseIterable, Hashable {
    case equal, yours, shares, exact
    /// the chip on screen
    var title: String {
        switch self {
        case .equal: return "Equally"
        case .yours: return "Your share"
        case .shares: return "By shares"
        case .exact: return "Amounts"
        }
    }
}

/// one seat at a split: who it is, whether they are in this one, and how much of it they take
struct SplitSeat: Hashable {
    /// the name their line under Owed to you will carry; empty for a seat nobody has named
    var name: String = ""
    /// in this payment, or left out of this one only
    var inIt: Bool = true
    /// by shares: how many shares they count for (1 unless you say otherwise)
    var shares: Int = 1
    /// amounts: what they pay; nil until you say
    var amount: Double? = nil
}

enum SplitWays {
    /// the most people one payment can be split between
    static let most: Int = 12
    /// the most shares one person can count for
    static let mostShares: Int = 9

    /// a figure to the paisa
    static func paisa(_ v: Double) -> Double { (v * 100).rounded() / 100 }

    /// each seat's part of the payment, seat 0 being whoever paid. Everyone left out takes nothing; the payer takes
    /// whatever the others don't, so the parts come to the total to the paisa whichever way it was split.
    static func parts(total: Double, seats: [SplitSeat], way: SplitWay) -> [Double] {
        var out: [Double] = Array(repeating: 0, count: seats.count)
        guard !seats.isEmpty else { return out }
        let whole: Double = max(0, paisa(total))
        // the others' seats: the payer's own part is never set here, it is what's left
        let others: [Int] = seats.indices.filter { $0 != 0 && seats[$0].inIt }
        switch way {
        case .equal:
            let n: Int = others.count + (seats[0].inIt ? 1 : 0)
            guard n > 0 else { out[0] = whole; return out }
            let part: Double = paisa(whole / Double(n))
            for i in others { out[i] = part }
        case .yours:
            // your own part is the one you set, so the last of the others takes the odd paisa instead of you
            let you: Double = seats[0].inIt ? min(max(0, paisa(seats[0].amount ?? 0)), whole) : 0
            guard let last = others.last else { out[0] = whole; return out }
            let part: Double = paisa((whole - you) / Double(others.count))
            for i in others { out[i] = part }
            out[last] = paisa(whole - you - part * Double(others.count - 1))
            out[0] = you
            return out
        case .shares:
            var all: Int = others.reduce(0) { $0 + max(0, seats[$1].shares) }
            if seats[0].inIt { all += max(0, seats[0].shares) }
            guard all > 0 else { out[0] = whole; return out }
            for i in others { out[i] = paisa(whole * Double(max(0, seats[i].shares)) / Double(all)) }
        case .exact:
            for i in others { out[i] = max(0, paisa(seats[i].amount ?? 0)) }
        }
        out[0] = paisa(whole - others.reduce(0) { $0 + out[$1] })
        // (whoever paid but is out of this one takes no rounding paisa: the last of the others does, so ₹100 between
        // three of them is 33.33, 33.33 and 33.34 and all ₹100 comes back to you, not 99.99)
        let weighed: Bool = way == .equal ? !others.isEmpty : way == .shares ? others.contains { seats[$0].shares > 0 } : false
        if !seats[0].inIt && weighed, let last = others.last(where: { way == .equal || seats[$0].shares > 0 }) {
            out[last] = paisa(out[last] + out[0])
            out[0] = 0
        }
        return out
    }

    /// more has been given away than was paid: the split can't be made (the payer's part has gone below zero)
    static func over(_ parts: [Double]) -> Bool { (parts.first ?? 0) < -0.005 }

    /// what comes back to you: everyone else's parts together
    static func back(_ parts: [Double]) -> Double { paisa(parts.dropFirst().reduce(0, +)) }

    /// what's split, from the payment as kosh counts it (net: a refund kosh saw is already off it, refunded is how
    /// much): with a seen refund, the net payment, or the refund put back on when you leave it in (useBack off); with
    /// none, the payment less the money back you typed. The refund is taken off once, never again from the net
    static func toSplit(net: Double, refunded: Double, typedBack: Double, useBack: Bool) -> Double {
        if refunded > 0 { return paisa(useBack ? net : net + refunded) }
        return max(0, paisa(net - min(net, max(0, typedBack))))
    }

    /// what stays yours, as the engine's "mine" reads it: the payment before any refund (the engine sets mine first and
    /// takes the refund off after, 21a then 21b) less what the others owe. From the net payment it would be the refund
    /// taken off twice
    static func mine(net: Double, refunded: Double, owed: Double) -> Double { max(0, paisa(net + max(0, refunded) - owed)) }

    /// a seat's part as a share of the whole, for the percentage beside it (0 when the payment is nothing)
    static func fraction(total: Double, part: Double) -> Double {
        let whole: Double = max(0, paisa(total))
        return whole > 0 ? part / whole : 0
    }

    /// the amounts a split starts from when you move to a way that asks for them, so nothing has to be typed from
    /// scratch: whatever each person's part is right now
    static func filled(_ seats: [SplitSeat], parts: [Double]) -> [SplitSeat] {
        var out: [SplitSeat] = seats
        for i in out.indices where i != 0 && i < parts.count { out[i].amount = out[i].inIt ? parts[i] : nil }
        return out
    }

    /// everyone in a split, the payer apart, in plain words: "Ria, Kabir and 2 others"
    static func names(_ seats: [SplitSeat]) -> String {
        var named: [String] = []
        var rest: Int = 0
        for s in seats.dropFirst() where s.inIt {
            let n: String = s.name.trimmingCharacters(in: .whitespaces)
            if n.isEmpty { rest += 1 } else { named.append(n) }
        }
        if rest > 0 { named.append(rest == 1 ? "someone else" : String(rest) + " others") }
        if named.isEmpty { return "" }
        if named.count == 1 { return named[0] }
        return named.dropLast().joined(separator: ", ") + " and " + (named.last ?? "")
    }

    /// everything still open with one person, netted into one figure: money owed to you counts up, money you owe
    /// counts down. Positive, they pay you; negative, you pay them.
    static func netted(_ items: [(dir: String, amount: Double)]) -> Double {
        paisa(items.reduce(0) { $0 + ($1.dir == "in" ? $1.amount : -$1.amount) })
    }

    /// who is out of this one, in plain words: "Kabir is out of this one", "Kabir and Ria are out of this one"
    static func leftOut(_ seats: [SplitSeat]) -> String {
        let out: [String] = seats.dropFirst().filter { !$0.inIt && !$0.name.trimmingCharacters(in: .whitespaces).isEmpty }.map(\.name)
        guard !out.isEmpty else { return "" }
        if out.count == 1 { return out[0] + " is out of this one" }
        let list: String = out.dropLast().joined(separator: ", ") + " and " + (out.last ?? "")
        return list + " are out of this one"
    }
}
