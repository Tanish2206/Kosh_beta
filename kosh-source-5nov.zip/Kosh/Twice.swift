import SwiftUI

// MARK: - Money in that shouldn't count, and a payment listed twice
//
// A payment's sheet for money that came in gets the same one-button choice a spend has: it counts as money in, or
// it's left out (it stays in the list, out of every total). Any payment with the same sum a few days either side gets
// "Listed twice?": one tap says they're the same payment, and kosh keeps the other line and counts it once (the
// "Counted twice?" merge, from the sheet itself). Both come with Undo.

extension Store {
    /// payments that could be this one told twice: the same sum, the same way (in or out), within five days
    func twins(of t: Txn) -> [Txn] {
        guard t.partOf == nil, live != nil else { return [] }
        let inn: Bool = t.dr == "in" || t.k == "in"
        let found: [Txn] = tx.filter { o in
            o.id != t.id && abs(o.a - t.a) < 0.5 && o.partOf == nil && (o.dr == "in" || o.k == "in") == inn
                && abs(Day.between(o.d, t.d)) <= 5
        }
        return Array(found.sorted { abs(Day.between($0.d, t.d)) < abs(Day.between($1.d, t.d)) }.prefix(3))
    }

    /// this payment is that one, told twice: it goes from the list and every total, the other stays. Undo.
    func sameAs(_ id: String, keep: String) {
        guard let live else { return }
        let saved: [String: Override?] = [id: live.overrides[id]]
        let gone: Txn? = tx.first { $0.id == id }
        tx.removeAll { $0.id == id }
        live.override(id) { $0.dup = keep }
        live.rebuildSoon()
        undoNote = UndoNote(text: "Counted once now") { [weak self] in
            guard let self else { return }
            if let gone, !self.tx.contains(where: { $0.id == id }) { self.tx.insert(gone, at: 0) }
            self.restore(saved)
        }
    }

    /// count money that came in, or leave it out, from a swipe: with Undo
    func swipeCountIn(_ t: Txn, _ on: Bool) {
        let saved: [String: Override?] = [t.id: live?.overrides[t.id]]
        setCounted(t.id, on)
        undoNote = UndoNote(text: on ? "Counted as money in" : "Left out of money in") { [weak self] in self?.restore(saved) }
    }
}

/// does money that came in count: one full-width button, and what it means in plain words
struct InCountRow: View {
    @Environment(Store.self) private var store
    let t: Txn
    var body: some View {
        let on: Bool = CountSection.counted(t)
        Group {
            Button {
                store.setCounted(t.id, !CountSection.counted(store.txn(t.id)))
            } label: {
                ZStack {
                    Capsule().fill(Color.primary.opacity(on ? 1 : 0.08))
                    HStack(spacing: 9) {
                        Image(systemName: on ? "checkmark.circle.fill" : "nosign")
                            .font(.body.weight(.bold))
                            .foregroundStyle(on ? Color.green : Color.orange)
                            .contentTransition(.symbolEffect(.replace))
                        Text(on ? "Counts as money in" : "Left out of money in")
                            .font(.body.weight(.semibold))
                            .foregroundStyle(on ? Color(uiColor: .systemBackground) : Color.primary)
                            .contentTransition(.opacity)
                    }
                }
                .frame(height: 52)
                .contentShape(Capsule())
                .animation(Motion.base, value: on)
            }
            .buttonStyle(.press)
            .accessibilityAddTraits(.isToggle)
            .accessibilityValue(on ? "Counted" : "Left out")
            .accessibilityHint(on ? "Leaves it out of money in" : "Counts it as money in")
            .sensoryFeedback(.selection, trigger: on)
            Text(on ? "In what came in, on Home’s Cash flow and in income. Tap to leave it out if it isn’t really money in."
                    : "You left it out. It stays in the list, out of every total.")
                .font(.footnote)
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
                .padding(.horizontal, 6)
        }
    }
}

/// the same sum a few days either side: one tap says it's this payment told twice
struct TwiceCard: View {
    @Environment(Store.self) private var store
    let t: Txn
    let twins: [Txn]
    /// the sheet closes once this one's gone
    let done: () -> Void
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            SheetCard {
                Label("Listed twice?", systemImage: "doc.on.doc")
                    .font(.subheadline.weight(.semibold))
                    .padding(.horizontal, 16)
                    .padding(.vertical, 14)
                ForEach(twins) { o in
                    Divider().padding(.leading, 16)
                    HStack(spacing: 12) {
                        VStack(alignment: .leading, spacing: 2) {
                            Text(o.m).font(.subheadline.weight(.medium)).lineLimit(1)
                            Text(Day.short(o.d) + (o.card.isEmpty ? "" : " · " + o.card))
                                .font(.caption).foregroundStyle(.secondary).lineLimit(1)
                        }
                        Spacer(minLength: 8)
                        Text(Fmt.rupees(o.a)).font(.subheadline.weight(.semibold)).monospacedDigit()
                        Button("Same one") {
                            store.sameAs(t.id, keep: o.id)
                            done()
                        }
                        .buttonStyle(.glass)
                        .accessibilityHint("Counts this payment once, keeping the other line")
                    }
                    .padding(.horizontal, 16)
                    .padding(.vertical, 8)
                    .privacySensitive()
                }
            }
            SheetFootnote("The same sum within a few days. If it’s one payment told twice, this line goes and the other counts once.")
        }
    }
}

// MARK: - Paid from: the bank behind a payment made through an app
//
// CRED's receipt (and a gateway's) names the card it paid, never the account the UPI left. The payment's sheet asks
// once: pick the account, and every other payment through that app follows until you pick another on one of them.

extension Store {
    /// apps and rails whose receipts don't name your bank
    static let rails: Set<String> = ["cred", "amazon pay", "phonepe", "paytm", "google pay", "gpay", "mobikwik", "billdesk", "razorpay", "payu", "cashfree", "bbps", "bharat bill pay"]

    /// whether the account a payment through an app left is known (you said, or kosh's likely one)
    func paidFromKnown(_ t: Txn) -> Bool {
        guard let v = t.via, !v.isEmpty else { return railOf(t) == nil }
        return (t.bk ?? "").caseInsensitiveCompare(v) != .orderedSame
    }

    /// the app a payment went through, when its bank isn't known from it
    func railOf(_ t: Txn) -> String? {
        if let v = t.via, !v.isEmpty { return v }
        guard (t.dr ?? "out") == "out", let b = t.bk, Self.rails.contains(b.lowercased()) else { return nil }
        return b
    }

    func setPaidFrom(_ id: String, _ a: Account) {
        guard let live, let t = txn(id), let app = railOf(t) else { return }
        let key: String = a.keys?.first ?? a.id
        let v: String = a.bank + "|" + a.last + "|" + key
        let saved: [String: Override?] = [id: live.overrides[id]]
        let before: String? = live.railFrom[app.lowercased()]
        live.override(id) { $0.from = v }
        live.railFrom[app.lowercased()] = v
        live.rebuildSoon(force: true)
        undoNote = UndoNote(text: "Paid from " + a.bank + (a.last.isEmpty ? "" : " ••" + a.last)) { [weak self] in
            self?.live?.railFrom[app.lowercased()] = before
            self?.restore(saved)
        }
    }
}

/// which of your accounts a payment through an app really left
struct PaidFromCard: View {
    /// how kosh knows (or is still finding out) which account it was
    static func why(_ t: Txn, app: String, known: Bool, likely: Bool) -> String {
        let platform: String = app + " is the app it went through, not an account: its receipt names the card paid, never your bank. "
        if t.fb == true { return "Matched from your bank’s daily balance: it fell by exactly what these " + app + " payments add up to. " + "You can still pick another." }
        if likely { return "Likely: most of your earlier " + app + " payments left this account. " + platform + "kosh settles it once your bank’s balance mail or statement comes." }
        if known { return platform + "You said which account; other " + app + " payments follow it." }
        return platform + "kosh finds the account from your bank’s alerts, its daily balance mail or its statement. You can also pick it now."
    }

    /// the app's own balance is always a place the money could have come from (Amazon Pay balance, Paytm wallet…),
    /// even before kosh has seen a top-up mail for it
    static func withOwnBalance(_ w: [Account], app: String) -> [Account] {
        let k: String = app.lowercased().components(separatedBy: " ").first ?? ""
        if k.isEmpty || w.contains(where: { $0.bank.lowercased().contains(k) || $0.name.lowercased().contains(k) }) { return w }
        let own = Account(id: "wallet-" + k, bank: app + " balance", name: app + " balance", last: "", kind: "wallet", balance: nil, asOf: "", count: 0, month: 0, last30: 0, lastUsed: "", owner: "me", color: "#FF9F0A", keys: [app + " balance"])
        return w + [own]
    }

    @Environment(Store.self) private var store
    let t: Txn
    let app: String
    var body: some View {
        let banks: [Account] = store.snap.accounts.filter { $0.kind == "bank" }
        let known: Bool = store.paidFromKnown(t)
        let likely: Bool = t.fg == true
        let acct: String = (t.bk ?? "") + ((t.l4 ?? "").isEmpty ? "" : " ••" + (t.l4 ?? ""))
        let choices: [Account] = banks + Self.withOwnBalance(store.snap.wallets, app: app)
        VStack(alignment: .leading, spacing: 8) {
            SheetCard {
                VStack(alignment: .leading, spacing: 12) {
                    Text("Paid from").font(.footnote.weight(.semibold)).foregroundStyle(.secondary).textCase(.uppercase).tracking(0.6)
                    HStack(spacing: 8) {
                        PaidNode(sym: "app.badge", title: app, sub: "the app", lit: false)
                        Image(systemName: "arrow.right").font(.caption.weight(.bold)).foregroundStyle(.tertiary).accessibilityHidden(true)
                        Menu {
                            ForEach(choices) { a in
                                Button { store.setPaidFrom(t.id, a) } label: {
                                    if known && t.bk == a.bank && (t.l4 ?? "") == a.last {
                                        Label(a.bank + (a.last.isEmpty ? "" : " ••" + a.last), systemImage: "checkmark")
                                    } else {
                                        Text(a.bank + (a.last.isEmpty ? "" : " ••" + a.last))
                                    }
                                }
                            }
                        } label: {
                            PaidNode(sym: "building.columns", title: known ? acct + (likely ? "?" : "") : "Choose the account",
                                     sub: known ? (likely ? "a guess · tap to confirm" : "your account · change") : "not known yet", lit: !known || likely)
                        }
                        .disabled(choices.isEmpty)
                    }
                }
                .padding(16)
            }
            SheetFootnote(known && !likely ? "Matched from your bank’s alerts or statement."
                          : known ? "A guess: a debit of the same sum that day. " + app + "’s mail doesn’t say where the money came from, so pick it above to be sure."
                          : app + "’s mail doesn’t say where the money came from (a bank, a card or its own balance). kosh fills it in when your bank’s alert or statement shows it, or pick it above.")
        }
    }
}


/// one end of a payment's route: the app it went through, or the account it came from
struct PaidNode: View {
    let sym: String
    let title: String
    let sub: String
    let lit: Bool
    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: sym).font(.subheadline.weight(.semibold)).foregroundStyle(Color.kosh)
                .frame(width: 30, height: 30).background(Color.kosh.opacity(0.12), in: Circle())
            VStack(alignment: .leading, spacing: 1) {
                Text(title).font(.subheadline.weight(.semibold)).foregroundStyle(lit ? Color.kosh : Color.primary).lineLimit(1).minimumScaleFactor(0.8)
                Text(sub).font(.caption).foregroundStyle(.secondary).lineLimit(1)
            }
            Spacer(minLength: 0)
        }
        .multilineTextAlignment(.leading)
        .padding(10)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color(.tertiarySystemFill), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous).strokeBorder(lit ? Color.kosh.opacity(0.5) : Color.clear, lineWidth: 1))
    }
}
