import SwiftUI

// MARK: - The building, drawn
//
// A quiet elevation of each property: a line for the roof (pitched for a house, flat for the rest),
// then one cell per floor, ground floor at the bottom, tinted by who uses it: let out (green), the
// family (blue) or empty (an outline). An open plot is a dashed boundary. It changes as you set the
// floors up.

enum FloorUse {
    static func color(_ status: String) -> Color {
        switch status {
        case "let": return Color(hex: "#30B45A")
        case "self": return Color.kosh
        default: return Color(hex: "#9A9AA2")
        }
    }
    static func word(_ status: String) -> String {
        switch status {
        case "let": return "Let out"
        case "self": return "Family uses it"
        default: return "Empty"
        }
    }
}

struct BuildingArt: View {
    enum Kind { case house, shop, flats, office, plot }
    let kind: Kind
    /// who uses each floor, ground floor first: let, self or vacant
    let floors: [String]
    var width: CGFloat = 104

    init(prop: Prop, width: CGFloat = 104) {
        kind = BuildingArt.kind(prop)
        floors = BuildingArt.uses(prop)
        self.width = width
    }

    init(kind: Kind, floors: [String], width: CGFloat = 104) {
        self.kind = kind; self.floors = floors.isEmpty ? ["self"] : floors; self.width = width
    }

    static func kind(_ prop: Prop) -> Kind {
        let t = (prop.type + " " + (prop.category ?? "")).lowercased()
        if t.contains("plot") || t.contains("vacant land") { return .plot }
        if t.contains("shop") || t.contains("sco") || t.contains("booth") || t.contains("showroom") || t.contains("commercial") { return .shop }
        if t.contains("flat") || t.contains("apartment") { return .flats }
        if t.contains("office") || t.contains("industrial") || t.contains("institution") { return .office }
        return .house
    }
    static func uses(_ prop: Prop) -> [String] {
        let st = prop.units.map { $0.status ?? ($0.tenant.isEmpty ? "vacant" : "let") }
        if !st.isEmpty { return st }
        return Array(repeating: prop.use == "let" ? "let" : prop.use == "vacant" ? "vacant" : "self", count: max(1, prop.floors ?? 1))
    }

    /// floors drawn: up to eight; a taller building says how many more
    var drawn: [String] { Array(floors.prefix(8)) }
    var gap: CGFloat { max(1.5, width * 0.035) }
    var floorHeight: CGFloat {
        let n = CGFloat(max(1, drawn.count))
        return max(8, min(26, 96 / n)) * width / 104
    }
    var line: CGFloat { max(1.2, width * 0.022) }

    var body: some View {
        VStack(spacing: gap) {
            if kind == .plot {
                RoundedRectangle(cornerRadius: width * 0.08, style: .continuous)
                    .strokeBorder(style: StrokeStyle(lineWidth: line, dash: [width * 0.06, width * 0.045]))
                    .foregroundStyle(Color.secondary.opacity(0.7))
                    .background(Color.green.opacity(0.08), in: RoundedRectangle(cornerRadius: width * 0.08, style: .continuous))
                    .frame(width: width, height: width * 0.5)
            } else {
                BuildingRoof(kind: kind, line: line).frame(width: width + gap * 2, height: kind == .house ? width * 0.26 : width * 0.08)
                VStack(spacing: gap) {
                    ForEach(Array(drawn.enumerated().reversed()), id: \.offset) { _, st in
                        FloorCell(use: st, radius: width * 0.05, line: line)
                            .frame(width: width, height: floorHeight)
                    }
                }
            }
            Capsule().fill(Color.primary.opacity(0.22)).frame(width: width + gap * 6, height: line)
        }
        .overlay(alignment: .topTrailing) {
            if floors.count > drawn.count {
                Text("+\(floors.count - drawn.count)")
                    .font(.caption2.weight(.bold))
                    .padding(.horizontal, 5).padding(.vertical, 2)
                    .background(.thinMaterial, in: Capsule())
            }
        }
        .accessibilityElement()
        .accessibilityLabel(label)
    }

    var label: String {
        let lets = floors.filter { $0 == "let" }.count
        return "\(floors.count) floor\(floors.count == 1 ? "" : "s"), \(lets) let out"
    }
}

/// one floor: a soft cell in the colour of who uses it; an empty floor is only its outline
struct FloorCell: View {
    let use: String
    var radius: CGFloat = 5
    var line: CGFloat = 1.2
    var body: some View {
        let c = FloorUse.color(use)
        let shape = RoundedRectangle(cornerRadius: radius, style: .continuous)
        if use == "vacant" {
            shape.strokeBorder(style: StrokeStyle(lineWidth: line, dash: [3, 2.5])).foregroundStyle(Color.secondary.opacity(0.55))
        } else {
            shape.fill(c.opacity(0.18)).overlay(shape.strokeBorder(c.opacity(0.55), lineWidth: line))
        }
    }
}

/// the top of the building, drawn as a line: a pitched roof for a house, a parapet for the rest
struct BuildingRoof: View {
    let kind: BuildingArt.Kind
    var line: CGFloat = 1.4
    var body: some View {
        switch kind {
        case .house:
            Gable(open: true).stroke(Color.primary.opacity(0.55), style: StrokeStyle(lineWidth: line * 1.3, lineCap: .round, lineJoin: .round))
        case .flats:
            HStack(alignment: .bottom, spacing: 0) {
                Spacer()
                RoundedRectangle(cornerRadius: 1).stroke(Color.primary.opacity(0.45), lineWidth: line).frame(width: 9, height: 5)
                Spacer().frame(width: 8)
            }
            .overlay(alignment: .bottom) { Capsule().fill(Color.primary.opacity(0.5)).frame(height: line * 1.4) }
        default:
            Capsule().fill(Color.primary.opacity(0.5)).frame(height: line * 1.4).frame(maxHeight: .infinity, alignment: .bottom)
        }
    }
}

/// a pitched roof (open: only its two slopes, as a line)
struct Gable: Shape {
    var open = false
    func path(in r: CGRect) -> Path {
        var p = Path()
        p.move(to: CGPoint(x: r.minX, y: r.maxY))
        p.addLine(to: CGPoint(x: r.midX, y: r.minY))
        p.addLine(to: CGPoint(x: r.maxX, y: r.maxY))
        if !open { p.closeSubpath() }
        return p
    }
}
