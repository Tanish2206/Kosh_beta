import SwiftUI

// MARK: - Deposits: every one kosh has seen, where it stands, and why
//
// The engine (engine.js › depositBook) follows each fixed or recurring deposit through the mail: asked for, booked,
// in a statement, renewed, matured, closed, each step with the mail it stands on. The Deposits page groups them:
// Live (counted in every total), Needs a look (matured with nothing heard since, or not seen for a while: listed with
// their figure, counted only once you say you still have them), Closed. Each opens to its journey, the one sentence
// of where it stands, and what you can tell kosh about it (prof.depFix).

// MARK: the engine's book (snap.deposits)

/// one part of a list that may not read (a field this version doesn't know): left out, never the whole screen
struct DepositLossy<T: Decodable & Hashable>: Decodable, Hashable {
    let v: T?
    init(from d: Decoder) throws { v = try? T(from: d) }
}

struct DepositBook: Decodable, Hashable {
    var items: [DepositItem] = []
    var asks: [DepositAsk] = []
    /// what the counted deposits come to, and the figure of those that need a look
    var counted: Double = 0
    var look: Double = 0
    enum CodingKeys: String, CodingKey { case items, asks, counted, look }
    init(from d: Decoder) throws {
        let c = try d.container(keyedBy: CodingKeys.self)
        items = ((try? c.decode([DepositLossy<DepositItem>].self, forKey: .items)) ?? []).compactMap { $0.v }
        asks = ((try? c.decode([DepositLossy<DepositAsk>].self, forKey: .asks)) ?? []).compactMap { $0.v }
        counted = (try? c.decode(Double.self, forKey: .counted)) ?? 0
        look = (try? c.decode(Double.self, forKey: .look)) ?? 0
    }
}

/// a booking request kosh saw: never a deposit by itself ("booked" once a deposit answers it, "waiting" for your
/// consent, "lapsed", or "sweep": an auto deposit facility)
struct DepositAsk: Decodable, Hashable {
    var d: String = ""; var bank: String = ""; var amt: Double? = nil; var rate: Double? = nil; var term: String? = nil
    var status: String = ""; var mail: String = ""; var dep: String? = nil
}

/// one dated step of a deposit's journey, and the mail it stands on ("" for kosh's own reckoning or your word)
struct DepositStep: Decodable, Hashable {
    var d: String = ""; var t: String = ""; var say: String = ""; var q: String? = nil; var mail: String? = nil; var src: String? = nil; var amt: Double? = nil
}

struct DepositItem: Decodable, Identifiable, Hashable {
    var id: String = ""; var alias: [String] = []; var title: String = ""; var hold: String? = nil
    var bank: String = ""; var no: String? = nil; var rd: Bool = false; var person: String = "me"
    /// live, look, closed or hidden; and where it stands: live, soon, renewed, incomplete, waiting, unseen, closed
    var group: String = "live"; var status: String = "live"; var label: String = ""; var counted: Bool = false
    var amt: Double = 0; var rate: Double = 0; var start: String? = nil; var mat: String? = nil; var matAmt: Double? = nil
    /// worth today (its principal grown at its rate), and the figure it's listed at (last seen, for those that need a look)
    var now: Double = 0; var fig: Double = 0
    var auto: Bool = false; var carry: Bool = false; var rateOld: Bool = false
    /// what's missing (amount, rate, maturity), where it is, and what would fill it: passwords, open, add
    var missing: [String] = []; var place: String? = nil; var fix: String? = nil; var doc: String? = nil
    var why: String = ""; var whyQ: String = ""
    var first: String? = nil; var last: String? = nil; var ended: String? = nil
    var saidHave: String? = nil; var saidClosed: String? = nil
    /// where its amount, rate and maturity came from: mail, advice, statement, asked, you
    var srcAmt: String? = nil; var srcRate: String? = nil; var srcMat: String? = nil
    var steps: [DepositStep] = []; var mails: [String] = []; var like: [String] = []
    /// one in another currency (an FCNR deposit): its currency, its figure in it, and the rate it's counted at
    /// in rupees, said in words ("₹94.96 to the dollar (ECB rate of 16 Oct 2026, refreshed daily)")
    var ccy: String? = nil; var fxAmt: Double? = nil; var fxSaid: String? = nil
    /// its last word from outside kosh: a mail, a statement, its advice or you, and the day (PortfolioViews.swift)
    var fresh: Holding.Fresh? = nil

    struct Said: Decodable, Hashable { var have: String? = nil; var closed: String? = nil }
    struct Src: Decodable, Hashable { var amt: String? = nil; var rate: String? = nil; var mat: String? = nil }
    enum CodingKeys: String, CodingKey {
        case id, alias, title, hold, bank, no, rd, person, group, status, label, counted, amt, rate, start, mat, matAmt, now, fig
        case auto, carry, rateOld, missing, place = "where", fix, doc, why, whyQ, first, last, ended, said, src, steps, mails, like
        case ccy, fxAmt, fxSaid, fresh
    }
    init(from d: Decoder) throws {
        let c = try d.container(keyedBy: CodingKeys.self)
        id = try c.decode(String.self, forKey: .id)
        title = (try? c.decode(String.self, forKey: .title)) ?? ""
        bank = (try? c.decode(String.self, forKey: .bank)) ?? ""
        alias = (try? c.decode([String].self, forKey: .alias)) ?? []
        hold = try? c.decode(String.self, forKey: .hold)
        no = try? c.decode(String.self, forKey: .no)
        rd = (try? c.decode(Bool.self, forKey: .rd)) ?? false
        person = (try? c.decode(String.self, forKey: .person)) ?? "me"
        group = (try? c.decode(String.self, forKey: .group)) ?? "live"
        status = (try? c.decode(String.self, forKey: .status)) ?? "live"
        label = (try? c.decode(String.self, forKey: .label)) ?? ""
        counted = (try? c.decode(Bool.self, forKey: .counted)) ?? false
        amt = (try? c.decode(Double.self, forKey: .amt)) ?? 0
        rate = (try? c.decode(Double.self, forKey: .rate)) ?? 0
        start = try? c.decode(String.self, forKey: .start)
        mat = try? c.decode(String.self, forKey: .mat)
        matAmt = try? c.decode(Double.self, forKey: .matAmt)
        now = (try? c.decode(Double.self, forKey: .now)) ?? 0
        fig = (try? c.decode(Double.self, forKey: .fig)) ?? 0
        auto = (try? c.decode(Bool.self, forKey: .auto)) ?? false
        carry = (try? c.decode(Bool.self, forKey: .carry)) ?? false
        rateOld = (try? c.decode(Bool.self, forKey: .rateOld)) ?? false
        missing = (try? c.decode([String].self, forKey: .missing)) ?? []
        place = try? c.decode(String.self, forKey: .place)
        fix = try? c.decode(String.self, forKey: .fix)
        doc = try? c.decode(String.self, forKey: .doc)
        why = (try? c.decode(String.self, forKey: .why)) ?? ""
        whyQ = (try? c.decode(String.self, forKey: .whyQ)) ?? why
        first = try? c.decode(String.self, forKey: .first)
        last = try? c.decode(String.self, forKey: .last)
        ended = try? c.decode(String.self, forKey: .ended)
        if let s = try? c.decode(Said.self, forKey: .said) { saidHave = s.have; saidClosed = s.closed }
        if let s = try? c.decode(Src.self, forKey: .src) { srcAmt = s.amt; srcRate = s.rate; srcMat = s.mat }
        steps = ((try? c.decode([DepositLossy<DepositStep>].self, forKey: .steps)) ?? []).compactMap { $0.v }
        mails = (try? c.decode([String].self, forKey: .mails)) ?? []
        like = (try? c.decode([String].self, forKey: .like)) ?? []
        ccy = try? c.decode(String.self, forKey: .ccy)
        fxAmt = try? c.decode(Double.self, forKey: .fxAmt)
        fxSaid = try? c.decode(String.self, forKey: .fxSaid)
        fresh = try? c.decode(Holding.Fresh.self, forKey: .fresh)
    }
    /// the one sentence of where it stands, without its figures while amounts are hidden
    func sentence(hidden: Bool) -> String { hidden ? whyQ : why }
    var tint: Color {
        switch status {
        case "live", "renewed": return Color.green
        case "soon": return Color.orange
        case "incomplete": return Color.sky
        case "waiting", "unseen": return Color.orange
        default: return Color.secondary
        }
    }
    /// the figure a row shows, and what it is
    var shownFigure: Double { group == "look" ? fig : now }
}

/// what you said about your deposits, as the engine reads it (prof.depFix)
struct DepFix: Codable, Hashable {
    struct Facts: Codable, Hashable { var amt: Double? = nil; var rate: Double? = nil; var mat: String? = nil; var on: String? = nil }
    /// you still have it (the day you said so); it's closed (its day, or "" when you don't know it)
    var have: [String: String]? = nil
    var closed: [String: String]? = nil
    /// its amount, rate and maturity, as you know them
    var set: [String: Facts]? = nil
    /// these are one deposit
    var same: [[String]]? = nil
    /// not yours
    var not: [String: Bool]? = nil
    var isEmpty: Bool { (have ?? [:]).isEmpty && (closed ?? [:]).isEmpty && (set ?? [:]).isEmpty && (same ?? []).isEmpty && (not ?? [:]).isEmpty }
}

extension LiveSession {
    private func changeDepFix(_ f: (inout DepFix) -> Void) {
        var x = depFix
        f(&x)
        depFix = x
        save(); rebuildSoon()
    }
    /// "I still have it": counted again (kosh asks once more after its maturity)
    func depositHave(_ id: String) {
        changeDepFix { f in
            var h: [String: String] = f.have ?? [:]; h[id] = Self.today; f.have = h
            var c: [String: String] = f.closed ?? [:]; c[id] = nil; f.closed = c.isEmpty ? nil : c
        }
    }
    /// "It's closed", on a day you know or not
    func depositClosed(_ id: String, on day: String?) {
        changeDepFix { f in
            var c: [String: String] = f.closed ?? [:]; c[id] = day ?? ""; f.closed = c
            var h: [String: String] = f.have ?? [:]; h[id] = nil; f.have = h.isEmpty ? nil : h
        }
    }
    /// back to what the mail says
    func depositForget(_ id: String) {
        changeDepFix { f in
            var h: [String: String] = f.have ?? [:]; h[id] = nil; f.have = h.isEmpty ? nil : h
            var c: [String: String] = f.closed ?? [:]; c[id] = nil; f.closed = c.isEmpty ? nil : c
        }
    }
    /// its amount, rate and maturity as you know them (nil leaves what the mail says)
    func depositSet(_ id: String, amt: Double?, rate: Double?, mat: String?) {
        changeDepFix { f in
            var s: [String: DepFix.Facts] = f.set ?? [:]
            let facts = DepFix.Facts(amt: (amt ?? 0) > 0 ? amt : nil, rate: (rate ?? 0) > 0 ? rate : nil, mat: (mat ?? "").isEmpty ? nil : mat, on: Self.today)
            s[id] = facts.amt == nil && facts.rate == nil && facts.mat == nil ? nil : facts
            f.set = s.isEmpty ? nil : s
        }
    }
    /// these two are the same deposit
    func depositSame(_ a: String, _ b: String) {
        guard a != b else { return }
        changeDepFix { f in
            var m: [[String]] = f.same ?? []
            if !m.contains(where: { Set($0) == Set([a, b]) }) { m.append([a, b]) }
            f.same = m
        }
    }
    func depositApart(_ id: String) {
        changeDepFix { f in
            let m: [[String]] = (f.same ?? []).filter { !$0.contains(id) }
            f.same = m.isEmpty ? nil : m
        }
    }
    /// not yours (read from someone else's mail, say), or yours after all
    func depositNotMine(_ id: String, _ on: Bool) {
        changeDepFix { f in
            var n: [String: Bool] = f.not ?? [:]; n[id] = on ? true : nil; f.not = n.isEmpty ? nil : n
        }
    }
    func depositMerged(_ id: String) -> Bool { (depFix.same ?? []).contains { $0.contains(id) } }
}

// MARK: the page of deposits

extension Store {
    /// the registry's deposits for whoever is being looked at, by group (live, look, closed, hidden)
    func deposits(_ p: Person, _ group: String) -> [DepositItem] {
        (snap.deposits?.items ?? []).filter { $0.group == group && p.owns($0.person) }
    }
    func deposit(_ id: String) -> DepositItem? {
        (snap.deposits?.items ?? []).first { $0.id == id || $0.alias.contains(id) }
    }
    /// deposits held another way (added by hand, a bond or a gold bond from a CAS): not in the registry
    func otherDeposits(_ p: Person) -> [Holding] {
        holdings(p).filter { $0.cls == "dep" && ($0.dep ?? "").isEmpty }.sorted { $0.amt > $1.amt }
    }
}

/// Live, Needs a look, Closed: the sections the Deposits page shows (inside a List)
struct DepositSections: View {
    @Environment(Store.self) private var store
    let person: Person
    var body: some View {
        let live: [DepositItem] = store.deposits(person, "live")
        let look: [DepositItem] = store.deposits(person, "look")
        let closed: [DepositItem] = store.deposits(person, "closed")
        let hidden: [DepositItem] = store.deposits(person, "hidden")
        let other: [Holding] = store.otherDeposits(person)
        let waiting: [DepositAsk] = (store.snap.deposits?.asks ?? []).filter { $0.status == "waiting" }
        // every maturity in the next twelve months and closure in the last six (PortfolioViews.swift)
        if store.snap.depDates != nil {
            Section { DepositDatesLink(person: person) }
        }
        if !live.isEmpty || !other.isEmpty {
            Section {
                ForEach(live) { d in DepositLink(d: d, showWho: person == .family) }
                ForEach(other) { h in
                    // one you added opens to edit, as it does elsewhere
                    if let session = store.live, let mine = session.typedHolding(h) {
                        Button { store.betaSheet = .holding(mine.id) } label: { HoldingRow(h: h, sym: "building.columns.fill", color: Color(hex: "#007AFF"), showWho: person == .family).foregroundStyle(Color.primary) }
                    } else {
                        HoldingRow(h: h, sym: "building.columns.fill", color: Color(hex: "#007AFF"), showWho: person == .family)
                    }
                }
            } header: {
                Text("Live")
            } footer: {
                if live.contains(where: { !$0.counted }) {
                    Text("A deposit whose amount kosh doesn’t know yet is listed but not counted.")
                }
            }
        }
        if !waiting.isEmpty {
            Section {
                ForEach(waiting, id: \.mail) { a in DepositAskRow(a: a) }
            } header: {
                Text("Waiting for your consent")
            } footer: {
                Text("A booking request is not a deposit until the bank books it.")
            }
        }
        if !look.isEmpty {
            Section {
                ForEach(look) { d in DepositLink(d: d, showWho: person == .family) }
            } header: {
                HStack {
                    Text("Needs a look")
                    Spacer()
                    Text(Fmt.words(look.reduce(0) { $0 + $1.fig })).monospacedDigit().privacySensitive().accessibilityHidden(store.hidden)
                }
            } footer: {
                Text("Not in your totals until you say you still have them.")
            }
        }
        if !closed.isEmpty {
            Section("Closed") {
                ForEach(closed) { d in DepositLink(d: d, showWho: person == .family) }
            }
        }
        if !hidden.isEmpty {
            Section("Not yours") {
                ForEach(hidden) { d in DepositLink(d: d, showWho: person == .family) }
            }
        }
    }
}

/// one deposit in the list; it opens to its journey
struct DepositLink: View {
    @Environment(Store.self) private var store
    let d: DepositItem
    var showWho: Bool = false
    var body: some View {
        Button { store.push(.deposit(d.id)) } label: { DepositRow(d: d, showWho: showWho).foregroundStyle(Color.primary) }
            .accessibilityHint("Opens its journey")
    }
}

struct DepositRow: View {
    @Environment(Store.self) private var store
    @Environment(\.dynamicTypeSize) private var type
    let d: DepositItem
    var showWho: Bool = false
    /// one quiet line: where it stands, whose, its rate, its maturity
    var detail: String {
        var bits: [String] = [d.label]
        if showWho { bits.append(store.ownerName(d.person)) }
        if d.rate > 0 { bits.append(Fmt.trim(d.rate, 2) + "%") }
        if let m = d.mat, m.count >= 10, d.group != "closed" {
            let word: String = m < store.snap.today ? "matured " : "matures "
            bits.append(word + Day.fmt(m, "d MMM yyyy"))
        } else if let e = d.ended, e.count >= 10, d.group == "closed" {
            bits.append(Day.fmt(e, "d MMM yyyy"))
        }
        return bits.joined(separator: " · ")
    }
    var figure: String {
        if d.shownFigure > 0 { return Fmt.words(d.shownFigure) }
        return d.group == "closed" ? "" : "Amount not known"
    }
    var body: some View {
        let stacked: Bool = type.isAccessibilitySize
        let layout: AnyLayout = stacked ? AnyLayout(VStackLayout(alignment: .leading, spacing: 6)) : AnyLayout(HStackLayout(spacing: 12))
        layout {
            HStack(spacing: 12) {
                InstIcon(name: d.bank, color: Color.gray, size: 36, site: InstSites.domain(for: d.title), plain: true)
                VStack(alignment: .leading, spacing: 2) {
                    Text(HoldingName.pretty(d.title)).font(.body.weight(.medium)).lineLimit(stacked ? nil : 1)
                    Text(detail).font(.caption).foregroundStyle(.secondary).lineLimit(stacked ? nil : 1)
                    // its last word from the bank, a statement or you, and when (PortfolioViews.swift)
                    if d.group != "closed" { HoldingAsOf(deposit: d) }
                    if !d.missing.isEmpty && d.group != "closed" {
                        Text(missingLine).font(.caption).foregroundStyle(Color.sky).lineLimit(stacked ? nil : 1)
                    }
                }
            }
            if !stacked { Spacer(minLength: 8) }
            VStack(alignment: stacked ? .leading : .trailing, spacing: 2) {
                Text(figure).font(figureFont).monospacedDigit()
                    .foregroundStyle(d.shownFigure > 0 ? Color.primary : Color.secondary)
                    .privacySensitive()
                if d.group == "look" && d.shownFigure > 0 {
                    Text("when last seen").font(.caption).foregroundStyle(.secondary)
                }
            }
            .fixedSize(horizontal: !stacked, vertical: false)
        }
        .padding(.vertical, 2)
        // what VoiceOver says: no figure while amounts are hidden
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(spoken)
    }
    var spoken: String {
        var bits: [String] = [HoldingName.pretty(d.title), detail]
        if !d.missing.isEmpty && d.group != "closed" { bits.append(missingLine) }
        if !store.hidden && !figure.isEmpty { bits.append(d.group == "look" && d.shownFigure > 0 ? figure + " when last seen" : figure) }
        return bits.joined(separator: ", ")
    }
    var missingLine: String {
        let list: String = d.missing.joined(separator: ", ")
        return Words.cap(list) + " not known yet"
    }
    var figureFont: Font { d.shownFigure > 0 ? Font.body.weight(.semibold) : Font.caption }
}

struct DepositAskRow: View {
    @Environment(Store.self) private var store
    let a: DepositAsk
    var what: String {
        var bits: [String] = []
        if let x = a.amt, x > 0 { bits.append(Fmt.words(x)) }
        if let t = a.term, !t.isEmpty { bits.append(t) }
        if let r = a.rate, r > 0 { bits.append(Fmt.trim(r, 2) + "%") }
        return bits.joined(separator: " · ")
    }
    var title: String {
        let when: String = Day.fmt(a.d, "d MMM")
        return a.bank + " FD asked for on " + when
    }
    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(title).font(.subheadline.weight(.medium))
            if !what.isEmpty { Text(what).font(.caption).foregroundStyle(.secondary).privacySensitive() }
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(store.hidden || what.isEmpty ? title : title + ", " + what)
    }
}

// MARK: one deposit's journey

struct DepositPage: View {
    @Environment(Store.self) private var store
    let id: String
    @State private var sheet: DepositSheet?
    @State private var askNotMine = false

    enum DepositSheet: String, Identifiable { case closed, facts, same; var id: String { rawValue } }

    var body: some View {
        if let d = store.deposit(id) {
            ObsidianList {
                head(d)
                standing(d)
                terms(d)
                journey(d)
                if store.live != nil { saying(d) }
            }
            .navigationTitle(HoldingName.pretty(d.title))
            .navigationBarTitleDisplayMode(.inline)
            // (a Wealth page wherever it's opened from, and its sheets with it)
            .obsidianPage()
            .sheet(item: $sheet) { s in
                Group {
                    switch s {
                    case .closed: DepositClosedSheet(d: d)
                    case .facts: DepositFactsSheet(d: d)
                    case .same: DepositSameSheet(d: d)
                    }
                }
                .obsidianSheet()
                .environment(store)
                // (figures hide with the rest; no text field is privacy-sensitive, so the editors stay typeable)
                .redacted(reason: store.hidden ? .privacy : [])
            }
            .confirmationDialog("Not yours?", isPresented: $askNotMine, titleVisibility: .visible) {
                Button("It isn’t mine", role: .destructive) { store.live?.depositNotMine(d.id, true) }
                Button("Cancel", role: .cancel) {}
            } message: {
                Text("kosh leaves it out of every list and total. You can bring it back from Not yours.")
            }
        } else {
            ContentUnavailableView("This deposit isn’t in your mail any more", systemImage: "building.columns", description: Text("kosh no longer reads a deposit by this name."))
        }
    }

    /// what the big figure is
    static func caption(_ d: DepositItem) -> String {
        if d.group == "look" { return "when last seen" }
        if d.group == "closed" { return "" }
        if !d.counted { return "not counted yet" }
        let grown: Bool = d.rate > 0 && d.amt > 0 && d.now > d.amt
        return grown ? "today, with its interest" : "put in"
    }
    @ViewBuilder func head(_ d: DepositItem) -> some View {
        let fig: Double = d.shownFigure
        let caption: String = Self.caption(d)
        Section {
            VStack(spacing: 8) {
                InstIcon(name: d.bank, color: Color.gray, size: 56, site: InstSites.domain(for: d.title), plain: true)
                Text(HoldingName.pretty(d.title)).font(.title3.weight(.semibold)).multilineTextAlignment(.center)
                Text(store.ownerName(d.person)).font(.subheadline).foregroundStyle(.secondary)
                if fig > 0 {
                    Text(Fmt.words(fig))
                        .font(.largeTitle.weight(.bold)).fontDesign(.rounded).monospacedDigit()
                        .minimumScaleFactor(0.6).lineLimit(1)
                        .privacySensitive()
                }
                if !caption.isEmpty { Text(caption).font(.subheadline).foregroundStyle(.secondary) }
                Chip(text: d.label, color: d.tint)
            }
            .frame(maxWidth: .infinity)
            .listRowBackground(Color.clear)
            .accessibilityElement(children: .ignore)
            .accessibilityLabel(Self.spokenHead(d, owner: store.ownerName(d.person), hidden: store.hidden))
        }
    }
    /// the head as VoiceOver says it: whose, where it stands, and its figure only while amounts show
    static func spokenHead(_ d: DepositItem, owner: String, hidden: Bool) -> String {
        var bits: [String] = [HoldingName.pretty(d.title), owner, d.label]
        if !hidden && d.shownFigure > 0 { bits.append(Fmt.words(d.shownFigure) + ", " + caption(d)) }
        return bits.joined(separator: ", ")
    }

    @ViewBuilder func standing(_ d: DepositItem) -> some View {
        Section {
            Text(d.sentence(hidden: store.hidden)).font(.body).fixedSize(horizontal: false, vertical: true)
            if d.fix == "passwords", store.live != nil {
                let add: String = "Add your " + d.bank + " details"
                Button { store.betaSheet = .passwords } label: { Label(add, systemImage: "key.fill") }
            }
        } header: { Text("Where it stands") }
    }

    @ViewBuilder func terms(_ d: DepositItem) -> some View {
        Section {
            if d.amt > 0 { termRow("Put in", Fmt.words(d.amt), d.srcAmt, money: true) }
            if d.rate > 0 { termRow(d.rateOld ? "Rate (its last term’s)" : "Rate", Fmt.trim(d.rate, 2) + "% a year", d.srcRate, money: false) }
            if let s = d.start, s.count >= 10 { termRow(d.status == "renewed" ? "This term began" : "Booked", Day.fmt(s, "d MMM yyyy"), nil, money: false) }
            if let m = d.mat, m.count >= 10 { termRow(m < store.snap.today ? "Matured" : "Matures", Day.fmt(m, "d MMM yyyy"), d.srcMat, money: false) }
            if let x = d.matAmt, x > 0 { termRow("At maturity", Fmt.words(x), nil, money: true) }
            if d.counted && d.now > 0 && d.now != d.amt { termRow("Worth today", Fmt.words(d.now), nil, money: true) }
            if d.auto { LabeledContent("At maturity", value: d.carry ? "Renews with its interest" : "Renews on its own") }
            ForEach(d.missing, id: \.self) { m in
                LabeledContent(Words.cap(m), value: "Not known")
                    .foregroundStyle(.secondary)
            }
        } header: {
            Text("Its terms")
        } footer: {
            if let p = d.place, !d.missing.isEmpty {
                Text(Words.cap(d.missing.joined(separator: ", ")) + ": " + p + ".")
            } else if d.counted && d.rate > 0 {
                Text("Worth today is what was put in, grown at its rate with interest added every quarter, as banks do.")
            }
        }
    }

    /// a fact and where it came from (the mail, the advice, a statement, the request, you)
    @ViewBuilder func termRow(_ label: String, _ value: String, _ src: String?, money: Bool) -> some View {
        let from: String = Self.sourceWord(src)
        let said: String = money && store.hidden ? "hidden" : value
        let spoken: String = from.isEmpty ? label + ", " + said : label + ", " + said + ", " + from
        LabeledContent {
            VStack(alignment: .trailing, spacing: 1) {
                if money { Text(value).monospacedDigit().privacySensitive() } else { Text(value).monospacedDigit() }
                if !from.isEmpty { Text(from).font(.caption2).foregroundStyle(.tertiary) }
            }
        } label: {
            Text(label)
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(spoken)
    }
    static func factsWord(_ d: DepositItem) -> String {
        if d.missing.isEmpty { return "Correct its amount, rate or maturity…" }
        let list: String = d.missing.joined(separator: ", ")
        return "Add its " + list + "…"
    }
    static func sourceWord(_ s: String?) -> String {
        switch s ?? "" {
        case "mail": return "from the bank’s mail"
        case "advice": return "from its advice"
        case "statement": return "from a statement"
        case "asked": return "as asked for"
        case "you": return "as you said"
        default: return ""
        }
    }

    @ViewBuilder func journey(_ d: DepositItem) -> some View {
        Section {
            ForEach(Array(d.steps.enumerated()), id: \.offset) { pair in
                DepositStepRow(s: pair.element, title: d.title, last: pair.offset == d.steps.count - 1)
            }
        } header: {
            Text("Its journey")
        } footer: {
            Text("Each step is a mail kosh read; tap one to see it.")
        }
    }

    @ViewBuilder func saying(_ d: DepositItem) -> some View {
        let look: Bool = d.group == "look"
        Section {
            if d.group == "hidden" {
                Button { store.live?.depositNotMine(d.id, false) } label: { Label("It is mine", systemImage: "arrow.uturn.backward") }
            } else {
                if d.saidHave != nil || d.saidClosed != nil {
                    Button { store.live?.depositForget(d.id) } label: { Label("Let kosh work it out from the mail", systemImage: "arrow.uturn.backward") }
                }
                if look || (d.group == "live" && d.saidHave == nil && d.status == "unseen") {
                    Button { store.live?.depositHave(d.id) } label: { Label("I still have it", systemImage: "checkmark.circle") }
                }
                if d.group != "closed" {
                    Button { sheet = .closed } label: { Label("It’s closed…", systemImage: "archivebox") }
                    Button { sheet = .facts } label: { Label(Self.factsWord(d), systemImage: "square.and.pencil") }
                }
                if !d.like.isEmpty {
                    Button { sheet = .same } label: { Label("Same deposit as…", systemImage: "rectangle.on.rectangle") }
                }
                if store.live?.depositMerged(d.id) == true {
                    Button { store.live?.depositApart(d.id) } label: { Label("These aren’t the same deposit", systemImage: "rectangle.split.2x1") }
                }
                Button(role: .destructive) { askNotMine = true } label: { Label("Not mine", systemImage: "xmark.circle") }
            }
        } header: {
            Text("What you know")
        } footer: {
            Text(look ? "Say you still have it and it counts again; kosh asks once more after it matures." : "What you say here stands over what the mail says.")
        }
    }
}

/// one step: when, what, and the mail it stands on (tap opens it, as other source rows do)
struct DepositStepRow: View {
    @Environment(Store.self) private var store
    @Environment(\.dynamicTypeSize) private var type
    let s: DepositStep
    let title: String
    var last: Bool = false
    var words: String { store.hidden ? (s.q ?? s.say) : s.say }
    /// the step's dot: green as it goes on, grey once it ended, orange where kosh lost sight of it, kosh's own for yours
    var dot: Color {
        switch s.t {
        case "closed", "matured": return Color.secondary
        case "unseen": return Color.orange
        case "you": return Color.kosh
        default: return Color.green
        }
    }
    var source: String {
        switch s.src ?? "" {
        case "statement": return "A statement"
        case "advice": return "Its advice, read on this phone"
        case "you": return "You"
        case "kosh": return (s.mail ?? "").isEmpty ? "kosh, from its dates" : "The bank’s mail"
        default: return "The bank’s mail"
        }
    }
    var body: some View {
        let mail: String = s.mail ?? ""
        if !mail.isEmpty, store.live != nil {
            Button { store.betaSheet = .source(SourceRef(title: HoldingName.pretty(title), mails: [mail], type: "deposit")) } label: { content.foregroundStyle(Color.primary) }
                .accessibilityHint("Opens the mail it was read from")
        } else {
            content
        }
    }
    var content: some View {
        let stacked: Bool = type.isAccessibilitySize
        let when: String = s.d.count >= 10 ? Day.fmt(s.d, "d MMM yyyy") : ""
        let mail: String = s.mail ?? ""
        return HStack(alignment: .top, spacing: 12) {
            VStack(spacing: 0) {
                Circle().fill(dot).frame(width: 10, height: 10).padding(.top, 5)
                if !last { Rectangle().fill(Color.secondary.opacity(0.25)).frame(width: 2).frame(maxHeight: .infinity) }
            }
            .frame(width: 12)
            .accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 2) {
                Text(when).font(.caption.weight(.semibold)).foregroundStyle(.secondary)
                // (while amounts are hidden its words are the ones without figures)
                Text(words).font(.subheadline).fixedSize(horizontal: false, vertical: true)
                Text(source).font(.caption).foregroundStyle(.tertiary)
            }
            if !stacked && !mail.isEmpty && store.live != nil {
                Spacer(minLength: 4)
                Image(systemName: "envelope").font(.footnote).foregroundStyle(.tertiary).accessibilityHidden(true)
            }
        }
        .accessibilityElement(children: .combine)
    }
}

// MARK: what you can say, in a sheet each

struct DepositClosedSheet: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    let d: DepositItem
    @State private var knowDay = false
    @State private var day = Date()
    var body: some View {
        NavigationStack {
            ObsidianForm {
                Section {
                    Toggle("I know the day", isOn: $knowDay)
                    if knowDay { DatePicker("Closed on", selection: $day, in: ...Date(), displayedComponents: .date).indiaDates() }
                } footer: {
                    Text("kosh moves it to Closed and leaves it out of your totals from that day.")
                }
            }
            .navigationTitle("Closed")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        store.live?.depositClosed(d.id, on: knowDay ? Day.iso(day) : nil)
                        dismiss()
                    }
                }
            }
        }
    }
}

struct DepositFactsSheet: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    let d: DepositItem
    @State private var amount = ""
    @State private var rate = ""
    @State private var knowMat = false
    @State private var mat = Date()
    var body: some View {
        NavigationStack {
            ObsidianForm {
                Section {
                    TextField("Amount put in (₹)", text: $amount).keyboardType(.decimalPad)
                    TextField("Rate (% a year)", text: $rate).keyboardType(.decimalPad)
                    Toggle("I know when it matures", isOn: $knowMat)
                    if knowMat { DatePicker("Matures", selection: $mat, displayedComponents: .date).indiaDates() }
                } footer: {
                    Text("Your figures stand over the mail’s. Its advice, once read, fills in the rest.")
                }
            }
            .navigationTitle(HoldingName.pretty(d.title))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        let a: Double? = Double(amount.replacingOccurrences(of: ",", with: ""))
                        let r: Double? = Double(rate.replacingOccurrences(of: "%", with: ""))
                        store.live?.depositSet(d.id, amt: a, rate: r, mat: knowMat ? Day.iso(mat) : nil)
                        dismiss()
                    }
                }
            }
            .onAppear {
                if d.amt > 0 { amount = String(Int(d.amt.rounded())) }
                if d.rate > 0 { rate = Fmt.trim(d.rate, 2) }
                if let m = d.mat, m.count >= 10 { knowMat = true; mat = Day.date(m) }
            }
        }
    }
}

struct DepositSameSheet: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    let d: DepositItem
    var body: some View {
        let others: [DepositItem] = d.like.compactMap { store.deposit($0) }
        NavigationStack {
            ObsidianList {
                Section {
                    ForEach(others) { o in
                        Button {
                            store.live?.depositSame(d.id, o.id)
                            dismiss()
                        } label: { DepositRow(d: o).foregroundStyle(Color.primary) }
                    }
                } footer: {
                    Text("kosh joins their journeys into one deposit. You can part them again from its page.")
                }
            }
            .navigationTitle("Same deposit as…")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } } }
        }
    }
}

// MARK: what kosh noticed, about a deposit

enum DepositNotice {
    /// the deposit a heads-up is about ("dep|look|<id>", "dep|mat|<id>|<day>"), or nil
    static func depositID(_ watchID: String) -> String? {
        if watchID.hasPrefix("dep|look|") { return String(watchID.dropFirst("dep|look|".count)) }
        if watchID.hasPrefix("dep|mat|") {
            let rest: String = String(watchID.dropFirst("dep|mat|".count))
            guard let cut = rest.range(of: "|", options: .backwards) else { return rest }
            return String(rest[..<cut.lowerBound])
        }
        return nil
    }
}
