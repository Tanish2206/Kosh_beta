import SwiftUI

// MARK: - Day lens: a film strip of the month's days above the bottom edge, and a rolling read-out of the day
//
// Scroll the ledger and a glass strip of days rises from the bottom edge (the tab bar steps out of its way) and
// slides along with the list, frame for frame. Drag the strip and the list jumps day by day under it, with a tick
// for every day crossed (a firmer one on a day over budget), and a panel opens with the day's figures rolling into
// place. Everything wears the day's mood: blue for a calm day, amber near the budget, coral over it.
//
// Smoothness is the point, so the work is split:
// - each day heading reports where it is on screen (one CGFloat, no view update) into LensTracker (smooth-5nov);
// - LensTracker works out where the list is, in days, as a fraction (12.4 = 40% through the 13th day back);
// - only LensStrip reads that fraction, so a scroll frame redraws one HStack offset and nothing else;
// - the rest of the lens reads the whole day only, so it changes once per day, not once per frame.

/// whether the day lens is up; kosh's tab bar steps out while it is, so the two never sit on top of each other
@Observable final class LensVeil {
    static let shared = LensVeil()
    var up: Bool = false
}

/// where the ledger is, as days. The ledger's rows write it; only the lens reads it.
@Observable final class LensTracker {
    /// the day at the top of the list, as an index from the newest (0) — changes once per day
    var top: Int = 0
    /// the same, with how far through that day the list has scrolled (12.4) — changes every frame
    var pos: Double = 0
    var scrolling: Bool = false
    /// which way the list last moved: down (into older days) hides the tab bar, up brings it back
    var down: Bool = false

    /* (smooth-5nov) Only the day headings report where they are: two to four on screen, where every payment row used
       to (twenty-odd geometry callbacks a scroll frame, then a hop to the next run loop, so the strip drew a frame
       behind the list and every frame drew twice). The place is worked out on the spot from the headings either side
       of the top edge; inside a day taller than the screen it carries on from the scroll offset. */
    @ObservationIgnored private var index: [String: Int] = [:]
    @ObservationIgnored private var counts: [Int] = []
    /// the headings in view (or just outside it): day → global minY
    @ObservationIgnored private var heads: [Int: CGFloat] = [:]
    /// each day's height, heading to next heading, measured whenever both were in view
    @ObservationIgnored private var heights: [Int: CGFloat] = [:]
    /// the global y of the top of what's visible in the list (under the sub-tab row)
    @ObservationIgnored private var listTop: CGFloat = 0
    @ObservationIgnored private var inset: CGFloat = 0
    @ObservationIgnored private var lastY: CGFloat = 0
    @ObservationIgnored private var run: CGFloat = 0
    /// the last place a heading gave, and the scroll offset then, to carry on from inside a long day
    @ObservationIgnored private var anchor: (k: Int, f: CGFloat, y: CGFloat)? = nil
    /// (smooth-5nov-b) the glide that moves the list with the strip (LedgerGlide.swift), set by the ledger
    @ObservationIgnored weak var glide: LedgerGlide?
    /// the glide has the list's scroll now (set by LedgerGlide)
    @ObservationIgnored var gliding: Bool = false
    var dayCount: Int { counts.count }
    func rows(_ k: Int) -> Int { k >= 0 && k < counts.count ? counts[k] : 0 }
    func dayIndex(_ day: String) -> Int? { index[day] }
    func headGlobal(_ k: Int) -> CGFloat? { heads[k] }

    func set(_ groups: [DayGroup]) {
        var ix: [String: Int] = [:]
        for (k, g) in groups.enumerated() { ix[g.day] = k }
        if ix != index {
            index = ix
            counts = groups.map { $0.items.count }
            heads = [:]; heights = [:]; anchor = nil
            recompute()
        }
    }

    func listFrame(top: CGFloat) {
        if abs(top - listTop) > 0.5 { listTop = top; recompute() }
    }
    func listInset(_ v: CGFloat) {
        if abs(v - inset) > 0.5 { inset = v; recompute() }
    }

    /// the list's scroll offset, every frame: the direction (it flips only past a few points), and the place when no
    /// heading is near enough to say
    func moved(_ y: CGFloat) {
        let dy: CGFloat = y - lastY
        lastY = y
        if heads.isEmpty { recompute() }
        // the strip moving the list isn't the person scrolling: the way it went says nothing about the tab bar
        if gliding { run = 0; return }
        if y < 40 { run = 0; if down { down = false }; return }
        if dy == 0 { return }
        if (dy > 0) != (run > 0) { run = 0 }
        run += dy
        if run > 24 { if !down { down = true } } else if run < -16 { if down { down = false } }
    }

    /// a day heading's place on screen (global minY)
    func head(_ day: String, minY: CGFloat) {
        guard let k = index[day] else { return }
        if let old = heads[k], abs(old - minY) < 0.25 { return }
        heads[k] = minY
        recompute()
    }
    func headGone(_ day: String) {
        guard let k = index[day] else { return }
        heads[k] = nil
    }

    /// a day's height: measured if it has been, else its rows at a typical height
    private func height(_ k: Int) -> CGFloat {
        if let h = heights[k] { return h }
        let n: Int = k >= 0 && k < counts.count ? counts[k] : 1
        return 44 + CGFloat(max(1, n)) * 64 + 14
    }

    private func recompute() {
        let last: Int = counts.count - 1
        guard last >= 0 else { return }
        let line: CGFloat = listTop + inset + 2
        // the lowest heading at or above the top edge (the day being read) and the highest one under it
        var above: (k: Int, y: CGFloat)? = nil
        var below: (k: Int, y: CGFloat)? = nil
        for (k, y) in heads {
            if y <= line {
                if above == nil || y > above!.y { above = (k, y) }
            } else if below == nil || y < below!.y {
                below = (k, y)
            }
        }
        var k: Int
        var f: CGFloat
        if let a = above {
            k = a.k
            if let b = below, b.k == a.k + 1 {
                let h: CGFloat = max(1, b.y - a.y)
                heights[a.k] = h
                f = (line - a.y) / h
            } else {
                f = (line - a.y) / height(a.k)
            }
        } else if let b = below {
            k = b.k - 1
            if k < 0 { k = 0; f = 0 } else { f = 1 - (b.y - line) / height(k) }
        } else if let an = anchor {
            // no heading near: a long day, carried on by the scroll offset
            k = an.k
            f = an.f + (lastY - an.y) / height(k)
            while f >= 1 && k < last { let over: CGFloat = (f - 1) * height(k); k += 1; f = over / height(k) }
            while f < 0 && k > 0 { let under: CGFloat = f * height(k); k -= 1; f = 1 + under / height(k) }
        } else {
            return
        }
        k = min(last, max(0, k))
        if above != nil || below != nil { anchor = (k, f, lastY) }
        let p: Double = Double(k) + Double(min(0.999, max(0, f)))
        if abs(p - pos) > 0.002 { pos = p }
        if k != top { top = k }
    }
}

/// one day, worked out once per month rather than on every frame
struct LensDay: Identifiable {
    let day: String
    let total: Double
    /// the month's spending up to the end of this day
    let soFar: Double
    let cats: [LensCat]
    var id: String { day }
}

struct LensCat: Identifiable {
    let name: String
    let v: Double
    let color: Color
    var id: String { name }
}

enum LensMood: Equatable {
    case calm, near, over
    init(spent: Double, budget: Double) {
        let v: Double = budget > 0 ? spent / budget : 0
        self = v < 0.6 ? .calm : (v <= 1 ? .near : .over)
    }
    var color: Color {
        switch self {
        case .calm: return Color(red: 0.36, green: 0.49, blue: 1.0)
        case .near: return Color(red: 0.96, green: 0.64, blue: 0.36)
        case .over: return Color(red: 1.0, green: 0.42, blue: 0.29)
        }
    }
    var word: String {
        switch self {
        case .calm: return "CALM DAY"
        case .near: return "NEAR BUDGET"
        case .over: return "OVER BUDGET"
        }
    }
}

struct DayLens: View {
    @Environment(Store.self) private var store
    /// where the tab bar's top sits on screen, so the lens can stand clear above it while it's showing
    @Environment(\.barTop) private var barTop
    /// the bottom of the lens's own space on screen (the screen's bottom edge)
    @State private var bottomY: CGFloat = 0
    let groups: [DayGroup]
    let tracker: LensTracker
    /// scroll the ledger so this day's heading is at the top
    let jump: (String) -> Void

    static let cell: CGFloat = 52
    static let stripH: CGFloat = 72

    @State private var days: [LensDay] = []
    /// while your finger is on the strip: where it has dragged to, in days from the newest
    /// where the strip stands under your finger, kept in its own box: only the strip reads it, so a drag redraws the
    /// strip and nothing else (as view state here, every frame of a drag rebuilt the whole lens, panel and all)
    @State private var drag = LensDrag()
    @State private var start: Double = 0
    /// the day under the lens while scrubbing; drives the haptics, so it only changes under your finger
    @State private var picked: Int = 0
    @State private var scrubbing: Bool = false
    @State private var shown: Bool = false
    @State private var hide: Task<Void, Never>? = nil
    /// the strip's width, to tell which day a tap landed on
    @State private var stripW: CGFloat = 0
    /// a finger is on the strip (a tap or the start of a drag)
    @State private var touching: Bool = false
    /// a tap opened the day up close: the panel stays until you scroll the list or tap the lens again
    @State private var focused: Bool = false
    @State private var focusedAt: Date = .distantPast
    /// the strip carrying on after a flick, a day at a time; and the list catching up once the finger pauses
    @State private var coast: Task<Void, Never>? = nil
    @State private var follow: Task<Void, Never>? = nil

    var body: some View {
        let n: Int = days.count
        let open: Bool = scrubbing || focused
        let i: Int = n == 0 ? 0 : min(n - 1, max(0, open ? picked : tracker.top))
        let d: LensDay? = n == 0 ? nil : days[i]
        let budget: Double = dailyBudget
        let mood: LensMood = LensMood(spent: d?.total ?? 0, budget: budget)

        ZStack(alignment: .bottom) {
            // the room dims and takes the day's colour while you scrub; no blur, so the list costs nothing extra
            if open {
                LinearGradient(colors: [.clear, .black.opacity(0.55)], startPoint: .top, endPoint: .bottom)
                    .overlay(alignment: .bottom) {
                        RadialGradient(colors: [mood.color.opacity(0.42), .clear], center: .bottom, startRadius: 0, endRadius: 360)
                            .frame(height: 520)
                    }
                    .ignoresSafeArea()
                    .allowsHitTesting(false)
                    .transition(.opacity)
            }

            VStack(spacing: 10) {
                if let d {
                    if open {
                        panel(d, mood: mood, budget: budget)
                            .transition(.asymmetric(
                                insertion: .scale(scale: 0.97, anchor: .bottom).combined(with: .opacity).combined(with: .offset(y: 16)),
                                removal: .opacity.combined(with: .offset(y: 12))))
                    } else {
                        capsule(d, mood: mood)
                            .transition(.opacity.combined(with: .offset(y: 8)))
                    }
                }
                LensStrip(days: days, tracker: tracker, drag: drag, live: scrubbing, fixed: stripFixed, mood: mood, budget: budget)
                    .glassEffect(.regular.tint(mood.color.opacity(0.1)).interactive(), in: .rect(cornerRadius: 24))
                    .contentShape(.rect(cornerRadius: 24))
                    .onGeometryChange(for: CGFloat.self) { g in g.size.width } action: { w in stripW = w }
                    .gesture(scrub)
                    .accessibilityElement(children: .ignore)
                    .accessibilityLabel("Days")
                    .accessibilityValue(d.map { Day.fmt($0.day, "EEEE d MMMM") } ?? "")
                    .accessibilityAdjustableAction { dir in go(to: min(n - 1, max(0, i + (dir == .increment ? -1 : 1)))) }
            }
            .padding(.horizontal, 16)
            // scrolling down, the bar steps away and the lens takes the bottom edge; scrolling up, the bar comes back
            // and the lens stands just above it, never on it
            .padding(.bottom, lift)
            .animation(Motion.open, value: lift)
            // in from the bottom edge, where the tab bar was; out faster than it came, never bouncing
            .offset(y: shown ? 0 : 130)
            .opacity(shown ? 1 : 0)
            .allowsHitTesting(shown)
        }
        .animation(shown ? Motion.open : Motion.base, value: shown)
        .animation(scrubbing ? Motion.out(0.4) : Motion.base, value: scrubbing)
        .animation(focused ? Motion.out(0.4) : Motion.base, value: focused)
        .animation(Motion.out(0.4), value: mood)
        .onAppear { rebuild() }
        .onChange(of: groupsKey) { rebuild() }
        .onGeometryChange(for: CGFloat.self) { g in g.frame(in: .global).maxY } action: { y in bottomY = y }
        .onChange(of: tracker.scrolling) { _, moving in
            // scrolling the list yourself closes a day opened by a tap (not the jump the tap itself made)
            if moving && focused && Date().timeIntervalSince(focusedAt) > 0.5 { focused = false }
            if moving { reveal() } else { later() }
        }
        .onChange(of: tracker.down) { _, d in
            if shown { veil(d || scrubbing || focused) }
        }
        .onDisappear {
            hide?.cancel()
            LensVeil.shared.up = false
        }
    }

    // MARK: pieces

    /// what shows while you only scroll: the day and what it spent, rolling as days pass
    func capsule(_ d: LensDay, mood: LensMood) -> some View {
        HStack(spacing: 8) {
            Text(Day.fmt(d.day, "EEE")).foregroundStyle(mood.color)
            Text(Day.fmt(d.day, "d MMM"))
            Circle().fill(.secondary).frame(width: 3, height: 3)
            Text(Fmt.rupees(d.total)).privacySensitive()
                .contentTransition(.numericText(value: d.total))
        }
        .font(.subheadline.weight(.semibold))
        .monospacedDigit()
        .contentTransition(.numericText())
        .padding(.horizontal, 16)
        .frame(height: 38)
        .glassEffect(.regular.tint(mood.color.opacity(0.14)), in: .capsule)
        .animation(Motion.base, value: d.day)
    }

    /// the read-out while you scrub
    func panel(_ d: LensDay, mood: LensMood, budget: Double) -> some View {
        let share: Double = budget > 0 ? d.total / budget : 0
        let catTotal: Double = max(1, d.cats.reduce(0) { $0 + $1.v })
        return VStack(alignment: .leading, spacing: 14) {
            HStack(alignment: .bottom) {
                VStack(alignment: .leading, spacing: 0) {
                    Text(Day.fmt(d.day, "EEEE").uppercased())
                        .font(.caption.weight(.bold)).tracking(1.6)
                        .foregroundStyle(mood.color)
                        .contentTransition(.opacity)
                    HStack(alignment: .lastTextBaseline, spacing: 6) {
                        Text(Day.fmt(d.day, "d"))
                            .font(.system(size: 60, weight: .heavy, design: .rounded))
                            .contentTransition(.numericText(value: Double(Day.fmt(d.day, "d")) ?? 0))
                        Text(Day.fmt(d.day, "MMM"))
                            .font(.title2.weight(.bold))
                            .contentTransition(.opacity)
                    }
                }
                Spacer(minLength: 8)
                VStack(alignment: .trailing, spacing: 5) {
                    Text(mood.word)
                        .font(.system(size: 10, weight: .bold)).tracking(1.2)
                        .foregroundStyle(mood.color)
                        .padding(.horizontal, 8).padding(.vertical, 3)
                        .background(mood.color.opacity(0.16), in: .capsule)
                        .contentTransition(.interpolate)
                    Text(Fmt.rupees(d.total))
                        .font(.system(size: 30, weight: .bold, design: .rounded))
                        .contentTransition(.numericText(value: d.total))
                        .privacySensitive()
                    Text(Fmt.pct(share) + " of the day's budget")
                        .font(.caption).foregroundStyle(.secondary)
                        .contentTransition(.numericText(value: share))
                }
                .padding(.bottom, 8)
            }
            .monospacedDigit()

            // what the day went on: one stacked bar, then the biggest three
            VStack(alignment: .leading, spacing: 8) {
                GeometryReader { g in
                    HStack(spacing: 2) {
                        ForEach(d.cats) { c in
                            Capsule().fill(c.color)
                                .frame(width: max(3, (g.size.width - CGFloat(max(0, d.cats.count - 1)) * 2) * CGFloat(c.v / catTotal)))
                        }
                    }
                }
                .frame(height: 8)
                .background(Color.primary.opacity(0.08), in: .capsule)
                .clipShape(.capsule)
                HStack(spacing: 12) {
                    ForEach(d.cats.prefix(3)) { c in
                        HStack(spacing: 5) {
                            Circle().fill(c.color).frame(width: 7, height: 7)
                            Text(c.name).foregroundStyle(.primary)
                            Text(Fmt.short(c.v)).foregroundStyle(.secondary).privacySensitive()
                        }
                        .font(.caption)
                        .lineLimit(1)
                    }
                }
            }

            Divider().opacity(0.6)
            HStack {
                Text(Day.fmt(d.day, "MMMM") + " so far · day " + Day.fmt(d.day, "d"))
                    .font(.footnote).foregroundStyle(.secondary)
                    .contentTransition(.opacity)
                Spacer()
                Text(Fmt.rupees(d.soFar))
                    .font(.headline.weight(.bold)).monospacedDigit()
                    .contentTransition(.numericText(value: d.soFar))
                    .privacySensitive()
            }
        }
        .padding(18)
        .glassEffect(.regular.tint(mood.color.opacity(0.18)), in: .rect(cornerRadius: 30))
        .background {
            RadialGradient(colors: [mood.color.opacity(0.35), .clear], center: .bottom, startRadius: 0, endRadius: 220)
                .offset(y: 40)
                .allowsHitTesting(false)
        }
        // a day passing under a moving finger changes fast: quick, so the read-out never trails behind
        .animation(scrubbing ? Motion.quick : Motion.base, value: d.day)
    }

    // MARK: moving

    var scrub: some Gesture {
        DragGesture(minimumDistance: 0)
            .onChanged { v in
                let n: Int = days.count
                guard n > 0 else { return }
                if !touching {
                    // where the strip stood when the finger came down (a whole day, as it shows at rest)
                    touching = true
                    LensHaptics.ready()
                    if coast != nil { coast?.cancel(); coast = nil; drag.pos = drag.pos.rounded() }
                    start = scrubbing ? drag.pos : (stripFixed ?? tracker.pos)
                    picked = Int(start.rounded())
                    reveal()
                    // caught again while coasting: the list goes on following the finger
                    if scrubbing { tracker.glide?.hold(drag) }
                }
                // a tap never opens the panel: only a real drag does
                guard scrubbing || abs(v.translation.width) > 6 else { return }
                // (smooth-5nov-b) the list behind follows the strip frame for frame (LedgerGlide), not a day at a time
                if !scrubbing { drag.pos = start; scrubbing = true; tracker.glide?.hold(drag) }
                // drag right and older days come under the lens
                let p: Double = min(Double(n - 1), max(0, start + Double(v.translation.width / Self.cell)))
                drag.pos = p
                let k: Int = Int(p.rounded())
                if k != picked {
                    // one tick for every day crossed, however fast the finger went (a firmer one on a day over budget)
                    let step: Int = k > picked ? 1 : -1
                    var d: Int = picked
                    while d != k { d += step; LensHaptics.tick(over: days[d].total > dailyBudget) }
                    picked = k
                    // (the list moves with the strip through LedgerGlide; a scrollTo per day made it lay out under the
                    // finger and stutter, so no jump here)
                }
            }
            .onEnded { v in
                touching = false
                tracker.glide?.release()
                let n: Int = days.count
                guard n > 0 else { return }
                if !scrubbing {
                    // a tap: straight to the day under the finger (left of the lens is older), opened up close.
                    // Tapping the day already open closes it again
                    guard stripW > 0 else { later(); return }
                    let k: Int = min(n - 1, max(0, Int((start + Double((stripW / 2 - v.location.x) / Self.cell)).rounded())))
                    if focused && k == picked { focused = false; later(); return }
                    if k != picked { LensHaptics.tick(over: days[k].total > dailyBudget) }
                    picked = k
                    jump(days[k].day)
                    focusedAt = Date()
                    focused = true
                    reveal()
                    return
                }
                // let go: settle on the day under the lens, then carry on as far as the flick says, a day at a time,
                // each with its tick, slowing as it goes. A slow lift-off stays put; a small flick goes 1-2 days, a
                // real one 3-4
                let here: Int = Int(min(Double(n - 1), max(0, drag.pos.rounded())))
                let speed: Double = Double(v.velocity.width)
                let extra: Int = abs(speed) < 260 ? 0 : Int(min(4, max(1, (abs(speed) / 380).rounded()))) * (speed > 0 ? 1 : -1)
                let end: Int = min(n - 1, max(0, here + extra))
                if here != picked { LensHaptics.tick(over: days[here].total > dailyBudget); picked = here }
                withAnimation(Motion.quick) { drag.pos = Double(here) }
                follow?.cancel()
                guard end != here else { settle(on: here); return }
                let step: Int = end > here ? 1 : -1
                coast = Task { @MainActor in
                    var d: Int = here
                    var gap: Double = 0.07
                    while d != end {
                        try? await Task.sleep(for: .seconds(gap))
                        if Task.isCancelled { return }
                        d += step
                        withAnimation(Motion.out(gap * 1.7)) { drag.pos = Double(d) }
                        LensHaptics.tick(over: days[d].total > dailyBudget)
                        picked = d
                        gap *= 1.32
                    }
                    try? await Task.sleep(for: .seconds(0.12))
                    if Task.isCancelled { return }
                    coast = nil
                    settle(on: d)
                }
            }
    }

    /// let go (and any coast done): the list moves to the day, and the panel stays open on it until you scroll the list
    /// or tap the day again
    func settle(on k: Int) {
        jump(days[k].day)
        focusedAt = Date()
        focused = true
        scrubbing = false
        later()
    }

    /// moves the list to the day under the lens once the finger has rested on it a moment
    func catchUp() {
        follow?.cancel()
        let k: Int = picked
        follow = Task { @MainActor in
            try? await Task.sleep(for: .seconds(0.14))
            if Task.isCancelled || k >= days.count { return }
            jump(days[k].day)
        }
    }

    func go(to k: Int) {
        guard k >= 0, k < days.count else { return }
        picked = k
        jump(days[k].day)
        reveal(); later()
    }

    func reveal() {
        hide?.cancel()
        if !shown { shown = true }
        veil(tracker.down || scrubbing || focused)
    }

    /// the tab bar steps out (true) or comes back (false)
    func veil(_ up: Bool) {
        if LensVeil.shared.up != up { LensVeil.shared.up = up }
    }

    /// how high the lens sits: at the bottom edge while the bar is away, else clear above the bar
    var lift: CGFloat {
        guard !LensVeil.shared.up, let top = barTop, bottomY > top else { return 10 }
        return bottomY - top + 8
    }

    func later() {
        hide?.cancel()
        hide = Task { @MainActor in
            try? await Task.sleep(for: .seconds(1.6))
            if !Task.isCancelled && !scrubbing && !focused && !tracker.scrolling && coast == nil {
                shown = false
                veil(false)
            }
        }
    }

    // MARK: the figures

    /// where the strip stands when it isn't following the list: under your finger while dragging, on the day you
    /// opened, or on the top day once the list comes to rest, always a whole day, dead centre in the lens
    var stripFixed: Double? {
        if scrubbing { return nil }
        if focused { return Double(picked) }
        if !tracker.scrolling { return Double(tracker.top) }
        return nil
    }

    /// the day's budget: your month's budget spread over its days, else what the month has averaged a day
    var dailyBudget: Double {
        let fc = store.snap.fc
        if fc.budget > 0, fc.dim > 0 { return fc.budget / Double(fc.dim) }
        let spent: Double = days.reduce(0) { $0 + $1.total }
        return days.isEmpty ? 0 : spent / Double(days.count)
    }

    var groupsKey: String { (groups.first?.day ?? "") + "·" + String(groups.count) + "·" + String(Int(groups.reduce(0) { $0 + $1.total })) }

    func rebuild() {
        var out: [LensDay] = []
        var running: Double = groups.reduce(0) { $0 + $1.total }
        for g in groups {
            var by: [String: Double] = [:]
            for t in g.items where t.sp && t.a > 0 { by[t.c, default: 0] += t.a }
            let cats: [LensCat] = by.map { LensCat(name: $0.key, v: $0.value, color: store.catColor($0.key)) }.sorted { $0.v > $1.v }
            out.append(LensDay(day: g.day, total: g.total, soFar: running, cats: cats))
            running -= g.total
        }
        days = out
        tracker.set(groups)
    }
}

/// the strip itself: the only part of the lens that follows the list frame by frame
struct LensStrip: View {
    @Environment(\.accessibilityReduceMotion) private var still
    let days: [LensDay]
    let tracker: LensTracker
    /// under a finger (live): where the drag has it, read here alone
    let drag: LensDrag
    let live: Bool
    /// a set place (a day opened, the list at rest); nil follows the list frame by frame
    let fixed: Double?
    let mood: LensMood
    let budget: Double
    /// (smooth-5nov-c) how fast the strip moves, for its motion blur: a box, so measuring it redraws nothing
    @State private var speed = StripSpeed()

    var body: some View {
        // while it moves (a finger on it, or following the list) it's drawn every frame, so the streak fades the moment
        // it slows or rests; at rest the timeline is paused and the strip draws only when something changes
        TimelineView(.animation(minimumInterval: nil, paused: !LensBlur.on || still || !(live || fixed == nil))) { _ in strip }
    }

    var strip: some View {
        let n: Int = days.count
        // oldest on the left, so the day `pos` from the newest sits at column n-1-pos
        let pos: Double = live ? drag.pos : (fixed ?? tracker.pos)
        let whole: Bool = (live || fixed != nil) && pos == pos.rounded()
        let col: CGFloat = CGFloat(Double(n - 1) - pos)
        let cw: CGFloat = DayLens.cell
        let calm: Bool = still
        // the streak's length in points: none at rest, settling, or with Reduce Motion on
        let streak: CGFloat = speed.measure(pos, CACurrentMediaTime(), rest: whole || calm || (!live && fixed != nil))
        return GeometryReader { g in
            let mid: CGFloat = g.size.width / 2
            ZStack(alignment: .leading) {
                LensCells(days: days, budget: budget, calm: calm)
                    .equatable()
                    .offset(x: mid - cw / 2 - col * cw)
            }
            .frame(width: g.size.width, height: DayLens.stripH, alignment: .leading)
            .coordinateSpace(.named("lens.strip"))
            // the days streak sideways as they rush past, and sharpen as they slow (Metal, this strip alone)
            .layerEffect(ShaderLibrary.kMotionBlur(.float(streak)), maxSampleOffset: CGSize(width: 8, height: 0), isEnabled: LensBlur.on && streak > 0)
            .mask(LinearGradient(stops: [
                .init(color: .clear, location: 0), .init(color: .black, location: 0.2),
                .init(color: .black, location: 0.8), .init(color: .clear, location: 1),
            ], startPoint: .leading, endPoint: .trailing))
            .background {
                RoundedRectangle(cornerRadius: 17, style: .continuous)
                    .fill(mood.color.opacity(0.24))
                    .overlay(RoundedRectangle(cornerRadius: 17, style: .continuous).strokeBorder(mood.color.opacity(0.9), lineWidth: 1))
                    .frame(width: cw, height: 60)
                    .shadow(color: mood.color.opacity(0.45), radius: 10)
                    .position(x: mid, y: DayLens.stripH / 2)
            }
        }
        .frame(height: DayLens.stripH)
        // settling on a whole day eases in; following the list or a finger stays 1:1
        .animation(whole ? Motion.open : nil, value: pos)
    }
}

/// (smooth-5nov-c) the strip's motion blur needs Kosh/MotionBlur.metal, which needs Xcode's Metal Toolchain on the
/// Mac that builds (xcodebuild -downloadComponent MetalToolchain). Until then it's off: copy
/// tools/patches/files/MotionBlur.metal into Kosh/ and set this true
enum LensBlur { static let on: Bool = false }

/// (smooth-5nov-c) the strip's speed, smoothed over a few frames, as a motion-blur length
final class StripSpeed {
    private var p: Double = .nan
    private var t: CFTimeInterval = 0
    private var v: Double = 0
    func measure(_ pos: Double, _ now: CFTimeInterval, rest: Bool) -> CGFloat {
        defer { p = pos; t = now }
        if rest || p.isNaN { v = 0; return 0 }
        let dt: Double = now - t
        if dt <= 0.0005 { return blur }
        if dt > 0.1 { v = 0; return 0 }
        let inst: Double = (pos - p) / dt
        v += (inst - v) * min(1, dt / 0.03)
        return blur
    }
    /// days a second → points: about a frame and a half of travel, never more than 14 pt, nothing under 0.6
    private var blur: CGFloat {
        let x: Double = min(14, abs(v) * Double(DayLens.cell) * 0.012)
        return x < 0.6 ? 0 : CGFloat(x)
    }
}

/// where a finger has the strip, in days from the newest; observed by the strip alone
@Observable final class LensDrag { var pos: Double = 0 }

/// the cells, built once per month: moving the strip never rebuilds them
struct LensCells: View, Equatable {
    let days: [LensDay]
    let budget: Double
    let calm: Bool
    static func == (a: LensCells, b: LensCells) -> Bool {
        a.calm == b.calm && a.budget == b.budget && a.days.count == b.days.count && a.days.first?.day == b.days.first?.day
            && a.days.first?.total == b.days.first?.total
    }
    var body: some View {
        HStack(spacing: 0) {
            ForEach(days.reversed()) { d in
                cell(d)
                    .frame(width: DayLens.cell, height: DayLens.stripH)
                    // each day lifts as it nears the lens: worked out on the GPU from where it sits, so moving the
                    // strip never runs this view's body again
                    .visualEffect { [calm] content, proxy in
                        let x: CGFloat = proxy.frame(in: .named("lens.strip")).midX
                        let w: CGFloat = proxy.size.width
                        let mid: CGFloat = (proxy.bounds(of: .named("lens.strip"))?.width ?? 0) / 2
                        let near: CGFloat = max(0, 1 - abs(x - mid) / w)
                        return content
                            .scaleEffect(calm ? 1 : 1 + 0.16 * near)
                            .opacity(Double(max(0.28, 1 - abs(x - mid) / (w * 5))))
                    }
            }
        }
    }
    func cell(_ d: LensDay) -> some View {
        let first: Bool = Day.fmt(d.day, "d") == "1"
        let over: Bool = budget > 0 && d.total > budget
        let fill: Double = budget > 0 ? min(1, d.total / budget) : 0
        return VStack(spacing: 4) {
            Text(first ? Day.fmt(d.day, "MMM").uppercased() : Day.fmt(d.day, "EEEEE"))
                .font(.system(size: 9, weight: .bold)).tracking(0.5)
                .foregroundStyle(first ? Color(red: 1, green: 0.61, blue: 0.48) : Color.white.opacity(0.6))
            Text(Day.fmt(d.day, "d"))
                .font(.system(size: 18, weight: .bold, design: .rounded)).monospacedDigit()
                .foregroundStyle(.white)
            ZStack(alignment: .leading) {
                Capsule().fill(Color.white.opacity(0.14))
                Capsule().fill(over ? LensMood.over.color : LensMood.calm.color).frame(width: 20 * fill)
            }
            .frame(width: 20, height: 3)
        }
    }
}


/// the strip's ticks: a light one per day, a firmer one on a day over budget; prepared when a finger comes down so the
/// first tick isn't late
enum LensHaptics {
    @MainActor static let light = UISelectionFeedbackGenerator()
    @MainActor static let firm = UIImpactFeedbackGenerator(style: .medium)
    @MainActor static func ready() { light.prepare(); firm.prepare() }
    @MainActor static func tick(over: Bool) {
        if over { firm.impactOccurred(intensity: 0.85); firm.prepare() } else { light.selectionChanged(); light.prepare() }
    }
}
