import SwiftUI
import Charts

// MARK: - The live view's pictures, each drawn natively and built in on kosh's motion scale
//
// Seven pictures: one figure, months as bars, two sides compared, a ranked list, parts of a whole, a timeline, a
// calendar. Each draws the engine's figures as they are (LiveFill) and grows in: numbers counting up, bars rising,
// rows arriving 40 ms apart (Motion.stagger), never a bounce on money. `compact` is the Home card's smaller version.

struct LivePicture: View {
    let fill: LiveFill
    var compact: Bool = false
    var body: some View {
        switch fill.picture {
        case "trend": LiveTrend(fill: fill, compact: compact)
        case "compare": LiveCompare(fill: fill, compact: compact)
        case "ranked": LiveRanked(fill: fill, compact: compact)
        case "split": LiveSplit(fill: fill, compact: compact)
        case "timeline": LiveTimeline(fill: fill, compact: compact)
        case "calendar": LiveCalendar(fill: fill, compact: compact)
        default: LiveFigure(fill: fill, compact: compact)
        }
    }
}

/// a figure that counts in from nothing, once, when it's first shown (and moves to a new figure without starting over)
struct LiveNumber: View {
    let value: Double
    var count: Bool = false
    var signed: Bool = false
    var font: Font = .system(size: 44, weight: .bold, design: .rounded)
    @State private var shown: Double = 0
    var body: some View {
        Text(count ? String(Int(safe: shown.rounded())) : (signed && value < 0 ? "−" : "") + Fmt.rupees(shown))
            .font(font)
            .monospacedDigit()
            .contentTransition(.numericText(value: shown))
            .privacySensitive()
            .onAppear { withAnimation(Motion.reveal) { shown = value } }
            .onChange(of: value) { _, v in withAnimation(Motion.base) { shown = v } }
            .accessibilityLabel(count ? String(Int(safe: value)) : Fmt.rupees(value))
    }
}

/// what a picture says when there's nothing to draw
struct LiveBlank: View {
    let text: String
    var body: some View {
        Label(text, systemImage: "circle.dashed").font(.subheadline).foregroundStyle(.secondary)
    }
}

// MARK: one figure

struct LiveFigure: View {
    let fill: LiveFill
    var compact: Bool
    @State private var grown = false
    var body: some View {
        VStack(alignment: .leading, spacing: compact ? 6 : 12) {
            if let f = fill.figure {
                Text(f.label + " · " + fill.range.dates).font(.subheadline.weight(.medium)).foregroundStyle(.secondary)
                LiveNumber(value: abs(f.value), count: fill.unit == "count", signed: f.signed == true && f.value < 0,
                           font: .system(size: compact ? 30 : 46, weight: .bold, design: .rounded))
                if let s = f.sub, !s.isEmpty { Text(s).font(.footnote).foregroundStyle(.secondary) }
                if let d = f.delta, !compact { delta(d) }
            }
            if !compact && !fill.series.isEmpty && !fill.isBlank {
                Divider().padding(.vertical, 2)
                Text(fill.fact == "networth" ? "What makes it" : "Most of it went to").font(.footnote.weight(.semibold)).foregroundStyle(.secondary)
                let top: Double = fill.series.map { abs($0.value) }.max() ?? 1
                ForEach(Array(fill.series.prefix(5).enumerated()), id: \.offset) { i, p in
                    LiveBarRow(label: p.label, value: p.value, of: top, tint: p.value < 0 ? .orange : Color.kosh, i: i, sub: nil)
                }
            }
            if fill.isBlank && fill.figure == nil { LiveBlank(text: fill.blank) }
        }
    }
    func delta(_ d: LiveFill.Delta) -> some View {
        let up: Bool = d.value > 0
        let same: Bool = abs(d.value) < 1
        let ink: Color = same ? .secondary : fill.fact == "income" ? (up ? .green : .orange) : (up ? .orange : .green)
        return HStack(spacing: 6) {
            Image(systemName: same ? "equal" : up ? "arrow.up.right" : "arrow.down.right").font(.caption.weight(.bold))
            Text(same ? "The same as " + d.words : Fmt.rupees(abs(d.value)) + (up ? " more than " : " less than ") + d.words)
                .font(.subheadline.weight(.semibold))
        }
        .foregroundStyle(ink)
        .padding(.horizontal, 10).padding(.vertical, 6)
        .background(ink.opacity(0.12), in: Capsule())
        .privacySensitive()
    }
}

/// a row with its bar, growing from nothing in its turn
struct LiveBarRow: View {
    let label: String
    let value: Double
    let of: Double
    var tint: Color = Color.kosh
    let i: Int
    var sub: String?
    var rank: Int? = nil
    @State private var grown = false
    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            HStack(alignment: .firstTextBaseline) {
                if let rank { Text(String(format: "%02d", rank)).font(.system(.caption, design: .monospaced, weight: .semibold)).foregroundStyle(.tertiary) }
                Text(label).font(.subheadline).lineLimit(1)
                Spacer(minLength: 8)
                Text((value < 0 ? "−" : "") + Fmt.rupees(abs(value))).font(.subheadline.weight(.semibold)).monospacedDigit().privacySensitive()
            }
            GeometryReader { g in
                Capsule().fill(Color.primary.opacity(0.06))
                    .overlay(alignment: .leading) {
                        Capsule().fill(tint.gradient)
                            .frame(width: grown ? max(4, g.size.width * CGFloat(min(1, abs(value) / max(of, 1)))) : 0)
                    }
            }
            .frame(height: 6)
            if let sub, !sub.isEmpty { Text(sub).font(.caption).foregroundStyle(.secondary) }
        }
        .opacity(grown ? 1 : 0)
        .onAppear { withAnimation(Motion.reveal.delay(Motion.stagger(i, after: 0.15))) { grown = true } }
    }
}

// MARK: months as bars

struct LiveTrend: View {
    let fill: LiveFill
    var compact: Bool
    @State private var grown = false
    @State private var picked: String?
    var body: some View {
        let pts: [LiveFill.Point] = fill.series
        let sel: LiveFill.Point? = pts.first { $0.k == picked }
        VStack(alignment: .leading, spacing: 10) {
            if !compact {
                HStack(alignment: .firstTextBaseline) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(sel.map { $0.label + ($0.live == true ? " so far" : "") } ?? (fill.usual != nil ? "A usual month" : fill.range.words))
                            .font(.subheadline.weight(.medium)).foregroundStyle(.secondary)
                        LiveNumber(value: sel?.value ?? fill.usual ?? pts.last?.value ?? 0, font: .system(size: 34, weight: .bold, design: .rounded))
                    }
                    Spacer()
                }
            }
            Chart {
                ForEach(Array(pts.enumerated()), id: \.offset) { i, p in
                    BarMark(x: .value("Month", p.label), y: .value("Rupees", grown ? p.value : 0), width: .ratio(0.62))
                        .foregroundStyle(barInk(p))
                        .cornerRadius(5)
                        .opacity(picked == nil || picked == p.k ? 1 : 0.45)
                }
                if let u = fill.usual, u > 0, !compact {
                    RuleMark(y: .value("Usual", u))
                        .lineStyle(StrokeStyle(lineWidth: 1, dash: [4, 4]))
                        .foregroundStyle(Color.secondary)
                        .annotation(position: .top, alignment: .leading) { Text("usual").font(.caption2).foregroundStyle(.secondary) }
                }
            }
            .chartYAxis(compact ? .hidden : .automatic)
            .chartYAxis { AxisMarks(position: .trailing) { v in AxisGridLine(); AxisValueLabel { if let d = v.as(Double.self) { Text(Fmt.short(d)) } } } }
            .chartXAxis { AxisMarks { _ in AxisValueLabel() } }
            .frame(height: compact ? 70 : 210)
            .chartOverlay { proxy in
                GeometryReader { _ in
                    Rectangle().fill(.clear).contentShape(Rectangle())
                        .onTapGesture { loc in
                            if let l: String = proxy.value(atX: loc.x) { withAnimation(Motion.quick) { picked = pts.first { $0.label == l }?.k == picked ? nil : pts.first { $0.label == l }?.k } }
                        }
                }
            }
            .privacySensitive()
            if fill.isBlank { LiveBlank(text: fill.blank) }
        }
        .onAppear { withAnimation(Motion.reveal.delay(0.1)) { grown = true } }
    }
    func barInk(_ p: LiveFill.Point) -> AnyShapeStyle {
        if p.live == true { return AnyShapeStyle(Color.kosh.opacity(0.4)) }
        if p.k == fill.mark { return AnyShapeStyle(Color.orange.gradient) }
        return AnyShapeStyle(Color.kosh.gradient)
    }
}

// MARK: two sides

struct LiveCompare: View {
    let fill: LiveFill
    var compact: Bool
    @State private var grown = false
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            if let c = fill.compare {
                let top: Double = max(c.a.value, c.b.value, 1)
                HStack(alignment: .bottom, spacing: 18) {
                    side(c.a, top: top, ink: Color.kosh)
                    side(c.b, top: top, ink: Color.secondary.opacity(0.55))
                }
                .frame(height: compact ? 90 : 170)
                if !compact && !fill.series.isEmpty {
                    Text("What moved most").font(.footnote.weight(.semibold)).foregroundStyle(.secondary)
                    let most: Double = fill.series.map { abs($0.delta ?? 0) }.max() ?? 1
                    ForEach(Array(fill.series.enumerated()), id: \.offset) { i, p in
                        LiveBarRow(label: p.label + ((p.delta ?? 0) > 0 ? "  up" : "  down"), value: p.delta ?? 0, of: most,
                                   tint: (p.delta ?? 0) > 0 ? .orange : .green, i: i, sub: Fmt.rupees(p.value) + " against " + Fmt.rupees(p.prev ?? 0))
                    }
                }
            }
            if fill.isBlank { LiveBlank(text: fill.blank) }
        }
        .onAppear { withAnimation(Motion.reveal.delay(0.1)) { grown = true } }
    }
    func side(_ s: LiveFill.Side, top: Double, ink: Color) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Spacer(minLength: 0)
            Text(Fmt.rupees(s.value)).font(.system(.headline, design: .rounded, weight: .bold)).monospacedDigit().privacySensitive()
            GeometryReader { g in
                VStack { Spacer(minLength: 0)
                    RoundedRectangle(cornerRadius: 8, style: .continuous).fill(ink.gradient)
                        .frame(height: grown ? max(6, g.size.height * CGFloat(s.value / top)) : 0)
                }
            }
            Text(s.label).font(.footnote.weight(.semibold)).lineLimit(1)
            if !compact { Text(s.dates).font(.caption2).foregroundStyle(.secondary).lineLimit(1) }
        }
        .frame(maxWidth: .infinity)
    }
}

// MARK: a ranked list

struct LiveRanked: View {
    let fill: LiveFill
    var compact: Bool
    var body: some View {
        let pts: [LiveFill.Point] = compact ? Array(fill.series.prefix(3)) : fill.series
        let top: Double = pts.map { abs($0.value) }.max() ?? 1
        VStack(alignment: .leading, spacing: compact ? 8 : 14) {
            ForEach(Array(pts.enumerated()), id: \.offset) { i, p in
                LiveBarRow(label: p.label, value: p.value, of: top, i: i,
                           sub: compact ? nil : [p.sub, p.n.map { $0 == 1 ? "1 payment" : "\($0) payments" }, p.share.map { "\($0)%" }].compactMap { $0 }.joined(separator: " · "),
                           rank: compact ? nil : i + 1)
            }
            if let m = fill.more, m > 0, !compact { Text("and \(m) more").font(.footnote).foregroundStyle(.secondary) }
            if fill.isBlank { LiveBlank(text: fill.blank) }
        }
    }
}

// MARK: parts of a whole

struct LiveSplit: View {
    let fill: LiveFill
    var compact: Bool
    @Environment(Store.self) private var store
    @State private var grown = false
    static let palette: [Color] = [Color(hex: "#C2410C"), Color(hex: "#1D4ED8"), Color(hex: "#0F766E"), Color(hex: "#A16207"), Color(hex: "#7C3AED"), Color(hex: "#BE185D"), Color(hex: "#475569")]
    func ink(_ p: LiveFill.Point, _ i: Int) -> Color {
        if p.rest == true { return Color.secondary.opacity(0.4) }
        if fill.fact == "spend" || fill.fact == "paid", store.snap.cats[p.k] != nil { return store.catColor(p.k) }
        return Self.palette[i % Self.palette.count]
    }
    var body: some View {
        let pts: [LiveFill.Point] = fill.series.filter { $0.value > 0 }
        let total: Double = fill.total ?? pts.reduce(0) { $0 + $1.value }
        if compact {
            // one bar in proportion, the parts in their colours
            GeometryReader { g in
                HStack(spacing: 2) {
                    ForEach(Array(pts.enumerated()), id: \.offset) { i, p in
                        RoundedRectangle(cornerRadius: 3).fill(ink(p, i)).frame(width: max(2, (g.size.width - CGFloat(pts.count * 2)) * CGFloat(p.value / max(total, 1))))
                    }
                }
            }
            .frame(height: 12)
            .privacySensitive()
        } else {
            VStack(alignment: .leading, spacing: 16) {
                ZStack {
                    Chart {
                        ForEach(Array(pts.enumerated()), id: \.offset) { i, p in
                            SectorMark(angle: .value("Rupees", grown ? p.value : (i == 0 ? 1 : 0)), innerRadius: .ratio(0.64), angularInset: 1.5)
                                .cornerRadius(4)
                                .foregroundStyle(ink(p, i))
                        }
                    }
                    .frame(height: 220)
                    VStack(spacing: 2) {
                        Text(fill.range.words).font(.caption).foregroundStyle(.secondary)
                        LiveNumber(value: total, font: .system(size: 26, weight: .bold, design: .rounded))
                    }
                }
                .privacySensitive()
                ForEach(Array(pts.enumerated()), id: \.offset) { i, p in
                    HStack(spacing: 10) {
                        Circle().fill(ink(p, i)).frame(width: 9, height: 9)
                        Text(p.label).font(.subheadline).lineLimit(1)
                        Spacer()
                        if let s = p.share { Text("\(s)%").font(.footnote).foregroundStyle(.secondary).monospacedDigit() }
                        Text(Fmt.rupees(p.value)).font(.subheadline.weight(.semibold)).monospacedDigit().privacySensitive()
                    }
                    .opacity(grown ? 1 : 0)
                    .animation(Motion.base.delay(Motion.stagger(i, after: 0.25)), value: grown)
                }
                if fill.isBlank { LiveBlank(text: fill.blank) }
            }
            .onAppear { withAnimation(Motion.reveal) { grown = true } }
        }
    }
}

// MARK: a timeline

struct LiveTimeline: View {
    let fill: LiveFill
    var compact: Bool
    @State private var shown = false
    var body: some View {
        let items: [LiveFill.Item] = compact ? Array(fill.items.prefix(2)) : fill.items
        VStack(alignment: .leading, spacing: 0) {
            if let f = fill.figure, !compact {
                HStack(alignment: .firstTextBaseline) {
                    Text(f.label).font(.subheadline.weight(.medium)).foregroundStyle(.secondary)
                    Spacer()
                    LiveNumber(value: f.value, font: .system(size: 24, weight: .bold, design: .rounded))
                }
                .padding(.bottom, 14)
            }
            ForEach(Array(items.enumerated()), id: \.offset) { i, it in
                HStack(alignment: .top, spacing: 12) {
                    DateBadge(date: it.d)
                    VStack(alignment: .leading, spacing: 3) {
                        Text(it.title).font(.subheadline.weight(.semibold)).lineLimit(1)
                        Text([it.when, it.sub].filter { !$0.isEmpty }.joined(separator: " · ")).font(.caption).foregroundStyle(.secondary).lineLimit(2)
                    }
                    Spacer(minLength: 6)
                    VStack(alignment: .trailing, spacing: 4) {
                        Text((it.dir == "in" ? "+" : "") + Fmt.rupees(it.value)).font(.subheadline.weight(.semibold)).monospacedDigit()
                            .foregroundStyle(it.dir == "in" ? Color.green : Color.primary).privacySensitive()
                        if let st = it.state { state(st) }
                    }
                }
                .padding(.vertical, 9)
                .opacity(shown ? 1 : 0)
                .offset(y: shown ? 0 : 8)
                .animation(Motion.base.delay(Motion.stagger(i, after: 0.1)), value: shown)
                if i < items.count - 1 { Divider().padding(.leading, 54) }
            }
            if let m = fill.more, m > 0, !compact { Text("and \(m) more: tap the line below to see them all").font(.footnote).foregroundStyle(.secondary).padding(.top, 8) }
            if fill.isBlank { LiveBlank(text: fill.blank) }
        }
        .onAppear { shown = true }
    }
    func state(_ s: String) -> some View {
        let (word, ink): (String, Color) = s == "paid" ? ("paid", .green) : s == "late" ? ("late", .red) : s == "part" ? ("part back", .orange) : s == "waiting" ? ("waiting", .secondary) : ("due", .orange)
        return Text(word).font(.caption2.weight(.semibold)).foregroundStyle(ink).padding(.horizontal, 7).padding(.vertical, 2).background(ink.opacity(0.12), in: Capsule())
    }
}

// MARK: a calendar of days

struct LiveCalendar: View {
    let fill: LiveFill
    var compact: Bool
    @State private var picked: String?
    @State private var shown = false
    var body: some View {
        let days: [LiveFill.DayCell] = fill.days
        let top: Double = days.map(\.value).max() ?? 1
        let lead: Int = days.first.map { (Day.weekday($0.d) + 5) % 7 } ?? 0
        let cols: [GridItem] = Array(repeating: GridItem(.flexible(), spacing: compact ? 3 : 6), count: 7)
        let sel: LiveFill.DayCell? = days.first { $0.d == picked }
        VStack(alignment: .leading, spacing: 12) {
            if !compact {
                HStack(alignment: .firstTextBaseline) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(sel.map { Day.long($0.d) } ?? fill.range.dates).font(.subheadline.weight(.medium)).foregroundStyle(.secondary)
                        LiveNumber(value: sel?.value ?? fill.figure?.value ?? 0, font: .system(size: 30, weight: .bold, design: .rounded))
                    }
                    Spacer()
                }
                HStack { ForEach(["M", "T", "W", "T", "F", "S", "S"].indices, id: \.self) { i in Text(["M", "T", "W", "T", "F", "S", "S"][i]).font(.caption2.weight(.semibold)).foregroundStyle(.tertiary).frame(maxWidth: .infinity) } }
            }
            LazyVGrid(columns: cols, spacing: compact ? 3 : 6) {
                ForEach(0..<lead, id: \.self) { _ in Color.clear.frame(height: compact ? 10 : 38) }
                ForEach(Array(days.enumerated()), id: \.offset) { i, d in
                    let w: Double = d.value / max(top, 1)
                    RoundedRectangle(cornerRadius: compact ? 2.5 : 8, style: .continuous)
                        .fill(d.value > 0 ? Color.kosh.opacity(0.18 + 0.82 * w) : Color.primary.opacity(0.05))
                        .overlay {
                            if !compact { Text(String(Day.dayNumber(d.d))).font(.caption2.weight(.medium)).foregroundStyle(w > 0.55 ? Color.onKosh : Color.secondary) }
                        }
                        .overlay { if d.d == fill.mark || d.d == picked { RoundedRectangle(cornerRadius: compact ? 2.5 : 8, style: .continuous).strokeBorder(Color.primary.opacity(0.7), lineWidth: 1.5) } }
                        .frame(height: compact ? 10 : 38)
                        .opacity(shown ? 1 : 0)
                        .animation(Motion.base.delay(Motion.stagger(i / 7, after: 0.1)), value: shown)
                        .onTapGesture { if !compact { withAnimation(Motion.quick) { picked = picked == d.d ? nil : d.d } } }
                        .accessibilityLabel(Day.long(d.d) + ": " + Fmt.rupees(d.value))
                }
            }
            .privacySensitive()
            if fill.isBlank { LiveBlank(text: fill.blank) }
        }
        .onAppear { shown = true }
    }
}
