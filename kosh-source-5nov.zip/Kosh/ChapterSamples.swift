import SwiftUI

// MARK: - Chapters: what one is, and a sample year to show the design
//
// A chapter on the timeline is either one of your own (a trip or event kosh keeps, with its payments) or one
// of the samples: a made-up household's year, there to show how Chapters looks and reads before your own fill
// it. Nothing in the samples is anyone's real spending, and every name in them is invented.

struct Chapter: Identifiable, Hashable {
    let id: String
    let title: String
    let fam: ChapterFam
    /// its kind's drawing and look (KindTile key)
    let kind: String
    /// a stamp of its own; empty for one made from its name
    let stamp: String
    /// its ink, and the pale wash its card sits on (empty: made from the ink)
    let ink: String
    let tint: String
    /// its first and last day, and the day it hangs from on the timeline
    let from: String
    let to: String
    let pin: String
    let dates: String
    let amount: Double
    let extra: String
    var badge: String = ""
    var draft: Bool = false
    var rot: Double = -4
    var sample: Bool = true
    /// the first day money went out for it ahead of its days (flights, a venue's advance); empty when none did
    var lead: String = ""

    var art: StampArt {
        if !stamp.isEmpty { return Stamps.get(stamp) }
        return Stamps.custom(title: title, kind: kind, fam: fam, from: from, ink: Color(hex: ink).mix(with: .black, by: 0.22))
    }
    var inkColor: Color { stamp.isEmpty ? Color(hex: ink).mix(with: .black, by: 0.22) : Stamps.get(stamp).ink }
    func wash(_ scheme: ColorScheme) -> Color {
        if scheme == .dark { return inkColor.opacity(0.26) }
        if tint.isEmpty { return Color(hex: ink).mix(with: .white, by: 0.88) }
        return Color(hex: tint)
    }
    var days: Int { max(1, Day.between(from, to) + 1) }
    var famName: String {
        switch fam {
        case .journey: return "Journey"
        case .life: return "Life event"
        case .occasion: return "Occasion"
        case .project: return "Project"
        case .all: return "Chapter"
        }
    }
}

struct ChapterStory {
    struct HeroStamp: Identifiable {
        let key: String
        let size: CGFloat
        let rot: Double
        /// where its centre sits, as a share of the cover's width and height
        let x: CGFloat
        let y: CGFloat
        var id: String { key }
    }
    struct Figure: Identifiable {
        let value: String
        let label: String
        var id: String { label }
    }
    struct Feature: Identifiable {
        let symbol: String
        let title: String
        let sub: String
        var id: String { title }
    }
    struct Line: Identifiable {
        let name: String
        let amount: Double
        let share: String
        var planned: Double = 0
        var ahead: Double = 0
        var id: String { name }
    }
    struct Bar: Identifiable {
        let label: String
        let title: String
        let value: Double
        let note: String
        var id: String { title }
    }
    struct Band: Identifiable {
        let name: String
        let span: Int
        var id: String { name }
    }
    struct Place: Identifiable {
        let name: String
        let days: Int
        let amount: Double
        var id: String { name }
    }
    struct Pay: Identifiable {
        let kind: String
        let name: String
        let note: String
        let amount: String
        var id: String { name }
    }
    struct Avatar: Identifiable {
        let initial: String
        let color: String
        let fg: String
        var id: String { initial + color }
    }

    let chapter: Chapter
    var number: Int = 1
    var place: String = ""
    var who: String = ""
    var stamps: [HeroStamp] = []
    var figures: [Figure] = []
    var budget: Double = 0
    var spent: Double = 0
    var ahead: Double = 0
    var there: Double = 0
    var linesTitle: String = "Where it went"
    var lines: [Line] = []
    var planned: Bool = false
    var barsTitle: String = ""
    var bars: [Bar] = []
    var average: Double = 0
    var bands: [Band] = []
    var places: [Place] = []
    var gifts: [Pay] = []
    var biggest: [Pay] = []
    var features: [Feature] = []
    var people: [Avatar] = []
    var peopleTitle: String = ""
    var peopleSub: String = ""
    var groupLink: Bool = false
    /// a month with and without it, beside an ordinary one
    var month: String = ""
    var withIt: Double = 0
    var without: Double = 0
    var usual: Double = 0
    var footnote: String = ""
    var payments: Int = 0
    var share: String = ""
    /// one of your own: its id, its biggest payments
    var trip: String? = nil
    var topIDs: [String] = []
}

struct PayRow: Identifiable {
    let kind: String
    let name: String
    let sub: String
    let amount: String
    var fx: String = ""
    var id: String { name + sub }
}

struct PayGroup: Identifiable {
    let key: String
    let title: String
    let place: String
    let total: String
    let more: String
    let rows: [PayRow]
    var id: String { title + place }
}

struct GroupMember: Identifiable {
    let name: String
    let state: String
    let paid: String
    let color: String
    let fg: String
    var id: String { name }
}

/// the look each kind of chapter starts with when it's one of your own
struct ChapterPreset {
    let key: String
    let label: String
    let kind: String
    let sym: String
    let color: String
}

enum ChapterKinds {
    /// kind → (label, trip or event, symbol, colour, family)
    static let table: [(String, String, String, String, String, ChapterFam)] = [
        ("intl", "International trip", "trip", "airplane", "#007AFF", .journey),
        ("getaway", "Getaway", "trip", "beach.umbrella.fill", "#30B0C7", .journey),
        ("road", "Road trip", "trip", "car.fill", "#34C759", .journey),
        ("yatra", "Pilgrimage", "trip", "mountain.2.fill", "#FF9500", .journey),
        ("work", "Work trip", "trip", "briefcase.fill", "#5E5CE6", .journey),
        ("wedding", "Wedding", "event", "heart.fill", "#FF2D55", .life),
        ("move", "New city", "event", "shippingbox.fill", "#5E5CE6", .life),
        ("home", "New home", "event", "house.fill", "#A2845E", .life),
        ("baby", "New baby", "event", "stroller.fill", "#AF52DE", .life),
        ("study", "Studies", "event", "graduationcap.fill", "#34C759", .life),
        ("festival", "Festival", "event", "sparkles", "#FF9500", .occasion),
        ("party", "Celebration", "event", "party.popper.fill", "#FF2D55", .occasion),
        ("ceremony", "Ceremony", "event", "gift.fill", "#FF9500", .occasion),
        ("guest", "Wedding guest", "event", "envelope.fill", "#AF52DE", .occasion),
        ("reno", "Renovation", "event", "hammer.fill", "#007AFF", .project),
        ("vehicle", "New vehicle", "event", "car.side.fill", "#30B0C7", .project),
        ("course", "Course & exam", "event", "book.fill", "#34C759", .project),
        ("venture", "Side venture", "event", "storefront.fill", "#A2845E", .project),
        ("own", "A chapter of your own", "event", "star.fill", "#FF9500", .life)
    ]

    static func preset(_ key: String) -> ChapterPreset {
        let row = table.first { $0.0 == key } ?? table[table.count - 1]
        return ChapterPreset(key: row.0, label: row.1, kind: row.2, sym: row.3, color: row.4)
    }
    static func fam(_ key: String) -> ChapterFam { table.first { $0.0 == key }?.5 ?? .life }

    /// the kind a chapter of your own was made as, from its symbol
    static func kind(forSym sym: String, event: Bool) -> String {
        if let row = table.first(where: { $0.3 == sym }) { return row.0 }
        switch sym {
        case "beach.umbrella", "sailboat.fill", "tent.fill": return "getaway"
        case "figure.hiking", "mountain.2", "tram.fill": return event ? "own" : "road"
        case "party.popper": return "party"
        case "hammer": return "reno"
        case "gift": return "ceremony"
        case "heart": return "wedding"
        default: return event ? "own" : "intl"
        }
    }
}

enum ChapterSamples {
    /// every chapter hangs from its first day; what was paid before it shows as its lead
    static func c(_ id: String, _ title: String, _ kind: String, _ stamp: String, _ tint: String,
                  _ from: String, _ to: String, lead: String = "", _ dates: String, _ amount: Double, _ extra: String,
                  badge: String = "", draft: Bool = false, rot: Double = -4) -> Chapter {
        let ink: String = "#000000"
        return Chapter(id: id, title: title, fam: ChapterKinds.fam(kind), kind: kind, stamp: stamp, ink: ink, tint: tint,
                       from: from, to: to, pin: from, dates: dates, amount: amount, extra: extra, badge: badge, draft: draft, rot: rot,
                       sample: true, lead: lead)
    }

    static let chapters: [Chapter] = [
        c("vaishno", "Vaishno Devi", "yatra", "vaishno", "#FBF1EA", "2025-04-20", "2025-04-22", lead: "2025-03-02", "20 – 22 Apr 2025", 21300, "3 days", rot: -5),
        c("car", "The new car", "vehicle", "car", "#F2F3F4", "2025-08-02", "2025-08-23", "2 – 23 Aug 2025", 985000, "3 weeks", rot: 4),
        c("diwali25", "Diwali 2025", "festival", "diwali25", "#FFF4E6", "2025-10-15", "2025-11-02", "15 Oct – 2 Nov", 84300, "19 days", rot: -4),
        c("japan", "Japan in autumn", "intl", "japan", "#FCEEEA", "2025-11-12", "2025-11-24", lead: "2025-09-02", "12 – 24 Nov 2025", 384200, "13 days", badge: "Group of 4", rot: -6),
        c("wedding", "A & R, the wedding", "wedding", "wedding", "#FBEEF1", "2026-02-06", "2026-02-08", lead: "2025-09-05", "6 – 8 Feb 2026", 1840000, "3 days", badge: "Biggest chapter", rot: 5),
        c("rishikesh", "Rishikesh", "getaway", "rishikesh", "#EAF5F2", "2026-03-07", "2026-03-09", lead: "2026-02-21", "7 – 9 Mar 2026", 18450, "3 days", rot: -3),
        c("kitchen", "Kitchen redo", "reno", "kitchen", "#EDF2FA", "2026-04-01", "2026-06-15", "1 Apr – 15 Jun", 312000, "11 weeks", badge: "Over budget", rot: 4),
        c("spiti", "Spiti loop", "road", "spiti", "#F1F5EA", "2026-06-02", "2026-06-11", lead: "2026-05-26", "2 – 11 Jun 2026", 64900, "10 days", rot: -5),
        c("sixty", "A 60th birthday", "party", "party", "#FBF0F8", "2026-06-20", "2026-06-20", "20 Jun 2026", 58600, "1 evening", rot: 4),
        c("pune", "Kochi to Pune", "move", "pune", "#EFF0FB", "2026-07-01", "2026-07-31", lead: "2026-06-20", "Jul 2026", 146800, "1 month", rot: 5),
        c("offsite", "Client offsite", "work", "bengaluru", "#F1F2F5", "2026-08-14", "2026-08-16", lead: "2026-07-30", "14 – 16 Aug 2026", 42600, "₹38,000 to claim", badge: "To claim", rot: -4),
        c("diwali26", "Diwali 2026", "festival", "diwali26", "#FFF4E6", "2026-10-25", "2026-11-10", "25 Oct – 10 Nov", 90000, "budget", rot: 3),
        c("kabir", "Kabir weds Isha", "guest", "guest", "#F4F0FA", "2026-11-21", "2026-11-23", lead: "2026-09-02", "21 – 23 Nov · Udaipur", 63000, "budget", rot: -3),
        c("bali", "Bali", "getaway", "bali", "#ECF7FA", "2026-12-14", "2026-12-19", lead: "2026-09-10", "14 – 19 Dec 2026", 112400, "paid ahead", badge: "Draft from your mail", draft: true, rot: -4)
    ]

    static func chapter(_ id: String) -> Chapter? { chapters.first { $0.id == id } }

    /// the kinds to start a chapter from, by family
    static let kinds: [(ChapterFam, String, [(String, String)])] = [
        (.journey, "Trips with days and places. What you spend there goes in on its own.",
         [("intl", "International trip"), ("getaway", "Getaway"), ("road", "Road trip"), ("yatra", "Pilgrimage"), ("work", "Work trip")]),
        (.life, "The big turns, planned over months, usually with a budget.",
         [("wedding", "Wedding"), ("move", "New city"), ("home", "New home"), ("baby", "New baby"), ("study", "Studies")]),
        (.occasion, "Festivals, parties and ceremonies. Short, busy, full of gifts.",
         [("festival", "Festival"), ("party", "Celebration"), ("ceremony", "Ceremony"), ("guest", "Wedding guest")]),
        (.project, "Things you build or buy over weeks.",
         [("reno", "Renovation"), ("vehicle", "New vehicle"), ("course", "Course & exam"), ("venture", "Side venture")])
    ]

    // MARK: the stories

    static func story(_ id: String) -> ChapterStory {
        let ch: Chapter = chapter(id) ?? chapters[0]
        var st: ChapterStory
        switch id {
        case "japan": st = japan(ch)
        case "wedding": st = wedding(ch)
        default: st = made(ch, spec(id))
        }
        st.number = (chapters.sorted { $0.pin < $1.pin }.firstIndex { $0.id == id } ?? 0) + 1
        return st
    }

    static func japan(_ ch: Chapter) -> ChapterStory {
        var st = ChapterStory(chapter: ch)
        st.place = "Tokyo, Kyoto and Osaka"
        st.who = "4 of you"
        st.stamps = [.init(key: "kyoto", size: 92, rot: 9, x: 0.76, y: 0.33), .init(key: "osaka", size: 80, rot: -6, x: 0.89, y: 0.78)]
        st.figures = [.init(value: "₹3,84,200", label: "you paid"), .init(value: "13", label: "days"), .init(value: "₹11,577", label: "a day there"), .init(value: "86", label: "payments")]
        st.budget = 350000
        st.spent = 384200
        st.ahead = 233700
        st.there = 150500
        st.lines = [
            .init(name: "Flights", amount: 112800, share: "29%", ahead: 112800), .init(name: "Stays", amount: 108900, share: "28%", ahead: 108900),
            .init(name: "Food", amount: 58400, share: "15%"), .init(name: "Getting around", amount: 38700, share: "10%"),
            .init(name: "Shopping", amount: 36000, share: "9%"), .init(name: "Visa, insurance and fees", amount: 16860, share: "4%", ahead: 12000),
            .init(name: "Experiences", amount: 12540, share: "3%")
        ]
        st.barsTitle = "Day by day"
        st.bars = [
            .init(label: "12", title: "Wed 12 Nov · Tokyo", value: 17200, note: "IC cards, airport bus, sushi"),
            .init(label: "13", title: "Thu 13 Nov · Tokyo", value: 10200, note: "A museum, ramen, the metro"),
            .init(label: "14", title: "Fri 14 Nov · Tokyo", value: 13500, note: "Shopping in Shibuya"),
            .init(label: "15", title: "Sat 15 Nov · Tokyo", value: 7800, note: "Day trip to Kamakura"),
            .init(label: "16", title: "Sun 16 Nov · Tokyo", value: 14600, note: "Electronics in Akihabara"),
            .init(label: "17", title: "Mon 17 Nov · Tokyo", value: 11300, note: "Konbini, izakaya, a jacket"),
            .init(label: "18", title: "Tue 18 Nov · Kyoto", value: 9300, note: "Bullet train, temples"),
            .init(label: "19", title: "Wed 19 Nov · Kyoto", value: 18200, note: "Kaiseki dinner, kimono rental"),
            .init(label: "20", title: "Thu 20 Nov · Kyoto", value: 10700, note: "Arashiyama, a tea house"),
            .init(label: "21", title: "Fri 21 Nov · Kyoto", value: 8700, note: "Day trip to Nara"),
            .init(label: "22", title: "Sat 22 Nov · Osaka", value: 12600, note: "Street food in Dotonbori"),
            .init(label: "23", title: "Sun 23 Nov · Osaka", value: 9800, note: "Aquarium, a drugstore haul"),
            .init(label: "24", title: "Mon 24 Nov · Osaka", value: 6600, note: "Airport train, last gifts")
        ]
        st.average = 11577
        st.bands = [.init(name: "Tokyo", span: 6), .init(name: "Kyoto", span: 4), .init(name: "Osaka", span: 3)]
        st.places = [.init(name: "Tokyo", days: 6, amount: 74600), .init(name: "Kyoto", days: 4, amount: 46900), .init(name: "Osaka", days: 3, amount: 29000)]
        st.biggest = [
            .init(kind: "flight", name: "Flights · DEL ⇄ Japan", note: "paid 2 Sep · for 2 of you", amount: "₹1,12,800"),
            .init(kind: "stay", name: "Hotel, Shinjuku · 6 nights", note: "paid 14 Sep", amount: "₹52,400"),
            .init(kind: "stay", name: "Ryokan, Kyoto · 4 nights", note: "paid 20 Sep", amount: "₹34,600"),
            .init(kind: "stay", name: "Hotel, Namba · 3 nights", note: "paid 26 Sep", amount: "₹21,900"),
            .init(kind: "shop", name: "Electronics, Akihabara", note: "16 Nov · ¥16,700", amount: "₹9,400")
        ]
        st.features = [
            .init(symbol: "ticket", title: "₹2,33,700 booked ahead", sub: "Flights, stays, the visa and insurance, paid between 2 Sep and 30 Oct."),
            .init(symbol: "yensign", title: "Spent in yen, shown in rupees", sub: "Each card payment at the day's rate, with the 3.5% forex markup counted as a fee."),
            .init(symbol: "arrow.uturn.backward", title: "₹4,300 coming back", sub: "A tour the operator cancelled. kosh is watching your mail for it.")
        ]
        st.people = [.init(initial: "You", color: "#3D63C9", fg: "#FFFFFF"), .init(initial: "R", color: "#E9B04A", fg: "#2A1A00"), .init(initial: "K", color: "#4E9A72", fg: "#FFFFFF"), .init(initial: "M", color: "#7A1F33", fg: "#FFFFFF")]
        st.peopleTitle = "With Ria, Kabir and Meera"
        st.peopleSub = "Group pass · you're the host"
        st.groupLink = true
        st.month = "November 2025"
        st.withIt = 212400
        st.without = 61900
        st.usual = 63700
        st.footnote = "The trip didn't disturb ordinary life: November without it came to ₹61,900, close to your usual ₹63,700."
        st.payments = 86
        st.share = "Japan in autumn, 12 – 24 Nov 2025: ₹3,84,200 over 13 days, ₹11,577 a day there. Saved in kosh."
        return st
    }

    static func wedding(_ ch: Chapter) -> ChapterStory {
        var st = ChapterStory(chapter: ch)
        st.place = "Jaipur, planned over five months"
        st.who = "you and family"
        st.ahead = 1480000
        st.there = 360000
        st.stamps = [.init(key: "jaipur", size: 92, rot: 8, x: 0.76, y: 0.33), .init(key: "ceremony", size: 76, rot: -10, x: 0.89, y: 0.78)]
        st.figures = [.init(value: "₹18,40,000", label: "spent"), .init(value: "₹4,10,000", label: "came in as gifts"), .init(value: "5", label: "months of planning"), .init(value: "64", label: "payments")]
        st.budget = 2000000
        st.spent = 1840000
        st.linesTitle = "Planned and paid"
        st.lines = [
            .init(name: "Venue and catering", amount: 820000, share: "", planned: 850000),
            .init(name: "Outfits and jewellery", amount: 360000, share: "", planned: 300000),
            .init(name: "Décor and flowers", amount: 210000, share: "", planned: 220000),
            .init(name: "Photo and video", amount: 140000, share: "", planned: 150000),
            .init(name: "Guests' stay and travel", amount: 115000, share: "", planned: 120000),
            .init(name: "Mehendi and sangeet", amount: 100000, share: "", planned: 120000),
            .init(name: "Invites and gifts", amount: 95000, share: "", planned: 140000)
        ]
        st.planned = true
        st.barsTitle = "Month by month"
        st.bars = [
            .init(label: "Sep", title: "September 2025", value: 240000, note: "The venue and the caterer booked"),
            .init(label: "Oct", title: "October 2025", value: 110000, note: "Photographer, invitations"),
            .init(label: "Nov", title: "November 2025", value: 230000, note: "Outfits ordered, décor booked"),
            .init(label: "Dec", title: "December 2025", value: 380000, note: "Jewellery, rooms for guests"),
            .init(label: "Jan", title: "January 2026", value: 520000, note: "Outfits collected, mehendi, sangeet"),
            .init(label: "Feb", title: "February 2026", value: 360000, note: "The day: every balance paid")
        ]
        st.gifts = [
            .init(kind: "mail", name: "UPI and transfers", note: "from 38 people, put in by kosh", amount: "₹1,62,000"),
            .init(kind: "guest", name: "Envelopes", note: "counted and added by you", amount: "₹2,48,000")
        ]
        st.biggest = [
            .init(kind: "wedding", name: "Venue, Jaipur · advance", note: "paid 8 Sep", amount: "₹4,00,000"),
            .init(kind: "food", name: "Caterer · balance", note: "paid 8 Feb", amount: "₹2,70,000"),
            .init(kind: "shop", name: "Jewellery", note: "paid 14 Dec", amount: "₹1,90,000"),
            .init(kind: "fun", name: "Photographer · full", note: "paid 3 Oct", amount: "₹1,40,000")
        ]
        st.features = [
            .init(symbol: "gift", title: "₹4,10,000 came in as gifts", sub: "Shagun by UPI and in envelopes. What it really cost: ₹14,30,000."),
            .init(symbol: "calendar", title: "January was the heaviest month", sub: "₹5.2L, with outfits collected and two functions."),
            .init(symbol: "checkmark.seal", title: "Seven vendors, all settled", sub: "Each advance paired with its balance on the day.")
        ]
        st.people = [.init(initial: "You", color: "#3D63C9", fg: "#FFFFFF"), .init(initial: "F", color: "#C9A15A", fg: "#2A1A00")]
        st.peopleTitle = "Paid by you and family"
        st.peopleSub = "You ₹9,60,000 · family ₹8,80,000"
        st.month = "An average month, Sep – Feb"
        st.withIt = 367900
        st.without = 61200
        st.usual = 63700
        st.footnote = "Ordinary spending averaged ₹61,200 a month while it was planned, a touch under your usual ₹63,700. The wedding stayed in its own chapter."
        st.payments = 64
        st.share = "A & R, the wedding, 8 Feb 2026: ₹18,40,000 spent, ₹1,60,000 under budget, ₹4,10,000 came in as gifts. Saved in kosh."
        return st
    }

    // MARK: the rest, told from a short brief each

    struct Spec {
        /// name, share of what's spent (%), share of that paid ahead (0…1), its tile, its biggest payment's name, planned (₹)
        var lines: [(String, Double, Double, String, String, Double)] = []
        var place: String = ""
        var who: String = ""
        var spent: Double = 0
        var budget: Double = 0
        var bars: String = "days"
        var notes: [String] = []
        var features: [ChapterStory.Feature] = []
        var places: [ChapterStory.Place] = []
        var month: String = ""
        var withIt: Double = 0
        var without: Double = 0
        var usual: Double = 63700
        var footnote: String = ""
        var payments: Int = 0
    }

    static func spec(_ id: String) -> Spec {
        var s = Spec()
        switch id {
        case "vaishno":
            s.place = "Katra and the Bhawan"
            s.who = "3 of you"
            s.lines = [("Train tickets", 30, 1, "train", "Train · Delhi ⇄ Katra", 0), ("Stay in Katra", 28, 1, "stay", "Hotel in Katra · 2 nights", 0),
                       ("Food", 16, 0, "food", "Dinner near the Bhawan", 0), ("Ponies and cabs", 14, 0, "train", "Pony ride up the hill", 0),
                       ("Offerings", 8, 0, "yatra", "Offerings at the shrine", 0), ("Prasad and gifts", 4, 0, "shop", "Prasad to bring home", 0)]
            s.notes = ["Train in, the climb begins", "Darshan at dawn", "The walk down, train home"]
            s.features = [.init(symbol: "tram", title: "Booked six weeks ahead", sub: "Train and stay were paid in early March, when fares were lowest."),
                          .init(symbol: "figure.walk", title: "The climb cost least", sub: "Ponies and cabs came to under a sixth of it.")]
            s.month = "April 2025"; s.without = 60900; s.withIt = 82200
            s.footnote = "A short trip that barely moved April: ₹60,900 without it."
            s.payments = 14
        case "car":
            s.place = "Delivered from the showroom"
            s.who = "for the household"
            s.lines = [("The car", 86, 0, "vehicle", "The car · on-road balance", 0), ("Road tax and registration", 7, 0, "doc", "Road tax and registration", 0),
                       ("Insurance", 4, 0, "shield", "First-year insurance", 0), ("Accessories", 3, 0, "shop", "Mats, a dashcam, seat covers", 0)]
            s.bars = "weeks"
            s.notes = ["Booking amount", "Loan approved, insurance quoted", "Delivery day: the balance paid"]
            s.features = [.init(symbol: "building.columns", title: "₹6,00,000 on a car loan", sub: "Only the down payment and fees are counted here; the EMIs live in Loans."),
                          .init(symbol: "shield", title: "Insured from day one", sub: "The first year's cover came with the delivery.")]
            s.month = "August 2025"; s.without = 64800; s.withIt = 1049800
            s.footnote = "August without the car was ₹64,800, an ordinary month."
            s.payments = 9
        case "diwali25":
            s.place = "At home, and two visits"
            s.who = "the household"
            s.lines = [("Gifts", 32, 0, "ceremony", "Gift hampers for family", 0), ("Clothes", 22, 0, "shop", "New clothes for everyone", 0),
                       ("Sweets and food", 18, 0, "food", "Sweets for the neighbours", 0), ("Lights and décor", 12, 0, "festival", "Lights and rangoli", 0),
                       ("Puja", 6, 0, "ceremony", "Puja things", 0), ("House help bonus", 6, 0, "home", "Bonus for the help", 0), ("Crackers", 4, 0, "party", "Green crackers", 0)]
            s.notes = ["Cleaning and shopping", "Gifts for the office", "Lights go up", "Sweets ordered", "Clothes, a last trip", "Dhanteras", "Diwali", "Visiting family"]
            s.features = [.init(symbol: "gift", title: "A third of it went in gifts", sub: "Thirty-one of them, most bought in the week before."),
                          .init(symbol: "calendar.badge.clock", title: "Dhanteras was the busiest day", sub: "Silver coins and a new pressure cooker.")]
            s.month = "October 2025"; s.without = 63100; s.withIt = 141400
            s.footnote = "October without Diwali was ₹63,100, right on your usual."
            s.payments = 47
        case "rishikesh":
            s.place = "By the Ganga"
            s.who = "2 of you"
            s.lines = [("Riverside camp", 40, 1, "stay", "Riverside camp · 2 nights", 0), ("Food", 20, 0, "food", "Cafés along the river", 0),
                       ("Rafting and fun", 18, 0.5, "fun", "Rafting, 16 km", 0), ("Getting there", 16, 1, "vehicle", "Cab from Delhi and back", 0), ("Shopping", 6, 0, "shop", "A few things from the market", 0)]
            s.notes = ["Drive up, evening aarti", "Rafting, a café afternoon", "Yoga, the drive home"]
            s.features = [.init(symbol: "water.waves", title: "Rafting was the one big extra", sub: "Booked half ahead, half on the day."),
                          .init(symbol: "leaf", title: "A light weekend", sub: "Under ₹6,200 a day there, with the camp paid ahead.")]
            s.month = "March 2026"; s.without = 62400; s.withIt = 80850
            s.footnote = "March without it was ₹62,400."
            s.payments = 11
        case "kitchen":
            s.place = "Cabinets, counter and appliances"
            s.who = "for the home"
            s.budget = 280000
            s.lines = [("Cabinets and counter", 40, 0, "reno", "Modular cabinets · second part", 106000), ("Appliances", 24, 0, "home", "Chimney and hob", 64000),
                       ("Labour", 16, 0, "reno", "Carpenter and fitter", 45000), ("Plumbing and wiring", 10, 0, "reno", "Plumber and electrician", 34000), ("Tiles and paint", 10, 0, "reno", "Tiles and the backsplash", 31000)]
            s.bars = "weeks"
            s.notes = ["Demolition", "Plumbing and wiring", "Tiles", "Cabinet advance", "Waiting on the counter", "Counter fitted", "Cabinets fitted", "Appliances", "Paint", "Touch-ups", "Final payments"]
            s.features = [.init(symbol: "exclamationmark.triangle", title: "₹32,000 over budget", sub: "Mostly appliances: a better chimney than planned."),
                          .init(symbol: "hammer", title: "Eleven weeks, start to finish", sub: "The counter's delay added two weeks.")]
            s.month = "An average month, Apr – Jun"; s.without = 62000; s.withIt = 166000
            s.footnote = "Ordinary spending held near ₹62,000 a month through the work."
            s.payments = 23
        case "spiti":
            s.place = "Manali, Kaza and back over Kunzum"
            s.who = "3 of you, one car"
            s.lines = [("Stays", 34, 0.5, "stay", "Homestay in Kaza · 3 nights", 0), ("Fuel", 22, 0, "vehicle", "Fuel, Manali", 0),
                       ("Food", 18, 0, "food", "Dhabas and cafés", 0), ("Car service and tyres", 12, 1, "vehicle", "Service before the trip", 0),
                       ("Gear", 8, 1, "shop", "Jackets and gloves", 0), ("Permits and fees", 6, 0, "doc", "Permits and green tax", 0)]
            s.notes = ["Delhi to Manali", "Rest day in Manali", "Over Kunzum to Kaza", "Key monastery", "Langza and Hikkim", "Kaza market", "Tabo", "Nako lake", "Down to Shimla", "Home"]
            s.features = [.init(symbol: "fuelpump", title: "₹14,300 on fuel", sub: "About 1,900 km; fuel is a little dearer past Manali."),
                          .init(symbol: "car", title: "The car was readied first", sub: "Service and new tyres a week before, counted in the trip.")]
            s.places = [.init(name: "Manali", days: 2, amount: 14200), .init(name: "Kaza", days: 4, amount: 21800), .init(name: "Kinnaur", days: 4, amount: 12400)]
            s.month = "June 2026"; s.without = 63500; s.withIt = 128400
            s.footnote = "June without Spiti was ₹63,500, though the kitchen was finishing too."
            s.payments = 31
        case "sixty":
            s.place = "A dinner for forty"
            s.who = "you and family"
            s.budget = 60000
            s.lines = [("Venue and food", 52, 0, "food", "Dinner for forty", 31000), ("Gift", 18, 0, "ceremony", "A gold chain", 12000),
                       ("Cake and décor", 16, 0, "party", "Cake and flowers", 9000), ("Photos", 8, 0, "fun", "A photographer for the evening", 5000), ("Invites", 6, 0, "guest", "Printed invites", 3000)]
            s.bars = ""
            s.features = [.init(symbol: "checkmark.seal", title: "Just under budget", sub: "₹1,400 to spare on the ₹60,000 planned."),
                          .init(symbol: "person.3", title: "Forty guests", sub: "About ₹1,465 a guest, all told.")]
            s.month = "June 2026"; s.without = 63500; s.withIt = 122100
            s.footnote = "One evening, and the month around it stayed ordinary."
            s.payments = 8
        case "pune":
            s.place = "From Kochi to a new flat in Pune"
            s.who = "the household"
            s.lines = [("Deposit", 38, 0, "home", "Deposit for the flat", 0), ("Packers and movers", 22, 0, "move", "Packers and movers", 0),
                       ("Furniture", 20, 0, "shop", "A sofa and a bed", 0), ("Travel", 10, 1, "flight", "Flights · COK → PNQ", 0), ("Setting up", 10, 0, "home", "Internet, gas and a fridge repair", 0)]
            s.bars = "weeks"
            s.notes = ["Packing up in Kochi", "The move", "Deposit and keys", "Furniture", "Settling in"]
            s.features = [.init(symbol: "arrow.uturn.backward", title: "₹56,000 of it comes back", sub: "The deposit is money parked, not spent; kosh keeps it apart."),
                          .init(symbol: "shippingbox", title: "Movers were the biggest bill", sub: "₹32,300 for door to door with the car.")]
            s.month = "July 2026"; s.without = 66900; s.withIt = 213700
            s.footnote = "July without the move was ₹66,900, a little above usual with new-city prices."
            s.payments = 26
        case "offsite":
            s.place = "Bengaluru"
            s.who = "for work"
            s.lines = [("Flights", 44, 1, "flight", "Flights · DEL ⇄ BLR", 0), ("Hotel", 34, 1, "stay", "Hotel · 2 nights", 0), ("Food", 12, 0, "food", "Team dinner", 0), ("Cabs", 10, 0, "train", "Cabs", 0)]
            s.notes = ["Fly in, team dinner", "The offsite", "Fly home"]
            s.features = [.init(symbol: "doc.text", title: "₹38,000 to claim", sub: "Flights and hotel, with receipts saved from your mail."),
                          .init(symbol: "briefcase", title: "Left out of your spending", sub: "Work trips don't count once they're claimed back.")]
            s.month = "August 2026"; s.without = 61800; s.withIt = 104400
            s.footnote = "Once it's claimed, August is ₹61,800 of ordinary life."
            s.payments = 7
        case "diwali26":
            s.place = "At home"
            s.who = "the household"
            s.budget = 90000
            s.spent = 21800
            s.lines = [("Gifts", 38, 0, "ceremony", "Early gifts", 30000), ("Clothes", 53, 0, "shop", "Clothes for the kids", 20000),
                       ("Lights and décor", 9, 0, "festival", "New lights", 10000), ("Sweets", 0, 0, "food", "", 12000),
                       ("House help bonus", 0, 0, "home", "", 12000), ("Puja", 0, 0, "ceremony", "", 6000)]
            s.bars = ""
            s.features = [.init(symbol: "calendar", title: "Starts in a few weeks", sub: "₹68,200 of the budget left, most of it for the last week."),
                          .init(symbol: "chart.line.uptrend.xyaxis", title: "Last year: ₹84,300", sub: "Gifts and clothes took more than half.")]
            s.payments = 5
        case "kabir":
            s.place = "Udaipur, as guests"
            s.who = "2 of you"
            s.budget = 63000
            s.spent = 29200
            s.lines = [("Travel and stay", 56, 1, "stay", "Hotel in Udaipur · 2 nights", 24000), ("Outfits", 44, 0, "shop", "Outfits for the sangeet", 18000), ("Gift", 0, 0, "ceremony", "", 21000)]
            s.bars = ""
            s.features = [.init(symbol: "envelope.open", title: "RSVP'd yes", sub: "The invite came by mail on 2 Sep; the hotel is booked."),
                          .init(symbol: "gift", title: "₹21,000 set aside for a gift", sub: "Not spent yet.")]
            s.payments = 4
        case "bali":
            s.place = "Seminyak and Ubud"
            s.who = "2 of you"
            s.spent = 112400
            s.lines = [("Flights", 55, 1, "flight", "Flights · DEL ⇄ DPS", 0), ("Stay", 38, 1, "stay", "Villa in Ubud · 3 nights", 0), ("Travel insurance", 7, 1, "shield", "Travel insurance", 0)]
            s.bars = ""
            s.features = [.init(symbol: "envelope.badge", title: "Found in your mail", sub: "A flight, a villa and travel insurance, paid in September."),
                          .init(symbol: "checkmark.circle", title: "Make it a chapter", sub: "Confirm the dates and what you spend there goes in on its own.")]
            s.payments = 3
        default:
            break
        }
        return s
    }

    /// a full story from a brief: its money split, day by day (or week, or month), its biggest payments
    static func made(_ ch: Chapter, _ s: Spec) -> ChapterStory {
        var st = ChapterStory(chapter: ch)
        let future: Bool = ch.from > Day.iso(Date())
        let spent: Double = s.spent > 0 ? s.spent : ch.amount
        st.place = s.place
        st.who = s.who
        st.spent = spent
        st.budget = s.budget
        st.planned = s.budget > 0
        st.linesTitle = st.planned ? "Planned and paid" : "Where it went"
        var ahead: Double = 0
        var lines: [ChapterStory.Line] = []
        var pays: [ChapterStory.Pay] = []
        for l in s.lines {
            let v: Double = (spent * l.1 / 100 / 100).rounded() * 100
            let a: Double = (v * l.2 / 100).rounded() * 100
            ahead += a
            lines.append(ChapterStory.Line(name: l.0, amount: v, share: String(Int(safe: l.1.rounded())) + "%", planned: l.5, ahead: a))
            if v > 0 && !l.4.isEmpty {
                let one: Double = l.2 >= 1 ? v : (v * 0.42 / 100).rounded() * 100
                let when: String = l.2 >= 1 ? "paid " + Day.fmt(Day.add(ch.from, -24), "d MMM") : Day.fmt(ch.from, "d MMM")
                pays.append(ChapterStory.Pay(kind: l.3, name: l.4, note: when, amount: Fmt.rupees(one)))
            }
        }
        st.lines = lines
        st.biggest = Array(pays.sorted { amountOf($0.amount) > amountOf($1.amount) }.prefix(4))
        let journey: Bool = ch.fam == .journey
        if journey && ahead > 0 {
            st.ahead = ahead
            st.there = max(0, spent - ahead)
        }
        let spread: Double = journey && ahead > 0 ? st.there : spent
        if !future && !ch.draft { st.bars = bars(ch, s, spread) }
        st.barsTitle = s.bars == "weeks" ? "Week by week" : s.bars == "months" ? "Month by month" : "Day by day"
        if s.bars == "days" && !st.bars.isEmpty { st.average = (spread / Double(st.bars.count)).rounded() }
        st.places = s.places
        st.features = s.features
        st.month = s.month
        st.withIt = s.withIt
        st.without = s.without
        st.usual = s.month.isEmpty ? 0 : s.usual
        st.footnote = s.footnote
        st.payments = s.payments

        var figs: [ChapterStory.Figure] = [.init(value: Fmt.rupees(spent), label: ch.draft ? "paid ahead" : future ? "spent so far" : "spent")]
        if ch.days > 31 {
            figs.append(.init(value: String(max(1, ch.days / 7)), label: "weeks"))
        } else if ch.days > 1 {
            figs.append(.init(value: String(ch.days), label: "days"))
        }
        if s.bars == "days" && st.there > 0 && ch.days > 1 {
            figs.append(.init(value: Fmt.rupees((st.there / Double(ch.days)).rounded()), label: "a day there"))
        } else if s.budget > 0 {
            figs.append(.init(value: Fmt.words(s.budget), label: "budget"))
        }
        figs.append(.init(value: String(s.payments), label: "payments"))
        st.figures = figs
        st.share = ch.title + ", " + ch.dates + ": " + Fmt.rupees(spent) + ". Saved in kosh."
        return st
    }

    static func amountOf(_ s: String) -> Double { Double(s.filter { $0.isNumber }) ?? 0 }

    /// a gentle, repeatable wobble so the made-up days aren't all alike
    static func wobble(_ seed: String, _ i: Int) -> Double {
        var h: UInt64 = 1469598103934665603
        for u in (seed + String(i)).unicodeScalars { h = (h ^ UInt64(u.value)) &* 1099511628211 }
        return 0.55 + Double(h % 1000) / 1000 * 0.9
    }

    static func bars(_ ch: Chapter, _ s: Spec, _ total: Double) -> [ChapterStory.Bar] {
        if s.bars.isEmpty || total <= 0 { return [] }
        var titles: [(String, String)] = []
        if s.bars == "days" {
            for i in 0..<min(31, ch.days) {
                let d: String = Day.add(ch.from, i)
                titles.append((Day.fmt(d, "d"), Day.fmt(d, "EEE d MMM")))
            }
        } else if s.bars == "weeks" {
            let n: Int = max(1, Int((Double(ch.days) / 7).rounded(.up)))
            for i in 0..<n {
                titles.append(("W" + String(i + 1), "Week of " + Day.fmt(Day.add(ch.from, i * 7), "d MMM")))
            }
        } else {
            var m: String = String(ch.from.prefix(7))
            var n: Int = 0
            while m <= String(ch.to.prefix(7)) && n < 24 {
                titles.append((Day.monthShort(m), Day.fmt(m + "-01", "MMMM yyyy")))
                m = Day.addMonths(m, 1)
                n += 1
            }
        }
        if titles.isEmpty { return [] }
        var w: [Double] = []
        for i in 0..<titles.count { w.append(wobble(ch.id, i)) }
        let sum: Double = w.reduce(0, +)
        var out: [ChapterStory.Bar] = []
        for (i, t) in titles.enumerated() {
            let v: Double = (total * w[i] / sum / 100).rounded() * 100
            let note: String = s.notes.isEmpty ? "" : s.notes[i % s.notes.count]
            out.append(ChapterStory.Bar(label: t.0, title: t.1, value: v, note: note))
        }
        return out
    }

    // MARK: every payment in a sample

    static let japanPayments: [PayGroup] = [
        PayGroup(key: "osaka", title: "Mon 24 Nov", place: "Osaka", total: "₹6,600", more: "2 more", rows: [
            PayRow(kind: "train", name: "Airport train to KIX", sub: "Getting around · card ••4821", amount: "₹2,100", fx: "¥3,700"),
            PayRow(kind: "shop", name: "Gift shop, airport", sub: "Shopping · forex card", amount: "₹3,200", fx: "¥5,600")]),
        PayGroup(key: "osaka", title: "Sun 23 Nov", place: "Osaka", total: "₹9,800", more: "3 more", rows: [
            PayRow(kind: "fun", name: "Aquarium", sub: "Experiences · card ••4821", amount: "₹2,200", fx: "¥3,900"),
            PayRow(kind: "shop", name: "Drugstore, Shinsaibashi", sub: "Shopping · forex card", amount: "₹5,400", fx: "¥9,500")]),
        PayGroup(key: "osaka", title: "Sat 22 Nov", place: "Osaka", total: "₹12,600", more: "6 more", rows: [
            PayRow(kind: "food", name: "Okonomiyaki, Dotonbori", sub: "Food · cash", amount: "₹2,900", fx: "¥5,100"),
            PayRow(kind: "fee", name: "Forex markup", sub: "Fees · 3.5% on the day's card payments", amount: "₹410")]),
        PayGroup(key: "kyoto", title: "Wed 19 Nov", place: "Kyoto", total: "₹18,200", more: "3 more", rows: [
            PayRow(kind: "food", name: "Kaiseki dinner", sub: "Food · card ••4821", amount: "₹10,500", fx: "¥18,500"),
            PayRow(kind: "fun", name: "Kimono rental", sub: "Experiences · forex card", amount: "₹4,000", fx: "¥7,000")]),
        PayGroup(key: "tokyo", title: "Wed 12 Nov", place: "Tokyo", total: "₹17,200", more: "4 more", rows: [
            PayRow(kind: "train", name: "Airport bus", sub: "Getting around · card ••4821", amount: "₹1,800", fx: "¥3,200"),
            PayRow(kind: "train", name: "Transit card top-up", sub: "Getting around · cash", amount: "₹5,700", fx: "¥10,000"),
            PayRow(kind: "food", name: "Sushi dinner, Ginza", sub: "Food · card ••4821", amount: "₹7,300", fx: "¥12,800")]),
        PayGroup(key: "ahead", title: "Paid ahead", place: "2 Sep – 30 Oct", total: "₹2,33,700", more: "That's all 6", rows: [
            PayRow(kind: "flight", name: "Flights · DEL ⇄ Japan", sub: "Travel · 2 Sep · card ••4821", amount: "₹1,12,800"),
            PayRow(kind: "stay", name: "Hotel, Shinjuku · 6 nights", sub: "Travel · 14 Sep · card ••4821", amount: "₹52,400"),
            PayRow(kind: "stay", name: "Ryokan, Kyoto · 4 nights", sub: "Travel · 20 Sep · card ••4821", amount: "₹34,600"),
            PayRow(kind: "stay", name: "Hotel, Namba · 3 nights", sub: "Travel · 26 Sep · card ••4821", amount: "₹21,900"),
            PayRow(kind: "doc", name: "Japan e-visa", sub: "Travel · 8 Oct · UPI", amount: "₹6,200"),
            PayRow(kind: "shield", name: "Travel insurance", sub: "Insurance · 30 Oct · UPI", amount: "₹5,800")])
    ]
    static let japanFilters: [(String, String, String)] = [("all", "All", "86"), ("ahead", "Paid ahead", "6"), ("tokyo", "Tokyo", "39"), ("kyoto", "Kyoto", "23"), ("osaka", "Osaka", "18")]

    /// Japan in full; the others from their story: what was paid ahead, then each day (or week, or month)
    static func payments(_ id: String) -> [PayGroup] {
        if id == "japan" { return japanPayments }
        let st: ChapterStory = story(id)
        var out: [PayGroup] = []
        for b in st.bars.reversed() {
            let row = PayRow(kind: st.chapter.kind, name: b.note.isEmpty ? st.chapter.title : b.note, sub: b.title, amount: Fmt.rupees(b.value))
            out.append(PayGroup(key: "there", title: b.title, place: "", total: Fmt.rupees(b.value), more: "", rows: [row]))
        }
        let ahead: [ChapterStory.Line] = st.lines.filter { $0.ahead > 0 }
        if !ahead.isEmpty {
            let rows: [PayRow] = ahead.map { PayRow(kind: "doc", name: $0.name, sub: "Paid ahead", amount: Fmt.rupees($0.ahead)) }
            out.append(PayGroup(key: "ahead", title: "Paid ahead", place: "", total: Fmt.rupees(st.ahead), more: "", rows: rows))
        }
        if out.isEmpty {
            let rows: [PayRow] = st.lines.filter { $0.amount > 0 }.map { PayRow(kind: st.chapter.kind, name: $0.name, sub: "So far", amount: Fmt.rupees($0.amount)) }
            out.append(PayGroup(key: "all", title: "So far", place: "", total: Fmt.rupees(st.spent), more: "", rows: rows))
        }
        return out
    }
    static func filters(_ id: String) -> [(String, String, String)] {
        if id == "japan" { return japanFilters }
        let g: [PayGroup] = payments(id)
        var out: [(String, String, String)] = [("all", "All", String(g.reduce(0) { $0 + $1.rows.count }))]
        let ahead: Int = g.filter { $0.key == "ahead" }.reduce(0) { $0 + $1.rows.count }
        let there: Int = g.filter { $0.key == "there" }.reduce(0) { $0 + $1.rows.count }
        if ahead > 0 && there > 0 {
            out.append(("ahead", "Paid ahead", String(ahead)))
            out.append(("there", "There", String(there)))
        }
        return out
    }

    // MARK: the group pass (Japan)

    static let members: [GroupMember] = [
        GroupMember(name: "You", state: "host", paid: "₹3,84,200", color: "#3D63C9", fg: "#FFFFFF"),
        GroupMember(name: "Ria", state: "joined 3 Sep", paid: "₹1,20,000", color: "#E9B04A", fg: "#2A1A00"),
        GroupMember(name: "Kabir", state: "joined 3 Sep", paid: "₹1,58,700", color: "#4E9A72", fg: "#FFFFFF"),
        GroupMember(name: "Meera", state: "joined 5 Sep · left Kyoto early", paid: "₹69,500", color: "#7A1F33", fg: "#FFFFFF")
    ]
    static let owedEqual: [(String, Double)] = [("Meera", 113600), ("Ria", 63100), ("Kabir", 24400)]
    static let owedByDays: [(String, Double)] = [("Ria", 82600), ("Meera", 55100), ("Kabir", 43900)]
    static let groupCode: String = "KSH-JP25-7Q4M"
}

// MARK: - The notebook Chapters opens on
//
// Chapters opens on a notebook, a page a chapter, oldest first, and a blank last page that's yours. Your own
// chapters fill it (NotebookMaker, in ChapterNotebook.swift, turns each into a page); until there's one, it holds
// six pages from a made-up household's life, 2019 to now. Like the rest of the samples, nothing in those is
// anyone's real spending, and every name is invented.

/// a page of the notebook: a chapter in a line, its numbers, its three biggest categories and kosh's note on it
struct NotebookChapter: Identifiable {
    let id: String
    let year: Int
    let title: String
    let when: String
    let months: Int
    let pays: Int
    let amount: Double
    /// "spent", "so far" for one still being written, "paid ahead" for one still to come
    var cap: String = "spent"
    /// its ink, and the wash its photo is printed on
    let ink: String
    let wash: String
    /// how the photo sits, taped on a little crooked
    let rot: Double
    /// the line under it, and the margin note in its summary
    let head: String
    var note: String = ""
    /// its three biggest categories and their share of what it cost (%)
    var top: [(String, Int)] = []
    var isNext: Bool = false
    /// its first day (yyyy-MM-dd): its stop on the slider. The blank page has none.
    var from: String = ""
    /// how long it ran, as the page puts it ("6 days", "3 months"); empty: its months
    var span: String = ""
    /// the drawing on its photo (NotebookScenes); empty: the one drawn for its id
    var scene: String = ""
    /// the photo re-inked in the chapter's colour; nil: as drawn
    var tint: SceneTint? = nil
    /// one of the made-up ones
    var sample: Bool = true
    /// one of yours: the chapter its page opens
    var chapterID: String? = nil
    /// what each of its top categories came to, when it's known to the rupee (yours)
    var topAmounts: [Double] = []
}

extension NotebookChapter {
    var sceneKey: String { scene.isEmpty ? id : scene }
    /// its stop on the slider, "Mar 2026"; the blank page's is "Next"
    var stop: String {
        if isNext { return "Next" }
        return from.isEmpty ? String(year) : Day.fmt(from, "MMM yyyy")
    }
    /// what its i-th biggest category came to: to the rupee when known, else its share of the whole, to the hundred
    func partAmount(_ i: Int, _ share: Int) -> Double {
        if i < topAmounts.count { return topAmounts[i] }
        return (amount * Double(share) / 100 / 100).rounded() * 100
    }
}

extension ChapterSamples {
    static let notebook: [NotebookChapter] = [
        NotebookChapter(id: "msc", year: 2019, title: "The MSc year", when: "Jul 2019 – Jun 2020", months: 12, pays: 214, amount: 680000,
                        ink: "#166534", wash: "#EDF6F0", rot: -4,
                        head: "Fees, flatmates, and enough Maggi to count as a minor.",
                        note: "62% went on fees. The other 38% went on surviving them.",
                        top: [("Fees", 62), ("Rent", 21), ("Food", 9)], from: "2019-07-01"),
        NotebookChapter(id: "wedding", year: 2021, title: "Our wedding", when: "26 – 28 Nov 2021", months: 7, pays: 168, amount: 1240000,
                        ink: "#9F1D3A", wash: "#FBEEF1", rot: 5,
                        head: "Three days, four outfits, one very happy caterer.",
                        note: "Nobody remembers the fairy lights. Everybody remembers the dal makhani.",
                        top: [("Venue & food", 46), ("Jewellery", 28), ("Clothes", 14)], from: "2021-11-26"),
        NotebookChapter(id: "home", year: 2023, title: "A new home", when: "Mar – Jul 2023", months: 5, pays: 131, amount: 620000,
                        ink: "#7A3418", wash: "#F8F0EA", rot: -3,
                        head: "₹6.2L later, the keys were yours.",
                        note: "Mostly the kitchen. The plants came free, courtesy of Mom.",
                        top: [("Interiors", 52), ("Furniture", 27), ("Moving", 9)], from: "2023-03-01"),
        NotebookChapter(id: "japan", year: 2024, title: "Japan, finally", when: "12 – 24 Nov 2024", months: 4, pays: 86, amount: 384200,
                        ink: "#C2412D", wash: "#FCEEEA", rot: -6,
                        head: "Twelve days, one bullet train, zero regrets about the ramen.",
                        note: "Booked four months early, so the flights stayed polite.",
                        top: [("Flights", 29), ("Stays", 28), ("Food", 15)], from: "2024-11-12"),
        NotebookChapter(id: "studio", year: 2025, title: "Starting the studio", when: "Feb – Jul 2025", months: 6, pays: 74, amount: 215000,
                        ink: "#78350F", wash: "#F8F2E9", rot: 4,
                        head: "Day one was a Tuesday. The chai budget held.",
                        note: "Half went on gear, a third sat with the landlord. Biscuits: unaccounted for.",
                        top: [("Equipment", 48), ("Deposit", 30), ("Website", 8)], from: "2025-02-01"),
        NotebookChapter(id: "baby", year: 2026, title: "Baby on the way", when: "since May 2026", months: 5, pays: 52, amount: 112600, cap: "so far",
                        ink: "#4F46E5", wash: "#F2F0FB", rot: 3,
                        head: "Due in February. Already owns more clothes than you.",
                        note: "Tiny socks, enormous joy. The scans were the big line.",
                        top: [("Doctor & scans", 44), ("Nursery", 31), ("Clothes", 12)], from: "2026-05-01")
    ]

    /// the last page: blank, and yours
    static let notebookNext = NotebookChapter(id: "next", year: 2027, title: "Your next chapter", when: "", months: 0, pays: 0, amount: 0,
                                              ink: "#3B5BFD", wash: "#EEF2FF", rot: 2,
                                              head: "Blank page, fresh chai. What’s it going to be?", isNext: true)

    static var notebookPages: [NotebookChapter] { notebook + [notebookNext] }

}
