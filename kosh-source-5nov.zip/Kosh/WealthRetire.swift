import SwiftUI

// MARK: - Wealth › Holdings › Retirement (1 Nov, his pick, "KindRetire")
//
// EPF, PPF and NPS together: what they come to, EPF month by month off the passbook (your share, your employer's, the
// year's interest on its March), the months to look at (nothing went in; your share without your employer's), old EPF
// accounts not moved into the current one, then a card an account. Every figure is the build's (snap.retirement,
// engine/21l and 21u); the year-by-year book, the missed months against payslips and the passbook itself are one tap
// on (HoldingsView › RetirementSections). The mockup's "at 58" projection is not drawn: it needs a salary path, a rate
// and an age kosh would have to assume.

struct WealthRetire: View {
    @Environment(Store.self) private var store
    @Environment(\.accessibilityReduceMotion) private var still
    let tabs: [String]
    let kind: String

    var body: some View {
        let p: Person = store.who
        let held: [Holding] = store.holdings(p).filter { $0.cls == "ret" && $0.amt > 0 }.sorted { $0.amt > $1.amt }
        // (the passbook's reckoning is read for whoever's inbox kosh reads: the household's and yours)
        let book: RetirementBook? = (p == .family || p == .me) ? store.snap.retirement : nil
        ScrollView {
            VStack(alignment: .leading, spacing: 30) {
                VStack(alignment: .leading, spacing: 0) {
                    HoldingsTop(tabs: tabs, kind: kind).padding(.bottom, 18)
                    if held.isEmpty {
                        RetireEmpty()
                    } else {
                        RetireHead(held: held, book: book)
                    }
                }
                if let e = book?.epf { RetireEPFMonths(epf: e) }
                RetireAccounts(held: held, book: book)
                if !held.isEmpty {
                    WealthLinkRow(title: "Every job, year by year, and the passbook", sub: "What went in each year, months to look at, what kosh remembers",
                                  color: Obsidian.property) { store.push(.holdings("ret:" + p.rawValue)) }
                        .background(RoundedRectangle(cornerRadius: 22, style: .continuous).fill(Obsidian.card))
                        .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous).stroke(Obsidian.cardBorder, lineWidth: 1))
                }
            }
            .padding(.horizontal, 20)
            .padding(.bottom, 40)
            .animation(still ? nil : Motion.base, value: store.who)
        }
        .scrollIndicators(.hidden)
    }
}

struct RetireEmpty: View {
    @Environment(Store.self) private var store
    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("No EPF, PPF or NPS kosh has read yet.")
                .font(.body).foregroundStyle(Obsidian.ink2)
                .fixedSize(horizontal: false, vertical: true)
            if store.live != nil {
                Button { store.betaSheet = .epf } label: {
                    Label("Add EPF, from the EPFO passbook", systemImage: "briefcase")
                        .font(.subheadline.weight(.semibold))
                        .frame(minHeight: 44)
                }
                .buttonStyle(.press)
            }
        }
        .padding(.top, 24)
    }
}

/// what it comes to, and what went in for the newest month the passbook has
struct RetireHead: View {
    let held: [Holding]
    let book: RetirementBook?

    var body: some View {
        let total: Double = held.reduce(0) { $0 + $1.amt }
        VStack(alignment: .leading, spacing: 0) {
            Text(Self.tag(held)).caption(Obsidian.property)
            WealthFigure(value: total)
                .padding(.top, 8)
            if let line = Self.lastMonth(book) {
                Text(line).font(.subheadline).foregroundStyle(Obsidian.ink2)
                    .fixedSize(horizontal: false, vertical: true)
                    .padding(.top, 8)
                    .privacySensitive()
            }
            if let e = book?.epf, let day = e.asOf {
                Text("EPFO passbook to " + Day.fmt(day, "d MMM yyyy")).font(.caption).foregroundStyle(Obsidian.ink3)
                    .padding(.top, 6)
            }
        }
    }

    /// "Retirement · EPF + PPF"
    static func tag(_ held: [Holding]) -> String {
        let types: [String] = Array(Set(held.map { $0.type.uppercased() })).filter { !$0.isEmpty }.sorted()
        return "Retirement" + (types.isEmpty ? "" : " · " + types.joined(separator: " + "))
    }

    /// "₹6,200 went in for Sep 2026, your share and your employer's"
    static func lastMonth(_ book: RetirementBook?) -> String? {
        guard let ms = book?.epf?.months, let last = ms.filter({ $0.ee + $0.er > 0 }).max(by: { $0.m < $1.m }) else { return nil }
        let both: String = last.er > 0 ? ", your share and your employer’s" : ", your share alone"
        return Fmt.rupees(last.ee + last.er) + " went into EPF for " + Day.fmt(last.m + "-01", "MMM yyyy") + both
    }
}

// MARK: EPF month by month

struct RetireEPFMonths: View {
    @Environment(Store.self) private var store
    let epf: RetirementBook.EPF

    var body: some View {
        let w: (months: [WealthEPFMonth], gaps: [WealthEPFGap]) = Self.window(epf)
        VStack(alignment: .leading, spacing: 12) {
            Text("EPF · month by month").caption()
            VStack(alignment: .leading, spacing: 12) {
                if w.months.isEmpty {
                    RetireNoMonths()
                } else {
                    EPFBars(months: w.months, gaps: w.gaps)
                        .frame(height: 120)
                    EPFAxis(months: w.months)
                    EPFLegend(interest: w.months.contains { $0.int > 0 })
                    if !w.gaps.isEmpty {
                        Text(Self.gapWords(w.gaps)).font(.caption.weight(.semibold)).foregroundStyle(Obsidian.motor)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                    if let i = w.months.last(where: { $0.int > 0 }) {
                        Text(Self.interestWords(i)).font(.caption).foregroundStyle(Obsidian.ink3)
                            .fixedSize(horizontal: false, vertical: true)
                            .privacySensitive()
                    }
                }
                if !epf.left.isEmpty {
                    Text(EPFSections.leftLine(epf))
                        .font(.caption.weight(.semibold)).foregroundStyle(Obsidian.motor)
                        .fixedSize(horizontal: false, vertical: true)
                        .padding(12)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(RoundedRectangle(cornerRadius: 12, style: .continuous).fill(Obsidian.motor.opacity(0.08)))
                        .privacySensitive()
                }
            }
            .obsidianCard(22, padding: 16)
        }
    }

    static func window(_ epf: RetirementBook.EPF) -> (months: [WealthEPFMonth], gaps: [WealthEPFGap]) {
        let rows: [(m: String, ee: Double, er: Double, int: Double)] = (epf.months ?? []).map { (x: RetirementBook.EPF.Month) -> (m: String, ee: Double, er: Double, int: Double) in
            (m: x.m, ee: x.ee, er: x.er, int: x.int ?? 0)
        }
        return WealthBook.epfWindow(rows, count: 12)
    }

    /// "Jul 2026: nothing went in. Aug–Sep 2026: your share went in, not your employer's."
    static func gapWords(_ gaps: [WealthEPFGap]) -> String {
        gaps.map { (g: WealthEPFGap) -> String in
            let span: String = g.from == g.to ? Day.fmt(g.from + "-01", "MMM yyyy")
                : Day.fmt(g.from + "-01", "MMM") + "–" + Day.fmt(g.to + "-01", "MMM yyyy")
            return span + (g.what == "none" ? ": nothing went in." : ": your share went in, not your employer’s.")
        }.joined(separator: " ")
    }

    /// "Interest of ₹9,000 for the year to Mar 2026, credited on its last month"
    static func interestWords(_ m: WealthEPFMonth) -> String {
        "Interest of " + Fmt.rupees(m.int) + " for the year to " + Day.fmt(m.m + "-01", "MMM yyyy") + ", shown on that March as the passbook dates it."
    }
}

/// a passbook read before kosh kept its months: say how to fill the chart, never draw a guessed one
struct RetireNoMonths: View {
    @Environment(Store.self) private var store
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Open your EPFO passbook once more and kosh will draw what went in each month, yours and your employer’s.")
                .font(.subheadline).foregroundStyle(Obsidian.ink2)
                .fixedSize(horizontal: false, vertical: true)
            if store.live != nil {
                Button { store.betaSheet = .epf } label: {
                    Text("Open the passbook").font(.subheadline.weight(.semibold)).foregroundStyle(Obsidian.property)
                        .frame(minHeight: 44)
                }
                .buttonStyle(.press)
            }
        }
    }
}

/// the bars: your share at the bottom, your employer's on it, an amber dot over a March with the year's interest; a
/// month to look at is an orange outline
struct EPFBars: View {
    let months: [WealthEPFMonth]
    let gaps: [WealthEPFGap]

    var body: some View {
        let top: Double = months.map(\.paid).max() ?? 1
        HStack(alignment: .bottom, spacing: 4) {
            ForEach(months) { (m: WealthEPFMonth) in
                EPFBar(m: m, top: top, flagged: Self.flagged(m.m, gaps))
            }
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(Self.spoken(months))
    }

    static func flagged(_ m: String, _ gaps: [WealthEPFGap]) -> Bool {
        gaps.contains { $0.from <= m && m <= $0.to }
    }
    static func spoken(_ months: [WealthEPFMonth]) -> String {
        months.map { (m: WealthEPFMonth) -> String in
            Day.fmt(m.m + "-01", "MMMM") + ": " + (m.paid > 0 ? Fmt.rupees(m.ee) + " yours, " + Fmt.rupees(m.er) + " your employer’s" : "nothing")
        }.joined(separator: "; ")
    }
}

struct EPFBar: View {
    let m: WealthEPFMonth
    let top: Double
    let flagged: Bool

    var body: some View {
        let room: CGFloat = 96
        let ee: CGFloat = top > 0 ? room * CGFloat(m.ee / top) : 0
        let er: CGFloat = top > 0 ? room * CGFloat(m.er / top) : 0
        VStack(spacing: 2) {
            Spacer(minLength: 0)
            if m.int > 0 {
                Circle().fill(Obsidian.savings).frame(width: 7, height: 7).padding(.bottom, 2)
            }
            if m.paid > 0 {
                if er > 0 { RoundedRectangle(cornerRadius: 3).fill(Color(hex: "#F7A8BC")).frame(height: max(2, er)) }
                RoundedRectangle(cornerRadius: 3).fill(Obsidian.property).frame(height: max(2, ee))
            } else {
                RoundedRectangle(cornerRadius: 3)
                    .strokeBorder(flagged ? Obsidian.motor : Color.white.opacity(0.12), style: StrokeStyle(lineWidth: 1, dash: [2, 2]))
                    .frame(height: 12)
            }
        }
        .frame(maxWidth: .infinity)
        .overlay(alignment: .bottom) {
            if flagged && m.paid > 0 {
                Rectangle().fill(Obsidian.motor).frame(height: 2).offset(y: 4)
            }
        }
    }
}

/// the first and the last month under the bars
struct EPFAxis: View {
    let months: [WealthEPFMonth]
    var body: some View {
        HStack {
            Text(Self.label(months.first?.m))
            Spacer()
            Text(Self.label(months.last?.m))
        }
        .font(.caption2).foregroundStyle(Obsidian.ink3)
    }
    static func label(_ m: String?) -> String {
        guard let m else { return "" }
        return Day.fmt(m + "-01", "MMM ’yy")
    }
}

struct EPFLegend: View {
    let interest: Bool
    var body: some View {
        HStack(spacing: 14) {
            Self.key(Obsidian.property, "You")
            Self.key(Color(hex: "#F7A8BC"), "Employer")
            if interest { Self.key(Obsidian.savings, "Interest") }
        }
        .font(.caption).foregroundStyle(Obsidian.ink2)
    }
    static func key(_ c: Color, _ label: String) -> some View {
        HStack(spacing: 5) {
            Circle().fill(c).frame(width: 7, height: 7)
            Text(label)
        }
    }
}

// MARK: each account

struct RetireAccounts: View {
    @Environment(Store.self) private var store
    let held: [Holding]
    let book: RetirementBook?

    var body: some View {
        let cards: [RetireCardData] = Self.cards(held: held, book: book, today: store.snap.today, who: store.who)
        if !cards.isEmpty {
            VStack(alignment: .leading, spacing: 12) {
                Text(cards.count == 1 ? "The account" : "Each account").caption()
                ForEach(cards) { (c: RetireCardData) in
                    if let r = c.route {
                        Button { store.push(r) } label: { RetireCard(c: c) }.buttonStyle(.press)
                    } else {
                        RetireCard(c: c)
                    }
                }
            }
        }
    }

    /// a card for each EPF job that counts, the PPF, the NPS, and anything else held for retirement; with no reckoning
    /// (another person's money) a card a holding
    static func cards(held: [Holding], book: RetirementBook?, today: String, who: Person = .family) -> [RetireCardData] {
        var out: [RetireCardData] = []
        guard let b = book else {
            return held.map { (h: Holding) -> RetireCardData in plain(h) }
        }
        if let e = b.epf {
            for j in e.jobs where j.counted && j.movedTo == nil && j.amt > 0 {
                out.append(epfCard(j, left: e.left.contains(j.id)))
            }
        }
        if let p = b.ppf {
            // (ppf-owner-4nov) one card an account, the person in view's own (the household sees each, named); closed
            // ones after, as history. A book from before rows existed keeps its one card
            if let rows = p.rows {
                for r in rows where who.owns(r.owner) { out.append(ppfRowCard(r, family: who == .family)) }
                for s in p.closed ?? [] where who.owns(s.owner) { out.append(ppfShutCard(s)) }
            } else {
                out.append(ppfCard(p))
            }
        }
        if let n = b.nps { out.append(npsCard(n)) }
        let known: Set<String> = ["EPF", "PPF", "NPS"]
        for h in held where !known.contains(h.type.uppercased()) { out.append(plain(h)) }
        // (EPF read off the portal alone has no jobs: its holdings stand)
        let jobsCounted: Int = b.epf?.jobs.filter({ $0.counted }).count ?? 0
        if jobsCounted == 0 {
            for h in held where h.type.uppercased() == "EPF" { out.append(plain(h)) }
        }
        return out
    }

    static func epfCard(_ j: RetirementBook.EPF.Job, left: Bool) -> RetireCardData {
        var stats: [(String, String)] = []
        if j.employee > 0 { stats.append(("Your share", Fmt.words(j.employee))) }
        if j.employer > 0 { stats.append(("Employer’s", Fmt.words(j.employer))) }
        if j.pension > 0 { stats.append(("Pension (EPS), apart", Fmt.words(j.pension))) }
        let name: String = j.name.isEmpty ? "Member ID ••" + String(j.id.suffix(5)) : j.name
        let meta: String = left ? "You’ve left: nothing going in" : (j.asOf.map { "Passbook to " + Day.fmt($0, "d MMM yyyy") } ?? "EPFO")
        return RetireCardData(id: "epf|" + j.id, ini: "EPF", title: name, meta: meta, amt: j.amt, stats: stats, warn: left)
    }

    static func ppfCard(_ p: RetirementBook.PPF) -> RetireCardData {
        var stats: [(String, String)] = []
        stats.append(("This year", Fmt.words(p.year.paid) + " of " + Fmt.words(p.year.cap)))
        if !p.year.over { stats.append(("Room left", Fmt.words(p.year.left))) }
        let meta: String = p.asOf.map { "Statement to " + Day.fmt($0, "d MMM yyyy") } ?? "PPF"
        let bar: Double = min(1, p.year.paid / max(1, p.year.cap))
        return RetireCardData(id: "ppf", ini: "PPF", title: p.accounts > 1 ? "\(p.accounts) PPF accounts" : "PPF", meta: meta, amt: p.total,
                              stats: stats, bar: bar, warn: p.year.over, note: p.year.over ? PPFSection.limitLine(p.year) : nil)
    }

    static func ppfRowCard(_ r: RetirementBook.PPF.Row, family: Bool) -> RetireCardData {
        var stats: [(String, String)] = []
        stats.append(("This year", Fmt.words(r.year.paid) + " of " + Fmt.words(r.year.cap)))
        if !r.year.over { stats.append(("Room left", Fmt.words(r.year.left))) }
        var meta: [String] = []
        if let h = PPFWords.holder(r.holder), family || r.why != "you" { meta.append(h) }
        meta.append(r.asOf.map { "Statement to " + Day.fmt($0, "d MMM yyyy") } ?? "PPF")
        let bar: Double = min(1, r.year.paid / max(1, r.year.cap))
        return RetireCardData(id: "ppf|" + r.id, ini: "PPF", title: PPFWords.title(r.bank), meta: meta.joined(separator: " · "), amt: r.amt,
                              stats: stats, bar: bar, warn: r.year.over || r.why == "inbox",
                              note: r.why == "inbox" ? "Read as yours because it came to your inbox. Tap to check whose it is." : nil,
                              route: .ppf(r.id))
    }

    static func ppfShutCard(_ s: RetirementBook.PPF.Shut) -> RetireCardData {
        var meta: [String] = []
        if let h = PPFWords.holder(s.holder) { meta.append(h) }
        meta.append(PPFWords.shutWords(s))
        return RetireCardData(id: "ppfshut|" + s.id, ini: "PPF", title: PPFWords.title(s.bank), meta: meta.joined(separator: " · "), amt: 0,
                              stats: [], tag: "Closed", route: .ppf(s.id))
    }

    static func npsCard(_ n: RetirementBook.NPS) -> RetireCardData {
        var stats: [(String, String)] = []
        if let t = n.tier1 { stats.append(("Tier I", Fmt.words(t.amt))) }
        if let t = n.tier2 { stats.append(("Tier II", Fmt.words(t.amt))) }
        if let u = n.untiered, u > 0 { stats.append(("Not said which tier", Fmt.words(u))) }
        return RetireCardData(id: "nps", ini: "NPS", title: "NPS", meta: "National Pension System", amt: n.total, stats: stats)
    }

    static func plain(_ h: Holding) -> RetireCardData {
        let t: String = h.type.uppercased()
        let meta: String = h.asOf.map { "As of " + Day.fmt(String($0.prefix(10)), "d MMM yyyy") } ?? (h.rate > 0 ? Fmt.trim(h.rate, 2) + "% a year" : "")
        return RetireCardData(id: "h|" + h.id, ini: t.isEmpty ? "₹" : String(t.prefix(3)), title: HoldingName.pretty(h.bank), meta: meta, amt: h.amt, stats: [])
    }
}

struct RetireCardData: Identifiable {
    let id: String
    let ini: String
    let title: String
    let meta: String
    let amt: Double
    let stats: [(String, String)]
    var bar: Double? = nil
    var warn: Bool = false
    var note: String? = nil
    /// (ppf-owner-4nov) words in place of the figure ("Closed"), and the page it opens
    var tag: String? = nil
    var route: Route? = nil
}

struct RetireCard: View {
    let c: RetireCardData
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .center, spacing: 12) {
                Text(c.ini)
                    .font(.system(size: 12, weight: .heavy))
                    .foregroundStyle(Obsidian.property)
                    .frame(width: 40, height: 40)
                    .background(RoundedRectangle(cornerRadius: 12, style: .continuous).fill(Obsidian.property.opacity(0.12)))
                VStack(alignment: .leading, spacing: 2) {
                    Text(c.title).font(.subheadline.weight(.semibold)).foregroundStyle(Obsidian.ink)
                        .fixedSize(horizontal: false, vertical: true)
                    if !c.meta.isEmpty {
                        Text(c.meta).font(.caption).foregroundStyle(c.warn ? Obsidian.motor : Obsidian.ink3)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                }
                Spacer(minLength: 6)
                if let t = c.tag {
                    Text(t).font(.subheadline.weight(.semibold)).foregroundStyle(Obsidian.ink3).fixedSize()
                } else {
                    Text(Fmt.words(c.amt)).font(.headline).monospacedDigit().foregroundStyle(Obsidian.ink).privacySensitive()
                        .fixedSize()
                }
                if c.route != nil {
                    Image(systemName: "chevron.right").font(.system(size: 12, weight: .semibold)).foregroundStyle(Obsidian.ink3)
                }
            }
            if let b = c.bar {
                GeometryReader { geo in
                    Capsule().fill(c.warn ? Obsidian.motor : Obsidian.property).frame(width: max(4, geo.size.width * CGFloat(b)))
                }
                .frame(height: 6)
                .background(Capsule().fill(Color(hex: "#1C1C22")))
            }
            if !c.stats.isEmpty {
                RetireStats(stats: c.stats)
            }
            if let n = c.note {
                Text(n).font(.caption).foregroundStyle(Obsidian.motor).fixedSize(horizontal: false, vertical: true)
            }
        }
        .obsidianCard(22, padding: 16)
        .accessibilityElement(children: .combine)
    }
}

/// a card's figures: side by side, or one under another when the words are large
struct RetireStats: View {
    let stats: [(String, String)]
    var body: some View {
        ViewThatFits(in: .horizontal) {
            HStack(alignment: .top, spacing: 8) { cells }
            VStack(alignment: .leading, spacing: 8) { cells }
        }
    }
    var cells: some View {
        ForEach(stats.indices, id: \.self) { (i: Int) in
            VStack(alignment: .leading, spacing: 2) {
                Text(stats[i].0).font(.caption2).foregroundStyle(Obsidian.ink3)
                Text(stats[i].1).font(.subheadline.weight(.bold)).monospacedDigit().foregroundStyle(Obsidian.ink).privacySensitive()
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
    }
}
