import SwiftUI

// MARK: - Settings: one calm list, most-used first
//
// You and your family, then Mail and papers (statements first: it's what most often needs you), then Privacy and
// reminders, then how kosh looks and counts, then Help and diagnostics, where every beta and diagnostic tool lives.
// Each row says where it stands on the right; a row that needs you says so in an orange capsule. Search finds a row
// by what it holds ("CRN", "erase", "Face ID"). The map of every row is in ios/native/SETTINGS.md.

/// one row of Settings' first page: what it is, its tile, and the words search finds it by
enum SettingsPage: String, CaseIterable, Identifiable {
    case family, details, statements, mail, sms, reading, privacy, reminders, look, counting, ask, help
    var id: String { rawValue }

    var title: String {
        switch self {
        case .family: return "You and your family"
        case .details: return "Your details"
        case .statements: return "Statements and papers"
        case .mail: return "Mail"
        case .sms: return "Payments by SMS"
        case .reading: return "Reading"
        case .privacy: return "Privacy and security"
        case .reminders: return "Reminders and briefings"
        case .look: return "Look"
        case .counting: return "How kosh counts"
        case .ask: return "Ask kosh"
        case .help: return "Help and diagnostics"
        }
    }
    var sym: String {
        switch self {
        case .family: return "person.2.fill"
        case .details: return "person.text.rectangle.fill"
        case .statements: return "doc.text.fill"
        case .mail: return "envelope.fill"
        case .sms: return "message.fill"
        case .reading: return "text.magnifyingglass"
        case .privacy: return "lock.fill"
        case .reminders: return "bell.badge.fill"
        case .look: return "paintpalette.fill"
        case .counting: return "plusminus.circle.fill"
        case .ask: return "sparkles"
        case .help: return "lifepreserver.fill"
        }
    }
    var color: Color {
        switch self {
        case .family: return Color.kosh
        case .details: return Color(hex: "#5E5CE6")
        case .statements: return Color(hex: "#FF9500")
        case .mail: return Color(hex: "#007AFF")
        case .sms: return Color(hex: "#34C759")
        case .reading: return Color(hex: "#30B0C7")
        case .privacy: return Color(hex: "#34C759")
        case .reminders: return Color(hex: "#FF3B30")
        case .look: return Color(hex: "#AF52DE")
        case .counting: return Color(hex: "#5E5CE6")
        case .ask: return Color.kosh
        case .help: return Color(hex: "#8E8E93")
        }
    }
    var sub: String {
        switch self {
        case .family: return "Everyone’s banks, cards and policies"
        case .details: return "Customer IDs, account numbers, folios"
        case .statements: return "Each bank’s papers, and what the locked ones need"
        case .mail: return "Your inboxes, and reading them again"
        case .sms: return "Bank SMS and UPI alerts, on this phone"
        case .reading: return "What reads the mail the rules can’t"
        case .privacy: return "Face ID, hide amounts, what kosh knows, erase"
        case .reminders: return "Bills due, goals, the morning brief"
        case .look: return "Colours, tab bar, what kosh calls you"
        case .counting: return "Wallets, gift cards, chapters"
        case .ask: return "Who answers, and what it sees"
        case .help: return "Notes, the reading check, exports"
        }
    }
    /// more words a search finds the row by, beyond its title and line
    var words: String {
        switch self {
        case .family: return "household people spouse parents person add remove"
        case .details: return "customer id crn account number folio policy number pan ifsc"
        case .statements: return "statements papers pdf locked password unlock crn customer id pan date of birth dob cas policy payslip tax files add couldn't read missing checked held back"
        case .mail: return "gmail outlook inbox sign in sign out read new mail google"
        case .sms: return "sms shortcut alerts upi messages otp"
        case .reading: return "smart reading ai apple intelligence reader api key ledger start months"
        case .privacy: return "face id lock hide amounts widgets icons what kosh knows export payments file erase delete"
        case .reminders: return "notifications bills due morning briefing sunday digest goals salary split subscriptions budgets"
        case .look: return "appearance dark light accent colour color theme tab bar name nickname upi id shimmer"
        case .counting: return "wallet gift card prepaid chapters trips events monthly spending"
        case .ask: return "ai key anthropic model learned sealed emails stored service plus"
        case .help: return "beta feedback notes diagnostics export reading check intro walkthrough client id microsoft google slow taps training"
        }
    }
    func matches(_ q: String) -> Bool {
        let hay: String = (title + " " + sub + " " + words).lowercased()
        let parts: [Substring] = q.lowercased().split(separator: " ")
        return !parts.isEmpty && parts.allSatisfy { hay.contains($0) }
    }
}

struct SettingsView: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss

    let white = Color(uiColor: .systemBackground)
    @AppStorage("kosh.icons") private var icons = true
    /// the name Home says hello with: a first name or a nickname
    @AppStorage("home.callName") private var callName = ""
    @State private var query: String = ""
    @Environment(\.dynamicTypeSize) private var type

    /// close Settings first: the walkthrough is presented from the app itself
    func show(_ s: Showcase) {
        dismiss()
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { store.showcase = s }
    }

    var body: some View {
        @Bindable var store = store
        NavigationStack {
            List {
                if let live = store.live {
                    if query.trimmingCharacters(in: .whitespaces).isEmpty {
                        // the head: today, then the word and how fresh the mail is; then the two that most often need
                        // you, as tiles (mail and statements open from here only: nothing opens from two places)
                        Section {
                            SettingsHero(over: Day.fmt(store.snap.today, "EEEE, d MMMM"), title: "Settings", muted: heroLine(live))
                            tiles(live)
                        }
                        Section {
                            NavigationLink { destination(.family) } label: { profile }
                            row(.details, live)
                        }
                        Section {
                            row(.sms, live)
                            row(.reading, live)
                        } header: { SettingsHeader("Mail and papers") }
                        Section {
                            row(.privacy, live)
                            row(.reminders, live)
                        } header: { SettingsHeader("Privacy and reminders") }
                        Section {
                            row(.look, live)
                            row(.counting, live)
                            row(.ask, live)
                        } header: { SettingsHeader("Your kosh") }
                        Section {
                            row(.help, live)
                        }
                        SetupAgainRow()
                    } else {
                        let hits: [SettingsPage] = SettingsPage.allCases.filter { $0.matches(query) }
                        if hits.isEmpty {
                            ContentUnavailableView.search(text: query)
                                .listRowBackground(Color.clear)
                        } else {
                            Section {
                                ForEach(hits) { (p: SettingsPage) in row(p, live) }
                            }
                        }
                    }
                } else {
                    // test mode: the sample household and the walkthroughs
                    Section {
                        NavigationLink { PeopleList() } label: { Label("Household", systemImage: "person.2.fill") }
                        NavigationLink { AppearanceSettings() } label: { Label("Appearance", systemImage: "paintpalette.fill") }
                        NavigationLink { TabBarEditor() } label: { Label("Tab bar", systemImage: "dock.rectangle") }
                        Toggle("Hide amounts", isOn: $store.hidden)
                    }
                    Section {
                        if Snapshot.hasDemo {
                            Toggle(isOn: Binding(get: { store.demo }, set: { store.setDemo($0) })) { Label("Sample data", systemImage: "theatermasks.fill") }
                        }
                        Button { show(.intro) } label: { Label("Play the intro", systemImage: "sparkles.rectangle.stack") }
                        Button { show(.cards) } label: { Label("Show the privacy cards", systemImage: "rectangle.on.rectangle.angled") }
                        Button { show(.setup) } label: { Label("Walk through the setup", systemImage: "sparkles") }
                    } header: { Text("Show kosh to someone") }
                    Section {
                        Button("Clear what I added on this phone", role: .destructive) { store.captures = []; store.userOwed = []; store.settledIDs = []; store.live?.rebuildSoon() }
                    }
                    SetupAgainRow()
                }
                if query.isEmpty {
                    Section {} footer: {
                        Text(store.live != nil ? "kosh beta · \(Day.fmt(store.snap.today, "d MMMM yyyy"))" : "kosh test mode · snapshot of \(Day.fmt(store.snap.today, "d MMMM yyyy"))")
                            .frame(maxWidth: .infinity).multilineTextAlignment(.center)
                    }
                }
            }
            .settingsPage("Settings")
            .animation(Motion.open, value: store.demo)
            .animation(Motion.base, value: query.isEmpty)
            .toolbar {
                // (the head says "Settings" in the page itself; the bar keeps the name for the pages' back buttons)
                if store.live != nil && query.isEmpty { ToolbarItem(placement: .principal) { Color.clear.frame(width: 1, height: 1) } }
            }
            .modifier(SettingsSearch(on: store.live != nil, query: $query))
            .toolbar {
                ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } }
            }
        }
    }

    /// the muted phrase beside "Settings": how fresh the mail is
    func heroLine(_ live: LiveSession) -> String {
        if live.allAccounts.isEmpty { return "no mail yet" }
        if !live.signedIn { return "mail needs you" }
        let w: String = MailSettings.when(live.lastScan)
        return w.isEmpty ? "" : "mail read " + w
    }

    /// Mail and Statements as two tiles: tinted only when they carry a state
    @ViewBuilder func tiles(_ live: LiveSession) -> some View {
        let n: Int = live.allAccounts.count
        let locked: Int = live.lockedDocs.count
        let mailNeeds: Bool = n == 0 || !live.signedIn
        let read: String = MailSettings.when(live.lastScan)
        let mail = SettingsStatusTile(label: "Mail", figure: String(n), unit: n == 1 ? "inbox" : "inboxes",
                                      word: n == 0 ? "Connect one" : !live.signedIn ? "Reconnect" : read.isEmpty ? "Connected" : "Read " + read,
                                      mood: mailNeeds ? .needs : .fine)
        let papers = SettingsStatusTile(label: "Statements", figure: locked > 0 ? String(locked) : String(live.docCount),
                                        unit: locked > 0 ? "locked" : "papers",
                                        word: locked > 0 ? "Need a detail" : live.docCount > 0 ? "All open" : "None yet",
                                        mood: locked > 0 ? .needs : live.docCount > 0 ? .fine : .calm)
        let layout: AnyLayout = type.isAccessibilitySize ? AnyLayout(VStackLayout(spacing: 12)) : AnyLayout(HStackLayout(spacing: 12))
        layout {
            NavigationLink { destination(.mail) } label: { mail }.buttonStyle(.press)
                .accessibilityLabel("Mail, \(n) " + (n == 1 ? "inbox" : "inboxes"))
            NavigationLink { destination(.statements) } label: { papers }.buttonStyle(.press)
                .accessibilityLabel(locked > 0 ? "Statements, \(locked) locked" : "Statements")
        }
        .listRowBackground(Color.clear)
        .listRowSeparator(.hidden)
        .listRowInsets(EdgeInsets(top: 6, leading: 0, bottom: 6, trailing: 0))
    }

    /// the household's card at the top, as iOS puts your Apple Account there
    var profile: some View {
        HStack(spacing: 14) {
            Avatar(name: store.snap.people.first?.full ?? store.snap.name, color: Color.koshFill, size: 56, ink: Color.onKosh)
            VStack(alignment: .leading, spacing: 2) {
                Text("You and your family").font(.title3.weight(.semibold))
                    .fixedSize(horizontal: false, vertical: true)
                Text(store.snap.people.count <= 1 ? "Just you" : "Household of " + Words.number(store.snap.people.count))
                    .font(SettingsType.caption).foregroundStyle(.secondary)
            }
        }
        .padding(.vertical, 8)
    }

    func row(_ p: SettingsPage, _ live: LiveSession) -> some View {
        let v: (text: String, alert: Bool) = value(p, live)
        return NavigationLink { destination(p) } label: {
            SettingsRow(symbol: p.sym, color: p.color, title: p.title, value: v.text, alert: v.alert)
        }
    }

    /// where each row stands, for its right side; alert when it needs you
    func value(_ p: SettingsPage, _ live: LiveSession) -> (text: String, alert: Bool) {
        switch p {
        case .family: return (store.snap.people.count <= 1 ? "Just you" : Words.number(store.snap.people.count) + " people", false)
        case .details: return (Self.detailsCount(store), false)
        case .statements:
            let n: Int = live.lockedDocs.count
            if n > 0 { return ("\(n) locked", true) }
            return (live.docCount > 0 ? "All open" : "", false)
        case .mail:
            // (every inbox kosh holds, Gmail or not; the first one's key gone says so, the rest still count)
            let n: Int = live.allAccounts.count
            if n == 0 { return ("Not connected", true) }
            if !live.signedIn { return ("Reconnect", true) }
            return (n == 1 ? "1 inbox" : "\(n) inboxes", false)
        case .sms: return (AlertSetup.on ? "On" : "Off", false)
        case .reading: return (live.aiName, false)
        case .privacy: return (AppLock.shared.on ? "Face ID" : "", false)
        case .reminders: return (Reminders.on ? "On" : "Off", false)
        case .look: return (Look.shared.scheme == .system ? "Auto" : Look.shared.scheme.title, false)
        case .counting: return (live.countPrepaid ? "When loaded" : "When spent", false)
        case .ask: return (KoshAgent.brainName, false)
        case .help:
            let n: Int = FeedbackBook.shared.notes.count
            return (n == 0 ? "" : n == 1 ? "1 note" : "\(n) notes", false)
        }
    }

    @ViewBuilder func destination(_ p: SettingsPage) -> some View {
        switch p {
        case .family: FamilySettings()
        case .details: DetailsPage()
        case .statements: StatementsSettings()
        case .mail: MailSettings()
        case .sms: AlertsSetupView()
        case .reading: ReadingSettings()
        case .privacy: PrivacySettings()
        case .reminders: ReminderSettings()
        case .look: LookSettings(callName: $callName)
        case .counting: CountingSettings()
        case .ask: AgentSettings()
        case .help: BetaSettings(show: show)
        }
    }
}

/// search on the first page, only when there is a first page to search (not in test mode)
struct SettingsSearch: ViewModifier {
    let on: Bool
    @Binding var query: String
    @ViewBuilder func body(content: Content) -> some View {
        if on {
            content.searchable(text: $query, placement: .navigationBarDrawer(displayMode: .automatic), prompt: "Search settings")
        } else {
            content
        }
    }
}

/// one line of Settings, the older name for the kit's SettingsRow (SettingsKit.swift): drawn by it, so it matches
struct SettingRow: View {
    let sym: String
    let color: Color
    let title: String
    let value: String
    let sub: String
    var alert: Bool = false
    var body: some View {
        SettingsRow(symbol: sym, color: color, title: title, caption: sub, value: value, alert: alert)
    }
}

/// a small count in a tinted capsule: "3 locked", "2 new"
struct CountCapsule: View {
    let text: String
    var tint: Color = Color.orange
    var body: some View {
        Text(text)
            .font(.caption.weight(.semibold)).monospacedDigit()
            .foregroundStyle(tint)
            .padding(.horizontal, 8).padding(.vertical, 3)
            .background(tint.opacity(0.14), in: Capsule())
            .lineLimit(1)
            .fixedSize()
    }
}

extension SettingsView {
    /// how many details Your details holds, for its row ("" when none)
    static func detailsCount(_ store: Store) -> String {
        // (the book, read once after each build: never the Keychain from a row's body)
        let n: Int = store.details.count
        return n == 0 ? "" : Words.number(n)
    }
}

/// the household, in test mode
struct PeopleList: View {
    @Environment(Store.self) private var store
    var body: some View {
        List {
            ForEach(store.snap.people) { p in
                HStack(spacing: 12) {
                    Avatar(name: p.full, color: Color(hex: p.color), size: 32)
                    Text(p.full)
                    Spacer()
                    Text(p.rel).foregroundStyle(.secondary)
                }
            }
        }
        .navigationTitle("Household")
    }
}

/// the Home card that lists what's left to add, back on Home if you put it away
struct SetupAgainRow: View {
    @Environment(Store.self) private var store
    @AppStorage("kosh.setupCard.until") private var until = ""
    var body: some View {
        let left = store.setupSteps.filter { !$0.done }
        if !left.isEmpty && !until.isEmpty {
            Section {
                ForEach(left.prefix(4)) { s in
                    if s.capture == "passwords" {
                        // the locked statements, and what each needs: their own page in Settings
                        NavigationLink { StatementsSettings() } label: { Label(s.title, systemImage: "plus.circle.fill") }
                    } else {
                        Button {
                            if let c = s.capture { store.sheet = .capture(c) }
                        } label: {
                            Label(s.title, systemImage: "plus.circle.fill")
                        }
                    }
                }
                Button("Show the card on Home again") { until = "" }
            } header: {
                Text("Finish setting up")
            }
        }
    }
}


/// Ask kosh: who works the answers out, and what they see
struct AgentSettings: View {
    @State private var mode = KoshAgent.mode
    @State private var url = UserDefaults.standard.string(forKey: "agent.url") ?? ""
    @State private var pass = ""
    @State private var model = UserDefaults.standard.string(forKey: "agent.model") ?? ""
    @State private var kept = MailVault.size()
    @State private var key = ""
    @State private var hasKey = Keychain.get(AgentCloud.askKeyName) != nil
    @State private var checking = false
    @State private var keyNote: String?
    @State private var answering = KoshAgent.brainName

    var body: some View {
        Form {
            Section {
                Picker("Who answers", selection: $mode) {
                    Text("Smart answers when a key is set up").tag("auto")
                    Text("Only this phone").tag("phone")
                }
                .onChange(of: mode) { _, v in KoshAgent.mode = v; answering = KoshAgent.brainName }
                LabeledContent("Answering now", value: answering)
            } footer: {
                Text("Smart answers see only what kosh looks up for each question: totals, dates, merchant and payee names. Never an email, a statement or an account number. On this phone, nothing is sent anywhere.")
            }
            Section {
                SecureField(hasKey ? "Key saved · paste a new one to replace it" : "sk-ant-…", text: $key)
                    .textInputAutocapitalization(.never).autocorrectionDisabled()
                Picker("Model", selection: Binding(get: { model.isEmpty ? AgentCloud.defaultModel : model }, set: { model = $0; UserDefaults.standard.set($0, forKey: "agent.model") })) {
                    ForEach(AgentCloud.models) { m in Text(m.name).tag(m.id) }
                }
                Button {
                    Task { await saveKey() }
                } label: {
                    HStack { if checking { ProgressView() }; Text(key.isEmpty ? "Check the saved key" : "Check and save") }
                }
                .disabled(checking || (key.isEmpty && !hasKey))
                if let keyNote { Text(keyNote).font(.footnote).foregroundStyle(keyNote.hasPrefix("Saved") || keyNote.hasPrefix("Works") ? Color.green : Color.orange) }
                if hasKey {
                    Button("Remove the key", role: .destructive) {
                        Keychain.set(nil, for: AgentCloud.askKeyName); hasKey = false; keyNote = nil; answering = KoshAgent.brainName
                    }
                }
                Toggle("Name unknown payments with AI", isOn: Binding(get: { UserDefaults.standard.object(forKey: "agent.nameUnknown") as? Bool ?? true },
                                                                          set: { UserDefaults.standard.set($0, forKey: "agent.nameUnknown") }))
                NavigationLink { LearnedView() } label: { Label("What kosh has learned", systemImage: "brain") }
            } header: { SettingsHeader("Your AI key") } footer: {
                Text("Makes Ask kosh smarter: it looks things up in your ledger as many times as a question needs and checks every figure, and writes a short brief each day. Naming unknown payments sends only the payee’s name, the amount, the day and how it was paid, and files only the ones the AI is sure of. The key stays in this phone’s Keychain; questions go straight to Anthropic, the AI’s maker, billed to your key. Get a key from Anthropic’s console: console.anthropic.com.")
            }
            Section {
                TextField("https://…", text: $url).keyboardType(.URL).textInputAutocapitalization(.never).autocorrectionDisabled()
                    .onSubmit { UserDefaults.standard.set(url.trimmingCharacters(in: .whitespaces), forKey: "agent.url") }
                SecureField(Keychain.get("agent.pass") == nil ? "Invite pass" : "Pass saved", text: $pass)
                    .onSubmit { Keychain.set(pass.isEmpty ? nil : pass, for: "agent.pass"); pass = "" }
                TextField("Model (empty for the default)", text: $model).textInputAutocapitalization(.never).autocorrectionDisabled()
                    .onSubmit { UserDefaults.standard.set(model.trimmingCharacters(in: .whitespaces), forKey: "agent.model") }
                Button("Save") {
                    UserDefaults.standard.set(url.trimmingCharacters(in: .whitespaces), forKey: "agent.url")
                    if !pass.isEmpty { Keychain.set(pass, for: "agent.pass"); pass = "" }
                    UserDefaults.standard.set(model.trimmingCharacters(in: .whitespaces), forKey: "agent.model")
                }
            } header: { SettingsHeader("kosh service (Plus)") } footer: {
                Text("Without it, kosh uses your own AI key above.")
            }
            Section {
                LabeledContent("Emails stored", value: "\(kept.count)")
                LabeledContent("Space", value: ByteCountFormatter.string(fromByteCount: Int64(kept.bytes), countStyle: .file))
            } header: { SettingsHeader("Sealed on this phone") } footer: {
                Text("Every email kosh read and every statement it opened, sealed with a key only this phone has. New rules read them again from here instead of your inbox. Erase, in Settings › Privacy and security, removes them and the key.")
            }
        }
        .settingsPage("Ask kosh")
        .onAppear { kept = MailVault.size(); answering = KoshAgent.brainName }
    }

    @MainActor
    func saveKey() async {
        checking = true
        defer { checking = false }
        let k = key.trimmingCharacters(in: .whitespacesAndNewlines)
        let use = k.isEmpty ? (Keychain.get(AgentCloud.askKeyName) ?? "") : k
        guard !use.isEmpty else { return }
        if let problem = await AgentCloud.check(key: use, model: model.isEmpty ? AgentCloud.defaultModel : model) {
            keyNote = problem
            return
        }
        if !k.isEmpty { Keychain.set(k, for: AgentCloud.askKeyName); key = ""; hasKey = true; keyNote = "Saved. Ask kosh now gives smart answers." }
        else { keyNote = "Works." }
        answering = KoshAgent.brainName
    }
}

// MARK: - The groups' pages

/// Privacy and security: the lock, hiding amounts, what kosh knows, and erasing it
struct PrivacySettings: View {
    @Environment(Store.self) private var store
    @AppStorage("kosh.icons") private var icons = true
    var body: some View {
        @Bindable var store = store
        List {
            GuardSettings()
            Section {
                Toggle(isOn: $store.hidden) { SettingsRow(symbol: "eye.slash.fill", color: Color(hex: "#5E5CE6"), title: "Hide amounts") }
                if store.live != nil { WidgetAmountsToggle() }
                Toggle(isOn: $icons) { SettingsRow(symbol: "building.columns.fill", color: Color(hex: "#30B0C7"), title: "Bank and insurer icons") }
            } header: { SettingsHeader("On screen") } footer: {
                Text("Icons come from each bank’s own website; off, kosh shows initials. Lock Screen widgets stay hidden until you unlock.")
            }
            if store.live != nil {
                Section {
                    NavigationLink { YourDataView() } label: { SettingsRow(symbol: "lock.doc.fill", color: Color(hex: "#34C759"), title: "What kosh knows") }
                    NavigationLink { LedgerExportView() } label: { SettingsRow(symbol: "square.and.arrow.up.fill", color: Color(hex: "#007AFF"), title: "Your payments, as a file") }
                } header: { SettingsHeader("Your data") }
                EraseSection()
            }
        }
        .settingsPage("Privacy and security")
    }
}

/// Reminders and briefings: bills due, the plan's nudges, the morning brief and Sunday's digest
struct ReminderSettings: View {
    var body: some View {
        List {
            PlanSettingsRows()
            BriefSettingsRows()
        }
        .settingsPage("Reminders and briefings")
    }
}

/// How kosh counts: wallets and gift cards, and chapters in a month's spending
struct CountingSettings: View {
    @Environment(Store.self) private var store
    var body: some View {
        List {
            if let live = store.live {
                Section {
                    Picker(selection: Binding(get: { live.countPrepaid }, set: { live.countPrepaid = $0 })) {
                        Text("When spent").tag(false)
                        Text("When loaded").tag(true)
                    } label: {
                        SettingsRow(symbol: "giftcard.fill", color: Color(hex: "#FF9500"), title: "Wallets and gift cards")
                    }
                    Toggle(isOn: Binding(get: { !live.everyday }, set: { live.everyday = !$0 })) {
                        SettingsRow(symbol: "airplane", color: Color(hex: "#007AFF"), title: "Trips and events in monthly spending")
                    }
                } footer: {
                    Text("Money loaded onto a wallet or gift card counts once: when spent, or when loaded. Leaving trips out keeps months comparable; balances still have them.")
                }
            }
        }
        .settingsPage("How kosh counts")
    }
}

/// Look: the colours, the tab bar, and what kosh calls you (Ask kosh, the intro and the beta moved to their own rows)
struct LookSettings: View {
    @Environment(Store.self) private var store
    @Binding var callName: String
    var body: some View {
        @Bindable var store = store
        List {
            Section {
                NavigationLink { AppearanceSettings() } label: {
                    SettingsRow(symbol: "paintpalette.fill", color: Color(hex: "#AF52DE"), title: "Appearance",
                                caption: Look.shared.accent.spoken,
                                value: Look.shared.scheme == .system ? "Auto" : Look.shared.scheme.title)
                }
                NavigationLink { TabBarEditor() } label: {
                    SettingsRow(symbol: "dock.rectangle", color: Color(hex: "#007AFF"), title: "Tab bar", value: String(store.tabs.count) + " tabs")
                }
            }
            Section {
                LabeledContent {
                    TextField("A first name", text: $callName)
                        .multilineTextAlignment(.trailing)
                        .textContentType(.nickname)
                        .submitLabel(.done)
                } label: { Text("Call me") }
                LabeledContent {
                    TextField("name@bank", text: $store.upi)
                        .multilineTextAlignment(.trailing)
                        .textInputAutocapitalization(.never).autocorrectionDisabled().keyboardType(.emailAddress)
                } label: { Text("UPI ID") }
            } header: { SettingsHeader("You") } footer: {
                Text("Your UPI ID goes into the reminders you send, so people can pay you back in one tap.")
            }
        }
        .settingsPage("Look")
    }
}

/// You and your family: everyone in the household, each with a page of everything that's theirs
struct FamilySettings: View {
    @Environment(Store.self) private var store
    var body: some View {
        List {
            Section {
                ForEach(store.snap.people) { p in
                    NavigationLink { PersonPage(person: p) } label: {
                        HStack(spacing: 12) {
                            Avatar(name: p.full.isEmpty ? p.name : p.full, color: Color(hex: p.color), size: 40)
                            VStack(alignment: .leading, spacing: 2) {
                                Text(p.full.isEmpty ? p.name : p.full).font(SettingsType.title)
                                Text(PersonPage.summary(store, p)).font(SettingsType.caption).foregroundStyle(.secondary)
                                    .fixedSize(horizontal: false, vertical: true)
                            }
                        }
                        .frame(minHeight: 52)
                    }
                }
            } header: { SettingsHeader("Household") }
            Section {
                NavigationLink {
                    ScrollView { HouseholdEditor().padding(20) }.navigationTitle("Household").onDisappear { store.live?.rebuild() }
                } label: { SettingsRow(symbol: "person.2.fill", color: Color.koshFill, title: "Add or change people") }
            } footer: {
                Text("Each person’s IDs are in Your details.")
            }
        }
        .settingsPage("You and your family")
    }
}

/// One person's page: their banks with the account's last four and Customer ID, cards, policies and details.
/// What kosh found in the mail says so; it asks only for what's still missing.
struct PersonPage: View {
    @Environment(Store.self) private var store
    let person: PersonInfo
    @State private var typed: PasswordProfile? = nil
    @State private var found: PasswordProfile = PasswordProfile()

    static func summary(_ store: Store, _ p: PersonInfo) -> String {
        let s = store.snap
        let a: Int = s.accounts.filter { $0.owner == p.id }.count + s.wallets.filter { $0.owner == p.id }.count
        let c: Int = s.cards.filter { $0.owner == p.id }.count
        let pol: Int = s.policies.filter { $0.owner == p.id && !$0.isEnded }.count
        var parts: [String] = []
        if a > 0 { parts.append("\(a) account\(a == 1 ? "" : "s")") }
        if c > 0 { parts.append("\(c) card\(c == 1 ? "" : "s")") }
        if pol > 0 { parts.append("\(pol) polic\(pol == 1 ? "y" : "ies")") }
        return parts.isEmpty ? p.rel : parts.joined(separator: ", ")
    }

    /// a number shown by its last four only
    static func masked(_ v: String) -> String { v.count <= 4 ? v : "••" + String(v.suffix(4)) }

    var body: some View {
        let s = store.snap
        let accounts: [Account] = s.accounts.filter { $0.owner == person.id } + s.wallets.filter { $0.owner == person.id }
        let cards: [CardInfo] = s.cards.filter { $0.owner == person.id }
        let policies: [Policy] = s.policies.filter { $0.owner == person.id && !$0.isEnded }
        let have: PasswordProfile = (typed ?? PasswordProfile()).filledWith(found)
        List {
            Section {
                HStack(spacing: 14) {
                    Avatar(name: person.full.isEmpty ? person.name : person.full, color: Color(hex: person.color), size: 56)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(person.full.isEmpty ? person.name : person.full).font(.title3.weight(.semibold))
                        Text(person.rel).font(.subheadline).foregroundStyle(.secondary)
                    }
                }
                .padding(.vertical, 4)
            }
            if !accounts.isEmpty {
                Section("Banks") {
                    ForEach(accounts) { a in
                        HStack(spacing: 12) {
                            InstIcon(name: a.bank, color: Color(hex: a.color), size: 30)
                            VStack(alignment: .leading, spacing: 1) {
                                Text(a.name.isEmpty ? a.bank : a.name).lineLimit(1)
                                Text(a.last.isEmpty ? a.bank : a.bank + " ••" + a.last).font(.caption).foregroundStyle(.secondary)
                            }
                            Spacer(minLength: 8)
                            if let b = a.balance { Text(Fmt.rupees(b)).font(.subheadline).foregroundStyle(.secondary).privacySensitive() }
                        }
                    }
                }
            }
            if !have.ids.isEmpty {
                Section {
                    ForEach(have.ids.keys.sorted(), id: \.self) { dom in
                        let mine: Bool = typed?.ids[dom] != nil
                        LabeledContent {
                            VStack(alignment: .trailing, spacing: 1) {
                                Text(Self.masked(have.ids[dom] ?? "")).monospacedDigit().privacySensitive()
                                Text(mine ? "Added by you" : "From your mail").font(SettingsType.caption).foregroundStyle(.secondary)
                            }
                        } label: { Text(Self.bankOf(dom)) }
                    }
                } header: { Text("Customer IDs") } footer: {
                    Text("Banks lock statements with these. kosh found them in the mail; it uses them only to open statements, on this phone.")
                }
            }
            if !cards.isEmpty {
                Section("Cards") {
                    ForEach(cards) { c in
                        HStack(spacing: 12) {
                            InstIcon(name: c.bank, color: Color(hex: c.color), size: 30)
                            VStack(alignment: .leading, spacing: 1) {
                                Text(c.product ?? c.name).lineLimit(1)
                                Text(c.bank + (c.last.isEmpty ? "" : " ••" + c.last)).font(.caption).foregroundStyle(.secondary)
                            }
                        }
                    }
                }
            }
            if !policies.isEmpty {
                Section("Insurance") {
                    ForEach(policies) { p in
                        HStack(spacing: 12) {
                            InstIcon(name: p.insurer, color: Color(hex: "#30B0C7"), size: 30)
                            VStack(alignment: .leading, spacing: 1) {
                                Text(p.plan ?? (p.insurer + " " + p.type)).lineLimit(1)
                                Text(p.type + (p.cover.map { " · cover " + Fmt.words($0) } ?? "")).font(.caption).foregroundStyle(.secondary)
                            }
                        }
                    }
                }
            }
            Section {
                LabeledContent("Date of birth", value: have.dob.isEmpty ? "Missing" : Day.fmt(have.dob, "d MMM yyyy"))
                LabeledContent("PAN") { Text(have.pan.isEmpty ? "Missing" : Self.masked(have.pan)).monospacedDigit() }
                NavigationLink {
                    PasswordProfileSheet(inSheet: false, person: person.id, personName: person.full.isEmpty ? person.name : person.full, inHousehold: true)
                        .onDisappear { load() }
                } label: { Label(have.dob.isEmpty || have.pan.isEmpty ? "Add what’s missing" : "Change details", systemImage: "square.and.pencil") }
                NavigationLink { DetailsPage(person: person.id) } label: { Label("Every ID and number kosh found", systemImage: "person.text.rectangle") }
            } header: { Text("Details") } footer: {
                Text("Kept in this phone’s Keychain, used only to open this person’s statements. Never sent anywhere.")
            }
        }
        .settingsPage(person.name)
        .onAppear { load() }
    }

    func load() {
        typed = PasswordProfile.load(for: person.id)
        found = PasswordProfile.harvested()[person.id] ?? PasswordProfile()
    }

    /// a bank's name from the domain its mail comes from ("axisbank.com" → Axis Bank), else the domain
    static func bankOf(_ dom: String) -> String {
        let d = dom.lowercased()
        let names: [(String, String)] = [("axis", "Axis Bank"), ("kotak", "Kotak"), ("hdfc", "HDFC Bank"), ("icici", "ICICI Bank"), ("sbi", "SBI"),
                                         ("yes", "Yes Bank"), ("idfc", "IDFC First"), ("indusind", "IndusInd"), ("federal", "Federal Bank"),
                                         ("au", "AU Bank"), ("rbl", "RBL Bank"), ("bob", "Bank of Baroda"), ("pnb", "PNB"), ("canara", "Canara Bank")]
        return names.first { d.hasPrefix($0.0) || d.contains("." + $0.0) }?.1 ?? dom
    }
}
