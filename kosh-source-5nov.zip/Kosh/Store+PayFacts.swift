import Foundation

// MARK: - The store: what kosh knows about each payment (PayFacts.swift; engine/21o-build-payfacts.js)
// Where it was made, what it bought, how often. Read-only lookups into the snapshot: nothing here is worked out again.

extension Store {
    /// a payment's facts; a part split out of a charge reads its charge's
    func payFact(_ t: Txn) -> PayFacts.Fact? {
        guard let p = snap.payFacts else { return nil }
        return p.pay[t.id] ?? t.partOf.flatMap { p.pay[$0] }
    }
    /// the shop a payment was made at, one however it's named
    func payShop(_ t: Txn) -> PayFacts.Shop? { snap.payFacts?.shop(payFact(t)?.sh) }
    /// how often that shop is paid: its beat, next day and usual sum
    func payRhythm(_ t: Txn) -> PayFacts.Rhythm? { snap.payFacts?.rhythm(payFact(t)?.rh) }
    /// shops and items on a beat whose next day falls between two days (yyyy-mm-dd, both included), soonest first
    func rhythmsDue(from: String, to: String) -> [PayFacts.Rhythm] {
        (snap.payFacts?.rhythms ?? []).filter { r in r.quiet != true && (r.next.map { $0 >= from && $0 <= to } ?? false) }
            .sorted { ($0.next ?? "") < ($1.next ?? "") }
    }
}
