import Foundation

// MARK: - Gmail's allowance, kept to
//
// Google lets one Cloud project spend 6,000 quota units a minute on each inbox (a project made on or after 1 May 2026;
// https://developers.google.com/workspace/gmail/api/reference/quota). What a request costs depends on the call: reading
// a whole email (messages.get, format=full, which every read of kosh's is) costs 60, its headers only 20, an attachment
// 20, a page of a search 5, the history check 2, the profile 1. So an inbox gives about 100 whole emails a minute, and
// going faster reads nothing faster: Google answers "too many" (429, or 403 rateLimitExceeded / userRateLimitExceeded)
// and every request waits. Each inbox has a bucket that refills at its pace: it starts under the allowance, edges up
// while Google keeps saying yes and kosh is waiting on it, never past the ceiling (no sixty seconds can spend more than
// the allowance, a full bucket included), and steps down, pausing longer each time, the moment Google says no. Two
// inboxes are two allowances, read side by side. A request Google turned away is asked again, never dropped
// (LiveSession.fetchSome keeps it on the list).
//
// The arithmetic is QuotaPace (QuotaPace.swift), on a clock it is handed: engine-test/gmail-pace.swift runs it on
// made-up hours with swiftc on the Mac, and engine-test/gmail-pace.js checks the costs and the ceiling against Google's
// table.

enum QuotaGate {
    /// the inbox the Gmail requests on this task are for: set around a read, inherited by its child tasks
    @TaskLocal static var inbox: String = ""
    /// every inbox's bucket
    static let shared = QuotaBuckets()
    /// Google's allowance for one inbox, units a minute. A project Google kept on the allowance it had before 1 May 2026
    /// may say so in the bundled beta.json ("gmailUnitsPerMinute", read off its quota page in the Cloud console)
    static let limit: Double = QuotaPace.limit(bundled: QuotaGate.bundledLimit())
    static var ceiling: Double { QuotaPace.ceiling(limit) }
    static var start: Double { QuotaPace.start(limit) }
    static let floor: Double = QuotaPace.floor

    /// what one request costs, by the Gmail path it goes to
    static func cost(_ path: String) -> Double { QuotaPace.cost(path) }

    private static func bundledLimit() -> Double? {
        guard let u = Bundle.main.url(forResource: "beta", withExtension: "json"), let d = try? Data(contentsOf: u),
              let j = (try? JSONSerialization.jsonObject(with: d)) as? [String: Any] else { return nil }
        return (j["gmailUnitsPerMinute"] as? NSNumber)?.doubleValue
    }
}

actor QuotaBuckets {
    private var buckets: [String: QuotaPace] = [:]

    private func bucket(_ k: String) -> QuotaPace {
        if let b = buckets[k] { return b }
        let saved = UserDefaults.standard.double(forKey: "quota.rate." + k)
        // (a pace kept by an older kosh may be past today's ceiling: QuotaPace brings it under)
        let b = QuotaPace(rate: saved > 0 ? saved : QuotaGate.start, now: Date(), limit: QuotaGate.limit)
        buckets[k] = b
        return b
    }

    /// wait until `units` can be spent on this inbox, then spend them
    func take(_ inbox: String, _ units: Double) async {
        let k = inbox.isEmpty ? "_" : inbox
        while !Task.isCancelled {
            var b = bucket(k)
            let r = b.take(units, now: Date())
            buckets[k] = b
            if r.stepped { UserDefaults.standard.set(b.rate, forKey: "quota.rate." + k) }
            if r.wait <= 0 { return }
            try? await Task.sleep(for: .seconds(r.wait))
        }
    }

    /// Google said too many: slow down, and wait as long as it asked
    func throttled(_ inbox: String, retryAfter: Double?) {
        let k = inbox.isEmpty ? "_" : inbox
        var b = bucket(k)
        b.throttled(retryAfter: retryAfter, now: Date())
        buckets[k] = b
        UserDefaults.standard.set(b.rate, forKey: "quota.rate." + k)
    }

    /// spent outside the bucket (the background downloads): later requests wait for it
    func spend(_ inbox: String, _ units: Double) {
        let k = inbox.isEmpty ? "_" : inbox
        var b = bucket(k)
        b.spend(units)
        buckets[k] = b
    }
}
