import SwiftUI

// MARK: - Insights in the black look (1 Nov, feat/insights-obsidian, from his screenshots)
//
// Month in review, Understanding you, Bills by home and every page behind them, drawn in the language of the Obsidian
// insurance design: a black page, near-black cards with a hairline, mono capital captions, big rounded figures, rings,
// segmented bars and coloured rails, one colour per kind. The tokens are Obsidian.swift's, read only (that file is
// shared with Insurance and Wealth); the pieces only these pages use live here. Motion is Style.swift's scale: a figure
// never bounces, a list arrives 40 ms apart, closing is quicker than opening.

/// the colours these pages use, all of them Obsidian's
enum InsightsInk {
    /// one colour a kind, biggest first: the segmented bar and its rows use the same order, so a row's rail is its segment
    static let kinds: [Color] = [Obsidian.ulip, Obsidian.health, Obsidian.savings, Obsidian.term, Obsidian.motor, Obsidian.property]
    static func kind(_ i: Int) -> Color { i >= 0 && i < kinds.count ? kinds[i] : Obsidian.ink3 }
    /// more than usual, less than usual
    static let more: Color = Obsidian.motor
    static let less: Color = Obsidian.health
    /// family, and kosh's own voice (what it noticed, a question it asks)
    static let family: Color = Obsidian.property
    static let voice: Color = Obsidian.term
    /// the empty part of a bar
    static let track: Color = Color.white.opacity(0.08)
    /// a life event's colour by its kind
    static func event(_ k: String) -> Color {
        switch k {
        case "job": return Obsidian.ulip
        case "move": return Obsidian.health
        case "family": return Obsidian.property
        default: return Obsidian.term
        }
    }
    /// a trip's part: travel · stay · food · other
    static func tripPart(_ k: String) -> Color {
        switch k {
        case "travel": return Obsidian.ulip
        case "stay": return Obsidian.term
        case "food": return Obsidian.savings
        default: return Obsidian.ink3
        }
    }
}

// MARK: the page

/// a page in the black look: black under everything, the cards spaced, a dark bar with a readable title
struct ObsScroll<Content: View>: View {
    let title: String
    var inline: Bool = true
    @ViewBuilder let content: () -> Content
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) { content() }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal, 16)
                .padding(.top, 8)
                .padding(.bottom, 36)
        }
        .scrollContentBackground(.hidden)
        .obsidianPage()
        .navigationTitle(title)
        .modifier(ObsTitleMode(inline: inline))
    }
}

/// inline for the pages behind a card; the three top pages keep the large title MonthDetail gives them
struct ObsTitleMode: ViewModifier {
    let inline: Bool
    @ViewBuilder func body(content: Content) -> some View {
        if inline { content.toolbarTitleDisplayMode(.inline) } else { content }
    }
}

/// a section's caption above its cards, with an optional figure or date on the right
struct ObsHead: View {
    let text: String
    var trailing: String = ""
    var body: some View {
        HStack(alignment: .firstTextBaseline, spacing: 8) {
            Text(text).caption()
            Spacer(minLength: 8)
            if !trailing.isEmpty { Text(trailing).caption().monospacedDigit() }
        }
        .padding(.horizontal, 4)
        .padding(.top, 12)
        .accessibilityAddTraits(.isHeader)
    }
}

/// a figure as the hero of a card: big, rounded, never wrapping, shrinking before it would clip
struct ObsFigure: View {
    let text: String
    var size: CGFloat = 44
    var color: Color = Obsidian.ink
    var body: some View {
        Text(text)
            .font(.system(size: size, weight: .semibold, design: .rounded))
            .tracking(-0.5)
            .monospacedDigit()
            .foregroundStyle(color)
            .lineLimit(1)
            .minimumScaleFactor(0.45)
            .contentTransition(.numericText())
    }
}

/// a pill: "▲ ₹4,200 over usual", in its colour on a wash of it
struct ObsPill: View {
    let text: String
    let tint: Color
    var sym: String = ""
    var body: some View {
        HStack(spacing: 5) {
            if !sym.isEmpty { Image(systemName: sym).font(.caption2.weight(.bold)) }
            Text(text).font(.footnote.weight(.semibold)).monospacedDigit().fixedSize(horizontal: false, vertical: true)
        }
        .foregroundStyle(tint)
        .padding(.horizontal, 10)
        .padding(.vertical, 5)
        .background(tint.opacity(0.14), in: Capsule())
        .overlay(Capsule().strokeBorder(tint.opacity(0.28), lineWidth: 1))
    }
}

/// a card's head: a dot in its colour, a caption, and a chevron when the card opens something
struct ObsCardHead: View {
    let title: String
    var tint: Color = Obsidian.ink3
    var trailing: String = ""
    var chevron: Bool = true
    var body: some View {
        HStack(spacing: 8) {
            Circle().fill(tint).frame(width: 6, height: 6)
            Text(title).caption()
            Spacer(minLength: 8)
            if !trailing.isEmpty { Text(trailing).caption().monospacedDigit() }
            if chevron { Image(systemName: "chevron.right").font(.caption.weight(.bold)).foregroundStyle(Obsidian.ink3) }
        }
    }
}

/// a thin bar on its track: a share of the biggest
struct ObsTrack: View {
    let share: Double
    let tint: Color
    var height: CGFloat = 4
    var body: some View {
        GeometryReader { (g: GeometryProxy) in
            ZStack(alignment: .leading) {
                Capsule().fill(InsightsInk.track)
                Capsule().fill(tint).frame(width: ObsTrack.width(share, g.size.width, height))
            }
        }
        .frame(height: height)
        .accessibilityHidden(true)
    }
    static func width(_ share: Double, _ full: CGFloat, _ least: CGFloat) -> CGFloat {
        max(least, full * CGFloat(min(1, max(0, share))))
    }
}

/// one bar cut into parts, each its colour, 2pt apart
struct ObsSegBar: View {
    struct Seg: Identifiable, Hashable {
        let id: String
        let v: Double
        let tint: Color
    }
    let segs: [Seg]
    var height: CGFloat = 12
    var body: some View {
        GeometryReader { (g: GeometryProxy) in
            HStack(spacing: 2) {
                ForEach(segs) { (s: Seg) in
                    RoundedRectangle(cornerRadius: 2, style: .continuous).fill(s.tint)
                        .frame(width: ObsSegBar.width(s, segs, g.size.width))
                }
            }
        }
        .frame(height: height)
        .clipShape(Capsule())
        .accessibilityHidden(true)
    }
    static func width(_ s: Seg, _ all: [Seg], _ full: CGFloat) -> CGFloat {
        let total: Double = all.reduce(0) { $0 + $1.v }
        guard total > 0 else { return 0 }
        let room: CGFloat = max(0, full - CGFloat(max(0, all.count - 1)) * 2)
        return max(2, room * CGFloat(s.v / total))
    }
}

/// a row of a kind: a rail in its colour, its name, its figure, a thin bar scaled to the biggest
struct ObsKindRow: View {
    let name: String
    let value: String
    let share: Double
    let tint: Color
    var sub: String = ""
    var chevron: Bool = false
    var body: some View {
        HStack(alignment: .center, spacing: 12) {
            RoundedRectangle(cornerRadius: 2, style: .continuous).fill(tint).frame(width: 4).frame(minHeight: 30)
            VStack(alignment: .leading, spacing: 7) {
                HStack(alignment: .firstTextBaseline, spacing: 8) {
                    Text(name).font(.subheadline).foregroundStyle(Obsidian.ink).lineLimit(2)
                    Spacer(minLength: 8)
                    Text(value).font(.subheadline.weight(.semibold)).monospacedDigit().foregroundStyle(Obsidian.ink).lineLimit(1).minimumScaleFactor(0.7)
                    if chevron { Image(systemName: "chevron.right").font(.caption2.weight(.bold)).foregroundStyle(Obsidian.ink3) }
                }
                if !sub.isEmpty { Text(sub).font(.caption).foregroundStyle(Obsidian.ink2).fixedSize(horizontal: false, vertical: true) }
                ObsTrack(share: share, tint: tint.opacity(0.9))
            }
        }
        .contentShape(Rectangle())
        .accessibilityElement(children: .combine)
    }
}

/// a stat tile: a caption, a figure, what it is against
struct ObsStatTile: View {
    let label: String
    let value: String
    var sub: String = ""
    var tint: Color = Obsidian.ink
    var sym: String = ""
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 6) {
                if !sym.isEmpty { Image(systemName: sym).font(.caption.weight(.semibold)).foregroundStyle(tint) }
                Text(label).caption().lineLimit(2)
            }
            Text(value)
                .font(.system(.title2, design: .rounded, weight: .semibold))
                .monospacedDigit()
                .foregroundStyle(Obsidian.ink)
                .lineLimit(2)
                .minimumScaleFactor(0.6)
                .fixedSize(horizontal: false, vertical: true)
            if !sub.isEmpty {
                Text(sub).font(.caption).foregroundStyle(Obsidian.ink2).fixedSize(horizontal: false, vertical: true)
            }
            Spacer(minLength: 0)
        }
        .frame(maxWidth: .infinity, minHeight: 112, alignment: .topLeading)
        .obsidianCard(20, padding: 14)
        .accessibilityElement(children: .combine)
    }
}

/// two columns of tiles; one column at the largest text sizes, so nothing clips
struct ObsTileGrid<Content: View>: View {
    @Environment(\.dynamicTypeSize) private var type
    @ViewBuilder let content: () -> Content
    var body: some View {
        LazyVGrid(columns: ObsTileGrid.cols(type.isAccessibilitySize), alignment: .leading, spacing: 10) { content() }
    }
    static func cols(_ big: Bool) -> [GridItem] {
        big ? [GridItem(.flexible())] : [GridItem(.flexible(), spacing: 10), GridItem(.flexible(), spacing: 10)]
    }
}

/// initials in a ring of their colour
struct ObsAvatar: View {
    let text: String
    let tint: Color
    var size: CGFloat = 38
    var body: some View {
        Text(text)
            .font(.system(size: size * 0.36, weight: .semibold, design: .rounded))
            .foregroundStyle(tint)
            .frame(width: size, height: size)
            .background(tint.opacity(0.16), in: Circle())
            .overlay(Circle().strokeBorder(tint.opacity(0.32), lineWidth: 1))
            .accessibilityHidden(true)
    }
}

/// a row that opens something: an icon, its words, a chevron
struct ObsLinkRow: View {
    let title: String
    var sub: String = ""
    var sym: String = ""
    var tint: Color = Obsidian.ink2
    var body: some View {
        HStack(alignment: .center, spacing: 12) {
            if !sym.isEmpty {
                Image(systemName: sym).font(.subheadline.weight(.semibold)).foregroundStyle(tint)
                    .frame(width: 32, height: 32).background(tint.opacity(0.14), in: RoundedRectangle(cornerRadius: 9, style: .continuous))
            }
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(.subheadline).foregroundStyle(Obsidian.ink).multilineTextAlignment(.leading).fixedSize(horizontal: false, vertical: true)
                if !sub.isEmpty { Text(sub).font(.caption).foregroundStyle(Obsidian.ink2).fixedSize(horizontal: false, vertical: true) }
            }
            Spacer(minLength: 8)
            Image(systemName: "chevron.right").font(.caption.weight(.bold)).foregroundStyle(Obsidian.ink3)
        }
        .contentShape(Rectangle())
    }
}

/// the hairline between rows in a card
struct ObsRule: View {
    var inset: CGFloat = 0
    var body: some View {
        Rectangle().fill(Obsidian.cardBorder).frame(height: 1).padding(.leading, inset)
    }
}

/// a footnote in the black look
struct ObsNote: View {
    let text: String
    var body: some View {
        Text(text).font(.footnote).foregroundStyle(Obsidian.ink3).fixedSize(horizontal: false, vertical: true)
            .padding(.horizontal, 4).padding(.top, 6)
    }
}

/// what a page says when it has nothing
struct ObsEmpty: View {
    let title: String
    let sym: String
    let text: String
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Image(systemName: sym).font(.title2).foregroundStyle(Obsidian.ink3)
            Text(title).font(.headline).foregroundStyle(Obsidian.ink)
            Text(text).font(.subheadline).foregroundStyle(Obsidian.ink2).fixedSize(horizontal: false, vertical: true)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .obsidianCard()
    }
}

// MARK: bars over months

/// a strip of month bars, the picked one lit: they grow in once, 40 ms apart, and never bounce
struct ObsBarStrip: View {
    struct Bar: Identifiable, Hashable {
        let id: String
        let label: String
        let v: Double
        let on: Bool
        /// a month still running or a part-month: drawn paler
        var faint: Bool = false
    }
    let bars: [Bar]
    var height: CGFloat = 64
    var tint: Color = Obsidian.ink
    @State private var grown: Bool = false
    @Environment(\.accessibilityReduceMotion) private var still
    var body: some View {
        let most: Double = max(1, bars.map(\.v).max() ?? 1)
        HStack(alignment: .bottom, spacing: 6) {
            ForEach(Array(bars.enumerated()), id: \.element.id) { (pair: EnumeratedSequence<[Bar]>.Element) in
                ObsBarColumn(b: pair.element, share: pair.element.v / most, height: height, tint: tint, grown: grown || still, delay: Motion.stagger(pair.offset))
            }
        }
        .onAppear { if !grown { withAnimation(Motion.reveal) { grown = true } } }
    }
}

struct ObsBarColumn: View {
    let b: ObsBarStrip.Bar
    let share: Double
    let height: CGFloat
    let tint: Color
    let grown: Bool
    let delay: Double
    var body: some View {
        VStack(spacing: 6) {
            RoundedRectangle(cornerRadius: 4, style: .continuous)
                .fill(ObsBarColumn.fill(b, tint))
                .frame(height: max(3, CGFloat(share) * height))
                .frame(maxWidth: .infinity)
                .scaleEffect(x: 1, y: grown ? 1 : 0.02, anchor: .bottom)
                .animation(Motion.reveal.delay(delay), value: grown)
            Text(b.label)
                .font(.system(size: 10, weight: b.on ? .semibold : .medium, design: .monospaced))
                .foregroundStyle(b.on ? Obsidian.ink : Obsidian.ink3)
                .lineLimit(1)
                .minimumScaleFactor(0.7)
        }
        .frame(height: height + 20, alignment: .bottom)
    }
    static func fill(_ b: ObsBarStrip.Bar, _ tint: Color) -> Color {
        if b.on { return b.faint ? tint.opacity(0.6) : tint }
        return Color.white.opacity(b.faint ? 0.1 : 0.18)
    }
}

// MARK: a list arriving in turn

/// each item comes up into place 40 ms after the one before (the eighth on with the rest); still for Reduce Motion
struct ObsArrive: ViewModifier {
    let i: Int
    @State private var seen: Bool = false
    @Environment(\.accessibilityReduceMotion) private var still
    func body(content: Content) -> some View {
        content
            .opacity(seen || still ? 1 : 0)
            .offset(y: seen || still ? 0 : 10)
            .onAppear { if !seen { withAnimation(Motion.open.delay(Motion.stagger(i))) { seen = true } } }
    }
}

extension View {
    /// arrive as item `i` of a list
    func obsArrive(_ i: Int) -> some View { modifier(ObsArrive(i: i)) }
}

// MARK: Insights' feature cards

/// a stat chip on a feature card: what it is, its figure
struct ObsChip: Identifiable, Hashable {
    let id: String
    let label: String
    let value: String
    var tint: Color = Obsidian.ink
}

struct ObsChipRow: View {
    let chips: [ObsChip]
    var body: some View {
        ViewThatFits(in: .horizontal) {
            HStack(spacing: 8) { cells }
            VStack(alignment: .leading, spacing: 8) { cells }
        }
    }
    private var cells: some View {
        ForEach(chips) { (c: ObsChip) in
            VStack(alignment: .leading, spacing: 4) {
                Text(c.label).caption().lineLimit(1)
                Text(c.value).font(.subheadline.weight(.semibold)).monospacedDigit().foregroundStyle(c.tint).lineLimit(1).minimumScaleFactor(0.7)
            }
            .padding(.horizontal, 12).padding(.vertical, 10)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous).strokeBorder(Obsidian.cardBorder, lineWidth: 1))
        }
    }
}

/// Insights' summary of a page, dark in the light tab: a caption, the title, a compact hero, two or three chips; the
/// whole card opens the page
struct ObsFeatureCard<Hero: View>: View {
    let caption: String
    let title: String
    let chips: [ObsChip]
    var hint: String = ""
    let tap: () -> Void
    @ViewBuilder let hero: () -> Hero
    var body: some View {
        Button(action: tap) {
            VStack(alignment: .leading, spacing: 14) {
                HStack(spacing: 8) {
                    Text(caption).caption()
                    Spacer(minLength: 8)
                    Image(systemName: "arrow.up.right").font(.caption.weight(.bold)).foregroundStyle(Obsidian.ink3)
                }
                Text(title).font(.title3.weight(.semibold)).foregroundStyle(Obsidian.ink)
                hero()
                if !chips.isEmpty { ObsChipRow(chips: chips) }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(18)
            .background(Obsidian.bg, in: RoundedRectangle(cornerRadius: 26, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 26, style: .continuous).strokeBorder(Color.white.opacity(0.1), lineWidth: 1))
            .contentShape(RoundedRectangle(cornerRadius: 26, style: .continuous))
        }
        .buttonStyle(.press)
        .environment(\.colorScheme, .dark)
        .accessibilityHint(hint)
    }
}
