import Foundation

// MARK: - Claude reads every money mail

/// Claude reads every money mail kosh keeps (reader.js › "Claude reads the mail"). Measured on 428 labelled mails it
/// reads 97% of them right; the rules and the on-phone reader read 69%, and 54% from senders they were never tuned to.
/// The mail goes masked (names, long numbers, personal addresses, PANs), five to a request, newest first; what comes
/// back is checked against the mail on this phone before it counts (engine.js › withClaude), and stays with the record
/// (`cl`), so new rules read the mail again without asking Claude. Through your own key straight to Anthropic, or
/// through the kosh service (Plus) when there is no key.
enum ClaudeReads {
    /// the version of the reading rules: a new one has every mail read again
    static let version: Int = Int((try? Engine.shared.call("clVersion", [])) ?? "") ?? 1
    /// how many requests are out at once (Anthropic's first tier allows 50 a minute; a request takes several seconds)
    static let atOnce = 4

    struct Route { let url: URL; let headers: [String: String]; let via: String }

    /// your own key first (straight to Anthropic, nobody between), else the kosh service with this phone's pass
    static func route() -> Route? {
        if let key = Keychain.get("claude.key") ?? Keychain.get(AgentCloud.askKeyName), !key.isEmpty, let u = URL(string: "https://api.anthropic.com/v1/messages") {
            return Route(url: u, headers: ["content-type": "application/json", "anthropic-version": "2023-06-01", "x-api-key": key], via: "key")
        }
        let set = UserDefaults.standard.string(forKey: "agent.url") ?? ""
        let base = (set.isEmpty ? AgentCloud.bundled("agentURL") : set).trimmingCharacters(in: CharacterSet(charactersIn: "/ "))
        if !base.isEmpty, let pass = Keychain.get("agent.pass"), !pass.isEmpty, let u = URL(string: base + "/v1/read") {
            return Route(url: u, headers: ["content-type": "application/json", "anthropic-version": "2023-06-01", "authorization": "Bearer " + pass], via: "kosh")
        }
        return nil
    }

    /// one request: Claude's answer, as text
    static func send(_ body: String, _ r: Route) async throws -> String {
        var req = URLRequest(url: r.url)
        req.httpMethod = "POST"
        for (k, v) in r.headers { req.setValue(v, forHTTPHeaderField: k) }
        req.timeoutInterval = 90
        req.httpBody = Data(body.utf8)
        let (data, resp) = try await URLSession.shared.data(for: req)
        let http = resp as? HTTPURLResponse
        let code = http?.statusCode ?? 0
        let said = ((try? JSONSerialization.jsonObject(with: data)) as? [String: Any]).flatMap { ($0["error"] as? [String: Any])?["message"] as? String } ?? ""
        // the service's day used up is said, not waited on
        if code == 429 && r.via == "kosh" && said.contains("today") { throw LiveError.http(code, said) }
        if code == 429 || code == 529 || code >= 500 { throw LiveError.busy(Double(http?.value(forHTTPHeaderField: "retry-after") ?? "") ?? 8) }
        if code == 401 || code == 403 { throw LiveError.badKey }
        guard code == 200 else { throw LiveError.http(code, said) }
        let j = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] ?? [:]
        let content = j["content"] as? [[String: Any]] ?? []
        return content.compactMap { ($0["type"] as? String) == "text" ? $0["text"] as? String : nil }.joined()
    }

    /// a request tried again while Anthropic (or the service) is busy, waiting longer each time
    static func sendRetrying(_ body: String, _ r: Route, times: Int = 5) async throws -> String {
        var wait = 2.0
        var attempt = 0
        while true {
            do { return try await send(body, r) }
            catch LiveError.busy(let s) {
                attempt += 1
                if attempt >= times { throw LiveError.busy(s) }
                try await Task.sleep(for: .seconds(max(s, wait)))
                wait *= 2
            }
        }
    }

    /// one batch: the request made and masked by the engine, sent, and the answer checked by the engine against the
    /// mail. Each mail's events (JSON), for the mail Claude answered for
    static func read(_ batch: [(String, MailMsg)], opts: String, route: Route) async throws -> [(String, MailMsg, String)] {
        let msgs = batch.map(\.1)
        let body = try Engine.shared.call("clReadRequestJSON", [JSONText.encode(msgs), opts])
        let text = try await sendRetrying(body, route)
        let out = try Engine.shared.call("clReadAnswerJSON", [text, JSONText.encode(msgs), opts])
        let got = (try? JSONSerialization.jsonObject(with: Data(out.utf8))) as? [[String: Any]] ?? []
        var res: [(String, MailMsg, String)] = []
        for (n, x) in got.enumerated() where n < batch.count {
            // (an answer that left a mail out: it is asked again next time)
            guard let evs = x["events"] as? [Any], JSONSerialization.isValidJSONObject(evs),
                  let d = try? JSONSerialization.data(withJSONObject: evs), let s = String(data: d, encoding: .utf8) else { continue }
            res.append((batch[n].0, batch[n].1, s))
        }
        return res
    }

    /// A paper kosh's own readers couldn't read, or whose figures said they misread it: its pages go to Claude masked
    /// (engine.js › "Claude reads a paper"), and what comes back is checked against the pages before any of it counts.
    /// The answer is kept sealed on this phone with the paper's text, so each paper is asked about once (a new
    /// version of the rules asks again). Nil without Claude, or when the request fails.
    static func readDoc(text: String, kind: String, from: String, title: String, names: [String], key: String) async -> String? {
        let cacheKey = "cldoc\(version)|" + key
        let meta = JSONText.object(["from": from, "title": title])
        let opts = JSONText.object(["names": names])
        if let kept = MailVault.getText(cacheKey) {
            return try? Engine.shared.call("clDocAnswerJSON", [kept, text, kind, meta, opts])
        }
        guard let r = route(), let body = try? Engine.shared.call("clDocRequestJSON", [text, kind, meta, opts]),
              let answer = try? await sendRetrying(body, r) else { return nil }
        MailVault.putText(answer, key: cacheKey)
        return try? Engine.shared.call("clDocAnswerJSON", [answer, text, kind, meta, opts])
    }
}

extension LiveSession {
    /// the words that never leave the phone: your name, your family's, and the words of your inboxes' addresses
    var claudeNames: [String] {
        var out: [String] = [name] + people.map(\.full)
        for a in allAccounts {
            let local = a.split(separator: "@").first.map(String.init) ?? ""
            let words = local.split(whereSeparator: { !$0.isLetter }).map(String.init).filter { $0.count >= 3 }
            if !words.isEmpty { out.append(words.joined(separator: " ")) }
        }
        return out.filter { !$0.isEmpty && $0 != "You" }
    }

    /// how far Claude has read: the mail it has read by the current rules, of all the mail kosh keeps
    var claudeCoverage: (read: Int, of: Int) {
        let v = ClaudeReads.version
        let mail = records.filter { $0.src != "manual" }
        return (mail.filter { $0.clv == v }.count, mail.count)
    }

    /// Claude reads every money mail it hasn't read by the current rules: newest first, a few requests at a time.
    /// What it read is filed as it comes back, so the screens fill in while the backlog is read.
    @MainActor
    func claudePass() async {
        guard let route = ClaudeReads.route(), !running || phase == .done || phase == .failed || phase == .idle else { return }
        let v = ClaudeReads.version
        // newest first: what's recent matters most, and a long backlog fills in behind it
        let todo = records.filter { $0.clv != v && $0.src != "manual" }.sorted { ($0.sent ?? "") > ($1.sent ?? "") }.map(\.id)
        if todo.isEmpty { return }
        phase = .claude
        message = nil
        claudeTotal = todo.count
        claudeDone = 0
        let opts = JSONText.object(["names": claudeNames])
        var k = 0
        var sinceSave = 0
        while k < todo.count {
            if KeepGoing.shared.stopped { break }
            if !Net.shared.online { guard await Net.shared.waitOnline() else { break } }
            let wave = Array(todo[k..<min(k + 5 * ClaudeReads.atOnce, todo.count)])
            k += wave.count
            var at = Dictionary(records.enumerated().map { ($1.id, $0) }, uniquingKeysWith: { a, _ in a })
            // the wave's mail, from the sealed copies (or the inbox, for mail kosh read before it kept them)
            var mails: [(String, MailMsg)] = []
            for id in wave {
                guard let i = at[id] else { continue }
                guard let m = await claudeMail(records[i]) else { continue }
                // a one-time password or a security notice never leaves the phone
                if (try? Engine.shared.call("clWantedJSON", [JSONText.encode(m)])) == "false" {
                    if let j = at[id], j < records.count, records[j].id == id { records[j].clv = v }
                    continue
                }
                mails.append((id, m))
            }
            let batches = stride(from: 0, to: mails.count, by: 5).map { Array(mails[$0..<min($0 + 5, mails.count)]) }
            var answers: [(String, MailMsg, String)] = []
            do {
                answers = try await withThrowingTaskGroup(of: [(String, MailMsg, String)].self) { g in
                    for b in batches { g.addTask { try await ClaudeReads.read(b, opts: opts, route: route) } }
                    var all: [(String, MailMsg, String)] = []
                    for try await r in g { all += r }
                    return all
                }
            } catch LiveError.badKey {
                message = route.via == "kosh" ? "kosh’s service didn’t accept this phone’s pass. Check it in Settings › Reading." : LiveError.badKey.errorDescription
                break
            } catch {
                message = "Smart reading stopped: \(error.localizedDescription)"
                break
            }
            // each mail read again with Claude's reading beside it, off the main thread
            let me = email, mode = checkMode
            at = Dictionary(records.enumerated().map { ($1.id, $0) }, uniquingKeysWith: { a, _ in a })
            for (id, m, evs) in answers {
                guard let i = at[id], i < records.count, records[i].id == id else { continue }
                let r = records[i]
                let acct = (r.acct ?? "").isEmpty ? email : (r.acct ?? email)
                let tag = inboxTag(acct)
                var withCl = m
                withCl.cl = evs
                let msg = withCl
                guard var fresh = await Task.detached(priority: .userInitiated, operation: { LiveSession.readingOf(msg, acct: acct, tag: tag, me: me, checkMode: mode) }).value else { continue }
                // a statement already opened, and a reading you chose, stay with the mail
                if let old = r.doc, let new = fresh.doc, old.att == new.att, old.kind == new.kind { fresh.doc = old }
                fresh.claude = r.claude
                fresh.use = r.use
                if let j = records.firstIndex(where: { $0.id == id }) { records[j] = fresh }
            }
            claudeDone = min(k, todo.count)
            sinceSave += wave.count
            if sinceSave >= 60 {
                sinceSave = 0; save(); LayoutBook.save()
                if readingBuildDue(every: 0) { lastRebuild = Date(); rebuildSoon() }
            }
        }
        save()
        LayoutBook.save()
        rebuildSoon()
        phase = .done
    }

    /// a mail as kosh kept it sealed on this phone, else fetched from its inbox again (and sealed)
    @MainActor
    func claudeMail(_ r: Reading) async -> MailMsg? {
        let rid = r.id
        if let m = await Task.detached(priority: .userInitiated, operation: { MailVault.get(rid) }).value { return m }
        guard !(r.from ?? "").isEmpty else { return nil }
        let acct = (r.acct ?? "").isEmpty ? email : (r.acct ?? email)
        let tag = inboxTag(acct)
        let msgId = tag.isEmpty || !r.id.hasPrefix(tag) ? r.id : String(r.id.dropFirst(tag.count))
        guard let m = try? await fetchOne(msgId, acct: acct) else { return nil }
        MailVault.put(m, id: r.id)
        return m
    }
}
