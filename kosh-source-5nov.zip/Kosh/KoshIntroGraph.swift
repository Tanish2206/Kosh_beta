import SwiftUI
import UIKit

// MARK: - The intro: the routes, the maths, the colours and the kosh mark
// (split out of KoshIntro.swift, 30 Oct 2026; the beats and what each draws are described there)

// MARK: - The routes (illustrative: the shape of the problem, not anyone's data)

enum IntroTier: Int { case app = 0, wallet, portal }

struct IntroNode {
    let id: String
    let name: String
    let tier: IntroTier
    let side: Int          // -1 left, 1 right, 0 the middle
    let wx: CGFloat        // place in the Wings drawing, -1...1
    let wy: CGFloat
    let head: Bool         // the hub most strings pass through (Savings)
    let idx: Int           // a portal's place in its column
}

struct IntroEdge {
    let from: Int
    let to: Int
    let aw: Bool           // app → wallet; otherwise wallet → portal
    let key: String
}

struct IntroRoute {
    let app: Int
    let wallet: Int
    let portal: Int
    let aw: Int
    let wp: Int
}

final class IntroGraph {
    static let shared: IntroGraph = IntroGraph()

    let nodes: [IntroNode]
    let edges: [IntroEdge]
    let routes: [IntroRoute]
    let story: [Int]
    let routesOf: [[Int]]
    let edgesOf: [Set<Int>]
    let nodesOf: [Set<Int>]
    let index: [String: Int]
    let awEdges: [Int]
    let wpEdges: [Int]

    // where money leaves: payment apps and cards on the left wing, banks and brokers on the right
    static let apps: [(String, String, Int, CGFloat, CGFloat)] = [
        ("gpay", "GPay", -1, 0.34, -0.92), ("phonepe", "PhonePe", -1, 0.70, -1.0), ("paytm", "Paytm", -1, 0.98, -0.84),
        ("cred", "CRED", -1, 0.90, -0.34), ("creditcard", "Credit card", -1, 0.84, 0.32), ("debitcard", "Debit card", -1, 0.70, 0.66),
        ("amazonpay", "Amazon Pay", -1, 0.38, 0.90),
        ("hdfc", "HDFC Bank", 1, 0.34, -0.92), ("icici", "ICICI Bank", 1, 0.70, -1.0), ("sbi", "SBI", 1, 0.98, -0.84),
        ("axis", "Axis Bank", 1, 0.90, -0.34), ("kotak", "Kotak", 1, 0.84, 0.32), ("zerodha", "Zerodha", 1, 0.70, 0.66),
        ("groww", "Groww", 1, 0.38, 0.90),
    ]
    // what it becomes: spending on the left, savings at the head, investments on the right
    static let wallets: [(String, String, Int, CGFloat, CGFloat)] = [
        ("food", "Food", -1, 0.46, -0.66), ("shopping", "Shopping", -1, 0.72, -0.50),
        ("bills", "Bills", -1, 0.56, -0.24), ("travel", "Travel", -1, 0.52, 0.26),
        ("insurance", "Insurance", -1, 0.38, 0.62),
        ("savings", "Savings", 0, 0, -0.74),
        ("funds", "Mutual funds", 1, 0.46, -0.66), ("stocks", "Stocks", 1, 0.72, -0.50),
        ("usstocks", "US stocks", 1, 0.56, -0.24), ("deposits", "Deposits", 1, 0.52, 0.26),
        ("gold", "Gold", 1, 0.38, 0.62),
    ]
    // the paper that records it, down the body
    static let portals: [String] = ["Receipts", "Invoices", "Statements", "Policies", "CAS", "Trade notes", "FD advice", "Tax forms"]
    static let appWallets: [(String, [String])] = [
        ("gpay", ["food", "bills", "savings"]), ("phonepe", ["food", "shopping", "savings"]), ("paytm", ["food", "travel", "bills"]),
        ("cred", ["bills", "insurance", "savings"]), ("creditcard", ["shopping", "travel", "bills"]), ("debitcard", ["shopping", "food"]),
        ("amazonpay", ["shopping", "bills"]),
        ("hdfc", ["funds", "deposits", "savings"]), ("icici", ["stocks", "deposits", "savings"]), ("sbi", ["deposits", "gold", "savings"]),
        ("axis", ["usstocks", "funds", "savings"]), ("kotak", ["deposits", "funds", "savings"]), ("zerodha", ["stocks", "funds", "gold"]),
        ("groww", ["funds", "usstocks", "stocks"]),
    ]
    static let walletPortals: [(String, [String])] = [
        ("food", ["Receipts", "Statements"]), ("shopping", ["Receipts", "Invoices", "Statements"]), ("bills", ["Invoices", "Statements"]),
        ("travel", ["Invoices", "Receipts", "Statements"]), ("insurance", ["Policies", "Tax forms", "Statements"]),
        ("savings", ["Statements", "CAS", "FD advice", "Tax forms", "Policies", "Trade notes"]),
        ("funds", ["CAS", "Tax forms", "Statements"]), ("stocks", ["Trade notes", "CAS", "Tax forms"]),
        ("usstocks", ["Statements", "Trade notes", "Tax forms"]), ("deposits", ["FD advice", "Tax forms", "Statements"]),
        ("gold", ["Invoices", "CAS"]),
    ]
    static let storyRoutes: [(String, String, String)] = [
        ("gpay", "food", "Receipts"), ("zerodha", "stocks", "Trade notes"), ("hdfc", "funds", "CAS"),
        ("cred", "insurance", "Policies"), ("sbi", "deposits", "FD advice"), ("groww", "usstocks", "Tax forms"),
    ]

    private init() {
        var ns: [IntroNode] = []
        for a in IntroGraph.apps {
            ns.append(IntroNode(id: a.0, name: a.1, tier: .app, side: a.2, wx: CGFloat(a.2) * a.3, wy: a.4, head: false, idx: 0))
        }
        for w in IntroGraph.wallets {
            ns.append(IntroNode(id: w.0, name: w.1, tier: .wallet, side: w.2, wx: CGFloat(w.2) * w.3, wy: w.4, head: w.2 == 0, idx: 0))
        }
        for (i, p) in IntroGraph.portals.enumerated() {
            ns.append(IntroNode(id: "p:" + p, name: p, tier: .portal, side: 0, wx: 0, wy: -0.44 + CGFloat(i) * 0.14, head: false, idx: i))
        }
        var ix: [String: Int] = [:]
        for (i, n) in ns.enumerated() { ix[n.id] = i }
        var es: [IntroEdge] = []
        for (a, ws) in IntroGraph.appWallets {
            for w in ws {
                if let f = ix[a], let t = ix[w] { es.append(IntroEdge(from: f, to: t, aw: true, key: a + ">" + w)) }
            }
        }
        for (w, ps) in IntroGraph.walletPortals {
            for p in ps {
                if let f = ix[w], let t = ix["p:" + p] { es.append(IntroEdge(from: f, to: t, aw: false, key: w + ">" + p)) }
            }
        }
        var rs: [IntroRoute] = []
        for (ai, a) in es.enumerated() where a.aw {
            for (wi, w) in es.enumerated() where !w.aw && w.from == a.to {
                rs.append(IntroRoute(app: a.from, wallet: a.to, portal: w.to, aw: ai, wp: wi))
            }
        }
        var ro: [[Int]] = Array(repeating: [], count: ns.count)
        var eo: [Set<Int>] = Array(repeating: [], count: ns.count)
        var no: [Set<Int>] = Array(repeating: [], count: ns.count)
        for (ri, r) in rs.enumerated() {
            for n in [r.app, r.wallet, r.portal] {
                ro[n].append(ri)
                eo[n].insert(r.aw)
                eo[n].insert(r.wp)
                no[n].insert(r.app)
                no[n].insert(r.wallet)
                no[n].insert(r.portal)
            }
        }
        var st: [Int] = []
        for s in IntroGraph.storyRoutes {
            guard let a = ix[s.0], let w = ix[s.1], let p = ix["p:" + s.2] else { continue }
            if let r = rs.firstIndex(where: { (x: IntroRoute) -> Bool in x.app == a && x.wallet == w && x.portal == p }) { st.append(r) }
        }
        nodes = ns
        edges = es
        routes = rs
        story = st
        routesOf = ro
        edgesOf = eo
        nodesOf = no
        index = ix
        awEdges = es.indices.filter { (i: Int) -> Bool in es[i].aw }
        wpEdges = es.indices.filter { (i: Int) -> Bool in !es[i].aw }
    }

    /// up to three names, then "+ more": the intro never prints a count
    func names(_ set: Set<Int>) -> String {
        let all: [String] = set.sorted().map { (i: Int) -> String in nodes[i].name }
        if all.count > 3 { return all.prefix(3).joined(separator: " · ") + " + more" }
        return all.joined(separator: " · ")
    }
}

// MARK: - Maths

enum IntroMath {
    static func clamp(_ v: Double) -> Double { v < 0 ? 0 : (v > 1 ? 1 : v) }
    static func ease(_ t: Double) -> Double { t < 0.5 ? 4 * t * t * t : 1 - pow(-2 * t + 2, 3) / 2 }
    static func easeOut(_ t: Double) -> Double { 1 - pow(1 - t, 3) }
    static func easeSine(_ t: Double) -> Double { -(cos(Double.pi * t) - 1) / 2 }
    /// overshoots a little and settles: the walls and the lid
    static func spring(_ t: Double) -> Double { t <= 0 ? 0 : (t >= 1 ? 1 : 1 - exp(-6.5 * t) * cos(11 * t)) }

    static func bez(_ p0: CGPoint, _ p1: CGPoint, _ p2: CGPoint, _ p3: CGPoint, _ n: Int) -> [CGPoint] {
        var out: [CGPoint] = []
        out.reserveCapacity(n)
        for i in 0..<n {
            let t: CGFloat = CGFloat(i) / CGFloat(n - 1)
            let u: CGFloat = 1 - t
            let b0: CGFloat = u * u * u
            let b1: CGFloat = 3 * u * u * t
            let b2: CGFloat = 3 * u * t * t
            let b3: CGFloat = t * t * t
            let x: CGFloat = b0 * p0.x + b1 * p1.x + b2 * p2.x + b3 * p3.x
            let y: CGFloat = b0 * p0.y + b1 * p1.y + b2 * p2.y + b3 * p3.y
            out.append(CGPoint(x: x, y: y))
        }
        return out
    }

    /// a closed Catmull–Rom loop through the points
    static func loop(_ pts: [CGPoint], per: Int) -> [CGPoint] {
        var out: [CGPoint] = []
        let m: Int = pts.count
        for i in 0..<m {
            let p0: CGPoint = pts[(i - 1 + m) % m]
            let p1: CGPoint = pts[i]
            let p2: CGPoint = pts[(i + 1) % m]
            let p3: CGPoint = pts[(i + 2) % m]
            for k in 0..<per {
                let t: CGFloat = CGFloat(k) / CGFloat(per)
                out.append(CGPoint(x: crf(p0.x, p1.x, p2.x, p3.x, t), y: crf(p0.y, p1.y, p2.y, p3.y, t)))
            }
        }
        return out
    }

    private static func crf(_ a: CGFloat, _ b: CGFloat, _ c: CGFloat, _ d: CGFloat, _ t: CGFloat) -> CGFloat {
        let t2: CGFloat = t * t
        let t3: CGFloat = t2 * t
        let k1: CGFloat = (-a + c) * t
        let k2: CGFloat = (2 * a - 5 * b + 4 * c - d) * t2
        let k3: CGFloat = (-a + 3 * b - 3 * c + d) * t3
        return 0.5 * (2 * b + k1 + k2 + k3)
    }
}

/// a small seeded generator, so the strings fall the same way every time
struct IntroRNG {
    private var a: UInt32
    init(key: String) {
        var h: UInt32 = 2166136261
        for b in key.utf8 {
            h ^= UInt32(b)
            h = h &* 16777619
        }
        a = h
    }
    mutating func next() -> Double {
        a = a &+ 0x6D2B79F5
        var t: UInt32 = (a ^ (a >> 15)) &* (1 | a)
        t = (t &+ ((t ^ (t >> 7)) &* (61 | t))) ^ t
        return Double(t ^ (t >> 14)) / 4294967296.0
    }
    mutating func jig(_ p: CGPoint, _ amount: CGFloat) -> CGPoint {
        let dx: CGFloat = CGFloat(next() - 0.5) * amount
        let dy: CGFloat = CGFloat(next() - 0.5) * amount
        return CGPoint(x: p.x + dx, y: p.y + dy)
    }
}

// MARK: - Colours

enum IntroInk {
    static let app: Color = Color(light: "#E08400", dark: "#FFAD3A")
    static let wallet: Color = Color(light: "#D2306F", dark: "#FF5E9E")
    static let gift: Color = Color(light: "#2B58E4", dark: "#5E8CFF")
    static let appText: Color = Color(light: "#9A5600", dark: "#FFB24D")
    static let walletText: Color = Color(light: "#AE2259", dark: "#FF7DB1")
    static let giftText: Color = Color(light: "#1E44C2", dark: "#8AABFF")
    static let muted: Color = Color(light: "#6B6B75", dark: "#8C8C96")
    static let tile: Color = Color(light: "#111111", dark: "#161618")
    static let silver: Color = Color(hex: "#D9D9D9")
    static let page: Color = Color(uiColor: .systemBackground)

    static func of(_ t: IntroTier) -> Color {
        switch t {
        case .app: return app
        case .wallet: return wallet
        case .portal: return gift
        }
    }
    static func text(_ t: IntroTier) -> Color {
        switch t {
        case .app: return appText
        case .wallet: return walletText
        case .portal: return giftText
        }
    }
}

// MARK: - The kosh mark, from the app icon (a 24-unit grid inside a 30.72-unit tile)

enum IntroMark {
    static let coin: CGPoint = CGPoint(x: 12, y: 12.85)
    static let coinR: CGFloat = 3.7
    static let rupee: Path = {
        var p = Path()
        p.move(to: CGPoint(x: 10.7, y: 10.95))
        p.addLine(to: CGPoint(x: 13.3, y: 10.95))
        p.move(to: CGPoint(x: 10.7, y: 11.85))
        p.addLine(to: CGPoint(x: 13.3, y: 11.85))
        p.move(to: CGPoint(x: 11.35, y: 10.95))
        p.addCurve(to: CGPoint(x: 11.35, y: 12.75), control1: CGPoint(x: 12.95, y: 10.95), control2: CGPoint(x: 12.95, y: 12.75))
        p.addLine(to: CGPoint(x: 10.8, y: 12.75))
        p.addLine(to: CGPoint(x: 12.95, y: 14.75))
        return p
    }()
    static let left: Path = IntroMark.shape([CGPoint(x: 3.5, y: 9.6), CGPoint(x: 12, y: 13.8), CGPoint(x: 12, y: 22.2), CGPoint(x: 3.5, y: 18)])
    static let right: Path = IntroMark.shape([CGPoint(x: 12, y: 13.8), CGPoint(x: 20.5, y: 9.6), CGPoint(x: 20.5, y: 18), CGPoint(x: 12, y: 22.2)])
    static let lid: Path = IntroMark.shape([CGPoint(x: 3.9, y: 4.8), CGPoint(x: 12, y: 0.8), CGPoint(x: 20.1, y: 4.8), CGPoint(x: 12, y: 8.8)])
    static let box: Path = {
        var p = Path()
        p.addPath(left)
        p.addPath(right)
        p.addPath(lid)
        return p
    }()
    private static func shape(_ pts: [CGPoint]) -> Path {
        var p = Path()
        p.addLines(pts)
        p.closeSubpath()
        return p
    }
}
