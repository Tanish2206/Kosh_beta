import SwiftUI

// MARK: - The street, in isometric
//
// Every property you let out stands on a floating block of town, drawn at 30°: a building per property, its
// tenants' windows on the long face (gold when this month's rent is in, red and breathing when it's late, dim
// before it's due), its floors stacked to scale, a shop's awning, a house's clay roof, a tank on a flat one. Roads
// run in front of each row of buildings.
//
// Properties in more than one state float as islands, one per state, each in its own colours with its number plate
// (HR, MH, PB) underneath. Tap an island and the camera flies in to it; tap a building (on that island, or on the one
// street when everything is in one state) and it flies in again, to that building alone: the others fade and its
// tenants' tags hang off its floors. The camera is one transform plus two fades (IsoLens) that SwiftUI animates, so
// the canvas is redrawn crisp at every step rather than a picture being scaled. Reduce Motion: nothing breathes or
// bobs, and the camera cuts instead of flying. VoiceOver reads each island, building and tag as a button.

/// one state's block, worked out from its buildings: where each stands in the block's own units (x along the street,
/// y across it, z up), and where the roads run
struct IsoBlock {
    struct Box {
        let house: StreetHouse
        let x: CGFloat
        let y: CGFloat
        let w: CGFloat
        let d: CGFloat
        /// walls' height, and a house's roof over them
        let h: CGFloat
        let roof: CGFloat
    }
    struct Road { let y: CGFloat; let x0: CGFloat; let x1: CGFloat }

    let boxes: [Box]
    let roads: [Road]
    /// the slab under it all: x0, y0, x1, y1
    let slab: (CGFloat, CGFloat, CGFloat, CGFloat)

    static let floor: CGFloat = 18
    static let parapet: CGFloat = 7
    static let road: CGFloat = 20
    static let gap: CGFloat = 14
    static let depth: CGFloat = 9
    static let cos: CGFloat = 0.866
    static let sin: CGFloat = 0.5

    /// how many to a row: one or two side by side, then twos (three stand as two and one), threes up to nine,
    /// fours up to sixteen, then fives: the block stays close to square, so the buildings stay as big as they can
    static func perRow(_ n: Int) -> Int {
        if n <= 2 { return max(1, n) }
        if n <= 4 { return 2 }
        if n <= 9 { return 3 }
        if n <= 16 { return 4 }
        return 5
    }

    static func size(_ h: StreetHouse) -> (w: CGFloat, d: CGFloat, h: CGFloat, roof: CGFloat) {
        let cols: Int = min(6, max(1, h.floors.map { $0.windows.count }.max() ?? 1))
        let n: CGFloat = CGFloat(max(1, h.floors.count))
        switch h.kind {
        case .house: return (max(40, CGFloat(cols) * 16 + 14), 34, n * floor, 16)
        case .shop: return (max(44, CGFloat(cols) * 15 + 10), 28, n * floor + parapet, 0)
        case .flats: return (max(36, CGFloat(cols) * 13 + 10), 30, n * floor + parapet, 0)
        case .office: return (max(40, CGFloat(cols) * 15 + 10), 30, n * floor + parapet, 0)
        case .plot: return (max(40, CGFloat(cols) * 15 + 10), 30, 0, 0)
        }
    }

    init(_ houses: [StreetHouse]) {
        let per: Int = Self.perRow(houses.count)
        var boxes: [Box] = []
        var roads: [Road] = []
        var y: CGFloat = 0
        var widest: CGFloat = 0
        var i: Int = 0
        while i < houses.count {
            let row: [StreetHouse] = Array(houses[i..<min(houses.count, i + per)])
            let deep: CGFloat = row.map { Self.size($0).d }.max() ?? 30
            var x: CGFloat = 0
            for hs in row {
                let s = Self.size(hs)
                // each building stands at the front of its row, against the road
                boxes.append(Box(house: hs, x: x, y: y + deep - s.d, w: s.w, d: s.d, h: s.h, roof: s.roof))
                x += s.w + Self.gap
            }
            widest = max(widest, x - Self.gap)
            roads.append(Road(y: y + deep + 4, x0: -10, x1: 0))
            y += deep + 4 + Self.road + 10
            i += per
        }
        self.boxes = boxes
        self.roads = roads.map { Road(y: $0.y, x0: -10, x1: widest + 10) }
        self.slab = (-14, -12, widest + 14, y - 6)
    }

    /// a point of the block on the page, before it's fitted
    static func at(_ x: CGFloat, _ y: CGFloat, _ z: CGFloat) -> CGPoint {
        CGPoint(x: (x - y) * cos, y: (x + y) * sin - z)
    }

    static func box(_ pts: [CGPoint]) -> CGRect {
        let xs: [CGFloat] = pts.map(\.x), ys: [CGFloat] = pts.map(\.y)
        let x0: CGFloat = xs.min() ?? 0, y0: CGFloat = ys.min() ?? 0
        return CGRect(x: x0, y: y0, width: max(1, (xs.max() ?? 1) - x0), height: max(1, (ys.max() ?? 1) - y0))
    }

    /// everything's extent on the page, before it's fitted
    var bounds: CGRect {
        var pts: [CGPoint] = []
        let (x0, y0, x1, y1) = slab
        for (x, y) in [(x0, y0), (x1, y0), (x1, y1), (x0, y1)] {
            pts.append(Self.at(x, y, 0))
            pts.append(Self.at(x, y, -Self.depth))
        }
        for b in boxes {
            let top: CGFloat = b.h + b.roof + 10
            pts.append(Self.at(b.x, b.y, top))
            pts.append(Self.at(b.x + b.w, b.y, top))
            pts.append(Self.at(b.x, b.y + b.d, top))
        }
        return Self.box(pts)
    }

    /// a building's extent on the page: its footprint's front up to its roof (and the tank or chimney on it)
    static func extent(_ b: Box) -> CGRect {
        let top: CGFloat = b.h + b.roof + 10
        return box([at(b.x, b.y + b.d, 0), at(b.x + b.w, b.y + b.d, 0), at(b.x + b.w, b.y, 0),
                    at(b.x, b.y, top), at(b.x + b.w, b.y, top), at(b.x, b.y + b.d, top), at(b.x + b.w, b.y + b.d, top)])
    }

    /// fitted into a frame: a scale and where the block's origin lands, never larger than life and a half
    func fit(_ size: CGSize) -> CGAffineTransform {
        let b: CGRect = bounds
        let k: CGFloat = min(1.5, size.width / b.width, size.height / b.height)
        return CGAffineTransform(a: k, b: 0, c: 0, d: k, tx: size.width / 2 - b.midX * k, ty: size.height / 2 - b.midY * k)
    }

    /// a building's outline on the page (its six visible corners), to know what a tap landed on
    static func outline(_ b: Box) -> [CGPoint] {
        let top: CGFloat = b.h + b.roof
        return [at(b.x, b.y + b.d, 0), at(b.x + b.w, b.y + b.d, 0), at(b.x + b.w, b.y, 0),
                at(b.x + b.w, b.y, top), at(b.x, b.y, top), at(b.x, b.y + b.d, top)]
    }

    /// the slab's outline on the page: its top and its two edges
    var shore: [CGPoint] {
        let (x0, y0, x1, y1) = slab
        let t: CGFloat = Self.depth
        return [Self.at(x0, y0, 0), Self.at(x1, y0, 0), Self.at(x1, y0, -t), Self.at(x1, y1, -t), Self.at(x0, y1, -t), Self.at(x0, y1, 0)]
    }

    /// the slab's front corner (its lowest point on the page), where a state's plate hangs
    var front: CGPoint {
        let (_, _, x1, y1) = slab
        return Self.at(x1, y1, -Self.depth)
    }

    /// how tall the tile gives the street: more rows, more room, up to a point
    static func height(_ n: Int) -> CGFloat {
        let rows: Int = (n + perRow(n) - 1) / max(1, perRow(n))
        return min(320, 150 + CGFloat(max(0, rows - 1)) * 64)
    }

    static func inside(_ p: CGPoint, _ poly: [CGPoint]) -> Bool {
        var hit: Bool = false
        var j: Int = poly.count - 1
        for i in 0..<poly.count {
            let a: CGPoint = poly[i], b: CGPoint = poly[j]
            if (a.y > p.y) != (b.y > p.y) && p.x < (b.x - a.x) * (p.y - a.y) / (b.y - a.y) + a.x { hit.toggle() }
            j = i
        }
        return hit
    }
}

// MARK: - The islands

/// a state's colours: its slab's top and two edges, its roads and their kerbs and dashes
struct IsoTheme {
    let top: Color, left: Color, right: Color, road: Color, kerb: Color, dash: Color

    init(_ c: [String]) {
        top = Color(hex: c[0]); left = Color(hex: c[1]); right = Color(hex: c[2])
        road = Color(hex: c[3]); kerb = Color(hex: c[4]); dash = Color(hex: c[5]).opacity(0.55)
    }

    /// dusk violet (the one street), then teal, olive, rose and slate for the next states
    static let all: [IsoTheme] = [
        IsoTheme(["#2E2754", "#1A1534", "#241D46", "#221B42", "#3A3263", "#8A80B0"]),
        IsoTheme(["#203A4C", "#122230", "#172C3B", "#15283A", "#2B4A5E", "#7FA6BF"]),
        IsoTheme(["#3B3A22", "#211F12", "#2C2A18", "#26241A", "#4A4730", "#B8AE7A"]),
        IsoTheme(["#45283F", "#26151F", "#351E30", "#2C1A2A", "#573A52", "#C99AB8"]),
        IsoTheme(["#2A3350", "#161C30", "#1E2640", "#1A2138", "#384570", "#93A6D6"]),
    ]
}

/// where kosh is looking: the whole street (or every state), one state's island, or one building up close
enum IsoLevel: Int { case all = 0, isle = 1, house = 2 }

/// every property you let out, grouped by the state it's in: one island each, the biggest first
struct IsoWorld {
    struct Isle: Identifiable {
        /// the state, as the property's portal has it ("" when it isn't set)
        let id: String
        let name: String
        let code: String
        let houses: [StreetHouse]
        let block: IsoBlock
        let theme: IsoTheme
        var lets: [TenantsView.Let] { houses.flatMap(\.lets) }
    }
    let isles: [Isle]
    var many: Bool { isles.count > 1 }

    init(_ houses: [StreetHouse]) {
        var order: [String] = []
        var by: [String: [StreetHouse]] = [:]
        for h in houses {
            let s: String = Street.state(h.p)
            if by[s] == nil { order.append(s) }
            by[s, default: []].append(h)
        }
        // the state with the most buildings takes the big spot; ties keep the order you added them
        let ranked: [String] = order.enumerated().sorted { a, b in
            let na: Int = by[a.element]?.count ?? 0, nb: Int = by[b.element]?.count ?? 0
            return na != nb ? na > nb : a.offset < b.offset
        }.map(\.element)
        isles = ranked.enumerated().map { (i: Int, s: String) -> Isle in
            let hs: [StreetHouse] = by[s] ?? []
            return Isle(id: s, name: Street.stateName(s), code: Street.plate(s), houses: hs, block: IsoBlock(hs),
                        theme: IsoTheme.all[i % IsoTheme.all.count])
        }
    }

    func index(_ isle: String?) -> Int? { isles.firstIndex { $0.id == isle } }
    func index(house: String?) -> Int? { isles.firstIndex { s in s.houses.contains { $0.id == house } } }

    /// each island's share of the frame: the first (the biggest) on the left, the others down the right
    static func shares(_ n: Int, _ s: CGSize) -> [CGRect] {
        let w: CGFloat = s.width, h: CGFloat = s.height
        switch n {
        case 1: return [CGRect(origin: .zero, size: s)]
        case 2: return [CGRect(x: 0, y: h * 0.14, width: w * 0.58, height: h * 0.86), CGRect(x: w * 0.5, y: 0, width: w * 0.5, height: h * 0.8)]
        case 3: return [CGRect(x: 0, y: h * 0.16, width: w * 0.62, height: h * 0.84), CGRect(x: w * 0.58, y: 0, width: w * 0.42, height: h * 0.52),
                        CGRect(x: w * 0.6, y: h * 0.52, width: w * 0.4, height: h * 0.48)]
        default:
            let cols: Int = n <= 4 ? 2 : 3
            let rows: Int = (n + cols - 1) / cols
            let cw: CGFloat = w / CGFloat(cols), ch: CGFloat = h / CGFloat(rows)
            return (0..<n).map { i in CGRect(x: CGFloat(i % cols) * cw, y: CGFloat(i / cols) * ch, width: cw, height: ch) }
        }
    }

    /// where each island sits in a frame this size, seen whole: each fitted to its share (above its plate), none
    /// drawn larger than the first, so a state with one flat doesn't tower over one with six buildings
    func fits(_ size: CGSize) -> [CGAffineTransform] {
        if isles.count == 1 { return [isles[0].block.fit(size)] }
        let rects: [CGRect] = Self.shares(isles.count, size)
        var first: CGFloat = 1.5
        var out: [CGAffineTransform] = []
        for (i, s) in isles.enumerated() {
            let r: CGRect = CGRect(x: rects[i].minX + 4, y: rects[i].minY + 2, width: rects[i].width - 8, height: rects[i].height - 28)
            let b: CGRect = s.block.bounds
            var k: CGFloat = min(1.5, r.width / b.width, r.height / b.height)
            if i == 0 { first = k } else { k = min(k, first) }
            out.append(CGAffineTransform(a: k, b: 0, c: 0, d: k, tx: r.midX - b.midX * k, ty: r.midY - b.midY * k))
        }
        return out
    }

    /// the camera for a level: nothing moved for the whole street; one island filling the frame; one building
    /// as large as fits the left half (its tags take the right), whichever island it stands on
    func lens(_ level: IsoLevel, isle: String?, house: String?, fits: [CGAffineTransform], size: CGSize) -> IsoLens {
        switch level {
        case .all:
            return .still
        case .isle:
            guard let i = index(isle) else { return .still }
            let bb: CGRect = isles[i].block.bounds.applying(fits[i])
            let room: CGRect = CGRect(x: 10, y: 6, width: size.width - 20, height: size.height - 12)
            let k: CGFloat = min(3, room.width / bb.width, room.height / bb.height)
            return IsoLens(CGAffineTransform(a: k, b: 0, c: 0, d: k, tx: room.midX - bb.midX * k, ty: room.midY - bb.midY * k), isles: 1, houses: 0)
        case .house:
            guard let i = index(house: house), let b = isles[i].block.boxes.first(where: { $0.house.id == house }) else { return .still }
            // the building's own camera, less the island's fit: what's applied over the fitted islands
            let close: CGAffineTransform = IsoLens.inside(b, size)
            return IsoLens(fits[i].inverted().concatenating(close), isles: 1, houses: 1)
        }
    }
}

/// the camera: a scale and a shift laid over the fitted islands, and how far the other islands and the other
/// buildings have faded. SwiftUI animates it as one value, so every frame of a flight is drawn afresh.
struct IsoLens: VectorArithmetic {
    var k: CGFloat
    var tx: CGFloat
    var ty: CGFloat
    var isles: CGFloat
    var houses: CGFloat

    init(k: CGFloat, tx: CGFloat, ty: CGFloat, isles: CGFloat, houses: CGFloat) {
        self.k = k; self.tx = tx; self.ty = ty; self.isles = isles; self.houses = houses
    }
    init(_ t: CGAffineTransform, isles: CGFloat, houses: CGFloat) {
        self.init(k: t.a, tx: t.tx, ty: t.ty, isles: isles, houses: houses)
    }

    static let still = IsoLens(k: 1, tx: 0, ty: 0, isles: 0, houses: 0)
    var transform: CGAffineTransform { CGAffineTransform(a: k, b: 0, c: 0, d: k, tx: tx, ty: ty) }

    /// one building, close: as large as fits the left half of the frame, never more than four times life
    static func inside(_ b: IsoBlock.Box, _ size: CGSize) -> CGAffineTransform {
        let r: CGRect = IsoBlock.extent(b)
        let k: CGFloat = min(4, size.width * 0.44 / r.width, size.height * 0.82 / r.height)
        let at: CGPoint = CGPoint(x: size.width * 0.27, y: size.height * 0.5)
        return CGAffineTransform(a: k, b: 0, c: 0, d: k, tx: at.x - r.midX * k, ty: at.y - r.midY * k)
    }

    static var zero: IsoLens { IsoLens(k: 0, tx: 0, ty: 0, isles: 0, houses: 0) }
    static func + (a: IsoLens, b: IsoLens) -> IsoLens {
        IsoLens(k: a.k + b.k, tx: a.tx + b.tx, ty: a.ty + b.ty, isles: a.isles + b.isles, houses: a.houses + b.houses)
    }
    static func - (a: IsoLens, b: IsoLens) -> IsoLens {
        IsoLens(k: a.k - b.k, tx: a.tx - b.tx, ty: a.ty - b.ty, isles: a.isles - b.isles, houses: a.houses - b.houses)
    }
    mutating func scale(by rhs: Double) {
        let r: CGFloat = CGFloat(rhs)
        k *= r; tx *= r; ty *= r; isles *= r; houses *= r
    }
    var magnitudeSquared: Double {
        let s: CGFloat = k * k + tx * tx + ty * ty + isles * isles + houses * houses
        return Double(s)
    }
}

// MARK: - The street on the page

/// the islands (or the one street) in their frame, with the camera where the level puts it
struct IsoStreet: View {
    let world: IsoWorld
    let level: IsoLevel
    /// the island and the building last flown to: kept while flying back out, so they fade back in place
    let isle: String?
    let house: String?
    /// the building's tenants' tags are up (once the flight in has settled)
    let tags: Bool
    let still: Bool
    let pickIsle: (String) -> Void
    let pickHouse: (String) -> Void
    let open: (TenantsView.Let) -> Void
    let more: () -> Void

    var body: some View {
        GeometryReader { g in
            let fits: [CGAffineTransform] = world.fits(g.size)
            IsoScene(world: world, fits: fits, size: g.size, level: level, isle: isle, house: house, tags: tags, still: still,
                     lens: world.lens(level, isle: isle, house: house, fits: fits, size: g.size),
                     pickIsle: pickIsle, pickHouse: pickHouse, open: open, more: more)
        }
    }
}

/// what's drawn for one frame of the camera: the canvas, the states' plates on the way in, the tags once there
struct IsoScene: View, Animatable {
    let world: IsoWorld
    let fits: [CGAffineTransform]
    let size: CGSize
    let level: IsoLevel
    let isle: String?
    let house: String?
    let tags: Bool
    let still: Bool
    var lens: IsoLens
    let pickIsle: (String) -> Void
    let pickHouse: (String) -> Void
    let open: (TenantsView.Let) -> Void
    let more: () -> Void

    var animatableData: IsoLens {
        get { lens }
        set { lens = newValue }
    }

    var body: some View {
        let cam: CGAffineTransform = lens.transform
        ZStack(alignment: .topLeading) {
            IsoCanvas(world: world, fits: fits, cam: cam, isle: isle, house: house, isleFade: lens.isles, houseFade: lens.houses, still: still)
                .contentShape(Rectangle())
                .onTapGesture { at in tap(at, cam: cam) }
                .accessibilityElement(children: .contain)
                .accessibilityChildren { spoken }
            if world.many && lens.isles < 0.98 {
                ForEach(Array(world.isles.enumerated()), id: \.element.id) { i, s in
                    let at: CGPoint = s.block.front.applying(fits[i]).applying(cam)
                    IslePlate(isle: s, still: still) { pickIsle(s.id) }
                        .fixedSize()
                        .position(x: min(max(at.x, 70), size.width - 70), y: min(at.y + 15, size.height - 12))
                        .opacity(Double(1 - lens.isles))
                        .allowsHitTesting(level == .all)
                }
            }
            if tags, let i = world.index(house: house), let b = world.isles[i].block.boxes.first(where: { $0.house.id == house }) {
                FloorTags(box: b, cam: fits[i].concatenating(cam), size: size, still: still, open: open, more: more)
                    .transition(.opacity)
            }
        }
        .accessibilityElement(children: .contain)
    }

    /// a tap: on the whole street of islands, the island under it; on one street or island, the frontmost building
    func tap(_ at: CGPoint, cam: CGAffineTransform) {
        switch level {
        case .all where world.many:
            for i in world.isles.indices.reversed() {
                let p: CGPoint = at.applying(fits[i].concatenating(cam).inverted())
                let s: IsoWorld.Isle = world.isles[i]
                if IsoBlock.inside(p, s.block.shore) || s.block.boxes.contains(where: { IsoBlock.inside(p, IsoBlock.outline($0)) }) {
                    pickIsle(s.id)
                    return
                }
            }
        case .all, .isle:
            let i: Int = world.many ? (world.index(isle) ?? 0) : 0
            let p: CGPoint = at.applying(fits[i].concatenating(cam).inverted())
            for b in world.isles[i].block.boxes.reversed() where IsoBlock.inside(p, IsoBlock.outline(b)) {
                pickHouse(b.house.id)
                return
            }
        case .house:
            break
        }
    }

    /// VoiceOver: the islands to fly to, or the buildings to step into
    @ViewBuilder var spoken: some View {
        if level == .all && world.many {
            ForEach(world.isles) { s in
                Rectangle()
                    .accessibilityLabel(IsoScene.say(s))
                    .accessibilityAddTraits(.isButton)
                    .accessibilityAction { pickIsle(s.id) }
            }
        } else if level != .house {
            let hs: [StreetHouse] = world.many ? (world.isles.first(where: { $0.id == isle })?.houses ?? []) : (world.isles.first?.houses ?? [])
            ForEach(hs) { h in
                Rectangle()
                    .accessibilityLabel(Street.say(h))
                    .accessibilityAddTraits(.isButton)
                    .accessibilityAction { pickHouse(h.id) }
            }
        }
    }

    static func say(_ s: IsoWorld.Isle) -> String {
        let n: Int = s.houses.count
        return s.name + ", " + String(n) + (n == 1 ? " property, " : " properties, ") + Street.status(s.lets).0.lowercased()
    }
}

/// the canvas: each island in its colours, its buildings over it; the others fading as the camera flies in
struct IsoCanvas: View {
    /// off while its tab is behind another (kosh keeps visited tabs alive): its animation rests
    @Environment(\.tabActive) private var tabActive
    let world: IsoWorld
    let fits: [CGAffineTransform]
    let cam: CGAffineTransform
    let isle: String?
    let house: String?
    let isleFade: CGFloat
    let houseFade: CGFloat
    let still: Bool

    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 20, paused: still || !tabActive)) { tl in
            let t: Double = still ? 0.25 : tl.date.timeIntervalSinceReferenceDate
            Canvas { ctx, _ in
                ctx.concatenate(cam)
                for (i, s) in world.isles.enumerated() {
                    var c: GraphicsContext = ctx
                    c.concatenate(fits[i])
                    let on: Bool = !world.many || s.id == isle
                    if !on { c.opacity *= Double(1 - 0.9 * isleFade) }
                    IsoPaint.island(&c, s, house: on ? house : nil, fade: houseFade, t: t)
                }
            }
        }
    }
}

/// a state's number plate under its island, with its name and a dot for how its rent stands
struct IslePlate: View {
    let isle: IsoWorld.Isle
    let still: Bool
    let tap: () -> Void
    @State private var up = false

    var body: some View {
        let dot: Color = Street.dot(isle.lets)
        Button(action: tap) {
            HStack(spacing: 6) {
                StatePlate(code: isle.code, height: 18)
                Text(isle.name)
                    .font(.system(size: 12, weight: .bold))
                    .foregroundStyle(Color.white)
                    .shadow(color: .black.opacity(0.6), radius: 3, y: 1)
                    .lineLimit(1)
                Circle().fill(dot).frame(width: 7, height: 7).shadow(color: dot, radius: 3)
            }
            .padding(.vertical, 4)
            .contentShape(Rectangle())
        }
        .buttonStyle(.press)
        .offset(y: up ? -3 : 0)
        .onAppear {
            guard !still else { return }
            withAnimation(.easeInOut(duration: 2.25).repeatForever(autoreverses: true).delay(Double(Dusk.pick(isle.id, 7)) * 0.2)) { up = true }
        }
        .accessibilityHidden(true)
    }
}

/// a number plate: white, with the blue strip down its left and the state's two letters
struct StatePlate: View {
    let code: String
    var height: CGFloat = 20
    var body: some View {
        HStack(spacing: 0) {
            Rectangle().fill(Color(hex: "#1F4FB5")).frame(width: height * 0.34)
            Text(code)
                .font(.system(size: height * 0.6, weight: .heavy))
                .tracking(0.6)
                .foregroundStyle(Color(hex: "#111111"))
                .padding(.horizontal, height * 0.28)
        }
        .frame(height: height)
        .background(Color.white)
        .clipShape(RoundedRectangle(cornerRadius: height * 0.22, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: height * 0.22, style: .continuous).strokeBorder(Color(hex: "#111111"), lineWidth: 1))
        .accessibilityHidden(true)
    }
}

// MARK: - Tags on the building up close

/// a tag for each window kosh knows (a tenant, or a floor to let) hung off the building's right, a line to its window
struct FloorTags: View {
    let box: IsoBlock.Box
    /// from the building's block to the frame
    let cam: CGAffineTransform
    let size: CGSize
    let still: Bool
    let open: (TenantsView.Let) -> Void
    let more: () -> Void

    struct Spot: Identifiable {
        let id: String
        let l: TenantsView.Let?
        let p: Prop
        let u: PropUnit
        let dot: CGPoint?
        var y: CGFloat
    }

    static let w: CGFloat = 136
    static let h: CGFloat = 38
    static let gap: CGFloat = 6

    /// the tags and where they hang: each level with its window, nudged apart so none overlap; when more than fit,
    /// the late and due ones first and a "more below" tag for the rest
    static func spots(_ b: IsoBlock.Box, cam: CGAffineTransform, height: CGFloat) -> (spots: [Spot], hidden: Int) {
        var all: [Spot] = []
        var seen: Set<String> = []
        for (k, fl) in b.house.floors.enumerated() {
            let rects: [CGRect] = IsoPaint.panes(b, k, fl)
            for (j, w) in fl.windows.enumerated() where w.tenant != nil || w.light == .empty {
                guard let u = w.u else { continue }
                let r: CGRect = rects[j]
                let dot: CGPoint? = b.house.kind == .plot ? nil : IsoBlock.at(b.x + r.midX, b.y + b.d, b.h - r.midY).applying(cam)
                all.append(Spot(id: w.id, l: w.tenant, p: b.house.p, u: u, dot: dot, y: (dot?.y ?? height) - h / 2))
                if let t = w.tenant { seen.insert(t.id) }
            }
        }
        // tenants on floors above the six drawn: no window to point at
        for l in b.house.lets where !seen.contains(l.id) {
            all.append(Spot(id: l.id, l: l, p: l.p, u: l.u, dot: nil, y: height))
        }
        let room: Int = max(1, Int((height - 12) / (h + gap)))
        var shown: [Spot] = all
        var hidden: Int = 0
        if all.count > room {
            hidden = all.count - (room - 1)
            shown = Array(all.sorted { a, b in rank(a) < rank(b) }.prefix(room - 1))
        }
        shown.sort { $0.y < $1.y }
        // apart, top down; then back up from the bottom if they ran off it
        var y: CGFloat = 6
        for i in shown.indices {
            shown[i].y = max(shown[i].y, y)
            y = shown[i].y + h + gap
        }
        var floor: CGFloat = height - 6 - (hidden > 0 ? h + gap : 0)
        for i in shown.indices.reversed() {
            shown[i].y = min(shown[i].y, floor - h)
            floor = shown[i].y - gap
        }
        return (shown, hidden)
    }
    /// late first, then due, then the rest, then floors to let
    static func rank(_ s: Spot) -> Int {
        guard let l = s.l else { return 3 }
        return TenantsView.rank(l)
    }

    var body: some View {
        let placed: (spots: [Spot], hidden: Int) = Self.spots(box, cam: cam, height: size.height)
        let spots: [Spot] = placed.spots
        let hidden: Int = placed.hidden
        let right: CGFloat = IsoBlock.extent(box).applying(cam).maxX
        let x: CGFloat = min(right + 18, size.width - Self.w - 8)
        ZStack(alignment: .topLeading) {
            Canvas { ctx, _ in
                for s in spots {
                    guard let d = s.dot else { continue }
                    let ink: Color = RentWords.night(s.u)
                    var line = Path()
                    line.move(to: d)
                    line.addLine(to: CGPoint(x: x, y: s.y + Self.h / 2))
                    ctx.stroke(line, with: .color(ink.opacity(0.7)), lineWidth: 1)
                    ctx.fill(Path(ellipseIn: CGRect(x: d.x - 3.5, y: d.y - 3.5, width: 7, height: 7)), with: .color(ink))
                }
            }
            .allowsHitTesting(false)
            .accessibilityHidden(true)
            ForEach(Array(spots.enumerated()), id: \.element.id) { i, s in
                FloorTag(spot: s, still: still, delay: Motion.stagger(i)) {
                    if let l = s.l { open(l) } else { more() }
                }
                .offset(x: x, y: s.y)
            }
            if hidden > 0 {
                let word: String = "+" + String(hidden) + " more below"
                Button(action: more) {
                    Text(word)
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundStyle(Dusk.lilac)
                        .frame(width: Self.w, height: Self.h)
                        .background(Color(hex: "#14122C").opacity(0.84), in: RoundedRectangle(cornerRadius: 11, style: .continuous))
                }
                .buttonStyle(.press)
                .offset(x: x, y: size.height - 6 - Self.h)
            }
        }
    }
}

/// one tag: the floor, who, the rent and where it stands
struct FloorTag: View {
    let spot: FloorTags.Spot
    let still: Bool
    let delay: Double
    let tap: () -> Void
    @State private var shown = false

    var body: some View {
        let u: PropUnit = spot.u
        let who: String = spot.l == nil ? "To let" : (NudgeWords.name(u).isEmpty ? u.label : NudgeWords.name(u))
        let word: String = spot.l == nil ? "Empty" : RentWords.of(u, short: true).text
        let late: Bool = u.now?.st == "late"
        Button(action: tap) {
            VStack(alignment: .leading, spacing: 1) {
                HStack(spacing: 4) {
                    Text(Street.badge(spot.p, u)).foregroundStyle(Color(hex: "#A9A2CF"))
                    Text(who).foregroundStyle(Color.white).privacySensitive()
                }
                .font(.system(size: 12, weight: .bold))
                .lineLimit(1)
                HStack(spacing: 4) {
                    Text(spot.l == nil ? "" : Fmt.rupees(u.rent)).foregroundStyle(Dusk.lilac).monospacedDigit().privacySensitive()
                    Spacer(minLength: 2)
                    Text(word).fontWeight(.bold).foregroundStyle(RentWords.night(u))
                }
                .font(.system(size: 11))
                .lineLimit(1)
            }
            .padding(.horizontal, 9)
            .frame(width: FloorTags.w, height: FloorTags.h, alignment: .leading)
            .background(Color(hex: "#14122C").opacity(0.84), in: RoundedRectangle(cornerRadius: 11, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 11, style: .continuous).strokeBorder(late ? Dusk.red.opacity(0.55) : Color.white.opacity(0.14), lineWidth: 1))
            .contentShape(RoundedRectangle(cornerRadius: 11, style: .continuous))
        }
        .buttonStyle(.press)
        .opacity(shown ? 1 : 0)
        .offset(x: shown ? 0 : -6)
        .onAppear {
            if still { shown = true } else { withAnimation(Motion.large.delay(delay)) { shown = true } }
        }
        .accessibilityLabel(who + ", " + u.label + ", " + word)
        .accessibilityHint(spot.l == nil ? "Shows the floors below" : "Opens their row below")
    }
}

// MARK: - Painting the block

enum IsoPaint {
    static let leftWall = Color(hex: "#2E2752")
    static let rightWall = Color(hex: "#3E3468")
    static let roofTop = Color(hex: "#5A4B8A")
    static let roofIn = Color(hex: "#473C77")
    static let band = Color(hex: "#3A3166")
    static let bandLight = Color(hex: "#4A3F7A")

    static func poly(_ pts: [CGPoint]) -> Path {
        var p = Path()
        p.addLines(pts)
        p.closeSubpath()
        return p
    }
    static func at(_ x: CGFloat, _ y: CGFloat, _ z: CGFloat) -> CGPoint { IsoBlock.at(x, y, z) }

    /// an island: its slab, then its buildings; when one is flown to, the others fade and it's drawn again on top
    static func island(_ ctx: inout GraphicsContext, _ s: IsoWorld.Isle, house: String?, fade: CGFloat, t: Double) {
        slab(&ctx, s.block, s.theme)
        var chosen: IsoBlock.Box?
        for b in s.block.boxes {
            var c: GraphicsContext = ctx
            if b.house.id == house { chosen = b } else { c.opacity *= Double(1 - 0.84 * fade) }
            building(&c, b, t: t)
        }
        if let b = chosen, fade > 0.001 {
            var c: GraphicsContext = ctx
            c.opacity *= Double(fade)
            building(&c, b, t: t)
        }
    }

    /// the slab, its two edges, and a road in front of each row with its kerb and dashes
    static func slab(_ ctx: inout GraphicsContext, _ b: IsoBlock, _ th: IsoTheme) {
        let (x0, y0, x1, y1) = b.slab
        let t: CGFloat = IsoBlock.depth
        ctx.fill(poly([at(x0, y1, 0), at(x1, y1, 0), at(x1, y1, -t), at(x0, y1, -t)]), with: .color(th.left))
        ctx.fill(poly([at(x1, y0, 0), at(x1, y1, 0), at(x1, y1, -t), at(x1, y0, -t)]), with: .color(th.right))
        ctx.fill(poly([at(x0, y0, 0), at(x1, y0, 0), at(x1, y1, 0), at(x0, y1, 0)]), with: .color(th.top))
        for r in b.roads {
            ctx.fill(poly([at(r.x0, r.y, 0), at(r.x1, r.y, 0), at(r.x1, r.y + 2, 0), at(r.x0, r.y + 2, 0)]), with: .color(th.kerb))
            ctx.fill(poly([at(r.x0, r.y + 2, 0), at(r.x1, r.y + 2, 0), at(r.x1, r.y + IsoBlock.road, 0), at(r.x0, r.y + IsoBlock.road, 0)]), with: .color(th.road))
            var x: CGFloat = r.x0 + 4
            let mid: CGFloat = r.y + 2 + (IsoBlock.road - 2) / 2
            while x < r.x1 - 6 {
                ctx.fill(poly([at(x, mid - 0.6, 0), at(x + 7, mid - 0.6, 0), at(x + 7, mid + 0.6, 0), at(x, mid + 0.6, 0)]), with: .color(th.dash))
                x += 14
            }
        }
    }

    static func building(_ ctx: inout GraphicsContext, _ b: IsoBlock.Box, t: Double) {
        let h: StreetHouse = b.house
        let top: CGFloat = b.h
        // a soft shadow thrown away from the moon (down and to the left)
        ctx.drawLayer { l in
            l.addFilter(.blur(radius: 3))
            l.fill(poly([at(b.x, b.y + b.d, 0), at(b.x + b.w, b.y + b.d, 0), at(b.x + b.w - 8, b.y + b.d + 14, 0), at(b.x - 8, b.y + b.d + 14, 0)]),
                   with: .color(Color(hex: "#07051A").opacity(0.45)))
        }
        if h.kind == .plot {
            plot(&ctx, b)
            return
        }
        // the side facing the moon (x = x + w, along y), lit; the long front (y = y + d, along x), in shade
        face(&ctx, origin: at(b.x + b.w, b.y + b.d, top), along: CGVector(dx: IsoBlock.cos, dy: -IsoBlock.sin)) { f in
            f.fill(Path(CGRect(x: 0, y: 0, width: b.d, height: top)), with: .color(rightWall))
            side(&f, b, t: t)
        }
        face(&ctx, origin: at(b.x, b.y + b.d, top), along: CGVector(dx: IsoBlock.cos, dy: IsoBlock.sin)) { f in
            f.fill(Path(CGRect(x: 0, y: 0, width: b.w, height: top)), with: .color(leftWall))
            front(&f, b, t: t)
        }
        if h.kind == .house { gable(&ctx, b) } else { flatRoof(&ctx, b) }
    }

    /// draws on one wall in its own flat coordinates: x across the wall, y down from its top
    static func face(_ ctx: inout GraphicsContext, origin: CGPoint, along: CGVector, draw: (inout GraphicsContext) -> Void) {
        ctx.drawLayer { l in
            l.concatenate(CGAffineTransform(a: along.dx, b: along.dy, c: 0, d: 1, tx: origin.x, ty: origin.y))
            draw(&l)
        }
    }

    /// where the windows of one floor sit on the long front, in the wall's own coordinates (k: the floor's place, top first)
    static func panes(_ b: IsoBlock.Box, _ k: Int, _ fl: StreetHouse.Floor) -> [CGRect] {
        let lip: CGFloat = b.house.kind == .house ? 0 : IsoBlock.parapet
        let y0: CGFloat = lip + CGFloat(k) * IsoBlock.floor
        let m: Int = max(1, fl.windows.count)
        let door: Bool = b.house.kind == .house && fl.level == 0
        let room: CGFloat = b.w - 10 - (door ? 12 : 0)
        let gap: CGFloat = m > 4 ? 2.5 : 4
        let ww: CGFloat = max(3, (room - CGFloat(m - 1) * gap) / CGFloat(m))
        return fl.windows.indices.map { j in CGRect(x: 5 + CGFloat(j) * (ww + gap), y: y0 + 4, width: ww, height: IsoBlock.floor - 8) }
    }

    /// the long front: a band between floors, and the tenants' windows on each floor
    static func front(_ f: inout GraphicsContext, _ b: IsoBlock.Box, t: Double) {
        let h: StreetHouse = b.house
        let lip: CGFloat = h.kind == .house ? 0 : IsoBlock.parapet
        if lip > 0 {
            f.fill(Path(CGRect(x: 0, y: 0, width: b.w, height: lip)), with: .color(Color(hex: "#352D5C")))
            f.fill(Path(CGRect(x: 0, y: 0, width: b.w, height: 1)), with: .color(Color(hex: "#7B6AB0")))
        }
        for (k, fl) in h.floors.enumerated() {
            let y0: CGFloat = lip + CGFloat(k) * IsoBlock.floor
            if k > 0 { f.fill(Path(CGRect(x: 0, y: y0 - 1, width: b.w, height: 2)), with: .color(band)) }
            for (r, w) in zip(panes(b, k, fl), fl.windows) { pane(&f, r, w.light, t: t) }
            if fl.windows.contains(where: { $0.shop }) {
                // an awning over the shops
                f.fill(Path(CGRect(x: 3, y: y0 + 1.5, width: b.w - 6, height: 2.6)), with: .color(Color(hex: "#A44E3C")))
                var sx: CGFloat = 3
                while sx < b.w - 6 {
                    f.fill(Path(CGRect(x: sx, y: y0 + 1.5, width: 2, height: 2.6)), with: .color(Color(hex: "#CDB18E")))
                    sx += 4
                }
            }
            if h.kind == .house && fl.level == 0 {
                f.fill(Path(CGRect(x: b.w - 14, y: y0 + 4, width: 8, height: IsoBlock.floor - 4)), with: .color(Color(hex: "#1C1734")))
                f.fill(Path(ellipseIn: CGRect(x: b.w - 17, y: y0 + 5, width: 2.4, height: 2.4)), with: .color(Color(hex: "#FFEDB5")))
            }
        }
    }

    /// the lit side: one window a floor, in the light of that floor's last window
    static func side(_ f: inout GraphicsContext, _ b: IsoBlock.Box, t: Double) {
        let h: StreetHouse = b.house
        let lip: CGFloat = h.kind == .house ? 0 : IsoBlock.parapet
        if lip > 0 {
            f.fill(Path(CGRect(x: 0, y: 0, width: b.d, height: lip)), with: .color(Color(hex: "#463B72")))
            f.fill(Path(CGRect(x: 0, y: 0, width: b.d, height: 1)), with: .color(Color(hex: "#8C7BC0")))
        }
        for (k, fl) in h.floors.enumerated() {
            let y0: CGFloat = lip + CGFloat(k) * IsoBlock.floor
            if k > 0 { f.fill(Path(CGRect(x: 0, y: y0 - 1, width: b.d, height: 2)), with: .color(bandLight)) }
            let light: StreetLight = fl.windows.last?.light ?? .neighbour
            let r: CGRect = CGRect(x: b.d * 0.3, y: y0 + 4, width: b.d * 0.4, height: IsoBlock.floor - 8)
            pane(&f, r, light, t: t)
        }
    }

    /// a pane in its light, with its glow; a late one breathes
    static func pane(_ f: inout GraphicsContext, _ r: CGRect, _ light: StreetLight, t: Double) {
        switch light {
        case .paid:
            f.drawLayer { l in
                l.addFilter(.blur(radius: 2.5))
                l.fill(Path(r.insetBy(dx: -1.5, dy: -1.5)), with: .color(Dusk.gold.opacity(0.5)))
            }
            f.fill(Path(r), with: .linearGradient(Gradient(colors: [Color(hex: "#FFEDB5"), Color(hex: "#FFD66B"), Color(hex: "#FFC23D")]),
                                                  startPoint: CGPoint(x: r.midX, y: r.minY), endPoint: CGPoint(x: r.midX, y: r.maxY)))
        case .late:
            let breath: Double = 0.5 + 0.5 * Foundation.sin(t * 2 * .pi / 1.2)
            f.drawLayer { l in
                l.addFilter(.blur(radius: 2.5 + 1.5 * breath))
                l.fill(Path(r.insetBy(dx: -2, dy: -2)), with: .color(Dusk.red.opacity(0.3 + 0.55 * breath)))
            }
            f.fill(Path(r), with: .radialGradient(Gradient(colors: [Color(hex: "#FF8A70"), Color(hex: "#E0442E"), Color(hex: "#B8301C")]),
                                                  center: CGPoint(x: r.midX, y: r.minY + r.height * 0.62), startRadius: 0, endRadius: max(r.width, r.height) * 0.8))
        case .due:
            f.fill(Path(r), with: .color(Color(hex: "#8E6C72")))
        case .family:
            f.fill(Path(r), with: .color(Color(hex: "#A9C1FF")))
        case .empty:
            f.fill(Path(r), with: .color(Dusk.shutter))
            var y: CGFloat = r.minY + 1
            while y < r.maxY {
                f.fill(Path(CGRect(x: r.minX, y: y, width: r.width, height: 0.7)), with: .color(Dusk.slat))
                y += 2
            }
        case .waiting, .neighbour:
            f.fill(Path(r), with: .color(Color(hex: "#3A3462")))
        }
    }

    /// a flat roof: its top, a parapet's inner edge, and a water tank on its back corner
    static func flatRoof(_ ctx: inout GraphicsContext, _ b: IsoBlock.Box) {
        let z: CGFloat = b.h
        ctx.fill(poly([at(b.x, b.y, z), at(b.x + b.w, b.y, z), at(b.x + b.w, b.y + b.d, z), at(b.x, b.y + b.d, z)]), with: .color(roofTop))
        let i: CGFloat = 2.5
        ctx.fill(poly([at(b.x + i, b.y + i, z), at(b.x + b.w - i, b.y + i, z), at(b.x + b.w - i, b.y + b.d - i, z), at(b.x + i, b.y + b.d - i, z)]), with: .color(roofIn))
        // the tank: a small box
        let tx: CGFloat = b.x + 5, ty: CGFloat = b.y + 4, tw: CGFloat = 9, td: CGFloat = 8, th: CGFloat = 8
        ctx.fill(poly([at(tx, ty + td, z), at(tx + tw, ty + td, z), at(tx + tw, ty + td, z + th), at(tx, ty + td, z + th)]), with: .color(Color(hex: "#15122A")))
        ctx.fill(poly([at(tx + tw, ty, z), at(tx + tw, ty + td, z), at(tx + tw, ty + td, z + th), at(tx + tw, ty, z + th)]), with: .color(Color(hex: "#211C3C")))
        ctx.fill(poly([at(tx, ty, z + th), at(tx + tw, ty, z + th), at(tx + tw, ty + td, z + th), at(tx, ty + td, z + th)]), with: .color(Color(hex: "#2E2850")))
    }

    /// a house's clay roof: the ridge runs along the street, its gable end faces the moon
    static func gable(_ ctx: inout GraphicsContext, _ b: IsoBlock.Box) {
        let z: CGFloat = b.h, r: CGFloat = b.roof, o: CGFloat = 3
        let mid: CGFloat = b.y + b.d / 2
        let back: Path = poly([at(b.x - o, b.y - o, z), at(b.x + b.w + o, b.y - o, z), at(b.x + b.w + o, mid, z + r), at(b.x - o, mid, z + r)])
        let front: Path = poly([at(b.x - o, mid, z + r), at(b.x + b.w + o, mid, z + r), at(b.x + b.w + o, b.y + b.d + o, z), at(b.x - o, b.y + b.d + o, z)])
        let end: Path = poly([at(b.x + b.w, b.y, z), at(b.x + b.w, b.y + b.d, z), at(b.x + b.w, mid, z + r)])
        ctx.fill(back, with: .color(Color(hex: "#9C5038")))
        ctx.fill(end, with: .color(Color(hex: "#3E3468")))
        ctx.fill(front, with: .color(Color(hex: "#6E3224")))
        var p = Path()
        p.move(to: at(b.x - o, mid, z + r))
        p.addLine(to: at(b.x + b.w + o, mid, z + r))
        ctx.stroke(p, with: .color(Color(hex: "#D07E5E").opacity(0.7)), lineWidth: 0.8)
        // a chimney
        let cx: CGFloat = b.x + b.w * 0.7, cy: CGFloat = mid - 4
        ctx.fill(poly([at(cx, cy + 5, z + r - 2), at(cx + 5, cy + 5, z + r - 2), at(cx + 5, cy + 5, z + r + 8), at(cx, cy + 5, z + r + 8)]), with: .color(Color(hex: "#5E2C20")))
        ctx.fill(poly([at(cx + 5, cy, z + r - 2), at(cx + 5, cy + 5, z + r - 2), at(cx + 5, cy + 5, z + r + 8), at(cx + 5, cy, z + r + 8)]), with: .color(Color(hex: "#7A3A2A")))
    }

    /// land: a fenced plot
    static func plot(_ ctx: inout GraphicsContext, _ b: IsoBlock.Box) {
        let pts: [CGPoint] = [at(b.x, b.y, 0), at(b.x + b.w, b.y, 0), at(b.x + b.w, b.y + b.d, 0), at(b.x, b.y + b.d, 0)]
        ctx.fill(poly(pts), with: .color(Color(hex: "#2A3A2E")))
        ctx.stroke(poly(pts), with: .color(Color(hex: "#C9C2E6").opacity(0.5)), style: StrokeStyle(lineWidth: 1, dash: [3, 2]))
    }
}
