import SwiftUI
import Charts

// MARK: - Property: the buildings, the tenants and the tax

struct PropertyTabView: View {
    @Environment(Store.self) private var store
    var body: some View {
        @Bindable var store = store
        NavigationStack(path: $store.propPath) {
            PropertyPage()
                .navigationDestination(for: Route.self) { route in RouteDestination(route: route, zoom: nil) }
        }
    }
}

struct PropertyPage: View {
    @Environment(Store.self) private var store
    var body: some View {
        @Bindable var store = store
        Group {
            switch store.propSub {
            case .overview: PropertyOverview()
            case .tenants: TenantsView()
            case .tax: PropertyTaxView()
            }
        }
        .subSlide(store.propSub)
        .barFollows()
        .whoseScope(store.whoseNote(store.who, total: store.snap.prop.props.count, theirs: store.properties(store.who).count,
                                    open: store.snap.prop.props.filter { ($0.whose ?? []).isEmpty }.count, thing: ("property", "properties")))
        .safeAreaInset(edge: .top, spacing: 0) {
            SubTabBar(selection: $store.propSub, arrange: .property)
        }
        // the state's portal, once you've read from it, is the row's own circle beside the rest
        .tabHeader("Property", add: store.live == nil ? [] : [
            HeaderAction(title: "Add a property", symbol: "house") { store.betaSheet = .property(nil) },
        ], extra: usedPortal.map { st in
            HeaderAction(title: "Read again from " + (LiveSession.portal(for: st)?.name ?? st), symbol: "building.columns") { store.betaSheet = .portal(st) }
        })
    }

    /// the portal you've already used, if any: a small button rather than a card
    var usedPortal: String? {
        guard let live = store.live else { return nil }
        return PropertyPage.portalStates(live).first { PropertyPage.portalUsed(live, $0) }
    }

    /// the states your properties are in that kosh has a portal reader for
    static func portalStates(_ live: LiveSession) -> [String] {
        let s = Array(Set(live.properties.map(\.state).filter { LiveSession.portal(for: $0) != nil })).sorted()
        return s.isEmpty ? ["Haryana"] : s
    }
    /// read at least once from that state's portal
    static func portalUsed(_ live: LiveSession, _ state: String) -> Bool {
        live.properties.contains { $0.state == state && !($0.portalReadAt ?? "").isEmpty }
    }
}

/// months from one yyyy-MM to another
func monthsBetween(_ a: String, _ b: String) -> Int {
    func parts(_ s: String) -> (Int, Int)? {
        let p = s.prefix(7).split(separator: "-").compactMap { Int($0) }
        return p.count == 2 ? (p[0], p[1]) : nil
    }
    guard let x = parts(a), let y = parts(b) else { return 0 }
    return (y.0 * 12 + y.1) - (x.0 * 12 + x.1)
}

struct PropertyOverview: View {
    @Environment(Store.self) private var store
    var body: some View {
        let P = store.propBook(store.who)
        let lets = P.props.flatMap { $0.units }.filter { $0.status == "let" }
        let rent = lets.reduce(0) { $0 + $1.rent }
        ScrollView {
            VStack(alignment: .leading, spacing: 28) {
                if store.live != nil { Intro.property() }
                if store.live != nil && P.props.isEmpty {
                    BetaEmpty(sym: "building.2.fill", title: "No properties yet", text: "Add a property and the state it’s in. kosh shows that state’s tax portal and what ID it needs, and tracks rent if you let it out.", add: "Add property") { store.betaSheet = .property(nil) }
                }
                if let live = store.live {
                    if let gone = live.lastRemoved {
                        HStack(spacing: 10) {
                            Image(systemName: "trash").foregroundStyle(.secondary)
                            Text("Removed \(gone.short.isEmpty ? gone.name : gone.short)").font(.subheadline).lineLimit(1)
                            Spacer(minLength: 6)
                            Button("Undo") { withAnimation(Motion.open) { live.undoRemove() } }.font(.subheadline.weight(.semibold))
                        }
                        .padding(14)
                        .background(CardFill(), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                    }
                    // the portal, as a card only until it has been used
                    ForEach(PropertyPage.portalStates(live).filter { !PropertyPage.portalUsed(live, $0) }, id: \.self) { st in PortalConnectCard(state: st) }
                }
                // rent past its usual day, leases ending (TabSmarts.swift): the household's
                if store.who == .family, !P.props.isEmpty, let s = store.snap.smarts?.property { TabSmartLine(line: s.line, notes: s.notes ?? []) }
                if !P.props.isEmpty || store.live == nil {
                    PlanStack(.propOverview, spacing: 28) { id in
                        switch id {
                        case "head": PropertyHead(P: P, lets: lets.count, rent: rent)
                        case "alerts": alerts(P)
                        case "props":
                            VStack(alignment: .leading, spacing: 28) {
                                ForEach(P.props) { p in PropCard(p: p) }
                            }
                        case "events":
                            if !P.events.isEmpty {
                                VStack(alignment: .leading, spacing: 12) {
                                    SectionHeader(title: "What changes when")
                                    EventTimeline(events: P.events)
                                }
                            }
                        default: EmptyView()
                        }
                    }
                }
            }
            .padding(.horizontal, 20)
            .padding(.top, 12)
            .padding(.bottom, 36)
        }
    }

    @ViewBuilder func alerts(_ P: PropertyBook) -> some View {
        let late = P.props.flatMap { p in p.units.filter { $0.now?.st == "late" }.map { (p, $0) } }
        if !late.isEmpty {
            Button {
                withAnimation(Motion.open) { store.propSub = .tenants }
            } label: {
                HStack(spacing: 10) {
                    Image(systemName: "exclamationmark.triangle.fill")
                    Text(late.count == 1 ? "\(late[0].1.tenant.isEmpty ? late[0].0.short + " · " + late[0].1.label : late[0].1.tenant): rent is \(late[0].1.now?.late ?? 0) day\((late[0].1.now?.late ?? 0) == 1 ? "" : "s") late" : "\(late.count) rents are late")
                        .multilineTextAlignment(.leading)
                    Spacer(minLength: 0)
                    Image(systemName: "chevron.right").font(.footnote.weight(.semibold))
                }
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(Color.red)
                .padding(14)
                .background(Color.red.opacity(0.1), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            }
            .buttonStyle(.press)
        }
    }
}

struct PropCard: View {
    @Environment(Store.self) private var store
    @Environment(\.openURL) private var openURL
    let p: Prop

    var photo: UIImage? {
        guard let name = p.photo, !name.isEmpty else { return nil }
        return UIImage(contentsOfFile: LiveSession.photoFolder.appendingPathComponent(name).path)
    }

    var body: some View {
        // one card per property: the photo as a cover with the name on it, the floors as rows, then land and tax
        VStack(alignment: .leading, spacing: 10) {
            VStack(spacing: 0) {
                PropCover(p: p, photo: photo)
                PropFloors(p: p)
                // its rent over the twelve months to this one, where a floor is let
                if let log = p.rentLog {
                    Rectangle().fill(Color.primary.opacity(0.08)).frame(height: 0.5).padding(.horizontal, 16)
                    PropRentLine(log: log)
                }
                Rectangle().fill(Color.primary.opacity(0.08)).frame(height: 0.5).padding(.horizontal, 16)
                PropMetrics(p: p)
            }
            .background(CardFill())
            .clipShape(RoundedRectangle(cornerRadius: 26, style: .continuous))
            .contentShape(.contextMenuPreview, RoundedRectangle(cornerRadius: 26, style: .continuous))
            .contextMenu { PropMenuItems(p: p) }
            if store.live != nil, (p.portalReadAt ?? "").isEmpty, let st = p.state, !st.isEmpty, let portal = LiveSession.portal(for: st, city: p.city ?? "") {
                // not read from the portal yet: one quiet link under the card (its city's own portal, where kosh knows one)
                Button { store.betaSheet = .portal(st + "|" + (p.city ?? "")) } label: {
                    Label("Look it up on \(portal.name)", systemImage: "arrow.up.right.square").font(.subheadline.weight(.medium))
                }
                .buttonStyle(.press)
                .foregroundStyle(Color.kosh)
                .padding(.leading, 4)
            } else if store.live != nil, (p.portalReadAt ?? "").isEmpty, let link = p.portal, !link.isEmpty, let url = URL(string: link) {
                Button { openURL(url) } label: {
                    Label("Open \(p.portalName ?? "the tax portal")", systemImage: "arrow.up.right.square").font(.subheadline.weight(.medium))
                }
                .buttonStyle(.press)
                .foregroundStyle(Color.kosh)
                .padding(.leading, 4)
            }
        }
    }
}

/// what a property is, as an SF Symbol
enum PropLook {
    static func symbol(_ p: Prop) -> String {
        switch BuildingArt.kind(p) {
        case .house: return "house.fill"
        case .shop: return "storefront.fill"
        case .flats: return "building.2.fill"
        case .office: return "building.fill"
        case .plot: return "square.dashed"
        }
    }
    static func floorWord(_ i: Int) -> String {
        switch i {
        case 0: return "Ground floor"
        case 1: return "First floor"
        case 2: return "Second floor"
        case 3: return "Third floor"
        default: return "Floor \(i)"
        }
    }
}

/// the cover: the photo filling the frame (or a graphite field with the kind's symbol), the name on it
struct PropCover: View {
    @Environment(Store.self) private var store
    let p: Prop
    let photo: UIImage?
    var body: some View {
        let h: CGFloat = photo == nil ? 128 : 196
        ZStack(alignment: .bottomLeading) {
            if let img = photo {
                Color.clear
                    .overlay { Image(uiImage: img).resizable().scaledToFill() }
                    .clipped()
                    .privacySensitive()
            } else {
                LinearGradient(colors: [Color(hex: "#3A3A3C"), Color(hex: "#1C1C1E")], startPoint: .topLeading, endPoint: .bottomTrailing)
                    .overlay(alignment: .topTrailing) {
                        Image(systemName: PropLook.symbol(p)).font(.system(size: 72, weight: .regular))
                            .foregroundStyle(Color.white.opacity(0.10)).padding(.top, 14).padding(.trailing, 18)
                    }
            }
            LinearGradient(stops: [.init(color: .clear, location: 0.35), .init(color: .black.opacity(0.62), location: 1)], startPoint: .top, endPoint: .bottom)
            VStack(alignment: .leading, spacing: 3) {
                Text(p.short).font(.title3.weight(.bold)).foregroundStyle(.white)
                    .lineLimit(2).fixedSize(horizontal: false, vertical: true)
                Text(PropCover.subtitle(p)).font(.subheadline).foregroundStyle(.white.opacity(0.82)).lineLimit(1)
            }
            .padding(.horizontal, 16).padding(.bottom, 14).padding(.trailing, 56)
        }
        .frame(height: h)
        .frame(maxWidth: .infinity)
        .overlay(alignment: .topLeading) {
            Label(p.type.isEmpty ? "Property" : p.type, systemImage: PropLook.symbol(p))
                .font(.caption.weight(.semibold)).foregroundStyle(.white)
                .padding(.horizontal, 10).padding(.vertical, 6)
                .background(.ultraThinMaterial, in: Capsule())
                .environment(\.colorScheme, .dark)
                .padding(12)
        }
        .overlay(alignment: .topTrailing) {
            if store.live != nil {
                Menu { PropMenuItems(p: p) } label: {
                    Image(systemName: "ellipsis").font(.body.weight(.semibold)).foregroundStyle(.white)
                        .frame(width: 34, height: 34)
                        .background(.ultraThinMaterial, in: Circle())
                        .environment(\.colorScheme, .dark)
                }
                .accessibilityLabel("More for \(p.short)")
                .padding(12)
            }
        }
    }
    /// "House · 516 sq yd · Sector 10"
    static func subtitle(_ p: Prop) -> String {
        var bits: [String] = []
        if let sq = p.plotSqYd, sq > 0 { bits.append(Fmt.inr(sq) + " sq yd") }
        else if let a = p.plotArea, !a.isEmpty { bits.append(a) }
        if let c = p.city, !c.isEmpty { bits.append(c) }
        let n = p.units.count
        if n > 1 { bits.append("\(n) floors") }
        return bits.isEmpty ? (p.type.isEmpty ? "Property" : p.type) : bits.joined(separator: " · ")
    }
}

/// the property's actions, in its … menu and on a long press
struct PropMenuItems: View {
    @Environment(Store.self) private var store
    @Environment(\.openURL) private var openURL
    let p: Prop
    var body: some View {
        if store.live != nil {
            Button { store.betaSheet = .property(p.uid ?? p.pid) } label: { Label("Edit details", systemImage: "pencil") }
        }
        Button { withAnimation(Motion.open) { store.propSub = .tenants } } label: { Label("Tenants and rent", systemImage: "person.2") }
        Button { withAnimation(Motion.open) { store.propSub = .tax } } label: { Label("Property tax", systemImage: "building.columns") }
        if store.live != nil, let st = p.state, !st.isEmpty, let portal = LiveSession.portal(for: st, city: p.city ?? "") {
            Button { store.betaSheet = .portal(st + "|" + (p.city ?? "")) } label: { Label("Open \(portal.name)", systemImage: "arrow.up.right.square") }
        } else if let link = p.portal, !link.isEmpty, let url = URL(string: link) {
            Button { openURL(url) } label: { Label("Open \(p.portalName ?? "the tax portal")", systemImage: "arrow.up.right.square") }
        }
    }
}

/// each floor as a row, top floor first: its mark, who uses it, the rent and this month's
struct PropFloors: View {
    @Environment(Store.self) private var store
    let p: Prop
    var body: some View {
        let order: [Int] = Array(p.units.indices.reversed())
        VStack(spacing: 0) {
            if order.isEmpty {
                let st = BuildingArt.uses(p).first ?? "self"
                HStack(spacing: 12) {
                    if BuildingArt.kind(p) == .plot {
                        Image(systemName: "square.dashed")
                            .font(.system(size: 20, weight: .medium))
                            .foregroundStyle(FloorUse.color(st))
                            .frame(width: 44, height: 44)
                            .background(FloorUse.color(st).opacity(0.12), in: RoundedRectangle(cornerRadius: 13, style: .continuous))
                    } else {
                        LiftMark(floor: 0, floors: 1, ink: FloorUse.color(st))
                    }
                    VStack(alignment: .leading, spacing: 1) {
                        Text(BuildingArt.kind(p) == .plot ? "Open plot" : FloorUse.word(st)).font(.body.weight(.medium))
                        if store.live != nil {
                            Text("Add the floors from Edit details to track rent").font(.footnote).foregroundStyle(.secondary)
                        }
                    }
                    Spacer(minLength: 0)
                }
                .padding(.horizontal, 16).padding(.vertical, 12)
            }
            ForEach(Array(order.enumerated()), id: \.element) { k, i in
                if k > 0 { Rectangle().fill(Color.primary.opacity(0.08)).frame(height: 0.5).padding(.leading, 72) }
                FloorRow(u: p.units[i], i: i, floors: p.units.count)
            }
        }
        .padding(.vertical, 4)
    }
}

struct FloorRow: View {
    @Environment(Store.self) private var store
    let u: PropUnit
    let i: Int
    var floors: Int = 1
    var body: some View {
        let st: String = u.status ?? (u.tenant.isEmpty ? "vacant" : "let")
        let mark: (String, Color)? = st == "let" ? FloorRow.status(u) : nil
        Button {
            if st == "let" { withAnimation(Motion.open) { store.propSub = .tenants } }
        } label: {
            HStack(spacing: 14) {
                LiftMark(floor: i, floors: max(floors, i + 1), ink: FloorRow.ink(u, st))
                VStack(alignment: .leading, spacing: 1) {
                    Text(st == "let" && !u.tenant.isEmpty ? u.tenant : (st == "self" ? "Family home" : "Vacant"))
                        .font(.body.weight(.medium)).foregroundStyle(st == "vacant" ? Color.secondary : Color.primary).lineLimit(1)
                    Text(u.label.isEmpty ? PropLook.floorWord(i) : u.label).font(.footnote).foregroundStyle(.secondary).lineLimit(1)
                }
                Spacer(minLength: 8)
                if st == "let" && u.rent > 0 {
                    VStack(alignment: .trailing, spacing: 1) {
                        Text(Fmt.rupees(u.rent)).font(.body.weight(.semibold)).monospacedDigit().foregroundStyle(Color.primary).privacySensitive()
                        if let mark { Text(mark.0).font(.footnote.weight(.medium)).foregroundStyle(mark.1) }
                    }
                }
            }
            .padding(.horizontal, 16).padding(.vertical, 11)
            .contentShape(Rectangle())
        }
        .buttonStyle(.press)
    }
    /// the floor's colour: this month's rent where it's let (received, due, late), the family's blue, grey when empty
    static func ink(_ u: PropUnit, _ st: String) -> Color {
        if st == "vacant" { return Color(hex: "#9A9AA2") }
        if st == "self" { return Color.kosh }
        switch u.now?.st ?? "" {
        case "booked": return Color(hex: "#2E9E57")
        case "late": return Color(hex: "#D9442E")
        case "due": return Color(hex: "#E08A1E")
        default: return Color(hex: "#2E9E57")
        }
    }
    /// this month's rent in a word or two: received, due on a day, or so many days late
    static func status(_ u: PropUnit) -> (String, Color)? {
        guard let n = u.now else { return nil }
        switch n.st {
        case "booked": return ("Received", Color.green)
        case "late": return ("\(n.late ?? 0) day\((n.late ?? 0) == 1 ? "" : "s") late", Color.red)
        case "due": return ("Due " + (n.due.map { Day.fmt($0, "d MMM") } ?? ""), Color.orange)
        default: return n.due.map { ("Next " + Day.fmt($0, "d MMM"), Color.secondary) }
        }
    }
}

/// land and tax side by side, then who owns it and any charge on it, quietly
struct PropMetrics: View {
    @Environment(Store.self) private var store
    let p: Prop
    var body: some View {
        let due: Double = PropertyTaxView.due(p)
        let worth: Double = p.worth ?? 0
        let tax: (String, Color, String?) = PropMetrics.tax(p, due: due)
        let taxLabel: String = p.taxNow.map { "TAX · " + TaxYearWords.fy($0.fy).uppercased() } ?? "PROPERTY TAX"
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 0) {
                metric("LAND VALUE", worth > 0 ? Fmt.words(worth) : "Add rate", worth > 0 ? Color.primary : Color.kosh, sym: worth > 0 ? nil : "plus.circle.fill") {
                    if store.live != nil { store.betaSheet = .property(p.uid ?? p.pid) }
                }
                Rectangle().fill(Color.primary.opacity(0.08)).frame(width: 0.5, height: 34).padding(.horizontal, 14)
                metric(taxLabel, tax.0, tax.1, sym: tax.2) {
                    withAnimation(Motion.open) { store.propSub = .tax }
                }
            }
            .privacySensitive()
            let owner: String = p.owner ?? ""
            let charge: String = p.charge ?? ""
            if !owner.isEmpty || !charge.isEmpty {
                HStack(spacing: 14) {
                    if !owner.isEmpty { Label(owner, systemImage: "person.fill").lineLimit(1) }
                    if !charge.isEmpty { Label(charge.capitalized, systemImage: "lock.fill").lineLimit(1) }
                    Spacer(minLength: 0)
                }
                .font(.caption).foregroundStyle(.secondary)
                .labelStyle(PropCaptionLabel())
                .privacySensitive()
            }
        }
        .padding(16)
    }
    /// this year's tax in a word: what's due, paid, part paid, or no receipt yet (never "paid" on no evidence)
    static func tax(_ p: Prop, due: Double) -> (String, Color, String?) {
        if due > 0 && p.taxNow?.st != "paid" { return (Fmt.words(due) + " due", Color.orange, nil) }
        switch p.taxNow?.st ?? "" {
        case "paid": return ("Paid", Color.green, "checkmark.circle.fill")
        case "part": return ("Part paid", Color.orange, "circle.lefthalf.filled")
        default: return ("No receipt yet", Color.secondary, nil)
        }
    }

    func metric(_ label: String, _ value: String, _ tone: Color, sym: String?, tap: @escaping () -> Void) -> some View {
        Button(action: tap) {
            VStack(alignment: .leading, spacing: 3) {
                Text(label).font(.system(.caption2, weight: .semibold)).tracking(0.7).foregroundStyle(.secondary)
                HStack(spacing: 5) {
                    if let sym { Image(systemName: sym).font(.subheadline) }
                    Text(value).font(.headline).monospacedDigit().lineLimit(1).minimumScaleFactor(0.8)
                }
                .foregroundStyle(tone)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .contentShape(Rectangle())
        }
        .buttonStyle(.press)
    }
}

/// a caption label with its symbol small and close
struct PropCaptionLabel: LabelStyle {
    func makeBody(configuration: Configuration) -> some View {
        HStack(spacing: 4) {
            configuration.icon.font(.system(size: 9, weight: .semibold)).foregroundStyle(.tertiary)
            configuration.title
        }
    }
}

/// one property's dues, split by kind, as a thin bar
struct TaxBar: View {
    let p: Prop
    var height: CGFloat = 8
    var body: some View {
        let parts = PropertyTaxView.parts(p).filter { $0.1 > 0 }
        let total = max(1, parts.reduce(0) { $0 + $1.1 })
        GeometryReader { g in
            let gaps = CGFloat(max(0, parts.count - 1)) * 2
            HStack(spacing: 2) {
                ForEach(parts, id: \.0) { part in
                    Capsule().fill(PropertyTaxView.color(part.0).gradient)
                        .frame(width: max(4, (g.size.width - gaps) * CGFloat(part.1 / total)))
                }
            }
        }
        .frame(height: height)
    }
}

struct EventTimeline: View {
    let events: [PropEvent]
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            ForEach(Array(events.enumerated()), id: \.element.id) { i, e in
                HStack(alignment: .top, spacing: 14) {
                    VStack(spacing: 0) {
                        Circle().stroke(e.kind == "tax" ? Color.orange : (e.kind == "up" ? Color.green : Color.kosh), lineWidth: 2.5)
                            .frame(width: 12, height: 12).padding(.top, 4)
                        if i < events.count - 1 { Rectangle().fill(Color.hairline).frame(width: 1.5) }
                    }
                    VStack(alignment: .leading, spacing: 2) {
                        Text(e.place.isEmpty ? e.when : "\(e.when) · \(e.place)").font(.subheadline.weight(.semibold)).foregroundStyle(.secondary)
                        Text("\(e.what): \(e.detail)").privacySensitive()
                    }
                    .padding(.bottom, 16)
                }
            }
        }
        .card(16)
    }
}


/// the tab's figures, each said once: what the properties bring in, then tax, land and tenants in one card
struct PropertyHead: View {
    @Environment(Store.self) private var store
    let P: PropertyBook
    let lets: Int
    let rent: Double
    var body: some View {
        let worth: Double = P.worth ?? 0
        let n = P.props.count
        let priced: Int = P.props.filter { ($0.worth ?? 0) > 0 }.count
        let due: Double = P.props.reduce(0) { $0 + PropertyTaxView.due($1) }
        let late: Int = P.props.flatMap { $0.units }.filter { $0.now?.st == "late" }.count
        // nothing due: how many are known paid this financial year (never "paid up" on no evidence)
        let paidN: Int = P.props.filter { $0.taxNow?.st == "paid" }.count
        let taxWord: String = paidN == n ? "Paid" : (paidN > 0 ? String(paidN) + " of " + String(n) + " paid" : "No receipt")
        let heroRent = rent > 0 || worth <= 0
        VStack(alignment: .leading, spacing: 16) {
            VStack(alignment: .leading, spacing: 2) {
                Text(PropertyHead.count(n, lets)).font(.subheadline.weight(.medium)).foregroundStyle(.secondary)
                HStack(alignment: .firstTextBaseline, spacing: 6) {
                    Text(heroRent ? (rent > 0 ? Fmt.rupees(rent) : "No rent") : Fmt.words(worth))
                        .scaledFont(size: 40, weight: .bold, design: .rounded, relativeTo: .largeTitle).lineLimit(1).minimumScaleFactor(0.6)
                        .privacySensitive()
                    if heroRent && rent > 0 { Text("a month").font(.title3.weight(.semibold)).foregroundStyle(.secondary) }
                }
                Text(heroRent ? (rent > 0 ? Fmt.words(rent * 12) + " a year in rent" : "Nothing is let out yet") : "the land, at the rates set")
                    .font(.subheadline).foregroundStyle(.secondary).privacySensitive()
            }
            if rent > 0 { RentRoll(P: P) }
            HStack(spacing: 0) {
                cell("Tax", due > 0 ? Fmt.words(due) : taxWord, due > 0 ? "due now" : TaxYearWords.fy(P.fy), due > 0 ? Color.orange : (paidN == n ? Color.green : Color.secondary)) {
                    withAnimation(Motion.open) { store.propSub = .tax }
                }
                if heroRent {
                    divider
                    cell("Land", worth > 0 ? Fmt.words(worth) : "Set rates", priced < n ? "\(priced) of \(n) priced" : "at your rates", worth > 0 ? Color.primary : Color.kosh) {
                        if let first = P.props.first(where: { ($0.worth ?? 0) <= 0 }), store.live != nil { store.betaSheet = .property(first.uid ?? first.pid) }
                    }
                }
                divider
                cell("Tenants", lets > 0 ? String(lets) : "None", late > 0 ? "\(late) late" : (lets > 0 ? "on time" : "nothing let"), late > 0 ? Color.red : Color.primary) {
                    withAnimation(Motion.open) { store.propSub = .tenants }
                }
            }
            .padding(.vertical, 14)
            .background(CardFill(), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        }
    }

    static func count(_ n: Int, _ lets: Int) -> String {
        let a = n == 1 ? "One property" : Words.cap(Words.number(n)) + " properties"
        return lets > 0 ? a + " · " + Words.number(lets) + " floor" + (lets == 1 ? "" : "s") + " let" : a
    }

    var divider: some View { Rectangle().fill(Color.primary.opacity(0.08)).frame(width: 0.5, height: 38) }

    func cell(_ label: String, _ value: String, _ sub: String, _ tone: Color, tap: @escaping () -> Void) -> some View {
        Button(action: tap) {
            VStack(alignment: .leading, spacing: 2) {
                Text(label.uppercased()).font(.system(.caption2, design: .rounded, weight: .bold)).tracking(0.6).foregroundStyle(.secondary)
                Text(value).font(.system(.body, design: .rounded, weight: .bold)).foregroundStyle(tone)
                    .lineLimit(1).minimumScaleFactor(0.7).privacySensitive()
                Text(sub).font(.caption2).foregroundStyle(.secondary).lineLimit(1)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.horizontal, 14)
            .contentShape(Rectangle())
        }
        .buttonStyle(.press)
    }
}


/// the rent roll: one bar, a piece for each tenant in proportion to their rent, and who pays what under it
struct RentRoll: View {
    let P: PropertyBook
    @State private var grown = false
    static let palette: [Color] = [Color(hex: "#5E8BFF"), Color(hex: "#34C759"), Color(hex: "#30B0C7"), Color(hex: "#AF8CFF"), Color(hex: "#FF9F0A"), Color(hex: "#FF6482")]
    struct Piece: Identifiable { let id: String; let name: String; let rent: Double; let color: Color }
    static func pieces(_ P: PropertyBook) -> [Piece] {
        var out: [Piece] = []
        for p in P.props {
            for u in p.units where (u.status ?? (u.tenant.isEmpty ? "vacant" : "let")) == "let" && u.rent > 0 {
                out.append(Piece(id: p.pid + u.code + u.label, name: u.tenant.isEmpty ? p.short : u.tenant, rent: u.rent, color: .clear))
            }
        }
        out.sort { $0.rent > $1.rent }
        return out.enumerated().map { Piece(id: $0.element.id, name: $0.element.name, rent: $0.element.rent, color: palette[$0.offset % palette.count]) }
    }
    var body: some View {
        let ps: [Piece] = RentRoll.pieces(P)
        let total: Double = max(1, ps.reduce(0) { $0 + $1.rent })
        if ps.count > 1 {
            VStack(alignment: .leading, spacing: 10) {
                GeometryReader { g in
                    HStack(spacing: 3) {
                        ForEach(ps) { x in
                            RoundedRectangle(cornerRadius: 4, style: .continuous).fill(x.color.gradient)
                                .frame(width: shareWidth(g.size.width, gaps: ps.count - 1, gap: 3, part: x.rent, of: total, least: 4, grown: grown))
                        }
                    }
                }
                .frame(height: 12)
                LazyVGrid(columns: [GridItem(.flexible(), spacing: 10, alignment: .leading), GridItem(.flexible(), spacing: 10, alignment: .leading)], alignment: .leading, spacing: 8) {
                    ForEach(ps.prefix(6)) { x in
                        HStack(spacing: 6) {
                            Circle().fill(x.color).frame(width: 7, height: 7)
                            Text(x.name).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                            Spacer(minLength: 2)
                            Text(Fmt.short(x.rent)).font(.caption.weight(.semibold)).monospacedDigit()
                        }
                    }
                }
            }
            .privacySensitive()
            .onAppear { withAnimation(Motion.reveal.delay(0.1)) { grown = true } }
        }
    }
}

/// a floor's mark, read like a lift's floor display: the building's floors as a column of slots with this one
/// lit, its name beside it. When it comes into view the light rises from the ground to its floor, and the name
/// counts up with it.
struct LiftMark: View {
    /// 0 for the ground floor
    let floor: Int
    /// how many floors the building has
    let floors: Int
    let ink: Color
    var size: CGFloat = 44
    @State private var arrived = false
    @Environment(\.colorScheme) private var scheme
    @Environment(\.accessibilityReduceMotion) private var still

    static func label(_ f: Int) -> String { f == 0 ? "G" : String(f) }

    var body: some View {
        let n: Int = max(1, min(floors, 6))
        let at: Int = min(floor, n - 1)
        let rail: CGFloat = size - 16
        let gap: CGFloat = 2.5
        let slot: CGFloat = max(3, (rail - gap * CGFloat(n - 1)) / CGFloat(n))
        let shown: Int = arrived || still ? at : 0
        let litY: CGFloat = rail - CGFloat(shown + 1) * slot - CGFloat(shown) * gap
        let wash: Color = scheme == .dark ? ink.opacity(0.22) : ink.mix(with: .white, by: 0.87)
        let deep: Color = scheme == .dark ? ink.mix(with: .white, by: 0.25) : ink.mix(with: .black, by: 0.12)
        ZStack(alignment: .topLeading) {
            RoundedRectangle(cornerRadius: size * 0.3, style: .continuous).fill(wash)
            VStack(spacing: gap) {
                ForEach(0..<n, id: \.self) { _ in
                    Capsule().fill(deep.opacity(0.16)).frame(width: 4.5, height: slot)
                }
            }
            .offset(x: 9, y: 8)
            Capsule()
                .fill(deep)
                .frame(width: 4.5, height: slot)
                .shadow(color: ink.opacity(0.45), radius: 3)
                .offset(x: 9, y: 8 + litY)
            Text(Self.label(arrived || still ? floor : 0))
                .font(.system(size: size * 0.44, weight: .bold, design: .rounded))
                .foregroundStyle(deep)
                .contentTransition(.numericText(countsDown: false))
                .frame(width: size - 17, height: size)
                .offset(x: 15)
        }
        .frame(width: size, height: size)
        .onAppear {
            if at == 0 || arrived { arrived = true; return }
            withAnimation(Motion.reveal.delay(Motion.stagger(at, after: 0.15))) { arrived = true }
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(floor == 0 ? "Ground floor" : "Floor " + String(floor) + " of " + String(floors))
    }
}
