import SwiftUI

// MARK: - The store: what Wealth's screens read (WealthHome, WealthFunds, WealthDeposits)
//
// Every figure here is another function's (netClasses, holdings, bankBalance, propertyWorth, depositsAhead, yearly,
// the repeats, the brief's fund fees); this file only hands them to WealthBook.swift as plain values and says what
// each kind is called and where each thing sits. Nothing is guessed: a deposit with no maturity amount has none here,
// a fund whose plan its name doesn't say has no plan, money at a place kosh can't confirm is a bank is in no
// bank's insurance row.

extension Store {
    /// what the household's worth is in, biggest first (the bank's money counted in Deposits)
    func wealthKinds(_ p: Person) -> [(key: String, v: Double)] {
        WealthBook.kinds(netClasses(p).map { (c: ClassSum) -> (key: String, v: Double) in (key: c.key, v: c.v) })
    }

    /// the accounts whose balance counts for this person (bankBalance's own rule)
    func wealthAccounts(_ p: Person) -> [Account] {
        snap.accounts.filter { (a: Account) -> Bool in p.owns(a.owner) && a.balance != nil }
    }

    /// an account's money: its balance and what's held in it for an IPO (bankBalance's rule)
    static func accountWorth(_ a: Account) -> Double { (a.balance ?? 0) + (a.held ?? 0) }

    /// everything owned, one line a thing: each holding, each bank account with money in it, and the land (each
    /// person's share of it, the household's unnamed part as the family's)
    func wealthThings(_ p: Person) -> [WealthThing] {
        var out: [WealthThing] = []
        for h in holdings(p) where h.amt > 0 {
            let dep: String = h.dep ?? ""
            out.append(WealthThing(name: HoldingName.pretty(h.bank), kind: h.cls, who: h.person, at: WealthWhere.of(h), amt: h.amt,
                                   ref: dep.isEmpty ? "kind:" + h.cls : "dep:" + dep, ret: h.xirr, sleeve: WealthKind.sleeve(h)))
        }
        for a in wealthAccounts(p) {
            let v: Double = Self.accountWorth(a)
            if v > 0 { out.append(WealthThing(name: WealthWhere.accountName(a), kind: "dep", who: a.owner, at: a.name, amt: v, ref: "acct:" + a.id, sleeve: "fix")) }
        }
        let land: Double = propertyWorth(p)
        if land > 0 {
            if p == .family {
                var named: Double = 0
                for person in snap.people {
                    let w: Double = snap.prop.byWho?[person.id]?.worth ?? 0
                    if w > 0 { out.append(WealthThing(name: "Land", kind: "prop", who: person.id, at: "Property", amt: w, ref: "prop")); named += w }
                }
                if land - named >= 1 { out.append(WealthThing(name: "Land", kind: "prop", who: "family", at: "Property", amt: land - named, ref: "prop")) }
            } else {
                out.append(WealthThing(name: "Land", kind: "prop", who: p.id, at: "Property", amt: land, ref: "prop"))
            }
        }
        return out
    }

    /// what Holdings has a tab for, by its key: dep (deposits and the bank's money, as Overview's tile counts them), mf,
    /// ret, stk, gold, and other (insurance funds and anything else held, and what you added by hand)
    func holdTabValues(_ p: Person) -> [String: Double] {
        var v: [String: Double] = [:]
        for k in wealthKinds(p) {
            switch k.key {
            case "dep", "mf", "ret", "stk", "gold": v[k.key, default: 0] += k.v
            case "prop": break
            default: v["other", default: 0] += k.v
            }
        }
        // (something added by hand with no figure still has its place)
        if captures.contains(where: { $0.kind == "other" }) && (v["other"] ?? 0) <= 0 { v["other"] = 0.01 }
        if captures.contains(where: { $0.kind == "gold" }) && (v["gold"] ?? 0) <= 0 { v["gold"] = 0.01 }
        return v
    }

    /// the deposits on their way back, for the line from today: each deposit kosh counts, on its maturity day (or its
    /// month's first, when the advice gave a month), what it pays when its mail says, and what it's worth today
    func wealthRunwayItems(_ p: Person) -> [WealthMaturing] {
        var out: [WealthMaturing] = []
        for h in holdings(p) where h.cls == "dep" && h.amt > 0 {
            let day: String = h.matDay ?? (h.mat.map { $0 + "-01" } ?? "")
            guard day.count >= 10 else { continue }
            let d: DepositItem? = (h.dep ?? "").isEmpty ? nil : deposit(h.dep ?? "")
            let back: Double? = (d?.matAmt ?? 0) > 0 ? d?.matAmt : nil
            let put: Double? = (d?.amt ?? 0) > 0 ? d?.amt : nil
            out.append(WealthMaturing(id: h.id, name: HoldingName.pretty(h.bank), who: h.person, day: day, putIn: put,
                                      back: back, now: h.amt, rate: h.rate > 0 ? h.rate : nil))
        }
        return out
    }

    /// the deposits coming back, as the engine dated them (depositsAhead): what went in, what each pays at maturity,
    /// what it's worth today, its rate; only what the build knows
    func wealthMaturing(_ p: Person) -> [WealthMaturing] {
        depositsAhead(p).filter { $0.look != true }.map { (d: DepDateItem) -> WealthMaturing in
            WealthMaturing(id: d.key, name: d.title, who: d.person, day: d.d, putIn: d.amt, back: d.matAmt, now: d.now, rate: d.rate)
        }
    }

    /// the money at each bank, for DICGC: every bank account with money in it and every deposit, under the bank the
    /// directory knows it by; the rest (a company's deposit, a bond, a bank kosh doesn't know) apart, with its figure
    func wealthHeld(_ p: Person) -> (banks: [WealthHeld], elsewhere: Double, elsewhereN: Int) {
        var banks: [WealthHeld] = []
        var elsewhere: Double = 0
        var n: Int = 0
        for a in wealthAccounts(p) {
            let v: Double = Self.accountWorth(a)
            guard v > 0 else { continue }
            if let key = WealthWhere.bankKey(a.name) ?? WealthWhere.bankKey(a.bank) {
                banks.append(WealthHeld(bank: a.name, key: key, who: a.owner, amt: v))
            } else { elsewhere += v; n += 1 }
        }
        for h in holdings(p) where h.cls == "dep" && h.amt > 0 {
            let at: String = WealthWhere.of(h)
            if let key = WealthWhere.bankKey(at) ?? WealthWhere.bankKey(h.bank) {
                banks.append(WealthHeld(bank: at.isEmpty ? HoldingName.pretty(h.bank) : at, key: key, who: h.person, amt: h.amt))
            } else { elsewhere += h.amt; n += 1 }
        }
        return (banks, elsewhere, n)
    }

    /// the repeats that put money into investments, still running, for this person
    func investRepeats(_ p: Person) -> [Recurring] {
        snap.recurring.filter { (r: Recurring) -> Bool in r.kind == "sip" && r.gone == nil && r.lapsed == nil && p.owns(r.o ?? "me") }
    }

    /// what a Regular fund costs against its Direct plan a year, from AMFI's fee list (the brief's), when kosh has it
    func regularFee(_ h: Holding) -> FundFeesInfo.Row? {
        (snap.brief?.fees?.rows ?? []).first { $0.name == h.bank && $0.person == h.person }
    }
}

/// what each kind is called on Wealth, its colour, and its one quiet line
enum WealthKind {
    static func title(_ k: String) -> String {
        switch k {
        case "dep": return "Deposits"
        case "stk": return "Stocks"
        case "mf": return "Mutual funds"
        case "ret": return "Retirement"
        case "gold": return "Gold"
        case "ins": return "Insurance savings"
        case "prop": return "Land"
        default: return k.capitalized
        }
    }
    static func color(_ k: String) -> Color {
        switch k {
        case "dep", "bank": return Obsidian.health
        case "stk": return Obsidian.ulip
        case "mf": return Obsidian.term
        case "ret": return Obsidian.property
        case "gold": return Obsidian.savings
        case "ins": return Obsidian.motor
        default: return Obsidian.ink2
        }
    }
    /// equity, fixed income or neither, for "How concentrated": shares and equity or index funds are equity; deposits,
    /// EPF, PPF and debt funds fixed; gold, land, NPS, hybrid funds and insurance funds neither (they are both, or other)
    static func sleeve(_ h: Holding) -> String {
        switch h.cls {
        case "stk": return "eq"
        case "dep": return "fix"
        case "mf":
            switch FundKind.of(h.bank) {
            case .equity, .index: return "eq"
            case .debt: return "fix"
            default: return ""
            }
        case "ret":
            let t: String = h.type.uppercased()
            return t == "EPF" || t == "PPF" ? "fix" : ""
        default: return ""
        }
    }
    /// "4 more funds", "8 stocks": a block of a kind's things together, on the map
    static func blockNoun(_ k: String, _ n: Int, _ more: Bool) -> String {
        let one: [String: (String, String)] = ["dep": ("deposit", "deposits"), "mf": ("fund", "funds"), "stk": ("stock", "stocks"),
                                                "ret": ("retirement account", "retirement accounts"), "gold": ("gold holding", "gold holdings"),
                                                "ins": ("policy fund", "policy funds"), "prop": ("property", "properties")]
        let w: (String, String) = one[k] ?? ("thing", "things")
        return (more ? "\(n) more " : "\(n) ") + (n == 1 ? w.0 : w.1)
    }
    /// a fund's plan, only when its name says it
    static func plan(_ name: String) -> String? {
        if FundFees.isRegular(name) { return "Regular" }
        let w: [String] = FundFees.planWords(name)
        return w.contains("direct") || w.contains("dir") ? "Direct" : nil
    }
}

/// where a thing sits: the bank a deposit is at, the fund house a fund is from, the EPFO for an EPF account
enum WealthWhere {
    /// a bank account as a line: "Example Bank ••1234"
    static func accountName(_ a: Account) -> String {
        let last: String = a.last.trimmingCharacters(in: .whitespaces)
        return a.name + (last.isEmpty ? "" : " ••" + String(last.suffix(4)))
    }

    static func of(_ h: Holding) -> String {
        switch h.cls {
        case "dep", "ret":
            let t: String = h.type.uppercased()
            if t == "EPF" { return "EPFO" }
            if t == "NPS" { return "NPS" }
            if let i = h.inst, !i.isEmpty { return i }
            return bankPart(h.bank)
        case "mf":
            return fundHouse(h.bank)
        case "stk":
            return "Demat"
        case "gold":
            let n: String = h.bank.lowercased()
            if n.contains("sovereign gold") || n.range(of: #"\bsgb\b"#, options: .regularExpression) != nil { return "RBI bond" }
            if let open = h.bank.firstIndex(of: "(") { return String(h.bank[..<open]).trimmingCharacters(in: .whitespaces) }
            return ""
        default:
            return ""
        }
    }

    /// "Example Bank FD ••1234" → "Example Bank": the name with the product's words and the number taken off
    static func bankPart(_ name: String) -> String {
        var s: String = name
        s = s.replacingOccurrences(of: #"(?i)\b(fixed deposits?|recurring deposits?|deposits?|fd|rd|ppf|tdr|stdr|a/c|account)\b"#, with: " ", options: .regularExpression)
        s = s.replacingOccurrences(of: #"[•x×X*]{2,}\s*\d+|\b\d{3,}\b|#\s*\w+"#, with: " ", options: .regularExpression)
        s = s.replacingOccurrences(of: #"[\s·\-–,]+$"#, with: "", options: .regularExpression)
        return s.split(separator: " ").joined(separator: " ")
    }

    /// the bank a name is, by India's directory of banks (its site is the key, so "HDFC" and "HDFC Bank Ltd" are one);
    /// nil for anything the directory doesn't know as a bank (a company's deposit, a bond, a wallet)
    static func bankKey(_ name: String) -> String? {
        let n: String = name.trimmingCharacters(in: .whitespaces)
        guard !n.isEmpty, let e = Directory.shared.entry(for: n), e.kind == "bank", !e.site.isEmpty else { return nil }
        return e.site
    }

    /// the fund house a scheme is from, by the AMFI list kosh knows ("Parag Parikh Flexi Cap" → "Parag Parikh"), "" when
    /// it isn't one of them
    static func fundHouse(_ scheme: String) -> String {
        let n: String = " " + scheme.lowercased().replacingOccurrences(of: #"[^a-z0-9 ]"#, with: " ", options: .regularExpression) + " "
        for (k, _) in InstSites.fundHouses where n.hasPrefix(" " + k + " ") {
            return (houseNames[k] ?? k.split(separator: " ").map { $0.prefix(1).uppercased() + $0.dropFirst() }.joined(separator: " ")) + " MF"
        }
        return ""
    }
    static let houseNames: [String: String] = [
        "icici prudential": "ICICI Prudential", "icici pru": "ICICI Prudential", "absl": "Aditya Birla", "ppfas": "Parag Parikh", "hdfc": "HDFC",
        "sbi": "SBI", "dsp": "DSP", "uti": "UTI", "lic": "LIC", "hsbc": "HSBC", "pgim": "PGIM", "jm": "JM Financial", "iti": "ITI", "nj": "NJ",
        "idfc": "Bandhan", "baroda bnp": "Baroda BNP Paribas", "whiteoak": "WhiteOak", "bajaj finserv": "Bajaj Finserv",
    ]
}
