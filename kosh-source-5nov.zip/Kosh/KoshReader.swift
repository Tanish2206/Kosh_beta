import Foundation
import Accelerate
#if canImport(UIKit)
import UIKit
#endif
#if canImport(llama)
import llama
#endif

/// kosh-reader: a small model trained for one job, reading one money email into kosh's record.
/// It runs on the phone through llama.cpp (Metal), so it is free, private and works offline.
/// The bank rules still read first; this reads what they miss and checks what they read.
final class KoshReader {
    static let shared = KoshReader()

    /// what the model was trained to see first; must match the training notebook exactly
    static let instruction = "Read this email and write kosh's record as JSON.\n\n"

    /// Its answer is always one JSON object that starts with a known kind; the grammar makes any
    /// other output impossible, so a small model can't wander off into prose.
    static let kindGrammar = #"""
    root   ::= "{" ws "\"kind\":" ws kind ( "," ws pair )* ws "}"
    kind   ::= "\"txn\"" | "\"refund\"" | "\"confirm\"" | "\"statement\"" | "\"bill\"" | "\"policy\"" | "\"investment\"" | "\"property\"" | "\"balance\"" | "\"voucher\"" | "\"deposit\"" | "\"not_money\"" | "\"unsure\""
    pair   ::= string ":" ws value
    value  ::= string | number | object
    object ::= "{" ws ( string ":" ws value ( "," ws string ":" ws value )* )? ws "}"
    string ::= "\"" ( [^"\\\x7F\x00-\x1F] | "\\" ["\\/bfnrt] )* "\""
    number ::= "-"? [0-9]+ ( "." [0-9]+ )?
    ws     ::= [ ]?
    """#

    /// kosh-reader v4 and later answer in the reader's events ({"events":[…]}, nothing when the mail moves no money).
    /// The grammar has to be the shape the model was trained on: with the old one, nearly every token the model wanted
    /// was refused, each refusal cost a pass over the whole 248k-token vocabulary, and the answer ran to the limit.
    static let eventsGrammar = #"""
    root   ::= "{" ws "\"events\":" ws "[" ws ( event ( "," ws event )* )? ws "]" ws "}"
    event  ::= "{" ws "\"type\":" ws type ( "," ws pair )* ws "}"
    type   ::= "\"move\"" | "\"balance\"" | "\"statement\"" | "\"due\"" | "\"expect\"" | "\"order\"" | "\"trade\"" | "\"fund\"" | "\"ipo\"" | "\"dividend\"" | "\"deposit\"" | "\"policy\"" | "\"mandate\"" | "\"account\"" | "\"booking\"" | "\"loan\"" | "\"noise\""
    pair   ::= string ":" ws value
    value  ::= string | number | object | array | "true" | "false" | "null"
    object ::= "{" ws ( pair ( "," ws pair )* )? ws "}"
    array  ::= "[" ws ( value ( "," ws value )* )? ws "]"
    string ::= "\"" ( [^"\\\x7F\x00-\x1F] | "\\" ["\\/bfnrt] )* "\""
    number ::= "-"? [0-9]+ ( "." [0-9]+ )?
    ws     ::= [ ]?
    """#

    /// the loaded model answers in events (v4 on): its .prompt.json says so ("format": "events", or "run": "v4" and on),
    /// else its file name does ("…-v4.q4_k_m")
    private(set) var speaksEvents = false
    private static func eventsFormat(name: String, side: [String: String]?) -> Bool {
        if side?["format"] == "events" { return true }
        func ver(_ s: String) -> Int? {
            guard let r = s.range(of: #"(?:^|[-_ ])v(\d+)"#, options: .regularExpression) else { return nil }
            return Int(s[r].filter(\.isNumber))
        }
        if let run = side?["run"], let v = ver(run) { return v >= 4 }
        return (ver(name.lowercased()) ?? 0) >= 4
    }

    enum Failure: LocalizedError {
        case noModel, unavailable, load(String), tooLong, decode
        var errorDescription: String? {
            switch self {
            case .noModel: return "kosh-reader isn’t on this phone yet."
            case .unavailable: return "This build doesn’t include the reader."
            case .load(let s): return "Couldn’t open kosh-reader: \(s)"
            case .tooLong: return "That email is too long for the reader."
            case .decode: return "The reader stopped partway."
            }
        }
    }

    private let lock = NSLock()
    private(set) var modelName = ""

    // MARK: speed: the phone's GPU and more cores while kosh is on screen
    // iOS refuses GPU work from an app in the background (llama_decode then fails with -3), so the
    // reader runs on the GPU (Metal) only while kosh is on screen, and on two CPU cores otherwise.
    // Switching reloads the model (it's memory-mapped, so that takes about a second).
    private static let stateLock = NSLock()
    nonisolated(unsafe) private static var _onScreen = false   // CPU until kosh is known to be on screen
    nonisolated(unsafe) private static var watching = false
    /// kosh is on screen (active), so the GPU and more cores are allowed
    static var onScreen: Bool { stateLock.lock(); defer { stateLock.unlock() }; return _onScreen }
    /// iOS lent kosh's background task the GPU (iOS 26 continued task with .gpu, KeepGoing.swift)
    nonisolated(unsafe) private static var _bgGPU = false
    static func setBackgroundGPU(_ on: Bool) { stateLock.lock(); _bgGPU = on; stateLock.unlock() }
    private static var backgroundGPU: Bool { stateLock.lock(); defer { stateLock.unlock() }; return _bgGPU }
    /// the phone is on its charger (kept up to date on the main thread)
    nonisolated(unsafe) private static var _charging = false
    private static var charging: Bool { stateLock.lock(); defer { stateLock.unlock() }; return _charging }
    /// starts following kosh coming on and off screen (once)
    private static func watch() {
        stateLock.lock(); defer { stateLock.unlock() }
        if watching { return }
        watching = true
        #if canImport(UIKit)
        // where kosh is right now (asked on the main thread, without waiting for it)
        DispatchQueue.main.async {
            let active = UIApplication.shared.applicationState == .active
            UIDevice.current.isBatteryMonitoringEnabled = true
            let st = UIDevice.current.batteryState
            stateLock.lock(); _onScreen = active; _charging = st == .charging || st == .full; stateLock.unlock()
        }
        NotificationCenter.default.addObserver(forName: UIDevice.batteryStateDidChangeNotification, object: nil, queue: .main) { _ in
            let st = UIDevice.current.batteryState
            stateLock.lock(); _charging = st == .charging || st == .full; stateLock.unlock()
        }
        let nc = NotificationCenter.default
        nc.addObserver(forName: UIApplication.didBecomeActiveNotification, object: nil, queue: nil) { _ in
            stateLock.lock(); _onScreen = true; stateLock.unlock()
        }
        nc.addObserver(forName: UIApplication.willResignActiveNotification, object: nil, queue: nil) { _ in
            stateLock.lock(); _onScreen = false; stateLock.unlock()
        }
        nc.addObserver(forName: UIApplication.didEnterBackgroundNotification, object: nil, queue: nil) { _ in
            stateLock.lock(); _onScreen = false; stateLock.unlock()
            // off screen and nothing reading: the model's memory goes back to the phone (it loads again when needed)
            DispatchQueue.global(qos: .utility).async { shared.unloadIfIdle() }
        }
        nc.addObserver(forName: UIApplication.didReceiveMemoryWarningNotification, object: nil, queue: nil) { _ in
            // iOS is short of memory: let the model go, unless a pass is reading with it
            DispatchQueue.global(qos: .utility).async { shared.unloadIfIdle() }
        }
        #endif
    }
    /// the model currently sits on the GPU
    private var onGPU = false

    // MARK: how fast it reads (printed to Xcode's console, summed up on the Reading screen)
    private let statsLock = NSLock()
    private var stEmails = 0, stPromptTok = 0, stOutTok = 0, stReloads = 0, stGPU = 0
    private var stPrompt = 0.0, stWrite = 0.0, stLoad = 0.0
    func resetStats() {
        statsLock.lock(); defer { statsLock.unlock() }
        stEmails = 0; stPromptTok = 0; stOutTok = 0; stReloads = 0; stGPU = 0; stPrompt = 0; stWrite = 0; stLoad = 0
    }
    /// "27 emails, 8.4 s each (reading 6.1 s for ~610 words-pieces, writing 2.3 s), GPU 27/27, 1 reload"
    func summary() -> String? {
        statsLock.lock(); defer { statsLock.unlock() }
        guard stEmails > 0 else { return nil }
        let n = Double(stEmails)
        func f(_ x: Double) -> String { String(format: "%.1f", x) }
        return "kosh-reader: \(stEmails) emails, \(f((stPrompt + stWrite) / n)) s each "
            + "(taking in \(stPromptTok / stEmails) tokens: \(f(stPrompt / n)) s · writing \(stOutTok / stEmails) tokens: \(f(stWrite / n)) s) · "
            + "GPU \(stGPU)/\(stEmails) · \(threads) cores · \(stReloads) loads (\(f(stLoad)) s)"
    }
    private func note(promptTok: Int, outTok: Int, prompt: Double, write: Double, emails: Int, refusals: Int) {
        // (also kept in kosh's diagnostics, per email: how long, how many tokens, and how often the grammar refused)
        let n = Double(max(1, emails))
        Perf.shared.record("kosh-reader · ms per email (\(onGPU ? "GPU" : "CPU"), \(emails) at once)", ms: (prompt + write) / n * 1000)
        Perf.shared.record("kosh-reader · taking in, ms per email", ms: prompt / n * 1000)
        Perf.shared.record("kosh-reader · writing, ms per email", ms: write / n * 1000)
        Perf.shared.record("kosh-reader · tokens in per email", ms: Double(promptTok) / n)
        Perf.shared.record("kosh-reader · tokens out per email", ms: Double(outTok) / n)
        Perf.shared.record("kosh-reader · grammar refusals per email", ms: Double(refusals) / n)
        statsLock.lock(); stEmails += emails; stPromptTok += promptTok; stOutTok += outTok; stPrompt += prompt; stWrite += write
        if onGPU { stGPU += emails }; statsLock.unlock()
        print(String(format: "[kosh-reader] %@ · %d cores · in %d tok %.2fs (%.0f tok/s) · out %d tok %.2fs (%.1f tok/s)",
                     onGPU ? "GPU" : "CPU", threads, promptTok, prompt, Double(promptTok) / max(prompt, 0.001), outTok, write, Double(outTok) / max(write, 0.001)))
    }
    /// the GPU failed once this session (an op it can't run, or a load that failed): CPU from then on
    private var gpuBroken = false
    /// the GPU iOS lent in the background failed once: CPU in the background from then on
    private var bgGPUBroken = false
    /// where the reader should run right now: on screen, or in a background task iOS gave the GPU
    private var wantGPU: Bool { !gpuBroken && (Self.onScreen || (Self.backgroundGPU && !bgGPUBroken)) }
    /// cores to read with: four on screen; in the background four only while the phone is cool, or charging
    /// and not hot; otherwise two (cool and quiet). The heat pause in readerPass still stops it when warm.
    private var threads: Int32 {
        let four = Int32(max(2, min(4, ProcessInfo.processInfo.activeProcessorCount)))
        if Self.onScreen { return four }
        let heat = ProcessInfo.processInfo.thermalState
        if heat == .nominal || (Self.charging && heat == .fair) { return four }
        return 2
    }
    /// the whole vocabulary's scores, kept between emails (only needed when the grammar refuses the model's first choice)
    private var fullVocab = [llama_token_data]()
    /// the text around the email the model was trained on, from the notebook's <model>.prompt.json beside it
    private var turns: (before: String, after: String)? = nil
    #if canImport(llama)
    private var model: OpaquePointer?
    private var ctx: OpaquePointer?
    private var vocab: OpaquePointer?
    #endif

    /// where downloaded or imported models live (inside the app's own folder): made the first time it is asked for,
    /// then the same URL without touching the disk. Erase removes kosh's folder and calls folderGone()
    static var folder: URL {
        let f = LiveSession.folder.appendingPathComponent("models", isDirectory: true)
        folderLock.lock(); defer { folderLock.unlock() }
        if !folderMade {
            try? FileManager.default.createDirectory(at: f, withIntermediateDirectories: true)
            folderMade = true
        }
        return f
    }
    private static let folderLock = NSLock()
    nonisolated(unsafe) private static var folderMade = false
    /// the folder is gone (Erase removed kosh's folder): the next look makes it again
    static func folderGone() { folderLock.lock(); folderMade = false; folderLock.unlock() }

    /// the newest model on the phone: one copied in by the user, or one shipped inside the app
    static func installed() -> URL? {
        let fm = FileManager.default
        let own = (try? fm.contentsOfDirectory(at: folder, includingPropertiesForKeys: [.contentModificationDateKey]))?
            .filter { $0.pathExtension == "gguf" } ?? []
        let bundled = (Bundle.main.urls(forResourcesWithExtension: "gguf", subdirectory: nil) ?? [])
        // only kosh-reader files: any other model file in the folder is not the reader
        let all = (own + bundled).filter { $0.lastPathComponent.lowercased().hasPrefix("kosh-reader") }
        return all.max { a, b in
            let da = (try? a.resourceValues(forKeys: [.contentModificationDateKey]).contentModificationDate) ?? .distantPast
            let db = (try? b.resourceValues(forKeys: [.contentModificationDateKey]).contentModificationDate) ?? .distantPast
            return da < db
        }
    }

    /// whether the installed reader answers in events (v4 on), known from its file without loading it
    static var installedSpeaksEvents: Bool {
        guard let url = installed() else { return false }
        let side = url.deletingPathExtension().appendingPathExtension("prompt.json")
        let sideJSON = (try? Data(contentsOf: side)).flatMap { try? JSONSerialization.jsonObject(with: $0) as? [String: String] }
        return eventsFormat(name: url.deletingPathExtension().lastPathComponent, side: sideJSON)
    }

    static var available: Bool {
        #if canImport(llama)
        return installed() != nil
        #else
        return false
        #endif
    }

    /// copy a .gguf the user picked into the app's folder
    static func importModel(from url: URL) throws -> URL {
        let scoped = url.startAccessingSecurityScopedResource()
        defer { if scoped { url.stopAccessingSecurityScopedResource() } }
        // (a model's .prompt.json goes beside it; only a .gguf replaces the reader)
        let dest = folder.appendingPathComponent(url.lastPathComponent)
        try? FileManager.default.removeItem(at: dest)
        try FileManager.default.copyItem(at: url, to: dest)
        shared.unload()
        return dest
    }

    // MARK: who is using the model
    // a pass that reads with the model holds it (hold, then letGo when it ends): the model stays loaded between its
    // emails, and is let go once no pass holds it, so its few hundred MB aren't kept for nothing
    private let useLock = NSLock()
    private var users = 0
    /// a pass is about to read with the model: it stays loaded until the pass lets go
    func hold() { useLock.lock(); users += 1; useLock.unlock() }
    /// the pass is done with the model: let it go once nobody else holds it (off the calling thread)
    func letGo() {
        useLock.lock(); users = max(0, users - 1); let idle = users == 0; useLock.unlock()
        if idle { DispatchQueue.global(qos: .utility).async { self.unloadIfIdle() } }
    }
    /// lets go of the model only if no pass holds it and nothing is reading right now (never waits on a reading)
    func unloadIfIdle() {
        guard lock.try() else { return }
        defer { lock.unlock() }
        useLock.lock(); let idle = users == 0; useLock.unlock()
        if idle { releaseModel() }
    }

    /// loads the model if it isn't yet (takes the lock, so it can't cross a reading or an unload)
    func load() throws {
        lock.lock(); defer { lock.unlock() }
        try loadLocked()
    }

    /// (the caller holds the lock)
    private func loadLocked() throws {
        #if canImport(llama)
        Self.watch()
        if model != nil { return }
        guard let url = Self.installed() else { throw Failure.noModel }
        llama_backend_init()
        let gpu = wantGPU
        let loadStart = Date()
        var mp = llama_model_default_params()
        // all layers on the GPU while on screen; none (CPU only) otherwise
        mp.n_gpu_layers = gpu ? 999 : 0
        var loaded = llama_model_load_from_file(url.path, mp)
        if loaded == nil && gpu {
            // the GPU wouldn't take it: the CPU, for the rest of this session
            gpuBroken = true
            mp.n_gpu_layers = 0
            loaded = llama_model_load_from_file(url.path, mp)
        }
        guard let m = loaded else { throw Failure.load(url.lastPathComponent) }
        let loadTook = Date().timeIntervalSince(loadStart)
        statsLock.lock(); stReloads += 1; stLoad += loadTook; statsLock.unlock()
        print(String(format: "[kosh-reader] loaded on %@ in %.2fs", mp.n_gpu_layers > 0 ? "GPU" : "CPU", loadTook))
        let onGPUNow = mp.n_gpu_layers > 0
        var cp = llama_context_default_params()
        // (an email's text is cut to about 1,800 characters, ~600 tokens; v4's answers run to ~300 tokens on a busy mail)
        // (each of the lanes gets its own 2,048-token window; a recurrent model keeps one state per lane)
        cp.n_ctx = UInt32(2048 * Self.lanes)
        cp.n_seq_max = UInt32(Self.lanes)
        cp.kv_unified = false
        cp.n_batch = 2048
        cp.n_ubatch = 512
        cp.offload_kqv = onGPUNow
        cp.op_offload = onGPUNow
        cp.n_threads = threads
        cp.n_threads_batch = threads
        guard let c = llama_init_from_model(m, cp) else { llama_model_free(m); throw Failure.load("no context") }
        onGPU = onGPUNow
        model = m; ctx = c; vocab = llama_model_get_vocab(m)
        modelName = url.deletingPathExtension().lastPathComponent
        let side = url.deletingPathExtension().appendingPathExtension("prompt.json")
        let sideJSON = (try? Data(contentsOf: side)).flatMap { try? JSONSerialization.jsonObject(with: $0) as? [String: String] }
        if let o = sideJSON, let b = o["before"], let a = o["after"] { turns = (b, a) } else { turns = nil }
        speaksEvents = Self.eventsFormat(name: modelName, side: sideJSON)
        #else
        throw Failure.unavailable
        #endif
    }

    func unload() {
        lock.lock(); defer { lock.unlock() }
        releaseModel()
    }

    /// lets go of the model (the caller holds the lock, or nothing else is reading)
    private func releaseModel() {
        #if canImport(llama)
        if let c = ctx { llama_free(c) }
        if let m = model { llama_model_free(m) }
        ctx = nil; model = nil; vocab = nil
        #endif
        modelName = ""
        onGPU = false
        speaksEvents = false
    }

    /// One email in (the engine's localPrompt text), the model's JSON answer out. Greedy and
    /// grammar-bound, so the same email always gives the same answer.
    func read(_ input: String, maxTokens: Int = 400) throws -> String {
        lock.lock(); defer { lock.unlock() }
        #if canImport(llama)
        Self.watch()
        // kosh came on or went off screen since the model was loaded: load it where it should run now
        if model != nil && onGPU != wantGPU { releaseModel() }
        try loadLocked()
        do {
            return try readOnce(input, maxTokens: maxTokens)
        } catch Failure.decode where onGPU {
            // the GPU stopped partway: if kosh is still on screen the GPU can't run this model, so the CPU
            // from now on; if kosh just left the screen, iOS took the GPU away. Either way, again on the CPU.
            if Self.onScreen { gpuBroken = true } else if Self.backgroundGPU { bgGPUBroken = true }
            releaseModel()
            try loadLocked()
            return try readOnce(input, maxTokens: maxTokens)
        }
        #else
        throw Failure.unavailable
        #endif
    }

    // MARK: reading several emails at once
    /// how many emails are read side by side. Writing one token at a time leaves the phone's GPU (and the CPU's vector
    /// units) mostly waiting on memory; a token for each of four emails costs about what one did, so four emails go
    /// through in little more than the time of one. Each email keeps its own 2,048-token window and its own grammar.
    static let lanes = 4
    /// batched reading failed once this session: one email at a time from then on
    private var lanesBroken = false

    /// Several emails in, one answer (or failure) per email out, in order. Same greedy, grammar-bound reading as read().
    func readMany(_ inputs: [String], maxTokens: Int = 400) -> [Result<String, Error>] {
        if inputs.count <= 1 { return inputs.map { i in Result { try read(i, maxTokens: maxTokens) } } }
        #if canImport(llama)
        lock.lock()
        Self.watch()
        if model != nil && onGPU != wantGPU { releaseModel() }
        do { try loadLocked() } catch { lock.unlock(); return inputs.map { _ in .failure(error) } }
        if !lanesBroken {
            var out: [Result<String, Error>] = []
            var ok = true
            for start in stride(from: 0, to: inputs.count, by: Self.lanes) {
                let part = Array(inputs[start..<min(start + Self.lanes, inputs.count)])
                if let got = try? readLanes(part, maxTokens: maxTokens) { out += got } else { ok = false; break }
            }
            if ok { lock.unlock(); return out }
            // the phone refused a batch (the GPU taken away mid-way, or a build that can't): one at a time from here
            lanesBroken = true
            print("[kosh-reader] reading several at once failed: one email at a time from now on")
        }
        lock.unlock()
        #endif
        return inputs.map { i in Result { try read(i, maxTokens: maxTokens) } }
    }

    #if canImport(llama)
    /// the prompt's tokens, in the turns the model was trained in (the caller holds the lock)
    private func promptTokens(_ input: String, vocab: OpaquePointer) -> [llama_token]? {
        // the training chat template trims the user turn, so trim it here too
        let content = (Self.instruction + input).trimmingCharacters(in: .whitespacesAndNewlines)
        // each model reads in the turns it was trained in: Qwen3's (thinking off, as the training notebook writes them)
        // or Gemma's
        let prompt = turns.map { $0.before + content + $0.after } ?? (modelName.lowercased().contains("qwen")
            ? "<|im_start|>user\n" + content + "<|im_end|>\n<|im_start|>assistant\n<think>\n\n</think>\n\n"
            : "<start_of_turn>user\n" + content + "<end_of_turn>\n<start_of_turn>model\n")
        var tokens = [llama_token](repeating: 0, count: prompt.utf8.count + 16)
        let n = llama_tokenize(vocab, prompt, Int32(prompt.utf8.count), &tokens, Int32(tokens.count), true, true)
        guard n > 0 else { return nil }
        return Array(tokens.prefix(Int(n)))
    }

    /// tokens one email may use (its window: the context is shared out between the lanes)
    private func window(_ ctx: OpaquePointer) -> Int { Int(llama_n_ctx(ctx)) / max(1, Int(llama_n_seq_max(ctx))) }

    /// The next token from these logits: the model's own top choice, unless the grammar refuses it; only then is the
    /// grammar run over the whole vocabulary (rare once the grammar is the shape the model was trained on).
    private func pick(_ logits: UnsafeMutablePointer<Float>, grammar: UnsafeMutablePointer<llama_sampler>?, nVocab: Int, refusals: inout Int) -> llama_token? {
        var top: Float = 0
        var at: vDSP_Length = 0
        vDSP_maxvi(logits, 1, &top, &at, vDSP_Length(nVocab))
        let best = llama_token(at)
        guard let grammar else { return best }
        var one = llama_token_data(id: best, logit: top, p: 0)
        let allowed = withUnsafeMutablePointer(to: &one) { ptr -> Bool in
            var arr = llama_token_data_array(data: ptr, size: 1, selected: -1, sorted: false)
            llama_sampler_apply(grammar, &arr)
            return ptr.pointee.logit.isFinite
        }
        if allowed { return best }
        refusals += 1
        // The best token the grammar allows is the highest-scoring allowed one. Among the model's top 64 there almost always
        // is one, and then it IS that best token (everything outside the 64 scores lower), so the answer is exactly what
        // the whole-vocabulary pass would give, at a sliver of the cost. Only when none of the 64 is allowed is it needed.
        let k = 64
        var heap = [llama_token_data]()
        heap.reserveCapacity(k)
        var floor = -Float.greatestFiniteMagnitude, floorAt = 0
        for i in 0..<nVocab {
            let v = logits[i]
            if heap.count < k {
                heap.append(llama_token_data(id: llama_token(i), logit: v, p: 0))
                if heap.count == k { floorAt = heap.indices.min { heap[$0].logit < heap[$1].logit }!; floor = heap[floorAt].logit }
            } else if v > floor {
                heap[floorAt] = llama_token_data(id: llama_token(i), logit: v, p: 0)
                floorAt = heap.indices.min { heap[$0].logit < heap[$1].logit }!; floor = heap[floorAt].logit
            }
        }
        let short = heap.withUnsafeMutableBufferPointer { buf -> llama_token? in
            var arr = llama_token_data_array(data: buf.baseAddress, size: buf.count, selected: -1, sorted: false)
            llama_sampler_apply(grammar, &arr)
            var pick: llama_token? = nil
            var high = -Float.greatestFiniteMagnitude
            for i in 0..<arr.size where arr.data[i].logit.isFinite && arr.data[i].logit > high { high = arr.data[i].logit; pick = arr.data[i].id }
            return pick
        }
        if let short { return short }
        if fullVocab.count != nVocab { fullVocab = [llama_token_data](repeating: llama_token_data(id: 0, logit: 0, p: 0), count: nVocab) }
        for i in 0..<nVocab { fullVocab[i] = llama_token_data(id: llama_token(i), logit: logits[i], p: 0) }
        return fullVocab.withUnsafeMutableBufferPointer { buf -> llama_token? in
            var arr = llama_token_data_array(data: buf.baseAddress, size: nVocab, selected: -1, sorted: false)
            llama_sampler_apply(grammar, &arr)
            var pick: llama_token? = nil
            var high = -Float.greatestFiniteMagnitude
            for i in 0..<arr.size where arr.data[i].logit.isFinite && arr.data[i].logit > high { high = arr.data[i].logit; pick = arr.data[i].id }
            return pick
        }
    }

    /// One email being written: its grammar, where it is, what it has written so far.
    private final class Lane {
        let seq: Int32; let grammar: UnsafeMutablePointer<llama_sampler>?
        var pos: Int32 = 0, outTok = 0, depth = 0, done = false
        /// inside a JSON string (and just after its backslash): a brace there is text, not the answer's shape
        var inString = false, escaped = false
        var out = [UInt8](), next: llama_token = 0
        init(seq: Int32, grammar: UnsafeMutablePointer<llama_sampler>?) { self.seq = seq; self.grammar = grammar }
        deinit { if let grammar { llama_sampler_free(grammar) } }
        /// takes the chosen token: false when the answer is finished (end of turn, its object closed, or out of room)
        func take(_ tok: llama_token, vocab: OpaquePointer, maxTokens: Int) -> Bool {
            outTok += 1
            if llama_vocab_is_eog(vocab, tok) { return false }
            if let grammar { llama_sampler_accept(grammar, tok) }
            var piece = [CChar](repeating: 0, count: 64)
            let len = llama_token_to_piece(vocab, tok, &piece, Int32(piece.count), 0, false)
            if len > 0 {
                let bytes = piece.prefix(Int(len)).map { UInt8(bitPattern: $0) }
                for b in bytes {
                    if inString {
                        if escaped { escaped = false } else if b == UInt8(ascii: "\\") { escaped = true } else if b == UInt8(ascii: "\"") { inString = false }
                    } else if b == UInt8(ascii: "\"") { inString = true }
                    else if b == UInt8(ascii: "{") { depth += 1 } else if b == UInt8(ascii: "}") { depth -= 1 }
                }
                out += bytes
                if depth == 0 && out.contains(UInt8(ascii: "{")) { return false }
            }
            next = tok
            return outTok < maxTokens
        }
    }

    /// up to `lanes` emails read side by side (the caller holds the lock). Throws only when the batch itself failed.
    private func readLanes(_ inputs: [String], maxTokens: Int) throws -> [Result<String, Error>] {
        guard let ctx, let vocab, inputs.count <= Int(llama_n_seq_max(ctx)) else { throw Failure.decode }
        llama_set_n_threads(ctx, threads, threads)
        let mem = llama_get_memory(ctx)
        llama_memory_clear(mem, true)
        let nVocab = Int(llama_vocab_n_tokens(vocab))
        let room = window(ctx)
        let grammarText = speaksEvents ? Self.eventsGrammar : Self.kindGrammar
        var results = [Result<String, Error>](repeating: .failure(Failure.decode), count: inputs.count)
        var lanes: [(Int, Lane)] = []
        var refusals = 0, promptTok = 0
        let tPrompt = Date()
        // every email's prompt taken in together, each on its own sequence (one pass while they fit in a batch); each
        // email's first token picked from its last position
        var ready: [(Int, Lane, [llama_token])] = []
        for (i, input) in inputs.enumerated() {
            guard let toks = promptTokens(input, vocab: vocab) else { results[i] = .failure(Failure.decode); continue }
            if toks.count + maxTokens > room { results[i] = .failure(Failure.tooLong); continue }
            ready.append((i, Lane(seq: Int32(i), grammar: llama_sampler_init_grammar(vocab, grammarText, "root")), toks))
        }
        let cap = Int(llama_n_batch(ctx))
        var g = 0
        while g < ready.count {
            // as many whole prompts as fit in one batch (always at least one: a prompt is never longer than its window)
            var h = g, size = 0
            while h < ready.count && (h == g || size + ready[h].2.count <= cap) { size += ready[h].2.count; h += 1 }
            var b = llama_batch_init(Int32(size), 0, 1)
            defer { llama_batch_free(b) }
            var at = 0
            var lastAt: [Int] = []
            for (_, lane, toks) in ready[g..<h] {
                for (j, t) in toks.enumerated() {
                    b.token[at] = t; b.pos[at] = Int32(j); b.n_seq_id[at] = 1; b.seq_id[at]![0] = lane.seq
                    b.logits[at] = j == toks.count - 1 ? 1 : 0
                    at += 1
                }
                lastAt.append(at - 1)
                lane.pos = Int32(toks.count)
                promptTok += toks.count
            }
            b.n_tokens = Int32(at)
            guard llama_decode(ctx, b) == 0 else { throw Failure.decode }
            for (n, (i, lane, _)) in ready[g..<h].enumerated() {
                guard let lg = llama_get_logits_ith(ctx, Int32(lastAt[n])),
                      let first = pick(lg, grammar: lane.grammar, nVocab: nVocab, refusals: &refusals) else { throw Failure.decode }
                if !lane.take(first, vocab: vocab, maxTokens: maxTokens) { lane.done = true }
                lanes.append((i, lane))
            }
            g = h
        }
        let promptTook = Date().timeIntervalSince(tPrompt)
        let tWrite = Date()
        // then every unfinished email moves one token per step, all in one batch
        var step = llama_batch_init(Int32(inputs.count), 0, 1)
        defer { llama_batch_free(step) }
        while true {
            let live = lanes.filter { !$0.1.done }
            if live.isEmpty { break }
            for (k, (_, lane)) in live.enumerated() {
                step.token[k] = lane.next; step.pos[k] = lane.pos; step.n_seq_id[k] = 1; step.seq_id[k]![0] = lane.seq; step.logits[k] = 1
                lane.pos += 1
            }
            step.n_tokens = Int32(live.count)
            guard llama_decode(ctx, step) == 0 else { throw Failure.decode }
            for (k, (_, lane)) in live.enumerated() {
                guard let lg = llama_get_logits_ith(ctx, Int32(k)), let tok = pick(lg, grammar: lane.grammar, nVocab: nVocab, refusals: &refusals) else { throw Failure.decode }
                if !lane.take(tok, vocab: vocab, maxTokens: maxTokens) { lane.done = true }
            }
        }
        var outTok = 0
        for (i, lane) in lanes { results[i] = .success(String(decoding: lane.out, as: UTF8.self)); outTok += lane.outTok }
        note(promptTok: promptTok, outTok: outTok, prompt: promptTook, write: Date().timeIntervalSince(tWrite), emails: lanes.count, refusals: refusals)
        return results
    }
    #endif

    /// one reading, on whatever the model is loaded on (the caller holds the lock)
    private func readOnce(_ input: String, maxTokens: Int) throws -> String {
        #if canImport(llama)
        guard let ctx, let vocab else { throw Failure.noModel }
        // four cores on screen, two otherwise (also set per email: kosh may have come on or off screen)
        llama_set_n_threads(ctx, threads, threads)
        guard let tokens0 = promptTokens(input, vocab: vocab) else { throw Failure.decode }
        var tokens = tokens0
        if tokens.count + maxTokens > window(ctx) { throw Failure.tooLong }
        llama_memory_clear(llama_get_memory(ctx), true)
        let lane = Lane(seq: 0, grammar: llama_sampler_init_grammar(vocab, speaksEvents ? Self.eventsGrammar : Self.kindGrammar, "root"))
        let nVocab = Int(llama_vocab_n_tokens(vocab))
        var refusals = 0
        let tPrompt = Date()
        let first = tokens.withUnsafeMutableBufferPointer { buf in
            llama_decode(ctx, llama_batch_get_one(buf.baseAddress, Int32(buf.count)))
        }
        guard first == 0 else { throw Failure.decode }
        let promptTook = Date().timeIntervalSince(tPrompt)
        let tWrite = Date()
        while true {
            guard let lg = llama_get_logits_ith(ctx, -1), let tok = pick(lg, grammar: lane.grammar, nVocab: nVocab, refusals: &refusals) else { throw Failure.decode }
            if !lane.take(tok, vocab: vocab, maxTokens: maxTokens) { break }
            var t = tok
            if llama_decode(ctx, llama_batch_get_one(&t, 1)) != 0 { throw Failure.decode }
        }
        note(promptTok: tokens.count, outTok: lane.outTok, prompt: promptTook, write: Date().timeIntervalSince(tWrite), emails: 1, refusals: refusals)
        return String(decoding: lane.out, as: UTF8.self)
        #else
        throw Failure.unavailable
        #endif
    }
}
