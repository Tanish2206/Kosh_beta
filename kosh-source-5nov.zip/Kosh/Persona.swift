import Foundation

/// Understanding you (engine/21t-build-persona.js, `snap.persona`): what the mail says about the household's life, each
/// line with its evidence and dates: life events (a new job, a move, someone new on a policy), trips (a chapter's own
/// figures, or a trip kosh drafted from bookings), whom you spend on (money sent, gifts, bills split) and habits, said
/// plainly. Nothing is inferred the mail did not state. Screen-free: the screens read it through `Store`
/// (Store+Persona.swift).
struct Persona: Decodable, Hashable {
    /// what a line was read from: "6 salary credits from …, 1 Jan – 1 Jun 2026", and the payments or mails behind it
    struct Evidence: Decodable, Hashable {
        let line: String
        var ids: [String]? = nil
        var from: String? = nil
        var to: String? = nil
    }
    struct Cat: Decodable, Hashable {
        let cat: String
        let v: Double
    }
    /// what was spent around an event: counted payments between two days, by kind
    struct Story: Decodable, Hashable {
        let from: String
        let to: String
        let spent: Double
        let n: Int
        var top: [Cat]? = nil
        /// a day's spending around it, and on a usual day (the mail's other days): the line is said only when they differ
        var perDay: Double? = nil
        var usual: Double? = nil
    }
    /// job · move · family
    struct Event: Decodable, Hashable, Identifiable {
        let id: String
        let k: String
        let on: String
        let title: String
        let line: String
        var ev: [Evidence]? = nil
        var story: Story? = nil
        var storyLine: String? = nil
        /// a move kosh asks about ("Is this a move?"), and your answer once given (yes)
        var ask: Bool? = nil
        var said: String? = nil
    }
    /// a trip chapter (its own figures) or a trip drafted from bookings (the draft's)
    struct Trip: Decodable, Hashable, Identifiable {
        let id: String
        let name: String
        var place: String? = nil
        let from: String
        var to: String? = nil
        var days: Int? = nil
        var total: Double? = nil
        var perDay: Double? = nil
        var n: Int? = nil
        var kinds: [String: Int]? = nil
        /// what it went on: travel · stay · food · other (only when they add up to its total)
        var split: [String: Double]? = nil
        var chapter: Bool? = nil
        var draft: Bool? = nil
        var ev: [Evidence]? = nil
    }
    /// sent · gift · split
    struct Part: Decodable, Hashable {
        let k: String
        let n: Int
        let amt: Double
        var what: [String]? = nil
        var ids: [String]? = nil
        var from: String? = nil
        var to: String? = nil
    }
    struct Person: Decodable, Hashable, Identifiable {
        let key: String
        let who: String
        var o: String? = nil
        var rel: String? = nil
        let total: Double
        var parts: [Part]? = nil
        var from: String? = nil
        var to: String? = nil
        let line: String
        var ev: [Evidence]? = nil
        var id: String { key }
    }
    /// weekend · late · payday · change, with the figures the line says
    struct Habit: Decodable, Hashable, Identifiable {
        let k: String
        let line: String
        var ev: [Evidence]? = nil
        var from: String? = nil
        var to: String? = nil
        var weekend: Double? = nil
        var weekday: Double? = nil
        var n: Int? = nil
        var amt: Double? = nil
        var paydays: Int? = nil
        var payWeek: Double? = nil
        var other: Double? = nil
        var cat: String? = nil
        var now: Double? = nil
        var usual: Double? = nil
        var id: String { k }
    }
    var v: Int? = nil
    var asOf: String? = nil
    var from: String? = nil
    var to: String? = nil
    var events: [Event]? = nil
    var trips: [Trip]? = nil
    var people: [Person]? = nil
    var habits: [Habit]? = nil
}

enum PersonaWords {
    static func sym(event k: String) -> String {
        switch k {
        case "job": return "briefcase.fill"
        case "move": return "shippingbox.fill"
        case "family": return "person.badge.plus"
        default: return "sparkles"
        }
    }
    static func sym(habit k: String) -> String {
        switch k {
        case "weekend": return "calendar"
        case "late": return "moon.stars.fill"
        case "payday": return "indianrupeesign.circle"
        case "change": return "arrow.up.arrow.down"
        default: return "circle"
        }
    }
    /// a trip's figures in a line: "₹42,300 · 5 days · ₹8,460 a day"
    static func trip(_ t: Persona.Trip, money: (Double) -> String) -> String {
        var bits: [String] = []
        if let tot = t.total, tot > 0 { bits.append(money(tot)) }
        if let d = t.days, d > 0 { bits.append(String(d) + (d == 1 ? " day" : " days")) }
        if let pd = t.perDay, pd > 0 { bits.append(money(pd) + " a day") }
        return bits.joined(separator: " · ")
    }
    /// one headline of "What kosh noticed": its symbol and words
    struct Noticed: Hashable, Identifiable {
        let id: String
        let sym: String
        let text: String
    }
    /// the three or four facts at the top of the page: the latest life event, the trips, whom you spend on most, and a
    /// habit. Each the engine's own words or figures; nothing added up again
    static func noticed(_ p: Persona, money: (Double) -> String, day: (String) -> String) -> [Noticed] {
        var out: [Noticed] = []
        if let e = p.events?.first {
            out.append(Noticed(id: "event", sym: sym(event: e.k), text: e.title + ", " + day(e.on)))
        }
        let trips: [Persona.Trip] = p.trips ?? []
        if let t = trips.first {
            let more: String = trips.count == 1 ? "1 trip" : String(trips.count) + " trips"
            out.append(Noticed(id: "trips", sym: "airplane", text: more + " found, the latest " + (t.place.map { $0.isEmpty ? t.name : "to " + $0 } ?? t.name) + " (" + day(t.from) + ")"))
        }
        if let w = (p.people ?? []).first(where: { $0.total > 0 }) {
            out.append(Noticed(id: "people", sym: "person.2.fill", text: "Most sent to " + w.who + ": " + money(w.total) + " in the last 12 months"))
        }
        if let h = p.habits?.first {
            out.append(Noticed(id: "habit", sym: sym(habit: h.k), text: h.line))
        }
        return Array(out.prefix(4))
    }
    /// a tile of "What kosh noticed" (insights-obsidian): what it is, its figure, what it is against. Two to four of them:
    /// the latest life event, the trips, whom the most money went to, a habit. The engine's figures, nothing added again
    struct Stat: Hashable, Identifiable {
        let id: String
        let label: String
        let value: String
        let sub: String
        let sym: String
    }
    static func stats(_ p: Persona, money: (Double) -> String, day: (String) -> String) -> [Stat] {
        var out: [Stat] = []
        if let e = p.events?.first {
            out.append(Stat(id: "event", label: "Latest change", value: e.title, sub: day(e.on), sym: sym(event: e.k)))
        }
        let trips: [Persona.Trip] = p.trips ?? []
        if let t = trips.first {
            let place: String = t.place.map { $0.isEmpty ? t.name : $0 } ?? t.name
            out.append(Stat(id: "trips", label: trips.count == 1 ? "Trip found" : "Trips found", value: String(trips.count), sub: "Latest: " + place + ", " + day(t.from), sym: "airplane"))
        }
        if let w = (p.people ?? []).first(where: { $0.total > 0 }) {
            out.append(Stat(id: "people", label: "Most went to", value: money(w.total), sub: w.who + ", last 12 months", sym: "person.2.fill"))
        }
        if let h = p.habits?.first {
            let t: (title: String, value: String, sub: String) = tile(h, money: money)
            out.append(Stat(id: "habit", label: t.title, value: t.value.isEmpty ? t.sub : t.value, sub: t.value.isEmpty ? "" : t.sub, sym: sym(habit: h.k)))
        }
        return Array(out.prefix(4))
    }
    /// a person's caption under their name, said once: "Father · 3 transfers · 1 gift" (the amount sits beside it)
    static func caption(_ w: Persona.Person) -> String {
        var bits: [String] = []
        if let r = w.rel, !r.isEmpty { bits.append(r) }
        for part in w.parts ?? [] {
            switch part.k {
            case "sent": bits.append(part.n == 1 ? "1 transfer" : String(part.n) + " transfers")
            case "gift": bits.append(part.n == 1 ? "1 gift" : String(part.n) + " gifts")
            default: bits.append(part.n == 1 ? "1 bill split" : String(part.n) + " bills split")
            }
        }
        return bits.joined(separator: " · ")
    }
    /// a habit as a tile: a title, its figure, and what it is against
    static func tile(_ h: Persona.Habit, money: (Double) -> String) -> (title: String, value: String, sub: String) {
        switch h.k {
        case "weekend":
            if let a = h.weekend, let b = h.weekday { return ("Weekends", money(a) + " a day", "against " + money(b) + " a weekday") }
        case "late":
            if let n = h.n { return ("After 11pm", String(n) + (n == 1 ? " payment" : " payments"), h.amt.map { money($0) + " in all" } ?? "") }
        case "payday":
            if let a = h.payWeek, let b = h.other { return ("Week after payday", money(a) + " a day", "against " + money(b) + " other days") }
        case "change":
            if let c = h.cat, let a = h.now { return (c, money(a), h.usual.map { "against " + money($0) + " usually" } ?? "") }
        default:
            break
        }
        return ("Habit", "", h.line)
    }
    /// one part of a trip's cost: travel · stay · food · other
    struct TripPart: Hashable, Identifiable {
        let k: String
        let v: Double
        var id: String { k }
    }
    /// a trip's split in the order it is drawn: travel, stay, food, other
    static func split(_ t: Persona.Trip) -> [TripPart] {
        let s: [String: Double] = t.split ?? [:]
        return ["travel", "stay", "food", "other"].compactMap { (k: String) -> TripPart? in
            guard let v = s[k], v > 0 else { return nil }
            return TripPart(k: k, v: v)
        }
    }
    static func splitName(_ k: String) -> String {
        switch k {
        case "travel": return "Travel"
        case "stay": return "Stay"
        case "food": return "Food"
        default: return "Other"
        }
    }
    /// "Asha Example" → "AE"
    static func initials(_ name: String) -> String {
        let words: [Substring] = name.split(whereSeparator: { !$0.isLetter })
        return words.prefix(2).compactMap { $0.first.map { String($0).uppercased() } }.joined()
    }
    /// what the page says when it has nothing to say yet
    static let empty: String = "kosh fills this in from what it reads: a new job from a new salary, a move from where your parcels go, trips from your bookings, whom you spend on, and how you spend. Nothing is guessed."
}
