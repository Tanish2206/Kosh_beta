import SwiftUI

// MARK: - Every bill, by kind (fb 1 Nov 22:09)
// "Map out all bills — internet, phone, electricity, gas, water, insurance — and the analytics for each; bills by home
// within." Read from the payments kosh already found in mail (Bills, Home › Maintenance, Insurance), so every bill
// paid shows, whether or not kosh could tie it to a connection and a home. Each kind: a month on average over the
// last year, the year as bars, the last one paid, the connections and homes it went to, and the journey: every
// payment, when, how much, through what, with a recap line on top. (Bills by home's own pages stay as they were;
// this is the map above them.)

struct BillKind: Identifiable, Hashable {
    let k: String
    let pays: [Txn]          // newest first
    var id: String { k }

    static let order: [String] = ["Electricity", "Internet", "Phone", "Gas", "Water", "DTH", "Maintenance", "Insurance"]
    static func sym(_ k: String) -> String {
        switch k {
        case "Electricity": return "bolt.fill"
        case "Internet": return "wifi"
        case "Phone": return "iphone"
        case "Gas": return "flame.fill"
        case "Water": return "drop.fill"
        case "DTH": return "tv"
        case "Maintenance": return "building.2.fill"
        default: return "shield.fill"
        }
    }
    static func tint(_ k: String) -> Color {
        switch k {
        case "Phone": return Obsidian.ulip
        case "Insurance": return Obsidian.term
        case "Internet": return Color(hex: "#C4B5FD")
        default: return HomeInk.kind(k)
        }
    }
    /// which kind of bill a payment is, or nil
    static func of(_ t: Txn) -> String? {
        guard t.sp, t.a > 0 else { return nil }
        let s: String = t.s.lowercased(), m: String = (t.m + " " + (t.pf ?? "")).lowercased()
        if t.c == "Insurance" { return "Insurance" }
        if t.c == "Home" && s == "maintenance" { return "Maintenance" }
        guard t.c == "Bills" || t.c == "Utilities" else { return nil }
        if s.contains("electric") { return "Electricity" }
        let net: Bool = m.range(of: #"fttx|fiber|fibre|airfiber|broadband|xstream|\bact\b|hathway|excitel|tikona|spectra|you broadband|\bwifi\b"#, options: .regularExpression) != nil
        let tel: Bool = m.range(of: #"\bjio\b|rjil|reliance jio|airtel|vodafone|\bvi\b|\bidea\b|bsnl|mtnl|recharge|prepaid|postpaid"#, options: .regularExpression) != nil
        if net && (s.contains("internet") || s.contains("broadband") || s.contains("mobile") || s.isEmpty) { return "Internet" }
        if s.contains("internet") || s.contains("broadband") { return "Internet" }
        // (a phone bill is a telecom's: a bank, a society or a person filed under Mobile isn't one)
        if s.contains("mobile") || s.contains("phone") || s.contains("postpaid") || s.contains("prepaid") { return tel && t.a <= 10000 ? "Phone" : nil }
        if s.contains("gas") || s.contains("lpg") { return "Gas" }
        if s.contains("water") { return "Water" }
        if s.contains("dth") || s.contains("cable") { return "DTH" }
        if m.contains("electric") || m.contains("power") || m.contains("bijli") || m.contains("vidyut") { return "Electricity" }
        return nil
    }
    /// every kind; with a home picked ("" for all), only that home's payments
    @MainActor static func all(_ store: Store, home: String = "") -> [BillKind] {
        var by: [String: [Txn]] = [:]
        for t in store.snap.tx {
            guard let k = of(t) else { continue }
            if !home.isEmpty && (BillKind.homeID(t, store) ?? "") != home { continue }
            by[k, default: []].append(t)
        }
        return order.compactMap { (k: String) -> BillKind? in
            guard let xs = by[k], !xs.isEmpty else { return nil }
            return BillKind(k: k, pays: xs.sorted { $0.d > $1.d })
        }
    }

    /// the last twelve months to `cm`, each month's sum
    func year(_ cm: String) -> [(m: String, v: Double)] {
        var out: [(m: String, v: Double)] = []
        for back in stride(from: 11, through: 0, by: -1) {
            let mm: String = BillKind.monthBack(cm, back)
            out.append((mm, pays.filter { $0.d.hasPrefix(mm) }.reduce(0) { $0 + $1.a }))
        }
        return out
    }
    static func monthBack(_ cm: String, _ n: Int) -> String {
        let p = cm.split(separator: "-"); guard p.count == 2, var y = Int(p[0]), var mo = Int(p[1]) else { return cm }
        mo -= n
        while mo <= 0 { mo += 12; y -= 1 }
        return String(y) + "-" + (mo < 10 ? "0" : "") + String(mo)
    }
    /// over the last year: the sum, and a month on average across the months since the first bill (at most twelve)
    func lastYear(_ cm: String) -> (total: Double, perMonth: Double, n: Int) {
        let from: String = BillKind.monthBack(cm, 11)
        let xs: [Txn] = pays.filter { String($0.d.prefix(7)) >= from }
        let total: Double = xs.reduce(0) { $0 + $1.a }
        guard let first = xs.last?.d else { return (0, 0, 0) }
        let f: String = String(first.prefix(7))
        var months: Int = 1
        while months < 12 && BillKind.monthBack(cm, months - 1) > f { months += 1 }
        return (total, total / Double(max(1, months)), xs.count)
    }
    /// the connection kosh tied a payment to: its bill in Bills by home, and that bill's connection
    @MainActor static func acct(_ t: Txn, _ store: Store) -> HomesBook.Acct? {
        guard let b = (store.snap.homes?.bills ?? []).first(where: { $0.paid == t.id }) else { return nil }
        return (store.snap.homes?.accts ?? []).first { $0.id == b.acct }
    }
    /// the biller as a person says it: the connection's board and its number's last digits ("UHBVN ••0000"), else the
    /// payee, with telecoms said by their brand
    @MainActor static func biller(_ t: Txn, _ store: Store) -> String {
        if let a = acct(t, store), let b = a.biller, !b.isEmpty {
            let no: String = String((a.no ?? "").suffix(4))
            return b + (no.isEmpty ? "" : " ••" + no)
        }
        let low: String = (t.m + " " + (t.pf ?? "")).lowercased()
        if low.range(of: #"\bjio\b|rjil|reliance jio|jio platforms|jiomart|reliance payment"#, options: .regularExpression) != nil { return low.contains("fttx") || low.contains("fiber") ? "JioFiber" : "Jio" }
        if low.contains("airtel") { return "Airtel" }
        if low.contains("vodafone") || low.range(of: #"\bvi\b"#, options: .regularExpression) != nil { return "Vi" }
        if low.contains("bsnl") { return "BSNL" }
        let raw: String = t.pf ?? store.payFact(t)?.at ?? t.m
        let c: String = ShopName.clean(raw)
        return c.isEmpty ? t.m : c
    }
    /// what it went through: "Amazon Pay", "CRED", "UPI", "card"
    @MainActor static func via(_ t: Txn, _ store: Store) -> String {
        let f = store.payFact(t)
        if let v = f?.via, !v.isEmpty { return v }
        // (a wallet's payment says its wallet by the mail it came in)
        if (f?.ch ?? "") == "wallet", let from = store.live?.records.first(where: { $0.id == t.id })?.from?.lowercased() {
            if from.contains("amazon") { return "Amazon Pay" }
            if from.contains("paytm") { return "Paytm" }
            if from.contains("phonepe") { return "PhonePe" }
            if from.contains("mobikwik") { return "MobiKwik" }
        }
        let m: String = t.m.lowercased()
        if m.contains("amazon") { return "Amazon Pay" }
        if m.contains("cred") { return "CRED" }
        if m.contains("paytm") { return "Paytm" }
        if m.contains("phonepe") { return "PhonePe" }
        switch f?.ch ?? "" {
        case "upi": return "UPI"
        case "card": return (f?.card ?? "") == "debit" ? "debit card" : "credit card"
        case "netbanking": return "net banking"
        case "auto": return "auto-pay"
        case "wallet": return "wallet"
        default: return ""
        }
    }
    /// the home a payment's bill sits on, when kosh tied it to one
    @MainActor static func homeID(_ t: Txn, _ store: Store) -> String? {
        guard let a = acct(t, store), let h = a.home, !h.isEmpty else { return nil }
        return h
    }
    @MainActor static func home(_ t: Txn, _ store: Store) -> String? {
        guard let a = acct(t, store), let h = a.home, !h.isEmpty,
              let home = store.homes.first(where: { $0.id == h }) else { return nil }
        return home.name
    }
    /// the recap: "8 electricity bills since Jan 2026, ₹46,898 in all; the biggest ₹9,120 in Jun 2026; mostly through Amazon Pay"
    @MainActor func recap(_ store: Store) -> String {
        let n: Int = pays.count
        let total: Double = pays.reduce(0) { $0 + $1.a }
        let first: String = pays.last.map { Day.fmt($0.d, "MMM yyyy") } ?? ""
        var bits: [String] = [String(n) + " " + (k == "Insurance" ? (n == 1 ? "premium" : "premiums") : (n == 1 ? "bill" : "bills")) + " since " + first + ", " + Fmt.rupees(total) + " in all"]
        if n >= 3, let big = pays.max(by: { $0.a < $1.a }) { bits.append("the biggest " + Fmt.rupees(big.a) + " in " + Day.fmt(big.d, "MMM yyyy")) }
        var vias: [String: Int] = [:]
        for t in pays { let v = BillKind.via(t, store); if !v.isEmpty { vias[v, default: 0] += 1 } }
        if let top = vias.max(by: { $0.value < $1.value }), Double(top.value) >= Double(n) * 0.5 { bits.append((top.value == n ? "always" : "mostly") + " through " + top.key) }
        return bits.joined(separator: "; ") + "."
    }
}

/// the map at the top of Bills by home: one row per kind of bill
struct BillsMapSection: View {
    @Environment(Store.self) private var store
    @AppStorage("bills.home") private var sel: String = ""
    var body: some View {
        let every: [BillKind] = BillKind.all(store)
        let kinds: [BillKind] = sel.isEmpty ? every : BillKind.all(store, home: sel)
        if !every.isEmpty {
            let cm: String = store.snap.cm
            let sum: Double = kinds.reduce(0) { $0 + $1.lastYear(cm).perMonth }
            BillHomeStrip(sel: $sel)
            ObsHead(text: sel.isEmpty ? "Every bill" : "Its bills", trailing: Fmt.rupees(sum) + " a month")
            VStack(spacing: 0) {
                ForEach(Array(kinds.enumerated()), id: \.element.id) { (i: Int, b: BillKind) in
                    if i > 0 { ObsRule(inset: 52) }
                    Button { store.push(.billKind(b.k)) } label: { BillKindRow(b: b, cm: cm) }
                        .buttonStyle(.press)
                }
            }
            .obsidianCard(24, padding: 16)
            .privacySensitive()
        }
    }
}

struct BillKindRow: View {
    @Environment(Store.self) private var store
    let b: BillKind
    let cm: String
    var body: some View {
        let y = b.lastYear(cm)
        let tint: Color = BillKind.tint(b.k)
        let last: Txn? = b.pays.first
        HStack(spacing: 12) {
            Image(systemName: BillKind.sym(b.k)).font(.system(size: 14, weight: .semibold)).foregroundStyle(tint)
                .frame(width: 36, height: 36)
                .background(tint.opacity(0.14), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
            VStack(alignment: .leading, spacing: 3) {
                Text(b.k).font(.subheadline.weight(.semibold)).foregroundStyle(Obsidian.ink)
                if let last {
                    Text("Last " + Fmt.rupees(last.a) + " · " + Day.fmt(last.d, last.d.prefix(4) == cm.prefix(4) ? "d MMM" : "d MMM yy"))
                        .font(.caption).foregroundStyle(Obsidian.ink3).monospacedDigit().lineLimit(1)
                }
            }
            Spacer(minLength: 8)
            BillSpark(vals: b.year(cm).map { $0.v }, tint: tint).frame(width: 64, height: 24)
            VStack(alignment: .trailing, spacing: 2) {
                Text(y.perMonth > 0 ? Fmt.rupees(y.perMonth) : "—").font(.subheadline.weight(.semibold)).foregroundStyle(Obsidian.ink).monospacedDigit()
                Text(y.perMonth > 0 ? "a month" : "none this year").font(.caption2).foregroundStyle(Obsidian.ink3)
            }
            .frame(minWidth: 70, alignment: .trailing)
        }
        .padding(.vertical, 10)
        .contentShape(Rectangle())
        .accessibilityElement(children: .combine)
    }
}

/// twelve thin bars
struct BillSpark: View {
    let vals: [Double]
    let tint: Color
    var body: some View {
        let top: Double = max(vals.max() ?? 0, 1)
        HStack(alignment: .bottom, spacing: 2) {
            ForEach(Array(vals.enumerated()), id: \.offset) { (i: Int, v: Double) in
                Capsule().fill(v > 0 ? tint.opacity(i == vals.count - 1 ? 1 : 0.7) : Color.white.opacity(0.08))
                    .frame(height: max(3, CGFloat(v / top) * 24))
            }
        }
        .accessibilityHidden(true)
    }
}

// MARK: one kind of bill

struct BillKindPage: View {
    @Environment(Store.self) private var store
    let k: String
    @AppStorage("bills.home") private var sel: String = ""
    var body: some View {
        let b: BillKind? = BillKind.all(store, home: sel).first { $0.k == k }
        ObsScroll(title: k, inline: false) {
            BillHomeStrip(sel: $sel)
            if let b {
                let cm: String = store.snap.cm
                let tint: Color = BillKind.tint(k)
                let y = b.lastYear(cm)
                let yr = b.year(cm)
                VStack(alignment: .leading, spacing: 12) {
                    Text("A month on average · last 12 months").caption(tint)
                    HStack(alignment: .firstTextBaseline, spacing: 6) {
                        ObsFigure(text: Fmt.rupees(y.perMonth), size: 44)
                        Text("a month").font(.footnote).foregroundStyle(Obsidian.ink2)
                    }
                    Text(b.recap(store)).font(.subheadline).foregroundStyle(Obsidian.ink2).fixedSize(horizontal: false, vertical: true)
                    ObsBarStrip(bars: yr.map { ObsBarStrip.Bar(id: $0.m, label: HomeWords.monthLetter($0.m), v: $0.v, on: $0.v > 0, faint: $0.m == cm) }, height: 72, tint: tint)
                        .padding(.top, 4)
                }
                .obsidianCard(24, padding: 18)

                let homes: [(String, Double, Int)] = Self.byHome(b, store)
                if homes.count > 1 || (homes.first.map { $0.0 != Self.noHome } ?? false) {
                    ObsHead(text: "By home", trailing: String(homes.filter { $0.0 != Self.noHome }.count))
                    BillSplit(rows: homes, tint: tint)
                }
                let billers: [(String, Double, Int)] = Self.byBiller(b, store)
                if billers.count > 1 {
                    ObsHead(text: k == "Insurance" ? "By insurer" : "By connection", trailing: String(billers.count))
                    BillSplit(rows: billers, tint: tint)
                }
                ObsHead(text: "The journey", trailing: String(b.pays.count))
                BillJourney(b: b, tint: tint)
            } else {
                ObsEmpty(title: "No " + k.lowercased() + " bills yet", sym: BillKind.sym(k), text: "They show here as kosh reads them in your mail.")
            }
        }
        .obsidianPage(aura: BillKind.tint(k))
    }
    static let noHome: String = "Home not known yet"
    @MainActor static func byHome(_ b: BillKind, _ store: Store) -> [(String, Double, Int)] {
        var sum: [String: Double] = [:], n: [String: Int] = [:]
        for t in b.pays { let h: String = BillKind.home(t, store) ?? noHome; sum[h, default: 0] += t.a; n[h, default: 0] += 1 }
        return sum.keys.sorted { (sum[$0] ?? 0) > (sum[$1] ?? 0) }.map { ($0, sum[$0] ?? 0, n[$0] ?? 0) }
    }
    @MainActor static func byBiller(_ b: BillKind, _ store: Store) -> [(String, Double, Int)] {
        var sum: [String: Double] = [:], n: [String: Int] = [:]
        for t in b.pays { let h: String = BillKind.biller(t, store); sum[h, default: 0] += t.a; n[h, default: 0] += 1 }
        return sum.keys.sorted { (sum[$0] ?? 0) > (sum[$1] ?? 0) }.map { ($0, sum[$0] ?? 0, n[$0] ?? 0) }
    }
}

/// a split of the kind's money: a row each, with its share as a bar
struct BillSplit: View {
    let rows: [(String, Double, Int)]
    let tint: Color
    var body: some View {
        let total: Double = max(rows.reduce(0) { $0 + $1.1 }, 1)
        VStack(spacing: 14) {
            ForEach(Array(rows.prefix(6).enumerated()), id: \.offset) { (_: Int, r: (String, Double, Int)) in
                BillSplitRow(name: r.0, v: r.1, n: r.2, share: r.1 / total, tint: tint)
            }
        }
        .obsidianCard(22, padding: 16)
    }
}

struct BillSplitRow: View {
    let name: String
    let v: Double
    let n: Int
    let share: Double
    let tint: Color
    var body: some View {
        let unknown: Bool = name == BillKindPage.noHome
        let pays: String = n == 1 ? "1 payment" : String(n) + " payments"
        let pct: String = String(Int((share * 100).rounded())) + "%"
        VStack(alignment: .leading, spacing: 6) {
            HStack(alignment: .firstTextBaseline) {
                Text(name).font(.subheadline).foregroundStyle(unknown ? Obsidian.ink3 : Obsidian.ink).lineLimit(1)
                Spacer(minLength: 8)
                Text(Fmt.rupees(v)).font(.subheadline.weight(.semibold)).foregroundStyle(Obsidian.ink).monospacedDigit()
            }
            GeometryReader { (g: GeometryProxy) in
                let w: CGFloat = max(4, g.size.width * CGFloat(share))
                ZStack(alignment: .leading) {
                    Capsule().fill(Color.white.opacity(0.06))
                    Capsule().fill(tint.opacity(unknown ? 0.35 : 0.9)).frame(width: w)
                }
            }
            .frame(height: 5)
            Text(pays + " · " + pct).font(.caption).foregroundStyle(Obsidian.ink3).monospacedDigit()
        }
    }
}

/// every payment, newest first, by year: when, how much, to whom, through what, for which home
struct BillJourney: View {
    @Environment(Store.self) private var store
    let b: BillKind
    let tint: Color
    @State private var all: Bool = false
    var body: some View {
        let shown: [Txn] = all ? b.pays : Array(b.pays.prefix(8))
        VStack(alignment: .leading, spacing: 0) {
            ForEach(Array(shown.enumerated()), id: \.element.id) { (i: Int, t: Txn) in
                let yearHead: Bool = i == 0 || shown[i - 1].d.prefix(4) != t.d.prefix(4)
                if yearHead {
                    Text(String(t.d.prefix(4))).caption().padding(.top, i == 0 ? 0 : 14).padding(.bottom, 8)
                }
                Button { store.sheet = .tx(t.id) } label: { stop(t, last: i == shown.count - 1) }
                    .buttonStyle(.press)
            }
            if b.pays.count > 8 {
                Button { withAnimation(Motion.open) { all.toggle() } } label: {
                    Text(all ? "Fewer" : "All " + String(b.pays.count)).font(.footnote.weight(.semibold)).foregroundStyle(tint)
                        .frame(maxWidth: .infinity, minHeight: 40)
                }
                .buttonStyle(.press)
            }
        }
        .obsidianCard(22, padding: 16)
        .privacySensitive()
    }
    func stop(_ t: Txn, last: Bool) -> some View {
        let via: String = BillKind.via(t, store)
        let home: String? = BillKind.home(t, store)
        let sub: String = [BillKind.biller(t, store), via.isEmpty ? "" : "via " + via, home ?? ""].filter { !$0.isEmpty }.joined(separator: " · ")
        return HStack(alignment: .top, spacing: 12) {
            VStack(spacing: 0) {
                Circle().fill(tint).frame(width: 9, height: 9).padding(.top, 5)
                if !last { Rectangle().fill(tint.opacity(0.25)).frame(width: 1.5).frame(maxHeight: .infinity) }
            }
            .frame(width: 10)
            VStack(alignment: .leading, spacing: 2) {
                HStack(alignment: .firstTextBaseline) {
                    Text(Day.fmt(t.d, "d MMM")).font(.subheadline.weight(.semibold)).foregroundStyle(Obsidian.ink)
                    Spacer(minLength: 8)
                    Text(Fmt.rupees(t.a)).font(.subheadline.weight(.semibold)).foregroundStyle(Obsidian.ink).monospacedDigit()
                }
                Text(sub).font(.caption).foregroundStyle(Obsidian.ink3).lineLimit(2)
            }
            .padding(.bottom, 14)
        }
        .contentShape(Rectangle())
    }
}


/// the homes as a strip on top, "All homes" first: the map and each kind's page show the picked home's bills
struct BillHomeStrip: View {
    @Environment(Store.self) private var store
    @Binding var sel: String
    var body: some View {
        let homes: [HomesBook.Home] = store.homes
        if homes.count >= 1 {
            ScrollView(.horizontal) {
                HStack(spacing: 8) {
                    chip(id: "", name: "All homes", sym: "square.grid.2x2")
                    ForEach(homes) { (h: HomesBook.Home) in chip(id: h.id, name: h.name, sym: "house") }
                }
                .padding(.vertical, 2)
            }
            .scrollIndicators(.hidden)
            .scrollClipDisabled()
            .onAppear { if !sel.isEmpty && !homes.contains(where: { $0.id == sel }) { sel = "" } }
        }
    }
    func chip(id: String, name: String, sym: String) -> some View {
        let on: Bool = sel == id
        return Button { withAnimation(Motion.base) { sel = id } } label: {
            HStack(spacing: 6) {
                Image(systemName: sym).font(.caption.weight(.semibold))
                Text(name).font(.subheadline.weight(.semibold)).lineLimit(1)
            }
            .foregroundStyle(on ? Color.black : Obsidian.ink2)
            .padding(.horizontal, 14).frame(minHeight: 38)
            .background(on ? Obsidian.ink : Color.white.opacity(0.06), in: Capsule())
            .overlay(Capsule().strokeBorder(Color.white.opacity(on ? 0 : 0.1), lineWidth: 1))
        }
        .buttonStyle(.press)
        .accessibilityAddTraits(on ? .isSelected : [])
    }
}
