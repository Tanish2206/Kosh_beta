import Foundation

/// The month in review, one month at a time (find-review, 1 Nov): which month it opens on, the usual month it is held
/// against, the six months beside it, and where the money went. Every figure is one the store already has (a month's
/// spending is Store.spent, the figure Insights shows for that month; its kinds are Store.catsSpent): nothing is summed
/// again here, only picked and ordered. Screen-free (Foundation only): engine-test/month-review.swift compiles it.
enum MonthReviewMath {
    /// the month it opens on: the last whole month (the one before this month) when kosh has it, else the newest
    static func start(_ months: [String], cm: String, partial: Set<String>) -> String {
        let whole: [String] = months.filter { $0 < cm && !partial.contains($0) }.sorted()
        if let last = whole.last { return last }
        return months.sorted().last ?? cm
    }
    /// the whole months before m a usual is taken over: never this month, never a part-month, the latest three
    static func usualMonths(_ m: String, months: [String], cm: String, partial: Set<String>) -> [String] {
        Array(months.filter { $0 < m && $0 != cm && !partial.contains($0) }.sorted().suffix(3))
    }
    /// the usual month: the middle of the last three whole months before it; nil with fewer than three
    static func usual(_ m: String, months: [String], cm: String, partial: Set<String>, spent: (String) -> Double) -> Double? {
        let over: [String] = usualMonths(m, months: months, cm: cm, partial: partial)
        guard over.count == 3 else { return nil }
        let v: [Double] = over.map(spent).sorted()
        return v[1]
    }
    /// how this month stands against the usual: "₹4,200 more than usual", "about usual" (within 5%)
    static func against(_ now: Double, usual: Double?, money: (Double) -> String) -> String? {
        guard let u = usual, u > 0 else { return nil }
        let d: Double = now - u
        if abs(d) < u * 0.05 { return "About your usual month (" + money(u) + ")" }
        return money(abs(d)) + (d > 0 ? " more than" : " less than") + " your usual month (" + money(u) + ")"
    }
    /// the usual month by the same day, for a month still running: the middle of the same three whole months, each up to
    /// that day of its own (a month shorter than the day counts whole), so a month's first days are never held against a
    /// whole month (a month's first day was said to be far under a whole usual month). nil with fewer than three, or a month kosh
    /// holds no day-by-day line for
    static func usualByDay(_ m: String, day: Int, months: [String], cm: String, partial: Set<String>, through: (String, Int) -> Double?) -> Double? {
        let over: [String] = usualMonths(m, months: months, cm: cm, partial: partial)
        guard over.count == 3, day >= 1 else { return nil }
        let v: [Double] = over.compactMap { (x: String) -> Double? in through(x, day) }.sorted()
        guard v.count == 3 else { return nil }
        return v[1]
    }
    /// a running month is held against the usual from its seventh day: before it there is too little to say
    static let compareFrom: Int = 7
    /// how a month stands against its usual, for the hero's pill: the words, and which way (1 more, -1 less, 0 about)
    struct Delta: Hashable {
        let text: String
        let dir: Int
        /// what it was held against: "your usual month", "your usual 1 – 12"
        let against: String
    }
    /// a whole month against the usual month; a running one (day given) against the usual by that day, or "Too early to
    /// compare" before the seventh
    static func delta(_ now: Double, usual: Double?, day: Int?, money: (Double) -> String) -> Delta? {
        if let d = day, d < compareFrom { return Delta(text: "Too early to compare", dir: 0, against: "") }
        guard let u = usual, u > 0 else { return nil }
        let against: String = day.map { "your usual 1 – " + String($0) } ?? "your usual month"
        let diff: Double = now - u
        if abs(diff) < u * 0.05 { return Delta(text: "About usual", dir: 0, against: against + ", " + money(u)) }
        return Delta(text: money(abs(diff)) + (diff > 0 ? " more" : " less"), dir: diff > 0 ? 1 : -1, against: "than " + against + ", " + money(u))
    }
    /// a month's days in words: "1 – 31 Oct 2026"; a running month "1 – 12 Nov so far", its first day "1 Nov so far"
    static func range(from: String, to: String, running: Bool, day: (String, String) -> String) -> String {
        if from == to { return day(from, running ? "d MMM" : "d MMM yyyy") + (running ? " so far" : "") }
        return day(from, "d") + " – " + day(to, running ? "d MMM" : "d MMM yyyy") + (running ? " so far" : "")
    }
    /// one bar of the six: the month, its spending, whether it is the one picked, whether it is still running or a part
    struct Bar: Hashable, Identifiable {
        let m: String
        let v: Double
        let picked: Bool
        let part: Bool
        var id: String { m }
    }
    /// the six months ending at m, oldest first, of those kosh has
    static func six(_ m: String, months: [String], cm: String, partial: Set<String>, spent: (String) -> Double) -> [Bar] {
        let list: [String] = Array(months.filter { $0 <= m }.sorted().suffix(6))
        return list.map { (x: String) -> Bar in Bar(m: x, v: spent(x), picked: x == m, part: x == cm || partial.contains(x)) }
    }
    /// one kind of spending's line: its figure and its share of the biggest (for the bar's length)
    struct Kind: Hashable, Identifiable {
        let cat: String
        let v: Double
        let share: Double
        var id: String { cat }
    }
    /// where it went, biggest first; the kinds under ₹1 left out; the rest after `top` folded into "Everything else"
    static func kinds(_ cats: [String: Double], top: Int = 6) -> [Kind] {
        let sorted: [(String, Double)] = cats.filter { $0.value >= 1 }.sorted { a, b in a.value != b.value ? a.value > b.value : a.key < b.key }
        var rows: [(String, Double)] = Array(sorted.prefix(top))
        let rest: Double = sorted.dropFirst(top).reduce(0) { $0 + $1.1 }
        if rest >= 1 { rows.append(("Everything else", rest)) }
        let most: Double = rows.map(\.1).max() ?? 0
        return rows.map { (r: (String, Double)) -> Kind in Kind(cat: r.0, v: r.1, share: most > 0 ? r.1 / most : 0) }
    }
    /// a name's initials for its avatar: "Sample Glow" → "SG", "zomato" → "Z"
    static func initials(_ name: String) -> String {
        let words: [Substring] = name.split(whereSeparator: { !$0.isLetter && !$0.isNumber })
        let firsts: [String] = words.prefix(2).compactMap { $0.first.map { String($0).uppercased() } }
        return firsts.joined()
    }
}
