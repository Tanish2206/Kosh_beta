import SwiftUI

// MARK: - The notebook's photographs
//
// Each sample page in the Chapters notebook has a small taped photo: a scene drawn in layers (sky, ground, the
// place, little things that move), in the same inks as the chapter's stamps. Each layer is an SVG path in a
// 240 × 150 box, filled and/or stroked, drawn with SVGShape like the rest of Chapters' art. A few layers move
// gently (steam off chai, a diya's flame, a mobile over a crib, a bullet train going by) while the page is the
// one open; with Reduce Motion they stay still, as drawn. Your own chapters borrow these: a trip gets the travel
// scene, a wedding or a festival the mandap, a move the house, and so on (NotebookMaker.scene), re-inked in the
// chapter's colour where the drawing allows it (SceneTint).

/// how a layer moves, if it does
enum SceneMotion {
    case rest, steam, flicker, twinkle, bob, sway, whoosh, drift

    /// where a layer is at a moment: moved, turned and scaled about an anchor (in the drawing's units), and how
    /// visible
    struct Pose {
        var tx: CGFloat = 0
        var ty: CGFloat = 0
        var sx: CGFloat = 1
        var sy: CGFloat = 1
        var rot: Double = 0
        var op: Double = 1
        var ax: CGFloat = 120
        var ay: CGFloat = 75
    }

    /// ease in and out (close to CSS's ease-in-out)
    static func ease(_ p: Double) -> Double { p * p * (3 - 2 * p) }
    /// how far through a cycle, 0…1
    static func phase(_ t: Double, _ period: Double) -> Double {
        let x: Double = t / period
        return x - x.rounded(.down)
    }
    /// there and back, one way per period, eased each way
    static func swing(_ t: Double, _ period: Double) -> Double {
        let x: Double = t / period
        let n: Double = x.rounded(.down)
        var p: Double = x - n
        if n.truncatingRemainder(dividingBy: 2) != 0 { p = 1 - p }
        return ease(p)
    }

    /// the pose at a moment; with no moment (Reduce Motion, or a page that isn't open) it's as drawn
    func pose(_ t: Double?, _ d: String) -> Pose {
        var o = Pose()
        guard let t else { return o }
        switch self {
        case .rest:
            break
        case .steam:
            let p: Double = Self.phase(t, 3.4)
            o.ty = CGFloat(3 - 10 * Self.ease(p))
            o.op = p < 0.35 ? 0.85 * Self.ease(p / 0.35) : 0.85 * (1 - Self.ease((p - 0.35) / 0.65))
        case .flicker:
            let p: Double = Self.swing(t, 1.3)
            o.sx = CGFloat(1 - 0.14 * p)
            o.sy = CGFloat(1 + 0.12 * p)
            let b: CGRect = SVGPath.path(d).boundingRect
            o.ax = b.midX
            o.ay = b.maxY
        case .twinkle:
            let p: Double = Self.phase(t, 2.6)
            let up: Double = p < 0.5 ? p * 2 : (1 - p) * 2
            o.op = 0.3 + 0.7 * Self.ease(up)
        case .bob:
            o.ty = CGFloat(-4 * Self.swing(t, 3.2))
        case .sway:
            o.rot = -5 + 10 * Self.swing(t, 3.6)
            o.ax = 100
            o.ay = 0
        case .whoosh:
            let p: Double = Self.phase(t, 6)
            o.tx = CGFloat(-40 + 76 * Self.ease(p))
            o.op = p < 0.12 ? p / 0.12 : (p > 0.8 ? (1 - p) / 0.2 : 1)
        case .drift:
            let p: Double = Self.swing(t, 5)
            o.tx = CGFloat(4 * p)
            o.ty = CGFloat(6 * p)
            o.rot = 40 * p
            let b: CGRect = SVGPath.path(d).boundingRect
            o.ax = b.midX
            o.ay = b.midY
        }
        return o
    }
}

/// one layer of a scene: a path in a 240 × 150 box, its fill and line (hex, or "paper", "kosh", "kosh:0.3")
struct SceneLayer {
    let d: String
    var fill: String = ""
    var stroke: String = ""
    var lw: CGFloat = 0
    var alpha: Double = 1
    var dash: [CGFloat] = []
    var motion: SceneMotion = .rest
    /// how far into its cycle it starts, so neighbours don't move in step
    var delay: Double = 0
}

/// hex colours as numbers: their channels, their hue, saturation and brightness, and mixes of them
enum InkMath {
    /// red, green and blue, each 0…1
    static func rgb(_ hex: String) -> (r: Double, g: Double, b: Double) {
        var s: String = hex.trimmingCharacters(in: .whitespaces)
        if s.hasPrefix("#") { s.removeFirst() }
        let v: UInt64 = UInt64(s, radix: 16) ?? 0
        return (r: Double((v >> 16) & 0xFF) / 255, g: Double((v >> 8) & 0xFF) / 255, b: Double(v & 0xFF) / 255)
    }

    /// hue, saturation and brightness, each 0…1
    static func hsb(_ hex: String) -> (h: Double, s: Double, b: Double) {
        let c = rgb(hex)
        let mx: Double = max(c.r, c.g, c.b)
        let mn: Double = min(c.r, c.g, c.b)
        let d: Double = mx - mn
        var h: Double = 0
        if d > 0 {
            if mx == c.r {
                h = (c.g - c.b) / d
                if h < 0 { h += 6 }
            } else if mx == c.g {
                h = (c.b - c.r) / d + 2
            } else {
                h = (c.r - c.g) / d + 4
            }
            h /= 6
        }
        return (h: h, s: mx > 0 ? d / mx : 0, b: mx)
    }

    /// a hex colour taken t of the way toward black (deeper) or white (paler), as hex
    static func deeper(_ hex: String, _ t: Double) -> String { mix(hex, 0, t) }
    static func paler(_ hex: String, _ t: Double) -> String { mix(hex, 1, t) }

    static func mix(_ hex: String, _ to: Double, _ t: Double) -> String {
        let c = rgb(hex)
        func ch(_ a: Double) -> Int { max(0, min(255, Int(((a + (to - a) * t) * 255).rounded()))) }
        return String(format: "#%02X%02X%02X", ch(c.r), ch(c.g), ch(c.b))
    }
}

/// A scene re-inked for a chapter of yours: every colour near the scene's own ink (within about 20° of its hue)
/// turns to the chapter's hue, keeping how light it was; gold, white and anything else stays as drawn.
struct SceneTint: Hashable {
    /// the scene's own ink's hue, and the chapter's (0…1)
    let base: Double
    let hue: Double
    /// how much richer, or quieter, the chapter's ink is than the scene's
    let sat: Double
    var key: String { "\(Int(base * 1000))-\(Int(hue * 1000))-\(Int(sat * 100))" }
}

/// a scene's colours: the photo's own hex inks, or, for the blank page drawn on the paper, the paper and the accent
@MainActor
enum SceneInk {
    private static var cache: [String: Color] = [:]

    static func color(_ s: String, _ tint: SceneTint? = nil) -> Color {
        if s == "paper" { return NotebookInk.paper }
        if s.hasPrefix("kosh") {
            let parts: [Substring] = s.split(separator: ":")
            if parts.count == 2, let a = Double(parts[1]) { return Color.kosh.mix(with: NotebookInk.paper, by: 1 - a) }
            return Color.kosh
        }
        let key: String = tint.map { s + "|" + $0.key } ?? s
        if let c = cache[key] { return c }
        var c = Color(hex: s)
        if let tint {
            let o = InkMath.hsb(s)
            var dh: Double = o.h - tint.base
            if dh > 0.5 { dh -= 1 } else if dh < -0.5 { dh += 1 }
            if o.s >= 0.05 && abs(dh) < 0.056 {
                var h: Double = tint.hue + dh
                if h < 0 { h += 1 } else if h >= 1 { h -= 1 }
                c = Color(hue: h, saturation: min(1, o.s * tint.sat), brightness: o.b)
            }
        }
        cache[key] = c
        return c
    }
}

/// a scene, fitted into its frame as SVG's xMidYMid meet would (centred, whole); it moves only while `live`
struct NotebookScene: View {
    /// off while its tab is behind another (kosh keeps visited tabs alive): its animation rests
    @Environment(\.tabActive) private var tabActive
    let layers: [SceneLayer]
    var live: Bool = false
    /// re-inked for one of your chapters; nil: as drawn
    var tint: SceneTint? = nil
    @Environment(\.accessibilityReduceMotion) private var still

    var body: some View {
        if live && !still {
            TimelineView(.animation(minimumInterval: 1.0 / 30, paused: !tabActive)) { ctx in
                SceneLayers(layers: layers, t: ctx.date.timeIntervalSinceReferenceDate, tint: tint)
            }
        } else {
            SceneLayers(layers: layers, t: nil, tint: tint)
        }
    }
}

struct SceneLayers: View {
    let layers: [SceneLayer]
    let t: Double?
    var tint: SceneTint? = nil

    var body: some View {
        GeometryReader { g in
            let s: CGFloat = min(g.size.width / 240, g.size.height / 150)
            ZStack(alignment: .topLeading) {
                ForEach(layers.indices, id: \.self) { i in
                    SceneLayerView(layer: layers[i], s: s, t: t, tint: tint)
                }
            }
            .frame(width: 240 * s, height: 150 * s, alignment: .topLeading)
            .position(x: g.size.width / 2, y: g.size.height / 2)
        }
        .accessibilityHidden(true)
    }
}

struct SceneLayerView: View {
    let layer: SceneLayer
    let s: CGFloat
    let t: Double?
    var tint: SceneTint? = nil

    var body: some View {
        let o: SceneMotion.Pose = layer.motion.pose(t.map { $0 + layer.delay }, layer.d)
        let anchor = UnitPoint(x: o.ax / 240, y: o.ay / 150)
        ZStack(alignment: .topLeading) {
            if !layer.fill.isEmpty {
                SVGShape(d: layer.d, box: 240).fill(SceneInk.color(layer.fill, tint))
            }
            if !layer.stroke.isEmpty {
                SVGShape(d: layer.d, box: 240)
                    .stroke(SceneInk.color(layer.stroke, tint),
                            style: StrokeStyle(lineWidth: layer.lw * s, lineCap: .round, lineJoin: .round, dash: layer.dash.map { $0 * s }))
            }
        }
        .frame(width: 240 * s, height: 150 * s)
        .scaleEffect(x: o.sx, y: o.sy, anchor: anchor)
        .rotationEffect(.degrees(o.rot), anchor: anchor)
        .offset(x: o.tx * s, y: o.ty * s)
        .opacity(layer.alpha * o.op)
    }
}

// MARK: the scenes

enum NotebookScenes {
    static func layers(_ id: String) -> [SceneLayer] {
        switch id {
        case "msc": return msc
        case "wedding": return wedding
        case "home": return home
        case "japan": return japan
        case "studio": return studio
        case "baby": return baby
        case "travel": return travel
        case "hills": return hills
        case "car": return car
        default: return blank
        }
    }

    /// the ink each scene is drawn around, for the ones that can wear a chapter's colour. The house and the
    /// studio are brick and wood, close in hue to the gold in every scene, so they stay as drawn.
    static func baseInk(_ id: String) -> String? {
        switch id {
        case "msc": return "#166534"
        case "wedding": return "#9F1D3A"
        case "japan", "travel": return "#C2412D"
        case "baby": return "#4F46E5"
        case "hills", "car": return "#2F6DB5"
        default: return nil
        }
    }

    /// a scene re-inked in a chapter's colour; nil when the scene stays as drawn, or the colour is too grey to
    /// carry a hue
    static func tint(_ scene: String, ink: String) -> SceneTint? {
        guard let base = baseInk(scene) else { return nil }
        let a = InkMath.hsb(base)
        let b = InkMath.hsb(ink)
        if b.s < 0.12 { return nil }
        let ratio: Double = max(0.45, min(1.25, b.s / max(0.01, a.s)))
        return SceneTint(base: a.h, hue: b.h, sat: ratio)
    }

    static func L(_ d: String, fill: String = "", stroke: String = "", lw: CGFloat = 0, alpha: Double = 1,
                  dash: [CGFloat] = [], motion: SceneMotion = .rest, delay: Double = 0) -> SceneLayer {
        SceneLayer(d: d, fill: fill, stroke: stroke, lw: lw, alpha: alpha, dash: dash, motion: motion, delay: delay)
    }

    /// the MSc year: the department building, a stack of books, a steaming bowl of Maggi, a mortarboard
    static let msc: [SceneLayer] = [
        L("M56 72a64 64 0 1 0 128 0a64 64 0 1 0 -128 0", fill: "#DAE9DF"),
        L("M-300 128H540V220H-300Z", fill: "#CBDFD2"),
        L("M208 128V104", stroke: "#77A689", lw: 3.2),
        L("M208 74c-13 0-20 11-17 20 2 8 9 11 17 11s15-3 17-11c3-9-4-20-17-20z", fill: "#9BBFA9"),
        L("M48 124h144v6H48z", fill: "#BED6C7"),
        L("M56 118h128v6H56z", fill: "#A8C8B4"),
        L("M64 66h112v52H64z", fill: "#FFFDF8", stroke: "#166534", lw: 1.6),
        L("M78 72v42M94 72v42M110 72v42M130 72v42M146 72v42M162 72v42", stroke: "#93B9A1", lw: 4.4),
        L("M114 118V98a6 6 0 0 1 12 0v20z", fill: "#166534"),
        L("M58 60h124v7H58z", fill: "#97BCA5"),
        L("M120 30V19", stroke: "#166534", lw: 1.2),
        L("M120 19h11l-3 3.2 3 3.2h-11z", fill: "#E9A23B"),
        L("M56 60 120 30l64 30z", fill: "#C2D9CA", stroke: "#166534", lw: 1.6),
        L("M114 48a6 6 0 1 0 12 0a6 6 0 1 0 -12 0", fill: "#FFFDF8", stroke: "#166534", lw: 1.3),
        L("M120 44.6V48l2.4 1.6", stroke: "#166534", lw: 1.2),
        L("M10 120h52v9H10z", fill: "#166534"),
        L("M14 124.5h44", stroke: "#FFFDF8", lw: 1, alpha: 0.5),
        L("M16 111h44v9H16z", fill: "#7DAB8E"),
        L("M20 115.5h36", stroke: "#FFFDF8", lw: 1, alpha: 0.5),
        L("M8 102h48v9H8z", fill: "#B1CDBB", stroke: "#166534", lw: 1.2),
        L("M18 95a12 7 0 0 0 24 0z", fill: "#E9A23B"),
        L("M21 94c1.5-2.5 3 0 4.5-1.5s3 0 4.5-1.5 3 0 4.5-1.5 3 0 4.5-1.5", stroke: "#EE8A1E", lw: 1.6),
        L("M16.5 95h27", stroke: "#166534", lw: 1.6),
        L("M25 88c-2-3 2-5 0-8M33 88c-2-3 2-5 0-8", stroke: "#8CB59B", lw: 1.4, motion: .steam),
        L("M220 26c2 6 2 10 0 15", stroke: "#E9A23B", lw: 1.8),
        L("M181 30v7c8 5 18 5 26 0v-7z", fill: "#6C9F7F"),
        L("M166 24 194 13l28 12-28 11z", fill: "#166534"),
        L("M192.2 24.5a1.8 1.8 0 1 0 3.6 0a1.8 1.8 0 1 0 -3.6 0", fill: "#E9A23B"),
        L("M218 41h4l-.6 6h-2.8z", fill: "#E9A23B"),
        L("M150 40l8-3M152 48l7-1", stroke: "#97BCA5", lw: 1.4),
        L("M146 14Q146 18 150 18Q146 18 146 22Q146 18 142 18Q146 18 146 14Z", fill: "#E9A23B", motion: .twinkle),
        L("M234 52.5Q234 56 237.5 56Q234 56 234 59.5Q234 56 230.5 56Q234 56 234 52.5Z", fill: "#E9A23B", motion: .twinkle, delay: 1.3),
        L("M32 61Q32 64 35 64Q32 64 32 67Q32 64 29 64Q32 64 32 61Z", fill: "#97BCA5", motion: .twinkle, delay: 2.4)
    ]

    /// the wedding: a mandap hung with marigolds, a diya, petals drifting
    static let wedding: [SceneLayer] = [
        L("M58 70a62 62 0 1 0 124 0a62 62 0 1 0 -124 0", fill: "#F4DDE2"),
        L("M-300 132H540V220H-300Z", fill: "#F0D5DB"),
        L("M76 142a44 6 0 1 0 88 0a44 6 0 1 0-88 0", stroke: "#E9A23B", lw: 1.4, dash: [2, 3]),
        L("M44 126h152v7H44z", fill: "#E3B8C1"),
        L("M54 120h132v6H54z", fill: "#D69AA8"),
        L("M86 120V70h5v50zM149 120V70h5v50z", fill: "#DCA7B3"),
        L("M58 56C58 32 88 18 120 12c32 6 62 20 62 44z", fill: "#EAC8D0", stroke: "#9F1D3A", lw: 1.6),
        L("M120 13v43M92 24c5 10 7 21 7 32M148 24c-5 10-7 21-7 32", stroke: "#D496A4", lw: 1.1),
        L("M120 12V5", stroke: "#9F1D3A", lw: 1.8),
        L("M117.4 4a2.6 2.6 0 1 0 5.2 0a2.6 2.6 0 1 0 -5.2 0", fill: "#E9A23B"),
        L("M56 56h128v8H56z", fill: "#9F1D3A"),
        L("M56 64q8 9 16 0q8 9 16 0q8 9 16 0q8 9 16 0q8 9 16 0q8 9 16 0q8 9 16 0q8 9 16 0", fill: "#ECCDD4", stroke: "#9F1D3A", lw: 1.3),
        L("M62 120V64h9v56zM169 120V64h9v56z", fill: "#9F1D3A"),
        L("M59 64h15v4H59zM166 64h15v4h-15z", fill: "#E9A23B"),
        L("M66.5 72v44M173.5 72v44", stroke: "#EE8A1E", lw: 4.4, dash: [0.1, 6.2]),
        L("M74 68q23 26 46 0q23 26 46 0", stroke: "#EE8A1E", lw: 4.6, dash: [0.1, 6]),
        L("M74 68q23 16 46 0q23 16 46 0", stroke: "#E9A23B", lw: 3.8, dash: [0.1, 5.4]),
        L("M120 66v14", stroke: "#E9A23B", lw: 3.6, dash: [0.1, 5]),
        L("M117.6 84a2.4 2.4 0 1 0 4.8 0a2.4 2.4 0 1 0 -4.8 0", fill: "#E9A23B"),
        L("M107 120l2.5-8h21l2.5 8z", fill: "#9F1D3A"),
        L("M120 111c-5.5-4-5.5-10.5 0-17 5.5 6.5 5.5 13 0 17z", fill: "#E9A23B", motion: .flicker),
        L("M120 110c-2.2-2-2.2-5 0-8.5 2.2 3.5 2.2 6.5 0 8.5z", fill: "#EE8A1E", motion: .flicker),
        L("M28 38c3-3 8-2 8 1-3 3-8 2-8-1z", fill: "#D2909F", motion: .drift),
        L("M206 30c3-3 8-2 8 1-3 3-8 2-8-1z", fill: "#EE8A1E", motion: .drift, delay: 1.3),
        L("M34 96c3-3 8-2 8 1-3 3-8 2-8-1z", fill: "#E9A23B", motion: .drift, delay: 2.4),
        L("M208 92c3-3 8-2 8 1-3 3-8 2-8-1z", fill: "#D2909F", motion: .drift, delay: 1.3),
        L("M18 61Q18 64 21 64Q18 64 18 67Q18 64 15 64Q18 64 18 61Z", fill: "#E9A23B", motion: .twinkle),
        L("M224 58.5Q224 62 227.5 62Q224 62 224 65.5Q224 62 220.5 62Q224 62 224 58.5Z", fill: "#E9A23B", motion: .twinkle, delay: 2.4)
    ]

    /// a new home: the house with a toran, plants, the key
    static let home: [SceneLayer] = [
        L("M173 40a17 17 0 1 0 34 0a17 17 0 1 0 -34 0", fill: "#E9A23B", alpha: 0.42),
        L("M-300 112C-100 100 40 98 120 108S300 98 540 104V220H-300Z", fill: "#EBDDD5"),
        L("M-300 128H540V220H-300Z", fill: "#E4D2C8"),
        L("M110 128 100 150h40l-10-22z", fill: "#FFFDF8", alpha: 0.55),
        L("M146 34h11v24h-11z", fill: "#AA7B68"),
        L("M76 70h88v58H76z", fill: "#FFFDF8", stroke: "#7A3418", lw: 1.8),
        L("M64 72 120 28l56 44z", fill: "#7A3418"),
        L("M80 60h80M93 50h54M106 40h28", stroke: "#CAAD9E", lw: 1.2),
        L("M86 82h18v18H86zM136 82h18v18h-18z", fill: "#E9A23B", alpha: 0.38),
        L("M86 82h18v18H86zM136 82h18v18h-18z", stroke: "#7A3418", lw: 1.5),
        L("M95 82v18M86 91h18M145 82v18M136 91h18", stroke: "#7A3418", lw: 1.1),
        L("M110 128v-26a10 10 0 0 1 20 0v26z", fill: "#9D6953"),
        L("M123.9 115a1.6 1.6 0 1 0 3.2 0a1.6 1.6 0 1 0 -3.2 0", fill: "#E9A23B"),
        L("M103 92q17 11 34 0", stroke: "#5E8C5A", lw: 3.4, dash: [0.1, 5]),
        L("M106 95q14 10 28 0", stroke: "#EE8A1E", lw: 3, dash: [0.1, 7]),
        L("M182 128l3-13h16l3 13z", fill: "#AF8370"),
        L("M181 115h22v3h-22z", fill: "#A06C57"),
        L("M193 115c-1-10-7-15-14-15 1 8 6 13 14 15z", fill: "#5E8C5A"),
        L("M193 115c1-12 7-18 15-19-1 9-7 15-15 19z", fill: "#7FA86B"),
        L("M193 115c0-9 2-16 6-21 1 8-1 15-6 21z", fill: "#5E8C5A"),
        L("M42 128l2-10h12l2 10z", fill: "#BC9685"),
        L("M50 118c-6-2-10-8-9-14 6 2 9 7 9 14z", fill: "#7FA86B"),
        L("M50 118c4-5 9-7 14-6-2 5-7 7-14 6z", fill: "#5E8C5A"),
        L("M30 46a8 8 0 1 0 16 0a8 8 0 1 0 -16 0", stroke: "#E9A23B", lw: 3, motion: .bob),
        L("M46 46h24M64 46v7M70 46v5", stroke: "#E9A23B", lw: 3, motion: .bob),
        L("M80 24.5Q80 28 83.5 28Q80 28 80 31.5Q80 28 76.5 28Q80 28 80 24.5Z", fill: "#E9A23B", motion: .twinkle),
        L("M220 71Q220 74 223 74Q220 74 220 77Q220 74 217 74Q220 74 220 71Z", fill: "#E9A23B", motion: .twinkle, delay: 1.3),
        L("M18 19.4Q18 22 20.6 22Q18 22 18 24.6Q18 22 15.4 22Q18 22 18 19.4Z", fill: "#C6A596", motion: .twinkle, delay: 2.4)
    ]

    /// Japan: Fuji at sunset, a torii, cherry blossom, the bullet train going by
    static let japan: [SceneLayer] = [
        L("M156 44a20 20 0 1 0 40 0a20 20 0 1 0 -40 0", fill: "#C2412D", alpha: 0.88),
        L("M-300 118H20L40 102l14 8 22-18 24 24H540V220H-300Z", fill: "#F5D9D3"),
        L("M56 128 112 60q8-8 16 0l64 68z", fill: "#EDC1B9"),
        L("M112 60q8-8 16 0l9 11-7-3-6 6-5-7-6 7-6-6-5 4z", fill: "#FFFDF8"),
        L("M-300 128H540V220H-300Z", fill: "#F3D2CC"),
        L("M84 128h72l-36 16z", fill: "#EEC4BD", alpha: 0.6),
        L("M20 138h26M64 144h18M152 137h30M196 143h24", stroke: "#FFFDF8", lw: 1.6, alpha: 0.9),
        L("M132 126.5h96", stroke: "#DF988C", lw: 1.2),
        L("M138 118h62c9 0 14 3 18 8.5H138z", fill: "#FFFDF8", stroke: "#C2412D", lw: 1.3, motion: .whoosh),
        L("M144 121.5h46", stroke: "#DC8F82", lw: 2.2, dash: [4, 2.5], motion: .whoosh),
        L("M138 124.4h78", stroke: "#C2412D", lw: 1, motion: .whoosh),
        L("M28 78h7l1.2 50h-9.4zM70 78h7l1.2 50h-9.4z", fill: "#C2412D"),
        L("M26 124h11v4H26zM68 124h11v4H68z", fill: "#882E1F"),
        L("M20 88h64v5H20z", fill: "#C2412D"),
        L("M49 79h6v9h-6z", fill: "#C2412D"),
        L("M17 73h70v5.5H17z", fill: "#C2412D"),
        L("M10 66q42-9 84 0l-2.5 7q-39.5-7-79 0z", fill: "#9B3424"),
        L("M-4 16C18 22 38 18 56 8M30 19c4 5 10 7 16 6", stroke: "#923122", lw: 2.2),
        L("M13.8 21a4.2 4.2 0 1 0 8.4 0a4.2 4.2 0 1 0 -8.4 0M34.4 15a3.6 3.6 0 1 0 7.2 0a3.6 3.6 0 1 0 -7.2 0M50.8 9a3.2 3.2 0 1 0 6.4 0a3.2 3.2 0 1 0 -6.4 0M42.6 25a3.4 3.4 0 1 0 6.8 0a3.4 3.4 0 1 0 -6.8 0M3 14a3 3 0 1 0 6 0a3 3 0 1 0 -6 0", fill: "#E4A59B"),
        L("M16.8 21a1.2 1.2 0 1 0 2.4 0a1.2 1.2 0 1 0 -2.4 0M37 15a1 1 0 1 0 2 0a1 1 0 1 0 -2 0M53.1 9a0.9 0.9 0 1 0 1.8 0a0.9 0.9 0 1 0 -1.8 0M45 25a1 1 0 1 0 2 0a1 1 0 1 0 -2 0", fill: "#E9A23B"),
        L("M70 34c2-2 6-1 6 1-2 2-6 1-6-1z", fill: "#E4A59B", motion: .drift),
        L("M96 22c2-2 6-1 6 1-2 2-6 1-6-1z", fill: "#E4A59B", motion: .drift, delay: 2.4),
        L("M140 20q4-4 8 0q4-4 8 0M158 30q3-3 6 0q3-3 6 0", stroke: "#C2412D", lw: 1.4)
    ]

    /// the studio: shelves, a desk with its first chart, chai, a lamp
    static let studio: [SceneLayer] = [
        L("M156 14h66v56h-66z", fill: "#FFFDF8", alpha: 0.7),
        L("M198 30a7 7 0 1 0 14 0a7 7 0 1 0 -14 0", fill: "#E9A23B", alpha: 0.55),
        L("M156 14h66v56h-66z", stroke: "#CBB09D", lw: 1.6),
        L("M189 14v56M156 42h66", stroke: "#CBB09D", lw: 1.4),
        L("M152 70h74v4h-74z", fill: "#CBB09D"),
        L("M14 46h78v4H14z", fill: "#A97D62"),
        L("M20 26h8v20h-8z", fill: "#78350F"),
        L("M29 30h7v16h-7z", fill: "#BE9D87"),
        L("M37 22h9v24h-9z", fill: "#9E6E50"),
        L("M47 28h6v18h-6z", fill: "#E9A23B", alpha: 0.8),
        L("M54 33l3-1 4 13.5-3 .5z", fill: "#D2B9A8"),
        L("M73 46l1.4-8h10l1.4 8z", fill: "#B8947C"),
        L("M79 38c-1-6-5-9-10-9 1 5 4 8 10 9z", fill: "#5E8C5A"),
        L("M79 38c1-7 5-10 10-11-1 6-5 10-10 11z", fill: "#7FA86B"),
        L("M106 22h20v20h-20z", fill: "#E9A23B", alpha: 0.6),
        L("M130 30h18v18h-18z", fill: "#DCC8B9"),
        L("M110 29h12M110 34h8M134 37h10", stroke: "#78350F", lw: 1, alpha: 0.45),
        L("M31 58 12 104h50L41 63z", fill: "#E9A23B", alpha: 0.2),
        L("M8 104h224v7H8z", fill: "#78350F"),
        L("M18 111h6v39h-6zM216 111h6v39h-6z", fill: "#9E6E50"),
        L("M150 111h56v20h-56z", fill: "#D2B9A8"),
        L("M172 121h12", stroke: "#FFFDF8", lw: 2),
        L("M74 60h72a4 4 0 0 1 4 4v38H70V64a4 4 0 0 1 4-4z", fill: "#986446"),
        L("M75 65h70v33H75z", fill: "#FFFDF8"),
        L("M84 93v-6M93 93v-12M102 93v-9M111 93v-17M120 93v-13", stroke: "#78350F", lw: 3.4),
        L("M126 82l9-9M129 73h6v6", stroke: "#E9A23B", lw: 2),
        L("M60 102h100v2H60z", fill: "#B28A71"),
        L("M28 104h22l-2-4H30z", fill: "#78350F"),
        L("M39 100 50 75 36 55", stroke: "#78350F", lw: 2.6),
        L("M26 48l18 12-6 4-16-10z", fill: "#78350F"),
        L("M188 101h16v3h-16zM190 98h12v3h-12z", fill: "#E9A23B", alpha: 0.9),
        L("M168 86h14l-2 18h-10z", fill: "#FFFDF8", stroke: "#78350F", lw: 1.3),
        L("M168.9 92h12.2l-1.3 12h-9.6z", fill: "#C5A692"),
        L("M172 80c-2-3 2-5 0-8M178 80c-2-3 2-5 0-8", stroke: "#C5A692", lw: 1.4, motion: .steam),
        L("M140 47Q140 50 143 50Q140 50 140 53Q140 50 137 50Q140 50 140 47Z", fill: "#E9A23B", motion: .twinkle),
        L("M232 87.4Q232 90 234.6 90Q232 90 232 92.6Q232 90 229.4 90Q232 90 232 87.4Z", fill: "#E9A23B", motion: .twinkle, delay: 1.3)
    ]

    /// baby on the way: a crib under a mobile, the moon, a teddy
    static let baby: [SceneLayer] = [
        L("M-300 136H540V220H-300Z", fill: "#E5E2F9"),
        L("M200 16a26 26 0 1 0 24 36A22 22 0 0 1 200 16z", fill: "#E9A23B", alpha: 0.92),
        L("M160 17Q160 22 165 22Q160 22 160 27Q160 22 155 22Q160 22 160 17Z", fill: "#A9A4F1", motion: .twinkle),
        L("M228 80Q228 84 232 84Q228 84 228 88Q228 84 224 84Q228 84 228 80Z", fill: "#E9A23B", motion: .twinkle, delay: 1.3),
        L("M138 45Q138 48 141 48Q138 48 138 51Q138 48 135 48Q138 48 138 45Z", fill: "#E9A23B", motion: .twinkle, delay: 2.4),
        L("M20 26.6Q20 30 23.4 30Q20 30 20 33.4Q20 30 16.6 30Q20 30 20 26.6Z", fill: "#A9A4F1", motion: .twinkle, delay: 1.3),
        L("M50 53.4Q50 56 52.6 56Q50 56 50 58.6Q50 56 47.4 56Q50 56 50 53.4Z", fill: "#E9A23B", motion: .twinkle),
        L("M100 0v14", stroke: "#B1ACF2", lw: 1.4, motion: .sway),
        L("M74 14h52", stroke: "#9892EF", lw: 2, motion: .sway),
        L("M78 14v12M100 14v18M122 14v10", stroke: "#B1ACF2", lw: 1, motion: .sway),
        L("M78 25Q78 30 83 30Q78 30 78 35Q78 30 73 30Q78 30 78 25Z", fill: "#E9A23B", motion: .sway),
        L("M98 34a5.5 5.5 0 1 0 7 7 4.5 4.5 0 0 1-7-7z", fill: "#9892EF", motion: .sway),
        L("M115 30a4 4 0 0 1 4.5-4 5 5 0 0 1 9.5 1.5 3.4 3.4 0 0 1 0 6.5h-11a3 3 0 0 1-3-4z", fill: "#C1BDF4", motion: .sway),
        L("M40 76h132v48H40z", fill: "#FFFDF8"),
        L("M48 102c0-5 4-7 10-7h16c6 0 8 3 8 6v3H48z", fill: "#FFFDF8", stroke: "#B9B4F3", lw: 1.2),
        L("M42 104C80 96 132 96 170 104V124H42z", fill: "#C1BDF4"),
        L("M42 104C80 96 132 96 170 104", stroke: "#FFFDF8", lw: 2, alpha: 0.7),
        L("M98.6 112a1.4 1.4 0 1 0 2.8 0a1.4 1.4 0 1 0 -2.8 0M128.6 116a1.4 1.4 0 1 0 2.8 0a1.4 1.4 0 1 0 -2.8 0M148.6 110a1.4 1.4 0 1 0 2.8 0a1.4 1.4 0 1 0 -2.8 0M78.6 118a1.4 1.4 0 1 0 2.8 0a1.4 1.4 0 1 0 -2.8 0M60.6 111a1.4 1.4 0 1 0 2.8 0a1.4 1.4 0 1 0 -2.8 0", fill: "#FFFDF8", alpha: 0.75),
        L("M53 78v44M66 78v44M79 78v44M92 78v44M105 78v44M118 78v44M131 78v44M144 78v44M157 78v44", stroke: "#8079EC", lw: 2.2),
        L("M37 76h138M37 124h138", stroke: "#4F46E5", lw: 4.4),
        L("M37 64v74M175 64v74", stroke: "#4F46E5", lw: 6),
        L("M33 61a4 4 0 1 0 8 0a4 4 0 1 0 -8 0M171 61a4 4 0 1 0 8 0a4 4 0 1 0 -8 0", fill: "#E9A23B"),
        L("M24 144a96 5 0 1 0 192 0a96 5 0 1 0-192 0", fill: "#DBD8F8"),
        L("M197 128a9 9 0 1 0 18 0a9 9 0 1 0 -18 0M199 113a7 7 0 1 0 14 0a7 7 0 1 0 -14 0M197.7 107.5a2.8 2.8 0 1 0 5.6 0a2.8 2.8 0 1 0 -5.6 0M208.7 107.5a2.8 2.8 0 1 0 5.6 0a2.8 2.8 0 1 0 -5.6 0", fill: "#B1ACF2"),
        L("M203.4 115.5a2.6 2.6 0 1 0 5.2 0a2.6 2.6 0 1 0 -5.2 0", fill: "#FFFDF8"),
        L("M202.7 111.6a0.9 0.9 0 1 0 1.8 0a0.9 0.9 0 1 0 -1.8 0M207.5 111.6a0.9 0.9 0 1 0 1.8 0a0.9 0.9 0 1 0 -1.8 0", fill: "#4F46E5")
    ]

    /// any trip of yours: a mountain at sunset, a paper plane, a suitcase on the shore, a train going by. Japan's
    /// photo without the torii, so it reads as anywhere.
    static let travel: [SceneLayer] = [
        L("M156 44a20 20 0 1 0 40 0a20 20 0 1 0 -40 0", fill: "#C2412D", alpha: 0.88),
        L("M-300 118H20L40 102l14 8 22-18 24 24H540V220H-300Z", fill: "#F5D9D3"),
        L("M56 128 112 60q8-8 16 0l64 68z", fill: "#EDC1B9"),
        L("M112 60q8-8 16 0l9 11-7-3-6 6-5-7-6 7-6-6-5 4z", fill: "#FFFDF8"),
        L("M-300 128H540V220H-300Z", fill: "#F3D2CC"),
        L("M84 128h72l-36 16z", fill: "#EEC4BD", alpha: 0.6),
        L("M20 138h26M64 144h18M152 137h30M196 143h24", stroke: "#FFFDF8", lw: 1.6, alpha: 0.9),
        L("M132 126.5h96", stroke: "#DF988C", lw: 1.2),
        L("M138 118h62c9 0 14 3 18 8.5H138z", fill: "#FFFDF8", stroke: "#C2412D", lw: 1.3, motion: .whoosh),
        L("M144 121.5h46", stroke: "#DC8F82", lw: 2.2, dash: [4, 2.5], motion: .whoosh),
        L("M138 124.4h78", stroke: "#C2412D", lw: 1, motion: .whoosh),
        L("M32 102h28a4 4 0 0 1 4 4v18a4 4 0 0 1 -4 4H32a4 4 0 0 1 -4 -4v-18a4 4 0 0 1 4 -4z", fill: "#C2412D"),
        L("M39 102v-5a2 2 0 0 1 2 -2h10a2 2 0 0 1 2 2v5", stroke: "#882E1F", lw: 2.2),
        L("M36 102v26M56 102v26", stroke: "#882E1F", lw: 1.4, alpha: 0.5),
        L("M41 115a5 5 0 1 0 10 0a5 5 0 1 0 -10 0", fill: "#E9A23B"),
        L("M33 130a1.6 1.6 0 1 0 3.2 0a1.6 1.6 0 1 0 -3.2 0M55.8 130a1.6 1.6 0 1 0 3.2 0a1.6 1.6 0 1 0 -3.2 0", fill: "#882E1F"),
        L("M16 58c-6 4-11 3-17 8", stroke: "#DF988C", lw: 1.4, dash: [3, 3], motion: .bob),
        L("M18 54 58 36 44 62z", fill: "#FFFDF8", stroke: "#C2412D", lw: 1.4, motion: .bob),
        L("M58 36 38 52 44 62", stroke: "#C2412D", lw: 1.1, motion: .bob),
        L("M-4 16C18 22 38 18 56 8M30 19c4 5 10 7 16 6", stroke: "#923122", lw: 2.2),
        L("M13.8 21a4.2 4.2 0 1 0 8.4 0a4.2 4.2 0 1 0 -8.4 0M34.4 15a3.6 3.6 0 1 0 7.2 0a3.6 3.6 0 1 0 -7.2 0M50.8 9a3.2 3.2 0 1 0 6.4 0a3.2 3.2 0 1 0 -6.4 0M42.6 25a3.4 3.4 0 1 0 6.8 0a3.4 3.4 0 1 0 -6.8 0M3 14a3 3 0 1 0 6 0a3 3 0 1 0 -6 0", fill: "#E4A59B"),
        L("M16.8 21a1.2 1.2 0 1 0 2.4 0a1.2 1.2 0 1 0 -2.4 0M37 15a1 1 0 1 0 2 0a1 1 0 1 0 -2 0M53.1 9a0.9 0.9 0 1 0 1.8 0a0.9 0.9 0 1 0 -1.8 0M45 25a1 1 0 1 0 2 0a1 1 0 1 0 -2 0", fill: "#E9A23B"),
        L("M96 22c2-2 6-1 6 1-2 2-6 1-6-1z", fill: "#E4A59B", motion: .drift, delay: 2.4),
        L("M140 20q4-4 8 0q4-4 8 0M158 30q3-3 6 0q3-3 6 0", stroke: "#C2412D", lw: 1.4),
        L("M226 84.5Q226 88 229.5 88Q226 88 226 91.5Q226 88 222.5 88Q226 88 226 84.5Z", fill: "#E9A23B", motion: .twinkle, delay: 1.3)
    ]

    /// any other chapter: a sun over rolling hills, a path up to a pennant, birds, clouds, a little confetti
    static let hills: [SceneLayer] = [
        L("M148 52a34 34 0 1 0 68 0a34 34 0 1 0 -68 0", fill: "#E9A23B", alpha: 0.18, motion: .twinkle),
        L("M160 52a22 22 0 1 0 44 0a22 22 0 1 0 -44 0", fill: "#E9A23B", alpha: 0.88),
        L("M30 46a7 7 0 0 1 12 -4a9 9 0 0 1 17 3a6 6 0 0 1 -1 12H33a6 6 0 0 1 -3 -11z", fill: "#FFFDF8", alpha: 0.95, motion: .bob),
        L("M92 30a5 5 0 0 1 9 -3a7 7 0 0 1 13 2a4 4 0 0 1 -1 8H95a4 4 0 0 1 -3 -7z", fill: "#FFFDF8", alpha: 0.9, motion: .bob, delay: 1.6),
        L("M124 22q4-4 8 0q4-4 8 0M142 32q3-3 6 0q3-3 6 0", stroke: "#1F4F8A", lw: 1.4),
        L("M-300 100C-120 92 10 74 70 82S160 102 200 88S280 76 540 90V220H-300Z", fill: "#DCE7F5"),
        L("M-300 120C-80 112 30 94 104 102S206 124 540 106V220H-300Z", fill: "#C4D6EE"),
        L("M-300 134C-60 128 80 122 150 128S300 140 540 132V220H-300Z", fill: "#A9C3E6"),
        L("M122 150C110 142 134 136 124 128S104 116 114 106", stroke: "#FFFDF8", lw: 3, alpha: 0.9, dash: [5, 4]),
        L("M114 106V80", stroke: "#1F4F8A", lw: 1.6),
        L("M114 80l20 6-20 6z", fill: "#2F6DB5"),
        L("M40 132V114", stroke: "#1F4F8A", lw: 2.4),
        L("M28 112a12 12 0 1 0 24 0a12 12 0 1 0 -24 0", fill: "#2F6DB5"),
        L("M37 104a8 8 0 1 0 16 0a8 8 0 1 0 -16 0", fill: "#4E86C8"),
        L("M213 131V122", stroke: "#1F4F8A", lw: 1.8),
        L("M206 120a7 7 0 1 0 14 0a7 7 0 1 0 -14 0", fill: "#4E86C8"),
        L("M196 100h5v3h-5z", fill: "#2F6DB5", motion: .drift),
        L("M64 70h4v4h-4z", fill: "#E9A23B", motion: .drift, delay: 1.3),
        L("M222 70a2 2 0 1 0 4 0a2 2 0 1 0 -4 0", fill: "#4E86C8", motion: .drift, delay: 2.4),
        L("M16 84l4-2 1 3-4 2z", fill: "#EE8A1E", motion: .drift, delay: 0.7),
        L("M146 10Q146 14 150 14Q146 14 146 18Q146 14 142 14Q146 14 146 10Z", fill: "#E9A23B", motion: .twinkle),
        L("M230 104Q230 107 233 107Q230 107 230 110Q230 107 227 107Q230 107 230 104Z", fill: "#2F6DB5", motion: .twinkle, delay: 1.3)
    ]

    /// the blank page: a dashed card waiting, a pen
    static let blank: [SceneLayer] = [
        L("M60 76a60 60 0 1 0 120 0a60 60 0 1 0 -120 0", fill: "kosh:0.13"),
        L("M-300 132H540V220H-300Z", fill: "kosh:0.15"),
        L("M84 30h72v92H84z", fill: "paper", stroke: "kosh", lw: 1.6, dash: [5, 4]),
        L("M94 52h52M94 64h52M94 76h40", stroke: "kosh:0.3", lw: 2),
        L("M108 98a12 12 0 1 0 24 0a12 12 0 1 0 -24 0", fill: "kosh:0.17", stroke: "kosh", lw: 1.4),
        L("M120 92v12M114 98h12", stroke: "kosh", lw: 1.8),
        L("M150 26 176 52l-6 6-26-26z", fill: "kosh"),
        L("M144 32l-10-4 4 10z", fill: "#E9A23B"),
        L("M64 36Q64 40 68 40Q64 40 64 44Q64 40 60 40Q64 40 64 36Z", fill: "#E9A23B", motion: .twinkle),
        L("M186 88.5Q186 92 189.5 92Q186 92 186 95.5Q186 92 182.5 92Q186 92 186 88.5Z", fill: "#E9A23B", motion: .twinkle, delay: 1.3),
        L("M70 103Q70 106 73 106Q70 106 70 109Q70 106 67 106Q70 106 70 103Z", fill: "kosh:0.45", motion: .twinkle, delay: 2.4)
    ]
}
