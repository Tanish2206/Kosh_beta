import Foundation

// MARK: - The live view, screen-free: what the engine hands back, and the views pinned to Home
//
// A question becomes a plan (what to show) and a fill (what it comes to), both made by Kosh/viewplan.js: the plan by
// kosh's own reading of the question or by Apple's on-device model (checked against the schema there), the fill by the
// same rules Ask kosh answers with. Nothing here works out a figure: it decodes them, and keeps the plans you pinned.
// A pinned plan is the question asked again on each build ("this month" stays this month), never figures frozen.
// Foundation only: engine-test/liveview-swift.js compiles it with swiftc.

/// one drawn answer's figures, as viewplan.js fills them; every number in it came from the engine
struct LiveFill: Decodable, Hashable {
    struct Range: Decodable, Hashable {
        let from: String; let to: String; let words: String; let dates: String
    }
    /// what it was held against: the same stretch before, by default
    struct Delta: Decodable, Hashable {
        let value: Double; let prev: Double; let words: String; let dates: String
    }
    struct Figure: Decodable, Hashable {
        let value: Double; let label: String
        var sub: String? = nil
        /// a figure that can be below nothing (net worth): drawn with its minus
        var signed: Bool? = nil
        var delta: Delta? = nil
    }
    /// a bar, a slice, a month or a row: its key, its name, its figure
    struct Point: Decodable, Hashable, Identifiable {
        let k: String; let label: String; let value: Double
        var n: Int? = nil
        /// its share of the whole, in percent
        var share: Int? = nil
        /// the running month
        var live: Bool? = nil
        /// a comparison's other side, and the change
        var prev: Double? = nil
        var delta: Double? = nil
        var sub: String? = nil
        /// "N others together"
        var rest: Bool? = nil
        var id: String { k }
    }
    /// one payment, bill or refund on a timeline
    struct Item: Decodable, Hashable {
        var ref: String? = nil
        let d: String; let title: String; let sub: String; let value: Double; let dir: String; let when: String
        var state: String? = nil
        enum CodingKeys: String, CodingKey { case ref = "id", d, title, sub, value, dir, when, state }
    }
    struct DayCell: Decodable, Hashable, Identifiable {
        let d: String; let value: Double; let n: Int
        var id: String { d }
    }
    struct Side: Decodable, Hashable {
        let label: String; let value: Double; let n: Int; let dates: String
    }
    struct Compare: Decodable, Hashable {
        let a: Side; let b: Side; let diff: Double
        var pct: Int? = nil
    }
    let v: Int
    let fact: String
    let picture: String
    /// rupees, or a count of payments
    let unit: String
    let range: Range
    let title: String
    /// the line under the question, its numbers the engine's
    let answer: String
    /// where it came from, with its dates: "From your bank, card and UPI mail · 1 Oct – 30 Oct 2026 · 52 payments"
    let source: String
    /// why there's nothing to draw, said plainly ("" when there is)
    let blank: String
    /// questions to tap next, each reshaping this view
    let follow: [String]
    let series: [Point]
    let items: [Item]
    let days: [DayCell]
    /// the payments behind it
    let rows: [String]
    var figure: Figure? = nil
    var compare: Compare? = nil
    var usual: Double? = nil
    /// the bar or day to mark (the biggest month, the heaviest day)
    var mark: String? = nil
    var note: String? = nil
    /// how many more rows than are shown
    var more: Int? = nil
    var total: Double? = nil

    var isBlank: Bool { !blank.isEmpty }
}

/// what one question gave: the plan as the engine's JSON text (kept whole, to pin or to carry a follow-up on from),
/// its fill, and who planned it
struct LiveAnswer: Hashable {
    var question: String
    var plan: String?
    var fill: LiveFill?
    /// "model" (Apple's on-device model), "rules" (kosh's own reading), "redrawn" (the same plan, another picture)
    var how: String
    /// why it isn't drawn (a question for words), when it isn't
    var why: String = ""
}

/// a view pinned to Home: the plan, refilled on each build
struct LivePin: Codable, Hashable, Identifiable {
    let id: String
    /// the plan, as viewplan.js wrote it (JSON text)
    let plan: String
    /// the question as asked, and the title at the time (shown until its first refill)
    let question: String
    let title: String
    /// when it was pinned, seconds since 1970
    let at: Double
}

enum LiveViewCore {
    /// the engine's answer to a question (liveViewJSON, or a model plan checked and filled): its plan kept as text
    static func answer(_ raw: String, question: String, how fallback: String = "rules") -> LiveAnswer {
        guard let data = raw.data(using: .utf8), let obj = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] else {
            return LiveAnswer(question: question, plan: nil, fill: nil, how: fallback, why: "kosh couldn’t work that out")
        }
        let how: String = (obj["how"] as? String) ?? fallback
        let why: String = (obj["why"] as? String) ?? ""
        guard let plan = obj["plan"] as? [String: Any], let planText = text(plan) else {
            return LiveAnswer(question: question, plan: nil, fill: nil, how: how, why: why)
        }
        var fill: LiveFill? = nil
        if let f = obj["fill"] as? [String: Any], let ft = text(f) { fill = decodeFill(ft) }
        return LiveAnswer(question: question, plan: planText, fill: fill, how: how, why: why)
    }

    /// a fill (liveViewFillJSON); nil when the engine refused the plan or the text isn't one
    static func decodeFill(_ raw: String) -> LiveFill? {
        guard let d = raw.data(using: .utf8) else { return nil }
        return try? JSONDecoder().decode(LiveFill.self, from: d)
    }

    /// a JSON object as text, keys sorted (the same plan is the same text, so a pin is found again)
    static func text(_ o: [String: Any]) -> String? {
        guard JSONSerialization.isValidJSONObject(o), let d = try? JSONSerialization.data(withJSONObject: o, options: [.sortedKeys]) else { return nil }
        return String(data: d, encoding: .utf8)
    }

    /// what makes two plans the same view to pin: the plan without the question's own words or the frame it was read
    /// with ("how much this month" and "is mahine kitna" pin once)
    static func pinKey(_ plan: String) -> String {
        guard let d = plan.data(using: .utf8), var o = (try? JSONSerialization.jsonObject(with: d)) as? [String: Any] else { return plan }
        o.removeValue(forKey: "q"); o.removeValue(forKey: "frame"); o.removeValue(forKey: "answer"); o.removeValue(forKey: "title")
        return text(o) ?? plan
    }

    /// a plan pinned, at most `cap` kept (the newest first); the same view pinned twice is one pin
    static func pinned(_ pins: [LivePin], adding plan: String, question: String, title: String, now: Double, cap: Int = 8) -> [LivePin] {
        let key: String = pinKey(plan)
        var out: [LivePin] = pins.filter { pinKey($0.plan) != key }
        out.insert(LivePin(id: UUID().uuidString, plan: plan, question: question, title: title, at: now), at: 0)
        return Array(out.prefix(cap))
    }

    static func isPinned(_ pins: [LivePin], plan: String) -> Bool {
        let key: String = pinKey(plan)
        return pins.contains { pinKey($0.plan) == key }
    }

    /// the line under the question with its figures picked out, for the screen to set in bold: each run of the answer
    /// that is a rupee figure, a percent or a count of payments
    static func figureRuns(_ answer: String) -> [(text: String, figure: Bool)] {
        guard let re = try? NSRegularExpression(pattern: "−?₹[0-9][0-9,]*(?:\\.[0-9]+)?(?:L|CR|k)?|[0-9]+%") else { return [(answer, false)] }
        let ns = answer as NSString
        var out: [(String, Bool)] = []
        var at = 0
        for m in re.matches(in: answer, range: NSRange(location: 0, length: ns.length)) {
            if m.range.location > at { out.append((ns.substring(with: NSRange(location: at, length: m.range.location - at)), false)) }
            out.append((ns.substring(with: m.range), true))
            at = m.range.location + m.range.length
        }
        if at < ns.length { out.append((ns.substring(from: at), false)) }
        return out.map { (text: $0.0, figure: $0.1) }
    }

    /// what the on-device model's choices make as a plan (the engine checks it before any figure is worked out): the
    /// stretch it named, its cut, its filters and its answer line
    static func modelPlan(question: String, fact: String, picture: String, period: String, count: Int?, by: String,
                          category: String?, payee: String?, person: String?, against: String?, answer: String, people: [String]) -> [String: Any] {
        var p: [String: Any] = ["v": 1, "q": question, "fact": fact, "picture": picture]
        let n: Int = max(1, count ?? 0)
        switch period {
        case "this_month": p["range"] = ["kind": "month", "back": 0]
        case "last_month": p["range"] = ["kind": "month", "back": 1]
        case "month_before_last": p["range"] = ["kind": "month", "back": 2]
        case "this_year": p["range"] = ["kind": "year", "back": 0]
        case "last_year": p["range"] = ["kind": "year", "back": 1]
        case "this_fy": p["range"] = ["kind": "fy", "back": 0]
        case "last_n_days": p["range"] = ["kind": "days", "n": count ?? 30]
        case "last_n_months": p["range"] = ["kind": "months", "n": count ?? 6]
        case "next_n_days": p["range"] = ["kind": "ahead", "start": 0, "days": count ?? 30]
        case "everything": p["range"] = ["kind": "all"]
        default: break
        }
        _ = n
        if by != "none" && !by.isEmpty { p["by"] = by }
        var f: [String: Any] = [:]
        if let c = category?.trimmingCharacters(in: .whitespaces), !c.isEmpty { f["category"] = c }
        if let m = payee?.trimmingCharacters(in: .whitespaces), !m.isEmpty { f["merchant"] = m }
        if let w = person?.trimmingCharacters(in: .whitespaces), !w.isEmpty { f["person"] = w }
        p["filters"] = f
        if picture == "compare" {
            let a: String = (against ?? "").trimmingCharacters(in: .whitespaces)
            if a.isEmpty || a == "previous" { p["against"] = ["prior": true] }
            else if a == "last_year" { p["against"] = ["range": ["kind": "year", "back": 1]] }
            else if people.contains(where: { $0.lowercased() == a.lowercased() }) { p["against"] = ["person": a] }
            else { p["against"] = ["merchant": a] }
        }
        if !answer.isEmpty { p["answer"] = answer }
        return p
    }
}
