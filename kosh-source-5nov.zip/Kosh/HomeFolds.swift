import SwiftUI

// MARK: - Home's sections, folded
//
// A section folded away on Home (its title tapped) keeps one small card: the figure in bold and a little picture of
// where it's heading, read the way the open section was left. Net worth: the figure, what moved it most over the range
// last picked on its chart (3M, 6M, 1Y or All), and its line over that range. Your expenses: the month so far, where
// it's likely to land and the average month over the range last picked on the spending chart, and those months as
// bars (this one solid up to now, ghosted up to likely; trips on top in their colour, or ghosted above when Everyday
// leaves them out), counted the way the open section counts (Actual or True, chapters in or out). A small tag over
// the picture says which: "1Y", "True · 6M". Tap the card to open the section again.

/// Net worth, folded
struct WorthFold: View {
    @Environment(Store.self) private var store
    /// the range the open chart was left on: the fold reads the same span
    @AppStorage("home.networth.range") private var range = 12
    let open: () -> Void

    var body: some View {
        let p = store.who
        let net: Double = store.netWorth(p)
        let pts: [NWPoint] = NetWorthTrend.window(store.worthSeries(p), range: range)
        let label: String = store.who.possessive("net worth", family: "Family net worth")
        let move: (String, Bool)? = Self.move(net: net, pts: pts)
        // (what moved it, the two biggest, as the open card says it)
        let moves: WorthMoves? = store.worthMoves(p, range: range)
        let tag: String = NetWorthTrend.ranges.first { $0.0 == range }?.1 ?? "1Y"
        Button(action: open) {
            HStack(alignment: .center, spacing: 14) {
                VStack(alignment: .leading, spacing: 3) {
                    Text(label).font(.system(.footnote, weight: .semibold)).foregroundStyle(.secondary).lineLimit(1)
                    Text(Fmt.signedWords(net))
                        .font(.system(.title, design: .rounded, weight: .bold))
                        .monospacedDigit()
                        .lineLimit(1).minimumScaleFactor(0.7)
                        .contentTransition(.numericText(value: net))
                        .privacySensitive()
                    if let mv = moves, !mv.moves.isEmpty {
                        mv.text(2)
                            .font(.system(.caption, weight: .semibold))
                            .foregroundStyle(.secondary)
                            .lineLimit(1).minimumScaleFactor(0.8)
                            .privacySensitive()
                    } else if let move {
                        Text(move.0)
                            .font(.system(.caption, weight: .semibold))
                            .foregroundStyle(move.1 ? Color.green : Color.orange)
                            .lineLimit(1).minimumScaleFactor(0.8)
                            .privacySensitive()
                    }
                }
                Spacer(minLength: 8)
                VStack(alignment: .trailing, spacing: 6) {
                    FoldTag(text: tag)
                    FoldLine(values: pts.map(\.v) + (pts.last?.day == nil ? [net] : []), ink: Color.kosh)
                        .id(tag)
                        .frame(width: 116, height: 42)
                }
            }
            .padding(16)
            .background { FoldWash() }
            .contentShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
        }
        .buttonStyle(.press)
        .accessibilityElement(children: .combine)
        .accessibilityHint("Opens the net worth section")
    }

    /// "▲ ₹4.2L (3.5%) since 1 Feb": from the line's first point to now, the open chart's own words
    static func move(net: Double, pts: [NWPoint]) -> (String, Bool)? {
        guard pts.count > 1, let first = pts.first else { return nil }
        let d: Double = net - first.v
        let pct: String = first.v > 0 ? " (" + Fmt.trim(abs(d) / first.v * 100, 1) + "%)" : ""
        let today: String = pts.last?.day ?? Day.monthEnd(pts.last?.m ?? first.m)
        let arrow: String = d >= 0 ? "▲ " : "▼ "
        return (arrow + Fmt.words(abs(d)) + pct + " since " + NetWorthTrend.since(first, today: today), d >= 0)
    }
}

/// Your expenses, folded
struct SpendFold: View {
    @Environment(Store.self) private var store
    /// the range the open spending chart was left on: the fold's bars and average read the same span
    @AppStorage("home.spend.range") private var range = 6
    let open: () -> Void

    var body: some View {
        let months: [MonthInfo] = store.snap.months.sorted { $0.m < $1.m }
        let now: MonthInfo? = months.last(where: { $0.live }) ?? months.last
        let total: Double = now.map { store.total(of: $0) } ?? 0
        let live: Bool = now?.live == true
        let title: String = (now?.name ?? "This month") + (live ? " so far" : "")
        let shown: [SpendBar] = SpendTrend.window(SpendTrend.bars(store), range: range, today: store.snap.today)
        let done: [SpendBar] = shown.filter { !$0.live }
        let avg: Double = SpendTrend.average(done)
        let line: String = Self.line(live: live, likely: store.likelyNow, avg: avg, usual: store.snap.fc.usual, lead: now?.lead ?? "")
        let bars: [MonthBars.Bar] = shown.map { b in
            MonthBars.Bar(id: b.m, letter: String(Day.fmt(b.m + "-01", "MMM").prefix(1)), v: b.v, likely: b.live ? b.likely : 0, live: b.live,
                          trip: b.trip, out: b.out)
        }
        Button(action: open) {
            HStack(alignment: .center, spacing: 14) {
                VStack(alignment: .leading, spacing: 3) {
                    Text(title).font(.system(.footnote, weight: .semibold)).foregroundStyle(.secondary).lineLimit(1)
                    Text(Fmt.rupees(total))
                        .font(.system(.title, design: .rounded, weight: .bold))
                        .monospacedDigit()
                        .lineLimit(1).minimumScaleFactor(0.7)
                        .contentTransition(.numericText(value: total))
                        .privacySensitive()
                    if !line.isEmpty {
                        Text(line).font(.system(.caption)).foregroundStyle(.secondary).lineLimit(1).minimumScaleFactor(0.8).privacySensitive()
                    }
                }
                Spacer(minLength: 8)
                VStack(alignment: .trailing, spacing: 6) {
                    FoldTag(text: Self.tag(store, range: range))
                    if bars.count > 1 {
                        MonthBars(bars: bars)
                            .id(range)
                            .frame(width: 116, height: 50)
                    }
                }
            }
            .padding(16)
            .background { FoldWash() }
            .contentShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
        }
        .buttonStyle(.press)
        .accessibilityElement(children: .combine)
        .accessibilityHint("Opens your expenses")
    }

    /// "likely ₹72,272 · avg ₹1.6L": where this month lands, and the average full month over the range picked
    /// (kosh's usual month when the range holds no full month yet)
    static func line(live: Bool, likely: Double, avg: Double, usual: Double, lead: String) -> String {
        guard live else { return lead }
        // "usual" is the one baseline kosh uses everywhere: the middle of your recent full months
        let against: String = usual > 0 ? "usual " + Fmt.words(usual) : ""
        return "likely " + Fmt.words(likely) + (against.isEmpty ? "" : " · " + against)
    }

    /// how the open section counts, in a few words: "True · 6M", "Everyday · Actual · 1Y"
    static func tag(_ store: Store, range: Int) -> String {
        NetWorthTrend.ranges.first { $0.0 == range }?.1 ?? "6M"
    }
}

/// what the folded picture shows, in small: the range and the way it's counted
struct FoldTag: View {
    let text: String
    var body: some View {
        Text(text)
            .font(.system(.caption2, weight: .semibold))
            .foregroundStyle(.secondary)
            .lineLimit(1)
            .fixedSize()
            .padding(.horizontal, 7).padding(.vertical, 2.5)
            .background(Color.primary.opacity(0.06), in: Capsule())
    }
}

/// the folded card's ground: the grey card with a faint wash of the accent from its top corner
struct FoldWash: View {
    var body: some View {
        RoundedRectangle(cornerRadius: 24, style: .continuous)
            .fill(Color.surface)
            .overlay(
                RoundedRectangle(cornerRadius: 24, style: .continuous)
                    .fill(LinearGradient(colors: [Color.kosh.opacity(0.12), Color.kosh.opacity(0)], startPoint: .topTrailing, endPoint: .bottomLeading))
            )
    }
}

/// a small line of where something's been: soft fill under it, drawn in from the left, a lit dot at today
struct FoldLine: View {
    let values: [Double]
    var ink: Color = Color.kosh
    @State private var drawn: CGFloat = 0
    @Environment(\.accessibilityReduceMotion) private var still

    /// the values as points in a box this size, a little room top and bottom
    static func points(_ v: [Double], _ s: CGSize) -> [CGPoint] {
        guard v.count > 1, let lo = v.min(), let hi = v.max() else {
            return [CGPoint(x: 0, y: s.height / 2), CGPoint(x: s.width, y: s.height / 2)]
        }
        let span: Double = max(hi - lo, abs(hi) * 0.02, 1)
        return v.enumerated().map { i, x in
            CGPoint(x: s.width * CGFloat(i) / CGFloat(v.count - 1), y: 5 + (s.height - 10) * CGFloat(1 - (x - lo) / span))
        }
    }
    /// a smooth line through the points (through each midpoint, bending at each point)
    static func line(_ p: [CGPoint]) -> Path {
        var path = Path()
        guard let first = p.first else { return path }
        path.move(to: first)
        if p.count == 2 { path.addLine(to: p[1]); return path }
        for i in 1..<p.count {
            let mid: CGPoint = CGPoint(x: (p[i - 1].x + p[i].x) / 2, y: (p[i - 1].y + p[i].y) / 2)
            if i == 1 { path.addLine(to: mid) } else { path.addQuadCurve(to: mid, control: p[i - 1]) }
        }
        path.addQuadCurve(to: p[p.count - 1], control: p[p.count - 1])
        return path
    }

    var body: some View {
        GeometryReader { g in
            let pts: [CGPoint] = Self.points(values, g.size)
            let path: Path = Self.line(pts)
            let end: CGPoint = pts.last ?? .zero
            ZStack(alignment: .topLeading) {
                Path { p in
                    p.addPath(path)
                    p.addLine(to: CGPoint(x: end.x, y: g.size.height))
                    p.addLine(to: CGPoint(x: pts.first?.x ?? 0, y: g.size.height))
                    p.closeSubpath()
                }
                .fill(LinearGradient(colors: [ink.opacity(0.26), ink.opacity(0)], startPoint: .top, endPoint: .bottom))
                .mask(alignment: .leading) { Rectangle().frame(width: g.size.width * drawn) }
                path.trim(from: 0, to: drawn)
                    .stroke(ink, style: StrokeStyle(lineWidth: 2.2, lineCap: .round, lineJoin: .round))
                Circle()
                    .fill(ink)
                    .frame(width: 7, height: 7)
                    .background(Circle().fill(ink.opacity(0.25)).frame(width: 15, height: 15))
                    .position(end)
                    .opacity(drawn >= 1 ? 1 : 0)
            }
        }
        .onAppear {
            if still { drawn = 1 } else { withAnimation(Motion.reveal) { drawn = 1 } }
        }
        .accessibilityHidden(true)
    }
}

/// months as bars: past months quiet, this one solid up to now and ghosted up to where it's likely to land; what
/// trips took sits on top in their colour, and what Everyday leaves out is ghosted above. A long span draws thinner
/// bars and letters only every few months.
struct MonthBars: View {
    struct Bar: Identifiable {
        let id: String
        let letter: String
        let v: Double
        let likely: Double
        let live: Bool
        /// what trips took of v (counted in), and what was left out of it (Everyday)
        var trip: Double = 0
        var out: Double = 0
    }
    let bars: [Bar]
    @State private var grown = false
    @Environment(\.accessibilityReduceMotion) private var still

    var body: some View {
        let top: Double = max(1, bars.map { max($0.v + $0.out, $0.likely) }.max() ?? 1)
        let n: Int = bars.count
        let gap: CGFloat = n > 10 ? 2 : n > 7 ? 4 : 6
        let every: Int = n > 14 ? 3 : 1
        HStack(alignment: .bottom, spacing: gap) {
            ForEach(Array(bars.enumerated()), id: \.element.id) { i, b in
                VStack(spacing: 4) {
                    GeometryReader { g in
                        let h: CGFloat = g.size.height
                        let grow: CGFloat = grown ? 1 : 0.05
                        let ghost: CGFloat = h * CGFloat(max(b.v, b.likely) / top)
                        let solid: CGFloat = h * CGFloat(b.v / top) * grow
                        let left: CGFloat = h * CGFloat(b.out / top) * grow
                        let tripShare: CGFloat = b.v > 0 ? CGFloat(min(1, b.trip / b.v)) : 0
                        ZStack(alignment: .bottom) {
                            if b.live && b.likely > b.v {
                                RoundedRectangle(cornerRadius: 4, style: .continuous)
                                    .strokeBorder(Color.kosh.opacity(0.55), style: StrokeStyle(lineWidth: 1, dash: [2, 2.5]))
                                    .background(Color.kosh.opacity(0.1), in: RoundedRectangle(cornerRadius: 4, style: .continuous))
                                    .frame(height: max(4, ghost))
                            }
                            VStack(spacing: 0) {
                                if b.out > 0 {
                                    Rectangle().fill(Color.tripInk.opacity(0.22)).frame(height: left)
                                }
                                if tripShare > 0 {
                                    Rectangle().fill(Color.tripInk.opacity(b.live ? 0.95 : 0.6)).frame(height: max(0, solid) * tripShare)
                                }
                                Rectangle()
                                    .fill(b.live ? AnyShapeStyle(LinearGradient(colors: [Color.sky, Color.kosh], startPoint: .top, endPoint: .bottom)) : AnyShapeStyle(Color.rule.opacity(0.22)))
                            }
                            .frame(height: max(3, solid + left))
                            .clipShape(RoundedRectangle(cornerRadius: n > 10 ? 2.5 : 4, style: .continuous))
                        }
                        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottom)
                    }
                    Text(i % every == 0 || b.live ? b.letter : " ")
                        .font(.system(size: n > 10 ? 8 : 9.5, weight: b.live ? .bold : .medium))
                        .foregroundStyle(b.live ? Color.primary : Color.secondary)
                }
            }
        }
        .onAppear {
            if still { grown = true } else { withAnimation(Motion.reveal.delay(0.05)) { grown = true } }
        }
        .accessibilityHidden(true)
    }
}
