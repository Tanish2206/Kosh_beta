import Foundation
import MetricKit

/// kosh's own crash reports (3 Nov 2026): iOS hands the app its crash diagnostics on the next launch (MetricKit). The
/// latest five are kept, as type, signal, reason and the top of the crashed thread (binary + offset), and go into the
/// diagnostics file the Mac pulls ("crashes"), so a crash can be found without the phone on a cable. Nothing leaves the
/// phone by itself.
final class CrashWatch: NSObject, MXMetricManagerSubscriber {
    static let shared = CrashWatch()
    static let key: String = "crashwatch.reports"

    func start() {
        MXMetricManager.shared.add(self)
        // (what iOS already holds from earlier launches)
        didReceive(MXMetricManager.shared.pastDiagnosticPayloads)
    }

    func didReceive(_ payloads: [MXDiagnosticPayload]) {
        var kept: [[String: Any]] = Self.reports()
        for p in payloads {
            for c in p.crashDiagnostics ?? [] {
                var r: [String: Any] = ["at": ISO8601DateFormatter().string(from: p.timeStampEnd), "version": c.applicationVersion]
                if let t = c.exceptionType { r["type"] = t.intValue }
                if let s = c.signal { r["signal"] = s.intValue }
                if let why = c.terminationReason { r["reason"] = String(why.prefix(400)) }
                if #available(iOS 17.0, *), let ex = c.exceptionReason { r["exception"] = String((ex.className + ": " + ex.composedMessage).prefix(600)) }
                let tree: Data = c.callStackTree.jsonRepresentation()
                r["frames"] = Self.frames(tree)
                r["tree"] = String(String(data: tree, encoding: .utf8)?.prefix(6000) ?? "")
                kept.insert(r, at: 0)
            }
        }
        if kept.count > 5 { kept = Array(kept.prefix(5)) }
        if let d = try? JSONSerialization.data(withJSONObject: kept) { UserDefaults.standard.set(d, forKey: Self.key) }
    }

    static func reports() -> [[String: Any]] {
        guard let d = UserDefaults.standard.data(forKey: key), let a = try? JSONSerialization.jsonObject(with: d) as? [[String: Any]] else { return [] }
        return a
    }

    /// the crashed thread's frames, innermost first: "Kosh+0x1a2b3c" (60 at most)
    static func frames(_ json: Data) -> [String] {
        guard let o = try? JSONSerialization.jsonObject(with: json) as? [String: Any],
              let stacks = o["callStacks"] as? [[String: Any]] else { return [] }
        let crashed: [String: Any]? = stacks.first { ($0["threadAttributed"] as? Bool) == true } ?? stacks.first
        var out: [String] = []
        var frame: [String: Any]? = (crashed?["callStackRootFrames"] as? [[String: Any]])?.first
        while let f = frame, out.count < 60 {
            let name: String = f["binaryName"] as? String ?? "?"
            let off: Int = (f["offsetIntoBinaryTextSegment"] as? Int) ?? 0
            out.append(name + "+0x" + String(off, radix: 16))
            frame = (f["subFrames"] as? [[String: Any]])?.first
        }
        return out
    }
}
