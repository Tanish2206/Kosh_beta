import SwiftUI

// MARK: - Gift cards: the vouchers the stores' mail delivered
//
// A row per voucher: the brand, its value, how long it has left (amber in its last month), how it came (bought,
// or paid with reward points), and a tap that opens the mail with the code in it. kosh keeps no code or PIN.
// Open ones first, the soonest to run out on top; used and expired ones linger a few months, greyed. kosh sees a
// Blinkit, Zomato or Swiggy card land in its app's balance; any other one you mark used with a press and hold.

struct GiftCardShelf: View {
    let vouchers: [Voucher]
    let today: String
    @Environment(\.openURL) private var openURL
    /// vouchers you marked used yourself (their ids, comma-separated)
    @AppStorage("vouchers.used") private var usedRaw: String = ""

    static let tint: Color = Color(light: "#C46A00", dark: "#FFA94D")
    static let amber: Color = Color(light: "#A35A00", dark: "#FFB04D")

    var marked: Set<String> { Set(usedRaw.split(separator: ",").map(String.init)) }

    /// what the shelf shows for a voucher: used when you said so, else what the mail showed
    func state(_ v: Voucher) -> String { v.status == "open" && marked.contains(v.id) ? "marked" : v.status }

    var body: some View {
        let rows: [Voucher] = Self.order(vouchers, state: state)
        let open: [Voucher] = rows.filter { state($0) == "open" }
        let worth: Double = open.reduce(0) { $0 + $1.value }
        VStack(alignment: .leading, spacing: 12) {
            AcctTitle(title: "Gift cards", detail: open.isEmpty ? "" : Fmt.rupees(worth))
            VStack(spacing: 0) {
                ForEach(Array(rows.prefix(8).enumerated()), id: \.element.id) { i, v in
                    if i > 0 { RowRule(inset: 50) }
                    row(v)
                }
            }
            .rowsCard()
            Text(Self.caption(open: open.count))
                .font(.system(.caption)).foregroundStyle(.secondary).padding(.horizontal, 4)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(.top, 4)
        .animation(Motion.open, value: usedRaw)
    }

    /// open ones first, the soonest to run out on top; the rest newest first
    static func order(_ vs: [Voucher], state: (Voucher) -> String) -> [Voucher] {
        let live: [Voucher] = vs.filter { state($0) == "open" }.sorted { ($0.until.isEmpty ? "9999" : $0.until) < ($1.until.isEmpty ? "9999" : $1.until) }
        let done: [Voucher] = vs.filter { state($0) != "open" }.sorted { $0.d > $1.d }
        return live + done
    }

    func row(_ v: Voucher) -> some View {
        let st: String = state(v)
        let live: Bool = st == "open"
        let left: Int = v.until.isEmpty ? Int.max : Day.between(today, v.until)
        let soon: Bool = live && left <= 30
        let tile: Color = live ? (soon ? Self.amber : Self.tint) : Color.secondary
        return Button { openMail(v) } label: {
            HStack(spacing: 12) {
                IconTile(symbol: "giftcard.fill", color: tile, size: 38)
                VStack(alignment: .leading, spacing: 1) {
                    Text(v.brand).font(.system(.subheadline, weight: .semibold))
                        .foregroundStyle(live ? Color.primary : Color.secondary).lineLimit(1)
                    Text(Self.line(v, state: st, left: left))
                        .font(.system(.caption)).foregroundStyle(soon ? Self.amber : Color.secondary).lineLimit(1)
                }
                Spacer(minLength: 8)
                Text(Fmt.rupees(v.value))
                    .font(.system(.subheadline, design: .rounded, weight: .semibold)).monospacedDigit()
                    .foregroundStyle(live ? Color.primary : Color.secondary)
                    .lineLimit(1).minimumScaleFactor(0.75)
                    .privacySensitive()
                    .layoutPriority(1)
            }
            .padding(.vertical, 10)
            .contentShape(Rectangle())
        }
        .buttonStyle(.press)
        .contextMenu { menu(v, state: st) }
        .accessibilityElement(children: .combine)
        .accessibilityHint("Opens the email with the code")
    }

    @ViewBuilder func menu(_ v: Voucher, state st: String) -> some View {
        Button { openMail(v) } label: { Label("Open the email", systemImage: "envelope") }
        if st == "open" {
            Button { mark(v, used: true) } label: { Label("Mark as used", systemImage: "checkmark.circle") }
        } else if st == "marked" {
            Button { mark(v, used: false) } label: { Label("Not used yet", systemImage: "arrow.uturn.backward") }
        }
    }

    func mark(_ v: Voucher, used: Bool) {
        var s: Set<String> = marked
        if used { s.insert(v.id) } else { s.remove(v.id) }
        usedRaw = s.sorted().joined(separator: ",")
    }

    /// "Good till 10 Oct 2027 · via PayZapp", "Runs out in 12 days", "Used 12 Oct", "Expired 7 May 2027"
    static func line(_ v: Voucher, state st: String, left: Int) -> String {
        if st == "marked" { return "Marked used" }
        if st == "used" { return v.usedOn.isEmpty ? "Used" : "Used " + Day.fmt(v.usedOn, "d MMM") }
        if st == "expired" { return "Expired " + Day.fmt(v.until, "d MMM yyyy") }
        var parts: [String] = []
        if v.until.isEmpty { parts.append("No end date in the email") }
        else if left <= 0 { parts.append("Runs out today") }
        else if left == 1 { parts.append("Runs out tomorrow") }
        else if left <= 30 { parts.append("Runs out in \(left) days") }
        else { parts.append("Good till " + Day.fmt(v.until, "d MMM yyyy")) }
        if v.how == "points" { parts.append("paid with points") }
        else if !v.via.isEmpty { parts.append("via " + v.via) }
        return parts.joined(separator: " · ")
    }

    static func caption(open: Int) -> String {
        if open == 0 { return "All spent. Nothing left in a drawer somewhere." }
        return "Money already paid for. Tap one for its code (kosh never keeps it). Spent one kosh didn't notice? Press and hold."
    }

    /// the voucher's own email, in the inbox it came to
    func openMail(_ v: Voucher) {
        guard !v.mail.isEmpty, var c = URLComponents(string: "https://mail.google.com/mail/") else { return }
        if !v.acct.isEmpty { c.queryItems = [URLQueryItem(name: "authuser", value: v.acct)] }
        c.fragment = "all/" + v.mail
        if let url = c.url { openURL(url) }
    }
}
