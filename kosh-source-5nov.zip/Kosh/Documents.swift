import Foundation
import PDFKit
import Compression

// MARK: - Locked statements: opened with the password the user gives, once per sender
//
// Banks, fund houses, brokers and insurers email statements as locked PDFs. kosh shows the
// file, the sender and the hint the sender's own email gives ("your password is ..."). kosh builds
// the password from the details saved in Settings › Statements (the sender's own rule, then the formats
// issuers commonly use: Papers.swift tryProfiles), or the user types it. The one that opens it is kept
// in the Keychain for that sender only, and tried on later files from the same sender.

enum SenderPasswords {
    static let key = "beta.senderPasswords"
    /// sender domain → the password the user typed for it
    static func all() -> [String: String] {
        guard let s = Keychain.get(key), let d = try? JSONDecoder().decode([String: String].self, from: Data(s.utf8)) else { return [:] }
        return d
    }
    static func get(_ sender: String) -> String? { all()[domain(sender)] }
    /// every password that has opened something from this sender, newest first (one bank, several cards: each card's
    /// own), so one typed for a second card doesn't lose the first's
    static let listKey = "beta.senderPasswords2"
    static func lists() -> [String: [String]] {
        guard let s = Keychain.get(listKey), let d = try? JSONDecoder().decode([String: [String]].self, from: Data(s.utf8)) else { return [:] }
        return d
    }
    static func every(_ sender: String) -> [String] {
        var out = lists()[domain(sender)] ?? []
        if let one = get(sender), !out.contains(one) { out.insert(one, at: 0) }
        return out
    }
    /// A mark for the password saved for this sender now, kept on a statement it didn't open (DocRef.tried) so that
    /// statement isn't downloaded again until another password is saved. Never made from the password: a statement's
    /// note lives in records.json, a file outside the Keychain, and a hash of a password built from a date of birth
    /// is undone by trying every date. A random mark, new each time the saved password changes; nil when none is saved.
    static let tagKey = "beta.senderPasswordTags"
    static func tags() -> [String: String] {
        guard let s = Keychain.get(tagKey), let d = try? JSONDecoder().decode([String: String].self, from: Data(s.utf8)) else { return [:] }
        return d
    }
    static func saveTags(_ t: [String: String]) {
        if t.isEmpty { Keychain.set(nil, for: tagKey); return }
        if let d = try? JSONEncoder().encode(t), let s = String(data: d, encoding: .utf8) { Keychain.set(s, for: tagKey) }
    }
    static func tag(_ sender: String) -> String? {
        guard get(sender) != nil else { return nil }
        var t = tags()
        if let x = t[domain(sender)] { return x }
        let x: String = String(UUID().uuidString.prefix(8)).lowercased()
        t[domain(sender)] = x
        saveTags(t)
        return x
    }
    static func set(_ sender: String, _ password: String) {
        var a = all()
        // (another password saved for it: a new mark, so the statements it hasn't been tried on get their turn)
        if a[domain(sender)] != password { var t = tags(); t[domain(sender)] = nil; saveTags(t) }
        a[domain(sender)] = password
        if let d = try? JSONEncoder().encode(a), let s = String(data: d, encoding: .utf8) { Keychain.set(s, for: key) }
        var l = lists()
        l[domain(sender)] = Array(([password] + (l[domain(sender)] ?? []).filter { $0 != password }).prefix(6))
        if let d = try? JSONEncoder().encode(l), let s = String(data: d, encoding: .utf8) { Keychain.set(s, for: listKey) }
    }
    static func forget(_ sender: String) {
        var a = all()
        a[domain(sender)] = nil
        if let d = try? JSONEncoder().encode(a), let s = String(data: d, encoding: .utf8) { Keychain.set(s, for: key) }
        var l = lists()
        l[domain(sender)] = nil
        if let d = try? JSONEncoder().encode(l), let s = String(data: d, encoding: .utf8) { Keychain.set(s, for: listKey) }
        var t = tags(); t[domain(sender)] = nil; saveTags(t)
    }
    static func clear() { Keychain.set(nil, for: key); Keychain.set(nil, for: listKey); Keychain.set(nil, for: tagKey) }
    static func domain(_ from: String) -> String {
        let e = from.lowercased()
        let addr = e.range(of: "<").map { String(e[$0.upperBound...]).replacingOccurrences(of: ">", with: "") } ?? e
        return addr.split(separator: "@").last.map(String.init) ?? addr
    }
}

enum DocUnlock {
    enum Result { case opened(String), locked, unreadable }

    /// Open a PDF: as is if it isn't locked, else with the password the user typed now,
    /// else with the one they saved earlier for this sender.
    static func open(_ data: Data, sender: String, typed: String?) async -> Result {
        guard let doc = PDFDocument(data: data) else { return .unreadable }
        if !doc.isLocked { return .opened(await text(of: doc)) }
        if let t = typed, !t.isEmpty, doc.unlock(withPassword: t) {
            SenderPasswords.set(sender, t)
            return .opened(await text(of: doc))
        }
        // every password saved for this sender, newest first (another card's from the same bank may be this one's)
        for saved in SenderPasswords.every(sender) {
            if let d = PDFDocument(data: data), d.unlock(withPassword: saved) {
                if saved != SenderPasswords.get(sender) { SenderPasswords.set(sender, saved) }
                return .opened(await text(of: d))
            }
        }
        return .locked
    }

    /// the first of these passwords that opens the file (one PDF, tried in turn on the phone), or nil. A zip or a
    /// workbook Excel locked is tried by unlock.js, with the same list in the same order (DocLocked)
    static func firstPassword(_ data: Data, _ candidates: [String], file: String = "") -> String? {
        if DocLocked.isZip(file) || DocLocked.isCompound(data) { return DocLocked.firstPassword(data, file: file, candidates) }
        guard let doc = PDFDocument(data: data), doc.isLocked else { return nil }
        for c in candidates where !c.isEmpty {
            if doc.unlock(withPassword: c) { return c }
        }
        return nil
    }

    /// Two readings of the same pages: rebuilt row by row from where the characters sit, and
    /// PDFKit's own text. Some statements read right one way, some the other, so the readers try
    /// both (split on `DocUnlock.alt`) and keep whichever adds up. After them, past `DocText.gridSep`,
    /// every word with where it sits (the grid), so a statement is read by its columns.
    static let alt = "\n\u{1E}\n"
    static func text(of doc: PDFDocument) async -> String {
        let read = DocText.read(doc)
        let rows = read.rows
        var plain = doc.string ?? ""
        if plain.count <= 40 {
            plain = ""
            for i in 0..<min(doc.pageCount, read.pagesRead) { if let p = doc.page(at: i), let s = p.string { plain += s + "\n" } }
        }
        var grid = read.grid
        var body: String
        if rows.count > 40 && plain.count > 40 { body = rows + alt + plain }
        else if rows.count <= 40 && plain.count <= 40 {
            // no text at all: a scan. The phone reads the pictures
            let seen = await DocOCR.read(doc)
            if seen.rows.count <= 40 { return rows.count > 40 ? rows : plain }
            body = seen.rows; grid = seen.grid
            if seen.pagesRead < seen.pages { body += "\n" + DocText.cutNote(seen.pagesRead, seen.pages) }
        } else { body = rows.count > 40 ? rows : plain }
        // a typed paper with scanned pages in it (a page photographed in, a signed schedule): those pages are read off
        // their pictures as well, their lines added after the typed ones in each reading
        if rows.count > 40 || plain.count > 40 {
            let thin = (0..<min(doc.pageCount, read.pagesRead)).filter { (doc.page(at: $0)?.string ?? "").trimmingCharacters(in: .whitespacesAndNewlines).count < 30 }
            if !thin.isEmpty && thin.count < read.pagesRead {
                let seen = await DocOCR.read(doc, budget: 30, pages: Array(thin.prefix(20)))
                if seen.rows.count > 40 { body = body.components(separatedBy: alt).map { $0 + "\n" + seen.rows }.joined(separator: alt) }
            }
        }
        if read.pagesRead < read.pages { body += "\n" + DocText.cutNote(read.pagesRead, read.pages) }
        return grid.isEmpty ? body : body + DocText.gridSep + grid
    }

    /// The sentence in the sender's own email that explains the password, to show beside the field
    /// the sentence in the sender's email that says what the password is made of (and its example),
    /// read from the text part or, when that's empty, the HTML
    static func hint(text: String, html: String = "") -> String {
        (try? Engine.shared.call("pdfHint", [text, String(html.prefix(200_000))])) ?? ""
    }
}

// MARK: - A PDF's text, row by row, and its words with where they sit
//
// PDFKit hands back text in the order the file stores it, which for a statement's table can be
// column by column. Rebuilding each line from where its characters sit puts a holding's ISIN,
// name, units and value on one row, cells three or more spaces apart, which is what the readers
// in engine.js expect. The same pass keeps each word's place on the page (the grid: "grid1", then
// "page,y<TAB>x0,x1,word<TAB>…" per line, in thousandths of the page, y from the top), which is how
// engine.js reads a statement by its columns. Pages are read until the time is up, not to a fixed
// count, so a year's statement isn't cut off at page 60.
enum DocText {
    static let gridSep = "\n\u{1F}\n"
    /// which way of reading a PDF's letters a kept text came from (glyphs-4nov: "2", letters without a box placed)
    static let extractor = "4"   // 4 (punct-4nov): commas and full stops join their line; 3 (drift-4nov): letter boxes counted without line breaks, per page

    /// letters with no box of their own between two that have one, on one line, set across the gap between them (each
    /// a share of it): only when the gap is about as wide as that many letters, never on a turned line
    static func place(_ lost: [UInt16], after a: CGRect, before b: CGRect, into chars: inout [DocLayout.Glyph]) {
        let n = CGFloat(lost.count)
        let gap: CGFloat = b.minX - a.maxX
        let cw: CGFloat = max(a.width, b.width, 1)
        let line: Bool = abs(b.midY - a.midY) < max(a.height, b.height) * 0.6
        guard line, gap >= cw * 0.25 * n, gap <= cw * 2.5 * n else { return }
        let w: CGFloat = gap / n
        for (k, c) in lost.enumerated() {
            chars.append(DocLayout.Glyph(c: c, r: CGRect(x: a.maxX + w * CGFloat(k), y: a.minY, width: w, height: a.height)))
        }
    }
    struct Read { var rows: String; var grid: String; var pagesRead: Int; var pages: Int }

    /// (drift-4nov) whether a page's letter boxes are counted without its text's line breaks: of neighbouring letters in
    /// one word, how many sit a line apart, counted both ways; the way with clearly fewer is the page's
    static func countsWithoutBreaks(_ page: PDFPage, _ ns: NSString) -> Bool {
        let n = min(ns.length, 4000)
        var jumpsA = 0, jumpsB = 0, pairs = 0, breaks = 0
        var prevA: CGRect? = nil, prevB: CGRect? = nil, prevLetter = false
        func letter(_ c: UInt16) -> Bool { (c >= 65 && c <= 90) || (c >= 97 && c <= 122) || (c >= 48 && c <= 57) }
        for j in 0..<n {
            let c = ns.character(at: j)
            if c == 10 || c == 13 { breaks += 1; prevLetter = false; prevA = nil; prevB = nil; continue }
            let isL = letter(c)
            let a = page.characterBounds(at: j)
            let b = breaks > 0 && j - breaks >= 0 ? page.characterBounds(at: j - breaks) : a
            if isL && prevLetter, let pa = prevA, let pb = prevB, !a.isNull, !b.isNull, !pa.isNull, !pb.isNull {
                pairs += 1
                if abs(a.midY - pa.midY) > max(a.height, pa.height) * 0.8 { jumpsA += 1 }
                if abs(b.midY - pb.midY) > max(b.height, pb.height) * 0.8 { jumpsB += 1 }
            }
            prevLetter = isL; prevA = isL ? a : nil; prevB = isL ? b : nil
        }
        return pairs >= 20 && breaks > 0 && jumpsA >= 5 && Double(jumpsB) < Double(jumpsA) * 0.4
    }

    /// a document too long to read whole: said at its end, so the statements list can say so
    static func cutNote(_ read: Int, _ pages: Int) -> String { "[kosh read the first \(read) of \(pages) pages]" }

    /// the body and the grid of a reading kept whole (the grid comes last)
    static func split(_ text: String) -> (body: String, grid: String) {
        guard let r = text.range(of: gridSep) else { return (text, "") }
        return (String(text[..<r.lowerBound]), String(text[r.upperBound...]))
    }

    static func rows(of doc: PDFDocument) -> String { read(doc).rows }

    static func read(_ doc: PDFDocument, budget: TimeInterval = 30, maxPages: Int = 500) -> Read {
        var out: [String] = []
        var grid: [String] = ["grid1"]
        let start = Date()
        var done = 0
        for i in 0..<min(doc.pageCount, maxPages) {
            if Date().timeIntervalSince(start) > budget { break }
            done += 1
            guard let page = doc.page(at: i), let s = page.string, !s.isEmpty else { continue }
            let box = page.bounds(for: .mediaBox)
            let ns = s as NSString
            // each character with where it sits, in the file's own order (DocLayout judges which way the text runs from it)
            var chars: [DocLayout.Glyph] = []
            chars.reserveCapacity(ns.length)
            // (glyphs-4nov: letters PDFKit gives no box for, AU's "Portf li S mmary", are placed in the gap their
            // neighbours on the line leave for them, never dropped and read as a space)
            var lost: [UInt16] = []
            // (drift-4nov) some PDFs' letter boxes are counted without the page text's line breaks (HDFC's statement): each
            // line break shifts every later letter's box by one, so a line's last letters land on the next line ("Mridul
            // Bhutan" | "i"). Per page, the counting that keeps words whole is used: boxes by the text's own index, or by
            // the index less the line breaks before it
            let drift: Bool = DocText.countsWithoutBreaks(page, ns)
            var breaks = 0
            for j in 0..<ns.length {
                let c = ns.character(at: j)
                if c == 10 || c == 13 { lost.removeAll(); breaks += 1; continue }
                let r = page.characterBounds(at: drift ? j - breaks : j)
                if r.isNull || r.isEmpty || !r.minX.isFinite || !r.minY.isFinite {
                    if c != 32 && c != 9 && c != 160 && !chars.isEmpty && lost.count < 4 { lost.append(c) } else if c == 32 || c == 9 { lost.removeAll() }
                    continue
                }
                if !lost.isEmpty, let prev = chars.last {
                    DocText.place(lost, after: prev.r, before: r, into: &chars)
                    lost.removeAll()
                }
                chars.append(DocLayout.Glyph(c: c, r: r))
            }
            // the page's lines and its grid (a page whose text runs up or down it is turned first: DocLayout.swift)
            let laid = DocLayout.page(chars, box: box, index: i)
            out += laid.rows
            grid += laid.grid
        }
        return Read(rows: out.joined(separator: "\n"), grid: grid.count > 1 ? grid.joined(separator: "\n") : "", pagesRead: done, pages: doc.pageCount)
    }
}

// MARK: - A statement sent as a spreadsheet (CSV or .xlsx), or printed in the mail itself
//
// Read on the phone like a PDF's table: the engine turns its rows into the same text and grid (engine.js
// csvDocJSON, xlsxDocJSON, mailTableDocJSON). An .xlsx is a zip: its first sheet and the shared strings are
// unzipped here (Apple's Compression, raw deflate) and handed over as XML. A workbook Excel locked with a password is
// opened by unlock.js with the password you typed or the sender's saved ones (DocLocked), then read the same way. An
// old .xls isn't a format kosh opens: the statements list says so.
enum DocTable {
    static func open(_ data: Data, file: String, sender: String = "", typed: String? = nil) -> DocUnlock.Result {
        let low = file.lowercased()
        if low.hasSuffix(".xlsx") && DocLocked.isCompound(data) {
            let (book, failed) = DocLocked.openBook(data, file: file, sender: sender, typed: typed)
            guard let book else { return failed }
            return open(book, file: file)
        }
        if low.hasSuffix(".csv") {
            guard let text = String(data: data, encoding: .utf8) ?? String(data: data, encoding: .isoLatin1),
                  let out = try? Engine.shared.call("csvDocJSON", [text]), let doc = try? JSONText.decode(String.self, out), doc.count > 20 else { return .unreadable }
            return .opened(doc)
        }
        if low.hasSuffix(".xlsx") {
            let zip = Unzip(data)
            guard let sheet = zip.text("xl/worksheets/sheet1.xml") ?? zip.firstText(prefix: "xl/worksheets/sheet") else {
                // a workbook locked with a password is a different file (not a zip): kosh can't open it
                return zip.isZip ? .unreadable : .locked
            }
            let shared = zip.text("xl/sharedStrings.xml") ?? ""
            guard let out = try? Engine.shared.call("xlsxDocJSON", [sheet, shared]), let doc = try? JSONText.decode(String.self, out), doc.count > 20 else { return .unreadable }
            return .opened(doc)
        }
        return .unreadable
    }

    /// the spreadsheets being opened right now, saved before each is unzipped: one still listed when kosh starts
    /// stopped kosh the last time it was opened, and is never opened again (it would stop kosh at every launch)
    static let openingKey = "beta.sheetsOpening"

    /// a spreadsheet statement unzipped and read off the main thread; one that stopped kosh before is unreadable
    static func openGuarded(_ data: Data, file: String, key: String, sender: String = "", typed: String? = nil) async -> DocUnlock.Result {
        let ud: UserDefaults = UserDefaults.standard
        var opening: [String] = ud.stringArray(forKey: openingKey) ?? []
        if opening.contains(key) { return .unreadable }
        opening.append(key)
        ud.set(Array(opening.suffix(20)), forKey: openingKey)
        let result: DocUnlock.Result = await Task.detached(priority: .utility) { DocTable.open(data, file: file, sender: sender, typed: typed) }.value
        // opened (or not) without stopping kosh: off the list
        var after: [String] = ud.stringArray(forKey: openingKey) ?? []
        after.removeAll { $0 == key }
        ud.set(after, forKey: openingKey)
        return result
    }

    /// the statement printed in a mail's own table, or nil
    static func fromMail(_ html: String) -> String? {
        guard !html.isEmpty, let out = try? Engine.shared.call("mailTableDocJSON", [String(html.prefix(400_000))]),
              let doc = try? JSONText.decode(String.self, out), !doc.isEmpty else { return nil }
        return doc
    }
}

/// just enough of a zip to read a workbook: the central directory, stored or deflated entries
struct Unzip {
    let data: Data
    var entries: [String: (offset: Int, method: Int, csize: Int, usize: Int)] = [:]
    var isZip: Bool { data.count > 4 && data[data.startIndex] == 0x50 && data[data.startIndex + 1] == 0x4B }

    init(_ data: Data) {
        self.data = Data(data)
        let b = [UInt8](self.data)
        func u16(_ i: Int) -> Int { i + 1 < b.count ? Int(b[i]) | Int(b[i + 1]) << 8 : 0 }
        func u32(_ i: Int) -> Int { i + 3 < b.count ? Int(b[i]) | Int(b[i + 1]) << 8 | Int(b[i + 2]) << 16 | Int(b[i + 3]) << 24 : 0 }
        // the end of central directory record, within the last 64 KB
        var eocd = -1
        var i = b.count - 22
        while i >= max(0, b.count - 65_557) { if u32(i) == 0x06054B50 { eocd = i; break }; i -= 1 }
        guard eocd >= 0 else { return }
        var at = u32(eocd + 16)
        let count = u16(eocd + 10)
        for _ in 0..<count {
            guard at + 46 <= b.count, u32(at) == 0x02014B50 else { break }
            let method = u16(at + 10), csize = u32(at + 20), usize = u32(at + 24)
            let nlen = u16(at + 28), elen = u16(at + 30), clen = u16(at + 32), local = u32(at + 42)
            guard at + 46 + nlen <= b.count else { break }
            let name = String(decoding: b[(at + 46)..<(at + 46 + nlen)], as: UTF8.self)
            // the data starts after the local header, whose name and extra fields have their own lengths
            if local + 30 <= b.count {
                let start = local + 30 + u16(local + 26) + u16(local + 28)
                entries[name] = (start, method, csize, usize)
            }
            at += 46 + nlen + elen + clen
        }
    }

    /// one entry's bytes, or nil for anything that doesn't add up (a size of nothing, an entry running past the end):
    /// a malformed workbook is a statement kosh can't read, never a crash
    func bytes(_ name: String) -> Data? {
        guard let e = entries[name], e.offset >= 0, e.csize >= 0, e.usize >= 0,
              e.offset + e.csize <= data.count, e.usize < 64_000_000 else { return nil }
        let src: Data = data.subdata(in: e.offset..<(e.offset + e.csize))
        if e.method == 0 { return src }
        guard e.method == 8, e.usize > 0, e.csize > 0, src.count == e.csize else { return nil }
        var dst = Data(count: e.usize)
        let n: Int = dst.withUnsafeMutableBytes { (d: UnsafeMutableRawBufferPointer) -> Int in
            src.withUnsafeBytes { (s: UnsafeRawBufferPointer) -> Int in
                guard let out = d.bindMemory(to: UInt8.self).baseAddress,
                      let input = s.bindMemory(to: UInt8.self).baseAddress else { return 0 }
                return compression_decode_buffer(out, e.usize, input, e.csize, nil, COMPRESSION_ZLIB)
            }
        }
        return n == e.usize ? dst : nil
    }
    func text(_ name: String) -> String? { bytes(name).flatMap { String(data: $0, encoding: .utf8) } }
    func firstText(prefix: String) -> String? {
        guard let name = entries.keys.filter({ $0.hasPrefix(prefix) && $0.hasSuffix(".xml") }).sorted().first else { return nil }
        return text(name)
    }
}

/// A PDF you added from Files (a CAS downloaded from a fund house's site, a policy schedule):
/// kept inside kosh's own folder so it can be opened again once you give its password.
struct LocalDoc: Codable, Identifiable, Hashable {
    var id = UUID().uuidString
    var file = ""          // the name it had
    var path = ""          // its copy inside kosh's folder
    var kind = ""          // what it turned out to be: cas, policy, cardstmt, ...
    var state = ""         // read, locked, empty
    var note: String? = nil
    var added = ""
    var owner = "me"
}
