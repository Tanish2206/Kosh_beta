import Foundation
#if canImport(FoundationModels)
import FoundationModels
#endif

// MARK: - The live view's planner: a question becomes a plan, the plan becomes figures
//
// The AI chooses what to show; kosh computes every number. Where the phone has Apple Intelligence, its on-device model
// reads the question first and chooses a plan: one fact, a stretch of days, its cut and filters, a picture, and an
// answer line whose numbers are only slots ({total}). It never sees a figure, only the household's own words (its
// kinds of spending, payees, people, cards) and kosh's own reading of the question. Its plan goes to the engine, which
// checks it against the schema and the household (viewplan.js checkPlan: a digit in its line, a payee the ledger
// hasn't, a stretch that hasn't happened, and it's refused) before working out a single figure. On any refusal, error
// or a model too slow, kosh's own reading answers (viewplan.js planOf), and with no model it always does.

@MainActor
enum LiveViewPlanner {
    /// Apple's model plans first where the phone has it (Settings can turn it off: "liveview.model")
    static var useModel: Bool {
        get { UserDefaults.standard.object(forKey: "liveview.model") as? Bool ?? true }
        set { UserDefaults.standard.set(newValue, forKey: "liveview.model") }
    }
    static var modelReady: Bool { useModel && AppleBrain.available }
    /// how long the model may take before kosh's own reading answers instead
    nonisolated static let modelBudget: Double = 6

    /// what the engine is handed: Ask kosh's ledger, and the Refunds list (which Ask's tools don't carry)
    static func context(_ store: Store) -> (ctx: String, extra: String) {
        let ctx: String = KoshAgent.context(store)
        let refunds: [[String: Any]] = (store.snap.refunds ?? []).map { r in
            var x: [String: Any] = ["id": r.id, "m": r.m, "d": r.d, "a": r.a, "exp": r.exp, "back": r.back, "by": r.by, "state": r.state, "o": r.o]
            if let s = r.stage { x["stage"] = s }
            return x
        }
        return (ctx, JSONText.object(["refunds": refunds]))
    }

    /// one question (and the plan before it, for a follow-up) → a plan and its figures
    static func draw(_ q: String, prev: String?, store: Store) async -> LiveAnswer {
        let (ctx, extra) = context(store)
        // kosh's own reading first, at once: it's the model's hint, and the answer whenever the model can't give one
        let rules: LiveAnswer = LiveViewCore.answer(await engine("liveViewJSON", [q, ctx, extra, prev ?? ""]), question: q)
        // a picture asked of the view on screen ("as a calendar") is kosh's to redraw: nothing for a model to choose
        if rules.how == "redrawn" || !modelReady { return rules }
        if let m = await modelDraw(q, prev: prev, rules: rules, ctx: ctx, extra: extra) { return m }
        return rules
    }

    /// a pinned plan, filled again on today's build
    static func refill(_ plan: String, store: Store) async -> LiveFill? {
        let (ctx, extra) = context(store)
        return LiveViewCore.decodeFill(await engine("liveViewFillJSON", [plan, ctx, extra]))
    }
    /// several pinned plans on one context (Home: built once, not once a pin)
    static func refill(_ plans: [String], store: Store) async -> [String: LiveFill] {
        let (ctx, extra) = context(store)
        var out: [String: LiveFill] = [:]
        for p in plans { if let f = LiveViewCore.decodeFill(await engine("liveViewFillJSON", [p, ctx, extra])) { out[p] = f } }
        return out
    }

    /// one engine call off the main thread (a build in progress makes it wait, never the screen)
    nonisolated static func engine(_ name: String, _ args: [String]) async -> String {
        await Task.detached(priority: .userInitiated) { (try? Engine.shared.call(name, args)) ?? "" }.value
    }

    // MARK: Apple's on-device model, choosing a plan

    /// the model's plan, checked by the engine and filled; nil when it has none the engine takes, or took too long
    static func modelDraw(_ q: String, prev: String?, rules: LiveAnswer, ctx: String, extra: String) async -> LiveAnswer? {
        #if canImport(FoundationModels)
        let vocabRaw: String = await engine("liveViewVocabJSON", [ctx])
        guard let vd = vocabRaw.data(using: .utf8), let vocab = (try? JSONSerialization.jsonObject(with: vd)) as? [String: Any] else { return nil }
        let people: [String] = (vocab["people"] as? [String]) ?? []
        let prompt: String = Self.prompt(q, vocab: vocab, rules: rules, prev: prev)
        // (the model's plan crosses as JSON text: a dictionary of Any isn't Sendable)
        let drafted: String? = await withTaskGroup(of: String?.self) { group in
            group.addTask { await Self.ask(prompt, question: q, people: people) }
            group.addTask { try? await Task.sleep(for: .seconds(Self.modelBudget)); return nil }
            let first: String?? = await group.next()
            group.cancelAll()
            return first ?? nil
        }
        guard let dt = drafted, let dd = dt.data(using: .utf8), var plan = (try? JSONSerialization.jsonObject(with: dd)) as? [String: Any] else { return nil }
        // a follow-up keeps what it carries on from (the frame kosh read it with)
        if let r = rules.plan, let rd = r.data(using: .utf8), let ro = (try? JSONSerialization.jsonObject(with: rd)) as? [String: Any], let fr = ro["frame"] { plan["frame"] = fr }
        guard let planText = LiveViewCore.text(plan) else { return nil }
        // the engine checks it, then fills it: a plan it refuses never reaches a figure
        guard let fill = LiveViewCore.decodeFill(await engine("liveViewFillJSON", [planText, ctx, extra])) else { return nil }
        return LiveAnswer(question: q, plan: planText, fill: fill, how: "model")
        #else
        return nil
        #endif
    }

    /// what the model is told: the question, today, the household's own words, the pictures and their slots, and kosh's
    /// own reading. Never a figure.
    static func prompt(_ q: String, vocab: [String: Any], rules: LiveAnswer, prev: String?) -> String {
        func list(_ k: String) -> String { ((vocab[k] as? [String]) ?? []).joined(separator: ", ") }
        var lines: [String] = []
        lines.append("Question: " + q)
        lines.append("Today: " + ((vocab["today"] as? String) ?? ""))
        lines.append("Kinds of spending in this household: " + list("categories"))
        lines.append("Payees: " + list("payees"))
        lines.append("People: " + list("people"))
        if let slots = vocab["slots"] as? [String: [String]] {
            lines.append("Slots for the answer line, by picture (also {range}, {subject}, {count} for all): " + slots.keys.sorted().map { $0 + " " + (slots[$0] ?? []).map { "{" + $0 + "}" }.joined(separator: " ") }.joined(separator: "; "))
        }
        if let r = rules.plan { lines.append("kosh's own reading of the question (keep it unless the question clearly asks otherwise): " + r) }
        else if !rules.why.isEmpty { lines.append("kosh's own reading couldn't place it (" + rules.why + ").") }
        if let p = prev { lines.append("The view on screen before this question: " + p) }
        return lines.joined(separator: "\n")
    }

    nonisolated static let instructions = """
    You choose how kosh, a household money app in India, draws an answer to a question about the household's own money. \
    You never work out or write a number: kosh computes every figure. Choose one fact, one picture, the stretch of days, \
    what to split or rank by, and filters taken only from the household's own lists. Write a one-line answer whose every \
    number is a slot in braces, such as {total} or {topValue}; a part that may be missing goes in square brackets. Never \
    write a digit, a rupee sign or a percent yourself. If the question isn't about spending, money in, investments, \
    holdings, net worth, balances, bills, refunds or payments, keep kosh's own reading.
    """

    #if canImport(FoundationModels)
    @Generable
    struct PlanDraft {
        @Guide(description: "What the question is about", .anyOf(["spend", "paid", "income", "invested", "holdings", "networth", "balances", "bills", "refunds", "payments"]))
        var fact: String
        @Guide(description: "How to draw it: one figure, months as bars, two things side by side, a ranked list, parts of a whole, a list of dated items, or a calendar of days", .anyOf(["figure", "trend", "compare", "ranked", "split", "timeline", "calendar"]))
        var picture: String
        @Guide(description: "The stretch of days", .anyOf(["this_month", "last_month", "month_before_last", "this_year", "last_year", "this_fy", "last_n_days", "last_n_months", "next_n_days", "everything"]))
        var period: String
        @Guide(description: "For last_n_days, last_n_months or next_n_days: how many", .range(1...365))
        var count: Int?
        @Guide(description: "What a ranked list or the parts are by", .anyOf(["none", "category", "payee", "person", "card", "method", "weekday", "month", "class", "account", "source"]))
        var by: String
        @Guide(description: "One kind of spending from the household's list, or empty")
        var category: String?
        @Guide(description: "One payee from the household's list, or empty")
        var payee: String?
        @Guide(description: "One person from the household's list, or empty")
        var person: String?
        @Guide(description: "For a comparison: previous (the same stretch before), last_year, or a person or payee from the lists")
        var against: String?
        @Guide(description: "One short line answering the question, every number a slot such as {total}; no digits")
        var answer: String
    }

    nonisolated static func ask(_ prompt: String, question: String, people: [String]) async -> String? {
        let session = LanguageModelSession(instructions: instructions)
        guard let r = try? await session.respond(to: prompt, generating: PlanDraft.self, options: GenerationOptions(sampling: .greedy, maximumResponseTokens: 220)) else { return nil }
        let d = r.content
        return LiveViewCore.text(LiveViewCore.modelPlan(question: question, fact: d.fact, picture: d.picture, period: d.period, count: d.count, by: d.by,
                                                        category: d.category, payee: d.payee, person: d.person, against: d.against, answer: d.answer, people: people))
    }
    #endif
}

/// the views pinned to Home, kept in the protected profile (LiveSession.own.liveViews) and drawn again on each build
@MainActor @Observable
final class LivePins {
    static let shared = LivePins()
    private(set) var pins: [LivePin] = []
    private init() {}

    /// what the profile holds (after it's read; before then, nothing is written over it)
    func load(_ store: Store) { if let live = store.live { pins = live.own.liveViews } }
    func isPinned(_ plan: String) -> Bool { LiveViewCore.isPinned(pins, plan: plan) }
    func pin(_ plan: String, question: String, title: String, store: Store) {
        guard let live = store.live else { return }
        pins = LiveViewCore.pinned(live.own.liveViews, adding: plan, question: question, title: title, now: Date().timeIntervalSince1970)
        live.own.liveViews = pins
        live.save()
    }
    func unpin(_ plan: String, store: Store) {
        guard let live = store.live else { return }
        let key: String = LiveViewCore.pinKey(plan)
        pins = live.own.liveViews.filter { LiveViewCore.pinKey($0.plan) != key }
        live.own.liveViews = pins
        live.save()
    }
}
