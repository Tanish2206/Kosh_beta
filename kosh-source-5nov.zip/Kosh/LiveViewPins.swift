import SwiftUI

// MARK: - Home: the live views you pinned, drawn again on each build, and the way in to ask one
//
// Each pin is a plan (LivePin): on every build (store.txGen) its figures are filled again on today's days, so "this
// month" is always this month. A card shows the title, the answer line, a small version of the picture and its dates;
// a tap opens it whole, a long press unpins it. With nothing pinned, one quiet line invites a question.

struct LivePinsSection: View {
    @Environment(Store.self) private var store
    @State private var fills: [String: LiveFill] = [:]
    @State private var open: Opened?
    private var pins: LivePins { LivePins.shared }

    struct Opened: Identifiable { let id = UUID(); let question: String; let plan: String? }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .firstTextBaseline) {
                Text(pins.pins.isEmpty ? "Ask, drawn" : "Pinned").font(.title2.weight(.bold))
                Spacer()
                Button { open = Opened(question: "", plan: nil) } label: { Label("Ask", systemImage: "chart.bar.xaxis").font(.subheadline.weight(.medium)) }
                    .buttonStyle(.press)
                    .foregroundStyle(Color.kosh)
            }
            if pins.pins.isEmpty {
                Button { open = Opened(question: "", plan: nil) } label: {
                    HStack(spacing: 12) {
                        Image(systemName: "sparkles").foregroundStyle(Color.kosh)
                        Text("Ask anything about your money, and kosh draws it. Pin a view, and it’s here, up to date, every day.")
                            .font(.subheadline).foregroundStyle(.secondary).multilineTextAlignment(.leading)
                    }
                    .card(14)
                }
                .buttonStyle(.press)
            } else {
                ForEach(Array(pins.pins.enumerated()), id: \.element.id) { i, p in
                    Button { open = Opened(question: p.question, plan: p.plan) } label: { card(p, fills[p.plan]) }
                        .buttonStyle(.press)
                        .contextMenu {
                            Button(role: .destructive) { withAnimation(Motion.close) { pins.unpin(p.plan, store: store) } } label: { Label("Unpin from Home", systemImage: "pin.slash") }
                        }
                        .transition(.opacity.animation(Motion.base.delay(Motion.stagger(i))))
                }
            }
        }
        .padding(.horizontal, 20).padding(.top, 22).padding(.bottom, 8)
        .task(id: String(store.txGen) + "|" + store.snap.today + "|" + String(pins.pins.count)) {
            pins.load(store)
            let plans: [String] = pins.pins.map(\.plan)
            guard !plans.isEmpty else { return }
            let got: [String: LiveFill] = await LiveViewPlanner.refill(plans, store: store)
            withAnimation(Motion.base) { fills = got }
        }
        .sheet(item: $open) { o in
            LiveViewScreen(seed: o.question.isEmpty ? nil : o.question, seedPlan: o.plan)
                .closesForAsk()
                .environment(store)
                .presentationDetents([.large])
                .redacted(reason: store.hidden ? .privacy : [])
        }
    }

    func card(_ p: LivePin, _ f: LiveFill?) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Eyebrow(text: f?.title.isEmpty == false ? f!.title : p.title)
                Spacer()
                Image(systemName: "pin.fill").font(.caption2).foregroundStyle(.tertiary)
            }
            if let f {
                LiveAnswerLine(text: f.answer, size: .system(.subheadline, design: .rounded, weight: .regular)).foregroundStyle(.primary)
                if !f.isBlank { LivePicture(fill: f, compact: true) }
                Text(f.range.dates.isEmpty ? f.range.words : f.range.dates).font(.caption).foregroundStyle(.secondary)
            } else {
                Text(p.question).font(.subheadline).foregroundStyle(.secondary)
                ProgressView().controlSize(.small)
            }
        }
        .foregroundStyle(Color.primary)
        .card(16)
    }
}
