/* kosh decide: "Should I…?" worked out on the household's own numbers, with the working shown, and where its net worth
   is heading over the next five years.

   Decisions (decide): prepay a loan or invest the money; buy a car in cash or on a loan; can we afford ₹X, now or by a
   date; break an FD or borrow against it; is the emergency fund enough; pay the card in full or the minimum. Each one
   is { verdict (one plain sentence), steps (numbered: what, the figure, how it was worked out), assumptions (the ones
   that matter can be changed and worked out again), changes (what would turn the answer), note, facts (the
   household's own figures it used, for "since you saved this…") }. The maths is deterministic and never certain about
   the future: returns are assumptions, said as such, and a choice that is the person's is left to them.

   The projection (project): today's net worth by kind (bank, invested, deposits, retirement, gold, insurance savings,
   property, loans), the money left each month before investing (the middle of the recent months, with its range),
   SIPs carrying on, loans paying down on their EMIs, FDs at their own rates until they mature, growth at rates shown
   and editable; month by month for five years, a base case and a scenario (more in SIPs, a prepayment, a big purchase,
   income up or down).

   Loaded after brief.js; it adds its functions to KoshEngine (decideJSON, decideRerunJSON, projectJSON) and agent.js
   uses it for the decide tool and the phone's answers. Nothing here is added to the snapshot. */

var KoshDecide = (function (E) {
  'use strict';
  var L = (E && E.lib) || {};

  /* ------------------------------------------------------------ small things */
  function lc(s) { return String(s == null ? '' : s).toLowerCase(); }
  function r0(n) { return Math.round(+n || 0); }
  function num(x) { var v = +x; return isFinite(v) ? v : 0; }
  function sum(list, f) { var s = 0; for (var i = 0; i < list.length; i++) s += num(f ? f(list[i]) : list[i]); return s; }
  function median(xs) { if (!xs.length) return 0; var s = xs.slice().sort(function (a, b) { return a - b; }), m = Math.floor(s.length / 2); return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2; }
  function clamp(x, lo, hi) { return Math.max(lo, Math.min(hi, x)); }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function dayOf(iso) { var p = String(iso || '').slice(0, 10).split('-'); return Date.UTC(+p[0], +p[1] - 1, +p[2]); }
  function addDays(iso, n) { var d = new Date(dayOf(iso) + n * 864e5); return d.getUTCFullYear() + '-' + pad(d.getUTCMonth() + 1) + '-' + pad(d.getUTCDate()); }
  function daysBetween(a, b) { return Math.round((dayOf(b) - dayOf(a)) / 864e5); }
  function isISO(s) { return /^\d{4}-\d{2}-\d{2}$/.test(String(s || '')); }
  /* a yyyy-MM-dd moved by n months, kept to the month's last day when it overflows (31 Jan + 1 month = 28 Feb) */
  function addMonths(iso, n) {
    var y = +iso.slice(0, 4), m = +iso.slice(5, 7) - 1 + n, d = +iso.slice(8, 10);
    y += Math.floor(m / 12); m = ((m % 12) + 12) % 12;
    var dim = new Date(Date.UTC(y, m + 1, 0)).getUTCDate();
    return y + '-' + pad(m + 1) + '-' + pad(Math.min(d, dim));
  }
  /* whole months from a to b (b later), counting a part month as one */
  function monthsUntil(a, b) {
    if (!isISO(a) || !isISO(b) || b <= a) return 0;
    var n = (+b.slice(0, 4) - +a.slice(0, 4)) * 12 + (+b.slice(5, 7) - +a.slice(5, 7));
    if (+b.slice(8, 10) > +a.slice(8, 10)) n++;
    return Math.max(1, n);
  }
  /* the months whose money lands between a and b: whole months after a's, the last only if b reaches its day */
  function wholeMonths(a, b) {
    if (!isISO(a) || !isISO(b) || b <= a) return 0;
    var n = (+b.slice(0, 4) - +a.slice(0, 4)) * 12 + (+b.slice(5, 7) - +a.slice(5, 7));
    if (+b.slice(8, 10) < +a.slice(8, 10)) n--;
    return Math.max(0, n);
  }
  var MON3 = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  function dShort(iso) { return isISO(iso) ? +iso.slice(8, 10) + ' ' + MON3[+iso.slice(5, 7) - 1] + ' ' + iso.slice(0, 4) : ''; }
  function mYear(iso) { return isISO(iso) ? MON3[+iso.slice(5, 7) - 1] + ' ' + iso.slice(0, 4) : ''; }
  function group(n) {
    var s = String(Math.round(Math.abs(n)));
    if (s.length <= 3) return s;
    var last = s.slice(-3), rest = s.slice(0, -3);
    return rest.replace(/\B(?=(\d{2})+(?!\d))/g, ',') + ',' + last;
  }
  function inr(n) { return (n < -0.5 ? '−' : '') + '₹' + group(n); }
  function trim2(x) { var s = x.toFixed(2); return s.replace(/0+$/, '').replace(/\.$/, ''); }
  /* ₹3 lakh, ₹1.25 crore, ₹45,000: for sentences */
  function words(n) {
    var a = Math.abs(n), s = n < -0.5 ? '−' : '';
    // (rounded before the unit is picked: ₹99.996 lakh is ₹1 crore, never "₹100 lakh")
    if (a >= 1e7 || Math.round(a / 1e3) >= 1e4) return s + '₹' + trim2(a / 1e7) + ' crore';
    if (a >= 1e5 || Math.round(a) >= 1e5) return s + '₹' + trim2(a / 1e5) + ' lakh';
    return s + '₹' + group(a);
  }
  /* "a, b and c" */
  function andList(xs) { return xs.length <= 1 ? (xs[0] || '') : xs.slice(0, -1).join(', ') + ' and ' + xs[xs.length - 1]; }
  function pct(x) { var v = Math.round(x * 100) / 100; return trim2(v) + '%'; }
  /* "15 years", "3 years 2 months", "8 months" */
  function span(months) {
    if (!isFinite(months)) return 'never, at this EMI';
    var y = Math.floor(months / 12), m = months % 12;
    if (!y) return m + ' month' + (m === 1 ? '' : 's');
    return y + ' year' + (y === 1 ? '' : 's') + (m ? ' ' + m + ' month' + (m === 1 ? '' : 's') : '');
  }

  /* ------------------------------------------------------------ the money maths */
  /** the EMI of a loan: P at rate% a year over n months (monthly rest, the Indian banks' convention) */
  function emiOf(P, rate, n) {
    var r = num(rate) / 1200;
    if (!(P > 0) || !(n > 0)) return 0;
    return r > 0 ? P * r * Math.pow(1 + r, n) / (Math.pow(1 + r, n) - 1) : P / n;
  }
  /** a loan paid down month by month: how many months, and the interest paid; never when the EMI doesn't cover the interest */
  function amortise(P, rate, emi, cap) {
    var r = num(rate) / 1200, bal = num(P), n = 0, interest = 0;
    cap = cap || 1200;
    if (!(bal > 0)) return { months: 0, interest: 0 };
    if (!(emi > 0) || emi <= bal * r + 1e-9) return { months: Infinity, interest: Infinity };
    while (bal > 0.005 && n < cap) {
      var i = bal * r;
      interest += i;
      bal = bal + i - emi;
      n++;
      if (bal < 0) bal = 0;
    }
    return { months: n, interest: interest };
  }
  /** what a sum grows to at ret% a year, compounded monthly, over n months */
  function fvLump(X, ret, months) { return num(X) * Math.pow(1 + num(ret) / 100, num(months) / 12); }
  /** what pmt a month, put in at each month's end, grows to at ret% a year over n months */
  function fvAnnuity(pmt, ret, months) {
    var m = Math.pow(1 + num(ret) / 100, 1 / 12) - 1, n = num(months);
    if (!(n > 0)) return 0;
    return m > 0 ? num(pmt) * (Math.pow(1 + m, n) - 1) / m : num(pmt) * n;
  }
  /** the return at which f(ret) changes sign between lo and hi (f rising), by halving */
  function solve(f, lo, hi) {
    var flo = f(lo), fhi = f(hi);
    if (!(flo < 0) || !(fhi > 0)) return null;
    for (var i = 0; i < 80; i++) {
      var mid = (lo + hi) / 2, v = f(mid);
      if (v > 0) hi = mid; else lo = mid;
    }
    return (lo + hi) / 2;
  }
  /** what a card balance costs if only the minimum is paid each month: months to clear, interest (and GST on it) */
  function minimumOnly(bal, monthly, minPct, floor) {
    var r = num(monthly) / 100, n = 0, interest = 0, b = num(bal);
    minPct = num(minPct) || 5; floor = floor == null ? 200 : floor;
    // the month's interest and GST at least the minimum: the balance never comes down
    if (b > 0.5 && b * r * 1.18 >= Math.max(b * minPct / 100, floor)) return { months: Infinity, interest: Infinity };
    while (b > 0.5 && n < 600) {
      var i = b * r, gst = i * 0.18;
      interest += i + gst;
      b += i + gst;
      var pay = Math.min(b, Math.max(b * minPct / 100, floor));
      b -= pay;
      n++;
    }
    return b > 0.5 ? { months: Infinity, interest: Infinity } : { months: n, interest: interest };
  }

  /* ------------------------------------------------------------ what the household's own numbers say */
  var LOAN_RATE = [[/home|housing|house|mortgage/, 8.5], [/car|vehicle|auto/, 9.5], [/two[- ]?wheeler|bike/, 12], [/education|student/, 10], [/gold/, 10], [/personal/, 13]];
  function defaultLoanRate(name) { var n = lc(name); for (var i = 0; i < LOAN_RATE.length; i++) if (LOAN_RATE[i][0].test(n)) return LOAN_RATE[i][1]; return 10; }
  /* the EMI the bank's mail shows for a loan added without one: a repeat named like it ("Example Home Loan EMI"), or of
     its kind at its bank, else the only EMI when it is the only loan without one */
  var LOAN_KIND = /\b(home|housing|car|vehicle|auto|personal|education|gold|bike|two[- ]?wheeler)\b/;
  function emiFromMail(l, recurring, lone) {
    var reps = (recurring || []).filter(function (r) { return r && r.kind === 'emi' && !r.gone && !r.lapsed && num(r.amount) > 0; });
    var b = lc(l.name).replace(/\s+/g, ' ').trim(), bank = lc(l.bank), kb = LOAN_KIND.exec(b);
    var hit = reps.filter(function (r) {
      var a = lc(r.name).replace(/\bemi\b/g, ' ').replace(/\s+/g, ' ').trim(), ka = LOAN_KIND.exec(a);
      if (a && b && (a.indexOf(b) >= 0 || b.indexOf(a) >= 0)) return true;
      return !!(ka && kb && ka[1] === kb[1] && (!bank || a.indexOf(bank) >= 0));
    })[0];
    if (hit) return num(hit.amount) / Math.max(1, num(hit.per) || 1);
    return lone && reps.length === 1 ? num(reps[0].amount) / Math.max(1, num(reps[0].per) || 1) : 0;
  }

  /* the months behind the money left over: complete months whose income kosh saw, newest last (at most six). A month
     where what came in covers less than half of what went out is one whose income the mail doesn't show (a salary
     paid into an account that sends no mail, or credits kosh can't name): its "left over" would be a fiction, so it
     is left out, and with no such month kosh says it can't see the income rather than guess. */
  function monthsOf(ctx) {
    return (ctx.cashflow || []).filter(function (c) { return c && !c.live && !c.noPay && num(c.inn) > 0 && num(c.inn) >= 0.5 * (num(c.out) + num(c.ev) + num(c.inv)); }).slice(-6);
  }
  /* complete months with spending, whatever kosh saw come in (for what usually goes out) */
  function spendMonthsOf(ctx) {
    return (ctx.cashflow || []).filter(function (c) { return c && !c.live && num(c.out) + num(c.ev) > 0; }).slice(-6);
  }
  function factsOf(ctx) {
    var today = ctx.today || '';
    var accts = (ctx.accounts || []).filter(function (a) { return a && a.balance !== null && a.balance !== undefined && isFinite(+a.balance); });
    var recent = accts.filter(function (a) { var d = String(a.asOf || '').slice(0, 10); return !isISO(d) || !isISO(today) || daysBetween(d, today) <= 90; });
    var old = accts.filter(function (a) { return recent.indexOf(a) < 0; });
    var stale = recent.filter(function (a) { var d = String(a.asOf || '').slice(0, 10); return isISO(d) && isISO(today) && daysBetween(d, today) > 10; });
    var bank = sum(recent, function (a) { return a.balance; });
    var ms = monthsOf(ctx);
    // the month's outgo: what was spent (and the trips left out of it), else income less what was left and invested
    var outgo = ms.map(function (c) { var o = num(c.out) + num(c.ev); return o > 0 ? o : num(c.inn) - num(c.kept) - num(c.inv); }).filter(function (v) { return v > 0; });
    var usual = num((ctx.fc || {}).usual) > 0 ? num(ctx.fc.usual) : median(outgo);
    // what usually goes out, from every recent complete month (for a take-home you tell kosh)
    var sm = spendMonthsOf(ctx), spendUsual = median(sm.map(function (c) { return num(c.out) + num(c.ev); }));
    // months of spending seen, and none with income that covers it: kosh can't see the income
    var blind = !ms.length && sm.length > 0;
    var before = ms.map(function (c) { return num(c.kept) + num(c.inv); });
    var recur = (ctx.recurring || []).filter(function (r) { return r && !r.gone && !r.lapsed; });
    var sip = sum(recur.filter(function (r) { return r.kind === 'sip'; }), function (r) { return num(r.amount) / Math.max(1, num(r.per) || 1); });
    var live = (ctx.loans || []).filter(function (l) { return l && l.active !== false; });
    var noEmi = live.filter(function (l) { return !(num(l.emi) > 0); }).length;
    var loans = live.map(function (l) {
      var bal = num(l.outstanding), mail = num(l.emi) > 0 ? 0 : emiFromMail(l, ctx.recurring, noEmi === 1);
      return { name: l.name || 'Loan', bank: l.bank || '', bal: bal, rate: num(l.rate), rateKnown: num(l.rate) > 0, emi: num(l.emi) || mail, emiMail: mail > 0 };
    });
    // EMIs: the loans' own, else the repeats kosh learned as EMIs
    var emiRep = sum(recur.filter(function (r) { return r.kind === 'emi'; }), function (r) { return num(r.amount) / Math.max(1, num(r.per) || 1); });
    var emiLoans = sum(loans, function (l) { return l.emi; });
    var emis = Math.max(emiRep, emiLoans);
    var holds = (ctx.hold || []).filter(function (h) { return h && num(h.amt) > 0; });
    var fds = holds.filter(function (h) { return h.cls === 'dep' && /^(?:FD|RD)$/i.test(h.type || '') ; });
    var liquid = holds.filter(function (h) { return h.cls === 'mf' && /liquid|overnight|money market|ultra short|arbitrage/i.test((h.type || '') + ' ' + (h.bank || '')); });
    return {
      today: today, bank: bank, accts: recent, stale: stale, old: old, oldAt: old.map(function (a) { return String(a.asOf || '').slice(0, 10); }).filter(isISO).sort().pop() || '', usual: usual, emis: emis, spendUsual: spendUsual, spendMonths: sm.length, blind: blind,
      income: median(ms.map(function (c) { return num(c.inn); })), before: median(before), beforeLo: before.length ? Math.min.apply(null, before) : 0,
      beforeHi: before.length ? Math.max.apply(null, before) : 0, months: ms.length, kept: median(ms.map(function (c) { return num(c.kept); })),
      invested: median(ms.map(function (c) { return num(c.inv); })), sip: sip, loans: loans, holds: holds, fds: fds, liquid: liquid,
      cards: (ctx.cards || []).map(function (c) {
        if (!c || !(num(c.due) > 0)) return null;
        var po = String(c.paidOn || '').slice(0, 10), so = String(c.stmtOn || '').slice(0, 10), dd = String(c.dueDate || '').slice(0, 10);
        // a payment since the statement came takes that much off what's due; a bill a month past its day is old news
        var since = isISO(po) && (!isISO(so) || po >= so) ? num(c.paid) : 0;
        var left = Math.max(0, num(c.due) - since);
        if (!(left > 0)) return null;
        if (isISO(dd) && isISO(today) && daysBetween(dd, today) > 30) return null;
        var o = {}; Object.keys(c).forEach(function (k) { o[k] = c[k]; });
        o.due = left; o.paidSince = since; o.pastDue = isISO(dd) && isISO(today) && dd < today;
        return o;
      }).filter(Boolean),
    };
  }
  /* "₹64,000 in HDFC ••4821 (10 Oct) and SBI ••1111 (1 Jul)" */
  function bankHow(F) {
    if (!F.accts.length) return 'kosh has no bank balance for you yet.';
    var parts = F.accts.slice(0, 4).map(function (a) { return (a.name || a.bank || 'An account') + (a.last ? ' ••' + a.last : '') + (isISO(String(a.asOf || '').slice(0, 10)) ? ' (' + dShort(String(a.asOf).slice(0, 10)).replace(/ \d{4}$/, '') + ')' : ''); });
    return 'The balances your banks last sent: ' + parts.join(', ') + (F.accts.length > 4 ? ' and ' + (F.accts.length - 4) + ' more' : '') + '.' + (F.stale.length ? ' Some are over ten days old.' : '');
  }
  /* a month's spending: EMIs, bills and premiums are in it already (kosh counts them as spending) */
  function needOf(F) { return F.usual > 0 ? F.usual : 0; }
  /* no balance to go on: none at all, or only ones too old (named, with their day) */
  function noBalance(d, F, what) {
    d.lean = 'unknown';
    d.missing.push('a recent bank balance');
    d.verdict = (F.oldAt ? 'The newest balance kosh has is from ' + dShort(F.oldAt) + ', too old to go on, so it can’t ' + what + '.' : 'kosh doesn’t have a bank balance for you yet, so it can’t ' + what + '.') +
      ' Ask again once a bank alert or statement with your balance comes in.';
    return d;
  }
  /* " This goes on the balance your bank sent on 1 Sep 2026." when that is over three weeks old */
  function staleLine(F) {
    var at = F.accts.map(function (a) { return String(a.asOf || '').slice(0, 10); }).filter(isISO).sort()[0];
    return at && isISO(F.today) && daysBetween(at, F.today) > 21 ? ' This goes on the balance your bank sent on ' + dShort(at) + '; if more has gone out since, there’s less.' : '';
  }

  /* ------------------------------------------------------------ one decision */
  function blank(kind, title, args, today) {
    return { kind: kind, title: title, verdict: '', lean: '', steps: [], key: [], assumptions: [], changes: [], note: '', missing: [], facts: [], figures: {}, args: JSON.stringify(args || {}), asOf: today || '', scenario: null };
  }
  function needs(d) { return andList(d.missing); }
  function step(d, label, value, how) { var n = d.steps.length + 1; d.steps.push({ n: n, label: label, value: value, how: how || '' }); return n; }
  function knob(d, key, label, value, unit, min, max, stepBy, note) { d.assumptions.push({ key: key, label: label, value: Math.round(num(value) * 100) / 100, unit: unit, min: min, max: max, step: stepBy, note: note || '' }); }
  function fact(d, key, label, value, unit) { if (isFinite(+value)) d.facts.push({ key: key, label: label, value: Math.round(+value * 100) / 100, unit: unit }); }
  var ADVICE = 'kosh works out the figures from your own money; the choice is yours. It isn’t a financial adviser.';

  function pickLoan(F, hint) {
    var h = lc(hint), list = F.loans.filter(function (l) { return l.bal > 0; });
    if (h) { var m = list.filter(function (l) { return lc(l.name + ' ' + l.bank).indexOf(h) >= 0 || (h === 'home' && /home|housing/.test(lc(l.name))) || (h === 'car' && /car|vehicle|auto/.test(lc(l.name))); }); if (m.length) list = m; }
    return list.sort(function (a, b) { return b.bal - a.bal; })[0] || null;
  }

  /* prepay a loan, or invest the same money */
  function prepay(a, ctx, F) {
    var d = blank('prepay', 'Prepay the loan, or invest?', a, ctx.today);
    var loan = pickLoan(F, a.loan);
    // with no loan added, the EMI kosh learned from the bank's mail (the one the question names, else the biggest)
    var rep = null;
    if (!loan) {
      var reps = (ctx.recurring || []).filter(function (r) { return r && r.kind === 'emi' && !r.gone && num(r.amount) > 0; });
      var named = a.loan ? reps.filter(function (r) { return lc(r.name).indexOf(lc(a.loan)) >= 0 || (a.loan === 'home' && /home|housing/.test(lc(r.name))); }) : [];
      rep = (named.length ? named : reps).sort(function (x, y) { return num(y.amount) - num(x.amount); })[0] || null;
    }
    var P = num(a.principal) || (loan ? loan.bal : 0), rate = num(a.rate) || (loan && loan.rateKnown ? loan.rate : 0);
    var E = num(a.emi) || (loan ? loan.emi : 0) || (rep ? num(rep.amount) : 0);
    var emiMail = !num(a.emi) && (loan ? loan.emiMail : !!rep);
    var name = loan ? loan.name : rep ? String(rep.name).replace(/\s*\bEMI\b\s*/i, ' ').trim() : (a.loan ? a.loan.replace(/^\w/, function (c) { return c.toUpperCase(); }) + ' loan' : 'The loan');
    if (!(E > 0) && P > 0 && rate > 0 && num(a.months) > 0) E = emiOf(P, rate, num(a.months));
    // (what's still needed, by name too, so a reply like "20 lakh at 8.5%" fills the right gaps)
    d.needs = [];
    if (!(P > 0)) { d.missing.push('what’s still outstanding on the loan'); d.needs.push('principal'); }
    if (!(rate > 0)) { d.missing.push('the loan’s interest rate'); d.needs.push('rate'); }
    if (!(E > 0) && !(num(a.months) > 0)) { d.missing.push('its EMI (or the months left)'); d.needs.push('emi'); }
    if (d.missing.length) {
      d.lean = 'unknown';
      d.verdict = 'To weigh it, kosh needs ' + needs(d) + '. Add the loan in Wealth › Debts, or say it: “prepay ₹3 lakh on ₹20 lakh at 8.5%, EMI ₹19,700”.';
      if (E > 0) step(d, 'What kosh knows', inr(E) + ' a month', name + '’s EMI' + (emiMail ? ', from your bank’s mail.' : loan ? ', as you added it.' : ', as you said.'));
      d.note = ADVICE;
      return d;
    }
    var ret = num(a.ret) > 0 ? num(a.ret) : 10;
    var need6 = 6 * needOf(F);
    var X = num(a.amount), assumedX = !!a.example;
    if (!(X > 0)) {
      // what's in the bank beyond six months of spending and EMIs; else an example to change. Kept with the question,
      // so working it out again later weighs the same amount
      var spare = F.bank - need6;
      X = spare >= 50000 ? Math.floor(spare / 50000) * 50000 : 100000;
      assumedX = true;
      a.amount = X; a.example = 1;
    }
    X = Math.min(X, P);
    var a1 = amortise(P, rate, E), a2 = amortise(P - X, rate, E);
    if (!isFinite(a1.months)) {
      d.lean = 'unknown';
      d.verdict = 'At ' + inr(E) + ' a month the EMI doesn’t cover the interest on ' + words(P) + ' at ' + pct(rate) + ', so kosh can’t weigh it. Check the loan’s figures.';
      d.note = ADVICE;
      return d;
    }
    var n1 = a1.months, n2 = a2.months, saved = a1.interest - a2.interest, early = n1 - n2;
    var FB = fvLump(X, ret, n1), FA = fvAnnuity(E, ret, n1 - n2), diff = FB - FA;
    var even = solve(function (rr) { return fvLump(X, rr, n1) - fvAnnuity(E, rr, n1 - n2); }, 0.01, 60);
    var end = isISO(ctx.today) ? addMonths(ctx.today, n1) : '';
    var left = F.bank - X;
    var said = num(a.principal) > 0 || num(a.rate) > 0;
    step(d, 'Your loan', words(P) + ' at ' + pct(rate), name + (said || !loan ? ', as you said' : ', as you added it') + '. EMI ' + inr(E) + ' a month' + (emiMail ? ', from your bank’s mail.' : '.'));
    step(d, 'Months left if nothing changes', span(n1), inr(E) + ' a month at ' + pct(rate) + ' clears ' + inr(P) + (end ? ' by ' + mYear(end) : '') + '.');
    step(d, 'Interest still to pay', inr(a1.interest), 'Each month’s interest on what’s left, added up over those ' + n1 + ' months.');
    step(d, 'Prepay ' + words(X) + ', same EMI', span(n2) + ', ' + inr(a2.interest) + ' interest', 'The loan falls to ' + inr(P - X) + '; the same EMI clears it ' + span(early) + ' sooner.');
    var sSaved = step(d, 'Interest saved by prepaying', inr(saved), inr(a1.interest) + ' less ' + inr(a2.interest) + ', at today’s rate. Most home loans float: if the rate goes up, prepaying saves more; if it falls, less.');
    step(d, 'Invest ' + words(X) + ' instead, at ' + pct(ret) + ' a year', inr(FB) + (end ? ' by ' + mYear(end) : ''), 'Over the same ' + n1 + ' months, compounded monthly, before tax.');
    step(d, 'Prepay, then invest the freed EMI', inr(FA) + (end ? ' by ' + mYear(end) : ''), 'Once the loan ends, ' + inr(E) + ' a month invested at ' + pct(ret) + ' for the ' + early + ' months left.');
    var sDiff = step(d, 'The difference', inr(Math.abs(diff)) + ' ' + (diff >= 0 ? 'for investing' : 'for prepaying'), inr(FB) + ' against ' + inr(FA) + '.');
    var sEven = even ? step(d, 'The return that breaks even', pct(even) + ' a year', 'Investing has to earn more than this a year, before tax, to come out ahead of prepaying.') : 0;
    d.key = [sSaved, sDiff].concat(sEven ? [sEven] : []);
    if (F.accts.length) step(d, 'Left in the bank after prepaying', inr(left), bankHow(F) + (need6 > 0 ? ' Six months of spending (EMIs included) is about ' + inr(need6) + '.' : ''));
    knob(d, 'ret', 'What investing would earn', ret, '%', 0, 18, 0.5, 'A year, before tax. Equity funds have averaged more over long stretches, with years of losses.');
    knob(d, 'amount', 'The prepayment', X, '₹', 10000, Math.max(10000, P), 10000, assumedX ? 'An example: say how much you have in mind.' : '');
    knob(d, 'rate', 'The loan’s rate', rate, '%', 1, 24, 0.05, '');
    var cushion = F.accts.length && need6 > 0 && left < need6;
    var margin = Math.max(0.05 * X, 25000);
    d.lean = diff > margin ? 'invest' : diff < -margin ? 'prepay' : 'close';
    var lead = d.lean === 'prepay' ? 'prepaying ' + words(X) + ' looks better: at today’s rate it saves ' + words(saved) + ' of interest and ends the loan ' + span(early) + ' early, more than investing at ' + pct(ret) + ' a year before tax is likely to make.'
      : d.lean === 'invest' ? 'investing ' + words(X) + ' could come out ahead by about ' + words(diff) + ' if it earns ' + pct(ret) + ' a year before tax; prepaying saves ' + words(saved) + ' of interest at today’s rate and ends the loan ' + span(early) + ' early.'
      : 'it’s close: prepaying ' + words(X) + ' saves ' + words(saved) + ' of interest at today’s rate, and investing at ' + pct(ret) + ' a year before tax would make about the same. Prepaying doesn’t depend on markets.';
    var cap = function (x) { return x.charAt(0).toUpperCase() + x.slice(1); };
    if (assumedX && cushion) d.verdict = 'There isn’t money to spare for it yet: the bank holds ' + words(F.bank) + ', under six months of spending (' + words(need6) + '). If you had ' + words(X) + ' to put in (an example: say your own amount), ' + lead;
    else if (cushion) d.verdict = left > 0 ? 'First, money for emergencies: after it, ' + words(left) + ' would be left in the bank, under six months of spending. If that’s fine, ' + lead
      : 'First, money for emergencies: the bank holds ' + words(F.bank) + ', less than ' + words(X) + ' and under six months of spending. If the money comes from elsewhere, ' + lead;
    else d.verdict = assumedX ? 'Taking ' + words(X) + ' as an example (say your own amount): ' + lead : cap(lead);
    if (even) d.changes.push('If investing earns more than ' + pct(even) + ' a year before tax, it comes out ahead; below that, prepaying wins. Tax on what investing makes lowers it.');
    d.changes.push('On a home you live in, under the old tax regime, up to ₹2 lakh of interest a year is deductible: that makes the loan cheaper and investing more attractive.');
    d.changes.push('If a floating rate goes up, prepaying saves more. If equity markets fall in the years you’re invested, investing makes less.');
    if (assumedX) d.changes.push('The amount is an example; change it to see your own.');
    d.note = ADVICE;
    fact(d, 'loanRate', name + '’s rate', rate, '%'); fact(d, 'loanBal', 'What’s outstanding on ' + name, P, '₹'); fact(d, 'loanEmi', name + '’s EMI', E, '₹'); fact(d, 'bank', 'In the bank', F.bank, '₹');
    d.figures = { saved: r0(saved), early: early, n1: n1, n2: n2, invested: r0(FB), prepaidThenInvested: r0(FA), diff: r0(diff), even: even ? Math.round(even * 100) / 100 : null, amount: r0(X) };
    d.scenario = { prepay: { amount: r0(X), loan: name } };
    return d;
  }

  /* a car in cash, or on a loan */
  function car(a, ctx, F) {
    var bike = /^(?:bike|scooter|scooty|two-wheeler|motorcycle)$/i.test(String(a.vehicle || '')), what = bike ? 'bike' : 'car';
    var d = blank('car', 'Buy the ' + what + ' in cash, or on a loan?', a, ctx.today);
    var C = num(a.amount);
    if (!(C > 0)) {
      d.missing.push('the ' + what + '’s price');
      d.lean = 'unknown';
      d.verdict = 'How much is the ' + what + '? Say it like “a ' + (bike ? '₹2 lakh bike' : '₹12 lakh car') + '”, and kosh weighs cash against a loan on your own money.';
      d.note = ADVICE;
      return d;
    }
    // what was said, within what a vehicle loan can be (a 0% "no-cost EMI" is one); a two-wheeler's loan costs more
    var rate = a.rate !== undefined && isFinite(+a.rate) ? clamp(num(a.rate), 0, 36) : (bike ? 12 : 9);
    var years = num(a.years) > 0 ? clamp(num(a.years), 1, 10) : (bike ? 3 : 5), n = Math.round(years * 12);
    var downPct = a.down !== undefined && isFinite(+a.down) && num(a.down) >= 0 ? clamp(num(a.down), 0, 100) : (num(a.downAmt) > 0 ? Math.min(100, num(a.downAmt) / C * 100) : 20);
    var D = Math.round(C * downPct / 100), Lo = C - D, E = emiOf(Lo, rate, n), interest = Math.max(0, E * n - Lo);
    if (Lo < 1) {
      // all of it down: there's no loan to weigh
      var after = F.bank - C;
      d.lean = 'cash';
      step(d, 'The ' + what, words(C), 'As you said, all of it paid down.');
      if (F.accts.length) step(d, 'In the bank afterwards', inr(after), bankHow(F));
      d.verdict = F.accts.length && after < 0 ? 'All of it down is cash, and the bank doesn’t hold ' + words(C) + ' now: a down payment you can make, and a loan for the rest, would weigh it.'
        : 'All of it down is paying cash: no loan, no interest.' + (F.accts.length ? ' It would leave ' + words(after) + ' in the bank' + (6 * needOf(F) > 0 && after < 6 * needOf(F) ? ', under six months of spending.' : '.') : '');
      knob(d, 'down', 'Down payment', downPct, '%', 0, 100, 5, '');
      d.note = ADVICE;
      d.figures = { emi: 0, interest: 0, diff: 0, down: D, borrowed: 0 };
      d.scenario = { purchase: { amount: r0(C), year: 1 } };
      fact(d, 'bank', 'In the bank', F.bank, '₹');
      return d;
    }
    var ret = num(a.ret) > 0 ? num(a.ret) : 7;
    var FA = fvAnnuity(E, ret, n), FB = fvLump(Lo, ret, n), diff = FB - FA;
    var even = solve(function (rr) { return fvLump(Lo, rr, n) - fvAnnuity(E, rr, n); }, 0.01, 60);
    var need6 = 6 * needOf(F);
    var afterCash = F.bank - C, afterLoan = F.bank - D;
    var share = F.income > 0 ? (E / F.income) * 100 : 0, allShare = F.income > 0 ? ((F.emis + E) / F.income) * 100 : 0;
    step(d, 'The ' + what, words(C), 'As you said.');
    step(d, 'On a loan', inr(D) + ' down, ' + inr(Lo) + ' borrowed', pct(downPct) + ' down; the rest at ' + pct(rate) + ' over ' + span(n) + '.');
    var sEmi = step(d, 'The EMI', inr(E) + ' a month', 'For ' + n + ' months: ' + inr(E * n) + ' in all.');
    var sInt = step(d, 'Interest on the loan', inr(interest), inr(E * n) + ' paid against ' + inr(Lo) + ' borrowed.');
    step(d, 'Cash: invest what the EMI would have been', inr(FA) + ' after ' + span(n), inr(E) + ' a month at ' + pct(ret) + ', what your savings earn.');
    step(d, 'Loan: keep ' + words(Lo) + ' invested instead', inr(FB) + ' after ' + span(n), 'The money not spent on the ' + what + ', at ' + pct(ret) + ' a year.');
    var sCd = step(d, 'The difference', inr(Math.abs(diff)) + ' ' + (diff >= 0 ? 'for the loan' : 'for cash'), inr(FB) + ' against ' + inr(FA) + '.');
    d.key = [sEmi, sInt, sCd];
    if (F.accts.length) {
      step(d, 'In the bank afterwards', 'cash: ' + inr(afterCash) + ' · loan: ' + inr(afterLoan), bankHow(F) + (need6 > 0 ? ' Six months of spending (EMIs included) is about ' + inr(need6) + '.' : ''));
    }
    var sShare = F.income > 0 ? step(d, 'The EMI against your income', Math.round(share) + '% of a month', 'Your usual month’s income is about ' + inr(F.income) + '; with your other EMIs, ' + Math.round(allShare) + '% goes to EMIs.') : 0;
    knob(d, 'rate', 'The ' + what + ' loan’s rate', rate, '%', 0, bike ? 30 : 20, 0.25, 'Ask the dealer’s bank and yours; they differ. A “no-cost EMI” is 0%.');
    knob(d, 'years', 'Years to repay', years, 'years', 1, bike ? 5 : 8, 1, '');
    knob(d, 'down', 'Down payment', downPct, '%', 0, 100, 5, '');
    knob(d, 'ret', 'What your savings earn', ret, '%', 3, 12, 0.5, 'A year, before tax: an FD or a debt fund earns about 7%.');
    var cashHurts = F.accts.length && need6 > 0 && afterCash < need6, cantCash = F.accts.length && afterCash < 0;
    var heavy = F.income > 0 && (share > 15 || allShare > 40);
    if (cantCash) { d.lean = 'loan'; d.key = [sEmi, sInt].concat(sShare ? [sShare] : []); d.verdict = 'The bank doesn’t hold ' + words(C) + ' now, so it’s a loan: about ' + inr(E) + ' a month for ' + span(n) + (interest >= 1 ? ', ' + words(interest) + ' in interest. A bigger down payment cuts both.' : ', with no interest at 0%: check the price is the same as paying cash.'); }
    else if (cashHurts && rate <= 12) { d.lean = 'loan'; d.verdict = 'Paying cash would leave ' + words(Math.max(0, afterCash)) + ' in the bank, under six months of spending; a loan keeps your cushion, for about ' + words(interest) + ' of interest.'; }
    else if (diff < 0) { d.lean = 'cash'; d.verdict = 'Paying cash looks better: the loan’s ' + pct(rate) + ' costs more than your savings earn (' + pct(ret) + '), and it saves about ' + words(interest) + ' of interest.'; }
    else { d.lean = 'loan'; d.verdict = 'A loan could make sense: your money earns ' + pct(ret) + ', more than the loan’s ' + pct(rate) + ', so keeping it invested comes out about ' + words(diff) + ' ahead.'; }
    if (heavy) d.verdict += ' The EMI would be ' + Math.round(share) + '% of your monthly income' + (allShare > 40 ? ', and EMIs ' + Math.round(allShare) + '% in all' : '') + ': on the high side.';
    if (even) d.changes.push('The loan comes out ahead only if your savings earn more than ' + pct(even) + ' a year; below that, cash wins.');
    d.changes.push('A dealer’s discount for cash, or a “no-cost EMI” offer, changes the sums: compare the on-road price both ways.');
    d.changes.push('If your income is uneven, a fixed EMI is a risk; if a big expense is coming, keeping cash in hand matters more.');
    d.note = ADVICE;
    fact(d, 'bank', 'In the bank', F.bank, '₹'); fact(d, 'income', 'Your usual month’s income', F.income, '₹'); fact(d, 'emis', 'Your EMIs', F.emis, '₹');
    d.figures = { emi: r0(E), interest: r0(interest), diff: r0(diff), down: D, borrowed: Lo };
    d.scenario = { purchase: { amount: r0(C), year: 1 } };
    if (d.lean !== 'cash' && Lo > 0) d.scenario.purchase.loan = { amount: r0(Lo), rate: rate, months: n };
    return d;
  }

  /* can we afford ₹X: now, or by a date */
  function afford(a, ctx, F) {
    var d = blank('afford', 'Can you afford it?', a, ctx.today);
    var X = num(a.amount), today = ctx.today;
    if (!(X > 0)) {
      d.missing.push('the amount');
      d.lean = 'unknown';
      d.verdict = 'How much is it? Say it like “can I afford ₹2 lakh by March”, and kosh checks it against your money.';
      return d;
    }
    if (!F.accts.length) return noBalance(d, F, 'say');
    var cushionM = num(a.cushion) > 0 ? num(a.cushion) : 6;
    var need = needOf(F), cushion = cushionM * need;
    var inWindow = function (x) { return x && !x.booked && isISO(x.date) && x.date >= today && x.date <= addDays(today, 30); };
    var due = (ctx.agenda || []).filter(function (x) { return inWindow(x) && x.kind !== 'in'; });
    var coming = (ctx.agenda || []).filter(function (x) { return inWindow(x) && x.kind === 'in'; });
    var dueAmt = sum(due, function (x) { return x.amt; }), inAmt = sum(coming, function (x) { return x.amt; });
    var avail = F.bank - dueAmt + inAmt, free = avail - cushion;
    // (a follow-up's months stand in for a date it replaced)
    var by = isISO(a.by) && a.by > today ? a.by : (num(a.months) > 0 ? addMonths(today, num(a.months)) : '');
    var m = by ? wholeMonths(today, by) : 0;
    // what's still to find, once what's free now is used, at the usual pace
    var perMonth = F.kept, toFind = Math.max(0, X - Math.max(0, free)), takes = perMonth > 0 && toFind > 0 ? span(Math.max(1, Math.ceil(toFind / perMonth - 1e-9))) : '';
    var listed = function (xs) { return xs.slice(0, 4).map(function (x) { return x.name + ' ' + inr(x.amt); }).join(', ') + (xs.length > 4 ? ' and ' + (xs.length - 4) + ' more' : '') + '.'; };
    step(d, 'In the bank now', inr(F.bank), bankHow(F));
    step(d, 'Going out in the next 30 days', inr(dueAmt), due.length ? listed(due) : 'Nothing kosh knows of.');
    if (inAmt > 0) step(d, 'Coming in the next 30 days', inr(inAmt), listed(coming));
    step(d, 'Set aside for emergencies', inr(cushion), need > 0 ? cushionM + ' months of spending, EMIs included (about ' + inr(need) + ' a month).' : 'Nothing: kosh hasn’t seen a month of your spending yet, so it can’t size it.');
    var sFree = step(d, 'Free to spend now', free >= 0 ? inr(free) : 'nothing yet', free >= 0 ? inr(F.bank) + (inAmt > 0 ? ' and what’s coming in,' : '') + ' less what’s due and the emergency money.' : 'The bank holds ' + inr(avail) + ' after what’s due, ' + inr(-free) + ' short of the emergency money.');
    d.key = [sFree];
    if (by) {
      var save = Math.max(0, perMonth) * m, have = Math.max(0, free) + save, needPM = m > 0 ? (X - Math.max(0, free)) / m : X;
      step(d, 'Left over each month, usually', inr(perMonth), F.months ? 'The middle of your last ' + F.months + ' months, after spending and investing.' : 'kosh hasn’t seen a full month of income yet.');
      d.key.push(step(d, 'Saved by ' + dShort(by), inr(have), (free > 0 ? inr(free) + ' free now and ' : '') + inr(Math.max(0, perMonth)) + ' a month for ' + m + ' month' + (m === 1 ? '' : 's') + ' (the months after this one, to ' + mYear(by) + ').'));
      if (have >= X) {
        d.lean = 'yes';
        d.verdict = 'Yes, by ' + dShort(by) + ': at your usual pace you’d have put aside about ' + words(have) + ', against ' + words(X) + '.' +
          (free < 0 ? ' Your emergency money is short of ' + cushionM + ' months, though (' + words(-free) + ' more), and this would wait on it.' : '');
      } else if (perMonth > 0 && m > 0 && needPM <= perMonth * 1.25) {
        d.lean = 'stretch';
        d.verdict = 'It’s a stretch by ' + dShort(by) + ': you’d need to put aside about ' + words(needPM) + ' a month, against the ' + words(perMonth) + ' you usually have left.';
      } else {
        d.lean = 'no';
        d.verdict = 'Not by ' + dShort(by) + ' at this pace: you’d have about ' + words(have) + ', ' + words(X - have) + ' short' + (takes ? '; at your usual pace it takes about ' + takes : '') + '.';
      }
      d.scenario = { purchase: { amount: r0(X), year: Math.max(1, Math.ceil(m / 12)) } };
    } else {
      if (avail < X) {
        d.lean = 'no';
        d.verdict = 'Not now: after what’s due in the next 30 days (' + words(dueAmt) + '), the bank has ' + words(Math.max(0, avail)) + ', ' + words(X - Math.max(0, avail)) + ' short.' + (takes ? ' At your usual ' + words(perMonth) + ' a month left over, the rest takes about ' + takes + ' to put aside.' : '');
      } else if (avail - X >= cushion) {
        d.lean = 'yes';
        d.verdict = 'Yes: after ' + words(X) + ' you’d still have ' + words(avail - X - cushion) + ' free, with what’s due paid and ' + cushionM + ' months of spending set aside.';
      } else if (avail - X >= 3 * need) {
        d.lean = 'stretch';
        d.verdict = 'You can, but it eats into your emergency money: it would leave ' + words(avail - X) + ' after what’s due, about ' + Math.floor((avail - X) / Math.max(1, need)) + ' months of spending.';
      } else {
        d.lean = 'no';
        d.verdict = 'You could pay it, but it would leave ' + words(avail - X) + ' after what’s due, under three months of spending.' + (takes ? ' Putting it aside first takes about ' + takes + ' at your usual pace.' : '');
      }
      d.scenario = { purchase: { amount: r0(X), year: 1 } };
    }
    if (!(need > 0)) d.verdict += ' kosh hasn’t seen a month of your spending yet, so nothing is set aside here for emergencies.';
    d.verdict += staleLine(F);
    knob(d, 'cushion', 'Months of spending set aside for emergencies', cushionM, 'months', 3, 12, 1, '');
    var fdSum = sum(F.fds, function (h) { return h.amt; });
    if (fdSum > 0) d.changes.push('Your FDs hold ' + words(fdSum) + ': breaking one adds to what’s free, at a small penalty.');
    if (F.sip > 0) d.changes.push('Pausing your SIPs (' + words(F.sip) + ' a month) would free more each month, at the cost of your investments.');
    d.changes.push('A bonus, or a big bill before then, changes it.');
    d.figures = { free: r0(free), avail: r0(avail), cushion: r0(cushion), due: r0(dueAmt) };
    fact(d, 'bank', 'In the bank', F.bank, '₹'); fact(d, 'kept', 'Left over each month', F.kept, '₹'); fact(d, 'need', 'A month’s spending', need, '₹');
    return d;
  }

  /* break an FD, or borrow against it */
  function fd(a, ctx, F) {
    var d = blank('fd', 'Break the FD, or not?', a, ctx.today);
    var h = lc(a.which), list = F.fds.slice();
    if (h) { var mm = list.filter(function (x) { return lc((x.bank || '') + ' ' + (x.type || '')).indexOf(h) >= 0; }); if (mm.length) list = mm; }
    var f = list.sort(function (x, y) { return num(y.amt) - num(x.amt); })[0];
    var amt = num(a.fdAmount) || (f ? num(f.amt) : 0), rate = num(a.fdRate) || (f ? num(f.rate) : 0);
    if (!(amt > 0) || !(rate > 0)) {
      d.lean = 'unknown';
      d.missing.push(amt > 0 ? 'the FD’s rate' : 'which FD (its amount and rate)');
      d.verdict = 'kosh doesn’t know an FD with its rate yet. Say it like “break my ₹3 lakh FD at 7.1%”, or add it in Wealth.';
      d.note = ADVICE;
      return d;
    }
    var mat = f && isISO(f.mat) ? f.mat : (isISO(a.mat) ? a.mat : '');
    var rm = mat ? monthsUntil(ctx.today, mat) : 0;
    // what's needed, when it was said; else the whole FD
    var needSaid = num(a.amount) > 0, N = Math.min(needSaid ? num(a.amount) : amt, amt);
    var p = a.penalty !== undefined && num(a.penalty) >= 0 ? num(a.penalty) : 1, spread = num(a.spread) > 0 ? num(a.spread) : 2;
    var heldKnown = num(a.held) > 0 || !!(f && isISO(f.start));
    var held = num(a.held) > 0 ? num(a.held) : (f && isISO(f.start) ? Math.max(0.1, daysBetween(f.start, ctx.today) / 365) : 1);
    var t = num(a.months) > 0 ? num(a.months) : (rm > 0 ? Math.min(rm, 6) : 6);
    // a loan against the FD runs only until it matures: then the FD pays it off
    var tb = rm > 0 ? Math.min(t, rm) : t;
    var penalty = amt * p / 100 * held;
    var od = N * (rate + spread) / 100 * tb / 12, odNet = N * spread / 100 * tb / 12;
    var freeNow = F.bank - 6 * needOf(F);
    var till = tb < t ? ', until it matures on ' + dShort(mat) + ' and pays the loan off' : '';
    step(d, 'The FD', words(amt) + ' at ' + pct(rate), (f ? (f.bank || 'Your FD') : 'As you said') + (mat ? ', maturing ' + dShort(mat) + ' (' + span(rm) + ')' : '') + '.');
    var sBr = step(d, 'Breaking it now', 'about ' + inr(penalty) + ' less interest', 'Banks usually pay ' + pct(p) + ' less for the time it was held (' + (heldKnown ? 'about ' + trim2(held) + ' year' + (held === 1 ? '' : 's') : 'kosh’s guess: about a year, since it doesn’t know when the FD opened') + ') when you break it early.');
    step(d, needSaid ? 'Borrowing ' + words(N) + ' against it instead' : 'Borrowing against the whole FD instead', 'about ' + inr(od) + ' interest for ' + span(tb), 'A loan or overdraft against an FD usually costs ' + pct(spread) + ' over its rate (' + pct(rate + spread) + '), and the FD keeps earning ' + pct(rate) + till + '.');
    var sOd = step(d, 'The borrowing’s real cost', inr(odNet), 'What it costs beyond what the FD earns on the same money: ' + pct(spread) + ' a year for ' + span(tb) + till + '.');
    d.key = [sBr, sOd];
    if (rm > 0) step(d, 'Waiting for it to mature', 'nothing lost', 'If the money can wait ' + span(rm) + ', it comes back in full.');
    if (F.accts.length) step(d, 'Free in the bank', inr(Math.max(0, freeNow)), bankHow(F) + ' Six months of spending set aside first.');
    knob(d, 'penalty', 'Penalty for breaking early', p, '%', 0, 2, 0.25, 'Check your bank’s: most charge 0.5% to 1%.');
    knob(d, 'spread', 'A loan against the FD costs over its rate', spread, '%', 0.5, 3, 0.25, '');
    knob(d, 'months', 'Months you need the money for', t, 'months', 1, 36, 1, '');
    knob(d, 'held', 'Years the FD has run', held, 'years', 0.25, 10, 0.25, f && isISO(f.start) ? '' : 'kosh doesn’t know when it opened: change this.');
    if (F.accts.length && freeNow >= N) { d.lean = 'keep'; d.verdict = 'You may not need to touch it: ' + words(Math.max(0, freeNow)) + ' is free in the bank beyond six months of spending, more than ' + (needSaid ? 'the ' + words(N) + ' you need.' : 'the whole FD (' + words(N) + ').') + staleLine(F); }
    else if (odNet < penalty) { d.lean = 'borrow'; d.verdict = 'Borrowing against the FD looks cheaper for ' + span(tb) + (till ? ' (until it matures)' : '') + ': about ' + words(odNet) + ' more than the FD earns, against ' + words(penalty) + ' lost by breaking it.'; }
    else if (penalty >= 1 && Math.abs(odNet - penalty) <= Math.max(100, 0.05 * penalty)) { d.lean = 'even'; d.verdict = 'It’s about even: breaking it costs about ' + words(penalty) + ' of interest, and borrowing against it about ' + words(odNet) + ' over ' + span(tb) + '. Breaking it is simpler; borrowing keeps the FD running.'; }
    else if (penalty < 1) { d.lean = 'break'; d.verdict = 'Breaking it looks cheaper: with no penalty it costs nothing extra, against about ' + words(odNet) + ' for borrowing over ' + span(tb) + '.'; }
    else { d.lean = 'break'; d.verdict = 'Breaking it looks cheaper: about ' + words(penalty) + ' less interest, against ' + words(odNet) + ' extra for borrowing over ' + span(tb) + '.'; }
    var cross = Math.max(1, Math.round(penalty / Math.max(1, N * spread / 100 / 12)));
    if (penalty < 1) d.changes.push('With no penalty, breaking it is the cheaper way for any length of time; a penalty of even 0.5% changes that for a few months.');
    else if (rm > 0 && cross >= rm) d.changes.push('Borrowing stays cheaper all the way to ' + dShort(mat) + ', when the FD matures and pays it off.');
    else d.changes.push('The longer you need the money, the more borrowing costs: past about ' + span(cross) + ', breaking it is cheaper.');
    d.changes.push('Some banks let you break part of an FD, or don’t charge a penalty on a senior citizen’s or a tax-saver’s terms (a 5-year tax-saver FD can’t be broken at all).');
    d.note = ADVICE;
    d.figures = { penalty: r0(penalty), od: r0(od), odNet: r0(odNet) };
    fact(d, 'fdRate', 'The FD’s rate', rate, '%'); fact(d, 'bank', 'In the bank', F.bank, '₹');
    return d;
  }

  /* is the emergency fund enough */
  function emergency(a, ctx, F) {
    var d = blank('emergency', 'Is your emergency fund enough?', a, ctx.today);
    var months = num(a.months) > 0 ? clamp(num(a.months), 1, 24) : 6;
    var need = needOf(F);
    if (!F.accts.length) return noBalance(d, F, 'size the cushion');
    if (!(need > 0)) {
      d.lean = 'unknown';
      d.missing.push('a month of your spending');
      d.verdict = 'kosh hasn’t seen a full month of your spending yet, so it can’t size the cushion. Ask again once a month of mail is in.';
      return d;
    }
    var target = months * need;
    var liquid = sum(F.liquid, function (h) { return h.amt; }), fdSum = sum(F.fds, function (h) { return h.amt; });
    var now = F.bank + liquid, withFd = now + fdSum;
    var covered = now / need, coveredFd = withFd / need;
    var sNeed = step(d, 'A month’s spending', inr(need), (num((ctx.fc || {}).usual) > 0 ? 'Your usual month, from the last three.' : 'The middle of your last ' + F.months + ' months.') + (F.emis > 0 ? ' EMIs, ' + inr(F.emis) + ' of it, go out whatever happens.' : ''));
    step(d, 'The cushion for ' + months + ' months', inr(target), months + ' × ' + inr(need) + '.');
    step(d, 'In the bank', inr(F.bank), bankHow(F));
    if (liquid > 0) step(d, 'In liquid funds', inr(liquid), 'Out in a day or two.');
    var sLast = step(d, 'Months it would last', trim2(Math.floor(covered * 10) / 10) + ' months', inr(now) + ' ÷ ' + inr(need) + '.');
    var sFd = fdSum > 0 ? step(d, 'With your FDs', trim2(Math.floor(coveredFd * 10) / 10) + ' months', inr(fdSum) + ' in FDs can be broken in a day, at a small penalty.') : 0;
    d.key = [sNeed, sLast].concat(sFd ? [sFd] : []);
    knob(d, 'months', 'Months of cushion', months, 'months', 3, 12, 1, 'Six is the usual rule; more with one income, dependants or an uncertain job.');
    if (now >= target) { d.lean = 'yes'; d.verdict = 'Yes: ' + words(now) + ' would last about ' + trim2(Math.floor(covered * 10) / 10) + ' months of spending, past the ' + months + ' months you’d want.' + (now > target * 1.5 ? ' What’s beyond it could be earning more.' : ''); }
    else if (withFd >= target) { d.lean = 'fd'; d.verdict = 'With your FDs, yes (' + trim2(Math.floor(coveredFd * 10) / 10) + ' months); in the bank alone ' + trim2(Math.floor(covered * 10) / 10) + ' months, short of ' + months + '. Keeping some in a sweep-in FD or a liquid fund makes it quicker to reach.'; }
    else { d.lean = 'no'; d.verdict = 'Not yet: the bank holds ' + trim2(Math.floor(covered * 10) / 10) + ' months of spending' + (fdSum > 0 ? ', ' + trim2(Math.floor(coveredFd * 10) / 10) + ' with your FDs' : '') + '; ' + months + ' months is ' + words(target) + ', ' + words(target - withFd) + ' more.' + (F.kept > 0 ? ' At your usual ' + words(F.kept) + ' a month left over, that’s about ' + span(Math.ceil((target - withFd) / F.kept)) + '.' : ''); }
    d.verdict += staleLine(F);
    d.changes.push('Good health cover means a hospital stay needn’t come out of this money.');
    d.changes.push('One income, dependants or a job that could go: aim for more months. Two steady incomes: fewer will do.');
    d.figures = { need: r0(need), target: r0(target), months: Math.floor(covered * 10) / 10, monthsFd: Math.floor(coveredFd * 10) / 10 };
    fact(d, 'bank', 'In the bank', F.bank, '₹'); fact(d, 'need', 'A month’s spending', need, '₹');
    return d;
  }

  /* pay the card in full, or the minimum */
  function card(a, ctx, F) {
    var d = blank('card', 'Pay the card in full, or the minimum?', a, ctx.today);
    var h = lc(a.card), list = F.cards.slice();
    if (h) { var m = list.filter(function (c) { return lc((c.name || '') + ' ' + (c.bank || '') + ' ' + (c.last || '')).indexOf(h) >= 0; }); if (m.length) list = m; }
    // the bill still to pay first, then one past its day
    var c = list.sort(function (x, y) { return (x.pastDue ? 1 : 0) - (y.pastDue ? 1 : 0) || String(x.dueDate || '9999').localeCompare(String(y.dueDate || '9999')) || num(y.due) - num(x.due); })[0];
    // no card's statement read: a card bill on the calendar, the nearest
    if (!c) {
      var bills = (ctx.agenda || []).filter(function (x) { return x && x.kind !== 'in' && !x.booked && num(x.amt) > 0 && /\bcard\b/i.test(x.name || '') && isISO(x.date) && x.date >= (ctx.today || ''); })
        .filter(function (x) { return !h || lc(x.name).indexOf(h) >= 0; }).sort(function (x, y) { return x.date.localeCompare(y.date); });
      if (bills[0]) c = { name: String(bills[0].name).replace(/\s*\bbill\b\s*$/i, ''), due: num(bills[0].amt), dueDate: bills[0].date, minDue: /minimum ₹?([\d,]+)/i.test(bills[0].sub || '') ? +(/minimum ₹?([\d,]+)/i.exec(bills[0].sub)[1].replace(/,/g, '')) : 0 };
    }
    var T = num(a.amount) || (c ? num(c.due) : 0);
    if (!(T > 0)) {
      d.lean = 'unknown';
      d.missing.push('the card’s due');
      d.verdict = 'kosh doesn’t have a card bill due right now. Ask again when the statement comes, or say the amount.';
      return d;
    }
    // the minimum is never more than the bill
    var M = Math.min(T, num(a.min) || (c && num(c.minDue) > 0 ? num(c.minDue) : Math.max(200, Math.round(T * 0.05))));
    var rate = num(a.monthly) > 0 ? clamp(num(a.monthly), 0.5, 6) : 3.6, carried = Math.max(0, T - M);
    // a bill not paid in full loses its interest-free days: interest runs on the whole bill from each purchase's date
    // (about a month of it by the next statement), not just on what's carried
    var next = carried > 0 ? T * rate / 100 : 0, gst = next * 0.18;
    var mo = minimumOnly(T, rate, 5, 200);
    var yearly = pct(Math.round((Math.pow(1 + rate / 100, 12) - 1) * 1000) / 10);
    var name = c ? (c.name || c.bank || 'Your card') + (c.last ? ' ••' + c.last : '') : 'The card';
    var late = !!(c && c.pastDue);
    step(d, 'The bill', inr(T) + (c && isISO(c.dueDate) ? (late ? ', was due ' : ', due ') + dShort(c.dueDate) : ''), name + ', from its statement.');
    step(d, 'The minimum', inr(M), M >= T ? 'The whole bill.' : 'Paying it avoids the late fee, not the interest.');
    step(d, 'Carried if you pay the minimum', inr(carried), inr(T) + ' less ' + inr(M) + '.');
    var sNext = step(d, 'Interest next month', inr(next + gst), carried > 0 ? 'Not paid in full, the bill loses its interest-free days: ' + pct(rate) + ' a month (about ' + yearly + ' a year) on the whole ' + inr(T) + ' from the day of each purchase, not just the ' + inr(carried) + ' carried, plus 18% GST on the interest. New spends pay interest from day one too.' : 'Nothing is carried.');
    var sMin = !(carried > 0) ? step(d, 'If you only ever paid the minimum', 'Cleared at once', 'The minimum is the whole bill.')
      : step(d, 'If you only ever paid the minimum', isFinite(mo.months) ? span(mo.months) + ', ' + inr(mo.interest) + ' interest' : 'Never cleared', isFinite(mo.months) ? 'Five percent of the balance (at least ₹200) each month, interest and GST added each month.' : 'At ' + pct(rate) + ' a month, the interest and GST each month are more than a 5% minimum: the balance keeps growing.');
    d.key = [sNext, sMin];
    if (F.accts.length) step(d, 'In the bank', inr(F.bank), bankHow(F));
    knob(d, 'monthly', 'The card’s interest, a month', rate, '%', 1, 4.5, 0.05, 'Most Indian cards charge 3.5% to 3.75% a month.');
    var lateLine = late ? ' Its due date (' + dShort(c.dueDate) + ') has passed: a late fee and interest are already running, so pay it now.' : '';
    if (!(carried > 0)) { d.lean = 'full'; d.verdict = 'The minimum is the whole bill: pay the ' + words(T) + '.' + lateLine; }
    else if (!F.accts.length || F.bank >= T) { d.lean = 'full'; d.verdict = 'Pay the full ' + words(T) + (F.accts.length ? ': it’s in the bank' : '') + '. Paying only the minimum would cost about ' + words(next + gst) + ' of interest next month alone (on the whole bill, at ' + pct(rate) + ' a month), far more than any savings earn.' + lateLine; }
    else { d.lean = 'most'; d.verdict = 'The full ' + words(T) + ' isn’t in the bank, so pay as much above the minimum as you can: until it’s cleared, interest runs at ' + pct(rate) + ' a month on the whole bill from each purchase, and on what’s left after.' + lateLine; }
    d.changes.push('If a loan or an FD-backed overdraft costs less than ' + yearly + ' a year (almost all do), using it to clear the card is cheaper.');
    d.figures = { next: r0(next + gst), carried: r0(carried), minMonths: !(carried > 0) ? 0 : isFinite(mo.months) ? mo.months : null, minInterest: !(carried > 0) ? 0 : isFinite(mo.interest) ? r0(mo.interest) : null };
    fact(d, 'bank', 'In the bank', F.bank, '₹'); fact(d, 'cardDue', name + '’s bill', T, '₹');
    return d;
  }

  var KINDS = { prepay: prepay, car: car, afford: afford, fd: fd, emergency: emergency, card: card };
  /** one decision: kind and what was asked (amounts, rates, a loan or an FD by name, a date), worked out on ctx */
  function decide(kind, args, ctx) {
    ctx = ctx || {};
    var fn = KINDS[kind];
    if (!fn) return null;
    var a = {};
    Object.keys(args || {}).forEach(function (k) { if (args[k] !== undefined && args[k] !== null && args[k] !== '') a[k] = args[k]; });
    // (a rate of 0.09 from a tool means 9%; 0 stays 0, a no-cost EMI)
    ['rate', 'ret', 'fdRate', 'monthly', 'down'].forEach(function (k) { var v = +a[k]; if (a[k] !== undefined && isFinite(v) && v > 0 && v < 1) a[k] = Math.round(v * 10000) / 100; });
    var d = fn(a, ctx, factsOf(ctx));
    d.args = JSON.stringify(a);
    d.id = kind + '|' + (ctx.today || '') + '|' + d.args;
    return d;
  }
  /** a saved decision worked out again on today's numbers: what moved since, and whether the answer did */
  function rerun(saved, ctx) {
    if (!saved || !KINDS[saved.kind]) return null;
    var args = {};
    try { args = JSON.parse(saved.args || '{}') || {}; } catch (e) { args = {}; }
    var d = decide(saved.kind, args, ctx);
    var was = {};
    (saved.facts || []).forEach(function (f) { was[f.key] = f; });
    d.since = [];
    d.facts.forEach(function (f) {
      var o = was[f.key];
      if (!o || !isFinite(+o.value)) return;
      var moved = f.unit === '%' ? Math.abs(f.value - o.value) >= 0.01 : Math.abs(f.value - o.value) >= Math.max(1, Math.abs(o.value) * 0.02);
      if (!moved) return;
      var fmt = function (v) { return f.unit === '%' ? pct(v) : f.unit === '₹' ? words(v) : String(v) + ' ' + f.unit; };
      d.since.push(f.label + ' ' + (f.value > o.value ? 'went up' : 'went down') + ' from ' + fmt(o.value) + ' to ' + fmt(f.value) + '.');
    });
    if (d.lean === 'unknown' && saved.lean && saved.lean !== 'unknown') d.since.push('kosh can’t weigh it again yet: it needs ' + needs(d) + '.');
    else if (saved.lean && d.lean && saved.lean !== d.lean && saved.lean !== 'unknown') d.since.push('The answer changed: ' + d.verdict);
    else if (!d.since.length) d.since.push('Nothing kosh used has moved since you saved it.');
    d.savedOn = saved.savedOn || saved.asOf || '';
    return d;
  }

  /* ------------------------------------------------------------ the projection */
  var RATES = { equity: 10, debt: 7, savings: 3, ret: 7.5, gold: 6, ins: 6, prop: 5, inflation: 5 };
  var RATE_LABEL = {
    equity: ['Shares and equity funds', 'A year. Over long stretches Indian equity funds have earned more, with years of losses.'],
    debt: ['Bonds, debt funds, and FDs once they mature', 'A year, about what a fixed deposit earns.'],
    savings: ['Savings accounts', 'A year.'],
    ret: ['EPF, PPF and NPS', 'A year: EPF pays a little more, PPF a little less.'],
    gold: ['Gold', 'A year.'], ins: ['Insurance savings (ULIPs, endowments)', 'A year.'], prop: ['Property', 'A year.'],
    inflation: ['Prices rising', 'A year: for what the end figure is worth in today’s money.'],
  };
  /* a fund that lends rather than owns shares: it grows at the debt rate */
  var DEBT_FUND = /\b(?:liquid|overnight|money market|debt|gilt|g-?sec|bonds?|corporate|credit|banking\s*(?:&|and)?\s*psu|psu|arbitrage|ultra[- ]short|low duration|short duration|medium duration|long duration|dynamic bond|floater|floating rate|treasury|fixed maturity|fmp|target maturity)\b/i;
  /* what is owned today, by kind: from the phone's own figures (ctx.start), else from the ledger */
  function startOf(ctx) {
    var s = ctx.start || null, out = { bank: 0, cash: 0, prop: 0, eq: 0, debt: 0, ret: 0, gold: 0, ins: 0, fds: [], loans: [] };
    var holds = s && s.hold ? s.hold : (ctx.hold || []);
    out.bank = s && s.bank != null ? num(s.bank) : sum((ctx.accounts || []).filter(function (a) { return a && a.balance != null; }), function (a) { return a.balance; });
    out.cash = s ? num(s.cash) : 0;
    out.prop = s ? num(s.prop) : 0;
    holds.forEach(function (h) {
      var v = num(h.amt);
      if (!(v > 0)) return;
      var cls = h.cls || 'mf', type = String(h.type || '');
      if (cls === 'mf' && DEBT_FUND.test(type + ' ' + (h.bank || '') + ' ' + (h.name || ''))) out.debt += v;
      else if (cls === 'mf' || cls === 'stk') out.eq += v;
      else if (cls === 'ret') out.ret += v;
      else if (cls === 'gold' || /^gold$/i.test(type)) out.gold += v;
      else if (cls === 'ins') out.ins += v;
      else if (cls === 'dep' && /^(?:FD|RD)$/i.test(type) && num(h.rate) > 0 && isISO(String(h.mat || '').length === 7 ? h.mat + '-28' : h.mat)) out.fds.push({ name: (h.bank ? h.bank + ' ' : '') + (/^RD$/i.test(type) ? 'RD' : 'FD'), amt: v, rate: num(h.rate), mat: String(h.mat).length === 7 ? h.mat + '-28' : h.mat });
      else out.debt += v;
    });
    var loans = (s && s.loans ? s.loans : (ctx.loans || [])).filter(function (l) { return l && l.active !== false; });
    var noEmi = loans.filter(function (l) { return !(num(l.emi) > 0); }).length;
    loans.forEach(function (l) {
      var bal = num(l.outstanding != null ? l.outstanding : l.bal);
      if (!(bal > 0)) return;
      var emi = num(l.emi) > 0 ? num(l.emi) : emiFromMail(l, ctx.recurring, noEmi === 1);
      out.loans.push({ name: l.name || 'Loan', bal: bal, rate: num(l.rate) > 0 ? num(l.rate) : defaultLoanRate(l.name), rateGuessed: !(num(l.rate) > 0), emi: emi });
    });
    return out;
  }
  function worthOf(st) {
    return st.bank + st.cash + st.prop + st.eq + st.debt + st.ret + st.gold + st.ins + sum(st.fds, function (f) { return f.live === false ? 0 : f.amt; }) - sum(st.loans, function (l) { return l.bal; });
  }
  function partsOf(st) {
    return { cash: r0(st.bank + st.cash), invest: r0(st.eq), safe: r0(st.debt + st.ret + sum(st.fds, function (f) { return f.live === false ? 0 : f.amt; })), other: r0(st.gold + st.ins + st.prop), loans: r0(sum(st.loans, function (l) { return l.bal; })) };
  }
  function clone(st) {
    return { bank: st.bank, cash: st.cash, prop: st.prop, eq: st.eq, debt: st.debt, ret: st.ret, gold: st.gold, ins: st.ins,
      fds: st.fds.map(function (f) { return { name: f.name, amt: f.amt, rate: f.rate, mat: f.mat, live: true }; }),
      loans: st.loans.map(function (l) { return { name: l.name, bal: l.bal, rate: l.rate, emi: l.emi, rateGuessed: l.rateGuessed, done: false }; }) };
  }
  /* month by month: growth, FDs maturing into debt, loans paying down, the month's money in; a point at each year's end */
  function run(start, R, flow, scen, today, years, events) {
    var st = clone(start), pts = [], M = years * 12, freed = 0, dry = '', zero = '', sold = 0, at = today, grows = [];
    var mo = {}; Object.keys(R).forEach(function (k) { mo[k] = Math.pow(1 + R[k] / 100, 1 / 12) - 1; });
    var extraSip = num(scen.sip), dIncome = num(scen.income) ? flow.income * num(scen.income) / 100 : 0;
    var pp = scen.prepay && num(scen.prepay.amount) > 0 ? scen.prepay : null;
    var buy = scen.purchase && num(scen.purchase.amount) > 0 ? scen.purchase : null;
    var buyAt = buy ? (clamp(Math.round(num(buy.year) || 1), 1, years) - 1) * 12 + 1 : 0;
    var lend = buy && buy.loan && num(buy.loan.amount) > 0 ? buy.loan : null;
    function take(x) {
      // money needed: from the bank, then debt, then what's invested (counted as sold, from the month the bank has none)
      st.bank -= x;
      var y = 0, z = 0;
      if (st.bank < 0) { y = Math.min(st.debt, -st.bank); st.debt -= y; st.bank += y; }
      if (st.bank < 0) { z = Math.min(st.eq, -st.bank); st.eq -= z; st.bank += z; }
      if (y + z > 0.5) { sold += y + z; if (!zero) { zero = at; if (events) events.push({ m: monthOf(at), text: 'The bank reaches nothing; from here savings and investments are sold to cover the months.' }); } }
    }
    function monthOf(iso) { return Math.max(0, (+iso.slice(0, 4) - +today.slice(0, 4)) * 12 + (+iso.slice(5, 7) - +today.slice(5, 7))); }
    if (pp) {
      var ln = st.loans.filter(function (l) { return !pp.loan || lc(l.name) === lc(pp.loan) || lc(l.name).indexOf(lc(pp.loan)) >= 0; }).sort(function (a, b) { return b.bal - a.bal; })[0];
      if (ln) { var y0 = Math.min(num(pp.amount), ln.bal); ln.bal -= y0; take(y0); }
    }
    pts.push({ y: 0, date: today, worth: r0(worthOf(st)), parts: partsOf(st) });
    for (var k = 1; k <= M; k++) {
      var monthEnd = addMonths(today, k), freedBefore = freed;
      at = monthEnd;
      st.bank *= 1 + (st.bank > 0 ? mo.savings : 0); st.eq *= 1 + mo.equity; st.debt *= 1 + mo.debt; st.ret *= 1 + mo.ret;
      st.gold *= 1 + mo.gold; st.ins *= 1 + mo.ins; st.prop *= 1 + mo.prop;
      st.fds.forEach(function (f) {
        if (!f.live) return;
        f.amt *= Math.pow(1 + f.rate / 400, 1 / 3);
        if (f.mat <= monthEnd) { st.debt += f.amt; f.live = false; if (events) events.push({ m: k, text: f.name + ' matures; renewed at ' + pct(R.debt) + '.' }); }
      });
      st.loans.forEach(function (l) {
        if (l.done || !(l.bal > 0)) return;
        if (!(l.emi > 0)) return;   // no EMI known: the loan stays as it is
        var i = l.bal * l.rate / 1200, pay = Math.min(l.emi, l.bal + i);
        if (i > l.emi && grows.indexOf(l.name) < 0) { grows.push(l.name); if (events) events.push({ m: k, text: l.name + '’s EMI (' + inr(l.emi) + ') is less than its interest (' + inr(i) + ' a month): it grows.' }); }
        l.bal = l.bal + i - pay;
        // a loan taken in the scenario: its EMI isn't in the months behind 'before', so it comes out of the bank
        if (l.fresh) take(pay);
        if (l.bal <= 0.5) {
          l.bal = 0; l.done = true;
          if (!l.fresh) { freed += l.emi; st.bank += l.emi - pay; }
          if (events) events.push({ m: k, text: l.name + ' ends; its ' + inr(l.emi) + ' EMI is free from then.' });
        }
      });
      st.eq += flow.invest + extraSip;
      // (the months behind 'before' paid every EMI: one that has ended adds its EMI from the month after)
      var left = flow.before + dIncome - flow.invest - extraSip + freedBefore;
      if (left >= 0) st.bank += left; else take(-left);
      if (buy && k === buyAt) {
        var lent = lend ? Math.min(num(lend.amount), num(buy.amount)) : 0;
        take(num(buy.amount) - lent);
        if (lent > 0) {
          var lr = num(lend.rate) > 0 ? num(lend.rate) : 9, ln2 = Math.max(1, Math.round(num(lend.months) || 60));
          st.loans.push({ name: lend.name || 'The new loan', bal: lent, rate: lr, emi: emiOf(lent, lr, ln2), rateGuessed: false, done: false, fresh: true });
        }
      }
      if (st.bank < 0 && !dry) dry = monthEnd;
      if (k % 12 === 0) pts.push({ y: k / 12, date: monthEnd, worth: r0(worthOf(st)), parts: partsOf(st) });
    }
    // dry: the month the bank first runs out (and selling starts); broke: when there's nothing left to sell
    return { pts: pts, dry: zero || dry, broke: dry, sold: sold, grows: grows };
  }
  /** five years (or opts.years) ahead: { start, base, scen, flow, assumptions, events, notes, headline, scenarioLine } */
  function project(ctx, opts) {
    ctx = ctx || {}; opts = opts || {};
    var today = isISO(ctx.today) ? ctx.today : '2026-01-01', years = clamp(Math.round(num(opts.years) || 5), 1, 30);
    var R = {}, A = opts.assume || {};
    Object.keys(RATES).forEach(function (k) { R[k] = A[k] != null && isFinite(+A[k]) ? clamp(+A[k], -20, 40) : RATES[k]; });
    var F = factsOf(ctx), start = startOf(ctx);
    var invest = A.invest != null && isFinite(+A.invest) ? Math.max(0, +A.invest) : (F.sip > 0 ? F.sip : F.invested);
    // a take-home you give kosh: what's left before investing is that less what usually goes out
    var takeHome = A.income != null && isFinite(+A.income) && +A.income > 0 ? +A.income : 0;
    var before = A.before != null && isFinite(+A.before) ? +A.before
      : takeHome ? takeHome - F.spendUsual
      // (income kosh can't see: the bank is held where it is and the SIPs go on, rather than a fall it can't know)
      : F.blind ? invest : F.before;
    var income = takeHome || F.income;
    // (SIPs carry on whatever the month left: what's put in comes out of the money before investing)
    var flow = { before: before, invest: invest, income: income, lo: F.beforeLo, hi: F.beforeHi, months: F.months, sip: F.sip };
    var events = [];
    var base = run(start, R, flow, {}, today, years, events);
    var scen = opts.scenario || {}, hasScen = !!(num(scen.sip) || num(scen.income) || (scen.prepay && num(scen.prepay.amount) > 0) || (scen.purchase && num(scen.purchase.amount) > 0));
    var alt = hasScen ? run(start, R, flow, scen, today, years, null) : null;
    var end = base.pts[base.pts.length - 1], endAlt = alt ? alt.pts[alt.pts.length - 1] : null;
    var real = end.worth / Math.pow(1 + R.inflation / 100, years);
    var out = {
      today: today, years: years, start: base.pts[0], base: base.pts, scen: alt ? alt.pts : [], flow: { before: r0(before), invest: r0(invest), income: r0(income), lo: r0(F.beforeLo), hi: r0(F.beforeHi), months: F.months, sip: r0(F.sip), blind: F.blind && !takeHome && A.before == null },
      assumptions: [], events: events.map(function (e) { return { y: Math.ceil(e.m / 12), date: addMonths(today, e.m), text: e.text }; }).slice(0, 8), notes: [],
      headline: '', scenarioLine: '', real: r0(real), dry: base.dry, dryAlt: alt ? alt.dry : '',
    };
    Object.keys(RATES).forEach(function (k) { out.assumptions.push({ key: k, label: RATE_LABEL[k][0], value: R[k], unit: '%', min: k === 'inflation' ? 0 : -5, max: k === 'inflation' ? 12 : 20, step: 0.5, note: RATE_LABEL[k][1] }); });
    out.assumptions.push({ key: 'income', label: 'Take-home a month', value: r0(income), unit: '₹', min: 0, max: 5000000, step: 5000, note: takeHome ? 'Yours. What usually goes out is ' + inr(F.spendUsual) + ' a month, so ' + inr(takeHome - F.spendUsual) + ' is left before investing.' : F.blind ? 'kosh can’t see your salary in your mail. Put in what lands each month and it works out what’s left.' : F.months ? 'What kosh saw come in, the middle of your last ' + F.months + ' months.' : 'kosh hasn’t seen a full month of income yet.' });
    out.assumptions.push({ key: 'before', label: 'Left each month before investing', value: r0(before), unit: '₹', min: -500000, max: 2000000, step: 1000, note: A.before != null ? 'Yours.' : takeHome ? 'Your take-home less what usually goes out.' : F.blind ? 'Not known: kosh can’t see your income, so it keeps the bank where it is.' : F.months ? 'The middle of your last ' + F.months + ' months (' + inr(F.beforeLo) + ' to ' + inr(F.beforeHi) + ').' : 'kosh hasn’t seen a full month of income yet.' });
    out.assumptions.push({ key: 'invest', label: 'Invested each month', value: r0(invest), unit: '₹', min: 0, max: 1000000, step: 500, note: F.sip > 0 ? 'Your SIPs.' : 'What you put in, the middle of the recent months.' });
    var when = mYear(end.date);
    out.headline = out.flow.blind ? 'kosh can’t see your income yet, so this only grows what you own: about ' + words(end.worth) + ' by ' + when + '.' : (end.worth >= 0 ? 'At this pace, about ' + words(end.worth) : 'At this pace, about ' + words(end.worth) + ' (more owed than owned)') + ' by ' + when + ', or ' + words(real) + ' in today’s money.';
    if (endAlt) {
      var dlt = endAlt.worth - end.worth, what = [];
      if (num(scen.sip)) what.push(words(num(scen.sip)) + ' more a month in SIPs');
      if (scen.prepay && num(scen.prepay.amount) > 0) what.push('prepaying ' + words(num(scen.prepay.amount)) + (scen.prepay.loan ? ' on ' + scen.prepay.loan : ''));
      if (scen.purchase && num(scen.purchase.amount) > 0) {
        var onLoan = scen.purchase.loan && num(scen.purchase.loan.amount) > 0 ? Math.min(num(scen.purchase.loan.amount), num(scen.purchase.amount)) : 0;
        what.push('spending ' + words(num(scen.purchase.amount)) + ' in year ' + clamp(Math.round(num(scen.purchase.year) || 1), 1, years) + (onLoan ? ' (' + words(onLoan) + ' of it on a loan)' : ''));
      }
      if (num(scen.income)) what.push('income ' + (num(scen.income) > 0 ? 'up ' : 'down ') + Math.abs(num(scen.income)) + '%');
      out.scenarioLine = 'With ' + what.join(', ') + ': about ' + words(endAlt.worth) + ' by ' + when + ', ' + words(Math.abs(dlt)) + (dlt >= 0 ? ' more.' : ' less.');
    }
    out.notes.push(end.worth >= 0 ? 'Before tax and not adjusted for prices rising: ' + words(end.worth) + ' in ' + end.date.slice(0, 4) + ' buys about what ' + words(real) + ' does today.'
      : 'More owed than owned: owing ' + words(-end.worth) + ' in ' + end.date.slice(0, 4) + ' weighs about what owing ' + words(-real) + ' does today.');
    if (A.before != null || takeHome) out.notes.push('What’s left each month uses ' + (takeHome ? 'the take-home you gave, ' + inr(takeHome) + ', less what usually goes out, ' + inr(F.spendUsual) : 'your figure') + ': ' + inr(before) + ' a month before investing.');
    else if (F.blind) out.notes.push('kosh sees what you spend (about ' + inr(F.spendUsual) + ' a month) but not your salary: it isn’t in your mail, or it comes as a transfer kosh can’t name. So this keeps the bank where it is and only grows what you own. Put in your take-home below to see where you’re really heading.');
    else if (F.months && r0(F.beforeLo) === r0(F.beforeHi)) out.notes.push('What’s left each month before investing was ' + inr(F.beforeLo) + ' in ' + (F.months === 1 ? 'your last month' : 'each of your last ' + F.months + ' months') + '; this uses it.');
    else if (F.months) out.notes.push('What’s left each month before investing has ranged from ' + inr(F.beforeLo) + ' to ' + inr(F.beforeHi) + ' over your last ' + F.months + ' months; this uses ' + inr(before) + ', the middle.');
    else out.notes.push('kosh hasn’t seen a full month of income yet, so it adds nothing from the months ahead; change it below.');
    if (F.months && F.months < 3) out.notes.push('That’s from only ' + F.months + ' month' + (F.months === 1 ? '' : 's') + ': treat it as a rough guess.');
    if (start.loans.some(function (l) { return l.rateGuessed; })) out.notes.push('A loan without its rate is taken at a usual rate for its kind; add the rate in Wealth › Debts.');
    if (start.loans.some(function (l) { return !(l.emi > 0); })) out.notes.push('A loan without its EMI is left as it is.');
    start.loans.filter(function (l) { return l.emi > 0 && l.bal * l.rate / 1200 >= l.emi; }).slice(0, 2).forEach(function (l) {
      out.notes.push(l.name + '’s EMI (' + inr(l.emi) + ') doesn’t cover its interest (' + inr(l.bal * l.rate / 1200) + ' a month), so the loan grows each month: check its figures in Wealth › Debts.');
    });
    if (start.ret > 0) out.notes.push('EPF contributions taken from your salary before it lands aren’t added here, so retirement money grows faster than this.');
    if (base.dry) out.notes.push('At this pace the bank runs short by ' + mYear(base.dry) + (base.sold > 0.5 ? ': after that about ' + words(base.sold) + ' of savings and investments would be sold to cover the months, by ' + mYear(end.date) : '') + (base.broke ? '. By ' + mYear(base.broke) + ' nothing is left to sell; the line carries on as if you borrowed.' : '.'));
    out.notes.push('Returns are assumptions, not promises: markets fall in some years.');
    return out;
  }

  /* ------------------------------------------------------------ the words of a question */
  /* the kind of decision a question asks, and what it names: amounts, rates, years, a date, a loan or an FD */
  var MONTH_IX = { jan: 0, january: 0, feb: 1, february: 1, mar: 2, march: 2, apr: 3, april: 3, may: 4, jun: 5, june: 5, jul: 6, july: 6, aug: 7, august: 7, sep: 8, sept: 8, september: 8, oct: 9, october: 9, nov: 10, november: 10, dec: 11, december: 11 };
  function byDate(s, today) {
    var m = /\b(?:by|before|till|until|tak) (?:the end of |end of )?(jan|january|feb|february|mar|march|apr|april|may|jun|june|jul|july|aug|august|sep|sept|september|oct|october|nov|november|dec|december)(?: (\d{4}))?\b/.exec(s);
    if (m && isISO(today)) {
      var mi = MONTH_IX[m[1]], y = m[2] ? +m[2] : +today.slice(0, 4);
      if (!m[2] && mi < +today.slice(5, 7) - 1) y++;
      return y + '-' + pad(mi + 1) + '-' + pad(new Date(Date.UTC(y, mi + 1, 0)).getUTCDate());
    }
    var n = /\b(?:in|within|over the next|in the next|next) (\d+|a|one|two|three|six|twelve) (months?|years?|mahine|saal)\b/.exec(s);
    if (n && isISO(today)) {
      var k = /^\d+$/.test(n[1]) ? +n[1] : { a: 1, one: 1, two: 2, three: 3, six: 6, twelve: 12 }[n[1]];
      return addMonths(today, /^(?:year|saal)/.test(n[2]) ? k * 12 : k);
    }
    if (/\bnext year\b|\bagle saal\b/.test(s) && isISO(today)) return addMonths(today, 12);
    return '';
  }
  /* the words of a question, made plain: amounts as rupees (12 lakh, ₹12L, 1.5 crore, 50k, 5,00,000), "9.5 percent" as 9.5% */
  function plain(q) {
    var s = ' ' + lc(q).replace(/[’']/g, "'").replace(/(\d),(?=\d)/g, '$1').replace(/[?!,;:()"]/g, ' ').replace(/\s+/g, ' ').trim() + ' ';
    return s.replace(/(\d+(?:\.\d+)?)\s*(?:cr|crore|crores)\b/g, function (m, n) { return String(Math.round(+n * 1e7)); })
      .replace(/(\d+(?:\.\d+)?)\s*(?:l|lakh|lakhs|lac|lacs)\b/g, function (m, n) { return String(Math.round(+n * 1e5)); })
      .replace(/(\d+(?:\.\d+)?)\s*k\b/g, function (m, n) { return String(Math.round(+n * 1e3)); })
      .replace(/(\d+(?:\.\d+)?)\s*(?:percent|per cent|pc|pct|prcnt)\b/g, '$1%')
      .replace(/\b(?:rs\.?|inr|rupees?)\s*(?=\d)/g, '₹').replace(/₹\s+/g, '₹');
  }
  /* a question that looks something up (when, did, show, how much, kab, kitna…) rather than one to weigh; a choice word
     (should, or, ya, afford, karu, le sakta, cash…) makes it one to weigh again */
  var LOOKUP = /\b(?:when|did|show|list|kab|kitn[aei]|how much|how many|what is|what's|whats|what was|what were|what are|which|history|statement|broke|broken|closed|matured)\b/;
  var CHOICE = /\bshould\b|\bshall\b|\bor\b|\bya\b|\bvs\.?\b|\bversus\b|\bafford\b|\bkaru\b|\bkaroon\b|\bkarun\b|\blu\b|\bloon\b|\blun\b|\ble sakt[aei]\b|\ble lu\b|\bcash\b|\bbetter\b|\bworth it\b|\bgood idea\b|\bmakes? sense\b/;
  /* what a vehicle question is about when it's money already gone: the ledger's, not a decision */
  var SPENT = /\b(?:cost|costs|spent|spend|paid|service|servicing|insurance|renewal|petrol|diesel|fuel|repair|toll|parking|fastag|challan|wash|accessor(?:y|ies))\b/;
  var VEHICLE = /\b(?:car|bike|scooter|scooty|two-wheeler|two wheeler|motorcycle)\b/;
  function intentOf(q, today) {
    var s = plain(q);
    var lookup = LOOKUP.test(s) && !CHOICE.test(s);
    var kind = '';
    var amtSeen = /₹?\d{4,}/.test(s);
    var card = /\bcard\b|\bcredit card\b|\bcc\b/.test(s), loan = /\bloans?\b/.test(s);
    if (/\bemergency (?:fund|money|corpus|savings?|kitty|cushion)\b|\brainy day\b|\bemergency ke liye\b/.test(s)) kind = 'emergency';
    else if (lookup) return null;
    else if (card && /\bminimum\b|\bmin (?:due|amount|payment|pay)\b|\b(?:in )?full\b|\bpoora\b|\bpura\b|\bwhole (?:bill|amount)\b|\btotal (?:due|amount)\b/.test(s) && /\bpay\b|\bbhar\w*|\bshould\b|\bkaru\b|\bkaroon\b|\bor\b|\bya\b/.test(s)) kind = 'card';
    else if (/\bfds?\b|\bfixed deposits?\b/.test(s) && /\bbreak|\bclose|\bwithdraw|\bencash|\btod|\bliquidat|\bpremature|\bearly\b|\bborrow against\b|\bloan against\b|\boverdraft\b/.test(s)) kind = 'fd';
    else if (/\bpre-?pay|\bpart(?:-| )?pay(?:ment)?\b|\bforeclos|\bpay (?:off|down) (?:my |the |our )?(?:\w+ )?loan\b|\bclose (?:my |the |our )?(?:\w+ )?loan (?:early|off|now)\b/.test(s) || (loan && /\binvest/.test(s) && /\bor\b|\bya\b|\bvs\b|\bbetter\b|\bshould\b/.test(s))) kind = 'prepay';
    // a car or a bike: a choice to make, a wish to buy, or a price that isn't money already spent on one
    else if (VEHICLE.test(s) && (CHOICE.test(s) || /\bbuy\b|\bbuying\b|\bkharid\w*|\bkhareed\w*|\blena\b|\bleni\b|\bfinance\b|\bpurchase\b/.test(s) || (amtSeen && !SPENT.test(s)))) kind = 'car';
    else if (/\bafford\b|\bcan (?:i|we) (?:buy|spend|pay for|manage|go for)\b|\b(?:le|kharid|khareed) sakt[aei]\b|\bafford kar\b/.test(s) && amtSeen) kind = 'afford';
    if (!kind) return null;
    var args = {};
    // an EMI said ("EMI ₹19,700") is the loan's, not the sum in question
    var emiQ = /\bemi\s*(?:of|is|=)?\s*₹?(\d{3,})|₹?(\d{3,})\s*(?:a month |per month |monthly )?emi\b/.exec(s);
    if (emiQ) args.emi = +(emiQ[1] || emiQ[2]);
    // (a year after "in", "by" or a month is a date, not an amount; ₹2,000 is an amount)
    var amts = [], amRe = /(₹)?(\d{4,}(?:\.\d+)?)/g, am;
    while ((am = amRe.exec(s))) {
      var av = +am[2];
      if (!(av >= 1000) || av === args.emi) continue;
      if (!am[1] && av >= 1900 && av <= 2100 && /(?:\bin|\bby|\bof|\buntil|\btill|\bbefore|\bfrom|\bsince|\b(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*)\s*$/.test(s.slice(Math.max(0, am.index - 14), am.index))) continue;
      amts.push(av);
    }
    var pcts = [], re = /(\d+(?:\.\d+)?)\s*%/g, m;
    while ((m = re.exec(s))) pcts.push({ v: +m[1], at: m.index, before: s.slice(Math.max(0, m.index - 40), m.index) });
    var yrs = /(\d+(?:\.\d+)?)\s*(?:years?|yrs?|saal)\b/.exec(s), mos = /(\d+)\s*(?:months?|mahine)\b/.exec(s);
    if (kind === 'prepay') {
      var near = /(?:prepay|pre-pay|part pay(?:ment)?|pay|put|use|lagau|lagaun|daal\w*)\s+(?:of\s+|around\s+|about\s+)?₹?(\d{4,})/.exec(s);
      // what's still outstanding: "on ₹20 lakh", "₹20 lakh left", "my 20 lakh loan"
      var owe = /₹?(\d{4,})\s*(?:outstanding|left|baaki|pending|remaining)|(?:outstanding|loan of|on a|on my|on the|of|\bon)\s+₹?(\d{4,})|\bmy ₹?(\d{4,}) (?:\w+ )?loan\b/.exec(s);
      if (near) args.amount = +near[1];
      if (owe) args.principal = +(owe[1] || owe[2] || owe[3]);
      if (!near && amts.length >= 2) { var sorted = amts.slice().sort(function (x, y) { return y - x; }); args.principal = args.principal || sorted[0]; args.amount = sorted[sorted.length - 1]; }
      else if (!near && amts.length === 1 && !owe) args.amount = amts[0];
      if (args.amount && args.principal && args.amount === args.principal) delete args.principal;
      pcts.forEach(function (p) { if (/invest\w*(?: it)?(?: at| in)?\s*$|return\w*\s*(?:of|at)?\s*$|earn\w*\s*(?:at)?\s*$|grow\w*\s*(?:at)?\s*$|\bat\s*$/.test(p.before) && /invest|return|earn|grow|fund|equity|market|sip/.test(p.before)) args.ret = p.v; else if (args.rate === undefined) args.rate = p.v; });
      if (mos) args.months = +mos[1]; else if (yrs && /left|remaining|baaki|tenure/.test(s)) args.months = Math.round(+yrs[1] * 12);
      var which = /\b(home|house|housing|car|personal|education|gold)\s+loan\b/.exec(s);
      if (which) args.loan = which[1] === 'house' || which[1] === 'housing' ? 'home' : which[1];
    } else if (kind === 'car') {
      // a down payment, either way round: "down payment ₹3 lakh", "₹3 lakh down", "20% down"
      var dn = /(?:down ?payment|down|advance)\s*(?:of\s*)?₹?(\d{4,})|₹?(\d{4,})\s*(?:down ?payment|down|advance)\b/.exec(s);
      var dp = /(\d+(?:\.\d+)?)\s*%\s*(?:down|downpayment|down payment)/.exec(s);
      var dAmt = dn ? +(dn[1] || dn[2]) : 0;
      if (amts.length) args.amount = Math.max.apply(null, amts.filter(function (v) { return v !== dAmt; }).concat([0])) || undefined;
      if (dAmt) args.downAmt = dAmt;
      if (dp) args.down = +dp[1];
      pcts.forEach(function (p) { if (dp && p.v === +dp[1] && p.at === dp.index) return; if (/save|savings|fd|earn|invest/.test(p.before)) args.ret = p.v; else if (args.rate === undefined) args.rate = p.v; });
      if (yrs) args.years = +yrs[1]; else if (mos) args.years = Math.round(+mos[1] / 12 * 100) / 100;
      if (/\b(?:bike|scooter|scooty|two-wheeler|two wheeler|motorcycle)\b/.test(s)) args.vehicle = 'bike';
    } else if (kind === 'afford') {
      if (amts.length) args.amount = Math.max.apply(null, amts);
      var by = byDate(s, today);
      if (by) args.by = by;
    } else if (kind === 'fd') {
      // the FD's own amount ("FD of ₹3 lakh", "my 3 lakh FD"); what's needed ("for ₹1 lakh", "need 1 lakh", "2 lakh chahiye")
      var fdAmt = /(?:fds?|fixed deposits?)\s+(?:of|worth)\s+₹?(\d{4,})|₹?(\d{4,})\s*(?:ki |ka |ke |wali |wala )?(?:fds?|fixed deposits?)\b/.exec(s);
      var needFor = /\bfor\s+₹?(\d{4,})/.exec(s), needSay = /(?:need|want|require|chahiye)\D{0,12}₹?(\d{4,})|₹?(\d{4,})\s*(?:chahiye|for\b)/.exec(s);
      var fA = fdAmt ? +(fdAmt[1] || fdAmt[2]) : 0;
      var nV = needFor && +needFor[1] !== fA ? +needFor[1] : needSay && +(needSay[1] || needSay[2]) !== fA ? +(needSay[1] || needSay[2]) : 0;
      if (fA) args.fdAmount = fA;
      if (nV) args.amount = nV;
      else { var other = amts.filter(function (v) { return v !== fA; }); if (other.length) args.amount = other[0]; }
      if (pcts.length) args.fdRate = pcts[0].v;
      if (mos) args.months = +mos[1];
      var bk = /\b(hdfc|icici|sbi|axis|kotak|idfc|indusind|yes|au|bob|pnb|canara|federal|rbl|bajaj|shriram|post office)\b/.exec(s);
      if (bk) args.which = bk[1];
    } else if (kind === 'emergency') {
      if (mos) args.months = +mos[1];
    } else if (kind === 'card') {
      if (amts.length) args.amount = Math.max.apply(null, amts);
      var cb = /\b(hdfc|icici|sbi|axis|kotak|idfc|indusind|yes|amex|hsbc|rbl|onecard|scapia|federal|au|citi)\b/.exec(s);
      if (cb) args.card = cb[1];
    }
    return { kind: kind, args: args };
  }
  /* a short follow-up to a decision ("what if it earns 8%?", "and 5 lakh?", "with 25% down"): the same decision with
     that changed. A question about the ledger that happens to hold a number isn't one. After kosh asked for a loan's
     figures, a reply like "20 lakh at 8.5%" is the loan and its rate. */
  function followUp(q, prev) {
    if (!prev || !prev.kind) return null;
    var s = plain(q);
    if (s.trim().split(' ').length > 9) return null;
    if (/\bpayments?\b|\btransactions?\b|\bshow\b|\blist\b|\babove\b|\bover\b|\bunder\b|\bbelow\b|\bspen[dt]\b|\bspending\b|\bpaid\b|\bbought\b|\bwhere\b|\bwho\b/.test(s)) return null;
    // "with" carries on only with a down payment, a rate, a tenure or an EMI
    if (/\bwith\b/.test(s) && !/\bwith\s+(?:a |an |the )?(?:₹?\d[\d.]*\s*%|₹?\d+\s*(?:down|years?|months?|saal|mahine|emi)\b|down\b|emi\b)/.test(s)) return null;
    if (/\bdown\b/.test(s) && prev.kind !== 'car') return null;
    var need = prev.need || [];
    var em = /\bemi\s*(?:of|is|=)?\s*₹?(\d{3,})|₹?(\d{3,})\s*(?:a month |per month |monthly )?emi\b/.exec(s), emi = em ? +(em[1] || em[2]) : 0;
    var p = /(\d+(?:\.\d+)?)\s*%/.exec(s), y = /(\d+(?:\.\d+)?)\s*(?:years?|saal)\b/.exec(s), mo = /(\d+)\s*(?:months?|mahine)\b/.exec(s);
    var a = null, ar = /₹?(\d{4,})/g, x;
    while ((x = ar.exec(s))) if (+x[1] !== emi) { a = x; break; }
    if (!p && !a && !y && !mo && !emi) return null;
    var args = {};
    Object.keys(prev.args || {}).forEach(function (k) { args[k] = prev.args[k]; });
    if (p) {
      var v = +p[1];
      if (prev.kind === 'prepay') { if ((need.indexOf('rate') >= 0 || /\bloan|\brate|\binterest\b/.test(s)) && !/\breturn|\bearn|\binvest|\bgrow|\bsip\b/.test(s)) args.rate = v; else args.ret = v; }
      else if (prev.kind === 'car') { if (/\bsav|\bearn|\binvest|\bfd\b/.test(s)) args.ret = v; else if (/\bdown/.test(s)) args.down = v; else args.rate = v; }
      else if (prev.kind === 'fd') { if (/\bpenalt/.test(s)) args.penalty = v; else args.fdRate = v; }
      else if (prev.kind === 'card') args.monthly = v;
    }
    if (a) {
      if (prev.kind === 'prepay' && need.indexOf('principal') >= 0) args.principal = +a[1];
      else if (prev.kind === 'car' && /\bdown\b/.test(s)) { args.downAmt = +a[1]; delete args.down; }
      else { args.amount = +a[1]; delete args.example; }
    }
    if (emi) args.emi = emi;
    if (y && prev.kind === 'car') args.years = +y[1];
    if (mo && prev.kind === 'car' && !y) args.years = Math.round(+mo[1] / 12 * 100) / 100;
    if (mo && (prev.kind === 'fd' || prev.kind === 'emergency')) args.months = +mo[1];
    if (mo && prev.kind === 'prepay') args.months = +mo[1];
    // a follow-up's months, or years, stand in for the date it replaces
    if ((mo || y) && prev.kind === 'afford') { args.months = mo ? +mo[1] : Math.round(+y[1] * 12); delete args.by; }
    return { kind: prev.kind, args: args };
  }

  /* what a decision says, in a few lines, for the chat: the verdict and the figures that decide it */
  function summary(d) {
    if (!d) return '';
    var lines = [d.verdict];
    var picked = (d.key || []).map(function (n) { return d.steps.filter(function (s) { return s.n === n; })[0]; }).filter(Boolean);
    if (picked.length && !d.missing.length) lines.push(picked.map(function (s) { return '- ' + s.label + ': ' + s.value; }).join('\n'));
    return lines.join('\n\n');
  }
  /* the working as text, for the tool's answer (Claude cites figures from it) */
  function working(d) {
    if (!d) return '';
    var t = d.verdict + '\nThe working:\n' + d.steps.map(function (s) { return s.n + '. ' + s.label + ': ' + s.value + (s.how ? ' (' + s.how + ')' : ''); }).join('\n');
    if (d.assumptions.length) t += '\nAssumed: ' + d.assumptions.map(function (a) { return a.label + ' ' + (a.unit === '₹' ? inr(a.value) : trim2(a.value) + (a.unit === '%' ? '%' : ' ' + a.unit)); }).join('; ') + '.';
    if (d.changes.length) t += '\nWhat would change it: ' + d.changes.join(' ');
    if (d.note) t += '\n' + d.note;
    return t;
  }

  var api = {
    decide: decide, rerun: rerun, project: project, intentOf: intentOf, followUp: followUp, summary: summary, working: working,
    lib: { emiOf: emiOf, amortise: amortise, fvLump: fvLump, fvAnnuity: fvAnnuity, minimumOnly: minimumOnly, solve: solve, addMonths: addMonths, monthsUntil: monthsUntil, words: words },
    RATES: RATES,
    decideJSON: function (kind, args, ctx) { var d = null; try { d = decide(kind, JSON.parse(args || '{}'), JSON.parse(ctx || '{}')); } catch (e) { d = null; } return JSON.stringify(d); },
    decideRerunJSON: function (saved, ctx) { var d = null; try { d = rerun(JSON.parse(saved || '{}'), JSON.parse(ctx || '{}')); } catch (e) { d = null; } return JSON.stringify(d); },
    projectJSON: function (ctx, opts) { var p = null; try { p = project(JSON.parse(ctx || '{}'), JSON.parse(opts || '{}')); } catch (e) { p = null; } return JSON.stringify(p); },
  };
  if (E) { for (var k in api) if (Object.prototype.hasOwnProperty.call(api, k) && /JSON$/.test(k)) E[k] = api[k]; E.decideAPI = api; }
  return api;
})(typeof KoshEngine !== 'undefined' ? KoshEngine : require('./engine.js'));
if (typeof module !== 'undefined' && module.exports) module.exports = KoshDecide;
