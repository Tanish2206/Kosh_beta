import Foundation

// MARK: - The store: understanding you (Persona.swift; engine/21t-build-persona.js)
// Read-only lookups into the snapshot, and your word on a trip kosh drafted (renamed, joined to the next, split at a day:
// learnt for good, trips.js reads them on every build; "Not a trip" is dropTripDraft, as on Chapters).

extension Store {
    var persona: Persona? { snap.persona }
    /// the mails behind a line of evidence (a payment's id is its mail's, "#n" a part of it)
    func evidenceMails(_ e: Persona.Evidence) -> [String] {
        var out: [String] = []
        for id in e.ids ?? [] {
            let m: String = String(id.split(separator: "#").first ?? Substring(id))
            if !out.contains(m) { out.append(m) }
        }
        return out
    }
    func renameTrip(_ id: String, _ name: String) {
        guard let live else { return }
        live.learnTrip(name: name, for: id)
    }
    func joinTrips(_ a: String, _ b: String) {
        guard let live else { return }
        live.learnTrip(join: a, b)
    }
    func splitTrip(_ id: String, at day: String) {
        guard let live else { return }
        live.learnTrip(split: id, at: day)
    }
    /// your answer to "Is this a move?" (engine/21t prof.moveSaid): yes says it as a move from then on, no never again
    func sayMove(_ id: String, _ yes: Bool) {
        guard let live else { return }
        live.learnMove(id, yes ? "yes" : "no")
    }
}

extension LiveSession {
    static let tripNamesKey: String = "beta.tripNames"
    static let tripJoinKey: String = "beta.tripJoin"
    static let tripSplitKey: String = "beta.tripSplit"
    var tripNames: [String: String] { (ud.dictionary(forKey: Self.tripNamesKey) as? [String: String]) ?? [:] }
    var tripJoin: [String] { ud.stringArray(forKey: Self.tripJoinKey) ?? [] }
    var tripSplit: [String: String] { (ud.dictionary(forKey: Self.tripSplitKey) as? [String: String]) ?? [:] }
    static let moveSaidKey: String = "beta.moveSaid"
    var moveSaid: [String: String] { (ud.dictionary(forKey: Self.moveSaidKey) as? [String: String]) ?? [:] }

    func learnMove(_ id: String, _ said: String) {
        var m: [String: String] = moveSaid
        m[id] = said
        ud.set(m, forKey: Self.moveSaidKey)
        rebuildSoon(force: true)
    }

    func learnTrip(name: String, for id: String) {
        var m: [String: String] = tripNames
        let n: String = String(name.trimmingCharacters(in: .whitespacesAndNewlines).prefix(60))
        if n.isEmpty { m.removeValue(forKey: id) } else { m[id] = n }
        ud.set(m, forKey: Self.tripNamesKey)
        rebuildSoon(force: true)
    }
    func learnTrip(join a: String, _ b: String) {
        var list: [String] = tripJoin
        let pair: String = a + "|" + b
        if !list.contains(pair) { list.append(pair) }
        ud.set(list, forKey: Self.tripJoinKey)
        rebuildSoon(force: true)
    }
    func learnTrip(split id: String, at day: String) {
        var m: [String: String] = tripSplit
        m[id] = day
        ud.set(m, forKey: Self.tripSplitKey)
        rebuildSoon(force: true)
    }
    /// your word on homes and trips, for the engine's profile (engine/21s prof.homeOf, prof.homes; trips.js
    /// prof.tripNames, prof.tripJoin, prof.tripSplit)
    func learntPlaces(_ p: inout [String: Any]) {
        let ho: [String: String] = homeOf
        if !ho.isEmpty { p["homeOf"] = ho }
        let hn: [[String: String]] = homesNamed
        if !hn.isEmpty { p["homes"] = hn }
        let tn: [String: String] = tripNames
        if !tn.isEmpty { p["tripNames"] = tn }
        let tj: [String] = tripJoin
        if !tj.isEmpty { p["tripJoin"] = tj }
        let ts: [String: String] = tripSplit
        if !ts.isEmpty { p["tripSplit"] = ts }
        let ms: [String: String] = moveSaid
        if !ms.isEmpty { p["moveSaid"] = ms }
    }
}
