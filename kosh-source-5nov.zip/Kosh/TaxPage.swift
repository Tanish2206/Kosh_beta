import SwiftUI
import Charts

// MARK: - Property tax: what's due and what it's made of, how long is left, each property, over time, the table

enum TaxInk {
    static let year = Color(hex: "#3B5BFD")
    static let arrears = Color(hex: "#FF9F0A")
    static let interest = Color(hex: "#FF6B57")
    static let dev = Color(hex: "#B0895A")
    static let garbage = Color(hex: "#30B0C7")
    static let amber = Color(light: "#A35A00", dark: "#FFB04D")
    static let older = Color(light: "#C46A00", dark: "#FFA94D")
    static let brown = Color(light: "#6E5B45", dark: "#CDB89F")
    static let faint = Color(hex: "#8E8E96")
    static let lines: [Color] = [Color(hex: "#3B5BFD"), Color(hex: "#8E4EC6"), Color(hex: "#14A0B8"), Color(hex: "#FF9F0A"), Color(hex: "#34C759"), Color(hex: "#FF6482")]
    /// the name each kind goes by on the page
    static func word(_ kind: String, short: Bool = false) -> String {
        if kind == "Property tax" { return short ? "This year" : "This year’s tax" }
        return kind
    }
}

struct PropertyTaxView: View {
    @Environment(Store.self) private var store

    struct Part: Identifiable { let prop: String; let kind: String; let v: Double; var id: String { prop + kind } }
    static let kinds: [(String, Color)] = [("Property tax", TaxInk.year), ("Arrears", TaxInk.arrears), ("Interest", TaxInk.interest), ("Development", TaxInk.dev), ("Garbage", TaxInk.garbage)]
    static func color(_ kind: String) -> Color { kinds.first { $0.0 == kind }?.1 ?? Color.gray }

    static func parts(_ p: Prop) -> [(String, Double)] {
        let k: Double = paidSince(p) ? 0 : 1
        return [("Property tax", k * (p.tax.property > 0 ? p.tax.property : (p.taxDue ?? 0))), ("Arrears", k * p.older), ("Interest", k * (p.interest ?? 0)),
                ("Development", k * p.dev), ("Garbage", k * p.tax.san)]
    }
    static func due(_ p: Prop) -> Double {
        if paidSince(p) { return 0 }
        let sum = parts(p).reduce(0) { $0 + $1.1 }
        return max(p.tax.total, sum)
    }
    /// what the portal showed due is paid since it was read (a receipt in your mail, or you marked it): none of it is
    /// due now, until the portal is read again
    static func paidSince(_ p: Prop) -> Bool {
        guard let n = p.taxNow else { return false }
        return n.st == "paid" && n.src != "portal"
    }
    /// "FY 25–26" for a date
    static func fy(_ d: String) -> String {
        let y = Int(d.prefix(4)) ?? 0, m = Int(d.dropFirst(5).prefix(2)) ?? 1
        let start = m >= 4 ? y : y - 1
        return String(format: "FY %02d–%02d", start % 100, (start + 1) % 100)
    }
    /// plot area in square yards, where the portal gave one
    static func sqyd(_ p: Prop) -> Double? {
        guard let a = p.plotArea, let v = Double(a.split(separator: " ").first ?? ""), v > 0 else { return nil }
        if a.contains("sq m") { return v * 1.19599 }
        if a.contains("sq ft") { return v / 9 }
        return v
    }
    /// each kind of due, summed over the properties
    static func totals(_ props: [Prop]) -> [(String, Color, Double)] {
        var out: [(String, Color, Double)] = []
        for (i, k) in kinds.enumerated() {
            var v: Double = 0
            for p in props { v += parts(p)[i].1 }
            if v > 0 { out.append((k.0, k.1, v)) }
        }
        return out
    }
    /// "24.4k", "1.2L"; a dash for nothing
    static func k(_ v: Double) -> String { v > 0.5 ? String(Fmt.short(v).dropFirst()) : "—" }

    var payments: [Txn] {
        store.snap.tx.filter { $0.c == "Tax" && $0.s == "Property tax" && $0.k == "out" && $0.ex == nil }
    }

    var body: some View {
        let P: PropertyBook = store.propBook(store.who)
        let all: Double = P.props.reduce(0) { $0 + Self.due($1) }
        ScrollView {
            VStack(alignment: .leading, spacing: 26) {
                if P.props.isEmpty {
                    if store.live != nil {
                        BetaEmpty(sym: "building.columns.fill", title: "No properties yet",
                                  text: "Add a property and the state it’s in. kosh reads what’s due off the state’s portal: this year’s tax, arrears and interest.",
                                  add: "Add property") { store.betaSheet = .property(nil) }
                    }
                } else {
                    PlanStack(.propTax, spacing: 26) { id in
                        switch id {
                        case "hero": TaxHero(props: P.props, all: all)
                        case "tiles":
                            if all > 0 {
                                TaxTiles(props: P.props, all: all, payments: payments)
                            }
                        case "each":
                            VStack(alignment: .leading, spacing: 12) {
                                Text("Each property").font(.system(.title2, weight: .bold))
                                ForEach(P.props.sorted { Self.due($0) > Self.due($1) }) { p in TaxCard(p: p) }
                                LoosePays(title: "Not placed on a property", note: "Property tax kosh found that fits none of your properties, or two of them equally. Set each property’s city and yearly tax to place them.", rows: P.taxLoose ?? [])
                            }
                        case "trend": TaxTrend(props: P.props, payments: payments)
                        case "table":
                            if all > 0 && P.props.count > 1 {
                                VStack(alignment: .leading, spacing: 12) {
                                    Text("The table").font(.system(.title2, weight: .bold))
                                    TaxTable(props: P.props, all: all)
                                }
                            }
                        case "notes": TaxNotes(notes: notes(P.props, all: all))
                        default: EmptyView()
                        }
                    }
                }
            }
            .padding(.horizontal, 20)
            .padding(.top, 14)
            .padding(.bottom, 36)
        }
    }

    func notes(_ props: [Prop], all: Double) -> [SmartNote] {
        guard all > 0 else { return [] }
        var out: [SmartNote] = []
        let old: Double = props.reduce(0) { $0 + $1.older + ($1.interest ?? 0) }
        if old / all > 0.3 {
            out.append(SmartNote(id: "old", sym: "clock.arrow.circlepath", color: TaxInk.arrears,
                                 text: "\(Fmt.pct(old / all)) of what’s due is from earlier years: arrears and the interest on them. Paying only this year’s tax leaves that part where it is."))
        }
        if let top = props.max(by: { Self.due($0) < Self.due($1) }), props.count > 1, Self.due(top) / all > 0.4 {
            let share: Double = Self.due(top) / all
            let words: String = abs(share - 0.5) < 0.04 ? "half" : Fmt.pct(share)
            out.append(SmartNote(id: "top", sym: "building.2.fill", color: Color.kosh,
                                 text: "\(top.short) is \(words) of all the tax due, \(Fmt.rupees(Self.due(top)))."))
        }
        let clear = props.filter { Self.due($0) <= 0 && !($0.portalReadAt ?? "").isEmpty }
        if !clear.isEmpty {
            out.append(SmartNote(id: "clear", sym: "checkmark.seal.fill", color: Color(hex: "#34C759"),
                                 text: "Nothing is due on \(clear.map(\.short).prefix(3).joined(separator: ", "))."))
        }
        for p in props {
            let rent: Double = p.units.filter { $0.status == "let" }.reduce(0) { $0 + $1.rent } * 12
            let year: Double = Self.parts(p)[0].1
            if rent > 0 && year > 0 {
                let pct: Double = year / rent * 100
                let said: String = pct < 10 ? Fmt.trim(pct, 1) + "%" : Fmt.pct(year / rent)
                out.append(SmartNote(id: "rent" + p.pid, sym: "house.fill", color: Color(hex: "#34C759"),
                                     text: "This year’s tax on \(p.short) is \(said) of the \(Fmt.words(rent)) it earns in rent a year."))
            }
        }
        let rated = props.compactMap { p -> (Prop, Double)? in
            guard let a = Self.sqyd(p) else { return nil }
            let y = Self.parts(p)[0].1
            return y > 0 ? (p, y / a) : nil
        }.sorted { $0.1 < $1.1 }
        if rated.count >= 2, let lo = rated.first, let hi = rated.last, hi.1 > lo.1 * 1.5 {
            out.append(SmartNote(id: "rate", sym: "square.dashed", color: TaxInk.garbage,
                                 text: "A year’s tax works out to \(Fmt.rupees((hi.1 * 10).rounded() / 10)) a square yard on \(hi.0.short), against \(Fmt.rupees((lo.1 * 10).rounded() / 10)) on \(lo.0.short)."))
        }
        return out
    }
}

/// the total due, what it's made of, how long is left to pay it without a penalty
struct TaxHero: View {
    @Environment(Store.self) private var store
    let props: [Prop]
    let all: Double
    @State private var grown = false

    var body: some View {
        let totals: [(String, Color, Double)] = PropertyTaxView.totals(props)
        let till: String? = props.filter { PropertyTaxView.due($0) > 0 }.map(\.payableTill).filter { !$0.isEmpty }.min()
        let read: String? = props.compactMap(\.portalReadAt).filter { !$0.isEmpty }.max()
        let n: Int = props.count
        let line: String = (n == 1 ? "One property" : Words.cap(Words.number(n)) + " properties") + (read.map { " · read " + Day.fmt($0, "d MMM") } ?? "")
        VStack(alignment: .leading, spacing: 18) {
            HStack(alignment: .top, spacing: 12) {
                VStack(alignment: .leading, spacing: 2) {
                    Text(all > 0 ? "Property tax due" : "Property tax").font(.system(.footnote, weight: .semibold)).foregroundStyle(all > 0 ? TaxInk.amber : RentInk.goodHead)
                    Text(all > 0 ? Fmt.rupees(all) : "Nothing due")
                        .scaledFont(size: 40, weight: .bold, design: .rounded, relativeTo: .largeTitle).monospacedDigit()
                        .lineLimit(1).minimumScaleFactor(0.6)
                        .privacySensitive()
                    Text(line).font(.system(.footnote)).foregroundStyle(TaxInk.brown)
                }
                Spacer(minLength: 4)
                if all > 0, let till { DaysRing(till: till, today: store.snap.today) }
            }
            if all > 0 {
                GeometryReader { g in
                    let gaps: CGFloat = CGFloat(max(0, totals.count - 1)) * 3
                    HStack(spacing: 3) {
                        ForEach(totals, id: \.0) { t in
                            RoundedRectangle(cornerRadius: 6, style: .continuous).fill(t.1)
                                .frame(width: shareWidth(g.size.width - gaps, gaps: 0, gap: 0, part: t.2, of: all, least: 6, grown: grown))
                        }
                    }
                }
                .frame(height: 14)
                VStack(spacing: 10) {
                    ForEach(totals, id: \.0) { t in
                        HStack(spacing: 10) {
                            Circle().fill(t.1).frame(width: 9, height: 9)
                            Text(TaxInk.word(t.0)).font(.system(.subheadline))
                            Spacer(minLength: 6)
                            Text(Fmt.rupees(t.2)).font(.system(.subheadline, design: .rounded, weight: .semibold)).monospacedDigit().privacySensitive()
                            Text(Fmt.pct(t.2 / all)).font(.system(.caption, design: .rounded)).monospacedDigit().foregroundStyle(TaxInk.brown).frame(width: 38, alignment: .trailing)
                        }
                    }
                }
                if let till {
                    HStack(spacing: 8) {
                        Image(systemName: "calendar").font(.system(.footnote, weight: .semibold)).foregroundStyle(TaxInk.amber)
                        Text("Payable without a penalty till \(Text(Day.fmt(till, "d MMM yyyy")).fontWeight(.semibold).foregroundStyle(Color.primary))")
                            .font(.system(.footnote)).foregroundStyle(Color(light: "#4A3A26", dark: "#DCC7AA"))
                        Spacer(minLength: 0)
                    }
                    .padding(.vertical, 11).padding(.horizontal, 12)
                    .background(Color.lift(0.75), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                }
            }
        }
        .padding(20)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(
            LinearGradient(colors: all > 0 ? [Color(light: "#FFEFD9", dark: "#3A2A12"), Color(light: "#FFF7EC", dark: "#261E12"), Color(light: "#FFFDF9", dark: "#1B1814")] : [Color(light: "#E3F5EA", dark: "#16301F"), Color(light: "#F2FAF5", dark: "#142219"), Color(light: "#FBFDFB", dark: "#151917")],
                           startPoint: .topLeading, endPoint: .bottomTrailing),
            in: RoundedRectangle(cornerRadius: 28, style: .continuous)
        )
        .overlay(RoundedRectangle(cornerRadius: 28, style: .continuous).strokeBorder((all > 0 ? Color(light: "#C46A00", dark: "#FFA94D") : RentInk.goodHead).opacity(0.16), lineWidth: 0.5))
        .onAppear { withAnimation(Motion.reveal.delay(0.1)) { grown = true } }
    }
}

/// days left to pay without a penalty, as a ring that empties towards the day (coral once it's passed)
struct DaysRing: View {
    let till: String
    let today: String
    @State private var shown = false
    var body: some View {
        let left: Int = Day.between(today, till)
        // the year runs from 1 April: the ring is the share of the time from then to the day that's still left
        let y: Int = Int(till.prefix(4)) ?? 2026
        let m: Int = Int(till.dropFirst(5).prefix(2)) ?? 12
        let start: String = String(m >= 4 ? y : y - 1) + "-04-01"
        let span: Int = max(1, Day.between(start, till))
        let frac: CGFloat = left <= 0 ? 1 : CGFloat(min(1, Double(left) / Double(span)))
        let ink: Color = left < 0 ? RentInk.late : left <= 14 ? RentInk.late : TaxInk.arrears
        ZStack {
            Circle().stroke(ink.opacity(0.16), lineWidth: 7)
            Circle()
                .trim(from: 0, to: shown ? frac : 0)
                .stroke(ink, style: StrokeStyle(lineWidth: 7, lineCap: .round))
                .rotationEffect(.degrees(-90))
            VStack(spacing: 2) {
                Text(String(abs(left))).font(.system(size: 22, weight: .bold, design: .rounded)).monospacedDigit()
                Text(left < 0 ? "DAYS OVER" : left == 1 ? "DAY LEFT" : "DAYS LEFT").font(.system(size: 8.5, weight: .bold)).tracking(0.4).foregroundStyle(left < 0 ? RentInk.lateDeep : TaxInk.amber)
            }
        }
        .frame(width: 78, height: 78)
        .onAppear { withAnimation(Motion.reveal.delay(0.15)) { shown = true } }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(left < 0 ? "\(-left) days past the day" : "\(left) days left to pay without a penalty")
    }
}

/// four figures that say where it stands
struct TaxTiles: View {
    let props: [Prop]
    let all: Double
    let payments: [Txn]
    var body: some View {
        let old: Double = props.reduce(0) { $0 + $1.older }
        let interest: Double = props.reduce(0) { $0 + ($1.interest ?? 0) }
        let year: Double = props.reduce(0) { $0 + PropertyTaxView.parts($1)[0].1 }
        let fyNow: String = PropertyTaxView.fy(Day.parser.string(from: Date()))
        let paidNow: [Txn] = payments.filter { PropertyTaxView.fy($0.d) == fyNow }
        let paid: Double = paidNow.reduce(0) { $0 + $1.a }
        LazyVGrid(columns: [GridItem(.flexible(), spacing: 10), GridItem(.flexible(), spacing: 10)], spacing: 10) {
            TaxTile(sym: "clock.arrow.circlepath", ink: TaxInk.arrears, label: "Earlier years", value: Fmt.rupees(old + interest),
                    sub: "\(Fmt.pct((old + interest) / max(1, all))) of what’s due", tone: old + interest > 0 ? TaxInk.amber : nil)
            TaxTile(sym: "percent", ink: TaxInk.interest, label: "Interest", value: Fmt.rupees(interest),
                    sub: interest > 0 ? "on tax left unpaid" : "none charged")
            TaxTile(sym: "calendar", ink: TaxInk.year, label: "This year’s tax", value: Fmt.rupees(year), sub: "the year’s own demand")
            TaxTile(sym: "checkmark", ink: Color(hex: "#34C759"), label: "Paid in " + fyNow, value: paid > 0 ? Fmt.rupees(paid) : "Nothing yet",
                    sub: paid > 0 ? "\(paidNow.count) payment\(paidNow.count == 1 ? "" : "s") found" : "none found in your mail", money: paid > 0)
        }
    }
}

struct TaxTile: View {
    let sym: String
    let ink: Color
    let label: String
    let value: String
    var sub: String = ""
    var tone: Color? = nil
    var money: Bool = true
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Image(systemName: sym)
                .font(.system(size: 13, weight: .bold))
                .foregroundStyle(ink)
                .frame(width: 30, height: 30)
                .background(ink.opacity(0.15), in: Circle())
            VStack(alignment: .leading, spacing: 1) {
                Text(label).font(.system(.footnote)).foregroundStyle(.secondary).lineLimit(1)
                Text(value)
                    .font(.system(.title3, design: money ? Font.Design.rounded : Font.Design.default, weight: .bold)).monospacedDigit()
                    .foregroundStyle(tone ?? Color.primary)
                    .lineLimit(1).minimumScaleFactor(0.6)
                    .privacySensitive()
                if !sub.isEmpty { Text(sub).font(.system(.caption)).foregroundStyle(.secondary).lineLimit(2) }
            }
        }
        .padding(14)
        .frame(maxWidth: .infinity, minHeight: 128, alignment: .topLeading)
        .background(Color.surface, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
    }
}

/// one property: what's due on it and of what, anything to know, and its portal
struct TaxCard: View {
    @Environment(Store.self) private var store
    @Environment(\.openURL) private var openURL
    let p: Prop

    var body: some View {
        let due: Double = PropertyTaxView.due(p)
        let parts: [(String, Double)] = PropertyTaxView.parts(p).filter { $0.1 > 0 }
        VStack(alignment: .leading, spacing: 14) {
            HStack(spacing: 12) {
                thumb
                VStack(alignment: .leading, spacing: 2) {
                    Text(p.short).font(.system(.body, weight: .semibold)).lineLimit(2)
                    if !p.pid.isEmpty && !(p.pid.hasPrefix("P") && Int(p.pid.dropFirst()) != nil) {
                        Text("PID " + p.pid).font(.system(.caption, design: .monospaced)).foregroundStyle(.secondary).lineLimit(1)
                    }
                }
                Spacer(minLength: 8)
                VStack(alignment: .trailing, spacing: 1) {
                    // (nothing due is said only when it's known: paid this year, or the portal read showing nothing)
                    let known: Bool = p.taxNow?.st == "paid" || !(p.portalReadAt ?? "").isEmpty
                    let head: String = due > 0 ? Fmt.rupees(due) : (p.taxNow?.st == "paid" ? "Paid" : (known ? "Nothing due" : "No receipt"))
                    Text(head)
                        .font(.system(.title3, design: .rounded, weight: .bold)).monospacedDigit()
                        .foregroundStyle(due > 0 ? TaxInk.amber : (known ? RentInk.goodDeep : RentInk.grey)).privacySensitive()
                    if let r = p.portalReadAt, !r.isEmpty {
                        Text("read " + Day.fmt(r, "d MMM")).font(.system(.caption)).foregroundStyle(TaxInk.faint)
                    }
                }
            }
            if due > 0 {
                TaxBar(p: p, height: 10)
                LazyVGrid(columns: [GridItem(.flexible(), spacing: 16, alignment: .leading), GridItem(.flexible(), spacing: 16, alignment: .leading)], alignment: .leading, spacing: 8) {
                    ForEach(parts, id: \.0) { part in
                        HStack(spacing: 7) {
                            Circle().fill(PropertyTaxView.color(part.0)).frame(width: 7, height: 7)
                            Text(TaxInk.word(part.0, short: true)).foregroundStyle(.secondary).lineLimit(1)
                            Spacer(minLength: 2)
                            Text(Fmt.rupees(part.1)).fontWeight(.semibold).monospacedDigit().privacySensitive()
                        }
                        .font(.system(.footnote))
                    }
                }
            }
            // this financial year: paid (from the receipts in your mail, or the portal), part paid, due or no receipt
            // yet, the years before it, and the next day that matters
            TaxYearBlock(p: p)
            ForEach(p.flags, id: \.text) { f in
                HStack(alignment: .top, spacing: 10) {
                    Circle().fill(f.level == "crit" ? RentInk.late : (f.level == "info" ? TaxInk.faint : TaxInk.arrears)).frame(width: 7, height: 7).padding(.top, 6)
                    Text(f.text).font(.system(.footnote)).foregroundStyle(Color(light: "#4A4A52", dark: "#AEAEB5")).fixedSize(horizontal: false, vertical: true)
                    Spacer(minLength: 0)
                }
                .padding(.vertical, 11).padding(.horizontal, 12)
                .background(RentInk.paper, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            }
            HStack(spacing: 8) {
                if !p.payableTill.isEmpty && due > 0 {
                    Text("Payable till " + Day.fmt(p.payableTill, "d MMM yyyy")).font(.system(.footnote)).foregroundStyle(.secondary)
                } else if due <= 0, let r = p.portalReadAt, !r.isEmpty {
                    Text("Nothing due when last read").font(.system(.footnote)).foregroundStyle(.secondary)
                }
                Spacer(minLength: 0)
                if canOpen {
                    Button(action: open) {
                        HStack(spacing: 6) {
                            Text("Open the portal")
                            Image(systemName: "arrow.up.right").font(.system(.caption2, weight: .bold))
                        }
                        .font(.system(.footnote, weight: .semibold))
                        .padding(.horizontal, 14)
                        .frame(minHeight: 36)
                        .background(RentInk.paper, in: Capsule())
                    }
                    .buttonStyle(.press)
                    .foregroundStyle(Color.kosh)
                }
            }
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.surface, in: RoundedRectangle(cornerRadius: 26, style: .continuous))
    }

    /// kosh's own reader for the state's portal when it has one, else the portal's site
    var reader: String? {
        let st: String = p.state ?? ""
        // (the property's city with it: its own corporation's portal, where kosh knows one)
        return store.live != nil && !st.isEmpty && LiveSession.portal(for: st) != nil ? st + "|" + (p.city ?? "") : nil
    }
    var site: URL? {
        guard let s = p.portal, !s.isEmpty else { return nil }
        return URL(string: s.hasPrefix("http") ? s : "https://" + s)
    }
    var canOpen: Bool { reader != nil || site != nil }
    func open() {
        if let st = reader { store.betaSheet = .portal(st) } else if let u = site { openURL(u) }
    }

    @ViewBuilder var thumb: some View {
        if let name = p.photo, !name.isEmpty, let img = UIImage(contentsOfFile: LiveSession.photoFolder.appendingPathComponent(name).path) {
            Image(uiImage: img).resizable().scaledToFill()
                .frame(width: 56, height: 56)
                .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
        } else {
            BuildingArt(prop: p, width: 34)
                .frame(width: 56, height: 56)
                .background(RentInk.paper, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        }
    }
}

/// what was due each time the portal was read, and what was paid each year
struct TaxTrend: View {
    let props: [Prop]
    let payments: [Txn]
    struct Point: Identifiable { let prop: String; let d: Date; let v: Double; var id: String { prop + String(d.timeIntervalSince1970) } }
    struct Year: Identifiable { let fy: String; let v: Double; let now: Bool; var id: String { fy } }
    /// what VoiceOver says of the lines: each property's due when the portal was last read
    static func spoken(_ points: [Point], names: [String]) -> String {
        let each: [String] = names.map { n -> String in
            let last: Point? = points.filter { $0.prop == n }.max(by: { $0.d < $1.d })
            return n + " " + Fmt.rupees(last?.v ?? 0)
        }
        return "What was due when the portal was last read: " + each.joined(separator: ", ")
    }

    var body: some View {
        let points: [Point] = props.flatMap { p in (p.hist ?? []).map { Point(prop: p.short, d: Day.date($0.d), v: $0.total) } }
        let readings: Int = props.map { ($0.hist ?? []).count }.max() ?? 0
        let names: [String] = props.filter { ($0.hist ?? []).count > 0 }.map(\.short)
        let years: [Year] = Self.years(payments)
        if readings >= 2 || !payments.isEmpty || props.contains(where: { PropertyTaxView.due($0) > 0 }) {
            VStack(alignment: .leading, spacing: 12) {
                Text("Over time").font(.system(.title2, weight: .bold))
                if readings >= 2 {
                    VStack(alignment: .leading, spacing: 12) {
                        Text("What was due, each time the portal was read").font(.system(.subheadline, weight: .semibold))
                        Chart(points) { pt in
                            LineMark(x: .value("Read", pt.d), y: .value("Due", pt.v))
                                .foregroundStyle(by: .value("Property", pt.prop))
                                .interpolationMethod(.monotone)
                                .lineStyle(StrokeStyle(lineWidth: 2.5, lineCap: .round))
                            PointMark(x: .value("Read", pt.d), y: .value("Due", pt.v))
                                .foregroundStyle(by: .value("Property", pt.prop))
                                .symbolSize(26)
                        }
                        .chartForegroundStyleScale(domain: names, range: names.indices.map { TaxInk.lines[$0 % TaxInk.lines.count] })
                        .chartLegend(.hidden)
                        .chartYAxis { AxisMarks(position: .leading, values: .automatic(desiredCount: 3)) { v in AxisGridLine(); AxisValueLabel { if let d = v.as(Double.self) { Text(PropertyTaxView.k(d) == "—" ? "0" : PropertyTaxView.k(d)) } } } }
                        .chartXAxis { AxisMarks(values: .automatic(desiredCount: 4)) { _ in AxisValueLabel(format: .dateTime.day().month(.abbreviated)) } }
                        .frame(height: 170)
                        .accessibilityElement(children: .ignore)
                        .spokenFigures(Self.spoken(points, names: names), hidden: "What was due on " + names.joined(separator: ", ") + ", each time the portal was read")
                        .privacySensitive()
                        WrapRow(spacing: 14, lineSpacing: 6) {
                            ForEach(Array(names.enumerated()), id: \.offset) { i, n in
                                HStack(spacing: 5) {
                                    Capsule().fill(TaxInk.lines[i % TaxInk.lines.count]).frame(width: 12, height: 3)
                                    Text(n)
                                }
                            }
                        }
                        .font(.system(.caption))
                        .foregroundStyle(.secondary)
                    }
                    .padding(16)
                    .background(Color.surface, in: RoundedRectangle(cornerRadius: 26, style: .continuous))
                } else {
                    AgeBars(props: props)
                }
                if years.contains(where: { $0.v > 0 }) {
                    PaidYears(years: years)
                }
            }
        }
    }

    /// the last five financial years to now, with what was paid in each
    static func years(_ payments: [Txn]) -> [Year] {
        let now: String = PropertyTaxView.fy(Day.parser.string(from: Date()))
        let start: Int = (Int(now.dropFirst(3).prefix(2)) ?? 26) + 2000
        var out: [Year] = []
        for y in (start - 4)...start {
            let fy: String = String(format: "FY %02d–%02d", y % 100, (y + 1) % 100)
            let v: Double = payments.filter { PropertyTaxView.fy($0.d) == fy }.reduce(0) { $0 + $1.a }
            out.append(Year(fy: fy, v: v, now: fy == now))
        }
        // years before the first payment kosh found say nothing: leave them out
        while let f = out.first, f.v <= 0, !f.now, out.count > 1 { out.removeFirst() }
        return out
    }
}

/// tax paid in each financial year, as bars; this year waits, hatched, until it's paid
struct PaidYears: View {
    let years: [TaxTrend.Year]
    @State private var grown = false
    var body: some View {
        let top: Double = max(1, years.map(\.v).max() ?? 1)
        VStack(alignment: .leading, spacing: 12) {
            Text("Paid each year").font(.system(.subheadline, weight: .semibold))
            HStack(alignment: .bottom, spacing: 12) {
                ForEach(years) { y in
                    VStack(spacing: 5) {
                        Text(y.v > 0 ? PropertyTaxView.k(y.v) : (y.now ? "not yet" : "—"))
                            .font(.system(.caption2, design: .rounded, weight: .semibold)).monospacedDigit()
                            .foregroundStyle(y.v > 0 ? Color.secondary : (y.now ? TaxInk.amber : TaxInk.faint))
                            .lineLimit(1).minimumScaleFactor(0.7)
                        if y.v > 0 {
                            RoundedRectangle(cornerRadius: 8, style: .continuous)
                                .fill(LinearGradient(colors: [Color(hex: "#5FD98A"), Color(hex: "#34C759")], startPoint: .top, endPoint: .bottom))
                                .frame(height: max(8, 110 * CGFloat(y.v / top) * (grown ? 1 : 0.05)))
                        } else {
                            Hatch()
                                .stroke(Color.rule.opacity(0.1), lineWidth: 1.5)
                                .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
                                .overlay(RoundedRectangle(cornerRadius: 8, style: .continuous).strokeBorder(Color.rule.opacity(0.18), lineWidth: 1.5))
                                .frame(height: 22)
                        }
                    }
                    .frame(maxWidth: .infinity)
                }
            }
            .frame(height: 140, alignment: .bottom)
            .privacySensitive()
            HStack(spacing: 12) {
                ForEach(years) { y in
                    Text(String(y.fy.dropFirst(3)))
                        .font(.system(.caption2, weight: y.now ? Font.Weight.semibold : Font.Weight.regular))
                        .foregroundStyle(y.now ? Color.primary : TaxInk.faint)
                        .frame(maxWidth: .infinity)
                }
            }
            Text("Property tax payments kosh found in your mail and bank alerts.").font(.system(.caption)).foregroundStyle(.secondary)
        }
        .padding(16)
        .background(Color.surface, in: RoundedRectangle(cornerRadius: 26, style: .continuous))
        .onAppear { withAnimation(Motion.reveal.delay(0.1)) { grown = true } }
    }
}

/// diagonal lines, for a bar still to come
struct Hatch: Shape {
    func path(in r: CGRect) -> Path {
        var p = Path()
        var x: CGFloat = r.minX - r.height
        while x < r.maxX {
            p.move(to: CGPoint(x: x, y: r.maxY))
            p.addLine(to: CGPoint(x: x + r.height, y: r.minY))
            x += 6
        }
        return p
    }
}

/// until there's a history: how much of each property's dues is old (arrears and interest)
struct AgeBars: View {
    let props: [Prop]
    var body: some View {
        let rows: [Prop] = props.filter { PropertyTaxView.due($0) > 0 }.sorted { PropertyTaxView.due($0) > PropertyTaxView.due($1) }
        VStack(alignment: .leading, spacing: 14) {
            VStack(alignment: .leading, spacing: 3) {
                Text("How old the dues are").font(.system(.subheadline, weight: .semibold))
                Text("Amber is from earlier years. Each time the portal is read kosh keeps the figures, and a line of how they move appears here.")
                    .font(.system(.caption)).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            }
            if rows.isEmpty {
                Text("Nothing due on any property.").font(.subheadline).foregroundStyle(.secondary)
            }
            ForEach(rows) { p in
                let due: Double = PropertyTaxView.due(p)
                let old: Double = p.older + (p.interest ?? 0)
                VStack(alignment: .leading, spacing: 6) {
                    HStack {
                        Text(p.short).font(.subheadline.weight(.medium)).lineLimit(1)
                        Spacer()
                        Text(Fmt.pct(old / max(1, due)) + " old").font(.caption.weight(.semibold)).foregroundStyle(old > 0 ? TaxInk.amber : Color.secondary)
                    }
                    GeometryReader { g in
                        HStack(spacing: 2) {
                            Capsule().fill(TaxInk.arrears).frame(width: max(old > 0 ? 4 : 0, g.size.width * CGFloat(old / max(1, due))))
                            Capsule().fill(TaxInk.year.opacity(0.55))
                        }
                    }
                    .frame(height: 9)
                }
            }
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.surface, in: RoundedRectangle(cornerRadius: 26, style: .continuous))
    }
}

/// the figures in rows and columns
struct TaxTable: View {
    let props: [Prop]
    let all: Double
    var body: some View {
        let sorted: [Prop] = props.sorted { PropertyTaxView.due($0) > PropertyTaxView.due($1) }
        VStack(spacing: 0) {
            row(["Property", "This yr", "Older", "Other", "Due"], head: true)
                .padding(.vertical, 10)
            ForEach(sorted) { p in
                Rectangle().fill(Color.rule.opacity(0.14)).frame(height: 0.5)
                let x = PropertyTaxView.parts(p)
                let older: Double = x[1].1 + x[2].1
                HStack(spacing: 8) {
                    Text(p.short).font(.system(.footnote, weight: .medium)).lineLimit(1).frame(maxWidth: .infinity, alignment: .leading).layoutPriority(1.5)
                    cell(PropertyTaxView.k(x[0].1))
                    cell(PropertyTaxView.k(older), ink: older > 0 ? TaxInk.older : TaxInk.faint, bold: older > 0)
                    cell(PropertyTaxView.k(x[3].1 + x[4].1), ink: x[3].1 + x[4].1 > 0 ? Color.primary : TaxInk.faint)
                    cell(PropertyTaxView.k(PropertyTaxView.due(p)), bold: true, heavy: true)
                }
                .padding(.vertical, 11)
            }
            Rectangle().fill(Color.rule.opacity(0.22)).frame(height: 1)
            HStack(spacing: 8) {
                Text("Total").font(.system(.footnote, weight: .bold)).frame(maxWidth: .infinity, alignment: .leading).layoutPriority(1.5)
                cell(PropertyTaxView.k(sum(0)), bold: true, heavy: true)
                cell(PropertyTaxView.k(sum(1) + sum(2)), ink: TaxInk.older, bold: true, heavy: true)
                cell(PropertyTaxView.k(sum(3) + sum(4)), bold: true, heavy: true)
                cell(PropertyTaxView.k(all), bold: true, heavy: true)
            }
            .padding(.vertical, 12)
        }
        .privacySensitive()
        .padding(.vertical, 6)
        .padding(.horizontal, 16)
        .background(Color.surface, in: RoundedRectangle(cornerRadius: 26, style: .continuous))
    }
    func sum(_ i: Int) -> Double { props.reduce(0) { $0 + PropertyTaxView.parts($1)[i].1 } }
    func row(_ titles: [String], head: Bool) -> some View {
        HStack(spacing: 8) {
            ForEach(Array(titles.enumerated()), id: \.offset) { i, t in
                Text(t.uppercased())
                    .font(.system(.caption2, weight: .bold)).tracking(0.4)
                    .foregroundStyle(TaxInk.faint)
                    .lineLimit(1).minimumScaleFactor(0.8)
                    .frame(maxWidth: .infinity, alignment: i == 0 ? .leading : .trailing)
                    .layoutPriority(i == 0 ? 1.5 : 1)
            }
        }
    }
    func cell(_ s: String, ink: Color = Color.primary, bold: Bool = false, heavy: Bool = false) -> some View {
        Text(s)
            .font(.system(.footnote, design: .rounded, weight: heavy ? Font.Weight.bold : (bold ? Font.Weight.semibold : Font.Weight.regular))).monospacedDigit()
            .foregroundStyle(ink)
            .lineLimit(1).minimumScaleFactor(0.7)
            .frame(maxWidth: .infinity, alignment: .trailing)
    }
}

/// worth knowing: each note on its own soft colour
struct TaxNotes: View {
    let notes: [SmartNote]
    var body: some View {
        if !notes.isEmpty {
            VStack(alignment: .leading, spacing: 12) {
                Text("Worth knowing").font(.system(.title2, weight: .bold))
                ForEach(notes) { n in
                    HStack(alignment: .top, spacing: 12) {
                        Image(systemName: n.sym)
                            .font(.system(size: 13, weight: .bold))
                            .foregroundStyle(n.color)
                            .frame(width: 30, height: 30)
                            .background(n.color.opacity(0.18), in: Circle())
                        Text(n.text).font(.system(.footnote)).lineSpacing(2).foregroundStyle(Color(light: "#2C2C30", dark: "#E5E5EA")).fixedSize(horizontal: false, vertical: true)
                            .privacySensitive()
                        Spacer(minLength: 0)
                    }
                    .padding(14)
                    .background(n.color.opacity(0.09), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
                }
            }
        }
    }
}
