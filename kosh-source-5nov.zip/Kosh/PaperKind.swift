import Foundation

// MARK: - What an opened paper is read as
//
// Screen-free, so engine-test/paper-kind.js compiles it with swiftc off a Mac. A paper whose mail said what it is (a
// bank's statement, a fund house's CAS) is read as that. One added from Files whose name says nothing ("unknown") is
// what its own pages say it is (the engine's docKind, engine/09b-doc-class.js), when that is a kind whose lines or
// holdings kosh keeps: a bank or card statement, a holdings statement, a policy. Before (30 Oct), a bank or card
// statement added from Files as "Sep.pdf" was read, its lines found, and then dropped: applyDoc kept a statement's lines
// only when it had been asked for a statement, and said "Opened, but nothing kosh tracks was in it".
enum PaperKind {
    /// the kinds applyDoc keeps the figures of by the kind itself
    static let readable: Set<String> = ["stmt", "cardstmt", "cas", "policy"]

    static func readAs(asked: String, found: String?) -> String {
        guard asked.isEmpty || asked == "unknown", let found, readable.contains(found) else { return asked }
        return found
    }
}
