import SwiftUI

// MARK: - Find, rebuilt (3 Nov 2026)
//
// One scrolling page, not a List: the search field on top, one row of filters under it (each a menu, filled when on,
// with a Filters button that says how many are on), then:
//   · nothing typed: your recent searches, four shortcuts (to sort, big spends, refunds, this month), the payees you pay
//     most (a tap searches them) and this month by category;
//   · something typed: a summary card (what it adds up to, how often, the last six months as bars), the payees it found
//     (a tap narrows to one), then the payments by month under sticky headers, sorted as you pick; a long press on a
//     payment files it, counts it or not, or puts it in a chapter;
//   · nothing found: which filter to take off, and how many payments that gives.
// (Rebuilt off List: the List re-sorted its sections while a payment's sheet opened over it and the page fell over.)

enum FindSort: String, CaseIterable, Identifiable {
    case newest, oldest, largest
    var id: String { rawValue }
    var title: String {
        switch self {
        case .newest: return "Newest first"
        case .oldest: return "Oldest first"
        case .largest: return "Largest first"
        }
    }
}

/// a month of results: its key (yyyy-MM), the payments, what went out
struct FindMonth: Identifiable {
    let m: String
    let rows: [Txn]
    let out: Double
    var id: String { m }
}

/// a payee among the results: its name, how many, what went out
struct FindPayee: Identifiable {
    let name: String
    let n: Int
    let v: Double
    let sym: String
    let color: Color
    var id: String { name }
}

enum FindGroups {
    static func months(_ rows: [Txn], sort: FindSort) -> [FindMonth] {
        if sort == .largest {
            return [FindMonth(m: "largest", rows: rows.sorted { $0.a > $1.a }, out: rows.filter { $0.sp }.reduce(0) { $0 + $1.a })]
        }
        var order: [String] = []
        var by: [String: [Txn]] = [:]
        let sorted: [Txn] = sort == .oldest ? rows.reversed() : rows
        for t in sorted where t.wf == nil {
            let m: String = String(t.d.prefix(7))
            if by[m] == nil { order.append(m) }
            by[m, default: []].append(t)
        }
        return order.map { (m: String) -> FindMonth in
            let list: [Txn] = by[m] ?? []
            return FindMonth(m: m, rows: list, out: list.filter { $0.sp }.reduce(0) { $0 + $1.a })
        }
    }
    @MainActor static func payees(_ rows: [Txn], _ store: Store) -> [FindPayee] {
        var n: [String: Int] = [:]
        var v: [String: Double] = [:]
        var first: [String: Txn] = [:]
        for t in rows where t.partOf == nil {
            let k: String = t.m
            n[k, default: 0] += 1
            v[k, default: 0] += t.a
            if first[k] == nil { first[k] = t }
        }
        let keys: [String] = n.keys.sorted { (a: String, b: String) -> Bool in (v[a] ?? 0) != (v[b] ?? 0) ? (v[a] ?? 0) > (v[b] ?? 0) : a < b }
        return keys.prefix(8).map { (k: String) -> FindPayee in
            let t: Txn? = first[k]
            return FindPayee(name: k, n: n[k] ?? 0, v: v[k] ?? 0, sym: t.map { $0.u ? "questionmark" : $0.sym } ?? "circle", color: t.map { store.color(for: $0) } ?? Color.gray)
        }
    }
    /// the payees you pay most, the last 90 days, for whoever is shown
    @MainActor static func usual(_ store: Store) -> [FindPayee] {
        let from: String = Day.add(store.snap.today, -90)
        let rows: [Txn] = store.tx.filter { $0.k == "out" && $0.d >= from && store.who.owns($0.o) && !$0.u && $0.partOf == nil }
        var n: [String: Int] = [:]
        var v: [String: Double] = [:]
        var first: [String: Txn] = [:]
        for t in rows {
            n[t.m, default: 0] += 1
            v[t.m, default: 0] += t.a
            if first[t.m] == nil { first[t.m] = t }
        }
        let keys: [String] = n.keys.filter { (n[$0] ?? 0) >= 2 }.sorted { (a: String, b: String) -> Bool in (n[a] ?? 0) != (n[b] ?? 0) ? (n[a] ?? 0) > (n[b] ?? 0) : a < b }
        return keys.prefix(10).map { (k: String) -> FindPayee in
            let t: Txn? = first[k]
            return FindPayee(name: k, n: n[k] ?? 0, v: v[k] ?? 0, sym: t?.sym ?? "circle", color: t.map { store.color(for: $0) } ?? Color.gray)
        }
    }
}

struct LedgerFind: View {
    @Environment(Store.self) private var store
    @State private var q = FindQuery()
    @FocusState private var typing: Bool
    @State private var shown = 120
    @State private var sort: FindSort = .newest
    @State private var filtering = false
    @AppStorage("find.recent") private var recentRaw: String = ""

    var body: some View {
        let hits: [Txn] = q.run(store)
        let read: FindParse = q.understood(store)
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 0, pinnedViews: [.sectionHeaders]) {
                FindBarPlus(q: $q, read: read) { typing = false; filtering = true }
                    .padding(.top, 4)
                    .padding(.bottom, 14)
                if q.blank {
                    FindHome(q: $q, recent: Self.recent(recentRaw)) { w in forget(w) }
                } else if hits.isEmpty {
                    FindNothing(q: $q)
                } else {
                    results(hits, read: read)
                }
            }
            .padding(.bottom, 40)
        }
        .scrollDismissesKeyboard(.immediately)
        .background(Color(uiColor: .systemGroupedBackground))
        .searchable(text: $q.text, placement: .navigationBarDrawer(displayMode: .always), prompt: "Payee, category, month or ₹ amount")
        .searchFocused($typing)
        .onSubmit(of: .search) { remember(q.words) }
        .navigationTitle("Find")
        .toolbarTitleDisplayMode(.inline)
        .sheet(isPresented: $filtering) { FindSheet(q: $q) }
        .toolbar {
            if !q.blank {
                ToolbarItem(placement: .topBarTrailing) {
                    Menu {
                        Picker("Sort", selection: $sort) { ForEach(FindSort.allCases) { Text($0.title).tag($0) } }
                        if store.live != nil && !hits.isEmpty {
                            Section("Change all \(hits.count)") { RefileItems(rows: hits) }
                        }
                        Button("Clear search", role: .destructive) { remember(q.words); q = FindQuery() }
                    } label: {
                        Image(systemName: "ellipsis.circle")
                    }
                    .accessibilityLabel("Sort, change all, clear")
                }
            }
        }
        .sensoryFeedback(.selection, trigger: q.on)
        .onChange(of: q) { _, _ in shown = 120 }
        .onDisappear { remember(q.words) }
        .onAppear {
            if let p = store.findPreset { q = p; store.findPreset = nil } else { typing = true }
        }
    }

    @ViewBuilder
    func results(_ hits: [Txn], read: FindParse) -> some View {
        let page: [Txn] = Array(hits.prefix(shown))
        let months: [FindMonth] = FindGroups.months(page, sort: sort)
        let payees: [FindPayee] = FindGroups.payees(hits, store)
        FindSummary(q: q, hits: hits)
            .padding(.horizontal, 16)
            .padding(.bottom, 14)
        if payees.count > 1 {
            FindPayeeStrip(title: "Found at", payees: payees) { p in q.text = p.name }
                .padding(.bottom, 14)
        }
        ForEach(months) { (g: FindMonth) in
            Section {
                FindRowsCard(rows: g.rows, mark: read.words, showDay: true)
                    .padding(.horizontal, 16)
                    .padding(.bottom, 14)
            } header: {
                FindMonthHeader(m: g.m, n: g.rows.count, out: g.out, today: store.snap.today)
            }
        }
        if hits.count > shown {
            Button { shown += 120 } label: {
                Text("Show \(min(120, hits.count - shown)) more").font(.subheadline.weight(.semibold))
                    .frame(maxWidth: .infinity).frame(height: 46)
                    .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
            }
            .buttonStyle(.press)
            .padding(.horizontal, 16)
        }
    }

    static func recent(_ raw: String) -> [String] { raw.split(separator: "|").map(String.init).filter { !$0.isEmpty } }
    private func remember(_ w: String) {
        let word: String = w.replacingOccurrences(of: "|", with: " ").trimmingCharacters(in: .whitespaces)
        guard word.count >= 2 else { return }
        var list: [String] = Self.recent(recentRaw).filter { $0.lowercased() != word.lowercased() }
        list.insert(word, at: 0)
        recentRaw = list.prefix(8).joined(separator: "|")
    }
    private func forget(_ w: String) {
        if w.isEmpty { recentRaw = ""; return }
        recentRaw = Self.recent(recentRaw).filter { $0 != w }.joined(separator: "|")
    }

    static func byDay(_ rows: [Txn]) -> [DayGroup] {
        var order: [String] = []
        var by: [String: [Txn]] = [:]
        for t in rows {
            if by[t.d] == nil { order.append(t.d) }
            by[t.d, default: []].append(t)
        }
        return order.map { d in
            let items: [Txn] = by[d] ?? []
            return DayGroup(day: d, items: items.filter { $0.wf == nil }, total: items.filter { $0.sp }.reduce(0) { $0 + $1.a })
        }
    }
}

// MARK: the filter bar

/// Filters (with how many are on), then a chip a filter: Date, Category, Paid with, Amount, Type, Status; what your
/// typing was read as goes under it in one quiet line
struct FindBarPlus: View {
    @Environment(Store.self) private var store
    @Binding var q: FindQuery
    let read: FindParse
    let more: () -> Void
    var body: some View {
        let typed: [String] = read.chips.filter { $0.kind != "text" }.map(\.title)
        let tokens: [FindToken] = FindToken.of(q, store)
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 0) {
                    Button(action: more) {
                        HStack(spacing: 6) {
                            Image(systemName: "line.3.horizontal.decrease").font(.system(size: 13, weight: .bold))
                            Text("Filters").font(.system(.footnote, weight: .semibold))
                            if q.on > 0 {
                                Text(String(q.on)).font(.caption2.weight(.bold)).monospacedDigit()
                                    .foregroundStyle(Color.koshFill)
                                    .frame(minWidth: 18, minHeight: 18)
                                    .background(Color.onKosh, in: Circle())
                            }
                        }
                        .foregroundStyle(q.on > 0 ? Color.onKosh : Color.primary)
                        .padding(.horizontal, 13).frame(height: 36)
                        .background(q.on > 0 ? Color.koshFill : Color(uiColor: .secondarySystemGroupedBackground), in: Capsule())
                        .contentShape(Capsule())
                    }
                    .buttonStyle(.press)
                    .padding(.leading, 16)
                    // (the filters' own row scrolls under the Filters button, to the screen's edge)
                    FindFilterRow(q: $q, more: more).padding(.leading, -12)
            }
            if !tokens.isEmpty {
                ScrollView(.horizontal) {
                    HStack(spacing: 6) {
                        ForEach(tokens) { (t: FindToken) in
                            Button { withAnimation(Motion.base) { t.off(&q) } } label: {
                                FindOnChip(title: t.title, sym: t.sym, removable: true)
                            }
                            .buttonStyle(.press)
                        }
                        if tokens.count > 1 {
                            Button("Clear all") { withAnimation(Motion.base) { let w = q.text; q = FindQuery(); q.text = w } }
                                .font(.footnote.weight(.semibold))
                                .padding(.leading, 4)
                        }
                    }
                    .padding(.horizontal, 16)
                }
                .scrollIndicators(.hidden)
            }
            if !typed.isEmpty {
                Label("Showing " + typed.joined(separator: " · "), systemImage: "sparkles")
                    .font(.caption.weight(.medium))
                    .foregroundStyle(.secondary)
                    .padding(.horizontal, 20)
            }
        }
    }
}

// MARK: nothing typed

struct FindHome: View {
    @Environment(Store.self) private var store
    @Binding var q: FindQuery
    let recent: [String]
    let forget: (String) -> Void
    var body: some View {
        let d: (tiles: [FindCatTile], uncatN: Int, uncatMonth: Double, overN: Int) = FindStartData.make(store)
        let usual: [FindPayee] = FindGroups.usual(store)
        VStack(alignment: .leading, spacing: 22) {
            if !recent.isEmpty {
                VStack(alignment: .leading, spacing: 8) {
                    FindSectionTitle(title: "Recent", action: "Clear") { forget("") }
                    ScrollView(.horizontal) {
                        HStack(spacing: 8) {
                            ForEach(recent, id: \.self) { (w: String) in
                                Button { q.text = w } label: {
                                    Label(w, systemImage: "clock.arrow.circlepath")
                                        .font(.footnote.weight(.semibold)).foregroundStyle(Color.primary)
                                        .padding(.horizontal, 12).frame(height: 34)
                                        .background(Color(uiColor: .secondarySystemGroupedBackground), in: Capsule())
                                }
                                .buttonStyle(.press)
                                .contextMenu { Button("Remove", role: .destructive) { forget(w) } }
                            }
                        }
                        .padding(.horizontal, 16)
                    }
                    .scrollIndicators(.hidden)
                }
            }
            VStack(alignment: .leading, spacing: 8) {
                FindSectionTitle(title: "Shortcuts")
                FindShortcuts(q: $q, uncatN: d.uncatN, overN: d.overN).padding(.horizontal, 16)
            }
            if !usual.isEmpty {
                FindPayeeStrip(title: "You pay most", payees: usual, money: false) { p in q.text = p.name }
            }
            if !d.tiles.isEmpty || d.uncatN > 0 {
                VStack(alignment: .leading, spacing: 8) {
                    FindSectionTitle(title: Day.monthName(store.snap.cm) + " by category")
                    FindCatGrid(q: $q, tiles: d.tiles, uncatN: 0, uncatMonth: 0).padding(.horizontal, 16)
                }
            }
            Text("Type a payee, a UPI ID, a note or a card; a category (“food”); a month (“oct”); or an amount: 22,476 · 500-1000 · over 5k · under 1L.")
                .font(.footnote).foregroundStyle(.secondary)
                .padding(.horizontal, 20)
        }
    }
}

struct FindSectionTitle: View {
    let title: String
    var action: String? = nil
    var tap: (() -> Void)? = nil
    var body: some View {
        HStack {
            Text(title).font(.title3.weight(.bold))
            Spacer()
            if let action, let tap { Button(action, action: tap).font(.subheadline) }
        }
        .padding(.horizontal, 20)
    }
}

/// four big tiles: what needs sorting, big spends, refunds, this month
struct FindShortcuts: View {
    @Binding var q: FindQuery
    let uncatN: Int
    let overN: Int
    private let cols: [GridItem] = [GridItem(.flexible(), spacing: 10), GridItem(.flexible(), spacing: 10)]
    var body: some View {
        LazyVGrid(columns: cols, spacing: 10) {
            tile("To sort", uncatN > 0 ? String(uncatN) + " payments" : "All sorted", "questionmark.square.dashed", Color.orange) { q.uncat = true }
            tile("Big spends", overN > 0 ? String(overN) + " over ₹5,000" : "Over ₹5,000", "chart.bar.fill", Color.pink) { q.text = ">5000" }
            tile("Refunds", "Money back", "arrow.uturn.backward.circle.fill", Color.green) { q.refunds = true }
            tile("This month", "Everything so far", "calendar", Color.kosh) { q.span = .month }
        }
    }
    private func tile(_ title: String, _ sub: String, _ sym: String, _ tint: Color, _ act: @escaping () -> Void) -> some View {
        Button { withAnimation(Motion.base) { act() } } label: {
            HStack(spacing: 12) {
                Image(systemName: sym).font(.system(size: 17, weight: .semibold)).foregroundStyle(.white)
                    .frame(width: 38, height: 38)
                    .background(tint.gradient, in: RoundedRectangle(cornerRadius: 11, style: .continuous))
                VStack(alignment: .leading, spacing: 1) {
                    Text(title).font(.subheadline.weight(.semibold)).foregroundStyle(Color.primary)
                    Text(sub).font(.caption).foregroundStyle(.secondary).lineLimit(1).minimumScaleFactor(0.85)
                }
                Spacer(minLength: 0)
            }
            .padding(12)
            .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            .contentShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
        }
        .buttonStyle(.press)
    }
}

/// payees as round marks in a row: a tap searches one
struct FindPayeeStrip: View {
    let title: String
    let payees: [FindPayee]
    var money: Bool = true
    let tap: (FindPayee) -> Void
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            FindSectionTitle(title: title)
            ScrollView(.horizontal) {
                HStack(alignment: .top, spacing: 12) {
                    ForEach(payees) { (p: FindPayee) in
                        Button { withAnimation(Motion.base) { tap(p) } } label: {
                            VStack(spacing: 6) {
                                IconTile(symbol: p.sym, color: p.color, size: 48)
                                Text(p.name).font(.caption.weight(.semibold)).foregroundStyle(Color.primary).lineLimit(2).multilineTextAlignment(.center)
                                Text(money ? Fmt.short(p.v) : String(p.n) + "×").font(.caption2).foregroundStyle(.secondary).monospacedDigit().privacySensitive()
                            }
                            .frame(width: 76)
                        }
                        .buttonStyle(.press)
                    }
                }
                .padding(.horizontal, 16)
            }
            .scrollIndicators(.hidden)
        }
    }
}

// MARK: results

/// what the results add up to, how often and since when, and the last six months as bars
struct FindSummary: View {
    @Environment(Store.self) private var store
    let q: FindQuery
    let hits: [Txn]
    var body: some View {
        let spend: [Txn] = hits.filter { $0.sp }
        let main: [Txn] = spend.isEmpty ? hits.filter { $0.k == "in" } : spend
        let total: Double = main.reduce(0) { $0 + $1.a }
        let came: Double = spend.isEmpty ? 0 : hits.filter { $0.k == "in" && ($0.ex ?? "").isEmpty }.reduce(0) { $0 + $1.a }
        let label: String = spend.isEmpty ? (main.isEmpty ? "Found" : "Came in") : "Spent"
        let what: String = q.words.isEmpty ? "" : " on “" + q.words + "”"
        VStack(alignment: .leading, spacing: 10) {
            Text(label + what).font(.subheadline.weight(.medium)).foregroundStyle(.secondary).lineLimit(1)
            HStack(alignment: .firstTextBaseline, spacing: 8) {
                Text(main.isEmpty ? String(hits.count) : Fmt.rupees(total))
                    .font(.system(size: 36, weight: .bold, design: .rounded))
                    .contentTransition(.numericText(value: total))
                    .minimumScaleFactor(0.6).lineLimit(1)
                    .privacySensitive()
                if came > 0 {
                    Text("+" + Fmt.rupees(came) + " in").font(.subheadline.weight(.semibold)).foregroundStyle(Color.green).privacySensitive()
                }
            }
            Text(Self.often(main.isEmpty ? hits : main, today: store.snap.today))
                .font(.footnote).foregroundStyle(.secondary)
            FindBars(rows: main, today: store.snap.today)
                .frame(height: 64)
                .padding(.top, 2)
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
    }
    /// "14 payments since 3 Jan · about ₹2,100 a month · last 2 days ago"
    static func often(_ rows: [Txn], today: String) -> String {
        guard let first = rows.map(\.d).min(), let last = rows.map(\.d).max() else { return "" }
        let n: String = String(rows.count) + (rows.count == 1 ? " payment" : " payments")
        let months: Int = max(1, Day.between(first, today) / 30 + 1)
        let sum: Double = rows.reduce(0) { $0 + $1.a }
        var bits: [String] = [n + " since " + Day.fmt(first, first.prefix(4) == today.prefix(4) ? "d MMM" : "MMM yyyy")]
        if rows.count >= 3 { bits.append("about " + Fmt.rupees(Fmt.roundish(sum / Double(months))) + " a month") }
        bits.append("last " + Day.label(last, today: today).lowercased())
        return bits.joined(separator: " · ")
    }
}

/// the last six months of the results, a bar each (this month lit)
struct FindBars: View {
    let rows: [Txn]
    let today: String
    var body: some View {
        let cm: String = String(today.prefix(7))
        let ms: [String] = (0..<6).reversed().map { Day.addMonths(cm, -$0) }
        let vs: [Double] = ms.map { m in rows.filter { $0.d.hasPrefix(m) }.reduce(0) { $0 + $1.a } }
        let top: Double = max(1, vs.max() ?? 1)
        HStack(alignment: .bottom, spacing: 8) {
            ForEach(Array(ms.enumerated()), id: \.offset) { (i, m) in
                VStack(spacing: 4) {
                    Spacer(minLength: 0)
                    RoundedRectangle(cornerRadius: 5, style: .continuous)
                        .fill(m == cm ? Color.kosh.gradient : Color.kosh.opacity(0.35).gradient)
                        .frame(height: max(3, CGFloat(vs[i] / top) * 44))
                    Text(Day.monthShort(m)).font(.caption2).foregroundStyle(.secondary)
                }
                .frame(maxWidth: .infinity)
            }
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("The last six months")
    }
}

/// a month's sticky heading: the month, how many, what went out
struct FindMonthHeader: View {
    let m: String
    let n: Int
    let out: Double
    let today: String
    var body: some View {
        HStack(alignment: .firstTextBaseline) {
            Text(m == "largest" ? "Largest first" : Day.monthName(m) + (m.prefix(4) == today.prefix(4) ? "" : " " + String(m.prefix(4))))
                .font(.headline)
            Text(String(n)).font(.subheadline).foregroundStyle(.secondary).monospacedDigit()
            Spacer()
            if out > 0 { Text(Fmt.rupees(out)).font(.subheadline.weight(.semibold)).monospacedDigit().foregroundStyle(.secondary).privacySensitive() }
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 8)
        .frame(maxWidth: .infinity)
        .background(Color(uiColor: .systemGroupedBackground).opacity(0.96))
    }
}

/// a month's payments in one rounded card, hairlines between them
struct FindRowsCard: View {
    let rows: [Txn]
    let mark: [String]
    var showDay: Bool = true
    var body: some View {
        VStack(spacing: 0) {
            ForEach(Array(rows.enumerated()), id: \.element.id) { (i, t) in
                if i > 0 { Divider().padding(.leading, 64) }
                FindPayRow(t: t, mark: mark, showDay: showDay)
            }
        }
        .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
    }
}

/// a payment found: its row (the words you typed lit), "Set category" when it has none, and a long press for the rest
struct FindPayRow: View {
    @Environment(Store.self) private var store
    let t: Txn
    let mark: [String]
    let showDay: Bool
    var body: some View {
        let sortable: Bool = Store.needsSorting(t) && store.live != nil
        let when: String = showDay ? Day.fmt(t.d, "d MMM") : Day.time12(t.t)
        VStack(alignment: .leading, spacing: 6) {
            TxRow(t: t, when: when, mark: mark)
            if sortable { FindSetCategory(t: t) }
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 10)
        .contextMenu { FindRowMenu(t: t) }
    }
}

struct FindRowMenu: View {
    @Environment(Store.self) private var store
    let t: Txn
    var body: some View {
        let out: Bool = t.k == "out" || t.k == "prepaid" || t.dr == "out"
        let counted: Bool = t.ex == nil && (t.nc ?? "").isEmpty
        Button { store.openTx(t.id) } label: { Label("Open", systemImage: "doc.text.magnifyingglass") }
        if store.live != nil {
            Button { store.openTx(t.id, at: "cats") } label: { Label("Category", systemImage: "tag") }
            if t.refOf == nil && (out || t.k == "in") {
                Button { if out { store.swipeCount(t, !counted) } else { store.swipeCountIn(t, !counted) } } label: {
                    Label(counted ? "Don’t count" : "Count", systemImage: counted ? "eye.slash" : "eye")
                }
            }
            if out && t.partOf == nil {
                Button { store.openTx(t.id, at: "trip") } label: { Label("Chapter", systemImage: "book.pages") }
            }
        }
    }
}

// MARK: nothing found

struct FindNothing: View {
    @Environment(Store.self) private var store
    @Binding var q: FindQuery
    var body: some View {
        let drops: [FindDrop] = FindDrops.make(q, store)
        VStack(spacing: 16) {
            Image(systemName: "magnifyingglass").font(.system(size: 34, weight: .semibold)).foregroundStyle(.tertiary)
                .padding(.top, 30)
            Text("Nothing matches").font(.title3.weight(.bold))
            Text(drops.isEmpty ? (q.words.isEmpty ? "No payment has all of these." : "Nothing for “" + q.words + "”. Try part of the name, or a UPI ID.") : "No payment has all of these. Take one off:")
                .font(.subheadline).foregroundStyle(.secondary).multilineTextAlignment(.center)
                .padding(.horizontal, 30)
            if !drops.isEmpty {
                VStack(spacing: 0) {
                    ForEach(Array(drops.enumerated()), id: \.element.id) { (i, d) in
                        if i > 0 { Divider().padding(.leading, 48) }
                        Button { withAnimation(Motion.base) { q = d.q } } label: {
                            HStack {
                                Label("Take off " + d.title, systemImage: "minus.circle").foregroundStyle(Color.primary)
                                Spacer(minLength: 8)
                                Text(String(d.n) + (d.n == 1 ? " payment" : " payments")).foregroundStyle(.secondary).monospacedDigit()
                            }
                            .padding(.horizontal, 16).frame(minHeight: 50)
                        }
                        .buttonStyle(.press)
                    }
                }
                .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                .padding(.horizontal, 16)
            }
        }
        .frame(maxWidth: .infinity)
    }
}
