import Foundation

// MARK: - A locked zip or a locked workbook
//
// Some statements come as a password-protected zip (a consolidated statement, a contract-note bundle) or as an Excel
// workbook locked with a password. PDFKit opens a locked PDF; nothing in iOS opens these, so unlock.js does, in the
// engine, with the same passwords kosh works out for a PDF (the one you typed, the ones saved for the sender, the ones
// made from your details). What opens comes back as the files inside (a zip) or an ordinary .xlsx, and is read as any
// other paper is (DocUnlock for a PDF, DocTable for a spreadsheet). The slow steps run on the phone's own hashes
// (KoshNative.swift).

/// What unlock.js makes of a zip or a workbook, and the glue that reads what it opened.
enum DocLocked {
    struct Inner: Decodable, Sendable { var name: String; var b64: String }
    struct Answer: Decodable, Sendable {
        var state: String           // opened, plain, locked, unreadable
        var kind: String?
        var password: String?
        var files: [Inner]?
        var why: String?
    }

    static func isZip(_ file: String) -> Bool { file.lowercased().hasSuffix(".zip") }
    /// a compound file (an Excel workbook locked with a password is one; so is an old .xls), not a zip
    static func isCompound(_ data: Data) -> Bool {
        data.count > 512 && Array(data.prefix(8)) == [0xD0, 0xCF, 0x11, 0xE0, 0xA1, 0xB1, 0x1A, 0xE1]
    }

    /// unlock.js's answer for these bytes, each password tried in turn; nil when the engine couldn't answer. Never on
    /// the main thread: a workbook's lock takes a moment for each password
    static func ask(_ data: Data, file: String, _ passwords: [String]) -> Answer? {
        guard data.count <= 40_000_000,
              let out = try? Engine.shared.call("unlockJSON", [data.base64EncodedString(), file, JSONText.encode(passwords)]) else { return nil }
        return try? JSONText.decode(Answer.self, out)
    }

    /// the passwords to try without asking anyone: the one you typed now, then every one saved for this sender
    static func passwords(sender: String, typed: String?) -> [String] {
        var out: [String] = []
        if let t = typed, !t.isEmpty { out.append(t) }
        for p in SenderPasswords.every(sender) where !p.isEmpty && !out.contains(p) { out.append(p) }
        return out
    }

    /// the password that opened it, kept for the sender (as one you typed is for a PDF)
    static func keep(_ answer: Answer, sender: String) {
        guard !sender.isEmpty, let pw = answer.password, !pw.isEmpty, pw != SenderPasswords.get(sender) else { return }
        SenderPasswords.set(sender, pw)
    }

    /// Between the statements of one zip, in the text a zip opens to (LiveSession applyDoc reads each apart, then one
    /// reading of them all: docread.js mergeDocsJSON)
    static let fileSep = "\n\u{1D}\n"

    /// A zip: unlocked (or a plain one), then every statement inside read as itself (a PDF, often locked with the same
    /// password, so that is tried on it first; a workbook; a CSV), the ones unlock.js picks (zipReadsJSON: a statement
    /// sent twice once, never a leaflet or a readme, at most twelve), their texts joined by `fileSep`. A zip with any of
    /// its statements still locked says locked (never a part of it read as the whole); one with none kosh can read says so
    /// `also`: every other password worked out for the sender (Papers.swift tryProfiles hands its whole list), tried on
    /// a statement inside that is locked another way than the zip (PwTries.inner)
    static func openZip(_ data: Data, file: String, sender: String, typed: String?, also: [String] = []) async -> DocUnlock.Result {
        let pws: [String] = passwords(sender: sender, typed: typed)
        let got: Answer? = await Task.detached(priority: .utility) { DocLocked.ask(data, file: file, pws) }.value
        guard let a = got else { return .unreadable }
        if a.state == "locked" { return .locked }
        guard a.state == "opened" || a.state == "plain" else { return .unreadable }
        keep(a, sender: sender)
        let files: [Inner] = a.files ?? []
        let opener: String? = a.password
        // each statement inside: the password you typed first (it may be a PDF's own, when the zip opened with a saved
        // one), then the sender's saved ones, the zip's among them (keep, above). Handed only the zip's, a PDF locked
        // another way stayed locked however often you typed its password
        let first: String? = (typed?.isEmpty == false) ? typed : opener
        let tries: [String] = PwTries.inner(typed: typed, opener: opener, also: also)
        let allNames: [String] = files.map { $0.name }
        let picked: [String] = (try? JSONText.decode([String].self, try Engine.shared.call("zipReadsJSON", [JSONText.encode(allNames)]))) ?? allNames
        var texts: [String] = []
        var stillLocked: Bool = false
        for name in picked {
            guard let f = files.first(where: { $0.name == name }), let inner = Data(base64Encoded: f.b64) else { continue }
            var one: DocUnlock.Result = .unreadable
            if name.lowercased().hasSuffix(".pdf") {
                // (the first of the tries that opens it, when it is locked; else as it is)
                let pw: String? = tries.count > 1 ? DocUnlock.firstPassword(inner, tries, file: name) : nil
                one = await DocUnlock.open(inner, sender: sender, typed: pw ?? first)
            } else if DocRef.isSheet(name) {
                let pw: String? = tries.count > 1 && DocLocked.isCompound(inner) ? DocLocked.firstPassword(inner, file: name, tries) : nil
                one = await Task.detached(priority: .utility) { DocTable.open(inner, file: name, sender: sender, typed: pw ?? first) }.value
            }
            switch one {
            case .opened(let t): texts.append(t)
            case .locked: stillLocked = true
            case .unreadable: break
            }
        }
        // a statement inside still locked (its own password, not the one typed or saved): the zip says locked, so you are
        // asked for the rest, and nothing of it is read until all of it opens (the ones that opened keep their password,
        // so the next try opens them again). Read as opened, the zip was taken as read and the locked statement was never
        // asked for again: a part of the zip counted as the whole of it
        if stillLocked { return .locked }
        if texts.isEmpty { return .unreadable }
        return .opened(texts.joined(separator: fileSep))
    }

    /// A workbook Excel locked: the ordinary .xlsx inside (nil, and why not, when it doesn't open)
    static func openBook(_ data: Data, file: String, sender: String, typed: String?) -> (book: Data?, failed: DocUnlock.Result) {
        let pws: [String] = passwords(sender: sender, typed: typed)
        guard !pws.isEmpty else { return (nil, .locked) }
        guard let a = ask(data, file: file, pws) else { return (nil, .unreadable) }
        if a.state == "locked" { return (nil, .locked) }
        guard a.state == "opened", let f = a.files?.first, let book = Data(base64Encoded: f.b64) else { return (nil, .unreadable) }
        keep(a, sender: sender)
        return (book, .unreadable)
    }

    /// the first of these passwords that opens a zip or a workbook (as DocUnlock.firstPassword does a PDF), or nil
    static func firstPassword(_ data: Data, file: String, _ candidates: [String]) -> String? {
        guard let a = ask(data, file: file, candidates.filter { !$0.isEmpty }), a.state == "opened" else { return nil }
        return a.password
    }
}
