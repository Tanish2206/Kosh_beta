import SwiftUI

// MARK: - Wealth › Overview: the map of everything owned, and how concentrated it is (1 Nov, his pick, "HoldMap")
//
// The map: every thing owned as a block sized by what it's worth today, biggest first, coloured by its kind; Return
// colours each block by what it made a year instead (grey where kosh hasn't its dated money). The biggest things are
// blocks of their own, a kind's small ones one block ("4 more funds"); tap a block for its page (a deposit's journey, a
// bank account) or its kind's Holdings tab. Laid out by WealthBook.squarify, so it is tested off the screen. It takes
// the place of "Everything you own" (each thing ranked as a bar): the map says the same, by size, at a glance; Kind is
// "What it's in" above it; "Whose" moved into How concentrated; "Where it sits" (fund house, bank) is gone, its one
// question that matters (how much at one bank) answered there too.
//
// The mockup's "What moved it this month" is not drawn: to split the month's change into money put in, market moves,
// interest and losses kosh would need each holding's worth and flows at every month's end, and it keeps only each
// kind's total (snap.worth). A split it can't prove would be a guess.

struct WealthMapCard: View {
    @Environment(Store.self) private var store
    let p: Person
    @State private var by: String = "kind"

    var body: some View {
        let blocks: [WealthBlock] = WealthBook.blocks(store.wealthThings(p), noun: WealthKind.blockNoun)
        let total: Double = blocks.reduce(0) { $0 + $1.amt }
        let returns: Bool = blocks.contains { $0.ret != nil }
        let mode: String = returns ? by : "kind"
        if !blocks.isEmpty && total > 0 {
            VStack(alignment: .leading, spacing: 14) {
                ViewThatFits(in: .horizontal) {
                    HStack(alignment: .bottom) {
                        MapHead(total: total, today: store.snap.today)
                        Spacer(minLength: 8)
                        if returns { WealthPills(options: Self.modes, selection: $by, height: 32) }
                    }
                    VStack(alignment: .leading, spacing: 10) {
                        MapHead(total: total, today: store.snap.today)
                        if returns { WealthPills(options: Self.modes, selection: $by, height: 32) }
                    }
                }
                WealthTreemap(blocks: blocks, byReturn: mode == "return") { (ref: String) in store.openRef(ref) }
                    .frame(height: 312)
                Text(mode == "return" ? Self.returnFoot : Self.kindFoot)
                    .font(.caption).foregroundStyle(Obsidian.ink3)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
    }

    static let modes: [(id: String, label: String)] = [(id: "kind", label: "Kind"), (id: "return", label: "Return")]
    static let kindFoot: String = "Each block is sized by what it’s worth today. Tap one to open it."
    static let returnFoot: String = "Brighter for more made a year (XIRR, a deposit’s rate); red for a loss; grey where kosh hasn’t its dated money, or for a block of several."
}

struct MapHead: View {
    let total: Double
    let today: String
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text("Everything you own · " + Day.fmt(today, "d MMM")).caption()
            Text(Fmt.words(total))
                .font(.system(size: 34, weight: .bold)).tracking(-0.8).monospacedDigit()
                .foregroundStyle(Obsidian.ink)
                .lineLimit(1).minimumScaleFactor(0.6)
                .privacySensitive()
        }
    }
}

/// the blocks, laid out to fill the frame; they come in with the house stagger
struct WealthTreemap: View {
    let blocks: [WealthBlock]
    let byReturn: Bool
    let open: (String) -> Void
    @State private var on: Bool = false
    @Environment(\.accessibilityReduceMotion) private var still

    var body: some View {
        GeometryReader { geo in
            let boxes: [WealthBox] = WealthBook.squarify(blocks.map(\.amt), w: Double(geo.size.width), h: Double(geo.size.height))
            ZStack(alignment: .topLeading) {
                ForEach(blocks.indices, id: \.self) { (i: Int) in
                    tile(i, boxes)
                }
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
        .onAppear { on = true }
        .animation(still ? nil : Motion.base, value: byReturn)
    }

    func tile(_ i: Int, _ boxes: [WealthBox]) -> some View {
        let b: WealthBlock = blocks[i]
        let box: WealthBox = i < boxes.count ? boxes[i] : WealthBox(x: 0, y: 0, w: 0, h: 0)
        let tone: Color = byReturn ? MapTone.byReturn(b.ret, n: b.n) : WealthKind.color(b.kind)
        let w: CGFloat = max(0, CGFloat(box.w) - 3)
        let h: CGFloat = max(0, CGFloat(box.h) - 3)
        return WealthMapTile(b: b, tone: tone, w: w, h: h, big: i < 3) { open(b.ref) }
            .frame(width: w, height: h)
            .position(x: CGFloat(box.x + box.w / 2), y: CGFloat(box.y + box.h / 2))
            .opacity(on || still ? 1 : 0)
            .scaleEffect(on || still ? 1 : 0.97)
            .animation(still ? nil : Motion.open.delay(Motion.stagger(i)), value: on)
    }
}

/// a block's colour when it shows what it made: brighter mint for more a year, red for a loss, grey when unknown
enum MapTone {
    static func byReturn(_ r: Double?, n: Int) -> Color {
        guard n == 1, let r else { return Obsidian.ink3 }
        if r < 0 { return Color(hex: "#FF7A7A") }
        if r >= 12 { return Obsidian.health }
        if r >= 7 { return Color(hex: "#3FB98F") }
        return Color(hex: "#2E8068")
    }
}

struct WealthMapTile: View {
    let b: WealthBlock
    let tone: Color
    let w: CGFloat
    let h: CGFloat
    let big: Bool
    let action: () -> Void

    private var showName: Bool { w >= 58 && h >= 46 }
    private var showValue: Bool { w >= 40 && h >= 26 }
    private var nameLines: Int { h >= 70 ? 2 : 1 }
    private var valueSize: CGFloat { (big && w >= 110 && h >= 80) ? 20 : 13 }
    private var pad: CGFloat { w >= 58 ? 9 : 5 }
    private var label: String {
        let ret: String = b.ret.map { ", " + Fmt.trim($0, 1) + "% a year" } ?? ""
        return b.name + ", " + Fmt.words(b.amt) + ret
    }

    @ViewBuilder private var nameText: some View {
        if showName {
            Text(b.name).font(.system(size: 12, weight: .semibold)).foregroundStyle(Obsidian.ink).lineLimit(nameLines)
        }
    }

    @ViewBuilder private var valueText: some View {
        if showValue {
            Text(Fmt.words(b.amt))
                .font(.system(size: valueSize, weight: .bold))
                .monospacedDigit()
                .foregroundStyle(tone)
                .lineLimit(1)
                .minimumScaleFactor(0.6)
                .privacySensitive()
        }
    }

    private var face: some View {
        let shape: RoundedRectangle = RoundedRectangle(cornerRadius: 6, style: .continuous)
        let fill: Color = tone.opacity(0.15)
        let edge: Color = tone.opacity(0.35)
        let stack: VStack = VStack(alignment: .leading, spacing: 2) {
            nameText
            Spacer(minLength: 0)
            valueText
        }
        return stack
            .padding(pad)
            .frame(width: w, height: h, alignment: .topLeading)
            .background(shape.fill(fill))
            .overlay(shape.strokeBorder(edge, lineWidth: 1))
            .contentShape(Rectangle())
    }

    var body: some View {
        Button(action: action) { face }
            .buttonStyle(.press)
            .disabled(b.ref.isEmpty)
            .accessibilityElement(children: .ignore)
            .accessibilityLabel(label)
            .accessibilityAddTraits(.isButton)
    }
}

// MARK: how concentrated

/// the biggest three things' share of everything, the bank holding the most, equity against fixed income, and (for the
/// family) whose it is
struct WealthSpreadCard: View {
    @Environment(Store.self) private var store
    let p: Person

    var body: some View {
        let things: [WealthThing] = store.wealthThings(p)
        if let s = WealthBook.spread(things, banks: WealthBook.cover(store.wealthHeld(p).banks)) {
            VStack(alignment: .leading, spacing: 12) {
                Text("How concentrated").caption()
                VStack(alignment: .leading, spacing: 12) {
                    WealthSplitBar(parts: Self.strip(things), height: 14, gap: 2)
                        .clipShape(Capsule())
                    SpreadRow(title: s.top == 1 ? "Your one holding" : "Top \(s.top) holdings", value: Fmt.pct(s.topShare) + " of everything", strong: s.topShare >= 0.5)
                    if let bank = s.bank {
                        SpreadRow(title: "Largest single bank", value: bank + " · " + Fmt.pct(s.bankShare), strong: false)
                    }
                    if let e = s.equity, let f = s.fixed {
                        SpreadRow(title: "Equity vs fixed", value: "\(e) : \(f)", strong: false)
                    }
                    if let whose = Self.whose(store, p, things) {
                        SpreadRow(title: "Whose", value: whose, strong: false)
                    }
                    if s.equity != nil && s.neither >= 0.01 {
                        Text("Equity vs fixed leaves out gold, land, hybrid and insurance funds and NPS: " + Fmt.pct(s.neither) + " of everything.")
                            .font(.caption).foregroundStyle(Obsidian.ink3)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                }
                .obsidianCard(22, padding: 16)
            }
        }
    }

    /// the strip: the top three things in their kind's colour (each a little fainter), the rest grey
    static func strip(_ things: [WealthThing]) -> [(id: String, v: Double, color: Color)] {
        let all: [WealthThing] = things.filter { $0.amt > 0 }.sorted { $0.amt > $1.amt }
        var out: [(id: String, v: Double, color: Color)] = []
        for (i, t) in all.prefix(3).enumerated() {
            out.append((id: "t\(i)", v: t.amt, color: WealthKind.color(t.kind).opacity(1 - Double(i) * 0.2)))
        }
        let rest: Double = all.dropFirst(3).reduce(0) { $0 + $1.amt }
        if rest > 0 { out.append((id: "rest", v: rest, color: Color(hex: "#2A2A30"))) }
        return out
    }

    /// "You 62% · Mom 38%": the family's view only, two people or more
    static func whose(_ store: Store, _ p: Person, _ things: [WealthThing]) -> String? {
        guard p == .family && store.whoOptions.count > 2 else { return nil }
        let rows: [WealthRow] = WealthBook.rows(things, by: "whose", showWho: true, kindName: WealthKind.title, whoName: { (id: String) -> String in
            id == "family" ? "Joint" : WhoseSwitch.first(store.ownerName(id))
        })
        guard rows.count > 1 else { return nil }
        let total: Double = rows.reduce(0) { $0 + $1.amt }
        return rows.prefix(3).map { (r: WealthRow) -> String in r.name + " " + Fmt.pct(r.amt / max(total, 1)) }.joined(separator: " · ")
    }
}

struct SpreadRow: View {
    let title: String
    let value: String
    let strong: Bool
    var body: some View {
        ViewThatFits(in: .horizontal) {
            HStack(alignment: .firstTextBaseline) {
                Text(title).font(.subheadline).foregroundStyle(Obsidian.ink2)
                Spacer(minLength: 8)
                Text(value).font(.subheadline.weight(.bold)).foregroundStyle(strong ? Obsidian.savings : Obsidian.ink).privacySensitive()
            }
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(.subheadline).foregroundStyle(Obsidian.ink2)
                Text(value).font(.subheadline.weight(.bold)).foregroundStyle(strong ? Obsidian.savings : Obsidian.ink).privacySensitive()
            }
        }
        .accessibilityElement(children: .combine)
    }
}
