import SwiftUI

// MARK: - A stretch of time, for Accounts and Cards
//
// The last 30 days by default; any month the ledger holds, picked from a menu at the top right.

struct Span: Hashable {
    /// "30d", or a month as yyyy-MM
    let key: String
    static let last30 = Span(key: "30d")
    /// the saved choice, if the ledger still holds that month; else the last 30 days
    static func pick(_ key: String, months: [MonthInfo]) -> Span {
        months.contains(where: { $0.m == key }) ? Span(key: key) : .last30
    }
    var isMonth: Bool { key.count == 7 }
    /// the first and last day it covers
    func range(today: String) -> (String, String) {
        if isMonth { return (key + "-01", key + "-31") }
        return (Day.add(today, -29), today)
    }
    func has(_ d: String, today: String) -> Bool {
        let (a, b) = range(today: today)
        return d >= a && d <= b
    }
    func title(cm: String) -> String {
        if !isMonth { return "Last 30 days" }
        return key == cm ? "This month" : Day.fmt(key + "-01", key.prefix(4) == cm.prefix(4) ? "MMMM" : "MMM yyyy")
    }
    /// for the middle of a sentence
    func phrase(cm: String) -> String {
        if !isMonth { return "in the last 30 days" }
        return key == cm ? "so far this month" : "in " + Day.fmt(key + "-01", "MMMM")
    }
}

/// the stretch, as a menu: the last 30 days, then each month the ledger holds, newest first
struct SpanMenu: View {
    @Environment(Store.self) private var store
    @Binding var key: String
    var body: some View {
        let cm = store.snap.cm
        let months: [String] = store.snap.months.map(\.m).sorted(by: >)
        Menu {
            Picker("Show", selection: $key) {
                Text("Last 30 days").tag("30d")
                ForEach(months, id: \.self) { m in
                    Text(Span(key: m).title(cm: cm)).tag(m)
                }
            }
        } label: {
            HStack(spacing: 4) {
                Text(Span(key: key).title(cm: cm)).font(.subheadline.weight(.semibold))
                Image(systemName: "chevron.up.chevron.down").font(.caption2.weight(.bold))
            }
            .foregroundStyle(Color.kosh)
            .padding(.horizontal, 12).padding(.vertical, 7)
            .glassEffect(.regular.interactive(), in: .capsule)
        }
        .sensoryFeedback(.selection, trigger: key)
        .accessibilityLabel(Text(verbatim: "Period: " + Span(key: key).title(cm: cm)))
    }
}

// MARK: - The banks, as a strip to flick through

struct BankPick: Identifiable, Hashable {
    let id: String          // the bank's name as kosh files it
    let color: String
    let count: Int
    var hint: String = ""
    /// how many here wait on you (locked, not opened): an orange capsule on the chip when the strip shows badges
    var badge: Int = 0
    /// a symbol in place of the institution's mark (a shelf that is no institution: "Other")
    var sym: String = ""
    /// most first, then by name
    static func ordered(_ xs: [BankPick]) -> [BankPick] {
        xs.sorted { a, b in a.count != b.count ? a.count > b.count : a.id < b.id }
    }
}

/// "All", then each bank with its mark and how many it has here; one tap narrows the page to it
struct BankStrip: View {
    let banks: [BankPick]
    @Binding var pick: String
    /// every bank here has its own icon: show them; else each one's initials
    let logos: Bool
    var noun: String = ""
    /// each chip shows what waits on you (its badge) instead of how many it has (Settings › Statements and papers)
    var badges: Bool = false
    @Namespace private var glass
    static func spoken(_ label: String, _ count: Int, _ noun: String) -> String {
        guard count > 1 else { return label }
        let n: String = noun.isEmpty ? String(count) : String(count) + " " + noun
        return label + ", " + n
    }

    var body: some View {
        ScrollView(.horizontal) {
            GlassEffectContainer(spacing: 8) {
                HStack(spacing: 8) {
                    chip(id: "", label: "All", count: banks.reduce(0) { $0 + $1.count }, bank: nil, badge: banks.reduce(0) { $0 + $1.badge })
                    ForEach(banks) { b in chip(id: b.id, label: b.id, count: b.count, bank: b, badge: b.badge) }
                }
                .padding(.horizontal, 20)
                .padding(.vertical, 4)
            }
        }
        .scrollIndicators(.hidden)
        .scrollClipDisabled()
        .sensoryFeedback(.selection, trigger: pick)
    }

    func chip(id: String, label: String, count: Int, bank: BankPick?, badge: Int = 0) -> some View {
        let on: Bool = pick == id
        let lead: CGFloat = bank == nil ? 14 : 7
        let ink: Color = on ? Color.onKosh : Color.primary
        let glassID: String = id.isEmpty ? "all" : id
        let traits: AccessibilityTraits = on ? AccessibilityTraits.isSelected : AccessibilityTraits()
        return Button {
            withAnimation(Motion.large) { pick = id }
        } label: {
            HStack(spacing: 7) {
                if let bank, !bank.sym.isEmpty {
                    Image(systemName: bank.sym).font(.caption.weight(.semibold))
                        .frame(width: 20, height: 20)
                        .background(Color.primary.opacity(0.08), in: Circle())
                } else if let bank {
                    InstIcon(name: bank.id, color: Color(hex: bank.color), size: 20, hint: bank.hint, mark: !logos)
                }
                Text(label).font(.subheadline.weight(.semibold)).lineLimit(1)
                if badges {
                    // (a small count, only where something waits on you; it stays small at large text)
                    if badge > 0 {
                        Text(String(badge)).font(.caption2.weight(.bold)).monospacedDigit()
                            .dynamicTypeSize(...DynamicTypeSize.large)
                            .foregroundStyle(on ? Color.onKosh : Color.white)
                            .padding(.horizontal, 5).padding(.vertical, 1)
                            .background(on ? Color.onKosh.opacity(0.25) : Color.orange, in: Capsule())
                    }
                } else if count > 1 {
                    Text(String(count)).font(.caption.weight(.bold)).monospacedDigit().opacity(0.6)
                }
            }
            .foregroundStyle(ink)
            .padding(.leading, lead).padding(.trailing, 13).padding(.vertical, 7)
        }
        .buttonStyle(.plain)
        .glassEffect(on ? Glass.regular.tint(Color.koshFill).interactive() : Glass.regular.interactive(), in: .capsule)
        .glassEffectID(glassID, in: glass)
        // (with badges, a picked institution is in the spotlight: the rest step back a little)
        .scaleEffect(badges && !pick.isEmpty && !on ? 0.96 : 1)
        .opacity(badges && !pick.isEmpty && !on ? 0.6 : 1)
        .animation(Motion.base, value: pick)
        .accessibilityAddTraits(traits)
        .accessibilityLabel(badges ? (badge > 0 ? label + ", " + String(badge) + " waiting on you" : label) : Self.spoken(label, count, noun))
    }
}

// MARK: - How a payment was made

enum PayWay {
    static func symbol(_ md: String) -> String {
        switch md {
        case "card": return "creditcard.fill"
        case "upi": return "qrcode"
        case "transfer": return "building.columns.fill"
        case "auto": return "arrow.triangle.2.circlepath"
        case "atm": return "banknote.fill"
        case "cash": return "banknote.fill"
        case "wallet": return "wallet.bifold.fill"
        default: return "building.columns.fill"
        }
    }
    static func word(_ md: String) -> String {
        switch md {
        case "card": return "Card"
        case "upi": return "UPI"
        case "transfer": return "Bank transfer"
        case "auto": return "Auto-debit"
        case "atm": return "ATM"
        case "cash": return "Cash"
        case "wallet": return "Wallet"
        case "bank": return "Bank"
        default: return ""
        }
    }
    /// "UPI · HDFC ••1234", "Card · SBI Card ••5678", "Cash"; nil when nothing says
    static func line(_ t: Txn) -> String? {
        let md: String = t.md ?? ""
        if md == "cash" { return "Cash" }
        let bank: String = (t.bk ?? "").trimmingCharacters(in: .whitespaces)
        let l4: String = t.l4 ?? ""
        var acct: String = bank
        if !bank.isEmpty && !l4.isEmpty { acct = bank + " ••" + l4 }
        let w: String = word(md)
        // through an app (CRED, a gateway): the account first when it's known, the app after it, never as the account
        if let via = t.via, !via.isEmpty {
            if bank.caseInsensitiveCompare(via) == .orderedSame {
                let card: String = (t.pl4 ?? "").isEmpty ? "" : " · for ••" + (t.pl4 ?? "")
                return "via " + via + card
            }
            return (acct.isEmpty ? w : acct) + " · via " + via
        }
        if md == "wallet" {
            if acct.isEmpty { return "Wallet" }
            // "Zomato Money", "Amazon Pay Balance" say what they are; "MobiKwik" becomes "MobiKwik wallet"
            if acct.range(of: #"(?i)\b(money|cash|wallet|balance|credits?|coins|gift card)$"#, options: .regularExpression) != nil { return acct }
            return acct + " wallet"
        }
        if w.isEmpty {
            if !acct.isEmpty { return acct }
            if t.card.isEmpty { return nil }
            return t.card
        }
        if acct.isEmpty {
            if w == "Bank" { return nil }
            return w
        }
        return w + " · " + acct
    }
}

// MARK: - Pieces that wrap onto the next line, like tags

struct WrapRow: Layout {
    var spacing: CGFloat = 6
    var lineSpacing: CGFloat = 6
    func sizeThatFits(proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) -> CGSize {
        let width = proposal.width ?? .infinity
        var x: CGFloat = 0, y: CGFloat = 0, line: CGFloat = 0, widest: CGFloat = 0
        for v in subviews {
            let s = v.sizeThatFits(.unspecified)
            if x > 0 && x + s.width > width { y += line + lineSpacing; x = 0; line = 0 }
            x += s.width + spacing
            line = max(line, s.height)
            widest = max(widest, x - spacing)
        }
        return CGSize(width: min(widest, width), height: y + line)
    }
    func placeSubviews(in bounds: CGRect, proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) {
        var x = bounds.minX, y = bounds.minY, line: CGFloat = 0
        for v in subviews {
            let s = v.sizeThatFits(.unspecified)
            if x > bounds.minX && x + s.width > bounds.maxX { y += line + lineSpacing; x = bounds.minX; line = 0 }
            v.place(at: CGPoint(x: x, y: y), proposal: ProposedViewSize(s))
            x += s.width + spacing
            line = max(line, s.height)
        }
    }
}

// MARK: - A statement: read, or waiting on its password (with the bank's own rule for it)

struct StatementCard: View {
    @Environment(Store.self) private var store
    let s: StmtStatus
    var logos: Bool = false
    /// on one account's page: only that account's closing balance (a joint bank's statement names each member's)
    var only: String = ""
    @State private var pw = ""
    @State private var working = false
    @State private var failed = false
    @State private var showWords = false
    @FocusState private var typing: Bool

    var locked: Bool { s.state == "locked" }
    static func closes(_ s: StmtStatus, only: String) -> [StmtStatus.Close] {
        if only.isEmpty { return s.closes }
        return s.closes.filter { !$0.last4.isEmpty && ($0.last4.hasSuffix(only) || only.hasSuffix($0.last4)) }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 12) {
                InstIcon(name: s.inst, color: Color.gray, size: 36, plain: true, mark: !logos)
                VStack(alignment: .leading, spacing: 1) {
                    Text(Self.title(s)).font(.body.weight(.medium)).lineLimit(1)
                    Text(Self.sub(s, today: store.snap.today)).font(.footnote).foregroundStyle(.secondary).lineLimit(1)
                }
                Spacer(minLength: 8)
                badge
            }
            if locked { unlock }
            else if s.state == "read", !Self.closes(s, only: only).isEmpty {
                VStack(alignment: .leading, spacing: 4) {
                    ForEach(Self.closes(s, only: only), id: \.self) { c in
                        HStack {
                            Text(Self.closedLine(c))
                                .font(.subheadline).foregroundStyle(.secondary)
                            Spacer()
                            Text(Fmt.rupees(c.v)).font(.subheadline.weight(.semibold)).monospacedDigit().privacySensitive()
                        }
                    }
                }
                .padding(.leading, 48)
            }
        }
        .padding(14)
        .background(Color.surface, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        .animation(Motion.open, value: s.state)
    }

    @ViewBuilder var badge: some View {
        switch s.state {
        case "read":
            Image(systemName: "checkmark.circle.fill").font(.title3).foregroundStyle(Color.green).accessibilityLabel("Read")
        case "locked":
            Image(systemName: "lock.fill").font(.subheadline.weight(.semibold)).foregroundStyle(.white)
                .frame(width: 28, height: 28).background(Color.orange.gradient, in: Circle()).accessibilityLabel("Needs its password")
        case "empty":
            Image(systemName: "exclamationmark.circle").font(.title3).foregroundStyle(.secondary)
        default:
            ProgressView().controlSize(.small)
        }
    }

    @ViewBuilder var unlock: some View {
        let wordsTitle: String = showWords ? "Hide what the email says" : "What the email says"
        let wordsIcon: String = showWords ? "chevron.up" : "text.quote"
        let quoted: String = "“" + s.hint + "”"
        let isMade: String = s.name + "’s password is"
        let keptNote: String = "Used only on " + s.name + "’s statements and stored in this phone’s Keychain; the next ones open by themselves."
        VStack(alignment: .leading, spacing: 10) {
            if s.parts.isEmpty {
                Text(Self.noRule(s))
                    .font(.subheadline).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            } else {
                Text(isMade).font(.subheadline.weight(.semibold))
                WrapRow(spacing: 6, lineSpacing: 6) {
                    ForEach(Array(s.parts.enumerated()), id: \.offset) { i, p in
                        if i > 0 { Image(systemName: "plus").font(.caption.weight(.bold)).foregroundStyle(.tertiary).frame(height: 30) }
                        piece(p)
                    }
                }
                if let at = s.findAt, !at.isEmpty {
                    // (where-3nov) where to find the detail it needs
                    Label(at, systemImage: "lightbulb").font(.footnote).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                }
                if !s.example.isEmpty {
                    Text("Their example: \(Text(s.example).font(.subheadline.monospaced()).foregroundStyle(Color.primary))")
                        .font(.subheadline).foregroundStyle(.secondary)
                }
                if !s.hint.isEmpty {
                    Button { withAnimation(Fold.motion(opening: !showWords)) { showWords.toggle() } } label: {
                        Label(wordsTitle, systemImage: wordsIcon)
                            .font(.footnote.weight(.medium))
                    }
                    .buttonStyle(.press).foregroundStyle(Color.kosh)
                    Unfold(open: showWords) {
                        Text(quoted).font(.footnote).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                    }
                }
            }
            HStack(spacing: 8) {
                SecureField("Password", text: $pw)
                    .textContentType(.password)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .focused($typing)
                    .submitLabel(.go)
                    .onSubmit { open() }
                    .padding(.horizontal, 12).padding(.vertical, 10)
                    .background(Color.raised, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                Button { open() } label: {
                    Group { if working { ProgressView().tint(Color.onKosh) } else { Text("Open").fontWeight(.semibold) } }
                        .frame(minWidth: 56).padding(.vertical, 10).padding(.horizontal, 6)
                }
                .buttonStyle(.borderedProminent).koshFilled().buttonBorderShape(.roundedRectangle(radius: 12))
                .disabled(pw.isEmpty || working || store.live == nil)
            }
            if failed {
                Label("That didn’t open it. Check each part against the rule above.", systemImage: "xmark.circle.fill")
                    .font(.footnote).foregroundStyle(Color.red)
            } else {
                Text(keptNote)
                    .font(.caption).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            }
            // or let kosh make it: the details it's built from, and what this sender still needs
            Button { store.betaSheet = .passwords } label: {
                Label(PasswordProfile.anySaved ? "What this needs, and your saved details" : "Save your details: kosh opens these itself", systemImage: "person.text.rectangle")
                    .font(.footnote.weight(.medium))
            }
            .buttonStyle(.press).foregroundStyle(Color.kosh)
        }
        .padding(.leading, 48)
    }

    func piece(_ p: StmtStatus.Part) -> some View {
        HStack(spacing: 6) {
            Image(systemName: Self.symbol(p.k)).font(.caption.weight(.semibold)).foregroundStyle(Color.kosh)
            Text(p.label).font(.footnote.weight(.medium))
            if !p.note.isEmpty {
                Text(p.note).font(.caption2.weight(.bold).monospaced())
                    .padding(.horizontal, 5).padding(.vertical, 2)
                    .background(Color.kosh.opacity(0.12), in: RoundedRectangle(cornerRadius: 5, style: .continuous))
                    .foregroundStyle(Color.kosh)
            }
        }
        .padding(.horizontal, 10).padding(.vertical, 7)
        .background(Color.raised, in: Capsule())
    }

    func open() {
        guard !pw.isEmpty, !working, let live = store.live else { return }
        working = true; failed = false; typing = false
        let domain = s.domain.lowercased()
        let typed = pw
        Task { @MainActor in
            let n = await live.unlockSender(domain, password: typed)
            working = false
            if n > 0 { pw = "" } else { failed = true }
        }
    }

    static func symbol(_ k: String) -> String {
        switch k {
        case "name": return "person.text.rectangle"
        case "mobile": return "iphone"
        case "dob": return "calendar"
        case "card": return "creditcard"
        case "acct": return "building.columns"
        case "crn", "cid": return "number"
        case "pan": return "person.badge.key"
        case "pin": return "mappin.and.ellipse"
        default: return "key"
        }
    }
    static func noRule(_ s: StmtStatus) -> String {
        // (the sender's own line, quoted: where to find it, "Find your statement password under card controls on the app")
        if !s.hint.isEmpty { return s.name + "’s mail says: “" + s.hint + "”" }
        return s.name + "’s email didn’t say what the password is made of. Banks usually say it in the statement email or their app."
    }
    static func closedLine(_ c: StmtStatus.Close) -> String {
        let head: String = c.last4.isEmpty ? "Closed on" : "••" + c.last4 + " closed on"
        let day: String = c.d.count == 10 ? " " + Day.fmt(c.d, "d MMM") : ""
        return head + day
    }
    static func title(_ s: StmtStatus) -> String {
        s.name + (s.kind == "cardstmt" ? " card statement" : " statement")
    }
    static func sub(_ s: StmtStatus, today: String) -> String {
        switch s.state {
        case "read":
            let came: String = "Came " + Day.when(s.sent, today: today)
            return s.note.isEmpty ? came : came + " · " + s.note
        case "locked": return "Locked · came " + Day.when(s.sent, today: today)
        case "older": return "An older one"
        case "empty": return s.note.isEmpty ? "Not a readable PDF" : s.note
        default: return "Opening…"
        }
    }
}

// MARK: - Where a balance comes from

enum BalanceWords {
    /// "From today's balance alert", "Your 30 Sep statement + 4 payments since", "You typed it 3 Oct"
    static func source(_ a: Account, today: String) -> String {
        guard let b = a.bal else { return a.balance == nil ? "No balance yet" : "Latest" }
        let day = String(b.at.prefix(10))
        let when: String = dayWords(day, today: today)
        let base: String
        switch b.src {
        case "statement": base = "Statement, " + when
        case "typed": base = "You, " + Day.when(day, today: today)
        case "note": base = day == today ? "Bank’s balance mail, today" : "Bank’s balance mail, " + when
        default: base = day == today ? "Bank alert, today" : "Bank alert, " + when
        }
        if b.stale == true { return base }
        if let m = b.behind { return base + " · " + Day.fmt(m + "-01", "MMMM") + " statement not read" }
        // (livebal-4nov) a gap is never said
        return b.n > 0 ? base + " + " + String(b.n) + " since" : base
    }
    /// "12 Sep", or "20 May 2025" when it isn't this year
    static func dayWords(_ day: String, today: String) -> String {
        day.prefix(4) == today.prefix(4) ? Day.fmt(day, "d MMM") : Day.fmt(day, "d MMM yyyy")
    }
    /// how fresh: up to date (0), a few days or carried forward (1), old (2). A balance too old to carry forward is
    /// old; one whose payments don't add up is never up to date
    static func age(_ a: Account, today: String) -> Int {
        guard let b = a.bal else { return 2 }
        if b.stale == true { return 2 }
        let day = String(b.at.prefix(10))
        let days = Day.cal.dateComponents([.day], from: Day.date(day), to: Day.date(today)).day ?? 99
        var age: Int = days <= 2 ? 0 : days <= 40 ? 1 : 2
        if b.behind != nil { age = max(age, 1) }
        return age
    }
    /// how kosh knows the balance is right, in a line: every balance it was told adds up with the payments between
    /// them; or where it doesn't; or that there's nothing yet to check it against
    static func proof(_ a: Account, today: String) -> String? {
        guard let b = a.bal else { return nil }
        let checked: Int = b.ok ?? 0
        let gaps: Int = b.bad ?? 0
        if b.stale == true {
            return "From " + dayWords(String(b.at.prefix(10)), today: today) + ". kosh doesn’t carry an old balance forward: the payments since may not all be in your mail."
        }
        if let m = b.behind {
            let came: String = b.behindSent.map { " came " + dayWords($0, today: today) + "," } ?? ""
            return "Your " + Day.fmt(m + "-01", "MMMM") + " statement" + came + " but kosh couldn’t read its closing balance, so this is still from " + dayWords(String(b.at.prefix(10)), today: today) + ". It’s listed under Settings › Statements and papers › Couldn’t read."
        }
        switch b.check {
        case "ok":
            let pairs: String = checked == 1 ? "the balance before it" : String(checked) + " balances before it"
            return "Checked: it adds up with " + pairs + " and every payment between." // (livebal-4nov-b)
        case "gap":
            return nil
            if let g = a.gaps?.last {
                return "Doesn’t add up: " + Fmt.rupees(abs(g.amt)) + (g.amt < 0 ? " left" : " came in") + " between " + dayWords(String(g.from.prefix(10)), today: today) + " and " + dayWords(String(g.to.prefix(10)), today: today) + " with no payment kosh has. Shown as your bank said it."
            }
            return "Doesn’t add up with the payments kosh has. Shown as your bank said it."
        case "one": return "Nothing to check it against yet: the next balance your bank sends will."
        default: return nil
        }
    }
    static func color(_ age: Int) -> Color {
        if age == 0 { return Color.green }
        if age == 1 { return Color.orange }
        return Color(.tertiaryLabel)
    }
    /// the words beside the dot, in a deeper shade of it so they read
    static func ink(_ age: Int) -> Color {
        if age == 0 { return Color(light: "#1A7A43", dark: "#5FD38A") }
        if age == 1 { return Color(light: "#A35A00", dark: "#FFB04D") }
        return Color.secondary
    }
}

// MARK: - The look Accounts, Cards and Wallets share
//
// A lead card on a soft wash (blue for banks and cards, warm for wallets), 22pt titles outside the cards,
// small capitals over a group of rows, and grey cards of rows with hairlines between them.

enum HeroWash {
    case blue, warm
    var colors: [Color] {
        switch self {
        case .blue: return [Color(light: "#E4ECFF", dark: "#1B2547"), Color(light: "#F0F5FF", dark: "#161C33"), Color(light: "#FDFEFF", dark: "#15171F")]
        case .warm: return [Color(light: "#FFEBD9", dark: "#3A2614"), Color(light: "#FFF5EB", dark: "#261C13"), Color(light: "#FFFDFB", dark: "#1B1714")]
        }
    }
    var edge: Color { self == .blue ? Color(hex: "#3B5BFD").opacity(0.16) : Color(light: "#C46A00", dark: "#FFA94D").opacity(0.16) }
    /// the small line over the figure
    var ink: Color { self == .blue ? Color(light: "#2A44D6", dark: "#9DB0FF") : Color(light: "#A35000", dark: "#FFB04D") }
    /// the line under it
    var soft: Color { self == .blue ? Color(light: "#4A4F66", dark: "#B6BACB") : Color(light: "#5E4B3C", dark: "#CDB8A6") }
}

extension View {
    /// a page's lead card: padded, full width, on its wash, radius 28
    func heroWash(_ w: HeroWash) -> some View {
        self
            .padding(20)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(LinearGradient(colors: w.colors, startPoint: .topLeading, endPoint: .bottomTrailing),
                        in: RoundedRectangle(cornerRadius: 28, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 28, style: .continuous).strokeBorder(w.edge, lineWidth: 0.5))
    }
    /// a grey card of rows, radius 26
    func rowsCard() -> some View {
        self
            .padding(.horizontal, 16)
            .padding(.vertical, 4)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.surface, in: RoundedRectangle(cornerRadius: 26, style: .continuous))
    }
}

/// a page's lead card: what it adds up to on its wash, the stretch's menu top right, a line under the figure,
/// and whatever the page puts at its foot (a named split, a row of wallets)
struct MoneyHero<Foot: View>: View {
    let heading: String
    /// the figure; nil puts `empty` in its place
    let value: Double?
    var empty: String = ""
    let line: String
    let wash: HeroWash
    @Binding var spanKey: String
    @ViewBuilder let foot: Foot
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack(spacing: 10) {
                Text(heading).font(.system(.footnote, weight: .semibold)).foregroundStyle(wash.ink).lineLimit(1)
                Spacer(minLength: 8)
                SpanMenu(key: $spanKey)
            }
            if let v = value {
                Text(Fmt.rupees(v))
                    .scaledFont(size: 40, weight: .bold, design: .rounded, relativeTo: .largeTitle).monospacedDigit()
                    .lineLimit(1).minimumScaleFactor(0.6)
                    .contentTransition(.numericText(value: v))
                    .privacySensitive()
                    .padding(.top, 4)
            } else {
                Text(empty).font(.system(.title, design: .rounded, weight: .bold))
                    .foregroundStyle(wash.soft)
                    .lineLimit(1).minimumScaleFactor(0.7)
                    .padding(.top, 6)
            }
            if !line.isEmpty {
                Text(line).font(.system(.footnote)).foregroundStyle(wash.soft)
                    .fixedSize(horizontal: false, vertical: true)
                    .padding(.top, 4)
            }
            foot
        }
        .heroWash(wash)
    }
}

/// a section's title, outside its card: 22pt bold, with a quiet word on the right
struct AcctTitle: View {
    let title: String
    var detail: String = ""
    var body: some View {
        HStack(alignment: .firstTextBaseline, spacing: 8) {
            Text(title).font(.system(.title2, weight: .bold)).lineLimit(1).minimumScaleFactor(0.8)
                .accessibilityAddTraits(.isHeader)
            Spacer(minLength: 8)
            if !detail.isEmpty {
                Text(detail).font(.subheadline).foregroundStyle(.secondary).monospacedDigit().lineLimit(1)
            }
        }
    }
}

/// small capitals over a group of rows: "YOURS · ₹3.6L"
struct GroupLabel: View {
    let title: String
    var figure: String = ""
    /// the figure is money: hidden when the screen is
    var money: Bool = true
    var body: some View {
        HStack(spacing: 0) {
            Text(title.uppercased())
            if !figure.isEmpty {
                Text(" · ")
                if money { Text(figure).monospacedDigit().privacySensitive() } else { Text(figure).monospacedDigit() }
            }
        }
        .font(.system(.footnote, weight: .semibold))
        .tracking(0.5)
        .foregroundStyle(.secondary)
        .lineLimit(1)
        .padding(.horizontal, 4)
        .accessibilityElement(children: .combine)
        .accessibilityAddTraits(.isHeader)
    }
}

/// the hairline between two rows in a card
struct RowRule: View {
    var inset: CGFloat = 50
    var body: some View {
        Rectangle().fill(Color.rule.opacity(0.13)).frame(height: 0.5).padding(.leading, inset)
    }
}

/// one share in a split bar, named
struct LegendPart: Identifiable {
    let id: String
    let name: String
    let color: Color
    let v: Double
}

/// a whole as one bar of shares, each one named underneath with its dot and figure, so two banks of
/// nearly the same blue still tell apart
struct HeroLegend: View {
    let parts: [LegendPart]
    let grown: Bool
    var ink: Color = HeroWash.blue.soft
    var body: some View {
        let total: Double = parts.reduce(0) { $0 + $1.v }
        let shares: [(Color, Double)] = parts.map { ($0.color, $0.v / max(total, 1)) }
        let spoken: String = parts.map { $0.name + " " + Fmt.short($0.v) }.joined(separator: ", ")
        let plain: String = parts.map(\.name).joined(separator: ", ")
        VStack(alignment: .leading, spacing: 10) {
            SplitBar(parts: shares, grown: grown, height: 10)
            WrapRow(spacing: 14, lineSpacing: 6) {
                ForEach(parts) { p in
                    HStack(spacing: 5) {
                        Circle().fill(p.color).frame(width: 8, height: 8)
                        Text(p.name).fontWeight(.semibold).oneLineUnlessLarge()
                        Text(Fmt.short(p.v)).foregroundStyle(ink).monospacedDigit().privacySensitive()
                    }
                    .font(.system(.caption))
                }
            }
        }
        .accessibilityElement(children: .ignore)
        // (with amounts hidden, VoiceOver names the banks and not what each holds)
        .spokenFigures(spoken, hidden: plain)
    }
}

/// a card in miniature: its colour, its chip
struct MiniCard: View {
    let hex: String
    var width: CGFloat = 32
    var dim: Bool = false
    var body: some View {
        let col: Color = Color(hex: hex)
        let h: CGFloat = (width * 0.66).rounded()
        let r: CGFloat = width * 0.16
        RoundedRectangle(cornerRadius: r, style: .continuous)
            .fill(LinearGradient(colors: [col.mix(with: .white, by: 0.06), col.mix(with: .black, by: 0.4)], startPoint: .topLeading, endPoint: .bottomTrailing))
            .frame(width: width, height: h)
            .overlay(alignment: .topLeading) {
                RoundedRectangle(cornerRadius: 1.5, style: .continuous)
                    .fill(LinearGradient(colors: [Color(hex: "#F4DC97"), Color(hex: "#C9A24A")], startPoint: .topLeading, endPoint: .bottomTrailing))
                    .frame(width: width * 0.22, height: h * 0.24)
                    .offset(x: width * 0.125, y: h * 0.29)
            }
            .overlay(RoundedRectangle(cornerRadius: r, style: .continuous).strokeBorder(Color.white.opacity(0.25), lineWidth: 0.5))
            .shadow(color: .black.opacity(0.12), radius: 1, y: 1)
            .opacity(dim ? 0.55 : 1)
            .accessibilityHidden(true)
    }
}

// MARK: - Colours that tell apart, and ink that reads on them

enum Swatch {
    static func rgb(_ hex: String) -> (Double, Double, Double) {
        var s = hex.trimmingCharacters(in: .whitespaces)
        if s.hasPrefix("#") { s.removeFirst() }
        var v: UInt64 = 0
        Scanner(string: s).scanHexInt64(&v)
        return (Double((v >> 16) & 0xFF) / 255, Double((v >> 8) & 0xFF) / 255, Double(v & 0xFF) / 255)
    }
    static func gap(_ a: (Double, Double, Double), _ b: (Double, Double, Double)) -> Double {
        let r: Double = a.0 - b.0
        let g: Double = a.1 - b.1
        let bl: Double = a.2 - b.2
        return ((r * r + g * g + bl * bl) / 3).squareRoot()
    }
    /// each colour as it is, unless it sits too close to one already used: then a step lighter, and another,
    /// so a bar of three navy banks still reads as three
    static func distinct(_ hexes: [String]) -> [Color] {
        var used: [(Double, Double, Double)] = []
        var out: [Color] = []
        for h in hexes {
            let base: (Double, Double, Double) = rgb(h)
            var c: (Double, Double, Double) = base
            var step: Int = 0
            while step < 4 && used.contains(where: { gap($0, c) < 0.09 }) {
                step += 1
                let f: Double = Double(step) * 0.24
                c = (base.0 + (1 - base.0) * f, base.1 + (1 - base.1) * f, base.2 + (1 - base.2) * f)
            }
            used.append(c)
            out.append(Color(red: c.0, green: c.1, blue: c.2))
        }
        return out
    }
    /// how light a colour is to the eye (0 black, 1 white)
    static func luminance(_ hex: String) -> Double {
        let c: (Double, Double, Double) = rgb(hex)
        func lin(_ x: Double) -> Double { x <= 0.04045 ? x / 12.92 : pow((x + 0.055) / 1.055, 2.4) }
        return 0.2126 * lin(c.0) + 0.7152 * lin(c.1) + 0.0722 * lin(c.2)
    }
    /// white on a dark colour; on a light one (Swiggy's orange, Paytm's sky) a deep shade of the colour itself
    static func ink(on hex: String) -> Color {
        luminance(hex) > 0.22 ? Color(hex: hex).mix(with: .black, by: 0.78) : Color.white
    }
}
