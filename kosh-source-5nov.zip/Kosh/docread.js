/* kosh docread: the money papers people keep as PDFs that aren't bank or card statements — salary slips, fixed
   deposit advices, loan statements and repayment schedules, NPS statements, tax certificates (Form 16, Form 16A,
   bank interest certificates, capital-gains statements), EPFO passbooks and equity contract notes — read into what
   kosh keeps.

   Swift opens the PDF on the phone and rebuilds each page's text row by row from where each character sits: a
   table row comes out on one line with its cells three or more spaces apart; ordinary text stays single-spaced.
   Each reader is registered on KoshEngine.docReaders under its kind, so parseDoc(text, kind, from, title) uses it.

   Every reader also returns the document's own arithmetic test as `check` ({ ok, read, stated, note }): ok only
   when the figures printed on it add up. A reading that doesn't add up is still returned, with ok false, so the
   person can look at it; a reader that recognises nothing says so and returns empty lists. Nothing here guesses
   a number: every figure is printed on the page, or is plain arithmetic on printed figures.

   Loaded after engine.js, like mailwire.js; Swift calls fifoGainsJSON through KoshEngine. */

var KoshDocs = (function (E) {
  'use strict';
  var L = E.lib || {};
  var READERS = E.docReaders || (E.docReaders = {});
  var MON = L.MON || 'jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec';
  var MONTHS = ['january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december'];
  var MON3 = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  var ISIN = /\bIN[A-Z0-9]{9}[0-9]\b/;
  var NOTHING = 'Nothing kosh recognises in it';

  /* ------------------------------------------------------------ small things */
  function r2(n) { return Math.round((+n || 0) * 100) / 100; }
  function r4(n) { return Math.round((+n || 0) * 1e4) / 1e4; }
  function trim(s) { return String(s == null ? '' : s).replace(/\s+/g, ' ').trim(); }
  function cells(line) { return String(line || '').split(/\s{3,}|\t/).map(trim).filter(Boolean); }
  function linesOf(text) { return String(text || '').replace(/ /g, ' ').replace(/\r/g, '').split('\n'); }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function sum(list, f) { var s = 0; for (var i = 0; i < list.length; i++) s += f ? (+f(list[i]) || 0) : (+list[i] || 0); return s; }
  // rupees for a note: ₹1,23,456 in whole rupees (the check itself works in paise); small sums keep their paise (₹34.07)
  function rs(n) {
    var a = Math.abs(+n || 0), s = a < 1000 && Math.abs(a - Math.round(a)) >= 0.005 ? '₹' + a.toFixed(2) : (L.inr ? L.inr(a) : '₹' + Math.round(a));
    return (n < -0.005 ? '−' : '') + s;
  }
  function empty(note) {
    return { holdings: [], facts: [], loans: [], trades: [], check: { ok: false, read: 0, stated: 0, note: note || NOTHING } };
  }
  function emailOf(from) { var m = /<([^>]+)>/.exec(from || ''); return trim(m ? m[1] : (from || '')).toLowerCase(); }
  function domainOf(from) { return emailOf(from).split('@')[1] || ''; }
  // "EXAMPLE TECH PRIVATE LIMITED" → "Example Tech Private Limited"; short acronyms (HDFC, SBI) stay as printed
  var PLAIN_WORDS = /^(?:BANK|OF|THE|AND|STATE|INDIA|UNION|CITY|FIRST|LTD|PVT|TECH|LABS?|CORP|INC|LLP)$/;
  function nameCase(s) {
    s = trim(s);
    if (!s || s !== s.toUpperCase() || !/[A-Z]/.test(s)) return s;
    return s.split(' ').map(function (w, i) {
      if ((w.length <= 3 || !/[AEIOU]/.test(w) || w === 'ICICI') && /^[A-Z&.]+$/.test(w) && !PLAIN_WORDS.test(w)) return w;
      if (i > 0 && /^(?:OF|AND|THE)$/.test(w)) return w.toLowerCase();
      return w.charAt(0) + w.slice(1).toLowerCase();
    }).join(' ');
  }

  /* ------------------------------------------------------------ amounts
     A cell that is just an amount: "1,23,456.78", "-15,000.00", "(1,234.50)", "Rs. 500", "₹ 2,00,000.00",
     "INR 1,000", "1,000/-", "15,033.45 Dr". Brackets mean minus, as accountants print it. A run of nine or more
     bare digits is an account, order or receipt number, never an amount. */
  var AMT_CELL = /^(?:(?:rs\.?|inr|₹)\s*)?([-−–]\s*)?(\()?\s*(?:(?:rs\.?|inr|₹)\s*)?(\d{1,3}(?:,\d{2,3})+(?:\.\d{1,4})?|\d+(?:\.\d{1,4})?)\s*(\))?\s*(?:\/-)?\s*(?:\(?\s*(cr|dr)\s*\)?\.?)?$/i;
  function amt(s) {
    var m = AMT_CELL.exec(trim(s));
    if (!m || !!m[2] !== !!m[4]) return null;
    if (/^\d{9,}$/.test(m[3])) return null;
    var a = parseFloat(m[3].replace(/,/g, ''));
    var neg = !!(m[1] || m[2]);
    return { v: neg ? -a : a, abs: a, neg: neg, dc: (m[5] || '').toLowerCase(), t: m[3] };
  }
  function numbersOf(cs, from) {
    var out = [];
    for (var k = from || 0; k < cs.length; k++) { var a = amt(cs[k]); if (a) { a.k = k; out.push(a); } }
    return out;
  }

  /* ------------------------------------------------------------ dates
     Any day a document prints, to yyyy-mm-dd: 05/09/2026 and 05-09-26 are day first, as Indian papers write them;
     05-Sep-2026, 5th September 2026, Sep 5, 2026 and 2026-09-05 too. Unlike a statement line, a deposit's
     maturity or a loan's last instalment can be years ahead, so any real day from 1990 to 2100 is fine. */
  var DATE_SRC = '\\d{4}-\\d{2}-\\d{2}|\\d{1,2}[\\/\\-.]\\d{1,2}[\\/\\-.]\\d{2,4}|\\d{1,2}(?:st|nd|rd|th)?[\\s\\-\\/.,]*(?:' + MON + ')[a-z]*\\.?[\\s\\-\\/.,]*\\d{2,4}|(?:' + MON + ')[a-z]*\\.?\\s+\\d{1,2}(?:st|nd|rd|th)?,?\\s+\\d{4}';
  var DATE_IN = new RegExp('(?:^|[^\\d])(' + DATE_SRC + ')(?![\\d])', 'i');
  var DATE_ONLY = new RegExp('^(?:' + DATE_SRC + ')$', 'i');
  function monthNo(w) {
    w = String(w || '').toLowerCase().replace(/\.$/, '');
    if (w.length < 3) return 0;
    for (var i = 0; i < 12; i++) if (MONTHS[i].indexOf(w) === 0 || (w === 'sept' && i === 8)) return i + 1;
    return 0;
  }
  function isoOf(y, m, d) {
    y = +y; m = +m; d = +d;
    if (y < 100) y += 2000;
    if (!(y >= 1990 && y <= 2100) || !(m >= 1 && m <= 12) || !(d >= 1)) return '';
    if (d > new Date(Date.UTC(y, m, 0)).getUTCDate()) return '';
    return y + '-' + pad(m) + '-' + pad(d);
  }
  function day(s) {
    var m = DATE_IN.exec(String(s || ''));
    if (!m) return '';
    var t = m[1].toLowerCase(), x;
    if ((x = /^(\d{4})-(\d{2})-(\d{2})$/.exec(t))) return isoOf(x[1], x[2], x[3]);
    if ((x = /^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{2,4})$/.exec(t))) return x[3].length === 3 ? '' : isoOf(x[3], x[2], x[1]);
    if ((x = /^(\d{1,2})(?:st|nd|rd|th)?[\s\-\/.,]*([a-z]+)\.?[\s\-\/.,]*(\d{2,4})$/.exec(t))) return x[3].length === 3 ? '' : isoOf(x[3], monthNo(x[2]), x[1]);
    if ((x = /^([a-z]+)\.?\s+(\d{1,2})(?:st|nd|rd|th)?,?\s+(\d{4})$/.exec(t))) return isoOf(x[3], monthNo(x[1]), x[2]);
    return '';
  }
  function fmtDay(iso) { return iso ? (+iso.slice(8, 10)) + ' ' + MON3[+iso.slice(5, 7) - 1] + ' ' + iso.slice(0, 4) : ''; }
  function addMonths(iso, n) {
    var y = +iso.slice(0, 4), m = +iso.slice(5, 7) - 1 + n, d = +iso.slice(8, 10);
    y += Math.floor(m / 12); m = ((m % 12) + 12) % 12;
    return y + '-' + pad(m + 1) + '-' + pad(Math.min(d, new Date(Date.UTC(y, m + 1, 0)).getUTCDate()));
  }
  function daysBetween(a, b) { return Math.round((Date.parse(b + 'T00:00:00Z') - Date.parse(a + 'T00:00:00Z')) / 864e5); }
  // the Indian financial year a day falls in: April to March, '2025-26'
  function fyOf(iso) { var y = +iso.slice(0, 4), s = +iso.slice(5, 7) >= 4 ? y : y - 1; return s + '-' + pad((s + 1) % 100); }
  function fyStr(y) { return y + '-' + pad((y + 1) % 100); }
  function periodRe(lead) { return new RegExp('(?:' + lead + ')\\s*[:\\-]?\\s*(?:from\\s+)?(' + DATE_SRC + ')\\s*(?:to|till|until|-|–)\\s*(' + DATE_SRC + ')', 'i'); }

  /* ------------------------------------------------------------ labels and the values printed against them
     On a rebuilt page a label starts a cell ("Net Pay   1,01,550.00", "Net Pay: 1,01,550.00"); list numbers
     before it ("1.", "(a)") are fine. Its value is in the same cell after it, else in the cells that follow,
     else (a summary box: a row of labels over a row of figures) in the same column on the next line. In
     single-spaced text a label may sit mid-line, but then only with a colon after it ("… Gross Salary: 85,000").
     `skip` is what, following the label, makes it something else ("PF Number", "EMI Date"). */
  function label(src, skip) {
    return {
      at: new RegExp('^(?:' + src + ')(?![a-z])', 'i'),
      mid: new RegExp('(?:^|[\\s|;,])(?:' + src + ')(?![a-z])\\s*(?:\\([^)]*\\)\\s*)?[:=]\\s*', 'ig'),
      skip: skip || null
    };
  }
  var LIST_MARK = /^(?:\(?(?:\d{1,2}|[a-h]|[ivx]{1,4})[.)]\s+)+/i;
  var ID_AFTER = /^\s*(?:no\b|no\.|number|num\b|a\/c|account|uan|id\b|code|wages|basis|base\b|ceiling|eligible|limit)/i;
  function valueIn(s, kind) {
    s = trim(s).replace(/^[\s.:=\-–#]+/, '');
    if (!s) return null;
    if (kind === 'amt') {
      var m = /^(?:(?:rs\.?|inr|₹)\s*)?[-−(]?\s*(?:(?:rs\.?|inr|₹)\s*)?\d[\d,]*(?:\.\d+)?\)?(?:\s*\/-)?(?:\s*\(?(?:cr|dr)\b\)?)?/i.exec(s);
      return m ? amt(m[0]) : null;
    }
    if (kind === 'pct') {
      var p = /^(\d{1,2}(?:\.\d{1,4})?)\s*(?:%|per\s*cent|p\.?\s*a\b|$)/i.exec(s);
      return p && +p[1] > 0 && +p[1] < 30 ? { v: +p[1] } : null;
    }
    if (kind === 'date') { var d = day(s); return d ? { v: d } : null; }
    return { v: s };
  }
  // every place a label appears, in page order, with its value; col 'first' or 'last' of a run of figures
  function hits(lines, F, kind, col, from, to) {
    var out = [], li, cs, ci;
    from = from || 0; to = to == null ? lines.length : Math.min(to, lines.length);
    for (li = from; li < to; li++) {
      cs = cells(lines[li]);
      for (ci = 0; ci < cs.length; ci++) {
        var c = cs[ci].replace(LIST_MARK, ''), m = F.at.exec(c);
        if (!m) continue;
        var rest = c.slice(m[0].length), bare = rest.replace(/^\s*(?:\([^)]*\)\s*)+/, '');
        if (F.skip && F.skip.test(bare)) continue;
        if ((kind === 'amt' || kind === 'pct') && ID_AFTER.test(bare)) continue;
        var v = valueIn(bare, kind), run = null;
        if (!v && kind === 'amt') {
          run = [];
          for (var k = ci + 1; k < cs.length; k++) { var a = amt(cs[k]); if (!a) break; run.push(a); }
          if (run.length) v = col === 'last' ? run[run.length - 1] : run[0];
        } else if (!v && ci + 1 < cs.length) v = valueIn(cs[ci + 1], kind);
        if (!v && cs.length > 1 && !numbersOf(cs).length) {
          // a summary box: labels on one line, their figures in the same columns on the next (one line of them:
          // under a table's header the next line is only its first row)
          var nx = li + 1 < to ? cells(lines[li + 1]) : [], nx2 = li + 2 < to ? cells(lines[li + 2]) : [];
          if (nx.length === cs.length && !(nx2.length === nx.length && numbersOf(nx2).length)) v = valueIn(nx[ci], kind);
        }
        if (v) out.push({ v: v.v, a: v, run: run, li: li, ci: ci, rest: rest, lab: cs[ci], cells: cs });
      }
    }
    if (out.length) return out;
    for (li = from; li < to; li++) {
      var line = lines[li], mm;
      F.mid.lastIndex = 0;
      while ((mm = F.mid.exec(line))) {
        var after = line.slice(mm.index + mm[0].length);
        var v2 = valueIn(kind === 'text' ? (cells(after)[0] || '') : after, kind);
        if (v2) out.push({ v: v2.v, a: v2, run: null, li: li, ci: 0, rest: '', lab: mm[0], cells: [line] });
      }
    }
    return out;
  }
  function first(lines, F, kind, col, from, to) { var h = hits(lines, F, kind, col, from, to); return h.length ? h[0] : null; }
  function last4(s) { var d = String(s || '').replace(/\D/g, ''); return d.length >= 4 ? d.slice(-4) : ''; }

  // the bank that sent it, from the sender, else its name at the top of the page
  function bankOf(from, lines) {
    var ins = L.institution ? L.institution(from || '') : null;
    if (ins) return ins.short || ins.name;
    for (var i = 0; i < Math.min(lines.length, 8); i++) {
      var c = cells(lines[i])[0] || '';
      var m = /^((?:[A-Za-z&.']+\s+){0,4}Bank(?:\s+of\s+[A-Za-z]+)?)(?![a-z])/i.exec(c) || /^(Bank\s+of\s+[A-Za-z]+)/i.exec(c);
      if (m && !/^(?:your|the|dear|our|this|a)\s/i.test(m[1])) return nameCase(m[1]);
    }
    return '';
  }

  /* ------------------------------------------------------------ 1. salary slips
     Two layouts between them cover most slips: a two-column table (Earnings | Amount | Deductions | Amount) and
     a list of "Label: value" lines. Some slips print two figures per line — full-month and actual, or this month
     and year-to-date — so both columns are read and the one where gross less deductions is the net pay wins. */
  var PAY = {
    gross: label('gross\\s+(?:earnings?|salary|pay|wages|amount|total)|total\\s+gross(?:\\s+(?:earnings?|salary|pay))?|total\\s+(?:earnings?|salary)|earnings\\s+total|gross(?!\\s+(?:deduct|recover))'),
    ded: label('total\\s+deductions?|gross\\s+deductions?|deductions?\\s+total|total\\s+recover(?:y|ies)'),
    net: label('net\\s+(?:pay(?:able)?|salary|take\\s*home|amount(?:\\s+(?:payable|paid|credited))?|payment)|take\\s*home(?:\\s+(?:pay|salary))?|amount\\s+credited(?:\\s+to\\s+(?:your\\s+)?(?:bank|account))?'),
    basic: label('basic(?:\\s+(?:salary|pay|wages?))?', /^\s*(?:\+|&|and\b|rate)/i),
    hra: label('h\\.?r\\.?a\\.?|house\\s+rent\\s+allowance', /^\s*(?:exempt|exemption|rate)/i),
    pf: label('(?:employee(?:\'?s)?\\s+)?(?:contribution\\s+to\\s+)?(?:provident\\s+fund|e?\\.?p\\.?f\\.?)(?:\\s+(?:contribution|deduction|employee(?:\'?s)?(?:\\s+share)?))?', /^\s*(?:employer|admin)/i),
    tds: label('income\\s*tax(?:\\s*\\(?tds\\)?)?|tds|tax\\s+deducted(?:\\s+at\\s+source)?', /^\s*(?:pan|regime|section|act\b)/i),
    pt: label('prof(?:essional|\\.)?\\s*tax|p\\.?\\s?tax|pt'),
    employer: label('employer(?:\'?s)?\\s+name|name\\s+of\\s+(?:the\\s+)?employer|company\\s+name|employer|company|organi[sz]ation(?:\\s+name)?', /^\s*(?:address|code|id\b|pan|tan|gst|logo)/i)
  };
  var CO = /\b(?:pvt\.?|private|ltd\.?|limited|llp|inc\.?|corporation|corp\.?|technologies|solutions|services|industries|enterprises|consulting|labs?)(?![a-z])/i;
  var WEBMAIL = /^(?:gmail|googlemail|yahoo|outlook|hotmail|live|icloud|me|rediffmail|rediff|aol|proton(?:mail)?|zoho)\./i;
  function cleanCo(s) { return nameCase(trim(String(s).replace(/\s*[-–|,:]?\s*(?:pay\s*slip|salary\s+slip|pay\s+statement).*$/i, '').replace(/[\s,;:-]+$/, ''))).slice(0, 80); }
  function employerOf(lines, from) {
    var h = first(lines, PAY.employer, 'text');
    if (h && CO.test(h.v)) return cleanCo(h.v);
    for (var i = 0; i < Math.min(lines.length, 12); i++) {
      var c = cells(lines[i])[0] || '';
      if (CO.test(c) && !/:/.test(c) && !/^(?:bank|a\/c|account|pan|uan|ifsc|address|branch|location|designation|department)\b/i.test(c)) return cleanCo(c);
    }
    if (h) return cleanCo(h.v);
    var ins = L.institution ? L.institution(from || '') : null;
    if (ins) return ins.name;
    var dom = domainOf(from);
    return dom && !WEBMAIL.test(dom) ? dom : '';
  }
  function monthYear(w, y) { var m = monthNo(w); y = +y; if (y < 100) y += 2000; return m && y >= 2000 && y < 2100 ? y + '-' + pad(m) : ''; }
  function payMonth(lines, flat, title) {
    var res = [
      /\bfor\s+(?:the\s+)?month\s+(?:of\s+)?[:\-]?\s*([a-z]{3,9})\.?[\s,\-'’\/]*(\d{4}|\d{2})\b/ig,
      /\b(?:pay\s*slip|salary\s+slip|pay\s+statement|salary\s+statement)\s*(?:for|of|[:\-–])?\s*([a-z]{3,9})\.?[\s,\-'’\/]*(\d{4}|\d{2})\b/ig,
      /\bmonth(?:\s*(?:&|and)\s*year)?\s*[:\-]\s*([a-z]{3,9})\.?[\s,\-'’\/]*(\d{4}|\d{2})\b/ig
    ];
    for (var i = 0; i < res.length; i++) {
      var m;
      while ((m = res[i].exec(flat))) { var my = monthYear(m[1], m[2]); if (my) return my; }
    }
    // "Pay Period: 01-Sep-2026 to 30-Sep-2026": the month it ends in (a 26th-to-25th payroll is the later month's)
    var pp = periodRe('pay\\s*period').exec(flat);
    if (pp && day(pp[2])) return day(pp[2]).slice(0, 7);
    var nm = /\bmonth\s*[:\-]\s*(\d{1,2})[\/\-](\d{4})\b/i.exec(flat);
    if (nm && +nm[1] >= 1 && +nm[1] <= 12) return nm[2] + '-' + pad(+nm[1]);
    // a month and year near the top ("Sep-2026"), once whole dates (date of joining…) are out of the way
    var top = lines.slice(0, 15).join(' ').replace(new RegExp(DATE_SRC, 'gi'), ' ');
    var g = new RegExp('\\b(' + MON + ')[a-z]*\\.?[\\s\\-\'’,]*(\\d{4})\\b', 'i').exec(top);
    if (g && monthYear(g[1], g[2])) return monthYear(g[1], g[2]);
    var t = new RegExp('(' + MON + ')[a-z]*[\\s_\\-]*(\\d{4}|\\d{2})(?!\\d)', 'i').exec(title || '');
    return t ? monthYear(t[1], t[2]) : '';
  }
  function payslip(text, from, title, flat) {
    var lines = linesOf(text);
    function one(F, col) { var h = first(lines, F, 'amt', col); return h ? Math.abs(h.v) : 0; }
    function read(col) {
      var g = first(lines, PAY.gross, 'amt', col), d = first(lines, PAY.ded, 'amt', col), n = first(lines, PAY.net, 'amt', col);
      var x = { gross: g ? Math.abs(g.v) : 0, ded: d ? Math.abs(d.v) : 0, net: n ? Math.abs(n.v) : 0,
                basic: one(PAY.basic, col), hra: one(PAY.hra, col), pf: one(PAY.pf, col), tds: one(PAY.tds, col), pt: one(PAY.pt, col),
                found: !!(g || d || n), derived: false };
      // no "Total Deductions" line: PF, income tax and professional tax are the deductions, and the check says if that's all
      if (!d && (x.pf || x.tds || x.pt)) { x.ded = r2(x.pf + x.tds + x.pt); x.derived = true; }
      return x;
    }
    function balances(x) { return x.gross > 0 && x.net > 0 && Math.abs(x.gross - x.ded - x.net) <= 1; }
    // which column a two-figure slip means: this month (before a year-to-date column) or actual (after full-month)
    var hint = '';
    for (var i = 0; i < lines.length; i++) {
      var l = lines[i];
      if (/earnings?/i.test(l) && cells(l).length >= 3 && !numbersOf(cells(l)).length) {
        if (/\bytd\b|year\s*to\s*date|cumulative|upto\s+(?:this|the)\s+month/i.test(l)) hint = 'first';
        else if (/\b(?:actual|earned|paid)\b/i.test(l) && /\b(?:rate|full|monthly|master|fixed|standard|gross)\b/i.test(l)) hint = 'last';
        break;
      }
    }
    var a = read(hint === 'last' ? 'last' : 'first'), b = read(hint === 'last' ? 'first' : 'last');
    var x = balances(a) || !balances(b) ? a : b;
    if (!x.found) return empty();
    var ok = balances(x), read0 = r2(x.gross - x.ded);
    var note = ok ? 'Gross ' + rs(x.gross) + ' less deductions ' + rs(x.ded) + (x.derived ? ' (PF, income tax and professional tax)' : '') + ' is the net pay printed, ' + rs(x.net)
      : !x.gross ? 'No gross pay printed to check the net pay against'
      : !x.net ? 'No net pay printed to check the gross pay against'
      : 'Gross ' + rs(x.gross) + ' less deductions ' + rs(x.ded) + ' is ' + rs(read0) + ', but the net pay printed is ' + rs(x.net);
    return {
      kind: 'payslip',
      facts: [{ k: 'payslip', month: payMonth(lines, flat, title), employer: employerOf(lines, from), gross: r2(x.gross), deductions: r2(x.ded), net: r2(x.net),
                basic: r2(x.basic), hra: r2(x.hra), pf: r2(x.pf), tds: r2(x.tds), profTax: r2(x.pt) }],
      holdings: [],
      check: { ok: ok, read: x.gross ? read0 : 0, stated: r2(x.net), note: note }
    };
  }

  /* ------------------------------------------------------------ 2. fixed and term deposits
     An advice for one deposit is a list of labels; a receipt or renewal advice for several is a table, one deposit a
     row. Table rows are read by what each cell is (a date, a rate, an amount) and placed by the header's order. The
     check: a cumulative deposit's maturity amount is its principal compounded quarterly at its rate from start to
     maturity (within 1%); a payout deposit returns its principal. */
  var FD = {
    prin: label('principal(?:\\s+amount)?|deposit\\s+amount|amount\\s+of\\s+(?:the\\s+)?(?:deposit|fd|td)|amount\\s+deposited|deposit\\s+(?:value|principal)|renewed\\s+amount|renewal\\s+amount|(?:fd|td|term\\s+deposit|fixed\\s+deposit)\\s+amount|investment\\s+amount|amount\\s+invested|booking\\s+amount'),
    // an SBI advice prints its principal as just "Amount" (only at the start of its line: never "Maturity Amount")
    amt: { at: /^amount(?:\s*\((?:rs|inr|₹)\.?\))?(?![a-z])/i, mid: /(?!)/g, skip: null },
    rate: label('rate\\s+of\\s+interest|interest\\s+rate|roi|rate(?!\\s+of\\s+(?:tds|tax))'),
    start: label('value\\s+date|date\\s+of\\s+(?:deposit|opening|issue|renewal|booking|investment)|(?:deposit|start|opening|effective|renewal|booking|issue|creation|open|investment)\\s+(?:date|dt\\.?)|(?:deposit|account)\\s+(?:start|open(?:ing)?)\\s+date|deposit(?:ed)?\\s+on|renewed\\s+on|booked\\s+on'),
    mat: label('maturity\\s+(?:date|dt\\.?)|date\\s+of\\s+maturity|matur(?:es|ity)\\s+on|due\\s+date'),
    matAmt: label('maturity\\s+(?:amount|value|proceeds|amt)|amount\\s+(?:on|at|payable\\s+on)\\s+maturity'),
    // how long it runs: "1 Year 6 Months", "400 days", "2 Yrs 3 Mths"
    tenure: label('tenure|period(?:\\s+of\\s+deposit)?|deposit\\s+(?:period|tenure|term)|term(?:\\s+of\\s+deposit)?|duration'),
    no: label('(?:fixed\\s+|term\\s+)?deposit\\s+(?:a\\/c\\s+|account\\s+)?(?:no|number)|(?:fd|td|tdr|stdr)\\s+(?:a\\/c\\s+|account\\s+)?(?:no|number)|account\\s+(?:no|number)|a\\/c\\s+(?:no|number)|receipt\\s+(?:no|number)|deposit\\s+id'),
    payout: label('interest\\s+payout(?:\\s+(?:frequency|option|mode))?|payout(?:\\s+(?:frequency|option|type))?|interest\\s+(?:payment\\s+)?(?:frequency|option)|(?:deposit|scheme|product)\\s+type|type\\s+of\\s+deposit|scheme|product')
  };
  function payoutOf(s) {
    s = String(s || '').toLowerCase();
    var non = /non[\s\-]*cumulative/.test(s);
    if (!non && /cumulative|re-?invest|on\s+maturity|\bstdr\b|special\s+term|interest\s+compounded/.test(s)) return 'cumulative';
    if (/monthly/.test(s)) return 'monthly';
    if (/quarterly/.test(s)) return 'quarterly';
    return '';
  }
  // principal compounded quarterly for whole quarters, simple interest for the days left over, as banks do
  function grow(p, rate, start, mat) {
    var q = 0;
    while (q < 400 && addMonths(start, 3 * (q + 1)) <= mat) q++;
    var rest = Math.max(0, daysBetween(addMonths(start, 3 * q), mat));
    return p * Math.pow(1 + rate / 400, q) * (1 + rate * rest / 36500);
  }
  // "1 Year 6 Months 10 Days", "400 days", "2 Yrs 3 Mths", "18 M": years, months and days
  function tenureOf(s) {
    s = String(s || '').toLowerCase();
    var y = /(\d{1,2})\s*(?:years?|yrs?|y)\b/.exec(s), mo = /(\d{1,3})\s*(?:months?|mths?|mos?|m)\b/.exec(s), d = /(\d{1,4})\s*(?:days?|d)\b/.exec(s);
    if (!y && !mo && !d) return null;
    var t = { y: y ? +y[1] : 0, m: mo ? +mo[1] : 0, d: d ? +d[1] : 0 };
    return t.y || t.m || t.d ? t : null;
  }
  function tenureText(t) {
    if (!t) return '';
    var parts = [];
    if (t.y) parts.push(t.y + (t.y === 1 ? ' year' : ' years'));
    if (t.m) parts.push(t.m + (t.m === 1 ? ' month' : ' months'));
    if (t.d) parts.push(t.d + (t.d === 1 ? ' day' : ' days'));
    return parts.join(' ');
  }
  function plusTenure(start, t) {
    if (!start || !t) return '';
    var x = addMonths(start, 12 * t.y + t.m);
    if (t.d) { var dt = new Date(Date.UTC(+x.slice(0, 4), +x.slice(5, 7) - 1, +x.slice(8, 10) + t.d)); x = dt.toISOString().slice(0, 10); }
    return x;
  }
  function fdBlock(lines, a, b, docPayout) {
    var p = first(lines, FD.prin, 'amt', 'first', a, b) || first(lines, FD.amt, 'amt', 'first', a, b), r = first(lines, FD.rate, 'pct', 'first', a, b);
    var s = first(lines, FD.start, 'date', 'first', a, b), m = first(lines, FD.mat, 'date', 'first', a, b);
    var ma = first(lines, FD.matAmt, 'amt', 'first', a, b), no = first(lines, FD.no, 'text', 'first', a, b);
    var po = first(lines, FD.payout, 'text', 'first', a, b), te = first(lines, FD.tenure, 'text', 'first', a, b);
    var t = te ? tenureOf(te.v) : null;
    var start = s ? s.v : '', mat = m ? m.v : '';
    // a maturity date the advice leaves out is its start plus its tenure
    if (!mat && start && t) mat = plusTenure(start, t);
    return { amt: p ? Math.abs(p.v) : 0, rate: r ? r.v : 0, start: start, mat: mat, matAmt: ma ? Math.abs(ma.v) : 0,
             depNo: last4(no && no.v), payout: payoutOf(po ? po.v : '') || docPayout, tenure: tenureText(t) };
  }
  function fdColumn(h) {
    h = h.toLowerCase();
    if (/matur/.test(h) && /date|\bon\b/.test(h)) return 'mat';
    if (/matur/.test(h) && /amount|value|amt|proceeds/.test(h)) return 'matAmt';
    if (/interest/.test(h) && /amount|amt|earned|accrued|payable/.test(h)) return 'int';
    if (/rate|roi|%/.test(h)) return 'rate';
    if (/date|from/.test(h)) return 'start';
    if (/principal|amount|amt|deposit\s+value|value/.test(h)) return 'amt';
    return '';
  }
  function fdTable(lines, docPayout) {
    var hi = -1, cols = [];
    for (var i = 0; i < lines.length; i++) {
      var cs = cells(lines[i]);
      if (cs.length >= 3 && !numbersOf(cs).length && cs.some(function (c) { return /matur/i.test(c); }) && cs.some(function (c) { return /amount|principal|deposit|value/i.test(c); })) {
        hi = i; cols = cs.map(fdColumn); break;
      }
    }
    if (hi < 0) return [];
    var amtCols = cols.filter(function (c) { return c === 'amt' || c === 'int' || c === 'matAmt'; });
    var out = [], misses = 0;
    for (var j = hi + 1; j < lines.length && misses < 3; j++) {
      var rc = cells(lines[j]);
      if (!rc.length) continue;
      if (/^(?:grand\s+)?total\b/i.test(rc[0])) break;
      var dates = [], amts = [], rate = 0, no = '';
      rc.forEach(function (c, k) {
        if (DATE_ONLY.test(c) && day(c)) { dates.push(day(c)); return; }
        if (k === 0 && /^[\dXx*•]{6,}$/.test(c)) { no = last4(c); return; }
        var pc = /^(\d{1,2}(?:\.\d{1,4})?)\s*%?(?:\s*p\.?\s*a\.?)?$/i.exec(c);
        if (pc && +pc[1] > 0 && +pc[1] < 30 && !rate) { rate = +pc[1]; return; }
        var a = amt(c);
        if (a && a.abs >= 100 && /[.,]/.test(a.t)) amts.push(a.abs);
      });
      if (!dates.length || !amts.length) { misses++; continue; }
      misses = 0;
      var d = { amt: 0, rate: rate, start: '', mat: '', matAmt: 0, depNo: no, payout: payoutOf(rc.join(' ')) || docPayout };
      dates.sort();
      if (dates.length >= 2) { d.start = dates[0]; d.mat = dates[dates.length - 1]; }
      else if (cols.indexOf('mat') >= 0 && cols.indexOf('start') < 0) d.mat = dates[0];
      else d.start = dates[0];
      if (amts.length === amtCols.length) amtCols.forEach(function (c, k) { if (c === 'amt') d.amt = amts[k]; else if (c === 'matAmt') d.matAmt = amts[k]; });
      else if (amts.length === 1) d.amt = amts[0];
      else if (amts.length === 2) { d.amt = Math.min(amts[0], amts[1]); d.matAmt = Math.max(amts[0], amts[1]); }
      else {
        // principal + interest = maturity: the three that add up
        for (var x = 0; x < amts.length; x++) for (var y = 0; y < amts.length; y++) for (var z = 0; z < amts.length; z++)
          if (x !== y && y !== z && x !== z && amts[x] > amts[y] && Math.abs(amts[x] + amts[y] - amts[z]) <= 1 && !d.amt) { d.amt = amts[x]; d.matAmt = amts[z]; }
      }
      out.push(d);
    }
    return out;
  }
  function fdCheck(d) {
    var payout = d.payout === 'monthly' || d.payout === 'quarterly' || (d.payout === '' && d.matAmt && Math.abs(d.matAmt - d.amt) <= 1);
    if (payout) {
      if (!d.matAmt) return { ok: d.rate > 0, read: d.amt, stated: 0, note: d.rate > 0 ? 'Interest is paid out, so the ' + rs(d.amt) + ' principal is what comes back at maturity' : 'No interest rate printed' };
      var same = Math.abs(d.matAmt - d.amt) <= 1;
      return { ok: same, read: d.amt, stated: d.matAmt, note: same ? 'Interest is paid out, and the maturity amount is the ' + rs(d.amt) + ' principal'
        : 'Interest is paid out, yet the maturity amount ' + rs(d.matAmt) + ' isn\'t the ' + rs(d.amt) + ' principal' };
    }
    if (d.matAmt) {
      if (!(d.rate && d.start && d.mat && d.mat > d.start)) return { ok: false, read: 0, stated: d.matAmt, note: 'A maturity amount is printed, but not the rate and dates to check it' };
      var want = r2(grow(d.amt, d.rate, d.start, d.mat)), ok = Math.abs(want - d.matAmt) <= want * 0.01;
      return { ok: ok, read: want, stated: d.matAmt, note: rs(d.amt) + ' at ' + d.rate + '% compounded quarterly from ' + fmtDay(d.start) + ' to ' + fmtDay(d.mat) + ' is ' + rs(want) +
        (ok ? ', in line with the ' + rs(d.matAmt) + ' maturity amount printed' : ', but the maturity amount printed is ' + rs(d.matAmt)) };
    }
    var all = d.amt && d.rate && d.start && d.mat;
    return { ok: !!all, read: d.amt, stated: 0, note: all ? 'No maturity amount printed; principal, rate and dates are all there' : 'No maturity amount printed, and the ' + (!d.rate ? 'rate' : !d.start ? 'start date' : 'maturity date') + ' is missing too' };
  }
  function fd(text, from, title, flat) {
    var lines = linesOf(text);
    var docPayout = payoutOf(lines.slice(0, 8).join(' '));
    var deps = fdTable(lines, docPayout);
    if (!deps.some(function (d) { return d.amt > 0; })) {
      // several deposits on one advice: a block from each deposit number to the next
      var nos = hits(lines, FD.no, 'text'), starts = [];
      nos.forEach(function (h) { if (starts.indexOf(h.li) < 0) starts.push(h.li); });
      deps = [];
      if (starts.length >= 2) starts.forEach(function (s, k) {
        var d = fdBlock(lines, k === 0 ? 0 : s, k + 1 < starts.length ? starts[k + 1] : lines.length, docPayout);
        if (d.amt) deps.push(d);
      });
      if (deps.length < 2) deps = [fdBlock(lines, 0, lines.length, docPayout)];
    }
    deps = deps.filter(function (d) { return d.amt > 0; });
    if (!deps.length) return empty();
    var bank = bankOf(from, lines), checks = deps.map(fdCheck);
    var holdings = deps.map(function (d) {
      return { bank: bank, type: 'FD', cls: 'dep', amt: r2(d.amt), rate: d.rate, rem: d.mat ? 'Matures ' + fmtDay(d.mat) : '', mat: d.mat, matAmt: r2(d.matAmt),
               start: d.start, depNo: d.depNo, payout: d.payout, tenure: d.tenure || undefined };
    });
    var bad = checks.filter(function (c) { return !c.ok; });
    var note = deps.length === 1 ? checks[0].note : !bad.length ? 'All ' + deps.length + ' deposits add up' : bad.length + ' of ' + deps.length + ' deposits don\'t add up. ' + bad[0].note;
    return { kind: 'fd', holdings: holdings, check: { ok: !bad.length, read: r2(sum(checks, function (c) { return c.read; })), stated: r2(sum(checks, function (c) { return c.stated; })), note: note } };
  }

  /* ------------------------------------------------------------ 3. loans
     A loan statement prints its principal at the start and end of the period and what was repaid in it; a repayment
     schedule prints one row per instalment. A schedule's columns (opening, EMI, principal, interest, closing, in
     whatever order) are told apart by arithmetic, not by header words: principal + interest = EMI, opening −
     principal = closing, and each row opens where the one before closed. */
  var LN = {
    out: label('(?:closing\\s+)?principal\\s+(?:outstanding|balance|o\\/s)|outstanding\\s+principal|closing\\s+principal(?:\\s+(?:outstanding|balance))?|balance\\s+principal|(?:current\\s+|total\\s+)?outstanding\\s+(?:balance|amount|loan(?:\\s+amount)?)|loan\\s+outstanding|closing\\s+balance'),
    open: label('opening\\s+(?:principal(?:\\s+(?:outstanding|balance))?|balance|outstanding)|principal\\s+outstanding\\s+at\\s+(?:the\\s+)?(?:beginning|start)'),
    paidP: label('(?:total\\s+)?principal\\s+(?:repaid|paid|component|recovered|received|amount\\s+(?:paid|repaid))'),
    paidI: label('(?:total\\s+)?interest\\s+(?:repaid|paid|component|recovered|received|amount\\s+(?:paid|repaid))'),
    emi: label('(?:current\\s+|monthly\\s+)?emi(?:\\s+amount)?|(?:monthly\\s+)?instal+ment(?:\\s+amount)?', /^\s*(?:paid|due|date|start|end|count|no\b|number|s\b|received|overdue|bounce|frequency|mode|cycle|day)/i),
    rate: label('(?:current\\s+|applicable\\s+)?(?:rate\\s+of\\s+interest|interest\\s+rate|roi)'),
    left: label('(?:balance|remaining|residual|outstanding|pending|left)\\s+(?:tenure|term|tenor|emis|instal+ments)|(?:no\\.?\\s+of\\s+)?(?:emis|instal+ments)\\s+(?:remaining|pending|left|outstanding|due)|tenure\\s+(?:remaining|left|balance)'),
    next: label('next\\s+(?:emi|instal+ment|repayment|due)(?:\\s+due)?(?:\\s+date)?|next\\s+due\\s+on'),
    no: label('loan\\s+(?:account|a\\/c)(?:\\s+(?:no|number))?|loan\\s+(?:no|number)|agreement\\s+(?:no|number)|lan')
  };
  function months(s) {
    s = String(s || '').toLowerCase();
    var y = /(\d+)\s*(?:years?|yrs?)\b/.exec(s), m = /(\d+)\s*(?:months?|mths?|emis?|instal)/.exec(s);
    if (y || m) return (y ? +y[1] * 12 : 0) + (m ? +m[1] : 0);
    var n = /^\s*(\d{1,3})\s*$/.exec(s);
    return n ? +n[1] : 0;
  }
  function stdEmi(p, rate, n) { var r = rate / 1200; return r ? p * r * Math.pow(1 + r, n) / (Math.pow(1 + r, n) - 1) : p / n; }
  // a repayment schedule: rows of a date and figures; the role of each figure found by what adds up
  function schedule(lines) {
    var raw = [];
    lines.forEach(function (line) {
      var cs = cells(line), di = -1;
      for (var k = 0; k < cs.length; k++) if (DATE_ONLY.test(cs[k]) && day(cs[k])) { di = k; break; }
      if (di < 0) return;
      var a = numbersOf(cs, di + 1).map(function (x) { return x.v; });
      if (a.length >= 3 && a.length <= 7) raw.push({ date: day(cs[di]), a: a });
    });
    if (raw.length < 2) return null;
    var counts = {}, m = 0;
    raw.forEach(function (r) { counts[r.a.length] = (counts[r.a.length] || 0) + 1; if (!m || counts[r.a.length] > counts[m]) m = r.a.length; });
    var rows = raw.filter(function (r) { return r.a.length === m; });
    if (rows.length < 2) return null;
    function rowOk(R, n, list) {
      var a = list[n].a, pv = n > 0 ? list[n - 1].a : null;
      if (a[R.p] < 0 || a[R.c] < 0 || a[R.i] < 0) return false;
      if (R.o >= 0) { if (Math.abs(a[R.o] - a[R.p] - a[R.c]) > 1) return false; if (pv && Math.abs(a[R.o] - pv[R.c]) > 1) return false; }
      else if (pv && Math.abs(pv[R.c] - a[R.p] - a[R.c]) > 1) return false;
      if (R.e >= 0 && Math.abs(a[R.p] + a[R.i] - a[R.e]) > 1) return false;
      return true;
    }
    var sample = rows.slice(0, 24), best = null;
    for (var p = 0; p < m; p++) for (var c = 0; c < m; c++) for (var o = -1; o < m; o++) for (var i = 0; i < m; i++) for (var e = -1; e < m; e++) {
      var used = [p, c, i].concat(o >= 0 ? [o] : []).concat(e >= 0 ? [e] : []);
      if (used.some(function (u, k) { return used.indexOf(u) !== k; })) continue;
      if (o >= 0 && o > c) continue;   // the opening balance is printed before the closing one
      var R = { p: p, c: c, o: o, i: i, e: e }, good = 0;
      for (var n = 0; n < sample.length; n++) if (rowOk(R, n, sample)) good++;
      var score = good * 100 + (o >= 0 ? 10 : 0) + (e >= 0 ? 10 : 0) + (p < c ? 1 : 0);
      if (!best || score > best.score) best = { R: R, score: score, good: good };
    }
    if (!best || best.good < Math.max(2, Math.ceil(sample.length * 0.6))) return null;
    var R0 = best.R;
    var out = rows.map(function (r, n) {
      var a = r.a;
      return { date: r.date, open: R0.o >= 0 ? a[R0.o] : r2(a[R0.c] + a[R0.p]), prin: a[R0.p], int: a[R0.i], emi: R0.e >= 0 ? a[R0.e] : r2(a[R0.p] + a[R0.i]), close: a[R0.c], ok: rowOk(R0, n, rows) };
    });
    return { rows: out, broken: raw.length - rows.length };
  }
  function loanAsOf(flat) {
    var p = periodRe('(?:statement\\s+)?period|statement\\s+from').exec(flat);
    if (p && day(p[2])) return day(p[2]);
    var re = new RegExp('\\bas\\s+(?:on|of|at)\\s*(?:date)?\\s*[:\\-]?\\s*(' + DATE_SRC + ')', 'ig'), m, best = '';
    while ((m = re.exec(flat))) { var d = day(m[1]); if (d > best) best = d; }
    if (best) return best;
    var s = new RegExp('(?:statement\\s+date|date\\s+of\\s+statement|generated\\s+on)\\s*[:\\-]?\\s*(' + DATE_SRC + ')', 'i').exec(flat);
    return s ? day(s[1]) : '';
  }
  function loan(text, from, title, flat) {
    var lines = linesOf(text);
    var head = (lines.slice(0, 12).join(' ') + ' ' + title).toLowerCase();
    var name = /home\s+loan|housing\s+loan|home\s+finance|mortgage/.test(head) ? 'Home loan' : /car\s+loan|auto\s+loan|vehicle\s+loan|two[\s\-]wheeler/.test(head) ? 'Car loan'
      : /personal\s+loan/.test(head) ? 'Personal loan' : /home\s+loan|housing\s+loan/i.test(flat) ? 'Home loan' : /car\s+loan|auto\s+loan|vehicle\s+loan/i.test(flat) ? 'Car loan' : /personal\s+loan/i.test(flat) ? 'Personal loan' : 'Loan';
    function amtOf(F) { var h = first(lines, F, 'amt', 'last'); return h ? Math.abs(h.v) : 0; }
    var outs = hits(lines, LN.out, 'amt', 'last'), open = first(lines, LN.open, 'amt', 'last');
    var dated = outs.filter(function (h) { return day(h.rest); }).sort(function (x, y) { return day(x.rest) < day(y.rest) ? -1 : 1; });
    var opening = open ? Math.abs(open.v) : 0, closing = 0;
    if (dated.length) closing = Math.abs(dated[dated.length - 1].v); else if (outs.length) closing = Math.abs(outs[0].v);
    // "Principal outstanding as on 01-Apr" and "… as on 30-Sep": the earlier is the opening
    if (!opening && dated.length >= 2 && day(dated[0].rest) < day(dated[dated.length - 1].rest)) opening = Math.abs(dated[0].v);
    var paidP = amtOf(LN.paidP), paidI = amtOf(LN.paidI), emi = amtOf(LN.emi);
    var rate = first(lines, LN.rate, 'pct'), left = first(lines, LN.left, 'text'), next = first(lines, LN.next, 'date'), no = first(lines, LN.no, 'text');
    var asOf = loanAsOf(flat), sch = schedule(lines);
    var x = { outstanding: closing, emi: emi, rate: rate ? rate.v : 0, tenureLeft: left ? months(left.v) : 0, nextDue: next ? next.v : '', paidPrincipal: paidP, paidInterest: paidI };
    if (sch) {
      var rows = sch.rows, paid = asOf ? rows.filter(function (r) { return r.date <= asOf; }) : null;
      var ahead = asOf ? rows.filter(function (r) { return r.date > asOf; }) : null;
      var full = !asOf && Math.abs(rows[rows.length - 1].close) <= 1;   // a whole schedule, issued at the start
      if (!asOf && !full) { paid = rows; ahead = []; }
      if (full) { paid = []; ahead = rows; }
      if (!x.outstanding) x.outstanding = paid.length ? paid[paid.length - 1].close : rows[0].open;
      if (!x.emi) x.emi = (ahead[0] || rows[rows.length - 1]).emi;
      if (!x.tenureLeft && ahead.length) x.tenureLeft = ahead.length;
      if (!x.nextDue && ahead.length) x.nextDue = ahead[0].date;
      if (!x.paidPrincipal && paid.length) x.paidPrincipal = r2(sum(paid, function (r) { return r.prin; }));
      if (!x.paidInterest && paid.length) x.paidInterest = r2(sum(paid, function (r) { return r.int; }));
    }
    if (!x.outstanding && !x.emi && !sch && !opening) return empty();
    // the check
    var check;
    if (opening && paidP && closing) {
      var want = r2(opening - paidP), ok = Math.abs(want - closing) <= 1;
      check = { ok: ok, read: want, stated: r2(closing), note: 'Opening principal ' + rs(opening) + ' less ' + rs(paidP) + ' repaid is ' + rs(want) + (ok ? ', the closing principal printed' : ', but the closing principal printed is ' + rs(closing)) };
    } else if (sch) {
      var bad = sch.rows.filter(function (r) { return !r.ok; }), rs0 = sch.rows, firstOpen = rs0[0].open, lastClose = rs0[rs0.length - 1].close;
      var w2 = r2(firstOpen - sum(rs0, function (r) { return r.prin; })), ok2 = !bad.length && !sch.broken && Math.abs(w2 - lastClose) <= 1 + 0.01 * rs0.length;
      check = { ok: ok2, read: w2, stated: r2(lastClose), note: ok2 ? rs0.length + ' instalments: their principal takes the balance from ' + rs(firstOpen) + ' to ' + rs(lastClose) + ', and every row adds up'
        : bad.length ? 'The instalment of ' + fmtDay(bad[0].date) + ' doesn\'t add up' : sch.broken ? sch.broken + ' schedule row(s) couldn\'t be read' : 'The principal repaid doesn\'t take the balance from ' + rs(firstOpen) + ' to ' + rs(lastClose) };
    } else if (x.emi && x.outstanding && x.rate && x.tenureLeft) {
      var std = r2(stdEmi(x.outstanding, x.rate, x.tenureLeft)), ok3 = Math.abs(std - x.emi) <= x.emi * 0.02;
      check = { ok: ok3, read: std, stated: r2(x.emi), note: rs(x.outstanding) + ' at ' + x.rate + '% over ' + x.tenureLeft + ' months is an EMI of ' + rs(std) + (ok3 ? ', in line with the ' + rs(x.emi) + ' printed' : ', not the ' + rs(x.emi) + ' printed') };
    } else check = { ok: false, read: 0, stated: 0, note: 'Not enough figures printed to check this loan (it needs opening and closing principal, a schedule, or EMI, rate and tenure)' };
    return {
      kind: 'loan', holdings: [],
      loans: [{ bank: bankOf(from, lines), name: name, last4: last4(no && no.v), outstanding: r2(x.outstanding), emi: r2(x.emi), rate: x.rate, tenureLeft: x.tenureLeft,
                nextDue: x.nextDue, asOf: asOf, paidPrincipal: r2(x.paidPrincipal), paidInterest: r2(x.paidInterest) }],
      check: check
    };
  }

  /* ------------------------------------------------------------ 4. NPS
     A CRA statement (Protean, KFintech, CAMS) lists each pension fund scheme's units, NAV and value, per tier, and
     the tier's (or the account's) total. A scheme row is where units × NAV = value. A "Total" line totals the rows
     since the last total: one tier's, or both when the table mixes them. */
  function triple(ns) {
    var best = null;
    for (var i = 0; i < ns.length; i++) for (var j = i + 1; j < ns.length; j++) for (var k = j + 1; k < ns.length; k++) {
      var a = ns[i], b = ns[j], v = ns[k];
      if (a > 0 && b > 0 && v >= 1 && Math.abs(a * b - v) <= Math.max(1, v * 0.003)) best = { a: a, b: b, v: v };
    }
    return best;
  }
  function tierOf(s) { return /\btier[\s\-]*(?:ii|2)\b/i.test(s) ? 'II' : /\btier[\s\-]*(?:i|1)\b/i.test(s) ? 'I' : ''; }
  function nps(text, from, title, flat) {
    var lines = linesOf(text);
    var tiers = {}, order = [], cur = '', pending = [], grand = null, grandLabel = null, docCost = 0, sumHead = null, unitsFirst = true;
    function T(t) { if (!tiers[t]) { tiers[t] = { schemes: [], total: null, summary: null, label: null, cost: 0 }; order.push(t); } return tiers[t]; }
    lines.forEach(function (line) {
      var cs = cells(line);
      if (!cs.length) return;
      var ns = [], words = [];
      cs.forEach(function (c) { var a = amt(c); if (a) ns.push(a.v); else words.push(c); });
      var t = tierOf(line), c0 = cs[0].replace(LIST_MARK, '');
      if (!ns.length) {
        if (/units?/i.test(line) && /\bnav\b/i.test(line)) unitsFirst = line.search(/units?/i) < line.search(/\bnav\b/i);
        if (/contribution/i.test(line) && /value|valuation|holding/i.test(line) && cs.length >= 3) {
          sumHead = cs.slice(1).map(function (h) { return /contribution/i.test(h) ? 'cost' : /value|valuation|holding/i.test(h) ? 'value' : ''; });
        } else if (t) cur = t;
        return;
      }
      // a tier's row in a summary table: Tier I | contribution | value | gain
      if (/^tier\b/i.test(c0) && t && sumHead) {
        var off = sumHead.length - ns.length;
        ns.forEach(function (v, k) { var role = sumHead[k + off]; if (role === 'value') T(t).summary = v; else if (role === 'cost') T(t).cost = v; });
        return;
      }
      var tr = ns.length >= 3 ? triple(ns) : null, head = words.join(' ');
      if (tr && /[a-z]{3,}/i.test(head) && /scheme|fund|pension|nps|trust|plan|tier/i.test(head) && !/^(?:grand\s+)?(?:sub\s*)?total\b/i.test(c0)) {
        var at = t || cur || 'I';
        T(at).schemes.push({ name: trim(head.replace(/\s*[-–]?\s*tier[\s\-]*(?:ii|i|1|2)\b/ig, '')).slice(0, 80), units: r4(unitsFirst ? tr.a : tr.b), nav: r4(unitsFirst ? tr.b : tr.a), value: r2(tr.v) });
        pending.push(at);
        return;
      }
      if (/^(?:grand\s+)?(?:sub\s*)?total\b/i.test(c0) && !/contribution|units?\b|withdraw|charge|switch|redemption|gain|loss/i.test(c0)) {
        var v = ns[ns.length - 1], ts = pending.filter(function (x, k) { return pending.indexOf(x) === k; });
        if (/grand/i.test(c0) || ts.length > 1 || (!ts.length && !t)) grand = v;
        else T(ts.length ? ts[0] : t).total = v;
        pending = [];
        return;
      }
      if (/^(?:total\s+)?contributions?\b|^amount\s+contributed/i.test(c0)) { if (t || cur) T(t || cur).cost = Math.abs(ns[ns.length - 1]); else docCost = Math.abs(ns[ns.length - 1]); return; }
      if (/^(?:value\s+of\s+(?:your\s+)?holdings?|total\s+holding\s+value|current\s+valuation|current\s+value|total\s+value)/i.test(c0)) {
        if (t || cur) T(t || cur).label = ns[ns.length - 1]; else grandLabel = ns[ns.length - 1];
        return;
      }
      if (t) cur = t;
    });
    var live = order.filter(function (t) { return tiers[t].schemes.length || tiers[t].summary != null; });
    if (!live.length) return empty();
    var pran = /\bPRAN\b\s*(?:no\.?|number)?\s*[:\-]?\s*(\d{12})\b/i.exec(flat);
    var asOf = (function () {
      var m = new RegExp('\\bas\\s+(?:on|of|at)\\s*[:\\-]?\\s*(' + DATE_SRC + ')', 'i').exec(flat) || new RegExp('statement\\s+date\\s*[:\\-]?\\s*(' + DATE_SRC + ')', 'i').exec(flat);
      if (m) return day(m[1]);
      var p = periodRe('(?:statement\\s+)?period').exec(flat);
      return p ? day(p[2]) : '';
    })();
    var compared = [], holdings = [];
    live.forEach(function (t) {
      var x = tiers[t], s = r2(sum(x.schemes, function (y) { return y.value; }));
      var stated = x.total != null ? x.total : x.summary != null ? x.summary : x.label;
      if (stated == null && live.length === 1) stated = grand != null ? grand : grandLabel;
      if (x.schemes.length && stated != null) compared.push({ t: t, read: s, stated: stated });
      holdings.push({ bank: 'NPS · Tier ' + t, type: 'NPS', cls: 'ret', amt: r2(stated != null ? stated : s), units: r4(sum(x.schemes, function (y) { return y.units; })),
                      asOf: asOf, cost: r2(x.cost || (live.length === 1 ? docCost : 0)), last4: pran ? pran[1].slice(-4) : '', schemes: x.schemes });
    });
    // a total under a table that mixes both tiers is checked too, as is the account's value when no tier has its own
    var both = live.length > 1 ? (grand != null ? grand : !compared.length ? grandLabel : null) : null;
    if (both != null) compared.push({ t: 'both tiers', read: r2(sum(live, function (t) { return sum(tiers[t].schemes, function (y) { return y.value; }); })), stated: both });
    var bad = compared.filter(function (c) { return Math.abs(c.read - c.stated) > 1; });
    function who(c) { return c.t === 'both tiers' ? 'Schemes in both tiers' : 'Tier ' + c.t + ' schemes'; }
    var note = !compared.length ? 'No total printed to check the schemes against'
      : bad.length ? who(bad[0]) + ' add up to ' + rs(bad[0].read) + ', but the total printed is ' + rs(bad[0].stated)
      : compared.map(function (c) { return who(c) + ' add up to the ' + rs(c.stated) + ' total printed'; }).join('; ');
    return { kind: 'nps', holdings: holdings,
             check: { ok: compared.length > 0 && !bad.length, read: r2(sum(compared, function (c) { return c.read; })), stated: r2(sum(compared, function (c) { return c.stated; })), note: note } };
  }

  /* ------------------------------------------------------------ 5. the EPF passbook (the EPFO's own PDF)
     One UAN holds a member ID for each job, and each member ID has a passbook of its own: an opening balance, a row
     for every month of wages (your share, your employer's, and the pension (EPS) part), the interest the EPFO credits
     once a financial year, and a closing balance. The whole history is read, not only the last figure: the passbook is
     the one paper that carries it, where the portal page carries today's totals alone.

     Each passbook states its own sum, so it is checked column by column: the opening balance, plus every month, plus
     every year's interest, is the closing balance it prints. A member ID whose columns don't come to its closing
     balance is read but never counted (check.ok false, and no holding of its own): one month misread would show as
     money the person doesn't have. Months with no closing balance under them aren't counted either — there is nothing
     printed to check them against.

     The pension (EPS) share stays out of the money: it buys a pension, it isn't a balance to draw. It is said in
     words beside the figure, as the portal reading already does. */
  // an EPF account written with slashes (HR/GGN/0012345/000/0012345), as a passbook's header prints it, reads as one id
  var EPF_SLASHED = /\b([A-Z]{2})\s*\/\s*([A-Z]{3})\s*\/\s*(\d{7})\s*\/\s*(\d{3})(?:\s*\/\s*(\d{7}))?\b/g;
  var EPF_ID = /\b([A-Z]{5}\d{14,17})\b/;
  /* the money on a passbook row: the wage month, the transaction date, the due-month code, the member ID, a para
     number and a rate taken out first, so the share columns are all that is left */
  function epfAmounts(l) {
    var s = String(l || '')
      .replace(/\b\d{1,2}[-\/.]\d{1,2}[-\/.]\d{2,4}\b/g, ' ')
      .replace(/\b[A-Za-z]{3,9}[-\s\/]?\d{4}\b/g, ' ')
      .replace(/\b(?:0[1-9]|1[0-2])[-\/]?20\d{2}\b/g, ' ')
      .replace(/\b[A-Z]{5}\d{7,17}\b/g, ' ')
      .replace(/\bpara\s*[\dA-Za-z()]+/gi, ' ')
      .replace(/\d+(?:\.\d+)?\s*%/g, ' ');
    var out = [];
    (s.match(/-?\d[\d,]*(?:\.\d{1,2})?/g) || []).forEach(function (x) { var a = amt(x); if (a) out.push(a.v); });
    return out;
  }
  /* a row's three share figures: the employee's, the employer's and the pension (EPS) part. A layout that prints a
     total column prints it last and it is exactly the sum, so it is dropped rather than read as a share; a figure
     before the shares (the month's wages) is dropped from the front. */
  function epfShares(ns) {
    var v = ns.slice();
    while (v.length > 3) {
      var last = v[v.length - 1], rest = v.slice(0, v.length - 1);
      if (Math.abs(last - sum(rest.slice(-3))) <= 1 || Math.abs(last - sum(rest.slice(-2))) <= 1) v.pop();
      else v.shift();
    }
    if (v.length < 2) return null;
    return { ee: v[0], er: v[1], pen: v.length > 2 ? v[2] : 0 };
  }
  // "Apr-2023", "APR 2023", "04/2023", "2023-04" at the start of a row: the month of wages the row is for
  function epfWageMonth(l) {
    var m = /^\s*([A-Za-z]{3,9})[-\s\/]?(20\d{2})\b/.exec(l);
    if (m) { var n = monthNo(m[1]); if (n) return m[2] + '-' + pad(n); }
    m = /^\s*(20\d{2})[-\/](0[1-9]|1[0-2])\b/.exec(l);
    if (m) return m[1] + '-' + m[2];
    m = /^\s*(0?[1-9]|1[0-2])[-\/](20\d{2})\b/.exec(l);
    return m ? m[2] + '-' + pad(+m[1]) : '';
  }
  /* the rows that say what a block of months comes to, not what one month moved: a passbook puts "OB", "Total" and
     "Closing Balance" in its transaction-type column, so they are looked for in a cell of their own as well as at
     the start of the line */
  function epfRow(l, word) {
    return new RegExp('(?:^|\\s{3,}|\\t)(?:' + word + ')(?![a-z])', 'i').test(l);
  }
  function epfCol(c) { return c === 'ee' ? 'your share' : c === 'er' ? 'your employer’s share' : 'the pension (EPS) share'; }
  var EPF_COLS = ['ee', 'er', 'pen'];
  /* every financial year of the passbook: what went in that year (by the month the wages were for, which is how the
     EPFO reckons a year) and the interest credited at its end */
  function epfYears(m) {
    var by = {}, order = [];
    function Y(fy) {
      if (!by[fy]) { by[fy] = { fy: fy, ee: 0, er: 0, pen: 0, trf: 0, interest: 0, months: 0 }; order.push(fy); }
      return by[fy];
    }
    m.months.forEach(function (x) {
      var fy = x.m ? fyOf(x.m + '-01') : x.d ? fyOf(x.d) : '';
      if (!fy) return;
      var y = Y(fy);
      y.ee += x.ee; y.er += x.er; y.pen += x.pen;
      // a previous job's balance arriving isn't a year's saving: kept apart so no year counts it as one
      if (x.k === 'trf') y.trf += x.ee + x.er;
      if (x.k === 'cont') y.months++;
    });
    m.ints.forEach(function (x) { if (x.fy) Y(x.fy).interest += x.ee + x.er; });
    return order.sort().map(function (k) {
      var y = by[k];
      return { fy: y.fy, ee: r2(y.ee), er: r2(y.er), pen: r2(y.pen), trf: r2(y.trf), interest: r2(y.interest), months: y.months };
    });
  }
  function epf(text, from, title, flat) {
    var t = String(text || '').replace(/\r/g, '').replace(/ /g, ' ').replace(EPF_SLASHED, function (_, a, b, c, d, e) { return a + b + c + d + (e || ''); });
    var lines = t.split('\n');
    var uan = (/\b(?:uan|universal\s+account\s+(?:no\.?|number))\b[^0-9A-Za-z]{0,12}(\d{12})\b/i.exec(t) || [])[1] || '';
    var mem = {}, order = [], cur = '';
    function M(id) {
      if (!mem[id]) {
        mem[id] = { memberId: id, establishment: '', joined: '', left: '', asOf: '', open: null, close: null, months: [], ints: [] };
        order.push(id);
      }
      return mem[id];
    }
    var EST = /^(?:est(?:ablishment)?\.?\s*(?:id\s*(?:\/|and)?\s*)?name|establishment|employer(?:'s)?\s+name|company\s+name)\b\s*[:\-]?\s*/i;
    lines.forEach(function (raw) {
      var l = trim(raw);
      if (!l) return;
      var idm = EPF_ID.exec(l);
      if (idm) { cur = idm[1]; M(cur); }
      var d = day(l);
      var est = EST.exec(l);
      if (est && cur) {
        var name = trim(l.slice(est[0].length).replace(/^[A-Z]{5}\d{7,17}\s*[\/\-|]?\s*/, '').split(/\s{3,}|\t/)[0]);
        if (name && /[A-Za-z]{3}/.test(name)) mem[cur].establishment = nameCase(name).slice(0, 80);
        return;
      }
      if (!cur) return;
      var m = mem[cur];
      if (/^(?:date\s+of\s+joining|joining\s+date|doj)\b/i.test(l)) { if (d) m.joined = d; return; }
      if (/^(?:date\s+of\s+exit|exit\s+date|doe)\b/i.test(l)) { if (d) m.left = d; return; }
      // a year's own totals repeat the rows above them
      if (epfRow(l, 'grand\\s+total|sub\\s*total|total')) return;
      var sh = epfShares(epfAmounts(l));
      if (!sh) return;
      if (/opening\s+balance/i.test(l) || epfRow(l, 'ob')) { m.open = sh; return; }
      if (/closing\s+balance/i.test(l) || epfRow(l, 'cb\\s+as\\s+on')) { m.close = sh; if (d) m.asOf = d; return; }
      // the interest the EPFO credits once a financial year, dated that year's last day
      if (/\bint(?:erest)?\.?\b/i.test(l) && !/^(?:rate|roi)\b/i.test(l)) {
        m.ints.push({ d: d, fy: d ? fyOf(d) : '', ee: sh.ee, er: sh.er, pen: sh.pen });
        if (d > m.asOf) m.asOf = d;
        return;
      }
      var wm = epfWageMonth(l);
      if (!wm && !/\b(?:cr|dr)\b|cont\.?\s*for|due[\s\-]?month|transfer|\btrf\b|claim|withdraw|settle|advance/i.test(l)) return;
      // money out (a claim, a withdrawal, a transfer to the next job) counts against the columns
      var out = /\bdr\b|claim|withdraw|settle|advance|refund|trf[\s\-]?out|transfer[\s\-]?out/i.test(l) && !/\bcr\b/i.test(l);
      var trf = !out && /transfer|\btrf\b|previous\s+(?:employer|member|account)/i.test(l);
      m.months.push({ m: wm, d: d, ee: out ? -sh.ee : sh.ee, er: out ? -sh.er : sh.er, pen: out ? -sh.pen : sh.pen,
                      k: out ? 'out' : trf ? 'trf' : 'cont' });
      if (d > m.asOf) m.asOf = d;
    });
    var live = order.filter(function (id) { return mem[id].months.length || mem[id].close; });
    if (!live.length) return empty();
    var holdings = [], members = [], notes = [], bad = 0, read = 0, stated = 0, asOf = '';
    live.forEach(function (id) {
      var m = mem[id];
      var open = m.open || { ee: 0, er: 0, pen: 0 };
      var sums = {};
      EPF_COLS.forEach(function (c) {
        sums[c] = r2(open[c] + sum(m.months, function (x) { return x[c]; }) + sum(m.ints, function (x) { return x[c]; }));
      });
      var whose = m.establishment || 'Member ID ••' + id.slice(-5);
      var off = m.close ? EPF_COLS.filter(function (c) { return Math.abs(sums[c] - m.close[c]) > 1; }) : [];
      var ok = !!m.close && !off.length;
      var trfIn = r2(sum(m.months.filter(function (x) { return x.k === 'trf' && x.ee + x.er > 0; }), function (x) { return x.ee + x.er; }));
      var one = { memberId: id, establishment: m.establishment, uan: uan, joined: m.joined, left: m.left, asOf: m.asOf,
                  open: open, close: m.close || null, months: m.months, years: epfYears(m), rows: m.months.length,
                  trfIn: trfIn, ok: ok };
      members.push(one);
      if (!ok) {
        bad++;
        notes.push(whose + ': ' + (m.close
          ? epfCol(off[0]) + ' comes to ' + rs(sums[off[0]]) + ' where its closing balance prints ' + rs(m.close[off[0]])
          : m.months.length + (m.months.length === 1 ? ' month read, but no closing balance printed to check it against'
                                                     : ' months read, but no closing balance printed to check them against')));
        return;
      }
      read = r2(read + sums.ee + sums.er);
      stated = r2(stated + m.close.ee + m.close.er);
      if (m.asOf > asOf) asOf = m.asOf;
      notes.push(whose + ': its opening balance, every month and every year’s interest come to the ' + rs(m.close.ee + m.close.er) + ' it closes on');
      var bits = ['your share ' + rs(m.close.ee), 'your employer’s ' + rs(m.close.er)];
      if (m.close.pen > 0) bits.push('pension (EPS) ' + rs(m.close.pen) + ' on top, which this figure leaves out');
      holdings.push({ bank: 'EPF · ' + (m.establishment || ('Member ID ••' + id.slice(-5))), type: 'EPF', cls: 'ret',
                      amt: r2(m.close.ee + m.close.er), rem: bits.join(' · '), asOf: m.asOf,
                      last4: uan ? uan.slice(-4) : id.slice(-4), memberId: id });
    });
    return { kind: 'epf', holdings: holdings, facts: [], asOf: asOf, epf: { uan: uan, members: members },
             check: { ok: holdings.length > 0 && !bad, read: read, stated: stated, note: notes.join('; ') } };
  }

  /* ------------------------------------------------------------ 6. tax papers
     Form 16 (Part A: TDS by quarter; Part B: the salary), Form 16A (TDS on other income, from a bank or company),
     a bank's interest certificate (interest per deposit and the total) and a broker's or fund house's capital-gains
     statement (gains per sale, short and long term, and the totals). Each is checked against its own totals. */
  function fyFrom(flat) {
    var m = /\b(?:financial\s+year|f\.?\s?y\.?)\s*[:\-]?\s*(20\d{2})\s*[-–\/]\s*(\d{4}|\d{2})\b/i.exec(flat);
    if (m && (+m[2] === +m[1] + 1 || +m[2] === (+m[1] + 1) % 100)) return fyStr(+m[1]);
    m = /\b(?:assessment\s+year|a\.?\s?y\.?)\s*[:\-]?\s*(20\d{2})\s*[-–\/]\s*(\d{4}|\d{2})\b/i.exec(flat);
    if (m && (+m[2] === +m[1] + 1 || +m[2] === (+m[1] + 1) % 100)) return fyStr(+m[1] - 1);
    var p = periodRe('(?:period|from)').exec(flat);
    return p && day(p[1]) ? fyOf(day(p[1])) : '';
  }
  // who issued it: "Name and address of the Employer" with the name after it, or below it in the same column
  function partyAfter(lines, re) {
    for (var li = 0; li < lines.length; li++) {
      var cs = cells(lines[li]);
      for (var ci = 0; ci < cs.length; ci++) {
        var m = re.exec(cs[ci]);
        if (!m) continue;
        var rest = trim(cs[ci].slice(m.index + m[0].length).replace(/^[\s:.\-–]+/, ''));
        if (rest && /[a-z]{3,}/i.test(rest)) return cleanCo(rest);
        var nx = cells(lines[li + 1] || '');
        if (nx.length) return cleanCo(nx[Math.min(ci, nx.length - 1)]);
      }
    }
    return '';
  }
  // Part A's (and 16A's) quarter table: Q1..Q4 rows and their total
  function quarters(lines) {
    var rows = [], total = null, hasPaid = false;
    for (var li = 0; li < lines.length; li++) {
      var cs = cells(lines[li]);
      if (!cs.length) continue;
      var h = cs.join(' ');
      if (!rows.length && /quarter/i.test(h) && /tax\s+deducted|amount\s+of\s+tax/i.test(h)) hasPaid = /paid\s*\/?\s*credited|amount\s+paid/i.test(h);
      var isQ = /^q(?:uarter)?\s*[-–]?\s*[1-4]$/i.test(cs[0]) || /^q[1-4]\b/i.test(cs[0]);
      if (!isQ && !(rows.length && !total && /^total\b/i.test(cs[0]))) continue;
      var ns = numbersOf(cs, 1).map(function (x) { return Math.abs(x.v); });
      if (!ns.length) continue;
      var r = ns.length >= 3 ? { paid: ns[ns.length - 3], tds: ns[ns.length - 2], dep: ns[ns.length - 1] }
        : ns.length === 2 ? (hasPaid ? { paid: ns[0], tds: ns[1], dep: 0 } : { paid: 0, tds: ns[0], dep: ns[1] }) : { paid: 0, tds: ns[0], dep: 0 };
      if (isQ) rows.push(r); else total = r;
    }
    return { rows: rows, total: total };
  }
  var NAME_OF = /name\s+(?:and\s+address\s+)?of\s+(?:the\s+)?(?:employer|deductor)(?:\s*\/\s*specified\s+bank)?/i;
  function form16(lines, flat, from, isA) {
    var q = quarters(lines), fy = fyFrom(flat);
    var payer = partyAfter(lines, NAME_OF) || (isA ? bankOf(from, lines) : employerOf(lines, from));
    var fact = { k: isA ? 'tds' : 'form16', fy: fy, payer: payer, amount: 0, tds: 0, stcg: 0, ltcg: 0 }, check;
    if (isA) {
      // 16A's "Summary of payment": the total paid or credited
      var from0 = -1;
      for (var i = 0; i < lines.length; i++) {
        if (/summary\s+of\s+payment/i.test(lines[i])) from0 = i;
        else if (from0 >= 0 && /summary\s+of\s+tax/i.test(lines[i])) break;
        else if (from0 >= 0 && /^total\b/i.test(cells(lines[i])[0] || '')) { var tn = numbersOf(cells(lines[i]), 1); if (tn.length) fact.amount = Math.abs(tn[0].v); break; }
      }
    }
    if (q.rows.length) {
      var sumT = r2(sum(q.rows, function (r) { return r.tds; })), sumP = r2(sum(q.rows, function (r) { return r.paid; }));
      if (!fact.amount) fact.amount = q.total && q.total.paid ? q.total.paid : sumP;
      if (q.total) {
        fact.tds = q.total.tds;
        var okT = Math.abs(sumT - q.total.tds) <= 1, okP = !q.total.paid || !sumP || Math.abs(sumP - q.total.paid) <= 1;
        check = { ok: okT && okP, read: sumT, stated: q.total.tds,
                  note: okT && okP ? 'TDS for ' + q.rows.length + ' quarter(s) adds up to the ' + rs(q.total.tds) + ' total printed'
                    : !okT ? 'TDS by quarter adds up to ' + rs(sumT) + ', but the total printed is ' + rs(q.total.tds) : 'Amounts paid by quarter add up to ' + rs(sumP) + ', but the total printed is ' + rs(q.total.paid) };
      } else {
        fact.tds = sumT;
        check = { ok: false, read: sumT, stated: 0, note: 'TDS by quarter read, but no total printed to check it against' };
      }
    } else if (!isA) {
      // Part B alone: the gross salary, which must read the same wherever it's printed
      var gs = hits(lines, label('gross\\s+salary|salary\\s+as\\s+per\\s+provisions\\s+contained\\s+in\\s+section\\s+17\\s*\\(\\s*1\\s*\\)'), 'amt');
      var tx = first(lines, label('total\\s+tax\\s+deducted|tax\\s+deducted(?:\\s+at\\s+source)?|net\\s+tax\\s+payable|tax\\s+payable'), 'amt', 'last');
      if (!gs.length) return null;
      var g0 = Math.abs(gs[0].v), same = gs.every(function (h) { return Math.abs(Math.abs(h.v) - g0) <= 1; });
      fact.amount = g0; fact.tds = tx ? Math.abs(tx.v) : 0;
      check = { ok: same, read: g0, stated: g0, note: same ? 'Gross salary ' + rs(g0) + ' read from Part B' + (gs.length > 1 ? ', the same everywhere it is printed' : '') + '; there is no quarterly TDS table to cross-check'
        : 'Gross salary is printed as both ' + rs(g0) + ' and ' + rs(Math.abs(gs[gs.length - 1].v)) };
    } else return null;
    fact.amount = r2(fact.amount); fact.tds = r2(fact.tds);
    return { facts: [fact], check: check };
  }
  function interestCert(lines, flat, from) {
    var hi = -1, cols = [];
    for (var i = 0; i < lines.length; i++) {
      var cs = cells(lines[i]);
      if (cs.length >= 2 && !numbersOf(cs).length && cs.some(function (c) { return /interest/i.test(c) && !/rate/i.test(c); })) {
        hi = i;
        cols = cs.map(function (c) {
          return /tds|tax\s+deducted/i.test(c) ? 'tds' : /interest/i.test(c) && !/rate/i.test(c) ? 'int' : /rate|roi|%/i.test(c) ? 'rate'
            : /principal|deposit\s+amount|balance|amount\s+of\s+deposit/i.test(c) ? 'prin' : '';
        }).filter(function (c) { return c; });
        break;
      }
    }
    var rows = [], total = null;
    if (hi >= 0) for (var j = hi + 1; j < lines.length; j++) {
      var rc = cells(lines[j]), ns = numbersOf(rc, 1).map(function (x) { return Math.abs(x.v); });
      if (!rc.length || !ns.length) continue;
      // right-aligned: the last figure is the last column's
      var r = {}, off = cols.length - ns.length;
      ns.forEach(function (v, k) { if (cols[k + off]) r[cols[k + off]] = v; });
      if (/^(?:grand\s+)?total\b/i.test(rc[0])) { total = r; break; }
      if (r.int != null) rows.push(r);
    }
    var fact = { k: 'interest', fy: fyFrom(flat), payer: bankOf(from, lines), amount: 0, tds: 0, stcg: 0, ltcg: 0 }, check;
    var sumI = r2(sum(rows, function (r) { return r.int; })), sumT = r2(sum(rows, function (r) { return r.tds; }));
    if (rows.length && total && total.int != null) {
      fact.amount = total.int; fact.tds = total.tds != null ? total.tds : sumT;
      var okI = Math.abs(sumI - total.int) <= 1, okT = total.tds == null || Math.abs(sumT - total.tds) <= 1;
      check = { ok: okI && okT, read: sumI, stated: total.int, note: okI && okT ? 'Interest on ' + rows.length + ' deposit(s) adds up to the ' + rs(total.int) + ' total printed'
        : !okI ? 'Interest per deposit adds up to ' + rs(sumI) + ', but the total printed is ' + rs(total.int) : 'TDS per deposit adds up to ' + rs(sumT) + ', but the total printed is ' + rs(total.tds) };
    } else {
      var ti = hits(lines, label('total\\s+interest(?:\\s+(?:paid|credited|earned|accrued))?|interest\\s+(?:paid|credited|earned)(?:\\s+during\\s+the\\s+(?:year|period))?'), 'amt');
      var tt = first(lines, label('total\\s+tds|tds\\s+(?:deducted|amount)|total\\s+tax\\s+deducted|tax\\s+deducted(?:\\s+at\\s+source)?'), 'amt');
      if (!ti.length && !rows.length) return null;
      if (!ti.length) { fact.amount = sumI; fact.tds = sumT; check = { ok: false, read: sumI, stated: 0, note: 'Interest per deposit read, but no total printed to check it against' }; }
      else {
        var t0 = Math.abs(ti[0].v), same = ti.every(function (h) { return Math.abs(Math.abs(h.v) - t0) <= 1; });
        fact.amount = t0; fact.tds = tt ? Math.abs(tt.v) : 0;
        check = { ok: same, read: t0, stated: t0, note: same ? 'One total read, ' + rs(t0) + ' of interest; there are no per-deposit lines to cross-check' : 'The total interest is printed as both ' + rs(t0) + ' and ' + rs(Math.abs(ti[ti.length - 1].v)) };
      }
    }
    fact.amount = r2(fact.amount); fact.tds = r2(fact.tds);
    return { facts: [fact], check: check };
  }
  function gainsStmt(lines, flat, from) {
    var sect = '', rows = [], pending = [], tot = { st: [], lt: [], all: [] }, outside = [];
    var TERM_CELL = /^(?:st|lt|stcg|ltcg|stcl|ltcl|short(?:[\s\-]*term)?|long(?:[\s\-]*term)?)$/i;
    // gains-4nov: the gain is the figure that is a sale price less its cost (less expenses) on the row, wherever its
    // column sits (a computation prints actual cost and FMV after it); else the row's last figure
    function gainOf(ns) {
      var v = ns.map(function (n) { return n.v; });
      for (var a = 0; a < v.length; a++) for (var b = 0; b < v.length; b++) {
        if (a === b || !(v[a] > 0) || !(v[b] > 0)) continue;
        for (var c = 0; c < v.length; c++) {
          if (c === a || c === b || v[c] === 0) continue;
          if (Math.abs(v[a] - v[b] - v[c]) <= Math.max(1, v[a] * 0.0005)) return v[c];
        }
      }
      return v[v.length - 1];
    }
    function termOf(s) { return /\b(?:short[\s\-]*term|stcg|stcl)\b/i.test(s) ? 'st' : /\b(?:long[\s\-]*term|ltcg|ltcl)\b/i.test(s) ? 'lt' : ''; }
    lines.forEach(function (line) {
      // gains-4nov: figures a single space apart ("24/02/2026 3,46,348.69 2,92,852.48") are cells of their own
      var cs = [].concat.apply([], cells(line).map(function (c) { return /^[\d,.\/\-]+(?: [\d,.\/\-]+)+$/.test(c) ? c.split(' ').map(function (x) { return x.replace(/(\d)\.$/, '$1'); }) : [c]; }));
      if (!cs.length) return;
      var c0 = cs[0].replace(LIST_MARK, ''), ns = numbersOf(cs), th = termOf(c0);
      // gains-4nov: a heading of another kind of income ends the gains section
      if (!ns.length && !th && /^[A-Z][A-Z\s\-\/&().,]{12,}$/.test(c0) && !/gain|loss|profit|sale|purchase|securit|name|date|total/i.test(c0)) sect = '';
      if (!ns.length) { if (th) sect = th; return; }
      var isTotal = /^(?:grand\s+)?(?:sub[\s\-]*)?total\b/i.test(c0) || (th && /gain|loss|profit/i.test(c0) && cs.length <= 3) || /^net\s+(?:capital\s+)?gain/i.test(c0);
      if (isTotal) {
        var v = ns.length >= 3 ? gainOf(ns) : ns[ns.length - 1].v, ts = pending.filter(function (x, k) { return pending.indexOf(x) === k; });
        var t = th || (/grand|net|capital\s+gains?\s*$/i.test(c0) ? 'all' : ts.length === 1 && ts[0] !== 'na' ? ts[0] : 'all');
        tot[t].push(v);
        if (t === 'all' && !sect && !ts.length) outside.push(v);   // gains-4nov
        if (!th || ts.length) pending = [];
        return;
      }
      var hasName = cs.some(function (c) { return /[a-z]{3,}/i.test(c) && !TERM_CELL.test(c) && !DATE_ONLY.test(c); });
      var hasDate = cs.some(function (c) { return DATE_ONLY.test(c) && day(c); });
      if ((!hasName && !(sect && hasDate && ns.length >= 3)) || ns.length < 2 || !(hasDate || ISIN.test(line) || ns.length >= 3)) return;   // gains-4nov: a sale row with no name, in a gains section
      var tc = cs.filter(function (c) { return TERM_CELL.test(c); })[0], term = tc ? termOf(tc.replace(/^st$/i, 'stcg').replace(/^lt$/i, 'ltcg')) : sect || 'na';
      rows.push({ term: term, gain: ns.length >= 3 ? gainOf(ns) : ns[ns.length - 1].v });
      pending.push(term);
    });
    // gains-4nov: in a paper with short- and long-term sections (an income computation), lines and totals outside them
    // (interest, salary, the tax worked out) are no gains
    if (rows.some(function (r) { return r.term === 'st' || r.term === 'lt'; })) {
      rows = rows.filter(function (r) { return r.term !== 'na'; });
      tot.all = tot.all.filter(function (v) { return outside.indexOf(v) < 0; });
    }
    if (!rows.length && !tot.st.length && !tot.lt.length && !tot.all.length) return null;
    var tol = rows.length > 10 ? 2 : 1, comps = [];
    function s(t) { return r2(sum(rows.filter(function (r) { return !t || r.term === t; }), function (r) { return r.gain; })); }
    if (rows.length) {
      tot.st.forEach(function (v) { comps.push({ what: 'Short-term', read: s('st'), stated: v }); });
      tot.lt.forEach(function (v) { comps.push({ what: 'Long-term', read: s('lt'), stated: v }); });
      tot.all.forEach(function (v) { comps.push({ what: 'All', read: s(''), stated: v }); });
    }
    var stcg = tot.st.length ? tot.st[0] : s('st'), ltcg = tot.lt.length ? tot.lt[0] : s('lt');
    var fact = { k: 'gains', fy: fyFrom(flat), payer: (L.institution && L.institution(from) ? L.institution(from).name : '') || employerOf(lines, ''), amount: r2(tot.all.length && !tot.st.length && !tot.lt.length ? tot.all[0] : stcg + ltcg), tds: 0, stcg: r2(stcg), ltcg: r2(ltcg) };
    var check;
    if (comps.length) {
      var bad = comps.filter(function (c) { return Math.abs(c.read - c.stated) > tol; });
      check = { ok: !bad.length, read: r2(sum(comps, function (c) { return c.read; })), stated: r2(sum(comps, function (c) { return c.stated; })),
                note: bad.length ? bad[0].what + ' gains per sale add up to ' + rs(bad[0].read) + ', but the total printed is ' + rs(bad[0].stated)
                  : 'Gains on ' + rows.length + ' sale(s) add up to the totals printed (short term ' + rs(stcg) + ', long term ' + rs(ltcg) + ')' };
    } else if (!rows.length) {
      var consistent = [tot.st, tot.lt, tot.all].every(function (l) { return l.every(function (v) { return Math.abs(v - l[0]) <= 1; }); });
      check = { ok: consistent, read: fact.amount, stated: fact.amount, note: consistent ? 'Totals read (short term ' + rs(stcg) + ', long term ' + rs(ltcg) + '); there are no per-sale lines to cross-check' : 'The totals printed don\'t agree with each other' };
    } else check = { ok: false, read: s(''), stated: 0, note: 'Gains per sale read, but no totals printed to check them against' };
    return { facts: [fact], check: check };
  }
  function taxKind(s) {
    if (/form\s*(?:no\.?\s*)?16\s*a\b/i.test(s)) return 'tds';
    if (/form\s*(?:no\.?\s*)?16\b(?!\s*a\b)/i.test(s)) return 'form16';
    if (/interest\s+certificate|certificate\s+of\s+interest|interest\s+(?:paid|earned)\s+certificate/i.test(s)) return 'interest';
    if (/capital\s+gains?|reali[sz]ed\s+(?:gain|profit)|tax\s+p\s*&\s*l|profit\s+(?:and|&)\s+loss\s+statement/i.test(s)) return 'gains';
    return '';
  }
  function tax(text, from, title, flat) {
    var lines = linesOf(text);
    var k = taxKind(lines.slice(0, 15).join(' ')) || taxKind(title) || taxKind(flat);
    var r = k === 'gains' ? gainsStmt(lines, flat, from) : k === 'interest' ? interestCert(lines, flat, from) : k ? form16(lines, flat, from, k === 'tds') : null;
    if (!r) return empty();
    r.kind = 'tax'; r.holdings = [];
    return r;
  }

  /* ------------------------------------------------------------ 6. contract notes
     A trade row carries Buy or Sell (B/S) in its own cell, then quantity, trade price and the rest: it is a trade
     when quantity × a rate on it is a figure further along (the net total). Its value is quantity × trade price.
     The levies come after, one line each (the last figure is the note's total column): brokerage, exchange and
     clearing charges, STT, SEBI fees, stamp duty, GST. Then what the client pays or receives. */
  var SIDE = /^(?:b|s|buy|sell|bought|sold|purchase|sale)$/i;
  var EXCH_CELL = /^(nse|bse)(?:[\s\-:]?(?:eq|cm|cash|capital\s+market))?$/i;
  var LEVIES = [
    ['brokerage', /^(?:taxable\s+value\s+of\s+supply\s*\(?\s*brokerage\s*\)?|(?:total\s+)?brokerage(?:\s+(?:charges?|amount))?)(?![a-z])/i],
    ['exch', /^(?:exchange\s+(?:transaction|txn|turnover)\s+charges?|(?:total\s+)?transaction\s+charges?|exchange\s+charges?|txn\s+charges?)/i],
    ['clearing', /^clearing\s+charges?/i],
    ['stt', /^(?:securities\s+transaction\s+tax|(?:total\s+)?stt)(?![a-z])/i],
    ['sebi', /^sebi\s+(?:turnover\s+)?(?:fees?|charges?)/i],
    ['stamp', /^stamp\s*duty/i],
    ['ipft', /^(?:ipft|investor\s+protection)/i],
    ['gst', /^(?:total\s+)?gst(?![a-z])|^goods\s+and\s+services\s+tax/i],
    ['cgst', /^cgst/i], ['sgst', /^sgst/i], ['igst', /^igst/i], ['utgst', /^utgst/i]
  ];
  var NET = label('net\\s+amount\\s+(?:receivable|payable|due)|net\\s+(?:receivable|payable)(?:\\s+amount)?|amount\\s+(?:receivable|payable)\\s+by\\s+(?:the\\s+)?client|net\\s+amount');
  function cleanSec(s) {
    return trim(String(s || '').replace(new RegExp(ISIN.source, 'g'), ' ').replace(/[(\[]\s*[)\]]/g, ' ').replace(/[\s\-–:\/|]+$/, '').replace(/^[\s\-–:\/|]+/, '')
      .replace(/\s*[-–]\s*(?:eq|be|bz)\s*$/i, '').replace(/\s+(?:eq|equity\s+shares?)\s*$/i, '')).slice(0, 80);
  }
  /* papers-4nov: one row per ISIN, a Buy block then a Sell block (quantity, average price, brokerage a share,
     price after brokerage, the side's total), then the net quantity and obligation, and no B/S cell. A side with
     a quantity is a trade when quantity x either price is that side's total. */
  function isinBlockTrades(cs) {
    var ii = -1;
    for (var k = 0; k < cs.length; k++) if (ISIN.test(cs[k])) { ii = k; break; }
    if (ii < 0) return null;
    var ns = numbersOf(cs, ii + 1);
    if (ns.length < 10) return null;
    var name = '';
    for (var c = ii; c < cs.length; c++) { if (/[a-z]{3,}/i.test(cs[c])) { var nm = cleanSec(cs[c]); if (nm.length > name.length) name = nm; } }
    var isin = ISIN.exec(cs[ii])[0], out = [];
    for (var s = 0; s < 2; s++) {
      var b = ns.slice(s * 5, s * 5 + 5).map(function (n) { return n.abs; });
      if (b.length < 5) return null;
      if (!(b[0] > 0)) { if (b[4] > 0.005) return null; continue; }
      if (b[0] !== Math.round(b[0] * 1000) / 1000) return null;
      var okp = [b[1], b[3]].some(function (p) { return p > 0 && Math.abs(b[0] * p - b[4]) <= Math.max(0.5, b[4] * 0.0005); });
      if (!okp) return null;
      out.push({ date: '', isin: isin, name: name, side: s === 0 ? 'buy' : 'sell', qty: b[0], price: r4(b[1]), value: r2(b[0] * b[1]), exch: '' });
    }
    return out.length ? out : null;
  }
  function tradeRow(cs) {
    var si = -1;
    for (var k = 0; k < cs.length; k++) if (SIDE.test(cs[k])) { si = k; break; }
    if (si < 0) return null;
    var ns = numbersOf(cs, si + 1);
    if (ns.length < 2) return null;
    var q = ns[0].abs, price = ns[1].abs;
    if (!(q > 0) || q !== Math.round(q) || !(price > 0)) return null;
    // a trade: quantity × the trade price (or the rate net of brokerage) is a figure further along the row
    var seen = false;
    for (var x = 1; x < ns.length && !seen; x++) for (var y = x + 1; y < ns.length; y++)
      if (ns[y].abs > 0 && Math.abs(q * ns[x].abs - ns[y].abs) <= Math.max(0.5, ns[y].abs * 0.0005)) { seen = true; break; }
    if (!seen) return null;
    var name = '', isin = '', date = '', exch = '';
    cs.forEach(function (c, i) {
      var mi = ISIN.exec(c);
      if (mi && !isin) isin = mi[0];
      if (DATE_ONLY.test(c) && day(c) && !date) { date = day(c); return; }
      var ex = EXCH_CELL.exec(c);
      if (ex) { exch = ex[1].toUpperCase(); return; }
      if (i === si || !/[a-z]{3,}/i.test(c)) return;
      var nm = cleanSec(c);
      if (nm.length > name.length) name = nm;
    });
    var pre = /^(NSE|BSE)\s*:/i.exec(name);
    if (pre) { exch = exch || pre[1].toUpperCase(); name = trim(name.slice(pre[0].length)); }
    return { date: date, isin: isin, name: name, side: /^(?:b|buy|bought|purchase)$/i.test(cs[si]) ? 'buy' : 'sell', qty: q, price: r4(price), value: r2(q * price), exch: exch };
  }
  // which way the net amount goes: positive when the client pays
  function netSign(lab, a) {
    var l = String(lab || '').toLowerCase();
    if (a.dc === 'dr') return a.abs;
    if (a.dc === 'cr') return -a.abs;
    if (/receivable[^()]*\(\s*payable/.test(l)) return a.neg ? a.abs : -a.abs;
    if (/payable[^()]*\(\s*receivable/.test(l)) return a.neg ? -a.abs : a.abs;
    if (/payable/.test(l) && !/receivable/.test(l)) return a.neg ? -a.abs : a.abs;
    if (/receivable/.test(l) && !/payable/.test(l)) return a.neg ? a.abs : -a.abs;
    return null;
  }
  function contract(text, from, title, flat) {
    var lines = linesOf(text), trades = [], used = {}, sectExch = '', levy = {};
    var td = first(lines, label('trade\\s+date'), 'date');
    var ex0 = /\b(?:exchange|segment|market)\s*[:\-]?\s*(NSE|BSE)\b/i.exec(flat);
    lines.forEach(function (line, li) {
      var cs = cells(line);
      if (cs.length === 1 && EXCH_CELL.test(cs[0])) { sectExch = EXCH_CELL.exec(cs[0])[1].toUpperCase(); return; }
      var t = tradeRow(cs);
      if (!t) {   // papers-4nov
        var tb = isinBlockTrades(cs);
        if (!tb) return;
        used[li] = 1;
        tb.forEach(function (x) { x.date = td ? td.v : ''; x.exch = sectExch || (ex0 ? ex0[1].toUpperCase() : ''); x.block = 1; trades.push(x); });
        return;
      }
      used[li] = 1;
      t.date = t.date || (td ? td.v : '');
      t.exch = t.exch || sectExch || (ex0 ? ex0[1].toUpperCase() : '');
      trades.push(t);
    });
    if (!trades.length) return null;
    // papers-4nov-c: the per-ISIN summary is the note's trades; its annexure (each order, its brokerage) only details them
    if (trades.some(function (t) { return t.block; })) trades = trades.filter(function (t) { return t.block; }).map(function (t) { delete t.block; return t; });
    lines.forEach(function (line, li) {
      if (used[li]) return;
      var cs = cells(line);
      if (!cs.length) return;
      var c0 = cs[0].replace(LIST_MARK, '');
      for (var k = 0; k < LEVIES.length; k++) {
        var m = LEVIES[k][1].exec(c0);
        if (!m || levy[LEVIES[k][0]] != null) continue;
        var ns = numbersOf(cs, 1), rest0 = c0.slice(m[0].length).replace(/^\s*(?:\([^)]*\)\s*)+/, '');
        // papers-4nov-b: a footnote mark after "(₹)" ("CGST (@9% …) (₹)3") is no amount
        var v = ns.length ? ns[ns.length - 1] : /^\s*\d\s*$/.test(rest0) ? null : valueIn(rest0, 'amt');
        if (v) levy[LEVIES[k][0]] = v.abs;
        break;
      }
    });
    var gst = levy.gst != null ? levy.gst : (levy.cgst || 0) + (levy.sgst || 0) + (levy.igst || 0) + (levy.utgst || 0);
    var charges = r2((levy.brokerage || 0) + (levy.exch || 0) + (levy.clearing || 0) + (levy.stt || 0) + (levy.sebi || 0) + (levy.stamp || 0) + (levy.ipft || 0) + gst);
    var buys = r2(sum(trades, function (t) { return t.side === 'buy' ? t.value : 0; })), sells = r2(sum(trades, function (t) { return t.side === 'sell' ? t.value : 0; }));
    var want = r2(buys - sells + charges), tol = trades.length > 10 ? 2 : 1;
    var nh = hits(lines, NET, 'amt', 'last').filter(function (h) { return !used[h.li]; })[0], net = null, guessed = false;
    if (nh) {
      net = netSign(nh.lab, nh.a);
      if (net == null) { guessed = true; net = Math.abs(want - nh.a.abs) <= Math.abs(want + nh.a.abs) ? nh.a.abs : -nh.a.abs; }
    }
    var ok = net != null && Math.abs(want - net) <= tol;
    var said = 'Bought ' + rs(buys) + ', sold ' + rs(sells) + ' and ' + rs(charges) + ' in charges';
    var note = net == null ? said + ', but no net amount is printed to check against'
      : ok ? said + ' come to the ' + rs(Math.abs(net)) + ' the client ' + (net >= 0 ? 'pays' : 'receives') + (guessed ? ' (which way isn\'t printed)' : '')
      : said + ' come to ' + rs(want) + ', but the net amount printed is ' + rs(net);
    return { kind: 'contract', holdings: [], trades: trades, charges: charges, net: net == null ? 0 : r2(net), check: { ok: ok, read: want, stated: net == null ? 0 : r2(net), note: note } };
  }

  /* ------------------------------------------------------------ 7. capital gains, first in first out
     Trades from contract notes, matched sale to the oldest purchase still held, per security (its ISIN, else its
     name). Listed shares held more than 12 months are long term. A sale of more than kosh has seen bought (shares
     bought before kosh's mail starts) costs the unseen part at zero and says so (unknownCost). A sale that uses
     both older and newer lots is split into its long- and short-term parts. */
  function longTerm(bought, sold) { return sold > addMonths(bought, 12); }
  function fifoGains(trades, today) {
    today = /^\d{4}-\d{2}-\d{2}$/.test(today || '') ? today : new Date().toISOString().slice(0, 10);
    var list = [];
    (Array.isArray(trades) ? trades : []).forEach(function (t, n) {
      if (!t || !/^\d{4}-\d{2}-\d{2}$/.test(t.date || '') || (t.side !== 'buy' && t.side !== 'sell')) return;
      var q = Math.abs(+t.qty || 0), v = Math.abs(+t.value || 0) || q * Math.abs(+t.price || 0);
      if (!(q > 0) || !(v > 0)) return;
      list.push({ n: n, date: t.date, side: t.side, qty: q, value: v, isin: String(t.isin || '').toUpperCase(), name: trim(t.name) });
    });
    // a name seen with an ISIN keys its ISIN-less trades too
    var isinOf = {};
    list.forEach(function (t) { if (t.isin && t.name) isinOf[t.name.toUpperCase()] = t.isin; });
    list.forEach(function (t) { if (!t.isin && isinOf[t.name.toUpperCase()]) t.isin = isinOf[t.name.toUpperCase()]; t.key = t.isin || t.name.toUpperCase(); });
    list.sort(function (a, b) { return a.date < b.date ? -1 : a.date > b.date ? 1 : a.side !== b.side ? (a.side === 'buy' ? -1 : 1) : a.n - b.n; });
    var book = {}, keys = [], sells = [], fy = {};
    list.forEach(function (t) {
      var b = book[t.key];
      if (!b) { b = book[t.key] = { isin: t.isin, name: t.name, lots: [], realized: 0 }; keys.push(t.key); }
      if (!b.name && t.name) b.name = t.name;
      if (t.side === 'buy') { b.lots.push({ date: t.date, qty: t.qty, cost: t.value }); return; }
      var left = t.qty, unit = t.value / t.qty, parts = { long: { qty: 0, cost: 0 }, short: { qty: 0, cost: 0 } };
      while (left > 1e-9 && b.lots.length) {
        var lot = b.lots[0], take = Math.min(left, lot.qty), c = lot.cost * take / lot.qty;
        var p = parts[longTerm(lot.date, t.date) ? 'long' : 'short'];
        p.qty += take; p.cost += c;
        lot.qty -= take; lot.cost -= c; left -= take;
        if (lot.qty <= 1e-9) b.lots.shift();
      }
      var unknown = left > 1e-9 ? left : 0;
      if (unknown) parts.short.qty += unknown;   // when they were bought isn't known: counted short term, at no cost
      ['long', 'short'].forEach(function (term) {
        var p = parts[term];
        if (!(p.qty > 1e-9)) return;
        var proceeds = unit * p.qty, gain = proceeds - p.cost, f = fyOf(t.date);
        var s = { date: t.date, isin: b.isin, name: b.name, qty: r4(p.qty), proceeds: r2(proceeds), cost: r2(p.cost), gain: r2(gain), term: term };
        if (unknown) s.unknownCost = true;
        sells.push(s);
        b.realized += gain;
        fy[f] = fy[f] || { stcg: 0, ltcg: 0 };
        fy[f][term === 'long' ? 'ltcg' : 'stcg'] += gain;
      });
    });
    Object.keys(fy).forEach(function (f) { fy[f].stcg = r2(fy[f].stcg); fy[f].ltcg = r2(fy[f].ltcg); });
    var byIsin = keys.map(function (k) {
      var b = book[k], q = sum(b.lots, function (l) { return l.qty; }), c = sum(b.lots, function (l) { return l.cost; });
      return { isin: b.isin, name: b.name, qty: r4(q), cost: r2(c), avg: q > 1e-9 ? r2(c / q) : 0, realized: r2(b.realized),
               longQty: r4(sum(b.lots.filter(function (l) { return longTerm(l.date, today); }), function (l) { return l.qty; })) };
    }).sort(function (a, b) { return a.name < b.name ? -1 : a.name > b.name ? 1 : 0; });
    return { byIsin: byIsin, fy: fy, sells: sells };
  }

  /* ------------------------------------------------------------ the registry and the bridge */
  // a reader never throws: anything it can't make sense of is "nothing recognised"
  function guard(fn, kind) {
    return function (text, from, title, flat) {
      try {
        text = String(text || '');
        var out = fn(text, String(from || ''), String(title || ''), flat || text.replace(/[ \t]+/g, ' ')) || empty();
        out.kind = out.kind || kind;
        return out;
      } catch (e) { var x = empty(); x.kind = kind; return x; }
    };
  }
  var api = {
    payslip: guard(payslip, 'payslip'), fd: guard(fd, 'fd'), loan: guard(loan, 'loan'), nps: guard(nps, 'nps'), epf: guard(epf, 'epf'), tax: guard(tax, 'tax'),
    // the contract-note reader itself: null when the note has no trade rows kosh can read
    contract: function (text, from, title, flat) {
      try { text = String(text || ''); return contract(text, String(from || ''), String(title || ''), flat || text.replace(/[ \t]+/g, ' ')); } catch (e) { return null; }
    },
    fifoGains: fifoGains,
    lib: { amt: amt, day: day, cells: cells, label: label, hits: hits, grow: grow, stdEmi: stdEmi, fyOf: fyOf, addMonths: addMonths, payoutOf: payoutOf, schedule: schedule },

    // the bridge Swift calls (JSON strings in, JSON strings out)
    // trades as contract notes give them ([{ date, isin, name, side, qty, price, value }]) → realised gains, FIFO
    fifoGainsJSON: function (tradesJSON, today) {
      var t;
      try { t = JSON.parse(tradesJSON || '[]'); } catch (e) { t = []; }
      try { return JSON.stringify(fifoGains(t, today || '')); } catch (e2) { return JSON.stringify({ byIsin: [], fy: {}, sells: [] }); }
    },
    docReaderKindsJSON: function () { return JSON.stringify(Object.keys(READERS)); },
    /* a statement's layout with nothing of its content, for the diagnostics export: each line as its shape (a date
       "D", an amount "A", any other number "#", a word "w", a run of words "w+") with only the words a statement's
       frame is made of kept (Date, Narration, Withdrawal, Deposit, Balance, Opening, Closing, Cr, Dr, Total, Page,
       Statement, Period, Account…). No names, no figures, no merchants. With how many lines carry a date and an amount
       (the lines a statement's transactions are on), so a reading that took few of them shows */
    docShapeJSON: function (text, max) {
      var KEEP = /^(?:date|txn|tran|transaction|value|posting|narration|description|particulars|details|remarks|chq|cheque|ref|reference|no|withdrawal|withdrawals|debit|debits|deposit|deposits|credit|credits|balance|bal|opening|closing|total|totals|page|of|statement|period|from|to|account|a\/c|summary|cr|dr|amount|inr|rs|b\/f|c\/f|brought|carried|forward|type|mode|upi|neft|imps|rtgs|atm|pos|nach|ach|int|interest|sweep|fd|td|branch|ifsc|customer|id|crn|cif|nominee|holder|joint|name|address|currency|available|ledger|cleared|uncleared|hold|lien|limit|drawing|power|mab|aqb|amb|end|day|in|out|and|the|for|your)$/i;
      var DATE = /^(?:\d{1,2}[-\/.](?:\d{1,2}|[a-z]{3})[-\/.]\d{2,4}|\d{4}-\d{2}-\d{2}|\d{1,2}[a-z]{3}\d{2,4})$/i;
      var AMT = /^-?(?:₹|rs\.?|inr)?\(?-?\d{1,3}(?:,\d{2,3})*(?:\.\d{1,2})\)?(?:cr|dr)?$|^-?\d+\.\d{2}(?:cr|dr)?$/i;
      var lines = String(text || '').split(/\n/), out = [], withDA = 0, n = 0;
      lines.forEach(function (ln) {
        var toks = ln.trim().split(/\s+/).filter(Boolean);
        if (!toks.length) return;
        n++;
        var sh = [], hasD = false, hasA = false;
        toks.forEach(function (t) {
          var k = DATE.test(t) ? 'D' : AMT.test(t) ? 'A' : /\d/.test(t) ? '#' : KEEP.test(t.replace(/[^a-z\/]/gi, '')) ? t.toLowerCase().replace(/[^a-z\/]/g, '') : 'w';
          if (k === 'D') hasD = true; if (k === 'A') hasA = true;
          if (k === 'w' && sh[sh.length - 1] === 'w+') return;
          if (k === 'w' && sh[sh.length - 1] === 'w') { sh[sh.length - 1] = 'w+'; return; }
          sh.push(k);
        });
        if (hasD && hasA) withDA++;
        if (out.length < (+max || 70)) out.push(sh.join(' '));
      });
      return JSON.stringify({ lines: n, dateAndAmount: withDA, shape: out });
    }
  };
  /* ------------------------------------------------------------ several statements in one zip
     A zip can hold several statements (a consolidated statement per PAN or per depository, a month of contract notes,
     two accounts' statements): Swift opens each, reads each as itself (its own best reading, LiveSession applyDoc) and
     hands the readings here as a list. One reading comes back, made of all of them, each thing in it counted once: a
     statement that is in the zip twice (the same pages, or the same rows as a PDF and a workbook) once, a holding once
     (by its fund or share, folio, units and value), a statement's lines once per account and period, a trade once (by its
     number, else its share, side, quantity, price and day), a policy once (by its number). The zip's papers are mostly of
     one kind; any of another kind are left out and named (`skipped`), never read as the main kind. Figures are only
     added: a total is the sum of the statements' totals, and it is trusted only when every statement's was. */
  function mergeDocs(list, kind) {
    list = (list || []).filter(function (d) { return d && typeof d === 'object'; });
    if (list.length <= 1) return list[0] || null;
    var kindOf = function (d) { return d.kind || d.docKind || kind || ''; };
    var counts = {};
    list.forEach(function (d) { var k = kindOf(d); counts[k] = (counts[k] || 0) + 1; });
    // (the zip's own kind wins a tie; a paper that read as nothing is no kind at all)
    var main = Object.keys(counts).sort(function (a, b) { return counts[b] - counts[a] || (b === kind) - (a === kind); })[0];
    var skipped = list.filter(function (d) { return kindOf(d) !== main; }).map(kindOf);
    var same = list.filter(function (d) { return kindOf(d) === main; });
    // a statement in the zip twice (its pages and its workbook, or a copy) is one: by what it holds
    var hKey = function (h) { return [h.cls || '', h.isin || '', String(h.bank || '').toLowerCase(), h.folio || '', r2(h.units), r2(h.amt)].join('|'); };
    var rowKey = function (r) { return [r.date, r2(r.amt), r.dir, String(r.desc || '').toLowerCase().replace(/\s+/g, ' ')].join('|'); };
    var tKey = function (t) { return t.no ? 'no|' + t.no : [t.isin || String(t.name || '').toLowerCase(), t.side, r4(t.qty), r4(t.price), t.date].join('|'); };
    var pKey = function (p) { var n = String(p.policyNo || '').replace(/[^A-Za-z0-9]/g, '').toUpperCase(); return n ? 'no|' + n : JSON.stringify(p); };
    var partsOf = function (d) {
      if (d.parts && d.parts.length) return d.parts;
      if ((d.rows && d.rows.length) || d.close != null) return [{ rows: d.rows || [], last4: d.last4, from: d.from, to: d.to, close: d.close, closeDate: d.closeDate, check: d.check, opening: d.opening }];
      return [];
    };
    var print = function (d) {
      return JSON.stringify([(d.holdings || []).map(hKey).sort(), partsOf(d).map(function (P) { return [P.last4 || '', P.from || '', P.to || ''].concat((P.rows || []).map(rowKey)).join('~'); }).sort(),
        (d.trades || []).map(tKey).sort(), (d.policies || []).map(pKey).sort(), (d.facts || []).map(function (f) { return JSON.stringify(f); }).sort()]);
    };
    var seenDoc = {}, docs = [];
    same.forEach(function (d) { var k = print(d); if (!seenDoc[k]) { seenDoc[k] = 1; docs.push(d); } });
    var out = { kind: main, holdings: [], policies: [] };
    var uniqBy = function (field, key) {
      var seen = {}, all = [];
      docs.forEach(function (d) { (d[field] || []).forEach(function (x) { var k = key(x); if (!seen[k]) { seen[k] = 1; all.push(x); } }); });
      return all;
    };
    out.holdings = uniqBy('holdings', hKey);
    out.policies = uniqBy('policies', pKey);
    ['facts', 'loans', 'dues', 'properties', 'ids'].forEach(function (f) { var a = uniqBy(f, function (x) { return JSON.stringify(x); }); if (a.length || docs.some(function (d) { return d[f]; })) out[f] = a; });
    var tr = uniqBy('trades', tKey);
    if (tr.length || docs.some(function (d) { return d.trades; })) out.trades = tr;
    docs.forEach(function (d) { ['cat', 'docKind', 'instr'].forEach(function (f) { if (out[f] == null && d[f] != null && d[f] !== '') out[f] = d[f]; }); });
    var days = docs.map(function (d) { return d.asOf; }).filter(Boolean).sort();
    if (days.length) out.asOf = days[days.length - 1];
    // a holdings total only when every statement with holdings printed one: the sums, trusted when every one was
    var withH = docs.filter(function (d) { return (d.holdings || []).length; });
    if (withH.length && withH.every(function (d) { return d.total; })) {
      out.total = { read: r2(sum(withH, function (d) { return d.total.read; })), stated: r2(sum(withH, function (d) { return d.total.stated; })),
        reconciled: withH.every(function (d) { return d.total.reconciled === true; }) };
      var tv = withH.map(function (d) { return d.total.trusted; });
      if (tv.some(function (v) { return v === false; })) out.total.trusted = false; else if (tv.every(function (v) { return v === true; })) out.total.trusted = true;
    }
    // a statement's lines: each statement (or each account of a combined one) its own part, a part told twice once
    var seenP = {}, parts = [];
    docs.forEach(function (d) { partsOf(d).forEach(function (P) { var k = [P.last4 || '', P.from || '', P.to || '', r2(P.close)].concat((P.rows || []).map(rowKey)).join('~'); if (!seenP[k]) { seenP[k] = 1; parts.push(P); } }); });
    if (parts.length === 1 && docs.length === 1) { ['rows', 'last4', 'from', 'to', 'close', 'closeDate', 'opening', 'credit', 'limit', 'avail'].forEach(function (f) { if (docs[0][f] != null) out[f] = docs[0][f]; }); }
    else if (parts.length) out.parts = parts;
    var named = [], namedF = [];
    docs.forEach(function (d) { (d.named || []).forEach(function (n) { if (named.indexOf(n) < 0) named.push(n); }); (d.namedF || []).forEach(function (n) { if (namedF.indexOf(n) < 0) namedF.push(n); }); });
    if (named.length) out.named = named;
    if (namedF.length) out.namedF = namedF;
    if (docs.some(function (d) { return d.byColumns; })) out.byColumns = true;
    // whether the papers' own figures added up: every one did, one didn't, or some couldn't say
    var cs = docs.map(function (d) { return d.check; }).filter(Boolean);
    if (parts.length > 1) cs = parts.map(function (P) { return P.check; }).filter(Boolean);
    if (cs.length) out.check = { ok: cs.some(function (c) { return c.ok === false; }) ? false : cs.every(function (c) { return c.ok === true; }) ? true : null,
      read: r2(sum(cs, function (c) { return c.read; })), stated: r2(sum(cs, function (c) { return c.stated; })), note: cs.map(function (c) { return c.note; }).filter(Boolean).join('; ').slice(0, 600) };
    var epfs = docs.map(function (d) { return d.epf; }).filter(Boolean);
    if (epfs.length) { var mem = {}, members = []; epfs.forEach(function (e) { (e.members || []).forEach(function (m) { if (!mem[m.memberId]) { mem[m.memberId] = 1; members.push(m); } }); }); out.epf = { uan: epfs[0].uan, members: members }; }
    out.files = docs.length;
    if (list.length > docs.length + skipped.length) out.twice = list.length - docs.length - skipped.length;
    if (skipped.length) out.skipped = skipped;
    return out;
  }
  api.mergeDocs = mergeDocs;
  api.mergeDocsJSON = function (listJSON, kind) {
    var list = []; try { list = JSON.parse(listJSON || '[]').map(function (x) { return typeof x === 'string' ? JSON.parse(x) : x; }); } catch (e) { list = []; }
    return JSON.stringify(mergeDocs(list, kind || ''));
  };
  READERS.payslip = api.payslip;
  READERS.fd = api.fd;
  READERS.loan = api.loan;
  READERS.nps = api.nps;
  READERS.epf = api.epf;
  READERS.tax = api.tax;
  READERS.contract = function (text, from, title, flat) {
    var r = api.contract(text, from, title, flat);
    return r || { kind: 'contract', holdings: [], facts: [], loans: [], trades: [], charges: 0, net: 0, check: { ok: false, read: 0, stated: 0, note: 'No trades found' } };
  };
  // Swift calls everything through KoshEngine
  for (var k in api) if (Object.prototype.hasOwnProperty.call(api, k) && /JSON$/.test(k)) E[k] = api[k];
  return api;
})(typeof KoshEngine !== 'undefined' ? KoshEngine : require('./engine.js'));
if (typeof module !== 'undefined' && module.exports) module.exports = KoshDocs;
