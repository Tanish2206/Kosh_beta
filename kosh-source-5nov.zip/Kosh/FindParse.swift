import Foundation

/// How Find understood what you typed (find-review, 1 Nov): the words it still looks for in a payment (its name, note,
/// UPI ID, card, bank), and the filters it read out of the rest: a kind of spending named ("food", "groceries",
/// "cash withdrawal"), "uncategorised" or "no category", a month's name ("oct", "october 2025"), and amounts as typed
/// ("22,476", ">5000", "500-1000", "over 5k", "under 1.2L"). Each is shown under the field as a chip, so you see what
/// kosh took your words to mean. Screen-free (Foundation only): engine-test/find-parse.swift compiles it with swiftc.
struct FindParse: Equatable {
    /// the words still looked for in a payment
    var words: [String] = []
    /// the kinds of spending named, as kosh files them
    var cats: [String] = []
    /// "uncategorised", "no category": what Sort these takes in
    var uncat: Bool = false
    /// months named, yyyy-MM: the latest such month on or before this month, unless a year was typed
    var months: [String] = []
    /// amount filters, in the form Store.amountFits reads ("22476", ">5000", "<500", "500-1000")
    var amounts: [String] = []

    var isEmpty: Bool { words.isEmpty && cats.isEmpty && !uncat && months.isEmpty && amounts.isEmpty }
    /// what it was taken to mean, a chip each: ("cat", "Food & Drinks"), ("month", "October 2026"), ("amount", "Over ₹5,000")
    var chips: [(kind: String, title: String)] {
        var out: [(kind: String, title: String)] = []
        for w in words { out.append((kind: "text", title: "“" + w + "”")) }
        for c in cats { out.append((kind: "cat", title: c)) }
        if uncat { out.append((kind: "uncat", title: "Uncategorised")) }
        for m in months { out.append((kind: "month", title: Self.monthTitle(m))) }
        for a in amounts { out.append((kind: "amount", title: Self.amountTitle(a))) }
        return out
    }

    static let monthNames: [String] = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
    /// "jan", "january", "sept": the month's number
    static func monthNumber(_ w: String) -> Int? {
        let s: String = w.lowercased()
        guard s.count >= 3 else { return nil }
        if s == "sept" { return 9 }
        for (i, name) in monthNames.enumerated() {
            let n: String = name.lowercased()
            if s == n || (s.count == 3 && n.hasPrefix(s)) { return i + 1 }
        }
        return nil
    }
    static func monthTitle(_ m: String) -> String {
        let mo: Int = Int(m.suffix(2)) ?? 1
        return monthNames[max(0, min(11, mo - 1))] + " " + String(m.prefix(4))
    }
    /// "5000" → 5000, "5k" → 5000, "1.2l" or "1.2lakh" → 120000, "22,476" → 22476; nil when it isn't an amount
    static func number(_ raw: String) -> Double? {
        var s: String = raw.lowercased().replacingOccurrences(of: ",", with: "")
        var times: Double = 1
        if s.hasSuffix("lakh") { s = String(s.dropLast(4)); times = 100000 }
        else if s.hasSuffix("cr") { s = String(s.dropLast(2)); times = 10000000 }
        else if s.hasSuffix("k") { s = String(s.dropLast(1)); times = 1000 }
        else if s.hasSuffix("l") { s = String(s.dropLast(1)); times = 100000 }
        guard !s.isEmpty, s.allSatisfy({ $0.isNumber || $0 == "." }), let v = Double(s), v > 0 else { return nil }
        return (v * times).rounded()
    }
    /// an amount token, put the way Store.amountFits reads it; nil when it isn't one
    static func amount(_ tok: String) -> String? {
        let s: String = tok.lowercased()
        if s.hasPrefix(">") || s.hasPrefix("<") {
            guard let v = number(String(s.dropFirst())) else { return nil }
            return String(s.prefix(1)) + String(Int(v))
        }
        let parts: [Substring] = s.split(separator: "-")
        if parts.count == 2, let lo = number(String(parts[0])), let hi = number(String(parts[1])), lo <= hi {
            return String(Int(lo)) + "-" + String(Int(hi))
        }
        // (a bare number is an amount only with three figures or more, or a k/L: "12" may be part of a name; an amount is
        // still looked for in the names too, as Store.search does with every word)
        guard let v = number(s) else { return nil }
        let digits: Int = s.filter { $0.isNumber }.count
        if digits < 3 && !(s.hasSuffix("k") || s.hasSuffix("l") || s.hasSuffix("lakh") || s.hasSuffix("cr")) { return nil }
        return String(Int(v))
    }
    static func amountTitle(_ a: String) -> String {
        if a.hasPrefix(">") { return "Over " + rupees(Double(a.dropFirst()) ?? 0) }
        if a.hasPrefix("<") { return "Under " + rupees(Double(a.dropFirst()) ?? 0) }
        let p: [Substring] = a.split(separator: "-")
        if p.count == 2 { return rupees(Double(p[0]) ?? 0) + "–" + rupees(Double(p[1]) ?? 0) }
        return rupees(Double(a) ?? 0)
    }
    /// ₹5,000, ₹1,20,000: Indian grouping, whole rupees
    static func rupees(_ v: Double) -> String {
        let n: Int = Int(v.rounded())
        var s: String = String(abs(n))
        if s.count > 3 {
            let last: String = String(s.suffix(3))
            var head: String = String(s.dropLast(3))
            var groups: [String] = []
            while head.count > 2 { groups.insert(String(head.suffix(2)), at: 0); head = String(head.dropLast(2)) }
            if !head.isEmpty { groups.insert(head, at: 0) }
            s = groups.joined(separator: ",") + "," + last
        }
        return (n < 0 ? "-₹" : "₹") + s
    }

    /// the phrases that mean "no category"
    static let uncatPhrases: [String] = ["no category", "not categorised", "not categorized", "needs a category", "uncategorised", "uncategorized", "uncategorised payments", "unsorted"]

    /// read what was typed against the kinds kosh files under and this month (yyyy-MM)
    static func parse(_ text: String, cats known: [String], cm: String) -> FindParse {
        var out = FindParse()
        var s: String = " " + text.lowercased()
            .replacingOccurrences(of: "₹", with: " ").replacingOccurrences(of: "rs.", with: " ")
            .replacingOccurrences(of: "\u{2013}", with: "-") + " "
        // "over 5000", "above 5k", "under 500", "below 1L": the amount's side joined to it
        for (w, sign) in [("over ", ">"), ("above ", ">"), ("more than ", ">"), ("under ", "<"), ("below ", "<"), ("less than ", "<")] {
            s = s.replacingOccurrences(of: " " + w, with: " " + sign)
        }
        s = s.replacingOccurrences(of: "> ", with: ">").replacingOccurrences(of: "< ", with: "<")
        for p in uncatPhrases where s.contains(" " + p + " ") {
            out.uncat = true
            s = s.replacingOccurrences(of: " " + p + " ", with: " ")
        }
        // kinds of spending: the whole name first (longest first), then a name's first word of four letters or more when
        // only one kind starts with it ("food" is Food & Drinks)
        let names: [String] = known.filter { $0 != "Miscellaneous" }.sorted { $0.count > $1.count }
        for c in names {
            let low: String = " " + c.lowercased() + " "
            if s.contains(low) {
                if !out.cats.contains(c) { out.cats.append(c) }
                s = s.replacingOccurrences(of: low, with: " ")
            }
        }
        var toks: [String] = s.split(separator: " ").map(String.init).filter { !$0.isEmpty }
        var i: Int = 0
        let cmYear: Int = Int(cm.prefix(4)) ?? 2026
        let cmMonth: Int = Int(cm.suffix(2)) ?? 1
        while i < toks.count {
            let t: String = toks[i]
            if let mo = monthNumber(t) {
                var y: Int = mo > cmMonth ? cmYear - 1 : cmYear
                if i + 1 < toks.count, let yy = Int(toks[i + 1]), yy >= 2000 && yy <= 2100 { y = yy; toks.remove(at: i + 1) }
                let m: String = String(y) + "-" + (mo < 10 ? "0" : "") + String(mo)
                if !out.months.contains(m) { out.months.append(m) }
            } else if let a = amount(t) {
                out.amounts.append(a)
            } else if t.count >= 4, let c = firstWordCat(t, names) {
                if !out.cats.contains(c) { out.cats.append(c) }
            } else {
                out.words.append(t)
            }
            i += 1
        }
        return out
    }
    static func firstWordCat(_ w: String, _ names: [String]) -> String? {
        let hits: [String] = names.filter { n in
            let first: String = n.lowercased().split(whereSeparator: { !$0.isLetter }).first.map(String.init) ?? ""
            return first == w
        }
        return hits.count == 1 ? hits[0] : nil
    }
}
