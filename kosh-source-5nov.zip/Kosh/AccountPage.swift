import SwiftUI

// MARK: - One account
//
// The balance and how kosh knows it (the last balance your bank told it, the payments since, and whether every
// balance adds up with the payments between them); where it didn't; what came and went; and, at the bottom, the
// account set right in a tap: whose it is, these two are one, this one is two, its name, closed, not mine.

struct AccountPage: View {
    @Environment(Store.self) private var store
    /// opened from Wealth: its sheets in the black look too
    @Environment(\.obsidian) private var obsidian
    let id: String
    @AppStorage("accts.span") private var spanKey = "30d"
    @State private var editing = false

    var body: some View {
        if let a = store.snap.accounts.first(where: { $0.id == id }) ?? store.snap.wallets.first(where: { $0.id == id }) {
            content(a)
        } else {
            ContentUnavailableView("This account isn’t here any more", systemImage: "building.columns")
        }
    }

    func content(_ a: Account) -> some View {
        let today: String = store.snap.today
        let span: Span = Span.pick(spanKey, months: store.snap.months)
        let flow = store.accountFlow([a], span: span, today: today)
        let logos: Bool = IconBook.shared.all([(a.bank, a.name)])
        let isWallet: Bool = a.kind == "wallet"
        let wash: HeroWash = isWallet ? .warm : .blue
        let sub: String = AccountPage.subLine(a, whose: store.who == .family || isWallet || a.owner == "family" ? AccountPage.whoseWords(a, store) : "")
        let login: String = isWallet ? (a.inbox ?? "") : ""
        let title: String = AccountPage.title(a)
        let stale: Bool = a.bal?.stale == true
        let balTitle: String = stale ? "Last balance kosh has" : ((a.bal?.n ?? 0) > 0 ? "Balance now, worked out" : "Balance")
        let editTitle: String = a.bal?.src == "typed" ? "Update the balance" : "Type today’s balance"
        // (this account's statements only: one whose closing balance names another account's digits is that one's)
        let stmts: [StmtStatus] = (store.snap.stmts ?? []).filter { s in
            s.kind == "stmt" && s.inst == a.bank && (s.closes.isEmpty || a.last.isEmpty || !StatementCard.closes(s, only: a.last).isEmpty)
        }
        let canEdit: Bool = store.live != nil
        return ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                VStack(alignment: .leading, spacing: 0) {
                    HStack(spacing: 12) {
                        if isWallet {
                            WalletBadge(name: a.bank, hex: a.color, size: 44)
                        } else {
                            InstIcon(name: a.bank, color: Color(hex: a.color), size: 44, hint: a.name, mark: !logos)
                        }
                        VStack(alignment: .leading, spacing: 1) {
                            Text(title).font(.system(.body, weight: .bold)).lineLimit(1)
                            Text(sub).font(.system(.footnote)).foregroundStyle(wash.soft).monospacedDigit().lineLimit(1)
                            if !login.isEmpty {
                                Text(AccountPage.loginLine(a.bank, login)).font(.system(.caption)).foregroundStyle(wash.soft.opacity(0.8))
                                    .lineLimit(1).truncationMode(.middle)
                            }
                        }
                    }
                    .accessibilityElement(children: .combine)
                    Text(balTitle).font(.system(.footnote, weight: .semibold)).foregroundStyle(wash.ink).padding(.top, 18)
                    if let v = a.balance {
                        Text(Fmt.rupees(v))
                            .scaledFont(size: 40, weight: .bold, design: .rounded, relativeTo: .largeTitle).monospacedDigit()
                            .foregroundStyle(stale ? AnyShapeStyle(wash.soft) : AnyShapeStyle(Color.primary))
                            .lineLimit(1).minimumScaleFactor(0.6)
                            .contentTransition(.numericText(value: v))
                            .privacySensitive()
                            .padding(.top, 2)
                        if stale, let b = a.bal {
                            Text("On " + Day.fmt(String(b.at.prefix(10)), "d MMMM yyyy"))
                                .font(.system(.footnote, weight: .semibold)).foregroundStyle(wash.soft).padding(.top, 2)
                        }
                    } else {
                        Text(a.isDebitCardOnly ? "Account not known yet" : "Not known yet").font(.system(.title, design: .rounded, weight: .bold))
                            .foregroundStyle(wash.soft).padding(.top, 4)
                        Text(AccountPage.unknownLine(a)).font(.system(.footnote)).foregroundStyle(wash.soft)
                            .fixedSize(horizontal: false, vertical: true).padding(.top, 4)
                    }
                    if let w = AccountPage.heldWords(a) {
                        Text(w).font(.system(.footnote)).foregroundStyle(wash.soft).privacySensitive()
                            .fixedSize(horizontal: false, vertical: true).padding(.top, 4)
                    }
                    if let b = a.bal { BalanceTrail(a: a, b: b).padding(.top, 12) }
                    if !a.isDebitCardOnly {
                        Button { editing = true } label: {
                            Label(editTitle, systemImage: "square.and.pencil")
                                .font(.subheadline.weight(.semibold))
                                .padding(.horizontal, 16)
                                .frame(minHeight: 40)
                                .background(Color.lift(0.92), in: Capsule())
                                .overlay(Capsule().strokeBorder(wash.edge, lineWidth: 0.5))
                                .contentShape(Capsule())
                        }
                        .buttonStyle(.press)
                        .foregroundStyle(Color.kosh)
                        .padding(.top, 14)
                        .disabled(!canEdit)
                        .opacity(canEdit ? 1 : 0.5)
                    }
                }
                .heroWash(wash)
                // (livebal-4nov) no 'Where it didn’t add up' list
                HStack(alignment: .center) {
                    Text("Activity").font(.system(.title2, weight: .bold)).accessibilityAddTraits(.isHeader)
                    Spacer()
                    SpanMenu(key: $spanKey)
                }
                FlowTiles(flow: flow, span: span, wallet: isWallet)
                if !flow.items.isEmpty {
                    VStack(alignment: .leading, spacing: 8) {
                        GroupLabel(title: "Payments", figure: WalletCards.latest(60, of: flow.items.count) ?? "", money: false)
                        VStack(spacing: 0) {
                            ForEach(Array(flow.items.prefix(60).enumerated()), id: \.element.id) { i, t in
                                if i > 0 { RowRule(inset: 48) }
                                TxRow(t: t, when: Day.label(t.d, today: today), showWay: false).padding(.vertical, 10)
                            }
                        }
                        .rowsCard()
                    }
                } else {
                    Text(AccountPage.quietLine(isWallet, span.phrase(cm: store.snap.cm)))
                        .font(.system(.footnote)).foregroundStyle(.secondary).padding(.horizontal, 4)
                }
                if !stmts.isEmpty {
                    VStack(alignment: .leading, spacing: 8) {
                        GroupLabel(title: "Statement")
                        ForEach(stmts) { s in StatementCard(s: s, logos: logos, only: a.last) }
                    }
                }
                // (dcard-4nov) the cards that go with it: its debit cards, and the same bank's credit cards in the holder's name
                if !isWallet && !a.isDebitCardOnly { AccountCards(a: a, cards: store.snap.cards.filter { $0.bank == a.bank && ($0.owner == a.owner || a.owner.isEmpty) }) }
                // the bank's IDs and numbers for this person (Your details)
                // (its own numbers only: its last four, the other ways its mail wrote them, and its debit cards')
                if !isWallet { InstitutionDetails(inst: a.bank, who: a.owner, last4: a.last, alias: (a.alias ?? []) + (a.debit ?? [])) }
                if canEdit && !isWallet { AccountFixes(a: a) }
            }
            .padding(.horizontal, 20)
            .padding(.top, 8)
            .padding(.bottom, 40)
        }
        .navigationTitle(title)
        .navigationBarTitleDisplayMode(.inline)
        .animation(Motion.open, value: spanKey)
        .sheet(isPresented: $editing) {
            BalanceEditor(a: a).presentationDetents([.medium]).obsidianSheet(obsidian)
        }
    }
}

/// where the figure comes from: the starting point, what came and went since, and now
extension AccountPage {
    /// what kind of account it is: the bank's own word for it, read from the details its mail printed beside the
    /// number ("Savings A/c No", "Current A/c Number", "FD A/c No"). Never guessed — a.name is the bank's display
    /// name ("HDFC Bank"), so guessing from it called a fixed deposit, a current, a salary, an NRE and an overdraft
    /// account "savings" alike. Nothing printed, nothing said: kindWord is empty and the line says so.
    static func kindWord(_ a: Account) -> String {
        if a.kind == "wallet" { return "Wallet" }
        if a.isDebitCardOnly { return "Debit card" }
        return Details.typeWord(a.atype)
    }
    /// the account's own name, the one you gave it first
    static func title(_ a: Account) -> String {
        if let n = a.nick, !n.isEmpty { return n }
        return a.kind == "wallet" || a.name.isEmpty ? a.bank : a.name
    }
    /// "Savings account ••4821 · debit card ••7301 · Asha", or a debit card's "Debit card ••9902 · account not known yet"
    /// held for an IPO: out of what the bank calls available, still yours, and in net worth
    static func heldWords(_ a: Account) -> String? {
        guard let h = a.held, h > 0, a.balance != nil else { return nil }
        let names: [String] = (a.heldFor ?? []).map { (x: Account.Held) -> String in x.name }
        let what: String = names.prefix(2).joined(separator: ", ")
        let forWhat: String = what.isEmpty ? "an IPO" : what + " IPO"
        return "Plus " + Fmt.rupees(h) + " held for " + forWhat + ". It comes back if no shares are allotted, and counts in your net worth."
    }

    /// the account named by every part kosh has: the bank's word for its type, its last four, its debit cards and
    /// whose it is. A part no mail has printed is said in words, never filled in.
    static func subLine(_ a: Account, whose: String) -> String {
        var bits: [String] = []
        if a.isDebitCardOnly {
            bits.append("Debit card ••" + (a.debit?.first ?? ""))
            bits.append("account not known yet")
        } else {
            let kind: String = kindWord(a)
            bits.append(kind.isEmpty ? "Account" : kind)
            if !a.last.isEmpty { bits[bits.count - 1] += " ••" + a.last }
            if !a.debitWords.isEmpty { bits.append(a.debitWords) }
        }
        if !whose.isEmpty { bits.append(whose) }
        if !a.isDebitCardOnly && a.kind != "wallet" && kindWord(a).isEmpty { bits.append(Details.noType) }
        return bits.joined(separator: " · ")
    }
    /// whose it is in words: "Asha", "Joint: You and Asha", "Kamala Example" (a name on its mail, to confirm)
    static func whoseWords(_ a: Account, _ store: Store) -> String {
        if a.owner == "family" {
            let names: [String] = (a.joint ?? []).map { store.ownerName($0) }
            return names.isEmpty ? "Joint" : "Joint: " + names.joined(separator: " and ")
        }
        return store.ownerName(a.owner)
    }
    /// the login a wallet belongs to: the Gmail its mail comes to
    static func loginLine(_ bank: String, _ inbox: String) -> String { bank + " login: " + inbox }
    /// under a balance kosh doesn't know
    static func unknownLine(_ a: Account) -> String {
        if a.kind == "wallet" { return "Wallets don’t email their balance. Type it once and kosh keeps it current." }
        if a.isDebitCardOnly { return "Its mail names the card, not the account it pays from. Say which below, or kosh will tell once a mail prints both." }
        return "No alert or statement has said it yet. Type what your bank’s app shows."
    }
    static func quietLine(_ wallet: Bool, _ phrase: String) -> String {
        wallet ? "Nothing in or out of this wallet " + phrase + "." : "Nothing in or out " + phrase + ". A quiet account."
    }
}

struct BalanceTrail: View {
    @Environment(Store.self) private var store
    let a: Account
    let b: BalInfo
    var body: some View {
        let today = store.snap.today
        let day = String(b.at.prefix(10))
        let from: String = BalanceTrail.fromWords(b, day: day, today: today)
        let proof: String? = BalanceWords.proof(a, today: today)
        let good: Bool = b.check == "ok"
        let warn: Bool = b.stale == true
        VStack(spacing: 0) {
            row(from, Fmt.rupees(b.v), strong: false)
            if b.n > 0 {
                Rectangle().fill(Color.primary.opacity(0.08)).frame(height: 0.5)
                row(WalletCards.count(b.n, "payment") + " in and out since", Self.signed(b.net), strong: false)
                Rectangle().fill(Color.primary.opacity(0.08)).frame(height: 0.5)
                row("Now", Fmt.rupees(a.balance ?? b.v), strong: true)
            }
            // (sweep-5nov) a sweep account: what its moves are, and what keeps the figure right between statements
            if a.sweep == true {
                Rectangle().fill(Color.primary.opacity(0.08)).frame(height: 0.5)
                HStack(alignment: .firstTextBaseline, spacing: 8) {
                    Image(systemName: "arrow.left.arrow.right.circle").font(.system(.footnote, weight: .semibold)).foregroundStyle(Color.secondary)
                    Text("Sweep is on: money over the limit moves into a linked deposit and back. kosh counts those as your own money moving, never spending or income. Banks don’t alert a sweep, so between statements your bank’s SMS balance is what keeps this right.")
                        .font(.footnote).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                    Spacer(minLength: 0)
                }
                .padding(.horizontal, 14).padding(.vertical, 10)
            }
            // (smsstop-5nov) the live balance leans on SMS: when they've stopped reaching kosh, say so here
            if a.kind == "bank", AlertsState.now(kept: 0).health == .stopped, let l = AlertIntake.lastAt {
                Rectangle().fill(Color.primary.opacity(0.08)).frame(height: 0.5)
                HStack(alignment: .firstTextBaseline, spacing: 8) {
                    Image(systemName: "message.badge.waveform").font(.system(.footnote, weight: .semibold)).foregroundStyle(Color(light: "#A35A00", dark: "#FFB04D"))
                    Text("Your bank’s SMS haven’t reached kosh since " + AlertsTurnOn.when(l) + ", so this may miss payments since. Settings › Payments by SMS shows how to fix it.")
                        .font(.footnote).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                    Spacer(minLength: 0)
                }
                .padding(.horizontal, 14).padding(.vertical, 10)
            }
            if let proof {
                Rectangle().fill(Color.primary.opacity(0.08)).frame(height: 0.5)
                HStack(alignment: .firstTextBaseline, spacing: 8) {
                    Image(systemName: good ? "checkmark.seal.fill" : warn ? "exclamationmark.triangle.fill" : "circle.dashed")
                        .font(.system(.footnote, weight: .semibold))
                        .foregroundStyle(good ? Color(light: "#1A7A43", dark: "#5FD38A") : warn ? Color(light: "#A35A00", dark: "#FFB04D") : Color.secondary)
                    Text(proof).font(.footnote).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                    Spacer(minLength: 0)
                }
                .padding(.horizontal, 14).padding(.vertical, 10)
                .accessibilityElement(children: .combine)
            }
        }
        .background(Color.lift(0.75), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
    }
    /// "Your September statement closed on it", "Your bank’s alert, today", "Your bank’s balance mail, 4 Oct"
    static func fromWords(_ b: BalInfo, day: String, today: String) -> String {
        switch b.src {
        case "statement":
            if let m = b.month, !m.isEmpty { return "Your " + Day.monthName(m) + " statement’s closing balance" }
            return "Your statement closed on " + Day.fmt(day, "d MMM")
        case "typed": return "You typed it " + Day.when(day, today: today)
        case "note": return "Your bank’s balance mail, " + Day.when(day, today: today)
        default: return "Your bank’s alert, " + (b.stale == true ? BalanceWords.dayWords(day, today: today) : Day.when(day, today: today))
        }
    }
    static func signed(_ v: Double) -> String {
        let sign: String = v >= 0 ? "+" : "−"
        return sign + Fmt.rupees(v)
    }
    func row(_ l: String, _ v: String, strong: Bool) -> some View {
        let lf: Font = strong ? Font.subheadline.weight(.semibold) : Font.subheadline
        let li: Color = strong ? Color.primary : Color.secondary
        let vf: Font = strong ? Font.subheadline.weight(.bold) : Font.subheadline.weight(.medium)
        return HStack {
            Text(l).font(lf).foregroundStyle(li)
            Spacer(minLength: 8)
            Text(v).font(vf).monospacedDigit().privacySensitive()
        }
        .padding(.horizontal, 14).padding(.vertical, 10)
    }
}

/// the stretches where an account's balances didn't add up with its payments: money no payment kosh has explains
struct GapList: View {
    @Environment(Store.self) private var store
    let gaps: [BalGap]
    var body: some View {
        let today: String = store.snap.today
        VStack(alignment: .leading, spacing: 8) {
            GroupLabel(title: gaps.count == 1 ? "Where it didn’t add up" : "Where it didn’t add up, latest last")
            VStack(spacing: 0) {
                ForEach(Array(gaps.enumerated()), id: \.offset) { i, g in
                    if i > 0 { RowRule(inset: 0) }
                    HStack(alignment: .firstTextBaseline) {
                        Text(GapList.span(g, today: today)).font(.subheadline)
                        Spacer(minLength: 8)
                        Text((g.amt < 0 ? "−" : "+") + Fmt.rupees(abs(g.amt)))
                            .font(.subheadline.weight(.semibold)).monospacedDigit().privacySensitive()
                    }
                    .padding(.vertical, 12)
                    .accessibilityElement(children: .combine)
                }
            }
            .rowsCard()
            Text("Money moved that kosh has no payment for: one your bank told only by SMS, or one kosh filed under another account. The balance after it is the bank’s own.")
                .font(.footnote).foregroundStyle(.secondary).padding(.horizontal, 4).fixedSize(horizontal: false, vertical: true)
        }
    }
    /// "1 Aug to 31 Aug", "3 Oct, 10:00 to 6:30 pm"
    static func span(_ g: BalGap, today: String) -> String {
        let a = String(g.from.prefix(10)), b = String(g.to.prefix(10))
        if a == b {
            let t0 = String(g.from.dropFirst(11).prefix(5)), t1 = String(g.to.dropFirst(11).prefix(5))
            return BalanceWords.dayWords(a, today: today) + ", " + Day.time12(t0) + " to " + Day.time12(t1)
        }
        return BalanceWords.dayWords(a, today: today) + " to " + BalanceWords.dayWords(b, today: today)
    }
}

// MARK: - Setting an account right

/// what you can tell kosh about an account, each a row: whose it is, its name, these two are one, this one is two,
/// a debit card's account, closed, not mine. What you say stays said, whatever mail comes later
struct AccountFixes: View {
    @Environment(Store.self) private var store
    @Environment(\.obsidian) private var obsidian
    let a: Account
    @State private var naming = false
    @State private var newName = ""
    @State private var merging = false
    @State private var linking = false
    @State private var closing = false
    @State private var disowning = false

    var body: some View {
        let base: String = AccountFixes.baseKey(a)
        let others: [Account] = store.snap.accounts.filter { $0.bank == a.bank && $0.id != a.id && !$0.isDebitCardOnly && $0.tag == nil }
        let split: Bool = a.tag != nil
        let merged: Bool = store.live?.isMerged(base) ?? false
        VStack(alignment: .leading, spacing: 8) {
            GroupLabel(title: "Is this right?")
            VStack(spacing: 0) {
                WhoseRow(a: a)
                RowRule(inset: 46)
                if a.isDebitCardOnly {
                    fixRow("creditcard", "Which account is this card for?", sub: others.isEmpty ? "No other " + a.bank + " account yet" : nil) { linking = true }
                        .disabled(others.isEmpty)
                } else {
                    fixRow("character.cursor.ibeam", a.nick == nil ? "Give it a name" : "Rename it", sub: a.nick) { newName = a.nick ?? ""; naming = true }
                    if !others.isEmpty || merged {
                        RowRule(inset: 46)
                        if merged {
                            fixRow("arrow.triangle.branch", "These were two accounts", sub: "Undo the merge") { store.live?.unmergeAccounts(base) }
                        } else {
                            fixRow("arrow.triangle.merge", "It’s the same as another account", sub: nil) { merging = true }
                        }
                    }
                    RowRule(inset: 46)
                    if split {
                        fixRow("rectangle.on.rectangle.slash", "It’s one account", sub: "Join the halves again") { store.live?.splitAccount(base, false) }
                    } else {
                        fixRow("rectangle.split.2x1", "It’s two accounts", sub: "Two people’s accounts with the same last four") { store.live?.splitAccount(base, true) }
                    }
                    RowRule(inset: 46)
                    fixRow("archivebox", "It’s closed", sub: nil) { closing = true }
                }
                RowRule(inset: 46)
                fixRow("hand.raised", "It isn’t ours", sub: nil, tint: Color.red) { disowning = true }
            }
            .rowsCard()
            Text("What you say here stays said, whatever mail comes later.")
                .font(.footnote).foregroundStyle(.secondary).padding(.horizontal, 4)
        }
        .alert("Name this account", isPresented: $naming) {
            TextField("Salary account", text: $newName).textInputAutocapitalization(.words)
            Button("Save") { store.live?.nameAccount(a.id, newName) }
            Button("Cancel", role: .cancel) {}
        } message: { Text(a.bank + (a.last.isEmpty ? "" : " ••" + a.last)) }
        .confirmationDialog("Closed for good?", isPresented: $closing, titleVisibility: .visible) {
            Button("It’s closed") { store.live?.closeAccount(base, true) }
        } message: { Text("It leaves your accounts. Its payments stay in your spending and history.") }
        .confirmationDialog("Not your household’s?", isPresented: $disowning, titleVisibility: .visible) {
            Button("It isn’t ours", role: .destructive) { store.live?.setHidden(a.id, true) }
        } message: { Text("kosh leaves it and its payments out. You can bring it back in Settings.") }
        .sheet(isPresented: $merging) {
            AccountPicker(title: "The same account as…", note: "Two ways your bank wrote one account. Their payments and balances become one.", accounts: others) { other in
                store.live?.mergeAccounts(base, AccountFixes.baseKey(other))
            }
            .presentationDetents([.medium])
            .obsidianSheet(obsidian)
        }
        .sheet(isPresented: $linking) {
            AccountPicker(title: "This card is for…", note: "Its payments move to that account and count in its balance.", accounts: others) { other in
                store.live?.linkDebitCard(bank: a.bank, card: a.debit?.first ?? "", to: other.last)
            }
            .presentationDetents([.medium])
            .obsidianSheet(obsidian)
        }
    }
    /// an account's key without whose half it is ("HDFC A/c ••7777 · me" → "HDFC A/c ••7777")
    static func baseKey(_ a: Account) -> String {
        guard let t = a.tag, a.id.hasSuffix(" · " + t) else { return a.id }
        return String(a.id.dropLast(t.count + 3))
    }
    func fixRow(_ sym: String, _ title: String, sub: String?, tint: Color = Color.kosh, _ act: @escaping () -> Void) -> some View {
        Button(action: act) {
            HStack(spacing: 12) {
                Image(systemName: sym).font(.system(size: 15, weight: .semibold)).foregroundStyle(tint).frame(width: 30)
                VStack(alignment: .leading, spacing: 1) {
                    Text(title).font(.system(.subheadline)).foregroundStyle(tint == Color.red ? Color.red : Color.primary)
                    if let sub, !sub.isEmpty { Text(sub).font(.system(.caption)).foregroundStyle(.secondary).lineLimit(1) }
                }
                Spacer(minLength: 8)
            }
            .frame(minHeight: 50)
            .contentShape(Rectangle())
        }
        .buttonStyle(.press)
    }
}

/// whose the account is: the household, a joint holding, or a name its mail is written to that's still to confirm
struct WhoseRow: View {
    @Environment(Store.self) private var store
    let a: Account
    var body: some View {
        let people: [PersonInfo] = store.snap.people
        let toConfirm: [PersonToConfirm] = store.snap.peopleToConfirm ?? []
        Menu {
            ForEach(people) { p in
                Button { store.live?.setOwner(a.id, p.id) } label: {
                    if a.owner == p.id { Label(p.id == "me" ? "You" : p.full, systemImage: "checkmark") } else { Text(p.id == "me" ? "You" : p.full) }
                }
            }
            if people.count > 1 {
                Button { store.live?.setOwner(a.id, "family") } label: {
                    if a.owner == "family" { Label("Joint", systemImage: "checkmark") } else { Text("Joint") }
                }
            }
            // only the names this account's own mail is written to, never every name kosh is asking about
            ForEach(toConfirm.filter { $0.id == a.owner || (a.joint ?? []).contains($0.id) }) { p in
                Button { store.live?.addPerson(name: p.full, rel: "") } label: { Label("Add " + p.full + " to the household", systemImage: "person.badge.plus") }
                Button(role: .destructive) { store.live?.setHidden("name:" + p.id, true) } label: { Label(p.full + " isn’t family", systemImage: "person.crop.circle.badge.xmark") }
            }
        } label: {
            HStack(spacing: 12) {
                Image(systemName: "person.crop.circle").font(.system(size: 15, weight: .semibold)).foregroundStyle(Color.kosh).frame(width: 30)
                VStack(alignment: .leading, spacing: 1) {
                    Text("Whose is it").font(.system(.subheadline)).foregroundStyle(Color.primary)
                    Text(WhoseRow.why(a, store)).font(.system(.caption)).foregroundStyle(.secondary).lineLimit(1)
                }
                Spacer(minLength: 8)
                Text(AccountPage.whoseWords(a, store)).font(.system(.subheadline)).foregroundStyle(.secondary).lineLimit(1)
                Image(systemName: "chevron.up.chevron.down").font(.system(.caption2, weight: .semibold)).foregroundStyle(.tertiary)
            }
            .frame(minHeight: 50)
            .contentShape(Rectangle())
        }
        .buttonStyle(.press)
    }
    /// why kosh thinks so, in a few words
    static func why(_ a: Account, _ store: Store) -> String {
        if store.live?.owners[a.id] != nil { return "You said so" }
        if a.owner == "family" { return "Its mail is written to both of you" }
        if store.snap.peopleToConfirm?.contains(where: { $0.id == a.owner }) == true { return "Its mail is written to them. Add them?" }
        return "By the name its mail is written to"
    }
}

/// another account at the same bank, picked from a list
struct AccountPicker: View {
    @Environment(\.dismiss) private var dismiss
    let title: String
    let note: String
    let accounts: [Account]
    let pick: (Account) -> Void
    var body: some View {
        NavigationStack {
            ObsidianList {
                Section {
                    ForEach(accounts) { o in
                        Button { pick(o); dismiss() } label: {
                            HStack {
                                Text(AccountPage.title(o)).foregroundStyle(Color.primary)
                                Spacer()
                                Text(o.last.isEmpty ? "" : "••" + o.last).monospacedDigit().foregroundStyle(.secondary)
                            }
                        }
                    }
                } footer: { Text(note) }
            }
            .navigationTitle(title)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } } }
        }
    }
}

/// what you said about your accounts, kept as the engine reads it (prof.acctFix)
extension LiveSession {
    struct AcctFix: Codable {
        var merge: [[String]]? = nil
        var split: [String: Bool]? = nil
        var confirm: [String: Bool]? = nil
        var closed: [String: Bool]? = nil
        var names: [String: String]? = nil
        var cards: [String: String]? = nil
        /// a payment's account, by its mail's id; a statement's, by its file
        var place: [String: String]? = nil
        var stmt: [String: String]? = nil
        /// (ppf-owner-4nov) a PPF by its key (inst|last4): "closed" (closed or paid out), "notppf", "same:<key>"
        var ppf: [String: String]? = nil
    }
    var acctFix: AcctFix {
        get { acctFixJSON.data(using: .utf8).flatMap { try? JSONDecoder().decode(AcctFix.self, from: $0) } ?? AcctFix() }
        set { if let d = try? JSONEncoder().encode(newValue), let s = String(data: d, encoding: .utf8) { acctFixJSON = s == "{}" ? "" : s } }
    }
    func isMerged(_ key: String) -> Bool { (acctFix.merge ?? []).contains { $0.contains(key) } }
    func mergeAccounts(_ a: String, _ b: String) {
        var f = acctFix
        var m: [[String]] = f.merge ?? []
        if !m.contains(where: { Set($0) == Set([a, b]) }) { m.append([a, b]) }
        f.merge = m
        acctFix = f
    }
    func unmergeAccounts(_ key: String) {
        var f = acctFix
        let m: [[String]] = (f.merge ?? []).filter { !$0.contains(key) }
        f.merge = m.isEmpty ? nil : m
        acctFix = f
    }
    func splitAccount(_ key: String, _ on: Bool) {
        var f = acctFix
        var s: [String: Bool] = f.split ?? [:]
        s[key] = on ? true : nil
        f.split = s.isEmpty ? nil : s
        acctFix = f
    }
    /// yes, this account only a shop's or an app's mail names is ours
    func confirmAccount(_ key: String) {
        var f = acctFix
        var c: [String: Bool] = f.confirm ?? [:]
        c[key] = true
        f.confirm = c
        acctFix = f
    }
    /// (ppf-owner-4nov) what you said of a PPF: closed, not a PPF, the same as another; nil takes it back
    func setPPF(_ key: String, _ said: String?) {
        var f = acctFix
        var m: [String: String] = f.ppf ?? [:]
        m[key] = said
        f.ppf = m.isEmpty ? nil : m
        acctFix = f
    }
    func closeAccount(_ key: String, _ on: Bool) {
        var f = acctFix
        var c: [String: Bool] = f.closed ?? [:]
        c[key] = on ? true : nil
        f.closed = c.isEmpty ? nil : c
        acctFix = f
    }
    func nameAccount(_ key: String, _ name: String) {
        var f = acctFix
        var n: [String: String] = f.names ?? [:]
        let t: String = name.trimmingCharacters(in: .whitespacesAndNewlines)
        n[key] = t.isEmpty ? nil : String(t.prefix(40))
        f.names = n.isEmpty ? nil : n
        acctFix = f
    }
    /// the payments (or statements) kosh couldn't place at a bank: all of them that account's
    func placeUnplaced(_ u: AcctUnplaced, to l4: String) {
        guard !l4.isEmpty else { return }
        var f = acctFix
        if u.why == "statement" {
            var s: [String: String] = f.stmt ?? [:]
            for src in u.srcs ?? [] { s[src] = l4 }
            f.stmt = s.isEmpty ? nil : s
        } else {
            var p: [String: String] = f.place ?? [:]
            for id in u.ids ?? [] { p[id] = l4 }
            f.place = p.isEmpty ? nil : p
        }
        acctFix = f
    }
    func linkDebitCard(bank: String, card: String, to l4: String) {
        guard !card.isEmpty, !l4.isEmpty else { return }
        var f = acctFix
        var c: [String: String] = f.cards ?? [:]
        c[bank + "|" + card] = l4
        f.cards = c
        acctFix = f
    }
}

/// today's balance, as your bank's app shows it: carried forward from now on
struct BalanceEditor: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    let a: Account
    @State private var text = ""
    @FocusState private var focused: Bool
    var typed: Bool { store.live?.typedBalances[a.id] != nil }
    var acctName: String { a.last.isEmpty ? a.bank : a.bank + " ••" + a.last }
    static func footer(_ a: Account) -> String {
        let app: String = a.kind == "wallet" ? "the " + a.bank + " app" : "your bank’s app"
        return "Open " + app + " and type the balance it shows. kosh carries it forward with every payment from now on, until a newer statement or alert says otherwise."
    }
    var body: some View {
        NavigationStack {
            ObsidianForm {
                Section {
                    HStack {
                        Text("₹").font(.title.weight(.semibold)).foregroundStyle(.secondary)
                        TextField("0", text: $text).keyboardType(.decimalPad).font(.title.weight(.semibold)).focused($focused)
                    }
                } header: {
                    Text(acctName)
                } footer: {
                    Text(BalanceEditor.footer(a))
                }
                if typed {
                    Section {
                        Button("Stop using the balance I typed", role: .destructive) {
                            store.live?.setBalance(a.id, nil)
                            dismiss()
                        }
                    }
                }
            }
            .navigationTitle("Balance")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        if let v = Double(text.replacingOccurrences(of: ",", with: "").trimmingCharacters(in: .whitespaces)) {
                            store.live?.setBalance(a.id, TypedAmount.cap(v))
                        }
                        dismiss()
                    }
                    .disabled(Double(text.replacingOccurrences(of: ",", with: "").trimmingCharacters(in: .whitespaces)) == nil)
                }
            }
            .onAppear { focused = true }
        }
    }
}


/// (dcard-4nov) an account's cards: each debit card of it (a guess said as one, when its bank has several of your
/// accounts), and the same bank's credit cards in the holder's name, each opening its own page
struct AccountCards: View {
    let a: Account
    let cards: [CardInfo]
    var body: some View {
        let debit: [String] = a.debit ?? []
        let guess: Set<String> = Set(a.debitGuess ?? [])
        if !debit.isEmpty || !cards.isEmpty {
            VStack(alignment: .leading, spacing: 8) {
                GroupLabel(title: "Cards", figure: String(debit.count + cards.count), money: false)
                VStack(spacing: 0) {
                    ForEach(Array(debit.enumerated()), id: \.element) { i, d in
                        if i > 0 { RowRule(inset: 16) }
                        HStack {
                            VStack(alignment: .leading, spacing: 2) {
                                Text("Debit card ••" + d).font(.system(.body, weight: .semibold))
                                Text(guess.contains(d) ? "On this account by kosh’s best guess · change it below" : "Pays from this account")
                                    .font(.system(.footnote)).foregroundStyle(.secondary)
                            }
                            Spacer()
                        }
                        .padding(.vertical, 10).padding(.horizontal, 16)
                    }
                    ForEach(Array(cards.enumerated()), id: \.element.id) { i, c in
                        if i > 0 || !debit.isEmpty { RowRule(inset: 16) }
                        HStack {
                            VStack(alignment: .leading, spacing: 2) {
                                Text((c.product ?? c.name) + " ••" + c.last).font(.system(.body, weight: .semibold))
                                Text(c.due.map { "Credit card · last bill " + Fmt.rupees($0) } ?? "Credit card from the same bank").font(.system(.footnote)).foregroundStyle(.secondary)
                            }
                            Spacer()
                        }
                        .padding(.vertical, 10).padding(.horizontal, 16)
                    }
                }
                .rowsCard()
            }
        }
    }
}
