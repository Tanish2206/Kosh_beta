import SwiftUI

// MARK: - Wealth's own pieces, in the Obsidian look
//
// The outlined pills, the big figure with its
// unit set small, whose money, a section's head, the split bar, and the line you drag a finger across. Each small and
// typed so the compiler never has to guess (the Mac's has given up on long view expressions before).

// (the page, `.obsidianPage()`, and the card, `.obsidianCard()`, are Obsidian.swift's, shared with Insurance)

/// a row of outlined pills, one picked (filled in ink, black words): a range, a sort, a grouping. Whose money is
/// Obsidian.swift's boxed `ObsidianChips`
struct WealthPills: View {
    @Environment(\.accessibilityReduceMotion) private var still
    let options: [(id: String, label: String)]
    @Binding var selection: String
    var mono: Bool = false
    var height: CGFloat = 34

    var body: some View {
        HStack(spacing: 6) {
            ForEach(options.indices, id: \.self) { (i: Int) in
                pill(options[i].id, options[i].label)
            }
        }
        .sensoryFeedback(.selection, trigger: selection)
    }

    func pill(_ id: String, _ label: String) -> some View {
        let on: Bool = id == selection
        let fill: Color = on ? Obsidian.ink : Color.clear
        let edge: Color = on ? Obsidian.ink : Color.white.opacity(0.12)
        let font: Font = mono ? .system(size: 12, weight: .regular, design: .monospaced) : .system(size: 12.5, weight: .medium)
        return Button {
            withAnimation(still ? nil : Motion.base) { selection = id }
        } label: {
            Text(label)
                .font(font)
                .foregroundStyle(on ? Color.black : Obsidian.ink2)
                .lineLimit(1)
                .padding(.horizontal, 11)
                .frame(minWidth: 44, minHeight: height)
                .background(Capsule().fill(fill))
                .overlay(Capsule().stroke(edge, lineWidth: 1))
                .contentShape(Capsule())
        }
        .buttonStyle(.press)
        .accessibilityAddTraits(on ? .isSelected : [])
    }
}

/// "₹1.58" large and "CR" small beside it: the figure is what the eye reads, the unit only says its size
struct WealthFigure: View {
    let value: Double
    var size: CGFloat = 56
    var signed: Bool = false

    var body: some View {
        let parts: (String, String) = Self.split(signed ? Fmt.signedWords(value) : Fmt.words(value))
        HStack(alignment: .firstTextBaseline, spacing: 3) {
            Text(parts.0)
                .font(.system(size: size, weight: .semibold))
                .tracking(-size * 0.04)
                .monospacedDigit()
                .contentTransition(.numericText(value: value))
            if !parts.1.isEmpty {
                Text(parts.1)
                    .font(.system(size: size * 0.46, weight: .medium))
                    .foregroundStyle(Obsidian.ink2)
            }
        }
        .foregroundStyle(Obsidian.ink)
        .lineLimit(1)
        .minimumScaleFactor(0.6)
        .privacySensitive()
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(signed ? Fmt.signedWords(value) : Fmt.words(value))
    }

    /// "₹1.58CR" → ("₹1.58", "CR"); "₹25.4L" → ("₹25.4", "L"); "₹2,30,908" → ("₹2,30,908", "")
    static func split(_ s: String) -> (String, String) {
        for unit in ["CR", "L"] where s.hasSuffix(unit) { return (String(s.dropLast(unit.count)), unit) }
        return (s, "")
    }
}

/// You / Asha / Ravi / All: whose money the page shows (the app's own picker, store.who), a first name each, on one line
/// that scrolls when the family is large (his ask, 1 Nov: the boxed chips wrapped full names); hidden with one person
struct WhoseSwitch: View {
    @Environment(Store.self) private var store
    var body: some View {
        if store.whoOptions.count > 2 {
            ObsidianSegments(items: items, picked: whoBinding)
                .accessibilityLabel("Whose money")
        }
    }
}

extension WhoseSwitch {
    /// each person by first name ("You" for the phone's owner; the full name when two share a first name), then
    /// everyone: "Both" for two, "All" past that
    var items: [(id: String, label: String)] {
        let people: [Person] = store.whoOptions.filter { $0 != .family }
        let firsts: [String] = people.map { (p: Person) -> String in Self.first(p.title) }
        var out: [(id: String, label: String)] = []
        for (i, p) in people.enumerated() {
            let shared: Bool = firsts.filter { $0 == firsts[i] }.count > 1
            out.append((id: p.id, label: shared ? p.title : firsts[i]))
        }
        out.append((id: Person.family.id, label: people.count == 2 ? "Both" : "All"))
        return out
    }
    static func first(_ name: String) -> String {
        let w: String = name.split(separator: " ").first.map(String.init) ?? name
        return w.isEmpty ? name : w
    }
    var whoBinding: Binding<String> {
        let s: Store = store
        return Binding<String>(get: { s.who.id }, set: { (id: String) in s.who = s.personFor(id) })
    }
}

/// whose money, as a dropdown for a title's line: "All ⌄" in a dark capsule; its menu lists each person and everyone,
/// the one on show ticked (1 Nov: the row of segments under the title took a line of its own)
struct WhoseMenu: View {
    @Environment(Store.self) private var store
    var body: some View {
        if store.whoOptions.count > 2 {
            // (worked out here, from this view's own store: a WhoseSwitch made inside a body has no environment, and
            // reading its store there stops the app — 1 Nov, the Wealth tab)
            let items: [(id: String, label: String)] = Self.items(store)
            let now: String = items.first { $0.id == store.who.id }?.label ?? "All"
            let s: Store = store
            let pick: Binding<String> = Binding<String>(get: { s.who.id }, set: { (id: String) in s.who = s.personFor(id) })
            Menu {
                Picker("Whose money", selection: pick) {
                    ForEach(items, id: \.id) { it in Text(it.label).tag(it.id) }
                }
            } label: {
                HStack(spacing: 6) {
                    Image(systemName: store.who == .family ? "person.2.fill" : "person.fill").font(.system(size: 11, weight: .semibold))
                    Text(now).font(.system(size: 14, weight: .semibold)).lineLimit(1)
                    Image(systemName: "chevron.down").font(.system(size: 10, weight: .bold))
                }
                .foregroundStyle(Obsidian.ink)
                .padding(.horizontal, 13).frame(minHeight: 34)
                .background(Color.white.opacity(0.08), in: Capsule())
                .overlay(Capsule().strokeBorder(Color.white.opacity(0.10), lineWidth: 1))
                .contentShape(Capsule())
            }
            .accessibilityLabel("Whose money")
            .accessibilityValue(now)
            .sensoryFeedback(.selection, trigger: store.who.id)
        }
    }
    static func items(_ store: Store) -> [(id: String, label: String)] {
        let people: [Person] = store.whoOptions.filter { $0 != .family }
        let firsts: [String] = people.map { (p: Person) -> String in WhoseSwitch.first(p.title) }
        var out: [(id: String, label: String)] = []
        for (i, p) in people.enumerated() {
            let shared: Bool = firsts.filter { $0 == firsts[i] }.count > 1
            out.append((id: p.id, label: shared ? p.title : firsts[i]))
        }
        out.append((id: Person.family.id, label: people.count == 2 ? "Both" : "All"))
        return out
    }
}

/// a section's head: its title, and something quiet or a way on at the right
struct WealthSectionHead<Trailing: View>: View {
    let title: String
    @ViewBuilder var trailing: () -> Trailing
    var body: some View {
        HStack(alignment: .firstTextBaseline) {
            Text(title)
                .font(.system(size: 20, weight: .semibold))
                .tracking(-0.3)
                .foregroundStyle(Obsidian.ink)
                .accessibilityAddTraits(.isHeader)
            Spacer(minLength: 8)
            trailing()
        }
    }
}

/// "Deposits ›": a way on from a section's head
struct WealthMore: View {
    let label: String
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            HStack(spacing: 3) {
                Text(label).font(.system(size: 13))
                Image(systemName: "chevron.right").font(.system(size: 11, weight: .semibold))
            }
            .foregroundStyle(Obsidian.ink2)
            .frame(minHeight: 44)
            .contentShape(Rectangle())
        }
        .buttonStyle(.press)
    }
}

/// a strip split by share, each part in its own colour, with a small gap between
struct WealthSplitBar: View {
    let parts: [(id: String, v: Double, color: Color)]
    var height: CGFloat = 12
    var gap: CGFloat = 3

    var body: some View {
        GeometryReader { geo in
            let total: Double = parts.reduce(0) { $0 + max(0, $1.v) }
            let room: CGFloat = max(0, geo.size.width - gap * CGFloat(max(0, parts.count - 1)))
            HStack(spacing: gap) {
                ForEach(parts.indices, id: \.self) { (i: Int) in
                    let v: Double = max(0, parts[i].v)
                    let w: CGFloat = total > 0 ? room * CGFloat(v / total) : 0
                    RoundedRectangle(cornerRadius: 4, style: .continuous)
                        .fill(parts[i].color)
                        .frame(width: max(2, w))
                }
            }
        }
        .frame(height: height)
        .accessibilityHidden(true)
    }
}

/// net worth month by month as a line; drag a finger across it to read any month. Path and a drag, nothing heavier
struct WealthLine: View {
    let pts: [NWPoint]
    let color: Color
    @Binding var pick: Int?

    var body: some View {
        GeometryReader { geo in
            let size: CGSize = geo.size
            let xy: [CGPoint] = Self.place(pts.map(\.v), in: size)
            ZStack(alignment: .topLeading) {
                Path { p in
                    p.move(to: CGPoint(x: 0, y: size.height - 10))
                    p.addLine(to: CGPoint(x: size.width, y: size.height - 10))
                }
                .stroke(Color.white.opacity(0.08), lineWidth: 1)
                Self.area(xy, floor: size.height - 10)
                    .fill(LinearGradient(colors: [color.opacity(0.30), color.opacity(0)], startPoint: .top, endPoint: .bottom))
                Self.line(xy)
                    .stroke(color, style: StrokeStyle(lineWidth: 2.2, lineCap: .round, lineJoin: .round))
                marker(xy, height: size.height - 10)
            }
            .contentShape(Rectangle())
            .gesture(
                DragGesture(minimumDistance: 0)
                    .onChanged { (v: DragGesture.Value) in
                        let i: Int = Self.index(at: v.location.x, width: size.width, count: pts.count)
                        if pick != i { pick = i }
                    }
                    .onEnded { _ in pick = nil }
            )
        }
        .sensoryFeedback(.selection, trigger: pick)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("Net worth over time")
    }

    @ViewBuilder func marker(_ xy: [CGPoint], height: CGFloat) -> some View {
        let i: Int = pick ?? (xy.count - 1)
        if i >= 0 && i < xy.count {
            let at: CGPoint = xy[i]
            if pick != nil {
                Path { p in
                    p.move(to: CGPoint(x: at.x, y: 0))
                    p.addLine(to: CGPoint(x: at.x, y: height))
                }
                .stroke(Color.white.opacity(0.35), style: StrokeStyle(lineWidth: 1, dash: [2, 3]))
            }
            Circle().fill(color.opacity(0.18)).frame(width: 24, height: 24).position(at)
            Circle().fill(Color.black).frame(width: 10, height: 10).overlay(Circle().stroke(color, lineWidth: 2.5)).position(at)
        }
    }

    /// each value's place: across the width, and up the height between the least and the most (a flat line sits low)
    static func place(_ vs: [Double], in size: CGSize) -> [CGPoint] {
        guard vs.count > 1 else { return [] }
        let lo: Double = vs.min() ?? 0
        let hi: Double = vs.max() ?? 0
        let span: Double = hi - lo
        let top: CGFloat = 14
        let bottom: CGFloat = size.height - 20
        let step: CGFloat = size.width / CGFloat(vs.count - 1)
        var out: [CGPoint] = []
        for (i, v) in vs.enumerated() {
            let f: CGFloat = span > 0 ? CGFloat((v - lo) / span) : 0
            out.append(CGPoint(x: CGFloat(i) * step, y: bottom - f * (bottom - top)))
        }
        return out
    }
    static func line(_ xy: [CGPoint]) -> Path {
        Path { p in
            guard let first = xy.first else { return }
            p.move(to: first)
            for q in xy.dropFirst() { p.addLine(to: q) }
        }
    }
    static func area(_ xy: [CGPoint], floor: CGFloat) -> Path {
        Path { p in
            guard let first = xy.first, let last = xy.last else { return }
            p.move(to: CGPoint(x: first.x, y: floor))
            for q in xy { p.addLine(to: q) }
            p.addLine(to: CGPoint(x: last.x, y: floor))
            p.closeSubpath()
        }
    }
    static func index(at x: CGFloat, width: CGFloat, count: Int) -> Int {
        guard count > 1, width > 0 else { return 0 }
        let f: CGFloat = min(1, max(0, x / width))
        return Int((f * CGFloat(count - 1)).rounded())
    }
}

/// a row that opens another page, in the Obsidian look: its name, a quiet line, a chevron
struct WealthLinkRow: View {
    let title: String
    let sub: String
    let color: Color
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            HStack(spacing: 12) {
                Circle().fill(color).frame(width: 8, height: 8)
                VStack(alignment: .leading, spacing: 3) {
                    Text(title).font(.system(size: 15, weight: .medium)).foregroundStyle(Obsidian.ink)
                    Text(sub).font(.system(size: 12.5)).foregroundStyle(Obsidian.ink3).lineLimit(2).privacySensitive()
                }
                Spacer(minLength: 8)
                Image(systemName: "chevron.right").font(.system(size: 12, weight: .semibold)).foregroundStyle(Obsidian.ink3)
            }
            .padding(.vertical, 14)
            .padding(.horizontal, 16)
            .contentShape(Rectangle())
        }
        .buttonStyle(.press)
    }
}

/// "in 41 days", "tomorrow", "today"
enum WealthDays {
    static func until(_ day: String, today: String) -> String {
        let n: Int = Day.between(today, day)
        if n <= 0 { return "today" }
        if n == 1 { return "tomorrow" }
        return "in \(n) days"
    }
}
