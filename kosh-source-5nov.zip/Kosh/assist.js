/* kosh assist: what needs doing, worked out from what kosh already read (ASSISTANT.md §3). One action per real-world
   thing, however many mails tell it; each says when it is for, why kosh thinks so (the mails, with their days and the
   line read), the money at stake and where it stands; each closes itself when the evidence says it's done.

     id     kind + the thing's own key: "refund|order:EX4021987", "refund|<the payment refunded>", "due|<the calendar's
            id: month|day|name>". Stable across builds and re-reads: the person's done, snoozed and dismissed are kept by it
     kind   refund · due · pickup · delivery · attempt · cardfee · dispute · cas (tripdoc and settle wait on his decisions: §8)
     ink    now (today or gone by) · soon (within a week) · watch (kosh is only watching)
     state  open · closed (the evidence closed it) · done · snoozed · dismissed (the person: prof.actions)

   The rule that decides everything here: an action kosh is not sure of is never made. Sure is a day that was printed
   (in the mail, a statement, or by the person) and a key that is the thing's own (an order number, the payment, the
   calendar's item); never a shop's name alone, never a day kosh worked out. A refund with no promised day makes none.

   This file decides what is to be done; it never works out a figure. Every rupee is a field another part made: a
   refund's from snap.refunds and snap.refundPromises (engine/21b), a bill's from snap.agenda (21e). It is outside every
   reading fingerprint (ReadingPrint in LiveCore.swift), like agent.js: changing it never reads a mail again.

   Loaded after journey.js and agent.js (LiveCore.swift's list); it hangs off build() (E.postBuild): snap.actions. */

var KoshAssist = (function (E) {
  'use strict';
  // (in Node, the journey first: its threads are the evidence here. On the phone, LiveCore's order sees to it)
  if (typeof require === 'function' && typeof module !== 'undefined') { try { require('./journey.js'); } catch (e) { /* the tests load it */ } }
  var L = (E && E.lib) || {};
  var inr = L.inr || function (n) { return '₹' + Math.round(n); };
  var SOON = 7;          // a bill due within a week is "soon"
  var KEEP = 7;          // what closed itself stays this many days, so Today and the briefing can say it did
  var BEHIND = 7;        // a bill gone by stays this long (the calendar drops a card bill three days on)

  /* ------------------------------------------------------------ small things */
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function isDay(s) { return /^\d{4}-\d{2}-\d{2}$/.test(String(s || '')); }
  function dayN(iso) { var p = String(iso || '').slice(0, 10).split('-'); return Date.UTC(+p[0], +p[1] - 1, +p[2]) / 864e5; }
  function isoN(n) { var d = new Date(n * 864e5); return d.getUTCFullYear() + '-' + pad(d.getUTCMonth() + 1) + '-' + pad(d.getUTCDate()); }
  function addDays(iso, n) { return isoN(dayN(iso) + n); }
  function money(n) { return Math.round((+n || 0) * 100) / 100; }
  var MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  function dShort(iso) { return isDay(iso) ? +iso.slice(8, 10) + ' ' + MON[+iso.slice(5, 7) - 1] : ''; }
  function orderKey(s) { var k = String(s || '').replace(/[^A-Za-z0-9]/g, '').toUpperCase(); return k.length >= 3 ? k : ''; }
  // a refund's own key: its order's number, else the payment it refunds (a promise with neither has none)
  function refundKey(r) {
    var o = orderKey(r.order);
    if (o) return 'order:' + o;
    return r.id && String(r.id).indexOf('promise|') !== 0 ? String(r.id) : '';
  }

  // the evidence, oldest first: one row a mail says once (a mail read into two steps of one kind is one)
  function evidence(list) {
    var seen = {};
    return list.filter(function (e) { var k = (e.mail || e.from) + '|' + e.step; if (seen[k]) return false; seen[k] = 1; return true; })
      .sort(function (x, y) { return String(x.d).localeCompare(String(y.d)); });
  }

  /* ------------------------------------------------------------ is it sure? (ASSISTANT.md §3.5) */
  function sure(a) {
    if (!a || !a.kind || !isDay(a.due)) return false;
    var key = String(a.id || '').slice(a.kind.length + 1);
    return String(a.id || '').indexOf(a.kind + '|') === 0 && key.replace(/[^A-Za-z0-9]/g, '').length >= 3;
  }

  /* ------------------------------------------------------------ refunds: promised, sent, back, late (engine/21b) */
  function refundActions(snap, today) {
    var out = [], threads = snap.threads || [];
    var rows = (snap.refunds || []).concat(snap.refundPromises || []);
    rows.forEach(function (r) {
      if (!r || !r.by) return;   // no day promised or set: tracked on the Refunds page, never a reminder
      var key = refundKey(r);
      if (!key) return;
      var who = r.m || 'the shop', back = r.stage === 'back';
      // the money at stake, as the Refunds page shows it: what came back once it has, else what's still to come
      var amt = r.state === 'back' ? money(r.exp) : money(Math.max(0, r.exp - r.back));
      var mails = r.mails || [], said = mails[mails.length - 1] || null, sentBy = mails.filter(function (m) { return m.sent; })[0] || null;
      var a = { id: 'refund|' + key, kind: 'refund', due: r.by, amt: amt, ref: r.id, owner: r.o || undefined };
      var ev = mails.map(function (m) { var e = { d: m.d, mail: m.id, from: who, step: m.sent ? 'refund sent' : 'refund promised' }; if (m.q) e.q = m.q; return e; });
      (r.credits || []).forEach(function (c) { ev.push({ d: c.d, mail: c.id, from: c.m || '', step: c.shop ? 'the shop’s word, booked' : 'came back' }); });
      if (r.src === 'you') ev.unshift({ d: r.d, mail: r.id, from: r.m || '', step: 'you marked it' });
      if (r.lateWhy === 'statement' && r.stmt) ev.push({ d: r.stmt.to, from: (r.stmt.inst ? r.stmt.inst + ' ' : '') + '••' + r.stmt.last4, step: 'statement without it' });
      a.ev = evidence(ev);
      if (back) {
        var last = (r.credits || []).filter(function (c) { return !c.shop; }).sort(function (x, y) { return String(x.d).localeCompare(String(y.d)); }).pop();
        if (!last || last.d < addDays(today, -KEEP)) return;   // (it came back a while ago: the Refunds page has it)
        a.state = 'closed'; a.ink = 'watch';
        a.closed = { d: last.d, what: 'came back', mail: last.id };
        a.title = inr(amt) + ' refund from ' + who + ' came back';
        a.why = 'On ' + dShort(last.d) + (last.m ? ', ' + last.m : '') + '.';
        a.can = [];
      } else if (r.state === 'late') {
        a.state = 'open'; a.ink = 'now';
        a.title = inr(amt) + ' refund from ' + who + ' is late';
        a.why = r.lateWhy === 'statement' && r.stmt
          ? 'It should have landed by ' + dShort(r.by) + '. It isn’t on your ' + (r.stmt.inst ? r.stmt.inst + ' ' : '') + '••' + r.stmt.last4 + ' statement to ' + dShort(r.stmt.to) + '.'
          : 'You expected it by ' + dShort(r.by) + ', and it hasn’t come back yet.';
        a.can = ['got', 'snooze', 'wrong'];
      } else {
        a.state = 'open'; a.ink = 'watch';
        a.title = inr(amt) + ' refund from ' + who;
        a.why = r.src === 'you' ? 'You expect it by ' + dShort(r.by) + '.'
          : sentBy ? who + ' said on ' + dShort(sentBy.d) + ' it has sent it, to land by ' + dShort(r.by) + '. Your bank hasn’t shown it yet.'
          : who + (said ? ' said on ' + dShort(said.d) : ' said') + ' it would be back by ' + dShort(r.by) + '.';
        a.can = ['got', 'snooze', 'wrong'];
      }
      // its thread: the order's whole story, else the refund's own
      var oid = orderKey(r.order);
      var th = (oid && threads.filter(function (t) { return t.kind === 'order' && orderKey(t.order) === oid; })[0]) ||
        threads.filter(function (t) { return t.kind === 'refund' && mails.some(function (m) { return t.id === 'refund:' + m.id; }); })[0];
      if (th) a.thread = th.id;
      out.push(a);
    });
    return out;
  }

  /* ------------------------------------------------------------ bills due: the calendar's own (snap.agenda)
     Only what the mail printed the day of: a card's statement, a biller's own bill, a free trial's end. Never a repeat
     kosh learnt from the spending (its day is kosh's guess), never what an auto-debit pays by itself */
  function printed(a) { return a.cat === 'Card Payments' || a.sub === 'Due, from your mail' || !!a.trial; }
  function calId(a) { return a.m + '|' + (a.date || 'any') + '|' + a.name; }
  function words(s) { return String(s || '').toLowerCase().replace(/[^a-z0-9 ]+/g, ' ').split(/\s+/).filter(function (w) { return w.length >= 3 && !/^(?:bill|card|the|and|ltd|limited|pvt|payment)$/.test(w); }); }
  // the thread the bill is from (journey.js): the card's statement of that due day, or the biller's bill of it
  function billThread(a, threads) {
    var l4 = (/••(\d{2,4})\b/.exec(a.name) || [])[1] || '';
    if (a.cat === 'Card Payments') {
      var c = threads.filter(function (t) { return t.kind === 'card' && l4 && String(t.last4 || '').slice(-l4.length) === l4 && (t.cycles || []).some(function (cy) { return cy.due === a.date; }); })[0];
      if (c) return { t: c, steps: (c.cycles.filter(function (cy) { return cy.due === a.date; })[0] || {}).steps || [] };
      return null;
    }
    var w = words(a.name);
    var b = threads.filter(function (t) { return t.kind === 'bill' && words(t.title).some(function (x) { return w.indexOf(x) >= 0; }) && (t.items || []).some(function (it) { return it.due === a.date; }); })[0];
    return b ? { t: b, steps: (b.items.filter(function (it) { return it.due === a.date; })[0] || {}).steps || [] } : null;
  }
  /* ------------------------------------------------------------ parcels (the journey's order threads, round three)
     One action per parcel (its order's number, else its tracking number), however many of the shop's and the courier's
     mails tell it. A return's pickup booked for a printed day (and window) until it's picked up; a delivery out today,
     or on its way with a printed day, until it's delivered (the cash to keep ready when the mail says it's cash on
     delivery); a missed delivery or pickup, or one held for collection, with what to do next and by when, until it's
     delivered or picked up. In transit with no day says nothing; a food or quick-commerce order arrives in minutes
     and says nothing either */
  var INSTANT = /\b(?:swiggy|zomato|blinkit|zepto|instamart|dunzo|eatsure|swish|bb ?now|bigbasket now|magicpin)\b/i;
  var NEXT_WORDS = { retry: 'The courier will try again', reschedule: 'Pick a new day with the courier', collect: 'Collect it from the courier', contact: 'Call the courier' };
  // where a parcel stands: its furthest step (delivered, picked up close it), the latest of those as far along (a late
  // "in transit" after "out" or "delivered" moves nothing back), as the journey's order status does
  var PARCEL_RANK = { shipped: 2, out: 3, attempted: 3, rescheduled: 3, held: 3, delivered: 4, 'pickup booked': 1, 'pickup missed': 1, 'pickup moved': 1, 'picked up': 2 };
  function standing(list) { return list.reduce(function (best, x) { return !best || (PARCEL_RANK[x.t] || 0) >= (PARCEL_RANK[best.t] || 0) ? x : best; }, null); }
  function parcelActions(snap, today) {
    var out = [];
    (snap.threads || []).forEach(function (t) {
      if (t.kind !== 'order' || INSTANT.test((t.shop || '') + ' ' + (t.title || ''))) return;
      var steps = (t.steps || []).filter(function (x) { return x.parcel || x.t === 'delivered' || x.t === 'picked up'; });
      if (!steps.some(function (x) { return x.parcel; })) return;
      var key = orderKey(t.order) ? 'order:' + orderKey(t.order) : orderKey(t.awb) ? 'awb:' + orderKey(t.awb) : '';
      if (!key) return;
      var who = t.shop || 'the shop';
      var ev = evidence(steps.map(function (x) { var e = { d: x.d, mail: x.mail, from: x.courier && x.courier !== who ? who + ' \u00b7 ' + x.courier : who, step: x.t }; if (x.q) e.q = x.q; return e; }));
      function make(kind) { return { id: kind + '|' + key, kind: kind, ev: ev, thread: t.id, ref: t.id }; }
      function win(x) { return x.win && (x.win.from || x.win.to) ? ', ' + (x.win.from || '') + (x.win.to ? '\u2013' + x.win.to : '') : ''; }
      // the way here: where it stands is its latest step on the way to the door
      var fwd = steps.filter(function (x) { return /^(?:shipped|out|attempted|rescheduled|held|delivered)$/.test(x.t); }), last = standing(fwd);
      if (last) {
        var tried = fwd.filter(function (x) { return x.t === 'attempted' || x.t === 'held'; }).pop();
        var cod = fwd.filter(function (x) { return x.cod > 0; }).map(function (x) { return x.cod; }).pop();
        if (last.t === 'delivered') {
          var had = fwd.some(function (x) { return x.parcel && ((x.t === 'out' && x.on) || (x.t === 'shipped' && x.on) || x.t === 'attempted' || x.t === 'held' || x.t === 'rescheduled'); });
          if (had && last.d >= addDays(today, -KEEP)) {
            var c = make(tried ? 'attempt' : 'delivery');
            c.due = last.d; c.state = 'closed'; c.ink = 'watch'; c.can = [];
            c.closed = { d: last.d, what: 'delivered', mail: last.mail };
            c.title = 'Parcel from ' + who + ' delivered'; c.why = 'On ' + dShort(last.d) + '.';
            out.push(c);
          }
        } else if (last.t === 'attempted' || last.t === 'held') {
          var by0 = last.until || last.by || last.on || '';
          if (isDay(by0) && by0 >= today) {
            var a = make('attempt');
            a.due = by0; a.state = 'open'; a.ink = 'now'; a.can = ['done', 'snooze', 'wrong'];
            a.title = last.t === 'held' ? 'Parcel from ' + who + ' waits to be collected' : 'Missed delivery from ' + who;
            a.why = (NEXT_WORDS[last.next] || (last.t === 'held' ? NEXT_WORDS.collect : 'See what the courier says')) + ' by ' + dShort(by0) + '.' + (cod ? ' It is cash on delivery: ' + inr(cod) + '.' : '');
            if (cod) a.amt = money(cod);
            out.push(a);
          }
        } else {
          // out today, or on its way (or moved) to a printed day
          var day = last.t === 'out' ? (last.on || '') : (last.on || last.by || '');
          if (isDay(day) && day >= today && day <= addDays(today, SOON) && (last.t !== 'out' || day === today)) {
            var d = make('delivery');
            d.due = day; d.state = 'open'; d.ink = day === today ? 'now' : 'watch'; d.can = ['got', 'snooze', 'wrong'];
            d.title = 'Parcel from ' + who + (day === today ? (last.t === 'out' ? ' is out for delivery' : ' arrives today') : ' arrives ' + dShort(day));
            d.why = (last.t === 'out' ? who + '\u2019s mail of ' + dShort(last.d) + ' says it is out for delivery' : who + '\u2019s mail of ' + dShort(last.d) + ' says it arrives ' + (day === today ? 'today' : dShort(day))) + win(last) + '.' +
              (cod ? ' Keep ' + inr(cod) + ' ready in cash: it is cash on delivery.' : '');
            if (cod) d.amt = money(cod);
            out.push(d);
          }
        }
      }
      // a return: its pickup, until it's picked up
      var back = steps.filter(function (x) { return /^(?:pickup booked|pickup missed|pickup moved|picked up)$/.test(x.t); }), rl = standing(back);
      if (!rl) return;
      if (rl.t === 'picked up') {
        if (back.some(function (x) { return x.t === 'pickup booked' && x.on; }) && rl.d >= addDays(today, -KEEP)) {
          var p0 = make('pickup');
          p0.due = rl.d; p0.state = 'closed'; p0.ink = 'watch'; p0.can = [];
          p0.closed = { d: rl.d, what: 'picked up', mail: rl.mail };
          p0.title = 'Return to ' + who + ' picked up'; p0.why = 'On ' + dShort(rl.d) + '.';
          out.push(p0);
        }
        return;
      }
      if (rl.t === 'pickup missed') {
        var by1 = rl.until || rl.by || rl.on || '';
        if (isDay(by1) && by1 >= today) {
          var m = make('attempt');
          m.due = by1; m.state = 'open'; m.ink = 'now'; m.can = ['done', 'snooze', 'wrong'];
          m.title = 'Return pickup missed'; m.why = (NEXT_WORDS[rl.next] || 'See what the courier says') + ' by ' + dShort(by1) + '.';
          out.push(m);
        }
        return;
      }
      if (isDay(rl.on) && rl.on >= today) {
        var p = make('pickup');
        p.due = rl.on; p.state = 'open'; p.ink = rl.on === today ? 'now' : rl.on <= addDays(today, SOON) ? 'soon' : 'watch'; p.can = ['ready', 'snooze', 'wrong'];
        p.title = 'Return pickup ' + (rl.on === today ? 'today' : dShort(rl.on));
        p.why = who + ' booked the courier for ' + dShort(rl.on) + win(rl) + '. Keep it packed.';
        out.push(p);
      }
    });
    return out;
  }

  function dueActions(snap, today) {
    var out = [], threads = snap.threads || [], seen = {};
    (snap.agenda || []).forEach(function (a) {
      if (!a || a.kind !== 'out' || !isDay(a.date) || a.learnt || a.auto || !printed(a)) return;
      if (a.date < addDays(today, -BEHIND) || a.date > addDays(today, SOON)) return;
      var id = 'due|' + calId(a);
      if (seen[id]) return;
      seen[id] = 1;
      var th = billThread(a, threads);
      var x = { id: id, kind: 'due', due: a.date, amt: money(a.amt), ref: calId(a) };
      x.ev = th ? evidence(th.steps.map(function (s) { var e = { d: s.d, mail: s.mail, from: th.t.title || '', step: s.t }; if (s.q) e.q = s.q; return e; })) : [];
      if (th) x.thread = th.t.id;
      var gone = a.date < today;
      if (a.trial) {
        x.title = a.name + ': free trial ends ' + (a.date === today ? 'today' : dShort(a.date));
        x.why = 'Its mail says the trial ends ' + dShort(a.date) + ', then ' + inr(a.amt) + ' is charged.';
      } else {
        x.title = a.name + (a.date === today ? ' due today' : gone ? ' was due ' + dShort(a.date) : ' due ' + dShort(a.date));
        x.why = (a.cat === 'Card Payments' ? 'The statement says ' : 'The bill says ') + inr(a.bill > 0 ? a.bill : a.amt) + ' is due by ' + dShort(a.date) + (a.cat === 'Card Payments' && /^Minimum /.test(a.sub || '') ? ' (' + a.sub.toLowerCase() + ')' : '') +
          // (paid in part: the calendar's figure is what is still to pay)
          (a.part > 0 ? '; ' + inr(a.part) + ' paid so far, ' + inr(a.amt) + ' to go.' : '.');
      }
      if (a.booked) {
        if (a.marked) { x.state = 'done'; x.ink = 'watch'; x.can = []; }
        else {
          var paid = th ? th.steps.filter(function (s) { return s.t === 'paid'; }).pop() : null;
          x.state = 'closed'; x.ink = 'watch'; x.can = [];
          x.closed = paid ? { d: paid.d, what: 'paid', mail: paid.mail } : { what: 'paid' };
          x.title = a.name + ' paid';
          x.why = paid ? 'Paid ' + inr(paid.amt) + ' on ' + dShort(paid.d) + '.' : 'Kosh saw it paid.';
        }
      } else {
        x.state = 'open'; x.ink = a.date <= today ? 'now' : 'soon';
        x.can = a.trial ? ['done', 'snooze', 'wrong'] : ['paid', 'snooze', 'wrong'];
      }
      out.push(x);
    });
    return out;
  }

  /* ------------------------------------------------------------ a card's annual fee (engine/21m: snap.cardFees)
     Only a day a mail printed, within a month: the fee, the spend that waives it and what kosh has seen spent in the
     card's year, all as the card's row has them. A day kosh would work out from last year's charge makes none */
  var FEE_AHEAD = 30;
  function cardFeeActions(snap, today) {
    var out = [];
    (snap.cardFees || []).forEach(function (c) {
      if (!c || !isDay(c.feeOn) || !c.said || c.feeOn < today || c.feeOn > addDays(today, FEE_AHEAD)) return;
      var name = (c.bank ? c.bank + ' ' : '') + '••' + c.last;
      var a = { id: 'cardfee|' + c.card + '|' + c.feeOn, kind: 'cardfee', due: c.feeOn, ref: c.card, state: 'open',
        ink: c.feeOn <= addDays(today, SOON) ? 'soon' : 'watch', can: ['done', 'snooze', 'wrong'] };
      if (c.fee > 0) a.amt = money(c.fee);
      if (c.owner) a.owner = c.owner;
      a.title = name + ' annual fee' + (c.fee > 0 ? ' of ' + inr(c.fee) : '') + ' on ' + dShort(c.feeOn);
      var w = 'Its mail of ' + dShort(c.said.d) + ' says the annual fee is charged on ' + dShort(c.feeOn) + '.';
      if (c.waive > 0 && c.spent >= 0 && c.yearFrom) w += ' Spend ' + inr(c.waive) + ' in the card’s year and it is waived: kosh has seen ' + inr(c.spent) + ' since ' + dShort(c.yearFrom) + (c.toWaive > 0 ? ', ' + inr(c.toWaive) + ' to go.' : ', enough.');
      if (c.unused) w += ' You haven’t used it since ' + dShort(c.lastUsed) + '.';
      a.why = w;
      var e = { d: c.said.d, mail: c.said.mail, from: c.bank || '', step: 'fee day printed' };
      if (c.said.q) e.q = c.said.q;
      a.ev = [e];
      out.push(a);
    });
    return out;
  }

  /* ------------------------------------------------------------ charged twice (engine/21m: snap.doubles)
     The note is the row's own, ready for the person to send from their mail app; kosh never sends it. A credit of the
     sum on the card closes it, and it stays a few days to say so */
  function disputeActions(snap, today) {
    var out = [];
    (snap.doubles || []).forEach(function (r) {
      if (!r || !isDay(r.d) || !r.ids || r.ids.length < 2) return;
      var a = { id: 'dispute|' + r.id, kind: 'dispute', due: r.d, amt: money(r.a), ref: r.id, note: r.note || '' };
      if (r.o) a.owner = r.o;
      a.ev = evidence(r.ids.map(function (id, i) { return { d: r.d, mail: id, from: r.acct || '', step: 'charged at ' + ((r.times || [])[i] || '') }; }));
      if (r.state === 'reversed' && r.back) {
        if (r.back.d < addDays(today, -KEEP)) return;
        a.state = 'closed'; a.ink = 'watch'; a.can = [];
        a.closed = { d: r.back.d, what: 'reversed', mail: r.back.id };
        a.title = inr(r.a) + ' charged twice at ' + (r.m || 'a shop') + ': reversed';
        a.why = 'Credited back on ' + dShort(r.back.d) + '.';
      } else {
        a.state = 'open'; a.ink = 'now'; a.can = ['done', 'snooze', 'wrong'];
        a.title = inr(r.a) + ' charged twice at ' + (r.m || 'a shop');
        a.why = 'Your ' + (r.acct || 'card') + ' was charged ' + inr(r.a) + ' at ' + (r.times || []).join(' and again at ') + ' on ' + dShort(r.d) + ', each told by its own alert. A note to the bank is ready for you to send.';
      }
      out.push(a);
    });
    return out;
  }

  /* ------------------------------------------------------------ no fund statement (engine/21n: snap.casGap)
     One per person, the gap's own id. Asking for a statement is the person's to do, on the registrar's own page
     (CAS-FAILSAFE.md); a statement that came locked is theirs to open with the password they chose. Never a figure */
  function casActions(snap, today) {
    var out = [];
    (snap.casGap || []).forEach(function (g) {
      if (!g || !g.id || !g.kind) return;
      var a = { id: g.id, kind: 'cas', due: g.kind === 'locked' && isDay(g.on) ? g.on : today, state: 'open', title: g.title || '', why: g.why || '',
        ink: g.kind === 'locked' ? 'now' : 'soon', can: g.ask ? ['ask', 'done', 'snooze', 'wrong'] : ['unlock', 'snooze'], ref: g.id };
      if (g.who) a.owner = g.who;
      a.ev = [];
      if (g.last) a.ev.push({ d: g.last, from: '', step: 'newest statement read' });
      if (g.signal && isDay(g.signal.d)) a.ev.push({ d: g.signal.d, from: '', step: g.signal.what === 'paid' ? 'money into funds' : g.signal.what === 'fund' ? 'a fund moved' : 'funds held' });
      if (g.kind === 'locked' && isDay(g.on)) a.ev.push({ d: g.on, from: g.sender || '', step: 'statement came, locked' });
      a.ev = evidence(a.ev);
      out.push(a);
    });
    return out;
  }

  /* ------------------------------------------------------------ the person's word (prof.actions, kept by action id)
     done: you did it (evidence closing it later just confirms it); snoozed: hidden until its day; dismissed ("not
     right"): never shown again for that key. Evidence closes what you said done or snoozed, never reopens what you
     dismissed */
  function withPerson(a, said, today) {
    if (!said || !said.s) return a;
    if (said.s === 'dismissed') { a.state = 'dismissed'; return a; }
    if (a.state === 'closed') return a;
    if (said.s === 'done') a.state = 'done';
    else if (said.s === 'snoozed' && isDay(said.until) && said.until > today && a.state === 'open') { a.state = 'snoozed'; a.until = said.until; }
    return a;
  }

  var STATE_RANK = { open: 0, snoozed: 1, closed: 2, done: 3, dismissed: 4 }, INK_RANK = { now: 0, soon: 1, watch: 2 };
  function actions(snap, prof) {
    prof = prof || {};
    var today = isDay(snap.today) ? snap.today : isDay(prof.today) ? prof.today : isoN(Math.floor(Date.now() / 864e5));
    var said = prof.actions || {};
    var all = refundActions(snap, today).concat(dueActions(snap, today), parcelActions(snap, today), cardFeeActions(snap, today), disputeActions(snap, today), casActions(snap, today)).filter(sure);
    // one action per thing: the first made stands (a key is one refund, one bill)
    var byId = {}, out = [];
    all.forEach(function (a) {
      if (byId[a.id]) return;
      byId[a.id] = 1;
      out.push(withPerson(a, said[a.id], today));
    });
    out.sort(function (x, y) {
      return (STATE_RANK[x.state] - STATE_RANK[y.state]) || (INK_RANK[x.ink] - INK_RANK[y.ink]) ||
        (x.state === 'closed' ? String((y.closed || {}).d || '').localeCompare(String((x.closed || {}).d || '')) : String(x.due).localeCompare(String(y.due))) || String(x.id).localeCompare(String(y.id));
    });
    return out;
  }

  var api = { actions: actions, sure: sure, refundKey: refundKey };
  if (E && E.postBuild) E.postBuild.push(function (snap, prof) { snap.actions = actions(snap, prof || {}); });
  if (E) E.assist = api;
  return api;
})(typeof KoshEngine !== 'undefined' ? KoshEngine : require('./engine.js'));
if (typeof module !== 'undefined' && module.exports) module.exports = KoshAssist;
