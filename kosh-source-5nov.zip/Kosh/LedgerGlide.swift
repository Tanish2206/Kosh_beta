import SwiftUI
import UIKit

// MARK: - Ledger glide: the list behind the day lens moves with the strip, frame for frame (smooth-5nov-b)
//
// While a finger drags the day strip (and while it coasts and settles after), the ledger moves with it: every display
// frame, the place the strip stands at (in days, 12.4) becomes a scroll offset, from where UIKit has each day's first
// payment laid out, and is set on the List's own scroll view. Nothing in SwiftUI is asked to scroll, so no view body
// runs for it: the list moves exactly as it does under a finger, and the cells it needs come in the same way.
// A jump a day at a time (scrollTo) made the list lay out under the finger and stuttered: this glides instead.
// - under the finger it follows within a few milliseconds; coasting and settling it eases (smooth-out), never bouncing
// - a tap many days away jumps once to just short of the day, then glides the rest
// - a finger on the list itself takes over at once
// - if the list isn't laid out as expected (sections ≠ days), it does nothing and the lens jumps as before

@MainActor final class LedgerGlide: NSObject {
    /// the ledger List's own scroll view, found from one of its rows (GlideHook)
    weak var cv: UICollectionView?
    weak var tracker: LensTracker?
    private weak var drag: LensDrag?
    /// a whole day to settle on (a tap, a let-go)
    private var goal: Double? = nil
    private var finger: Bool = false
    /// where the list stands now, in days from the newest
    private var cur: Double = 0
    private var link: CADisplayLink? = nil
    private var last: CFTimeInterval = 0
    /// a day heading's top less its first payment's top (learned from one on screen)
    private var delta: CGFloat = -36

    /// gliding now: the ledger's scroll is ours, not a person's
    var active: Bool { link != nil }

    /// a finger has the strip: the list follows it
    func hold(_ d: LensDrag) {
        guard ready() else { return }
        begin()
        drag = d
        goal = nil
        finger = true
    }

    /// the finger left the strip: the list carries on after it (coasting), easing
    func release() { finger = false }

    /// glide the list to a day's heading; false when the list can't be moved here (the caller jumps instead)
    func go(_ day: String) -> Bool {
        guard ready(), let k = tracker?.dayIndex(day) else { return false }
        begin()
        drag = nil
        finger = false
        goal = Double(k)
        return true
    }

    func stop() {
        link?.invalidate()
        link = nil
        tracker?.gliding = false
        FrameMeter.shared.run(false, "lens glide")
        drag = nil
        goal = nil
        finger = false
    }

    private func ready() -> Bool {
        guard let cv, cv.window != nil, let t = tracker else { return false }
        let n: Int = t.dayCount
        guard n > 0, cv.numberOfSections == n + 1 else { return false }
        return cv.numberOfItems(inSection: 1) == t.rows(0) && cv.numberOfItems(inSection: n) == t.rows(n - 1)
    }

    private func begin() {
        guard link == nil, let cv else { return }
        cur = tracker?.pos ?? 0
        // a list still coasting from a flick stops where it is
        if cv.isDecelerating { cv.setContentOffset(cv.contentOffset, animated: false) }
        learn(cv)
        let l = CADisplayLink(target: self, selector: #selector(step(_:)))
        l.preferredFrameRateRange = CAFrameRateRange(minimum: 80, maximum: 120, preferred: 120)
        l.add(to: .main, forMode: .common)
        link = l
        last = 0
        tracker?.gliding = true
        FrameMeter.shared.run(true, "lens glide")   // (smooth-5nov-c)
    }

    /// how far a heading sits above its day's first payment, from one on screen now (the list is still)
    private func learn(_ cv: UICollectionView) {
        guard let t = tracker else { return }
        for k in 0..<t.dayCount {
            guard let g = t.headGlobal(k), let a = cv.layoutAttributesForItem(at: IndexPath(item: 0, section: k + 1)) else { continue }
            let y: CGFloat = cv.convert(CGPoint(x: 0, y: g), from: nil).y
            let d: CGFloat = y - a.frame.minY
            if d < 0 && d > -120 { delta = d }
            return
        }
    }

    /// day k's heading top in the list's content (k == n: just past the last day)
    private func headY(_ cv: UICollectionView, _ k: Int, _ n: Int) -> CGFloat? {
        if k >= n {
            let c: Int = cv.numberOfItems(inSection: n)
            guard c > 0, let a = cv.layoutAttributesForItem(at: IndexPath(item: c - 1, section: n)) else { return nil }
            return a.frame.maxY + 14
        }
        guard let a = cv.layoutAttributesForItem(at: IndexPath(item: 0, section: k + 1)) else { return nil }
        return a.frame.minY + delta
    }

    /// the scroll offset that puts the list at p days (the day's heading at the top edge, plus f of the way to the next)
    private func offset(_ cv: UICollectionView, _ p: Double, _ n: Int) -> CGFloat? {
        let k: Int = min(n - 1, max(0, Int(p.rounded(.down))))
        let f: CGFloat = CGFloat(min(1, max(0, p - Double(k))))
        guard let y0 = headY(cv, k, n), let y1 = headY(cv, k + 1, n) else { return nil }
        let y: CGFloat = y0 + (y1 - y0) * f - cv.adjustedContentInset.top
        let lo: CGFloat = -cv.adjustedContentInset.top
        let hi: CGFloat = max(lo, cv.contentSize.height + cv.adjustedContentInset.bottom - cv.bounds.height)
        return min(hi, max(lo, y))
    }

    @objc private func step(_ l: CADisplayLink) {
        guard let cv, cv.window != nil, let t = tracker else { stop(); return }
        // a finger on the list itself takes over
        if cv.isTracking { stop(); return }
        let n: Int = t.dayCount
        guard n > 0, cv.numberOfSections == n + 1 else { stop(); return }
        let target: Double
        if let d = drag { target = min(Double(n - 1), max(0, d.pos)) } else if let g = goal { target = g } else { stop(); return }
        let now: CFTimeInterval = l.timestamp
        let dt: Double = last == 0 ? max(0.004, l.targetTimestamp - l.timestamp) : min(1.0 / 30, max(0.001, now - last))
        last = now
        var gap: Double = target - cur
        // far off (a tap many days away): one jump to just short of it, then glide the rest
        if abs(gap) > 3 { cur = target - (gap > 0 ? 1.5 : -1.5); gap = target - cur }
        // under the finger it keeps up within a few frames; coasting and settling, it eases in (smooth-out)
        let tau: Double = finger ? 0.028 : 0.085
        cur += gap * (1 - exp(-dt / tau))
        let done: Bool = drag == nil && abs(target - cur) < 0.002
        if done { cur = target }
        if let y = offset(cv, cur, n), abs(y - cv.contentOffset.y) > 0.2 {
            cv.contentOffset = CGPoint(x: cv.contentOffset.x, y: y)
        }
        if done { stop() }
    }
}

/// finds the ledger List's scroll view from one of its rows; draws nothing, takes no touches
struct GlideHook: UIViewRepresentable {
    let glide: LedgerGlide
    func makeUIView(context: Context) -> HookView {
        let v = HookView()
        v.isUserInteractionEnabled = false
        v.glide = glide
        return v
    }
    func updateUIView(_ v: HookView, context: Context) {
        v.glide = glide
        v.find()
    }
    final class HookView: UIView {
        weak var glide: LedgerGlide?
        override func didMoveToWindow() {
            super.didMoveToWindow()
            find()
        }
        func find() {
            guard window != nil, let glide, glide.cv == nil else { return }
            var v: UIView? = superview
            while let s = v {
                if let cv = s as? UICollectionView { glide.cv = cv; return }
                v = s.superview
            }
        }
    }
}

/// (smooth-5nov-c) how smoothly a scroll really drew: while the ledger scrolls (or the lens glides it), every display
/// frame is timed; when it stops, the share of frames missed, the worst frame and how long it ran go into Perf (the
/// diagnostics), so smoothness is measured on the phone, not guessed. Costs one display-link callback a frame, only
/// while something moves.
@MainActor final class FrameMeter: NSObject {
    static let shared = FrameMeter()
    private var link: CADisplayLink? = nil
    private var name: String = ""
    private var last: CFTimeInterval = 0
    private var began: CFTimeInterval = 0
    private var frames: Int = 0
    private var lost: Int = 0
    private var worst: Double = 0

    func run(_ on: Bool, _ what: String) {
        if on {
            guard link == nil else { return }
            name = what; last = 0; frames = 0; lost = 0; worst = 0; began = CACurrentMediaTime()
            let l = CADisplayLink(target: self, selector: #selector(tick(_:)))
            l.preferredFrameRateRange = CAFrameRateRange(minimum: 80, maximum: 120, preferred: 120)
            l.add(to: .main, forMode: .common)
            link = l
        } else {
            guard link != nil, what == name else { return }
            link?.invalidate(); link = nil
            let secs: Double = CACurrentMediaTime() - began
            guard frames > 20 else { return }
            Perf.shared.record(name + " · frames missed %", ms: 100 * Double(lost) / Double(frames + lost))
            Perf.shared.record(name + " · worst frame", ms: worst)
            Perf.shared.record(name + " · seconds", ms: secs)
        }
    }

    @objc private func tick(_ l: CADisplayLink) {
        let now: CFTimeInterval = l.timestamp
        let expected: Double = max(0.004, l.targetTimestamp - l.timestamp)
        if last > 0 {
            let dt: Double = now - last
            frames += 1
            lost += max(0, Int((dt / expected).rounded()) - 1)
            worst = max(worst, dt * 1000)
        }
        last = now
    }
}
