import SwiftUI
import UIKit
import Observation

// MARK: - The store: tabs and deep links
// (split out of Store.swift, 30 Oct 2026; the stored state stays in the class there)

extension Store {
    // MARK: tabs and deep links

    /// the saved bar, or the old three-plus-two one carried over (with Chapters arriving in it once)
    static func savedTabs() -> [AppTab] {
        let saved: [String] = Saved.load("kosh.tabs", [String]())
        if !saved.isEmpty { return tidy(saved.compactMap(AppTab.init(rawValue:))) }
        var slots: [AppTab] = Saved.load("kosh.slots", [AppTab.insurance.rawValue, AppTab.property.rawValue]).compactMap(AppTab.init(rawValue:))
        if !Saved.ud.bool(forKey: "kosh.chapters.tab") {
            Saved.ud.set(true, forKey: "kosh.chapters.tab")
            if !slots.contains(.chapters) {
                if slots.count >= 2 { slots[1] = .chapters } else { slots.append(.chapters) }
            }
        }
        let out: [AppTab] = tidy([.home, .transactions, .portfolio] + slots)
        Saved.save("kosh.tabs", out.map(\.rawValue))
        return out
    }
    /// Home first, each once, no fewer than four and no more than six
    static func tidy(_ list: [AppTab]) -> [AppTab] {
        var out: [AppTab] = [.home]
        for t in list where !out.contains(t) { out.append(t) }
        for t in AppTab.pinnable where out.count < AppTab.fewest && !out.contains(t) { out.append(t) }
        return Array(out.prefix(AppTab.most))
    }
    /// kosh draws the bar itself, icons alone, at any count (5 Nov 2026: it follows a swipe between tabs and slims
    /// on scroll, which the system's bar can't do)
    var glassBar: Bool { true }
    var canAddTab: Bool { tabs.count < AppTab.most }
    var canRemoveTab: Bool { tabs.count > AppTab.fewest }

    func addTab(_ t: AppTab) {
        guard canAddTab, !tabs.contains(t) else { return }
        tabs.append(t)
    }
    func removeTab(_ t: AppTab) {
        guard canRemoveTab, t != .home, let i = tabs.firstIndex(of: t) else { return }
        tabs.remove(at: i)
        if tab == t { tab = .home }
    }
    /// Home stays first
    func moveTab(_ t: AppTab, to i: Int) {
        guard t != .home, let from = tabs.firstIndex(of: t) else { return }
        let to: Int = max(1, min(tabs.count - 1, i))
        if from == to { return }
        var s: [AppTab] = tabs
        s.remove(at: from)
        s.insert(t, at: to)
        tabs = s
    }
    func setTabs(_ list: [AppTab]) {
        tabs = Store.tidy(list)
        if !tabs.contains(tab) { tab = .home }
    }

    /// a module's own screen: its tab when it has one, otherwise opened from Home
    func land(_ t: AppTab) {
        if tabs.contains(t) {
            tab = t
            setPath(t, [])
            return
        }
        if t == .loans && tabs.contains(.portfolio) {
            tab = .portfolio
            portSub = .loans
            portPath = []
            return
        }
        tab = .home
        homeSub = .overview
        homePath = [.module(t)]
    }
    func setPath(_ t: AppTab, _ p: [Route]) {
        switch t {
        case .home: homePath = p
        case .transactions: txPath = p
        case .portfolio: portPath = p
        case .property: propPath = p
        case .committees: commPath = p
        case .people: peoplePath = p
        case .insurance: insPath = p
        case .loans: loanPath = p
        case .chapters: chapPath = p
        }
    }
    func pathCount(_ t: AppTab) -> Int {
        switch t {
        case .home: return homePath.count
        case .transactions: return txPath.count
        case .portfolio: return portPath.count
        case .property: return propPath.count
        case .committees: return commPath.count
        case .people: return peoplePath.count
        case .insurance: return insPath.count
        case .loans: return loanPath.count
        case .chapters: return chapPath.count
        }
    }
    /// a chapter's payments in Transactions
    func showInLedger(_ chapter: String) {
        ledgerChapter = chapter
        txSub = .all
        land(.transactions)
    }

    /// back one screen in the current tab
    func pop() {
        switch tab {
        case .home: _ = homePath.popLast()
        case .transactions: _ = txPath.popLast()
        case .portfolio: _ = portPath.popLast()
        case .property: _ = propPath.popLast()
        case .committees: _ = commPath.popLast()
        case .people: _ = peoplePath.popLast()
        case .insurance: _ = insPath.popLast()
        case .loans: _ = loanPath.popLast()
        case .chapters: _ = chapPath.popLast()
        }
    }

    func push(_ r: Route) {
        switch tab {
        case .home: homePath.append(r)
        case .transactions: txPath.append(r)
        case .portfolio: portPath.append(r)
        case .property: propPath.append(r)
        case .committees: commPath.append(r)
        case .people: peoplePath.append(r)
        case .insurance: insPath.append(r)
        case .loans: loanPath.append(r)
        case .chapters: chapPath.append(r)
        }
    }

    /// open a module wherever it lives: its own tab if pinned, otherwise the tab that holds it
    func open(_ module: AppTab) {
        withAnimation(Motion.open) {
            if tabs.contains(module) { tab = module; return }
            if module == .loans && tabs.contains(.portfolio) { tab = .portfolio; portSub = .loans; return }
            if module == .home { tab = .home; return }
            tab = .home
            homeSub = .overview
            homePath = [.module(module)]
        }
    }
}
