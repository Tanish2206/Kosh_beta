import Foundation
import Observation
import UIKit
import Network

// MARK: - LiveSession: statements and papers: finding, unlocking and reading the PDFs, and applying what they say
// (split out of LiveSession.swift, 17 Oct 2026; its stored state stays in the class there)

extension LiveSession {
    // MARK: statements: open the user's own locked PDFs on the phone and read them
    //
    // Every PDF worth reading that turned up in the mail, plus any added from Files. Unlocked ones
    // (and ones whose sender's password you gave before) are read straight after each scan. For a
    // CAS only the newest from each sender and inbox matters, so older ones are never asked about.

    struct DocWant: Decodable { let kind: String; let file: String; var files: [String]? = nil }

    /// One PDF as the Portfolio and Insurance tabs list it
    struct DocItem: Identifiable, Hashable {
        let id: String           // record id, or "local:" + LocalDoc id
        let file: String
        let sender: String       // who sent it, by name where kosh knows the sender
        let domain: String       // what its saved password is keyed by
        let date: String
        let kind: String
        let state: String        // read, locked, empty, older, ""
        let note: String
        let hint: String
        let owner: String
        /// opened, but neither kosh's readers nor Claude could read it
        var unread: Bool = false
        /// what it's about, once read (invest, insurance, loan, bank, card, tax, details); "" until then
        var cat: String = ""
        /// the institution the engine named for its sender ("" when it named none): the shelf it sits on in
        /// Settings › Statements and papers (PaperShelf.home), never a name guessed from its address
        var inst: String = ""
        var local: Bool { id.hasPrefix("local:") }
    }

    func docItems(kinds: Set<String>) -> [DocItem] {
        // (asked on every redraw of the pages with a statements banner: made once for each change to the records,
        // the files added by hand, or the household)
        let key: String = kinds.sorted().joined(separator: ",") + "|" + String(recordsVersion) + "|" + String(people.count) + "|"
            + localDocs.map { $0.id + ":" + $0.state + ":" + $0.kind + ":" + $0.owner }.joined(separator: ",")
        if let known = docItemsMemo[key] { return known }
        let made: [DocItem] = makeDocItems(kinds: kinds)
        if docItemsMemo.count > 40 { docItemsMemo.removeAll() }
        docItemsMemo[key] = made
        return made
    }
    private func makeDocItems(kinds: Set<String>) -> [DocItem] {
        var out: [DocItem] = records.compactMap { r in
            guard let d = r.doc, kinds.contains(d.kind) else { return nil }
            let dom = SenderPasswords.domain(d.from)
            return DocItem(id: r.id, file: d.file, sender: (r.inst ?? "").isEmpty ? dom : r.inst!, domain: dom, date: r.sent ?? "",
                           kind: d.kind, state: d.state, note: d.note ?? "", hint: d.hint, owner: ownerOf(inbox: d.acct), unread: d.unread == true && d.state != "older", cat: d.cat ?? "", inst: r.inst ?? "")
        }
        out += localDocs.filter { kinds.contains($0.kind) || ($0.kind.isEmpty || $0.kind == "unknown") && kinds.contains("cas") }.map {
            DocItem(id: "local:" + $0.id, file: $0.file, sender: $0.kind == "epf" ? "EPFO passbook" : "Added from Files",
                    domain: Self.pwKey(forLocal: $0), date: $0.added,
                    kind: $0.kind, state: $0.state, note: $0.note ?? "", hint: "", owner: $0.owner, inst: $0.kind == "epf" ? "EPFO" : "")
        }
        return out.sorted { $0.date > $1.date }
    }

    /// What a password typed for a paper shared in from Files is remembered by. A passbook is locked with the
    /// holder's own details and every passbook the same way, so one is remembered for the EPFO and opens the next;
    /// anything else is remembered for that one file, as it always was.
    static func pwKey(forLocal doc: LocalDoc) -> String { doc.kind == "epf" ? epfDomain : "file:" + doc.id }

    /// (asked on every redraw of Home: worked out once for each change to the records)
    var lockedDocs: [Reading] {
        if let m = lockedMemo, m.version == recordsVersion { return m.docs }
        let docs: [Reading] = records.filter { $0.doc != nil && $0.doc!.state == "locked" }
        lockedMemo = (recordsVersion, docs)
        return docs
    }

    var docCount: Int { records.count(where: { $0.doc != nil && $0.doc?.kind != "order" }) + localDocs.count }

    var docsRead: Int { records.count(where: { $0.doc?.state == "read" && $0.doc?.unread != true && $0.doc?.kind != "order" }) + localDocs.filter { $0.state == "read" }.count }

    /// papers opened that neither kosh's readers nor Claude could read
    var unreadDocs: [DocItem] { docItems(kinds: ["cas", "contract", "policy", "cardstmt", "stmt", "society", "payslip", "tax", "fd", "loan", "nps"]).filter(\.unread) }

    /// those papers read again (a better reader, or Claude now set up)
    @MainActor

    func rereadUnread() async {
        for i in records.indices where records[i].doc?.unread == true { records[i].doc?.state = ""; records[i].doc?.unread = nil }
        await readDocuments()
    }

    /// the newest CAS from each sender and inbox; the rest are history kosh doesn't need
    /// the kinds of statement where only the newest counts: a CAS and a contract note say everything held,
    /// and a bank statement's closing balance is what kosh carries forward, so last month's adds nothing
    static let newestOnly: Set<String> = ["cas"]

    /// the kinds read as runs, month after month: newest of each first (balances, holdings), then the rest (history)
    static let runKinds: Set<String> = ["cas", "contract", "stmt", "cardstmt"]

    func newestCAS(_ kinds: Set<String> = LiveSession.newestOnly) -> Set<String> {
        var best: [String: (date: String, id: String)] = [:]
        for r in records {
            guard let d = r.doc, kinds.contains(d.kind), d.held != false else { continue }
            // a bank's statements for one account (its digits in the subject) are one run; another account's are another
            // a registrar's statement of one folio is a run of its own: each is opened, and sets just its folios
            let part: Bool = d.kind == "cas" && Self.casPart(r.subject ?? "", d.file)
            let stmtRun: String = d.kind == "stmt" ? ((try? Engine.shared.call("stmtKey", [r.subject ?? ""])) ?? "") : ""
            let run: String = part ? "part:" + r.id : stmtRun
            let key = d.kind + "|" + SenderPasswords.domain(d.from) + "|" + run + "|" + d.acct
            let date = r.sent ?? ""
            if best[key] == nil || date > best[key]!.date { best[key] = (date, r.id) }
        }
        return Set(best.values.map(\.id))
    }

    /// Fetch and open every statement not yet read: as is, or with the password you gave its sender.
    /// What stays locked waits on the Portfolio and Insurance tabs for its password.
    @MainActor

    func readDocuments() async {
        guard !readingDocs else { return }
        readingDocs = true
        KeepGoing.shared.begin("Opening statements and invoices")
        defer {
            readingDocs = false; KeepGoing.shared.end()
            // details learnt from what was read (a policy's date of birth, a statement's Customer ID): the locked ones get another try
            let again: Bool = harvestedNew
            harvestedNew = false
            Task { @MainActor in
                if again, !self.unlocking { _ = await self.openLockedWithProfile() }
                await self.exportStatementsOnce()
            }
        }
        if harvestFromEverything() { harvestedNew = true }
        var newest = newestCAS()
        // what will be opened, counted first so the bar knows where it ends (a run cut short counts on from where it got to)
        var kinds = Set<String>()
        var count = localDocs.filter { $0.state.isEmpty }.count
        for r in records {
            guard let d = r.doc, willOpen(d, id: r.id, newest: newest) else { continue }
            count += 1
            kinds.insert(d.kind)
        }
        if !localDocs.filter({ $0.state.isEmpty }).isEmpty { kinds.insert("stmt") }
        docLabel = kinds == ["order"] ? "Opening invoices" : kinds.contains("order") ? "Opening statements and invoices" : "Opening statements"
        note("docs: \(count) to open")
        defer { note("docs: stopped at \(docDone) of \(docTotal)") }
        let carried = plan("docs")
        docDone = carried?.done ?? 0
        docTotal = docDone + count
        if count > 0 {
            stretchSeen = true
            plans["docs"] = ReadingPlan(job: "docs", accounts: allAccounts, total: docTotal, done: docDone)
            if carried != nil { pickUp("docs") }
        } else {
            plans["docs"] = nil
        }
        // the newest of each run first (a balance, holdings, a policy), then everything older, newest first
        let heads = newestCAS(Self.runKinds)
        let order: [Int] = records.indices.sorted { a, b in
            let ha = heads.contains(records[a].id) || !Self.runKinds.contains(records[a].doc?.kind ?? ""), hb = heads.contains(records[b].id) || !Self.runKinds.contains(records[b].doc?.kind ?? "")
            if ha != hb { return ha }
            return (records[a].sent ?? "") > (records[b].sent ?? "")
        }
        // the names kosh already knows (the household) become password facts with no typing, so the auto-unlock can
        // run from a name and the one date of birth the person may still need to enter
        harvestPasswordNames()
        let anyDetails = PasswordProfile.anyUsable
        // after this version arrives: locked papers get another turn, with the rule read afresh from their mail (two
        // ways, "Customer ID, or name and date of birth") and with the family's details as well as yours
        // (3: the rules read right for a slice of the Customer ID, two ways side by side, and one sender's account and card
        // statements kept apart; and a statement that couldn't be fetched tried again by its attachment's id of today)
        // a statement's note of the password it was tried with was once a short hash of that password, kept in
        // records.json: any note not of today's shape (SenderPasswords.tag, eight hex letters) goes, and that
        // statement gets one more try with what is saved
        for j in records.indices where (records[j].doc?.tried).map({ $0.range(of: "^[0-9a-f]{8}$", options: .regularExpression) == nil }) ?? false {
            records[j].doc?.tried = nil
        }
        // (cardbill2-4nov) papers once read from a leaflet riding with the statement: pointed at the statement, read again
        await repickLeafletDocs()
        if ud.integer(forKey: "pw.guessV") < 3 {
            for j in records.indices where records[j].doc?.state == "locked" { records[j].doc?.auto = nil; records[j].doc?.hinted = 1 }
            ud.set(3, forKey: "pw.guessV")
        }
        for i in order {
            guard i < records.count, var d = records[i].doc, d.state.isEmpty || d.state == "locked" || d.state == "older" else { continue }
            if halted { cutShort("docs"); return }
            if !Net.shared.online {
                guard await Net.shared.waitOnline() else { cutShort("docs"); return }
            }
            if Self.newestOnly.contains(d.kind) && !newest.contains(records[i].id) {
                if d.state != "older" || d.unread == true { d.state = "older"; d.unread = nil; d.note = "An older statement: the newest one counts"; records[i].doc = d }
                continue
            }
            if d.state == "locked" && (d.hinted ?? 0) < 2 {
                // the sender's own words on how the password is made, to build it from and to show beside the field
                let domain = SenderPasswords.domain(d.from)
                // (another paper of the same kind from the sender already read afresh: its words are this one's too. A bank's
                // card statements and its account statements come from one address with different rules: never shared)
                let kind: String = d.kind
                let known = records.first { $0.doc.map { $0.kind == kind && SenderPasswords.domain($0.from) == domain && !$0.hint.isEmpty && ($0.hinted ?? 0) >= 2 } ?? false }?.doc
                if let known { d.hint = known.hint }
                else if let m = try? await fetchOne(d.msg, acct: d.acct) {
                    d.hint = DocUnlock.hint(text: m.text, html: m.html)
                    // the same mail often prints a Customer ID, PAN, date of birth or PIN code: harvested with no typing
                    harvestPasswordFacts(text: m.text, html: m.html, inbox: d.acct, domain: SenderPasswords.domain(d.from))
                }
                d.hinted = 2
                if i < records.count { records[i].doc = d }
            }
            if d.state == "locked", anyDetails, d.auto != true {
                // passwords made from the details saved for you and your family (the paper's likely holder first): the
                // sender's rule, then the usual formats. Once per statement, and also when the sender's saved
                // password doesn't open this one (another card's)
                if await tryProfiles(at: i, PasswordProfile.ordered(first: likelyHolders(records[i]))) { openedOne(); continue }
                guard i < records.count else { continue }
                d = records[i].doc ?? d
            }
            if d.state == "locked" && !Self.worthTrying(d) {
                // still waiting on you
                continue
            }
            await openDoc(at: i, typed: nil)
            openedOne()
            // a "holdings statement" with nothing held in it gives way: the sender's next newest is opened in this pass
            if d.kind == "cas", i < records.count, records[i].doc?.held == false { newest = newestCAS() }
        }
        for i in localDocs.indices where localDocs[i].state.isEmpty {
            if halted { cutShort("docs"); return }
            await openLocal(at: i, typed: nil)
            openedOne()
        }
        await readPastHoldings(newest: newest)
        if halted { cutShort("docs"); return }
        plans["docs"] = nil
        save(); writePlans(); rebuildSoon()
    }

    /// whether readDocuments opens this statement now (the newest of its kind, and not waiting on a password)
    func willOpen(_ d: DocRef, id: String, newest: Set<String>) -> Bool {
        guard d.state.isEmpty || d.state == "locked" || d.state == "older" else { return false }
        if Self.newestOnly.contains(d.kind) && !newest.contains(id) { return false }
        if d.state == "locked" && !Self.worthTrying(d) { return false }
        return true
    }

    /// a locked statement still has something new to try: your saved details (once), or a saved password for its
    /// sender it hasn't been tried with. Otherwise it waits for you, and isn't downloaded again on every read.
    static func worthTrying(_ d: DocRef) -> Bool {
        if d.auto != true && PasswordProfile.anyUsable { return true }
        guard let tag = SenderPasswords.tag(d.from) else { return false }
        return d.tried != tag
    }

    /// one more statement or invoice opened: on the bar, and saved now and then
    @MainActor

    func openedOne() {
        docDone += 1
        if docTotal < docDone { docTotal = docDone }
        plans["docs"]?.done = docDone
        plans["docs"]?.total = docTotal
        stretchRead += 1
        checkpoint(1)
    }

    /// an older holdings statement from the last year not yet opened for its month's figure
    var pastHoldingsWaiting: Bool {
        let since = Self.daysAgo(400)
        let waiting = records.contains { r in
            guard let d = r.doc else { return false }
            return d.kind == "cas" && d.state == "older" && d.past != true && (r.sent ?? "") >= since
        }
        guard waiting else { return false }
        let runs = openCASRuns(newestCAS())
        return records.contains { r in
            guard let d = r.doc else { return false }
            return d.kind == "cas" && d.state == "older" && d.past != true && (r.sent ?? "") >= since && runs.contains(SenderPasswords.domain(d.from) + "|" + d.acct)
        }
    }

    /// the senders (and inboxes) whose newest holdings statement has opened
    func openCASRuns(_ newest: Set<String>) -> Set<String> {
        var runs = Set<String>()
        for r in records where newest.contains(r.id) {
            if let d = r.doc, d.kind == "cas", d.state == "read" { runs.insert(SenderPasswords.domain(d.from) + "|" + d.acct) }
        }
        return runs
    }

    /// Last year's monthly holdings statements (CAS), each opened once for what it said that month, so net
    /// worth can be drawn over the year and not just since the newest one. Only once the newest from the same
    /// sender has opened (with its password, if it had one), so none of these ever asks for a password; the
    /// holdings shown stay the newest statement's.
    @MainActor

    func readPastHoldings(newest: Set<String>) async {
        let since = Self.daysAgo(400)
        let openRuns = openCASRuns(newest)
        guard !openRuns.isEmpty else { return }
        let todo: [Int] = records.indices.filter { i in
            guard let d = records[i].doc, d.kind == "cas", d.past != true, d.state == "older" || d.state.isEmpty,
                  !newest.contains(records[i].id), (records[i].sent ?? "") >= since,
                  openRuns.contains(SenderPasswords.domain(d.from) + "|" + d.acct) else { return false }
            return true
        }
        // on the bar with the rest
        docTotal += todo.count
        plans["docs"]?.total = docTotal
        for i in todo {
            guard i < records.count, var d = records[i].doc else { continue }
            if halted { return }
            d.past = true
            records[i].doc = d
            let ok = await openDoc(at: i, typed: nil)
            openedOne()
            if !ok, var back = records[i].doc {
                back.state = "older"; back.unread = nil; back.note = "An older statement: the newest one counts"
                records[i].doc = back
            }
        }
    }

    /// a statement's sealed text is good to read again as it is: a bank or card statement kept before kosh read
    /// statements by their columns has no grid, so it's fetched and opened once more
    /// (and one kept from a turned page read sideways, before 30 Oct, is opened again: DocLayout.sideways)
    /// (glyphs-4nov) a statement's kept text came from today's way of reading a PDF's letters: else it is fetched once more
    static func keptExtractedNow(_ key: String, file: String, kind: String) -> Bool {
        guard kind == "stmt" || kind == "cardstmt" || kind == "cas", file.lowercased().hasSuffix(".pdf") else { return true }
        return MailVault.getText(key + "|x") == DocText.extractor
    }

    static func keptReads(_ kept: String, kind: String) -> Bool {
        ((kind != "stmt" && kind != "cardstmt") || kept.contains(DocText.gridSep)) && !DocLayout.sideways(DocText.split(kept).grid)
    }

    /// When the way statements are read changes (15 Oct: by their columns, a year's statement past page 60; 17 Oct:
    /// a bank statement's opening balance and its holders' names), every bank and card statement already opened is
    /// opened again, once (3, 30 Oct: a turned page is read the way it is shown; a statement kept sideways is fetched again,
    /// the rest read again from what was kept)
    /// (4, 3 Nov: a statement's dates checked against the month its file is for, and a bank statement with no closing
    /// balance no longer counted as read)
    static let statementReader = 15   // 15 (4 Nov, cardbill3-4nov): a card statement's total due proven by its own lines (HDFC Tata Neu read as its previous dues).
    // 14 (4 Nov, cardbill2-4nov): card bills off PDFKit's text when the rebuilt rows are jumbled, labels in sentences passed over, card digits from the masked number.
    // 13 (4 Nov, drift-4nov, statements chat): letters re-read where a PDF counts its letter boxes without line breaks (HDFC savings).
    // 12 12 (4 Nov, smart-4nov, statements chat): headers like "Transaction"/"Date and Time", figures under their labels, "null" words, a second account's table, the lines' reading when the columns' contradicts itself; partial readings go to the next reader.
    // 11 11 (4 Nov, ppf-owner-4nov): a PPF on a statement carries the holders it names and its closed line, so it counts for its holder, not whose inbox it came to.
    // 10 (4 Nov, cardbill-4nov): a card statement's own bill (total due, minimum, due day) and its card from the masked number it prints.
    // 9 (4 Nov, gridopen-4nov/custid-4nov): by its columns with the opening balance its label prints (HDFC), a Customer ID never an account number.
    // 8 8 (4 Nov, gone-4nov/hsbc-4nov): a statement as on its "Statement Date" (HSBC composite), any spaces before an opening/closing figure.
    // 7 7 (4 Nov, cardlines-4nov): card lines printed under their words, rates no amounts, GST under a line, EMI/discount tables skipped, HSBC summary row, period at the head; policy numbers, gains computations.
    // 6 6 (4 Nov, papers-4nov): holding statements whose Total line prints units and value reconcile, contract notes one row per ISIN, broker ledgers and meeting notices told apart; also re-reads holdings papers and contract notes.
    // 5 (4 Nov, statements chat): Axis 0.00 columns, PPF/FD types, closed status, "As on", HSBC composite, card summaries

    @MainActor

    func reopenStatementsIfReaderChanged() {
        guard ud.integer(forKey: "beta.stmtReader") < Self.statementReader else { return }
        for i in records.indices {
            guard var d = records[i].doc, d.kind == "stmt" || d.kind == "cardstmt" || (Self.statementReader >= 6 && (d.kind == "cas" || d.kind == "contract")), d.state == "read" || d.state == "older" else { continue }
            d.state = ""
            records[i].doc = d
        }
        ud.set(Self.statementReader, forKey: "beta.stmtReader")
        save()
    }

    /// what kosh may be missing: months a card was used with no statement in the mail, quiet months on a busy
    /// account, and senders whose money mail kosh can't read yet (engine.js gaps)
    struct Gaps: Decodable {
        struct Gap: Decodable, Hashable { let name: String; let instr: String; let last4: String; let months: [String]; let what: String }
        struct Unread: Decodable, Hashable { let name: String; let domain: String; let n: Int }
        let gaps: [Gap]; let unread: [Unread]
    }

    @MainActor

    func gaps() -> Gaps? {
        struct Light: Encodable { let id: String; let kind: String; let sent: String?; let from: String?; let inst: String?; let instKind: String?; let instr: String?; let last4: String?; let date: String?; let dir: String? }
        let light = records.map { Light(id: $0.id, kind: $0.kind, sent: $0.sent, from: $0.from, inst: $0.inst, instKind: $0.instKind, instr: $0.instr, last4: $0.last4, date: $0.date, dir: $0.dir) }
        guard let out = try? Engine.shared.call("gapsJSON", [JSONText.encode(light), JSONText.encode(statements), Self.today]) else { return nil }
        return try? JSONText.decode(Gaps.self, out)
    }

    /// where a paper's text is kept on this phone once opened: its mail and its file's name (never the attachment's id,
    /// which Gmail changes every time the mail is fetched). A zip's is kept under its own key since every statement in
    /// it is read (27 Oct): a zip kept as only its first statement is opened once more
    /// (cardbill2-4nov, stmtpick) A mail with several PDFs: kosh once took the first, and HSBC sends its "Most Important
    /// Terms & Conditions.pdf" ahead of the card statement (and "Important_Notes.pdf" ahead of the savings statement), so
    /// every HSBC statement was read from the leaflet. The engine now passes leaflets over (docLeaflet); each paper read
    /// from one is pointed at the statement its mail carries and read again, once. A mail that can't be fetched now is
    /// tried on the next pass.
    @MainActor
    func repickLeafletDocs() async {
        guard ud.integer(forKey: "beta.stmtPick") < 1 else { return }
        var done = true
        for i in records.indices {
            guard i < records.count, let d = records[i].doc, d.file != "(mail)",
                  (try? Engine.shared.call("docLeafletJSON", [d.file])) == "true" else { continue }
            if halted { done = false; break }
            guard let m = try? await fetchOne(d.msg, acct: d.acct) else { done = false; continue }
            guard i < records.count, records[i].doc?.msg == d.msg,
                  let out = try? Readers.engine(for: m.from).call("docWantedJSON", [JSONText.encode(m)]),
                  let want = try? JSONText.decode(DocWant.self, out), !want.kind.isEmpty, want.file != d.file,
                  let att = m.attachments.first(where: { $0.filename == want.file }) else { continue }
            var nd: DocRef = d
            nd.att = att.id; nd.file = att.filename; nd.kind = want.kind
            nd.state = ""; nd.note = nil; nd.unread = nil; nd.tried = nil; nd.auto = nil
            records[i].doc = nd
            // what the leaflet was read as goes with it (its "lines" were the terms' worked examples)
            statements.removeAll { $0.src == "doc:" + d.msg || $0.src.hasPrefix("doc:" + d.msg + "#") }
        }
        if done { ud.set(1, forKey: "beta.stmtPick") }
        save()
    }

    static func docTextKey(_ d: DocRef) -> String { d.msg + "|f:" + d.file.lowercased() + (DocLocked.isZip(d.file) ? "|all" : "") }

    /// try one statement: returns true if it opened
    @MainActor

    @discardableResult

    func openDoc(at i: Int, typed: String?, opened: String? = nil) async -> Bool {
        guard i < records.count, var d = records[i].doc else { return false }
        if d.kind == "order" { return await openOrder(at: i) }
        // the reading goes on while this one is opened: find the record again by its id when it's done
        let rid = records[i].id, sent = records[i].sent ?? ""
        do {
            // opened once before: its text is sealed on this phone, read again without downloading or unlocking it.
            // Kept by the mail and the file's name: Gmail gives an attachment a new id each time the mail is fetched,
            // so a text kept by the id was never found again (those older ones are still looked for)
            let textKey = Self.docTextKey(d)
            let oldKey = d.msg + "|" + d.att
            // (glyphs-4nov) a statement kept from before letters without a box were placed: fetched again, once; when it
            // can't be fetched, what was kept is read as it was
            let keptNow: String? = typed == nil && opened == nil ? (MailVault.getText(textKey) ?? MailVault.getText(oldKey)) : nil
            var useKept: Bool = keptNow.map { Self.keptReads($0, kind: d.kind) } ?? false
            var prefetched: Data? = nil
            if useKept && d.att != "body" && !Self.keptExtractedNow(textKey, file: d.file, kind: d.kind) {
                if let got = try? await docBytes(&d) { prefetched = got; useKept = false }
            }
            let result: DocUnlock.Result
            if let opened {
                // just opened by the caller (a password put together from your details): not downloaded again
                result = .opened(opened)
                MailVault.putText(opened, key: textKey)
                MailVault.putText(DocText.extractor, key: textKey + "|x")
            } else if useKept, let kept = keptNow {
                result = .opened(kept)
            } else if d.att == "body" {
                // a statement printed in the mail itself: its table, from the sealed copy of the mail
                if let m = MailVault.get(rid), let doc = DocTable.fromMail(m.html) { result = .opened(doc); MailVault.putText(doc, key: textKey) }
                else { result = .unreadable }
            } else if DocLocked.isZip(d.file) {
                // a zip (a consolidated statement or contract notes bundled, often locked): opened by unlock.js with the
                // password you typed or the sender's saved ones, then the statement inside read as itself
                let bytes = try await docBytes(&d)
                result = await DocLocked.openZip(bytes, file: d.file, sender: d.from, typed: typed)
                if case .opened(let text) = result { MailVault.putText(text, key: textKey) }
            } else if DocRef.isSheet(d.file) {
                let bytes = try await docBytes(&d)
                result = await DocTable.openGuarded(bytes, file: d.file, key: textKey, sender: d.from, typed: typed)
                if case .opened(let text) = result { MailVault.putText(text, key: textKey) }
            } else {
                let bytes: Data
                if let got = prefetched { bytes = got } else { bytes = try await docBytes(&d) }
                let from = d.from
                let fresh = await Task.detached(priority: .utility) { await DocUnlock.open(bytes, sender: from, typed: typed) }.value
                // a statement kept from before kosh read columns, and now locked with no saved password: the old reading
                let refetchedBad: Bool = { if prefetched == nil { return false }; if case .unreadable = fresh { return true }; return false }()
                if case .locked = fresh, typed == nil, let kept = MailVault.getText(textKey) ?? MailVault.getText(oldKey) { result = .opened(kept) } else if refetchedBad, let kept = keptNow { result = .opened(kept) } else { result = fresh }
                if case .opened(let text) = fresh { MailVault.putText(text, key: textKey); MailVault.putText(DocText.extractor, key: textKey + "|x") }
            }
            switch result {
            case .opened(let text):
                if harvestPasswordFacts(text: String(DocText.split(text).body.prefix(20000)), html: "", inbox: d.acct, domain: SenderPasswords.domain(d.from)) { harvestedNew = true }
                let part: Bool = d.kind == "cas" && Self.casPart(records.first { $0.id == rid }?.subject ?? "", d.file)
                d.note = await applyDoc(kind: d.kind, text: text, from: d.from, title: d.file, source: "doc:" + d.msg, sent: sent, owner: ownerOf(inbox: d.acct), key: SenderPasswords.domain(d.from) + "|" + d.acct, part: part)
                // nothing held in it: not a holdings statement, so the sender's next newest is the one that counts
                if d.kind == "cas" { d.held = lastDocHeld ? nil : false }
                // what it's about, so every paper is filed (investments, insurance, a loan, your details)
                d.cat = lastDocCat.isEmpty ? nil : lastDocCat
                d.state = "read"
                // opened, but neither kosh nor Claude could read it: listed under Couldn't read, opened again when either reads better
                d.unread = (docUnderstood.removeValue(forKey: "doc:" + d.msg) ?? true) ? nil : true
            case .locked:
                d.state = "locked"
                // the sender's saved password doesn't open this one (another card's, say): not fetched again for it
                if typed == nil, let tag = SenderPasswords.tag(d.from) { d.tried = tag }
            case .unreadable:
                d.state = "empty"
                d.note = DocLocked.isZip(d.file) ? "No statement kosh can read inside the zip" : DocRef.isSheet(d.file) ? "Not a spreadsheet kosh can read" : "Not a readable PDF"
            }
        } catch LiveError.busy {
            d.note = "The inbox was busy; kosh tries again after the next scan"
        } catch LiveError.signIn {
            // (Gmail's sign-in has lapsed: nothing can be fetched until it's reconnected, and that's what to say)
            d.note = "Waiting for Gmail to be reconnected"
            note("doc fetch: Gmail needs reconnecting")
        } catch {
            // (why, in a word, for the statements list and the diagnostics: the mail gone, refused, or no connection)
            let why: String = Self.gone(error) ? " (the email is no longer there)" : { if case LiveError.http(let c, _)? = error as? LiveError, c > 0 { return " (the inbox said \(c))" }; return (error as? URLError) != nil ? " (no connection)" : "" }()
            d.note = "Couldn’t fetch it from the inbox" + why + "; kosh tries again after the next scan"
            // (the error itself, its kind and code only, for the trace)
            let ns = error as NSError
            note("doc fetch failed: " + String(describing: type(of: error)) + " " + ns.domain + " " + String(ns.code) + why)
        }
        guard let j = records.firstIndex(where: { $0.id == rid }) else { return false }
        records[j].doc = d
        return d.state == "read"
    }

    /// A shop's order mail whose amount is only in its invoices (Blinkit, Zepto, BigBasket): every invoice is
    /// fetched and read on this phone, and the order becomes what a receipt mail would have made it, a wallet
    /// payment or a receipt that waits for the bank's alert. Nothing is kept but the reading.
    @MainActor

    func openOrder(at i: Int) async -> Bool {
        guard i < records.count, var d = records[i].doc else { return false }
        var texts: [String] = []
        do {
            for att in [d.att] + (d.more ?? []) {
                let bytes = try await attachmentBytes(acct: d.acct, msg: d.msg, att: att)
                let from = d.from
                let result = await Task.detached(priority: .utility) { await DocUnlock.open(bytes, sender: from, typed: nil) }.value
                if case .opened(let text) = result { texts.append(text) }
            }
        } catch {
            d.note = "Couldn’t fetch the invoice from the inbox; kosh tries again after the next scan"
            records[i].doc = d
            return false
        }
        let r = records[i]
        // (every paper's file name, in the order the papers were opened: the engine ties a fee's paper to its booking by them)
        let names: [String] = r.files ?? [d.file]
        guard !texts.isEmpty,
              let out = try? Engine.shared.call("orderDocJSON", [texts.joined(separator: "\n\u{1D}\n"), r.from ?? d.from, r.subject ?? "", r.sent ?? "", r.id, names.joined(separator: "\n")]),
              var read = Reading.fromEngine(out) else {
            d.state = "empty"; d.note = "Couldn’t read the invoice"
            records[i].doc = d
            return false
        }
        d.state = "read"
        d.note = read.kind == "noise" ? "No total in the invoice" : "Read the invoice: " + Fmt.rupees(read.amt ?? 0)
        do {   // (diag: how many invoices named their items, and one that didn't, to teach the reader)
            let ud = UserDefaults.standard, has: Bool = (read.evs ?? "").contains("\"lines\":[{")
            ud.set(ud.integer(forKey: has ? "orderdoc.lines" : "orderdoc.none") + 1, forKey: has ? "orderdoc.lines" : "orderdoc.none")
            if !has { var smp = ud.stringArray(forKey: "orderdoc.samples2") ?? []; let plain: String = texts.map { t in let v = t.components(separatedBy: "\u{1E}"); return (v.count > 1 ? v[1] : v[0]).components(separatedBy: "\u{1F}")[0] }.joined(separator: "\n"); if smp.count < 8 && !smp.contains(where: { $0.hasPrefix(r.from ?? "") }) { smp.append((r.from ?? "") + " | " + (r.subject ?? "") + " || " + String(plain.prefix(3000))); ud.set(smp, forKey: "orderdoc.samples2") } }
        }
        read.id = r.id; read.acct = r.acct; read.doc = d; read.rp = r.rp
        if read.files == nil { read.files = r.files }
        records[i] = read
        return read.kind != "noise"
    }

    /// A password for one sender: kosh tries it on every statement from that sender still locked,
    /// keeps it (for that sender only) if one opens, and reads them all.
    @MainActor

    func unlockSender(_ domain: String, password: String) async -> Int {
        if domain.hasPrefix("file:") {
            let id = String(domain.dropFirst(5))
            guard let i = localDocs.firstIndex(where: { $0.id == id }) else { return 0 }
            let ok = await openLocal(at: i, typed: password)
            save(); rebuild()
            return ok ? 1 : 0
        }
        var opened = 0
        // papers shared in from Files that are kept by a sender rather than by the one file (a passbook: the EPFO's
        // own rule, so one password opens every passbook shared in, this one and the next)
        for i in localDocs.indices where localDocs[i].state == "locked" && Self.pwKey(forLocal: localDocs[i]) == domain {
            if await openLocal(at: i, typed: password) { opened += 1 }
        }
        let newest = newestCAS()
        for i in records.indices {
            guard let d = records[i].doc, d.state == "locked", SenderPasswords.domain(d.from) == domain else { continue }
            if Self.newestOnly.contains(d.kind) && !newest.contains(records[i].id) { continue }
            if await openDoc(at: i, typed: password) { opened += 1 }
        }
        save(); rebuild()
        return opened
    }

    /// A PDF from Files: copied into kosh's folder, then read like any statement
    @MainActor

    func addLocalDocument(_ url: URL) async -> LocalDoc? {
        let scoped = url.startAccessingSecurityScopedResource()
        defer { if scoped { url.stopAccessingSecurityScopedResource() } }
        guard let data = try? Data(contentsOf: url) else { return nil }
        let dir = Self.folder.appendingPathComponent("docs", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        var doc = LocalDoc(file: url.lastPathComponent, added: Self.today)
        // a spreadsheet keeps its kind of file, and is read as a bank statement
        let sheet = DocRef.isSheet(doc.file) || DocLocked.isZip(doc.file)
        doc.path = doc.id + (sheet ? "." + (url.pathExtension.lowercased()) : ".pdf")
        do { try data.write(to: dir.appendingPathComponent(doc.path), options: [.atomic, Self.protection]) } catch { return nil }
        if let out = try? Engine.shared.call("docWantedJSON", [JSONText.encode(["filename": doc.file, "subject": doc.file, "from": ""])]),
           let want = try? JSONText.decode(DocWant.self, out) { doc.kind = want.kind }
        if sheet && doc.kind.isEmpty { doc.kind = "stmt" }
        localDocs.append(doc)
        await openLocal(at: localDocs.count - 1, typed: nil)
        save(); rebuild()
        return localDocs.last
    }

    func removeLocalDocument(_ id: String) {
        guard let i = localDocs.firstIndex(where: { $0.id == id }) else { return }
        let src = "file:" + id
        try? FileManager.default.removeItem(at: Self.folder.appendingPathComponent("docs").appendingPathComponent(localDocs[i].path))
        docHoldings.removeAll { $0.source.hasPrefix("cas|" + src) || $0.source == src }
        forgetEPFBook(source: src)
        fundSegs.removeAll { $0.src == src }
        userPolicies.removeAll { $0.source == src }
        localDocs.remove(at: i)
        save(); rebuild()
    }

    @MainActor

    @discardableResult

    func openLocal(at i: Int, typed: String?) async -> Bool {
        guard i < localDocs.count else { return false }
        var doc = localDocs[i]
        let url = Self.folder.appendingPathComponent("docs").appendingPathComponent(doc.path)
        guard let data = try? Data(contentsOf: url) else {
            // there but locked away (the phone hasn't been unlocked since it started): tried again later
            if !FileManager.default.fileExists(atPath: url.path) { doc.state = "empty"; localDocs[i] = doc }
            return false
        }
        let key = "file:" + doc.id
        /* A password typed for a paper shared in from Files was kept under that one file, so the next one from the
           same place asked all over again. An EPFO passbook is locked with the holder's own details and every
           passbook is locked the same way, so one typed for a passbook is remembered for the EPFO (as a sender's is
           for the sender) and opens the next. A paper whose kind isn't settled yet is offered the EPFO's too: that
           is only ever a password the person already typed for a passbook of their own. */
        let pwKey: String = Self.pwKey(forLocal: doc)
        var result: DocUnlock.Result
        if DocLocked.isZip(doc.file) {
            result = await DocLocked.openZip(data, file: doc.file, sender: pwKey, typed: typed)
        } else if DocRef.isSheet(doc.file) {
            result = await DocTable.openGuarded(data, file: doc.file, key: key, sender: pwKey, typed: typed)
        } else {
            result = await Task.detached(priority: .utility) { await DocUnlock.open(data, sender: pwKey, typed: typed) }.value
            if case .locked = result, pwKey != Self.epfDomain, !SenderPasswords.every(Self.epfDomain).isEmpty {
                let epfKey = Self.epfDomain
                result = await Task.detached(priority: .utility) { await DocUnlock.open(data, sender: epfKey, typed: nil) }.value
            }
        }
        switch result {
        case .opened(let text):
            let kind = doc.kind.isEmpty ? "unknown" : doc.kind
            doc.note = await applyDoc(kind: kind, text: text, from: "", title: doc.file, source: key, sent: doc.added, owner: doc.owner, key: key)
            if doc.kind.isEmpty || doc.kind == "unknown" { doc.kind = lastDocKind }
            doc.state = "read"
            // it turned out to be a passbook: the password that opened it is the EPFO's rule, not this one file's,
            // so it moves over and the next passbook shared in opens by itself
            if doc.kind == "epf", pwKey != Self.epfDomain, let pw = SenderPasswords.get(key) { SenderPasswords.set(Self.epfDomain, pw) }
        case .locked: doc.state = "locked"
        case .unreadable: doc.state = "empty"; doc.note = DocLocked.isZip(doc.file) ? "No statement kosh can read inside the zip" : DocRef.isSheet(doc.file) ? "Not a spreadsheet kosh can read (an old .xls)" : "Not a readable PDF"
        }
        localDocs[i] = doc
        return doc.state == "read"
    }

    /// What one opened PDF says, folded into Portfolio and Insurance. Returns a line for the list.
    /// The rules read it first; a policy document they find nothing in goes to kosh-reader.
    @MainActor

    func applyDoc(kind: String, text: String, from: String, title: String, source: String, sent: String, owner: String, key: String, part: Bool = false) async -> String {
        docUnderstood[source] = false
        lastDocHeld = false
        lastDocCat = ""
        lastDocFacts = []
        func score(_ d: DocParsed) -> Double {
            let sum = d.holdings.reduce(0) { $0 + $1.amt }
            let t = d.total
            let checked: Double = d.check?.ok == true ? 1e14 : 0
            let reconciled: Double = t?.reconciled == true ? 1e13 : 0
            let trusted: Double = t?.trusted == true ? 1e12 : 0
            let parts: Int = (d.facts ?? []).count + (d.loans ?? []).count + (d.trades ?? []).count
            // a statement's lines: when the reading adds up, each counts; when it doesn't, the lines whose balance follows
            // from the line before count, and a line nothing explains counts a little against it, so the reading with
            // more phantom lines (a summary row read as a purchase) never wins on their number
            let rows: [DocParsed.L] = d.rows ?? []
            let sure: Int = rows.filter { $0.chk == true }.count
            let loose: Int = rows.count - sure
            let lineScore: Double = rows.isEmpty ? 0 : (checked > 0 ? Double(rows.count) * 1e9 : 1e10 + Double(sure) * 1e9 - Double(loose) * 1e7)
            let found: Double = Double(d.policies.count) * 1e11 + Double(parts) * 1e9 + lineScore
            return checked + reconciled + trusted + found + sum
        }
        // a zip's several statements (DocLocked.openZip joins them with DocLocked.fileSep) are each read as themselves
        let files: [String] = text.components(separatedBy: DocLocked.fileSep)
        var bests: [String] = []
        var firstText: String = ""
        // (templates-5nov) each sender's statement layouts as kosh last read them whole: tried first, kept only if they add up
        let isStmt: Bool = kind == "stmt" || kind == "cardstmt"
        let tpls: String = isStmt ? StmtTemplates.json : ""
        for file in files {
            // both readings of the pages; keep the one that adds up (or reads the most). The grid (every word with where it
            // sits) goes beside each, so a statement is read by its columns
            let (body, grid) = DocText.split(file)
            let variants: [String] = body.components(separatedBy: DocUnlock.alt)
            if firstText.isEmpty { firstText = variants.first ?? body }
            // read off the main thread, on the engine the builds use: a year's statement takes seconds on the phone, and the
            // screens stay smooth meanwhile
            // (with the day its mail came: a date the pages can't mean, a year cut at a column's edge, is put right by it)
            // (each reading beside the text it was read from: the one that wins teaches its sender's template)
            let outs: [(String, String)] = await Task.detached(priority: .utility) { () -> [(String, String)] in
                variants.compactMap { v -> (String, String)? in
                    guard let o = try? Engine.builder.call("parseDocJSON", [v, kind, from, title, grid, sent, tpls]) else { return nil }
                    return (v, o)
                }
            }.value
            var best: String? = nil
            var bestText: String = ""
            var bestScore: Double = -1
            for (v, out) in outs {
                guard let p = try? JSONText.decode(DocParsed.self, out) else { continue }
                let sc: Double = score(p)
                if best == nil || sc > bestScore { best = out; bestText = v; bestScore = sc }
            }
            // (cardbill2-4nov) a card statement's bill as any reading of these pages printed it, when the reading that won
            // printed none (the phone's rebuilt rows can come out jumbled where PDFKit's text reads the box whole): one
            // backed by the statement's own equation first
            // (and its card's digits, when every other reading that names them names the same ones)
            if kind == "cardstmt", let b0 = best, let d0 = b0.data(using: .utf8),
               var o0 = (try? JSONSerialization.jsonObject(with: d0)) as? [String: Any],
               o0["bill"] == nil || ((o0["last4"] as? String) ?? "").isEmpty {
                let all: [[String: Any]] = outs.compactMap { pair -> [String: Any]? in
                    guard let dd = pair.1.data(using: .utf8) else { return nil }
                    return (try? JSONSerialization.jsonObject(with: dd)) as? [String: Any]
                }
                var changed = false
                let bills: [[String: Any]] = all.compactMap { $0["bill"] as? [String: Any] }
                if o0["bill"] == nil, let pick = bills.first(where: { ($0["eq"] as? Bool) == true }) ?? bills.first { o0["bill"] = pick; changed = true }
                let l4s: Set<String> = Set(all.compactMap { $0["last4"] as? String }.filter { !$0.isEmpty })
                if ((o0["last4"] as? String) ?? "").isEmpty, l4s.count == 1, let l4 = l4s.first { o0["last4"] = l4; changed = true }
                if changed, let nd = try? JSONSerialization.data(withJSONObject: o0), let ns = String(data: nd, encoding: .utf8) { best = ns }
            }
            if let best {
                bests.append(best)
                // (templates-5nov) a reading that adds up teaches its sender's layout; a template tried that didn't add up counts
                // a failure (engine.js › docTemplatesUpdateJSON). Off the main thread, on the engine that read it
                if isStmt {
                    let read: String = best, page: String = bestText
                    await Task.detached(priority: .utility) {
                        StmtTemplates.update(had: tpls, parsed: read, text: page, kind: kind, from: from, title: title, grid: grid, sent: sent)
                    }.value
                }
            }
        }
        // ...and then as one: every holding, line, trade and policy once, a statement in the zip twice once (docread.js)
        var oneJSON: String? = bests.first
        if bests.count > 1 {
            let list: [String] = bests
            oneJSON = await Task.detached(priority: .utility) { () -> String? in try? Engine.builder.call("mergeDocsJSON", [JSONText.encode(list), kind]) }.value
        }
        guard let readJSON = oneJSON, var parsed = try? JSONText.decode(DocParsed.self, readJSON) else { return "Opened, but kosh couldn’t read it" }
        // a paper added from Files whose name said nothing is what its own pages say: a bank or card statement's lines are
        // kept as a statement's (PaperKind)
        let kind: String = PaperKind.readAs(asked: kind, found: parsed.docKind)
        // a document too long to read whole says how far kosh got
        let cut: String? = text.range(of: #"\[kosh read the first \d+ of \d+ pages\]"#, options: .regularExpression).map { String(text[$0]).trimmingCharacters(in: CharacterSet(charactersIn: "[]")) }
        let text = firstText
        var byReader = false
        if parsed.holdings.isEmpty, parsed.policies.isEmpty, kind == "policy" || kind == "unknown",
           let read = await readPagesWithModel(text: text, from: from, title: title),
           let p = try? JSONText.decode(DocParsed.self, read), !p.policies.isEmpty {
            parsed = p; byReader = true
        }
        // kosh's own readers couldn't make sense of it (nothing found, or its own figures say a line was misread):
        // Claude reads the pages, and its reading counts only when it checks out against them (engine.js › "Claude
        // reads a paper"). Payslips, tax forms, deposits, loans and contract notes stay with docread.js
        var byClaude = false
        if !Self.paperKinds.contains(parsed.kind ?? kind), !Self.understood(parsed, kind: kind),
           let out = await ClaudeReads.readDoc(text: text, kind: kind, from: from, title: title, names: claudeNames, key: source + "|" + kind),
           let c = try? JSONText.decode(DocParsed.self, out), Self.understood(c, kind: c.kind ?? kind) {
            parsed = c; byClaude = true
        }
        docUnderstood[source] = Self.paperKinds.contains(parsed.kind ?? kind) || Self.understood(parsed, kind: kind)
        // what the paper is about, and the details it prints about its holder (a Customer ID, folio, PRAN, policy
        // number…): kept on this phone for Your details, and for opening the sender's next statements
        lastDocCat = parsed.cat ?? Details.catOf(kind: parsed.kind ?? kind)
        if let ids = parsed.ids, !ids.isEmpty {
            lastDocFacts = ids
            let domain: String = SenderPasswords.domain(from)
            DetailsStore.saveDoc(DocDetails(source: source, who: owner, inst: Details.instOf(domain), domain: domain, date: String(sent.prefix(10)),
                                            cat: lastDocCat, items: ids))
        }
        // pages that turn out to be another paper (a contract note mailed as a statement) are read as that paper
        let paper: String = Self.paperKinds.contains(parsed.kind ?? "") ? (parsed.kind ?? kind) : kind
        // (an EPFO passbook stays an EPF paper, holdings and all: that is how its password is remembered for the EPFO
        // and how the Retirement screen lists it)
        // (accttype-4nov: a bank statement that also lists a PPF or a deposit is still a bank statement)
        lastDocKind = paper == "epf" ? "epf" : (paper == "stmt" ? "stmt" : (parsed.holdings.isEmpty ? (parsed.policies.isEmpty ? paper : "policy") : "cas"))
        lastDocHeld = !parsed.holdings.isEmpty
        // a paper read again says it afresh: the policies it made last time give way to today's reading
        userPolicies.removeAll { $0.source == source }
        // the papers beyond statements (docread.js): counted only when their own figures add up
        if Self.paperKinds.contains(paper) { return applyPaper(kind: paper, parsed: parsed, from: from, source: source, sent: sent, owner: owner, key: key) }
        var lines: [String] = []
        if !parsed.holdings.isEmpty, let t = parsed.total, t.trusted == false {
            lastDocKind = "cas"
            let what = t.stated > 0 ? "Read \(Fmt.words(t.read)) of the \(Fmt.words(t.stated)) it shows" : "Its rows came to only \(Fmt.words(t.read))"
            return what + ": a layout kosh can’t read yet, so it isn’t counted. Shake the phone to send it in."
        }
        if !parsed.holdings.isEmpty {
            // the newest statement from this sender and inbox replaces what an older one said
            let tag = "cas|" + key + "|"
            // every statement, older ones too, is a dated reading for net worth over time
            var byCls: [String: Double] = [:]
            for h in parsed.holdings { byCls[h.cls, default: 0] += h.amt }
            // (one folio's statement isn't all that sender holds for you: no reading of its own)
            if !part { noteReading(src: tag, date: (parsed.asOf ?? "").count >= 10 ? (parsed.asOf ?? "") : sent, owner: owner, values: byCls) }
            // and each fund's purchases, SIPs and redemptions in it, for yearly returns
            noteFundRows(parsed, source: source, owner: owner)
            let day: String = Self.isDay(parsed.asOf ?? "") ? String((parsed.asOf ?? "").prefix(10)) : String(sent.prefix(10))
            if part {
                // one folio's (or one transaction's) statement: those folios are set to its day, the rest stay as the
                // consolidated statement said
                lines.append(mergePart(parsed.holdings, day: day, tag: tag + "part|" + sent, owner: owner))
            } else {
                let older = docHoldings.filter { $0.source.hasPrefix(tag) && !$0.source.contains("|part|") }
                // (a row's own day may have been moved on by a one-folio statement since: the statements are compared by
                // when they were sent)
                // (an older statement left aside on purpose is understood, never "couldn't read")
                if let prevSent = older.first?.source.split(separator: "|").last.map(String.init), prevSent > sent { docUnderstood[source] = true; save(); return "An older statement: the newest one counts" }
                // its own earlier rows give way; one-folio statements' rows are settled below (settleParts)
                docHoldings.removeAll { $0.source.hasPrefix(tag) && !$0.source.contains("|part|") }
                var added: [Int] = []
                for h in parsed.holdings {
                    var uh = UserHolding(bank: h.bank, type: h.type, cls: h.cls, amt: h.amt, rate: h.rate ?? 0, rem: h.rem ?? "", owner: owner,
                                         source: tag + sent, units: h.units, isin: h.isin, asOf: parsed.asOf)
                    if let c = h.cost, c > 0 { uh.cost = c }
                    if let f = h.folio, !f.isEmpty { uh.folio = f }
                    // (ppf-owner-4nov) a PPF (or NPS, Sukanya) is its holder's, not whose inbox the statement came to:
                    // the names the statement prints go with it, and the engine says whose (ppfSettle)
                    if h.cls == "ret" {
                        let nm: [String] = parsed.named ?? parsed.namedF ?? []
                        if !nm.isEmpty { uh.named = Array(nm.prefix(4)) }
                        if h.closed == true { uh.closed = true }
                    }
                    docHoldings.append(uh)
                    added.append(docHoldings.count - 1)
                }
                settleParts(owner: owner, day: day, added: added, tag: tag)
                let sum = parsed.holdings.reduce(0) { $0 + $1.amt }
                var line = "\(parsed.holdings.count) holding\(parsed.holdings.count == 1 ? "" : "s"), \(Fmt.words(sum))"
                if let t = parsed.total {
                    if t.reconciled { line += ", matches the statement’s total" }
                    else if t.stated > 0 { line += ", statement says \(Fmt.words(t.stated)): some rows weren’t read" }
                }
                lines.append(line)
            }
        }
        // (a number with nothing beside it, no cover, premium, dates or plan, only fills in a policy kosh has by that number)
        for p in parsed.policies where (p.cover ?? 0) > 0 || (p.premium ?? 0) > 0
            || (!(p.policyNo ?? "").isEmpty && (!(p.nextDue ?? "").isEmpty || !(p.start ?? "").isEmpty || !(p.end ?? "").isEmpty || !(p.plan ?? "").isEmpty
                || userPolicies.contains { !$0.policyNo.isEmpty && $0.policyNo == p.policyNo })) {
            // a policy is known by its number; a paper without one may only fill in the one policy
            // kosh already has from that insurer
            let no = (p.policyNo ?? "").filter { $0.isLetter || $0.isNumber }.uppercased()
            let sameInsurer = userPolicies.filter { !(p.insurer ?? "").isEmpty && $0.insurer == p.insurer }
            if no.isEmpty && sameInsurer.count != 1 { continue }
            var pol = userPolicies.first { !no.isEmpty && $0.policyNo.filter { $0.isLetter || $0.isNumber }.uppercased() == no }
                ?? (no.isEmpty ? sameInsurer.first : nil) ?? UserPolicy()
            let isNew = !userPolicies.contains { $0.id == pol.id }
            func fill(_ cur: inout String, _ v: String?) { if let v, !v.isEmpty { cur = v } }
            func fillOpt(_ cur: inout String?, _ v: String?) { if let v, !v.isEmpty { cur = v } }
            fill(&pol.insurer, p.insurer); fill(&pol.type, p.type); fill(&pol.policyNo, p.policyNo); fill(&pol.nextDue, p.nextDue)
            if let c = p.cover, c > 0 { pol.cover = c }
            if let pr = p.premium, pr > 0 { pol.premium = pr }
            fillOpt(&pol.plan, p.plan); fillOpt(&pol.holder, p.holder); fillOpt(&pol.insured, p.insured); fillOpt(&pol.nominee, p.nominee)
            fillOpt(&pol.frequency, p.frequency); fillOpt(&pol.start, p.start); fillOpt(&pol.end, p.end); fillOpt(&pol.hint, p.hint)
            fillOpt(&pol.vehicle, p.vehicle); fillOpt(&pol.addOns, p.addOns)
            if let t = p.term, t > 0 { pol.term = t }
            if let t = p.ppt, t > 0 { pol.ppt = t }
            if let v = p.maturity, v > 0 { pol.maturity = v }
            // a newer unit statement's fund value replaces an older one's
            if let v = p.fundValue, v > 0, (p.fundAsOf ?? "") >= (pol.fundAsOf ?? "") { pol.fundValue = v; pol.fundAsOf = p.fundAsOf ?? sent }
            if isNew { pol.owner = owner; pol.source = source }
            if let i = userPolicies.firstIndex(where: { $0.id == pol.id }) { userPolicies[i] = pol } else { userPolicies.append(pol) }
            lines.append([p.insurer ?? "", p.type ?? "", (p.cover ?? 0) > 0 ? "cover " + Fmt.words(p.cover!) : ""].filter { !$0.isEmpty }.joined(separator: " · "))
        }
        // a card or bank statement: every line, kept so the engine can square it with the alerts
        if kind == "cardstmt" || kind == "stmt" {
            // a combined statement is read one account at a time; otherwise the whole is one account
            let parts: [DocParsed.Part] = (parsed.parts ?? []).isEmpty
                ? [DocParsed.Part(rows: parsed.rows ?? [], last4: parsed.last4, from: parsed.from, to: parsed.to, close: parsed.close, closeDate: parsed.closeDate, check: parsed.check, opening: parsed.opening)]
                : (parsed.parts ?? [])
            statements.removeAll { $0.src == source || $0.src.hasPrefix(source + "#") }
            var total = 0, ins = 0, closes: [String] = [], held: [String] = [], sure = 0
            for (n, part) in parts.enumerated() where !part.rows.isEmpty || part.close != nil {
                let doc = StmtDoc(src: parts.count > 1 ? source + "#" + String(n) : source, from: from,
                                  instr: parsed.instr ?? (kind == "cardstmt" ? "card" : "account"), last4: part.last4 ?? "",
                                  rows: part.rows.map { StmtDoc.Row(date: $0.date, desc: $0.desc, amt: $0.amt, dir: $0.dir, chk: $0.chk) },
                                  sent: sent, owner: owner, periodFrom: part.from ?? "", periodTo: part.to ?? "",
                                  close: kind == "stmt" ? part.close : nil, closeDate: kind == "stmt" ? part.closeDate : nil,
                                  ok: part.check?.ok, note: part.check?.note,
                                  open: kind == "stmt" ? part.opening : nil, named: parsed.named, namedF: parsed.namedF,
                                  credit: kind == "cardstmt" && parts.count == 1 ? parsed.credit : nil,
                                  limit: kind == "cardstmt" && parts.count == 1 ? parsed.limit : nil,
                                  avail: kind == "cardstmt" && parts.count == 1 ? parsed.avail : nil,
                                  status: parts.count == 1 ? parsed.status : nil)
                var docB: StmtDoc = doc
                // cardbill-4nov: the card's bill as its statement prints it (a combined statement's parts have none)
                if kind == "cardstmt", parts.count == 1, let b = parsed.bill, b.due.count == 10 {
                    docB.billAmt = b.amt; docB.billMin = b.min; docB.billDue = b.due; docB.billOn = b.on
                }
                // every month's statement is kept: its lines are the year's history where alerts are missing, and the
                // engine takes the latest closing balance for today's
                statements.append(docB)
                if part.check?.ok == false {
                    held.append(((part.last4 ?? "").isEmpty ? "" : "••" + (part.last4 ?? "") + ": ") + (part.check?.note ?? ""))
                    sure += part.rows.filter { $0.chk == true }.count
                }
                total += part.rows.count
                ins += part.rows.filter { $0.dir == "in" }.count
                if let c = part.close {
                    let which: String = (part.last4 ?? "").isEmpty ? "" : "••" + (part.last4 ?? "") + " "
                    closes.append(which + "closed on " + Fmt.rupees(c))
                }
            }
            if total > 0 {
                let read: String = total == 1 ? "1 line read" : String(total) + " lines read"
                let came: String = ins > 0 ? " (" + String(ins) + " in)" : ""
                lines.append(read + came + ", squared with your alerts")
            }
            lines += closes
            // its own figures say a line was missed or misread: its lines only fill in names, none is added
            if !held.isEmpty { lines.append("Doesn’t add up (" + held.joined(separator: "; ") + ")" + (sure > 0 ? "" : ", so no line is added from it")) }
            if parsed.byColumns == true { lines.append("Read by its columns") }
        }
        if let cut { lines.append(cut.prefix(1).uppercased() + cut.dropFirst()) }
        // (a zip of several statements says so: they were read together, each counted once)
        if bests.count > 1 && !lines.isEmpty { lines.append(String(bests.count) + " statements in the zip, each counted once") }
        if lines.isEmpty { return "Opened, but nothing kosh tracks was in it" }
        return lines.joined(separator: "; ") + (byClaude ? " (read by kosh’s smart reading, checked against the pages)" : byReader ? " (read by \(aiName))" : "")
    }

    /// what a paper's reading found is something kosh can count: a statement's lines (not contradicted by its own
    /// figures), a holdings statement's holdings that come to its total, a policy
    static func understood(_ d: DocParsed, kind: String) -> Bool {
        // (cover-4nov) a statement read only in part (a fraction of its dated lines) that its own figures don't confirm
        // isn't read, whatever balance it found: the next reader gets it
        if (d.kind ?? kind) == "stmt" || (d.kind ?? kind) == "cardstmt", d.check?.ok != true, let c = d.cover, c.dated >= 5, Double(c.read) < Double(c.dated) * 0.6 { return false }
        switch d.kind ?? kind {
        case "stmt":
            // a bank account's statement is read when its closing balance is: that is the account's balance on its day,
            // and what kosh carries forward. Lines without it (a layout read only in part) aren't "read": the statement goes
            // to the next reader and waits under Couldn't read, and the account says its balance is behind (engine.js)
            if let parts = d.parts, !parts.isEmpty { return parts.contains { $0.close != nil } && parts.allSatisfy { $0.check?.ok != false } }
            if d.dormant == true { return true }
            return d.close != nil && d.check?.ok != false
        case "cardstmt":
            if let parts = d.parts, !parts.isEmpty { return parts.contains { !$0.rows.isEmpty || $0.close != nil } && parts.allSatisfy { $0.check?.ok != false } }
            // a quiet month: no lines, but the statement itself was read (its closing balance, or Claude found it empty)
            if (d.rows ?? []).isEmpty { return d.close != nil || d.dormant == true }
            return d.check?.ok != false
        case "cas": return !d.holdings.isEmpty && d.total?.trusted != false
        case "policy": return !d.policies.isEmpty
        default: return !d.holdings.isEmpty || !d.policies.isEmpty || !(d.rows ?? []).isEmpty
        }
    }

    struct DocChunk: Decodable { let prompt: String; let text: String }

    /// kosh-reader on a page the rules found nothing in, a few pieces at a time on this phone. Each
    /// piece's answer is checked against that piece (every amount and ID it names must be printed);
    /// what survives is merged into one reading, in the shape the rules give. Nil if the reader
    /// isn't in use or found nothing.
    @MainActor

    func readPagesWithModel(text: String, from: String, title: String, pieces: Int = 6) async -> String? {
        let apple = aiMode == "apple" && AppleBrain.available
        guard apple || (aiMode == "reader" && KoshReader.available) else { return nil }
        let meta = JSONText.encode(["from": from, "title": title])
        guard let cj = try? Engine.shared.call("docChunksJSON", [meta, text, "1800", String(pieces)]),
              let chunks = try? JSONText.decode([DocChunk].self, cj), !chunks.isEmpty else { return nil }
        // kosh-reader v4 was trained on mail and SMS only, never a document's page: known from its file, so the model
        // isn't loaded just to find that out
        if !apple && KoshReader.installedSpeaksEvents { return nil }
        // the model is held while these pieces are read, and let go after (unless another pass still reads with it)
        if !apple { KoshReader.shared.hold() }
        defer { if !apple { KoshReader.shared.letGo() } }
        if !apple {
            do { try await Task.detached { try KoshReader.shared.load() }.value } catch { return nil }
            // kosh-reader v4 was trained on mail and SMS only, never a document's page: reading up to six pieces of every
            // statement with it was slow and found nothing, so a page goes straight on to the next reader
            if KoshReader.shared.speaksEvents { return nil }
            readerName = KoshReader.shared.modelName
        }
        var answers: [String] = []
        for c in chunks {
            let prompt = c.prompt
            let raw: String
            if !Self.coolEnough() { break }
            do {
                if apple { raw = try await AppleBrain.readPage(prompt) }
                else { raw = try await Task.detached(priority: .utility) { try KoshReader.shared.read(prompt) }.value }
            }
            catch KoshReader.Failure.tooLong { continue }
            catch { if apple { continue } else { break } }
            if let one = try? Engine.shared.call("readerDocJSON", [prompt, raw, c.text]) { answers.append(one) }
        }
        guard !answers.isEmpty, let merged = try? Engine.shared.call("mergeReaderDocsJSON", ["[" + answers.joined(separator: ",") + "]"]) else { return nil }
        return merged
    }

    struct DocParsed: Decodable {
        struct H: Decodable {
            // (rem optional: a paper that says nothing more of a holding, an NPS statement, is still read; it was lost whole)
            let bank: String; let type: String; let cls: String; let amt: Double; let rate: Double?; let rem: String?; let units: Double?; let isin: String?; let cost: Double?
            /// (ppf-owner-4nov) the statement's line says this account is closed
            var closed: Bool? = nil
            /// a deposit advice's maturity, what it pays then, when it started, its number's last digits
            var mat: String? = nil; var matAmt: Double? = nil; var start: String? = nil; var depNo: String? = nil; var asOf: String? = nil
            /// a CAS fund's folio (last digits), the units it opened the period on, and its rows when they add up
            var folio: String? = nil; var open: Double? = nil; var flows: [CashFlow]? = nil
        }
        /// what the pages turned out to be (a contract note mailed as a statement says "contract")
        var kind: String? = nil
        /// what the paper's own words say it is (engine/09b docClass), when nobody said: a card statement added from Files
        var docKind: String? = nil
        /// what it's about (invest, insurance, loan, bank, card, tax, details), and the details it prints about its holder
        var cat: String? = nil
        var ids: [ReadingFact]? = nil
        /// whether the paper's own figures added up (docread.js, and a statement's lines against its balances)
        struct C: Decodable { let ok: Bool?; let read: Double?; let stated: Double?; let note: String? }
        var check: C? = nil
        /// (cover-4nov) printed lines that look like a statement's lines, and how many of them were read
        struct Cv: Decodable { let dated: Int; let read: Int }
        var cover: Cv? = nil
        /// a payslip's or tax form's figures
        var facts: [DocFact]? = nil
        struct LoanRead: Decodable { let bank: String?; let name: String?; let last4: String?; let outstanding: Double?; let emi: Double?; let rate: Double?; let tenureLeft: Double?; let nextDue: String?; let asOf: String? }
        var loans: [LoanRead]? = nil
        /// a contract note's trades
        var trades: [Trade]? = nil
        struct P: Decodable {
            let insurer: String?; let type: String?; let cover: Double?; let premium: Double?; let policyNo: String?
            let plan: String?; let holder: String?; let insured: String?; let nominee: String?; let frequency: String?
            let start: String?; let end: String?; let nextDue: String?; let term: Int?; let ppt: Int?
            let hint: String?
            var maturity: Double? = nil; var fundValue: Double? = nil; var fundAsOf: String? = nil
            /// a motor schedule's registration, and its cover type and add-ons as words
            var vehicle: String? = nil; var addOns: String? = nil
        }
        struct T: Decodable { let read: Double; let stated: Double; let reconciled: Bool; let trusted: Bool? }
        struct L: Decodable { let date: String; let desc: String; let amt: Double; let dir: String; var chk: Bool? = nil }
        let holdings: [H]; let policies: [P]; let asOf: String?; let total: T?
        /// a card or bank statement's lines, and whose they are
        var rows: [L]? = nil; var instr: String? = nil; var last4: String? = nil; var from: String? = nil; var to: String? = nil
        /// the balance a bank statement closed on, and the day; each account in a combined statement
        var close: Double? = nil; var closeDate: String? = nil
        /// its opening balance, and the holders it names
        var opening: Double? = nil; var named: [String]? = nil
        /// the names only a holder field printed (no greeting): never enough alone to give a stranger the account
        var namedF: [String]? = nil
        /// a card statement that leaves the card in credit ("Total Amount Due 1,250.00 Cr"): what the card owes you
        var credit: Double? = nil
        /// a card statement's credit limit, and its available credit limit on the statement's day
        var limit: Double? = nil; var avail: Double? = nil
        /// (cardbill-4nov) the bill it prints for itself: total amount due, minimum, due day, the statement's day
        struct Bill: Decodable { let amt: Double; let min: Double?; let due: String; let on: String? }
        var bill: Bill? = nil
        struct Part: Decodable { var rows: [L]; var last4: String?; var from: String?; var to: String?; var close: Double?; var closeDate: String?; var check: C? = nil; var opening: Double? = nil }
        var parts: [Part]? = nil
        /// (accttype-4nov) the statement says the account is "closed" or "dormant"
        var status: String? = nil
        /// read by its columns (the grid), not line by line
        var byColumns: Bool? = nil
        /// a statement with no lines in its period, read as such (Claude found the period and its balances, no lines)
        var dormant: Bool? = nil
        /// An EPFO passbook's whole history (docread.js READERS.epf): every member ID under the UAN — one per job —
        /// with its opening balance, a row for each month of wages, the interest credited each financial year, and the
        /// closing balance it prints. `ok` is per member: its columns came to the closing balance printed on it.
        struct EPFBook: Decodable {
            struct Sh: Decodable { let ee: Double; let er: Double; let pen: Double }
            /// one month of wages: the month it is for, the day it was credited, the three shares, and what kind of
            /// row it is (cont: the month's contribution, trf: a previous job's balance moved in, out: money taken out)
            struct Mo: Decodable { let m: String; let d: String; let ee: Double; let er: Double; let pen: Double; let k: String }
            /// one financial year: what the three shares moved, how much of that was a previous job's balance
            /// arriving (trf: not a year's saving), the interest credited at its end, and how many months of wages
            struct Yr: Decodable { let fy: String; let ee: Double; let er: Double; let pen: Double; let trf: Double; let interest: Double; let months: Int }
            struct Mem: Decodable {
                let memberId: String; let establishment: String; let uan: String
                let joined: String; let left: String; let asOf: String
                let open: Sh; let close: Sh?; let months: [Mo]; let years: [Yr]
                let rows: Int; let trfIn: Double; let ok: Bool
            }
            let uan: String; let members: [Mem]
        }
        var epf: EPFBook? = nil
    }
}

/// Each sender's statement layout as kosh last read it whole (engine.js › "statement layout templates"): where each
/// column sits on the page, the header's words, how its days are written, how money in is told from money out, and the
/// labels of its opening and closing balances. Learnt on this phone from a statement whose own figures added up, and
/// tried first on that sender's next statement (kept only if it adds up too), so a layout read once is read again with
/// no model. Nothing of a statement's lines is in it, and an account's digits only as a hash. Kept like the learned
/// rules (LearnedRules): in the phone's defaults under a "beta." key, so Erase takes it (KoshDefaults).
enum StmtTemplates {
    static let key = "beta.stmtTemplates"
    private static let lock = NSLock()

    /// every template, by sender key, as the engine takes them ("{}" when there are none)
    static var json: String {
        lock.lock(); defer { lock.unlock() }
        return UserDefaults.standard.string(forKey: key) ?? "{}"
    }

    /// what one statement's reading changed, from the engine, kept: {key: template} replaces, {key: null} forgets
    static func update(had: String, parsed: String, text: String, kind: String, from: String, title: String, grid: String, sent: String) {
        guard let ch = try? Engine.builder.call("docTemplatesUpdateJSON", [had, parsed, text, kind, from, title, grid, sent]) else { return }
        merge(ch)
    }

    /// (read, changed and written under the lock: two statements read at once each keep what they taught)
    static func merge(_ changes: String) {
        guard let cd = changes.data(using: .utf8),
              let ch = (try? JSONSerialization.jsonObject(with: cd)) as? [String: Any], !ch.isEmpty else { return }
        lock.lock(); defer { lock.unlock() }
        var all: [String: Any] = [:]
        if let s = UserDefaults.standard.string(forKey: key), let d = s.data(using: .utf8),
           let o = (try? JSONSerialization.jsonObject(with: d)) as? [String: Any] { all = o }
        for (k, v) in ch {
            if v is NSNull { all.removeValue(forKey: k) } else { all[k] = v }
        }
        guard let d = try? JSONSerialization.data(withJSONObject: all), let s = String(data: d, encoding: .utf8) else { return }
        UserDefaults.standard.set(s, forKey: key)
    }
}
