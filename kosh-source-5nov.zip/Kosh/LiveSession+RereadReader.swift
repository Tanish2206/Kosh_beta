import Foundation

extension LiveSession {
    /// Every mail an on-phone reader (kosh-reader or Apple Intelligence) read before, read again by the reader on
    /// the phone now: after a new kosh-reader model, its older readings shouldn't linger. Each mail's text comes back
    /// from its sealed copy (MailVault) or the inbox; its old reading is cleared, and the reader pass reads it again.
    /// Readings Claude made, and mail the rules read on their own, are left as they are.
    @MainActor
    func rereadWithCurrentReader() async {
        guard !running || phase == .done || phase == .failed || phase == .idle else { return }
        // (a record's own reading slot is only ever filled by an on-phone reader: applyAI; Claude's go elsewhere)
        let ids = records.filter { $0.claude != nil }.map(\.id)
        if ids.isEmpty {
            message = "Nothing to read again: no email has been read by \(aiName) on this phone yet. Tap “Run \(aiName) now”."
            return
        }
        message = "Getting \(ids.count) emails ready to read again…"
        var ready = 0
        for id in ids {
            guard let i = records.firstIndex(where: { $0.id == id }) else { continue }
            let r = records[i]
            // the mail's text, if kosh no longer holds it
            var text = r.text, html = r.html
            if text == nil && html == nil {
                guard let m = await claudeMail(r) else { continue }
                text = m.text; html = m.html
            }
            guard let j = records.firstIndex(where: { $0.id == id }) else { continue }
            records[j].text = text
            records[j].html = html
            records[j].claude = nil
            if records[j].use == "claude" { records[j].use = nil }
            // what the rules couldn't read goes back to the reader; what they read is double-checked again
            records[j].check = records[j].kind == "unknown" ? nil : Check(status: "pending", fields: [])
            ready += 1
        }
        save()
        rebuildSoon()
        if ready == 0 {
            message = "Couldn’t get those \(ids.count) emails back (the inbox didn’t answer). Try again online."
            return
        }
        message = "Reading \(ready) emails again with \(aiName)…"
        await aiPass()
        // (the pass leaves its own word if it stopped: too warm, off screen, an error)
        if message == nil { message = "Read \(ready) emails again with \(aiName)." }
    }
}
