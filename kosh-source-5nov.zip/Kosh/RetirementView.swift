import SwiftUI

// MARK: - Retirement: EPF, PPF and NPS, held together
//
// EPF comes first because it is usually the largest of the three and always the stalest: a passbook changes only
// when somebody opens it, and the EPFO adds a year's interest once, after the year has ended. So every figure here
// says which day it is for and how long ago that was — and where that is months, the clock comes with the sentence
// that says why months old is the newest there is, so an old figure never reads as kosh having failed.
//
// Nothing on this screen is a figure kosh made up. The one sum kosh makes itself — the interest that has accrued
// since the EPFO last credited any — is labelled as kosh's own, is never added to what you own, and says so in
// words on its own row. The pension (EPS) share sits beside the money, never inside it: it buys a pension, it isn't
// a balance to draw. Gratuity has no row at all, because no paper a household keeps states a gratuity balance.
//
// The build does the reckoning once (engine/21l-build-retirement.js › snap.retirement); this file only says it.

extension Store {
    /// the UAN kosh has already read from the mail or a paper, so it is never asked for (Your details › snap.facts)
    var rememberedUAN: String {
        let digits: [String] = (snap.facts ?? []).flatMap { (g: FactGroup) -> [String] in
            g.items.filter { $0.k == "uan" && $0.masked != true }.map { $0.v.filter(\.isNumber) }
        }
        return digits.first { $0.count == 12 } ?? ""
    }
    /// the date of birth kosh has (it opens locked papers; the EPFO asks for it too), as "14 Mar 1989" or ""
    var rememberedDOB: String {
        let saved: PasswordProfile? = PasswordProfile.load(for: "me")
        let found: PasswordProfile? = PasswordProfile.harvested()["me"]
        let raw: String = [saved?.dob ?? "", found?.dob ?? ""].first { !$0.isEmpty } ?? ""
        return raw.count >= 10 ? Day.fmt(String(raw.prefix(10)), "d MMM yyyy") : raw
    }
}

/// The Retirement sections, inside the "ret" instrument page's list. EPF, then PPF, then NPS; then the passbook
/// itself and what kosh remembers of you, so nothing is ever asked for twice.
struct RetirementSections: View {
    @Environment(Store.self) private var store
    let person: Person

    var body: some View {
        // (the jobs under a UAN, the payslips and the ledger are read for whoever's inbox kosh reads, so this is
        //  shown for the household and for you; another person's EPF shows as their holdings alone, with no reckoning)
        let mine: Bool = person == .family || person == .me
        if mine, let r = store.snap.retirement {
            if let e = r.epf { EPFSections(epf: e) }
            if let p = r.ppf { PPFSection(ppf: p, person: person) }
            if let n = r.nps { NPSSection(nps: n) }
            if let o = r.other {
                Section("Other retirement savings") {
                    RetRow(title: o.n == 1 ? "One more account" : "\(o.n) more accounts", detail: "Not EPF, PPF or NPS", amt: o.total)
                }
            }
        }
        if mine { RetirementPapers() }
    }
}

// MARK: - one row of money, with a line under it

/// a figure with what it is and where it came from, in the Portfolio's own shape
struct RetRow: View {
    let title: String
    let detail: String
    let amt: Double
    var fade: Bool = false
    var body: some View {
        HStack(alignment: .firstTextBaseline, spacing: 10) {
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(.subheadline.weight(.medium)).lineLimit(2)
                if !detail.isEmpty { Text(detail).font(.caption).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true) }
            }
            Spacer(minLength: 8)
            Text(amt > 0 ? Fmt.rupees(amt) : "—")
                .font(.subheadline.weight(.semibold)).monospacedDigit().privacySensitive()
                .foregroundStyle(fade ? Color.secondary : Color.primary)
        }
        .padding(.vertical, 2)
    }
}

/// one dated figure's own line: what it was read from and when, orange once it's old — and, for EPF, the reason in
/// words right beside it, because a passbook months old is normal
struct RetAsOf: View {
    let asOf: String?
    let days: Int?
    let old: Bool
    let what: String
    var why: String = ""
    var body: some View {
        if let asOf, asOf.count >= 10 {
            VStack(alignment: .leading, spacing: 2) {
                HStack(spacing: 4) {
                    Image(systemName: old ? "clock" : "checkmark.circle")
                        .font(.caption2.weight(.semibold))
                    Text(RetWords.asOf(what: what, day: asOf, days: days ?? 0, old: old))
                        .font(.caption2)
                }
                .foregroundStyle(old ? Color.orange : Color.secondary)
                if old && !why.isEmpty {
                    Text(why).font(.caption2).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                }
            }
            .accessibilityElement(children: .combine)
        }
    }
}

enum RetWords {
    /// "EPFO passbook, as of 31 Mar 2026, 7 months ago"
    static func asOf(what: String, day: String, days: Int, old: Bool) -> String {
        var s: String = what + ", as of " + Day.fmt(day, "d MMM yyyy")
        if old { s += ", " + FreshWords.ago(days) }
        return s
    }
    /// "Apr 2026", from a "2026-04"
    static func month(_ m: String) -> String { Day.fmt(m + "-01", "MMM yyyy") }
    /// "FY 2025-26"
    static func fy(_ s: String) -> String { "FY " + s }
    static func count(_ n: Int, _ one: String, _ many: String) -> String { Words.number(n) + " " + (n == 1 ? one : many) }
}

// MARK: - EPF

struct EPFSections: View {
    let epf: RetirementBook.EPF
    @State private var showYears = false

    var body: some View {
        // the figure, its day, and what has happened since
        Section {
            VStack(alignment: .leading, spacing: 8) {
                HStack(alignment: .firstTextBaseline) {
                    Label("EPF", systemImage: "briefcase.fill").font(.subheadline.weight(.semibold))
                    Spacer()
                    Text(Fmt.rupees(epf.total)).font(.title3.weight(.bold)).monospacedDigit().privacySensitive()
                }
                RetAsOf(asOf: epf.asOf, days: epf.days, old: epf.old == true, what: "EPFO passbook", why: epf.why)
                if let p = epf.partial {
                    Text(Self.partLine(p)).font(.caption).foregroundStyle(Color.orange).fixedSize(horizontal: false, vertical: true)
                }
                if epf.pension > 0 {
                    Text("A pension (EPS) share of " + Fmt.rupees(epf.pension) + " sits beside this. It buys a pension; it isn't a balance to draw, so it isn't in the figure.")
                        .font(.caption).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                }
            }
            .padding(.vertical, 4)
            if let s = epf.since {
                RetRow(title: "Gone in since, from your payslips",
                       detail: RetWords.count(s.months, "month", "months") + " of PF from your pay, "
                             + RetWords.month(s.from) + (s.from == s.to ? "" : " to " + RetWords.month(s.to))
                             + ". Your own share — a payslip states no one else's.",
                       amt: s.employee)
            }
            // kosh's own sum, said as such and in no total
            if let a = epf.accrued {
                VStack(alignment: .leading, spacing: 4) {
                    HStack(alignment: .firstTextBaseline, spacing: 10) {
                        VStack(alignment: .leading, spacing: 2) {
                            Label("Interest since, as kosh reckons it", systemImage: "function")
                                .font(.subheadline.weight(.medium))
                            Text("kosh's own sum, not the EPFO's. Not counted in what you own.")
                                .font(.caption.weight(.medium)).foregroundStyle(Color.orange)
                        }
                        Spacer(minLength: 8)
                        Text("~" + Fmt.rupees(a.amt)).font(.subheadline.weight(.semibold)).monospacedDigit()
                            .foregroundStyle(.secondary).privacySensitive()
                    }
                    Text(a.note).font(.caption).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                }
                .padding(.vertical, 2)
            }
        } header: {
            Text("EPF")
        } footer: {
            if epf.accrued != nil {
                Text("The EPFO declares one rate a year and credits it after the year has ended, so interest kosh has worked out itself enters no total until the EPFO credits it.")
            }
        }

        // the jobs under the UAN
        if !epf.jobs.isEmpty {
            Section {
                ForEach(epf.jobs) { j in EPFJobRow(job: j, epf: epf) }
            } header: {
                Text(epf.jobs.count == 1 ? "1 job under your UAN" : "\(epf.jobs.count) jobs under your UAN")
            } footer: {
                if !epf.left.isEmpty { Text(Self.leftLine(epf)) }
                else if epf.jobs.contains(where: { $0.movedTo != nil }) {
                    Text("A job whose balance has moved into a newer account keeps its row and counts nothing: it is the same money.")
                }
            }
        }

        // a payslip says PF left your pay with no row for it in the passbook
        if let missing = epf.missing, !missing.isEmpty {
            Section {
                ForEach(missing, id: \.month) { m in
                    RetRow(title: RetWords.month(m.month) + ": PF left your pay, no passbook row",
                           detail: m.employer.isEmpty ? "Your payslip shows it taken out; the passbook that covers that month doesn't show it arriving."
                                                      : "Your " + m.employer + " payslip shows it taken out; the passbook that covers that month doesn't show it arriving.",
                           amt: m.employee, fade: true)
                }
            } header: {
                Text(missing.count == 1 ? "A month to look at" : "Months to look at")
            } footer: {
                Text("Nothing has been changed or added for these. Open your passbook again first — a credit can land late. If it still isn't there, raise it with your employer.")
            }
        }

        // growth per year, folded away
        if let years = epf.years, !years.isEmpty {
            Section {
                Button { withAnimation(Fold.motion(opening: !showYears)) { showYears.toggle() } } label: {
                    HStack {
                        Label("Year by year", systemImage: "chart.bar.fill").font(.subheadline.weight(.medium))
                        Spacer()
                        Image(systemName: "chevron.right").font(.footnote.weight(.semibold)).foregroundStyle(.tertiary)
                            .foldTurn(showYears, degrees: 90)
                    }
                    .contentShape(Rectangle())
                }
                .buttonStyle(.press)
                Unfold(open: showYears) {
                    VStack(alignment: .leading, spacing: 8) {
                        ForEach(years.reversed()) { y in
                            HStack(alignment: .firstTextBaseline) {
                                VStack(alignment: .leading, spacing: 1) {
                                    Text(RetWords.fy(y.fy)).font(.subheadline.weight(.medium))
                                    Text(Self.yearLine(y)).font(.caption).foregroundStyle(.secondary)
                                }
                                Spacer(minLength: 8)
                                Text(Fmt.rupees(y.saved + y.interest)).font(.subheadline).monospacedDigit().privacySensitive()
                            }
                        }
                    }
                    .padding(.top, 2)
                }
            } footer: {
                Text("What went in that year and what the EPFO credited at its end, off the passbook. A balance arriving from an older job isn't counted as that year's saving.")
            }
        }
    }

    static func yearLine(_ y: RetirementBook.EPF.Year) -> String {
        var bits: [String] = []
        if y.saved > 0 { bits.append(Fmt.rupees(y.saved) + " in" + (y.months > 0 ? " over " + RetWords.count(y.months, "month", "months") : "")) }
        bits.append(y.interest > 0 ? Fmt.rupees(y.interest) + " interest" : "no interest credited yet")
        return bits.joined(separator: " · ")
    }

    /// "One job you've left still holds ₹2,40,000." — money sitting where nobody is adding to it
    /// a figure for some jobs only is said as part of the money, with what would make it whole
    static func partLine(_ p: RetirementBook.EPF.Partial) -> String {
        "Part of your EPF: " + String(p.read) + " of " + String(p.of) + " jobs read. The EPFO didn't show the "
            + (p.of - p.read == 1 ? "other one" : "other " + String(p.of - p.read)) + " — open the passbook and pick each member ID to make this whole."
    }

    static func leftLine(_ epf: RetirementBook.EPF) -> String {
        let rows: [RetirementBook.EPF.Job] = epf.jobs.filter { epf.left.contains($0.id) }
        let sum: Double = rows.reduce(0) { $0 + $1.amt }
        let which: String = rows.count == 1 ? (rows.first?.name.isEmpty == false ? rows[0].name + " still holds " : "A job you've left still holds ")
                                            : String(rows.count) + " jobs you've left still hold "
        return which + Fmt.rupees(sum) + ". It earns the EPFO's rate where it is, but nothing is going in. "
            + "The EPFO moves it into your current account only when you ask it to (a transfer request on the member portal)."
    }
}

/// one job under the UAN: its employer, the years it ran, and what its account holds
struct EPFJobRow: View {
    let job: RetirementBook.EPF.Job
    let epf: RetirementBook.EPF
    var body: some View {
        let moved: Bool = job.movedTo != nil
        let left: Bool = epf.left.contains(job.id)
        HStack(alignment: .firstTextBaseline, spacing: 10) {
            VStack(alignment: .leading, spacing: 2) {
                Text(job.name.isEmpty ? "Member ID ••" + String(job.id.suffix(5)) : job.name)
                    .font(.subheadline.weight(.medium)).lineLimit(2)
                Text(Self.under(job: job, moved: moved, left: left))
                    .font(.caption).foregroundStyle(moved ? Color.secondary : (left ? Color.orange : Color.secondary))
                    .fixedSize(horizontal: false, vertical: true)
            }
            Spacer(minLength: 8)
            Text(job.unread == true ? "not read yet" : (job.amt > 0 ? Fmt.rupees(job.amt) : "₹0"))
                .font(.subheadline.weight(moved ? .regular : .semibold)).monospacedDigit().privacySensitive()
                .foregroundStyle(moved || job.unread == true ? Color.secondary : Color.primary)
        }
        .padding(.vertical, 2)
    }

    /// "Apr 2022 – Jun 2026 · 51 months in the passbook", "Moved into your current account"
    static func under(job: RetirementBook.EPF.Job, moved: Bool, left: Bool) -> String {
        if moved { return "Moved into your newer account — the same money, counted once there" }
        var bits: [String] = []
        let span: String = Self.span(job)
        if !span.isEmpty { bits.append(span) }
        if job.months > 0 { bits.append(RetWords.count(job.months, "month", "months") + " in the passbook") }
        if left { bits.append("you've left: nothing going in") }
        if job.pension > 0 { bits.append("pension (EPS) " + Fmt.rupees(job.pension) + " on top") }
        return bits.joined(separator: " · ")
    }
    static func span(_ job: RetirementBook.EPF.Job) -> String {
        let from: String = job.joined.map { Day.fmt($0, "MMM yyyy") } ?? job.firstMonth.map { RetWords.month($0) } ?? ""
        let to: String = job.left.map { Day.fmt($0, "MMM yyyy") } ?? ""
        if from.isEmpty { return to.isEmpty ? "" : "to " + to }
        return to.isEmpty ? "since " + from : from + " – " + to
    }
}

// MARK: - PPF

struct PPFSection: View {
    @Environment(Store.self) private var store
    let ppf: RetirementBook.PPF
    var person: Person = .family
    var body: some View {
        // (ppf-owner-4nov) the person in view's accounts, each one opening; the household's, each named
        if let rows = ppf.rows {
            let mine: [RetirementBook.PPF.Row] = rows.filter { person.owns($0.owner) }
            let shut: [RetirementBook.PPF.Shut] = (ppf.closed ?? []).filter { person.owns($0.owner) }
            if !mine.isEmpty || !shut.isEmpty {
                Section {
                    ForEach(mine) { (r: RetirementBook.PPF.Row) in
                        Button { store.push(.ppf(r.id)) } label: {
                            RetRow(title: PPFWords.title(r.bank), detail: PPFWords.rowLine(r, store), amt: r.amt)
                        }
                        .buttonStyle(.plain)
                    }
                    ForEach(shut) { (s: RetirementBook.PPF.Shut) in
                        Button { store.push(.ppf(s.id)) } label: {
                            LabeledContent(PPFWords.title(s.bank), value: "Closed")
                        }
                        .buttonStyle(.plain)
                    }
                } header: {
                    Text(mine.count > 1 ? "\(mine.count) PPF accounts" : "PPF")
                } footer: {
                    Text("A PPF is one person’s, never joint. Each counts for whoever its statement names; tap one to see it, or to say whose it is, that it’s closed, or that it isn’t a PPF.")
                }
            }
            PPFLeftOut()
        } else {
            legacy
        }
    }
    @ViewBuilder var legacy: some View {
        Section {
            VStack(alignment: .leading, spacing: 8) {
                HStack(alignment: .firstTextBaseline) {
                    Label(ppf.accounts > 1 ? "\(ppf.accounts) PPF accounts" : "PPF", systemImage: "lock.shield.fill")
                        .font(.subheadline.weight(.semibold))
                    Spacer()
                    Text(Fmt.rupees(ppf.total)).font(.title3.weight(.bold)).monospacedDigit().privacySensitive()
                }
                RetAsOf(asOf: ppf.asOf, days: ppf.days, old: ppf.old == true, what: "Its annual statement",
                        why: "A PPF statement comes once a year, after the year's interest is credited.")
            }
            .padding(.vertical, 4)
            VStack(alignment: .leading, spacing: 6) {
                HStack(alignment: .firstTextBaseline) {
                    Text(RetWords.fy(ppf.year.fy) + ", so far").font(.subheadline.weight(.medium))
                    Spacer()
                    Text(Fmt.rupees(ppf.year.paid) + " of " + Fmt.rupees(ppf.year.cap))
                        .font(.subheadline).monospacedDigit().privacySensitive()
                }
                ProgressView(value: min(1, ppf.year.paid / max(1, ppf.year.cap)))
                    .tint(ppf.year.over ? Color.orange : Color.kosh)
                Text(Self.limitLine(ppf.year)).font(.caption).foregroundStyle(ppf.year.over ? Color.orange : Color.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .padding(.vertical, 2)
        } header: {
            Text("PPF")
        } footer: {
            Text("From the payments kosh has already filed this financial year, nothing assumed about a standing instruction that hasn't run yet.")
        }
    }

    static func limitLine(_ y: RetirementBook.PPF.Year) -> String {
        let n: String = y.n == 1 ? "one payment" : Words.number(y.n) + " payments"
        if y.n == 0 { return "Nothing in yet this year. One account may take " + Fmt.rupees(y.cap) + " in a financial year." }
        if y.over {
            return Fmt.rupees(y.paid) + " in over " + n + ", which is past the " + Fmt.rupees(y.cap)
                + " one account may take in a year. Anything over the limit earns no interest and isn't deductible — worth checking whether some of it went to another account."
        }
        return Fmt.rupees(y.paid) + " in over " + n + " since " + Day.fmt(y.from, "d MMM") + ". "
            + Fmt.rupees(y.left) + " more may go in before 31 March."
    }
}

// MARK: - NPS

struct NPSSection: View {
    let nps: RetirementBook.NPS
    var body: some View {
        Section {
            HStack(alignment: .firstTextBaseline) {
                Label("NPS", systemImage: "chart.pie.fill").font(.subheadline.weight(.semibold))
                Spacer()
                Text(Fmt.rupees(nps.total)).font(.title3.weight(.bold)).monospacedDigit().privacySensitive()
            }
            .padding(.vertical, 2)
            if let t = nps.tier1 { NPSTierRow(tier: t, name: "Tier I", note: "The pension account: locked until you retire") }
            if let t = nps.tier2 { NPSTierRow(tier: t, name: "Tier II", note: "Yours to take out whenever you like") }
            if let v = nps.untiered, v > 0 {
                RetRow(title: "One NPS account", detail: "The statement didn't say which tier", amt: v)
            }
        } header: {
            Text("NPS")
        } footer: {
            Text("Tier I and Tier II are two different accounts with two different rules, so kosh never adds them into one line.")
        }
    }
}

struct NPSTierRow: View {
    let tier: RetirementBook.NPS.Tier
    let name: String
    let note: String
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack(alignment: .firstTextBaseline, spacing: 10) {
                VStack(alignment: .leading, spacing: 2) {
                    Text(name).font(.subheadline.weight(.medium))
                    Text(tier.cost > 0 ? note + " · " + Fmt.rupees(tier.cost) + " put in" : note)
                        .font(.caption).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                }
                Spacer(minLength: 8)
                Text(Fmt.rupees(tier.amt)).font(.subheadline.weight(.semibold)).monospacedDigit().privacySensitive()
            }
            RetAsOf(asOf: tier.navAsOf, days: tier.days, old: tier.old == true, what: "NAVs of its statement",
                    why: "An NPS statement is valued at the NAVs of its own day. Open a newer one to bring it up to date.")
        }
        .padding(.vertical, 2)
    }
}

// MARK: - the passbook itself, and what kosh remembers of you

/// The three taps that matter: open the EPFO yourself, tap Download, share the PDF into kosh. Then the papers list
/// for the passbooks already shared in, and the two things kosh remembers so it never asks again.
struct RetirementPapers: View {
    @Environment(Store.self) private var store
    /// the UAN and the date of birth kosh has, so the screen never asks for either
    var known: [Remembered] { Self.remembered(store) }
    var body: some View {
        if store.live != nil {
            Section {
                Button { store.betaSheet = .epf } label: {
                    HStack(spacing: 12) {
                        IconTile(symbol: "arrow.down.doc.fill", color: Color.kosh, size: 30)
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Open the EPFO passbook").font(.subheadline.weight(.semibold))
                            Text("Three taps: log in (kosh puts your UAN in, you type the password and the captcha), tap Download, then Share into kosh. kosh then has every month since you joined.")
                                .font(.caption).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                        }
                        Spacer(minLength: 6)
                        Image(systemName: "chevron.right").font(.footnote.weight(.semibold)).foregroundStyle(.tertiary)
                    }
                    .contentShape(Rectangle())
                }
                .buttonStyle(.press)
            } header: {
                Text("Bring EPF up to date")
            } footer: {
                Text("kosh never stores your EPFO password. The login always shows a captcha, which is there to stop software signing in, so a stored password wouldn't save you the trip — and the PDF carries far more than the page does.")
            }
            Section {
                ForEach(known) { item in
                    HStack {
                        Label(item.id, systemImage: "checkmark.seal.fill").font(.subheadline)
                        Spacer()
                        Text(item.value).font(.subheadline).monospacedDigit().foregroundStyle(.secondary).privacySensitive()
                    }
                }
                if known.isEmpty {
                    Text("kosh hasn't found your UAN in your mail yet. A payslip or an EPFO mail usually prints it, and kosh remembers it from there.")
                        .font(.subheadline).foregroundStyle(.secondary)
                }
                Button { store.betaSheet = .passwords } label: {
                    Label("Your details", systemImage: "person.text.rectangle").font(.subheadline)
                }
                .buttonStyle(.press).foregroundStyle(Color.kosh)
            } header: {
                Text("What kosh remembers")
            } footer: {
                Text("Kept on this phone, and used to fill in the EPFO's login and to open a locked passbook. Your EPFO password is not among them and never will be.")
            }
            // the passbooks and NPS statements already shared in, each with its password box if it's still locked
            StatementsSection(kinds: ["epf", "nps"], title: "Passbooks and statements",
                              empty: "No passbook or NPS statement opened yet. Share one in above, or from Files below.")
        }
    }

    /// one thing kosh already knows about you, named as it is called
    struct Remembered: Identifiable, Hashable { let id: String; let value: String }

    /// what kosh already knows, so it is never asked for: the UAN, and the date of birth the EPFO asks for too
    static func remembered(_ store: Store) -> [Remembered] {
        var out: [Remembered] = []
        let uan: String = store.rememberedUAN
        if !uan.isEmpty { out.append(Remembered(id: "UAN", value: uan)) }
        let dob: String = store.rememberedDOB
        if !dob.isEmpty { out.append(Remembered(id: "Date of birth", value: dob)) }
        return out
    }
}
