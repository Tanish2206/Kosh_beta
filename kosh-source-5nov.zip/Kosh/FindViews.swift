import SwiftUI

// MARK: - Find, redrawn (find-review, 1 Nov, from his screenshots)
//
// Under the field: one row of filters always there (Date, Category, Account, Amount, Spent/Received, Status), each a
// menu, lit when on; then what is on, as chips you take off, with how your typing was read ("Food & Drinks",
// "October 2026", "Over ₹5,000"); then the live line, "23 payments · ₹14,520". With nothing typed, Find guides by
// tapping: quick chips, a tile for each kind of spending with this month's count and total, your recent searches and a
// few examples. With nothing found, it says which filter to take off and how many payments that gives.

/// the field's company: the filters, what's on, and the live line
struct FindHead: View {
    @Environment(Store.self) private var store
    @Binding var q: FindQuery
    let read: FindParse
    let count: Int
    let out: Double
    let came: Double
    let more: () -> Void

    var body: some View {
        let on: [FindToken] = FindToken.of(q, store)
        let typed: [(kind: String, title: String)] = read.chips.filter { $0.kind != "text" }
        VStack(alignment: .leading, spacing: 8) {
            FindFilterRow(q: $q, more: more)
            if !on.isEmpty || !typed.isEmpty {
                FindOnRow(q: $q, on: on, typed: typed)
            }
            if !q.blank {
                FindTotal(count: count, out: out, came: came)
                    .padding(.horizontal, 20)
            }
        }
    }
}

/// a filter's chip: its name, or what it's set to, lit when on
struct FindFilterChip: View {
    let title: String
    let on: Bool
    var body: some View {
        HStack(spacing: 5) {
            Text(title).font(.system(.footnote, weight: .semibold)).lineLimit(1)
            Image(systemName: "chevron.down").font(.system(size: 9, weight: .bold))
        }
        .foregroundStyle(on ? Color.onKosh : Color.primary)
        .padding(.horizontal, 12)
        .frame(height: 34)
        .background(on ? Color.koshFill : Color.primary.opacity(0.06), in: Capsule())
        .frame(minHeight: 44)
        .contentShape(Capsule())
    }
}

/// Date · Category · Account · Amount · Spent/Received · Status
struct FindFilterRow: View {
    @Environment(Store.self) private var store
    @Binding var q: FindQuery
    let more: () -> Void

    var body: some View {
        ScrollView(.horizontal) {
            HStack(spacing: 8) {
                dateMenu
                Button(action: more) { FindFilterChip(title: q.cats.isEmpty ? "Category" : Self.list(q.cats.sorted()), on: !q.cats.isEmpty) }
                    .buttonStyle(.press)
                    .accessibilityHint("Opens every filter, categories first")
                accountMenu
                amountMenu
                flowMenu
                statusMenu
            }
            .padding(.horizontal, 20)
        }
        .scrollIndicators(.hidden)
    }
    static func list(_ xs: [String]) -> String {
        xs.count <= 1 ? (xs.first ?? "") : xs[0] + " +" + String(xs.count - 1)
    }
    private var dateMenu: some View {
        Menu {
            Picker("Date", selection: $q.span) {
                ForEach(FindSpan.allCases) { (s: FindSpan) in Text(s.title).tag(s) }
            }
        } label: {
            FindFilterChip(title: q.span == .all ? "Date" : q.span.title, on: q.span != .all)
        }
    }
    private var accountMenu: some View {
        let ways: [(String, String, String)] = FindFilters.ways
        let title: String = q.ways.isEmpty ? "Account" : Self.list(q.ways.sorted().map { (w: String) -> String in w == "wallet" ? "Wallets" : PaidWith.title(w) })
        return Menu {
            ForEach(ways, id: \.0) { (w: (String, String, String)) in
                Button {
                    FindFilters.flip(&q.ways, w.0)
                } label: {
                    Label(w.1, systemImage: q.ways.contains(w.0) ? "checkmark" : w.2)
                }
            }
            if !q.ways.isEmpty { Button("Any account", role: .destructive) { q.ways = [] } }
            Button("Banks and cards…", action: more)
        } label: {
            FindFilterChip(title: title, on: !q.ways.isEmpty)
        }
    }
    private var amountMenu: some View {
        Menu {
            Picker("Amount", selection: $q.size) {
                ForEach(FindSize.allCases) { (s: FindSize) in Text(s.title).tag(s) }
            }
            Button("A range of my own…", action: more)
        } label: {
            FindFilterChip(title: q.ranged ? FindAmount.label(q.lo, q.hi) : (q.size == .any ? "Amount" : q.size.title), on: q.size != .any || q.ranged)
        }
    }
    private var flowMenu: some View {
        Menu {
            Picker("Spent or received", selection: $q.flow) {
                ForEach(FindFlow.allCases) { (f: FindFlow) in Label(f.title, systemImage: f.sym).tag(f) }
            }
        } label: {
            FindFilterChip(title: q.flow == .any ? "Spent/Received" : q.flow.title, on: q.flow != .any)
        }
    }
    private var statusMenu: some View {
        let n: Int = (q.uncat ? 1 : 0) + (q.unnamed ? 1 : 0) + (q.chapter ? 1 : 0) + (q.refunds ? 1 : 0)
        return Menu {
            Toggle("Uncategorised", isOn: $q.uncat)
            Toggle("Needs a name", isOn: $q.unnamed)
            Toggle("Refunds and money back", isOn: $q.refunds)
            Toggle("In a chapter", isOn: $q.chapter)
        } label: {
            FindFilterChip(title: n == 0 ? "Status" : (n == 1 ? Self.statusWord(q) : "Status · " + String(n)), on: n > 0)
        }
    }
    static func statusWord(_ q: FindQuery) -> String {
        if q.uncat { return "Uncategorised" }
        if q.unnamed { return "Needs a name" }
        if q.refunds { return "Refunds" }
        return "In a chapter"
    }
}

/// what's on, each with a cross; then how the typing was read, which goes when the words do
struct FindOnRow: View {
    @Binding var q: FindQuery
    let on: [FindToken]
    let typed: [(kind: String, title: String)]
    var body: some View {
        ScrollView(.horizontal) {
            HStack(spacing: 8) {
                ForEach(on) { (t: FindToken) in
                    Button {
                        withAnimation(Motion.base) { t.off(&q) }
                    } label: {
                        FindOnChip(title: t.title, sym: t.sym, removable: true)
                    }
                    .buttonStyle(.press)
                    .accessibilityHint("Takes this filter off")
                }
                if !typed.isEmpty {
                    Text("Read as").font(.caption).foregroundStyle(.secondary)
                    ForEach(Self.chips(typed)) { (c: FindReadChip) in
                        FindOnChip(title: c.title, sym: FindOnChip.sym(c.kind), removable: false)
                    }
                }
            }
            .padding(.horizontal, 20)
        }
        .scrollIndicators(.hidden)
    }
    static func chips(_ typed: [(kind: String, title: String)]) -> [FindReadChip] {
        var out: [FindReadChip] = []
        for (i, x) in typed.enumerated() { out.append(FindReadChip(id: i, kind: x.kind, title: x.title)) }
        return out
    }
}

struct FindReadChip: Identifiable {
    let id: Int
    let kind: String
    let title: String
}

struct FindOnChip: View {
    let title: String
    let sym: String
    let removable: Bool
    static func sym(_ kind: String) -> String {
        switch kind {
        case "cat": return "square.grid.2x2"
        case "uncat": return "questionmark.square.dashed"
        case "month": return "calendar"
        case "amount": return "indianrupeesign"
        default: return "textformat"
        }
    }
    var body: some View {
        HStack(spacing: 6) {
            if !sym.isEmpty { Image(systemName: sym).font(.system(size: 11, weight: .semibold)) }
            Text(title).font(.system(.footnote, weight: .semibold)).lineLimit(1)
            if removable {
                Image(systemName: "xmark").font(.system(size: 9, weight: .heavy))
                    .frame(width: 18, height: 18)
                    .background(Color.kosh.opacity(0.14), in: Circle())
            }
        }
        .foregroundStyle(removable ? Color.kosh : Color.secondary)
        .padding(.leading, 11).padding(.trailing, removable ? 7 : 11)
        .frame(height: 30)
        .background(removable ? Color.kosh.opacity(0.12) : Color.clear, in: Capsule())
        .overlay(Capsule().strokeBorder(removable ? Color.clear : Color.secondary.opacity(0.35), lineWidth: 1))
        .frame(minHeight: 44)
        .contentShape(Capsule())
        .accessibilityLabel(title)
    }
}

// MARK: nothing typed yet: guide by tapping

/// one kind of spending's tile: this month's payments and total
struct FindCatTile: Identifiable, Hashable {
    let cat: String
    let n: Int
    let v: Double
    var id: String { cat }
}

enum FindStartData {
    /// this month's kinds of money out for whoever is shown, the most money first, and the payments with no category
    /// (all time, as Sort these counts them) with this month's total
    @MainActor static func make(_ store: Store) -> (tiles: [FindCatTile], uncatN: Int, uncatMonth: Double, overN: Int) {
        let cm: String = store.snap.cm
        var n: [String: Int] = [:]
        var v: [String: Double] = [:]
        var uncatN: Int = 0
        var uncatMonth: Double = 0
        var overN: Int = 0
        for t in store.tx where store.who.owns(t.o) {
            if Store.needsSorting(t) {
                uncatN += 1
                if t.d.hasPrefix(cm) && t.sp { uncatMonth += t.a }
            }
            if t.k == "out" && t.a > 5000 && t.partOf == nil { overN += 1 }
            guard t.d.hasPrefix(cm), t.k == "out", t.partOf == nil, t.c != "Miscellaneous", !t.c.isEmpty else { continue }
            n[t.c, default: 0] += 1
            if t.sp { v[t.c, default: 0] += t.a }
        }
        let tiles: [FindCatTile] = n.keys.map { (c: String) -> FindCatTile in FindCatTile(cat: c, n: n[c] ?? 0, v: v[c] ?? 0) }
            .sorted { (a: FindCatTile, b: FindCatTile) -> Bool in a.v != b.v ? a.v > b.v : a.cat < b.cat }
        return (tiles, uncatN, uncatMonth, overN)
    }
}

struct FindStart: View {
    @Environment(Store.self) private var store
    @Binding var q: FindQuery
    let recent: [String]
    static let examples: [String] = ["Swiggy", ">5000", "Oct", "food", "uncategorised"]

    var body: some View {
        let d: (tiles: [FindCatTile], uncatN: Int, uncatMonth: Double, overN: Int) = FindStartData.make(store)
        Section {
            FindQuickRow(q: $q, uncatN: d.uncatN, overN: d.overN)
                .listRowBackground(Color.clear)
                .listRowInsets(EdgeInsets(top: 4, leading: 0, bottom: 4, trailing: 0))
        }
        Section {
            FindCatGrid(q: $q, tiles: d.tiles, uncatN: d.uncatN, uncatMonth: d.uncatMonth)
                .listRowBackground(Color.clear)
                .listRowInsets(EdgeInsets(top: 4, leading: 4, bottom: 4, trailing: 4))
        } header: {
            Text("This month by category · " + Day.monthName(store.snap.cm))
        }
        if !recent.isEmpty {
            Section("Recent searches") {
                ForEach(recent, id: \.self) { (w: String) in
                    Button { q.text = w } label: {
                        Label(w, systemImage: "clock.arrow.circlepath").foregroundStyle(Color.primary)
                    }
                }
            }
        }
        Section {
            FindExamples(q: $q, words: Self.examples)
                .listRowBackground(Color.clear)
                .listRowInsets(EdgeInsets(top: 4, leading: 0, bottom: 4, trailing: 0))
        } header: {
            Text("Try typing")
        } footer: {
            Text("A shop, a person, a UPI ID or a note; a category; a month; an amount (22,476, 5000-10000, >5000, under 1L).")
        }
    }
}

struct FindQuickRow: View {
    @Binding var q: FindQuery
    let uncatN: Int
    let overN: Int
    var body: some View {
        ScrollView(.horizontal) {
            HStack(spacing: 8) {
                if uncatN > 0 {
                    quick("Uncategorised · " + String(uncatN), "questionmark.square.dashed") { q.uncat = true }
                }
                quick("This month", "calendar") { q.span = .month }
                if overN > 0 { quick("Over ₹5,000", "indianrupeesign") { q.text = ">5000" } }
                quick("Refunds", "arrow.uturn.backward") { q.refunds = true }
                quick("Card", "creditcard") { q.ways = ["card"] }
                quick("UPI", "qrcode") { q.ways = ["upi"] }
            }
            .padding(.horizontal, 20)
        }
        .scrollIndicators(.hidden)
    }
    private func quick(_ title: String, _ sym: String, _ act: @escaping () -> Void) -> some View {
        Button {
            withAnimation(Motion.base) { act() }
        } label: {
            HStack(spacing: 6) {
                Image(systemName: sym).font(.system(size: 12, weight: .semibold))
                Text(title).font(.system(.footnote, weight: .semibold)).lineLimit(1)
            }
            .foregroundStyle(Color.primary)
            .padding(.horizontal, 12)
            .frame(height: 34)
            .background(Color(.secondarySystemGroupedBackground), in: Capsule())
            .frame(minHeight: 44)
            .contentShape(Capsule())
        }
        .buttonStyle(.press)
    }
}

/// the tiles: a kind of spending each, with its icon, this month's payments and total; Uncategorised first
struct FindCatGrid: View {
    @Environment(Store.self) private var store
    @Binding var q: FindQuery
    let tiles: [FindCatTile]
    let uncatN: Int
    let uncatMonth: Double
    private let cols: [GridItem] = [GridItem(.flexible(), spacing: 10), GridItem(.flexible(), spacing: 10), GridItem(.flexible(), spacing: 10)]

    var body: some View {
        LazyVGrid(columns: cols, spacing: 10) {
            if uncatN > 0 {
                Button { q.uncat = true } label: {
                    FindTileFace(sym: "questionmark.square.dashed", color: Color.orange, name: "Uncategorised", count: String(uncatN) + " to sort", money: uncatMonth > 0 ? Fmt.rupees(uncatMonth) : "")
                }
                .buttonStyle(.press)
            }
            ForEach(tiles.prefix(11)) { (t: FindCatTile) in
                Button {
                    q.cats = [t.cat]
                    q.span = .month
                } label: {
                    FindTileFace(sym: store.symbol(t.cat), color: store.catColor(t.cat), name: t.cat, count: String(t.n) + (t.n == 1 ? " payment" : " payments"), money: t.v > 0 ? Fmt.rupees(t.v) : "")
                }
                .buttonStyle(.press)
            }
        }
        .privacySensitive()
    }
}

struct FindTileFace: View {
    let sym: String
    let color: Color
    let name: String
    let count: String
    let money: String
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            IconTile(symbol: sym, color: color, size: 30)
            Text(name).font(.footnote.weight(.semibold)).foregroundStyle(Color.primary).lineLimit(1).minimumScaleFactor(0.8)
            Text(count).font(.caption2).foregroundStyle(.secondary).lineLimit(1)
            Text(money.isEmpty ? " " : money).font(.caption.weight(.semibold)).monospacedDigit().foregroundStyle(Color.primary).lineLimit(1)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(10)
        .background(Color(.secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        .contentShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
        .accessibilityElement(children: .combine)
    }
}

struct FindExamples: View {
    @Binding var q: FindQuery
    let words: [String]
    var body: some View {
        ScrollView(.horizontal) {
            HStack(spacing: 8) {
                ForEach(words, id: \.self) { (w: String) in
                    Button { q.text = w } label: {
                        Text(w).font(.system(.footnote, weight: .semibold)).foregroundStyle(Color.kosh)
                            .padding(.horizontal, 12).frame(height: 32)
                            .overlay(Capsule().strokeBorder(Color.kosh.opacity(0.4), lineWidth: 1))
                            .frame(minHeight: 44)
                            .contentShape(Capsule())
                    }
                    .buttonStyle(.press)
                }
            }
            .padding(.horizontal, 20)
        }
        .scrollIndicators(.hidden)
    }
}

// MARK: nothing found: which filter to take off

struct FindDrop: Identifiable {
    let id: String
    let title: String
    let n: Int
    let q: FindQuery
}

enum FindDrops {
    /// each filter on (and the typed words), taken off one at a time, with how many payments that gives; the most first
    @MainActor static func make(_ q: FindQuery, _ store: Store) -> [FindDrop] {
        var out: [FindDrop] = []
        for t in FindToken.of(q, store) {
            var q2: FindQuery = q
            t.off(&q2)
            if q2.blank { continue }
            let n: Int = q2.run(store).count
            if n > 0 { out.append(FindDrop(id: t.id, title: t.title, n: n, q: q2)) }
        }
        if !q.words.isEmpty && q.on > 0 {
            var q2: FindQuery = q
            q2.text = ""
            let n: Int = q2.run(store).count
            if n > 0 { out.append(FindDrop(id: "words", title: "“" + q.words + "”", n: n, q: q2)) }
        }
        return Array(out.sorted { (a: FindDrop, b: FindDrop) -> Bool in a.n > b.n }.prefix(3))
    }
}

struct FindNoResults: View {
    @Environment(Store.self) private var store
    @Binding var q: FindQuery
    var body: some View {
        let drops: [FindDrop] = FindDrops.make(q, store)
        Section {
            ContentUnavailableView("Nothing matches", systemImage: "magnifyingglass",
                                   description: Text(drops.isEmpty ? (q.words.isEmpty ? "No payment has all of these." : "Nothing for “" + q.words + "”. Try a shorter word or part of the name.") : "No payment has all of these. Take one off:"))
                .listRowBackground(Color.clear)
        }
        if !drops.isEmpty {
            Section {
                ForEach(drops) { (d: FindDrop) in
                    Button {
                        withAnimation(Motion.base) { q = d.q }
                    } label: {
                        HStack {
                            Label("Take off " + d.title, systemImage: "minus.circle").foregroundStyle(Color.primary)
                            Spacer(minLength: 8)
                            Text(String(d.n) + (d.n == 1 ? " payment" : " payments")).foregroundStyle(.secondary).monospacedDigit()
                        }
                    }
                }
            }
        }
    }
}

// MARK: a payment found

/// the payment's row with the words you typed lit in its name, and, when it has no category, "Set category" there
struct FindHitRow: View {
    @Environment(Store.self) private var store
    let t: Txn
    let mark: [String]
    var body: some View {
        let sortable: Bool = Store.needsSorting(t) && store.live != nil
        VStack(alignment: .leading, spacing: 6) {
            TxRow(t: t, when: Day.time12(t.t), mark: mark)
            if sortable { FindSetCategory(t: t) }
        }
        .modifier(TxSwipes(t: t))
    }
}

/// a menu of the kinds of spending; a pick files the payment at once, as its sheet's category edit does
struct FindSetCategory: View {
    @Environment(Store.self) private var store
    let t: Txn
    var body: some View {
        let cats: [String] = store.spendCategories
        Menu {
            ForEach(cats, id: \.self) { (c: String) in
                Button { store.setCategory(t.id, c, "") } label: { Label(c, systemImage: store.symbol(c)) }
            }
        } label: {
            HStack(spacing: 6) {
                Image(systemName: "tag").font(.system(size: 12, weight: .semibold))
                Text("Set category").font(.system(.footnote, weight: .semibold))
            }
            .foregroundStyle(Color.kosh)
            .padding(.horizontal, 12).frame(height: 30)
            .background(Color.kosh.opacity(0.12), in: Capsule())
            .frame(minHeight: 44, alignment: .leading)
            .contentShape(Capsule())
        }
        .padding(.leading, 48)
        .accessibilityHint("Files this payment under the category you pick")
    }
}

/// a payment's name with the words you typed lit (bold, kosh's colour); the name as it is when nothing matches
enum TxMark {
    static func lit(_ name: String, _ words: [String]) -> AttributedString {
        var out = AttributedString(name)
        let low: String = name.lowercased()
        // (a name whose lower case changes its length is left unlit, never cut in the wrong place)
        guard low.count == name.count else { return out }
        for w in words where w.count >= 2 {
            var from: String.Index = low.startIndex
            while let r = low.range(of: w.lowercased(), range: from..<low.endIndex) {
                let a: Int = low.distance(from: low.startIndex, to: r.lowerBound)
                let n: Int = low.distance(from: r.lowerBound, to: r.upperBound)
                let lo: AttributedString.Index = out.index(out.startIndex, offsetByCharacters: a)
                let hi: AttributedString.Index = out.index(lo, offsetByCharacters: n)
                out[lo..<hi].foregroundColor = Color.kosh
                out[lo..<hi].inlinePresentationIntent = .stronglyEmphasized
                from = r.upperBound
            }
        }
        return out
    }
}
