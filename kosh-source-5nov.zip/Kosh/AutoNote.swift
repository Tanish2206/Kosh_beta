import Foundation

/// the note kosh writes for a payment it knows the contents of (fb 2 Nov): once each, never over yours
@MainActor
enum AutoNote {
    static let key: String = "autonote.done"
    /// "Yogabar 26% High Protein Oats 1kg — ₹1,099\nUrban Platter Round Rice Paper Sheets — ₹295\nOrder 407-1971701-6067505"
    static func note(_ t: Txn, _ store: Store) -> String? {
        if let o = store.order(t), let show = o.show { return EventWords.note(show, booking: o.o) }
        // a bill paid through an app: where, for which card or connection, from where, its references (BillLoop.swift)
        if t.lp != nil, let n = LoopWords.note(t, store) { return n }
        guard let f = store.payFact(t) else { return nil }
        var lines: [String] = []
        if let o = f.outlet, !o.isEmpty { lines.append("From " + o) }
        let items: [PayFacts.Item] = f.items ?? []
        for it in items.prefix(6) {
            var l: String = SplitWords.short(it.n)
            if (it.q ?? 1) > 1 { l = String(it.q ?? 1) + " × " + l }
            if let a = it.amt, a > 0 { l += " — " + Fmt.rupees(a) }
            if it.ret != nil { l += " (returned)" }
            lines.append(l)
        }
        if items.count > 6 { lines.append("+" + String(items.count - 6) + " more") }
        if let orders = SplitWords.orders(items) { lines.append(orders) }
        // (nothing but a restaurant's name, or nothing at all: no note)
        guard items.count > 0 else { return nil }
        return lines.joined(separator: "\n")
    }
    static func apply(_ store: Store) {
        guard let live = store.live else { return }
        var done: Set<String> = Set(UserDefaults.standard.stringArray(forKey: key) ?? [])
        var wrote: Int = 0, cands: Int = 0, hasN: Int = 0, hasO: Int = 0, noItems: Int = 0
        for t in store.snap.tx where (t.k == "out" || (t.k == "cardpay" && t.dr != "in" && t.mr != true)) && t.partOf == nil && t.wf == nil {
            cands += 1
            // (a note of yours, or one you cleared after kosh wrote it, stays as it is)
            if !t.n.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { hasN += 1; continue }
            if let o = live.overrides[t.id], let on = o.n, !on.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { hasO += 1; continue }
            // (a note kosh wrote that has since gone, lost to a sheet saved before it arrived: written again; one you
            // cleared yourself is kept cleared by its own mark)
            if done.contains(t.id) && live.overrides[t.id]?.n == "" && UserDefaults.standard.bool(forKey: "autonote.cleared." + t.id) { continue }
            guard let n = note(t, store) else { noItems += 1; continue }
            live.override(t.id) { $0.n = n }
            done.insert(t.id)
            wrote += 1
        }
        let pf: Int = store.snap.tx.filter { store.payFact($0)?.items?.isEmpty == false }.count
        let my: String = store.snap.tx.filter { $0.d == "2026-10-25" && $0.m.lowercased().contains("myntra") }.map { String($0.a) + ":" + $0.c + ":wu" + String($0.wu?.count ?? 0) }.joined(separator: ",")
        var amL: [String] = []
        for t in store.snap.tx where t.d == "2026-11-02" && t.m.lowercased().contains("amazon") {
            let ic: Int = store.payFact(t)?.items?.count ?? -1
            let oc: Int = live.overrides[t.id]?.n?.count ?? -1
            amL.append(String(t.a) + ":items\(ic):done\(done.contains(t.id) ? 1 : 0):n\(t.n.count):o\(oc)")
        }
        let am: String = amL.joined(separator: ",")
        UserDefaults.standard.set("amazon2nov " + am + " | tx \(store.snap.tx.count) cands \(cands) note \(hasN) ovr \(hasO) noitems \(noItems) wrote \(wrote) done \(done.count) withItems \(pf) myntra \(my)", forKey: "autonote.debug")
        if wrote > 0 {
            UserDefaults.standard.set(Array(done), forKey: key)
            live.rebuildSoon()
        }
    }
}
