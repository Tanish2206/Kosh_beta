import Foundation

// MARK: - Insurance, worked out for the screens (no drawing here)
//
// What the three Insurance screens show (InsuranceBook.swift: the home, the payments timeline, a policy's page) worked
// out from the build's policies and premiums ahead (engine/21f and 22: Policy, PremAhead), once a build for whoever's
// money is showing (Store.insuranceHome). Every figure is one the build holds or a sum of them; what isn't known is
// nil or empty, and the screens leave its row out. No words or ₹ here: the screens write them. Foundation only, so
// engine-test/insurance-obsidian.js compiles it with the phone's own Policy and PremAhead (tools/swiftslice.js) and
// holds each figure to the build.

/// the kinds the screens colour and group by
enum InsKind: String, CaseIterable, Hashable {
    case health, term, savings, ulip, motor, property, other
    /// a policy's kind, from the build's (PolicyKinds' names)
    static func of(kind: String, type: String) -> InsKind {
        switch kind {
        case "Health", "Top-up": return .health
        case "Term": return .term
        case "Endowment", "Savings", "Money back", "Pension", "Whole life": return .savings
        case "ULIP": return .ulip
        case "Car", "Two-wheeler", "Vehicle": return .motor
        case "Home": return .property
        case "": return type == "Motor" ? .motor : type == "Health" ? .health : .other
        default: return type == "Motor" ? .motor : .other
        }
    }
    static func of(_ p: Policy) -> InsKind { of(kind: p.kind ?? "", type: p.type) }
    var title: String {
        switch self {
        case .health: return "Health"
        case .term: return "Term life"
        case .savings: return "Savings plans"
        case .ulip: return "ULIP"
        case .motor: return "Motor"
        case .property: return "Home"
        case .other: return "Other cover"
        }
    }
    /// a life policy: its premiums run for years and its page has a schedule
    var life: Bool { self == .term || self == .savings || self == .ulip }
}

/// days as kosh writes them (yyyy-MM-dd): whole days apart, a month on, a month's last day
enum InsDay {
    static func parts(_ s: String) -> (Int, Int, Int)? {
        let p: [Substring] = s.prefix(10).split(separator: "-")
        guard p.count == 3, let y = Int(p[0]), let m = Int(p[1]), let d = Int(p[2]), m >= 1, m <= 12, d >= 1, d <= 31 else { return nil }
        return (y, m, d)
    }
    /// days since 1970-01-01 (the civil calendar, no time zone)
    static func index(_ s: String) -> Int? {
        guard let (y0, m, d) = parts(s) else { return nil }
        let y: Int = m <= 2 ? y0 - 1 : y0
        let era: Int = (y >= 0 ? y : y - 399) / 400
        let yoe: Int = y - era * 400
        let mp: Int = (m + 9) % 12
        let doy: Int = (153 * mp + 2) / 5 + d - 1
        let doe: Int = yoe * 365 + yoe / 4 - yoe / 100 + doy
        return era * 146097 + doe - 719468
    }
    static func between(_ a: String, _ b: String) -> Int {
        guard let x = index(a), let y = index(b) else { return 0 }
        return y - x
    }
    static func monthLength(_ y: Int, _ m: Int) -> Int {
        if m == 2 { return (y % 4 == 0 && y % 100 != 0) || y % 400 == 0 ? 29 : 28 }
        return [4, 6, 9, 11].contains(m) ? 30 : 31
    }
    static func iso(_ y: Int, _ m: Int, _ d: Int) -> String {
        String(format: "%04d-%02d-%02d", y, m, d)
    }
    /// n months on, the day kept (cut to the month's last)
    static func addMonths(_ s: String, _ n: Int) -> String {
        guard let (y, m, d) = parts(s) else { return s }
        let t: Int = y * 12 + (m - 1) + n
        let ny: Int = t / 12, nm: Int = t % 12 + 1
        return iso(ny, nm, min(d, monthLength(ny, nm)))
    }
    static func addDays(_ s: String, _ n: Int) -> String {
        guard let i = index(s) else { return s }
        // (back from a day index: the civil calendar, the other way)
        let z: Int = i + n + 719468
        let era: Int = (z >= 0 ? z : z - 146096) / 146097
        let doe: Int = z - era * 146097
        let yoe: Int = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365
        let doy: Int = doe - (365 * yoe + yoe / 4 - yoe / 100)
        let mp: Int = (5 * doy + 2) / 153
        let d: Int = doy - (153 * mp + 2) / 5 + 1
        let m: Int = mp < 10 ? mp + 3 : mp - 9
        return iso(yoe + era * 400 + (m <= 2 ? 1 : 0), m, d)
    }
    /// the last day of the month n months on from the one s is in
    static func monthEnd(_ s: String, _ n: Int) -> String {
        guard let (y, m, _) = parts(s) else { return s }
        let t: Int = y * 12 + (m - 1) + n
        let ny: Int = t / 12, nm: Int = t % 12 + 1
        return iso(ny, nm, monthLength(ny, nm))
    }
    /// whole years and months from a to b
    static func span(_ a: String, _ b: String) -> (years: Int, months: Int) {
        guard let (y0, m0, d0) = parts(a), let (y1, m1, d1) = parts(b) else { return (0, 0) }
        var mo: Int = (y1 - y0) * 12 + (m1 - m0)
        if d1 < d0 { mo -= 1 }
        mo = max(0, mo)
        return (mo / 12, mo % 12)
    }
}

// MARK: The home

/// one premium or renewal ahead (a PremAhead), as the cards and the timeline show it
struct InsDue: Hashable, Identifiable {
    let a: PremAhead
    let kind: InsKind
    /// days from today (below nothing: past due, in its grace period)
    let days: Int
    /// its policy's premium comes by auto-debit (the last one did)
    let auto: Bool
    /// how often: "monthly", "quarterly", "half-yearly", "yearly", "renewal" (cover bought a year at a time), "" not known
    let every: String
    var id: String { a.id }
    var known: Bool { a.amt > 0 }
}

/// a slice of the premium ring, a kind's tile
struct InsKindPart: Hashable, Identifiable {
    let kind: InsKind
    /// its policies' premiums a year, and that as a share of all of them (0…1)
    let yearly: Double
    let share: Double
    let n: Int
    /// its headline: what its policies cover or pay (figure, and which: "cover", "sum", "maturity", "fund", "idv",
    /// "property"), only when every one of them says it; figOn, the day a fund value is for
    let fig: Double?
    let figIs: String
    let figOn: String
    /// one policy covering several people (a floater): how many
    let members: Int
    var id: String { kind.rawValue }
}

/// a person whose name policies are in: how many, and their premiums a year
struct InsWhose: Hashable, Identifiable {
    let id: String
    let n: Int
    let yearly: Double
}

struct InsHome: Hashable {
    /// premiums a year, of how many policies, for how many people
    let yearly: Double
    let n: Int
    let people: Int
    /// the ring and the tiles: kinds by their premiums a year, biggest first (a kind with none known last, by count)
    let parts: [InsKindPart]
    /// life cover, health cover (each health policy's sum once) and what's insured of things (motor IDV, home cover)
    let life: Double
    let health: Double
    let assets: Double
    /// the premiums ahead, soonest first (one past due first)
    let next: [InsDue]
    let whose: [InsWhose]
    /// kinds of cover kosh found no policy of ("Health", "Term", "Accident", "Home", "Travel"), each only while no
    /// policy kosh couldn't name the kind of might be one
    let gaps: [String]
    /// every running policy, the soonest due first
    let rows: [Policy]

    static func freq(_ p: Policy?) -> String {
        guard let p else { return "" }
        let f: String = (p.frequency ?? "").lowercased()
        if f.isEmpty { return InsKind.of(p).life ? "" : "renewal" }
        switch PremiumPlan.step(p) {
        case 1: return "monthly"
        case 3: return "quarterly"
        case 6: return "half-yearly"
        case 0: return "single premium"
        default: return InsKind.of(p).life ? "yearly" : "renewal"
        }
    }

    /// the premiums ahead of these policies (the build's premAhead, already for whoever is showing): from today, and a
    /// day gone by only while its policy is past due
    static func dues(_ ahead: [PremAhead], _ pols: [Policy], today: String) -> [InsDue] {
        var by: [String: Policy] = [:]
        for p in pols { by[p.id] = p }
        var out: [InsDue] = []
        for a in ahead {
            let p: Policy? = by[a.policy]
            if a.date < today && p?.status != "overdue" { continue }
            let k: InsKind = p.map { InsKind.of($0) } ?? InsKind.of(kind: a.kind, type: "")
            out.append(InsDue(a: a, kind: k, days: InsDay.between(today, a.date), auto: p?.auto == true, every: freq(p)))
        }
        return out.sorted { (x: InsDue, y: InsDue) -> Bool in x.a.date != y.a.date ? x.a.date < y.a.date : x.a.amt > y.a.amt }
    }

    static func make(_ pols: [Policy], ahead: [PremAhead], today: String) -> InsHome {
        let running: [Policy] = pols.filter { !$0.isEnded }
        let yearly: Double = running.reduce(0) { $0 + max(0, $1.yearly) }
        var parts: [InsKindPart] = []
        for k in InsKind.allCases {
            let mine: [Policy] = running.filter { InsKind.of($0) == k }
            if mine.isEmpty { continue }
            let y: Double = mine.reduce(0) { $0 + max(0, $1.yearly) }
            let fig: (Double?, String, String) = headline(k, mine)
            let floater: Int = mine.count == 1 ? (mine[0].covers ?? []).count : 0
            parts.append(InsKindPart(kind: k, yearly: y, share: yearly > 0 ? y / yearly : 0, n: mine.count, fig: fig.0, figIs: fig.1, figOn: fig.2, members: floater > 1 ? floater : 0))
        }
        parts.sort { (a: InsKindPart, b: InsKindPart) -> Bool in a.yearly != b.yearly ? a.yearly > b.yearly : a.n > b.n }
        let cover: (Policy) -> Double = { max(0, $0.cover ?? 0) }
        let life: Double = running.filter { InsKind.of($0).life || ($0.kind ?? "") == "Life" }.reduce(0) { $0 + cover($1) }
        let health: Double = running.filter { InsKind.of($0) == .health }.reduce(0) { $0 + cover($1) }
        let assets: Double = running.filter { InsKind.of($0) == .motor || InsKind.of($0) == .property }.reduce(0) { $0 + cover($1) }
        var whoN: [String: Int] = [:], whoY: [String: Double] = [:]
        for p in running { whoN[p.owner, default: 0] += 1; whoY[p.owner, default: 0] += max(0, p.yearly) }
        let whose: [InsWhose] = whoN.keys.map { InsWhose(id: $0, n: whoN[$0] ?? 0, yearly: whoY[$0] ?? 0) }
            .sorted { (a: InsWhose, b: InsWhose) -> Bool in a.id == "me" ? true : b.id == "me" ? false : a.yearly != b.yearly ? a.yearly > b.yearly : a.id < b.id }
        let rows: [Policy] = running.sorted { (a: Policy, b: Policy) -> Bool in
            let x: String = a.nextDue.isEmpty ? "9999" : a.nextDue, y: String = b.nextDue.isEmpty ? "9999" : b.nextDue
            return x != y ? x < y : a.yearly > b.yearly
        }
        return InsHome(yearly: yearly, n: running.count, people: whose.count, parts: parts, life: life, health: health, assets: assets,
                       next: dues(ahead, running, today: today), whose: whose, gaps: gaps(running), rows: rows)
    }

    /// a kind's headline figure: health, what it insures (a sum); term, life cover; a savings plan, what it pays at
    /// maturity, else its cover; a ULIP, its fund value (and the day), else its cover; motor, the IDV; home, what's
    /// insured. Only when every policy of the kind gave it: a sum of some of them would read as all of them
    static func headline(_ k: InsKind, _ mine: [Policy]) -> (Double?, String, String) {
        let every: ((Policy) -> Double) -> Double? = { (f: (Policy) -> Double) -> Double? in
            let v: [Double] = mine.map(f)
            return v.allSatisfy { $0 > 0 } ? v.reduce(0, +) : nil
        }
        let cover: (Policy) -> Double = { $0.cover ?? 0 }
        switch k {
        case .health: return (every(cover), "sum", "")
        case .term: return (every(cover), "cover", "")
        case .savings:
            if let m = every({ $0.maturity ?? 0 }) { return (m, "maturity", "") }
            return (every(cover), "cover", "")
        case .ulip:
            if let f = every({ $0.fundValue ?? 0 }) {
                let on: String = mine.compactMap { $0.fundAsOf }.filter { !$0.isEmpty }.min() ?? ""
                return (f, "fund", on)
            }
            return (every(cover), "cover", "")
        case .motor: return (every(cover), "idv", "")
        case .property: return (every(cover), "property", "")
        case .other: return (every(cover), "cover", "")
        }
    }

    /// kinds of cover with no policy in the mail: said only of kinds a person holds for themselves, and never while a
    /// policy kosh couldn't name the kind of might be that kind (an unnamed life policy might be term; "Other" cover
    /// might be any of the rest)
    static func gaps(_ running: [Policy]) -> [String] {
        let have: Set<String> = Set(running.map { $0.kind ?? "" })
        let unnamedLife: Bool = have.contains("Life")
        let unnamedOther: Bool = have.contains("Other") || have.contains("")
        var out: [String] = []
        if !have.contains("Health") && !have.contains("Top-up") && !unnamedOther { out.append("Health") }
        if !have.contains("Term") && !unnamedLife { out.append("Term") }
        for k in ["Accident", "Home", "Travel"] where !have.contains(k) && !unnamedOther { out.append(k) }
        return out
    }
}

// MARK: The payments timeline

enum InsRange: String, CaseIterable, Hashable {
    case d7, d30, m1, m3, m6
    var label: String {
        switch self {
        case .d7: return "7 days"
        case .d30: return "30 days"
        case .m1: return "1 month"
        case .m3: return "3 months"
        case .m6: return "6 months"
        }
    }
    /// its last day: a week or thirty days on, or the end of this month, of the third or of the sixth
    func end(_ today: String) -> String {
        switch self {
        case .d7: return InsDay.addDays(today, 7)
        case .d30: return InsDay.addDays(today, 30)
        case .m1: return InsDay.monthEnd(today, 0)
        case .m3: return InsDay.monthEnd(today, 2)
        case .m6: return InsDay.monthEnd(today, 5)
        }
    }
    /// how many of the six months it reaches into
    func months(_ today: String) -> Int {
        let e: String = end(today)
        guard let (y0, m0, _) = InsDay.parts(today), let (y1, m1, _) = InsDay.parts(e) else { return 1 }
        return min(6, (y1 - y0) * 12 + (m1 - m0) + 1)
    }
}

/// one month of the six: what falls due in it by kind (biggest kind first), and whether the range reaches it
struct InsMonthBar: Hashable, Identifiable {
    let m: String
    let total: Double
    let parts: [InsSlicePart]
    let inRange: Bool
    var id: String { m }
}
struct InsSlicePart: Hashable { let kind: InsKind; let amt: Double }

/// a month of the list: its premiums, what the known ones add up to
struct InsMonthGroup: Hashable, Identifiable {
    let m: String
    let items: [InsDue]
    let total: Double
    var id: String { m }
}

struct InsTimeline: Hashable {
    let range: InsRange
    let end: String
    /// what falls due from today to the end (and one past due), what the known ones add up to, how many by auto-debit,
    /// how many have no figure yet, and the largest
    let items: [InsDue]
    let total: Double
    let auto: Int
    let unknown: Int
    let largest: InsDue?
    /// the next six months, whatever the range (the ones it doesn't reach dimmed), and the most any of them holds
    let bars: [InsMonthBar]
    let barMax: Double
    let sixTotal: Double
    let sixN: Int
    let groups: [InsMonthGroup]
    /// days from today to the end: where on the runway each one sits
    let span: Int

    static func make(_ dues: [InsDue], today: String, range: InsRange) -> InsTimeline {
        let end: String = range.end(today)
        let items: [InsDue] = dues.filter { $0.a.date <= end }
        let total: Double = items.reduce(0) { $0 + max(0, $1.a.amt) }
        let largest: InsDue? = items.filter(\.known).max { $0.a.amt < $1.a.amt }
        let reach: Int = range.months(today)
        var bars: [InsMonthBar] = []
        let sixEnd: String = InsDay.monthEnd(today, 5)
        for i in 0..<6 {
            let m: String = String(InsDay.monthEnd(today, i).prefix(7))
            let these: [InsDue] = dues.filter { (i == 0 ? $0.a.date <= InsDay.monthEnd(today, 0) : String($0.a.date.prefix(7)) == m) && $0.known }
            var by: [InsKind: Double] = [:]
            for d in these { by[d.kind, default: 0] += d.a.amt }
            let parts: [InsSlicePart] = InsKind.allCases.compactMap { (k: InsKind) -> InsSlicePart? in by[k].map { InsSlicePart(kind: k, amt: $0) } }
                .sorted { $0.amt > $1.amt }
            bars.append(InsMonthBar(m: m, total: these.reduce(0) { $0 + $1.a.amt }, parts: parts, inRange: i < reach))
        }
        let six: [InsDue] = dues.filter { $0.a.date <= sixEnd }
        var groups: [InsMonthGroup] = []
        for d in items {
            // (one past due is this month's to pay)
            let m: String = d.days < 0 ? String(today.prefix(7)) : String(d.a.date.prefix(7))
            if let i = groups.firstIndex(where: { $0.m == m }) {
                let g: InsMonthGroup = groups[i]
                groups[i] = InsMonthGroup(m: m, items: g.items + [d], total: g.total + max(0, d.a.amt))
            } else {
                groups.append(InsMonthGroup(m: m, items: [d], total: max(0, d.a.amt)))
            }
        }
        return InsTimeline(range: range, end: end, items: items, total: total, auto: items.filter(\.auto).count,
                           unknown: items.filter { !$0.known }.count, largest: largest, bars: bars,
                           barMax: bars.map(\.total).max() ?? 0, sixTotal: six.reduce(0) { $0 + max(0, $1.a.amt) }, sixN: six.count,
                           groups: groups, span: max(1, InsDay.between(today, end)))
    }
}

// MARK: A policy's page

/// one premium (or, with many, one year of them) on the ring and in the grid: paid, the next, or still to come
enum InsStep: String, Hashable { case paid, next, left }

struct InsYear: Hashable, Identifiable {
    let year: Int
    let state: InsStep
    var id: Int { year }
}

struct InsPolicyPage {
    let p: Policy
    let kind: InsKind
    /// the schedule (a life policy whose start, premium and paying term are known): the ring's steps (each premium, or
    /// each year of them when there are more than thirty), how many are paid and left, what's still to pay
    let ring: [InsStep]
    let paid: Int
    let total: Int
    let left: Int
    let toGo: Double
    /// the next premium: its day, days to it, which one it is (0: not known)
    let nextDays: Int?
    let nextIndex: Int
    /// the policy's life: where today, the last premium and the end sit on it (0…1), how long it has run and has left
    let lifeFrom: String
    let lifeTo: String
    let todayAt: Double?
    let payEndAt: Double?
    let ran: (years: Int, months: Int)?
    let toRun: (years: Int, months: Int)?
    /// what goes in (every premium of its schedule) and what has, what comes back (its maturity figure) and when
    let putIn: Double?
    let back: Double?
    /// the year grid
    let years: [InsYear]

    static func make(_ p: Policy, today: String) -> InsPolicyPage {
        let kind: InsKind = InsKind.of(p)
        let total: Int = max(0, p.totalN ?? 0)
        let paid: Int = min(total, max(0, p.paidN ?? 0))
        let left: Int = total > 0 ? max(0, total - paid) : 0
        let start: String = p.start ?? ""
        let step: Int = PremiumPlan.step(p)
        let scheduled: Bool = total > 0 && InsDay.parts(start) != nil && p.premium > 0
        // the years each premium falls in, from the start, every step
        var years: [InsYear] = []
        if scheduled {
            var byYear: [Int: [Int]] = [:]
            for k in 0..<total {
                let d: String = step == 0 ? start : InsDay.addMonths(start, step * k)
                if let (y, _, _) = InsDay.parts(d) { byYear[y, default: []].append(k) }
            }
            for y in byYear.keys.sorted() {
                let ks: [Int] = byYear[y] ?? []
                let st: InsStep = ks.allSatisfy { $0 < paid } ? .paid : ks.contains(paid) ? .next : .left
                years.append(InsYear(year: y, state: st))
            }
            if years.count > 40 { years = [] }
        }
        var ring: [InsStep] = []
        if scheduled {
            if total <= 30 { ring = (0..<total).map { $0 < paid ? .paid : $0 == paid ? .next : .left } }
            else { ring = years.map(\.state) }
        }
        let nextDays: Int? = p.nextDue.isEmpty || p.isEnded ? nil : InsDay.between(today, p.nextDue)
        // the policy's life: from its start to its end (a life policy's maturity, other cover's renewal day)
        let end: String = !(p.endDate ?? "").isEmpty ? (p.endDate ?? "") : (p.end ?? "")
        let hasLife: Bool = InsDay.parts(start) != nil && InsDay.parts(end) != nil && end > start
        let whole: Double = Double(max(1, InsDay.between(start, end)))
        let at: (String) -> Double = { (d: String) -> Double in min(1, max(0, Double(InsDay.between(start, d)) / whole)) }
        let payEnd: String = p.payEnd ?? ""
        let putIn: Double? = scheduled ? Double(total) * p.premium : nil
        let back: Double? = (p.maturity ?? 0) > 0 ? p.maturity : nil
        return InsPolicyPage(p: p, kind: kind, ring: ring, paid: paid, total: total, left: left,
                             toGo: scheduled ? Double(left) * p.premium : 0,
                             nextDays: nextDays, nextIndex: scheduled && left > 0 ? paid + 1 : 0,
                             lifeFrom: hasLife ? start : "", lifeTo: hasLife ? end : "",
                             todayAt: hasLife ? at(today) : nil,
                             payEndAt: hasLife && scheduled && !payEnd.isEmpty && payEnd < end ? at(payEnd) : nil,
                             ran: hasLife && start <= today ? InsDay.span(start, today) : nil,
                             toRun: hasLife && end > today ? InsDay.span(today, end) : nil,
                             putIn: putIn, back: back, years: years)
    }
}
