import SwiftUI

// MARK: - Each property's year: its property tax (paid, part paid, due, or no receipt yet) and its rent, month by month
//
// All of it is worked out in the build (engine/20c-build-property-tax.js places each municipal payment on its
// property; engine/21h-build-rent-forecast.js keeps each property's twelve months of rent): these views only say it.

/// a property's tax for the year, in words
enum TaxYearWords {
    /// "FY 26–27" from "2026-27"
    static func fy(_ s: String) -> String {
        let y: Int = Int(s.prefix(4)) ?? 0
        return String(format: "FY %02d–%02d", y % 100, (y + 1) % 100)
    }
    /// "26–27", for a column
    static func fyShort(_ s: String) -> String { String(fy(s).dropFirst(3)) }

    /// this year's tax in a few words, its ink and its symbol
    static func status(_ n: TaxNow) -> (title: String, ink: Color, sym: String) {
        switch n.st {
        case "paid": return ("Paid for " + fy(n.fy), RentInk.goodDeep, "checkmark.circle.fill")
        case "part": return ("Part paid for " + fy(n.fy), TaxInk.amber, "circle.lefthalf.filled")
        case "due": return (Fmt.rupees(n.due) + " due", TaxInk.amber, "exclamationmark.circle.fill")
        default: return ("No receipt yet for " + fy(n.fy), RentInk.grey, "questionmark.circle")
        }
    }

    /// the line under it: how it's known paid, or what's paid and the day that matters next
    static func line(_ n: TaxNow) -> String {
        if n.st == "paid" {
            switch n.src {
            case "portal": return n.read.isEmpty ? "The portal showed nothing due" : "The portal showed nothing due on " + Day.fmt(n.read, "d MMM yyyy")
            case "marked": return "You marked it paid"
            default:
                if n.last.isEmpty { return "" }
                let more: String = n.n > 1 ? " · " + String(n.n) + " payments this year" : ""
                return Fmt.rupees(n.lastAmt) + " paid on " + Day.fmt(n.last, "d MMM yyyy") + more
            }
        }
        var bits: [String] = []
        if n.st == "part" {
            bits.append(Fmt.rupees(n.paid) + " paid" + (n.expect > 0 ? " of about " + Fmt.rupees(n.expect) : ""))
        } else if n.st == "open" && n.expect > 0 {
            bits.append("About " + Fmt.rupees(n.expect) + (n.from == "last year" ? ", as paid last year" : " for the year"))
        }
        if !n.next.isEmpty { bits.append(next(n)) }
        return bits.joined(separator: " · ")
    }

    /// the day that matters while it isn't paid: the city's rebate, the portal's last day, or the year's end
    static func next(_ n: TaxNow) -> String {
        let d: String = Day.fmt(n.next, "d MMM yyyy")
        switch n.kind {
        case "rebate": return "Usually " + n.note + " by " + d
        case "portal": return "Payable without a penalty till " + d
        default: return "Due by " + d
        }
    }
}

/// on a property's tax card: this year's status, the years paid, and the receipts found
struct TaxYearBlock: View {
    let p: Prop
    @State private var receipts = false

    /// what VoiceOver says of the years: each one's figure, or that nothing was found
    static func spoken(_ years: [TaxYear]) -> String {
        let each: [String] = years.map { (y: TaxYear) -> String in
            let v: String = y.paid > 0 ? Fmt.rupees(y.paid) : "nothing found"
            return TaxYearWords.fy(y.fy) + " " + v
        }
        return "Paid each year: " + each.joined(separator: ", ")
    }

    var body: some View {
        if let n = p.taxNow {
            let s: (title: String, ink: Color, sym: String) = TaxYearWords.status(n)
            let line: String = TaxYearWords.line(n)
            let years: [TaxYear] = p.taxYears ?? []
            let pays: [PropPay] = p.taxPays ?? []
            let found: String = pays.count == 1 ? "1 payment found" : String(pays.count) + " payments found"
            VStack(alignment: .leading, spacing: 12) {
                HStack(alignment: .top, spacing: 10) {
                    Image(systemName: s.sym).font(.system(.subheadline, weight: .semibold)).foregroundStyle(s.ink).padding(.top, 1)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(s.title).font(.system(.subheadline, weight: .semibold)).foregroundStyle(s.ink)
                        if !line.isEmpty {
                            Text(line).font(.system(.caption)).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true).privacySensitive()
                        }
                    }
                    Spacer(minLength: 0)
                }
                if years.count > 1 || years.contains(where: { $0.paid > 0 }) {
                    HStack(spacing: 6) {
                        ForEach(years) { y in
                            let now: Bool = y.fy == n.fy
                            VStack(spacing: 2) {
                                Text(y.paid > 0 ? Fmt.short(y.paid) : "—")
                                    .font(.system(.caption, design: .rounded, weight: .semibold)).monospacedDigit()
                                    .foregroundStyle(y.paid > 0 ? Color.primary : TaxInk.faint)
                                    .lineLimit(1).minimumScaleFactor(0.7)
                                Text(TaxYearWords.fyShort(y.fy))
                                    .font(.system(.caption2, weight: now ? Font.Weight.semibold : Font.Weight.regular))
                                    .foregroundStyle(now ? Color.primary : TaxInk.faint)
                            }
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 7)
                            .background(y.paid > 0 ? RentInk.good.opacity(0.12) : RentInk.paper, in: RoundedRectangle(cornerRadius: 10, style: .continuous))
                        }
                    }
                    .privacySensitive()
                    .accessibilityElement(children: .ignore)
                    .accessibilityLabel(Self.spoken(years))
                }
                if !pays.isEmpty {
                    Button {
                        withAnimation(Fold.motion(opening: !receipts)) { receipts.toggle() }
                    } label: {
                        HStack(spacing: 6) {
                            Text(found)
                            Image(systemName: "chevron.down").font(.system(.caption2, weight: .bold)).foldTurn(receipts)
                        }
                        .font(.system(.footnote, weight: .semibold))
                        .foregroundStyle(Color.kosh)
                        .frame(minHeight: 30)
                    }
                    .buttonStyle(.press)
                    Unfold(open: receipts) {
                        PayRows(rows: pays)
                    }
                }
            }
        }
    }
}

/// payments on the ledger, one row each (its day, who it went to or came from, the amount); a tap opens it
struct PayRows: View {
    @Environment(Store.self) private var store
    let rows: [PropPay]
    var body: some View {
        VStack(spacing: 0) {
            ForEach(Array(rows.enumerated()), id: \.element.id) { i, r in
                if i > 0 { RowRule(inset: 0) }
                Button { store.sheet = .tx(r.id) } label: {
                    HStack(spacing: 10) {
                        Text(Day.fmt(r.d, "d MMM yyyy")).font(.system(.footnote)).foregroundStyle(.secondary).monospacedDigit()
                            .frame(width: 92, alignment: .leading)
                        Text(r.m.isEmpty ? "Payment" : r.m).font(.system(.footnote)).lineLimit(1)
                        Spacer(minLength: 6)
                        Text(Fmt.rupees(r.a)).font(.system(.footnote, design: .rounded, weight: .semibold)).monospacedDigit()
                        Image(systemName: "chevron.right").font(.system(.caption2, weight: .semibold)).foregroundStyle(.tertiary)
                    }
                    .padding(.vertical, 9)
                    .contentShape(Rectangle())
                }
                .buttonStyle(.press)
            }
        }
        .privacySensitive()
    }
}

/// payments kosh found but couldn't place: property tax that fits no property, or a credit called rent that no floor
/// took. Said, never guessed
struct LoosePays: View {
    let title: String
    let note: String
    let rows: [PropPay]
    var body: some View {
        if !rows.isEmpty {
            let first: String = rows.map(\.d).min() ?? ""
            let last: String = rows.map(\.d).max() ?? ""
            let span: String = first == last ? Day.fmt(first, "d MMM yyyy") : Day.fmt(first, "d MMM yy") + " – " + Day.fmt(last, "d MMM yy")
            let total: Double = rows.reduce(0) { $0 + $1.a }
            let count: String = rows.count == 1 ? "1 payment" : String(rows.count) + " payments"
            let sum: String = Fmt.rupees(total) + " in " + count + " · " + span
            VStack(alignment: .leading, spacing: 8) {
                VStack(alignment: .leading, spacing: 2) {
                    Text(title).font(.system(.subheadline, weight: .semibold))
                    Text(sum)
                        .font(.system(.caption)).foregroundStyle(.secondary).monospacedDigit().privacySensitive()
                    Text(note).font(.system(.caption)).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                }
                PayRows(rows: rows)
            }
            .padding(16)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.surface, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        }
    }
}

/// a month of rent, as a colour: in, part in, late, due this month, or nothing to collect
enum RentLogInk {
    static func fill(_ st: String) -> Color {
        switch st {
        case "in": return RentInk.lit
        case "part": return RentInk.due
        case "late": return RentInk.late
        case "due": return RentInk.due.opacity(0.5)
        default: return Color.rule.opacity(0.12)
        }
    }
    /// "Dec 2025 – Oct 2026"
    static func range(_ log: RentLog, short: Bool = false) -> String {
        let f: String = short ? "MMM yy" : "MMM yyyy"
        if log.from == log.to { return Day.fmt(log.from + "-01", f) }
        return Day.fmt(log.from + "-01", f) + " – " + Day.fmt(log.to + "-01", f)
    }
    /// "2 rents missed", "none missed"
    static func missed(_ n: Int) -> String { n == 0 ? "none missed" : (n == 1 ? "1 rent missed" : String(n) + " rents missed") }
}

/// under a building's tenants: its rent over the twelve months to this one, what was to come and what came
struct PropRentLog: View {
    let log: RentLog
    let cm: String
    @State private var grown = false
    @Environment(\.accessibilityReduceMotion) private var still

    var body: some View {
        let top: Double = max(1, log.months.map { max($0.exp, $0.got) }.max() ?? 1)
        let late: [RentLogMonth] = log.months.filter { $0.missed > 0 }
        let lateMonths: [String] = late.map { (x: RentLogMonth) -> String in Day.fmt(x.m + "-01", "MMM yy") }
        let lateLine: String = late.isEmpty ? "" : "Not received: " + lateMonths.joined(separator: ", ")
        let spoken: String = "Rent " + RentLogInk.range(log) + ": " + Fmt.rupees(log.received) + " received of " + Fmt.rupees(log.expected)
        let missed: String = log.missed == 0 ? "None" : (log.missed == 1 ? "1 rent" : String(log.missed) + " rents")
        VStack(alignment: .leading, spacing: 12) {
            VStack(alignment: .leading, spacing: 2) {
                Text("Rent, month by month").font(.system(.subheadline, weight: .semibold))
                Text(RentLogInk.range(log)).font(.system(.caption)).foregroundStyle(.secondary)
            }
            HStack(alignment: .bottom, spacing: 4) {
                ForEach(log.months) { x in
                    VStack(spacing: 4) {
                        bar(x, top: top)
                        Text(String(x.short.prefix(1)))
                            .font(.system(.caption2, weight: x.m == cm ? Font.Weight.bold : Font.Weight.regular))
                            .foregroundStyle(x.m == cm ? Color.primary : Color.secondary)
                    }
                    .frame(maxWidth: .infinity)
                }
            }
            .frame(height: 96, alignment: .bottom)
            .accessibilityElement(children: .ignore)
            .accessibilityLabel(spoken + ", " + RentLogInk.missed(log.missed))
            HStack(spacing: 8) {
                TenantTile(cap: "Received", value: Fmt.rupees(log.received), tone: RentInk.goodDeep, money: true)
                TenantTile(cap: "Expected", value: Fmt.rupees(log.expected), money: true)
                TenantTile(cap: "Missed", value: missed, tone: log.missed > 0 ? RentInk.lateDeep : RentInk.goodDeep)
            }
            if !lateLine.isEmpty {
                Text(lateLine).font(.system(.caption)).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            }
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.surface, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        .privacySensitive()
        .onAppear {
            if still { grown = true } else { withAnimation(Motion.reveal.delay(0.1)) { grown = true } }
        }
    }

    /// a month: its outline is what was to come in, its fill what came
    func bar(_ x: RentLogMonth, top: Double) -> some View {
        let room: CGFloat = 76
        let want: CGFloat = x.exp > 0 ? max(6, room * CGFloat(x.exp / top)) : 4
        let have: CGFloat = x.got > 0 ? max(4, room * CGFloat(x.got / top)) : 0
        let edge: Color = x.st == "none" ? Color.rule.opacity(0.18) : RentLogInk.fill(x.st).opacity(0.55)
        return ZStack(alignment: .bottom) {
            RoundedRectangle(cornerRadius: 4, style: .continuous)
                .strokeBorder(edge, lineWidth: 1)
                .frame(height: want)
            if have > 0 {
                RoundedRectangle(cornerRadius: 4, style: .continuous)
                    .fill(RentLogInk.fill(x.st))
                    .frame(height: grown ? have : 3)
            }
        }
        .frame(maxWidth: .infinity)
        .overlay(alignment: .bottom) {
            if x.m == cm {
                RoundedRectangle(cornerRadius: 6, style: .continuous).strokeBorder(Color.primary.opacity(0.45), lineWidth: 1.5)
                    .frame(height: max(want, have) + 6).padding(.horizontal, -2).offset(y: 3)
            }
        }
    }
}

/// on a property's card on the overview: its rent over the twelve months to this one, in a line; a tap goes to tenants
struct PropRentLine: View {
    @Environment(Store.self) private var store
    let log: RentLog
    var body: some View {
        Button {
            withAnimation(Motion.open) { store.propSub = .tenants }
        } label: {
            VStack(alignment: .leading, spacing: 8) {
                HStack(alignment: .firstTextBaseline, spacing: 6) {
                    Text("RENT · " + RentLogInk.range(log, short: true).uppercased())
                        .font(.system(.caption2, weight: .semibold)).tracking(0.7).foregroundStyle(.secondary).lineLimit(1)
                    Spacer(minLength: 6)
                    Text(RentLogInk.missed(log.missed)).font(.system(.caption, weight: .semibold))
                        .foregroundStyle(log.missed > 0 ? RentInk.lateDeep : RentInk.goodDeep)
                }
                HStack(spacing: 3) {
                    ForEach(log.months) { x in
                        RoundedRectangle(cornerRadius: 3, style: .continuous).fill(RentLogInk.fill(x.st)).frame(height: 8)
                    }
                }
                Text("\(Text(Fmt.rupees(log.received)).fontWeight(.semibold).foregroundStyle(Color.primary)) received of \(Fmt.rupees(log.expected))")
                    .font(.system(.footnote)).foregroundStyle(.secondary).monospacedDigit().lineLimit(1).minimumScaleFactor(0.8)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            .contentShape(Rectangle())
        }
        .buttonStyle(.press)
        .privacySensitive()
        .accessibilityElement(children: .combine)
        .accessibilityHint("Opens tenants and rent")
    }
}
