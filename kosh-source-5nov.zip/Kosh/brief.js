/* kosh brief: kosh telling you about your money before you ask — the Sunday digest (the week in one screen), the
   morning briefing (what changed since yesterday and one thing to do), and what each Regular mutual fund plan costs
   you in rupees against the Direct plan of the same fund.

   Arithmetic on the household's own ledger, done on the phone, like agent.js. It hangs off build() (E.postBuild),
   after agent.js, so the briefing can lead with what kosh noticed (snap.watch). It counts the way every other screen
   does: spending is the payments the months count (t.sp), money in is what was earned or came back (never a transfer
   from a person, never a refund tied to its payment, which nets off it), a card's bill is the card's spending paid,
   never spending again. A day is the day the money moved, even when you count it in another month (t.od). What's
   due is the calendar's own list (snap.agenda), which already makes one bill of the mails that tell the same bill.

   Every notification line comes twice: with the figures, and quiet (no amount, no name, no card digits) for the Lock
   Screen, which is what it says unless you ask for figures, and always while amounts are hidden or kosh is locked.

   Also here, so they can be tested off the phone: reading AMFI's fee lists (the phone fetches them, Brief.swift), and
   deciding which fund houses to ask again and how what comes back joins what kosh had.

   Loaded after plan.js; Swift reads snap.brief (Brief.swift). */

var KoshBrief = (function (E) {
  'use strict';
  var L = (E && E.lib) || {};
  var inr = L.inr || function (n) { return '₹' + Math.round(n); };

  /* ------------------------------------------------------------ small things */
  function r0(n) { return Math.round(+n || 0); }
  function sum(list, f) { var s = 0; for (var i = 0; i < list.length; i++) s += +(f ? f(list[i]) : list[i]) || 0; return s; }
  function amtOf(x) { return x.amt; }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function isDay(s) { return /^\d{4}-\d{2}-\d{2}$/.test(String(s || '')); }
  function dayOf(iso) { var p = String(iso || '').slice(0, 10).split('-'); return Date.UTC(+p[0], +p[1] - 1, +p[2]); }
  function addDays(iso, n) { var d = new Date(dayOf(iso) + n * 864e5); return d.getUTCFullYear() + '-' + pad(d.getUTCMonth() + 1) + '-' + pad(d.getUTCDate()); }
  function daysBetween(a, b) { return Math.round((dayOf(b) - dayOf(a)) / 864e5); }
  /** Monday 0 … Sunday 6 */
  function weekday(iso) { return (new Date(dayOf(iso)).getUTCDay() + 6) % 7; }
  var MON3 = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  var MONF = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  function dShort(iso) { return iso ? +iso.slice(8, 10) + ' ' + MON3[+iso.slice(5, 7) - 1] : ''; }
  /** "12–18 Oct", "27 Oct – 2 Nov", "29 Dec 2025 – 4 Jan 2026" */
  function span(from, to) {
    if (from.slice(0, 4) !== to.slice(0, 4)) return dShort(from) + ' ' + from.slice(0, 4) + ' – ' + dShort(to) + ' ' + to.slice(0, 4);
    if (from.slice(0, 7) !== to.slice(0, 7)) return dShort(from) + ' – ' + dShort(to);
    return +from.slice(8, 10) + '–' + dShort(to);
  }
  /** "one payment", "3 payments" */
  function plural(n, one, many) { return (n === 1 ? 'one' : String(n)) + ' ' + (n === 1 ? one : (many || one + 's')); }
  var NUMW = ['no', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten', 'eleven', 'twelve'];
  function words(n, one, many) { return (NUMW[n] || String(n)) + ' ' + (n === 1 ? one : (many || one + 's')); }
  function cap(s) { return s ? s.charAt(0).toUpperCase() + s.slice(1) : s; }
  /** "12:40" → "12:40 pm" */
  function clock(hm) { var p = String(hm).split(':'), h = +p[0]; return (h % 12 || 12) + ':' + p[1] + (h < 12 ? ' am' : ' pm'); }
  /** the day the money moved: a payment you count in another month keeps its own day in t.od */
  function whenOf(t) { return isDay(t.od) ? t.od : t.d; }

  /* ------------------------------------------------------------ what counts, the way every screen counts it */
  /** spending: what the months count (refunds already netted off their payments, a card's bill never counted twice) */
  function isSpend(t) { return !!t.sp && !t.mr && t.a > 0; }
  /** a refund that came back: a credit kosh tied to its payment, or one filed as a refund. A refund reduces what
      went out and is never money in: one tied to its payment already came off it (engine.js), one kosh couldn't
      tie comes off the week's spending here */
  function isRefund(t) { return t.k === 'in' && !t.mr && t.a > 0 && (!!t.refOf || t.c === 'Refund'); }
  // (engine.js marks one it couldn't tie: nt, the kind of spending it comes off, and nta, how much it took off there)
  function isLooseRefund(t) { return isRefund(t) && !t.refOf && (!t.ex || !!t.nt); }
  function looseBack(t) { return t.nt ? +t.nta || 0 : t.a; }
  /** money in that was earned: salary, interest, rent, dividends, cashback; never a person's transfer, never a refund */
  function isIncome(t) { return t.k === 'in' && t.c !== 'Transfer in' && !t.ex && !t.mr && t.a > 0 && !isRefund(t); }
  function isFromPeople(t) { return t.k === 'in' && t.c === 'Transfer in' && !t.ex && !t.mr && t.a > 0; }
  /** money put into investments (a credit filed under Investments is money back from them, not money put in) */
  function isInvest(t) { return t.k === 'invest' && t.dr !== 'in' && !t.ex && !t.mr && t.a > 0; }
  function isRedeem(t) { return t.k === 'invest' && t.dr === 'in' && !t.ex && !t.mr && t.a > 0; }
  function counted(t) { return isSpend(t) || isIncome(t) || isFromPeople(t) || isInvest(t) || isRedeem(t) || isLooseRefund(t); }

  /** the calendar's payments still to make between two days. The calendar has already made one bill of the mails
      that tell the same bill (one biller, one due day, one sum); two bills it shows are two here too. A day kosh
      learnt from your spending (no bill in the mail) is marked, to be said as a usual day, not a due date. */
  function dueBetween(agenda, from, to) {
    var out = [], ids = {};
    (agenda || []).forEach(function (a) {
      if (!a || a.kind !== 'out' || a.booked || !isDay(a.date) || a.date < from || a.date > to || !(a.amt > 0)) return;
      var d = { name: a.name || 'A payment', amt: r0(a.amt), date: a.date, cat: a.cat || '', sym: a.sym || 'calendar', sub: a.sub || '' };
      if (a.learnt) d.learnt = true;
      out.push(d);
    });
    out.sort(function (a, b) { return a.date.localeCompare(b.date) || b.amt - a.amt; });
    out.forEach(function (d) {
      var id = d.date + '|' + d.name + '|' + d.amt, k = id, n = 1;
      while (ids[k]) k = id + '|' + (++n);
      ids[k] = 1; d.id = k;
    });
    return out;
  }
  /** a payment due, in words with nothing of yours in it ("A card bill") */
  function dueWhat(d) {
    if (d.cat === 'Card Payments') return 'a card bill';
    if (d.cat === 'Insurance') return 'a premium';
    if (d.cat === 'committee') return 'a committee instalment';
    if (d.cat === 'Tax') return 'a tax payment';
    if (/\bemi\b|\bloan\b/i.test(d.name + ' ' + d.sub)) return 'an EMI';
    if (/\bsip\b/i.test(d.name + ' ' + d.sub)) return 'an SIP';
    return 'a payment';
  }

  /* ------------------------------------------------------------ what kosh noticed, quietly */
  /** what a heads-up is about, with no amount, name or digits in it: for the Lock Screen */
  function quietThing(f) {
    var t = String(f.title || '');
    switch (f.kind) {
      case 'fee': return /late|interest|finance/i.test(t + ' ' + (f.detail || '')) ? 'a late fee or interest on a card' : 'a fee on a card';
      case 'dup': return 'the same charge twice';
      case 'unusual': return /a first/i.test(t) ? 'a first payment somewhere new' : 'a payment much bigger than usual';
      case 'pricerise': return 'a repeat payment that went up';
      case 'newsub': return 'a new payment every month';
      case 'due': return 'a payment due soon';
      case 'short': return 'more due this week than in your accounts';
      case 'maturity': return 'a deposit about to mature';
      case 'renewal': return /past due|lapsed/i.test(t) ? 'a premium past its due date' : 'a premium due soon';
      case 'rent': return 'rent that hasn’t come in';
      case 'refund': return 'a refund still to come back';
      case 'pace': return 'spending ahead of the month’s budget';
      case 'idle': return 'more in savings than you need there';
      case 'stopped': return /\bsip\b/i.test(t) ? 'an SIP that didn’t go this month' : 'an EMI that didn’t go this month';
      case 'salary': return /hasn/i.test(t) ? 'a salary that hasn’t come yet' : 'a salary different from usual';
      default: return 'something that needs a look';
    }
  }
  /** a heads-up about a day still to come (a bill due, a deposit maturing, a premium due): its date is that day */
  function aboutDay(f) { return f.kind === 'due' || f.kind === 'maturity' || /^ren\|/.test(String(f.id || '')); }
  /** a heads-up that is the same news as a payment the briefing already says (a bill due, a premium due) */
  function sameAsDue(f, d) {
    if (f.date !== d.date) return false;
    if (f.kind === 'due') return f.id === 'due|' + d.name + '|' + d.date || (+f.amt > 0 && Math.abs(+f.amt - d.amt) <= 1);
    if (/^ren\|/.test(String(f.id || ''))) return d.cat === 'Insurance';
    return false;
  }
  /** what kosh noticed, most pressing first, as the briefing for `day` takes them: none that is a payment it already
      says; for a morning after the one kosh built on (tomorrow's, made today), none about a day already gone, and a
      "due today" said of its own day. Within one level of pressing, the days still to come go earliest first (kosh's
      list puts the latest first). */
  function things(watch, due, day, today) {
    var list = (watch || []).filter(function (f) {
      if (!f || !f.id || !f.title) return false;
      if ((due || []).some(function (d) { return sameAsDue(f, d); })) return false;
      if (day !== today && aboutDay(f) && isDay(f.date) && f.date < day) return false;
      return true;
    }).map(function (f) {
      var title = String(f.title).replace(/\.$/, '');
      if (day !== today && f.kind === 'due' && isDay(f.date)) {
        if (f.date !== day) title = title.replace(/\bdue today\b/, 'due ' + dShort(f.date));
        else title = title.replace(new RegExp('\\bdue ' + dShort(f.date) + '$'), 'due today');
      }
      return { id: f.id, kind: f.kind || '', sev: +f.sev || 1, title: title, detail: f.detail || '', sym: f.sym || 'sparkles', date: isDay(f.date) ? f.date : '',
               line: 'kosh noticed: ' + title + '.', quiet: 'kosh noticed ' + quietThing(f) + '.' };
    });
    for (var i = 0; i < list.length;) {
      var j = i, at = [];
      while (j < list.length && list[j].sev === list[i].sev) { if (aboutDay(list[j]) && list[j].date) at.push(j); j++; }
      var sorted = at.map(function (k) { return list[k]; }).sort(function (a, b) { return a.date.localeCompare(b.date); });
      at.forEach(function (k, n) { list[k] = sorted[n]; });
      i = j;
    }
    return list.slice(0, 6);
  }

  /* ================================================================ the morning briefing
     What changed since yesterday and what today and tomorrow ask of you, for the morning of `day`: what's due on the
     day and the next, yesterday's payments and what came in (a salary, a refund), and what kosh noticed, for the one
     thing to do (the phone picks it: the first you haven't snoozed or done, and not one already rung). `news` says
     whether there's anything apart from what kosh noticed; `worth`, whether there's anything at all. `at`: the time
     of the build ("12:40"), for tomorrow's briefing made today, whose yesterday is only partly over. */
  function briefing(snap, day, at) {
    if (!isDay(day)) return null;
    var yday = addDays(day, -1);
    var tx = (snap.tx || []).filter(function (t) { return t && whenOf(t) === yday; });
    var refunds = tx.filter(isRefund), spend = tx.filter(isSpend), income = tx.filter(isIncome);
    var top = spend.slice().sort(function (a, b) { return b.a - a.a; })[0] || null;
    var salary = income.filter(function (t) { return t.c === 'Salary'; });
    var out = { n: spend.length, amt: r0(sum(spend, function (t) { return t.a; })), top: top ? { id: top.id, m: top.m || '', a: r0(top.a), sym: top.sym || '' } : null };
    var inn = { n: income.length, amt: r0(sum(income, function (t) { return t.a; })),
                salary: salary.length ? { amt: r0(sum(salary, function (t) { return t.a; })), from: salary[0].m || '' } : null,
                refunds: refunds.map(function (t) { return { id: t.id, m: t.m || '', a: r0(t.a) }; }) };
    var due = dueBetween(snap.agenda, day, addDays(day, 1)).map(function (d) { d.when = d.date === day ? 'today' : 'tomorrow'; return d; });
    var th = things(snap.watch, due, day, snap.today);
    var b = { day: day, yday: yday, out: out, inn: inn, due: due, things: th };
    // read before the day ended: what came after isn't in it yet (a build late in the evening counts as the day)
    if (yday === snap.today && /^(?:[01]\d|2[0-3]):[0-5]\d$/.test(String(at || '')) && at < '23:00') b.upto = at;
    b.news = out.n > 0 || inn.n > 0 || inn.refunds.length > 0 || due.length > 0;
    b.worth = b.news || th.length > 0;
    var lines = morningLines(b);
    b.lines = lines.loud; b.qlines = lines.quiet; b.lead = lines.lead;
    return b;
  }

  /** the briefing in sentences, with figures and without, what's due first (`lead` lines of it, which a notification
      always keeps); the one thing to do is added after them by whoever picks it */
  function morningLines(b) {
    var loud = [], quiet = [];
    function both(l, q) { loud.push(l); quiet.push(q); }
    ['today', 'tomorrow'].forEach(function (when) {
      var ds = b.due.filter(function (d) { return d.when === when; });
      var firm = ds.filter(function (d) { return !d.learnt; }), usual = ds.filter(function (d) { return d.learnt; });
      if (firm.length === 1) both('Due ' + when + ': ' + firm[0].name + ', ' + inr(firm[0].amt) + '.', cap(dueWhat(firm[0])) + ' is due ' + when + '.');
      else if (firm.length > 1) both('Due ' + when + ': ' + firm.length + ' payments, ' + inr(sum(firm, amtOf)) + '.', cap(words(firm.length, 'payment')) + ' are due ' + when + '.');
      // a day learnt from your spending: when it usually goes, not a due date
      if (usual.length === 1) both(usual[0].name + ' usually goes out around ' + when + ': ' + inr(usual[0].amt) + '.', 'A regular payment usually goes out around ' + when + '.');
      else if (usual.length > 1) both(cap(words(usual.length, 'regular payment')) + ' usually go out around ' + when + ': ' + inr(sum(usual, amtOf)) + '.', cap(words(usual.length, 'regular payment')) + ' usually go out around ' + when + '.');
    });
    var lead = loud.length;
    var o = b.out, i = b.inn;
    if (o.n || i.n) {
      var head = b.upto ? 'Yesterday till ' + clock(b.upto) + ': ' : 'Yesterday: ';
      var l = head, q = head;
      if (o.n) { l += inr(o.amt) + ' out' + (i.n ? '' : o.n === 1 ? ' in one payment' : ' across ' + o.n + ' payments'); q += plural(o.n, 'payment') + ' out'; }
      if (i.n) { l += (o.n ? ', ' : '') + inr(i.amt) + ' in'; q += (o.n ? ', ' : '') + (o.n ? (i.n === 1 ? 'one' : String(i.n)) + ' in' : plural(i.n, 'payment') + ' in'); }
      both(l + '.', q + '.');
    }
    if (i.salary) both('Salary landed: ' + inr(i.salary.amt) + '.', 'Your salary landed.');
    if (i.refunds.length) {
      var rs = i.refunds;
      both(rs.length === 1 ? inr(rs[0].a) + ' came back from ' + (rs[0].m || 'a refund') + '.' : inr(sum(rs, function (r) { return r.a; })) + ' came back in ' + rs.length + ' refunds.',
           rs.length === 1 ? 'A refund came back.' : cap(words(rs.length, 'refund')) + ' came back.');
    }
    return { loud: loud, quiet: quiet, lead: lead };
  }

  /* ================================================================ the Sunday digest
     The last complete Monday–Sunday week (on a Sunday, this week: today is its last day, so far): money in and out,
     the three biggest moves, the category that grew most against its usual week, what's due in the seven days from
     today, and what kosh noticed in it. Net worth is the phone's (Store.netWorth, with cash and today's loans), so
     the digest and Home never show two figures for it. */
  function digestWeek(today) {
    var wd = weekday(today);
    var to = wd === 6 ? today : addDays(today, -(wd + 1));
    return { from: addDays(to, -6), to: to, partial: to === today };
  }

  /** the category that grew most this week against its usual week (the weeks before it, up to eight, when kosh has
      at least four): at least a third more, and ₹500 more */
  function grewMost(tx, w, cats) {
    var all = (tx || []).filter(function (t) { return t && isDay(whenOf(t)); });
    if (!all.length) return null;
    var first = all.reduce(function (m, t) { return whenOf(t) < m ? whenOf(t) : m; }, whenOf(all[0]));
    var weeks = Math.min(8, Math.floor(daysBetween(first, w.from) / 7));
    if (weeks < 4) return null;
    var start = addDays(w.from, -7 * weeks), now = {}, before = {};
    all.forEach(function (t) {
      if (!isSpend(t)) return;
      var c = t.c || 'Miscellaneous', d = whenOf(t);
      if (d >= w.from && d <= w.to) now[c] = (now[c] || 0) + t.a;
      else if (d >= start && d < w.from) before[c] = (before[c] || 0) + t.a;
    });
    var best = null;
    Object.keys(now).forEach(function (c) {
      var usual = (before[c] || 0) / weeks, more = now[c] - usual;
      if (now[c] < usual * 4 / 3 || more < 500) return;
      if (!best || more > best.more) best = { cat: c, week: r0(now[c]), usual: r0(usual), more: r0(more) };
    });
    if (!best) return null;
    var ci = (cats || {})[best.cat] || {};
    best.sym = ci.symbol || 'square.grid.2x2.fill'; best.color = ci.color || '#8E8E93';
    return best;
  }

  function digest(snap) {
    var today = snap.today;
    if (!isDay(today)) return null;
    var w = digestWeek(today);
    var tx = (snap.tx || []).filter(function (t) { var d = t && whenOf(t); return d && d >= w.from && d <= w.to && !t.mr; });
    var spend = tx.filter(isSpend), income = tx.filter(isIncome), people = tx.filter(isFromPeople), inv = tx.filter(isInvest), back = tx.filter(isRedeem);
    var moving = tx.filter(counted);
    // a refund kosh couldn't tie to its payment comes off the week's spending (never below nothing)
    var spent = sum(spend, function (t) { return t.a; }), refunded = Math.min(spent, sum(tx.filter(isLooseRefund), looseBack));
    var moves = moving.slice().sort(function (a, b) { return b.a - a.a || String(whenOf(b)).localeCompare(String(whenOf(a))); }).slice(0, 3).map(function (t) {
      var kind = isInvest(t) ? 'invest' : isRedeem(t) ? 'redeem' : isLooseRefund(t) ? 'back' : t.k === 'in' ? (isFromPeople(t) ? 'people' : 'in') : 'out';
      return { id: t.id, d: whenOf(t), m: t.m || '', a: r0(t.a), dir: t.k === 'in' || kind === 'redeem' ? 'in' : 'out', kind: kind, c: t.c || '', sym: t.sym || '' };
    });
    // the seven days from today: on a Sunday, a bill due that day is in that day's digest
    var dueFrom = today, dueTo = addDays(today, 6);
    var due = dueBetween(snap.agenda, dueFrom, dueTo);
    var noticed = (snap.watch || []).filter(function (f) { return f && f.title && !aboutDay(f) && isDay(f.date) && f.date >= w.from && f.date <= w.to; })
      .sort(function (a, b) { return (+b.sev || 1) - (+a.sev || 1); }).slice(0, 4)
      .map(function (f) { return { id: f.id, kind: f.kind || '', sev: +f.sev || 1, title: f.title, detail: f.detail || '', sym: f.sym || 'sparkles' }; });
    var d = {
      from: w.from, to: w.to, label: span(w.from, w.to), partial: w.partial,
      out: r0(spent - refunded), outN: spend.length, refunded: r0(refunded),
      inn: r0(sum(income, function (t) { return t.a; })), innN: income.length,
      people: r0(sum(people, function (t) { return t.a; })), invest: r0(sum(inv, function (t) { return t.a; })), redeemed: r0(sum(back, function (t) { return t.a; })),
      moves: moves, grew: grewMost(snap.tx, w, snap.cats),
      dueFrom: dueFrom, dueTo: dueTo, due: due, dueTotal: r0(sum(due, amtOf)),
      noticed: noticed, quiet: moving.length === 0,
      // money that moved but isn't spending or income (a card's bill, a move between your accounts, a payment you left out)
      other: tx.length - moving.length,
    };
    var lines = sundayLines(d);
    d.title = 'Your week, ' + d.label;
    d.lines = lines.loud; d.qlines = lines.quiet;
    return d;
  }

  function sundayLines(d) {
    var loud = [], quiet = [];
    if (d.quiet) {
      var s = d.other ? 'A quiet week: nothing kosh counts as spent or earned.' : 'A quiet week: kosh saw no money move.';
      loud.push(s); quiet.push(s);
    } else {
      var l = [], q = [], out = d.outN > 0 && d.out >= 1;
      if (out) { l.push(inr(d.out) + ' out'); q.push(plural(d.outN, 'payment') + ' out'); }
      if (d.innN) { l.push(inr(d.inn) + ' in'); q.push(out ? (d.innN === 1 ? 'one' : String(d.innN)) + ' in' : plural(d.innN, 'payment') + ' in'); }
      // nothing spent or earned: what went into investments and came back from them
      if (!l.length && d.invest) { l.push(inr(d.invest) + ' invested'); q.push('money invested'); }
      if (!out && !d.innN && d.redeemed) { l.push(inr(d.redeemed) + ' back from investments'); q.push('money back from investments'); }
      if (!l.length && d.people) { l.push(inr(d.people) + ' from people'); q.push('money from people'); }
      if (l.length) { loud.push(cap(l.join(', ')) + '.'); quiet.push(cap(q.join(', ')) + '.'); }
      else if (d.outN && d.refunded) { loud.push('What went out came back as refunds.'); quiet.push('What went out came back as refunds.'); }
    }
    // which category, only with the figures: on the Lock Screen it would say what you spent on
    if (d.grew) { loud.push(d.grew.cat + ' was higher than usual.'); quiet.push('One category ran higher than usual.'); }
    if (d.due.length) {
      loud.push('Next 7 days: ' + plural(d.due.length, 'payment') + ' due, ' + inr(d.dueTotal) + '.');
      quiet.push('Next 7 days: ' + plural(d.due.length, 'payment') + ' due.');
    }
    return { loud: loud, quiet: quiet };
  }

  /* ================================================================ fund fees, in rupees
     A Regular plan pays a distributor's commission out of the fund every year; the Direct plan of the same fund
     doesn't. What that costs is the gap between the two plans' total expense ratios (AMFI publishes both, every
     scheme, every day: the phone fetches them, FundFees in Brief.swift, and hands them over as prof.brief.ter), on what
     the plan is worth today: a year's extra fee, and what it comes to over ten years if the money stays (the gap
     compounds: what the fund would grow to at the Direct plan's cost, less at the Regular's, at a stated yearly return
     before costs for its kind of fund). A fund whose fees AMFI's list doesn't give for certain is said so, never guessed. */
  var GROWTH = { equity: 12, index: 12, hybrid: 10, debt: 7, arbitrage: 7, other: 9 };
  /* the plan and option words said after a fund's own name ("- Regular Plan - Growth Option", "Reg Gr", "IDCW
     Payout"). Only the run of them at the end is the plan: "Example Regular Savings Fund" keeps its "Regular".
     Brief.swift (FundFees.tailWords) reads with the same list; engine-test/brief.js checks they agree. */
  var TAIL_WORDS = ['regular', 'reg', 'rg', 'direct', 'dir', 'plan', 'plans', 'option', 'options', 'opt', 'growth', 'gr', 'idcw', 'dividend', 'div',
    'payout', 'reinvestment', 'reinvest', 'bonus', 'cumulative', 'accumulation', 'daily', 'weekly', 'fortnightly', 'monthly', 'quarterly', 'halfyearly',
    'annual', 'yearly', 'sweep', 'transfer', 'of', 'the'];
  var TAIL = {};
  TAIL_WORDS.forEach(function (w) { TAIL[w] = 1; });
  /** a fund's name in words, its own name apart from the plan and option after it */
  function nameWords(name) {
    var s = String(name || '').toLowerCase();
    // a plan said in brackets ("(Regular Plan)") is the plan; anything else in brackets (an old name) isn't the fund's
    s = s.replace(/\(([^()]*)\)/g, function (m, inner) {
      var w = inner.replace(/[^a-z0-9]+/g, ' ').trim().split(' ');
      return w[0] && w.every(function (x) { return TAIL[x]; }) ? ' ' + inner + ' ' : ' ';
    });
    s = s.replace(/\b(?:formerly(?: known as)?|erstwhile)\b.*$/, ' ').replace(/&/g, ' and ').replace(/['’`]/g, '')
      .replace(/\bincome\s+distribution\s+(?:cum|and)\s+capital\s+withdrawal\b/g, ' idcw ').replace(/\bhalf[\s-]*yearly\b/g, ' halfyearly ')
      .replace(/\bre[\s-]*investment\b/g, ' reinvestment ').replace(/\bpay[\s-]*out\b/g, ' payout ');
    var base = s.split(/[^a-z0-9]+/).filter(Boolean), tail = [];
    while (base.length && TAIL[base[base.length - 1]]) tail.unshift(base.pop());
    return { base: base, tail: tail };
  }
  /** a fund's own name as one key, without its plan and option ("Example Flexi Cap Fund - Regular Plan - Growth",
      "EXAMPLE FLEXI CAP FUND" and "Example Flexi Cap Reg Gr" are one fund) */
  function fundKey(name) {
    var w = nameWords(name).base;
    if (w.length > 1 && (w[w.length - 1] === 'fund' || w[w.length - 1] === 'scheme')) w = w.slice(0, -1);
    var k = w.join('');
    return k.length >= 4 && /[a-z]{3}/.test(k) ? k : '';
  }
  /** a Regular plan by its name: its plan words say Regular, and not Direct ("Example Regular Savings Fund - Growth"
      names no plan) */
  function isRegular(name) {
    var t = nameWords(name).tail;
    return t.some(function (w) { return w === 'regular' || w === 'reg' || w === 'rg'; }) && !t.some(function (w) { return w === 'direct' || w === 'dir'; });
  }
  /** a scheme's name as AMFI writes it from day to day (spacing and case aside) */
  function light(s) { return String(s || '').toLowerCase().replace(/[^a-z0-9]+/g, ''); }
  /** which kind of fund, for the growth the ten-year figure assumes: AMFI's category first, then the name (a debt
      index fund is debt; gold, silver and the like are "other") */
  function fundKind(name, cat) {
    var n = ' ' + String(name || '').toLowerCase().replace(/&/g, ' and ').replace(/[^a-z0-9]+/g, ' ') + ' ', c = String(cat || '').toLowerCase();
    if (/\barbitrage\b/.test(n) || /\barbitrage\b/.test(c)) return 'arbitrage';
    if (/^\s*debt\b/.test(c)) return 'debt';
    if (/^\s*hybrid\b/.test(c)) return 'hybrid';
    if (/^\s*equity\b/.test(c)) return 'equity';
    if (/ (?:hybrid|balanced|asset allocation|equity savings|multi asset|dynamic asset) /.test(n)) return 'hybrid';
    if (/ (?:sdl|gilt|g ?sec|bonds?|debt|liquid|overnight|money market|treasury|floater|floating rate|credit risk|banking and psu|duration|short term|ultra short|crisil ibx|ibx|target maturity|fixed maturity|fmp|income fund|savings fund) /.test(n)) return 'debt';
    if (/ (?:gold|silver|commodity|commodities) /.test(n) || /\b(?:gold|silver)\b/.test(c)) return 'other';
    if (/ (?:index|etf|nifty|sensex|next 50|bse) /.test(n) || /\b(?:index|etfs?)\b/.test(c)) return 'index';
    if (/ (?:equity|elss|tax saver|flexi ?cap|large|mid|small|multi ?cap|focused|value|contra|thematic|sectoral|bluechip|opportunities|dividend yield|infrastructure|pharma|technology|banking) /.test(n)) return 'equity';
    return 'other';
  }
  /** the fund houses a household's Regular plans are with, as AMFI numbers them ([{mfId, mfName}] from AMFI's list):
      the phone asks AMFI for those houses' fee lists only */
  var HOUSE_ALIAS = [[/^parag parikh/, 'ppfas'], [/^(?:idfc)\b/, 'bandhan'], [/^(?:absl|aditya birla)/, 'aditya birla sun life'], [/^(?:iifl|360 one)/, '360 one'],
    [/^franklin/, 'franklin templeton'], [/^kotak/, 'kotak mahindra'], [/^invesco/, 'invesco'], [/^lic\b/, 'lic'], [/^(?:bnp|baroda)/, 'baroda bnp paribas'],
    [/^(?:jm)\b/, 'jm financial'], [/^(?:mahindra)/, 'mahindra manulife'], [/^(?:pgim)/, 'pgim india'], [/^(?:icici)/, 'icici prudential'], [/^(?:nippon|reliance)/, 'nippon india']];
  function houseKey(s) { return String(s || '').toLowerCase().replace(/\bmutual fund\b|\bmf\b|\basset management\b|\bamc\b|\blimited\b|\bltd\b|\bco\b|[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim(); }
  function feesHouses(names, list) {
    var houses = (list || []).map(function (h) { return { id: String(h.mfId || h.MF_ID || h.id || ''), key: houseKey(h.mfName || h.name || '') }; })
      .filter(function (h) { return h.id && h.key; }).sort(function (a, b) { return b.key.length - a.key.length; });
    var out = [];
    (names || []).forEach(function (n) {
      if (!isRegular(n)) return;
      var low = String(n || '').toLowerCase().trim();
      HOUSE_ALIAS.forEach(function (a) { if (a[0].test(low)) low = a[1] + low.replace(a[0], ''); });
      var h = houses.filter(function (x) { return low.indexOf(x.key + ' ') === 0 || low === x.key; })[0];
      if (h && out.indexOf(h.id) < 0) out.push(h.id);
    });
    return out;
  }
  function fees(snap, prof) {
    var ter = ((prof || {}).brief || {}).ter || null;
    var rows = ter && Array.isArray(ter.rows) ? ter.rows : [];
    // each scheme's latest fees, under its fund's key and its own name (AMFI lists a scheme day by day)
    var byKey = {};
    rows.forEach(function (r) {
      if (!r || !r.s || !(+r.r >= 0) || !(+r.d >= 0) || +r.r > 5 || +r.d > 5) return;
      var k = fundKey(r.s);
      if (!k) return;
      var g = byKey[k] || (byKey[k] = {}), nm = light(r.s);
      if (!g[nm] || String(r.on || '') > String(g[nm].on || '')) g[nm] = r;
    });
    /* the fees for a fund's name: none in the list; two schemes of different fees under one name (no match at all);
       no Direct plan to compare (AMFI prints an ETF's Direct fee as 0) */
    function lookup(name) {
      var g = byKey[fundKey(name)];
      if (!g) return { why: 'none' };
      var all = Object.keys(g).map(function (k) { return g[k]; });
      if (all.some(function (r) { return +r.r !== +all[0].r || +r.d !== +all[0].d; })) return { why: 'two' };
      var r = all.reduce(function (a, b) { return String(b.on || '') > String(a.on || '') ? b : a; });
      return +r.d > 0 ? { r: r } : { why: 'nodirect' };
    }
    // one row a plan and a person, however many folios it's in
    var plans = {}, order = [];
    (snap.hold || []).forEach(function (h) {
      if (!h || h.cls !== 'mf' || !isRegular(h.bank) || !(h.amt > 0)) return;
      var id = (h.person || '') + '|' + (fundKey(h.bank) || light(h.bank));
      if (!plans[id]) { plans[id] = { id: id, name: h.bank, amt: 0, person: h.person || '', isin: h.isin || '' }; order.push(id); }
      plans[id].amt += +h.amt;
    });
    if (!order.length) return null;
    var known = [], unknown = [];
    order.forEach(function (id) {
      var h = plans[id], found = ter ? lookup(h.name) : { why: 'list' };
      if (!found.r) { unknown.push({ id: id, name: h.name, amt: r0(h.amt), person: h.person, why: found.why }); return; }
      var r = found.r, rr = +r.r, dd = +r.d, gap = Math.round((rr - dd) * 100) / 100;
      var kind = fundKind(h.name, r.cat), g = GROWTH[kind] / 100;
      var year = gap > 0 ? h.amt * gap / 100 : 0;
      var ten = gap > 0 ? h.amt * (Math.pow(1 + g - dd / 100, 10) - Math.pow(1 + g - rr / 100, 10)) : 0;
      known.push({ id: id, name: h.name, amt: r0(h.amt), person: h.person, isin: h.isin, r: rr, d: dd, gap: gap, year: r0(year), ten: r0(ten),
                   kind: kind, growth: GROWTH[kind], on: isDay(r.on) ? r.on : '' });
    });
    known.sort(function (a, b) { return b.year - a.year; });
    var days = known.map(function (k) { return k.on; }).filter(isDay).sort();
    var onTo = days[days.length - 1] || '';
    return { asOf: onTo ? MONF[+onTo.slice(5, 7) - 1] + ' ' + onTo.slice(0, 4) : String((ter && ter.month) || '').replace(/-/g, ' '), at: (ter && ter.at) || '',
             onFrom: days[0] || '', onTo: onTo, rows: known, unknown: unknown,
             year: r0(sum(known, function (k) { return k.year; })), ten: r0(sum(known, function (k) { return k.ten; })), fetched: !!ter };
  }

  /* ------------------------------------------------------------ AMFI's answers, read
     AMFI's site answers with JSON through the API its own TER page uses: the fund houses (/api/populate-mf), the
     months a financial year has fees for (/api/populate-ter-month) and a house's fees for a month, a page at a time
     (/api/populate-te-rdata-revised). Read here tolerantly: field names in any case and spelling the site has used,
     fees as numbers or text ("1.62", "1.62%", "NA"), dates in any of the forms .NET and Excel write them, months put in
     order here rather than trusted. Something that isn't an answer at all (an error page) is a failure, null; an
     answer with nothing in it is nothing yet. */
  function parseJSON(text) { if (text && typeof text === 'object') return text; try { return JSON.parse(String(text)); } catch (e) { return undefined; } }
  function normKey(k) { return String(k).toLowerCase().replace(/[^a-z0-9]/g, ''); }
  /** the first of these fields an object has (names compared without case or underscores) */
  function pick(o, names) {
    if (!o || typeof o !== 'object') return undefined;
    var map = {};
    Object.keys(o).forEach(function (k) { if (o[k] !== null && o[k] !== undefined && o[k] !== '' && map[normKey(k)] === undefined) map[normKey(k)] = o[k]; });
    for (var i = 0; i < names.length; i++) { var v = map[normKey(names[i])]; if (v !== undefined) return v; }
    return undefined;
  }
  function listOf(o) {
    if (Array.isArray(o)) return o;
    var v = pick(o, ['data', 'result', 'rows', 'items', 'records', 'list', 'value']);
    return Array.isArray(v) ? v : null;
  }
  function toInt(v) { var n = parseInt(String(v === undefined ? '' : v).replace(/[^\d]/g, ''), 10); return n > 0 ? n : 0; }
  /** a fee, percent a year: null when there's none to read */
  function pct(v) {
    if (typeof v === 'number') return isFinite(v) ? v : null;
    var s = String(v === undefined || v === null ? '' : v).replace(/[%,\s]/g, '');
    if (!/^-?\d*\.?\d+$/.test(s)) return null;
    return parseFloat(s);
  }
  var MONTHS = { jan: 1, feb: 2, mar: 3, apr: 4, may: 5, jun: 6, jul: 7, aug: 8, sep: 9, sept: 9, oct: 10, nov: 11, dec: 12 };
  /** "sep", "sept", "september" → 9 */
  function monNum(w) {
    w = String(w || '').toLowerCase();
    if (MONTHS[w]) return MONTHS[w];
    var n = MONTHS[w.slice(0, 3)];
    return n && MONF[n - 1].toLowerCase().indexOf(w) === 0 ? n : 0;
  }
  function ymd(y, m, d) {
    if (!(y >= 2000 && y <= 2100 && m >= 1 && m <= 12 && d >= 1 && d <= 31)) return '';
    var s = y + '-' + pad(m) + '-' + pad(d);
    return addDays(s, 0) === s ? s : '';
  }
  /** India's day for a moment in milliseconds */
  function istDay(ms) { var t = new Date(ms + 5.5 * 3600e3); return ymd(t.getUTCFullYear(), t.getUTCMonth() + 1, t.getUTCDate()); }
  /** a date AMFI wrote, as yyyy-mm-dd: "2026-09-30", "2026-09-30T00:00:00", "30-09-2026", "30/09/2026",
      "30-Sep-2026", "30 September 2026", "Sep 30 2026 12:00AM", "/Date(1790726400000)/", or a number of milliseconds */
  function dateOf(v) {
    if (typeof v === 'number') return v > 1e11 ? istDay(v) : v > 1e9 ? istDay(v * 1000) : '';
    var s = String(v === undefined || v === null ? '' : v).trim(), m;
    if ((m = /^\/Date\((-?\d+)(?:[+-]\d{4})?\)\/$/.exec(s))) return istDay(+m[1]);
    if ((m = /^(\d{4})[-\/.](\d{1,2})[-\/.](\d{1,2})(?:$|[T\s])/.exec(s))) return ymd(+m[1], +m[2], +m[3]);
    if ((m = /^(\d{1,2})[-\/.](\d{1,2})[-\/.](\d{4})(?:$|\s)/.exec(s))) return ymd(+m[3], +m[2], +m[1]);
    if ((m = /^(\d{1,2})[-\/.\s]+([a-z]+)[-\/.,\s]+(\d{4})(?:$|\s)/i.exec(s)) && monNum(m[2])) return ymd(+m[3], monNum(m[2]), +m[1]);
    if ((m = /^([a-z]+)[-\/.\s]+(\d{1,2}),?[-\/.\s]+(\d{4})(?:$|\s)/i.exec(s)) && monNum(m[1])) return ymd(+m[3], monNum(m[1]), +m[2]);
    return '';
  }
  /** a month AMFI named ("09-2026", "2026-09", "September-2026", "Sep 2026"), as yyyy-mm */
  function monthKey(v) {
    var s = String(v === undefined || v === null ? '' : v).trim(), m;
    if ((m = /^(\d{1,2})[-\/.\s](\d{4})$/.exec(s))) return ymd(+m[2], +m[1], 1).slice(0, 7);
    if ((m = /^(\d{4})[-\/.\s]?(\d{2})$/.exec(s))) return ymd(+m[1], +m[2], 1).slice(0, 7);
    if ((m = /^([a-z]+)[-\/.,\s]+(\d{4})$/i.exec(s)) && monNum(m[1])) return ymd(+m[2], monNum(m[1]), 1).slice(0, 7);
    return '';
  }
  /** AMFI's fund houses: [{id, name}], without "All" or "Select" */
  function terHouses(text) {
    var list = listOf(parseJSON(text));
    if (!list) return null;
    var out = [], seen = {};
    list.forEach(function (x) {
      var id = String(pick(x, ['mfId', 'MF_ID', 'mfid', 'id', 'value']) === undefined ? '' : pick(x, ['mfId', 'MF_ID', 'mfid', 'id', 'value'])).trim();
      var name = String(pick(x, ['mfName', 'MF_Name', 'mfname', 'name', 'text', 'label']) || '').replace(/\s+/g, ' ').trim();
      if (!/^\d+$/.test(id) || !name || /^(?:all|select)\b/i.test(name) || seen[id]) return;
      seen[id] = 1;
      out.push({ id: id, name: name });
    });
    return out;
  }
  /** the months a year has fees for, newest first (by kosh's own sort), none still to come: [{value, name, key}].
      `value` is what to ask for that month with, as AMFI gave it */
  function terMonths(text, today) {
    var list = listOf(parseJSON(text));
    if (!list) return null;
    var by = {};
    list.forEach(function (x) {
      var value = String(pick(x, ['MonthNumber', 'monthNo', 'value', 'month', 'id']) === undefined ? '' : pick(x, ['MonthNumber', 'monthNo', 'value', 'month', 'id'])).trim();
      var name = String(pick(x, ['MonthYear', 'MonthName', 'text', 'name', 'label']) || '').trim();
      var key = monthKey(value) || monthKey(name);
      if (!key || !value || (isDay(today) && key > today.slice(0, 7)) || by[key]) return;
      by[key] = { value: value, name: name || value, key: key };
    });
    return Object.keys(by).sort().reverse().map(function (k) { return by[k]; });
  }
  /** one page of a house's fees for a month: each scheme's latest day on the page, and how many pages there are (0:
      not said; ask the next page while one comes back full) */
  function terPage(house, text) {
    var o = parseJSON(text), list = listOf(o);
    if (!list) return null;
    var meta = !Array.isArray(o) ? (pick(o, ['meta', 'pagination', 'paging']) || o) : {};
    var pages = toInt(pick(meta, ['pageCount', 'totalPages', 'pages', 'lastPage']));
    if (!pages) {
      var total = toInt(pick(meta, ['total', 'totalCount', 'totalRecords', 'recordCount', 'count'])), size = toInt(pick(meta, ['pageSize', 'perPage', 'limit']));
      if (total && size) pages = Math.ceil(total / size);
    }
    var latest = {};
    list.forEach(function (x) {
      if (!x || typeof x !== 'object') return;
      var s = String(pick(x, ['Scheme_Name', 'SchemeName', 'Scheme', 'NameOfScheme']) || '').replace(/\s+/g, ' ').trim();
      var r = pct(pick(x, ['R_TER', 'RTER', 'RegularTER', 'TER_Regular', 'RegularPlanTotalTER', 'TotalTERRegular']));
      var d = pct(pick(x, ['D_TER', 'DTER', 'DirectTER', 'TER_Direct', 'DirectPlanTotalTER', 'TotalTERDirect']));
      var on = dateOf(pick(x, ['TER_Date', 'TERDate', 'Date', 'AsOnDate', 'TER_DT']));
      var cat = String(pick(x, ['SchemeCat_Desc', 'SchemeCategory', 'Scheme_Category', 'Category', 'SchemeCat']) || '').replace(/\s+/g, ' ').trim();
      // a fee outside 0–5% a year is a misprint, not a fee
      if (!s || r === null || d === null || r < 0 || r > 5 || d < 0 || d > 5 || !on) return;
      var k = s.toLowerCase();
      if (latest[k] && latest[k].on >= on) return;
      latest[k] = { mf: String(house), s: s, cat: cat, r: r, d: d, on: on };
    });
    return { rows: Object.keys(latest).sort().map(function (k) { return latest[k]; }), pages: pages, n: list.length };
  }

  /* ------------------------------------------------------------ asking AMFI again
     state: what the phone keeps (fees.json): rows, and per house the day its fees last came (seen) and when asking
     last failed (miss, seconds), and the houses whose list was longer than kosh reads at once (cut). A fees file from
     before (houses and the day, at) reads as each of those houses seen that day. */
  function seenOf(state) {
    if (state && state.seen) return state.seen;
    var s = {};
    ((state || {}).houses || []).forEach(function (h) { if (isDay(state.at)) s[String(h)] = state.at; });
    return s;
  }
  /** the houses to ask now: one never asked, or whose fees came a week ago; one whose ask failed waits an hour */
  function terDue(state, ids, today, now) {
    var seen = seenOf(state || {}), miss = (state || {}).miss || {};
    return (ids || []).map(String).filter(function (id) {
      if (+miss[id] > 0 && now - miss[id] < 3600) return false;
      return !isDay(seen[id]) || !isDay(today) || daysBetween(seen[id], today) >= 7;
    });
  }
  /** what came back joined to what kosh had. got: [{id, status: 'rows' | 'none' | 'fail', rows, cut}]. A house
      whose list came replaces its fees (a list cut short at kosh's page limit only adds to them, never counting as
      the whole list); a house AMFI had nothing for yet, or whose ask failed, keeps what it had. */
  function terMerge(state, got, today, now) {
    state = state || {};
    var rows = (state.rows || []).slice(), seen = {}, miss = {}, cut = {};
    var s0 = seenOf(state);
    Object.keys(s0).forEach(function (k) { seen[k] = s0[k]; });
    Object.keys(state.miss || {}).forEach(function (k) { miss[k] = state.miss[k]; });
    (Array.isArray(state.cut) ? state.cut : []).forEach(function (k) { cut[k] = true; });
    var at = state.at || '', month = state.month || '';
    (got || []).forEach(function (g) {
      var id = String(g.id);
      if (g.status === 'fail') { miss[id] = now; return; }
      delete miss[id];
      seen[id] = today; at = today;
      if (g.status !== 'rows' || !(g.rows || []).length) return;
      var fresh = g.rows.filter(function (r) { return r && r.s; }).map(function (r) { return { mf: id, s: String(r.s), cat: String(r.cat || ''), r: +r.r, d: +r.d, on: String(r.on || '') }; });
      var names = {};
      fresh.forEach(function (r) { names[light(r.s)] = 1; });
      rows = rows.filter(function (r) { return String(r.mf) !== id || (g.cut && !names[light(r.s)]); }).concat(fresh);
      if (g.cut) cut[id] = true; else delete cut[id];
      fresh.forEach(function (r) { if (isDay(r.on) && r.on.slice(0, 7) > month) month = r.on.slice(0, 7); });
    });
    return { rows: rows, seen: seen, miss: miss, cut: Object.keys(cut).sort(), at: at, month: month };
  }

  /* ================================================================ everything this module adds to the snapshot */
  function build(snap, prof) {
    snap = snap || {};
    var today = snap.today;
    if (!isDay(today)) return {};
    var at = String((((prof || {}).brief) || {}).now || '');
    var out = {
      // this morning's (Home shows it all day), and tomorrow morning's, from what's in now (the notification rings
      // before the next build, if there is none)
      daily: briefing(snap, today),
      next: briefing(snap, addDays(today, 1), at),
      digest: digest(snap),
    };
    var f = fees(snap, prof);
    if (f) out.fees = f;
    return out;
  }

  var api = {
    build: build, briefing: briefing, digest: digest, digestWeek: digestWeek, fees: fees, fundKey: fundKey, isRegular: isRegular, feesHouses: feesHouses, quietThing: quietThing,
    tailWords: TAIL_WORDS.slice(), terHouses: terHouses, terMonths: terMonths, terPage: terPage, terDue: terDue, terMerge: terMerge, dateOf: dateOf,
    /** the fund houses to ask AMFI about: names of the household's funds, AMFI's list of houses → [mfId] */
    briefFeesHousesJSON: function (names, list) { var o = []; try { o = feesHouses(JSON.parse(names || '[]'), JSON.parse(list || '[]')); } catch (e) { o = []; } return JSON.stringify(o); },
    /** AMFI's answers read (null when it isn't one): houses → [{id, name}]; months → [{value, name, key}]; a page → {rows, pages, n} */
    briefTerHousesJSON: function (text) { return JSON.stringify(terHouses(text)); },
    briefTerMonthsJSON: function (text, today) { return JSON.stringify(terMonths(text, today)); },
    briefTerPageJSON: function (house, text) { return JSON.stringify(terPage(house, text)); },
    /** which houses to ask now, and what came back joined to what kosh had (FundFees.refresh) */
    briefTerDueJSON: function (state, ids, today, now) { var o = []; try { o = terDue(JSON.parse(state || '{}'), JSON.parse(ids || '[]'), today, +now); } catch (e) { o = []; } return JSON.stringify(o); },
    briefTerMergeJSON: function (state, got, today, now) { var o = null; try { o = terMerge(JSON.parse(state || '{}'), JSON.parse(got || '[]'), today, +now); } catch (e) { o = null; } return JSON.stringify(o); },
  };
  if (E) for (var k in api) if (Object.prototype.hasOwnProperty.call(api, k) && /JSON$/.test(k)) E[k] = api[k];
  if (E && E.postBuild) E.postBuild.push(function (snap, prof) { snap.brief = build(snap, prof || {}); });
  return api;
})(typeof KoshEngine !== 'undefined' ? KoshEngine : require('./engine.js'));
if (typeof module !== 'undefined' && module.exports) module.exports = KoshBrief;
