import SwiftUI

// MARK: - Chapters' postcards: visa pages
//
// The ideas (and your own chapters, first) as a stage over the caption, turning every 2.6 s; a finger on it holds
// it still, a swipe turns it, a tap on the one in front starts that kind of chapter (or opens yours), a tap on a
// neighbour brings it to the front. An open passport page; each idea a visa sticker (its scene as the photo, its
// kind, an MRZ line, a holographic sheen); the next one peeks in at the edge, the stamp lands on the corner of the
// one in front. Drawn on a 390 × 300 stage and scaled to the room the page has. Reduce Motion: no sheen, no thump;
// the cards still change. VoiceOver: one element, swiped up or down to turn. (The Clothesline look was retired on
// 17 Oct 2026.)

struct ChapterStage: View {
    let ideas: [ChapterIdea]
    /// the stage's height on the page (the caption goes under it); nil: whatever the page leaves it
    var height: CGFloat? = nil
    let start: (ChapterIdea) -> Void
    var open: ((String) -> Void)? = nil

    @Environment(Store.self) private var store
    @Environment(\.accessibilityReduceMotion) private var still
    @Environment(\.accessibilityVoiceOverEnabled) private var voiceOver
    @Environment(\.tabActive) private var tabActive
    /// turns so far: never wrapped, so the cards always move the same way
    @State private var step = 0
    @State private var holding = false
    @State private var deleting: ChapterIdea?

    static let dwell: Double = 2.6
    static let design = CGSize(width: 390, height: 300)
    static let words: CGFloat = 50
    /// the least the stage is drawn at, when the page leaves it the room
    static let least: CGFloat = 190

    var body: some View {
        let n: Int = max(1, ideas.count)
        let cur: Int = ((step % n) + n) % n
        let idea: ChapterIdea = ideas[min(cur, ideas.count - 1)]
        let label: String = Self.label(idea)
        let hint: String = Self.hint(idea)
        content(cur, idea)
            .task(id: holding || voiceOver || !tabActive) { await tick() }
            .sensoryFeedback(.selection, trigger: step) { _, _ in holding || voiceOver }
            .accessibilityElement(children: .ignore)
            .accessibilityLabel(label)
            .accessibilityHint(hint)
            .accessibilityAddTraits(.isButton)
            .accessibilityAction { tap(idea) }
            .accessibilityAdjustableAction { d in turn(d) }
            .modifier(DeleteAsk(deleting: $deleting))
    }

    /// the stage, scaled to its room, and the caption under it
    func content(_ cur: Int, _ idea: ChapterIdea) -> some View {
        let motion: Animation = still ? Motion.base : Motion.reveal
        return VStack(spacing: 8) {
            GeometryReader { g in
                let k: CGFloat = min(1.1, g.size.width / Self.design.width, g.size.height / Self.design.height)
                stage(cur)
                    .frame(width: Self.design.width, height: Self.design.height)
                    .scaleEffect(k)
                    .frame(width: g.size.width, height: g.size.height)
            }
            .frame(minHeight: height ?? Self.least, maxHeight: height ?? .infinity)
            .contentShape(Rectangle())
            .simultaneousGesture(swipe)
            StageCaption(idea: idea, still: still)
                .frame(height: Self.words - 8)
                .contentShape(Rectangle())
                .onTapGesture { tap(idea) }
        }
        .animation(motion, value: step)
    }

    /// on to the next every couple of seconds, while nobody's holding it and VoiceOver isn't turning it
    func tick() async {
        // held, read aloud, or behind another tab: the postcards stay where they are
        guard !holding && !voiceOver && tabActive else { return }
        while !Task.isCancelled {
            // the opening spread is read, not glanced at: it stays a little longer
            let n: Int = max(1, ideas.count)
            let here: ChapterIdea = ideas[((step % n) + n) % n]
            // the book is read, not glanced at; a chapter of yours waits long enough to be caught and opened
            try? await Task.sleep(for: .seconds(Self.dwell * (here.isCover ? 2.2 : here.chapterID != nil ? 1.8 : 1)))
            if Task.isCancelled { break }
            step += 1
        }
    }
    func turn(_ d: AccessibilityAdjustmentDirection) {
        switch d {
        case .increment: step += 1
        case .decrement: step -= 1
        @unknown default: break
        }
    }
    static func label(_ i: ChapterIdea) -> String {
        let lead: String = i.chapterID != nil ? "Your chapter: " : "Idea: "
        return lead + i.line + " " + Words.cap(i.note) + "."
    }
    static func hint(_ i: ChapterIdea) -> String {
        if i.isCover { return "Turns to your chapters and ideas." }
        return i.chapterID != nil ? "Opens this chapter. Swipe up or down for others." : "Starts a chapter like this. Swipe up or down for other ideas."
    }

    @ViewBuilder func stage(_ cur: Int) -> some View {
        VisaStage(ideas: ideas, cur: cur, still: still, card: card, next: { go(1) })
    }

    /// a card as a button: the one in front starts (or opens), a neighbour comes to the front; yours can go
    func card(_ i: Int, _ d: Int, _ face: AnyView) -> AnyView {
        let it: ChapterIdea = ideas[i]
        return AnyView(
            Button { d == 0 ? tap(it) : go(d) } label: { face }
                .buttonStyle(PulsePress())
                .contextMenu {
                    if let id = it.chapterID {
                        Button { open?(id) } label: { Label("Open", systemImage: "book") }
                        Button(role: .destructive) { deleting = it } label: { Label("Delete chapter", systemImage: "trash") }
                    }
                }
        )
    }

    func tap(_ i: ChapterIdea) {
        if i.isCover { go(1); return }
        if let id = i.chapterID, let open { open(id) } else { start(i) }
    }
    func go(_ by: Int) { step += by }

    var swipe: some Gesture {
        DragGesture(minimumDistance: 18)
            .onChanged { _ in if !holding { holding = true } }
            .onEnded { v in
                if v.translation.width < -40 { step += 1 } else if v.translation.width > 40 { step -= 1 }
                holding = false
            }
    }

    /// where a card sits from the one in front: −n/2 … n/2
    static func offset(_ i: Int, _ cur: Int, _ n: Int) -> Int {
        let half: Int = n / 2
        return ((i - cur + half) % n + n) % n - half
    }
}

/// "Delete Goa?": one of your chapters, asked to go from its postcard
struct DeleteAsk: ViewModifier {
    @Binding var deleting: ChapterIdea?
    @Environment(Store.self) private var store
    func body(content: Content) -> some View {
        let title: String = deleting.map { "Delete " + $0.line + "?" } ?? ""
        let shown = Binding<Bool>(get: { deleting != nil }, set: { if !$0 { deleting = nil } })
        content.confirmationDialog(title, isPresented: shown, titleVisibility: .visible) {
            Button("Delete", role: .destructive) {
                if let id = deleting?.chapterID { withAnimation(Motion.open) { store.deleteTrip(id) } }
                deleting = nil
            }
        } message: {
            Text("Its payments stay where they are, back to ordinary spending.")
        }
    }
}

/// the big line and the small one under it, blurring into the next
struct StageCaption: View {
    let idea: ChapterIdea
    let still: Bool
    var body: some View {
        ZStack {
            VStack(spacing: 3) {
                Text(idea.line)
                    .font(.system(size: 21, weight: .semibold, design: .serif))
                    .tracking(-0.2)
                    .foregroundStyle(NotebookInk.text)
                Text(idea.note)
                    .font(.system(size: 10.5, weight: .semibold).smallCaps())
                    .tracking(0.8)
                    .foregroundStyle(NotebookInk.soft)
            }
            .lineLimit(1)
            .minimumScaleFactor(0.7)
            .multilineTextAlignment(.center)
            .id(idea.id)
            .transition(still ? AnyTransition.opacity : AnyTransition(.blurReplace(.upUp)))
        }
        .frame(maxWidth: .infinity)
        .padding(.horizontal, 20)
    }
}

// MARK: - The stamp, landing

/// a stamp at rest, or landing: it comes down large and turned, settles with a bounce, and a ring of ink spreads
/// out from it. It lands each time its card comes to the front.
struct ThumpStamp: View {
    let art: StampArt
    let size: CGFloat
    var rotation: Double = -12
    let on: Bool
    let still: Bool

    struct Pose { var s: CGFloat = 1; var r: Double = 0; var o: Double = 0.9; var ring: CGFloat = 1.25; var ringO: Double = 0 }

    var body: some View {
        let live: Bool = on && !still
        ZStack {
            StampView(art: art, size: size, rotation: 0)
                .environment(\.colorScheme, .light)
                .blendMode(.multiply)
        }
        .frame(width: size, height: size)
        .keyframeAnimator(initialValue: Pose(), trigger: on) { c, p in
            c.scaleEffect(p.s)
                .rotationEffect(.degrees(rotation + p.r))
                .opacity(p.o)
                .background {
                    Circle().strokeBorder(art.ink, lineWidth: 2)
                        .scaleEffect(p.ring * 0.7)
                        .opacity(p.ringO)
                }
        } keyframes: { _ in
            // landing: it waits a beat for its card to arrive, comes down at 1.7× and turned, and settles
            let wait: Double = live ? 0.3 : 0.001
            let fall: Double = live ? 0.45 : 0.001
            let big: CGFloat = live ? 1.7 : 1
            let turned: Double = live ? -14 : 0
            let unseen: Double = live ? 0 : 0.9
            let ink: Double = live ? 0.35 : 0
            KeyframeTrack(\.s) {
                MoveKeyframe(big)
                LinearKeyframe(big, duration: wait)
                SpringKeyframe(CGFloat(1), duration: fall, spring: Motion.popSpring)
            }
            KeyframeTrack(\.r) {
                MoveKeyframe(turned)
                LinearKeyframe(turned, duration: wait)
                SpringKeyframe(0.0, duration: fall)
            }
            KeyframeTrack(\.o) {
                MoveKeyframe(unseen)
                LinearKeyframe(unseen, duration: wait)
                LinearKeyframe(0.9, duration: live ? 0.2 : 0.001)
            }
            KeyframeTrack(\.ring) {
                MoveKeyframe(CGFloat(0.6))
                LinearKeyframe(CGFloat(0.6), duration: wait)
                LinearKeyframe(CGFloat(1.25), duration: live ? 0.5 : 0.001)
            }
            KeyframeTrack(\.ringO) {
                MoveKeyframe(0.0)
                LinearKeyframe(0.0, duration: wait)
                MoveKeyframe(ink)
                LinearKeyframe(0.0, duration: live ? 0.5 : 0.001)
            }
        }
        .accessibilityHidden(true)
    }
}

/// the stage runs past its sides to the screen's edges (the neighbours peek in from there), never over the words above or under it
struct EdgeToEdge: ViewModifier {
    func body(content: Content) -> some View {
        content.mask { Rectangle().padding(.horizontal, -400) }
    }
}

// MARK: - Visa pages

struct VisaStage: View {
    let ideas: [ChapterIdea]
    let cur: Int
    let still: Bool
    let card: (Int, Int, AnyView) -> AnyView
    /// on to the first page after the book
    var next: () -> Void = {}

    static let navy = Color(hex: "#1E2A55")

    var body: some View {
        let n: Int = ideas.count
        let onCover: Bool = ideas[cur].isCover
        ZStack(alignment: .topLeading) {
            Ellipse().fill(Color(hex: ideas[cur].wash).opacity(0.12)).frame(width: 300, height: 176).blur(radius: 56)
                .position(x: 195, y: 150)
            if onCover {
                // the book open on its first spread: the line on the left, the title and its stickers on the right
                BookSpread(still: still)
                    .frame(width: 362, height: 274)
                    .contentShape(Rectangle())
                    .onTapGesture { next() }
                    .accessibilityAddTraits(.isButton)
                    .accessibilityHint("Turns to your chapters and ideas")
                    .offset(x: 14, y: 14)
                    .transition(.asymmetric(insertion: .opacity.combined(with: .scale(scale: 0.97)), removal: .opacity))
            } else {
                // the passport: its navy cover, and the page with its fine print
                RoundedRectangle(cornerRadius: 12, style: .continuous).fill(Self.navy)
                    .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).strokeBorder(Color.white.opacity(0.07), lineWidth: 1))
                    .shadow(color: .black.opacity(0.55), radius: 20, y: 18)
                    .frame(width: 362, height: 274)
                    .offset(x: 14, y: 14)
                VisaPage()
                    .frame(width: 350, height: 262)
                    .offset(x: 20, y: 20)
            }
            ForEach(0..<n, id: \.self) { i in
                let d: Int = ChapterStage.offset(i, cur, n)
                if abs(d) <= 2 && !ideas[i].isCover && !(onCover && d < 0) {
                    sticker(i, d)
                }
            }
        }
        .frame(width: ChapterStage.design.width, height: ChapterStage.design.height, alignment: .topLeading)
        .modifier(EdgeToEdge())
    }

    func sticker(_ i: Int, _ d: Int) -> some View {
        let x: CGFloat
        let r: Double
        let s: CGFloat
        let o: Double
        switch d {
        case 0: x = 0; r = -1.5; s = 1; o = 1
        case 1: x = 304; r = 3; s = 0.9; o = 0.5
        case -1: x = -70; r = -5; s = 0.9; o = 0
        default: x = d > 0 ? 380 : -90; r = d > 0 ? 4 : -6; s = 0.86; o = 0
        }
        let face: AnyView = AnyView(VisaSticker(idea: ideas[i], front: d == 0, still: still))
        let layer: Double = Double(10 - abs(d)) + (d == 1 ? 0.5 : 0)
        let left: CGFloat = 45 + x
        return card(i, d, face)
            .scaleEffect(s)
            .rotationEffect(.degrees(r))
            .opacity(o)
            .offset(x: left, y: 64)
            .zIndex(layer)
            .allowsHitTesting(d == 0 || d == 1)
    }
}

/// a passport page: cream paper, a fold shadow at the spine, guilloche lines, its heading and number
struct VisaPage: View {
    var body: some View {
        ZStack(alignment: .top) {
            Color(hex: "#EFE7D5")
            Canvas { ctx, size in
                let ink: Color = Color(hex: "#1E2A55").opacity(0.05)
                var x: CGFloat = -size.height
                while x < size.width {
                    var p = Path()
                    p.move(to: CGPoint(x: x, y: size.height))
                    p.addLine(to: CGPoint(x: x + size.height * 0.58, y: 0))
                    ctx.stroke(p, with: .color(ink), lineWidth: 0.8)
                    x += 7
                }
                let c = CGPoint(x: size.width / 2, y: -size.height * 0.3)
                var r: CGFloat = 40
                while r < size.height * 1.6 {
                    ctx.stroke(Path(ellipseIn: CGRect(x: c.x - r, y: c.y - r, width: 2 * r, height: 2 * r)), with: .color(ink), lineWidth: 0.6)
                    r += 6
                }
            }
            LinearGradient(colors: [Color(hex: "#463214").opacity(0.24), .clear], startPoint: .leading, endPoint: UnitPoint(x: 0.07, y: 0.5))
            Text("VISAS · वीज़ा")
                .font(.system(size: 7, weight: .semibold)).tracking(1.4)
                .foregroundStyle(Color(hex: "#1E2A55").opacity(0.42))
                .padding(.top, 12)
            Text("15")
                .font(.system(size: 9, weight: .medium, design: .serif))
                .foregroundStyle(Color(hex: "#1E2A55").opacity(0.45))
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottomTrailing)
                .padding(.trailing, 14).padding(.bottom, 8)
        }
        .clipShape(RoundedRectangle(cornerRadius: 4, style: .continuous))
        .accessibilityHidden(true)
    }
}

/// one idea as a visa: its wash with fine print, the header, the scene as the photo, its fields, the MRZ line,
/// a holographic sheen, and the stamp pressed over the corner
struct VisaSticker: View {
    let idea: ChapterIdea
    let front: Bool
    let still: Bool

    static let size = CGSize(width: 300, height: 182)

    /// "V<CHAPTER<<WEDDING<<<<…", 36 characters
    static func mrz(_ kind: String) -> String {
        let k: String = kind.uppercased().map { $0.isLetter ? String($0) : "<" }.joined()
        let line: String = "V<CHAPTER<<" + k
        return line.count >= 36 ? String(line.prefix(36)) : line + String(repeating: "<", count: 36 - line.count)
    }

    var body: some View {
        let ink: Color = idea.stamp?.ink ?? Color(hex: "#3F3F46")
        let shape = RoundedRectangle(cornerRadius: 10, style: .continuous)
        ZStack(alignment: .topLeading) {
            Color(hex: idea.wash)
            VisaFinePrint(ink: ink)
            VisaHeader(script: idea.stamp?.script ?? "", ink: ink)
            VisaPhoto(idea: idea, front: front)
                .offset(x: 12, y: 34)
            VisaFields(kind: idea.kind, from: idea.from, spent: idea.spent)
                .offset(x: 122, y: 36)
            Text(Self.mrz(idea.kind))
                .font(.system(size: 10.5, weight: .semibold, design: .monospaced)).tracking(0.5)
                .foregroundStyle(Color(hex: "#2A2A30"))
                .lineLimit(1)
                .padding(.horizontal, 12)
                .frame(width: Self.size.width, height: 30, alignment: .leading)
                .background(Color.white.opacity(0.6))
                .overlay(alignment: .top) { Rectangle().fill(Color.black.opacity(0.06)).frame(height: 1) }
                .offset(y: Self.size.height - 30)
            if front && !still { Sheen() }
        }
        .frame(width: Self.size.width, height: Self.size.height)
        .clipShape(shape)
        .overlay(shape.strokeBorder(Color.black.opacity(0.08), lineWidth: 1))
        .shadow(color: .black.opacity(0.35), radius: 12, y: 10)
        .overlay(alignment: .bottomTrailing) {
            if let art = idea.stamp {
                ThumpStamp(art: art, size: 88, rotation: -14, on: front, still: still)
                    .offset(x: 26, y: 30)
            }
        }
        .environment(\.colorScheme, .light)
    }
}

struct VisaFinePrint: View {
    let ink: Color
    var body: some View {
        Canvas { ctx, size in
            var x: CGFloat = -size.height
            while x < size.width {
                var p = Path()
                p.move(to: CGPoint(x: x, y: size.height))
                p.addLine(to: CGPoint(x: x + size.height * 0.7, y: 0))
                ctx.stroke(p, with: .color(ink.opacity(0.1)), lineWidth: 0.5)
                x += 6
            }
        }
        .accessibilityHidden(true)
    }
}

struct VisaHeader: View {
    let script: String
    let ink: Color
    var body: some View {
        HStack {
            Text("VISA · CHAPTER").font(.system(size: 8, weight: .bold)).tracking(1.6)
            Spacer()
            Text(script).font(.system(size: 10, weight: .bold))
        }
        .foregroundStyle(ink)
        .padding(.horizontal, 12)
        .frame(width: VisaSticker.size.width, height: 24)
        .overlay(alignment: .bottom) { Rectangle().fill(Color.black.opacity(0.1)).frame(height: 1) }
    }
}

struct VisaPhoto: View {
    let idea: ChapterIdea
    let front: Bool
    var body: some View {
        ZStack {
            Color(hex: idea.wash)
            NotebookScene(layers: NotebookScenes.layers(idea.scene), live: front, tint: idea.tint)
                .scaleEffect(1.75)
        }
        .frame(width: 90, height: 94)
        .clipped()
        .padding(3)
        .background(Color.white, in: RoundedRectangle(cornerRadius: 3))
        .shadow(color: .black.opacity(0.18), radius: 1.5, y: 1)
    }
}

struct VisaFields: View {
    let kind: String
    /// one of yours: its first day and what it came to; an idea's are blanks to fill
    var from: String = ""
    var spent: String = ""
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            field("KIND", kind.uppercased(), dash: false)
            field("FROM", from.isEmpty ? "— — / — —" : from, dash: from.isEmpty)
            if spent.isEmpty { field("BUDGET", "₹ — — — —", dash: true) } else { field("SPENT", spent, dash: false) }
        }
    }
    func field(_ label: String, _ value: String, dash: Bool) -> some View {
        VStack(alignment: .leading, spacing: 3) {
            Text(label).font(.system(size: 7, weight: .bold)).tracking(1.1).foregroundStyle(Color(hex: "#14141E").opacity(0.5))
            Text(value).font(.system(size: 12, weight: .semibold, design: .monospaced)).tracking(dash ? 1.4 : 0.5)
                .foregroundStyle(dash ? Color(hex: "#14141E").opacity(0.38) : Color(hex: "#1C1C22"))
                .lineLimit(1)
        }
    }
}

/// a holographic band sweeping across the visa
struct Sheen: View {
    /// off while its tab is behind another (kosh keeps visited tabs alive): its animation rests
    @Environment(\.tabActive) private var tabActive
    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 30, paused: !tabActive)) { tl in
            let p: Double = (tl.date.timeIntervalSinceReferenceDate / 3).truncatingRemainder(dividingBy: 1)
            GeometryReader { g in
                LinearGradient(stops: [
                    .init(color: .clear, location: 0.3), .init(color: Color(hex: "#78C8FF").opacity(0.26), location: 0.4),
                    .init(color: Color(hex: "#FF96DC").opacity(0.26), location: 0.47), .init(color: Color(hex: "#96FFC8").opacity(0.26), location: 0.54),
                    .init(color: Color.white.opacity(0.55), location: 0.58), .init(color: .clear, location: 0.66),
                ], startPoint: .leading, endPoint: .trailing)
                .frame(width: g.size.width * 2.5)
                .rotationEffect(.degrees(-20))
                .offset(x: CGFloat(-1.6 + 1.7 * p) * g.size.width)
            }
        }
        .allowsHitTesting(false)
        .accessibilityHidden(true)
    }
}

// MARK: - The book, open on its first spread
//
// The passport's opening spread, before any visa: two cream pages on the navy cover, the page edges stacked at both
// sides and the fold's shadow down the middle. On the left, a line about the chapters of a life; on the right, the
// book's name and stickers from the kinds of chapter (a flight, the hills, a temple, a heart, a new home, a gift),
// stuck on at angles, with a strip of tape at a corner. The stickers settle on as it opens (not with Reduce Motion).

struct BookSpread: View {
    let still: Bool
    @State private var on = false

    static let paper = Color(hex: "#F4ECDB")
    static let ink = Color(hex: "#2B2A33")
    static let soft = Color(hex: "#7A6F5E")

    struct Sticker: Identifiable {
        let id: Int; let sym: String; let fill: String; let x: CGFloat; let y: CGFloat; let size: CGFloat; let turn: Double
    }
    static let stickers: [Sticker] = [
        Sticker(id: 0, sym: "airplane", fill: "#3B82F6", x: 34, y: 150, size: 40, turn: -10),
        Sticker(id: 1, sym: "mountain.2.fill", fill: "#22A06B", x: 88, y: 168, size: 36, turn: 7),
        Sticker(id: 2, sym: "building.columns.fill", fill: "#C2410C", x: 136, y: 142, size: 34, turn: -6),
        Sticker(id: 3, sym: "heart.fill", fill: "#E0457B", x: 50, y: 212, size: 32, turn: 9),
        Sticker(id: 4, sym: "house.fill", fill: "#A2845E", x: 102, y: 222, size: 34, turn: -4),
        Sticker(id: 5, sym: "gift.fill", fill: "#7C3AED", x: 146, y: 200, size: 30, turn: 12),
    ]

    var body: some View {
        ZStack {
            // the cover, a little bigger than the pages
            RoundedRectangle(cornerRadius: 12, style: .continuous).fill(VisaStage.navy)
                .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).strokeBorder(Color.white.opacity(0.07), lineWidth: 1))
                .shadow(color: .black.opacity(0.5), radius: 20, y: 18)
            HStack(spacing: 0) {
                page(left: true) { quote }
                page(left: false) { title }
            }
            .padding(.horizontal, 7)
            .padding(.vertical, 6)
        }
        .onAppear {
            if still { on = true } else { withAnimation(Motion.reveal.delay(0.15)) { on = true } }
        }
        .accessibilityHidden(true)
    }

    /// a page: paper, the other pages' edges on the outside, the fold's shadow on the inside
    func page<C: View>(left: Bool, @ViewBuilder _ content: () -> C) -> some View {
        ZStack {
            Self.paper
            LinearGradient(colors: [Color(hex: "#5A4220").opacity(0.22), .clear],
                           startPoint: left ? .trailing : .leading,
                           endPoint: left ? UnitPoint(x: 0.82, y: 0.5) : UnitPoint(x: 0.18, y: 0.5))
            HStack(spacing: 1.2) {
                ForEach(0..<3, id: \.self) { _ in Rectangle().fill(Color(hex: "#D9CDB4")).frame(width: 0.6) }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: left ? .leading : .trailing)
            .padding(.vertical, 2)
            content()
        }
        .clipShape(UnevenRoundedRectangle(topLeadingRadius: left ? 6 : 1, bottomLeadingRadius: left ? 6 : 1,
                                          bottomTrailingRadius: left ? 1 : 6, topTrailingRadius: left ? 1 : 6, style: .continuous))
    }

    var quote: some View {
        VStack(spacing: 10) {
            Text("CHAPTERS OF A LIFE")
                .font(.system(size: 7, weight: .semibold)).tracking(1.6)
                .foregroundStyle(Self.soft)
            Spacer(minLength: 0)
            Text("Some chapters you plan.\nSome find you.\nEach one deserves\na page of its own.")
                .font(.system(size: 15, weight: .regular, design: .serif).italic())
                .lineSpacing(3)
                .multilineTextAlignment(.center)
                .foregroundStyle(Self.ink)
                .minimumScaleFactor(0.8)
            HStack(spacing: 6) {
                Capsule().fill(Self.soft.opacity(0.5)).frame(width: 18, height: 1)
                Image(systemName: "sparkle").font(.system(size: 7, weight: .bold)).foregroundStyle(Color(hex: "#C2410C"))
                Capsule().fill(Self.soft.opacity(0.5)).frame(width: 18, height: 1)
            }
            Spacer(minLength: 0)
            Text("i").font(.system(size: 9, design: .serif)).foregroundStyle(Self.soft)
        }
        .padding(.vertical, 12)
        .padding(.horizontal, 14)
    }

    var title: some View {
        ZStack(alignment: .topLeading) {
            VStack(alignment: .leading, spacing: 0) {
                Text("THE BOOK OF").font(.system(size: 7, weight: .semibold)).tracking(1.6).foregroundStyle(Self.soft)
                Text("Adventures,").font(.system(size: 24, weight: .bold, design: .serif)).foregroundStyle(Self.ink)
                    .padding(.top, 3)
                Text("so far.").font(.system(size: 24, weight: .regular, design: .serif).italic()).foregroundStyle(Self.ink)
                Path { p in
                    p.move(to: CGPoint(x: 0, y: 4))
                    p.addCurve(to: CGPoint(x: 92, y: 3), control1: CGPoint(x: 30, y: 0), control2: CGPoint(x: 60, y: 8))
                }
                .stroke(Color(hex: "#C2410C"), style: StrokeStyle(lineWidth: 1.8, lineCap: .round))
                .frame(width: 92, height: 8)
                .padding(.top, 2)
                Spacer(minLength: 0)
                Text("ii").font(.system(size: 9, design: .serif)).foregroundStyle(Self.soft)
                    .frame(maxWidth: .infinity, alignment: .trailing)
            }
            .padding(.vertical, 12)
            .padding(.horizontal, 14)
            Rectangle().fill(Color(hex: "#F6D78B").opacity(0.75))
                .frame(width: 46, height: 14)
                .rotationEffect(.degrees(28))
                .offset(x: 130, y: 6)
            ForEach(Self.stickers) { s in
                sticker(s)
                    .scaleEffect(on ? 1 : 0.4)
                    .opacity(on ? 1 : 0)
                    .animation(still ? nil : Motion.reveal.delay(Motion.stagger(s.id, after: 0.2)), value: on)
                    .position(x: s.x, y: s.y)
            }
        }
    }

    /// a sticker: a round of colour with a white die-cut edge, its drawing in white, stuck on at an angle
    func sticker(_ s: Sticker) -> some View {
        Image(systemName: s.sym)
            .font(.system(size: s.size * 0.42, weight: .bold))
            .foregroundStyle(.white)
            .frame(width: s.size, height: s.size)
            .background(Circle().fill(Color(hex: s.fill)))
            .overlay(Circle().strokeBorder(Color.white, lineWidth: 2.5))
            .shadow(color: .black.opacity(0.18), radius: 2.5, y: 1.5)
            .rotationEffect(.degrees(s.turn))
    }
}
