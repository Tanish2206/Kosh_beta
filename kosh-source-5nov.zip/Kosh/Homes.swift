import Foundation

/// Bills by home (engine/21s-build-homes.js, `snap.homes`): each home's bills (electricity, water, piped gas, LPG,
/// broadband, DTH, society maintenance), put on the home they belong to (never on who paid), each spread over the days it
/// covers so homes and months compare. Facts beside the ledger, never a second figure of spending: a home's month is
/// its bills' share of that month. Screen-free: the screens read it through `Store` (Store+Homes.swift); the words are
/// made here so they can be tested without the screens.
struct HomesBook: Decodable, Hashable {
    /// one month of a home: its bills' share of it, whether every connection's bills cover it, and the units used
    struct Month: Decodable, Hashable, Identifiable {
        let m: String
        let v: Double
        var whole: Bool? = nil
        var units: [Units]? = nil
        var id: String { m }
    }
    struct Units: Decodable, Hashable {
        var k: String? = nil
        var unit: String? = nil
        var n: Double? = nil
    }
    struct MonthFig: Decodable, Hashable {
        let m: String
        let v: Double
    }
    /// the same whole months a year apart
    struct YearOnYear: Decodable, Hashable {
        let now: Double
        let was: Double
        let n: Int
        let from: String
        let to: String
    }
    /// one fact about a home, its figures and dates in the words (avg · peak · yoy)
    struct Line: Decodable, Hashable {
        let k: String
        let line: String
        var v: Double? = nil
    }
    /// a kind's month on average (the same whole months as the home's)
    struct KindFig: Decodable, Hashable {
        let k: String
        let v: Double
    }
    /// electricity in a month: units, what they cost, a unit's rate
    struct ElecMonth: Decodable, Hashable, Identifiable {
        let m: String
        let units: Double
        var unit: String? = nil
        let v: Double
        let rate: Double
        var id: String { m }
    }
    /// a summer month (Apr–Jun) against a winter month (Dec–Feb), whole months of the last two years
    struct Season: Decodable, Hashable {
        let summer: Double
        let winter: Double
        let sn: Int
        let wn: Int
    }
    /// a bill coming by its connection's own cycle, at what the same bill cost a year before (year) or its usual (usual)
    struct Next: Decodable, Hashable, Identifiable {
        let acct: String
        let k: String
        let on: String
        let amt: Double
        var how: String? = nil
        var id: String { acct + on }
    }
    /// out of the ordinary: a jump against the same days a year before, a missed cycle, arrears carried
    struct Alert: Decodable, Hashable, Identifiable {
        let k: String
        let acct: String
        let d: String
        var amt: Double? = nil
        var x: Double? = nil
        var usual: Double? = nil
        var due: String? = nil
        var id: String { k + acct + d }
    }
    struct Home: Decodable, Hashable, Identifiable {
        let id: String
        let name: String
        var place: String? = nil
        var state: String? = nil
        var pin: String? = nil
        /// the property it is (Property tab), when it is one
        var prop: String? = nil
        /// how kosh knows it is this home: you · address · property · state
        var by: String? = nil
        var kinds: [String]? = nil
        var accts: [String]? = nil
        var perMonth: Double? = nil
        var perDay: Double? = nil
        var from: String? = nil
        var to: String? = nil
        var n: Int? = nil
        var months: [Month]? = nil
        var peak: MonthFig? = nil
        var low: MonthFig? = nil
        var yoy: YearOnYear? = nil
        var jumps: [String]? = nil
        var lines: [Line]? = nil
        var byKind: [KindFig]? = nil
        var elec: [ElecMonth]? = nil
        var season: Season? = nil
        var next: [Next]? = nil
        var alerts: [Alert]? = nil
    }
    /// one connection (a consumer number, a CA, a flat): its home, the board, its last four figures
    struct Acct: Decodable, Hashable, Identifiable {
        let id: String
        var home: String? = nil
        let k: String
        var biller: String? = nil
        var n: Int? = nil
        var last: String? = nil
        var no: String? = nil
        var nol: String? = nil
        var state: String? = nil
        var by: String? = nil
        var off: Bool? = nil
        var per: Int? = nil
        var from: String? = nil
        var to: String? = nil
        var perDay: Double? = nil
    }
    /// a bill far above the same season a year before: how many times, and what those days cost then
    struct Jump: Decodable, Hashable {
        let x: Double
        let usual: Double
        let from: String
        let to: String
    }
    /// one bill: its cost, the days it covers (est: '' printed · since the bill before · usual gap · gap (one missing) ·
    /// none), its units, the payment that paid it
    struct Bill: Decodable, Hashable, Identifiable {
        let id: String
        let acct: String
        var home: String? = nil
        let k: String
        let d: String
        let amt: Double
        var est: String? = nil
        var src: [String]? = nil
        var from: String? = nil
        var to: String? = nil
        var days: Int? = nil
        var perDay: Double? = nil
        var units: Double? = nil
        var unit: String? = nil
        var rate: Double? = nil
        var paid: String? = nil
        var paidOnly: Bool? = nil
        var jump: Jump? = nil
        var asked: Double? = nil
    }
    var v: Int? = nil
    var homes: [Home]? = nil
    var accts: [Acct]? = nil
    var bills: [Bill]? = nil
    var unplaced: [String]? = nil
    var asOf: String? = nil
}

/// the words of the Bills by home screens, made without the screens (money and days are passed in, as Style formats them)
enum HomeWords {
    static func sym(_ k: String) -> String {
        switch k {
        case "Electricity": return "bolt.fill"
        case "Water": return "drop.fill"
        case "Gas", "LPG": return "flame.fill"
        case "Internet": return "wifi"
        case "DTH": return "tv"
        case "Maintenance": return "building.2.fill"
        default: return "house.fill"
        }
    }
    /// how kosh knows the home: said once, in plain words
    static func how(_ by: String?) -> String {
        switch by ?? "" {
        case "you": return "You put it here"
        case "address": return "From the address on its bills"
        case "property": return "The one property of yours in its board’s state"
        case "state": return "From its board’s state; tell kosh if it’s another home"
        default: return ""
        }
    }
    /// a connection in a line: "Electricity · UHBVN · Account No ••0001"
    static func acct(_ a: HomesBook.Acct) -> String {
        var s: String = a.k
        if let b = a.biller, !b.isEmpty { s += " · " + b }
        if let no = a.no, !no.isEmpty { s += " · " + (a.nol ?? "No.") + " ••" + no }
        return s
    }
    /// the days a bill covers, and how kosh knows them
    static func days(_ b: HomesBook.Bill, day: (String) -> String) -> String {
        guard let f = b.from, let t = b.to, let n = b.days, n > 0 else { return "Days not known: not in any month" }
        let span: String = day(f) + " – " + day(t) + " (" + String(n) + " days)"
        switch b.est ?? "" {
        case "": return span + ", as printed"
        case "since": return span + ", since the bill before"
        case "usual": return span + ", its usual gap"
        case "gap": return span + ", its usual gap: a bill before it is missing"
        default: return span
        }
    }
    /// a bill's second line: what it covers a day, the units and their rate
    static func detail(_ b: HomesBook.Bill, money: (Double) -> String) -> String {
        var bits: [String] = []
        if let pd = b.perDay, pd > 0 { bits.append(money(pd) + " a day") }
        if let u = b.units, u > 0 {
            let unit: String = b.unit ?? "units"
            var s: String = (u == u.rounded() ? String(Int(u)) : String(format: "%.1f", u)) + " " + unit
            if let r = b.rate, r > 0 { s += " at about " + money(r) + " each (bill ÷ " + unit + ")" }
            bits.append(s)
        }
        if let a = b.asked, a > b.amt { bits.append(money(b.amt) + " of " + money(a) + " is this bill’s, the rest carried from before") }
        if b.paid == nil { bits.append("No payment seen yet") }
        return bits.joined(separator: " · ")
    }
    /// the jump, said plainly with its dates
    static func jump(_ b: HomesBook.Bill, money: (Double) -> String, day: (String) -> String) -> String? {
        guard let j = b.jump else { return nil }
        let x: String = j.x == j.x.rounded() ? String(Int(j.x)) : String(format: "%.1f", j.x)
        return x + "× the same days a year before (" + money(j.usual) + ", " + day(j.from) + " – " + day(j.to) + ")"
    }
    /// what is out of the ordinary, said as a title and a line with its dates (insights-obsidian, 1 Nov)
    static func alert(_ a: HomesBook.Alert, kind: String, money: (Double) -> String, day: (String) -> String) -> (title: String, line: String) {
        switch a.k {
        case "jump":
            let x: Double = a.x ?? 0
            let xs: String = x == x.rounded() ? String(Int(x)) : String(format: "%.1f", x)
            return (kind + " bill up " + String(Int(((x - 1) * 100).rounded())) + "%",
                    xs + "× the same days a year before" + (a.usual.map { " (" + money($0) + " then)" } ?? "") + ", the bill of " + day(a.d))
        case "missed":
            return ("No " + kind.lowercased() + " bill since " + day(a.d), "It was due about " + day(a.due ?? a.d) + " by its cycle: a bill kosh hasn’t seen, or a connection closed")
        case "arrears":
            return (money(a.amt ?? 0) + " carried on the " + kind.lowercased() + " bill", "The bill of " + day(a.d) + " asks for more than its own charges")
        default:
            return (kind, day(a.d))
        }
    }
    /// a bill coming: "Electricity · about 9 Nov", "₹1,800, what it was a year before"
    static func next(_ n: HomesBook.Next, money: (Double) -> String) -> String {
        money(n.amt) + ((n.how ?? "") == "year" ? ", what it cost a year before" : ", its usual")
    }
    /// summer against winter in words: "A summer month costs 2.5× a winter one"
    static func season(_ s: HomesBook.Season) -> String {
        guard s.winter > 0, s.summer > 0 else { return "" }
        let r: Double = s.summer / s.winter
        if r >= 0.9 && r <= 1.1 { return "Summer and winter cost about the same" }
        if r > 1 { return "A summer month costs " + String(format: "%.1f", r) + "× a winter one" }
        return "A winter month costs " + String(format: "%.1f", 1 / r) + "× a summer one"
    }
    /// this year against the same months a year before, as a change: 0.12 is 12% more
    static func yoy(_ h: HomesBook.Home) -> Double? {
        guard let y = h.yoy, y.was > 0 else { return nil }
        return (y.now - y.was) / y.was
    }
    /// a kind's share of a home's month: 0.42
    static func share(_ k: HomesBook.KindFig, of h: HomesBook.Home) -> Double {
        let total: Double = (h.byKind ?? []).reduce(0) { $0 + $1.v }
        return total > 0 ? k.v / total : 0
    }
    /// two homes side by side: a row a figure, each home's, said only where both have it
    struct Row: Hashable, Identifiable {
        let label: String
        let a: Double
        let b: Double
        var id: String { label }
    }
    static func compare(_ a: HomesBook.Home, _ b: HomesBook.Home) -> [Row] {
        var out: [Row] = []
        if let x = a.perMonth, let y = b.perMonth { out.append(Row(label: "A month", a: x, b: y)) }
        if let x = a.perDay, let y = b.perDay { out.append(Row(label: "A day", a: x, b: y)) }
        let ka: [String: Double] = Dictionary((a.byKind ?? []).map { ($0.k, $0.v) }, uniquingKeysWith: { x, _ in x })
        let kb: [String: Double] = Dictionary((b.byKind ?? []).map { ($0.k, $0.v) }, uniquingKeysWith: { x, _ in x })
        for k in ["Electricity", "Water", "Gas", "LPG", "Internet", "Maintenance", "DTH"] {
            let x: Double = ka[k] ?? 0, y: Double = kb[k] ?? 0
            if x > 0 || y > 0 { out.append(Row(label: k, a: x, b: y)) }
        }
        return out
    }
    /// a month's label on the chart: "J" for June, the year under January
    static func monthLetter(_ m: String) -> String {
        let letters: [String] = ["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"]
        guard m.count >= 7, let mo = Int(m.dropFirst(5).prefix(2)), mo >= 1, mo <= 12 else { return "" }
        return letters[mo - 1]
    }
}
