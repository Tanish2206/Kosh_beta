/* kosh's live view: ask anything, and kosh draws it. A question becomes a VIEW PLAN, a small typed spec of what to
   show (one fact, the filters, one picture, an answer line whose numbers are slots); the plan becomes a FILL, the
   figures, worked out by the same rules Ask kosh answers with (agent.js lends them as KoshAgent.figures, so a figure
   is computed in one place). The phone draws the fill natively (LiveView*.swift).

   The one rule: the AI chooses what to show; kosh computes every number. Apple's on-device model, where the phone has
   it, may write a plan; this file checks it (checkPlan) against the schema and the household's own names, and a plan
   whose answer line holds a digit outside a {slot} is refused. So a rupee a model made up can never reach the screen.
   With no model, or any error, the rule planner here (planOf) reads the question the way Ask kosh does (its
   understand(), English and Hinglish alike) and always works.

   A plan keeps relative days ("this month", "the last 6 months"), so a view pinned to Home is the same question asked
   again on each build, never last month's figures frozen.

   Outside every reading fingerprint, like agent.js: changing it re-reads no mail. Loaded after agent.js. */
var KoshLiveView = (function (E, A) {
  'use strict';
  var F = A.figures;
  var V = 1;

  /* ------------------------------------------------------------ the plan's schema */
  var FACTS = ['spend', 'paid', 'income', 'invested', 'holdings', 'networth', 'balances', 'bills', 'refunds', 'payments'];
  var PICTURES = ['figure', 'trend', 'compare', 'ranked', 'split', 'timeline', 'calendar'];
  // what each fact can be drawn as
  var FITS = {
    spend: ['figure', 'trend', 'compare', 'ranked', 'split', 'timeline', 'calendar'],
    paid: ['figure', 'trend', 'ranked', 'timeline', 'calendar'],
    income: ['figure', 'trend', 'ranked', 'split', 'timeline'],
    invested: ['figure', 'trend', 'ranked', 'timeline'],
    holdings: ['figure', 'split', 'ranked'],
    networth: ['figure'],
    balances: ['figure', 'ranked'],
    bills: ['figure', 'timeline', 'calendar'],
    refunds: ['figure', 'timeline'],
    payments: ['figure', 'timeline', 'calendar'],
  };
  // what a ranking or a split can be by, for each fact
  var BYS = {
    spend: ['category', 'payee', 'person', 'card', 'method', 'weekday', 'month'],
    paid: ['payee', 'category', 'person', 'card', 'method', 'weekday', 'month'],
    income: ['source', 'month', 'person'],
    invested: ['payee', 'month'],
    holdings: ['class', 'person'],
    balances: ['account'],
  };
  var RANGES = ['month', 'months', 'days', 'year', 'fy', 'all', 'span', 'ahead'];
  // the filters a plan may carry, by type (the same keys Ask kosh's frames use, so the rows are the same rows)
  var FILTERS = { category: 's', merchant: 's', merchants: 'a', person: 's', card: 's', method: 's', min: 'n', max: 'n', weekend: 's', unnamed: 'b',
    billKind: 's', forName: 's', forWho: 's', biz: 'b', dir: 's', what: 's', which: 's', shops: 'b' };
  var METHODS = ['upi', 'cash', 'card', 'wallet', 'auto', 'transfer'];
  // the slots an answer line may use, for each picture (all pictures: range, subject, count)
  var SLOTS_ALL = ['range', 'subject', 'count'];
  var SLOTS = {
    figure: ['total', 'change', 'prev', 'before', 'top', 'topValue', 'usual', 'what'],
    trend: ['usual', 'last', 'lastMonth', 'high', 'highMonth', 'low', 'lowMonth', 'total', 'months'],
    compare: ['a', 'b', 'aLabel', 'bLabel', 'diff', 'pct', 'more', 'moved', 'movedBy'],
    ranked: ['top', 'topValue', 'share', 'total', 'n'],
    split: ['top', 'topValue', 'share', 'total', 'n'],
    timeline: ['n', 'total', 'first', 'firstDate', 'firstValue', 'next', 'nextDate', 'nextValue'],
    calendar: ['total', 'n', 'peak', 'peakDay', 'days'],
  };

  /* ------------------------------------------------------------ small things */
  function lc(s) { return String(s == null ? '' : s).toLowerCase(); }
  function isObj(x) { return !!x && typeof x === 'object' && !Array.isArray(x); }
  function isDay(s) { return /^\d{4}-\d{2}-\d{2}$/.test(String(s || '')) && isFinite(Date.parse(s + 'T00:00:00Z')); }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function sumA(rows) { var s = 0; for (var i = 0; i < rows.length; i++) s += +rows[i].a || 0; return s; }
  function r0(n) { return Math.round((+n || 0) * 100) / 100; }
  function monthsBack(m, n) { var y = +m.slice(0, 4), mo = +m.slice(5, 7) - n; while (mo < 1) { mo += 12; y--; } while (mo > 12) { mo -= 12; y++; } return y + '-' + pad(mo); }
  function monthsBetween(a, b) { return (+b.slice(0, 4) - +a.slice(0, 4)) * 12 + (+b.slice(5, 7) - +a.slice(5, 7)); }
  var MON3 = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  var DOW = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
  function money(v) { return F.inr(Math.round(Math.abs(+v || 0))); }
  function n_(n, one, many) { return n + ' ' + (n === 1 ? one : (many || one + 's')); }
  // (kosh is written small, even first)
  function cap1(s) { s = String(s || ''); return /^kosh\b/.test(s) ? s : s.charAt(0).toUpperCase() + s.slice(1); }
  function dayLabel(d) { return isDay(d) ? +d.slice(8, 10) + ' ' + MON3[+d.slice(5, 7) - 1] + ' ' + d.slice(0, 4) : ''; }
  // "1 Oct – 30 Oct 2026": the dates themselves, beside every figure
  function datesLabel(from, to) {
    if (!isDay(to)) return '';
    if (!isDay(from)) return 'up to ' + dayLabel(to);
    if (from === to) return dayLabel(from);
    return +from.slice(8, 10) + ' ' + MON3[+from.slice(5, 7) - 1] + (from.slice(0, 4) !== to.slice(0, 4) ? ' ' + from.slice(0, 4) : '') + ' – ' + dayLabel(to);
  }

  /* ------------------------------------------------------------ days: a plan keeps them relative */
  /* the stretch a frame names, as a plan keeps it: this month and the months before it, the last N days or months, this
     year or financial year, everything, or the dates themselves when they're none of those */
  function relRange(from, to, today, label) {
    var tm = today.slice(0, 7);
    if (!from) return { kind: 'all' };
    if (!isDay(from) || !isDay(to || today)) return { kind: 'month', back: 0 };
    to = to || today;
    if (from.slice(8) === '01') {
      var m = from.slice(0, 7);
      if (m === to.slice(0, 7) && (to === today || to === F.monthEnd(from))) { var back = monthsBetween(m, tm); if (back >= 0) return { kind: 'month', back: back }; }
      if (to === today && m < tm) {
        if (from.slice(5) === '01-01' && m.slice(0, 4) === tm.slice(0, 4)) return { kind: 'year', back: 0 };
        if (from.slice(5) === '04-01' && fyStart(today) === from) return { kind: 'fy', back: 0 };
        return { kind: 'months', n: monthsBetween(m, tm) + 1 };
      }
      if (from.slice(5) === '01-01' && to === from.slice(0, 4) + '-12-31') return { kind: 'year', back: +tm.slice(0, 4) - +from.slice(0, 4) };
      if (from.slice(5) === '04-01' && to === (+from.slice(0, 4) + 1) + '-03-31') return { kind: 'fy', back: Math.round(F.daysBetween(from, fyStart(today)) / 365) };
    }
    if (to === today) return { kind: 'days', n: F.daysBetween(from, today) + 1, label: label || undefined };
    return { kind: 'span', from: from, to: to, label: label || undefined };
  }
  function fyStart(today) { var y = +today.slice(0, 4), mo = +today.slice(5, 7); return (mo >= 4 ? y : y - 1) + '-04-01'; }
  /* a plan's stretch, as days, on a given today: { from, to, label } (label: the words Ask kosh uses for it) */
  function resolve(r, today) {
    r = r || { kind: 'month', back: 0 };
    var tm = today.slice(0, 7), y = +today.slice(0, 4);
    switch (r.kind) {
      case 'month': {
        var m = monthsBack(tm, +r.back || 0), to = (+r.back || 0) === 0 ? today : F.monthEnd(m + '-01');
        return { from: m + '-01', to: to, label: (+r.back || 0) === 0 ? 'this month' : 'in ' + F.monthWord(m, today) };
      }
      case 'months': { var n = Math.max(1, Math.min(36, +r.n || 6)); return { from: monthsBack(tm, n - 1) + '-01', to: today, label: n === 1 ? 'this month' : 'over the last ' + n + ' months' }; }
      case 'days': { var d = Math.max(1, Math.min(1100, +r.n || 30)); return { from: F.addDays(today, -(d - 1)), to: today, label: r.label || (d === 1 ? 'today' : 'in the last ' + d + ' days') }; }
      case 'year': { var yy = y - (+r.back || 0); return { from: yy + '-01-01', to: (+r.back || 0) === 0 ? today : yy + '-12-31', label: (+r.back || 0) === 0 ? 'this year' : 'in ' + yy }; }
      case 'fy': {
        var fs = +fyStart(today).slice(0, 4) - (+r.back || 0);
        return { from: fs + '-04-01', to: (+r.back || 0) === 0 ? today : (fs + 1) + '-03-31', label: (+r.back || 0) === 0 ? 'this financial year' : 'in FY ' + fs + '–' + String(fs + 1).slice(2) };
      }
      case 'all': return { from: '', to: today, label: 'in all kosh has read' };
      case 'ahead': {
        var st = Math.max(0, +r.start || 0), nd = Math.max(1, Math.min(120, +r.days || 30)), f0 = F.addDays(today, st), t0 = F.addDays(today, st + nd);
        return { from: f0, to: t0, label: r.label || (st === 0 ? 'in the next ' + nd + ' days' : 'from ' + F.on(f0, today) + ' to ' + F.on(t0, today)) };
      }
      case 'span': return { from: r.from, to: r.to, label: r.label || '' };
    }
    return resolve({ kind: 'month', back: 0 }, today);
  }

  /* ------------------------------------------------------------ checking a plan (the rule planner's and the model's) */
  function knownCats(ctx) { var c = {}; (ctx.tx || []).forEach(function (t) { if (t.c) c[lc(t.c)] = t.c; if (t.s) c[lc(t.s)] = t.s; if (t.nt) c[lc(t.nt)] = t.nt; }); return c; }
  function knownPeople(ctx) { var p = { me: 'me', you: 'me' }; (ctx.people || []).forEach(function (x) { if (x.name) p[lc(x.name)] = x.id === 'me' ? 'me' : x.name; if (x.full) p[lc(x.full)] = x.id === 'me' ? 'me' : x.name; }); return p; }
  function payeeSeen(ctx, part) { var w = lc(part).trim(); if (w.length < 2) return false; return (ctx.tx || []).some(function (t) { return lc(t.m).indexOf(w) >= 0; }); }
  /* the slots an answer line names, and whether it holds a number of its own */
  function slotsIn(tpl) { var out = [], re = /\{(\w+)\}/g, m; while ((m = re.exec(tpl))) out.push(m[1]); return out; }
  function digitsOutside(tpl) { return /[0-9₹%०-९]/.test(String(tpl).replace(/\{\w+\}/g, '')); }

  /* { ok, plan (filled in), errors } — a plan with any error is never filled */
  function checkPlan(p, ctx) {
    var err = [], today = ctx.today || '';
    if (!isObj(p)) return { ok: false, errors: ['not a plan'] };
    if (p.v !== undefined && +p.v !== V) err.push('version ' + p.v + ' is not ' + V);
    var fact = String(p.fact || ''), pic = String(p.picture || '');
    if (FACTS.indexOf(fact) < 0) err.push('unknown fact "' + fact + '"');
    if (PICTURES.indexOf(pic) < 0) err.push('unknown picture "' + pic + '"');
    else if (FITS[fact] && FITS[fact].indexOf(pic) < 0) err.push(fact + ' can’t be drawn as ' + pic);
    var out = { v: V, q: String(p.q || '').slice(0, 300), fact: fact, picture: pic };
    // the stretch
    var r = isObj(p.range) ? p.range : null;
    if (!r) r = defaultRange(fact, pic);
    if (RANGES.indexOf(r.kind) < 0) err.push('unknown range "' + r.kind + '"');
    else {
      var rr = { kind: r.kind };
      if (r.kind === 'month' || r.kind === 'year' || r.kind === 'fy') { rr.back = Math.round(+r.back || 0); if (!(rr.back >= 0 && rr.back <= 30)) err.push('range back out of reach'); }
      if (r.kind === 'months') { rr.n = Math.round(+r.n || 0); if (!(rr.n >= 1 && rr.n <= 36)) err.push('months out of reach'); }
      if (r.kind === 'days') { rr.n = Math.round(+r.n || 0); if (!(rr.n >= 1 && rr.n <= 1100)) err.push('days out of reach'); }
      if (r.kind === 'ahead') { rr.start = Math.round(+r.start || 0); rr.days = Math.round(+r.days || 0); if (!(rr.days >= 1 && rr.days <= 120 && rr.start >= 0 && rr.start <= 366)) err.push('days ahead out of reach'); }
      if (r.kind === 'span') {
        rr.from = String(r.from || ''); rr.to = String(r.to || '');
        if (!isDay(rr.from) || !isDay(rr.to) || rr.from > rr.to) err.push('span dates are not days in order');
        else if (fact !== 'bills' && today && rr.to > today) err.push('a span that hasn’t happened yet');
      }
      if (r.label && typeof r.label === 'string' && !/\d{3,}/.test(r.label)) rr.label = r.label.slice(0, 60);
      if ((r.kind === 'ahead') !== (fact === 'bills') && !(fact === 'bills' && r.kind === 'span')) err.push(fact === 'bills' ? 'bills look ahead' : 'only bills look ahead');
      out.range = rr;
    }
    // what it's cut by
    if (pic === 'ranked' || pic === 'split') {
      var by = String(p.by || (BYS[fact] || [])[0] || '');
      if (!BYS[fact] || BYS[fact].indexOf(by) < 0) err.push(fact + ' can’t be split by "' + by + '"');
      out.by = by;
    } else if (p.by && pic === 'trend') out.by = 'month';
    // the filters: known keys, each of its own type; a category, person or payee must be the household's own
    var fl = {}, cats = null, ppl = null;
    if (p.filters !== undefined && !isObj(p.filters)) err.push('filters is not an object');
    Object.keys(isObj(p.filters) ? p.filters : {}).forEach(function (k) {
      var v = p.filters[k], t = FILTERS[k];
      if (v === undefined || v === null || v === '' || v === false) return;
      if (!t) { err.push('unknown filter "' + k + '"'); return; }
      if (t === 's' && typeof v !== 'string') { err.push(k + ' is not text'); return; }
      if (t === 'n' && !(typeof v === 'number' && isFinite(v) && v >= 0)) { err.push(k + ' is not an amount'); return; }
      if (t === 'b' && v !== true) { err.push(k + ' is not true'); return; }
      if (t === 'a' && !(Array.isArray(v) && v.every(function (x) { return typeof x === 'string'; }))) { err.push(k + ' is not a list'); return; }
      fl[k] = v;
    });
    if (fl.category) { cats = knownCats(ctx); var c = cats[lc(fl.category)]; if (!c && fact !== 'income') err.push('no category "' + fl.category + '" in this household'); else if (c) fl.category = c; }
    if (fl.person) { ppl = knownPeople(ctx); var pp = ppl[lc(fl.person)] || ppl[lc(fl.person).split(' ')[0]]; if (!pp) err.push('no one called "' + fl.person + '" in this household'); else fl.person = pp; }
    if (fl.merchant && !payeeSeen(ctx, fl.merchant)) err.push('no payee "' + fl.merchant + '" in the ledger');
    (fl.merchants || []).forEach(function (m) { if (!payeeSeen(ctx, m)) err.push('no payee "' + m + '" in the ledger'); });
    if (fl.method && METHODS.indexOf(fl.method) < 0) err.push('unknown way of paying "' + fl.method + '"');
    if (fl.min && fl.max && fl.min > fl.max) err.push('min above max');
    out.filters = fl;
    // what a comparison is held against
    if (pic === 'compare') {
      var ag = isObj(p.against) ? p.against : { prior: true }, ao = {};
      if (ag.person) { ppl = ppl || knownPeople(ctx); ao.person = ppl[lc(ag.person)] || ppl[lc(ag.person).split(' ')[0]]; if (!ao.person) err.push('no one called "' + ag.person + '" to compare with'); }
      else if (ag.merchant) { if (!payeeSeen(ctx, ag.merchant)) err.push('no payee "' + ag.merchant + '" to compare with'); ao.merchant = ag.merchant; }
      else if (isObj(ag.range)) { var c2 = checkPlan({ v: V, fact: fact, picture: 'figure', range: ag.range }, ctx); if (!c2.ok) err.push('the stretch to compare with: ' + c2.errors.join('; ')); else ao.range = c2.plan.range; }
      else ao.prior = true;
      out.against = ao;
    }
    if (p.top !== undefined) { var tp = Math.round(+p.top); if (!(tp >= 1 && tp <= 30)) err.push('top out of reach'); else out.top = tp; }
    if (p.order === 'asc') out.order = 'asc';
    if (p.sort === 'amount' || p.sort === 'date') out.sort = p.sort;
    if (p.unit === 'count') out.unit = 'count';
    // the answer line: slots only, never a number of its own
    var tpl = p.answer === undefined || p.answer === null ? '' : p.answer;
    if (typeof tpl !== 'string') err.push('answer is not text');
    else if (tpl) {
      if (tpl.length > 220) err.push('answer line too long');
      if (digitsOutside(tpl)) err.push('the answer line has a number of its own (numbers come only from {slots})');
      var ok = SLOTS_ALL.concat(SLOTS[pic] || []);
      slotsIn(tpl).forEach(function (s) { if (ok.indexOf(s) < 0) err.push('no slot {' + s + '} for a ' + pic); });
      if (/[{}]/.test(tpl.replace(/\{\w+\}/g, ''))) err.push('a broken slot in the answer line');
      if (/[\[\]]/.test(tpl.replace(/\[[^\[\]]*\]/g, ''))) err.push('a broken [optional] part in the answer line');
    }
    out.answer = tpl || defaultAnswer(out);
    var ti = p.title === undefined || p.title === null ? '' : String(p.title);
    if (ti && (ti.length > 60 || /\d/.test(ti))) err.push('the title has a number or is too long');
    if (ti) out.title = ti;
    if (isObj(p.frame)) out.frame = p.frame;
    return { ok: !err.length, plan: out, errors: err };
  }
  function defaultRange(fact, pic) {
    if (fact === 'bills') return { kind: 'ahead', start: 0, days: 30 };
    if (pic === 'trend') return { kind: 'months', n: 6 };
    if (fact === 'invested') return { kind: 'year', back: 0 };
    if (fact === 'refunds' || fact === 'holdings' || fact === 'networth' || fact === 'balances') return { kind: 'all' };
    return { kind: 'month', back: 0 };
  }
  /* the line kosh says when the plan brings none of its own: numbers only from slots; [ … ] goes when a slot in it is blank */
  function defaultAnswer(p) {
    var f = p.fact, pic = p.picture;
    if (pic === 'figure') {
      if (p.unit === 'count') return '{count}{subject} {range}.';
      if (f === 'networth') return 'Your net worth is {total}, as Home counts it.';
      if (f === 'holdings') return 'Your holdings come to {total}{subject}.';
      if (f === 'balances') return '{total} in your bank accounts.';
      if (f === 'bills') return '{total} to go out {range}{subject}.';
      if (f === 'refunds') return '{total} still to come back[, across {count}].';
      if (f === 'income') return '{total} came to you{subject} {range}[, across {count}].[ That’s {change}.]';
      if (f === 'invested') return 'You put {total} into investments {range}[, across {count}].';
      if (f === 'paid') return 'You paid {total}{subject} {range}[, across {count}].[ That’s {change}.]';
      return '{total}{subject} {range}[, across {count}].[ That’s {change}.]';
    }
    if (pic === 'trend') return f === 'income' ? 'A usual month brings in {usual}.[ {lastMonth} was {last}.]' : 'A usual month{subject} is {usual}.[ {lastMonth} was {last}.][ The biggest was {highMonth}, {high}.]';
    if (pic === 'compare') return '{aLabel}: {a}{subject}, {diff} {more} {bLabel}[ ({pct})].[ What moved most: {moved}, {movedBy}.]';
    if (pic === 'ranked' || pic === 'split') {
      if (f === 'holdings') return '{top} is the biggest part of your holdings: {topValue} of {total}[ ({share})].';
      if (f === 'balances') return '{top} holds the most: {topValue} of {total}.';
      return '{top} took the most{subject} {range}: {topValue}[ ({share} of {total})].';
    }
    if (pic === 'timeline') {
      if (f === 'bills') return '{n} {range}, {total} going out.[ Next: {next}, {nextValue} {nextDate}.]';
      if (f === 'refunds') return '{n} on their way back, {total} in all.[ The oldest: {first}, {firstValue}.]';
      return '{count}{subject} {range}, {total} in all.[ The ' + (p.sort === 'amount' ? (p.order === 'asc' ? 'smallest' : 'biggest') : 'latest') + ': {first}, {firstValue}, {firstDate}.]';
    }
    if (pic === 'calendar') return f === 'bills' ? '{total} going out {range}.[ The heaviest day is {peakDay}: {peak}.]' : '{total}{subject} {range}.[ The heaviest day was {peakDay}: {peak}.]';
    return '{total} {range}.';
  }

  /* ------------------------------------------------------------ the rule planner: a question becomes a plan */
  var PIC_WORD = [
    [/\b(?:calendar|by day|day by day|each day|every day|daily)\b/, 'calendar'],
    [/\b(?:list|timeline|the payments|show (?:me )?(?:them|these|those)|one by one)\b/, 'timeline'],
    [/\b(?:pie|donut|doughnut|share|split|breakdown|break ?down)\b/, 'split'],
    [/\b(?:bars?|ranking|ranked|rank|leaderboard|top)\b/, 'ranked'],
    [/\b(?:trend|line|over time|month by month|graph|chart)\b/, 'trend'],
  ];
  /* a picture the question names outright ("as a calendar", "pie chart", "bar chart", "as a graph") */
  function askedPicture(s) {
    var m = /\b(?:as an? |in an? |on an? )?(calendar|pie(?: chart)?|donut|doughnut|bar chart|bars|line chart|line graph|graph|chart|timeline)\b/.exec(s);
    if (!m) return '';
    var w = m[1];
    return /calendar/.test(w) ? 'calendar' : /pie|donut|doughnut/.test(w) ? 'split' : /bar/.test(w) ? 'ranked' : /timeline/.test(w) ? 'timeline' : 'trend';
  }
  function low(q) { return ' ' + lc(q).replace(/[’‘`´]/g, "'").replace(/[?!.,;:()"“”]/g, ' ').replace(/\s+/g, ' ').trim() + ' '; }
  /* "as a calendar", "show it as a list", "pie chart": the same plan, drawn another way (when that fact can be) */
  function redraw(s, prev) {
    if (!prev || s.trim().split(' ').length > 7) return null;
    if (!/\b(?:as|in|show|draw|make it|see it|view|instead|chart|graph|pie|calendar|list|bars?|timeline|donut)\b/.test(s)) return null;
    for (var i = 0; i < PIC_WORD.length; i++) {
      if (!PIC_WORD[i][0].test(s)) continue;
      var pic = PIC_WORD[i][1];
      if (pic === prev.picture) return null;
      var fits = FITS[prev.fact] || [];
      var p = JSON.parse(JSON.stringify(prev));
      // a figure or a list of spending asked as a split: by category; as a calendar: the same stretch, day by day
      if (fits.indexOf(pic) < 0) {
        if (pic === 'split' && fits.indexOf('ranked') >= 0) pic = 'ranked'; else return null;
      }
      p.picture = pic; p.answer = ''; delete p.title;
      // the payments behind spending, money paid or money in, listed: Ask kosh's list ("show these payments")
      if (pic === 'timeline' && (p.fact === 'spend' || p.fact === 'paid' || p.fact === 'income')) { if (p.fact === 'income') p.filters.dir = 'in'; p.fact = 'payments'; p.sort = p.sort || 'date'; }
      if ((pic === 'ranked' || pic === 'split') && !p.by) p.by = (BYS[p.fact] || [])[0];
      if (pic === 'trend') { p.range = { kind: 'months', n: 6 }; delete p.by; }
      if (pic === 'timeline' || pic === 'calendar' || pic === 'figure') delete p.by;
      if (pic === 'calendar' && p.range && p.range.kind === 'months') p.range = { kind: 'month', back: 0 };
      return p;
    }
    return null;
  }
  // refunds still to come: Ask kosh's context has no Refunds list, the live view reads it
  var REFUND_OPEN = /\brefunds?\b(?=.*\b(?:pending|waiting|due|status|track|stuck|still|yet|open|owed|kab|kitne|kaunsa|abhi tak)\b)|\b(?:pending|waiting|due|open|stuck) (?:on )?(?:a |my |any )?refunds?\b|\bwaiting (?:on|for) (?:a |my |any )?refunds?\b/;

  var HOLD_ASK = /\b(?:investments?|portfolio|holdings?|mutual funds?|assets)\b/;
  var HOLD_NOT = /\bspen[dt]\b|\binvested\b|\bhow much (?:did|have|do) (?:i|we) (?:invest|put)\b|\b(?:this|last) (?:month|year|week|fy|financial year)\b|\bnet ?worth\b|\bsips?\b|\bput\b|\bpaid\b|\bmonth by month\b|\btrend\b/;
  // a total asked month by month, or cut by something ("by payee", "category wise", "har mahine ka")
  var BY_ASK = /\bby (month|months|categor\w*|kinds?|payees?|merchants?|shops?|stores?|person|people|cards?|days?|weekdays?)\b|\b(month|categor\w*|payee|shop|card|day)[ -]?wise\b|\b(?:har|every|each) (mahine|month)\b|\b(monthly) (?:spend|spending|kharcha|breakdown)\b/;

  /* the filters of a frame, as a plan keeps them */
  function filtersOf(f) {
    var o = {};
    Object.keys(FILTERS).forEach(function (k) { if (f[k] !== undefined && f[k] !== null && f[k] !== '' && f[k] !== false) o[k] = f[k]; });
    if (o.merchants && o.merchants.length < 2) delete o.merchants;
    // a list of payees joined is each of them; the first one is the frame's merchant too
    return o;
  }
  function rangeOf(f, today, def) { return f.named && f.from ? relRange(f.from, f.to, today, f.label) : def; }
  /* the frame Ask kosh understood, kept small for a follow-up to carry on from */
  function keepFrame(f) { var o = {}; Object.keys(f || {}).forEach(function (k) { var v = f[k]; if (k.indexOf('__') !== 0 && v !== undefined && v !== '' && (typeof v !== 'object' || Array.isArray(v) || (v && k === 'ahead'))) o[k] = v; }); return o; }

  /* question (+ the plan before, for a follow-up) → { plan, how, why }; plan is null when this is a question for words */
  function planOf(q, ctx, prev) {
    var today = ctx.today || '', s = low(q);
    if (!today) return { plan: null, why: 'no day to work from' };
    var again = redraw(s, prev);
    if (again) return done(again, 'redrawn');
    // "food spending as a calendar", "a pie of this month": the question, drawn the way it says
    var asked = askedPicture(s);
    if (REFUND_OPEN.test(s)) return done({ q: q, fact: 'refunds', picture: 'timeline', range: { kind: 'all' } }, 'rules');
    // what's held, asked as a whole ("how are my investments split", "my portfolio"), not money put in
    if (HOLD_ASK.test(s) && !HOLD_NOT.test(s)) return done({ q: q, fact: 'holdings', picture: 'split', by: 'class', range: { kind: 'all' }, filters: {} }, 'rules');
    var f = A.understand(q, ctx, prev && prev.frame ? prev.frame : null) || { act: 'none' };
    var p = { q: q, filters: filtersOf(f) };
    var thisMonth = { kind: 'month', back: 0 };
    switch (f.act) {
      case 'total': {
        p.fact = f.merchant && F.isPerson(f.merchant, ctx) ? 'paid' : 'spend';
        p.picture = 'figure'; p.range = rangeOf(f, today, thisMonth);
        // "this year by month", "har mahine ka": the same spending, month by month; "by payee": cut that way
        var cut = BY_ASK.exec(s);
        if (cut) {
          var w = cut[1] || cut[2] || cut[3] || cut[4] || 'month';
          var byW = /^(?:month|mahine|monthly)/.test(w) ? 'month' : /^(?:categor|kind)/.test(w) ? 'category' : /^(?:payee|merchant|shop|store)/.test(w) ? 'payee' : /^(?:person|people)/.test(w) ? 'person' : /^card/.test(w) ? 'card' : /^(?:day|week)/.test(w) ? 'weekday' : 'month';
          if (byW === 'month') { p.picture = 'trend'; if (p.range.kind === 'month') p.range = { kind: 'months', n: 6 }; }
          else if (!(byW === 'payee' && f.merchant)) { p.picture = byW === 'category' || byW === 'person' ? 'split' : 'ranked'; p.by = byW; if (byW === 'payee') p.fact = 'paid'; }
        }
        break;
      }
      case 'rank': {
        var by = f.by === 'payee' ? 'payee' : f.by || 'category';
        p.fact = by === 'payee' ? 'paid' : 'spend';
        if (by === 'month') { p.picture = 'trend'; p.range = rangeOf(f, today, { kind: 'months', n: 12 }); p.mark = 'high'; break; }
        p.picture = by === 'category' || by === 'person' ? 'split' : 'ranked';
        p.by = by; p.range = rangeOf(f, today, thisMonth);
        if (f.order === 'asc') p.order = 'asc';
        if (f.n) p.top = f.n;
        if (f.shops) p.filters.shops = true;
        break;
      }
      case 'biggest': case 'list': case 'last': {
        p.fact = 'payments'; p.picture = 'timeline';
        p.sort = f.act === 'biggest' || f.sort === 'amount' ? 'amount' : 'date';
        p.range = f.act === 'last' ? rangeOf(f, today, { kind: 'all' }) : f.act === 'list' && !f.named && (f.merchant || f.category || f.person) ? { kind: 'days', n: 90, label: 'in the last 3 months' } : rangeOf(f, today, thisMonth);
        if (f.n) p.top = Math.min(30, f.n);
        if (f.order === 'asc') p.order = 'asc';
        if (f.act === 'last' && /\b(?:received|credited|came|got|salary|refund|income)\b/.test(s)) p.filters.dir = 'in';
        if (f.dir === 'in') p.filters.dir = 'in';
        break;
      }
      case 'count': {
        p.fact = 'payments'; p.picture = 'figure'; p.unit = 'count';
        p.range = rangeOf(f, today, /\bhow often\b/.test(s) ? { kind: 'days', n: 90, label: 'in the last 3 months' } : thisMonth);
        break;
      }
      case 'avg': {
        if (f.unit && f.unit !== 'month') return { plan: null, why: 'an average a payment, day or week is said in words' };
        p.fact = 'spend'; p.picture = 'trend'; p.range = { kind: 'months', n: 7 };
        break;
      }
      case 'trend': {
        var nM = /\b(?:last|past) (\d+|three|four|six|twelve) months\b/.exec(s), cnt = nM ? (/^\d+$/.test(nM[1]) ? +nM[1] : { three: 3, four: 4, six: 6, twelve: 12 }[nM[1]]) : 6;
        p.fact = f.what === 'income' ? 'income' : 'spend'; p.picture = 'trend'; p.range = { kind: 'months', n: Math.max(2, Math.min(24, cnt)) };
        break;
      }
      case 'compare': {
        p.fact = 'spend'; p.picture = 'compare';
        var A0 = null, B0 = null, cut = /\b(?:compared? (?:to|with)|against|vs|versus|than)\b/.exec(s);
        if (!cut && /\bcompare\b/.test(s) && / with /.test(s)) cut = { index: s.indexOf(' with '), 0: ' with ' };
        if (!cut && /\bcompare\b/.test(s) && / and /.test(s)) cut = { index: s.lastIndexOf(' and '), 0: ' and ' };
        if (cut) {
          var head = A.periodOf(s.slice(0, cut.index) + ' ', today), tail = A.periodOf(' ' + s.slice(cut.index + cut[0].length), today);
          if (head.named) A0 = relRange(head.from, head.to, today, head.label);
          if (tail.named) B0 = relRange(tail.from, tail.to, today, tail.label);
        }
        if (f.bills && !A0 && !f.named) { A0 = { kind: 'month', back: 1 }; B0 = { kind: 'month', back: 2 }; }
        if (!A0 && B0) A0 = thisMonth;
        p.range = A0 || rangeOf(f, today, thisMonth);
        // a stretch held against itself says nothing: the stretch before it instead
        if (B0 && JSON.stringify(resolve(B0, today)) === JSON.stringify(resolve(p.range, today))) B0 = null;
        if (f.person2) { p.against = { person: f.person2 }; if (!f.named) p.range = thisMonth; }
        else if (f.merchant2) { p.against = { merchant: f.merchant2 }; if (!f.named) p.range = thisMonth; delete p.filters.merchants; }
        else p.against = B0 ? { range: B0 } : { prior: true };
        break;
      }
      case 'income': {
        if (f.reimb || f.usual) return { plan: null, why: 'said in words' };
        p.fact = 'income'; p.picture = 'figure';
        var fromWho = !!f.merchant && (!f.category || f.category === 'Refund');
        p.range = rangeOf(f, today, fromWho ? { kind: 'days', n: 365, label: 'in the last 12 months' } : thisMonth);
        break;
      }
      case 'invested': { p.fact = 'invested'; p.picture = 'figure'; p.range = rangeOf(f, today, { kind: 'year', back: 0 }); break; }
      case 'due': {
        var win = f.ahead && f.ahead.from ? f.ahead : { from: today, to: F.addDays(today, 30), words: 'in the next 30 days' };
        var st = Math.max(0, F.daysBetween(today, win.from)), nd = Math.max(1, F.daysBetween(win.from, win.to));
        p.fact = 'bills'; p.picture = nd >= 20 ? 'calendar' : 'timeline'; p.range = { kind: 'ahead', start: st, days: nd, label: win.words };
        // (what's due is cut by its own words, "EMI", "card", a bank: never by a kind of spending the ledger files)
        p.filters = {}; ['what', 'which', 'card'].forEach(function (k) { if (f[k]) p.filters[k] = f[k]; });
        if (f.next) p.sort = 'date';
        break;
      }
      case 'balances': { p.fact = 'balances'; p.picture = 'ranked'; p.by = 'account'; p.range = { kind: 'all' }; p.filters = p.filters.person ? { person: p.filters.person } : {}; break; }
      case 'wealth': {
        var nw = /\bnet ?worth\b|\bhow much (?:am i|are we) worth\b|\bwhat (?:am i|are we) worth\b|\btotal (?:assets|wealth)\b/.test(s);
        p.fact = nw ? 'networth' : 'holdings'; p.picture = nw ? 'figure' : 'split'; if (!nw) p.by = 'class'; p.range = { kind: 'all' };
        // what's held is cut only by whose it is (a kind of spending named beside it, "investments", is the question's word)
        p.filters = p.filters.person ? { person: p.filters.person } : {};
        break;
      }
      default:
        return { plan: null, why: f.act === 'none' || !f.act ? 'kosh couldn’t place it' : 'a question for words (' + f.act + ')', frame: keepFrame(f) };
    }
    p.frame = keepFrame(f);
    if (asked && asked !== p.picture && (FITS[p.fact] || []).indexOf(asked) >= 0) {
      p.picture = asked;
      if (asked === 'ranked' || asked === 'split') p.by = p.by || (BYS[p.fact] || [])[0]; else delete p.by;
      if (asked === 'trend' && (!p.range || p.range.kind === 'month')) p.range = { kind: 'months', n: 6 };
      if (asked === 'compare') p.against = { prior: true };
    }
    return done(p, 'rules');
    function done(plan, how) {
      plan.v = V;
      var c = checkPlan(plan, ctx);
      if (!c.ok) return { plan: null, why: c.errors.join('; '), how: how };
      return { plan: c.plan, how: how };
    }
  }

  /* ------------------------------------------------------------ the filler: a plan becomes figures */
  function frameOf(plan, span) {
    var f = JSON.parse(JSON.stringify(plan.filters || {}));
    if (f.merchants && f.merchants.length && !f.merchant) f.merchant = f.merchants[0];
    f.from = span.from; f.to = span.to; f.named = true; f.label = span.label || '';
    return f;
  }
  /* money in, as Ask kosh counts it: never money back on a payment (unless refunds are asked), never your own transfers
     (unless it's from someone named, or the family business's) */
  function incomeRows(ctx, f, span) {
    var fromWho = !!f.merchant && (!f.category || f.category === 'Refund');
    return (ctx.tx || []).filter(function (t) {
      return t.k === 'in' && (!t.ex || f.category === 'Refund') && (f.biz || fromWho || t.c !== 'Transfer in') && t.c !== 'Self Transfer' && F.within2(t, span, ctx.today) && F.fits(t, f, ctx);
    });
  }
  function investRows(ctx, f, span) { return (ctx.tx || []).filter(function (t) { return F.putIn(t) && t.a > 0 && t.s !== 'Chit fund' && F.within2(t, span, ctx.today) && F.fits(t, f, ctx); }); }
  /* the rows a plan is about, and the figure they come to (the month's rule: spending less the money back on it) */
  function rowsAndTotal(plan, ctx, f, span) {
    switch (plan.fact) {
      case 'spend': { var r = F.spentRows(ctx, f, span); return { rows: r, total: F.spentSum(ctx, f, span), back: F.backFor(ctx, f, span) }; }
      case 'paid': { var p = F.paidRows(ctx, f, span); return { rows: p, total: sumA(p), back: [] }; }
      case 'income': { var i = incomeRows(ctx, f, span); return { rows: i, total: sumA(i), back: [] }; }
      case 'invested': { var v = investRows(ctx, f, span); return { rows: v, total: sumA(v), back: [] }; }
      case 'payments': {
        var pr = f.dir === 'in' ? (ctx.tx || []).filter(function (t) { return t.k === 'in' && t.a > 0 && F.within2(t, span, ctx.today) && F.fits(t, f, ctx); }) : F.paidRows(ctx, f, span);
        return { rows: pr, total: sumA(pr), back: [] };
      }
    }
    return { rows: [], total: 0, back: [] };
  }
  function byDate(a, b) { return (b.d + (b.t || '')).localeCompare(a.d + (a.t || '')); }
  function byAmt(a, b) { return b.a - a.a; }
  function idsOf(rows) { return rows.slice(0, 400).map(function (t) { return t.id; }); }
  /* what a payment row is called on screen: its kind, and the card or account it went on */
  function rowSub(t) { return [t.c && t.c !== 'Money out' ? t.c : '', t.card || ''].filter(Boolean).join(' · '); }
  function personName(id, ctx) { if (!id || id === 'me') return 'You'; var p = (ctx.people || []).filter(function (x) { return x.id === id; })[0]; return p ? p.name : id; }
  // the stretch just before a stretch, the way Ask kosh holds a month so far against the same days of the month before
  function priorOf(span, today) {
    if (!span.from) return null;
    if (span.from.slice(8) === '01' && span.from.slice(0, 7) === span.to.slice(0, 7)) {
      var pm = F.addDays(span.from, -1), endB = pm.slice(0, 8) + span.to.slice(8);
      return { from: pm.slice(0, 8) + '01', to: span.to === F.monthEnd(span.from) || endB > pm ? pm : endB };
    }
    return F.before(span, today) || { from: F.addDays(span.from, -30), to: F.addDays(span.from, -1) };
  }

  function fill(plan, ctx, extra) {
    extra = extra || {};
    var today = ctx.today || '', span = resolve(plan.range, today), f = frameOf(plan, span);
    var o = { v: V, plan: plan, fact: plan.fact, picture: plan.picture, unit: plan.unit === 'count' ? 'count' : 'rupees', range: { from: span.from, to: span.to, words: span.label || F.spanWords(span, today), dates: datesLabel(span.from, span.to) },
      title: plan.title || '', answer: '', slots: {}, series: [], items: [], days: [], rows: [], source: '', blank: '', follow: [] };
    var S = o.slots, fd = F.firstDay(ctx);
    S.range = o.range.words;
    S.subject = plan.fact === 'holdings' || plan.fact === 'networth' || plan.fact === 'balances' || plan.fact === 'refunds' ? (plan.filters.person ? ' for ' + F.personWord(plan.filters.person) : '') : F.about(f, ctx);
    // a stretch kosh has no mail for is a blank, never a zero
    var ledgerFact = ['spend', 'paid', 'income', 'invested', 'payments'].indexOf(plan.fact) >= 0;
    if (ledgerFact && !fd) { o.blank = 'kosh hasn’t read any payments yet.'; return finish(o, plan); }
    if (ledgerFact && span.to && fd && span.to < fd) { o.blank = 'kosh’s mail starts on ' + dayLabel(fd) + ', so it can’t see ' + S.range.replace(/^in /, '') + '.'; return finish(o, plan); }
    if (ledgerFact && span.from && fd && span.from < fd && F.daysBetween(span.from, fd) >= 2) o.note = 'kosh’s mail goes back to ' + dayLabel(fd) + ', so this counts from then.';
    var pic = plan.picture;
    if (plan.fact === 'holdings') fillHoldings(o, plan, ctx);
    else if (plan.fact === 'networth') fillNetWorth(o, plan, ctx);
    else if (plan.fact === 'balances') fillBalances(o, plan, ctx);
    else if (plan.fact === 'bills') fillBills(o, plan, ctx, span, f);
    else if (plan.fact === 'refunds') fillRefunds(o, plan, ctx, extra);
    else if (pic === 'figure') fillFigure(o, plan, ctx, span, f);
    else if (pic === 'trend') fillTrend(o, plan, ctx, span, f);
    else if (pic === 'compare') fillCompare(o, plan, ctx, span, f);
    else if (pic === 'ranked' || pic === 'split') fillRanked(o, plan, ctx, span, f);
    else if (pic === 'timeline') fillTimeline(o, plan, ctx, span, f);
    else if (pic === 'calendar') fillCalendar(o, plan, ctx, span, f);
    return finish(o, plan);
  }

  function fillFigure(o, plan, ctx, span, f) {
    var S = o.slots, rt = rowsAndTotal(plan, ctx, f, span), today = ctx.today;
    o.rows = idsOf(rt.rows);
    S.count = n_(rt.rows.length, 'payment');
    if (plan.unit === 'count') {
      o.figure = { value: rt.rows.length, label: cap1(S.range), sub: rt.rows.length ? money(sumA(rt.rows)) + ' in all' : '' };
      S.count = rt.rows.length === 1 ? 'One payment' : rt.rows.length + ' payments';
      if (!rt.rows.length) o.blank = 'No payments' + S.subject + ' ' + S.range + '.';
      seriesTop(o, rt.rows, 'payee', ctx, 4);
      return;
    }
    S.total = money(rt.total);
    var backAmt = sumA(rt.back);
    o.figure = { value: r0(rt.total), label: cap1(S.range), sub: rt.rows.length ? S.count + (backAmt > 0 ? ', after ' + money(backAmt) + ' back' : '') : '' };
    if (!rt.rows.length) { o.blank = (plan.fact === 'income' ? 'Nothing came in' : plan.fact === 'invested' ? 'Nothing went into investments' : plan.fact === 'paid' ? 'Nothing paid' : 'Nothing spent') + S.subject + ' ' + S.range + '.'; return; }
    // against the same stretch before, when kosh's mail reaches it
    var b = plan.fact === 'invested' ? null : priorOf(span, today), fd = F.firstDay(ctx);
    if (b && b.from >= fd) {
      var pr = rowsAndTotal(plan, ctx, frameOf(plan, b), b).total, d = rt.total - pr, bw = F.beforeWords(b, span, today);
      if (pr > 0) {
        o.figure.delta = { value: r0(d), prev: r0(pr), words: bw, dates: datesLabel(b.from, b.to) };
        S.prev = money(pr); S.before = bw;
        S.change = Math.abs(d) < 1 ? 'the same as ' + bw : money(d) + (d > 0 ? ' more than ' : ' less than ') + bw;
      }
    }
    seriesTop(o, rt.rows, plan.fact === 'income' ? 'source' : 'payee', ctx, 4);
    if (o.series.length) { S.top = o.series[0].label; S.topValue = money(o.series[0].value); }
  }
  /* the biggest few under a figure, by payee or source (a list of payments: kept whole) */
  function seriesTop(o, rows, by, ctx, n) {
    var g = by === 'source' ? groupSource(rows) : F.groupBy(rows, 'payee', ctx);
    o.series = g.slice(0, n).map(function (x) { return { k: x.k, label: x.name, value: r0(x.v), n: x.n }; });
  }
  function groupSource(rows) {
    var g = {};
    rows.forEach(function (t) { var k = t.c && t.c !== 'Money in' ? t.c : t.m; (g[k] = g[k] || { k: k, name: k, v: 0, n: 0, rows: [] }); g[k].v += t.a; g[k].n++; g[k].rows.push(t); });
    return Object.keys(g).map(function (k) { return g[k]; }).sort(function (a, b) { return b.v - a.v; });
  }

  function fillTrend(o, plan, ctx, span, f) {
    var S = o.slots, today = ctx.today, tm = today.slice(0, 7), first = (F.firstDay(ctx) || today).slice(0, 7);
    var ms = [], m = span.from ? span.from.slice(0, 7) : first, last = (span.to || today).slice(0, 7);
    if (m < first) m = first;
    if (last > tm) last = tm;
    for (; m <= last && ms.length < 37; m = monthsBack(m, -1)) ms.push(m);
    var all = [];
    ms.forEach(function (mm) {
      var w = { from: mm + '-01', to: mm === tm ? today : F.monthEnd(mm + '-01') };
      var rt = rowsAndTotal(plan, ctx, frameOf(plan, w), w);
      all = all.concat(rt.rows);
      o.series.push({ k: mm, label: MON3[+mm.slice(5, 7) - 1] + (mm.slice(0, 4) !== tm.slice(0, 4) ? ' ' + mm.slice(2, 4) : ''), value: r0(rt.total), n: rt.rows.length, live: mm === tm, from: w.from, to: w.to });
    });
    o.rows = idsOf(all);
    var full = o.series.filter(function (x) { return !x.live; });
    if (!full.length && !o.series.length) { o.blank = 'Nothing' + S.subject + ' ' + S.range + ' to go by yet.'; return; }
    var usual = F.median(full.map(function (x) { return x.value; }));
    if (full.length) { o.usual = r0(usual); S.usual = money(usual); }
    var last = full[full.length - 1];
    if (last) { S.last = money(last.value); S.lastMonth = F.monthWord(last.k, today); }
    var hi = o.series.slice().sort(function (a, b) { return b.value - a.value; })[0], lo = full.slice().sort(function (a, b) { return a.value - b.value; })[0];
    if (hi && hi.value > 0) { S.high = money(hi.value); S.highMonth = F.monthWord(hi.k, today) + (hi.live ? ' so far' : ''); o.mark = hi.k; }
    if (lo) { S.low = money(lo.value); S.lowMonth = F.monthWord(lo.k, today); }
    S.total = money(o.series.reduce(function (a, x) { return a + x.value; }, 0));
    S.months = n_(o.series.length, 'month');
    S.count = n_(all.length, 'payment');
    if (!all.length) o.blank = 'Nothing' + S.subject + ' ' + S.range + '.';
  }

  function fillCompare(o, plan, ctx, span, f) {
    var S = o.slots, today = ctx.today, ag = plan.against || { prior: true }, A0 = span, B0, fA = f, fB = f, two = '';
    if (ag.person) { two = 'person'; B0 = A0; fA = Object.assign({}, f, { person2: undefined }); fB = Object.assign({}, fA, { person: ag.person }); }
    else if (ag.merchant) { two = 'payee'; B0 = A0; fA = Object.assign({}, f, { merchants: undefined }); fB = Object.assign({}, fA, { merchant: ag.merchant }); }
    else if (ag.range) {
      var rb = resolve(ag.range, today); B0 = { from: rb.from, to: rb.to, label: rb.label };
      // a month so far against a whole month: the same days of it, so the two are fair
      if (A0.to === today && A0.from.slice(8) === '01' && B0.from && B0.from.slice(8) === '01' && B0.to === F.monthEnd(B0.from) && A0.from.slice(0, 7) !== B0.from.slice(0, 7)) {
        var cutB = B0.from.slice(0, 8) + today.slice(8); if (cutB < B0.to) B0 = { from: B0.from, to: cutB, cut: true };
      }
      fB = frameOf(plan, B0);
    } else { B0 = priorOf(A0, today); fB = frameOf(plan, B0); }
    if (!B0) { o.blank = 'Nothing to hold ' + S.range + ' against.'; return; }
    var a = rowsAndTotal(plan, ctx, fA, A0), b = rowsAndTotal(plan, ctx, fB, B0), d = a.total - b.total;
    var aL = two === 'person' ? F.personWord(fA.person || 'me') : two === 'payee' ? F.payeeName(fA.merchant, ctx) : cap1(S.range);
    // (a stretch named for itself keeps its name; one cut to the same days, or the one before, is said as Ask kosh says it)
    var bL = two === 'person' ? F.personWord(ag.person) : two === 'payee' ? F.payeeName(ag.merchant, ctx) : (B0.label && !B0.cut ? B0.label.replace(/^in /, '') : F.beforeWords(B0, A0, today));
    o.compare = { a: { label: aL, value: r0(a.total), n: a.rows.length, dates: datesLabel(A0.from, A0.to) }, b: { label: bL, value: r0(b.total), n: b.rows.length, dates: datesLabel(B0.from, B0.to) }, diff: r0(d), pct: b.total > 0 ? Math.round(Math.abs(d) / b.total * 100) : null };
    S.a = money(a.total); S.b = money(b.total); S.aLabel = aL; S.bLabel = bL; S.diff = Math.abs(d) < 1 ? 'the same as' : money(d); S.more = Math.abs(d) < 1 ? '' : d > 0 ? 'more than' : 'less than';
    if (Math.abs(d) < 1) S.diff = 'the same as';
    if (b.total > 0 && Math.abs(d) >= 1) S.pct = (d > 0 ? 'up ' : 'down ') + o.compare.pct + '%';
    S.count = n_(a.rows.length, 'payment');
    o.rows = idsOf(a.rows);
    if (a.total < 1 && b.total < 1) { o.blank = 'Nothing' + S.subject + ' ' + (two ? S.range : S.range + ', or ' + bL) + '.'; return; }
    // what moved most, by kind (or by payee within one kind), each less the money back on it, as the months take it
    if (!two) {
      var key = f.category ? 'payee' : 'category';
      var gA = F.groupBy(a.rows, key, ctx), gB = F.groupBy(b.rows, key, ctx);
      if (key === 'category') { gA = F.lessBack(gA, a.back, 'category'); gB = F.lessBack(gB, b.back, 'category'); }
      var mapB = {}; gB.forEach(function (x) { mapB[x.k] = x; });
      var ch = gA.map(function (x) { return { k: x.k, label: x.name, a: x.v, b: mapB[x.k] ? mapB[x.k].v : 0 }; });
      gB.forEach(function (x) { if (!gA.some(function (y) { return y.k === x.k; })) ch.push({ k: x.k, label: x.name, a: 0, b: x.v }); });
      ch = ch.map(function (x) { return { k: x.k, label: x.label, a: r0(x.a), b: r0(x.b), d: r0(x.a - x.b) }; }).filter(function (x) { return Math.abs(x.d) >= 1; }).sort(function (x, y) { return Math.abs(y.d) - Math.abs(x.d); }).slice(0, 5);
      o.series = ch.map(function (x) { return { k: x.k, label: x.label, value: x.a, prev: x.b, delta: x.d }; });
      if (ch.length) { S.moved = ch[0].label; S.movedBy = (ch[0].d > 0 ? 'up ' : 'down ') + money(ch[0].d); }
    }
  }

  function fillRanked(o, plan, ctx, span, f) {
    var S = o.slots, by = plan.by, fr = by === 'method' ? Object.assign({}, f, { method: '' }) : f, today = ctx.today, gs, tot, base;
    if (plan.fact === 'income') {
      base = incomeRows(ctx, fr, span);
      gs = by === 'month' ? F.groupBy(base, 'month', ctx) : by === 'person' ? F.groupBy(base, 'person', ctx) : groupSource(base);
      tot = sumA(base);
    } else if (plan.fact === 'invested') {
      base = investRows(ctx, fr, span); gs = F.groupBy(base, by === 'month' ? 'month' : 'payee', ctx); tot = sumA(base);
    } else {
      base = by === 'payee' || plan.fact === 'paid' ? F.paidRows(ctx, fr, span) : F.spentRows(ctx, fr, span);
      if (by === 'card' && base.some(function (t) { return t.md === 'card'; })) base = base.filter(function (t) { return t.md === 'card'; });
      if (by === 'payee' && plan.filters.shops) base = base.filter(function (t) { return !F.isPerson(lc(t.m).trim(), ctx); });
      gs = F.groupBy(base, by, ctx); tot = sumA(base);
      // by kind, person or month: each less the money back on it, as Home's month and Insights take it off
      if ((by === 'category' || by === 'person' || by === 'month') && plan.fact === 'spend') {
        var back = F.backFor(ctx, fr, span);
        gs = F.lessBack(gs, back, by); tot = Math.max(0, tot - sumA(back));
      }
    }
    if (plan.order === 'asc') gs = gs.slice().reverse();
    o.rows = idsOf(base);
    S.count = n_(base.length, 'payment'); S.total = money(tot); S.n = String(gs.length);
    if (!gs.length) { o.blank = 'Nothing' + S.subject + ' ' + S.range + ' to go by yet.'; return; }
    var top = plan.top || (plan.picture === 'split' ? 6 : 8);
    var shown = gs.slice(0, top).map(function (x) { return { k: x.k, label: x.name, value: r0(x.v), n: x.n, share: tot > 0 ? Math.round(x.v / tot * 100) : 0 }; });
    if (gs.length > top) {
      var rest = gs.slice(top), rv = rest.reduce(function (a, x) { return a + x.v; }, 0);
      if (plan.picture === 'split') shown.push({ k: '__rest', label: n_(rest.length, 'other') + ' together', value: r0(rv), n: rest.reduce(function (a, x) { return a + x.n; }, 0), share: tot > 0 ? Math.round(rv / tot * 100) : 0, rest: true });
      else o.more = rest.length;
    }
    o.series = shown; o.total = r0(tot);
    S.top = shown[0].label; S.topValue = money(shown[0].value); S.share = shown[0].share + '%';
  }

  function fillTimeline(o, plan, ctx, span, f) {
    var S = o.slots, rt = rowsAndTotal(plan, ctx, f, span), today = ctx.today;
    var rows = rt.rows.slice().sort(plan.sort === 'amount' ? byAmt : byDate);
    if (plan.order === 'asc') rows.reverse();
    var lim = plan.top || 12;
    o.items = rows.slice(0, lim).map(function (t) { return { id: t.id, d: t.d, title: t.m, sub: rowSub(t), value: r0(t.a), dir: t.k === 'in' ? 'in' : 'out', when: F.on(t.d, today) }; });
    o.more = Math.max(0, rows.length - lim);
    o.rows = idsOf(rows);
    S.n = String(rows.length); S.count = rows.length === 1 ? 'One payment' : rows.length + ' payments'; S.total = money(sumA(rows));
    if (!rows.length) { o.blank = 'No payments' + S.subject + ' ' + S.range + '.'; return; }
    S.first = rows[0].m; S.firstValue = money(rows[0].a); S.firstDate = F.on(rows[0].d, today);
  }

  function fillCalendar(o, plan, ctx, span, f) {
    var S = o.slots, rt = rowsAndTotal(plan, ctx, f, span), by = {};
    rt.rows.forEach(function (t) { var k = t.d.slice(0, 10); (by[k] = by[k] || { v: 0, n: 0 }); by[k].v += t.a; by[k].n++; });
    for (var d = span.from || (F.firstDay(ctx) || ctx.today); d && d <= span.to && o.days.length < 93; d = F.addDays(d, 1)) o.days.push({ d: d, value: r0(by[d] ? by[d].v : 0), n: by[d] ? by[d].n : 0 });
    o.rows = idsOf(rt.rows);
    S.total = money(rt.total); S.count = n_(rt.rows.length, 'payment'); S.n = String(rt.rows.length); S.days = n_(o.days.filter(function (x) { return x.n; }).length, 'day');
    o.figure = { value: r0(rt.total), label: cap1(S.range) };
    // a day's sum is its payments whole; the money back comes off the stretch's total only
    var backAmt = sumA(rt.back);
    if (backAmt > 0) o.note = (o.note ? o.note + ' ' : '') + money(backAmt) + ' came back on these, so the days add to more than the total.';
    if (!rt.rows.length) { o.blank = 'Nothing' + S.subject + ' ' + S.range + '.'; return; }
    var peak = o.days.slice().sort(function (a, b) { return b.value - a.value; })[0];
    if (peak && peak.value > 0) { S.peak = money(peak.value); S.peakDay = F.on(peak.d, ctx.today); o.mark = peak.d; }
  }

  function fillBills(o, plan, ctx, span, f) {
    var S = o.slots, today = ctx.today, fits = F.dueFilter(f, ctx);
    var dated = (ctx.agenda || []).concat(F.loanDue(ctx, today)).filter(function (x) { return x.date && x.date >= span.from && x.date <= span.to && x.date >= today && fits(x); })
      .sort(function (a, b) { return a.date.localeCompare(b.date); });
    var outs = dated.filter(function (x) { return x.kind !== 'in'; }), open = outs.filter(function (x) { return !x.booked; });
    var tot = open.reduce(function (a, x) { return a + (+x.amt || 0); }, 0);
    o.items = dated.slice(0, 30).map(function (x) { return { d: x.date, title: x.name, sub: x.sub && !/learnt|from your mail/i.test(x.sub) ? x.sub : (x.cat || ''), value: r0(x.amt), dir: x.kind === 'in' ? 'in' : 'out', state: x.booked ? 'paid' : 'due', when: F.on(x.date, today) }; });
    S.n = n_(outs.length, 'bill'); S.count = S.n; S.total = money(tot);
    o.figure = { value: r0(tot), label: cap1(S.range), sub: n_(open.length, 'bill') + ' still to pay' };
    if (plan.picture === 'calendar') {
      var by = {};
      dated.forEach(function (x) { if (x.kind !== 'in' && !x.booked) { by[x.date] = (by[x.date] || 0) + (+x.amt || 0); } });
      for (var d = span.from; d <= span.to && o.days.length < 125; d = F.addDays(d, 1)) o.days.push({ d: d, value: r0(by[d] || 0), n: dated.filter(function (x) { return x.date === d && x.kind !== 'in'; }).length });
      var pk = o.days.slice().sort(function (a, b) { return b.value - a.value; })[0];
      if (pk && pk.value > 0) { S.peak = money(pk.value); S.peakDay = F.on(pk.d, today); o.mark = pk.d; }
    }
    if (!outs.length) { o.blank = 'Nothing due ' + S.range + '.'; return; }
    var nx = open[0];
    if (nx) { S.next = nx.name; S.nextValue = money(nx.amt); S.nextDate = F.on(nx.date, today); S.first = nx.name; S.firstValue = S.nextValue; S.firstDate = S.nextDate; }
  }

  /* the Refunds list (snap.refunds): what's still to come back on each, by the stage it's at */
  function fillRefunds(o, plan, ctx, extra) {
    var S = o.slots, today = ctx.today;
    var rf = (extra.refunds || []).filter(function (r) { var left = Math.max(0, (+r.exp || +r.a || 0) - (+r.back || 0)); return r.state !== 'back' && left > 0.5 && (!plan.filters.person || (r.o || 'me') === (plan.filters.person === 'me' ? 'me' : r.o)); });
    rf.sort(function (a, b) { return String(a.d).localeCompare(String(b.d)); });
    var left = function (r) { return Math.max(0, (+r.exp || +r.a || 0) - (+r.back || 0)); };
    var tot = rf.reduce(function (a, r) { return a + left(r); }, 0);
    o.items = rf.map(function (r) {
      return { id: r.id, d: r.d, title: r.m, sub: (r.stage === 'sent' ? 'the shop says it sent it' : r.stage === 'promised' ? 'the shop promised it' : r.state === 'part' ? 'part came back' : 'waiting') + (r.by ? ', due by ' + F.on(r.by, today) : ''),
        value: r0(left(r)), dir: 'in', state: r.state === 'late' ? 'late' : r.state === 'part' ? 'part' : 'waiting', when: F.on(r.d, today), paid: r0(r.a) };
    });
    o.range = { from: '', to: today, words: 'still open', dates: 'as of ' + dayLabel(today) };
    S.range = 'still open';
    S.n = n_(rf.length, 'refund'); S.count = S.n; S.total = money(tot);
    o.figure = { value: r0(tot), label: 'Still to come back', sub: S.n };
    o.rows = rf.map(function (r) { return r.id; });
    if (!rf.length) { o.blank = 'No refund is waiting: every one kosh tracks has come back.'; return; }
    S.first = rf[0].m; S.firstValue = money(left(rf[0])); S.firstDate = F.on(rf[0].d, today);
  }

  var CLASS = { dep: 'Deposits', stk: 'Stocks', mf: 'Mutual funds', ret: 'Retirement', gold: 'Gold', bank: 'Bank', ins: 'Insurance savings' };
  /* what's held, as the wealth lookup counts it (agent.js runTool 'wealth'), by kind or by person */
  function holdingsOf(plan, ctx) {
    var who = plan.filters.person;
    return (ctx.hold || []).filter(function (h) { return !who || personMatch(h.person || h.owner, who, ctx); });
  }
  function personMatch(id, who, ctx) { if (!who) return true; var w = who === 'me' ? 'me' : ((ctx.people || []).filter(function (p) { return p.name === who; })[0] || {}).id; return (id || 'me') === w; }
  function fillHoldings(o, plan, ctx) {
    var S = o.slots, hs = holdingsOf(plan, ctx), g = {}, tot = 0;
    hs.forEach(function (h) { var k = plan.by === 'person' ? (h.person || 'me') : h.cls; (g[k] = g[k] || { v: 0, n: 0 }); g[k].v += +h.amt || 0; g[k].n++; tot += +h.amt || 0; });
    o.series = Object.keys(g).map(function (k) { return { k: k, label: plan.by === 'person' ? personName(k, ctx) : CLASS[k] || k, value: r0(g[k].v), n: g[k].n, share: tot > 0 ? Math.round(g[k].v / tot * 100) : 0 }; }).sort(function (a, b) { return b.value - a.value; });
    o.total = r0(tot); S.total = money(tot); S.n = String(o.series.length); S.count = n_(hs.length, 'holding');
    o.figure = { value: r0(tot), label: 'Held today' };
    o.range = { from: '', to: ctx.today, words: 'as kosh last read each', dates: 'as of ' + dayLabel(ctx.today) };
    S.range = 'as kosh last read each';
    if (!hs.length) { o.blank = 'kosh hasn’t read any holdings yet: a fund or demat statement in your mail brings them in.'; return; }
    S.top = o.series[0].label; S.topValue = money(o.series[0].value); S.share = o.series[0].share + '%';
  }
  /* net worth as Home counts it (agent.js's wealth lookup gives the figure; its parts are laid out beside it) */
  function fillNetWorth(o, plan, ctx) {
    var S = o.slots, who = plan.filters.person, w = A.runTool('wealth', who ? { person: who } : {}, ctx), net = w && w.data ? +w.data.net : NaN;
    var mine = !who || personMatch('me', who, ctx);
    var acs = (ctx.accounts || []).filter(function (x) { return x.balance !== null && x.balance !== undefined && isFinite(+x.balance) && (!who || personMatch(x.owner || 'me', who, ctx)); });
    var bank = acs.reduce(function (a, x) { return a + (+x.balance); }, 0), held = holdingsOf(plan, ctx).reduce(function (a, h) { return a + (+h.amt || 0); }, 0);
    var cash = mine ? +ctx.cashInHand || 0 : 0, land = mine ? +ctx.land || 0 : 0;
    var loans = mine ? (ctx.loans || []).filter(function (l) { return l.active !== false; }).reduce(function (a, l) { return a + (+l.outstanding || 0); }, 0) : 0;
    o.range = { from: '', to: ctx.today, words: 'as Home counts it', dates: 'as of ' + dayLabel(ctx.today) };
    S.range = 'as Home counts it';
    if (!isFinite(net) || (!acs.length && !held && !loans)) { o.blank = 'kosh doesn’t know enough for a net worth yet: a balance alert, a fund statement or a loan brings it in.'; return; }
    // (the parts must make the lookup's figure, or kosh shows the figure alone)
    var parts = [{ k: 'bank', label: 'In the bank', value: r0(bank) }, { k: 'held', label: 'Invested', value: r0(held) }, { k: 'cash', label: 'Cash at home', value: r0(cash) }, { k: 'land', label: 'Land', value: r0(land) }, { k: 'loans', label: 'Loans left', value: -r0(loans) }]
      .filter(function (x) { return Math.abs(x.value) >= 1; });
    if (Math.abs(parts.reduce(function (a, x) { return a + x.value; }, 0) - net) <= 1) o.series = parts;
    o.figure = { value: r0(net), label: 'Net worth today', signed: true, sub: 'card bills aren’t taken off' };
    o.total = r0(net); S.total = (net < 0 ? '−' : '') + money(net);
  }
  function fillBalances(o, plan, ctx) {
    var S = o.slots, acs = (ctx.accounts || []).filter(function (x) { return x.balance !== null && x.balance !== undefined && isFinite(+x.balance) && (!plan.filters.person || personMatch(x.owner || 'me', plan.filters.person, ctx)); });
    var tot = acs.reduce(function (a, x) { return a + (+x.balance); }, 0);
    o.series = acs.map(function (x) { return { k: x.name + x.last, label: (x.nick || x.name || x.bank) + (x.last ? ' ••' + x.last : ''), value: r0(+x.balance), sub: x.asOf ? 'as of ' + F.on(String(x.asOf).slice(0, 10), ctx.today) : '', share: tot > 0 ? Math.round(+x.balance / tot * 100) : 0 }; }).sort(function (a, b) { return b.value - a.value; });
    o.total = r0(tot); S.total = money(tot); S.n = String(acs.length); S.count = n_(acs.length, 'account');
    o.figure = { value: r0(tot), label: 'In your bank accounts' };
    o.range = { from: '', to: ctx.today, words: 'each as of its last balance', dates: 'as of each account’s last balance' };
    S.range = 'each as of its last balance';
    if (!acs.length) { o.blank = 'kosh doesn’t know any bank balance yet: a balance alert or a statement brings it in.'; return; }
    S.top = o.series[0].label; S.topValue = money(o.series[0].value); S.share = o.series[0].share + '%';
  }

  /* the answer line, its slots filled: an [ … ] part goes when a slot in it is blank; a line whose own slot is blank
     gives way to kosh's default line for the picture, and a blank fill says why it's blank */
  function render(tpl, S) {
    // (a slot filled with nothing, as {subject} is for all spending, is filled; one never worked out is blank)
    var blank = function (k) { return S[k] === undefined || S[k] === null; };
    var t = String(tpl || '').replace(/\[([^\[\]]*)\]/g, function (m, inner) { return slotsIn(inner).some(blank) ? '' : inner; });
    if (slotsIn(t).some(blank)) return null;
    return t.replace(/\{(\w+)\}/g, function (m, k) { return String(S[k]); }).replace(/\s+([,.])/g, '$1').replace(/\s{2,}/g, ' ').trim();
  }
  function finish(o, plan) {
    if (o.blank) o.answer = o.blank;
    else o.answer = render(plan.answer, o.slots) || render(defaultAnswer(plan), o.slots) || '';
    o.answer = cap1(o.answer);
    if (!o.title) o.title = titleOf(plan, o);
    o.source = sourceOf(plan, o);
    o.follow = followOf(plan, o);
    return o;
  }
  function titleOf(p, o) {
    var subj = (o.slots.subject || '').trim();
    var what = { spend: 'Spending', paid: 'Paid', income: 'Money in', invested: 'Invested', holdings: 'Holdings', networth: 'Net worth', balances: 'Bank balances', bills: 'Coming up', refunds: 'Refunds on their way', payments: 'Payments' }[p.fact] || 'kosh';
    var by = p.by && (p.picture === 'ranked' || p.picture === 'split') ? ' by ' + ({ payee: 'payee', category: 'kind', person: 'person', card: 'card', method: 'way paid', weekday: 'day of the week', month: 'month', class: 'kind', account: 'account', source: 'source' }[p.by] || p.by) : '';
    var t = what + (subj && subj.length < 34 ? ' ' + subj : '') + by + (p.picture === 'trend' ? ', month by month' : p.picture === 'compare' ? ', compared' : '');
    return t.replace(/\d/g, '').slice(0, 60);
  }
  function sourceOf(p, o) {
    var from = { spend: 'your bank, card and UPI mail', paid: 'your bank, card and UPI mail', income: 'credits in your bank mail', invested: 'your bank and broker mail', payments: 'your bank, card and UPI mail',
      holdings: 'your fund, demat and deposit statements', networth: 'balances, holdings and loans kosh has read', balances: 'balance alerts and statements', bills: 'bills and dues in your mail, and repeats kosh learned', refunds: 'shops’ refund mail and your bank’s credits' }[p.fact] || 'your mail';
    return 'From ' + from + ' · ' + (o.range.dates || o.range.words) + (o.rows && o.rows.length ? ' · ' + n_(o.rows.length, p.fact === 'refunds' ? 'refund' : p.fact === 'bills' ? 'item' : 'payment') : '');
  }
  function followOf(p, o) {
    if (o.blank && p.fact !== 'refunds') return ['How much have I spent this month?', 'What’s due this week?'];
    var subj = !!(p.filters.category || p.filters.merchant || p.filters.person);
    switch (p.picture) {
      case 'figure': return p.fact === 'networth' ? ['What are my investments worth?', 'Bank balances'] : p.fact === 'refunds' ? ['Show them as a list'] : ['Month by month', subj ? 'Show these payments' : 'Split by category', 'Compare with last month'];
      case 'trend': return ['Split by category', 'Compare with last month', 'As a calendar'];
      case 'compare': return ['Month by month', 'Split by category', 'Show these payments'];
      case 'ranked': case 'split': return p.fact === 'holdings' ? ['What’s my net worth?'] : ['Show these payments', 'Month by month', p.by === 'category' ? 'Who did I pay the most?' : 'Split by category'];
      case 'timeline': return p.fact === 'bills' ? ['Can I cover what’s due this week?', 'As a calendar'] : ['Split by category', 'As a calendar', 'Month by month'];
      case 'calendar': return p.fact === 'bills' ? ['Show them as a list'] : ['Show these payments', 'Split by category'];
    }
    return [];
  }

  /* what the on-device model may name: the household's own kinds, people, payees and cards (it never sees a figure) */
  function vocab(ctx) {
    var cats = {}, payees = {};
    (ctx.tx || []).forEach(function (t) { if (t.sp && t.k === 'out') { if (t.c) cats[t.c] = (cats[t.c] || 0) + 1; var m = String(t.m || '').trim(); if (m) payees[m] = (payees[m] || 0) + 1; } });
    var top = function (o, n) { return Object.keys(o).sort(function (a, b) { return o[b] - o[a]; }).slice(0, n); };
    return { today: ctx.today, categories: top(cats, 30), payees: top(payees, 40), people: (ctx.people || []).map(function (p) { return p.id === 'me' ? 'me' : p.name; }),
      cards: (ctx.cards || []).map(function (c) { return c.name; }).slice(0, 12), facts: FACTS, pictures: PICTURES, fits: FITS, bys: BYS, slots: SLOTS, slotsAll: SLOTS_ALL };
  }

  /* one go: the rule planner's plan and its fill */
  function view(q, ctx, extra, prev) {
    var pl = planOf(q, ctx, prev);
    if (!pl.plan) return { plan: null, why: pl.why, how: pl.how || 'rules' };
    return { plan: pl.plan, how: pl.how, fill: fill(pl.plan, ctx, extra) };
  }

  function parse(s, d) { try { return s ? JSON.parse(s) : d; } catch (e) { return d; } }
  var api = {
    V: V, FACTS: FACTS, PICTURES: PICTURES, FITS: FITS, BYS: BYS, SLOTS: SLOTS, SLOTS_ALL: SLOTS_ALL,
    planOf: planOf, checkPlan: checkPlan, fill: fill, view: view, resolve: resolve, relRange: relRange, render: render, vocab: vocab, defaultAnswer: defaultAnswer,
    liveViewPlanJSON: function (q, ctx, prev) { var o; try { o = planOf(q || '', parse(ctx, {}), parse(prev, null)); } catch (e) { o = { plan: null, why: 'error: ' + (e && e.message || e) }; } return JSON.stringify(o); },
    liveViewCheckJSON: function (plan, ctx) { var o; try { o = checkPlan(parse(plan, null), parse(ctx, {})); } catch (e) { o = { ok: false, errors: ['error: ' + (e && e.message || e)] }; } return JSON.stringify(o); },
    liveViewFillJSON: function (plan, ctx, extra) {
      var o;
      try {
        var c = checkPlan(parse(plan, null), parse(ctx, {}));
        o = c.ok ? fill(c.plan, parse(ctx, {}), parse(extra, {})) : { v: V, error: c.errors.join('; ') };
      } catch (e) { o = { v: V, error: String(e && e.message || e) }; }
      return JSON.stringify(o);
    },
    liveViewJSON: function (q, ctx, extra, prev) { var o; try { o = view(q || '', parse(ctx, {}), parse(extra, {}), parse(prev, null)); } catch (e) { o = { plan: null, why: 'error: ' + (e && e.message || e) }; } return JSON.stringify(o); },
    liveViewVocabJSON: function (ctx) { return JSON.stringify(vocab(parse(ctx, {}))); },
  };
  for (var k in api) if (Object.prototype.hasOwnProperty.call(api, k) && /JSON$/.test(k)) E[k] = api[k];
  return api;
})(typeof KoshEngine !== 'undefined' ? KoshEngine : require('./engine.js'), typeof KoshAgent !== 'undefined' ? KoshAgent : require('./agent.js'));
if (typeof module !== 'undefined' && module.exports) module.exports = KoshLiveView;
