import Foundation
import PDFKit

// MARK: - Dev only: the statements themselves, for the statement test bench on the Mac
//
// The readers of bank, card, investment and insurance papers had no corpus: every fix was a guess made without the
// file (3 Nov, STATEMENTS-PLAN v2). Once per `token`, after the statements have been opened, this writes the PDFs
// kosh already knows about to Documents/stmt-export/ — the file exactly as the inbox gave it, the password that opens
// it (when one of the sender's saved ones does), the text kosh kept from it, and a manifest.json — and the Mac's
// autobuild ("stmts-<n>" in .build/pull) copies the folder to _corpus/stmts/phone/ (private: never the repo).
// Which: every bank/card statement of the last 13 months (so month N's closing can be checked against N+1's
// opening), one a year before that (layouts change), the newest two holdings statements per sender, and every policy
// and other paper. Nothing is sent anywhere; the folder is on the phone until the Mac copies it.
extension LiveSession {
    static let stmtExportToken = "stmts-3nov-a"
    static let stmtExportKey = "dev.stmtExportDone"
    static var stmtExportFolder: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("stmt-export", isDirectory: true)
    }

    struct StmtExportRow: Codable {
        var file: String; var msg: String; var from: String; var sent: String; var kind: String
        var name: String; var subject: String; var state: String; var note: String
        var password: String?; var locked: Bool; var text: String?; var bytes: Int
    }

    @MainActor
    func exportStatementsOnce() async {
        #if DEBUG
        guard UserDefaults.standard.string(forKey: Self.stmtExportKey) != Self.stmtExportToken else { return }
        let fm = FileManager.default
        let dir = Self.stmtExportFolder
        try? fm.removeItem(at: dir)
        try? fm.createDirectory(at: dir, withIntermediateDirectories: true)
        let cutoff: String = {
            let f = DateFormatter(); f.dateFormat = "yyyy-MM-dd"; f.locale = Locale(identifier: "en_US_POSIX")
            return f.string(from: Calendar.current.date(byAdding: .month, value: -13, to: Date()) ?? Date())
        }()
        // pick what to export
        var picked: [Int] = []
        var perYear = Set<String>(), casCount: [String: Int] = [:]
        let order = records.indices.sorted { (records[$0].sent ?? "") > (records[$1].sent ?? "") }
        for i in order {
            guard let d = records[i].doc, d.kind != "order", d.att != "body" else { continue }
            let file = d.file.lowercased()
            guard file.hasSuffix(".pdf") || file == "pdf" || DocLocked.isZip(d.file) else { continue }
            let sent = records[i].sent ?? ""
            let dom = SenderPasswords.domain(d.from)
            switch d.kind {
            case "stmt", "cardstmt":
                if sent >= cutoff { picked.append(i) }
                else if perYear.insert(dom + "|" + d.kind + "|" + String(sent.prefix(4))).inserted { picked.append(i) }
            case "cas":
                let n = casCount[dom, default: 0]
                if n < 2 { picked.append(i); casCount[dom] = n + 1 }
            default:
                picked.append(i)
            }
        }
        note("stmt-export: \(picked.count) papers")
        var rows: [StmtExportRow] = []
        var n = 0
        for i in picked {
            guard i < records.count, var d = records[i].doc else { continue }
            let r = records[i]
            guard let bytes = try? await docBytes(&d) else { continue }
            n += 1
            let dom = SenderPasswords.domain(d.from)
            let ext = DocLocked.isZip(d.file) ? "zip" : "pdf"
            let name = String(format: "%04d", n) + "_" + dom + "_" + d.kind + "_" + (r.sent ?? "") + "." + ext
            try? bytes.write(to: dir.appendingPathComponent(name))
            let list = SenderPasswords.every(d.from)
            let file = d.file
            let locked: Bool = ext == "pdf" ? (PDFDocument(data: bytes)?.isLocked ?? false) : true
            let pw: String? = locked && !list.isEmpty ? await Task.detached(priority: .utility) { DocUnlock.firstPassword(bytes, list, file: file) }.value : nil
            let kept = MailVault.getText(Self.docTextKey(d))
            rows.append(StmtExportRow(file: name, msg: d.msg, from: d.from, sent: r.sent ?? "", kind: d.kind, name: d.file,
                                      subject: r.subject ?? "", state: d.state, note: d.note ?? "", password: pw, locked: locked,
                                      text: kept, bytes: bytes.count))
            if n % 20 == 0 { note("stmt-export: \(n) of \(picked.count)") }
        }
        let enc = JSONEncoder(); enc.outputFormatting = [.prettyPrinted, .sortedKeys]
        if let data = try? enc.encode(rows) { try? data.write(to: dir.appendingPathComponent("manifest.json")) }
        UserDefaults.standard.set(Self.stmtExportToken, forKey: Self.stmtExportKey)
        note("stmt-export: done, \(rows.count) written")
        #endif
    }
}
