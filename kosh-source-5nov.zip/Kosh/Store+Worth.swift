import SwiftUI
import UIKit
import Observation

// MARK: - The store: what's ahead, and what each person owns and owes: committees, property, holdings, net worth
// (split out of Store.swift, 30 Oct 2026; the stored state stays in the class there)

extension Store {
    // ahead
    var datedAhead: [AgendaItem] { figures.datedAhead }
    func anyDay(_ m: String) -> [AgendaItem] {
        snap.agenda.filter { $0.date == nil && $0.m == m }.sorted { a, b in
            if a.kind != b.kind { return a.kind == "in" }
            return a.amt > b.amt
        }
    }
    var stillOut: Double { figures.stillOut }
    var stillIn: Double { figures.stillIn }
    var liveCommittees: [Committee] { snap.comm.filter { !$0.done } }

    // whose: properties and committees by the person picked (a joint one shows for each of its holders). The
    // household's (no one person named) show only under Family, and are counted on the note that says so
    func committees(_ p: Person) -> [Committee] { p == .family ? snap.comm : snap.comm.filter { ($0.whose ?? []).contains(p.id) } }
    func commMonths(_ p: Person) -> [CommMonth] { p == .family ? (snap.commMonths ?? []) : (snap.commWho?[p.id] ?? []) }
    func properties(_ p: Person) -> [Prop] { p == .family ? snap.prop.props : snap.prop.props.filter { ($0.whose ?? []).contains(p.id) } }
    /// the property book as the picker shows it: the household's whole, or one person's part of it
    func propBook(_ p: Person) -> PropertyBook {
        let P = snap.prop
        guard p != .family else { return P }
        let s = P.byWho?[p.id]
        return PropertyBook(fy: P.fy, rent: s?.rent ?? 0, tax: s?.tax ?? 0, arrears: s?.arrears ?? 0, due: s?.tax ?? 0, props: properties(p), events: [],
                            worth: s?.worth ?? 0, taxLoose: nil, rentLoose: nil, byWho: P.byWho)
    }
    /// the note under a tab while one person is picked: what it shows, and how many are the household's alone
    func whoseNote(_ p: Person, total: Int, theirs: Int, open: Int, thing: (one: String, many: String)) -> String? {
        guard p != .family, total > 0 else { return nil }
        let name: String = p == .me ? "your" : p.title + "’s"
        var line: String = theirs == 0 ? "No \(thing.many) in \(name) name." : "Only the \(thing.many) in \(name) name; a joint one at \(p == .me ? "your" : "their") share."
        if open > 0 { line += " \(Words.cap(Words.number(open))) \(open == 1 ? thing.one + " isn’t" : thing.many + " aren’t") in anyone’s name yet: only under Family." }
        return line
    }

    /// the tab bar made from what the mail showed, after setup: Home, Transactions and Portfolio, then policies,
    /// properties, committees, loans and more than one person where kosh found them; four or five in all
    var foundTabs: [AppTab] {
        var out: [AppTab] = [.home, .transactions, .portfolio]
        if !snap.policies.isEmpty { out.append(.insurance) }
        if !snap.prop.props.isEmpty { out.append(.property) }
        if !liveCommittees.isEmpty { out.append(.committees) }
        if !snap.loans.isEmpty { out.append(.loans) }
        if snap.people.count > 1 { out.append(.people) }
        out = Array(out.prefix(5))
        for t in [AppTab.insurance, .people, .chapters] where out.count < AppTab.fewest && !out.contains(t) { out.append(t) }
        return out
    }
    func committee(_ id: String?) -> Committee? { snap.comm.first { $0.id == id } }

    /// The longer view: premiums, maturities, lease ends and rent rises, a year out
    var laterDue: [DueItem] {
        let end = Day.add(snap.today, 400)
        var out: [DueItem] = []
        for p in snap.policies where who.owns(p.owner) && p.nextDue >= snap.today && p.nextDue <= end {
            out.append(DueItem(id: "pol" + p.id, date: p.nextDue, title: "\(p.insurer) premium", sub: (p.type == "Policy" ? "Insurance" : "\(p.type) insurance") + " · premium " + p.premiumEvery, amount: p.premium, incoming: false, sym: "shield.lefthalf.filled", color: Color.green))
        }
        for h in holdings(who) where (h.type == "FD") {
            if let m = h.mat, m >= snap.cm {
                out.append(DueItem(id: "fd" + h.id, date: m + "-01", title: "\(h.bank) matures", sub: h.rate > 0 ? "FD at \(Fmt.trim(h.rate, 2))%" : "Fixed deposit", amount: h.amt, incoming: true, sym: "lock.open.fill", color: Color(hex: "#007AFF")))
            }
        }
        for e in snap.prop.events where e.m >= snap.cm && e.kind != "tax" {
            let d = e.m + "-01"
            if d <= end {
                out.append(DueItem(id: "ev" + e.id, date: d, title: e.what, sub: e.detail, amount: 0, incoming: e.kind == "up", sym: e.kind == "up" ? "arrow.up.right" : "doc.text.fill", color: e.kind == "up" ? Color.green : Color.kosh))
            }
        }
        return out.sorted { $0.date < $1.date }
    }

    // wealth
    func holdings(_ p: Person) -> [Holding] { figures.holdings(p) }
    /// the yearly return over one kind of holding ("mf", "dep"…) or all of them ("all"), whoever's they are
    func yearly(_ p: Person, _ cls: String) -> HoldReturn? { snap.rets?[p.rawValue + "|" + cls] }
    func classes(_ p: Person) -> [ClassSum] {
        let h = holdings(p)
        let defs: [(String, String, Color, String)] = [
            ("dep", "Deposits", Color(hex: "#007AFF"), "building.columns.fill"),
            ("stk", "Stocks", Color(hex: "#34C759"), "chart.line.uptrend.xyaxis"),
            ("mf", "Mutual funds", Color(hex: "#30B0C7"), "chart.pie.fill"),
            ("ret", "Retirement", Color(hex: "#FF9500"), "lock.fill"),
            ("gold", "Physical gold", Color(hex: "#D4A017"), "seal.fill"),
            ("ins", "Insurance savings", Color(hex: "#5E5CE6"), "shield.lefthalf.filled"),
        ]
        return defs.compactMap { (def: (String, String, Color, String)) -> ClassSum? in
            let (key, title, color, sym) = def
            let items = h.filter { $0.cls == key }
            let v = items.reduce(0) { $0 + $1.amt }
            return v > 0 ? ClassSum(key: key, title: title, color: color, sym: sym, v: v, n: items.count) : nil
        }
    }
    /// what the banks last said is in your accounts
    /// (with what is held in them for an IPO: still the account's money, out of what the bank calls available)
    func bankBalance(_ p: Person) -> Double { figures.bankBalance(p) }
    /// net worth's parts: money in the bank, then what's invested
    func netClasses(_ p: Person) -> [ClassSum] {
        var c = classes(p)
        let b = bankBalance(p)
        if b > 0 {
            let n = snap.accounts.filter { p.owns($0.owner) && $0.balance != nil }.count
            c.insert(ClassSum(key: "bank", title: "In the bank", color: Color(hex: "#5AC8FA"), sym: "indianrupeesign.circle.fill", v: b, n: n), at: 0)
        }
        let land = propertyWorth(p)
        if land > 0 { c.append(ClassSum(key: "prop", title: "Property (land)", color: Color(hex: "#8E6E53"), sym: "building.2.fill", v: land, n: properties(p).filter { ($0.worth ?? 0) > 0 }.count)) }
        return c
    }
    /// the land under the properties, at the rates set: the household's all of it, a person's what's in their name
    /// (a joint one at their share). A property no one is named on counts only for the household
    func propertyWorth(_ p: Person) -> Double { figures.propertyWorth(p) }
    func assets(_ p: Person) -> Double { figures.assets(p) }
    func debts(_ p: Person) -> Double { figures.debts(p) }
    func netWorth(_ p: Person) -> Double { figures.netWorth(p) }
    /// net worth month by month: what was held at each month's end (from the engine's dated record), with
    /// cash, the land at the rate you set and today's loans as they are now (kosh has no past figure for them); this
    /// month is today's figure, so the line ends where the headline is
    func worthSeries(_ p: Person) -> [NWPoint] { figures.worthSeries(p) }

    // accounts, cards, loans, insurance (filtered by whose)
    /// (a joint account is in each of its holders' view too)
    var accounts: [Account] { snap.accounts.filter { who.owns($0.owner) || ($0.joint ?? []).contains(who.id) } }
    var cards: [CardInfo] { snap.cards.filter { who.owns($0.owner) } }
    var wallets: [Account] { snap.wallets.filter { who.owns($0.owner) } }
    var loans: [Loan] { snap.loans.filter { who.owns($0.owner ?? "me") } }
    var vouchers: [Voucher] { (snap.vouchers ?? []).filter { who.owns($0.owner) } }
    /// the policies that still run (in force, due, past due in their grace, paid up); the rest are in the archive
    var policies: [Policy] { snap.policies.filter { who.owns($0.owner) && !$0.isEnded } }
    /// lapsed, expired, renewed under a new number, matured, or ended by you: the Insurance tab's archive
    var endedPolicies: [Policy] { snap.policies.filter { who.owns($0.owner) && $0.isEnded } }
    func person(_ id: String) -> PersonInfo? { snap.people.first { $0.id == id } }
    /// (a name the mail is written to that is no one in the household yet goes by that name, never its key)
    func ownerName(_ id: String) -> String { id == "me" ? "You" : (snap.personName(id) ?? id.capitalized) }

    func latest(_ kind: String) -> Capture? { captures.filter { $0.kind == kind }.sorted { $0.date < $1.date }.last }
    var cashInHand: Double { latest("cash")?.amount ?? 0 }
    func loanBalance(_ l: Loan) -> Double? { figures.loanBalance(l) }
    func addCapture(kind: String, title: String, amount: Double?, text: String) {
        captures.append(Capture(id: UUID().uuidString, kind: kind, title: title, amount: amount, text: text, date: snap.today))
    }
}
