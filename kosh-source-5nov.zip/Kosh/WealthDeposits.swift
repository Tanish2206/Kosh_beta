import SwiftUI

// MARK: - Wealth › Holdings › Deposits (W3, redrawn 1 Nov from his pick, "KindDeposits")
//
// Everything in deposits and bank accounts, what the deposits earn a year at their own rates; three figures that
// matter (the average rate, the next one back, what sits above DICGC's cover); when it comes back, as a line from today
// to the last maturity; then a card a deposit: how far through its term, what went in, what it's worth today, what it
// pays at maturity (blank when its mail doesn't say), and whether its bank's money is inside DICGC's ₹5 lakh a person.
// The mockup's after-tax rate and "vs inflation" need your tax slab and a price-index figure; kosh has neither, so
// they're left out rather than assumed. Bank accounts, deposits that need a look, and matured ones follow.

struct WealthDeposits: View {
    @Environment(Store.self) private var store
    @Environment(\.accessibilityReduceMotion) private var still
    let embedded: Bool
    let tabs: [String]
    let kind: String

    init(embedded: Bool = false, tabs: [String] = [], kind: String = "") {
        self.embedded = embedded
        self.tabs = tabs
        self.kind = kind
    }

    var body: some View {
        if embedded {
            scroller
        } else {
            scroller
                .background(alignment: .top) {
                    RadialGradient(colors: [Obsidian.health.opacity(0.15), Obsidian.health.opacity(0.04), Color.clear], center: .center, startRadius: 0, endRadius: 300)
                        .frame(width: 510, height: 600)
                        .offset(x: -40, y: -260)
                        .allowsHitTesting(false)
                }
                .navigationTitle("Deposits")
                .navigationBarTitleDisplayMode(.inline)
                .obsidianPage(aura: Obsidian.health)
        }
    }

    var scroller: some View {
        let p: Person = store.who
        let deps: [Holding] = store.holdings(p).filter { $0.cls == "dep" && $0.amt > 0 }.sorted { $0.amt > $1.amt }
        let accts: [Account] = store.wealthAccounts(p).filter { Store.accountWorth($0) > 0 }.sorted { Store.accountWorth($0) > Store.accountWorth($1) }
        return ScrollView {
            VStack(alignment: .leading, spacing: 30) {
                VStack(alignment: .leading, spacing: 0) {
                    top
                    if deps.isEmpty && accts.isEmpty {
                        Text("No deposits or bank balances kosh has read for " + (p == .family ? "the household" : p == .me ? "you" : p.title) + " yet.")
                            .font(.body).foregroundStyle(Obsidian.ink2).padding(.top, 30)
                            .fixedSize(horizontal: false, vertical: true)
                    } else {
                        DepositsHead(deps: deps, accts: accts)
                    }
                }
                DepositsStats(p: p, deps: deps)
                DepositsRunway(p: p)
                DepositsEach(p: p, deps: deps)
                DepositsBanks(p: p, accts: accts)
                DepositsMore(p: p)
            }
            .padding(.horizontal, 20)
            .padding(.bottom, 40)
            .animation(still ? nil : Motion.base, value: store.who)
        }
        .scrollIndicators(.hidden)
    }

    @ViewBuilder var top: some View {
        if embedded {
            HoldingsTop(tabs: tabs, kind: kind).padding(.bottom, 18)
        } else {
            WhoseSwitch()
        }
    }
}

/// the total, what the deposits earn a year at their own rates, and deposits against bank accounts
struct DepositsHead: View {
    @Environment(Store.self) private var store
    let deps: [Holding]
    let accts: [Account]

    var body: some View {
        let fd: Double = deps.reduce(0) { $0 + $1.amt }
        let bank: Double = accts.reduce(0) { $0 + Store.accountWorth($1) }
        let rated: [Holding] = deps.filter { $0.rate > 0 }
        let ratedSum: Double = rated.reduce(0) { $0 + $1.amt }
        let yearly: Double = rated.reduce(0) { $0 + $1.amt * $1.rate / 100 }
        let n: Int = deps.count + accts.count
        VStack(alignment: .leading, spacing: 0) {
            HStack(spacing: 6) {
                Circle().fill(Obsidian.health).frame(width: 6, height: 6)
                Text("Deposits · " + (n == 1 ? "1 account" : "\(n) accounts"))
                    .font(.system(size: 11, design: .monospaced)).tracking(0.7).textCase(.uppercase)
                    .foregroundStyle(Obsidian.health)
            }
            .padding(.horizontal, 10)
            .padding(.vertical, 5)
            .background(RoundedRectangle(cornerRadius: 10).fill(Obsidian.health.opacity(0.12)))
            .padding(.top, 6)
            Text("Worth today · " + Day.fmt(store.snap.today, "d MMM yyyy")).caption().padding(.top, 18)
            WealthFigure(value: fd + bank)
                .padding(.top, 6)
            if yearly >= 1 && ratedSum > 0 {
                Self.earns(yearly: yearly, rate: yearly / ratedSum * 100, of: rated.count, all: deps.count)
                    .font(.system(size: 13.5)).foregroundStyle(Obsidian.ink2)
                    .padding(.top, 10)
                    .fixedSize(horizontal: false, vertical: true)
                    .privacySensitive()
            }
            if fd > 0 && bank > 0 {
                WealthSplitBar(parts: [(id: "fd", v: fd, color: Obsidian.health), (id: "bank", v: bank, color: Obsidian.health.opacity(0.3))], height: 10)
                    .padding(.top, 20)
                HStack {
                    Self.legend(Obsidian.health, "Deposits " + Fmt.words(fd))
                    Spacer()
                    Self.legend(Obsidian.health.opacity(0.45), "Bank accounts " + Fmt.words(bank))
                }
                .font(.system(size: 11, design: .monospaced)).monospacedDigit().foregroundStyle(Obsidian.ink2)
                .padding(.top, 8)
                .privacySensitive()
            }
        }
    }

    static func legend(_ dot: Color, _ label: String) -> Text {
        let mark: Text = Text("● ").foregroundStyle(dot)
        return mark + Text(label)
    }

    /// "Earns about ₹1.2L a year · 7.1% on average", over the deposits whose rate kosh read
    static func earns(yearly: Double, rate: Double, of: Int, all: Int) -> Text {
        let fig: Text = Text(Fmt.words(yearly)).fontWeight(.semibold).foregroundStyle(Obsidian.health)
        let tail: String = " a year · " + Fmt.trim(rate, 2) + "% on average" + (of < all ? ", over the \(of) of \(all) deposits with a rate" : "")
        return Text("Deposits earn about ") + fig + Text(tail)
    }
}

// MARK: three figures that matter

/// the average rate over the deposits with one, the next one coming back, and what sits above DICGC's cover
struct DepositsStats: View {
    @Environment(Store.self) private var store
    let p: Person
    let deps: [Holding]

    var body: some View {
        let tiles: [DepositStat] = Self.tiles(store, p, deps)
        if tiles.count >= 2 {
            ViewThatFits(in: .horizontal) {
                HStack(alignment: .top, spacing: 8) {
                    ForEach(tiles) { (t: DepositStat) in DepositStatTile(t: t) }
                }
                VStack(alignment: .leading, spacing: 8) {
                    ForEach(tiles) { (t: DepositStat) in DepositStatTile(t: t) }
                }
            }
        }
    }

    static func tiles(_ store: Store, _ p: Person, _ deps: [Holding]) -> [DepositStat] {
        var out: [DepositStat] = []
        let rated: [Holding] = deps.filter { $0.rate > 0 }
        let ratedSum: Double = rated.reduce(0) { $0 + $1.amt }
        if ratedSum > 0 {
            let r: Double = rated.reduce(0) { $0 + $1.amt * $1.rate } / ratedSum
            out.append(DepositStat(id: "rate", title: "Avg rate", value: Fmt.trim(r, 2) + "%",
                                   note: rated.count < deps.count ? "\(rated.count) of \(deps.count) with a rate" : "a year", tone: Obsidian.ink))
        }
        let today: String = store.snap.today
        if let next = store.wealthRunwayItems(p).filter({ $0.day >= today }).min(by: { $0.day < $1.day }) {
            let same: Bool = Day.fmt(next.day, "yyyy") == Day.fmt(today, "yyyy")
            out.append(DepositStat(id: "next", title: "Next back", value: Day.fmt(next.day, same ? "d MMM" : "MMM yyyy"),
                                   note: WealthDays.until(next.day, today: today), tone: Obsidian.ink))
        }
        let cover: [WealthCover] = WealthBook.cover(store.wealthHeld(p).banks)
        if !cover.isEmpty {
            let above: Double = cover.reduce(0) { $0 + $1.above }
            out.append(DepositStat(id: "cover", title: "Above DICGC", value: above >= 1 ? Fmt.words(above) : "None",
                                   note: above >= 1 ? "not insured" : "all of it insured", tone: above >= 1 ? Obsidian.savings : Obsidian.health))
        }
        return out
    }
}

struct DepositStat: Identifiable, Hashable {
    let id: String
    let title: String
    let value: String
    let note: String
    let tone: Color
}

struct DepositStatTile: View {
    let t: DepositStat
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(t.title).caption()
            Text(t.value).font(.title3.weight(.bold)).monospacedDigit().foregroundStyle(t.tone)
                .lineLimit(1).minimumScaleFactor(0.7).privacySensitive()
            Text(t.note).font(.caption2).foregroundStyle(Obsidian.ink3)
                .fixedSize(horizontal: false, vertical: true)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .obsidianCard(16, padding: 12)
        .accessibilityElement(children: .combine)
    }
}

// MARK: when it comes back

/// every deposit with a maturity ahead on a line from today to the last, a dot each sized by what it brings back; what
/// comes back within a year, and what all of it pays when each deposit's mail says
struct DepositsRunway: View {
    @Environment(Store.self) private var store
    let p: Person

    var body: some View {
        let today: String = store.snap.today
        if let r = WealthBook.runway(store.wealthRunwayItems(p), today: today) {
            VStack(alignment: .leading, spacing: 12) {
                Text("When it comes back").caption()
                VStack(alignment: .leading, spacing: 14) {
                    RunwayLine(r: r, today: today)
                        .frame(height: 76)
                    Rectangle().fill(Obsidian.rule).frame(height: 1)
                    RunwayFact(title: "Coming back within a year", value: Self.yearValue(r))
                    if let all = r.all {
                        RunwayFact(title: "All of it, by " + Day.fmt(r.last, "MMM yyyy"), value: Fmt.words(all))
                    }
                }
                .obsidianCard(22, padding: 16)
            }
        }
    }

    static func yearValue(_ r: WealthRunway) -> String {
        if r.yearN == 0 { return "Nothing" }
        return Fmt.words(r.year) + (r.yearKnown ? "" : " (worth today)")
    }
}

struct RunwayFact: View {
    let title: String
    let value: String
    var body: some View {
        ViewThatFits(in: .horizontal) {
            HStack(alignment: .firstTextBaseline) {
                Text(title).font(.subheadline).foregroundStyle(Obsidian.ink2)
                Spacer(minLength: 8)
                Text(value).font(.subheadline.weight(.bold)).monospacedDigit().foregroundStyle(Obsidian.ink).privacySensitive()
            }
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(.subheadline).foregroundStyle(Obsidian.ink2)
                Text(value).font(.subheadline.weight(.bold)).monospacedDigit().foregroundStyle(Obsidian.ink).privacySensitive()
            }
        }
        .accessibilityElement(children: .combine)
    }
}

/// the line itself: today at the left, the last maturity at the right, a mint dot a deposit (bigger for more), a label
/// over the dots there's room for
struct RunwayLine: View {
    let r: WealthRunway
    let today: String

    var body: some View {
        GeometryReader { geo in
            let w: CGFloat = geo.size.width
            let top: Double = r.items.map(\.figure).max() ?? 1
            let sizes: [CGFloat] = r.items.map { (m: WealthMaturing) -> CGFloat in 12 + 20 * CGFloat((m.figure / max(top, 1)).squareRoot()) }
            let xs: [CGFloat] = Self.places(r.at, width: w, sizes: sizes)
            let shown: [Bool] = Self.labelled(xs, room: 64)
            ZStack(alignment: .topLeading) {
                Rectangle().fill(Color(hex: "#26262C")).frame(width: w, height: 2).offset(y: 37)
                Rectangle().fill(Obsidian.ink).frame(width: 2, height: 18).offset(y: 29)
                Text("Today").font(.caption2).foregroundStyle(Obsidian.ink2).offset(y: 52)
                Text(Day.fmt(r.last, "yyyy")).font(.caption2).foregroundStyle(Obsidian.ink2)
                    .frame(width: w, alignment: .trailing).offset(y: 52)
                ForEach(r.items.indices, id: \.self) { (i: Int) in
                    RunwayDot(m: r.items[i], size: sizes[i], label: shown[i])
                        .position(x: xs[i], y: shown[i] ? 30 : 38)
                }
            }
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(Self.spoken(r))
    }

    /// each dot's centre, kept inside the line
    static func places(_ at: [Double], width: CGFloat, sizes: [CGFloat]) -> [CGFloat] {
        var out: [CGFloat] = []
        for (i, f) in at.enumerated() {
            let half: CGFloat = (i < sizes.count ? sizes[i] : 12) / 2 + 2
            out.append(min(max(CGFloat(f) * width, half), width - half))
        }
        return out
    }
    /// which dots get a label: the first, then any far enough past the last one labelled
    static func labelled(_ xs: [CGFloat], room: CGFloat) -> [Bool] {
        var out: [Bool] = []
        var last: CGFloat = -1000
        for x in xs {
            let ok: Bool = x - last >= room
            out.append(ok)
            if ok { last = x }
        }
        return out
    }
    static func spoken(_ r: WealthRunway) -> String {
        r.items.map { (m: WealthMaturing) -> String in m.name + ", " + Day.fmt(m.day, "d MMMM yyyy") }.joined(separator: "; ")
    }
}

struct RunwayDot: View {
    let m: WealthMaturing
    let size: CGFloat
    let label: Bool
    var body: some View {
        VStack(spacing: 3) {
            if label {
                Text(Day.fmt(m.day, "MMM yyyy")).font(.system(size: 10.5, weight: .bold)).foregroundStyle(Obsidian.ink).fixedSize()
            }
            Circle().fill(Obsidian.health.opacity(m.back != nil ? 0.9 : 0.55)).frame(width: size, height: size)
        }
    }
}

// MARK: a card a deposit

/// every deposit, biggest first, as a card; a deposit kosh follows opens its journey
struct DepositsEach: View {
    @Environment(Store.self) private var store
    let p: Person
    let deps: [Holding]

    var body: some View {
        if !deps.isEmpty {
            let cover: [String: WealthCover] = Self.coverByKey(store, p)
            VStack(alignment: .leading, spacing: 12) {
                Text(deps.count == 1 ? "The deposit" : "Each deposit").caption()
                ForEach(deps) { (h: Holding) in
                    Button { open(h) } label: { DepositCard(h: h, d: deposit(h), cover: Self.row(h, cover), who: p == .family ? store.ownerName(h.person) : nil, today: store.snap.today) }
                        .buttonStyle(.press)
                }
            }
        }
    }

    func deposit(_ h: Holding) -> DepositItem? {
        let id: String = h.dep ?? ""
        return id.isEmpty ? nil : store.deposit(id)
    }
    func open(_ h: Holding) {
        if let d = h.dep, !d.isEmpty { store.push(.deposit(d)); return }
        if let live = store.live, let mine = live.typedHolding(h) { store.betaSheet = .holding(mine.id) }
    }
    static func coverByKey(_ store: Store, _ p: Person) -> [String: WealthCover] {
        var out: [String: WealthCover] = [:]
        for c in WealthBook.cover(store.wealthHeld(p).banks) { out[c.key] = c }
        return out
    }
    /// the deposit's bank's row ("" key: not a bank kosh knows)
    static func row(_ h: Holding, _ by: [String: WealthCover]) -> (key: String, row: WealthCover?) {
        let at: String = WealthWhere.of(h)
        let key: String = WealthWhere.bankKey(at) ?? WealthWhere.bankKey(h.bank) ?? ""
        return (key, key.isEmpty ? nil : by[key])
    }
}

struct DepositCard: View {
    let h: Holding
    let d: DepositItem?
    let cover: (key: String, row: WealthCover?)
    let who: String?
    let today: String

    var body: some View {
        let bank: String = WealthWhere.bankPart(HoldingName.pretty(h.bank))
        let end: String? = h.matDay ?? d?.mat ?? h.mat.map { $0 + "-01" }
        let term: (done: Double, left: String)? = WealthBook.term(start: d?.start, end: end, today: today)
        VStack(alignment: .leading, spacing: 14) {
            DepositCardHead(name: HoldingName.pretty(h.bank), initial: String(bank.prefix(1)).uppercased(), meta: meta, rate: h.rate)
            if let t = term, let s = d?.start, let e = end {
                DepositTerm(done: t.done, from: Day.fmt(s, "MMM yyyy"), left: t.left, to: Day.fmt(e, "MMM yyyy"))
            }
            DepositFigures(putIn: Self.putIn(h, d), now: h.amt, back: (d?.matAmt ?? 0) > 0 ? d?.matAmt : nil)
            DepositCoverStrip(key: cover.key, row: cover.row)
        }
        .obsidianCard(22, padding: 16)
        .contentShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
    }

    /// "FD · renews itself · Mom"
    var meta: String {
        var bits: [String] = [d?.rd == true ? "RD" : "FD"]
        if d?.auto == true { bits.append("renews itself") }
        if let who { bits.append(who) }
        return bits.joined(separator: " · ")
    }
    /// what went in: the deposit's own principal, else what its statement says it cost
    static func putIn(_ h: Holding, _ d: DepositItem?) -> Double? {
        if let a = d?.amt, a > 0 { return a }
        if let c = h.cost, c > 0 { return c }
        return nil
    }
}

struct DepositCardHead: View {
    let name: String
    let initial: String
    let meta: String
    let rate: Double
    var body: some View {
        HStack(alignment: .center, spacing: 12) {
            Text(initial.isEmpty ? "₹" : initial)
                .font(.system(size: 16, weight: .heavy))
                .foregroundStyle(Obsidian.health)
                .frame(width: 40, height: 40)
                .background(RoundedRectangle(cornerRadius: 12, style: .continuous).fill(Obsidian.health.opacity(0.12)))
            VStack(alignment: .leading, spacing: 2) {
                Text(name).font(.subheadline.weight(.semibold)).foregroundStyle(Obsidian.ink)
                    .fixedSize(horizontal: false, vertical: true)
                Text(meta).font(.caption).foregroundStyle(Obsidian.ink3)
            }
            Spacer(minLength: 6)
            if rate > 0 {
                Text(Fmt.trim(rate, 2) + "%")
                    .font(.footnote.weight(.bold)).monospacedDigit().foregroundStyle(Obsidian.health)
                    .padding(.horizontal, 10).padding(.vertical, 5)
                    .background(Capsule().fill(Obsidian.health.opacity(0.12)))
                    .fixedSize()
            }
        }
    }
}

/// how far through its term: a bar, the month it began, what's left, the month it ends
struct DepositTerm: View {
    let done: Double
    let from: String
    let left: String
    let to: String
    var body: some View {
        VStack(spacing: 6) {
            GeometryReader { geo in
                Capsule().fill(Obsidian.health).frame(width: max(4, geo.size.width * CGFloat(done)))
            }
            .frame(height: 6)
            .background(Capsule().fill(Color(hex: "#1C1C22")))
            HStack {
                Text(from)
                Spacer(minLength: 4)
                Text(left).foregroundStyle(Obsidian.ink2)
                Spacer(minLength: 4)
                Text(to)
            }
            .font(.caption2).foregroundStyle(Obsidian.ink3)
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("From " + from + " to " + to + ", " + left)
    }
}

/// put in, worth today, at maturity: side by side, or one under another when the words are large
struct DepositFigures: View {
    let putIn: Double?
    let now: Double
    let back: Double?
    var body: some View {
        ViewThatFits(in: .horizontal) {
            HStack(alignment: .top, spacing: 8) { cells }
            VStack(alignment: .leading, spacing: 8) { cells }
        }
    }
    @ViewBuilder var cells: some View {
        DepositFigure(title: "Put in", value: putIn.map(Fmt.words), tone: Obsidian.ink)
        DepositFigure(title: "Worth today", value: Fmt.words(now), tone: Obsidian.ink)
        DepositFigure(title: "At maturity", value: back.map(Fmt.words), tone: Obsidian.health)
    }
}

struct DepositFigure: View {
    let title: String
    let value: String?
    let tone: Color
    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(title).font(.caption2).foregroundStyle(Obsidian.ink3)
            if let value {
                Text(value).font(.subheadline.weight(.bold)).monospacedDigit().foregroundStyle(tone).privacySensitive()
            } else {
                Text("Not in its mail").font(.caption).foregroundStyle(Obsidian.ink3)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .accessibilityElement(children: .combine)
    }
}

/// whether its bank's money is inside DICGC's ₹5 lakh a person: mint inside, striped amber above, grey for money kosh
/// can't place at a bank
struct DepositCoverStrip: View {
    let key: String
    let row: WealthCover?
    var body: some View {
        let above: Double = row?.above ?? 0
        let over: Bool = above >= 1
        let tone: Color = key.isEmpty ? Obsidian.ink3 : (over ? Obsidian.savings : Obsidian.health)
        Text(Self.words(key: key, row: row))
            .font(.caption.weight(.bold))
            .foregroundStyle(tone)
            .fixedSize(horizontal: false, vertical: true)
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.horizontal, 12)
            .padding(.vertical, 10)
            .background {
                if over {
                    Stripes(color: Obsidian.savings).opacity(0.22)
                } else {
                    tone.opacity(0.08)
                }
            }
            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
            .privacySensitive()
    }

    static func words(key: String, row: WealthCover?) -> String {
        if key.isEmpty { return "Not at a bank kosh knows: DICGC covers bank deposits only" }
        guard let r = row else { return "Inside DICGC’s ₹5L cover at this bank" }
        if r.above >= 1 { return Fmt.words(r.above) + " at " + r.bank + " is above DICGC’s ₹5L a person" }
        return "Inside DICGC’s ₹5L cover at " + r.bank
    }
}

// MARK: bank accounts, and the rest

/// the bank's money, account by account; each opens its page
struct DepositsBanks: View {
    @Environment(Store.self) private var store
    let p: Person
    let accts: [Account]

    var body: some View {
        if !accts.isEmpty {
            let rows: [DepositLine] = accts.map { (a: Account) -> DepositLine in
                DepositLine(id: "a|" + a.id, name: WealthWhere.accountName(a), who: a.owner, amt: Store.accountWorth(a), rate: nil,
                            mat: nil, fd: false, dep: nil, account: a.id)
            }
            VStack(alignment: .leading, spacing: 12) {
                Text(accts.count == 1 ? "The bank account" : "Bank accounts").caption()
                VStack(spacing: 0) {
                    ForEach(Array(rows.enumerated()), id: \.element.id) { (pair: (offset: Int, element: DepositLine)) in
                        if pair.offset > 0 { Rectangle().fill(Obsidian.rule).frame(height: 1).padding(.leading, 64) }
                        Button { store.push(.account(pair.element.account ?? "")) } label: {
                            DepositLineRow(r: pair.element, who: p == .family ? store.ownerName(pair.element.who) : nil, cm: store.snap.cm)
                        }
                        .buttonStyle(.press)
                    }
                }
                .background(RoundedRectangle(cornerRadius: 22, style: .continuous).fill(Obsidian.card))
                .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous).stroke(Obsidian.cardBorder, lineWidth: 1))
            }
        }
    }
}

/// deposits kosh isn't counting until you say, and every one that matured or closed
struct DepositsMore: View {
    @Environment(Store.self) private var store
    let p: Person

    var body: some View {
        let look: Int = store.deposits(p, "look").count
        let dated: Bool = store.snap.depDates != nil
        if look > 0 || dated {
            VStack(spacing: 0) {
                if look > 0 {
                    WealthLinkRow(title: look == 1 ? "1 deposit needs a look" : "\(look) deposits need a look",
                                  sub: "Not in your totals until you say you still have them", color: Obsidian.savings) {
                        store.push(.holdings("dep:" + p.rawValue))
                    }
                }
                if look > 0 && dated { Rectangle().fill(Obsidian.rule).frame(height: 1).padding(.leading, 36) }
                if dated {
                    WealthLinkRow(title: "Matured and closed", sub: "Every maturity ahead and every closure behind", color: Obsidian.ink3) {
                        store.push(.maturities)
                    }
                }
            }
            .background(RoundedRectangle(cornerRadius: 22, style: .continuous).fill(Obsidian.card))
            .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous).stroke(Obsidian.cardBorder, lineWidth: 1))
        }
    }
}

/// amber stripes: the money above cover
struct Stripes: View {
    let color: Color
    var body: some View {
        Canvas { ctx, size in
            ctx.fill(Path(CGRect(origin: .zero, size: size)), with: .color(color.opacity(0.35)))
            var x: CGFloat = -size.height
            while x < size.width + size.height {
                var p = Path()
                p.move(to: CGPoint(x: x, y: size.height))
                p.addLine(to: CGPoint(x: x + size.height, y: 0))
                ctx.stroke(p, with: .color(color), lineWidth: 3)
                x += 6
            }
        }
    }
}

struct DepositLine: Identifiable, Hashable {
    let id: String
    let name: String
    let who: String
    let amt: Double
    let rate: Double?
    /// its maturity: a day (yyyy-MM-dd) or a month (yyyy-MM)
    let mat: String?
    let fd: Bool
    let dep: String?
    let account: String?
}

struct DepositLineRow: View {
    let r: DepositLine
    let who: String?
    let cm: String
    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: r.fd ? "building.columns" : "wallet.bifold")
                .font(.system(size: 16))
                .foregroundStyle(r.fd ? Obsidian.health : Obsidian.ink2)
                .frame(width: 36, height: 36)
                .background(RoundedRectangle(cornerRadius: 11, style: .continuous).fill(r.fd ? Obsidian.health.opacity(0.13) : Color(hex: "#141419")))
            VStack(alignment: .leading, spacing: 3) {
                Text(r.name).font(.system(size: 14.5, weight: .medium)).foregroundStyle(Obsidian.ink).lineLimit(1)
                Text(sub).font(.system(size: 12)).foregroundStyle(Obsidian.ink3).lineLimit(1)
            }
            Spacer(minLength: 8)
            VStack(alignment: .trailing, spacing: 3) {
                Text(Fmt.rupees(r.amt)).font(.system(size: 14.5, weight: .semibold)).monospacedDigit().foregroundStyle(Obsidian.ink).privacySensitive()
                if let x = r.rate { Text(Fmt.trim(x, 2) + "%").font(.system(size: 11, design: .monospaced)).foregroundStyle(Obsidian.ink3) }
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 14)
        .contentShape(Rectangle())
    }

    /// "Mom · matures 12 Dec 2026", "bank account, any time"
    var sub: String {
        var bits: [String] = []
        if let who { bits.append(who) }
        if let m = r.mat, !m.isEmpty {
            let day: Bool = m.count >= 10
            let word: String = String(m.prefix(7)) < cm ? "matured " : "matures "
            bits.append(word + Day.fmt(day ? m : m + "-01", day ? "d MMM yyyy" : "MMM yyyy"))
        } else if !r.fd {
            bits.append("bank account, any time")
        }
        return bits.joined(separator: " · ")
    }
}
