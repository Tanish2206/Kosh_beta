import SwiftUI
import Charts

// MARK: - Home: everything important, at a glance

struct HomeView: View {
    @Environment(Store.self) private var store
    @Namespace private var zoom

    var body: some View {
        @Bindable var store = store
        NavigationStack(path: $store.homePath) {
            Group {
                switch store.homeSub {
                case .overview: HomeOverview(zoom: zoom)
                case .genie: GenieView()
                }
            }
            // the page's own scroll moves the tab bar (the sub-tab row above is a scroll view too, and would be found first)
                .subSlide(store.homeSub)
        .barFollows()
            .pullForMail(store.live)
            // Overview and Genie, and at the row's end the bell: what kosh noticed and the threads coming up
            .safeAreaInset(edge: .top, spacing: 0) {
                SubTabBar(selection: $store.homeSub, bell: store.bellInfo)
            }
            // the title from the top of the screen; on Overview, Arrange this tab; whose money (with Hide amounts and
            // Settings), Ask kosh and add
            .tabHeader("Home", add: [HeaderAction(title: "Add a spend", symbol: "plus.circle") { store.sheet = .add(nil) }],
                       extra: store.homeSub == .overview ? HeaderAction(title: "Arrange this tab", symbol: "slider.horizontal.3") { store.sheet = .arrange(.home) } : nil)
            .navigationDestination(for: Route.self) { route in
                RouteDestination(route: route, zoom: zoom)
            }
        }
    }
}

struct HomeOverview: View {
    let zoom: Namespace.ID?
    @AppStorage("home.fold.months") private var monthsFolded = false
    @Environment(Store.self) private var store

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 0) {
                // hello in one language after another, with the name you gave kosh
                HelloLine().padding(.horizontal, 20).padding(.top, 6).padding(.bottom, 4)
                // a first read still going back through the year says how far it has got
                if let live = store.live { ReadingBackLine(live: live).padding(.horizontal, 20).padding(.bottom, 4) }
                if store.live != nil { Intro.home().padding(.horizontal, 20) }
                if let problem = store.live?.loadProblem { LoadProblemCard(text: problem).padding(.horizontal, 20).padding(.top, 12) }
                // locked statements, and whose details would open them
                if store.live != nil { FamilyUnlockCard() }
                // (no "Ask, drawn" card here: his call, 31 Oct. Asking lives in Ask kosh, beside Overview)
                // the rest in the order you set (Arrange this tab)
                PlanStack(.homeOverview) { id in section(id) }
            }
            .padding(.top, 8)
            .padding(.bottom, 32)
        }
        .background(Color(uiColor: .systemBackground))
    }

    @ViewBuilder func section(_ id: String) -> some View {
        switch id {
        case "setup": SetupCard().padding(.horizontal, 20).padding(.top, 16)
        case "brief": BriefHomeCard()
        case "worth": HomeBlock { NetWorthCard() }
        case "goals": GoalsHomeCard()
        case "expenses":
            HomeBlock(padded: false) {
                HStack(alignment: .center, spacing: 10) {
                    SectionHeader(title: "Spending", folded: $monthsFolded)
                    // whether trips and events count in the months, on the title's own line
                    if store.live != nil && !monthsFolded { ChaptersToggle().transition(.opacity.combined(with: .scale(scale: 0.96, anchor: .trailing))) }
                }
                .padding(.horizontal, 20)
                VStack(alignment: .leading, spacing: 0) {
                    Unfold(open: !monthsFolded, keep: true) {
                        MonthCarousel(zoom: zoom)
                    }
                    Unfold(open: monthsFolded) {
                        SpendFold { withAnimation(Fold.spring) { monthsFolded = false } }
                            .padding(.horizontal, 20)
                    }
                }
            }
        case "flow": if (store.snap.cashflow ?? []).count > 0 { HomeBlock { CashFlowCard() } }
        case "week": HomeBlock { WeekCard() }
        case "trip": if let trip = store.homeTrip { HomeBlock { TripHomeCard(trip: trip) } }
        case "also": AlsoInKosh().padding(.horizontal, 20).padding(.top, 14)
        default: EmptyView()
        }
    }
}

/// one part of Home, set apart from the next by a hairline and room to breathe
struct HomeBlock<Content: View>: View {
    var padded = true
    @ViewBuilder let content: Content
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            content
        }
        .padding(.horizontal, padded ? 20 : 0)
        .padding(.top, 22)
        .padding(.bottom, 8)
        .overlay(alignment: .top) {
            Rectangle().fill(Color.primary.opacity(0.07)).frame(height: 0.5).padding(.horizontal, 20)
        }
        .padding(.top, 8)
    }
}

// MARK: - Finish setting up: what the mail couldn't tell kosh

struct SetupCard: View {
    @Environment(Store.self) private var store
    /// put away until this day (yyyy-MM-dd), or "never"
    @AppStorage("kosh.setupCard.until") private var until = ""
    @State private var asking = false

    var body: some View {
        let steps = store.setupSteps
        let done = steps.filter { $0.done }.count
        let left = steps.filter { !$0.done }
        let away = until == "never" || (!until.isEmpty && store.snap.today < until)
        if !left.isEmpty && !away {
            VStack(alignment: .leading, spacing: 14) {
                HStack(spacing: 14) {
                    ZStack {
                        Circle().stroke(Color.kosh.opacity(0.15), lineWidth: 5)
                        Circle()
                            .trim(from: 0, to: CGFloat(done) / CGFloat(max(1, steps.count)))
                            .stroke(Color.kosh, style: StrokeStyle(lineWidth: 5, lineCap: .round))
                            .rotationEffect(.degrees(-90))
                        Text("\(done)/\(steps.count)")
                            .font(.system(size: 12, weight: .bold, design: .rounded))
                    }
                    .frame(width: 46, height: 46)
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Finish setting up").font(.headline)
                        Text("Your mail covered most of it. Add what it can’t see.")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                    Spacer(minLength: 4)
                    Button { asking = true } label: {
                        Image(systemName: "xmark").font(.footnote.weight(.bold)).foregroundStyle(.secondary)
                            .frame(width: 30, height: 30).background(Color.primary.opacity(0.06), in: Circle())
                    }
                    .buttonStyle(.press)
                    .accessibilityLabel("Put away")
                    .confirmationDialog("Finish setting up later?", isPresented: $asking, titleVisibility: .visible) {
                        Button("Remind me tomorrow") { withAnimation(Motion.open) { until = Day.add(store.snap.today, 1) } }
                        Button("Remind me next week") { withAnimation(Motion.open) { until = Day.add(store.snap.today, 7) } }
                        Button("Don’t show this again", role: .destructive) { withAnimation(Motion.open) { until = "never" } }
                    } message: {
                        Text("You can still add these any time from Settings.")
                    }
                }
                VStack(spacing: 0) {
                    ForEach(Array(left.prefix(3).enumerated()), id: \.element.id) { i, s in
                        if i > 0 { Divider().padding(.leading, 34) }
                        Button {
                            if s.capture == "gold" && store.live != nil { store.betaSheet = .holding("new:gold") }
                            else if s.capture == "passwords" { store.betaSheet = .passwords }
                            else if s.capture == "papers" { store.betaSheet = .papers }
                            else if let c = s.capture { store.sheet = .capture(c) }
                        } label: {
                            HStack(spacing: 10) {
                                Image(systemName: "plus.circle.fill")
                                    .font(.title3)
                                    .foregroundStyle(Color.kosh)
                                Text(s.title).foregroundStyle(Color.primary)
                                Spacer()
                                Text("Add").font(.subheadline.weight(.semibold)).foregroundStyle(Color.kosh)
                            }
                            .padding(.vertical, 10)
                            .contentShape(Rectangle())
                        }
                        .buttonStyle(.press)
                    }
                }
            }
            .padding(16)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.surface, in: RoundedRectangle(cornerRadius: 26, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 26, style: .continuous).stroke(Color.kosh.opacity(0.18), lineWidth: 1))
            .transition(.opacity.combined(with: .scale(scale: 0.97)))
        }
    }
}

// MARK: - Net worth, over time and what it is made of

struct NetWorthCard: View {
    @AppStorage("home.fold.networth") private var folded = false
    @Environment(Store.self) private var store

    var body: some View {
        let p = store.who
        VStack(alignment: .leading, spacing: 12) {
            SectionHeader(title: "Net worth", action: "Wealth", folded: $folded) {
                store.portSub = .overview
                store.open(.portfolio)
            }
            VStack(alignment: .leading, spacing: 0) {
                Unfold(open: !folded, keep: true) {
                    VStack(alignment: .leading, spacing: 18) {
                        NetWorthTrend(label: store.who.possessive("net worth", family: "Family net worth"), net: store.netWorth(p), pts: store.worthSeries(p))
                        // the figures behind it, small, in one row you can swipe
                        PulseStats(tiles: store.pulse(p)).padding(.horizontal, -18)
                        NetWorthBreakdown()
                        // a deposit in dollars is in the figure at the day's rate: said, with the rate and its day
                        if let line = foreignLine(p) {
                            Label(line, systemImage: "dollarsign.arrow.circlepath")
                                .font(.footnote).foregroundStyle(.secondary)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                        // (five years on at today's pace, OutlookLink, is off Home for now, 1 Nov, his ask: Portfolio keeps it)
                    }
                    .card(18)
                }
                Unfold(open: folded) {
                    WorthFold { withAnimation(Fold.spring) { folded = false } }
                }
            }
        }
        .animation(Motion.open, value: store.who)
    }

    /// "Includes USD 25,000.00 in deposits, counted at ₹94.96 to the dollar (ECB rate of 16 Oct 2026, refreshed daily)."
    func foreignLine(_ p: Person) -> String? {
        let items: [DepositItem] = (store.snap.deposits?.items ?? []).filter { (d: DepositItem) -> Bool in
            d.counted && d.ccy != nil && (d.fxAmt ?? 0) > 0 && d.fxSaid != nil && p.owns(d.person)
        }
        guard !items.isEmpty else { return nil }
        var lines: [String] = []
        for cur in Array(Set(items.compactMap(\.ccy))).sorted() {
            let mine: [DepositItem] = items.filter { $0.ccy == cur }
            let total: Double = mine.reduce(0) { $0 + ($1.fxAmt ?? 0) }
            // (a dollar figure grouped as dollars are, "USD 1,20,000" would read wrong)
            let amount: String = store.hidden ? "deposits in " + cur : cur + " " + Int(total.rounded()).formatted(.number.locale(Locale(identifier: "en_US"))) + " in deposits"
            lines.append("Includes " + amount + ", counted at " + (mine[0].fxSaid ?? "") + ".")
        }
        return lines.joined(separator: " ")
    }
}

/// the figure, what moved it over the range picked (3, 6 or 12 months, or all) and by how much in all, and the line;
/// drag to read a month
struct NetWorthTrend: View {
    @Environment(Store.self) private var store
    let label: String
    let net: Double
    let pts: [NWPoint]
    @State private var picked: Date?
    @AppStorage("home.networth.range") private var range = 12

    static let ranges: [(Int, String)] = [(3, "3M"), (6, "6M"), (12, "1Y"), (0, "All")]

    /// the range counted back from today, the way Stocks counts it: 3M on 7 October reaches back to 7 July,
    /// and since kosh knows what was owned at each month's end, the line opens on the last one before that
    /// (30 June: what July started with) and runs to today
    var shownPts: [NWPoint] { Self.window(pts, range: range) }
    static func window(_ pts: [NWPoint], range: Int) -> [NWPoint] {
        guard range > 0, let first = Self.opening(pts, range: range) else { return pts }
        return pts.filter { $0.m >= first }
    }
    /// the month whose end the range opens on
    static func opening(_ pts: [NWPoint], range: Int) -> String? {
        guard range > 0, let last = pts.last else { return nil }
        let today: String = last.day ?? Day.monthEnd(last.m)
        let back: Date = Day.cal.date(byAdding: .month, value: -range, to: Day.date(today)) ?? Day.date(today)
        let after: String = Day.add(Day.iso(back), 1)
        return Day.addMonths(String(after.prefix(7)), -1)
    }
    /// "1 Jul", or "1 Jul 2025" in another year: the day after a month-end, which is what that figure opened
    static func since(_ p: NWPoint, today: String) -> String {
        if let d = p.day { return Day.fmt(d, "d MMM") }
        let next: String = Day.add(Day.monthEnd(p.m), 1)
        let sameYear: Bool = next.prefix(4) == today.prefix(4)
        return Day.fmt(next, sameYear ? "d MMM" : "d MMM yyyy")
    }
    var chosen: NWPoint? {
        let s = shownPts
        guard let picked, s.count > 1 else { return nil }
        return s.min { abs($0.date.timeIntervalSince(picked)) < abs($1.date.timeIntervalSince(picked)) }
    }
    var change: (String, Bool)? {
        let s = shownPts
        guard s.count > 1, let first = s.first else { return nil }
        let d: Double = net - first.v
        let pct: String = first.v > 0 ? " (" + Fmt.trim(abs(d) / first.v * 100, 1) + "%)" : ""
        let today: String = s.last?.day ?? Day.monthEnd(s.last?.m ?? first.m)
        let arrow: String = d >= 0 ? "▲ " : "▼ "
        return (arrow + Fmt.words(abs(d)) + pct + " since " + Self.since(first, today: today), d >= 0)
    }
    /// when the range asks for more months than kosh has: say where the line starts, and why
    static func shortNote(pts: [NWPoint], range: Int) -> String? {
        guard let first = pts.first, let open = Self.opening(pts, range: range), first.m > open else { return nil }
        let since: String = Day.fmt(first.m + "-01", "MMM yyyy")
        return "kosh has net worth from " + since + " so far. Earlier months fill in as last year’s statements are read."
    }
    static func pointLabel(_ p: NWPoint) -> String {
        if p.day != nil { return "Today" }
        return "End of " + Day.fmt(p.m + "-01", "MMMM yyyy")
    }
    var body: some View {
        let shown = chosen
        let s = shownPts
        VStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 2) {
                    Text(shown.map { Self.pointLabel($0) } ?? label)
                        .font(.subheadline.weight(.medium)).foregroundStyle(.secondary)
                    Text(Fmt.signedWords(shown?.v ?? net))
                        .font(.system(size: 38, weight: .bold, design: .rounded))
                        .contentTransition(.numericText(value: shown?.v ?? net))
                        .privacySensitive()
                    // (1 Nov, his ask: nothing between the figure and the chart. What moved it, kind by kind, and the
                    // whole change were here: NetWorthMoves.swift still works them out, for when they come back)
                }
                Spacer(minLength: 8)
                if pts.count > 2 { RangeMenu(range: $range, ranges: NetWorthTrend.ranges) }
            }
            if s.count > 1 {
                NetWorthChart(pts: s, chosen: shown, picked: $picked)
                    .frame(height: 150)
                    .animation(Motion.open, value: range)
                if let note = Self.shortNote(pts: pts, range: range) {
                    Label(note, systemImage: "clock.arrow.circlepath")
                        .font(.caption).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                }
            } else {
                Label("kosh draws this over time from your bank alerts and statements as they come in.", systemImage: "chart.xyaxis.line")
                    .font(.footnote).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            }
        }
        .sensoryFeedback(.selection, trigger: shown?.m)
        .sensoryFeedback(.selection, trigger: range)
    }
}

/// a small capsule at the top right: the time range, picked from a menu
struct RangeMenu: View {
    @Binding var range: Int
    let ranges: [(Int, String)]
    var body: some View {
        Menu {
            Picker("Range", selection: $range) {
                ForEach(ranges.indices, id: \.self) { i in
                    let r = ranges[i]
                    Text(r.0 == 0 ? "All time" : r.0 == 12 ? "1 year" : "\(r.0) months").tag(r.0)
                }
            }
        } label: {
            HStack(spacing: 3) {
                Text(ranges.first { $0.0 == range }?.1 ?? "1Y").font(.footnote.weight(.semibold))
                Image(systemName: "chevron.down").font(.system(size: 9, weight: .bold))
            }
            .foregroundStyle(Color.primary)
            .padding(.horizontal, 10).padding(.vertical, 6)
            .background(Color.primary.opacity(0.06), in: Capsule())
        }
        .accessibilityLabel("Range")
    }
}

/// the figures under the chart, the way Stocks shows them: a caption and a value, column after column, swiped sideways
struct PulseStats: View {
    let tiles: [PulseTile]
    var body: some View {
        if !tiles.isEmpty {
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 0) {
                    ForEach(Array(tiles.enumerated()), id: \.element.id) { i, t in
                        if i > 0 { Rectangle().fill(Color.primary.opacity(0.08)).frame(width: 0.5, height: 30) }
                        Button(action: t.go) {
                            VStack(alignment: .leading, spacing: 2) {
                                // (no coloured dot: dots belong to the key under the bar, and these aren't its pieces)
                                Text(t.label.uppercased()).font(.system(.caption2, weight: .semibold)).tracking(0.5).foregroundStyle(.secondary).lineLimit(1)
                                Text(t.value).font(.system(.callout, design: .rounded, weight: .semibold)).monospacedDigit()
                                    .foregroundStyle(Color.primary).lineLimit(1).privacySensitive()
                            }
                            .padding(.horizontal, 14)
                            .contentShape(Rectangle())
                        }
                        .buttonStyle(.press)
                    }
                }
                .padding(.horizontal, 4)
            }
            .scrollClipDisabled()
        }
    }
}

struct NetWorthChart: View {
    let pts: [NWPoint]
    let chosen: NWPoint?
    @Binding var picked: Date?
    @Environment(\.colorScheme) private var scheme
    var body: some View {
        let lo: Double = pts.map(\.v).min() ?? 0
        let hi: Double = pts.map(\.v).max() ?? 0
        let pad: Double = max((hi - lo) * 0.18, abs(hi) * 0.02, 1)
        let floor: Double = lo - pad
        let every: Int = max(1, Int((Double(pts.count) / 5).rounded(.up)))
        let start: Date = pts.first?.date ?? Date()
        let end: Date = pts.last?.date ?? Date()
        let look: Look = Look.shared
        let dot: Color = look.line.paint(dark: scheme == .dark, accent: look.accent).dotColor
        // each figure on its own day: a month's end where it was, today at the end; the months marked where they begin.
        // The chart keeps the scales, the months, picking a point and VoiceOver; the line itself is drawn behind it,
        // in the colour picked in Settings › Appearance, its light flowing toward today (FlowLine, Appearance.swift)
        Chart {
            ForEach(pts) { x in
                LineMark(x: .value("Day", x.date), y: .value("Net worth", x.v))
                    .foregroundStyle(Color.clear)
                    .interpolationMethod(.monotone)
            }
            if let c = chosen {
                RuleMark(x: .value("Day", c.date)).foregroundStyle(Color.secondary.opacity(0.35))
                PointMark(x: .value("Day", c.date), y: .value("Net worth", c.v)).foregroundStyle(dot).symbolSize(70)
            }
        }
        .chartXScale(domain: start...max(end, start.addingTimeInterval(86400)))
        .chartYScale(domain: floor...(hi + pad))
        .chartYAxis(.hidden)
        .chartXAxis {
            AxisMarks(values: .stride(by: .month, count: every)) { _ in
                AxisValueLabel(format: .dateTime.month(.abbreviated), centered: false)
            }
        }
        .chartBackground { proxy in
            GeometryReader { g in
                if let plotAnchor = proxy.plotFrame {
                    let plot: CGRect = g[plotAnchor]
                    let line: [CGPoint] = pts.compactMap { x -> CGPoint? in
                        guard let px = proxy.position(forX: x.date), let py = proxy.position(forY: x.v) else { return nil }
                        return CGPoint(x: px, y: py)
                    }
                    FlowLine(pts: line, base: plot.height, dot: chosen == nil)
                        .frame(width: plot.width, height: plot.height)
                        .offset(x: plot.minX, y: plot.minY)
                }
            }
        }
        .chartXSelection(value: $picked)
    }
}

/// what net worth is made of: one bar in proportion, and a legend under it (the figures live in Portfolio)
struct NetWorthBreakdown: View {
    @Environment(Store.self) private var store
    @State private var grown = false
    @State private var picked: String?
    var body: some View {
        let p = store.who
        let classes = store.netClasses(p)
        let total: Double = max(1, classes.reduce(0) { $0 + $1.v })
        let mine = p == .family || p == .me
        let missingLoan: Loan? = mine ? store.snap.loans.first(where: { $0.active && store.loanBalance($0) == nil }) : nil
        VStack(alignment: .leading, spacing: 12) {
            GeometryReader { g in
                let gaps = CGFloat(max(0, classes.count - 1)) * 3
                HStack(spacing: 3) {
                    ForEach(classes) { c in
                        Capsule()
                            .fill(c.color.gradient)
                            .frame(width: max(0, (g.size.width - gaps) * CGFloat(c.v / total) * (grown ? 1 : 0.02)))
                            .opacity(picked == nil || picked == c.key ? 1 : 0.25)
                    }
                }
            }
            .frame(height: 8)
            // the key, short: three to a line in columns as wide as their widest, one size of type throughout, the lines
            // close; tap one to light its piece of the bar and read its amount in place of the share
            Grid(alignment: .leading, horizontalSpacing: 18, verticalSpacing: 2) {
                ForEach(Array(stride(from: 0, to: classes.count, by: 3)), id: \.self) { i in
                    GridRow {
                        ForEach(Array(classes[i..<min(i + 3, classes.count)])) { c in key(c, total: total) }
                    }
                }
            }
            if let l = missingLoan {
                Button { store.sheet = .capture("loan:" + l.id) } label: {
                    Label("Add the \(l.name.lowercased()) balance to take it off", systemImage: "plus.circle.fill").font(.footnote.weight(.semibold))
                }
                .buttonStyle(.press)
                .foregroundStyle(Color.kosh)
            }
        }
        .onAppear { withAnimation(Motion.reveal.delay(0.2)) { grown = true } }
        .sensoryFeedback(.selection, trigger: picked)
    }

    /// a class's name, short enough for a third of the card: "Bank", "Funds"
    static func short(_ c: ClassSum) -> String {
        switch c.key {
        case "bank": return "Bank"
        case "prop": return "Property"
        default: break
        }
        let t: String = c.title
        if t.lowercased().hasPrefix("mutual fund") { return "Funds" }
        return t
    }

    func key(_ c: ClassSum, total: Double) -> some View {
        let on: Bool = picked == c.key
        let dim: Bool = picked != nil && !on
        let title: String = Self.short(c)
        let share: String = Fmt.pct(c.v / total)
        return Button {
            withAnimation(Motion.base) { picked = on ? nil : c.key }
        } label: {
            HStack(spacing: 5) {
                Circle().fill(c.color).frame(width: 7, height: 7)
                Text(title).foregroundStyle(.secondary).lineLimit(1).fixedSize()
                Text(on ? Fmt.words(c.v) : share)
                    .fontWeight(.semibold)
                    .foregroundStyle(Color.primary)
                    .monospacedDigit()
                    .fixedSize()
                    .contentTransition(.numericText())
                    .privacySensitive()
            }
            .font(.footnote)
            .frame(minHeight: 24, alignment: .leading)
            .contentShape(Rectangle())
        }
        .buttonStyle(.press)
        .opacity(dim ? 0.4 : 1)
        .spokenFigures(title + ", " + share + ", " + Fmt.words(c.v), hidden: title + ", " + share)
    }
}

// MARK: - Between people: splits, loans and refunds

struct OwedTile: View {
    let title: String
    let value: Double
    let count: Int
    let color: Color
    var note: String? = nil
    var fill: Color = Color.surface
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title).font(.subheadline).foregroundStyle(.secondary)
            Text(Fmt.words(value))
                .font(.system(.title2, design: .rounded, weight: .bold))
                .foregroundStyle(value > 0 ? color : Color.primary)
                .minimumScaleFactor(0.7)
                .lineLimit(1)
                .privacySensitive()
            Text(note ?? (count == 0 ? "all settled" : "\(Words.number(count)) open"))
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(fill, in: RoundedRectangle(cornerRadius: 26, style: .continuous))
    }
}

// MARK: - The modules that aren't tabs

func moduleColor(_ t: AppTab) -> Color {
    switch t {
    case .property: return Color(hex: "#34C759")
    case .committees: return Color(hex: "#30B0C7")
    case .people: return Color(hex: "#FF9500")
    case .chapters: return Color(hex: "#C2412D")
    case .insurance: return Color(hex: "#30B0C7")
    case .loans: return Color(hex: "#FF3B30")
    case .portfolio: return Color(hex: "#007AFF")
    default: return Color.kosh
    }
}

// MARK: - The months, as cards you swipe through

struct MonthCarousel: View {
    @Environment(Store.self) private var store
    let zoom: Namespace.ID?

    var body: some View {
        ScrollView(.horizontal) {
            LazyHStack(spacing: 12) {
                ForEach(store.snap.months) { mo in
                    // the card opens its month from its top half; the lens chips below are buttons of their own
                    MonthCard(mo: mo)
                        .zoomSource(mo.m, zoom)
                    .containerRelativeFrame(.horizontal) { length, _ in max(0, length - 56) }
                    .scrollTransition(.interactive, axis: .horizontal) { content, phase in
                        content
                            .scaleEffect(phase.isIdentity ? 1 : 0.93)
                            .rotation3DEffect(.degrees(phase.value * -12), axis: (x: 0, y: 1, z: 0))
                            .opacity(phase.isIdentity ? 1 : 0.7)
                    }
                }
            }
            .scrollTargetLayout()
        }
        .scrollTargetBehavior(.viewAligned)
        .scrollIndicators(.hidden)
        .contentMargins(.horizontal, 20, for: .scrollContent)
        .sensoryFeedback(.selection, trigger: store.homePath.count)
    }
}

struct MonthCard: View {
    @Environment(Store.self) private var store
    let mo: MonthInfo

    var subtitle: String {
        let share: TripShare = store.tripShare(mo.m)
        if !share.list.isEmpty {
            let tail: String = TripMonthLine.short(share)
            if mo.live { return "likely " + Fmt.words(store.likelyNow) + " · " + tail }
            return tail
        }
        if mo.live { return "likely \(Fmt.rupees(store.likelyNow)) · usual \(Fmt.rupees(store.snap.fc.usual))" }
        return mo.lead
    }

    var body: some View {
        let total = store.total(of: mo)
        VStack(alignment: .leading, spacing: 0) {
            NavigationLink(value: Route.month(mo.m)) { top(total) }
                .buttonStyle(.press)
            // the month seen one way at a time: categories, places, fixed and everyday, who, how it was paid
            MonthLenses(mo: mo)
                .padding(.top, 8)
        }
        .padding(20)
        .frame(height: 418)
        .background(Color.surface, in: RoundedRectangle(cornerRadius: 30, style: .continuous))
        .contentShape(RoundedRectangle(cornerRadius: 30, style: .continuous))
    }

    func top(_ total: Double) -> some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack(alignment: .firstTextBaseline) {
                VStack(alignment: .leading, spacing: 2) {
                    Text(mo.name).font(.title2.weight(.bold))
                    Text(mo.live ? "Day \(store.snap.fc.d) of \(mo.days)" : "\(mo.payments) payments")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
                Spacer()
                MonthBadge(mo: mo)
            }
            Text(Fmt.rupees(total))
                .font(.system(size: 44, weight: .bold, design: .rounded))
                .contentTransition(.numericText(value: total))
                .privacySensitive()
                .padding(.top, 12)
            Text(subtitle)
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .lineLimit(1)
                .privacySensitive()
                .padding(.top, 1)
            // the line takes whatever room is left, so nothing sits empty between the month and its figure
            MiniChart(mo: mo)
                .frame(minHeight: 64, maxHeight: .infinity)
                .padding(.top, 12)
        }
        .contentShape(Rectangle())
    }
}

struct MonthBadge: View {
    @Environment(Store.self) private var store
    let mo: MonthInfo
    var body: some View {
        if mo.live {
            HStack(spacing: 6) {
                Image(systemName: "circle.fill")
                    .font(.system(size: 7))
                    .foregroundStyle(Color.green)
                    .symbolEffect(.pulse, options: .repeating)
                Text("Live")
            }
            .font(.footnote.weight(.semibold))
            .padding(.horizontal, 10).padding(.vertical, 5)
            .background(Color.raised, in: Capsule())
        } else if let ch = mo.change {
            let level = abs(ch) < 0.015
            HStack(spacing: 3) {
                if !level { Image(systemName: ch < 0 ? "arrow.down" : "arrow.up") }
                Text(level ? "Level" : Fmt.pct(abs(ch)))
                Text("vs \(Day.monthShort(mo.prev ?? mo.m))").foregroundStyle(.secondary).fontWeight(.regular)
            }
            .font(.footnote.weight(.semibold))
            .foregroundStyle(level ? Color.primary : (ch < 0 ? Color.green : Color.orange))
            .privacySensitive()
        }
    }
}

struct MiniChart: View {
    @Environment(Store.self) private var store
    let mo: MonthInfo
    /// the spending line's colour: light at the month's start, deepening to kosh's own by its end
    static var ink: LinearGradient {
        LinearGradient(colors: [Color.sky, Color.kosh, Color.kosh.mix(with: .purple, by: 0.35)], startPoint: .leading, endPoint: .trailing)
    }
    @State private var reveal: CGFloat = 0

    var body: some View {
        let pts = store.actualPoints(mo)
        let fc = mo.live ? store.forecastPoints() : []
        let band = mo.live ? store.bandPoints() : []
        Chart {
            if mo.live {
                ForEach(band) { b in
                    AreaMark(x: .value("Day", b.day), yStart: .value("Low", b.lo), yEnd: .value("High", b.hi))
                        .foregroundStyle(Color.kosh.opacity(0.07))
                        .interpolationMethod(.monotone)
                }
                ForEach(fc) { p in
                    LineMark(x: .value("Day", p.day), y: .value("Spent", p.v), series: .value("Series", "forecast"))
                        .foregroundStyle(Color.kosh.opacity(0.7))
                        .lineStyle(StrokeStyle(lineWidth: 2, lineCap: .round, dash: [1, 5]))
                        .interpolationMethod(.monotone)
                }
            }
            // a soft fill under the month so far
            ForEach(pts) { p in
                AreaMark(x: .value("Day", p.day), y: .value("Spent", p.v), series: .value("Series", "fill"))
                    .foregroundStyle(LinearGradient(colors: [Color.kosh.opacity(0.24), Color.kosh.opacity(0)], startPoint: .top, endPoint: .bottom))
                    .interpolationMethod(.monotone)
            }
            // the line itself: sky into kosh's colour, glowing
            ForEach(pts) { p in
                LineMark(x: .value("Day", p.day), y: .value("Spent", p.v), series: .value("Series", "actual"))
                    .foregroundStyle(MiniChart.ink)
                    .lineStyle(StrokeStyle(lineWidth: 3, lineCap: .round, lineJoin: .round))
                    .interpolationMethod(.monotone)
                    .shadow(color: Color.kosh.opacity(0.55), radius: 6, y: 2)
            }
            if mo.live, let last = pts.last {
                PointMark(x: .value("Day", last.day), y: .value("Spent", last.v))
                    .foregroundStyle(Color.kosh.opacity(0.18))
                    .symbolSize(260)
                PointMark(x: .value("Day", last.day), y: .value("Spent", last.v))
                    .foregroundStyle(Color.kosh)
                    .symbolSize(56)
                    .shadow(color: Color.kosh.opacity(0.7), radius: 5)
            }
        }
        .chartXScale(domain: 1...mo.days)
        .chartYScale(domain: 0...store.chartMax(mo))
        .chartXAxis(.hidden)
        .chartYAxis(.hidden)
        .chartLegend(.hidden)
        .mask(alignment: .leading) {
            GeometryReader { g in Rectangle().frame(width: g.size.width * reveal) }
        }
        .onAppear { withAnimation(Motion.reveal.delay(0.2)) { reveal = 1 } }
        .accessibilityElement(children: .ignore)
        .spokenFigures(MonthChart.spoken(mo, pts: pts, prev: []), hidden: "Spending through " + mo.name + ", day by day")
    }
}

extension View {
    /// a zoom source only when there is a namespace to zoom in
    @ViewBuilder func zoomSource(_ id: String, _ ns: Namespace.ID?) -> some View {
        if let ns { self.matchedTransitionSource(id: id, in: ns) } else { self }
    }

    /// pull down to read new mail (Home, Transactions); nothing to pull while kosh isn't reading a mailbox
    @ViewBuilder func pullForMail(_ live: LiveSession?) -> some View {
        if let live { self.refreshable { await live.pullRefresh() } } else { self }
    }
}


/// when the screens can't be built, or the phone's files couldn't be read: said plainly, not left blank
struct LoadProblemCard: View {
    @Environment(Store.self) private var store
    let text: String
    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: "exclamationmark.triangle.fill").foregroundStyle(Color.orange).font(.title3)
            VStack(alignment: .leading, spacing: 6) {
                Text(text).font(.subheadline.weight(.medium)).fixedSize(horizontal: false, vertical: true)
                Button("Try again") { store.live?.reloadIfNeeded(); store.live?.rebuild() }.font(.subheadline.weight(.semibold))
            }
            Spacer(minLength: 0)
        }
        .padding(14)
        .background(Color.orange.opacity(0.10), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        .textSelection(.enabled)
    }
}
