import Foundation

// MARK: - Rent marked received: on screen the moment it's tapped
//
// "Mark received" (and its Undo) saves the floor's month and lays the books out again, which takes seconds on a phone.
// The tap shouldn't wait for that: the month shows received at once (the card, the pill, the row, the year's strip),
// and the build that follows confirms it. A build that started before the tap would lay it out without it, so the
// mark is put back over that one, the way a payment's own change is (Store.edits); once a build that started after
// the tap lands, the engine's own figure stands and the mark is dropped.

extension Store {
    /// a floor's month you just marked (true) or unmarked (false), keyed "<property id>|<floor>|<yyyy-mm>", with the
    /// build that was running when you tapped
    struct RentMark { var received: Bool; var gen: Int }

    func markRent(property uid: String, unit idx: Int, month: String) {
        guard let live else { return }
        let key: String = uid + "|" + String(idx) + "|" + month
        // the month as it stands now (an earlier mark not built yet counts), and the other way round
        let was: Bool = rentMarks[key]?.received ?? Self.rentReceived(snap.value, uid: uid, idx: idx, month: month)
        rentMarks[key] = RentMark(received: !was, gen: live.buildGen)
        snap.replace(with: Self.withRentMarks(snap.value, rentMarks, today: snap.value.today))
        live.toggleRentPaid(property: uid, unit: idx, month: month)
    }

    /// is that month received as the screens show it
    static func rentReceived(_ s: Snapshot, uid: String, idx: Int, month: String) -> Bool {
        guard let p = s.prop.props.first(where: { ($0.uid ?? $0.pid) == uid || $0.pid == uid }),
              let u = p.units.first(where: { ($0.idx ?? -1) == idx }) else { return false }
        let r: RollMonth? = u.now?.m == month ? u.now : (u.roll.first { $0.m == month } ?? u.past?.first { $0.m == month })
        return r?.st == "booked"
    }

    /// a fresh build with the marks it was laid out without put over it; marks it already has are dropped
    func keepRentMarks(_ s: Snapshot) -> Snapshot {
        guard !rentMarks.isEmpty else { return s }
        let landed: Int = live?.buildGen ?? Int.max
        for (k, m) in rentMarks where landed > m.gen { rentMarks[k] = nil }
        return rentMarks.isEmpty ? s : Self.withRentMarks(s, rentMarks, today: s.today)
    }

    static func withRentMarks(_ s: Snapshot, _ marks: [String: RentMark], today: String) -> Snapshot {
        var s = s
        for (k, m) in marks {
            let parts: [Substring] = k.split(separator: "|", omittingEmptySubsequences: false)
            guard parts.count == 3, let idx = Int(parts[1]) else { continue }
            let uid = String(parts[0]), month = String(parts[2])
            guard let pi = s.prop.props.firstIndex(where: { ($0.uid ?? $0.pid) == uid || $0.pid == uid }),
                  let ui = s.prop.props[pi].units.firstIndex(where: { ($0.idx ?? -1) == idx }) else { continue }
            func fix(_ r: RollMonth) -> RollMonth {
                guard r.m == month else { return r }
                var r = r
                if m.received {
                    r.st = "booked"; r.got = "marked"; r.late = 0
                } else if r.got == "marked" {
                    // unmarked: due, or late from its day, until the build says exactly
                    let due: String = r.due ?? ""
                    let lateNow: Bool = due.count == 10 && due < today
                    r.st = lateNow ? "late" : "due"; r.got = nil
                    r.late = lateNow ? max(0, Day.between(due, today)) : 0
                }
                return r
            }
            var u = s.prop.props[pi].units[ui]
            u.roll = u.roll.map(fix)
            if let n = u.now { u.now = fix(n) }
            if let past = u.past { u.past = past.map(fix) }
            s.prop.props[pi].units[ui] = u
        }
        return s
    }
}
