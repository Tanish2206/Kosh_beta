import SwiftUI

// MARK: - Banks: what's in each account, whose it is, and how kosh knows
//
// A lead card on a blue wash with the total, how fresh it is and a named split by bank; the banks as chips;
// what came in and went out; each person's accounts; cash; statements; and how a balance is known.
// Wallets have their own segment now (WalletsView).

struct WalletAccounts: View {
    @Environment(Store.self) private var store
    @AppStorage("accts.span") private var spanKey = "30d"
    @State private var bank = ""
    @State private var grown = false

    /// one person's accounts, and what they hold between them
    struct Holder: Identifiable {
        let id: String
        let title: String
        let accs: [Account]
        let sum: Double
    }

    var body: some View {
        let span: Span = Span.pick(spanKey, months: store.snap.months)
        let today: String = store.snap.today
        let all: [Account] = store.accounts
        let accs: [Account] = Self.byBalance(all.filter { bank.isEmpty || $0.bank == bank })
        let known: [Account] = accs.filter { $0.balance != nil }
        let total: Double = known.compactMap(\.balance).reduce(0, +)
        let carried: Int = Self.carriedCount(known)
        let fresh: Int = known.filter { BalanceWords.age($0, today: today) == 0 }.count
        let banks: [BankPick] = Self.banks(all)
        let logos: Bool = IconBook.shared.all(all.map { ($0.bank, $0.name) })
        let flow = store.accountFlow(accs, span: span, today: today)
        let holders: [Holder] = Self.holders(accs, people: store.snap.people.filter { store.who.owns($0.id) }, toConfirm: store.snap.peopleToConfirm ?? [])
        let parts: [LegendPart] = Self.slices(known)
        let line: String = known.isEmpty ? Self.noBalanceLine : Self.freshLine(n: known.count, fresh: fresh, carried: carried)
        let showCash: Bool = bank.isEmpty && (store.who == .family || store.who == .me)
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                if all.isEmpty {
                    ContentUnavailableView("No bank accounts yet", systemImage: "building.columns",
                                           description: Text("They walk in as soon as your bank’s alerts and statements land in your mail."))
                        .padding(.top, 40)
                } else {
                    MoneyHero(heading: Self.heading(bank), value: known.isEmpty ? nil : total, empty: "Not known yet",
                              line: line, wash: .blue, spanKey: $spanKey) {
                        if parts.count > 1 { HeroLegend(parts: parts, grown: grown).padding(.top, 14) }
                    }
                    if banks.count > 1 {
                        BankStrip(banks: banks, pick: $bank, logos: logos, noun: "accounts").padding(.horizontal, -20).padding(.vertical, -6)
                    }
                    if !accs.isEmpty { FlowTiles(flow: flow, span: span) }
                    ForEach(holders) { h in
                        VStack(alignment: .leading, spacing: 8) {
                            GroupLabel(title: h.title, figure: h.sum > 0 ? Fmt.words(h.sum) : "")
                            VStack(spacing: 0) {
                                ForEach(Array(h.accs.enumerated()), id: \.element.id) { i, a in
                                    if i > 0 { RowRule(inset: 50) }
                                    Button { store.push(.account(a.id)) } label: { BankRow(a: a, logos: logos) }
                                        .buttonStyle(.press)
                                }
                            }
                            .rowsCard()
                        }
                    }
                }
                if bank.isEmpty && store.who == .family { AccountQuestions() }
                if showCash { CashRow() }
                StatementsGroup(kind: "stmt", bank: bank, logos: logos)
                BalanceHelp()
                AnotherGmail()
            }
            .padding(.horizontal, 20)
            .padding(.top, 14)
            .padding(.bottom, 40)
        }
        .animation(Motion.open, value: store.who)
        .animation(Motion.open, value: bank)
        .animation(Motion.open, value: spanKey)
        .onAppear { withAnimation(Motion.reveal.delay(0.1)) { grown = true } }
    }

    static let noBalanceLine = "No balances yet. Tap an account to type today’s."
    static func whose(_ p: PersonInfo) -> String { p.id == "me" ? "Yours" : (p.rel.isEmpty ? p.name : p.rel) }
    static func byBalance(_ xs: [Account]) -> [Account] {
        xs.sorted { a, b in
            let x: Double = a.balance ?? -1
            let y: Double = b.balance ?? -1
            return x > y
        }
    }
    static func carriedCount(_ xs: [Account]) -> Int {
        var n: Int = 0
        for a in xs { if let b = a.bal, b.n > 0 { n += 1 } }
        return n
    }
    static func heading(_ bank: String) -> String { bank.isEmpty ? "In your bank accounts" : "In " + bank }
    static func freshLine(n: Int, fresh: Int, carried: Int) -> String {
        var bits: [String] = []
        let all: String = n == 1 ? "Up to date" : "All " + String(n) + " up to date"
        let some: String = String(fresh) + " of " + String(n) + " up to date"
        bits.append(fresh == n ? all : some)
        if carried > 0 { bits.append(String(carried) + " carried forward from a statement or alert") }
        return bits.joined(separator: " · ")
    }
    static func banks(_ accs: [Account]) -> [BankPick] {
        var by: [String: (String, Int, String)] = [:]
        for a in accs { let x = by[a.bank] ?? (a.color, 0, a.name); by[a.bank] = (x.0, x.1 + 1, x.2) }
        return BankPick.ordered(by.map { BankPick(id: $0.key, color: $0.value.0, count: $0.value.1, hint: $0.value.2) })
    }
    /// each person's accounts, in the household's order; then the joint ones; then those whose mail is written to
    /// someone not in the household yet, by that name; any other owner, last
    static func holders(_ accs: [Account], people: [PersonInfo], toConfirm: [PersonToConfirm] = []) -> [Holder] {
        var out: [Holder] = []
        var placed = Set<String>()
        // (quiet-4nov) accounts nothing has moved through in six months go last, apart, under "Quiet accounts"
        let quiet: [Account] = accs.filter { ($0.quiet ?? "").isEmpty == false }
        for a in quiet { placed.insert(a.id) }
        func add(_ id: String, _ title: String, _ mine: [Account]) {
            if mine.isEmpty { return }
            for a in mine { placed.insert(a.id) }
            out.append(Holder(id: id, title: title, accs: mine, sum: mine.compactMap(\.balance).reduce(0, +)))
        }
        for p in people { add(p.id, whose(p), accs.filter { $0.owner == p.id && !placed.contains($0.id) }) }   // gone-4nov: a quiet account is listed once, under Quiet
        add("family", "Joint", accs.filter { $0.owner == "family" && !placed.contains($0.id) })
        for p in toConfirm { add(p.id, p.full, accs.filter { $0.owner == p.id && !placed.contains($0.id) }) }
        let rest: [Account] = accs.filter { !placed.contains($0.id) }
        if !rest.isEmpty { out.append(Holder(id: "~rest", title: "Others", accs: rest, sum: rest.compactMap(\.balance).reduce(0, +))) }
        if !quiet.isEmpty { out.append(Holder(id: "~quiet", title: "Quiet accounts", accs: quiet, sum: quiet.compactMap(\.balance).reduce(0, +))) }
        return out
    }
    /// what each bank holds, biggest first, in colours that tell apart
    static func slices(_ known: [Account]) -> [LegendPart] {
        var by: [String: Double] = [:]
        var hex: [String: String] = [:]
        for a in known {
            let v: Double = a.balance ?? 0
            if v <= 0 { continue }
            if by[a.bank] == nil { hex[a.bank] = a.color }
            by[a.bank, default: 0] += v
        }
        let names: [String] = by.keys.sorted { (by[$0] ?? 0) != (by[$1] ?? 0) ? (by[$0] ?? 0) > (by[$1] ?? 0) : $0 < $1 }
        let colors: [Color] = Swatch.distinct(names.map { hex[$0] ?? "#636366" })
        var out: [LegendPart] = []
        for (i, n) in names.enumerated() { out.append(LegendPart(id: n, name: n, color: colors[i], v: by[n] ?? 0)) }
        return out
    }
}

/// what came into and went out of a set of accounts over a stretch
struct AccountFlow {
    var inn: Double = 0
    var out: Double = 0
    var nIn = 0
    var nOut = 0
    /// of what came in, how many were top-ups (moves from your own money), for a wallet
    var nMoves = 0
    var items: [Txn] = []
    init(_ tx: [Txn], accounts: [Account], span: Span, today: String) {
        var keys = Set<String>()
        for a in accounts { keys.formUnion(a.keys ?? [a.id]) }
        let (lo, hi) = span.range(today: today)
        for t in tx where keys.contains(t.card) && t.partOf == nil && t.d >= lo && t.d <= hi {
            let v = t.full ?? t.a
            if t.dr == "in" {
                inn += v; nIn += 1
                if t.k == "move" { nMoves += 1 }
            } else if t.dr == "out" { out += v; nOut += 1 } else { continue }
            items.append(t)
        }
        items.sort { ($0.d, $0.t) > ($1.d, $1.t) }
    }
}

extension Store {
    /// what came into and went out of these accounts over a span (AccountFlow), worked out once a change to the
    /// payments or to the cards' own side of bills paid, not on every redraw of Accounts and an account's page
    func accountFlow(_ accounts: [Account], span: Span, today: String) -> AccountFlow {
        let key: String = span.key + "|" + today + "|" + accounts.map { ($0.keys ?? [$0.id]).joined(separator: ",") }.joined(separator: "|")
        if flowMemo.gen != txGen || flowMemo.mgen != mirrorsGen { flowMemo = (txGen, mirrorsGen, [:]) }
        if let known = flowMemo.by[key] { return known }
        let made = AccountFlow(tx + mirrors, accounts: accounts, span: span, today: today)
        flowMemo.by[key] = made
        return made
    }
}

/// one side of the money: a tinted arrow, what it is, the figure and how many payments made it
struct FlowTile: View {
    let title: String
    let value: Double
    let sub: String
    let sym: String
    let tint: Color
    var valueInk: Color = Color.primary
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack(spacing: 8) {
                Image(systemName: sym).font(.system(size: 12, weight: .bold)).foregroundStyle(tint)
                    .frame(width: 28, height: 28)
                    .background(tint.opacity(0.14), in: Circle())
                Text(title).font(.system(.footnote, weight: .semibold)).foregroundStyle(Color(light: "#3A3A44", dark: "#D1D1D6")).lineLimit(1)
            }
            Text(Fmt.rupees(value))
                .font(.system(.title2, design: .rounded, weight: .bold)).monospacedDigit()
                .foregroundStyle(valueInk)
                .lineLimit(1).minimumScaleFactor(0.6)
                .contentTransition(.numericText(value: value))
                .privacySensitive()
                .padding(.top, 10)
            Text(sub).font(.system(.caption)).foregroundStyle(.secondary).lineLimit(1).minimumScaleFactor(0.8).padding(.top, 2)
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.surface, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        .accessibilityElement(children: .ignore)
        .spokenFigures(title + ", " + Fmt.rupees(value) + ", " + sub, hidden: title + ", " + sub)
    }
}

/// came in and went out side by side (added and spent, for a wallet), with where the figures come from
struct FlowTiles: View {
    @Environment(Store.self) private var store
    let flow: AccountFlow
    let span: Span
    var wallet: Bool = false
    var body: some View {
        let phrase: String = span.phrase(cm: store.snap.cm)
        let green: Color = Color(light: "#1A7A43", dark: "#5FD38A")
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 10) {
                if wallet {
                    FlowTile(title: "Added", value: flow.inn, sub: Self.inLine(tops: flow.nMoves, others: flow.nIn - flow.nMoves),
                             sym: "arrow.down.to.line", tint: Color.kosh)
                    FlowTile(title: "Spent", value: flow.out, sub: WalletCards.count(flow.nOut, "payment"),
                             sym: "arrow.up.right", tint: Color(light: "#C46A00", dark: "#FFA94D"))
                } else {
                    FlowTile(title: "Came in", value: flow.inn, sub: WalletCards.count(flow.nIn, "payment"),
                             sym: "arrow.down.left", tint: green, valueInk: green)
                    FlowTile(title: "Went out", value: flow.out, sub: WalletCards.count(flow.nOut, "payment"),
                             sym: "arrow.up.right", tint: Color.kosh)
                }
            }
            Text(wallet ? Self.walletCaption(phrase) : Self.caption(phrase))
                .font(.system(.caption)).foregroundStyle(.secondary)
                .padding(.horizontal, 4).fixedSize(horizontal: false, vertical: true)
        }
    }
    static func caption(_ phrase: String) -> String { Words.cap(phrase) + ", by the alerts and statements kosh has read" }
    static func walletCaption(_ phrase: String) -> String { Words.cap(phrase) + ", by the payment and top-up mails kosh has read" }
    /// "3 top-ups", "2 refunds or cashbacks", "3 top-ups, 2 refunds"
    static func inLine(tops: Int, others: Int) -> String {
        if others <= 0 { return WalletCards.count(tops, "top-up") }
        if tops <= 0 { return others == 1 ? "1 refund or cashback" : String(others) + " refunds or cashbacks" }
        return WalletCards.count(tops, "top-up") + ", " + WalletCards.count(others, "refund")
    }
}

/// an account in the list: its badge; the bank, kind and last four; where the balance comes from with a dot for
/// how fresh; the balance on the right
struct BankRow: View {
    @Environment(Store.self) private var store
    let a: Account
    var logos: Bool = false
    var body: some View {
        let today: String = store.snap.today
        let age: Int = BalanceWords.age(a, today: today)
        // the bank's own word for the account's type, never a guess from its display name ("HDFC Bank"): a type no
        // mail has printed is said as that, so a fixed deposit is never read as savings (Details.typeWord)
        let kind: String = Details.typeWord(a.atype)
        let head: String = kind.isEmpty ? "Account" : kind
        let base: String = a.pending == true ? head + " · number not seen yet" : (a.last.isEmpty ? head : head + " ••" + a.last) + (kind.isEmpty ? " · " + Details.noType : "")
        let which: String = a.isDebitCardOnly ? "Debit card ••" + (a.debit?.first ?? "") + " · account not known yet" : (a.debitWords.isEmpty ? base : base + " · " + a.debitWords)
        let title: String = AccountPage.title(a)
        let figure: String = a.balance.map { Fmt.rupees($0) } ?? a.foreignFigure ?? "—"
        let ink: Color = (a.balance == nil && a.foreignFigure == nil) || age == 2 ? Color.secondary : Color.primary
        let addWord: String = a.ccy != nil ? "In " + (a.ccy ?? "") + ", not in your rupee totals" : store.live == nil ? "No balance yet" : a.isDebitCardOnly ? "Tap to say which account it’s for" : "Tap to type today’s balance"
        HStack(alignment: .top, spacing: 12) {
            InstIcon(name: a.bank, color: Color(hex: a.color), size: 38, hint: a.name, mark: !logos)
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(.system(.subheadline, weight: .semibold)).lineLimit(1)
                Text(which).font(.system(.caption)).monospacedDigit().foregroundStyle(.secondary).lineLimit(1)
                if a.balance != nil {
                    HStack(spacing: 5) {
                        Circle().fill(BalanceWords.color(age)).frame(width: 7, height: 7)
                        Text(BalanceWords.source(a, today: today)).lineLimit(1)
                    }
                    .font(.system(.caption, weight: .semibold))
                    .foregroundStyle(BalanceWords.ink(age))
                    .padding(.top, 1)
                } else {
                    Text(addWord).font(.system(.caption, weight: .semibold))
                        .foregroundStyle(store.live != nil ? Color.kosh : Color.secondary)
                        .padding(.top, 1)
                }
            }
            Spacer(minLength: 8)
            Text(figure)
                .font(.system(.subheadline, design: .rounded, weight: .semibold)).monospacedDigit()
                .foregroundStyle(ink)
                .lineLimit(1).minimumScaleFactor(0.7)
                .privacySensitive()
                .padding(.top, 1)
                .layoutPriority(1)
        }
        .padding(.vertical, 12)
        .contentShape(Rectangle())
        .accessibilityElement(children: .ignore)
        .spokenFigures(BankRow.spoken(title: title, which: which, how: a.balance == nil ? addWord : BalanceWords.source(a, today: today), figure: a.balance.map { Fmt.rupees($0) } ?? a.foreignFigure),
                       hidden: BankRow.spoken(title: title, which: which, how: a.balance == nil ? addWord : BalanceWords.source(a, today: today), figure: nil))
        .accessibilityHint("Opens the account")
    }
}

extension BankRow {
    /// "HDFC Savings, Savings ••4821, Your bank’s alert, today, ₹48,250" (the figure left out while amounts are hidden)
    static func spoken(title: String, which: String, how: String, figure: String?) -> String {
        var bits: [String] = [title, which, how]
        if let figure { bits.append(figure) }
        return bits.filter { !$0.isEmpty }.joined(separator: ", ")
    }
}

/// what kosh asks before it counts something as yours: a name on your mail that is no one in the household yet, a
/// bank account only another app's or shop's mail names, and payments it can't tell the account of. One row each
struct AccountQuestions: View {
    @Environment(Store.self) private var store
    @State private var placing: AcctUnplaced? = nil
    var body: some View {
        let people: [PersonToConfirm] = store.snap.peopleToConfirm ?? []
        let maybe: [AcctMaybe] = (store.snap.acctMaybe ?? []).filter { store.live?.hidden.contains($0.key) != true }
        let unplaced: [AcctUnplaced] = store.snap.acctUnplaced ?? []
        let live: Bool = store.live != nil
        if !people.isEmpty || !maybe.isEmpty || !unplaced.isEmpty {
            VStack(alignment: .leading, spacing: 8) {
                GroupLabel(title: "kosh is asking")
                VStack(spacing: 0) {
                    ForEach(Array(people.enumerated()), id: \.element.id) { i, p in
                        if i > 0 { RowRule(inset: 50) }
                        ask(sym: "person.crop.circle.badge.questionmark", title: p.full, line: AccountQuestions.personLine(p)) {
                            if live {
                                HStack(spacing: 8) {
                                    Button("No") { store.live?.setHidden("name:" + p.id, true) }.buttonStyle(.glass)
                                        .accessibilityLabel("No, " + p.full + " isn’t family")
                                    Button("Add") { store.live?.addPerson(name: p.full, rel: "") }.buttonStyle(.glassProminent).koshFilled()
                                        .accessibilityLabel("Add " + p.full + " to the household")
                                }
                            }
                        }
                    }
                    ForEach(Array(maybe.enumerated()), id: \.element.id) { i, q in
                        if i > 0 || !people.isEmpty { RowRule(inset: 50) }
                        ask(sym: "building.columns", title: q.bank + " ••" + q.last, line: AccountQuestions.maybeLine(q)) {
                            if live {
                                HStack(spacing: 8) {
                                    Button("No") { store.live?.setHidden(q.key, true) }.buttonStyle(.glass)
                                        .accessibilityLabel("No, " + q.bank + " ••" + q.last + " isn’t ours")
                                    Button("Ours") { store.live?.confirmAccount(q.key) }.buttonStyle(.glassProminent).koshFilled()
                                        .accessibilityLabel("Yes, " + q.bank + " ••" + q.last + " is ours")
                                }
                            }
                        }
                    }
                    ForEach(Array(unplaced.enumerated()), id: \.offset) { i, u in
                        if i > 0 || !people.isEmpty || !maybe.isEmpty { RowRule(inset: 50) }
                        ask(sym: "questionmark.folder", title: AccountQuestions.unplacedTitle(u), line: AccountQuestions.unplacedLine(u)) {
                            if live && !AccountQuestions.choices(u, store.snap.accounts).isEmpty {
                                Button("Place") { placing = u }.buttonStyle(.glassProminent).koshFilled()
                                    .accessibilityLabel("Place " + AccountQuestions.unplacedTitle(u).lowercased())
                            }
                        }
                    }
                }
                .rowsCard()
            }
            .sheet(item: $placing) { u in
                AccountPicker(title: u.why == "statement" ? "This statement is for…" : "These payments are…",
                              note: AccountQuestions.placeNote(u), accounts: AccountQuestions.choices(u, store.snap.accounts)) { a in
                    store.live?.placeUnplaced(u, to: a.last)
                }
                .presentationDetents([.medium])
            }
        }
    }
    func ask<B: View>(sym: String, title: String, line: String, @ViewBuilder buttons: () -> B) -> some View {
        HStack(alignment: .center, spacing: 12) {
            Image(systemName: sym).font(.system(size: 17, weight: .semibold)).foregroundStyle(Color.kosh).frame(width: 38)
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(.system(.subheadline, weight: .semibold)).lineLimit(1)
                Text(line).font(.system(.caption)).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            }
            Spacer(minLength: 8)
            buttons()
        }
        .padding(.vertical, 12)
    }
    /// "Named on 1 account’s mail and 21 mails in all. Part of your household?"
    static func personLine(_ p: PersonToConfirm) -> String {
        let n: Int = p.accounts + p.cards + p.wallets
        let what: String = n == 1 ? (p.accounts == 1 ? "an account’s" : p.cards == 1 ? "a card’s" : "a wallet’s") : String(n) + " accounts’ and cards’"
        return "Named on " + what + " mail. Set apart from yours until you say. Part of your household?"
    }
    static func maybeLine(_ q: AcctMaybe) -> String {
        let pays: String = q.n == 1 ? "1 payment" : String(q.n) + " payments"
        return "Only another app’s or shop’s mail names it (" + pays + "), never the bank’s own. Is it yours?"
    }
    static func unplacedTitle(_ u: AcctUnplaced) -> String {
        if u.why == "statement" { return u.n == 1 ? "1 " + u.bank + " statement to place" : String(u.n) + " " + u.bank + " statements to place" }
        return u.n == 1 ? "1 " + u.bank + " payment to place" : String(u.n) + " " + u.bank + " payments to place"
    }
    /// why kosh couldn't tell, in its words
    static func unplacedLine(_ u: AcctUnplaced) -> String {
        let one: Bool = u.n == 1
        switch u.why {
        case "statement":
            return (one ? "It prints no account number" : "They print no account number") + ", and you have more than one " + u.bank + " account. Its balance waits until you say which."
        case "digits":
            return "The digits " + (one ? "it prints fit" : "they print fit") + " more than one of your " + u.bank + " accounts. " + (one ? "It’s" : "They’re") + " in your spending, not in any balance."
        default:
            return (one ? "Its mail names no account" : "Their mail names no account") + ", and you have more than one at " + u.bank + ". " + (one ? "It’s" : "They’re") + " in your spending, not in any balance."
        }
    }
    static func placeNote(_ u: AcctUnplaced) -> String {
        u.why == "statement" ? "Its closing balance and lines count for that account." : "They move to that account and count in its balance."
    }
    /// the bank's accounts it could be
    static func choices(_ u: AcctUnplaced, _ accounts: [Account]) -> [Account] {
        let opts: [String] = u.options ?? []
        return accounts.filter { $0.bank == u.bank && !$0.isDebitCardOnly && $0.tag == nil && !$0.last.isEmpty && (opts.isEmpty || opts.contains($0.last)) }
    }
}

extension AcctUnplaced: Identifiable { var id: String { bank + "|" + (why ?? "") } }

/// cash in hand, counted by you
struct CashRow: View {
    @Environment(Store.self) private var store
    var body: some View {
        let c: Capture? = store.latest("cash")
        let today: String = store.snap.today
        let age: Int = CashRow.age(c, today: today)
        VStack(alignment: .leading, spacing: 8) {
            GroupLabel(title: "Cash")
            Button { store.sheet = .capture("cash") } label: {
                HStack(alignment: .top, spacing: 12) {
                    IconTile(symbol: "banknote", color: Color(hex: "#34C759"), size: 38)
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Cash in hand").font(.system(.subheadline, weight: .semibold)).foregroundStyle(Color.primary)
                        if c != nil {
                            HStack(spacing: 5) {
                                Circle().fill(BalanceWords.color(age)).frame(width: 7, height: 7)
                                Text(CashRow.counted(c, today: today)).lineLimit(1)
                            }
                            .font(.system(.caption, weight: .semibold))
                            .foregroundStyle(BalanceWords.ink(age))
                            .padding(.top, 1)
                        } else {
                            Text("Count it once, kosh keeps the tally").font(.system(.caption)).foregroundStyle(.secondary)
                        }
                    }
                    Spacer(minLength: 8)
                    Text(c == nil ? "Count" : Fmt.rupees(store.cashInHand))
                        .font(.system(.subheadline, design: .rounded, weight: .semibold)).monospacedDigit()
                        .foregroundStyle(c == nil ? Color.kosh : Color.primary)
                        .lineLimit(1).minimumScaleFactor(0.7)
                        .privacySensitive()
                        .padding(.top, 1)
                }
                .padding(.vertical, 12)
                .contentShape(Rectangle())
            }
            .buttonStyle(.press)
            .rowsCard()
            .accessibilityHint("Count the cash you have")
        }
    }
}

extension CashRow {
    static func counted(_ c: Capture?, today: String) -> String {
        guard let c else { return "Tap to count it" }
        return "Counted " + Day.when(c.date, today: today)
    }
    /// counted in the last two days (0), this month or so (1), longer ago (2)
    static func age(_ c: Capture?, today: String) -> Int {
        guard let c else { return 2 }
        let days: Int = Day.cal.dateComponents([.day], from: Day.date(c.date), to: Day.date(today)).day ?? 99
        if days <= 2 { return 0 }
        if days <= 40 { return 1 }
        return 2
    }
}

/// how kosh knows a balance, and how to keep it current
struct BalanceHelp: View {
    @State private var shown = false
    var body: some View {
        let turn: Double = shown ? 180 : 0
        VStack(alignment: .leading, spacing: 0) {
            Button { withAnimation(Fold.motion(opening: !shown)) { shown.toggle() } } label: {
                HStack(spacing: 12) {
                    Image(systemName: "info").font(.system(size: 14, weight: .bold)).foregroundStyle(Color.kosh)
                        .frame(width: 30, height: 30)
                        .background(Color.kosh.opacity(0.12), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
                    Text("How kosh knows a balance").font(.system(.subheadline, weight: .semibold)).foregroundStyle(Color.primary)
                    Spacer(minLength: 8)
                    Image(systemName: "chevron.down").font(.system(.caption, weight: .bold)).foregroundStyle(.secondary)
                        .rotationEffect(Angle.degrees(turn))
                        .animation(Fold.turn, value: shown)
                }
                .frame(minHeight: 56)
                .contentShape(Rectangle())
            }
            .buttonStyle(.press)
            .accessibilityHint(shown ? "Folds the explanation away" : "Shows how it works")
            Unfold(open: shown) {
                VStack(alignment: .leading, spacing: 14) {
                    line("envelope.fill", "A balance your bank sends", "Some banks put it in every alert, or send it daily. kosh takes the newest.")
                    line("doc.text.fill", "Your monthly statement", "Its closing balance is exact for that day. kosh opens the newest one per bank, once you’ve typed its password.")
                    line("hand.tap.fill", "One you type", "Tap an account and enter what your bank’s app shows.")
                    line("arrow.forward.circle.fill", "Then carried forward", "From the newest of these, every payment in or out since is added. A payment your bank told you about only by SMS can’t be seen, so an email alert for every debit and credit keeps it exact.")
                }
                .padding(.bottom, 16)
            }
        }
        .padding(.horizontal, 16)
        .background(Color.surface, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
    }
    func line(_ sym: String, _ title: String, _ body: String) -> some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: sym).font(.subheadline).foregroundStyle(Color.kosh).frame(width: 30)
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(.subheadline.weight(.semibold))
                Text(body).font(.footnote).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            }
        }
        .accessibilityElement(children: .combine)
    }
}

/// another Gmail, for accounts whose mail goes elsewhere
struct AnotherGmail: View {
    @Environment(Store.self) private var store
    var body: some View {
        if let live = store.live, live.signedIn {
            Button { store.betaSheet = .accounts } label: {
                Label("Accounts in another Gmail? Add it", systemImage: "envelope.badge.plus").font(.subheadline.weight(.medium))
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.press)
            .foregroundStyle(Color.kosh)
            .padding(.top, 4)
        }
    }
}
