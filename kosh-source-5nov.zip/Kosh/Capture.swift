import SwiftUI
import PhotosUI
import Vision

// MARK: - Capture: a photo or a number for what email can't see

struct CaptureSheet: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    let kind: String

    @State private var item: PhotosPickerItem?
    @State private var reading = false
    @State private var lines: [String] = []
    @State private var amounts: [Double] = []
    @State private var amount = ""
    @State private var note = ""
    @State private var readFailed = false

    struct Meta { let title: String; let sym: String; let color: Color; let prompt: String; let amountLabel: String; let notePrompt: String; let keywords: [String] }

    var meta: Meta {
        if kind == "cash" {
            return Meta(title: "Cash in hand", sym: "banknote.fill", color: Color(hex: "#34C759"),
                        prompt: "Count the cash at home and in wallets. kosh adds it to your net worth and tracks cash spends against it.",
                        amountLabel: "Cash in hand", notePrompt: "Where it is (optional)", keywords: [])
        }
        if kind.hasPrefix("loan:"), let l = store.snap.loans.first(where: { "loan:" + $0.id == kind }) {
            return Meta(title: "\(l.name) balance", sym: "house.fill", color: Color(hex: "#FF3B30"),
                        prompt: "Snap the latest loan statement or the bank app’s loan page. kosh reads the outstanding amount and rate.",
                        amountLabel: "Outstanding", notePrompt: "Interest rate, tenure left",
                        keywords: ["outstanding", "principal", "balance", "rate", "interest", "tenure", "emi"])
        }
        if kind.hasPrefix("policy:"), let p = store.snap.policies.first(where: { "policy:" + $0.id == kind }) {
            return Meta(title: "\(p.insurer)", sym: PolicyLook.sym(p.type), color: PolicyLook.color(p.type),
                        prompt: "Snap the policy schedule. kosh reads the policy number, cover and renewal date.",
                        amountLabel: "Cover (sum insured)", notePrompt: "Policy number, nominee",
                        keywords: ["policy", "sum insured", "sum assured", "cover", "nominee", "premium", "expiry", "renewal", "valid"])
        }
        if kind.hasPrefix("lease:") {
            return Meta(title: "Rent agreement", sym: "doc.text.fill", color: Color.green,
                        prompt: "Snap the first and last pages of the agreement. kosh reads the rent, deposit, dates and escalation.",
                        amountLabel: "Monthly rent", notePrompt: "Start and end, escalation, deposit",
                        keywords: ["rent", "deposit", "commenc", "period", "month", "increase", "escalat", "lessee", "tenant"])
        }
        if kind == "gold" {
            return Meta(title: "Gold and other savings", sym: "seal.fill", color: Color(hex: "#FFB300"),
                        prompt: "Jewellery, coins, a gold bond, NPS, a post office scheme. A rough value is enough.",
                        amountLabel: "Value", notePrompt: "What it is",
                        keywords: ["gold", "grams", "nps", "pran", "value", "certificate", "maturity"])
        }
        return Meta(title: "Anything else", sym: "tray.full.fill", color: Color.gray,
                    prompt: "NPS, a post office scheme, a chit, money left with family. Snap a document or type it in.",
                    amountLabel: "Value", notePrompt: "What it is", keywords: ["value", "maturity", "balance", "amount"])
    }

    var value: Double? { Double(amount.replacingOccurrences(of: ",", with: "")).map(TypedAmount.cap) }

    var body: some View {
        let m = meta
        NavigationStack {
            ObsidianForm {
                Section {
                    VStack(spacing: 10) {
                        IconTile(symbol: m.sym, color: m.color, size: 58)
                        Text(m.title).font(.title3.weight(.semibold)).multilineTextAlignment(.center)
                        Text(m.prompt)
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                            .multilineTextAlignment(.center)
                    }
                    .frame(maxWidth: .infinity)
                    .listRowBackground(Color.clear)
                }
                if kind != "cash" {
                    Section {
                        PhotosPicker(selection: $item, matching: .images) {
                            Label(lines.isEmpty ? "Choose a photo of it" : "Choose another photo", systemImage: "photo.on.rectangle.angled")
                        }
                        if reading {
                            HStack(spacing: 10) {
                                ProgressView()
                                Text("kosh is reading it…").foregroundStyle(.secondary)
                            }
                        }
                        if readFailed {
                            Text("Couldn’t read any text in that photo. Try a sharper one, or type it below.")
                                .font(.subheadline)
                                .foregroundStyle(Color.orange)
                        }
                    } footer: {
                        Text("Read on this phone with Apple’s text recognition. The photo isn’t saved.")
                    }
                }
                if !amounts.isEmpty {
                    Section("Amounts kosh found") {
                        ScrollView(.horizontal) {
                            HStack(spacing: 8) {
                                ForEach(amounts, id: \.self) { a in
                                    Button {
                                        amount = String(Int(safe: a.rounded()))
                                    } label: {
                                        Text(Fmt.rupees(a)).font(.subheadline.weight(.semibold))
                                    }
                                    .buttonStyle(.bordered)
                                    .buttonBorderShape(.capsule)
                                    .tint(value == a.rounded() ? Color.kosh : Color.gray)
                                }
                            }
                        }
                        .scrollIndicators(.hidden)
                    }
                }
                if !lines.isEmpty {
                    Section {
                        ForEach(lines, id: \.self) { l in
                            Button {
                                note = note.isEmpty ? l : note + "\n" + l
                            } label: {
                                HStack(alignment: .top) {
                                    Text(l).font(.subheadline).foregroundStyle(Color.primary).multilineTextAlignment(.leading)
                                    Spacer(minLength: 6)
                                    Image(systemName: "plus.circle").foregroundStyle(Color.kosh)
                                }
                            }
                        }
                    } header: {
                        Text("Lines kosh picked out")
                    } footer: {
                        Text("Tap a line to keep it in the notes.")
                    }
                }
                Section(m.amountLabel) {
                    HStack {
                        Text("₹").foregroundStyle(.secondary)
                        TextField("0", text: $amount).keyboardType(.decimalPad)
                    }
                }
                Section("Notes") {
                    TextField(m.notePrompt, text: $note, axis: .vertical).lineLimit(2...6)
                }
            }
            .navigationTitle("Add")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        store.addCapture(kind: kind, title: m.title, amount: value, text: note.trimmingCharacters(in: .whitespacesAndNewlines))
                        dismiss()
                    }
                    .fontWeight(.semibold)
                    .disabled(value == nil && note.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }
            .onChange(of: item) { _, new in
                guard let new else { return }
                Task { await read(new, keywords: m.keywords) }
            }
            .animation(Motion.open, value: lines)
            .animation(Motion.open, value: reading)
        }
    }

    func read(_ pick: PhotosPickerItem, keywords: [String]) async {
        reading = true
        readFailed = false
        defer { reading = false }
        guard let data = try? await pick.loadTransferable(type: Data.self) else { readFailed = true; return }
        let text = await TextReader.lines(in: data)
        if text.isEmpty { readFailed = true; return }
        let found = TextReader.amounts(in: text)
        amounts = found
        if amount.isEmpty, let first = found.first { amount = String(Int(safe: first.rounded())) }
        let picked = text.filter { line in
            let l = line.lowercased()
            return keywords.contains { l.contains($0) }
        }
        lines = Array((picked.isEmpty ? text : picked).prefix(8))
    }
}

/// Text off a photo, on the phone, and the rupee amounts in it
enum TextReader {
    static func lines(in data: Data) async -> [String] {
        var request = RecognizeTextRequest()
        request.recognitionLevel = .accurate
        request.usesLanguageCorrection = true
        guard let observations = try? await request.perform(on: data) else { return [] }
        return observations.compactMap { $0.topCandidates(1).first?.string }
            .map { $0.trimmingCharacters(in: .whitespaces) }
            .filter { !$0.isEmpty }
    }

    /// amounts written the Indian way: ₹ 1,25,000.00, Rs. 20500, INR 3,00,000
    static func amounts(in lines: [String]) -> [Double] {
        let joined = lines.joined(separator: "\n")
        let patterns = [
            "(?:₹|Rs\\.?|INR)\\s*([0-9][0-9,]*(?:\\.[0-9]{1,2})?)",
            "\\b([0-9]{1,2}(?:,[0-9]{2})+,[0-9]{3}(?:\\.[0-9]{1,2})?)\\b",
            "\\b([0-9]{1,3},[0-9]{3}(?:\\.[0-9]{1,2})?)\\b",
        ]
        var out: [Double] = []
        for p in patterns {
            guard let re = try? NSRegularExpression(pattern: p, options: [.caseInsensitive]) else { continue }
            let ns = joined as NSString
            for m in re.matches(in: joined, range: NSRange(location: 0, length: ns.length)) where m.numberOfRanges > 1 {
                let raw = ns.substring(with: m.range(at: 1)).replacingOccurrences(of: ",", with: "")
                if let v = Double(raw), v >= 100, !out.contains(v) { out.append(v) }
            }
        }
        return Array(out.sorted(by: >).prefix(6))
    }
}
