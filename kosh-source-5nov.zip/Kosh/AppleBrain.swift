import Foundation
#if canImport(FoundationModels)
import FoundationModels
#endif

// MARK: - Apple Intelligence: the model built into iOS, on this phone
//
// On an iPhone 15 Pro or later with Apple Intelligence on, iOS carries a ~3B model that runs on the
// phone's own silicon. It's about ten times the size of kosh-reader, costs nothing, needs no
// download, and nothing leaves the phone. kosh uses it three ways:
//   - to read the emails the bank rules can't (the same checks apply: anything it names that
//     isn't printed in the email is thrown out),
//   - to read policy schedules and portal pages the rules find nothing in,
//   - to answer questions about your money ("Ask kosh"), looking figures up in the ledger itself.
// Older phones keep kosh-reader.

enum AppleBrain {
    static var available: Bool {
        #if canImport(FoundationModels)
        if case .available = SystemLanguageModel.default.availability { return true }
        #endif
        return false
    }

    /// why it can't run here, in words
    static var unavailableReason: String {
        #if canImport(FoundationModels)
        switch SystemLanguageModel.default.availability {
        case .available: return ""
        case .unavailable(.deviceNotEligible): return "Apple Intelligence needs an iPhone 15 Pro or later."
        case .unavailable(.appleIntelligenceNotEnabled): return "Turn on Apple Intelligence in Settings › Apple Intelligence & Siri."
        case .unavailable(.modelNotReady): return "Apple Intelligence is still downloading its model. Try again in a while."
        case .unavailable: return "Apple Intelligence isn’t available on this phone."
        }
        #else
        return "This build doesn’t include Apple Intelligence."
        #endif
    }

    /// Why Apple's model couldn't read an email: stopped (the pass ends and carries on later) or skipped (that one email
    /// stays for another reader, the pass goes on)
    enum Failure: LocalizedError {
        case stopped(String), skipped(String)
        var errorDescription: String? {
            switch self { case .stopped(let s), .skipped(let s): return s }
        }
    }

    /// The events brief: the same event types and fields as kosh-reader v4 answers in and Claude is asked for
    /// (reader.js › CL.rules, CL_SCHEMA), cut down to fit Apple's window (instructions, schema, email and answer
    /// share about 4,000 tokens). The answer goes through reader.js › localAnswer exactly as kosh-reader's does.
    static let eventsInstructions = """
    You read one email (or bank SMS) sent to a household in India and list the money events it describes, for kosh, a \
    money app. Use only what is printed. Never guess an amount, date, digits, id or name: leave a field out when it is \
    not printed. Amounts are plain numbers in rupees (12345.5, no commas). Dates are YYYY-MM-DD; a date without a year \
    takes the email's year. dir is the owner's side: in when money came to the owner, out when it left.
    Event types and their fields:
    move: money has moved (done, past). dir, amt, date, time (HH:MM), via, party (the other side, as written), ref (UPI \
    ref, UTR or transaction id), mode (UPI, NEFT, IMPS, RTGS, NACH, ATM, POS), purpose (purchase, refund, reversal, \
    cashback, interest, dividend, salary, billpay, cardpay, emi, premium, investment, redemption, payout, topup, \
    withdrawal, fee, tax, transfer).
    balance: an available balance is printed. amt, via.
    statement: a card or account statement. total (total due), min (minimum due), due (due date), stmtDate, via.
    due: a bill, EMI or fee to pay by a date, not paid yet. what (bill, card, premium, emi, maintenance, subscription, \
    tax, fee), payee, amt, due.
    expect: money promised, not moved yet. dir, amt, what (refund, debit, credit, sip, unblock, maturity, payout), by \
    (latest date promised), on (exact day), order.
    order: a shop or app order or booking. shop, order (order id), status (placed, shipped, out, delivered, cancelled, \
    returned, refunded, declined), total.
    trade: shares bought or sold. side (buy, sell), name, isin, qty, price, value, date.
    fund: a mutual fund transaction. action (buy, sip, redeem, switch), scheme, folio, amt, units, nav, date.
    ipo: action (applied, blocked, allotted, not-allotted, unblocked), company, amt, shares.
    dividend: company, amt, date.
    deposit: a fixed or recurring deposit's step. action (open, renew, close, mature, instalment), inst, no (last 4 \
    digits of the deposit number), amt, rate, start, mat (maturity date), matAmt.
    policy: insurance. action (issued, paid, due, renewed, lapsed), insurer, policyNo, plan, premium, cover, due.
    mandate: an auto-debit or subscription. action (created, upcoming, done, cancelled, failed), party, amt, date, every \
    (week, month, quarter, year).
    account: a card or account delivered, activated, limit changed, closed. step (delivered, activated, limit, closed, \
    seen), via.
    noise: not money: OTP, offer, KYC, newsletter, security or login alert, failed or declined payment, a request \
    awaiting consent, a survey. reason (otp, offer, kyc, info, failed, request, service, security, newsletter, delivery).
    via is the owner's card or account: kind (card, account, wallet, upi, other), inst (short bank name: HDFC, ICICI, \
    SBI Card, Axis, Kotak), last4 (its last 4 digits as printed).
    Rules: future tense ("will be debited", "is due") is never a move. A paid receipt is a move out with party = the \
    shop, plus an order if it prints an order id. A premium receipt is policy paid and a move out with purpose premium. \
    A bill paid through an app or bank is a move out with purpose billpay and party = the biller. A card bill payment \
    received by the card is a move in with purpose cardpay on the card. A refund credited is a move in with purpose \
    refund; a refund promised is expect in with what refund. A debit alert with a balance is a move and a balance. An \
    email that isn't money has one noise event.
    """

    static let docInstructions = """
    You read one page of a document for kosh, a household money app in India: an insurance policy \
    schedule, or a property-tax portal page. Report only what is printed on the page. Amounts are \
    in rupees, digits only (a cover written as 5 lakh is 500000). Dates are YYYY-MM-DD. If the page \
    has neither a policy nor a property record, the kind is not_money.
    """

    #if canImport(FoundationModels)
    /// the owner's side of a move, balance, statement or account (reader.js › CL_SCHEMA "via")
    @Generable
    struct Via {
        @Guide(description: "card, account, wallet, upi or other")
        var kind: String?
        @Guide(description: "Short bank or issuer name, e.g. HDFC")
        var inst: String?
        @Guide(description: "Last 4 digits of the card or account, as printed")
        var last4: String?
    }

    /// One event, every type's fields side by side (each type uses its own; reader.js › clEvent keeps only those)
    @Generable
    struct MailEvent {
        @Guide(description: "The event's type", .anyOf(["move", "balance", "statement", "due", "expect", "order", "trade", "fund", "ipo", "dividend", "deposit", "policy", "mandate", "account", "noise"]))
        var type: String
        @Guide(description: "in or out")
        var dir: String?
        @Guide(description: "Amount in rupees")
        var amt: Double?
        @Guide(description: "YYYY-MM-DD")
        var date: String?
        @Guide(description: "HH:MM")
        var time: String?
        var via: Via?
        var party: String?
        var ref: String?
        var mode: String?
        var purpose: String?
        @Guide(description: "Statement total due, or order total, in rupees")
        var total: Double?
        @Guide(description: "Statement minimum due, in rupees")
        var min: Double?
        @Guide(description: "Due date, YYYY-MM-DD")
        var due: String?
        @Guide(description: "Statement date, YYYY-MM-DD")
        var stmtDate: String?
        var what: String?
        var payee: String?
        @Guide(description: "YYYY-MM-DD")
        var by: String?
        @Guide(description: "YYYY-MM-DD")
        var on: String?
        @Guide(description: "Order or booking id, as printed")
        var order: String?
        var shop: String?
        var status: String?
        var side: String?
        var name: String?
        var isin: String?
        var qty: Double?
        var price: Double?
        var value: Double?
        var action: String?
        var scheme: String?
        var folio: String?
        var units: Double?
        var nav: Double?
        var company: String?
        var shares: Double?
        var inst: String?
        @Guide(description: "Last 4 digits of the deposit number")
        var no: String?
        var rate: Double?
        @Guide(description: "YYYY-MM-DD")
        var start: String?
        @Guide(description: "Maturity date, YYYY-MM-DD")
        var mat: String?
        var matAmt: Double?
        var insurer: String?
        var policyNo: String?
        var plan: String?
        var premium: Double?
        var cover: Double?
        var every: String?
        var step: String?
        var reason: String?
        @Guide(description: "Currency code when not rupees, e.g. USD")
        var cur: String?
        @Guide(description: "One short line saying what the email is")
        var notes: String?
    }

    @Generable
    struct MailEvents {
        @Guide(description: "The money events this email describes, or one noise event")
        var events: [MailEvent]
    }

    @Generable
    struct DocRead {
        @Guide(description: "What the page holds", .anyOf(["policy", "property", "not_money"]))
        var kind: String
        @Guide(description: "Insurer's name")
        var insurer: String?
        @Guide(description: "Health, Life, Term, Motor, Home or Travel")
        var policyType: String?
        @Guide(description: "Plan or product name")
        var plan: String?
        @Guide(description: "Policy number exactly as printed")
        var policyNumber: String?
        @Guide(description: "Policy holder or proposer")
        var holder: String?
        @Guide(description: "Life assured or insured person")
        var insured: String?
        @Guide(description: "Nominee")
        var nominee: String?
        @Guide(description: "Sum insured or cover, in rupees")
        var cover: Double?
        @Guide(description: "Premium, in rupees")
        var premium: Double?
        @Guide(description: "Yearly, Half-yearly, Quarterly, Monthly or Single")
        var frequency: String?
        @Guide(description: "Policy start date, YYYY-MM-DD")
        var start: String?
        @Guide(description: "Policy end or maturity date, YYYY-MM-DD")
        var end: String?
        @Guide(description: "Next premium due date, YYYY-MM-DD")
        var nextDue: String?
        @Guide(description: "Property ID (PID, UPIC, PTIN, assessment or house number) exactly as printed")
        var pid: String?
        @Guide(description: "Owner's name as printed")
        var owner: String?
        @Guide(description: "Property address as printed")
        var address: String?
        @Guide(description: "Residential, Commercial and so on")
        var category: String?
        @Guide(description: "Plot area with its unit, as printed")
        var plotArea: String?
        @Guide(description: "Property tax due, in rupees")
        var taxDue: Double?
        @Guide(description: "Arrears, in rupees")
        var arrears: Double?
        @Guide(description: "Development charges due, in rupees")
        var dev: Double?
        @Guide(description: "Garbage or solid-waste charges, in rupees")
        var garbage: Double?
        @Guide(description: "Total amount due, in rupees")
        var total: Double?
    }
    #endif

    /// the most of an email Apple's model is given (the same as kosh-reader: LiveSession › readerPass asks the engine for 1,800)
    static let mailLimit = 1800

    /// One email (engine.localPrompt text) in, kosh-reader v4's answer out ({"events":[…]}), so it goes through the same
    /// checks (reader.js › localAnswer: every amount and card digit printed in the mail, marked lr so it never overrides
    /// what the rules read). Throws KoshReader.Failure.tooLong for an email too long for the window even cut down,
    /// Failure.skipped for one the model won't read, Failure.stopped when it can't read at all right now.
    static func readMailEvents(_ input: String) async throws -> String {
        #if canImport(FoundationModels)
        guard available else { throw Failure.stopped(unavailableReason) }
        var text = String(input.prefix(mailLimit))
        for attempt in 0..<2 {
            // a session of its own for every email (and every try): a session takes one request at a time, and no
            // email's reading should lean on the one before
            let session = LanguageModelSession(instructions: eventsInstructions)
            do {
                let r = try await session.respond(to: text, generating: MailEvents.self,
                                                  options: GenerationOptions(sampling: .greedy, maximumResponseTokens: 700))
                return eventsJSON(r.content)
            } catch let e as LanguageModelSession.GenerationError {
                switch e {
                case .exceededContextWindowSize:
                    // once more with the email's first half (its From, Date and Subject lead it), then it's left for another reader
                    if attempt == 0 && text.count > 600 { text = String(text.prefix(text.count / 2)) + "\n[cut]"; continue }
                    throw KoshReader.Failure.tooLong
                case .guardrailViolation: throw Failure.skipped("Apple Intelligence wouldn’t read this email.")
                case .unsupportedLanguageOrLocale: throw Failure.skipped("Apple Intelligence doesn’t read this email’s language.")
                case .decodingFailure: throw Failure.skipped("Apple Intelligence’s answer didn’t come out whole.")
                case .assetsUnavailable: throw Failure.stopped("Apple Intelligence isn’t ready right now. kosh carries on reading later.")
                case .rateLimited: throw Failure.stopped("Apple Intelligence is busy. kosh carries on reading later.")
                default: throw Failure.skipped(e.localizedDescription)
                }
            }
        }
        throw KoshReader.Failure.tooLong
        #else
        throw KoshReader.Failure.unavailable
        #endif
    }

    #if canImport(FoundationModels)
    /// the events as JSON, only the fields the model filled (reader.js › clEvent checks each one against the mail)
    static func eventsJSON(_ m: MailEvents) -> String {
        var out: [[String: Any]] = []
        for e in m.events.prefix(8) {
            var o: [String: Any] = ["type": e.type]
            func put(_ k: String, _ v: String?) {
                if let t = v?.trimmingCharacters(in: .whitespacesAndNewlines), !t.isEmpty { o[k] = t }
            }
            func num(_ k: String, _ v: Double?) { if let v, v.isFinite { o[k] = v } }
            put("dir", e.dir); num("amt", e.amt); put("date", e.date); put("time", e.time)
            if let v = e.via {
                var via: [String: Any] = [:]
                if let t = v.kind?.trimmingCharacters(in: .whitespaces).lowercased(), !t.isEmpty { via["kind"] = t }
                if let t = v.inst?.trimmingCharacters(in: .whitespaces), !t.isEmpty { via["inst"] = t }
                if let t = v.last4?.trimmingCharacters(in: .whitespaces), !t.isEmpty { via["last4"] = t }
                if !via.isEmpty { o["via"] = via }
            }
            put("party", e.party); put("ref", e.ref); put("mode", e.mode); put("purpose", e.purpose)
            num("total", e.total); num("min", e.min); put("due", e.due); put("stmtDate", e.stmtDate)
            put("what", e.what); put("payee", e.payee); put("by", e.by); put("on", e.on)
            put("order", e.order); put("shop", e.shop); put("status", e.status)
            put("side", e.side); put("name", e.name); put("isin", e.isin); num("qty", e.qty); num("price", e.price); num("value", e.value)
            put("action", e.action); put("scheme", e.scheme); put("folio", e.folio); num("units", e.units); num("nav", e.nav)
            put("company", e.company); num("shares", e.shares)
            put("inst", e.inst); put("no", e.no); num("rate", e.rate); put("start", e.start); put("mat", e.mat); num("matAmt", e.matAmt)
            put("insurer", e.insurer); put("policyNo", e.policyNo); put("plan", e.plan); num("premium", e.premium); num("cover", e.cover)
            put("every", e.every); put("step", e.step); put("reason", e.reason); put("cur", e.cur); put("notes", e.notes)
            out.append(o)
        }
        return JSONText.object(["events": out])
    }
    #endif

    /// One page of a document in (engine.docPrompt text), the reader's JSON shape out.
    static func readPage(_ input: String) async throws -> String {
        #if canImport(FoundationModels)
        let session = LanguageModelSession(instructions: docInstructions)
        let r = try await session.respond(to: input, generating: DocRead.self, options: GenerationOptions(sampling: .greedy, maximumResponseTokens: 400))
        let d = r.content
        func pick(_ pairs: [(String, Any?)]) -> [String: Any] {
            var out: [String: Any] = [:]
            for (k, v) in pairs {
                if let s = v as? String, !s.isEmpty { out[k] = s }
                if let n = v as? Double, n > 0 { out[k] = n }
            }
            return out
        }
        switch d.kind {
        case "policy":
            let p = pick([("insurer", d.insurer), ("type", d.policyType), ("plan", d.plan), ("number", d.policyNumber), ("holder", d.holder),
                          ("insured", d.insured), ("nominee", d.nominee), ("cover", d.cover), ("premium", d.premium), ("frequency", d.frequency),
                          ("start", d.start), ("end", d.end), ("next_due", d.nextDue)])
            return JSONText.object(["kind": "policy", "policy": p])
        case "property":
            let p = pick([("pid", d.pid), ("owner", d.owner), ("address", d.address), ("category", d.category), ("plot_area", d.plotArea),
                          ("tax_due", d.taxDue), ("arrears", d.arrears), ("dev", d.dev), ("garbage", d.garbage), ("total", d.total)])
            return JSONText.object(["kind": "property", "property": p])
        default:
            return #"{"kind":"not_money"}"#
        }
        #else
        throw KoshReader.Failure.unavailable
        #endif
    }
}
