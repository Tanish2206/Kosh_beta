import SwiftUI

// MARK: - Calendar: what leaves and what lands, six weeks close up and a year out

struct CalendarView: View {
    @Environment(Store.self) private var store
    @State private var day: String = ""
    @Namespace private var pick

    var body: some View {
        ScrollView {
            PlanStack(.homeCalendar, spacing: 26) { id in
                switch id {
                case "tally": TallyRow().padding(.horizontal, 20)
                case "days":
                    VStack(alignment: .leading, spacing: 26) {
                        DayStrip(selection: $day, ns: pick)
                        SelectedDay(day: day).padding(.horizontal, 20)
                    }
                case "committees": CommitteesThisMonth().padding(.horizontal, 20)
                case "later": LaterList().padding(.horizontal, 20)
                case "year": LaterThisYear().padding(.horizontal, 20)
                default: EmptyView()
                }
            }
            .padding(.top, 8)
            .padding(.bottom, 30)
        }
        .onAppear {
            if !takeDay() && day.isEmpty { day = store.snap.today }
        }
        .onChange(of: store.calendarDay) { _, _ in _ = takeDay() }
        .sensoryFeedback(.selection, trigger: day)
    }

    /// a day to open on, from a reminder tapped (Notify); taken once
    func takeDay() -> Bool {
        guard let d = store.calendarDay else { return false }
        store.calendarDay = nil
        withAnimation(Motion.base) { day = d }
        return true
    }
}

struct TallyRow: View {
    @Environment(Store.self) private var store
    var body: some View {
        HStack(spacing: 12) {
            tally(title: "Still to go out", value: Fmt.words(store.stillOut), note: "committees, bills", color: Color.primary)
            tally(title: "Still to come in", value: "+" + Fmt.words(store.stillIn), note: "salary, rent, your draw", color: Color.green)
        }
    }
    func tally(title: String, value: String, note: String, color: Color) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title).font(.subheadline).foregroundStyle(.secondary)
            Text(value)
                .font(.system(.title, design: .rounded, weight: .bold))
                .foregroundStyle(color)
                .minimumScaleFactor(0.7)
                .lineLimit(1)
                .privacySensitive()
            Text("in \(store.monthName): \(note)").font(.caption).foregroundStyle(.secondary).lineLimit(2)
        }
        .card(16)
    }
}

struct DayTile: Identifiable {
    let key: String; let top: String; let big: String; let isToday: Bool; let any: Bool; let dots: [Color]
    var id: String { key }
}

struct DayStrip: View {
    @Environment(Store.self) private var store
    @Binding var selection: String
    let ns: Namespace.ID

    var tiles: [DayTile] {
        var out: [DayTile] = []
        let dated = store.datedAhead
        for k in 0...41 {
            let d = Day.add(store.snap.today, k)
            let m = String(d.prefix(7))
            if k == 0 || Day.dayNumber(d) == 1 {
                let any = store.anyDay(m).filter { !$0.lock }
                if !any.isEmpty {
                    let dots = any.prefix(3).map { $0.kind == "in" ? Color.green : ($0.cat == "committee" ? Color.sky : store.catColor($0.cat)) }
                    out.append(DayTile(key: "any:" + m, top: "ANY DAY", big: Day.monthShort(m), isToday: false, any: true, dots: dots))
                }
            }
            let items = dated.filter { $0.date == d }
            let dots = items.prefix(3).map { $0.kind == "in" ? Color.green : store.catColor($0.cat) }
            out.append(DayTile(key: d, top: Day.fmt(d, "EEE").uppercased(), big: "\(Day.dayNumber(d))", isToday: d == store.snap.today, any: false, dots: dots))
        }
        return out
    }

    var body: some View {
        ScrollViewReader { proxy in
            ScrollView(.horizontal) {
                HStack(spacing: 6) {
                    ForEach(tiles) { t in
                        let sel = t.key == selection
                        Button {
                            withAnimation(Motion.base) { selection = t.key }
                        } label: {
                            VStack(spacing: 6) {
                                Text(t.top)
                                    .font(.system(.caption2, weight: .bold))
                                    .foregroundStyle(sel ? Color.onKosh.opacity(0.85) : (t.isToday ? Color.kosh : Color.secondary))
                                Text(t.big)
                                    .font(.system(.title3, design: .rounded, weight: .semibold))
                                    .foregroundStyle(sel ? Color.onKosh : Color.primary)
                                HStack(spacing: 3) {
                                    ForEach(0..<t.dots.count, id: \.self) { i in
                                        Circle().fill(sel ? Color.onKosh : t.dots[i]).frame(width: 5, height: 5)
                                    }
                                }
                                .frame(height: 6)
                            }
                            .frame(width: t.any ? 64 : 46, height: 78)
                            .background {
                                if sel {
                                    RoundedRectangle(cornerRadius: 16, style: .continuous)
                                        .fill(Color.koshFill)
                                        .matchedGeometryEffect(id: "selected", in: ns)
                                } else {
                                    RoundedRectangle(cornerRadius: 16, style: .continuous)
                                        .fill(t.any ? Color.sky.opacity(0.08) : Color.surface)
                                }
                            }
                        }
                        .buttonStyle(.press)
                        .id(t.key)
                    }
                }
                .padding(.horizontal, 20)
            }
            .scrollIndicators(.hidden)
            // a day picked from elsewhere (a reminder tapped) is brought into view; one already in view stays put
            .onAppear { proxy.scrollTo(selection) }
            .onChange(of: selection) { _, d in withAnimation(Motion.base) { proxy.scrollTo(d) } }
        }
    }
}

struct SelectedDay: View {
    @Environment(Store.self) private var store
    let day: String
    var body: some View {
        if day.hasPrefix("any:") {
            let m = String(day.dropFirst(4))
            let items = store.anyDay(m)
            VStack(alignment: .leading, spacing: 12) {
                SectionHeader(title: "\(Day.monthName(m)), no fixed day")
                RowsCard(items: items, inset: 68) { a in AgendaRow(a: a) }
            }
        } else if !day.isEmpty {
            let items = store.datedAhead.filter { $0.date == day }
            let next = store.datedAhead.first { ($0.date ?? "") > day }
            VStack(alignment: .leading, spacing: 12) {
                SectionHeader(title: day == store.snap.today ? "Today" : Day.long(day))
                if items.isEmpty {
                    Text(next.map { "Nothing is due. Next is \($0.name.lowercased()), \(Day.short($0.date ?? ""))." } ?? "Nothing is due.")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .card(16)
                } else {
                    RowsCard(items: items, inset: 68) { a in AgendaRow(a: a) }
                }
            }
            .id(day)
            .transition(.blurReplace)
        }
    }
}

struct CommitteesThisMonth: View {
    @Environment(Store.self) private var store
    var body: some View {
        let cm = store.snap.cm
        let list = store.committees(store.who).filter { !$0.done && ($0.now > 0 || $0.draw == cm) }
            .sorted { a, b in
                if (a.draw == cm) != (b.draw == cm) { return a.draw == cm }
                return a.now > b.now
            }
        VStack(alignment: .leading, spacing: 12) {
            SectionHeader(title: "Committees in \(store.monthName)", action: "All") {
                store.commSub = .active
                store.open(.committees)
            }
            RowsCard(items: list, inset: 68) { c in
                Button { store.push(.committee(c.id)) } label: {
                HStack(spacing: 12) {
                    RingView(c: c, size: 44)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(c.name).font(.body.weight(.medium))
                        if c.draw == cm {
                            Text("Your draw").font(.subheadline.weight(.semibold)).foregroundStyle(Color.green)
                        } else {
                            Text(c.members > 0 ? "Instalment \(c.paid + 1) of \(c.members)" : "Instalment \(c.paid + 1)")
                                .font(.subheadline).foregroundStyle(.secondary)
                        }
                    }
                    Spacer()
                    VStack(alignment: .trailing, spacing: 2) {
                        Text(c.draw == cm ? "+" + Fmt.words(c.net) : Fmt.words(c.now))
                            .font(.body.weight(.semibold))
                            .foregroundStyle(c.draw == cm ? Color.green : Color.primary)
                            .privacySensitive()
                        if let d = c.draw, d != cm {
                            Text("draws \(Day.fmt(d + "-01", "MMM yyyy"))").font(.caption).foregroundStyle(.secondary)
                        }
                    }
                }
                .contentShape(Rectangle())
                }
                .buttonStyle(.press)
            }
        }
    }
}

struct LaterList: View {
    @Environment(Store.self) private var store
    var body: some View {
        let later = store.datedAhead.filter { ($0.date ?? "") > store.snap.today }
        let months = Array(Set(later.map { $0.m })).sorted()
        VStack(alignment: .leading, spacing: 22) {
            ForEach(months, id: \.self) { m in
                VStack(alignment: .leading, spacing: 12) {
                    SectionHeader(title: m == store.snap.cm ? "Rest of \(Day.monthName(m))" : Day.monthName(m))
                    RowsCard(items: later.filter { $0.m == m }, inset: 68) { a in AgendaRow(a: a) }
                }
            }
        }
    }
}

/// The longer view: premiums, maturities, lease ends and rent rises
struct LaterThisYear: View {
    @Environment(Store.self) private var store
    var body: some View {
        let end = Day.add(store.snap.today, 42)
        let items = store.laterDue.filter { $0.date > end }
        if !items.isEmpty {
            VStack(alignment: .leading, spacing: 12) {
                SectionHeader(title: "Later this year", detail: "premiums, maturities, leases")
                RowsCard(items: items, inset: 68) { d in DueRow(d: d) }
            }
        }
    }
}

struct DueRow: View {
    @Environment(Store.self) private var store
    let d: DueItem
    var body: some View {
        HStack(spacing: 12) {
            DateBadge(date: d.date, today: d.date == store.snap.today)
            VStack(alignment: .leading, spacing: 2) {
                Text(d.title).font(.body.weight(.medium)).lineLimit(1)
                Text(d.sub).font(.subheadline).foregroundStyle(.secondary).lineLimit(2)
            }
            Spacer(minLength: 8)
            if d.amount > 0 {
                Text((d.incoming ? "+" : "") + Fmt.words(d.amount))
                    .font(.body.weight(.semibold))
                    .monospacedDigit()
                    .foregroundStyle(d.incoming ? Color.green : Color.primary)
                    .privacySensitive()
            } else {
                Image(systemName: d.sym).foregroundStyle(d.color)
            }
        }
    }
}
