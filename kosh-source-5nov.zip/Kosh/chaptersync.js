/* kosh chapter sync: a Chapter several people share, as an append-only log of signed operations (CHAPTERS.md).

   Every change anyone makes to a shared Chapter is one operation ("op"): open the chapter, invite, join, add a payment,
   edit it, drop it, settle up, leave. Each op is signed by the key of the phone (or browser) that made it, sealed with
   the chapter's own key (which travels only inside the invite link's # part, never to a server) and handed to a
   transport (ChapterTransport in Kosh/ChapterTransport.swift; an in-memory one for tests). Every phone keeps every op
   it has seen and works the chapter out again from all of them, in one fixed order, so two phones holding the same ops
   reach the same chapter to the paisa whatever order the ops came in, however late, however often.

     op      { v, ch, by, n, lc, at, k, b }: the chapter, the author's public key, the author's own count (1, 2, 3…), a
             Lamport clock (one more than the highest op the author held), the author's day (shown, never trusted for
             order), the kind and its body. Its id is the hash of its canonical text; it is signed as that text.
     order   by lc, then the author's key, then n, then id: the same on every phone.
     money   whole paise, never fractions of a rupee, so no phone rounds differently.

   The rules (each one a test in engine-test/chaptersync.js):
   - Only the person who opened the chapter can open it: its id is the hash of their key and a nonce they chose.
   - An op counts only if its signature holds and its author is a member at that point in the order; a member who left
     (or was removed by the owner) keeps their history, but nothing they sign after it counts.
   - Joining needs an invite's secret (the link's); an invite can be closed, can be for N joins, and can run out.
   - A payment's figure and payer are its adder's to change (it came from their mail or their hand); anyone in the
     chapter may change how it is split, its name or its kind. A split that gives away more than was paid is refused.
   - Settling up counts once the person paid says so (they made it, or confirmed it); "I paid" alone is shown, waiting.
   - Two payments of the same figure a day apart added by two people (a joint account's alert in both mailboxes) are
     both kept and named as maybe the same: kosh never drops a rupee on a guess, and never counts one twice unasked.
   - The same author signing two different ops with one count (a fork) keeps the one with the smaller id, and says so.

   Privacy: an offered payment carries its day, a cleaned name, its figure, its kind, who paid and the split. Never a
   card or account's digits, a UPI ID, a bank, the mail, or any other payment (offer() is the one door out).

   The ledger: a payment offered from your mail stays linked to its row on your phone only (links, never sent). What
   the chapter says your part is becomes the row's "mine" (what counts as your spending everywhere), and when your
   mail changes the row (money came back, a statement's figure), the chapter is offered the new figure (ledger()).

   Crypto is the caller's: { hash(text) → hex, verify(pub, text, sig) → bool, seal(key, text) → b64, open(key, b64) →
   text | null } and a signer { pub, sign(text) → sig }. The phone lends CryptoKit (P-256 and AES-GCM, as KoshNative
   lends its hashes); the tests lend Node's. It is outside every reading fingerprint: changing it reads no mail again. */

var KoshChapterSync = (function (E) {
  'use strict';
  var V = 1;
  var MOST = 12;             // the most people one payment is split between (SplitWays.most)
  var MOST_SHARES = 9;       // the most shares one person counts for (SplitWays.mostShares)
  var MOST_PAISE = 1e11;     // ₹100 crore: past it, a figure is a misreading
  var KINDS = { open: 1, invite: 1, revoke: 1, join: 1, name: 1, meta: 1, pay: 1, edit: 1, drop: 1, undo: 1, settle: 1, ok: 1, leave: 1, remove: 1 };

  // ---- small, exact helpers ----

  /* canonical JSON: keys sorted at every level, no spaces, undefined left out; what is signed and hashed */
  function canon(x) {
    if (x === null || typeof x !== 'object') return JSON.stringify(x === undefined ? null : x);
    if (Array.isArray(x)) return '[' + x.map(canon).join(',') + ']';
    return '{' + Object.keys(x).filter(function (k) { return x[k] !== undefined; }).sort().map(function (k) { return JSON.stringify(k) + ':' + canon(x[k]); }).join(',') + '}';
  }
  function isDay(d) {
    if (typeof d !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(d)) return false;
    var t = Date.UTC(+d.slice(0, 4), +d.slice(5, 7) - 1, +d.slice(8, 10));
    return new Date(t).toISOString().slice(0, 10) === d;
  }
  function dayNo(d) { return Math.round(Date.UTC(+d.slice(0, 4), +d.slice(5, 7) - 1, +d.slice(8, 10)) / 864e5); }
  function isPaise(v) { return typeof v === 'number' && isFinite(v) && Math.floor(v) === v && v > 0 && v <= MOST_PAISE; }
  function text(s, most) {
    if (typeof s !== 'string') return '';
    var t = s.replace(/[\u0000-\u001f\u007f]+/g, ' ').replace(/\s+/g, ' ').trim();
    return t.length > most ? t.slice(0, most).trim() : t;
  }
  function isId(s) { return typeof s === 'string' && /^[a-z0-9]{8,40}$/.test(s); }
  function cmp(a, b) { return a < b ? -1 : a > b ? 1 : 0; }
  function rupees(p) { return Math.round(p) / 100; }

  // ---- one payment's split, to the paisa (SplitWays.parts, in whole paise) ----

  /* each person's part of `amt` paise paid by `payer`. Whoever is out of it takes nothing; the others' parts are worked
     out; the payer takes what is left, so the parts always come to the payment (a rounding paisa lands on the payer, as
     SplitWays has it). Seats after the payer go in member-id order, so every phone works it out the same.
     way: equal · shares (sh: {mid: n}) · exact (am: {mid: paise}). null when it can't be made: nobody in it, someone
     unknown, or more given away than was paid */
  function parts(amt, payer, split, known) {
    if (!isPaise(amt) || !split || typeof split !== 'object') return null;
    var who = Array.isArray(split.who) ? split.who.slice() : [];
    if (!who.length || who.length > MOST) return null;
    var seen = {};
    for (var i = 0; i < who.length; i++) {
      if (typeof who[i] !== 'string' || seen[who[i]] || (known && !known[who[i]])) return null;
      seen[who[i]] = 1;
    }
    var payerIn = !!seen[payer];
    var others = who.filter(function (m) { return m !== payer; }).sort(cmp);
    var out = {};
    out[payer] = 0;
    others.forEach(function (m) { out[m] = 0; });
    var way = split.way || 'equal';
    if (way === 'equal') {
      var n = others.length + (payerIn ? 1 : 0);
      var part = Math.round(amt / n);
      others.forEach(function (m) { out[m] = part; });
    } else if (way === 'shares') {
      var sh = split.sh || {}, all = 0, bad = false;
      who.forEach(function (m) {
        var s = sh[m] === undefined ? 1 : sh[m];
        if (typeof s !== 'number' || Math.floor(s) !== s || s < 0 || s > MOST_SHARES) bad = true; else all += s;
      });
      if (bad || all <= 0) return null;
      others.forEach(function (m) { var s = sh[m] === undefined ? 1 : sh[m]; out[m] = Math.round(amt * s / all); });
    } else if (way === 'exact') {
      var am = split.am || {};
      for (var j = 0; j < others.length; j++) {
        var a = am[others[j]];
        if (typeof a !== 'number' || Math.floor(a) !== a || a < 0) return null;
        out[others[j]] = a;
      }
    } else return null;
    var given = others.reduce(function (s, m) { return s + out[m]; }, 0);
    out[payer] = amt - given;
    if (out[payer] < 0) return null;
    return out;
  }

  /* the fewest payments that square a chapter: whoever owes most pays whoever is owed most, and on; ties go by member
     id so every phone lists the same moves */
  function squares(net) {
    var owe = [], get = [];
    Object.keys(net).sort(cmp).forEach(function (m) {
      if (net[m] < 0) owe.push({ m: m, v: -net[m] }); else if (net[m] > 0) get.push({ m: m, v: net[m] });
    });
    var by = function (a, b) { return b.v - a.v || cmp(a.m, b.m); };
    owe.sort(by); get.sort(by);
    var out = [], i = 0, j = 0;
    while (i < owe.length && j < get.length) {
      var amt = Math.min(owe[i].v, get[j].v);
      if (amt > 0) out.push({ from: owe[i].m, to: get[j].m, amt: amt });
      owe[i].v -= amt; get[j].v -= amt;
      if (owe[i].v === 0) i++;
      if (get[j].v === 0) j++;
    }
    return out;
  }

  // ---- what each kind of op may carry ----

  function cleanSplit(s) {
    if (!s || typeof s !== 'object') return null;
    var out = { way: s.way === 'shares' || s.way === 'exact' ? s.way : 'equal', who: Array.isArray(s.who) ? s.who.filter(function (m) { return typeof m === 'string'; }).slice(0, MOST + 1) : [] };
    if (out.way === 'shares' && s.sh && typeof s.sh === 'object') out.sh = s.sh;
    if (out.way === 'exact' && s.am && typeof s.am === 'object') out.am = s.am;
    return out;
  }
  /* the body each kind keeps, every field checked; null refuses the op */
  function body(k, b) {
    b = b && typeof b === 'object' ? b : {};
    switch (k) {
      case 'open': {
        var t = text(b.t, 60);
        if (!t || typeof b.nonce !== 'string' || b.nonce.length < 16 || b.nonce.length > 64) return null;
        return { t: t, kind: b.kind === 'event' || b.kind === 'home' ? b.kind : 'trip', from: isDay(b.from) ? b.from : undefined, to: isDay(b.to) ? b.to : undefined, name: text(b.name, 40) || 'Someone', nonce: b.nonce };
      }
      case 'invite':
        if (!isId(b.iv) || typeof b.h !== 'string' || !/^[0-9a-f]{64}$/.test(b.h)) return null;
        return { iv: b.iv, h: b.h, uses: typeof b.uses === 'number' && Math.floor(b.uses) === b.uses && b.uses > 0 ? Math.min(b.uses, 99) : 0, until: isDay(b.until) ? b.until : undefined };
      case 'revoke': return isId(b.iv) ? { iv: b.iv } : null;
      case 'join':
        if (!isId(b.iv) || typeof b.key !== 'string' || b.key.length < 16 || b.key.length > 64) return null;
        return { iv: b.iv, key: b.key, name: text(b.name, 40) || 'Someone' };
      case 'name': { var nm = text(b.name, 40); return nm ? { name: nm } : null; }
      case 'meta': {
        var m = {};
        if (b.t !== undefined) { m.t = text(b.t, 60); if (!m.t) return null; }
        if (b.from !== undefined) { if (b.from !== '' && !isDay(b.from)) return null; m.from = b.from; }
        if (b.to !== undefined) { if (b.to !== '' && !isDay(b.to)) return null; m.to = b.to; }
        return Object.keys(m).length ? m : null;
      }
      case 'pay':
        if (!isId(b.p) || !isDay(b.d) || !isPaise(b.amt) || typeof b.by !== 'string') return null;
        return { p: b.p, d: b.d, what: text(b.what, 60) || 'Payment', amt: b.amt, by: b.by, split: cleanSplit(b.split), cat: text(b.cat, 30) || undefined, src: b.src === 'mail' || b.src === 'cash' ? b.src : 'typed' };
      case 'edit': {
        if (!isId(b.p) || !b.set || typeof b.set !== 'object') return null;
        var s = {}, set = b.set;
        if (set.d !== undefined) { if (!isDay(set.d)) return null; s.d = set.d; }
        if (set.what !== undefined) { s.what = text(set.what, 60); if (!s.what) return null; }
        if (set.amt !== undefined) { if (!isPaise(set.amt)) return null; s.amt = set.amt; }
        if (set.by !== undefined) { if (typeof set.by !== 'string') return null; s.by = set.by; }
        if (set.split !== undefined) { s.split = cleanSplit(set.split); if (!s.split) return null; }
        if (set.cat !== undefined) s.cat = text(set.cat, 30);
        return Object.keys(s).length ? { p: b.p, set: s, why: text(b.why, 80) || undefined } : null;
      }
      case 'drop': case 'undo':
        if (isId(b.p)) return { p: b.p };
        if (k === 'drop' && isId(b.s)) return { s: b.s };
        return null;
      case 'settle':
        if (!isId(b.s) || typeof b.from !== 'string' || typeof b.to !== 'string' || b.from === b.to || !isPaise(b.amt) || !isDay(b.d)) return null;
        return { s: b.s, from: b.from, to: b.to, amt: b.amt, d: b.d, how: b.how === 'upi' || b.how === 'cash' || b.how === 'bank' ? b.how : 'other' };
      case 'ok': return isId(b.s) ? { s: b.s } : null;
      case 'leave': return {};
      case 'remove': return typeof b.m === 'string' ? { m: b.m } : null;
    }
    return null;
  }

  // ---- working a chapter out from every op held ----

  /* ops: [{ op, sig }] as received (any order, repeats, strangers' and forgeries among them). The chapter as it stands:
     the same object on every phone that holds the same ops. crypto: { hash, verify } */
  function replay(ch, ops, crypto) {
    var refused = [], forks = [];
    var byId = {};
    (ops || []).forEach(function (r) {
      var op = r && r.op, why = '';
      if (!op || typeof op !== 'object') { refused.push({ id: '', why: 'not an op' }); return; }
      var c = canon(op), id = crypto.hash(c).slice(0, 32);
      if (byId[id]) return;                                   // the same op again: once
      if (op.v !== V) why = 'a newer kosh made it';
      else if (op.ch !== ch) why = 'another chapter';
      else if (!KINDS[op.k]) why = 'unknown kind';
      else if (typeof op.by !== 'string' || !op.by) why = 'no author';
      else if (!(op.n >= 1) || Math.floor(op.n) !== op.n || !(op.lc >= 1) || Math.floor(op.lc) !== op.lc) why = 'no count';
      else if (!crypto.verify(op.by, c, r.sig)) why = 'signature';
      if (why) { refused.push({ id: id, why: why }); return; }
      byId[id] = { id: id, op: op, mid: crypto.hash('kosh-member|' + op.by).slice(0, 16) };
    });
    // a fork: one author, one count, two ops. The smaller id stands, on every phone
    var slot = {};
    Object.keys(byId).sort(cmp).forEach(function (id) {
      var x = byId[id], key = x.op.by + '#' + x.op.n;
      if (slot[key]) { forks.push({ kept: slot[key].id, dropped: id, by: x.mid }); refused.push({ id: id, why: 'fork' }); delete byId[id]; }
      else slot[key] = x;
    });
    var list = Object.keys(byId).map(function (id) { return byId[id]; });
    list.sort(function (a, b) { return a.op.lc - b.op.lc || cmp(a.op.by, b.op.by) || a.op.n - b.op.n || cmp(a.id, b.id); });

    var st = { ch: ch, t: '', kind: 'trip', from: '', to: '', owner: '', open: false };
    var members = {}, order = [], invites = {}, pays = {}, payOrder = [], settles = {}, waiting = 0;
    var known = {};      // everyone who was ever a member (a payer or a seat may have left since)
    function refuse(x, why) { refused.push({ id: x.id, why: why }); }
    function current(mid) { return members[mid] && !members[mid].left; }
    function okPay(p) {
      if (!known[p.by]) return null;
      return parts(p.amt, p.by, p.split, known);
    }
    list.forEach(function (x, at) {
      var op = x.op, k = op.k, mid = x.mid, b = body(k, op.b);
      if (!b) return refuse(x, 'bad body');
      if (k === 'open') {
        if (st.open) return refuse(x, 'opened already');
        if (crypto.hash('kosh-chapter|' + op.by + '|' + b.nonce).slice(0, 32) !== ch) return refuse(x, 'not the chapter\'s own');
        st.open = true; st.t = b.t; st.kind = b.kind; st.from = b.from || ''; st.to = b.to || ''; st.owner = mid; st.made = op.at;
        members[mid] = { id: mid, name: b.name, since: op.at || '', how: 'opened', pub: op.by };
        known[mid] = 1; order.push(mid);
        return;
      }
      if (!st.open) { waiting++; return refuse(x, 'before the chapter opened'); }
      if (k === 'join') {
        if (current(mid)) return refuse(x, 'a member already');
        var iv = invites[b.iv];
        if (!iv || iv.closed) return refuse(x, 'no open invite');
        if (crypto.hash('kosh-invite|' + b.key) !== iv.h) return refuse(x, 'wrong invite secret');
        if (iv.uses && iv.used >= iv.uses) return refuse(x, 'invite used up');
        if (iv.until && !(isDay(op.at) && op.at <= iv.until)) return refuse(x, 'invite ran out');
        if (members[mid] && members[mid].left && !(iv.at > members[mid].leftAt)) return refuse(x, 'left before this invite');
        iv.used++;
        if (members[mid]) { members[mid].left = false; members[mid].name = b.name; members[mid].back = op.at || ''; }
        else { members[mid] = { id: mid, name: b.name, since: op.at || '', how: 'joined', pub: op.by }; order.push(mid); }
        known[mid] = 1;
        return;
      }
      if (!current(mid)) return refuse(x, members[mid] ? 'left the chapter' : 'not a member');
      switch (k) {
        case 'invite':
          if (invites[b.iv]) return refuse(x, 'invite again');
          invites[b.iv] = { iv: b.iv, h: b.h, uses: b.uses, until: b.until || '', used: 0, by: mid, at: at, closed: false };
          return;
        case 'revoke':
          if (!invites[b.iv]) { waiting++; return refuse(x, 'no such invite'); }
          invites[b.iv].closed = true;
          return;
        case 'name': members[mid].name = b.name; return;
        case 'meta':
          if (b.t !== undefined) st.t = b.t;
          if (b.from !== undefined) st.from = b.from;
          if (b.to !== undefined) st.to = b.to;
          return;
        case 'leave':
          if (mid === st.owner) return refuse(x, 'the owner can\'t leave');
          members[mid].left = true; members[mid].leftAt = at; members[mid].leftOn = op.at || '';
          return;
        case 'remove':
          if (mid !== st.owner) return refuse(x, 'only the owner removes');
          if (!current(b.m) || b.m === st.owner) return refuse(x, 'not removable');
          members[b.m].left = true; members[b.m].leftAt = at; members[b.m].leftOn = op.at || ''; members[b.m].removed = true;
          return;
        case 'pay': {
          if (pays[b.p]) return refuse(x, 'payment again');
          var p = { p: b.p, d: b.d, what: b.what, amt: b.amt, by: b.by, split: b.split, cat: b.cat || '', src: b.src, adder: mid, added: op.at || '', dropped: false, edits: 0 };
          var pp = okPay(p);
          if (!pp) return refuse(x, 'split can\'t be made');
          p.parts = pp; pays[b.p] = p; payOrder.push(b.p);
          return;
        }
        case 'edit': {
          var cur = pays[b.p];
          if (!cur) { waiting++; return refuse(x, 'no such payment'); }
          if ((b.set.amt !== undefined || b.set.by !== undefined) && mid !== cur.adder) return refuse(x, 'only its adder changes its figure or payer');
          var next = {};
          Object.keys(cur).forEach(function (f) { next[f] = cur[f]; });
          Object.keys(b.set).forEach(function (f) { next[f] = b.set[f]; });
          var np = okPay(next);
          if (!np) return refuse(x, 'split can\'t be made');
          next.parts = np; next.edits = cur.edits + 1; next.why = b.why || cur.why;
          pays[b.p] = next;
          return;
        }
        case 'drop': case 'undo': {
          if (b.s) {
            var sd = settles[b.s];
            if (!sd) { waiting++; return refuse(x, 'no such settle'); }
            if (mid !== sd.author && mid !== sd.to) return refuse(x, 'not theirs to drop');
            sd.dropped = true;
            return;
          }
          var dp = pays[b.p];
          if (!dp) { waiting++; return refuse(x, 'no such payment'); }
          if (mid !== dp.adder && mid !== st.owner) return refuse(x, 'only its adder or the owner drops it');
          dp.dropped = k === 'drop';
          return;
        }
        case 'settle': {
          if (settles[b.s]) return refuse(x, 'settle again');
          if (!known[b.from] || !known[b.to]) return refuse(x, 'not in the chapter');
          if (mid !== b.from && mid !== b.to) return refuse(x, 'only the two of them');
          settles[b.s] = { s: b.s, from: b.from, to: b.to, amt: b.amt, d: b.d, how: b.how, author: mid, done: mid === b.to, dropped: false };
          return;
        }
        case 'ok': {
          var so = settles[b.s];
          if (!so) { waiting++; return refuse(x, 'no such settle'); }
          if (mid !== so.to) return refuse(x, 'only the one paid confirms');
          so.done = true;
          return;
        }
      }
    });

    // the figures: what each paid and their part, settled money both ways, and where each stands
    var net = {}, row = {};
    order.forEach(function (m) { net[m] = 0; row[m] = { paid: 0, share: 0, sent: 0, got: 0 }; });
    var live = payOrder.map(function (p) { return pays[p]; }).filter(function (p) { return !p.dropped; });
    var total = 0;
    live.forEach(function (p) {
      total += p.amt;
      row[p.by].paid += p.amt;
      Object.keys(p.parts).forEach(function (m) { row[m].share += p.parts[m]; });
    });
    var settleList = Object.keys(settles).map(function (s) { return settles[s]; }).filter(function (s) { return !s.dropped; });
    settleList.forEach(function (s) { if (s.done) { row[s.from].sent += s.amt; row[s.to].got += s.amt; } });
    order.forEach(function (m) { var r = row[m]; net[m] = r.paid - r.share + r.sent - r.got; });

    // maybe the same payment, added by two people (a joint account told in both mailboxes): said, never decided
    var twins = [];
    var byAmt = {};
    live.forEach(function (p) { (byAmt[p.amt] = byAmt[p.amt] || []).push(p); });
    Object.keys(byAmt).forEach(function (a) {
      var g = byAmt[a];
      for (var i = 0; i < g.length; i++) for (var j = i + 1; j < g.length; j++) {
        if (g[i].adder !== g[j].adder && Math.abs(dayNo(g[i].d) - dayNo(g[j].d)) <= 1) twins.push([g[i].p, g[j].p].sort(cmp));
      }
    });
    twins.sort(function (a, b) { return cmp(a[0], b[0]) || cmp(a[1], b[1]); });

    var heads = {};
    list.forEach(function (x) { heads[x.mid] = Math.max(heads[x.mid] || 0, x.op.n); });
    var out = {
      ch: ch, open: st.open, t: st.t, kind: st.kind, from: st.from, to: st.to, owner: st.owner,
      members: order.map(function (m) {
        var x = members[m];
        return { id: m, name: x.name, since: x.since, how: x.how, left: !!x.left, removed: !!x.removed, leftOn: x.left ? x.leftOn : undefined, pub: x.pub };
      }),
      pays: live.slice().sort(function (a, b) { return cmp(a.d, b.d) || cmp(a.p, b.p); }).map(function (p) {
        return { p: p.p, d: p.d, what: p.what, amt: p.amt, by: p.by, split: p.split, parts: p.parts, cat: p.cat, src: p.src, adder: p.adder, added: p.added, edits: p.edits, why: p.why };
      }),
      dropped: payOrder.filter(function (p) { return pays[p].dropped; }).sort(cmp),
      settles: settleList.sort(function (a, b) { return cmp(a.d, b.d) || cmp(a.s, b.s); }).map(function (s) { return { s: s.s, from: s.from, to: s.to, amt: s.amt, d: s.d, how: s.how, by: s.author, state: s.done ? 'done' : 'said' }; }),
      invites: Object.keys(invites).sort(cmp).map(function (i) { var v = invites[i]; return { iv: v.iv, by: v.by, uses: v.uses, used: v.used, until: v.until, closed: v.closed }; }),
      total: total,
      people: order.map(function (m) { var r = row[m]; return { id: m, paid: r.paid, share: r.share, sent: r.sent, got: r.got, net: net[m] }; }),
      squares: squares(net),
      twins: twins,
      heads: heads, held: list.length, waiting: waiting,
      refused: refused.sort(function (a, b) { return cmp(a.id, b.id) || cmp(a.why, b.why); }),
      forks: forks.sort(function (a, b) { return cmp(a.dropped, b.dropped); }),
    };
    return out;
  }

  // ---- one phone's copy of a chapter ----

  function route(ch, key, crypto) { return crypto.hash('kosh-chapter-route|' + ch + '|' + key).slice(0, 32); }

  /* a phone's (or a browser's) copy: the ops it holds, the ones it made and hasn't handed over yet, and the chapter
     worked out from them. { ch, key, me: { pub, sign }, crypto, today } */
  function replica(o) {
    var crypto = o.crypto, me = o.me, ops = {}, sealed = {}, outbox = [], memo = null;
    var meId = crypto.hash('kosh-member|' + me.pub).slice(0, 16);
    function idOf(op) { return crypto.hash(canon(op)).slice(0, 32); }
    var r = {
      ch: o.ch, key: o.key, me: meId, route: route(o.ch, o.key, crypto), unopened: 0,
      held: function () { return Object.keys(ops).length; },
      /* the next op of ours, unsigned: its text is what gets signed (a browser signs with WebCrypto, which waits) */
      prepare: function (k, b, at) {
        var lc = 0, n = 0;
        Object.keys(ops).forEach(function (id) { var x = ops[id].op; lc = Math.max(lc, x.lc); if (x.by === me.pub) n = Math.max(n, x.n); });
        var op = { v: V, ch: r.ch, by: me.pub, n: n + 1, lc: lc + 1, at: at || o.today || '', k: k, b: b || {} };
        return { op: op, text: canon(op) };
      },
      /* one of ours, signed: held and queued to send if it counts. Its record, or null (and it is let go) */
      hold: function (rec) {
        var id = idOf(rec.op);
        ops[id] = { op: rec.op, sig: rec.sig }; memo = null;
        if (r.state().refused.some(function (x) { return x.id === id; })) { delete ops[id]; memo = null; return null; }
        outbox.push(id);
        return ops[id];
      },
      /* make, sign and hold an op of ours in one go (the phone's crypto doesn't wait). Its envelope, or null */
      make: function (k, b, at) {
        var pr = r.prepare(k, b, at);
        var rec = r.hold({ op: pr.op, sig: me.sign(pr.text) });
        return rec ? r.seal(rec) : null;
      },
      /* an op sealed for the transport: the same envelope every time it's asked for */
      seal: function (rec) {
        var id = idOf(rec.op);
        if (!sealed[id]) { var x = crypto.seal(r.key, canon(rec)); sealed[id] = { r: r.route, e: crypto.hash(x).slice(0, 32), x: x }; }
        return sealed[id];
      },
      /* records already opened (a browser opens them with WebCrypto first): held once each. How many were new */
      takeRecs: function (recs) {
        var added = 0;
        (recs || []).forEach(function (rec) {
          if (!rec || !rec.op || typeof rec.op !== 'object') { r.unopened++; return; }
          var id = idOf(rec.op);
          if (ops[id]) return;
          ops[id] = { op: rec.op, sig: rec.sig }; added++;
        });
        if (added) memo = null;
        return added;
      },
      /* envelopes from the transport, opened with the chapter's key; what doesn't open (a stranger's, damaged) is
         counted and left. How many new ops it held */
      take: function (envs) {
        var recs = [];
        (envs || []).forEach(function (e) {
          if (!e || e.r !== r.route || typeof e.x !== 'string') return;
          var t = crypto.open(r.key, e.x), rec = null;
          try { rec = t ? JSON.parse(t) : null; } catch (err) { rec = null; }
          if (!rec || !rec.op) { r.unopened++; return; }
          // (kept as it came, so handing it on later sends the same blob, not a new one the relay would keep twice)
          var id = idOf(rec.op);
          if (!sealed[id]) sealed[id] = { r: r.route, e: crypto.hash(e.x).slice(0, 32), x: e.x };
          recs.push(rec);
        });
        return r.takeRecs(recs);
      },
      /* what we made since last asked, sealed, for the transport; or as records (a browser seals them itself) */
      outbox: function () { var ids = outbox; outbox = []; return ids.map(function (id) { return r.seal(ops[id]); }); },
      outRecs: function () { var ids = outbox; outbox = []; return ids.map(function (id) { return ops[id]; }); },
      /* every op held, as envelopes: what a phone hands a member who joins late, or a relay that lost its copy */
      all: function () { return Object.keys(ops).sort(cmp).map(function (id) { return r.seal(ops[id]); }); },
      records: function () { return Object.keys(ops).sort(cmp).map(function (id) { return ops[id]; }); },
      state: function () { if (!memo) memo = replay(r.ch, Object.keys(ops).map(function (id) { return ops[id]; }), crypto); return memo; },
    };
    return r;
  }

  /* open a new chapter: its id is the hash of the opener's key and a nonce, so nobody else can open it */
  function create(o) {
    var nonce = o.nonce;
    var ch = o.crypto.hash('kosh-chapter|' + o.me.pub + '|' + nonce).slice(0, 32);
    var r = replica({ ch: ch, key: o.key, me: o.me, crypto: o.crypto, today: o.today });
    r.make('open', { t: o.title, kind: o.kind, from: o.from, to: o.to, name: o.name, nonce: nonce });
    return r;
  }

  /* an invite: its op (made by a member) and the link's secret part. The link is <page>#<key>.<chapter>.<invite>.<secret>:
     everything after # stays in the browser or the phone; a server never sees it */
  function invite(r, o) {
    var env = r.make('invite', { iv: o.iv, h: o.crypto.hash('kosh-invite|' + o.secret), uses: o.uses || 0, until: o.until });
    if (!env) return null;
    return { env: env, link: o.page + '#' + [r.key, r.ch, o.iv, o.secret].join('.') };
  }
  function parseLink(link) {
    var m = /#([A-Za-z0-9_\-+/=]{16,}?)\.([0-9a-f]{32})\.([a-z0-9]{8,40})\.([A-Za-z0-9_\-]{16,64})$/.exec(String(link || ''));
    return m ? { key: m[1], ch: m[2], iv: m[3], secret: m[4] } : null;
  }

  // ---- your ledger and the chapter ----

  /* the one door out of your ledger: a payment row as the chapter may see it. Its day, a name with no digits, account
     or UPI ID in it, the figure it cost after any money back (in paise), its kind, who paid and how it's split */
  function cleanName(s) {
    var t = String(s || '')
      .replace(/\S+@\S+/g, ' ')                       // a UPI ID or an address
      .replace(/\b(?:upi|imps|neft|rtgs|pos|ach|nach|ecom|vps|ref|txn|utr)\b[\/:\-]*/gi, ' ')
      .replace(/\d*[x*•]{2,}\d*/gi, ' ')               // a masked number, with the digits either side
      .replace(/\d[\d\s\-\/]{2,}\d/g, ' ')              // any run of four digits or more
      .replace(/[\/|#*_]+/g, ' ');
    return text(t, 60) || 'Payment';
  }
  function offer(row, o) {
    o = o || {};
    var cost = Math.round(((+row.a || 0) + (+row.shared || 0)) * 100);
    var b = { p: o.p, d: row.od || row.d, what: cleanName(row.m), amt: cost, by: o.by, split: o.split, cat: row.c || undefined, src: o.src || 'mail' };
    return body('pay', b);
  }

  /* what a chapter means for your ledger, worked out in one place:
       mine   for each payment you paid and offered from your mail: what stays yours, as the build's "mine" reads it
              (your part, plus any money back the build takes off after: SplitWays.mine), keyed by your row's id
       drift  a payment you offered whose row has since changed: money came back or a statement's figure (amt, the
              chapter is offered the new figure: kosh can send it, it's your mail's), or the row is gone or kept out
              (gone: asked, never sent by itself)
       owe    the moves that square the chapter and involve you
       shares your part of what others paid, for the day it was paid (a figure rule waiting on him: CHAPTERS.md §4)
     state: replay()'s; me: your member id; links: { p: your row id } (never sent); rows: your ledger's payments */
  function ledger(state, me, links, rows) {
    var byRow = {};
    (rows || []).forEach(function (t) { byRow[t.id] = t; });
    var out = { mine: {}, drift: [], owe: [], shares: [] };
    var dropped = {};
    (state.dropped || []).forEach(function (p) { dropped[p] = 1; });
    (state.pays || []).forEach(function (p) {
      var rid = links && links[p.p];
      if (rid && p.adder === me) {
        var t = byRow[rid];
        if (!t || t.ex) { out.drift.push({ p: p.p, row: rid, why: t ? 'kept out' : 'gone', ask: true }); return; }
        var now = Math.round(((+t.a || 0) + (+t.shared || 0)) * 100);
        if (now !== p.amt) out.drift.push({ p: p.p, row: rid, why: (+t.refunded || 0) > 0 ? 'money back' : 'figure', from: p.amt, to: now, ask: false });
        if (p.by === me) {
          var part = p.parts[me] || 0;
          out.mine[rid] = Math.round((rupees(part) + (+t.refunded || 0)) * 100) / 100;
        }
      } else if (p.by !== me && (p.parts[me] || 0) > 0) {
        out.shares.push({ p: p.p, d: p.d, what: p.what, a: rupees(p.parts[me]), cat: p.cat, by: p.by });
      }
    });
    (state.squares || []).forEach(function (m) { if (m.from === me || m.to === me) out.owe.push({ from: m.from, to: m.to, a: rupees(m.amt) }); });
    return out;
  }

  /* payments in your ledger the chapter may want, for one tap each: never added by themselves. In the chapter's days (or
     put in the local chapter it's tied to), spending, not offered yet; one that looks like a payment already in it (the
     same figure within a day) says so */
  function candidates(state, me, links, rows, o) {
    o = o || {};
    var offered = {};
    Object.keys(links || {}).forEach(function (p) { offered[links[p]] = 1; });
    var from = o.from || state.from, to = o.to || state.to || o.today || '9999-12-31';
    return (rows || []).filter(function (t) {
      if (offered[t.id] || t.ex || t.partOf || !(t.a > 0) || (t.dr && t.dr !== 'out')) return false;
      if (!(t.sp || t.nc === 'chapter' || (t.shared || 0) > 0)) return false;
      if (o.trip) return t.tr === o.trip;
      var d = t.od || t.d;
      return !!from && d >= from && d <= to;
    }).map(function (t) {
      var cost = Math.round(((+t.a || 0) + (+t.shared || 0)) * 100), d = t.od || t.d;
      var same = (state.pays || []).filter(function (p) { return p.amt === cost && Math.abs(dayNo(p.d) - dayNo(d)) <= 1; })[0];
      return { row: t.id, d: d, what: cleanName(t.m), amt: cost, maybe: same ? same.p : undefined };
    }).sort(function (a, b) { return cmp(b.d, a.d) || cmp(a.row, b.row); });
  }

  var api = {
    V: V, canon: canon, parts: parts, squares: squares, body: body, replay: replay, replica: replica, create: create,
    invite: invite, parseLink: parseLink, route: route, offer: offer, cleanName: cleanName, ledger: ledger, candidates: candidates,
  };
  if (E) E.chapterSync = api;
  return api;
})(typeof KoshEngine !== 'undefined' ? KoshEngine : null);
if (typeof module !== 'undefined' && module.exports) module.exports = KoshChapterSync;
