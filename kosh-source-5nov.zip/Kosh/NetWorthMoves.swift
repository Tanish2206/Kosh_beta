import SwiftUI

// MARK: - What moved net worth
//
// The line under the net worth figure says what moved it over the range its chart shows (3M, 6M, 1Y or All): the two
// or three kinds of holding that changed most, "Deposits +₹2L, Stocks −₹43k since 1 Jul", then the whole change. The
// engine keeps what each person held at each month's end, kind by kind (Snapshot.worth); today's is what the headline
// counts. Cash, the land and the loans are taken at today's figure for every month on the line (kosh has no past
// figure for them), so they move nothing there and are left out here; the kinds' changes add up to the line's. Worked
// out once a build for each person and range (Store.worthMoves), never in a view's body.

/// what moved net worth over a range, biggest change first
struct WorthMoves: Hashable {
    struct Move: Hashable, Identifiable {
        let key: String
        let title: String
        let d: Double
        var id: String { key }
    }
    /// the kinds that moved, biggest change first (a change of under ₹1,000, or tiny beside the biggest, is left out)
    let moves: [Move]
    /// the whole change over the range: what every kind's change adds up to
    let total: Double
    /// net worth on the day the range opens, as the line has it (for the change as a share)
    let opening: Double
    /// the day the range opens on, as the chart says it: "1 Jul", or "1 Jul 2025" in another year
    let since: String

    /// the kinds' names, short, as the breakdown's key says them
    static let titles: [String: String] = ["bank": "Bank", "dep": "Deposits", "stk": "Stocks", "mf": "Funds", "ret": "Retirement",
                                           "gold": "Gold", "ins": "Insurance savings"]

    /// "+₹2L", "−₹43k"
    static func signed(_ d: Double) -> String { (d >= 0 ? "+" : "−") + Fmt.short(d) }

    /// the biggest few, in words: "Deposits +₹2L, Stocks −₹43k"
    func line(_ n: Int = 3) -> String {
        moves.prefix(n).map { (m: Move) -> String in m.title + " " + Self.signed(m.d) }.joined(separator: ", ")
    }

    /// "Deposits +₹2L, Stocks −₹43k since 1 Jul": each kind in plain ink, its change green when up and orange when down
    func text(_ n: Int = 3) -> Text {
        var t: Text = Text(verbatim: "")
        for (i, m) in moves.prefix(n).enumerated() {
            let name: Text = Text(verbatim: (i > 0 ? ", " : "") + m.title + " ")
            let fig: Text = Text(verbatim: Self.signed(m.d)).foregroundStyle(m.d >= 0 ? Color.green : Color.orange)
            t = Text("\(t)\(name)\(fig)")
        }
        let tail: Text = Text(verbatim: " since " + since)
        return Text("\(t)\(tail)")
    }

    /// "▲ ₹5,561 (0.1%) in all": the whole change, as a share of what the range opened on
    var all: String {
        let pct: String = opening > 0 ? " (" + Fmt.trim(abs(total) / opening * 100, 1) + "%)" : ""
        return (total >= 0 ? "▲ " : "▼ ") + Fmt.words(abs(total)) + pct + " in all"
    }

    /// from the month's end the range opens on to today, kind by kind, for whoever's money is showing
    static func make(_ store: Store, _ p: Person, range: Int) -> WorthMoves? {
        let pts: [NWPoint] = NetWorthTrend.window(store.worthSeries(p), range: range)
        guard pts.count > 1, let first = pts.first, first.day == nil else { return nil }
        // then: each kind at the opening month's end (the engine's loan figure is left out, as the line leaves it out)
        var then: [String: Double] = [:]
        for w in store.snap.worth ?? [] where w.m == first.m && p.owns(w.o) {
            for (k, v) in w.v where k != "loan" { then[k, default: 0] += v }
        }
        // now: the same kinds, as the headline counts them today
        var now: [String: Double] = [:]
        let bank: Double = store.bankBalance(p)
        if bank != 0 { now["bank"] = bank }
        for h in store.holdings(p) { now[h.cls, default: 0] += h.amt }
        let keys: [String] = Array(Set(then.keys).union(now.keys))
        let all: [Move] = keys.map { (k: String) -> Move in
            Move(key: k, title: Self.titles[k] ?? "Other", d: (now[k] ?? 0) - (then[k] ?? 0))
        }
        let total: Double = all.reduce(0) { $0 + $1.d }
        let sorted: [Move] = all.sorted { abs($0.d) > abs($1.d) }
        let top: Double = abs(sorted.first?.d ?? 0)
        let floor: Double = max(1000, top * 0.05)
        let moves: [Move] = sorted.filter { abs($0.d) >= floor }
        let today: String = pts.last?.day ?? store.snap.today
        // (the share is of the line's own opening figure, as the chart reads it)
        return WorthMoves(moves: moves, total: total, opening: first.v, since: NetWorthTrend.since(first, today: today))
    }
}

extension Store {
    /// what moved net worth over a range (WorthMoves): worked out again only when a build or a change to the payments
    /// lands, or for another person, range or day
    func worthMoves(_ p: Person, range: Int) -> WorthMoves? {
        let key: String = p.id + "|" + String(range) + "|" + snap.today
        if worthMovesMemo.gen == txGen && worthMovesMemo.key == key { return worthMovesMemo.out }
        let out: WorthMoves? = WorthMoves.make(self, p, range: range)
        worthMovesMemo = (txGen, key, out)
        return out
    }
}
