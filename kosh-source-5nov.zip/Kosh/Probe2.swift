import Foundation

extension LiveSession {
    /// one-off look at a few mails' readings and their sealed text (diag only)
    func probe2() -> [[String: Any]] {
        var out: [[String: Any]] = []
        for r in records {
            let d: String = r.date ?? ""
            if d < "2026-11-01" || d > "2026-11-02" { continue }
            let f: String = (r.from ?? "").lowercased()
            let sj: String = (r.subject ?? "").lowercased()
            let hit: Bool = f.contains("amazon") || sj.contains("amazon") || (r.amt ?? 0) > 2600 && (r.amt ?? 0) < 2640
            if !hit { continue }
            let m = MailVault.get(r.id)
            let t: String = m?.text ?? ""
            var snip: String = ""
            for w in ["Credit", "balance", "Paid via", "Item"] {
                if let rg = t.range(of: w, options: .caseInsensitive) {
                    let a = t.index(rg.lowerBound, offsetBy: -80, limitedBy: t.startIndex) ?? t.startIndex
                    let b = t.index(rg.upperBound, offsetBy: 80, limitedBy: t.endIndex) ?? t.endIndex
                    snip += w + ": " + String(t[a..<b]) + " || "
                }
            }
            var o: [String: Any] = [:]
            o["id"] = r.id; o["kind"] = r.kind; o["rule"] = r.rule ?? ""; o["amt"] = r.amt ?? 0; o["date"] = d
            o["subj"] = String((r.subject ?? "").prefix(60)); o["evs"] = String((r.evs ?? "").prefix(900))
            o["tl"] = t.count; o["hl"] = m?.html.count ?? -1; o["snip"] = snip; o["head"] = String(t.prefix(300))
            out.append(o)
            if out.count >= 14 { break }
        }
        return out
    }
}
