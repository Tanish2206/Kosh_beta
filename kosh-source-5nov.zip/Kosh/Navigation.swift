import SwiftUI
import UIKit

// MARK: - Tabs, sub-tabs, navigation and sheets

enum AppTab: String, CaseIterable, Identifiable, Hashable {
    case home, transactions, portfolio, property, committees, people, insurance, loans, chapters
    var id: String { rawValue }
    var title: String {
        switch self {
        case .home: return "Home"
        case .transactions: return "Transactions"
        case .portfolio: return "Wealth"
        case .property: return "Property"
        case .committees: return "Committees"
        case .people: return "People"
        case .insurance: return "Insurance"
        case .loans: return "Loans"
        case .chapters: return "Chapters"
        }
    }
    var symbol: String {
        switch self {
        case .home: return "house.fill"
        case .transactions: return "list.bullet.rectangle.portrait.fill"
        case .portfolio: return "chart.pie.fill"
        case .property: return "building.2.fill"
        case .committees: return "circle.dotted.circle"
        case .people: return "person.2.fill"
        case .insurance: return "shield.lefthalf.filled"
        case .loans: return "building.columns.fill"
        case .chapters: return "book.pages.fill"
        }
    }
    /// the outline drawing the icon-only bar uses; it fills in when chosen
    var glyph: String {
        switch self {
        case .home: return "house"
        case .transactions: return "list.bullet.rectangle.portrait"
        case .portfolio: return "chart.pie"
        case .property: return "building.2"
        case .committees: return "circle.dotted.circle"
        case .people: return "person.2"
        case .insurance: return "shield"
        case .loans: return "building.columns"
        case .chapters: return "book.pages"
        }
    }
    /// what it's for, in a line, for the tab bar editor
    var blurb: String {
        switch self {
        case .home: return "The month, what's due, what kosh noticed"
        case .transactions: return "Every payment, accounts and cards"
        case .portfolio: return "Net worth, what it's in, what comes back"
        case .property: return "Rent, tenants and property tax"
        case .committees: return "Committees and kitty funds"
        case .people: return "Splits, lent and borrowed"
        case .insurance: return "Policies, premiums and renewals"
        case .loans: return "EMIs and what's left to pay"
        case .chapters: return "Trips and life events, each with its story"
        }
    }
    /// everything that can be a tab, in the order the editor offers them
    static let pinnable: [AppTab] = [.home, .transactions, .portfolio, .chapters, .insurance, .property, .committees, .people, .loans]
    /// the modules that aren't always a tab
    static let optional: [AppTab] = [.chapters, .insurance, .property, .committees, .people, .loans]
    /// the fewest and the most a tab bar holds
    static let fewest: Int = 4
    static let most: Int = 6
}

protocol SubTab: Hashable, CaseIterable, Identifiable where AllCases == [Self] {
    var title: String { get }
}

/// Home's sub-tabs: Overview (the calm cards) and Genie, where kosh's errands live (what needs you, what it's
/// chasing). The Calendar page opens from This week, a reminder or the widget.
enum HomeSub: String, SubTab {
    case overview, genie
    var id: String { rawValue }
    var title: String { self == .overview ? "Overview" : "Ask kosh" }
}

enum TxSub: String, SubTab {
    case all, insights, lab, accounts
    var id: String { rawValue }
    var title: String {
        switch self {
        case .all: return "All"
        case .accounts: return "Accounts & cards"
        case .insights: return "Insights"
        case .lab: return "Analytics testing"
        }
    }
}

enum PortSub: String, SubTab {
    case overview, investments, loans
    var id: String { rawValue }
    var title: String {
        switch self {
        case .overview: return "Overview"
        case .investments: return "Holdings"
        case .loans: return "Debts"
        }
    }
}

enum PropSub: String, SubTab {
    case overview, tenants, tax
    var id: String { rawValue }
    var title: String {
        switch self {
        case .overview: return "Overview"
        case .tenants: return "Tenants"
        case .tax: return "Property tax"
        }
    }
}

enum CommSub: String, SubTab {
    case active, schedule, completed
    var id: String { rawValue }
    var title: String {
        switch self {
        case .active: return "Active"
        case .schedule: return "Schedule"
        case .completed: return "Completed"
        }
    }
}

enum Route: Hashable {
    case month(String)
    case holdings(String)
    case category(String, String)
    case committee(String)
    case policy(String)
    /// a whole module, pushed when it isn't one of the tabs
    case module(AppTab)
    /// one bank account, opened out of Accounts
    case account(String)
    /// refunds you're waiting for
    case refunds
    /// every repeat, opened from Insights' Repeats section (it was a sub-tab of Transactions until 31 Oct)
    case repeats
    /// trips and events, and one of them
    case trips
    case trip(String)
    /// a chapter's page, every payment in it, and its group pass
    case chapter(String)
    case chapterPayments(String)
    case chapterGroup(String)
    /// an app or shop's orders (Blinkit, Amazon…), opened from Wallets
    case shop(String)
    /// search every payment, and filter by anything kosh files it under
    case find
    /// one app or store's payments, from Where you shop: its name, a category ("" for all) and how many months
    case platform(String, String, Int)
    /// what leaves and what lands: six weeks close up and a year out
    case calendar
    /// one deposit's journey (Deposits.swift)
    case deposit(String)
    /// one PPF account, by its key (inst|last4) (WealthPPF.swift)
    case ppf(String)
    /// a part of Insurance: "Health", "Life", "Motor", "Other", "Look", "Calendar" or "Payments" (InsurancePages.swift)
    case cover(String)
    /// Your details: a person's IDs and numbers ("" starts on yours) (Details.swift)
    case details(String)
    /// dividends by financial year and company; deposits maturing and closed (PortfolioViews.swift)
    case dividends
    case maturities
    /// what each month went on: events, gifts, fees and taxes on orders, new buys (OrderViews.swift)
    case review
    /// Wealth's mutual funds and its deposits, each a page of its own (WealthFunds.swift, WealthDeposits.swift)
    case wealthFunds
    case wealthDeposits
    /// what kosh understands of your life from the mail: events, trips, whom you spend on, habits (PersonaViews.swift)
    case persona
    /// the pages behind it, in its look (DeepPages.swift): a life event, a trip, a person, a habit (by their ids)
    case lifeEvent(String)
    case personaTrip(String)
    case personaPerson(String)
    case personaHabit(String)
    /// the payments behind a figure (a Month in review card, a line of evidence): a title, what it covers, the ids
    case payments(String, String, [String])
    /// each home's bills across the year, and one home's (HomeBillsViews.swift)
    case homes
    case home(String)
    /// one kind of bill across every home (BillsMap.swift)
    case billKind(String)
}

enum SheetKind: Identifiable {
    case tx(String), add(String?), tag, dups, split(String?), lend, settings, capture(String), parser, ask, tabs
    /// "Arrange this tab": its pages' sections, to show, hide and reorder
    case arrange(AppTab)
    /// "Sort these": the payments still in Miscellaneous, a payee at a time (SortThese.swift)
    case sort
    var id: String {
        switch self {
        case .tabs: return "tabs"
        case .arrange(let t): return "arrange" + t.rawValue
        case .tx(let id): return "tx" + id
        case .add(let p): return "add" + (p ?? "")
        case .tag: return "tag"
        case .sort: return "sort"
        case .dups: return "dups"
        case .split(let id): return "split" + (id ?? "")
        case .lend: return "lend"
        case .settings: return "settings"
        case .capture(let k): return "capture" + k
        case .parser: return "parser"
        case .ask: return "ask"
        }
    }
}

struct DayV: Identifiable { let day: Int; let v: Double; var id: Int { day } }
struct DayBand: Identifiable { let day: Int; let lo: Double; let hi: Double; var id: Int { day } }
struct DayGroup: Identifiable { let day: String; let items: [Txn]; let total: Double; var id: String { day } }
struct Suggestion: Identifiable, Hashable {
    let label: String; let c: String; let s: String; let card: String; let merchant: String; let sym: String
    var id: String { label + c + s }
}
/// one person's holdings at a month's end, by class (bank, dep, mf, stk, ret, gold…)
struct WorthRow: Decodable, Hashable { let m: String; let o: String; let v: [String: Double] }
/// net worth at a month's end (or, for the running month, today)
struct NWPoint: Identifiable, Hashable {
    let m: String; let v: Double
    /// the day the figure is for, when it isn't the month's last: today, for the running month
    var day: String? = nil
    var id: String { m }
    /// where it sits on a time line: the month's last day, or today
    var date: Date { Day.date(day ?? Day.monthEnd(m)) }
}
struct ClassSum: Identifiable { let key: String; let title: String; let color: Color; let sym: String; let v: Double; let n: Int; var id: String { key } }

/// Whose money a screen shows: everyone, or one person in the household. Every tab filters by it.
struct Person: Hashable, Identifiable {
    let id: String
    let title: String
    static let family = Person(id: "family", title: "Family")
    static let me = Person(id: "me", title: "You")
    var rawValue: String { id }
    func owns(_ owner: String) -> Bool { self == .family || owner == id }
    static func == (a: Person, b: Person) -> Bool { a.id == b.id }
    func hash(into h: inout Hasher) { h.combine(id) }
    /// "Your net worth", "Mom’s net worth"
    func possessive(_ thing: String, family: String) -> String {
        self == .family ? family : self == .me ? "Your " + thing : title + "’s " + thing
    }
}

enum LedgerFilter: String, CaseIterable, Identifiable {
    case all, me, mom, home, work, moneyIn, moves, chapters
    var id: String { rawValue }
    var title: String {
        switch self {
        case .chapters: return "In a chapter"
        case .all: return "Everything"
        case .me: return "For me"
        case .mom: return "For Mom"
        case .home: return "For home"
        case .work: return "For work"
        case .moneyIn: return "Money in"
        case .moves: return "Moves between accounts"
        }
    }
    var symbol: String {
        switch self {
        case .all: return "tray.full"
        case .me: return "person"
        case .mom: return "heart"
        case .home: return "house"
        case .work: return "briefcase"
        case .moneyIn: return "arrow.down.left"
        case .moves: return "arrow.left.arrow.right"
        case .chapters: return "book.pages"
        }
    }
}

/// How a payment was paid, as the Transactions filter groups it: "" (any way), "wallets" (any wallet),
/// "w:<name>" (one wallet), "card", "upi", "bank" (a transfer, auto-debit, ATM or the account itself), "cash".
enum PaidWith {
    static func key(_ t: Txn) -> String {
        switch t.md ?? "" {
        case "wallet": return "wallet"
        case "card": return "card"
        case "upi": return "upi"
        case "cash": return "cash"
        case "transfer", "auto", "atm", "bank": return "bank"
        default: return ""
        }
    }
    static func walletName(_ t: Txn) -> String {
        let b = (t.bk ?? "").trimmingCharacters(in: .whitespaces)
        return b.isEmpty ? t.card : b
    }
    /// "Amazon Pay", "Amazon Pay Balance" and "Amazon Pay wallet" are one wallet
    static func walletKey(_ name: String) -> String {
        name.lowercased().replacingOccurrences(of: #"\s+(wallet|balance)$"#, with: "", options: .regularExpression)
            .trimmingCharacters(in: .whitespaces)
    }
    static func matches(_ t: Txn, _ sel: String) -> Bool {
        if sel.isEmpty { return true }
        if sel.hasPrefix("w:") { return key(t) == "wallet" && walletKey(walletName(t)) == walletKey(String(sel.dropFirst(2))) }
        if sel == "wallets" { return key(t) == "wallet" }
        return key(t) == sel
    }
    static let ways: [(String, String, String)] = [
        ("card", "Card", "creditcard"), ("upi", "UPI", "qrcode"), ("bank", "Bank", "building.columns"), ("cash", "Cash", "banknote"),
    ]
    static func title(_ sel: String) -> String {
        if sel.hasPrefix("w:") { return String(sel.dropFirst(2)) }
        if sel == "wallets" { return "Wallets" }
        return ways.first { $0.0 == sel }?.1 ?? "Any way"
    }
    static func symbol(_ sel: String) -> String {
        if sel.hasPrefix("w:") || sel == "wallets" { return "wallet.bifold" }
        return ways.first { $0.0 == sel }?.2 ?? "tray.full"
    }
}

/// Something added by hand or read off a photo: cash in hand, a loan's balance, a policy's details, gold.
struct Capture: Codable, Identifiable, Hashable {
    var id: String; var kind: String; var title: String; var amount: Double?; var text: String; var date: String
}

/// One thing that is due, from any section: the calendar and Home read these.
struct DueItem: Identifiable, Hashable {
    let id: String; let date: String; let title: String; let sub: String; let amount: Double; let incoming: Bool; let sym: String; let color: Color
}

// MARK: - Saved on this phone

enum Saved {
    static let ud = UserDefaults.standard
    static func load<T: Decodable>(_ key: String, _ fallback: T) -> T {
        guard let d = ud.data(forKey: key), let v = try? JSONDecoder().decode(T.self, from: d) else { return fallback }
        return v
    }
    static func save<T: Encodable>(_ key: String, _ v: T) {
        if let d = try? JSONEncoder().encode(v) { ud.set(d, forKey: key) }
    }
}
