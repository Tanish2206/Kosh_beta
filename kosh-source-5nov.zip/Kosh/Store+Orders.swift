import Foundation

// MARK: - The store: what each order was (Orders.swift; engine/21r-build-orders.js)
// Read-only lookups into the snapshot, and your word on a payment's tags (an override, learnt by the engine for the
// payee's other payments where it is a kind). Nothing here is worked out again.

extension Store {
    /// a payment's order; a part split out of a charge reads its charge's
    func order(_ t: Txn) -> OrdersBook.Order? {
        guard let b = snap.orders else { return nil }
        return b.pay[t.id] ?? t.partOf.flatMap { b.pay[$0] }
    }
    /// every mail kosh read of a payment's order, oldest first; its own mail alone when it has no order
    func orderMailIDs(_ t: Txn) -> [String] {
        let own: String = String(t.id.split(separator: "#").first ?? Substring(t.id))
        let ids: [String] = (order(t)?.mails ?? []).map(\.id)
        // (story-5nov-swift) and every source that told it, the receipt and the statement, each once, the payment's own first
        var all: [String] = ids.isEmpty ? [own] : ids
        for x in (t.told ?? []) + [t.rc ?? ""] + (t.sm ?? []) where !x.isEmpty && !all.contains(x) { all.append(x) }
        return all
    }
    /// the month in review, newest first
    var monthReviews: [OrdersBook.Month] { snap.orders?.months ?? [] }

    /// a tag put on a payment by you (on), or taken off it (off): kosh's own tag taken off stays off; yours goes
    func setTag(_ id: String, _ tag: String, on: Bool) {
        guard let live else { return }
        let word: String = String(tag.trimmingCharacters(in: .whitespacesAndNewlines).prefix(30))
        guard !word.isEmpty else { return }
        live.override(id) { o in
            var add: [String] = o.tags ?? []
            var off: [String] = o.tagsOff ?? []
            if on {
                if !add.contains(word) { add.append(word) }
                off.removeAll { $0 == word }
            } else {
                add.removeAll { $0 == word }
                if !off.contains(word) { off.append(word) }
            }
            o.tags = add.isEmpty ? nil : add
            o.tagsOff = off.isEmpty ? nil : off
        }
        live.rebuildSoon()
    }
}
