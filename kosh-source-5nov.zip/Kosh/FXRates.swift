import Foundation

// MARK: - The day's rupee rates, for what's held in another currency
//
// An FCNR deposit is in dollars; net worth is in rupees. kosh counts it at the day's reference rate: the European
// Central Bank's, published each working day and served by Frankfurter (a public, keyless service). Once a day kosh
// asks for each FCNR currency against the rupee; the requests carry no amounts and nothing about what's held. When
// one can't be had, the last rate stays, said with its own day; with none at all the engine counts at kosh's own
// fixed rate and says so (engine.js fxToday, fxSaid).

final class FXRates: @unchecked Sendable {
    static let shared = FXRates()

    /// rupees for one unit of the currency, the day the rate is for (yyyy-MM-dd), and whose rate it is
    struct Rate: Codable, Hashable { var p: Double; var d: String; var src: String }
    struct Saved: Codable { var at: String = ""; var tried: Date = .distantPast; var rates: [String: Rate] = [:] }

    /// the currencies an FCNR deposit can be in, each asked for against the rupee
    static let currencies = ["USD", "GBP", "EUR", "CAD", "AUD", "SGD", "JPY", "CHF", "HKD"]
    static func url(_ cur: String) -> String { "https://api.frankfurter.dev/v1/latest?base=" + cur + "&symbols=INR" }

    private let lock = NSLock()
    private var saved = Saved()
    private var running = false
    private var gen = 0
    private var file: URL { LiveSession.folder.appendingPathComponent("fx.json") }

    init() {
        if let d = try? Data(contentsOf: file), let s = try? JSONDecoder().decode(Saved.self, from: d) { saved = s }
    }

    /// what the engine takes as prof.fx: currency → { p, d, src }
    var forEngine: [String: [String: Any]] {
        lock.lock(); defer { lock.unlock() }
        return saved.rates.filter { $0.value.p.isFinite && $0.value.p > 0 }.mapValues { ["p": $0.p, "d": $0.d, "src": $0.src] as [String: Any] }
    }
    var isEmpty: Bool { lock.lock(); defer { lock.unlock() }; return saved.rates.isEmpty }

    func clear() {
        lock.lock(); saved = Saved(); gen += 1; lock.unlock()
        try? FileManager.default.removeItem(at: file)
    }

    struct Answer: Decodable { let amount: Double; let base: String; let date: String; let rates: [String: Double] }

    /// Once a day (a failed try waits an hour; a pull, a quarter of an hour). True when a rate changed.
    func refresh(pulled: Bool = false) async -> Bool {
        let today: String = LiveSession.today
        lock.lock()
        if saved.tried == .distantPast, let d = try? Data(contentsOf: file), let x = try? JSONDecoder().decode(Saved.self, from: d) { saved = x }
        let since: TimeInterval = Date().timeIntervalSince(saved.tried)
        let due: Bool = pulled ? since > 15 * 60 : (saved.at != today && since > 3600)
        guard due, !running else { lock.unlock(); return false }
        running = true
        saved.tried = Date()
        let before: Saved = saved, era: Int = gen
        lock.unlock()

        var next: Saved = before
        // each currency on its own; an answer for another base than the one asked (or without the rupee) is no answer
        let got: [String: Rate] = await withTaskGroup(of: (String, Rate?).self) { group -> [String: Rate] in
            for cur in Self.currencies {
                group.addTask {
                    guard let a = await Self.fetch(Self.url(cur)), a.base == cur, a.amount > 0, let inr = a.rates["INR"], inr > 0 else { return (cur, nil) }
                    // (to four places: a yen is under a rupee, and two places would be half a percent off)
                    return (cur, Rate(p: (inr / a.amount * 10000).rounded() / 10000, d: a.date, src: "ECB"))
                }
            }
            var out: [String: Rate] = [:]
            for await (cur, r) in group { if let r { out[cur] = r } }
            return out
        }
        // a currency that didn't come keeps its last rate (said with its own day) and is asked again within the hour;
        // the day counts as done once every currency came
        for (cur, r) in got where r.p.isFinite && r.p > 0 { next.rates[cur] = r }
        if got.count == Self.currencies.count { next.at = today }
        // (written under the lock, so an Erase that came meanwhile is never undone by this write)
        lock.lock()
        running = false
        guard era == gen else { lock.unlock(); return false }
        saved = next
        if let d = try? JSONEncoder().encode(next) { try? d.write(to: file, options: [.atomic, LiveSession.protection]) }
        lock.unlock()
        return next.rates != before.rates
    }

    private static func fetch(_ s: String) async -> Answer? {
        guard let u = URL(string: s) else { return nil }
        let req = URLRequest(url: u, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 30)
        guard let (data, resp) = try? await URLSession.shared.data(for: req), (resp as? HTTPURLResponse)?.statusCode == 200 else { return nil }
        return try? JSONDecoder().decode(Answer.self, from: data)
    }
}
