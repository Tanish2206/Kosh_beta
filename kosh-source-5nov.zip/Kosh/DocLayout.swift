import Foundation

// MARK: - A page's characters into rows and a grid
//
// Screen-free (Foundation only), so engine-test/doc-layout.js compiles it with swiftc off a Mac against an emulation of
// the same pages. DocText (Documents.swift) hands it each character PDFKit gives with the box it sits in; it puts the
// characters into lines by where they sit (cells three or more spaces apart) and keeps each word's place (the grid:
// "page,y<TAB>x0,x1,word<TAB>…", in thousandths of the page, y from the top), which is what the engine's statement readers
// take.
//
// A page turned to be shown (a landscape statement on a portrait page with /Rotate 90, or a table drawn sideways)
// has its characters running up or down the page's own space, where PDFKit measures them: grouped by height they came out
// one letter a line, and the statement was lost to the row reading (30 Oct, papers QA). So the page is first turned the
// quarter turn that makes its text run left to right, judged by the characters themselves (how each one steps to the next
// within a word): a page whose text already runs left to right is untouched, character for character.
enum DocLayout {
    struct Glyph { let c: UInt16; let r: CGRect }
    struct Page { var rows: [String]; var grid: [String] }

    /// which way the page's text runs in its own space: 0 left to right, 1 upwards, 2 right to left, 3 downwards. Only a
    /// clear majority of at least 20 steps between neighbouring letters turns a page; anything less reads it as it is
    static func runs(_ glyphs: [Glyph]) -> Int {
        var votes = [0, 0, 0, 0]
        var i = 0
        while i + 1 < glyphs.count {
            let a = glyphs[i], b = glyphs[i + 1]
            i += 1
            if a.c == 32 || b.c == 32 { continue }
            let size = max(a.r.width, a.r.height, b.r.width, b.r.height, 1)
            let dx = b.r.midX - a.r.midX, dy = b.r.midY - a.r.midY
            if abs(dx) > size * 2.5 || abs(dy) > size * 2.5 || (abs(dx) < 0.01 && abs(dy) < 0.01) { continue }
            if abs(dx) >= abs(dy) { votes[dx > 0 ? 0 : 2] += 1 } else { votes[dy > 0 ? 1 : 3] += 1 }
        }
        let total = votes.reduce(0, +)
        guard total >= 20, let best = votes.indices.max(by: { votes[$0] < votes[$1] }), best != 0,
              Double(votes[best]) > Double(total) * 0.6 else { return 0 }
        return best
    }

    /// a rect, and the page's box, turned so text that ran `way` runs left to right (PDF space: y grows upwards)
    static func turn(_ r: CGRect, _ way: Int, in box: CGRect) -> CGRect {
        func pt(_ x: CGFloat, _ y: CGFloat) -> (CGFloat, CGFloat) {
            switch way {
            case 1: return (y - box.minY, box.maxX - x)
            case 2: return (box.maxX - x, box.maxY - y)
            case 3: return (box.maxY - y, x - box.minX)
            default: return (x, y)
            }
        }
        let a = pt(r.minX, r.minY), b = pt(r.maxX, r.maxY)
        return CGRect(x: min(a.0, b.0), y: min(a.1, b.1), width: abs(b.0 - a.0), height: abs(b.1 - a.1))
    }
    static func turnedBox(_ box: CGRect, _ way: Int) -> CGRect {
        way == 1 || way == 3 ? CGRect(x: 0, y: 0, width: box.height, height: box.width)
            : way == 2 ? CGRect(x: 0, y: 0, width: box.width, height: box.height) : box
    }

    /// a grid kept from before pages were turned that came out sideways: most of its words a single letter (a kosh
    /// before 30 Oct read a turned page so), so the paper is opened again rather than read from what was kept
    static func sideways(_ grid: String) -> Bool {
        var words = 0, single = 0
        for line in grid.split(separator: "\n") where line != "grid1" {
            for part in line.split(separator: "\t").dropFirst() {
                let bits = part.split(separator: ",", maxSplits: 2, omittingEmptySubsequences: false)
                guard bits.count == 3 else { continue }
                words += 1
                if bits[2].count == 1 { single += 1 }
            }
        }
        return words >= 60 && Double(single) >= Double(words) * 0.8
    }

    /// one page: its rows of text and its grid lines (without the "grid1" head)
    /// (punct-4nov) a letter, figure or symbol as tall as text, not a mark that sits low or small (, . : ; ' ` _ -)
    static func tall(_ c: UInt16) -> Bool {
        switch c { case 44, 46, 58, 59, 39, 96, 95, 45, 8217, 8216, 183: return false; default: return true }
    }
    static func page(_ glyphs0: [Glyph], box box0: CGRect, index: Int) -> Page {
        let way = runs(glyphs0)
        let box = turnedBox(box0, way)
        var chars: [(c: UInt16, r: CGRect)] = glyphs0.map { (c: $0.c, r: way == 0 ? $0.r : turn($0.r, way, in: box0)) }
        let W = max(box.width, 1), H = max(box.height, 1)
        var out: [String] = [], grid: [String] = []
        // lines: characters whose vertical centres sit together (PDF space: y grows upwards)
        chars.sort { $0.r.midY > $1.r.midY }
        // (punct-4nov) the lines are made of the letters and figures; a comma, full stop, colon or other small mark
        // (its box sits low or is short) then joins the line it sits within, never a line of its own (", ." under
        // "3 690 10" made "3,690.10" unreadable)
        let heights: [CGFloat] = chars.filter { $0.c != 32 && Self.tall($0.c) }.map { $0.r.height }.sorted()
        let medH: CGFloat = heights.isEmpty ? 0 : heights[heights.count / 2]
        func small(_ ch: (c: UInt16, r: CGRect)) -> Bool { !Self.tall(ch.c) || (medH > 0 && ch.r.height < medH * 0.45) }
        var lines: [[(c: UInt16, r: CGRect)]] = []
        var lineYs: [CGFloat] = []
        var bands: [(lo: CGFloat, hi: CGFloat)] = []
        var lineY: CGFloat = .infinity, lineH: CGFloat = 0
        var later: [(c: UInt16, r: CGRect)] = []
        for ch in chars {
            if small(ch) && ch.c != 32 { later.append(ch); continue }
            if !lines.isEmpty, abs(lineY - ch.r.midY) <= max(1.5, min(lineH, ch.r.height) * 0.5) {
                lines[lines.count - 1].append(ch)
                let b = bands[bands.count - 1]; bands[bands.count - 1] = (min(b.lo, ch.r.minY), max(b.hi, ch.r.maxY))
            } else {
                lines.append([ch]); lineY = ch.r.midY; lineH = ch.r.height; lineYs.append(ch.r.midY); bands.append((ch.r.minY, ch.r.maxY))
            }
        }
        for ch in later {
            // the line whose letters' height holds the mark (a comma hangs below the line, so its top is what counts),
            // else the nearest line within a line's height, else a line of its own
            var best = -1; var bestD: CGFloat = .infinity
            for (k, b) in bands.enumerated() {
                let h = max(b.hi - b.lo, 1)
                let inside = ch.r.maxY >= b.lo - h * 0.15 && ch.r.minY <= b.hi
                let d = inside ? 0 : min(abs(ch.r.maxY - b.lo), abs(ch.r.minY - b.hi))
                if d < bestD && d <= h * 0.6 { bestD = d; best = k }
                if d == 0 { break }
            }
            if best >= 0 { lines[best].append(ch) } else { lines.append([ch]); lineYs.append(ch.r.midY); bands.append((ch.r.minY, ch.r.maxY)) }
        }
        for n in lines.indices.sorted(by: { lineYs[$0] > lineYs[$1] }) {
            let line = lines[n]
            let sorted = line.sorted { $0.r.minX < $1.r.minX }
            var text = ""
            var lastMax: CGFloat? = nil
            var avg: CGFloat = 0
            let letters = sorted.filter { $0.c != 32 }
            if !letters.isEmpty { avg = letters.reduce(0) { $0 + $1.r.width } / CGFloat(letters.count) }
            // the words of the line with where they sit
            var words: [(x0: CGFloat, x1: CGFloat, t: String)] = []
            var cur: (x0: CGFloat, x1: CGFloat, t: String)? = nil
            for ch in sorted {
                if ch.c == 32 {
                    if !text.hasSuffix(" ") && !text.isEmpty { text += " " }
                    lastMax = ch.r.maxX
                    if let w = cur { words.append(w); cur = nil }
                    continue
                }
                if let m = lastMax {
                    let gap = ch.r.minX - m
                    if gap > max(avg, 2) * 1.8 { text = text.trimmingCharacters(in: .whitespaces) + "   " }
                    else if gap > max(avg, 2) * 0.3 && !text.hasSuffix(" ") { text += " " }
                    if gap > max(avg, 2) * 0.3, let w = cur { words.append(w); cur = nil }
                }
                let one = String(utf16CodeUnits: [ch.c], count: 1)
                text += one
                if var w = cur { w.x1 = max(w.x1, ch.r.maxX); w.t += one; cur = w } else { cur = (ch.r.minX, ch.r.maxX, one) }
                lastMax = ch.r.maxX
            }
            if let w = cur { words.append(w) }
            let t = text.trimmingCharacters(in: .whitespaces)
            if !t.isEmpty { out.append(t) }
            guard !words.isEmpty else { continue }
            let y = Int(((box.maxY - lineYs[n]) / H * 1000).rounded())
            var parts: [String] = ["\(index),\(y)"]
            for w in words {
                let x0 = Int(((w.x0 - box.minX) / W * 1000).rounded()), x1 = Int(((w.x1 - box.minX) / W * 1000).rounded())
                parts.append("\(x0),\(max(x1, x0 + 1)),\(w.t.replacingOccurrences(of: "\t", with: " "))")
            }
            grid.append(parts.joined(separator: "\t"))
        }
        return Page(rows: out, grid: grid)
    }
}
