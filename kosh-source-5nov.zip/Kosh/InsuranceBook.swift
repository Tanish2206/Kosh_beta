import SwiftUI
import Charts

// MARK: - Insurance: the policy book on a phone
//
// Nothing to upload. Insurers email the policy schedule when a policy starts, a receipt every time a premium
// is paid, a renewal notice before it's due and, for unit-linked plans, a unit statement with the fund value.
// kosh reads all of these from your mail (opening locked PDFs with the password rule the insurer's own mail
// states), matches them to the premium payments in your bank and card alerts, and keeps one record per policy.
// The home (InsuranceObsidian.swift, the black look he picked on 1 Nov): a ring of the premiums a year by kind, the
// cover they buy, what's due next, each kind as a tile, the kinds no policy was found of, whose name they're in, and
// every policy. Each kind's tile opens its part (InsurancePages.swift: Health, Life, Motor, Other); "Up next" opens the
// payments timeline (InsurancePayments.swift); a policy opens its page (InsurancePolicy.swift). What this file keeps is
// what those share. A figure kosh doesn't know is never shown as ₹0: its row is left out, or it says what's missing.

struct InsuranceBook: View {
    @Environment(Store.self) private var store
    var body: some View {
        ScrollView {
            InsuranceHome()
                .padding(.horizontal, 20)
                .padding(.top, 8)
                .padding(.bottom, 30)
        }
        .animation(Motion.base, value: store.who)
        .obsidianPage(aura: Obsidian.savings)
    }
}

/// what the Insurance pages share: which part a policy is in, the rows each part shows, the vehicles, the
/// look items and health rows for whoever's money is showing, and how a missing figure is said
enum InsBook {
    /// the parts of Insurance, in their order
    static let parts: [String] = ["Health", "Life", "Motor", "Other"]
    static func part(_ p: Policy) -> String { PolicyKinds.part(p) }
    /// a part's rows: running policies, never one kosh only knows from payments (that one waits in Needs a look)
    static func rows(_ all: [Policy], _ part: String) -> [Policy] {
        let mine: [Policy] = all.filter { PolicyKinds.part($0) == part && !PolicyKinds.onlyPaid($0) }
        return mine.sorted { a, b in
            let ca: Double = a.cover ?? 0, cb: Double = b.cover ?? 0
            if ca != cb { return ca > cb }
            return a.insurer < b.insurer
        }
    }
    static func vehicles(_ store: Store) -> [VehicleInfo] {
        (store.snap.vehicles ?? []).filter { store.who.owns($0.owner) }
    }
    static func look(_ store: Store) -> [LookItem] {
        (store.snap.needsLook ?? []).filter { store.who.owns($0.owner ?? "me") }
    }
    /// the household's cover gaps the build's tab line noticed (engine/21p, `smarts.insurance`): no health or life cover
    /// kosh can see for someone, a vehicle's cover ended. Shown under Needs a look since the line above the home went
    /// (his ask, 1 Nov); the premiums it also told are Up next's. The household's, so on the family's page only. When no
    /// premium is due the build moves its first gap into the line, so the line counts only when it is one of these.
    static func coverNotes(_ store: Store) -> [String] {
        guard store.who == .family, let s = store.snap.smarts?.insurance else { return [] }
        let gap: [String] = ["No health cover", "No life cover", "A vehicle’s cover"]
        let lead: [String] = gap.contains(where: { s.line.hasPrefix($0) }) ? [s.line] : []
        return lead + (s.notes ?? [])
    }
    static func health(_ store: Store) -> [HealthPerson] {
        let all: [HealthPerson] = store.snap.healthBy ?? []
        return store.who == .family ? all : all.filter { $0.id == store.who.id }
    }
    static func policy(_ store: Store, _ id: String) -> Policy? { store.snap.policies.first { $0.id == id } }

    /// a person by the name the household knows them by: "you", "Papa", or the name a policy prints
    static func who(_ id: String, _ snap: SnapBox) -> String {
        if id == "me" { return "you" }
        if let p = snap.people.first(where: { $0.id == id }) { return p.name }
        if let n = snap.healthBy?.first(where: { $0.id == id })?.name, !n.isEmpty { return n }
        if let n = snap.personName(id) { return n }
        return id.hasPrefix("n:") ? String(id.dropFirst(2)).capitalized : id.capitalized
    }
    /// whom a policy covers, in words: "covers Papa", "covers you, Asha, Papa and Mom", "covers 6 people"
    static func covers(_ p: Policy, _ snap: SnapBox) -> String {
        let ids: [String] = (p.covers ?? []).isEmpty ? [p.owner] : (p.covers ?? [])
        if ids.count > 4 { return "covers \(ids.count) people" }
        let names: [String] = ids.map { who($0, snap) }
        if names.count == 1 { return "covers " + names[0] }
        return "covers " + names.dropLast().joined(separator: ", ") + " and " + (names.last ?? "")
    }
    /// where a figure kosh doesn't have is: "in its locked paper", "not in mail yet"
    static func whereIs(_ p: Policy, _ what: String) -> String {
        guard let g = (p.gaps ?? []).first(where: { $0.what == what }) else { return "not in mail yet" }
        let a: String = g.at
        if a.contains("locked") { return "in its locked paper" }
        if a.contains("not opened") { return "in a paper not opened yet" }
        if a.contains("couldn") { return "in a paper kosh couldn’t read" }
        if a.contains("its PDF") { return "not in its mail or paper" }
        return "not in mail yet"
    }
    /// its missing cover or premium is in its policy paper, which came locked (engine.js › insuranceBook)
    static func locked(_ p: Policy) -> Bool { p.paperLocked == true && ((p.cover ?? 0) <= 0 || p.premium <= 0) }
    /// "Paper locked: cover and premium show once it opens", naming only what's still missing
    static func lockedLine(_ p: Policy) -> String {
        let part: String = PolicyKinds.part(p)
        var what: [String] = []
        if (p.cover ?? 0) <= 0 { what.append(part == "Motor" ? "IDV" : part == "Health" ? "sum insured" : "cover") }
        if p.premium <= 0 { what.append("premium") }
        if what.isEmpty { return "Paper locked" }
        return "Paper locked: " + what.joined(separator: " and ") + (what.count == 1 ? " shows" : " show") + " once it opens"
    }
    /// what opens a policy's locked paper, as its insurer's mail says it ("Your date of birth opens it."): Needs a look's
    /// own words for it, "" when there are none
    static func opens(_ store: Store, _ p: Policy) -> String {
        let t: String = (store.snap.needsLook ?? []).first(where: { $0.policy == p.id && $0.why == "locked" })?.text ?? ""
        return t.replacingOccurrences(of: "Its paper is locked. ", with: "")
    }
    /// one health policy on a person's row: "Care Supreme (shared) · ₹10L sum insured · renews 9 Jan 2027"
    static func healthLine(_ p: Policy) -> String {
        let shared: String = (p.covers ?? []).count > 1 ? " (shared)" : ""
        let c: Double = p.cover ?? 0
        let cover: String = c > 0 ? Fmt.words(c) + " sum insured" : locked(p) ? "sum insured in its locked paper" : "sum insured not read yet"
        let renews: String = p.nextDue.isEmpty ? "" : " · renews " + Day.fmt(p.nextDue, "d MMM yyyy")
        return name(p) + shared + " · " + cover + renews
    }
    /// a missing figure, said: "Premium not in mail yet", "Cover: in its locked paper"
    static func unknown(_ p: Policy, _ what: String, _ label: String) -> String {
        let w: String = whereIs(p, what)
        return w == "not in mail yet" ? label + " not in mail yet" : label + ": " + w
    }
    /// a policy's name: its plan, else its insurer and kind
    static func name(_ p: Policy) -> String {
        let plan: String = p.plan ?? ""
        // (a motor policy by its vehicle, when kosh read it: "Triumph Scrambler 400 X")
        if let m = p.model, !m.isEmpty, InsKind.of(p) == .motor { return m }
        if !plan.isEmpty { return plan }
        // (no plan named: "Bajaj Life policy", never "Bajaj Life life")
        let kind: String = PolicyKinds.title(PolicyKinds.of(p)).lowercased()
        return p.insurer.lowercased().contains(kind) || kind.isEmpty ? p.insurer + " policy" : p.insurer + " " + kind
    }
    /// days from today to a day ("" days: none)
    static func days(_ today: String, _ day: String) -> Int {
        Day.cal.dateComponents([.day], from: Day.date(today), to: Day.date(day)).day ?? 0
    }
    /// what a premium costs a year, said: "₹15,000 a year", "₹2,500 a month"
    static func premiumLine(_ p: Policy) -> String {
        if p.premium <= 0 { return "" }
        if let y = p.years, y >= 2 { return Fmt.rupees(p.premium) + " for \(y) years" }
        return Fmt.rupees(p.premium) + " " + p.premiumEvery
    }
}

// MARK: The four parts

/// a part's heading: its name, how many, and the way to its own page
struct InsPartHead: View {
    @Environment(Store.self) private var store
    let title: String
    let sym: String
    let color: Color
    var note: String = ""
    var route: Route? = nil
    var more: String = "See all"
    var body: some View {
        VStack(alignment: .leading, spacing: 3) {
            HStack(alignment: .firstTextBaseline, spacing: 8) {
                Image(systemName: sym).font(.headline).foregroundStyle(color).accessibilityHidden(true)
                Text(title).font(.title3.weight(.bold)).accessibilityAddTraits(.isHeader)
                Spacer(minLength: 8)
                if let r = route {
                    Button { store.push(r) } label: { Text(more).font(.subheadline.weight(.semibold)) }
                        .accessibilityLabel(more + ", " + title)
                }
            }
            if !note.isEmpty { Text(note).font(.footnote).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true) }
        }
    }
}

/// a group of rows on a card, each a button to its policy
struct InsRows: View {
    @Environment(Store.self) private var store
    let pols: [Policy]
    var body: some View {
        VStack(spacing: 0) {
            ForEach(Array(pols.enumerated()), id: \.element.id) { i, p in
                if i > 0 { Divider().padding(.leading, 62) }
                Button {
                    if store.live != nil && p.source == "manual" { store.betaSheet = .policy(p.id) } else { store.push(.policy(p.id)) }
                } label: { PolicyRow(p: p).padding(.horizontal, 14).padding(.vertical, 11) }
                .buttonStyle(.press)
            }
        }
        .background(CardFill(), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
    }
}

/// "3 more", under a part's first rows
struct InsMoreLink: View {
    @Environment(Store.self) private var store
    let n: Int
    let route: Route
    var body: some View {
        Button { store.push(route) } label: {
            HStack {
                Text("\(n) more").font(.subheadline.weight(.semibold))
                Spacer()
                Image(systemName: "chevron.right").font(.footnote.weight(.semibold)).foregroundStyle(.tertiary)
            }
            .padding(.horizontal, 14).padding(.vertical, 12)
            .background(CardFill(), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        }
        .buttonStyle(.press)
    }
}

/// a part with nothing in it: what would bring it, and the way to add one
struct InsNone: View {
    @Environment(Store.self) private var store
    let text: String
    var add: Bool = false
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(text).font(.subheadline).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            if add && store.live != nil {
                Button { store.betaSheet = .policy(nil) } label: { Label("Add one", systemImage: "plus.circle").font(.subheadline.weight(.semibold)) }
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(14)
        .background(CardFill(opacity: 0.7), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
    }
}

// MARK: Motor

/// where a vehicle's cover stands, as a pill: Covered, Renew in N days, Lapsed
enum VehicleStatus {
    static func pill(_ v: VehicleInfo) -> (String, Color) {
        switch v.status {
        case "lapsed": return ("Lapsed", Color.red)
        case "due":
            let d: Int = v.days ?? 0
            if d < 0 { return ("Renewal was due", Color.red) }
            if d == 0 { return ("Renew today", Color.orange) }
            return ("Renew in \(d) day" + (d == 1 ? "" : "s"), Color.orange)
        default: return ("Covered", Color.green)
        }
    }
    static func kindWord(_ v: VehicleInfo) -> String {
        switch v.kind {
        case "Car": return "Car"
        case "Two-wheeler": return "Two-wheeler"
        default: return "Car or two-wheeler"
        }
    }
    static func sym(_ v: VehicleInfo) -> String { v.kind == "Two-wheeler" ? "scooter" : "car.fill" }
    /// "Renews 1 Nov 2026", "Ended 19 Aug 2026", or that the date isn't in its mail
    static func renewLine(_ v: VehicleInfo) -> String {
        let day: String = v.renews ?? ""
        if day.isEmpty { return "Renewal date not in mail yet" }
        let word: String = v.status == "lapsed" ? "Ended " : "Renews "
        return word + Day.fmt(day, "d MMM yyyy")
    }
    /// "Comprehensive, with zero depreciation", or that its mail doesn't say
    static func coverLine(_ v: VehicleInfo) -> String {
        let type: String = v.coverType ?? ""
        if type.isEmpty { return "Not in mail yet" }
        let adds: [String] = v.addOns ?? []
        if adds.isEmpty { return type }
        return type + ", with " + adds.joined(separator: ", ").lowercased()
    }
    /// near or past its renewal: motor cover has no grace period
    static func warning(_ v: VehicleInfo) -> String {
        if v.status == "covered" { return "" }
        if v.status != "lapsed" { return "Motor cover has no grace period: renew before it ends." }
        let why: String = v.why ?? ""
        if why.isEmpty { return "Its cover has ended. Renew it before you drive." }
        return why + " Renew it before you drive."
    }
    /// the link to its current policy: "This year's policy ••0003"
    static func thisYear(_ p: Policy?) -> String {
        let no: String = p?.policyNo ?? ""
        if no.count > 4 { return "This year's policy ••" + String(no.suffix(4)) }
        return "This year's policy"
    }
}

// MARK: Needs a look

struct LookSection: View {
    @Environment(Store.self) private var store
    let items: [LookItem]
    var limit: Int = 0
    var body: some View {
        let shown: [LookItem] = limit > 0 && items.count > limit ? Array(items.prefix(limit - 1)) : items
        VStack(alignment: .leading, spacing: 10) {
            InsPartHead(title: "Needs a look", sym: "exclamationmark.magnifyingglass", color: Color.orange,
                        note: items.isEmpty ? "" : "What kosh found but can’t fill in, and the one thing that would.")
            if items.isEmpty {
                Text("Nothing: every policy kosh found has its cover and premium.").font(.subheadline).foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(14)
                    .background(CardFill(opacity: 0.7), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            } else {
                VStack(spacing: 0) {
                    ForEach(Array(shown.enumerated()), id: \.element.id) { i, it in
                        if i > 0 { Divider().padding(.leading, 50) }
                        LookRow(it: it).padding(.horizontal, 14).padding(.vertical, 12)
                    }
                }
                .background(CardFill(), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
                if items.count > shown.count { InsMoreLink(n: items.count - shown.count, route: .cover("Look")) }
            }
        }
    }
}

/// one thing kosh can't fill in, and the button that would
struct LookRow: View {
    @Environment(Store.self) private var store
    let it: LookItem
    var sym: String {
        switch it.why {
        case "locked": return "lock.fill"
        case "payments": return "indianrupeesign.circle.fill"
        case "unread": return "hourglass"
        default: return "doc.text.magnifyingglass"
        }
    }
    var title: String {
        let k: String = it.kind ?? ""
        let word: String = k.isEmpty || k == "Other" || k == "Policy" ? "" : " · " + PolicyKinds.title(k)
        return (it.insurer ?? "A policy") + word
    }
    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: sym)
                .font(.system(.subheadline, weight: .semibold))
                .foregroundStyle(Color.orange)
                .frame(width: 26, height: 26)
                .background(Color.orange.opacity(0.13), in: Circle())
                .accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 6) {
                Text(title).font(.subheadline.weight(.semibold))
                Text(it.text).font(.subheadline).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true).privacySensitive()
                actions
            }
            Spacer(minLength: 0)
        }
    }
    @ViewBuilder var actions: some View {
        if let live = store.live {
            switch it.why {
            case "locked":
                Button { store.betaSheet = .documents } label: { Label("Open it", systemImage: "lock.open").font(.subheadline.weight(.semibold)) }
            case "payments":
                HStack(spacing: 16) {
                    Button { store.betaSheet = .policy(nil) } label: { Label("Add its number", systemImage: "plus.circle").font(.subheadline.weight(.semibold)) }
                    if let key = it.key, !key.isEmpty {
                        Button { live.markPolicy(key, "ended") } label: { Text("It’s ended").font(.subheadline) }
                    }
                }
            case "unread":
                Button { Task { await live.scan() } } label: { Label("Read new mail", systemImage: "arrow.clockwise").font(.subheadline.weight(.semibold)) }
                    .disabled(live.running)
            default:
                if let id = it.policy {
                    Button { store.sheet = .capture("policy:" + id) } label: { Label("Add from the policy paper", systemImage: "doc.viewfinder").font(.subheadline.weight(.semibold)) }
                }
            }
        }
    }
}

/// what came from your mail, and what would fill in the rest; never a form to upload
struct MailFirstCard: View {
    @Environment(Store.self) private var store
    let found: Int
    var body: some View {
        let live = store.live
        let locked = live?.records.count(where: { $0.doc?.kind == "policy" && $0.doc?.state == "locked" }) ?? 0
        let unread = live?.records.count(where: { $0.doc?.kind == "policy" && ($0.doc?.state ?? "") == "" }) ?? 0
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 10) {
                Image(systemName: "envelope.badge.shield.half.filled").font(.title3).foregroundStyle(Color.kosh)
                Text(found == 0 ? "Policies come from your mail" : "From your mail").font(.headline)
                Spacer()
            }
            Text(found == 0
                 ? "Insurers email the schedule when a policy starts, a receipt for every premium, and renewal notices. kosh reads them, and matches premiums to your bank and card alerts. Nothing to upload."
                 : "Schedules, receipts, renewal notices and unit statements, matched to the premiums in your bank and card alerts.")
                .font(.subheadline).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            if locked > 0 {
                Button { store.betaSheet = .documents } label: {
                    Label("\(locked) policy PDF\(locked == 1 ? "" : "s") locked: give the password once", systemImage: "lock.open").font(.subheadline.weight(.semibold))
                }
            } else if unread > 0 {
                Label("\(unread) policy PDF\(unread == 1 ? "" : "s") waiting to be read", systemImage: "hourglass").font(.subheadline).foregroundStyle(.secondary)
            }
            if let live, live.signedIn {
                Button { Task { await live.scan() } } label: { Label("Read new mail", systemImage: "arrow.clockwise").font(.subheadline.weight(.semibold)) }.disabled(live.running)
            }
        }
        .padding(14)
        .background(Color.kosh.opacity(0.06), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
    }
}

/// where a policy stands, as a short word and a colour (nothing for one simply in force)
enum PolicyStatus {
    static func chip(_ p: Policy) -> (String, Color)? {
        switch p.status ?? "" {
        case "due": return ("Due soon", Color.orange)
        case "overdue": return ("Past due", Color.red)
        case "paidup": return ("Paid up", Color.green)
        case "lapsed": return ("Lapsed", Color.red)
        case "expired": return ("Expired", Color.secondary)
        case "renewed": return ("Renewed", Color.secondary)
        case "matured": return ("Matured", Color.green)
        case "ended": return ("Ended", Color.secondary)
        default: return nil
        }
    }
}

/// what no longer runs: lapsed, expired, renewed under a new number, matured. Kept, out of the way, each with why;
/// one kosh got wrong (a premium paid some way kosh can't see) goes back with "Still running"
struct PolicyArchive: View {
    @Environment(Store.self) private var store
    let pols: [Policy]
    @State private var open = false
    var body: some View {
        if !pols.isEmpty {
            VStack(alignment: .leading, spacing: 10) {
                Button { withAnimation(Fold.motion(opening: !open)) { open.toggle() } } label: {
                    HStack {
                        Label("Archive", systemImage: "archivebox").font(.title3.weight(.bold)).foregroundStyle(Color.primary)
                        Text(String(pols.count)).font(.subheadline.weight(.semibold)).foregroundStyle(.secondary)
                        Spacer()
                        Image(systemName: open ? "chevron.up" : "chevron.down").font(.subheadline.weight(.semibold)).foregroundStyle(.secondary)
                    }
                    .contentShape(Rectangle())
                }
                .buttonStyle(.press)
                Text("Lapsed, expired, renewed under a new number, or matured. Not counted in your cover or premiums.")
                    .font(.footnote).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                if open {
                    VStack(spacing: 10) {
                        ForEach(pols) { p in
                            Button { store.push(.policy(p.id)) } label: { ArchivedPolicyRow(p: p) }.buttonStyle(.press)
                        }
                    }
                }
            }
        }
    }
}

struct ArchivedPolicyRow: View {
    @Environment(Store.self) private var store
    let p: Policy
    var body: some View {
        let name: String = (p.plan ?? "").isEmpty ? p.insurer : (p.plan ?? "")
        let no: String = (p.policyNo ?? "").isEmpty ? "" : " ••" + String((p.policyNo ?? "").suffix(4))
        VStack(alignment: .leading, spacing: 6) {
            HStack(alignment: .top, spacing: 12) {
                PolicyBadge(p: p, size: 32).opacity(0.6)
                VStack(alignment: .leading, spacing: 2) {
                    Text(name).font(.subheadline.weight(.semibold)).lineLimit(1)
                    Text(p.insurer + no + " · " + store.ownerName(p.owner)).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                }
                Spacer(minLength: 4)
                if let st = PolicyStatus.chip(p) { Chip(text: st.0, color: st.1) }
            }
            if let w = p.statusWhy, !w.isEmpty { Text(w).font(.caption).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true) }
            if p.status == "lapsed" || p.status == "expired", let live = store.live, let key = p.key, !key.isEmpty {
                Button { live.markPolicy(key, "active") } label: { Label("Still running? Put it back", systemImage: "arrow.uturn.backward").font(.caption.weight(.semibold)) }
            }
        }
        .padding(12)
        .background(CardFill(opacity: 0.7), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
    }
}

struct VerdictChip: View {
    let v: String
    var color: Color {
        if v.hasPrefix("Keep") || v.hasPrefix("Continue") || v.hasPrefix("Paid") { return Color.green }
        if v.hasPrefix("Weigh") || v.hasPrefix("Pay the last") || v.hasPrefix("Decide") { return Color.orange }
        return Color.secondary
    }
    var body: some View { Chip(text: v, color: color) }
}

// MARK: Timeline

/// the years each policy runs: paying (solid), running on after the last premium (thin), money back (dot)
struct PolicyTimeline: View {
    @Environment(Store.self) private var store
    let pols: [Policy]
    struct Row: Identifiable { let p: Policy; let name: String; let start: Date; let payEnd: Date; let end: Date?; let back: Double; var id: String { p.id } }
    /// what VoiceOver says of the bars: each policy's years
    static func spoken(_ rows: [Row]) -> String {
        let each: [String] = rows.map { r -> String in
            let paying: String = "paid from " + Day.cal.component(.year, from: r.start).description + " to " + Day.cal.component(.year, from: r.payEnd).description
            let runs: String = r.end.map { ", runs to " + Day.cal.component(.year, from: $0).description } ?? ""
            let back: String = r.back > 0 ? ", money comes back at the end" : ""
            return r.name + ", " + paying + runs + back
        }
        return "The years they run: " + each.joined(separator: "; ")
    }
    var body: some View {
        let rows: [Row] = pols.compactMap { p in
            guard let s = p.start, !s.isEmpty else { return nil }
            let pe = (p.payEnd ?? "").isEmpty ? (p.endDate ?? p.nextDue) : (p.payEnd ?? "")
            guard !pe.isEmpty else { return nil }
            let e = (p.endDate ?? "").isEmpty ? nil : Day.date(p.endDate ?? "")
            return Row(p: p, name: (p.plan ?? "").isEmpty ? p.insurer : (p.plan ?? ""), start: Day.date(s), payEnd: Day.date(pe), end: e, back: p.maturity ?? 0)
        }
        if rows.count >= 1 {
            let today = Day.date(store.snap.today)
            VStack(alignment: .leading, spacing: 10) {
                VStack(alignment: .leading, spacing: 2) {
                    Text("The years they run").font(.headline)
                    Text("Solid while you pay; a thin line while it runs on; a dot where money comes back.").font(.subheadline).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                }
                Chart {
                    ForEach(rows) { r in
                        if let e = r.end, e > r.payEnd {
                            BarMark(xStart: .value("From", r.payEnd), xEnd: .value("To", e), y: .value("Policy", r.name), height: 3)
                                .foregroundStyle(PolicyLook.color(r.p.type).opacity(0.45))
                        }
                        BarMark(xStart: .value("From", r.start), xEnd: .value("To", r.payEnd), y: .value("Policy", r.name), height: 10)
                            .foregroundStyle(PolicyLook.color(r.p.type).gradient).cornerRadius(3)
                        if r.back > 0, let e = r.end {
                            PointMark(x: .value("When", e), y: .value("Policy", r.name)).foregroundStyle(Color.green).symbolSize(60)
                        }
                    }
                    RuleMark(x: .value("Today", today)).foregroundStyle(Color.secondary.opacity(0.5)).lineStyle(StrokeStyle(lineWidth: 1, dash: [3, 4]))
                        .annotation(position: .top, alignment: .leading) { Text("today").font(.caption2).foregroundStyle(.secondary) }
                }
                .chartYAxis { AxisMarks(position: .leading) { _ in AxisValueLabel().font(.caption) } }
                .chartXAxis { AxisMarks(values: .stride(by: .year, count: max(1, rows.count > 4 ? 10 : 5))) { _ in AxisValueLabel(format: .dateTime.year()).font(.caption2); AxisGridLine().foregroundStyle(Color.hairline) } }
                .frame(height: CGFloat(28 * rows.count + 40))
                // the years only: no figures, said the same with amounts hidden
                .accessibilityElement(children: .ignore)
                .accessibilityLabel(Self.spoken(rows))
            }
            .card(16)
        }
    }
}

// MARK: What it earns, when money comes back

struct WhatItEarns: View {
    let pols: [Policy]
    var body: some View {
        let rows = pols.filter { $0.xirr != nil || ($0.verdict ?? "").hasPrefix("Add") }.sorted { ($0.xirr ?? -99) > ($1.xirr ?? -99) }
        if !rows.isEmpty {
            VStack(alignment: .leading, spacing: 10) {
                VStack(alignment: .leading, spacing: 2) {
                    Text("What it earns").font(.headline)
                    Text("XIRR: the yearly return on every premium paid, against the fund value today or the maturity figure. A fixed deposit earns about 7%.").font(.subheadline).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                }
                VStack(spacing: 0) {
                    ForEach(Array(rows.enumerated()), id: \.element.id) { i, p in
                        if i > 0 { Divider() }
                        HStack(spacing: 10) {
                            PolicyBadge(p: p, size: 30)
                            VStack(alignment: .leading, spacing: 1) {
                                Text((p.plan ?? "").isEmpty ? p.insurer : (p.plan ?? "")).font(.subheadline.weight(.medium)).lineLimit(1)
                                Text(p.verdictWhy ?? "").font(.caption).foregroundStyle(.secondary).lineLimit(2)
                            }
                            Spacer()
                            if let x = p.xirr {
                                Text(Fmt.trim(x, 1) + "%").font(.subheadline.weight(.bold)).monospacedDigit().foregroundStyle(x >= 7 ? Color.green : x >= 4 ? Color.primary : Color.orange)
                            } else { Text("—").foregroundStyle(.secondary) }
                        }
                        .padding(.vertical, 8)
                    }
                }
            }
            .card(16)
            .privacySensitive()
        }
    }
}

struct MoneyBack: View {
    @Environment(Store.self) private var store
    let pols: [Policy]
    struct Item: Identifiable { let p: Policy; let date: String; let amt: Double; var id: String { p.id } }
    var body: some View {
        let items: [Item] = pols.compactMap { p in
            guard let e = p.endDate, !e.isEmpty, e >= store.snap.today else { return nil }
            let v: Double = p.maturity ?? 0
            let saving: Bool = ["ULIP", "Endowment", "Savings", "Money back", "Pension"].contains(PolicyKinds.of(p))
            return v > 0 || saving ? Item(p: p, date: e, amt: v) : nil
        }.sorted { $0.date < $1.date }
        if !items.isEmpty {
            VStack(alignment: .leading, spacing: 10) {
                VStack(alignment: .leading, spacing: 2) {
                    Text("When money comes back").font(.headline)
                    Text("Maturity dates, with the figure where the schedule or a statement gave one.").font(.subheadline).foregroundStyle(.secondary)
                }
                VStack(spacing: 0) {
                    ForEach(Array(items.enumerated()), id: \.element.id) { i, it in
                        if i > 0 { Divider().padding(.leading, 52) }
                        HStack(spacing: 12) {
                            DateBadge(date: it.date)
                            VStack(alignment: .leading, spacing: 1) {
                                Text((it.p.plan ?? "").isEmpty ? it.p.insurer : (it.p.plan ?? "")).font(.subheadline.weight(.medium)).lineLimit(1)
                                Text(Self.inWords(from: store.snap.today, to: it.date)).font(.caption).foregroundStyle(.secondary)
                            }
                            Spacer()
                            Text(it.amt > 0 ? Fmt.words(it.amt) : "figure not known").font(.subheadline.weight(.semibold)).foregroundStyle(it.amt > 0 ? Color.green : Color.secondary)
                        }
                        .padding(.vertical, 8)
                    }
                }
            }
            .card(16)
            .privacySensitive()
        }
    }
    static func inWords(from: String, to: String) -> String {
        let c = Day.cal.dateComponents([.year, .month], from: Day.date(from), to: Day.date(to))
        let y = c.year ?? 0, m = c.month ?? 0
        if y <= 0 && m <= 0 { return "this month" }
        if y <= 0 { return "in \(m) month\(m == 1 ? "" : "s")" }
        return "in \(y) year\(y == 1 ? "" : "s")" + (m > 0 ? " \(m) month\(m == 1 ? "" : "s")" : "")
    }
}


/// is the cover enough: health against the family and a city hospital bill, life against years of income
struct CoverCheck: View {
    @Environment(Store.self) private var store
    let pols: [Policy]
    /// "Health" or "Life" for that part's notes alone; "" for both
    var only: String = ""
    static func yearlyIncome(_ cf: [CashMonth]) -> Double {
        let full = cf.filter { !$0.live && $0.inn > 0 }.suffix(6)
        guard !full.isEmpty else { return 0 }
        return full.map(\.inn).reduce(0, +) / Double(full.count) * 12
    }
    var notes: [SmartNote] {
        let healthKinds: Set<String> = ["Health", "Top-up"]
        let mine: [Policy] = pols.filter { healthKinds.contains(PolicyKinds.of($0)) }
        // (one person's page: a floater someone else holds covers them too)
        let shared: [Policy] = store.who == .family ? [] : store.snap.policies.filter { p in
            !p.isEnded && healthKinds.contains(PolicyKinds.of(p)) && !pols.contains(p) && (p.covers ?? []).contains(store.who.id)
        }
        // (how many it's for: everyone a floater covers counts, a member kosh doesn't know yet too; one person's page is one)
        let covered: Set<String> = Set(mine.flatMap { $0.covers ?? [$0.owner] })
        let people: Int = store.who == .family ? max(1, store.snap.people.count, covered.count) : 1
        let health: Double = (mine + shared).reduce(0) { $0 + ($1.cover ?? 0) }
        let life: Double = pols.filter { ["Term", "Life", "Whole life", "Endowment", "Savings", "ULIP", "Money back", "Pension"].contains(PolicyKinds.of($0)) }.reduce(0) { $0 + ($1.cover ?? 0) }
        let income: Double = Self.yearlyIncome(store.snap.cashflow ?? [])
        var out: [SmartNote] = []
        let healthWant: Double = Double(people) * 500000
        let healthOn: Bool = only != "Life"
        if healthOn && health > 0 && health < healthWant {
            out.append(SmartNote(id: "h", sym: "cross.case.fill", color: Color.orange, text: "Health cover is " + Fmt.words(health) + (people > 1 ? " for \(people) of you" : "") + ". One hospital stay in a city runs to " + Fmt.words(500000) + " a person; a top-up plan adds cover cheaply."))
        } else if healthOn && health == 0 && !(mine + shared).isEmpty {
            // (a health policy whose sum insured isn't read yet is cover kosh can't size, never no cover)
            out.append(SmartNote(id: "h1", sym: "cross.case.fill", color: Color.secondary, text: "kosh found your health polic" + ((mine + shared).count == 1 ? "y" : "ies") + " but not yet the sum insured. Needs a look says where it is."))
        } else if healthOn && health == 0 {
            out.append(SmartNote(id: "h0", sym: "cross.case.fill", color: Color.orange, text: "No health cover found in your mail. If you hold one, its schedule may be on another Gmail, or add it by hand."))
        }
        if income > 0 && only != "Health" {
            if life > 0 && life < income * 10 {
                out.append(SmartNote(id: "l", sym: "heart.fill", color: Color.orange, text: "Life cover is " + Fmt.words(life) + " against about " + Fmt.words(income) + " a year coming in. Ten years of income (" + Fmt.words(income * 10) + ") is the usual mark; term cover gets there cheaply."))
            } else if life == 0 {
                out.append(SmartNote(id: "l0", sym: "heart.fill", color: Color.secondary, text: "No life cover found. With " + Fmt.words(income) + " a year coming in, a term plan for about " + Fmt.words(income * 10) + " is the usual starting point."))
            } else {
                out.append(SmartNote(id: "lok", sym: "checkmark.seal.fill", color: Color.green, text: "Life cover of " + Fmt.words(life) + " is more than ten years of what comes in. Good."))
            }
        }
        return out
    }
    var body: some View {
        let n = notes
        if !n.isEmpty {
            VStack(alignment: .leading, spacing: 10) {
                Text("Is it enough?").font(.headline)
                SmartNotes(notes: n)
            }
            .privacySensitive()
        }
    }
}
