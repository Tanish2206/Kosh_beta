import SwiftUI

// MARK: - Cards
//
// Your cards in three piles, each a deck whose cards open where they sit. On top, one card for the lot: what's to
// pay, what went on the cards in 30 days, and the next month as a ribbon with a dot on each bill's day (red when
// late, amber within the week); tap a dot for its card. Then Pay soon (a bill to pay, the soonest first), In use
// (spent on in the last 60 days, or its bill paid) and Resting (nothing due, nothing spent). Each pile folds into
// one row (its cards fanned, its figure in bold, a line on what's in it) and remembers whether you left it open.
// Each strip carries its bill and when it's due, or what went on it; tap one and it opens in place: its bill, what
// went on it this cycle, and its latest payments. The Bills segment beside Cards lists every bill by when it falls;
// tapping one opens its card here. A card kosh knows only from a statement or a bill reminder is here too.

struct WalletCards: View {
    @Environment(Store.self) private var store
    /// the card open in its deck
    @Binding var open: String?
    /// a card to open and scroll to (from the Bills list)
    @Binding var jump: String?
    /// which piles are open (kept on the phone); folded, each is one row with its figure and its cards fanned.
    /// The page reads it into state, so opening and folding animate (a stored setting changes outside the animation)
    @AppStorage("cards.piles") private var saved = ""
    @State private var piles: Set<Int>?

    static let full: CGFloat = 206
    static let strip: CGFloat = 62

    var body: some View {
        let today: String = store.snap.today
        // (an old card, nothing from it in 90 days, is out of the piles: folded away under Old cards, CardShelf)
        let shelf: (live: [CardInfo], old: [CardInfo]) = CardShelf.split(store.cards)
        let all: [CardInfo] = shelf.live
        let old: [CardInfo] = shelf.old
        let spend: [String: Double] = store.cardSpend30(today: today)
        let book: BillBook = store.billBook(all, spend: spend, orphans: false)
        let slots: [CardSlot] = CardPiles.slots(all, book: book, spend: spend, today: today)
        let pay: [CardSlot] = CardPiles.pile(slots, .pay)
        let use: [CardSlot] = CardPiles.pile(slots, .use)
        let rest: [CardSlot] = CardPiles.pile(slots, .rest)
        let logos: Bool = IconBook.shared.all(all.map { ($0.bank, $0.name) })
        ScrollViewReader { proxy in
            ScrollView {
                VStack(alignment: .leading, spacing: 0) {
                    if all.isEmpty && old.isEmpty {
                        ContentUnavailableView("No cards yet", systemImage: "creditcard",
                                               description: Text("Swipe once and the alert brings the card along. Statements and bill reminders count too."))
                            .padding(.top, 40)
                        LookAgainCard(noun: "card").padding(.top, 26)
                    } else {
                        CardsTop(slots: slots, pay: pay, book: book, today: today) { id in go(id, slots: slots, proxy: proxy) }
                        pile(.pay, pay, logos: logos)
                        pile(.use, use, logos: logos)
                        pile(.rest, rest, logos: logos)
                        LookAgainCard(noun: "card").padding(.top, 30)
                        if !old.isEmpty { OldCards(cards: old).padding(.top, 26) }
                        StatementsGroup(kind: "cardstmt", bank: "", logos: logos, needsOnly: true).padding(.top, 26)
                        AnotherGmail().padding(.top, 26)
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 14)
                .padding(.bottom, 40)
            }
            .onAppear { if let j = jump { go(j, slots: slots, proxy: proxy) } }
            .onChange(of: jump) { _, j in if let j { go(j, slots: slots, proxy: proxy) } }
        }
        .sensoryFeedback(.selection, trigger: open)
    }

    /// a pile: its row (cards fanned, its figure in bold, a line on what's in it) and, open, its deck unrolled
    /// under it with the fold's motion; the row opens and folds it
    @ViewBuilder func pile(_ p: CardPile, _ slots: [CardSlot], logos: Bool) -> some View {
        if !slots.isEmpty {
            let today: String = store.snap.today
            let on: Bool = isOpen(p)
            VStack(alignment: .leading, spacing: 0) {
                PileFold(title: PileWords.title(p), figure: PileWords.figure(p, slots), line: PileWords.line(p, slots, today: today),
                         slots: slots, open: on) {
                    setOpen(p, !on, slots: slots)
                }
                .padding(.top, 16)
                Unfold(open: on) {
                    CardDeck(slots: slots, open: $open, logos: logos)
                        .padding(.top, 14)
                }
            }
        }
    }
    static func decode(_ s: String) -> Set<Int> { Set(s.split(separator: ",").compactMap { Int($0) }) }
    func isOpen(_ p: CardPile) -> Bool { (piles ?? Self.decode(saved)).contains(p.rawValue) }
    func setOpen(_ p: CardPile, _ on: Bool, slots: [CardSlot] = []) {
        var s: Set<Int> = piles ?? Self.decode(saved)
        withAnimation(Fold.motion(opening: on)) {
            if on { s.insert(p.rawValue) } else {
                s.remove(p.rawValue)
                if slots.contains(where: { $0.id == open }) { open = nil }
            }
            piles = s
        }
        saved = s.sorted().map(String.init).joined(separator: ",")
    }

    /// open a card where it sits (unfolding its pile) and bring it into view
    func go(_ id: String, slots: [CardSlot], proxy: ScrollViewProxy) {
        jump = nil
        if let s = slots.first(where: { $0.id == id }), !isOpen(s.pile) { setOpen(s.pile, true) }
        withAnimation(Motion.large) { open = id }
        Task { @MainActor in
            try? await Task.sleep(for: .milliseconds(320))
            withAnimation(Motion.reveal) { proxy.scrollTo(CardDeck.anchor(id), anchor: UnitPoint(x: 0.5, y: 0.05)) }
        }
    }

    static func count(_ n: Int, _ noun: String) -> String { n == 1 ? "1 " + noun : String(n) + " " + noun + "s" }
    static func latest(_ k: Int, of n: Int) -> String? { n > k ? "Latest " + String(k) + " of " + String(n) : nil }
    /// what went on each card (by its row) in the stretch: each payment on its own card's row, found by the card's
    /// name, or by its bank and last four digits when the payment's card goes by another name (CardMatch)
    static func spend(_ tx: [Txn], index: CardMatch.Index, span: Span, today: String) -> [String: Double] {
        var out: [String: Double] = [:]
        let (lo, hi) = span.range(today: today)
        for t in tx where CardMatch.counts(t) && t.partOf == nil && t.d >= lo && t.d <= hi {
            guard let id = index.row(t) else { continue }
            out[id, default: 0] += t.full ?? t.a
        }
        return out
    }
}

extension Store {
    /// the cards as matching payments to them sees them (CardMatch.Index): a key that changes when they do
    fileprivate var cardsKey: String { snap.cards.map { $0.id + "/" + $0.bank + "/" + $0.last }.joined(separator: "|") }
    /// what went on each card in the last 30 days (WalletCards.spend), worked out once a change to the payments
    func cardSpend30(today: String) -> [String: Double] {
        let key: String = today + "|" + cardsKey
        if cardSpendMemo.gen == txGen && cardSpendMemo.key == key { return cardSpendMemo.out }
        let out: [String: Double] = WalletCards.spend(tx, index: CardMatch.Index(snap.cards), span: .last30, today: today)
        cardSpendMemo = (txGen, key, out)
        return out
    }
    /// one card's payments from `from` to today, the newest first, with its own side of a bill paid (once a change)
    func cardTxs(_ card: String, from: String, today: String) -> [Txn] {
        let key: String = card + "|" + from + "|" + today + "|" + cardsKey
        if cardTxMemo.gen != txGen || cardTxMemo.mgen != mirrorsGen { cardTxMemo = (txGen, mirrorsGen, [:]) }
        if let known = cardTxMemo.by[key] { return known }
        let index: CardMatch.Index = CardMatch.Index(snap.cards)
        let made: [Txn] = (tx + mirrors).filter { $0.d >= from && $0.d <= today && index.row($0) == card }.sorted { ($0.d, $0.t) > ($1.d, $1.t) }
        cardTxMemo.by[key] = made
        return made
    }
}

// MARK: - The piles

/// where a card sits on the page: a bill to pay, in use, or resting
enum CardPile: Int { case pay, use, rest }

/// a card as the page shows it: its pile, its bill (the open one, or the last paid), what went on it in 30 days
struct CardSlot: Identifiable {
    let c: CardInfo
    let pile: CardPile
    let bill: CardBill?
    let spent: Double
    var id: String { c.id }
}

/// the words on a strip's pill, and its colours
struct CardPill {
    let text: String
    let bg: Color
    let fg: Color
}

enum CardPiles {
    /// each card in its pile: an unpaid bill → Pay soon; spends in 30 days, used in the last 60, or a bill paid
    /// → In use; else Resting
    static func slots(_ cards: [CardInfo], book: BillBook, spend: [String: Double], today: String) -> [CardSlot] {
        var bills: [String: CardBill] = [:]
        for b in book.all { if let id = b.cardID, bills[id] == nil { bills[id] = b } }
        let recent: String = Day.add(today, -60)
        return cards.map { c in
            let b: CardBill? = bills[c.id]
            let spent: Double = spend[c.id] ?? 0
            var pile: CardPile = .rest
            if let b, !b.paid, b.left > 0 {
                pile = .pay
            } else if spent > 0 || b != nil || (!c.lastUsed.isEmpty && c.lastUsed >= recent) {
                pile = .use
            }
            return CardSlot(c: c, pile: pile, bill: b, spent: spent)
        }
    }

    /// a pile in order: bills soonest first (late at the top), then most spent, then most lately used
    static func pile(_ slots: [CardSlot], _ p: CardPile) -> [CardSlot] {
        let x: [CardSlot] = slots.filter { $0.pile == p }
        switch p {
        case .pay:
            return x.sorted { a, b in
                let da: String = a.bill?.due ?? "", db: String = b.bill?.due ?? ""
                return da != db ? da < db : (a.bill?.left ?? 0) > (b.bill?.left ?? 0)
            }
        case .use:
            return x.sorted { a, b in a.spent != b.spent ? a.spent > b.spent : a.c.lastUsed > b.c.lastUsed }
        case .rest:
            return x.sorted { a, b in a.c.lastUsed != b.c.lastUsed ? a.c.lastUsed > b.c.lastUsed : a.c.id < b.c.id }
        }
    }

    /// the card's next statement, from the day of the month its last one came (nil when kosh hasn't seen one)
    static func nextStatement(_ c: CardInfo, today: String) -> String? {
        guard let s = c.stmtOn, s.count == 10, let day = Int(s.suffix(2)) else { return nil }
        var m: String = String(s.prefix(7))
        for _ in 0..<15 {
            m = Day.addMonths(m, 1)
            let d: String = m + "-" + String(format: "%02d", min(day, Day.daysIn(m)))
            if d > today { return d }
        }
        return nil
    }

    /// the pill on a strip: how late, or when it's due (amber within the week); when its next bill comes; when last used
    static func pill(_ s: CardSlot, today: String) -> CardPill {
        let quiet: Color = Color.black.opacity(0.3)
        switch s.pile {
        case .pay:
            guard let b = s.bill else { return CardPill(text: "Bill due", bg: quiet, fg: .white) }
            let n: Int = b.daysLeft(today)
            if n < 0 { return CardPill(text: n == -1 ? "1 day late" : String(-n) + " days late", bg: Color(hex: "#FF453A"), fg: .white) }
            if n == 0 { return CardPill(text: "Due today", bg: Color(hex: "#FF9F0A"), fg: Color(hex: "#2B1600")) }
            if n <= 7 { return CardPill(text: Day.fmt(b.due, "EEE d") + " · in " + String(n) + "d", bg: Color(hex: "#FF9F0A"), fg: Color(hex: "#2B1600")) }
            return CardPill(text: "Due " + Day.fmt(b.due, "EEE d"), bg: Color.white.opacity(0.24), fg: .white)
        case .use:
            if let next = nextStatement(s.c, today: today) { return CardPill(text: "Bill " + Day.fmt(next, "d MMM"), bg: quiet, fg: .white) }
            if let b = s.bill, b.paid { return CardPill(text: "Paid " + Day.fmt(b.paidOn.isEmpty ? b.due : b.paidOn, "d MMM"), bg: quiet, fg: .white) }
            if !s.c.lastUsed.isEmpty { return CardPill(text: "Used " + Day.fmt(s.c.lastUsed, "d MMM"), bg: quiet, fg: .white) }
            return CardPill(text: "In use", bg: quiet, fg: .white)
        case .rest:
            let u: String = s.c.lastUsed
            if u.isEmpty { return CardPill(text: "Never used", bg: quiet, fg: Color.white.opacity(0.9)) }
            let when: String = Day.fmt(u, u.prefix(4) == today.prefix(4) ? "d MMM" : "MMM yyyy")
            return CardPill(text: "Last used " + when, bg: quiet, fg: Color.white.opacity(0.9))
        }
    }

    /// the strip's top right: the bill still to pay, what went on it, or that it's resting
    static func right(_ s: CardSlot) -> String {
        switch s.pile {
        case .pay: return Fmt.rupees(s.bill?.left ?? 0)
        case .use: return s.spent > 0 ? Fmt.rupees(s.spent) : "No spends"
        case .rest: return "Resting"
        }
    }

    /// the card's foot: the minimum and its statement, what went on it, or nothing at all
    static func foot(_ s: CardSlot) -> String {
        switch s.pile {
        case .pay:
            guard let b = s.bill else { return "" }
            let stmt: String = b.stmtOn.isEmpty ? "" : "statement " + Day.fmt(b.stmtOn, "d MMM")
            if b.paidAmt > 0 { return Fmt.rupees(b.paidAmt) + " paid so far" + (b.minDue > 0 ? " · min " + Fmt.rupees(b.minDue) : "") }
            if b.minDue > 0 { return "Minimum " + Fmt.rupees(b.minDue) + (stmt.isEmpty ? "" : " · " + stmt) }
            return stmt.isEmpty ? "From your mail" : Words.cap(stmt)
        case .use:
            if s.spent > 0 { return Fmt.rupees(s.spent) + " in 30 days" }
            if let b = s.bill, b.paid { return "Last bill paid" }
            return "Nothing spent lately"
        case .rest:
            return "Nothing due · nothing spent"
        }
    }

    /// the card's name as said, with no figures (what VoiceOver says while amounts are hidden)
    static func spokenName(_ s: CardSlot) -> String { CardWords.title(s.c) + (s.c.last.isEmpty ? "" : ", ending " + s.c.last) }
    static func spoken(_ s: CardSlot, today: String) -> String {
        let name: String = spokenName(s)
        switch s.pile {
        case .pay: return name + ", " + (s.bill.map { $0.spoken(today) } ?? "bill due")
        case .use: return name + ", " + (s.spent > 0 ? Fmt.rupees(s.spent) + " in the last 30 days" : "no spends lately") + ", " + pill(s, today: today).text
        case .rest: return name + ", resting, " + pill(s, today: today).text
        }
    }
}

/// a pile as a deck: each card's top strip over the next, the last one whole; tap a card and it opens where it
/// sits, its details under it, the cards below it moving down; tap it again (or Close) and it settles back
struct CardDeck: View {
    @Environment(Store.self) private var store
    let slots: [CardSlot]
    @Binding var open: String?
    let logos: Bool
    static func anchor(_ id: String) -> String { "card|" + id }

    var body: some View {
        let today: String = store.snap.today
        VStack(spacing: 0) {
            ForEach(Array(slots.enumerated()), id: \.element.id) { i, s in
                row(i, s, today: today).zIndex(Double(i))
            }
        }
    }

    func row(_ i: Int, _ s: CardSlot, today: String) -> some View {
        let isOpen: Bool = open == s.id
        let last: Bool = i == slots.count - 1
        return VStack(spacing: 0) {
            Button {
                withAnimation(Fold.motion(opening: !isOpen)) { open = isOpen ? nil : s.id }
            } label: {
                CardFace(c: s.c, mark: !logos, right: CardPiles.right(s), pill: CardPiles.pill(s, today: today), foot: CardPiles.foot(s))
                    .frame(height: WalletCards.full)
                    .offset(y: isOpen ? -2 : 0)
            }
            .buttonStyle(.press)
            .frame(height: isOpen || last ? WalletCards.full : WalletCards.strip, alignment: .top)
            .spokenFigures(CardPiles.spoken(s, today: today), hidden: CardPiles.spokenName(s))
            .accessibilityHint(isOpen ? "Closes its details" : "Opens its details here")
            Unfold(open: isOpen) {
                CardOpen(s: s) { withAnimation(Fold.close) { open = nil } }
                    .padding(.top, 10)
                    .padding(.bottom, last ? 0 : 18)
            }
        }
        .id(Self.anchor(s.id))
    }
}

/// a pile's row: its cards fanned (spreading a little when the pile is open), its name and figure in bold, a line
/// on what's in it, and a chevron; it opens the pile and folds it
struct PileFold: View {
    let title: String
    let figure: String
    let line: String
    let slots: [CardSlot]
    var open: Bool = false
    let toggle: () -> Void
    var body: some View {
        let fan: [CardSlot] = Array(slots.prefix(6))
        let spread: Double = open ? 1.7 : 1
        Button(action: toggle) {
            HStack(spacing: 14) {
                ZStack(alignment: .topLeading) {
                    ForEach(Array(fan.enumerated()), id: \.element.id) { i, s in
                        MiniCard(hex: s.c.color, width: 54)
                            .shadow(color: .black.opacity(0.35), radius: 3, y: 2)
                            .rotationEffect(.degrees((-9 + Double(i) * 3.4) * spread))
                            .offset(x: CGFloat(i) * 9 * (open ? 1.15 : 1), y: CGFloat(i % 2) * 3 + 4)
                    }
                }
                .frame(width: 104, height: 46, alignment: .topLeading)
                .animation(Fold.motion(opening: open), value: open)
                .accessibilityHidden(true)
                VStack(alignment: .leading, spacing: 3) {
                    HStack(alignment: .firstTextBaseline, spacing: 6) {
                        Text(title).font(.system(.body, weight: .semibold)).lineLimit(1)
                        Spacer(minLength: 4)
                        Text(figure)
                            .font(.system(.body, design: .rounded, weight: .bold)).monospacedDigit()
                            .lineLimit(1).minimumScaleFactor(0.75)
                            .privacySensitive()
                    }
                    Text(line)
                        .font(.system(.footnote)).foregroundStyle(.secondary)
                        .lineLimit(2).fixedSize(horizontal: false, vertical: true)
                        .privacySensitive()
                }
                Image(systemName: "chevron.down").font(.system(.caption, weight: .bold)).foregroundStyle(.tertiary)
                    .foldTurn(open)
            }
            .padding(14)
            .background(Color.surface, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
            .contentShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
        }
        .buttonStyle(.press)
        .accessibilityElement(children: .combine)
        .accessibilityAddTraits(.isButton)
        .accessibilityHint(open ? "Folds the pile" : "Opens the pile")
    }
}

/// the cards nothing has come from in 90 days (CardShelf), folded away at the foot of the page: each one's name and the
/// day of its last mail. Still cards, and everything counted from them stands; only out of the piles
struct OldCards: View {
    @Environment(Store.self) private var store
    let cards: [CardInfo]
    @State private var open = false
    @State private var retiredOpen = false
    var body: some View {
        let today: String = store.snap.today
        let parts = CardShelf.retire(cards, today: today)
        let onlyRetired: Bool = parts.quiet.isEmpty
        let title: String = onlyRetired ? "Retired cards · " + String(parts.retired.count) : "Old cards · " + String(parts.quiet.count)
        let hint: String = onlyRetired ? "Nothing from them in over a year" : "Nothing from them in 90 days"
        VStack(alignment: .leading, spacing: 0) {
            Button { withAnimation(Fold.motion(opening: !open)) { open.toggle() } } label: {
                HStack(spacing: 8) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(title).font(.system(.subheadline, weight: .semibold)).foregroundStyle(Color.primary)
                        Text(hint).font(.system(.caption)).foregroundStyle(.secondary)
                    }
                    Spacer(minLength: 6)
                    Image(systemName: "chevron.down").font(.system(.caption, weight: .bold)).foregroundStyle(.tertiary).foldTurn(open)
                }
                .padding(.horizontal, 14).padding(.vertical, 12)
                .contentShape(Rectangle())
            }
            .buttonStyle(.press)
            .accessibilityHint(open ? "Folds the old cards" : "Shows the old cards")
            Unfold(open: open) {
                VStack(spacing: 0) {
                    ForEach(parts.quiet) { (c: CardInfo) in
                        RowRule(inset: 0)
                        row(c, today: today)
                    }
                    if onlyRetired {
                        ForEach(parts.retired) { (c: CardInfo) in
                            RowRule(inset: 0)
                            row(c, today: today).opacity(0.6)
                        }
                    } else if !parts.retired.isEmpty {
                        RowRule(inset: 0)
                        Button { withAnimation(Fold.motion(opening: !retiredOpen)) { retiredOpen.toggle() } } label: {
                            HStack(spacing: 8) {
                                Text(String(parts.retired.count) + " retired · quiet for over a year")
                                    .font(.system(.footnote, weight: .medium)).foregroundStyle(.secondary)
                                Spacer(minLength: 6)
                                Image(systemName: "chevron.down").font(.system(.caption2, weight: .bold)).foregroundStyle(.tertiary).foldTurn(retiredOpen)
                            }
                            .frame(minHeight: 40)
                            .contentShape(Rectangle())
                        }
                        .buttonStyle(.press)
                        Unfold(open: retiredOpen) {
                            VStack(spacing: 0) {
                                ForEach(parts.retired) { (c: CardInfo) in row(c, today: today).opacity(0.6) }
                            }
                        }
                    }
                }
                .padding(.horizontal, 14)
            }
        }
        .background(Color.surface, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
    }
    func row(_ c: CardInfo, today: String) -> some View {
        let name: String = CardWords.full(c)
        let line: String = CardShelf.oldLine(c, today: today)
        return HStack(spacing: 10) {
            MiniCard(hex: c.color, width: 30).accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 1) {
                Text(name).font(.system(.subheadline)).lineLimit(1)
                Text(line).font(.system(.caption)).foregroundStyle(.secondary).lineLimit(1)
            }
            Spacer(minLength: 0)
        }
        .padding(.vertical, 10)
        .accessibilityElement(children: .combine)
    }
}

/// what a pile says about itself, folded or open
enum PileWords {
    static func title(_ p: CardPile) -> String {
        switch p {
        case .pay: return "Pay soon"
        case .use: return "In use"
        case .rest: return "Resting"
        }
    }
    static func left(_ slots: [CardSlot]) -> Double { slots.reduce(0) { $0 + ($1.bill?.left ?? 0) } }
    static func spent(_ slots: [CardSlot]) -> Double { slots.reduce(0) { $0 + $1.spent } }
    /// the figure on a folded pile: what's to pay, what went on them, how many are napping
    static func figure(_ p: CardPile, _ slots: [CardSlot]) -> String {
        switch p {
        case .pay: return Fmt.rupees(left(slots))
        case .use: return spent(slots) > 0 ? Fmt.rupees(spent(slots)) : WalletCards.count(slots.count, "card")
        case .rest: return WalletCards.count(slots.count, "card")
        }
    }
    /// the heading's figure when it's open
    static func meta(_ p: CardPile, _ slots: [CardSlot]) -> String {
        switch p {
        case .pay: return String(slots.count) + " · " + Fmt.rupees(left(slots))
        case .use: return spent(slots) > 0 ? String(slots.count) + " · " + Fmt.rupees(spent(slots)) + " spent" : String(slots.count)
        case .rest: return String(slots.count)
        }
    }
    /// "9 bills · 1 late · 3 this week · next Regalia, Tue 13"; "7 cards · most on Regalia"; napping, not lost
    static func line(_ p: CardPile, _ slots: [CardSlot], today: String) -> String {
        switch p {
        case .pay:
            var bits: [String] = [BillWords.bills(slots.count)]
            let late: Int = slots.filter { ($0.bill?.daysLeft(today) ?? 0) < 0 }.count
            let week: Int = slots.filter { (0...7).contains($0.bill?.daysLeft(today) ?? -1) }.count
            if late > 0 { bits.append(String(late) + " late") }
            if week > 0 { bits.append(String(week) + " this week") }
            if let next = slots.first(where: { ($0.bill?.daysLeft(today) ?? -1) >= 0 }), let b = next.bill {
                bits.append("next " + CardWords.short(next.c) + ", " + Day.fmt(b.due, "EEE d"))
            }
            return bits.joined(separator: " · ")
        case .use:
            let top: CardSlot? = slots.max(by: { $0.spent < $1.spent })
            let most: String = top.map { $0.spent > 0 ? " · most on " + CardWords.short($0.c) : "" } ?? ""
            return WalletCards.count(slots.count, "card") + " in 30 days" + most
        case .rest:
            return "Nothing due, nothing spent in 60 days. Napping, not lost."
        }
    }
}

// MARK: - On top: what's to pay, what went on the cards, and the month's bills on a ribbon

struct CardsTop: View {
    let slots: [CardSlot]
    let pay: [CardSlot]
    let book: BillBook
    let today: String
    let go: (String) -> Void

    var body: some View {
        let toPay: Double = pay.reduce(0) { $0 + ($1.bill?.left ?? 0) }
        let late: Int = pay.filter { ($0.bill?.daysLeft(today) ?? 0) < 0 }.count
        let spent: Double = slots.reduce(0) { $0 + $1.spent }
        let spenders: Int = slots.filter { $0.spent > 0 }.count
        let bills: String = pay.isEmpty ? "Nothing due" : WalletCards.count(pay.count, "bill")
        let quip: String = BillWords.quip(book)
        let onLine: String = "on " + String(spenders) + " of " + String(slots.count) + " cards"
        let lateWord: String = " · " + String(late) + " late"
        VStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .bottom, spacing: 12) {
                VStack(alignment: .leading, spacing: 1) {
                    Text("To pay").font(.system(.footnote, weight: .semibold)).foregroundStyle(.secondary)
                    Text(Fmt.rupees(toPay))
                        .font(.system(.largeTitle, design: .rounded, weight: .bold)).monospacedDigit()
                        .lineLimit(1).minimumScaleFactor(0.7)
                        .contentTransition(.numericText(value: toPay))
                        .privacySensitive()
                    HStack(spacing: 0) {
                        Text(bills).foregroundStyle(.secondary)
                        if late > 0 { Text(lateWord).fontWeight(.semibold).foregroundStyle(BillInk.late) }
                    }
                    .font(.system(.footnote))
                }
                Spacer(minLength: 8)
                VStack(alignment: .trailing, spacing: 1) {
                    Text("Spent, 30 days").font(.system(.footnote, weight: .semibold)).foregroundStyle(.secondary)
                    Text(Fmt.rupees(spent))
                        .font(.system(.title3, design: .rounded, weight: .bold)).monospacedDigit()
                        .lineLimit(1).minimumScaleFactor(0.7)
                        .privacySensitive()
                    Text(onLine).font(.system(.footnote)).foregroundStyle(.secondary)
                }
            }
            BillRibbon(pay: pay, slots: slots, today: today, go: go)
                .frame(height: 62)
            if !quip.isEmpty {
                Rectangle().fill(Color.rule.opacity(0.12)).frame(height: 0.5)
                Text(quip)
                    .font(.system(.footnote))
                    .foregroundStyle(Color.primary.opacity(0.8))
                    .fixedSize(horizontal: false, vertical: true)
                    .privacySensitive()
            }
        }
        .padding(.horizontal, 16)
        .padding(.top, 16)
        .padding(.bottom, 14)
        .background(Color.surface, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
    }
}

/// the next month on one line: today, a dot on each day a bill falls (as big as what's due, red when late, amber
/// within the week), a ring where a card's next statement should land; tap a dot for its card
struct BillRibbon: View {
    let pay: [CardSlot]
    let slots: [CardSlot]
    let today: String
    let go: (String) -> Void
    @Environment(\.accessibilityReduceMotion) private var still

    struct Mark: Identifiable {
        let day: String
        let n: Int
        let amount: Double
        let ids: [String]
        let spoken: String
        /// the same with no figures, while amounts are hidden
        let quiet: String
        var id: String { day }
    }
    static let back: Int = 3
    static let ahead: Int = 30

    static func x(_ n: Int, width: CGFloat) -> CGFloat {
        let d: CGFloat = CGFloat(max(-back, min(ahead, n)) + back)
        return 15 + d / CGFloat(back + ahead) * (width - 30)
    }
    static func ink(_ n: Int) -> Color {
        if n < 0 { return Color(hex: "#FF453A") }
        if n <= 7 { return Color(hex: "#FF9F0A") }
        return Color(light: "#636366", dark: "#E5E5EA")
    }

    var body: some View {
        let marks: [Mark] = Self.marks(pay, today: today)
        let top: Double = max(1, marks.map(\.amount).max() ?? 1)
        let stmts: [Int] = slots.filter { $0.pile == .use }.compactMap { CardPiles.nextStatement($0.c, today: today) }.map { Day.between(today, $0) }.filter { $0 > 0 && $0 <= Self.ahead }
        GeometryReader { g in
            let w: CGFloat = g.size.width
            let labels: [(CGFloat, String, Color)] = Self.labels(marks, width: w, today: today)
            ZStack(alignment: .topLeading) {
                Capsule()
                    .fill(LinearGradient(colors: [Color.rule.opacity(0.4), Color.rule.opacity(0.1)], startPoint: .leading, endPoint: .trailing))
                    .frame(width: w - 12, height: 2)
                    .offset(x: 6, y: 24)
                Text("Today").font(.system(.caption2, weight: .bold))
                    .fixedSize()
                    .position(x: Self.x(0, width: w), y: 6)
                Capsule().fill(Color.primary).frame(width: 2, height: 16).position(x: Self.x(0, width: w), y: 25)
                ForEach(Array(Set(stmts)).sorted(), id: \.self) { n in
                    Circle().strokeBorder(Color.rule.opacity(0.5), lineWidth: 1.5).frame(width: 8, height: 8)
                        .position(x: Self.x(n, width: w), y: 25)
                }
                ForEach(marks) { m in
                    let size: CGFloat = 10 + 8 * CGFloat((m.amount / top).squareRoot())
                    let ink: Color = Self.ink(m.n)
                    Button { if let id = m.ids.first { go(id) } } label: {
                        Circle().fill(ink)
                            .frame(width: size, height: size)
                            .padding(2)
                            .background(Circle().fill(Color.surface))
                            .overlay(Circle().strokeBorder(ink.opacity(0.55), lineWidth: 2).padding(-2))
                            .modifier(Breathe(on: m.n < 0 && !still))
                            .frame(width: 32, height: 32)
                            .contentShape(Circle())
                    }
                    .buttonStyle(.press)
                    .position(x: Self.x(m.n, width: w), y: 25)
                    .spokenFigures(m.spoken, hidden: m.quiet)
                    .accessibilityHint("Opens its card")
                }
                ForEach(Array(labels.enumerated()), id: \.offset) { _, l in
                    Text(l.1).font(.system(.caption2, weight: .semibold)).foregroundStyle(l.2)
                        .fixedSize()
                        .position(x: min(max(l.0, 22), w - 22), y: 52)
                        .accessibilityHidden(true)
                }
            }
        }
        .accessibilityElement(children: .contain)
        .accessibilityLabel("Bills over the next 30 days")
    }

    /// a dot for each day with bills to pay
    static func marks(_ pay: [CardSlot], today: String) -> [Mark] {
        var by: [String: [CardSlot]] = [:]
        for s in pay { if let b = s.bill { by[b.due, default: []].append(s) } }
        return by.keys.sorted().map { d in
            let ss: [CardSlot] = by[d] ?? []
            let amt: Double = ss.reduce(0) { $0 + ($1.bill?.left ?? 0) }
            let names: String = ss.map { CardWords.short($0.c) }.joined(separator: ", ")
            let n: Int = Day.between(today, d)
            let when: String = n < 0 ? (n == -1 ? "1 day late" : String(-n) + " days late") : n == 0 ? "due today" : "due " + Day.fmt(d, "EEEE d MMMM")
            return Mark(day: d, n: n, amount: amt, ids: ss.map(\.id), spoken: names + ", " + Fmt.rupees(amt) + ", " + when, quiet: names + ", " + when)
        }
    }

    /// the dates under the dots, left to right, leaving out any that would crowd the one before
    static func labels(_ marks: [Mark], width: CGFloat, today: String) -> [(CGFloat, String, Color)] {
        var out: [(CGFloat, String, Color)] = []
        var lastX: CGFloat = -100
        for m in marks {
            let px: CGFloat = x(m.n, width: width)
            if px - lastX < 40 { continue }
            let text: String = m.n < 0 ? "late" : m.n <= 6 ? Day.fmt(m.day, "EEE d") : Day.fmt(m.day, "d MMM")
            out.append((px, text, m.n < 0 ? BillInk.late : m.n <= 7 ? BillInk.soon : Color.secondary))
            lastX = px
        }
        return out
    }
}

// MARK: - A card, opened where it sits

struct CardOpen: View {
    @Environment(Store.self) private var store
    let s: CardSlot
    let close: () -> Void
    @State private var all = false

    var body: some View {
        let today: String = store.snap.today
        let stmt: String = s.c.stmtOn ?? ""
        let fromStmt: Bool = stmt.count == 10 && stmt >= Day.add(today, -45)
        let from: String = fromStmt ? Day.add(stmt, 1) : Day.add(today, -29)
        // (with the card's own side of a bill paid, which the lists show once, as the payment)
        let txs: [Txn] = store.cardTxs(s.c.id, from: from, today: today)
        let spent: [Txn] = txs.filter { CardMatch.counts($0) && $0.partOf == nil }
        let parts: [(String, Double)] = CardFocus.parts(spent)
        let sum: Double = parts.reduce(0) { $0 + $1.1 }
        let shown: [Txn] = Array(txs.prefix(all ? 40 : 3))
        let paidLine: String = s.bill.map { b in Fmt.rupees(b.amount) + " paid in full, " + Day.fmt(b.paidOn.isEmpty ? b.due : b.paidOn, "EEE d MMM") } ?? ""
        let nextLine: String = CardPiles.nextStatement(s.c, today: today).map { "Statement around " + Day.fmt($0, "EEE d MMM") } ?? ""
        let countLine: String = WalletCards.count(spent.count, "payment") + (fromStmt ? " since " + Day.fmt(stmt, "d MMM") : "")
        let usedLine: String = s.c.lastUsed.isEmpty ? "Not used in a year of mail" : "Last used " + Day.fmt(s.c.lastUsed, "d MMM yyyy")
        let moreLine: String = all ? "Fewer" : "All " + WalletCards.count(txs.count, "payment")
        VStack(alignment: .leading, spacing: 18) {
            if s.pile == .pay, let b = s.bill {
                CardBillBlock(b: b, today: today, mark: s.c.billMark ?? "")
            } else if let b = s.bill, b.paid {
                VStack(alignment: .leading, spacing: 3) {
                    Text("Last bill").font(.system(.footnote, weight: .semibold)).foregroundStyle(.secondary)
                    Text(paidLine)
                        .font(.system(.subheadline, weight: .semibold)).foregroundStyle(BillInk.paid)
                        .privacySensitive()
                }
            }
            if let cr = s.c.credit, cr > 0 {
                CardCreditBlock(amount: cr, on: s.c.creditOn ?? "", byMail: s.c.creditSaid == "mail")
            }
            CardLimitBlock(c: s.c, bill: s.bill)
            if let pays = s.c.pays, !pays.isEmpty {
                CardPaysBlock(pays: pays)
            }
            if s.pile == .use && !nextLine.isEmpty {
                VStack(alignment: .leading, spacing: 3) {
                    Text("Next bill").font(.system(.footnote, weight: .semibold)).foregroundStyle(.secondary)
                    Text(nextLine).font(.system(.body, weight: .semibold))
                }
            }
            if sum > 0 {
                VStack(alignment: .leading, spacing: 9) {
                    HStack(alignment: .firstTextBaseline) {
                        Text(fromStmt ? "This cycle" : "Last 30 days").font(.system(.footnote, weight: .semibold)).foregroundStyle(.secondary)
                        Spacer(minLength: 6)
                        Text(countLine)
                            .font(.system(.footnote)).foregroundStyle(.secondary)
                    }
                    Text(Fmt.rupees(sum)).font(.system(.title2, design: .rounded, weight: .bold)).monospacedDigit().privacySensitive()
                    CardCats(parts: parts, total: sum)
                }
            }
            if s.pile == .rest {
                VStack(alignment: .leading, spacing: 6) {
                    Text(usedLine)
                        .font(.system(.body, weight: .semibold))
                    Text(CardFocus.restLine(s.c, today: today))
                        .font(.system(.footnote)).foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                }
            }
            if !shown.isEmpty {
                VStack(spacing: 0) {
                    ForEach(shown) { t in
                        RowRule(inset: 0)
                        TxRow(t: t, when: Day.label(t.d, today: today), showWay: false).padding(.vertical, 10)
                    }
                    if txs.count > 3 {
                        RowRule(inset: 0)
                        Button {
                            withAnimation(Motion.open) { all.toggle() }
                        } label: {
                            Text(moreLine)
                                .font(.system(.subheadline, weight: .semibold))
                                .foregroundStyle(Color.kosh)
                                .frame(maxWidth: .infinity, minHeight: 44)
                        }
                        .buttonStyle(.press)
                    }
                }
            }
            // the issuer's IDs and numbers for this person (Your details)
            InstitutionDetails(inst: s.c.bank, who: s.c.owner, last4: s.c.last)
            Button("Close", action: close)
                .buttonStyle(.press)
                .font(.system(.footnote, weight: .semibold))
                .foregroundStyle(.secondary)
                .frame(maxWidth: .infinity, minHeight: 32)
        }
        .padding(16)
        .background(Color.surface, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
    }
}

/// a card left in credit by its statement ("Total Amount Due 1,250.00 Cr"): what it owes you, from which statement
struct CardCreditBlock: View {
    let amount: Double
    let on: String
    var byMail: Bool = false
    var body: some View {
        let head: String = on.isEmpty ? "In credit" : "In credit · " + (byMail ? "as of " : "statement ") + Day.fmt(on, "d MMM")
        let words: String = "Nothing is due. The card owes you this, and your next spends come out of it first."
        VStack(alignment: .leading, spacing: 4) {
            Text(head).font(.system(size: 13, weight: .semibold)).foregroundStyle(.secondary)
            Text(Fmt.rupees(amount)).font(.system(size: 22, weight: .bold, design: .rounded)).monospacedDigit().foregroundStyle(BillInk.paid).privacySensitive()
            Text(words).font(.system(size: 13)).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
        }
    }
}

/// a card's limit and how much of it is in use: from its latest alert's or statement's figures, or the limit you typed.
/// Used = the limit less what its alert or statement said was left, on that day; without that, the bill still to pay.
/// A limit its mail never prints is asked for once
struct CardLimitBlock: View {
    @Environment(Store.self) private var store
    let c: CardInfo
    let bill: CardBill?
    @State private var editing = false
    @State private var typed = ""

    /// what's used, as of which day, and what the figure is
    static func used(_ c: CardInfo, _ bill: CardBill?) -> (v: Double, on: String, what: String)? {
        guard let lim = c.limit, lim > 0 else { return nil }
        if let av = c.avail, av >= 0, av <= lim + 1, let on = c.availOn, !on.isEmpty, on >= (c.stmtOn ?? "") {
            return (max(0, lim - av), on, "used")
        }
        if let b = bill, !b.paid, b.left > 0 { return (b.left, b.stmtOn, "on the bill still to pay") }
        return nil
    }

    var body: some View {
        let lim: Double = c.limit ?? 0
        VStack(alignment: .leading, spacing: 8) {
            HStack(alignment: .firstTextBaseline) {
                Text("Credit limit").font(.system(.footnote, weight: .semibold)).foregroundStyle(.secondary)
                Spacer(minLength: 6)
                if !editing {
                    Button(lim > 0 ? "Change" : "Add") { typed = lim > 0 ? String(Int(safe: lim)) : ""; editing = true }
                        .font(.system(.footnote, weight: .semibold)).foregroundStyle(Color.kosh).buttonStyle(.press)
                }
            }
            if editing {
                HStack(spacing: 10) {
                    TextField("₹ limit", text: $typed).keyboardType(.numberPad).font(.system(.body, weight: .semibold))
                        .padding(.horizontal, 12).padding(.vertical, 9)
                        .background(Color.primary.opacity(0.06), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
                    Button("Save") {
                        let v: Double? = Double(typed.filter { $0.isNumber })
                        store.live?.setCardLimit(c.id, v); editing = false
                    }
                    .font(.system(.subheadline, weight: .semibold)).buttonStyle(.press).foregroundStyle(Color.kosh)
                    Button("Cancel") { editing = false }.font(.system(.subheadline)).buttonStyle(.press).foregroundStyle(.secondary)
                }
                if c.limitSaid == "you" {
                    Button("Use what its mail says") { store.live?.setCardLimit(c.id, nil); editing = false }
                        .font(.system(.footnote)).buttonStyle(.press).foregroundStyle(.secondary)
                }
            } else if lim > 0 {
                Text(Fmt.rupees(lim)).font(.system(.title3, design: .rounded, weight: .bold)).monospacedDigit().privacySensitive()
                if let u = Self.used(c, bill) {
                    let share: Double = min(1, u.v / lim)
                    CardLimitBar(share: share)
                    Text(Self.usedLine(u.v, u.what, share, u.on))
                        .font(.system(.footnote, weight: .semibold)).monospacedDigit().privacySensitive()
                    if share > 0.3 {
                        Text("Using more than 30% of a limit can weigh on a credit score.")
                            .font(.system(.footnote)).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                    }
                }
                Text(Self.source(c)).font(.system(.caption)).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            } else {
                Text("Its mail doesn’t print the limit. Add it once to see how much of it you’re using.")
                    .font(.system(.footnote)).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            }
        }
    }

    /// "₹1,85,864 used · 53% · 13 Oct 2026"
    static func usedLine(_ v: Double, _ what: String, _ share: Double, _ on: String) -> String {
        let head: String = Fmt.rupees(v) + " " + what + " · " + Fmt.pct(share)
        return on.isEmpty ? head : head + " · " + Day.fmt(on, "d MMM yyyy")
    }

    /// where the limit came from, in a line
    static func source(_ c: CardInfo) -> String {
        let shared: String = c.limitAll == true ? "Shared by all your " + c.bank + " cards. " : ""
        switch c.limitSaid ?? "" {
        case "you": return shared + "The limit you typed."
        case "statement": return shared + "From its statement" + ((c.limitOn ?? "").isEmpty ? "." : " of " + Day.fmt(c.limitOn ?? "", "d MMM yyyy") + ".")
        default: return shared + "From its alert" + ((c.limitOn ?? "").isEmpty ? "." : " of " + Day.fmt(c.limitOn ?? "", "d MMM yyyy") + ".")
        }
    }
}

/// how much of a card's limit is in use, as a bar: orange past 30%
struct CardLimitBar: View {
    let share: Double
    var body: some View {
        let ink: Color = share > 0.3 ? Color.orange : Color.kosh
        GeometryReader { (g: GeometryProxy) in
            let w: CGFloat = max(4, g.size.width * CGFloat(share))
            ZStack(alignment: .leading) {
                Capsule().fill(Color.primary.opacity(0.08))
                Capsule().fill(ink).frame(width: w)
            }
        }
        .frame(height: 6)
    }
}

/// a bill on an open card: what's due and when, the minimum, and how much has gone towards it
struct CardBillBlock: View {
    @Environment(Store.self) private var store
    let b: CardBill
    let today: String
    /// the bill's own key (CardInfo.billMark): Mark paid holds it until the mail shows the payment
    var mark: String = ""
    var body: some View {
        let n: Int = b.daysLeft(today)
        let ink: Color = n < 0 ? BillInk.late : n <= 7 ? BillInk.soon : Color.secondary
        let words: String = n < 0 ? "Was due " + Day.fmt(b.due, "EEE, d MMM") : "Due " + Day.fmt(b.due, "EEE, d MMM")
        let head: String = b.stmtOn.isEmpty ? "Bill" : "Bill · statement " + Day.fmt(b.stmtOn, "d MMM")
        let share: Double = b.amount > 0 ? min(1, b.paidAmt / b.amount) : 0
        let who: String = b.said == "issuer" ? " (its balance update)" : ""
        let paidLine: String = b.paidAmt > 0
            ? Fmt.rupees(b.paidAmt) + " paid so far" + (b.paidOn.isEmpty ? "" : ", " + Day.fmt(b.paidOn, "d MMM")) + who + ". " + Fmt.rupees(b.left) + " to go."
            : (n < 0 ? "No payment towards it in your email yet. If it’s unpaid, a late fee lands on the next statement." : "Nothing paid towards it yet.")
        let canMark: Bool = !mark.isEmpty && store.live != nil
        VStack(alignment: .leading, spacing: 8) {
            HStack(alignment: .firstTextBaseline, spacing: 8) {
                Text(head).font(.system(.footnote, weight: .semibold)).foregroundStyle(.secondary)
                Spacer(minLength: 6)
                Text(words).font(.system(.footnote, weight: .bold)).foregroundStyle(ink)
            }
            HStack(alignment: .firstTextBaseline) {
                Text(Fmt.rupees(b.left)).font(.system(.title, design: .rounded, weight: .bold)).monospacedDigit().privacySensitive()
                Spacer(minLength: 6)
                if b.minDue > 0 {
                    Text("minimum " + Fmt.rupees(b.minDue)).font(.system(.footnote, design: .rounded)).monospacedDigit().foregroundStyle(.secondary).privacySensitive()
                }
            }
            GeometryReader { g in
                ZStack(alignment: .leading) {
                    Capsule().fill(Color.rule.opacity(0.12))
                    Capsule().fill(BillInk.tick).frame(width: max(0, g.size.width * share))
                }
            }
            .frame(height: 6)
            .accessibilityHidden(true)
            Text(paidLine).font(.system(.footnote)).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true).privacySensitive()
            if canMark {
                // paid from somewhere kosh doesn't read: say so, and it is paid at once (Store.markPaid → ShownRules.paid)
                Button { store.markPaid(mark, undo: true) } label: {
                    Label("Mark paid", systemImage: "checkmark.circle")
                        .font(.system(.subheadline, weight: .semibold))
                        .frame(maxWidth: .infinity, minHeight: 40)
                }
                .buttonStyle(.bordered).tint(Color.kosh)
                .accessibilityHint("Counts this bill paid until your mail shows the payment")
            }
        }
    }
}

/// what the money went on, as one bar and a word for each piece
struct CardCats: View {
    @Environment(Store.self) private var store
    let parts: [(String, Double)]
    let total: Double
    @State private var grown = false
    var body: some View {
        let shares: [(Color, Double)] = parts.map { (color($0.0), $0.1 / max(total, 1)) }
        VStack(alignment: .leading, spacing: 8) {
            SplitBar(parts: shares, grown: grown, height: 8)
            WrapRow(spacing: 14, lineSpacing: 4) {
                ForEach(Array(parts.enumerated()), id: \.offset) { _, p in
                    HStack(spacing: 5) {
                        let label: String = p.0 + " " + Fmt.pct(p.1 / max(total, 1))
                        Circle().fill(color(p.0)).frame(width: 7, height: 7)
                        Text(label)
                    }
                    .font(.system(.caption))
                    .foregroundStyle(Color.primary.opacity(0.8))
                }
            }
        }
        .onAppear { withAnimation(Motion.reveal.delay(0.1)) { grown = true } }
    }
    func color(_ c: String) -> Color { c == "Other" ? Color(.systemGray3) : store.catColor(c) }
}

// MARK: - Which card a payment was on

/// A payment's card is the row whose id is the payment's card name. When no row goes by that name (the same card
/// filed under a slightly different one: "HDFC" and "HDFC Bank", a RuPay flag one mail said and another didn't),
/// the row with the same bank and last four digits has it, so a card with spends never reads "No spends".
enum CardMatch {
    /// what counts as spent on a card: spending under the lens, and a trip's spends that Everyday leaves out of the
    /// month (the card was charged all the same)
    static func counts(_ t: Txn) -> Bool { t.sp || t.ev == true }

    /// "HDFC Bank" → "hdfc", "SBI Card" → "sbi": the bank's name without the words that vary from mail to mail
    static func norm(_ bank: String) -> String {
        var s: String = bank.lowercased().replacingOccurrences(of: "[^a-z0-9]", with: "", options: .regularExpression)
        var trimmed: Bool = true
        while trimmed {
            trimmed = false
            for tail in ["limited", "ltd", "creditcards", "creditcard", "cards", "card", "bank"] where s.count > tail.count && s.hasSuffix(tail) {
                s = String(s.dropLast(tail.count))
                trimmed = true
                break
            }
        }
        return s
    }

    /// "hdfc|7310": a bank and the card's last four; empty when fewer than three digits are known
    static func ident(bank: String, last: String) -> String {
        let digits: String = String(String(last.filter { $0.isNumber }).suffix(4))
        guard digits.count >= 3, !bank.isEmpty else { return "" }
        return norm(bank) + "|" + digits
    }

    /// every card row (everyone's, so a payment on a card that isn't shown never lands on another), by id and by
    /// bank and digits
    struct Index {
        let ids: Set<String>
        let byIdent: [String: String]
        init(_ cards: [CardInfo]) {
            ids = Set(cards.map(\.id))
            var m: [String: String] = [:]
            for c in cards {
                let k: String = CardMatch.ident(bank: c.bank, last: c.last)
                if !k.isEmpty && m[k] == nil { m[k] = c.id }
            }
            byIdent = m
        }
        /// the id of the row this payment's card is, or nil when it wasn't a card's
        func row(_ t: Txn) -> String? {
            if ids.contains(t.card) { return t.card }
            guard t.card.contains(" CC") || t.md == "card" else { return nil }
            let k: String = CardMatch.ident(bank: t.bk ?? "", last: t.l4 ?? "")
            return k.isEmpty ? nil : byIdent[k]
        }
    }
}

// MARK: - How a card is named

enum CardWords {
    /// the card's own name when the mail said it ("Regalia"), else the bank's
    static func short(_ c: CardInfo) -> String {
        let p: String = c.product ?? ""
        if !p.isEmpty { return p }
        return c.name.isEmpty ? c.bank : c.name
    }
    /// the line under the card's name: its bank ("HDFC Bank") when the card has a name of its own; when it
    /// doesn't, the title already is the bank, so what kind of card it is ("RuPay credit card")
    static func under(_ c: CardInfo) -> String {
        let p: String = c.product ?? ""
        if !p.isEmpty { return c.name.isEmpty ? c.bank : c.name }
        let net: String = c.network ?? ""
        return net.isEmpty ? "Credit card" : net + " credit card"
    }
    /// "HDFC Regalia", or "Axis Bank" when the card's own name isn't known
    static func title(_ c: CardInfo) -> String {
        let p: String = c.product ?? ""
        if p.isEmpty { return c.name.isEmpty ? c.bank : c.name }
        if p.lowercased().hasPrefix(c.bank.lowercased()) { return p }
        return c.bank + " " + p
    }
    /// "HDFC Regalia ••7710"
    static func full(_ c: CardInfo) -> String { c.last.isEmpty ? title(c) : title(c) + " ••" + c.last }
    /// where the mail showed it, for a card with no spends
    static func seen(_ c: CardInfo) -> String {
        switch c.seen ?? "" {
        case "statement": return "seen in its statement"
        case "bill": return "seen in a bill reminder"
        case "payment": return "seen in a payment towards it"
        case "balance": return "seen in a balance mail"
        case "mail": return "seen in its mail"
        default: return ""
        }
    }
}


// MARK: - The card itself

/// the bank's colour with a sheen; its mark, the card's name and bank across the top with the bill (or what went
/// on it) and a pill for when it's due on the right, all inside the strip a deck shows; the chip and tap mark; its
/// last four; the foot (the minimum, what went on it, or that it's resting) and the network
struct CardFace: View {
    let c: CardInfo
    var mark: Bool = false
    var right: String = ""
    var pill: CardPill? = nil
    var foot: String = ""
    var body: some View {
        let col: Color = Color(hex: c.color)
        let title: String = CardWords.short(c)
        let bankName: String = CardWords.under(c)
        let network: String = (c.network ?? "").uppercased()
        let digits: String = c.last.isEmpty ? "number not in mail yet" : "•••• " + c.last
        ZStack(alignment: .topLeading) {
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .fill(LinearGradient(colors: [col.mix(with: .white, by: 0.08), col, col.mix(with: .black, by: 0.42)], startPoint: .topLeading, endPoint: .bottomTrailing))
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .fill(LinearGradient(stops: [.init(color: .white.opacity(0.2), location: 0), .init(color: .white.opacity(0), location: 0.36)], startPoint: .topLeading, endPoint: .bottomTrailing))
            VStack(alignment: .leading, spacing: 0) {
                HStack(spacing: 10) {
                    InstIcon(name: c.bank, color: col, size: 30, hint: c.name, glass: true, mark: mark)
                    VStack(alignment: .leading, spacing: 0) {
                        Text(title).font(.system(.callout, weight: .bold)).lineLimit(1)
                        Text(bankName).font(.system(.caption2)).opacity(0.84).lineLimit(1)
                    }
                    Spacer(minLength: 6)
                    VStack(alignment: .trailing, spacing: 3) {
                        Text(right).font(.system(.callout, design: .rounded, weight: .bold)).monospacedDigit()
                            .lineLimit(1).minimumScaleFactor(0.7).privacySensitive()
                        if let pill {
                            Text(pill.text)
                                .font(.system(.caption2, weight: .bold))
                                .lineLimit(1)
                                .foregroundStyle(pill.fg)
                                .padding(.horizontal, 7).padding(.vertical, 2)
                                .background(pill.bg, in: Capsule())
                        }
                    }
                    .layoutPriority(1)
                }
                HStack(spacing: 10) {
                    EMVChip()
                    Image(systemName: "wave.3.right").font(.system(.body, weight: .semibold)).opacity(0.85)
                }
                .padding(.top, 22)
                .padding(.leading, 2)
                Spacer(minLength: 0)
                Text(digits).font(.system(size: c.last.isEmpty ? 11 : 15, design: .monospaced)).tracking(c.last.isEmpty ? 0 : 1.5).opacity(0.92)
                HStack(alignment: .bottom, spacing: 8) {
                    Text(foot).font(.system(.caption, weight: .semibold)).opacity(0.88).lineLimit(1).minimumScaleFactor(0.85).privacySensitive()
                    Spacer(minLength: 4)
                    if !network.isEmpty {
                        Text(network).font(.system(.title3, weight: .heavy)).italic()
                            .lineLimit(1).minimumScaleFactor(0.6)
                    }
                }
                .padding(.top, 6)
            }
            .foregroundStyle(.white)
            .padding(.horizontal, 16).padding(.top, 14).padding(.bottom, 14)
        }
        .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).strokeBorder(Color.white.opacity(0.12), lineWidth: 0.5))
        .shadow(color: .black.opacity(0.18), radius: 9, y: -3)
    }
}


/// the gold contact chip
struct EMVChip: View {
    var body: some View {
        let line: Color = Color(red: 90 / 255, green: 65 / 255, blue: 15 / 255).opacity(0.45)
        RoundedRectangle(cornerRadius: 7, style: .continuous)
            .fill(LinearGradient(colors: [Color(hex: "#F4DC97"), Color(hex: "#D8B45C"), Color(hex: "#B8913C")], startPoint: .topLeading, endPoint: .bottomTrailing))
            .frame(width: 42, height: 31)
            .overlay {
                Path { p in
                    p.move(to: CGPoint(x: 13, y: 0)); p.addLine(to: CGPoint(x: 13, y: 31))
                    p.move(to: CGPoint(x: 28, y: 0)); p.addLine(to: CGPoint(x: 28, y: 31))
                    p.move(to: CGPoint(x: 0, y: 10)); p.addLine(to: CGPoint(x: 42, y: 10))
                    p.move(to: CGPoint(x: 0, y: 20)); p.addLine(to: CGPoint(x: 42, y: 20))
                }
                .stroke(line, lineWidth: 0.8)
            }
            .clipShape(RoundedRectangle(cornerRadius: 7, style: .continuous))
            .accessibilityHidden(true)
    }
}



// MARK: - What a card's payments say

enum CardFocus {}


extension CardFocus {
    /// the newest bill a statement gave for this card
    static func bill(_ agenda: [AgendaItem], key: String) -> AgendaItem? {
        var best: AgendaItem? = nil
        for a in agenda where a.cat == "Card Payments" && a.name.hasPrefix(key) {
            let d: String = a.date ?? ""
            if best == nil || d > (best?.date ?? "") { best = a }
        }
        return best
    }
    /// what the spends went on, the five biggest and the rest as Other
    static func parts(_ spent: [Txn]) -> [(String, Double)] {
        var byCat: [String: Double] = [:]
        for t in spent { byCat[t.c, default: 0] += t.full ?? t.a }
        let cats: [(String, Double)] = byCat.sorted { $0.value != $1.value ? $0.value > $1.value : $0.key < $1.key }.map { ($0.key, $0.value) }
        let rest: Double = cats.dropFirst(5).reduce(0) { $0 + $1.1 }
        var out: [(String, Double)] = Array(cats.prefix(5))
        if rest > 0 { out.append(("Other", rest)) }
        return out
    }
    static func restLine(_ c: CardInfo, today: String) -> String {
        let seen: String = CardWords.seen(c)
        if !c.lastUsed.isEmpty { return "Last used " + Day.when(c.lastUsed, today: today) + ". Resting in the wallet for now." }
        if !seen.isEmpty && (c.seen ?? "alerts") != "alerts" { return "kosh knows it from " + seen.replacingOccurrences(of: "seen in ", with: "") + "; no spends have shown up yet." }
        return "Resting in the wallet for now."
    }
}



/// one bar split by what the money went on, then the biggest few with their share; with each category's
/// drawing in place of its dot when `icons` is on
struct CategorySplit: View {
    @Environment(Store.self) private var store
    let parts: [(String, Double)]
    let total: Double
    var icons: Bool = false
    @State private var grown = false
    var body: some View {
        let shares: [(Color, Double)] = parts.map { (color($0.0), $0.1 / max(total, 1)) }
        let rows: [(String, Double)] = Array(parts.prefix(icons ? 5 : 4))
        VStack(alignment: .leading, spacing: 8) {
            SplitBar(parts: shares, grown: grown, height: 12)
            VStack(spacing: 0) {
                ForEach(Array(rows.enumerated()), id: \.offset) { i, p in
                    if i > 0 { RowRule(inset: icons ? 44 : 20) }
                    HStack(spacing: icons ? 12 : 10) {
                        if icons {
                            IconTile(symbol: symbol(p.0), color: color(p.0), size: 32)
                        } else {
                            Circle().fill(color(p.0)).frame(width: 10, height: 10)
                        }
                        Text(p.0).font(.system(.subheadline, weight: .semibold)).lineLimit(1)
                        Spacer(minLength: 8)
                        Text(Fmt.pct(p.1 / max(total, 1))).font(.system(.footnote, design: .rounded)).foregroundStyle(.secondary)
                            .monospacedDigit().frame(minWidth: 38, alignment: .trailing)
                        Text(Fmt.rupees(p.1)).font(.system(.subheadline, design: .rounded, weight: .semibold)).monospacedDigit()
                            .lineLimit(1).minimumScaleFactor(0.75)
                            .frame(minWidth: 64, alignment: .trailing).privacySensitive()
                    }
                    .frame(minHeight: icons ? 48 : 36)
                    .accessibilityElement(children: .combine)
                }
            }
        }
        .onAppear { withAnimation(Motion.reveal.delay(0.1)) { grown = true } }
    }
    func color(_ c: String) -> Color { c == "Other" ? Color(.systemGray3) : store.catColor(c) }
    func symbol(_ c: String) -> String { c == "Other" ? "square.grid.2x2" : store.symbol(c) }
}

// MARK: - Missing a card? kosh looks again

/// a bank, card or wallet you name, looked for again across the year's mail; what was found, in a line
struct LookAgainCard: View {
    @Environment(Store.self) private var store
    /// "card" or "wallet"
    var noun: String = "card"
    /// open with the keyboard up (the Add a wallet tile)
    var autofocus: Bool = false
    @State private var name = ""
    @State private var working = false
    @State private var result: String?
    @State private var foundAny = false
    @FocusState private var typing: Bool

    var body: some View {
        if let live = store.live, live.signedIn {
            let other: String? = live.lookingFor
            let busy: Bool = working || other != nil
            let typed: String = name.trimmingCharacters(in: .whitespacesAndNewlines)
            VStack(alignment: .leading, spacing: 14) {
                HStack(alignment: .top, spacing: 12) {
                    Image(systemName: noun == "wallet" ? "wallet.bifold" : "creditcard.and.123")
                        .font(.system(size: 16, weight: .semibold)).foregroundStyle(Color.kosh)
                        .frame(width: 38, height: 38)
                        .background(Color.kosh.opacity(0.14), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                    VStack(alignment: .leading, spacing: 2) {
                        Text(noun == "wallet" ? "Missing a wallet?" : "Missing a card?").font(.system(.subheadline, weight: .semibold))
                        Text(Self.blurb(noun)).font(.system(.footnote)).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                    }
                }
                .accessibilityElement(children: .combine)
                HStack(spacing: 8) {
                    TextField(noun == "wallet" ? "Like Paytm or MobiKwik" : "Bank or card, like Federal Bank", text: $name)
                        .textInputAutocapitalization(.words)
                        .autocorrectionDisabled()
                        .submitLabel(.search)
                        .focused($typing)
                        .onSubmit { go() }
                        .padding(.horizontal, 16)
                        .frame(height: 44)
                        .background(Color.raised, in: Capsule())
                        .disabled(busy)
                    Button { go() } label: {
                        Group {
                            if working { ProgressView().tint(Color.onKosh) } else { Text("Look again").fontWeight(.semibold) }
                        }
                        .frame(minWidth: 92, minHeight: 44)
                        .padding(.horizontal, 4)
                    }
                    .buttonStyle(.borderedProminent).koshFilled()
                    .buttonBorderShape(.capsule)
                    .disabled(typed.isEmpty || busy)
                }
                if working {
                    Text(Self.diggingLine(typed)).font(.system(.footnote)).foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                        .transition(.opacity)
                } else if let other {
                    Text("Already looking for " + other + ". One hunt at a time.").font(.system(.footnote)).foregroundStyle(.secondary)
                } else if let result {
                    VStack(alignment: .leading, spacing: 6) {
                        Label(result, systemImage: foundAny ? "checkmark.circle.fill" : "magnifyingglass")
                            .font(.system(.footnote, weight: .semibold))
                            .foregroundStyle(foundAny ? Color(light: "#1A7A43", dark: "#5FD38A") : Color.secondary)
                            .fixedSize(horizontal: false, vertical: true)
                        if !foundAny {
                            Button("Add another Gmail") { store.betaSheet = .accounts }
                                .font(.system(.footnote, weight: .semibold))
                        }
                    }
                    .transition(.opacity)
                }
            }
            .padding(16)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.surface, in: RoundedRectangle(cornerRadius: 26, style: .continuous))
            .animation(Motion.open, value: working)
            .animation(Motion.open, value: result)
            .onAppear { if autofocus { typing = true } }
        }
    }

    func go() {
        let n: String = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !n.isEmpty, !working, let live = store.live, live.lookingFor == nil else { return }
        typing = false
        working = true
        result = nil
        Task { @MainActor in
            let found: Int = await live.lookAgain(for: n)
            working = false
            foundAny = found > 0
            result = Self.resultLine(found, name: n)
        }
    }

    static func blurb(_ noun: String) -> String {
        if noun == "wallet" { return "kosh spots wallets from their payment and top-up mails. Name the app and it digs through your mail again." }
        return "kosh spots cards from their alerts and statements. Name the bank or card and it digs through your mail again."
    }
    static func diggingLine(_ name: String) -> String { "Digging through a year of mail for " + name + "… this can take a minute." }
    /// "Found 12 new emails from Federal Bank", or nothing new and where else it might be
    static func resultLine(_ n: Int, name: String) -> String {
        if n <= 0 { return "Nothing new from " + name + ". If its mail goes to another Gmail, add that inbox." }
        return "Found " + (n == 1 ? "1 new email" : String(n) + " new emails") + " from " + name + ". Anything in them is in now."
    }
}
