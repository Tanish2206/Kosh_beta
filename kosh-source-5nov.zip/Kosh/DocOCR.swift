import Foundation
import PDFKit
import Vision
import UIKit

// MARK: - A scanned statement, read off its pictures
//
// Some PDFs are photographs of paper (a deposit advice scanned at a branch, a policy schedule from an agent):
// they carry no text at all, so PDFKit reads nothing. Each page is drawn at twice its size and read with the
// phone's own text recogniser, on this phone, then laid out row by row from where each line sits, cells three
// or more spaces apart, which is what the readers in engine.js and docread.js expect from a typed PDF.
//
// The same reading also gives where each word sits (DocText's grid, so a scanned statement is read by its
// columns like a typed one), and Vision's document reader is asked for the page's tables: when it finds one,
// its rows and cells go along as a second grid, and the engine keeps whichever reading adds up.

enum DocOCR {
    struct Read { var rows: String; var grid: String; var pagesRead: Int; var pages: Int }

    /// the pages' text rebuilt into rows, and their grids; empty if nothing could be read. Pages are read until the
    /// time is up (a long scan isn't cut at a fixed page count; the note says how far it got)
    static func read(_ doc: PDFDocument, budget: TimeInterval = 60, maxPages: Int = 80, pages only: [Int]? = nil) async -> Read {
        var out: [String] = []
        var grid: [String] = ["grid1"], tables: [String] = ["grid1"]
        let start = Date()
        var done = 0
        for i in only ?? Array(0..<min(doc.pageCount, maxPages)) {
            if Date().timeIntervalSince(start) > budget { break }
            guard let page = doc.page(at: i), let image = render(page) else { done += 1; continue }
            let seen = recognise(image, page: i)
            out.append(contentsOf: seen.lines)
            grid.append(contentsOf: seen.grid)
            tables.append(contentsOf: await tableRows(image, page: i))
            done += 1
        }
        var g = grid.count > 1 ? grid.joined(separator: "\n") : ""
        if tables.count > 3 { g += (g.isEmpty ? "" : "\n") + tables.joined(separator: "\n") }
        return Read(rows: out.joined(separator: "\n"), grid: g, pagesRead: done, pages: doc.pageCount)
    }

    private static func render(_ page: PDFPage) -> CGImage? {
        let box = page.bounds(for: .mediaBox)
        guard box.width > 0, box.height > 0 else { return nil }
        // about 150 dpi on an A4 page, and never so big a page runs the phone out of memory
        let scale = min(2.0, 2400 / max(box.width, box.height))
        let size = CGSize(width: box.width * scale, height: box.height * scale)
        let fmt = UIGraphicsImageRendererFormat()
        fmt.scale = 1
        let img = UIGraphicsImageRenderer(size: size, format: fmt).image { ctx in
            UIColor.white.setFill()
            ctx.fill(CGRect(origin: .zero, size: size))
            ctx.cgContext.translateBy(x: 0, y: size.height)
            ctx.cgContext.scaleBy(x: scale, y: -scale)
            page.draw(with: .mediaBox, to: ctx.cgContext)
        }
        return img.cgImage
    }

    /// Vision's tables on one page, each row a grid line with a column to a step of 100 (as engine.js tableGrid)
    private static func tableRows(_ image: CGImage, page: Int) async -> [String] {
        let request = RecognizeDocumentsRequest()
        guard let found = try? await request.perform(on: image), let document = found.first?.document else { return [] }
        var lines: [String] = []
        var n = 0
        for table in document.tables where table.rows.count >= 3 {
            for row in table.rows {
                var parts: [String] = ["\(page),\(n * 10)"]
                for (k, cell) in row.enumerated() {
                    let t = cell.content.text.transcript.replacingOccurrences(of: "\t", with: " ")
                        .replacingOccurrences(of: "\n", with: " ").trimmingCharacters(in: .whitespaces)
                    if t.isEmpty { continue }
                    let x0 = k * 100 + 5
                    parts.append("\(x0),\(x0 + min(90, t.count * 5)),\(t)")
                }
                if parts.count > 1 { lines.append(parts.joined(separator: "\t")) }
                n += 1
            }
        }
        return lines
    }

    /// one page's lines: words whose middles sit at the same height join a line, left to right, with a wide gap
    /// between two of them marking a new cell; and the same words with where they sit, for the grid
    private static func recognise(_ image: CGImage, page: Int) -> (lines: [String], grid: [String]) {
        let req = VNRecognizeTextRequest()
        req.recognitionLevel = .accurate
        req.usesLanguageCorrection = false
        req.recognitionLanguages = ["en-IN", "en-US"]
        let handler = VNImageRequestHandler(cgImage: image, options: [:])
        guard (try? handler.perform([req])) != nil, let obs = req.results, !obs.isEmpty else { return ([], []) }
        struct Bit { let text: String; let box: CGRect; var words: [(box: CGRect, text: String)] }
        var bits: [Bit] = obs.compactMap { o in
            guard let c = o.topCandidates(1).first, !c.string.isEmpty else { return nil }
            // each word's own box, so a figure's column is where it really sits
            var words: [(box: CGRect, text: String)] = []
            let s = c.string
            var at = s.startIndex
            while at < s.endIndex {
                guard let r = s[at...].firstIndex(where: { !$0.isWhitespace }) else { break }
                let end = s[r...].firstIndex(where: { $0.isWhitespace }) ?? s.endIndex
                if let b = try? c.boundingBox(for: r..<end)?.boundingBox { words.append((b, String(s[r..<end]))) }
                at = end
            }
            if words.isEmpty { words = [(o.boundingBox, s)] }
            return Bit(text: s, box: o.boundingBox, words: words)
        }
        // Vision's boxes are 0...1 with y growing upwards: top of the page first
        bits.sort { $0.box.midY > $1.box.midY }
        var lines: [[Bit]] = []
        var lineY: CGFloat = .infinity, lineH: CGFloat = 0
        for b in bits {
            if !lines.isEmpty, abs(lineY - b.box.midY) <= max(0.004, min(lineH, b.box.height) * 0.5) {
                lines[lines.count - 1].append(b)
            } else {
                lines.append([b]); lineY = b.box.midY; lineH = b.box.height
            }
        }
        var text: [String] = [], grid: [String] = []
        for line in lines {
            let sorted = line.sorted { $0.box.minX < $1.box.minX }
            var t = ""
            var lastMax: CGFloat? = nil
            // a character's width, roughly, from the words on the line
            let charW: CGFloat = {
                let w = sorted.reduce(CGFloat(0)) { $0 + $1.box.width }, n = sorted.reduce(0) { $0 + max(1, $1.text.count) }
                return n > 0 ? w / CGFloat(n) : 0.01
            }()
            for b in sorted {
                if let m = lastMax { t += (b.box.minX - m) > charW * 2.5 ? "   " : " " }
                t += b.text
                lastMax = b.box.maxX
            }
            let s = t.trimmingCharacters(in: .whitespaces)
            if !s.isEmpty { text.append(s) }
            // the grid: thousandths of the page, y from the top
            let words = sorted.flatMap { $0.words }.sorted { $0.box.minX < $1.box.minX }
            guard !words.isEmpty else { continue }
            let mid = sorted.map { $0.box.midY }.reduce(0, +) / CGFloat(sorted.count)
            var parts: [String] = ["\(page),\(Int(((1 - mid) * 1000).rounded()))"]
            for w in words {
                let x0 = Int((w.box.minX * 1000).rounded()), x1 = Int((w.box.maxX * 1000).rounded())
                parts.append("\(x0),\(max(x1, x0 + 1)),\(w.text.replacingOccurrences(of: "\t", with: " "))")
            }
            grid.append(parts.joined(separator: "\t"))
        }
        return (text, grid)
    }
}
