import SwiftUI

// MARK: - Setup's one reading screen: who writes to you, what was found, and whose it is
//
// Setup used to wait on the last 30 days, then ask about the household, then show what was found, then the
// papers. Now reading starts the moment an inbox is connected, and this one screen fills in as it goes: within
// seconds the banks, cards, wallets, insurers and brokers that write to you (one small search each), then the
// accounts and cards their newest mail names, each with whose it is. The last week comes in behind it, the
// year's statements and the last three months after that, and the rest of the year while you use kosh. You can carry on as soon as the
// first look is done.

struct LiveFoundStep: View {
    @Environment(Store.self) private var store
    let next: () -> Void
    @State private var household = false

    var body: some View {
        let live = store.live!
        let looked = live.firstLook && !live.discovering
        let firstIn = live.phase == .done || live.phase == .idle || live.phase == .claude
        VStack(spacing: 0) {
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    StepTitle(sym: "sparkle.magnifyingglass",
                              title: looked ? (live.discovered.isEmpty ? "Reading your mail" : "Here’s who writes to you about money") : "Finding who writes to you about money",
                              text: looked ? "Say whose each account is. Everything else fills in behind you: the last week first, then the year’s statements and the last three months, then the rest of the year." : "One quick look per bank, card, wallet, insurer and broker. Read on this phone; nothing leaves it.")
                    Stages(live: live)
                    if !live.discovered.isEmpty { Senders(found: live.discovered) }
                    if live.phase == .failed {
                        BetaNote(text: (live.message ?? "The read stopped.") + " kosh carries on from where it got to.")
                        Button("Try again") { Task { await live.scan() } }.buttonStyle(.glass)
                    }
                    FoundList()
                    DisclosureGroup(isExpanded: $household) {
                        HouseholdEditor().padding(.top, 10)
                    } label: {
                        Label(live.people.count > 1 ? "The household · \(live.people.count) people" : "Someone else’s money too? Add them", systemImage: "person.2.fill")
                            .font(.headline)
                    }
                    .tint(Color.primary)
                }
                .padding(.horizontal, 24)
                .padding(.top, 60)
                .padding(.bottom, 20)
                .animation(Motion.open, value: live.discovered.count)
            }
            StepButton(title: looked || firstIn ? "Looks right" : "Finding…", enabled: looked || firstIn) {
                live.rebuild()
                next()
            }
            Text(firstIn ? "The year keeps filling in while you use kosh." : "You can carry on; the reading goes on behind.")
                .font(.footnote).foregroundStyle(.secondary).padding(.bottom, 8)
        }
        .sensoryFeedback(.impact(weight: .light), trigger: live.discovered.count)
        .sensoryFeedback(.success, trigger: looked)
    }

    /// where the reading is, in five lines
    struct Stages: View {
        let live: LiveSession
        var body: some View {
            let looked = live.firstLook && !live.discovering && live.discoverTotal > 0
            let weekIn = live.phase == .done || live.phase == .idle || live.phase == .claude
            VStack(alignment: .leading, spacing: 10) {
                SetupProgress.StageRow(title: "Who writes to you",
                                       detail: live.discovering ? "Checked \(live.discoverDone) of \(live.discoverTotal) senders" : live.discovered.isEmpty ? "Bank, card, wallet, insurer and broker mail" : "\(live.discovered.count) found",
                                       stage: live.discovering ? .active : looked || weekIn ? .done : .waiting)
                SetupProgress.StageRow(title: "The last week",
                                       detail: live.phase == .reading ? ReadingNow.pair(live.fetched, live.total) + " emails" : live.phase == .listing ? "Finding the money mail" : weekIn ? "\(live.ruleCount) read" : "Next",
                                       stage: weekIn ? .done : (live.phase == .reading || live.phase == .listing) && !live.discovering ? .active : .waiting)
                SetupProgress.StageRow(title: "The year’s statements",
                                       detail: live.readingDocs ? ReadingNow.pair(live.docDone, live.docTotal) + " opened" : live.findingDocs ? "Finding them" : live.docsRead > 0 ? "\(live.docsRead) opened" : "Balances, holdings, policies and every month’s lines",
                                       stage: live.findingDocs || live.readingDocs ? .active : live.docsRead > 0 ? .done : .waiting)
                SetupProgress.StageRow(title: "The last three months", detail: live.recentIn ? "In: Home stands on them" : live.backfilling ? "Newest first" : "Next",
                                       stage: live.recentIn ? .done : live.backfilling ? .active : .waiting)
                SetupProgress.StageRow(title: "The rest of the year", detail: live.yearIn ? "All twelve months are in" : live.backfilling && live.recentIn ? "In the background, a month at a time" : "While you use kosh",
                                       stage: live.yearIn ? .done : live.backfilling && live.recentIn ? .active : .waiting)
            }
        }
    }

    /// the senders found, as chips that drop in as they're found
    struct Senders: View {
        let found: [LiveSession.Found]
        var body: some View {
            VStack(alignment: .leading, spacing: 10) {
                Text("Writing to you").font(.headline)
                WrapRow(spacing: 8, lineSpacing: 8) {
                    ForEach(found) { f in
                        HStack(spacing: 6) {
                            InstIcon(name: f.short, color: Self.color(f.kind), size: 20, hint: f.name)
                            Text(f.short).font(.subheadline.weight(.medium))
                        }
                        .padding(.leading, 6).padding(.trailing, 10).padding(.vertical, 5)
                        .background(Color.surface, in: Capsule())
                        .transition(.scale(scale: 0.8).combined(with: .opacity))
                    }
                }
            }
        }
        static func color(_ kind: String) -> Color {
            switch kind {
            case "bank", "card": return Color.kosh
            case "insurer": return Color(hex: "#30B0C7")
            case "broker", "rta", "exchange", "pension": return Color(hex: "#34C759")
            case "wallet", "app", "voucher": return Color.orange
            case "lender": return Color(hex: "#FF3B30")
            default: return Color.secondary
            }
        }
    }
}

// MARK: - The end of setup: what kosh found, then the two asks it earns

/// Setup ends on value: what's due, what repeats, what was opened, what's waiting on you; then Face ID and
/// reminders, offered here because now they have something to protect and to remind you of. The figures fill in
/// as the reading carries on behind.
struct LiveDoneStep: View {
    @Environment(Store.self) private var store
    let finish: () -> Void
    @State private var lock: Bool = AppLock.shared.on
    @State private var remind: Bool = Reminders.on
    @State private var shown = false

    var body: some View {
        let s = store.snap
        let today: String = s.today
        let due: [AgendaItem] = s.agenda.filter { a in a.kind != "in" && !a.booked && (a.date.map { $0 >= today && $0 <= Day.add(today, 30) } ?? false) }
        let dueSum: Double = due.reduce(0) { $0 + $1.amt }
        let repeats: [Recurring] = s.recurring.filter { ($0.lapsed ?? "").isEmpty }
        let repeatSum: Double = repeats.reduce(0) { $0 + $1.monthly }
        let opened: Int = store.live?.docsRead ?? 0
        let locked: Int = store.live?.lockedDocs.count ?? 0
        let unnamed: Int = store.untagged.count
        let noticed: Int = (s.watch ?? []).count
        VStack(spacing: 0) {
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    StepTitle(sym: "sparkles", title: "Here’s what kosh found",
                              text: "From your mail so far. The rest of the year keeps filling in while you use kosh.")
                    FoundCards()
                    VStack(alignment: .leading, spacing: 0) {
                        if !due.isEmpty {
                            FoundLine(sym: "calendar.badge.clock", color: Color.orange, title: Fmt.rupees(dueSum) + " due in the next 30 days",
                                      text: due.count == 1 ? due[0].name : "\(due.count) bills, EMIs and dues, the first " + (due.first?.date.map { Day.short($0) } ?? ""))
                        }
                        if !repeats.isEmpty {
                            FoundLine(sym: "arrow.triangle.2.circlepath", color: Color(hex: "#5E5CE6"), title: "\(repeats.count) repeat\(repeats.count == 1 ? "" : "s"), " + Fmt.rupees(repeatSum) + " a month",
                                      text: "Subscriptions, SIPs, EMIs and bills that come back on their own")
                        }
                        if opened > 0 || locked > 0 {
                            FoundLine(sym: locked > 0 ? "lock.open.fill" : "doc.text.fill", color: Color.green,
                                      title: opened > 0 ? "\(opened) statement\(opened == 1 ? "" : "s") opened" : "Statements to open",
                                      text: locked > 0 ? "\(locked) still locked: kosh tries the details you save in Settings › Statements" : "Balances, holdings and policies read from them")
                        }
                        if unnamed > 0 {
                            FoundLine(sym: "questionmark.circle.fill", color: Color.orange, title: "\(unnamed) payment\(unnamed == 1 ? "" : "s") to name",
                                      text: "Name a payee once and all its payments follow. Home keeps the list.")
                        }
                        if noticed > 0 {
                            FoundLine(sym: "eye.fill", color: Color.kosh, title: "\(noticed) thing\(noticed == 1 ? "" : "s") worth a look", text: "On Home, most pressing first")
                        }
                    }
                    .card(16)
                    VStack(alignment: .leading, spacing: 14) {
                        if AppLock.available {
                            Toggle(isOn: $lock) {
                                VStack(alignment: .leading, spacing: 2) {
                                    Text("Lock kosh with " + AppLock.kind).font(.body.weight(.semibold))
                                    Text("Your money stays covered whenever kosh is out of sight.").font(.footnote).foregroundStyle(.secondary)
                                }
                            }
                            .onChange(of: lock) { _, v in AppLock.shared.on = v }
                        }
                        Toggle(isOn: $remind) {
                            VStack(alignment: .leading, spacing: 2) {
                                Text("Remind me before bills are due").font(.body.weight(.semibold))
                                Text(due.isEmpty ? "EMIs, card bills, premiums: the evening before and the morning of." : "Starting with the " + Fmt.rupees(dueSum) + " in the next 30 days.").font(.footnote).foregroundStyle(.secondary)
                            }
                        }
                        .onChange(of: remind) { _, v in
                            if v { Task { @MainActor in remind = await Reminders.enable(); if remind { Reminders.reschedule(store) } } } else { Reminders.disable() }
                        }
                    }
                    .tint(Color.kosh)
                    .card(16)
                }
                .padding(.horizontal, 24)
                .padding(.top, 72)
                .padding(.bottom, 20)
                .opacity(shown ? 1 : 0)
                .animation(Motion.reveal, value: shown)
            }
            StepButton(title: "Open kosh", action: finish)
        }
        .onAppear { shown = true }
    }

    struct FoundLine: View {
        let sym: String
        let color: Color
        let title: String
        let text: String
        var body: some View {
            HStack(alignment: .top, spacing: 12) {
                Image(systemName: sym)
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(color)
                    .frame(width: 32, height: 32)
                    .background(color.opacity(0.13), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
                VStack(alignment: .leading, spacing: 2) {
                    Text(title).font(.body.weight(.semibold)).privacySensitive()
                    Text(text).font(.footnote).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                }
                Spacer(minLength: 0)
            }
            .padding(.vertical, 8)
        }
    }
}

// MARK: - What was found, card by card: each counts up as it lands, and it ends on what the family is worth

struct FoundCards: View {
    @Environment(Store.self) private var store
    /// how many cards have landed (one after another, then the net worth)
    @State private var landed = 0

    struct Item: Identifiable {
        let id: String; let sym: String; let color: Color; let count: Int; let one: String; let many: String
        var logos: [String] = []
        var detail: String = ""
    }

    var body: some View {
        let s = store.snap
        let items: [Item] = Self.items(store)
        let worth: Double = store.netWorth(.family)
        VStack(spacing: 10) {
            LazyVGrid(columns: [GridItem(.flexible(), spacing: 10), GridItem(.flexible(), spacing: 10)], spacing: 10) {
                ForEach(Array(items.enumerated()), id: \.element.id) { i, it in
                    Card(item: it, on: landed > i)
                }
            }
            if worth > 0 {
                VStack(alignment: .leading, spacing: 4) {
                    Text(s.people.count > 1 ? "What the family is worth, so far" : "What you’re worth, so far").font(.subheadline).foregroundStyle(.secondary)
                    Text(Fmt.rupees(landed > items.count ? worth : 0))
                        .font(.system(.largeTitle, design: .rounded, weight: .bold))
                        .contentTransition(.numericText(value: landed > items.count ? worth : 0))
                        .privacySensitive()
                    Text("Bank balances, deposits, investments and property, less loans: from the mail and statements read so far.")
                        .font(.footnote).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(16)
                .background(Color.kosh.opacity(0.1), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
                .opacity(landed > items.count ? 1 : 0)
                .scaleEffect(landed > items.count ? 1 : 0.94)
            }
        }
        .task {
            // (one after another, a beat apart: each count runs up as its card lands)
            for i in 1...(items.count + 1) {
                try? await Task.sleep(for: .milliseconds(i == 1 ? 250 : 380))
                withAnimation(Motion.reveal) { landed = i }
            }
        }
        .sensoryFeedback(.impact(weight: .light), trigger: landed)
    }

    static func items(_ store: Store) -> [Item] {
        let s = store.snap
        func unique(_ xs: [String]) -> [String] { var seen = Set<String>(); return xs.filter { !$0.isEmpty && seen.insert($0).inserted } }
        let hold: [Holding] = store.holdings(.family)
        let pols: [Policy] = s.policies.filter { !$0.isEnded }
        let out: [Item] = [
            Item(id: "banks", sym: "building.columns.fill", color: Color.kosh, count: s.accounts.count + s.wallets.count, one: "account", many: "accounts",
                 logos: unique(s.accounts.map(\.bank) + s.wallets.map(\.bank))),
            Item(id: "cards", sym: "creditcard.fill", color: Color.sky, count: s.cards.count, one: "card", many: "cards", logos: unique(s.cards.map(\.bank))),
            Item(id: "policies", sym: "shield.lefthalf.filled", color: Color(hex: "#30B0C7"), count: pols.count, one: "insurance policy", many: "insurance policies",
                 logos: unique(pols.map(\.insurer))),
            Item(id: "invest", sym: "chart.line.uptrend.xyaxis", color: Color(hex: "#34C759"), count: hold.count, one: "deposit or investment", many: "deposits and investments",
                 detail: Fmt.words(hold.reduce(0) { $0 + $1.amt })),
            Item(id: "people", sym: "person.2.fill", color: Color.orange, count: s.people.count, one: "person", many: "people in the household",
                 detail: s.people.map(\.name).prefix(3).joined(separator: ", ")),
        ]
        return out.filter { $0.count > 0 }
    }

    struct Card: View {
        let item: Item
        let on: Bool
        var body: some View {
            VStack(alignment: .leading, spacing: 6) {
                HStack(spacing: 0) {
                    Image(systemName: item.sym).font(.title3).foregroundStyle(item.color)
                    Spacer(minLength: 4)
                    // the banks and insurers themselves, a few of their marks
                    HStack(spacing: -6) {
                        ForEach(item.logos.prefix(4), id: \.self) { n in
                            InstIcon(name: n, color: item.color, size: 22)
                        }
                    }
                }
                Text("\(on ? item.count : 0)")
                    .font(.system(.title, design: .rounded, weight: .bold))
                    .contentTransition(.numericText(value: Double(on ? item.count : 0)))
                Text(item.count == 1 ? item.one : item.many).font(.subheadline).foregroundStyle(.secondary).lineLimit(2)
                if !item.detail.isEmpty {
                    Text(item.detail).font(.footnote.weight(.medium)).foregroundStyle(.secondary).lineLimit(1).privacySensitive()
                }
            }
            .frame(maxWidth: .infinity, minHeight: 118, alignment: .topLeading)
            .padding(14)
            .background(Color.surface, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
            .opacity(on ? 1 : 0)
            .offset(y: on ? 0 : 14)
        }
    }
}
