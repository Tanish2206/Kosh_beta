import SwiftUI

// MARK: - Your payments, as a file
//
// A plain copy of your own payments over a stretch of days: a PDF (the same summary a travel claim's pack opens with,
// PackMaker.drawSummary) and a CSV every spreadsheet reads. kosh fills the days in from what it already knows — this
// month, the last three, or the financial year — so there is nothing to work out; the two date pickers are there for
// when you want other days. Both files are made on this phone and leave it only where you send them.

enum LedgerExport {
    /// the stretches kosh offers, each one it already knows
    enum Span: String, CaseIterable, Identifiable {
        case month, three, year, all
        var id: String { rawValue }
        var title: String {
            switch self {
            case .month: return "This month"
            case .three: return "Last 3 months"
            case .year: return "This year"
            case .all: return "Everything"
            }
        }
    }

    /// the first and last day of a stretch; `first` is the first day kosh has anything for
    static func days(_ s: Span, today: String, first: String) -> (from: String, to: String) {
        switch s {
        case .month: return (from: String(today.prefix(7)) + "-01", to: today)
        case .three: return (from: Day.addMonths(String(today.prefix(7)), -2) + "-01", to: today)
        case .year: return (from: fyStart(today), to: today)
        case .all: return (from: first.isEmpty ? fyStart(today) : first, to: today)
        }
    }

    /// the financial year this day sits in, as India counts it: 1 April to 31 March
    static func fyStart(_ today: String) -> String {
        let y: Int = Int(today.prefix(4)) ?? 0
        let m: Int = Int(today.dropFirst(5).prefix(2)) ?? 1
        return String(m >= 4 ? y : y - 1) + "-04-01"
    }

    static let header: [String] = ["Date", "In or out", "Paid to", "Category", "Sub-category", "Paid with", "How", "Amount", "Counts in spending", "Note"]

    /// one payment as a row of the sheet
    static func row(_ t: Txn) -> [String] {
        [t.od ?? t.d,
         t.k == "in" ? "In" : "Out",
         t.m,
         t.c,
         t.s,
         t.card,
         t.md ?? "",
         Fmt.trim(t.a, 2),
         CountSection.counted(t) ? "Yes" : "No",
         t.n]
    }

    /// one payment as a line of the PDF's summary
    static func lines(_ rows: [Txn]) -> [PackMaker.SummaryLine] {
        rows.enumerated().map { i, t in
            var bits: [String] = []
            if !t.c.isEmpty { bits.append(t.c) }
            if !t.s.isEmpty { bits.append(t.s) }
            if !t.card.isEmpty { bits.append(t.card) }
            if !t.n.isEmpty { bits.append(t.n) }
            return PackMaker.SummaryLine(no: i + 1, date: Day.fmt(t.od ?? t.d, "d MMM yyyy"), kind: t.k == "in" ? "In" : "Out",
                                         merchant: t.m, details: bits.joined(separator: " · "), amount: t.a)
        }
    }

    /// the two files, written to kosh's own temporary folder (Erase clears it). nil if the phone wouldn't write them.
    @MainActor
    static func make(rows: [Txn], from: String, to: String, name: String) -> (pdf: URL, csv: URL)? {
        let sorted: [Txn] = rows.sorted { ($0.od ?? $0.d) == ($1.od ?? $1.d) ? $0.m < $1.m : ($0.od ?? $0.d) < ($1.od ?? $1.d) }
        guard !sorted.isEmpty else { return nil }
        let out: [PackMaker.SummaryLine] = lines(sorted)
        let total: Double = sorted.reduce(0) { $0 + $1.a }
        let none: [Int?] = Array(repeating: nil, count: out.count)
        let pages: Int = PackMaker.layout(out).pages
        let pdf: Data = PackMaker.drawSummary(title: "Your payments", period: DraftWords.span(from, to), name: name, lines: out,
                                              pageOf: none, total: total, totalPages: pages, noProof: [])
        let csv: Data = CSV.make(header: header, rows: sorted.map(row))
        let folder: URL = FileManager.default.temporaryDirectory
            .appendingPathComponent("kosh-exports", isDirectory: true)
            .appendingPathComponent(UUID().uuidString, isDirectory: true)
        try? FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        let base: String = PackMaker.fileName("kosh payments " + from + " to " + to)
        let pdfURL: URL = folder.appendingPathComponent(base + ".pdf")
        let csvURL: URL = folder.appendingPathComponent(base + ".csv")
        guard (try? pdf.write(to: pdfURL, options: [.atomic, .completeFileProtection])) != nil,
              (try? csv.write(to: csvURL, options: [.atomic, .completeFileProtection])) != nil else { return nil }
        return (pdf: pdfURL, csv: csvURL)
    }
}

/// Your payments, as a file: the days already filled in, what goes in it, and the two files to send
struct LedgerExportView: View {
    @Environment(Store.self) private var store
    @State private var span: LedgerExport.Span = .year
    @State private var from: String = ""
    @State private var to: String = ""
    /// money that came in, as well as what went out
    @State private var alsoIn = false
    @State private var pdf: URL? = nil
    @State private var csv: URL? = nil
    @State private var ready = false

    /// the payments in those days, the way they happened
    var rows: [Txn] {
        store.tx.filter { t in
            let day: String = t.od ?? t.d
            guard day >= from && day <= to else { return false }
            return alsoIn || t.k != "in"
        }
    }

    var body: some View {
        let list: [Txn] = rows
        let out: Double = list.reduce(0) { $0 + ($1.k == "in" ? 0 : $1.a) }
        let into: Double = list.reduce(0) { $0 + ($1.k == "in" ? $1.a : 0) }
        List {
            Section {
                ScrollView(.horizontal) {
                    HStack(spacing: 6) {
                        ForEach(LedgerExport.Span.allCases) { s in
                            spanChip(s)
                        }
                    }
                    .padding(.vertical, 2)
                }
                .scrollIndicators(.hidden)
                .listRowInsets(EdgeInsets(top: 6, leading: 16, bottom: 6, trailing: 16))
                DatePicker("From", selection: day($from), displayedComponents: .date)
                DatePicker("To", selection: day($to), displayedComponents: .date)
                Toggle("Money that came in too", isOn: $alsoIn)
            } header: {
                Text("Which days")
            } footer: {
                Text("kosh has filled the days in. Change them if you want others.")
            }
            Section {
                figure("Payments", Fmt.inr(Double(list.count)))
                figure("Out", Fmt.rupees(out))
                if alsoIn { figure("In", Fmt.rupees(into)) }
            } header: {
                Text("What goes in it")
            }
            Section {
                Button {
                    make(list)
                } label: {
                    Label(pdf == nil ? "Make the files" : "Make them again", systemImage: "doc.badge.gearshape")
                        .fontWeight(.semibold)
                }
                .disabled(list.isEmpty)
                if let pdf {
                    ShareLink(item: pdf) { Label("Send the PDF", systemImage: "doc.richtext") }
                }
                if let csv {
                    ShareLink(item: csv) { Label("Send the CSV", systemImage: "tablecells") }
                }
            } footer: {
                Text(list.isEmpty
                     ? "No payments in those days yet."
                     : "The PDF is a table of every payment, the CSV the same rows for a spreadsheet. Both are made on this phone and go only where you send them.")
            }
        }
        .navigationTitle("Your payments, as a file")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear(perform: start)
        .onChange(of: alsoIn) { _, _ in pdf = nil; csv = nil }
    }

    func spanChip(_ s: LedgerExport.Span) -> some View {
        let on: Bool = span == s
        return Button {
            withAnimation(Motion.base) { pick(s) }
        } label: {
            Text(s.title)
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(on ? Color.primary : Color.secondary)
                .padding(.horizontal, 13)
                .frame(height: 34)
                .background(on ? Color.primary.opacity(0.14) : Color.clear, in: Capsule())
                .overlay(Capsule().strokeBorder(Color.primary.opacity(on ? 0.35 : 0.14), lineWidth: 1))
                .contentShape(Capsule())
        }
        .buttonStyle(.press)
        .accessibilityAddTraits(on ? .isSelected : [])
    }

    func figure(_ title: String, _ value: String) -> some View {
        HStack {
            Text(title)
            Spacer()
            Text(value).fontWeight(.semibold).monospacedDigit().privacySensitive()
        }
    }

    /// a day as the picker wants it, and back as kosh keeps it
    func day(_ text: Binding<String>) -> Binding<Date> {
        Binding(get: { Day.date(text.wrappedValue) }, set: { d in
            text.wrappedValue = Day.iso(d)
            pdf = nil; csv = nil
        })
    }

    func start() {
        guard !ready else { return }
        ready = true
        pick(.year)
    }

    func pick(_ s: LedgerExport.Span) {
        span = s
        let first: String = store.tx.map { $0.od ?? $0.d }.min() ?? ""
        let d: (from: String, to: String) = LedgerExport.days(s, today: store.snap.today, first: first)
        from = d.from
        to = d.to
        pdf = nil; csv = nil
    }

    func make(_ list: [Txn]) {
        let me: String = store.snap.people.first { $0.id == "me" }?.full ?? ""
        guard let files = LedgerExport.make(rows: list, from: from, to: to, name: me) else { return }
        pdf = files.pdf
        csv = files.csv
    }
}
