import SwiftUI
import AuthenticationServices

// MARK: - Connect an inbox: Gmail, Outlook, Yahoo, iCloud, AOL, Zoho, Rediffmail or any other mail
//
// One list for every way in. Gmail and Outlook sign in with their own pages (no password reaches kosh). The mail
// servers (Yahoo, iCloud, AOL, Zoho, a work address) take an app password made for kosh, which stays in this
// iPhone's Keychain; kosh tries it before saving anything. Every inbox is read-only.

struct ConnectInboxSheet: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    @Environment(\.webAuthenticationSession) private var webAuth
    /// whose inbox this is (nil: yours)
    var person: String? = nil
    var onDone: () -> Void = {}
    @State private var busy: String? = nil
    @State private var error: String?

    var body: some View {
        let live = store.live!
        NavigationStack {
            List {
                Section {
                    ForEach(MailProviderInfo.all) { p in
                        row(p, live: live)
                    }
                } header: {
                    Text(live.signedIn ? "Add an inbox" : "Where does your bank mail land?")
                } footer: {
                    Text("kosh only reads. It never sends, moves or deletes mail, and nothing it reads is marked as read.")
                }
                if let error {
                    Section { Text(error).font(.footnote).foregroundStyle(Color.red).fixedSize(horizontal: false, vertical: true) }
                }
            }
            .navigationTitle(title(live))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } } }
        }
    }

    func title(_ live: LiveSession) -> String {
        if let person, person != "me", let p = live.people.first(where: { $0.id == person }) { return "\(p.name)’s inbox" }
        return live.signedIn ? "Add an inbox" : "Connect your email"
    }

    @ViewBuilder
    func row(_ p: MailProviderInfo, live: LiveSession) -> some View {
        if p.kind == "imap" {
            NavigationLink {
                IMAPConnectView(provider: p, person: person) { finished() }
            } label: {
                ProviderRow(p: p, busy: false)
            }
            .disabled(busy != nil)
        } else if p.kind == "microsoft" && live.msClientID.isEmpty {
            NavigationLink {
                MicrosoftSetupView { Task { await signIn(MailProviderInfo.of("microsoft") ?? p) } }
            } label: {
                ProviderRow(p: p, busy: false)
            }
        } else {
            Button {
                Task { await signIn(p) }
            } label: {
                ProviderRow(p: p, busy: busy == p.id)
            }
            .buttonStyle(.press)
            .disabled(busy != nil || (p.kind == "google" && live.clientID.isEmpty))
        }
    }

    func finished() {
        onDone()
        dismiss()
    }

    /// Google's or Microsoft's own sign-in page, then back into kosh
    @MainActor
    func signIn(_ p: MailProviderInfo) async {
        guard let live = store.live else { return }
        busy = p.id
        error = nil
        defer { busy = nil }
        do {
            if p.kind == "microsoft" {
                let req = try live.microsoftRequest()
                let cb = try await webAuth.authenticate(using: req.url, callbackURLScheme: req.scheme)
                try await live.finishMicrosoft(cb, for: person)
            } else if live.signedIn {
                live.beginAddAccount(for: person)
                let req = try live.signInRequest()
                let cb = try await webAuth.authenticate(using: req.url, callbackURLScheme: req.scheme)
                try await live.finishAddAccount(cb)
            } else {
                let req = try live.signInRequest()
                let cb = try await webAuth.authenticate(using: req.url, callbackURLScheme: req.scheme)
                try await live.finishSignIn(cb)
            }
            store.refreshPeople()
            finished()
        } catch {
            live.cancelAddAccount()
            let ns = error as NSError
            if ns.domain == ASWebAuthenticationSessionErrorDomain && ns.code == ASWebAuthenticationSessionError.canceledLogin.rawValue {
                if p.kind == "google" { self.error = "Not connected. If Google said “Access blocked”, that address isn’t on the beta’s test-user list yet." }
                return
            }
            self.error = error.localizedDescription
        }
    }
}

/// a provider in the list: its initial on its colour, its name, and the addresses it covers
struct ProviderRow: View {
    let p: MailProviderInfo
    let busy: Bool
    var body: some View {
        HStack(spacing: 12) {
            Text(String(p.name.prefix(1)))
                .font(.system(size: 15, weight: .bold, design: .rounded))
                .foregroundStyle(.white)
                .frame(width: 32, height: 32)
                .background(Color(hex: p.color).gradient, in: RoundedRectangle(cornerRadius: 9, style: .continuous))
            VStack(alignment: .leading, spacing: 1) {
                Text(p.name).font(.body.weight(.semibold)).foregroundStyle(Color.primary)
                Text(p.sub).font(.caption).foregroundStyle(.secondary).lineLimit(1)
            }
            Spacer(minLength: 4)
            if busy { ProgressView() }
        }
        .padding(.vertical, 3)
        .contentShape(Rectangle())
        .accessibilityElement(children: .combine)
    }
}

/// a mail server inbox: the address, the app password (with the provider's own steps to make one) and, for any other
/// email, the server; kosh signs in once to check before it saves anything
struct IMAPConnectView: View {
    @Environment(Store.self) private var store
    @Environment(\.openURL) private var openURL
    let provider: MailProviderInfo
    var person: String? = nil
    let done: () -> Void
    @State private var address = ""
    @State private var password = ""
    @State private var host = ""
    @State private var port = "993"
    @State private var busy = false
    @State private var error: String?
    @State private var showServer = false
    @FocusState private var focus: Field?
    enum Field { case address, password }

    var body: some View {
        let app: Bool = provider.password == "app"
        Form {
            Section {
                TextField("you@" + (provider.domains.first ?? "example.com"), text: $address)
                    .keyboardType(.emailAddress)
                    .textContentType(.emailAddress)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .focused($focus, equals: .address)
                    .submitLabel(.next)
                    .onSubmit { focus = .password }
            } header: {
                Text("Your address")
            }
            if let steps = provider.steps, !steps.isEmpty {
                Section {
                    ForEach(Array(steps.enumerated()), id: \.offset) { i, s in
                        HStack(alignment: .firstTextBaseline, spacing: 10) {
                            Text("\(i + 1)").font(.subheadline.weight(.bold)).monospacedDigit().foregroundStyle(Color(hex: provider.color))
                            Text(s).font(.subheadline).fixedSize(horizontal: false, vertical: true)
                        }
                    }
                    if let u = provider.passwordURL, let url = URL(string: u) {
                        Button { openURL(url) } label: { Label("Open \(provider.name)", systemImage: "arrow.up.right.square") }
                    }
                } header: {
                    Text(app ? "Make an app password, once" : "Password")
                }
            }
            Section {
                SecureField(app ? "App password" : "Password", text: $password)
                    .textContentType(.password)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .focused($focus, equals: .password)
                    .submitLabel(.go)
                    .onSubmit { Task { await connect() } }
            } footer: {
                Text(app ? "An app password only lets kosh read mail. It stays in this iPhone’s Keychain; delete it at \(provider.name) any time to cut kosh off."
                         : "It stays in this iPhone’s Keychain and is used only to read.")
            }
            if provider.id == "imap" || showServer {
                Section {
                    TextField("imap.example.com", text: $host)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .keyboardType(.URL)
                    TextField("993", text: $port).keyboardType(.numberPad)
                } header: {
                    Text("Mail server")
                } footer: {
                    Text("Leave it empty and kosh looks it up. It works over an encrypted connection only (usually port 993).")
                }
            }
            Section {
                Button {
                    Task { await connect() }
                } label: {
                    HStack(spacing: 8) {
                        if busy { ProgressView() }
                        Text(busy ? "Checking with \(provider.name)…" : "Connect").font(.body.weight(.semibold))
                    }
                    .frame(maxWidth: .infinity)
                }
                .disabled(busy || !address.contains("@") || password.isEmpty)
                if let error {
                    Text(error).font(.footnote).foregroundStyle(Color.red).fixedSize(horizontal: false, vertical: true)
                }
            }
        }
        .navigationTitle(provider.name)
        .navigationBarTitleDisplayMode(.inline)
        .onAppear { if address.isEmpty { focus = .address } }
    }

    @MainActor
    func connect() async {
        guard let live = store.live, !busy else { return }
        let addr = address.trimmingCharacters(in: .whitespacesAndNewlines)
        // Gmail and Outlook addresses sign in with their own pages, no password
        let other = (try? Engine.shared.call("providerFor", [addr])) ?? ""
        if provider.id == "imap" && (other == "gmail" || other == "microsoft") {
            error = "For \(addr), go back and choose \(other == "gmail" ? "Gmail" : "Outlook"): it signs in without a password."
            return
        }
        busy = true
        error = nil
        defer { busy = false }
        do {
            try await live.connectIMAP(email: addr, password: password, provider: provider.id,
                                       host: host.isEmpty ? nil : host, port: Int(port), for: person)
            password = ""
            store.refreshPeople()
            done()
        } catch {
            self.error = error.localizedDescription
            if let m = error as? MailError, case .noServer = m { showServer = true }
        }
    }
}

/// Outlook sign-in needs kosh's app id with Microsoft, once (beta): paste it here
struct MicrosoftSetupView: View {
    @Environment(Store.self) private var store
    let then: () -> Void
    @State private var id = ""
    var body: some View {
        Form {
            Section {
                TextField("00000000-0000-0000-0000-000000000000", text: $id)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .font(.footnote.monospaced())
                Button("Save and sign in") {
                    store.live?.setMSClientID(id)
                    then()
                }
                .disabled(UUID(uuidString: id.trimmingCharacters(in: .whitespaces)) == nil)
            } header: {
                Text("Microsoft app ID")
            } footer: {
                Text("The beta signs in to Outlook with kosh’s own app in Microsoft Entra (its Application ID). It’s set once, then Outlook, Hotmail and Microsoft 365 inboxes connect with Microsoft’s sign-in page.")
            }
        }
        .navigationTitle("Outlook")
        .navigationBarTitleDisplayMode(.inline)
    }
}

/// "Not on Gmail?": the other ways in, as a quiet button under Connect Gmail
struct OtherEmailButton: View {
    var person: String? = nil
    var title = "Outlook, Yahoo, iCloud or other email"
    var onDone: () -> Void = {}
    @State private var showing = false
    var body: some View {
        Button { showing = true } label: {
            Label(title, systemImage: "envelope.badge")
                .font(.subheadline.weight(.semibold))
                .frame(maxWidth: .infinity)
        }
        .buttonStyle(.press)
        .foregroundStyle(Color.kosh)
        .sheet(isPresented: $showing) {
            ConnectInboxSheet(person: person, onDone: onDone).presentationDetents([.large])
        }
    }
}
