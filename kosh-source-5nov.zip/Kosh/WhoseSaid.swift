import Foundation

// MARK: - What was said about whose a property or committee is
//
// Screen-free, so swiftc can test it without Xcode (engine-test/whose-said.js). The engine reads the same list the
// same way (engine/21e whoseSaid): only people still in the household count, "family" is the household's on purpose,
// and a list naming no one left means kosh works it out again from the record and the payments.

enum WhoseSaid {
    /// the list with one person taken off (they left the household): nil when no one is left, so kosh works it out
    /// again; never moved to "you" by default, since whose a property is goes by its record, not by who is left
    static func without(_ list: [String]?, _ id: String) -> [String]? {
        guard let list else { return nil }
        let left: [String] = list.filter { $0 != id }
        return left.isEmpty ? nil : left
    }
    /// nothing said that still names someone in the household: "Let kosh work it out" is what stands
    static func isOpen(_ list: [String]?, people: [String]) -> Bool {
        guard let list else { return true }
        return !list.contains("family") && !list.contains { people.contains($0) }
    }
}
