import UIKit

// MARK: - Your hands first
//
// While you touch the screen (a tap, a scroll, switching tabs, and the second or so a scroll keeps gliding after),
// kosh's own work waits: the re-reading and reading of mail hold between emails, and a build of the screens waits for
// a pause. It all carries on the moment you stop, so a long read never makes the app feel heavy in your hands.

final class Interaction: @unchecked Sendable {
    static let shared = Interaction()
    /// when a finger last touched the screen (or lifted off it)
    private(set) var lastTouch: CFAbsoluteTime = 0

    /// someone is using the screen now, or was a moment ago (a flick keeps scrolling about a second after the finger lifts)
    var busy: Bool { CFAbsoluteTimeGetCurrent() - lastTouch < 1.2 }

    func touched() { lastTouch = CFAbsoluteTimeGetCurrent() }

    /// wait while someone is using the screen (at most `upTo` seconds), between pieces of background work
    static func yield(upTo: Double = 6) async {
        let until = CFAbsoluteTimeGetCurrent() + upTo
        while shared.busy && CFAbsoluteTimeGetCurrent() < until {
            try? await Task.sleep(for: .milliseconds(150))
        }
    }

    /// (smooth-5nov-c) run on the main thread once nobody is using the screen, waiting at most `upTo` seconds: a build
    /// landing swaps every screen's data, and under a moving finger (or a flick still coasting) that re-laid out the
    /// list mid-scroll
    static func whenStill(upTo: Double, _ work: @escaping @MainActor () -> Void) {
        let until: CFAbsoluteTime = CFAbsoluteTimeGetCurrent() + upTo
        func check() {
            if shared.busy && CFAbsoluteTimeGetCurrent() < until {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) { check() }
            } else {
                MainActor.assumeIsolated { work() }
            }
        }
        DispatchQueue.main.async { check() }
    }

    /// watch every window kosh has: one recognizer each that sees every touch and takes none
    @MainActor static func install() {
        for scene in UIApplication.shared.connectedScenes {
            guard let ws = scene as? UIWindowScene else { continue }
            for w in ws.windows where !(w.gestureRecognizers ?? []).contains(where: { $0 is TouchWatcher }) {
                let g = TouchWatcher(target: nil, action: nil)
                g.cancelsTouchesInView = false
                g.delaysTouchesBegan = false
                g.delaysTouchesEnded = false
                g.delegate = TouchWatcher.alongside
                w.addGestureRecognizer(g)
            }
        }
    }
}

/// sees touches, never claims them
final class TouchWatcher: UIGestureRecognizer {
    /// lets it run beside every other gesture
    final class Alongside: NSObject, UIGestureRecognizerDelegate {
        func gestureRecognizer(_ g: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith other: UIGestureRecognizer) -> Bool { true }
    }
    @MainActor static let alongside = Alongside()

    // (it stays "possible" while the finger moves, so it hears the whole gesture; it fails as the finger lifts)
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent) { Interaction.shared.touched() }
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent) { Interaction.shared.touched() }
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent) { Interaction.shared.touched(); state = .failed }
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent) { Interaction.shared.touched(); state = .failed }
}
