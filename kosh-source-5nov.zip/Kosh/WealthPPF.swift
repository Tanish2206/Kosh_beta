import SwiftUI

// MARK: - one PPF account (ppf-owner-4nov)
//
// A PPF is one person's, never joint, and kosh used to count every PPF statement in your inbox as yours: your
// parents' statements come to you too. Each account is now its own card and its own page: whose it is and why kosh
// thinks so, its balance and the paper it came from, this year against its own ₹1.5L, and what you can tell kosh
// (whose it is, that it's closed or paid out, that it isn't a PPF, that it's the same as another). What you say goes
// to the engine (prof.owners by "ppf|<key>", acctFix.ppf), so the rule stands for every rebuild, not just this screen.

enum PPFWords {
    /// "PPF SBI ••9014", "IndusInd PPF ••4321" → "SBI PPF ••9014"
    static func title(_ bank: String) -> String {
        let no: String = bank.range(of: #"••\s*\d{4}"#, options: .regularExpression).map { String(bank[$0]) } ?? ""
        let inst: String = bank.replacingOccurrences(of: #"\bPPF\b"#, with: " ", options: .regularExpression)
            .replacingOccurrences(of: #"••\s*\d+"#, with: " ", options: .regularExpression)
            .trimmingCharacters(in: .whitespaces)
        return [inst, "PPF", no].filter { !$0.isEmpty }.joined(separator: " ")
    }
    /// the name its paper printed, in a person's case ("SANJIV BHUTANI" → "Sanjiv Bhutani")
    static func holder(_ h: String?) -> String? {
        guard let h, !h.trimmingCharacters(in: .whitespaces).isEmpty else { return nil }
        return h.lowercased().split(separator: " ").map { $0.prefix(1).uppercased() + $0.dropFirst() }.joined(separator: " ")
    }
    /// whose, in words: a person of the household by their name; someone not in it by the name the paper printed
    static func owner(_ id: String, holder h: String?, _ store: Store) -> String {
        if id.hasPrefix("n:") { return holder(h) ?? holder(String(id.dropFirst(2))) ?? "Someone else" }
        return store.ownerName(id)
    }
    static func why(_ w: String) -> String {
        switch w {
        case "you": return "You said so"
        case "named": return "The name on its statement"
        case "added": return "You added it"
        default: return "It came to your inbox: check it"
        }
    }
    static func shutWords(_ s: RetirementBook.PPF.Shut) -> String {
        switch s.by {
        case "you": return "Closed or paid out, as you said"
        case "mail": return s.on.map { "Closed, its bank wrote on " + Day.fmt($0, "d MMM yyyy") } ?? "Closed, its bank wrote"
        default: return "Closed, its statement says"
        }
    }
    static func rowLine(_ r: RetirementBook.PPF.Row, _ store: Store) -> String {
        var bits: [String] = [owner(r.owner, holder: r.holder, store)]
        if let d = r.asOf { bits.append("statement to " + Day.fmt(d, "d MMM yyyy")) }
        return bits.joined(separator: " · ")
    }
}

struct PPFAccountPage: View {
    @Environment(Store.self) private var store
    let id: String
    @State private var ask: Ask?
    @State private var pickSame = false

    enum Ask: String, Identifiable { case closed, notPPF; var id: String { rawValue } }

    var body: some View {
        let book: RetirementBook.PPF? = store.snap.retirement?.ppf
        let row: RetirementBook.PPF.Row? = book?.rows?.first { $0.id == id }
        let shut: RetirementBook.PPF.Shut? = book?.closed?.first { $0.id == id }
        Group {
            if let r = row {
                ObsidianList {
                    head(title: r.bank, owner: r.owner, holder: r.holder, amt: r.amt, chip: "Active")
                    PPFWhoseRow(key: id, owner: r.owner, holder: r.holder, why: r.why)
                    figures(r)
                    if store.live != nil { saying(open: true) }
                }
                .navigationTitle(PPFWords.title(r.bank))
            } else if let s = shut {
                ObsidianList {
                    head(title: s.bank, owner: s.owner, holder: s.holder, amt: s.amt, chip: "Closed")
                    Section {
                        Text(PPFWords.shutWords(s) + ". It’s in no total: its money is counted where it went, in the account it was paid into.")
                            .fixedSize(horizontal: false, vertical: true)
                        if let d = s.asOf { LabeledContent("Its last balance", value: Day.fmt(d, "d MMM yyyy")) }
                    } header: { Text("Where it stands") }
                    if store.live != nil { saying(open: false) }
                }
                .navigationTitle(PPFWords.title(s.bank))
            } else {
                ContentUnavailableView("This PPF isn’t counted any more", systemImage: "lock.shield",
                                       description: Text("You said it isn’t a PPF, or it’s the same as another. Bring it back from Retirement › Every job, year by year."))
            }
        }
        .navigationBarTitleDisplayMode(.inline)
        .obsidianPage()
        .confirmationDialog(ask == .closed ? "Closed or paid out?" : "Not a PPF?", isPresented: Binding(get: { ask != nil }, set: { if !$0 { ask = nil } }), titleVisibility: .visible) {
            if ask == .closed {
                Button("It’s closed or paid out") { store.live?.setPPF(id, "closed") }
            } else {
                Button("It isn’t a PPF", role: .destructive) { store.live?.setPPF(id, "notppf") }
            }
            Button("Cancel", role: .cancel) {}
        } message: {
            Text(ask == .closed
                 ? "kosh takes it out of every total and keeps it as history. Money paid out to a nominee is counted in the account it was paid into."
                 : "kosh leaves it out of retirement and net worth. You can bring it back from Retirement › Every job, year by year.")
        }
        .sheet(isPresented: $pickSame) {
            PPFSamePicker(key: id).obsidianSheet().environment(store)
        }
    }

    @ViewBuilder func head(title: String, owner: String, holder: String?, amt: Double, chip: String) -> some View {
        Section {
            VStack(spacing: 8) {
                Text("PPF")
                    .font(.system(size: 15, weight: .heavy))
                    .foregroundStyle(Obsidian.property)
                    .frame(width: 56, height: 56)
                    .background(RoundedRectangle(cornerRadius: 16, style: .continuous).fill(Obsidian.property.opacity(0.12)))
                Text(PPFWords.title(title)).font(.title3.weight(.semibold)).multilineTextAlignment(.center)
                Text(PPFWords.owner(owner, holder: holder, store)).font(.subheadline).foregroundStyle(.secondary)
                if amt > 0 {
                    Text(Fmt.words(amt))
                        .font(.largeTitle.weight(.bold)).fontDesign(.rounded).monospacedDigit()
                        .minimumScaleFactor(0.6).lineLimit(1)
                        .privacySensitive()
                }
                Chip(text: chip, color: chip == "Closed" ? Color.gray : Obsidian.property)
            }
            .frame(maxWidth: .infinity)
            .listRowBackground(Color.clear)
        }
    }

    @ViewBuilder func figures(_ r: RetirementBook.PPF.Row) -> some View {
        Section {
            LabeledContent("Balance") { Text(Fmt.words(r.amt)).monospacedDigit().privacySensitive() }
            if let d = r.asOf { LabeledContent("As of", value: Day.fmt(d, "d MMM yyyy")) }
            LabeledContent("Read from", value: Self.source(r.via))
            if let x = r.rate, x > 0 { LabeledContent("Rate", value: Fmt.trim(x, 2) + "% a year") }
            if let m = r.mat, m.count >= 7 { LabeledContent("Matures", value: Day.fmt(String(m.prefix(7)) + "-01", "MMM yyyy")) }
        } header: {
            Text("Its figures")
        } footer: {
            Text("A PPF statement comes once a year, after March’s interest is credited, so its balance is usually months old.")
        }
        Section {
            VStack(alignment: .leading, spacing: 6) {
                HStack(alignment: .firstTextBaseline) {
                    Text(RetWords.fy(store.snap.retirement?.ppf?.year.fy ?? "") + ", so far").font(.subheadline.weight(.medium))
                    Spacer()
                    Text(Fmt.rupees(r.year.paid) + " of " + Fmt.rupees(r.year.cap)).font(.subheadline).monospacedDigit().privacySensitive()
                }
                ProgressView(value: min(1, r.year.paid / max(1, r.year.cap))).tint(r.year.over ? Color.orange : Obsidian.property)
                Text(r.year.over ? "Over the ₹1.5L a year one person may put in. The excess earns no interest." : Fmt.rupees(r.year.left) + " more may go in this financial year.")
                    .font(.caption).foregroundStyle(r.year.over ? Color.orange : Color.secondary)
            }
            .padding(.vertical, 2)
            if let ids = r.pays, !ids.isEmpty {
                Button { store.push(.payments("PPF payments", "This financial year", ids)) } label: {
                    LabeledContent(ids.count == 1 ? "One payment" : "\(ids.count) payments", value: "See them")
                }
            }
        } header: {
            Text("This year")
        } footer: {
            Text("From the payments kosh has filed under PPF for this person. With more than one PPF in one name, their payments aren’t placed in either.")
        }
    }

    static func source(_ via: String?) -> String {
        switch via ?? "" {
        case "ppf": return "Its bank’s mail"
        case "cas": return "A statement"
        case "manual": return "You added it"
        default: return "A statement"
        }
    }

    @ViewBuilder func saying(open: Bool) -> some View {
        Section {
            if open {
                Button { ask = .closed } label: { Label("It’s closed or paid out", systemImage: "checkmark.seal") }
                Button { pickSame = true } label: { Label("It’s the same as another PPF", systemImage: "square.on.square") }
                Button(role: .destructive) { ask = .notPPF } label: { Label("It isn’t a PPF", systemImage: "xmark.circle") }
            } else if store.live?.acctFix.ppf?[id] == "closed" {
                Button { store.live?.setPPF(id, nil) } label: { Label("It’s still open", systemImage: "arrow.uturn.backward") }
            }
        } header: { Text("Tell kosh") }
    }
}

/// whose a PPF is: a person of the household, or the holder its paper names; never joint
struct PPFWhoseRow: View {
    @Environment(Store.self) private var store
    let key: String
    let owner: String
    let holder: String?
    let why: String
    var body: some View {
        Section {
            Menu {
                ForEach(store.snap.people) { (p: PersonInfo) in
                    Button { store.live?.setOwner("ppf|" + key, p.id) } label: {
                        let name: String = p.id == "me" ? "You" : p.full
                        if owner == p.id { Label(name, systemImage: "checkmark") } else { Text(name) }
                    }
                }
                if owner.hasPrefix("n:") || store.live?.owners["ppf|" + key] != nil {
                    Divider()
                    if let h = PPFWords.holder(holder), owner.hasPrefix("n:") {
                        Button { store.live?.addPerson(name: h, rel: "") } label: { Label("Add " + h + " to the household", systemImage: "person.badge.plus") }
                    }
                    if store.live?.owners["ppf|" + key] != nil {
                        Button { store.live?.setOwner("ppf|" + key, "") } label: { Label("By the name on its statement", systemImage: "doc.text") }
                    }
                }
            } label: {
                HStack(spacing: 12) {
                    Image(systemName: "person.crop.circle").font(.system(size: 15, weight: .semibold)).foregroundStyle(Obsidian.property).frame(width: 30)
                    VStack(alignment: .leading, spacing: 1) {
                        Text("Whose is it").font(.subheadline).foregroundStyle(Color.primary)
                        Text(PPFWords.why(why)).font(.caption).foregroundStyle(why == "inbox" ? Color.orange : Color.secondary).lineLimit(1)
                    }
                    Spacer(minLength: 8)
                    Text(PPFWords.owner(owner, holder: holder, store)).font(.subheadline).foregroundStyle(.secondary).lineLimit(1)
                    Image(systemName: "chevron.up.chevron.down").font(.caption2.weight(.semibold)).foregroundStyle(.tertiary)
                }
                .frame(minHeight: 50)
                .contentShape(Rectangle())
            }
        } footer: {
            if let h = PPFWords.holder(holder) { Text("Its statement is in the name of " + h + ".") }
        }
    }
}

/// "the same as another PPF": the other accounts kosh holds, to pick the one this repeats
struct PPFSamePicker: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    let key: String
    var body: some View {
        let others: [RetirementBook.PPF.Row] = (store.snap.retirement?.ppf?.rows ?? []).filter { $0.id != key }
        NavigationStack {
            List {
                if others.isEmpty {
                    Text("kosh holds no other PPF to match it with.").foregroundStyle(.secondary)
                }
                ForEach(others) { (o: RetirementBook.PPF.Row) in
                    Button {
                        store.live?.setPPF(key, "same:" + o.id)
                        dismiss()
                    } label: {
                        LabeledContent(PPFWords.title(o.bank), value: PPFWords.owner(o.owner, holder: o.holder, store))
                    }
                }
            }
            .navigationTitle("The same as…")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } } }
        }
    }
}

/// the PPFs you said aren't one, or repeat another: each can come back
struct PPFLeftOut: View {
    @Environment(Store.self) private var store
    var body: some View {
        let said: [String: String] = store.live?.acctFix.ppf ?? [:]
        let out: [(String, String)] = said.filter { $0.value == "notppf" || $0.value.hasPrefix("same:") }.sorted { $0.key < $1.key }.map { ($0.key, $0.value) }
        if !out.isEmpty {
            Section {
                ForEach(out, id: \.0) { (pair: (String, String)) in
                    HStack {
                        VStack(alignment: .leading, spacing: 1) {
                            Text(Self.name(pair.0)).font(.subheadline)
                            Text(pair.1 == "notppf" ? "You said it isn’t a PPF" : "You said it’s the same as " + Self.name(String(pair.1.dropFirst(5))))
                                .font(.caption).foregroundStyle(.secondary)
                        }
                        Spacer()
                        Button("Bring back") { store.live?.setPPF(pair.0, nil) }.font(.subheadline)
                    }
                }
            } header: { Text("Left out of PPF") }
        }
    }
    /// "SBI|9014" → "SBI PPF ••9014"
    static func name(_ key: String) -> String {
        let p: [Substring] = key.split(separator: "|")
        return p.count == 2 ? String(p[0]) + " PPF ••" + String(p[1]) : key
    }
}
