import SwiftUI

// MARK: - Wallets: Zomato Money, Amazon Pay and the rest
//
// A warm lead card with what the wallets hold (the balances you've typed, carried forward) and how many of them
// kosh knows; what went in and out in the stretch; a tile per wallet (its balance, or a way to add one; how
// often it's used, what was spent from it and on what); the apps and shops paid in the stretch however they were
// paid (Blinkit, Zomato, Amazon…); where the wallet money went; the money added, each top-up paired with the bank
// or card that paid for it; the latest payments; and a word on why balances need typing once.

struct WalletsView: View {
    @Environment(Store.self) private var store
    @AppStorage("accts.span") private var spanKey = "30d"
    @State private var editing: Account?
    @State private var finding = false

    var body: some View {
        let span: Span = Span.pick(spanKey, months: store.snap.months)
        let cm: String = store.snap.cm
        let phrase: String = span.phrase(cm: cm)
        let wallets: [Account] = Self.order(store.wallets)
        let book: WalletBook = store.walletBook(wallets, span: span)
        let known: [Account] = wallets.filter { $0.balance != nil }
        let total: Double = known.compactMap(\.balance).reduce(0, +)
        let canFind: Bool = store.live?.signedIn == true
        let catSum: Double = book.cats.reduce(0) { $0 + $1.1 }
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                if wallets.isEmpty {
                    ContentUnavailableView("No wallets yet", systemImage: "wallet.bifold",
                                           description: Text("Pay with Zomato Money or Amazon Pay once and they show up here."))
                        .padding(.top, 40)
                    LookAgainCard(noun: "wallet")
                    if !store.vouchers.isEmpty { GiftCardShelf(vouchers: store.vouchers, today: store.snap.today) }
                    ShopTiles(span: span)
                } else {
                    MoneyHero(heading: "In your wallets", value: known.isEmpty ? nil : total, empty: "Balances unknown",
                              line: "", wash: .warm, spanKey: $spanKey) {
                        HStack(spacing: 10) {
                            BadgeRow(wallets: Array(wallets.prefix(5)))
                            Text(Self.knownLine(known: known.count, of: wallets.count))
                                .font(.system(.footnote)).foregroundStyle(HeroWash.warm.soft)
                                .lineLimit(2).fixedSize(horizontal: false, vertical: true)
                        }
                        .padding(.top, 10)
                    }
                    VStack(alignment: .leading, spacing: 8) {
                        HStack(spacing: 10) {
                            FlowTile(title: "Added", value: book.added, sub: FlowTiles.inLine(tops: book.nTop, others: book.nOther),
                                     sym: "arrow.down.to.line", tint: Color.kosh)
                            FlowTile(title: "Spent", value: book.spent, sub: WalletCards.count(book.nOut, "payment"),
                                     sym: "arrow.up.right", tint: Color(light: "#C46A00", dark: "#FFA94D"))
                        }
                        Text(FlowTiles.walletCaption(phrase))
                            .font(.system(.caption)).foregroundStyle(.secondary).padding(.horizontal, 4)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                    tiles(wallets, book: book, span: span, canFind: canFind)
                    if finding && canFind {
                        LookAgainCard(noun: "wallet", autofocus: true)
                            .transition(.opacity.combined(with: .move(edge: .top)))
                    }
                    if !store.vouchers.isEmpty { GiftCardShelf(vouchers: store.vouchers, today: store.snap.today) }
                    ShopTiles(span: span)
                    if catSum > 0 {
                        VStack(alignment: .leading, spacing: 12) {
                            AcctTitle(title: "Where wallet money went")
                            CategorySplit(parts: book.cats, total: catSum, icons: true)
                                .padding(.horizontal, 16).padding(.top, 16).padding(.bottom, 6)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .background(Color.surface, in: RoundedRectangle(cornerRadius: 26, style: .continuous))
                        }
                        .padding(.top, 4)
                    }
                    if !book.adds.isEmpty { added(book.adds) }
                    recent(book.recent, phrase: phrase)
                    note
                }
            }
            .padding(.horizontal, 20)
            .padding(.top, 14)
            .padding(.bottom, 40)
        }
        .animation(Motion.open, value: spanKey)
        .animation(Motion.open, value: store.who)
        .animation(Motion.large, value: finding)
        .sheet(item: $editing) { a in
            BalanceEditor(a: a).presentationDetents([.medium])
        }
    }

    // MARK: pieces

    /// two to a row, each row as tall as its taller tile; "Add a wallet" last when kosh can go looking
    func tiles(_ wallets: [Account], book: WalletBook, span: Span, canFind: Bool) -> some View {
        let cells: Int = wallets.count + (canFind ? 1 : 0)
        let rows: Int = (cells + 1) / 2
        return VStack(spacing: 10) {
            ForEach(0..<rows, id: \.self) { r in
                HStack(alignment: .top, spacing: 10) {
                    cell(r * 2, wallets: wallets, book: book, span: span, canFind: canFind)
                    cell(r * 2 + 1, wallets: wallets, book: book, span: span, canFind: canFind)
                }
                .fixedSize(horizontal: false, vertical: true)
            }
        }
    }

    @ViewBuilder func cell(_ i: Int, wallets: [Account], book: WalletBook, span: Span, canFind: Bool) -> some View {
        if i < wallets.count {
            let a: Account = wallets[i]
            WalletTile(a: a, stat: book.stats[a.id] ?? WalletStat(), span: span, who: Self.whoLine(a, in: wallets, store: store)) {
                if store.live != nil { editing = a } else { store.push(.account(a.id)) }
            }
        } else if i == wallets.count && canFind {
            AddWalletTile(open: finding) { finding.toggle() }
        } else {
            Color.clear.frame(maxWidth: .infinity)
        }
    }

    func added(_ adds: [WalletAdd]) -> some View {
        let counted: Bool = store.live?.countPrepaid ?? false
        let tag: String = counted ? "counted as spending" : "not spending"
        return VStack(alignment: .leading, spacing: 12) {
            AcctTitle(title: "Money added")
            VStack(spacing: 0) {
                ForEach(Array(adds.prefix(6).enumerated()), id: \.element.id) { i, x in
                    if i > 0 { RowRule(inset: 50) }
                    Button { store.sheet = .tx(x.txID) } label: {
                        HStack(alignment: .top, spacing: 12) {
                            IconTile(symbol: "arrow.down.to.line", color: Color.kosh, size: 38)
                            VStack(alignment: .leading, spacing: 1) {
                                Text(x.title).font(.system(.subheadline, weight: .semibold)).foregroundStyle(Color.primary)
                                    .lineLimit(2).fixedSize(horizontal: false, vertical: true)
                                    .privacySensitive()
                                Text(x.sub).font(.system(.caption)).monospacedDigit().foregroundStyle(.secondary)
                                    .lineLimit(2).fixedSize(horizontal: false, vertical: true)
                                Text(tag).font(.system(.caption2, weight: .semibold)).foregroundStyle(Color(light: "#4A4A52", dark: "#AEAEB5"))
                                    .padding(.horizontal, 8).frame(minHeight: 20)
                                    .background(Color.rule.opacity(0.08), in: Capsule())
                                    .padding(.top, 5)
                            }
                            Spacer(minLength: 0)
                        }
                        .padding(.vertical, 12)
                        .contentShape(Rectangle())
                    }
                    .buttonStyle(.press)
                    .accessibilityElement(children: .combine)
                    .accessibilityHint("Opens the payment")
                }
            }
            .rowsCard()
            Text(counted ? Self.countedNote : Self.moveNote)
                .font(.system(.caption)).foregroundStyle(.secondary).padding(.horizontal, 4)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(.top, 4)
    }

    func recent(_ pays: [WalletPay], phrase: String) -> some View {
        let today: String = store.snap.today
        return VStack(alignment: .leading, spacing: 12) {
            AcctTitle(title: "Recent wallet payments")
            if pays.isEmpty {
                Text("All quiet on the wallet front " + phrase + ".")
                    .font(.system(.footnote)).foregroundStyle(.secondary).padding(.horizontal, 4)
            } else {
                VStack(spacing: 0) {
                    ForEach(Array(pays.enumerated()), id: \.element.id) { i, p in
                        if i > 0 { RowRule(inset: 50) }
                        Button { store.sheet = .tx(p.t.id) } label: {
                            HStack(spacing: 12) {
                                IconTile(symbol: p.t.u ? "questionmark" : p.t.sym, color: store.color(for: p.t), size: 38)
                                VStack(alignment: .leading, spacing: 1) {
                                    Text(p.t.m).font(.system(.subheadline, weight: .semibold)).foregroundStyle(Color.primary).lineLimit(1)
                                    Text(p.wallet + " · " + Day.when(p.t.d, today: today))
                                        .font(.system(.caption)).foregroundStyle(.secondary).lineLimit(1)
                                }
                                Spacer(minLength: 8)
                                Text(Fmt.rupees(p.t.a))
                                    .font(.system(.subheadline, design: .rounded, weight: .semibold)).monospacedDigit()
                                    .lineLimit(1).minimumScaleFactor(0.75)
                                    .privacySensitive()
                                    .layoutPriority(1)
                            }
                            .padding(.vertical, 10)
                            .contentShape(Rectangle())
                        }
                        .buttonStyle(.press)
                        .accessibilityElement(children: .combine)
                        .accessibilityHint("Opens the payment")
                    }
                }
                .rowsCard()
            }
        }
        .padding(.top, 4)
    }

    var note: some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: "info").font(.system(size: 14, weight: .bold)).foregroundStyle(Color(light: "#C46A00", dark: "#FFA94D"))
                .frame(width: 30, height: 30)
                .background(Color(hex: "#FF9F0A").opacity(0.16), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
            Text("Wallets don’t email their balance. Type it once from the wallet’s app and kosh carries it forward with every payment and top-up.")
                .font(.system(.footnote)).foregroundStyle(Color(light: "#3A3A44", dark: "#D1D1D6"))
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(.horizontal, 16).padding(.vertical, 14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.surface, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        .accessibilityElement(children: .combine)
    }

    // MARK: words

    static let moveNote = "A top-up is a move between your own money, not spending. It counts when the wallet pays for something."
    static let countedNote = "You count top-ups as spending (Paid out), so what the wallet pays for later isn’t counted again."

    /// balances known first, the biggest first; then the most recently used
    static func order(_ xs: [Account]) -> [Account] {
        xs.sorted { a, b in
            let ka: Bool = a.balance != nil
            let kb: Bool = b.balance != nil
            if ka != kb { return ka }
            if ka, (a.balance ?? 0) != (b.balance ?? 0) { return (a.balance ?? 0) > (b.balance ?? 0) }
            if a.lastUsed != b.lastUsed { return a.lastUsed > b.lastUsed }
            return a.bank < b.bank
        }
    }
    /// "2 of 5 balances known"
    static func knownLine(known: Int, of n: Int) -> String {
        if known == 0 { return n == 1 ? "Tap the wallet to add its balance" : "Tap a wallet to add its balance" }
        if known == n { return n == 1 ? "Its balance, carried forward" : "All " + String(n) + " balances known" }
        return String(known) + " of " + String(n) + " balances known"
    }
    /// whose it is, when that's worth saying: someone else's in the family view, or one of two logins
    static func whoLine(_ a: Account, in xs: [Account], store: Store) -> String {
        var twins: Int = 0
        for x in xs where x.bank == a.bank { twins += 1 }
        var bits: [String] = []
        if twins > 1 || (store.who == .family && a.owner != "me") { bits.append(store.ownerName(a.owner)) }
        let inbox: String = a.inbox ?? ""
        if twins > 1 && !inbox.isEmpty { bits.append(inbox) }
        return bits.joined(separator: " · ")
    }
}

// MARK: - A wallet

/// a wallet's mark: its initials in its colour, in ink that reads on it; outlined when its balance isn't known
struct WalletBadge: View {
    let name: String
    let hex: String
    var size: CGFloat = 36
    var known: Bool = true
    static func initials(_ s: String) -> String {
        let caps: [Character] = s.filter { $0.isUppercase }.map { $0 }
        if caps.count >= 2 { return String(caps.prefix(2)) }
        let words: [Substring] = s.split(separator: " ")
        if words.count >= 2, let a = words[0].first, let b = words[1].first { return (String(a) + String(b)).uppercased() }
        return String(s.prefix(2)).uppercased()
    }
    var body: some View {
        let col: Color = Color(hex: hex)
        let r: CGFloat = size * 0.28
        let paper: Color = Color(light: "#FFF6EE", dark: "#2A2119")
        let brown: Color = Color(light: "#8A6A52", dark: "#C9A88E")
        Text(Self.initials(name))
            .font(.system(size: size * 0.36, weight: .heavy, design: .rounded))
            .foregroundStyle(known ? Swatch.ink(on: hex) : brown)
            .lineLimit(1).minimumScaleFactor(0.6)
            .frame(width: size, height: size)
            .background {
                if known {
                    RoundedRectangle(cornerRadius: r, style: .continuous)
                        .fill(LinearGradient(colors: [col.mix(with: .white, by: 0.06), col.mix(with: .black, by: 0.12)], startPoint: .top, endPoint: .bottom))
                } else {
                    RoundedRectangle(cornerRadius: r, style: .continuous).fill(paper)
                        .overlay(RoundedRectangle(cornerRadius: r, style: .continuous).strokeBorder(brown.opacity(0.45), lineWidth: 1.2))
                }
            }
            .accessibilityHidden(true)
    }
}

/// the wallets in the hero, overlapping: filled where the balance is known
struct BadgeRow: View {
    let wallets: [Account]
    var body: some View {
        HStack(spacing: -5) {
            ForEach(wallets) { w in
                WalletBadge(name: w.bank, hex: w.color, size: 24, known: w.balance != nil)
                    .padding(2)
                    .background(Color(light: "#FFF6EE", dark: "#2A2119"), in: RoundedRectangle(cornerRadius: 9, style: .continuous))
            }
        }
        .accessibilityHidden(true)
    }
}

/// one wallet: its mark and name, the balance (or a way to add it), how often it was used and what for
struct WalletTile: View {
    @Environment(Store.self) private var store
    let a: Account
    let stat: WalletStat
    let span: Span
    var who: String = ""
    var onAdd: () -> Void = {}
    var body: some View {
        let today: String = store.snap.today
        let top: String = stat.top.isEmpty ? (a.top ?? "") : stat.top
        let spent: String = Self.spentLine(stat, span: span, cm: store.snap.cm)
        let last: String = a.lastUsed.isEmpty ? "" : "last used " + Day.when(a.lastUsed, today: today)
        VStack(alignment: .leading, spacing: 0) {
            WalletBadge(name: a.bank, hex: a.color, size: 36)
            Text(a.bank).font(.system(.subheadline, weight: .semibold)).lineLimit(2)
                .fixedSize(horizontal: false, vertical: true)
                .padding(.top, 10)
            if !who.isEmpty {
                Text(who).font(.system(.caption2)).foregroundStyle(.secondary).lineLimit(1).truncationMode(.middle)
            }
            if let b = a.balance {
                Text(Fmt.rupees(b))
                    .font(.system(.title2, design: .rounded, weight: .bold)).monospacedDigit()
                    .lineLimit(1).minimumScaleFactor(0.6)
                    .contentTransition(.numericText(value: b))
                    .privacySensitive()
                    .padding(.top, 2)
            } else {
                Button(action: onAdd) {
                    HStack(spacing: 5) {
                        Image(systemName: "plus").font(.system(.caption, weight: .bold))
                        Text("Add balance").font(.system(.subheadline, weight: .semibold))
                    }
                    .foregroundStyle(Color.kosh)
                    .frame(minHeight: 29)
                    .contentShape(Rectangle())
                }
                .buttonStyle(.press)
                .padding(.top, 2)
                .accessibilityLabel("Add " + a.bank + "’s balance")
            }
            // what went out of it in the stretch, whatever its balance
            Text(spent)
                .font(.system(.caption, weight: stat.nOut > 0 ? .semibold : .regular)).monospacedDigit()
                .foregroundStyle(stat.nOut > 0 ? Color.primary : Color.secondary)
                .fixedSize(horizontal: false, vertical: true)
                .privacySensitive()
                .padding(.top, 4)
            if !last.isEmpty {
                Text(last).font(.system(.caption)).foregroundStyle(.secondary).lineLimit(1)
                    .padding(.top, 1)
            }
            if !top.isEmpty {
                HStack(spacing: 5) {
                    Circle().fill(store.catColor(top)).frame(width: 7, height: 7)
                    Text("mostly " + top).lineLimit(1)
                }
                .font(.system(.caption2))
                .foregroundStyle(.secondary)
                .padding(.top, 6)
            }
            Spacer(minLength: 0)
        }
        .padding(14)
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
        .background(Color.surface, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        .contentShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
        .onTapGesture { store.push(.account(a.id)) }
        .accessibilityElement(children: .combine)
        .accessibilityAddTraits(.isButton)
        .accessibilityHint("Opens the wallet")
        .accessibilityAction { store.push(.account(a.id)) }
        .accessibilityAction(named: Text(a.balance == nil ? "Add its balance" : "Update its balance")) { onAdd() }
    }
    /// "₹1,200 spent · 5 payments", "Nothing spent in 30 days"
    static func spentLine(_ stat: WalletStat, span: Span, cm: String) -> String {
        if stat.nOut > 0 { return Fmt.rupees(stat.spent) + " spent · " + WalletCards.count(stat.nOut, "payment") }
        return "Nothing spent " + (span.isMonth ? span.phrase(cm: cm) : "in 30 days")
    }
}

/// the last tile: name a wallet and kosh goes looking for it
struct AddWalletTile: View {
    let open: Bool
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 8) {
                Image(systemName: open ? "xmark" : "plus").font(.system(size: 14, weight: .bold)).foregroundStyle(Color.kosh)
                    .frame(width: 36, height: 36)
                    .background(Color.kosh.opacity(0.12), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
                Text(open ? "Never mind" : "Add a wallet").font(.system(.subheadline, weight: .semibold)).foregroundStyle(Color.kosh)
                Text("Or a gift card held as a balance. Name it and kosh goes looking.")
                    .font(.system(.caption)).foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
                Spacer(minLength: 0)
            }
            .padding(14)
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
            .background(Color.raised, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous).strokeBorder(Color.rule.opacity(0.18), lineWidth: 1.2))
            .contentShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
        }
        .buttonStyle(.press)
        .accessibilityHint(open ? "Closes the finder" : "Opens a box to name the wallet")
    }
}

// MARK: - What the wallets did in the stretch, in one pass

struct WalletStat {
    var spent: Double = 0
    var nOut: Int = 0
    var added: Double = 0
    var nIn: Int = 0
    var cats: [String: Double] = [:]
    /// what it was used for most
    var top: String {
        var best: String = ""
        var v: Double = 0
        for (k, x) in cats where x > v || (x == v && k < best) { best = k; v = x }
        return best
    }
}

/// a payment from a wallet, and the wallet's name
struct WalletPay: Identifiable {
    let t: Txn
    let wallet: String
    var id: String { t.id }
}

/// money put into a wallet (or a gift card), with where it came from
struct WalletAdd: Identifiable {
    let id: String
    let amount: Double
    let title: String
    let sub: String
    let d: String
    /// the payment to open: the bank's or card's side when kosh has it
    let txID: String
}

struct WalletBook {
    var stats: [String: WalletStat] = [:]
    var spent: Double = 0
    var nOut: Int = 0
    var added: Double = 0
    var nTop: Int = 0
    var nOther: Int = 0
    var cats: [(String, Double)] = []
    var recent: [WalletPay] = []
    var adds: [WalletAdd] = []

    /// the four biggest, the rest as Other
    static func split(_ by: [String: Double]) -> [(String, Double)] {
        let all: [(String, Double)] = by.sorted { $0.value != $1.value ? $0.value > $1.value : $0.key < $1.key }.map { ($0.key, $0.value) }
        var out: [(String, Double)] = Array(all.prefix(4))
        let rest: Double = all.dropFirst(4).reduce(0) { $0 + $1.1 }
        if rest > 0 { out.append(("Other", rest)) }
        return out
    }

    /// each top-up (the wallet's own "₹1,000 added") with the bank or card debit that paid for it: the same amount
    /// within a day, the wallet's name in it when two would do; then gift cards and loads with no wallet side
    static func adds(_ tops: [(Txn, String)], names: [String: String], tx: [Txn], span: Span, today: String, who: Person) -> [WalletAdd] {
        let (a, z) = span.range(today: today)
        let lo: String = Day.add(a, -1)
        let hi: String = Day.add(z, 1)
        let pre: [Txn] = tx.filter { $0.k == "prepaid" && $0.partOf == nil && who.owns($0.o) && $0.d >= lo && $0.d <= hi }
        var used = Set<String>()
        var out: [WalletAdd] = []
        for (w, wid) in tops.sorted(by: { $0.0.d > $1.0.d }) {
            let wname: String = names[wid] ?? w.card
            let stem: String = wname.lowercased().split(separator: " ").first.map(String.init) ?? ""
            var best: Txn? = nil
            for p in pre where !used.contains(p.id) && abs(p.a - w.a) <= 0.5 && abs(Day.between(p.d, w.d)) <= 1 {
                let hay: String = (p.m + " " + p.n).lowercased()
                if !stem.isEmpty && hay.contains(stem) { best = p; break }
                if best == nil { best = p }
            }
            let when: String = Day.fmt(w.d, "d MMM")
            let title: String = Fmt.rupees(w.a) + " added to " + wname
            if let p = best {
                used.insert(p.id)
                out.append(WalletAdd(id: w.id, amount: w.a, title: title, sub: "from " + source(p) + " · " + when, d: w.d, txID: p.id))
            } else {
                out.append(WalletAdd(id: w.id, amount: w.a, title: title, sub: when + " · paid from somewhere kosh doesn’t read", d: w.d, txID: w.id))
            }
        }
        for p in pre where !used.contains(p.id) && span.has(p.d, today: today) {
            let sub: String = what(p) + " · from " + source(p) + " · " + Day.fmt(p.d, "d MMM")
            out.append(WalletAdd(id: p.id, amount: p.a, title: Fmt.rupees(p.a) + " to " + p.m, sub: sub, d: p.d, txID: p.id))
        }
        return out.sorted { $0.d != $1.d ? $0.d > $1.d : $0.id < $1.id }
    }
    /// "HDFC ••4821", "HDFC card ••7710", "SBI ••3302 by UPI"
    static func source(_ t: Txn) -> String {
        let bank: String = (t.bk ?? "").trimmingCharacters(in: .whitespaces)
        let l4: String = t.l4 ?? ""
        let tail: String = l4.isEmpty ? "" : " ••" + l4
        let md: String = t.md ?? ""
        if md == "card" { return (bank.isEmpty ? "a card" : bank + " card") + tail }
        if bank.isEmpty { return t.card.isEmpty ? "your bank" : t.card }
        return bank + tail + (md == "upi" ? " by UPI" : "")
    }
    static func what(_ t: Txn) -> String {
        switch t.s {
        case "Gift cards": return "bought as a gift card"
        case "Prepaid cards": return "loaded on a prepaid card"
        case "Metro & transit cards": return "a metro or transit top-up"
        default: return "loaded into a wallet"
        }
    }
}

extension Store {
    /// what these wallets did in the stretch: per wallet and in all, where the money went, the latest payments,
    /// and the money added with where it came from
    func walletBook(_ wallets: [Account], span: Span) -> WalletBook {
        let today: String = snap.today
        var b = WalletBook()
        var owner: [String: String] = [:]
        var names: [String: String] = [:]
        for w in wallets {
            for k in w.keys ?? [w.id] { owner[k] = w.id }
            names[w.id] = w.bank
        }
        if owner.isEmpty { return b }
        var cats: [String: Double] = [:]
        var tops: [(Txn, String)] = []
        var pays: [WalletPay] = []
        let (lo, hi) = span.range(today: today)
        for t in tx where t.partOf == nil {
            guard let wid = owner[t.card], t.d >= lo && t.d <= hi else { continue }
            let v: Double = t.full ?? t.a
            let dir: String = t.dr ?? (t.k == "in" ? "in" : (t.k == "out" ? "out" : ""))
            var s: WalletStat = b.stats[wid] ?? WalletStat()
            if dir == "in" {
                s.added += v; s.nIn += 1; b.added += v
                if t.k == "move" { b.nTop += 1; tops.append((t, wid)) } else { b.nOther += 1 }
            } else if dir == "out" {
                s.spent += v; s.nOut += 1; b.spent += v; b.nOut += 1
                if t.k == "out" { s.cats[t.c, default: 0] += v; cats[t.c, default: 0] += v }
                pays.append(WalletPay(t: t, wallet: names[wid] ?? t.card))
            } else {
                continue
            }
            b.stats[wid] = s
        }
        b.cats = WalletBook.split(cats)
        b.recent = Array(pays.sorted { ($0.t.d, $0.t.t) > ($1.t.d, $1.t.t) }.prefix(6))
        b.adds = WalletBook.adds(tops, names: names, tx: tx, span: span, today: today, who: who)
        return b
    }
}

// MARK: - Apps and shops: where the orders went, however they were paid

/// one app or shop in the stretch: what went to it, how many orders, how each was paid, and when
struct ShopStat: Identifiable {
    let shop: Directory.Shop
    var spent: Double = 0
    var n: Int = 0
    /// how it was paid ("HDFC ••1234", "Zomato Money", "UPI") → how many times, and that way's symbol
    var ways: [String: Int] = [:]
    var waySym: [String: String] = [:]
    /// the hour of each order, when the mail said it, and how many fell on a Saturday or Sunday
    var hours: [Int] = []
    var weekend: Int = 0
    var id: String { shop.id }

    mutating func add(_ t: Txn) {
        spent += t.full ?? t.a
        n += 1
        let way: (String, String) = ShopStat.way(t)
        if !way.0.isEmpty { ways[way.0, default: 0] += 1; waySym[way.0] = way.1 }
        if let h = Int(t.t.prefix(2)), t.t.count >= 4, h >= 0, h < 24 { hours.append(h) }
        let wd: Int = Day.weekday(t.d)
        if wd == 1 || wd == 7 { weekend += 1 }
    }

    /// "HDFC ••1234", "Zomato Money", "UPI", with a symbol for the kind
    static func way(_ t: Txn) -> (String, String) {
        let bank: String = (t.bk ?? "").trimmingCharacters(in: .whitespaces)
        let l4: String = t.l4 ?? ""
        switch PaidWith.key(t) {
        case "wallet": return (PaidWith.walletName(t), "wallet.bifold")
        case "card": return (bank.isEmpty ? "a card" : bank + (l4.isEmpty ? " card" : " ••" + l4), "creditcard")
        case "upi": return ("UPI", "qrcode")
        case "cash": return ("cash", "banknote")
        case "bank": return (bank.isEmpty ? "bank transfer" : bank + (l4.isEmpty ? "" : " ••" + l4), "building.columns")
        default: return ("", "")
        }
    }

    /// the way used most, and how often
    var top: (String, Int)? {
        guard let best = ways.max(by: { a, b in a.value != b.value ? a.value < b.value : a.key > b.key }) else { return nil }
        return (best.key, best.value)
    }
    /// "mostly paid by HDFC ••1234", "paid by UPI every time"
    var paidLine: String {
        guard let best = top else { return "" }
        let way: String = best.0
        let k: Int = best.1
        if n == 1 { return "paid by " + way }
        if k == n { return "paid by " + way + " every time" }
        if k * 2 > n { return "mostly paid by " + way }
        return "paid a few ways, " + way + " most"
    }
    /// a word on the habit, only when the orders bear it out
    var quip: String? {
        if n == 1 { return "just the once" }
        if n < 3 { return nil }
        let food: Bool = shop.cat == "Food & Drinks" || shop.cat == "Groceries"
        if hours.count >= 3 {
            let late: Int = hours.filter { $0 >= 23 || $0 < 4 }.count
            if late * 2 > hours.count { return food ? "mostly midnight cravings" : "mostly after 11 at night" }
            let dinner: Int = hours.filter { $0 >= 19 && $0 < 23 }.count
            if food && dinner * 2 > hours.count { return "mostly dinner" }
            let early: Int = hours.filter { $0 >= 5 && $0 < 10 }.count
            if early * 2 > hours.count { return food ? "mostly breakfast runs" : "mostly mornings" }
        }
        if weekend * 3 >= n * 2 { return "mostly weekends" }
        if n >= 8 { return "practically a regular" }
        return nil
    }
    /// "7 orders"
    var orders: String { n == 1 ? "1 order" : String(n) + " orders" }
}

extension Store {
    /// the apps and shops paid in the stretch, the most spent first: every order, card, UPI or wallet alike
    func shopBook(span: Span) -> [ShopStat] {
        var by: [String: ShopStat] = [:]
        for t in shopOrders(span: span) {
            guard let s = shopOf(t) else { continue }
            var x: ShopStat = by[s.id] ?? ShopStat(shop: s)
            x.add(t)
            by[s.id] = x
        }
        return by.values.sorted { $0.spent != $1.spent ? $0.spent > $1.spent : $0.shop.name < $1.shop.name }
    }
    /// one shop's orders in the stretch, newest first
    func shopPayments(_ id: String, span: Span) -> [Txn] {
        shopOrders(span: span).filter { shopOf($0)?.id == id }.sorted { ($0.d, $0.t) > ($1.d, $1.t) }
    }
    /// the shop a payment went to, if it was one kosh knows
    func shopOf(_ t: Txn) -> Directory.Shop? {
        let wallet: String = PaidWith.key(t) == "wallet" ? PaidWith.walletName(t) : ""
        return Directory.shared.shop(payee: t.m, wallet: wallet, cat: t.c)
    }
    /// what went out to be spent in the stretch, each charge once (not its split-out parts), not what you set aside
    private func shopOrders(span: Span) -> [Txn] {
        let (lo, hi) = span.range(today: snap.today)
        return tx.filter { t in t.partOf == nil && t.k == "out" && (t.ex ?? "").isEmpty && who.owns(t.o) && t.d >= lo && t.d <= hi }
    }
}

/// the apps and shops section: a tile each, two to a row, the most spent first
struct ShopTiles: View {
    @Environment(Store.self) private var store
    let span: Span
    var body: some View {
        let shops: [ShopStat] = store.shopBook(span: span)
        let phrase: String = span.phrase(cm: store.snap.cm)
        if !shops.isEmpty {
            let total: Double = shops.reduce(0) { $0 + $1.spent }
            let orders: Int = shops.reduce(0) { $0 + $1.n }
            let rows: Int = (shops.count + 1) / 2
            VStack(alignment: .leading, spacing: 12) {
                AcctTitle(title: "Apps & shops you pay")
                Text(ShopTiles.lead(total: total, orders: orders, shops: shops.count, phrase: phrase))
                    .font(.system(.footnote)).foregroundStyle(.secondary).padding(.horizontal, 4)
                    .fixedSize(horizontal: false, vertical: true)
                    .privacySensitive()
                VStack(spacing: 10) {
                    ForEach(0..<rows, id: \.self) { r in
                        HStack(alignment: .top, spacing: 10) {
                            cell(r * 2, shops)
                            cell(r * 2 + 1, shops)
                        }
                        .fixedSize(horizontal: false, vertical: true)
                    }
                }
            }
            .padding(.top, 4)
        }
    }

    @ViewBuilder func cell(_ i: Int, _ shops: [ShopStat]) -> some View {
        if i < shops.count {
            let x: ShopStat = shops[i]
            ShopTile(x: x) { store.push(.shop(x.shop.id)) }
        } else {
            Color.clear.frame(maxWidth: .infinity)
        }
    }

    /// "₹6,120 over 14 orders at 4 apps in the last 30 days, however you paid."
    static func lead(total: Double, orders: Int, shops: Int, phrase: String) -> String {
        let at: String = shops == 1 ? "one app" : String(shops) + " apps and shops"
        return Fmt.rupees(total) + " over " + (orders == 1 ? "1 order" : String(orders) + " orders") + " at " + at + " " + phrase + ", by card, UPI or wallet."
    }
}

/// one app or shop: its mark, what went to it, its orders (and a word on them), and how it was mostly paid
struct ShopTile: View {
    let x: ShopStat
    let open: () -> Void
    var body: some View {
        let way: String = x.paidLine
        Button(action: open) {
            VStack(alignment: .leading, spacing: 0) {
                WalletBadge(name: x.shop.name, hex: x.shop.color, size: 36)
                Text(x.shop.name).font(.system(.subheadline, weight: .semibold)).foregroundStyle(Color.primary).lineLimit(1)
                    .padding(.top, 10)
                Text(Fmt.rupees(x.spent))
                    .font(.system(.title2, design: .rounded, weight: .bold)).monospacedDigit().foregroundStyle(Color.primary)
                    .lineLimit(1).minimumScaleFactor(0.6)
                    .contentTransition(.numericText(value: x.spent))
                    .privacySensitive()
                    .padding(.top, 2)
                Group {
                    if let q = x.quip {
                        Text("\(Text(x.orders).fontWeight(.semibold).foregroundStyle(Color.primary)), \(q)")
                    } else {
                        Text(x.orders).fontWeight(.semibold).foregroundStyle(Color.primary)
                    }
                }
                .font(.system(.caption))
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
                .padding(.top, 4)
                if !way.isEmpty {
                    HStack(alignment: .firstTextBaseline, spacing: 5) {
                        Image(systemName: x.top.flatMap { x.waySym[$0.0] } ?? "creditcard").font(.system(.caption2, weight: .semibold))
                        Text(way).fixedSize(horizontal: false, vertical: true)
                    }
                    .font(.system(.caption2))
                    .foregroundStyle(.secondary)
                    .padding(.top, 6)
                }
                Spacer(minLength: 0)
            }
            .padding(14)
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
            .background(Color.surface, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
            .contentShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
        }
        .buttonStyle(.press)
        .accessibilityElement(children: .combine)
        .accessibilityHint("Shows its orders")
    }
}

/// one app or shop's orders in the stretch, each opening its payment
struct ShopPage: View {
    @Environment(Store.self) private var store
    @AppStorage("accts.span") private var spanKey = "30d"
    let id: String
    var body: some View {
        let span: Span = Span.pick(spanKey, months: store.snap.months)
        let phrase: String = span.phrase(cm: store.snap.cm)
        let today: String = store.snap.today
        let stat: ShopStat? = store.shopBook(span: span).first { $0.shop.id == id }
        let name: String = Directory.shared.shops.first { $0.id == id }?.name ?? "Shop"
        let rows: [Txn] = store.shopPayments(id, span: span)
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                MoneyHero(heading: "Paid to " + name, value: stat?.spent ?? 0, line: Self.heroLine(stat, phrase: phrase),
                          wash: .warm, spanKey: $spanKey) {
                    if let s = stat, !s.paidLine.isEmpty {
                        Text(s.paidLine.prefix(1).uppercased() + String(s.paidLine.dropFirst()))
                            .font(.system(.footnote, weight: .semibold)).foregroundStyle(HeroWash.warm.ink)
                            .padding(.top, 10)
                    }
                }
                if rows.isEmpty {
                    Text("Nothing paid to \(name) \(phrase). Pick another stretch above.")
                        .font(.system(.footnote)).foregroundStyle(.secondary).padding(.horizontal, 4)
                } else {
                    VStack(alignment: .leading, spacing: 8) {
                        GroupLabel(title: "Orders", figure: WalletCards.latest(60, of: rows.count) ?? "", money: false)
                        VStack(spacing: 0) {
                            ForEach(Array(rows.prefix(60).enumerated()), id: \.element.id) { i, t in
                                if i > 0 { RowRule(inset: 48) }
                                TxRow(t: t, when: Day.label(t.d, today: today)).padding(.vertical, 10)
                            }
                        }
                        .rowsCard()
                    }
                }
                Text("Every payment to " + name + " kosh found, by card, UPI or wallet. A restaurant's order paid from an app's balance counts for the app.")
                    .font(.system(.caption)).foregroundStyle(.secondary).padding(.horizontal, 4)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .padding(.horizontal, 20)
            .padding(.top, 14)
            .padding(.bottom, 40)
        }
        .animation(Motion.open, value: spanKey)
        .navigationTitle(name)
        .navigationBarTitleDisplayMode(.inline)
    }

    /// "7 orders in the last 30 days, mostly midnight cravings"
    static func heroLine(_ stat: ShopStat?, phrase: String) -> String {
        guard let s = stat else { return "No orders " + phrase }
        var line: String = s.orders + " " + phrase
        if let q = s.quip { line += ", " + q }
        return line
    }
}
