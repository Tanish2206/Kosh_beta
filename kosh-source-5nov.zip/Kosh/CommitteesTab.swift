import SwiftUI
import Charts

// MARK: - Committees: the committee book on a phone
//
// A committee (chit fund, BC) pools a fixed sum every month and one member takes the pool each month. In an
// auction committee members bid for it: the discount the winner gives up, less the organiser's commission, is
// shared as a lower instalment for everyone that month. That saving is what a committee earns you. kosh keeps
// each month's actual instalment (recorded by you, or picked up from payments to the person you pay), what
// you received, and adds them up month by month: what goes out, what comes in, and what it earned.

struct CommitteesTabView: View {
    @Environment(Store.self) private var store
    var body: some View {
        @Bindable var store = store
        NavigationStack(path: $store.commPath) {
            CommitteesHome()
                .whoseScope(store.whoseNote(store.who, total: store.snap.comm.count, theirs: store.committees(store.who).count,
                                            open: store.snap.comm.filter { ($0.whose ?? []).isEmpty }.count, thing: ("committee", "committees")))
                .navigationDestination(for: Route.self) { route in RouteDestination(route: route, zoom: nil) }
        }
    }
}

/// month axes: bars are keyed by yyyy-MM (a long committee repeats month names), labelled with the short name,
/// and only every few months when there are many
enum CommAxis {
    static func months(_ lo: String, _ hi: String) -> [String] {
        var out: [String] = [], m = lo
        while m <= hi && out.count < 120 { out.append(m); m = Day.addMonths(m, 1) }
        return out
    }
    static func label(_ s: String, years: Bool, first: String) -> String {
        let withYear: Bool = years && (s.hasSuffix("-01") || s == first)
        return withYear ? Day.fmt(s + "-01", "MMM yy") : Day.monthShort(s)
    }
    static func marks(_ ms: [String]) -> some AxisContent {
        let step = max(1, Int((Double(ms.count) / 7).rounded(.up)))
        let shown = ms.enumerated().filter { $0.offset % step == 0 }.map(\.element)
        let years = Set(ms.map { $0.prefix(4) }).count > 1
        return AxisMarks(values: shown) { v in
            AxisValueLabel {
                if let s = v.as(String.self) { Text(label(s, years: years, first: shown.first ?? "")) }
            }
        }
    }
}

/// one colour per committee, the same on every chart and card
enum CommColor {
    /// committees' own colours: data, so kosh blue and sky stay themselves whatever the accent
    static let palette: [Color] = [Color(hex: "#3B5BFD"), Color.orange, Color(hex: "#30B0C7"), Color(hex: "#FF2D55"), Color.green, Color(hex: "#A2845E"), Color(hex: "#FFCC00"), Color(hex: "#5AC8FA")]
    static func of(_ c: Committee, in all: [Committee]) -> Color {
        let i = all.firstIndex { $0.id == c.id } ?? 0
        return palette[i % palette.count]
    }
}

// MARK: - The overview

// MARK: - Month by month

// MARK: - Finished

// MARK: - One committee

struct CommitteeDetail: View {
    @Environment(Store.self) private var store
    let id: String
    @State private var recording: CommRow?

    var body: some View {
        if let c = store.committee(id) {
            content(c)
                .sheet(item: $recording) { r in RecordInstalment(c: c, row: r).presentationDetents([.medium]) }
        } else {
            ContentUnavailableView("No such committee", systemImage: "circle.dotted.circle")
        }
    }

    var mine: Bool { store.live?.userCommittees.contains(where: { $0.id == id }) == true }

    static func endLine(_ end: Double) -> String {
        let head: String = end >= 0 ? "Ends about " + Fmt.words(end) + " ahead: " : "Costs about " + Fmt.words(abs(end)) + ": "
        return head + "what you receive against everything you pay in."
    }
    static func receiveLabel(_ c: Committee) -> String {
        guard c.net > 0 else { return "the pool" }
        return c.taken == true ? "you received" : "you'll receive"
    }
    static func earnedLabel(_ c: Committee) -> String {
        c.pct > 0 ? "earned, " + Fmt.trim(c.pct, 1) + "%" : "earned"
    }
    static func toPayLabel(_ c: Committee) -> String {
        c.left > 0 ? "to pay, " + CommText.many(c.left, "month") : "still to pay"
    }
    static func kindLine(_ c: Committee) -> String {
        CommText.kindLine(c) + " · " + String(c.paid) + " paid"
    }

    func status(_ c: Committee) -> String {
        if c.done { return "Finished" }
        if c.draw == store.snap.cm { return "Your month to take the pool" }
        if let d = c.draw { return d < store.snap.cm ? "Pool taken in \(Day.fmt(d + "-01", "MMMM yyyy"))" : "You take the pool in \(Day.fmt(d + "-01", "MMMM yyyy"))" }
        return "Your month isn't set"
    }

    @ViewBuilder func content(_ c: Committee) -> some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                HStack(spacing: 18) {
                    RingView(c: c, size: 92)
                    VStack(alignment: .leading, spacing: 4) {
                        Text(status(c)).font(.subheadline.weight(.semibold)).foregroundStyle(c.draw == store.snap.cm ? Color.green : Color.kosh)
                        Text("\(Fmt.rupees(c.face)) a month").font(.title2.weight(.bold)).privacySensitive()
                        Text(Self.kindLine(c)).font(.subheadline).foregroundStyle(.secondary)
                    }
                }
                LazyVGrid(columns: [GridItem(.flexible(), spacing: 12), GridItem(.flexible(), spacing: 12)], spacing: 12) {
                    CountTile(value: Fmt.short(c.contributed), label: "paid in", sym: "arrow.up.right", color: Color.kosh)
                    CountTile(value: Fmt.short(c.profit), label: Self.earnedLabel(c), sym: "sparkles", color: Color.green)
                    CountTile(value: Fmt.short(c.net > 0 ? c.net : c.pool), label: Self.receiveLabel(c), sym: "gift.fill", color: Color.sky)
                    CountTile(value: c.done ? "0" : Fmt.short(c.outstanding), label: Self.toPayLabel(c), sym: "calendar", color: Color.orange)
                }
                .privacySensitive()
                if let end = c.endNet, c.net > 0 {
                    Label(Self.endLine(end), systemImage: end >= 0 ? "arrow.up.right.circle.fill" : "arrow.down.right.circle.fill")
                        .font(.subheadline).foregroundStyle(end >= 0 ? Color.green : Color.orange).privacySensitive()
                }
                if store.live != nil && mine && !c.done { CommLinkCard(c: c) }
                if let rows = c.rows, !rows.isEmpty {
                    CommInstalmentChart(c: c, rows: rows)
                    CommMonthsList(c: c, rows: rows, cm: store.snap.cm, editable: mine) { r in recording = r }
                }
                Text(CommKind(rawValue: c.kind ?? "")?.line ?? "A committee earns when you pay less than face value in the months before your draw.")
                    .font(.footnote).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            }
            .padding(.horizontal, 20)
            .padding(.bottom, 30)
        }
        .navigationTitle(c.name)
        .toolbar {
            if mine {
                ToolbarItem(placement: .primaryAction) { Button { store.betaSheet = .committee(c.id) } label: { Image(systemName: "pencil") }.accessibilityLabel("Edit") }
            }
        }
    }
}

/// instalments month by month against face value: every rupee under the dashed line was earned
struct CommInstalmentChart: View {
    let c: Committee
    let rows: [CommRow]
    /// what VoiceOver says of the bars; the face value only while amounts show
    static func spoken(_ c: Committee, _ rows: [CommRow], figures: Bool) -> String {
        let paid: Int = rows.filter { $0.st == "paid" }.count
        let face: String = figures && c.face > 0 ? ", face value " + Fmt.rupees(c.face) : ""
        return "Instalments month by month, " + SpokenWords.count(rows.count, "month", "months") + ", " + String(paid) + " paid as recorded" + face
    }
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            SectionHeader(title: "Instalments", n: 1)
            Chart {
                ForEach(rows) { r in
                    BarMark(x: .value("Month", r.m), y: .value("Paid", r.amt))
                        .foregroundStyle(r.recv > 0 ? Color.green.gradient : (r.st == "paid" ? Color.kosh.gradient : Color.secondary.opacity(0.35).gradient))
                        .cornerRadius(4)
                }
                RuleMark(y: .value("Face", c.face))
                    .foregroundStyle(Color.secondary)
                    .lineStyle(StrokeStyle(lineWidth: 1, dash: [3, 4]))
                    .annotation(position: .top, alignment: .leading) {
                        Text("face " + Fmt.short(c.face)).font(.caption2.weight(.semibold)).foregroundStyle(.secondary).privacySensitive()
                    }
            }
            .chartXAxis { CommAxis.marks(rows.map(\.m)) }
            .chartYAxis(.hidden)
            .frame(height: 170)
            .accessibilityElement(children: .ignore)
            .spokenFigures(Self.spoken(c, rows, figures: true), hidden: Self.spoken(c, rows, figures: false))
            Text("Blue months are paid as recorded; grey are at face value (gone by with nothing recorded, or still ahead); green is your pool month.")
                .font(.footnote).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
        }
        .card(16)
    }
}

/// every month of the committee; tap one to record what it actually cost
struct CommMonthsList: View {
    let c: Committee
    let rows: [CommRow]
    let cm: String
    let editable: Bool
    let record: (CommRow) -> Void
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            SectionHeader(title: "Every month", n: 2)
            VStack(spacing: 0) {
                ForEach(Array(rows.enumerated()), id: \.element.id) { i, r in
                    if i > 0 { Divider().padding(.leading, 16) }
                    Button { if editable && r.st != "ahead" { record(r) } } label: { CommMonthRow(r: r, cm: cm) }
                        .buttonStyle(.press)
                }
            }
            .background(Color.surface, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            if editable { Text("Tap a month to put in what you actually paid.").font(.footnote).foregroundStyle(.secondary) }
        }
    }
}

struct CommMonthRow: View {
    let r: CommRow
    let cm: String
    var badge: (String, Color) {
        if r.recv > 0 { return ("your pool", Color.green) }
        switch r.st {
        case "paid": return (r.src == "bank" ? "from your bank" : (r.src == "you" ? "recorded" : (r.src == "total" ? "from the total paid" : "paid")), Color.kosh)
        case "assumed": return ("at face value", Color.secondary)
        case "due": return ("due", Color.orange)
        default: return ("ahead", Color.secondary)
        }
    }
    var body: some View {
        HStack(spacing: 10) {
            VStack(alignment: .leading, spacing: 2) {
                Text(r.m == cm ? "This month" : Day.fmt(r.m + "-01", "MMM yyyy")).font(.subheadline.weight(.medium))
                Text(badge.0).font(.caption).foregroundStyle(badge.1)
            }
            Spacer()
            VStack(alignment: .trailing, spacing: 2) {
                Text(Fmt.rupees(r.amt)).font(.subheadline.weight(.semibold)).monospacedDigit()
                    .foregroundStyle(r.st == "ahead" || r.st == "assumed" ? Color.secondary : Color.primary).privacySensitive()
                if r.disc > 0 {
                    Text("−\(Fmt.rupees(r.disc)) · \(Fmt.trim(r.pct, 1))%").font(.caption).foregroundStyle(Color.green).monospacedDigit().privacySensitive()
                } else if r.recv > 0 {
                    Text("+" + Fmt.rupees(r.recv) + " received").font(.caption).foregroundStyle(Color.green).privacySensitive()
                }
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 11)
        .contentShape(Rectangle())
    }
}

/// payments to the person or account you pay a committee to become its instalments, by themselves
struct CommLinkCard: View {
    @Environment(Store.self) private var store
    let c: Committee
    static func candLine(_ k: CommCand) -> String {
        let n: String = k.n == 1 ? "1 payment" : String(k.n) + " payments"
        return n + " · ~" + Fmt.short(k.avg)
    }
    var payee: String { (c.payeeName ?? "").isEmpty ? "your organiser" : (c.payeeName ?? "") }
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            if c.linked == true {
                HStack(alignment: .top, spacing: 12) {
                    Image(systemName: "link.circle.fill").font(.title3).foregroundStyle(Color.green)
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Paid to " + payee).font(.subheadline.weight(.semibold))
                        Text("Payments to them are recorded here as each month's instalment, and don't count as spending.").font(.caption).foregroundStyle(.secondary)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                    Spacer(minLength: 0)
                    Button("Unlink") { store.live?.linkCommittee(c.id, payee: nil, name: nil) }.font(.caption.weight(.semibold))
                }
            } else if let cands = c.candidates, !cands.isEmpty {
                Text("Do you pay it by UPI or bank transfer? Pick who you pay and kosh records each month for you.")
                    .font(.subheadline).fixedSize(horizontal: false, vertical: true)
                ForEach(cands) { k in
                    Button { store.live?.linkCommittee(c.id, payee: k.key, name: k.name) } label: {
                        HStack {
                            Image(systemName: "person.crop.circle").foregroundStyle(Color.kosh)
                            Text(k.name).font(.subheadline.weight(.medium)).lineLimit(1)
                            Spacer()
                            Text(Self.candLine(k)).font(.caption).foregroundStyle(.secondary).privacySensitive()
                        }
                        .padding(.vertical, 6)
                        .contentShape(Rectangle())
                    }
                    .buttonStyle(.press)
                }
            } else {
                Label("Paid in cash, or nothing like it in your bank mail yet. Tap a month below to put in what you paid.", systemImage: "banknote")
                    .font(.footnote).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            }
        }
        .padding(14)
        .background(Color.surface, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
    }
}

/// what one month actually cost
struct RecordInstalment: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    let c: Committee
    let row: CommRow
    @State private var amount = ""
    static func earnedLine(face: Double, paid: Double) -> String {
        let d: Double = face - paid
        let pct: String = Fmt.trim(d / paid * 100, 1)
        return "Earned " + Fmt.rupees(d) + " (" + pct + "%) this month"
    }
    var body: some View {
        NavigationStack {
            Form {
                Section {
                    TextField("Amount paid", text: $amount).keyboardType(.numberPad).font(.title2.weight(.semibold))
                    if let v = TypedAmount.whole(amount), v > 0, v < c.face {
                        Text(Self.earnedLine(face: c.face, paid: v)).foregroundStyle(Color.green)
                    }
                } header: {
                    Text(Day.fmt(row.m + "-01", "MMMM yyyy"))
                } footer: {
                    Text("Face value is " + Fmt.rupees(c.face) + ". In an auction month you pay less: the face value less your share of the discount.")
                }
                Section {
                    Button("Paid the full " + Fmt.rupees(c.face)) { save(c.face) }
                    if row.src == "you" { Button("Clear what I put in", role: .destructive) { store.live?.recordInstalment(c.id, month: row.m, amount: nil); dismiss() } }
                }
            }
            .navigationTitle("What it cost")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") { if let v = TypedAmount.whole(amount) { save(v) } }.disabled(TypedAmount.whole(amount) == nil)
                }
            }
            .onAppear { amount = row.st == "paid" ? String(Int(safe: row.amt)) : "" }
        }
    }
    func save(_ v: Double) {
        store.live?.recordInstalment(c.id, month: row.m, amount: v)
        dismiss()
    }
}
