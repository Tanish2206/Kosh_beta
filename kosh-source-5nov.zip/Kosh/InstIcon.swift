import SwiftUI
import UIKit
import WebKit

// MARK: - Banks' and insurers' own icons
//
// Each bank and insurer publishes an icon on its own website, the one a browser shows beside its
// name. kosh fetches it straight from that website on this phone (no other service sees which
// banks you use), keeps it, and shows it beside the account, card or policy. Where a site has
// none, or you turn icons off in Settings, the bank's colour and initials stand in.

enum InstSites {
    /// the website of each bank, card issuer and insurer, by the names kosh uses for them
    static let sites: [(String, String)] = [
        // insurers first: "HDFC Life" must win over "HDFC"
        ("hdfc life", "hdfclife.com"), ("hdfc ergo", "hdfcergo.com"), ("icici prudential", "iciciprulife.com"), ("icici pru", "iciciprulife.com"),
        ("icici lombard", "icicilombard.com"), ("axis max life", "axismaxlife.com"), ("max life", "axismaxlife.com"), ("sbi life", "sbilife.co.in"),
        ("sbi general", "sbigeneral.in"), ("tata aia", "tataaia.com"), ("tata aig", "tataaig.com"), ("lic", "licindia.in"), ("star health", "starhealth.in"),
        ("niva bupa", "nivabupa.com"), ("care health", "careinsurance.com"), ("bajaj life", "bajajlife.com"), ("bajaj general", "bajajgeneral.com"),
        ("bajaj allianz", "bajajgeneral.com"), ("acko", "acko.com"), ("go digit", "godigit.com"), ("aditya birla", "adityabirlacapital.com"),
        ("kotak life", "kotaklife.com"), ("pnb metlife", "pnbmetlife.com"), ("manipalcigna", "manipalcigna.com"), ("canara hsbc", "canarahsbclife.com"),
        ("sbi card", "sbicard.com"), ("policybazaar", "policybazaar.com"),
        // registrars, depositories and brokers that send statements
        ("cams", "camsonline.com"), ("kfintech", "kfintech.com"), ("kfin", "kfintech.com"), ("nsdl", "nsdl.co.in"), ("cdsl", "cdslindia.com"),
        ("zerodha", "zerodha.com"), ("groww", "groww.in"), ("upstox", "upstox.com"), ("angel one", "angelone.in"), ("dhan", "dhan.co"), ("epf", "epfindia.gov.in"), ("epfo", "epfindia.gov.in"), ("nps", "npstrust.org.in"),
        // banks and cards
        ("state bank", "sbi.bank.in|sbi.co.in"), ("sbi", "sbi.bank.in|sbi.co.in"), ("hdfc", "hdfc.bank.in|hdfcbank.com"), ("icici", "icici.bank.in|icicibank.com"), ("axis", "axis.bank.in|axisbank.com"),
        ("kotak", "kotak.bank.in|kotak.com"), ("indusind", "indusind.bank.in|indusind.com"), ("yes bank", "yes.bank.in|yesbank.in"), ("yes", "yes.bank.in|yesbank.in"), ("idfc", "idfcfirst.bank.in|idfcfirstbank.com"),
        ("au small", "au.bank.in|aubank.in"), ("au bank", "au.bank.in|aubank.in"), ("hsbc", "hsbc.co.in|hsbc.bank.in"), ("federal", "federal.bank.in|federalbank.co.in"), ("pnb", "pnb.bank.in|pnbindia.in"),
        ("punjab national", "pnb.bank.in|pnbindia.in"), ("bank of baroda", "bankofbaroda.bank.in|bankofbaroda.in"), ("baroda", "bankofbaroda.bank.in|bankofbaroda.in"), ("canara", "canarabank.bank.in|canarabank.com"),
        ("union bank", "unionbankofindia.bank.in|unionbankofindia.co.in"), ("idbi", "idbibank.in"), ("rbl", "rbl.bank.in|rblbank.com"), ("standard chartered", "sc.com"),
        ("american express", "americanexpress.com"), ("amex", "americanexpress.com"), ("onecard", "getonecard.app"), ("bandhan", "bandhanbank.com"),
        ("indian bank", "indianbank.in"), ("central bank", "centralbankofindia.co.in"), ("uco", "ucobank.com"), ("iob", "iob.in"),
        ("paytm", "paytm.com"), ("amazon pay", "amazon.in"), ("jupiter", "jupiter.money"), ("scapia", "scapia.cards"),
    ]
    /// India's fund houses (the AMFI list, not anyone's holdings) by the words their scheme names start with:
    /// "Axis Small Cap Fund" is Axis Mutual Fund, not Axis Bank. One kosh can't place gets its initials.
    static let fundHouses: [(String, String)] = [
        ("icici prudential", "icicipruamc.com"), ("icici pru", "icicipruamc.com"), ("aditya birla", "mutualfund.adityabirlacapital.com"),
        ("absl", "mutualfund.adityabirlacapital.com"), ("parag parikh", "amc.ppfas.com"), ("ppfas", "amc.ppfas.com"), ("canara robeco", "canararobeco.com"),
        ("baroda bnp", "barodabnpparibasmf.in"), ("mahindra manulife", "mahindramanulife.com"), ("motilal oswal", "motilaloswalmf.com"),
        ("franklin", "franklintempletonindia.com"), ("mirae", "miraeassetmf.co.in"), ("nippon", "mf.nipponindiaim.com"), ("axis", "axismf.com"),
        ("hdfc", "hdfcfund.com"), ("sbi", "sbimf.com"), ("kotak", "kotakmf.com"), ("uti", "utimf.com"), ("dsp", "dspim.com"), ("quant", "quantmutual.com"),
        ("tata", "tatamutualfund.com"), ("edelweiss", "edelweissmf.com"), ("invesco", "invescomutualfund.com"), ("bandhan", "bandhanmutual.com"),
        ("idfc", "bandhanmutual.com"), ("hsbc", "assetmanagement.hsbc.co.in"), ("pgim", "pgimindiamf.com"), ("sundaram", "sundarammutual.com"),
        ("lic", "licmf.com"), ("navi", "navi.com"), ("zerodha", "zerodhafundhouse.com"), ("groww", "growwmf.in"), ("whiteoak", "mf.whiteoakamc.com"),
        ("jm", "jmfinancialmf.com"), ("union", "unionmf.com"), ("iti", "itiamc.com"), ("quantum", "quantumamc.com"), ("bajaj finserv", "bajajamc.com"),
        ("samco", "samcomf.com"), ("shriram", "shriramamc.in"), ("nj", "njmutualfund.com"), ("trust", "trustmf.com"), ("taurus", "taurusmutualfund.com"),
    ]
    static func fundHouse(for scheme: String) -> String? { match(scheme, in: fundHouses) }
    /// the curated list first (it knows "HDFC Life" from "HDFC"), then India's directory of banks, insurers and wallets
    static func domain(for name: String) -> String? { match(name, in: sites) ?? Directory.shared.site(for: name) }
    private static func match(_ name: String, in list: [(String, String)]) -> String? {
        let n = " " + name.lowercased().replacingOccurrences(of: "[^a-z0-9 ]", with: " ", options: .regularExpression) + " "
        return list.first { n.contains(" " + $0.0 + " ") }?.1
    }
    /// icons on (the default), or each bank's colour and initials only
    static var enabled: Bool { UserDefaults.standard.object(forKey: "kosh.icons") as? Bool ?? true }
}

// MARK: - Listed companies' websites, for share icons
//
// A share's statement gives its name and ISIN, not the company's website. Searching the web for each
// holding would tell a search company what you own, so instead kosh downloads one public list, the same for
// everyone: Indian companies with their official websites, from Wikidata (the open knowledge base behind
// Wikipedia). It's fetched about once a month and nothing about your holdings goes with the request. A share
// is matched by ISIN, or by its name; a company not on the list keeps its initials.

final class CompanySites: @unchecked Sendable {
    static let shared = CompanySites()
    private let lock = NSLock()
    private var names: [String: String] = [:]
    private var isins: [String: String] = [:]
    private var fetched = ""
    private var url: URL { LiveSession.folder.appendingPathComponent("company-sites.json") }
    struct Saved: Codable { var at: String; var names: [String: String]; var isins: [String: String] }

    init() {
        if let d = try? Data(contentsOf: url), let s = try? JSONDecoder().decode(Saved.self, from: d) { names = s.names; isins = s.isins; fetched = s.at }
    }

    /// "ACME TECHNOLOGIES (INDIA) LIMITED" and "Acme Technologies" both read "acme technologies"
    static func key(_ name: String) -> String {
        var s = name.lowercased().replacingOccurrences(of: "&", with: " and ")
        s = s.replacingOccurrences(of: #"#.*$|\bequity shares?\b.*$|\bfv\b.*$"#, with: " ", options: .regularExpression)
        s = s.replacingOccurrences(of: "[^a-z0-9 ]", with: " ", options: .regularExpression)
        s = s.replacingOccurrences(of: #"\b(limited|ltd|pvt|private|the|india|co|company|corporation|corp|inc)\b"#, with: " ", options: .regularExpression)
        return s.split(separator: " ").joined(separator: " ")
    }

    func domain(name: String, isin: String?) -> String? {
        lock.lock(); defer { lock.unlock() }
        if let i = isin, !i.isEmpty, let d = isins[i.uppercased()] { return d }
        let k = Self.key(name)
        return k.count >= 3 ? names[k] : nil
    }

    private func lastFetched() -> String { lock.lock(); defer { lock.unlock() }; return fetched }
    private func keep(_ n: [String: String], _ i: [String: String], _ today: String) { lock.lock(); names = n; isins = i; fetched = today; lock.unlock() }

    /// the list, fetched again when it's a month old
    func refreshIfStale() async {
        let today = LiveSession.today
        let last = lastFetched()
        if !last.isEmpty, let d = Day.parser.date(from: last), Date().timeIntervalSince(d) < 30 * 86400, last <= today { return }
        let q = """
        SELECT ?c (SAMPLE(?label) AS ?name) (SAMPLE(?site) AS ?web) (GROUP_CONCAT(DISTINCT ?isin; separator=" ") AS ?isins) (GROUP_CONCAT(DISTINCT ?alt; separator="|") AS ?alts) WHERE {
          { ?c wdt:P414 wd:Q638740 } UNION { ?c wdt:P414 wd:Q638398 } UNION { ?c wdt:P946 ?i0 . FILTER(STRSTARTS(?i0, "INE")) } UNION { ?c wdt:P31 wd:Q4830453 ; wdt:P17 wd:Q668 } UNION { ?c wdt:P31 wd:Q891723 ; wdt:P17 wd:Q668 }
          ?c wdt:P856 ?site .
          ?c rdfs:label ?label FILTER(LANG(?label) = "en")
          OPTIONAL { ?c wdt:P946 ?isin FILTER(STRSTARTS(?isin, "INE")) }
          OPTIONAL { ?c skos:altLabel ?alt FILTER(LANG(?alt) = "en") }
        } GROUP BY ?c
        """
        var comps = URLComponents(string: "https://query.wikidata.org/sparql")!
        comps.queryItems = [URLQueryItem(name: "format", value: "json"), URLQueryItem(name: "query", value: q)]
        guard let u = comps.url else { return }
        var req = URLRequest(url: u)
        req.timeoutInterval = 60
        req.setValue("application/sparql-results+json", forHTTPHeaderField: "Accept")
        req.setValue("kosh-beta/1.0 (household money app; company icons)", forHTTPHeaderField: "User-Agent")
        struct V: Decodable { let value: String }
        struct B: Decodable { let name: V?; let web: V?; let isins: V?; let alts: V? }
        struct R: Decodable { struct Res: Decodable { let bindings: [B] }; let results: Res }
        guard let (data, resp) = try? await URLSession.shared.data(for: req), (resp as? HTTPURLResponse)?.statusCode == 200,
              let r = try? JSONDecoder().decode(R.self, from: data) else { return }
        var n: [String: String] = [:], i: [String: String] = [:]
        for b in r.results.bindings {
            guard let web = b.web?.value, let host = URL(string: web)?.host?.lowercased() else { continue }
            let d = host.hasPrefix("www.") ? String(host.dropFirst(4)) : host
            for nm in [b.name?.value ?? ""] + (b.alts?.value ?? "").split(separator: "|").map(String.init) {
                let k = Self.key(nm)
                if k.count >= 3 && n[k] == nil { n[k] = d }
            }
            for x in (b.isins?.value ?? "").split(separator: " ") where x.count == 12 { i[String(x)] = d }
        }
        guard n.count > 50 else { return }
        keep(n, i, today)
        if let d = try? JSONEncoder().encode(Saved(at: today, names: n, isins: i)) { try? d.write(to: url, options: .atomic) }
    }
}

actor IconStore {
    static let shared = IconStore()
    private var mem: [String: UIImage] = [:]
    private var tried: Set<String> = []
    private var running: [String: Task<UIImage?, Never>] = [:]
    /// apps' icons (AppIcons): kept in memory, and the ones being fetched
    var appMem: [String: UIImage] = [:]
    var appRunning: [String: Task<UIImage?, Never>] = [:]

    private var folder: URL {
        // "icons2": the sharp ones; the first set kept small favicons, stretched
        let f = LiveSession.folder.appendingPathComponent("icons2", isDirectory: true)
        try? FileManager.default.createDirectory(at: f, withIntermediateDirectories: true)
        return f
    }

    func icon(domain: String) async -> UIImage? {
        if let m = mem[domain] { return m }
        let name = domain.replacingOccurrences(of: "|", with: "+")
        let file = folder.appendingPathComponent(name + ".png")
        if let d = try? Data(contentsOf: file), let img = UIImage(data: d) { mem[domain] = img; return img }
        // a site that had none (or couldn't be reached) is asked again the next day
        let miss = folder.appendingPathComponent(name + ".none")
        if let a = try? FileManager.default.attributesOfItem(atPath: miss.path), let t = a[.modificationDate] as? Date, Date().timeIntervalSince(t) < 86400 { return nil }
        if tried.contains(domain) { return nil }
        if let r = running[domain] { return await r.value }
        let task = Task<UIImage?, Never> { await Self.fetch(domain) }
        running[domain] = task
        let img = await task.value
        running[domain] = nil
        tried.insert(domain)
        if let img, let png = img.pngData() {
            try? png.write(to: file, options: .atomic)
            mem[domain] = img
        } else {
            try? Data().write(to: miss)
        }
        return img
    }

    /// the first of a bank's sites (its new .bank.in address, then its old one) that gives an icon; a site
    /// that turns plain requests away is opened the way Safari opens it, on this phone, and its icon read off the page
    static func fetch(_ sites: String) async -> UIImage? {
        let list = sites.split(separator: "|").map(String.init)
        for d in list {
            if let img = await fetchOne(d) { return img }
        }
        for d in list {
            if let img = await WebIcon.fetch(d) { return img }
        }
        return nil
    }

    /// the sharpest icon a site publishes: a big PNG (its home-screen icon, an icon its page links with
    /// its size, or one from its web-app manifest), else its vector logo drawn at full size. A favicon
    /// too small to be sharp is never stretched: the bank's initials stand in instead.
    static let sharp: CGFloat = 96
    static func fetchOne(_ domain: String) async -> UIImage? {
        for host in [domain, "www." + domain] {
            for path in ["apple-touch-icon.png", "apple-touch-icon-precomposed.png"] {
                if let img = await image(at: "https://\(host)/\(path)"), px(img) >= sharp { return img }
            }
        }
        for host in ["www." + domain, domain] {
            guard let url = URL(string: "https://\(host)/"), let (data, resp) = try? await session.data(for: request(url)),
                  let html = String(data: data.prefix(600_000), encoding: .utf8) ?? String(data: data.prefix(600_000), encoding: .isoLatin1) else { continue }
            let base = resp.url ?? url
            var cands = links(in: html).compactMap { c -> (URL, Int, Bool)? in
                guard let u = URL(string: c.0, relativeTo: base)?.absoluteURL else { return nil }
                return (u, c.1, c.2)
            }
            if let mhref = manifestLink(in: html), let murl = URL(string: mhref, relativeTo: base)?.absoluteURL {
                cands += await manifestIcons(murl)
            }
            // biggest first; vector logos after every PNG big enough
            for c in cands.filter({ !$0.2 }).sorted(by: { $0.1 > $1.1 }) {
                if let img = await image(at: c.0.absoluteString), px(img) >= sharp { return img }
            }
            for c in cands.filter({ $0.2 }) {
                if let d = await bytes(at: c.0.absoluteString), let img = await SVGRaster.render(d, size: 180) { return img }
            }
            break
        }
        return nil
    }
    static func px(_ img: UIImage) -> CGFloat { min(img.size.width, img.size.height) * img.scale }

    /// icon links on a page with their declared size, and whether each is a vector logo
    static func links(in html: String) -> [(String, Int, Bool)] {
        guard let re = try? NSRegularExpression(pattern: "<link[^>]+>", options: [.caseInsensitive]) else { return [] }
        var found: [(String, Int, Bool)] = []
        for m in re.matches(in: html, range: NSRange(html.startIndex..., in: html)) {
            guard let r = Range(m.range, in: html) else { continue }
            let tag = String(html[r])
            let low = tag.lowercased()
            guard let rel = attr("rel", in: tag)?.lowercased(), rel.contains("icon"), let href = attr("href", in: tag) else { continue }
            let svg = low.contains(".svg") || low.contains("image/svg")
            var size = rel.contains("apple-touch-icon") ? 180 : 0
            if let sizes = attr("sizes", in: tag)?.lowercased() {
                size = sizes == "any" ? 1024 : sizes.split(separator: " ").compactMap { Int($0.split(separator: "x").first ?? "") }.max() ?? size
            }
            found.append((href, size, svg))
        }
        return found
    }
    static func manifestLink(in html: String) -> String? {
        guard let re = try? NSRegularExpression(pattern: "<link[^>]+rel=[\"']manifest[\"'][^>]*>", options: [.caseInsensitive]),
              let m = re.firstMatch(in: html, range: NSRange(html.startIndex..., in: html)), let r = Range(m.range, in: html) else { return nil }
        return attr("href", in: String(html[r]))
    }
    /// a web-app manifest's icons: these are usually 192 and 512 pixels
    static func manifestIcons(_ url: URL) async -> [(URL, Int, Bool)] {
        guard let (data, _) = try? await session.data(for: request(url)),
              let o = try? JSONSerialization.jsonObject(with: data) as? [String: Any], let icons = o["icons"] as? [[String: Any]] else { return [] }
        return icons.compactMap { i in
            guard let src = i["src"] as? String, let u = URL(string: src, relativeTo: url)?.absoluteURL else { return nil }
            let sizes = (i["sizes"] as? String ?? "").lowercased()
            let n = sizes == "any" ? 1024 : sizes.split(separator: " ").compactMap { Int($0.split(separator: "x").first ?? "") }.max() ?? 0
            let svg = (i["type"] as? String ?? "").contains("svg") || src.lowercased().contains(".svg")
            return (u, n, svg)
        }
    }
    static func attr(_ name: String, in tag: String) -> String? {
        guard let re = try? NSRegularExpression(pattern: name + "\\s*=\\s*[\"']([^\"']+)[\"']", options: [.caseInsensitive]),
              let m = re.firstMatch(in: tag, range: NSRange(tag.startIndex..., in: tag)), let r = Range(m.range(at: 1), in: tag) else { return nil }
        return String(tag[r]).replacingOccurrences(of: "&amp;", with: "&")
    }

    static let session: URLSession = {
        let c = URLSessionConfiguration.ephemeral
        c.timeoutIntervalForRequest = 8
        c.httpCookieStorage = nil
        return URLSession(configuration: c)
    }()
    static func request(_ url: URL) -> URLRequest {
        var r = URLRequest(url: url)
        r.setValue("Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1", forHTTPHeaderField: "User-Agent")
        return r
    }
    static func bytes(at s: String) async -> Data? {
        guard let url = URL(string: s), let (data, resp) = try? await session.data(for: request(url)),
              let http = resp as? HTTPURLResponse, http.statusCode == 200, data.count > 50, data.count < 2_000_000 else { return nil }
        return data
    }
    static func image(at s: String) async -> UIImage? {
        guard let url = URL(string: s), let (data, resp) = try? await session.data(for: request(url)),
              let http = resp as? HTTPURLResponse, http.statusCode == 200, data.count > 100, data.count < 2_000_000 else { return nil }
        return UIImage(data: data)
    }
}

/// Which institutions have an icon of their own, so a list can show icons for all of them or marks for
/// all of them: a column where some banks have their logo and the rest their initials reads as broken.
@MainActor @Observable
final class IconBook {
    static let shared = IconBook()
    private(set) var have: Set<String> = []
    private(set) var lacking: Set<String> = []
    func note(_ domain: String, _ ok: Bool) {
        if ok { if !have.contains(domain) { have.insert(domain) }; lacking.remove(domain) }
        else if !lacking.contains(domain) { lacking.insert(domain) }
    }
    /// every one of these (name, and words to find its website by) has its own icon
    func all(_ names: [(String, String)]) -> Bool {
        guard InstSites.enabled, !names.isEmpty else { return false }
        for (n, h) in names {
            guard let d = InstSites.domain(for: n) ?? InstSites.domain(for: h), have.contains(d) else { return false }
        }
        return true
    }
}

/// A site that turns away plain requests (most banks sit behind a bot check) is opened the way Safari
/// opens it, in a page no one sees, on this phone; its icon links are read off the page and the biggest
/// one drawn out of it. One site at a time, nothing kept but the icon.
@MainActor
enum WebIcon {
    private static var busy = false
    final class Nav: NSObject, WKNavigationDelegate {
        var done: CheckedContinuation<Bool, Never>?
        var status = 200
        func finish(_ ok: Bool) { done?.resume(returning: ok); done = nil }
        func webView(_ w: WKWebView, decidePolicyFor r: WKNavigationResponse) async -> WKNavigationResponsePolicy {
            if let h = r.response as? HTTPURLResponse, r.isForMainFrame { status = h.statusCode }
            return .allow
        }
        func webView(_ w: WKWebView, didFinish n: WKNavigation!) { finish(status < 400) }
        func webView(_ w: WKWebView, didFail n: WKNavigation!, withError e: Error) { finish(false) }
        func webView(_ w: WKWebView, didFailProvisionalNavigation n: WKNavigation!, withError e: Error) { finish(false) }
    }
    static func load(_ web: WKWebView, _ url: URL, timeout: Double) async -> Bool {
        let nav = Nav()
        web.navigationDelegate = nav
        let ok = await withCheckedContinuation { (c: CheckedContinuation<Bool, Never>) in
            nav.done = c
            web.load(URLRequest(url: url))
            DispatchQueue.main.asyncAfter(deadline: .now() + timeout) { nav.finish(false) }
        }
        web.navigationDelegate = nil
        return ok
    }
    static func fetch(_ domain: String) async -> UIImage? {
        while busy { try? await Task.sleep(for: .milliseconds(400)) }
        busy = true
        defer { busy = false }
        let cfg = WKWebViewConfiguration()
        cfg.websiteDataStore = .nonPersistent()
        cfg.mediaTypesRequiringUserActionForPlayback = .all
        let web = WKWebView(frame: CGRect(x: -4000, y: -4000, width: 390, height: 800), configuration: cfg)
        let window = UIApplication.shared.connectedScenes.compactMap { ($0 as? UIWindowScene)?.keyWindow }.first
        window?.addSubview(web)
        defer { web.stopLoading(); web.removeFromSuperview() }
        var home = false
        for host in ["www." + domain, domain] {
            if let u = URL(string: "https://\(host)/"), await load(web, u, timeout: 15) { home = true; break }
        }
        guard home else { return nil }
        let list = """
        (() => { const out = []; document.querySelectorAll('link[rel*="icon"]').forEach(l => { const s = parseInt((l.getAttribute('sizes') || '').split(/[x ]/i)[0]) || 0; out.push([l.href, /apple/i.test(l.rel) ? Math.max(s, 180) : (s || (/\\.svg/i.test(l.href) ? 1024 : 0))]); }); return JSON.stringify(out); })()
        """
        var cands: [(String, Int)] = []
        if let raw = try? await web.evaluateJavaScript(list) as? String, let data = raw.data(using: .utf8),
           let arr = try? JSONSerialization.jsonObject(with: data) as? [[Any]] {
            cands = arr.compactMap { (a: [Any]) -> (String, Int)? in
                guard a.count == 2, let h = a[0] as? String else { return nil }
                let n: Int = (a[1] as? NSNumber)?.intValue ?? 0
                return (h, n)
            }
        }
        cands.sort { $0.1 > $1.1 }
        cands.append(("https://www.\(domain)/apple-touch-icon.png", 180))
        let draw = "(() => { const i = document.images[0]; if (!i || !i.naturalWidth) return ''; const c = document.createElement('canvas'); c.width = i.naturalWidth; c.height = i.naturalHeight; c.getContext('2d').drawImage(i, 0, 0); return c.toDataURL('image/png'); })()"
        var tried = Set<String>()
        for (href, _) in cands where !tried.contains(href) && tried.count < 4 {
            tried.insert(href)
            guard let u = URL(string: href), await load(web, u, timeout: 10) else { continue }
            if href.lowercased().contains(".svg") {
                if let svg = try? await web.evaluateJavaScript("new XMLSerializer().serializeToString(document.documentElement)") as? String,
                   let img = await SVGRaster.render(Data(svg.utf8), size: 180) { return img }
                continue
            }
            if let url = try? await web.evaluateJavaScript(draw) as? String, let comma = url.firstIndex(of: ","),
               let d = Data(base64Encoded: String(url[url.index(after: comma)...])), let img = UIImage(data: d), IconStore.px(img) >= IconStore.sharp {
                return img
            }
        }
        return nil
    }
}

/// a bank's, card issuer's or insurer's icon, or its colour and initials while there's none
struct InstIcon: View {
    let name: String
    let color: Color
    var size: CGFloat = 36
    /// more words to find the website by, when the name alone doesn't say (an account's own name, say)
    var hint: String = ""
    /// on a coloured card: while there's no icon, a frosted tile with the initials rather than the bank's colour
    var glass: Bool = false
    /// the website to ask, when the name would find the wrong one (a fund house, say)
    var site: String? = nil
    /// while there's no icon, quiet grey initials rather than the bank's colour
    var plain: Bool = false
    /// the mark even when there's an icon: the list it's in shows marks for everyone
    var mark: Bool = false
    @AppStorage("kosh.icons") private var on = true
    @State private var img: UIImage?

    var body: some View {
        Group {
            if on, !mark, let img {
                Image(uiImage: img)
                    .resizable()
                    .interpolation(.high)
                    .scaledToFit()
                    .padding(size * 0.14)
                    .frame(width: size, height: size)
                    .background(Color.white, in: RoundedRectangle(cornerRadius: size * 0.28, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: size * 0.28, style: .continuous).stroke(Color.black.opacity(0.08), lineWidth: 0.5))
            } else if plain {
                Monogram(name: name, size: size)
            } else if glass {
                Text(BankBadge(bank: name, color: color).mark)
                    .font(.system(size: size * 0.3, weight: .heavy, design: .rounded))
                    .foregroundStyle(.white)
                    .frame(width: size, height: size)
                    .background(Color.white.opacity(0.18), in: RoundedRectangle(cornerRadius: size * 0.28, style: .continuous))
            } else {
                BankBadge(bank: name, color: color, size: size)
            }
        }
        .task(id: name + "|" + hint + "|" + (site ?? "") + (on ? "|on" : "")) {
            guard on, let d = site ?? InstSites.domain(for: name) ?? InstSites.domain(for: hint) else { img = nil; return }
            let got = await IconStore.shared.icon(domain: d)
            IconBook.shared.note(d, got != nil)
            withAnimation(Motion.base) { img = got }
        }
        .accessibilityHidden(true)
    }
}

/// a name's initials on a quiet grey tile, the way Contacts shows someone without a photo: rows of
/// shares stay easy to tell apart without a column of identical icons
struct Monogram: View {
    let name: String
    var size: CGFloat = 36
    static let filler: Set<String> = ["the", "of", "and", "india", "indian", "limited", "ltd", "co", "company", "corporation", "corp",
                                      "fund", "direct", "regular", "growth", "plan", "option", "idcw", "dividend", "scheme", "mutual"]
    static func letters(_ s: String) -> String {
        let words = s.split(whereSeparator: { !$0.isLetter && !$0.isNumber }).map(String.init)
        let kept = words.filter { !filler.contains($0.lowercased()) && !$0.allSatisfy(\.isNumber) }
        let w = kept.isEmpty ? words : kept
        guard let first = w.first else { return "·" }
        // a name that is itself letters in capitals keeps them (ITC, HDFC, NTPC)
        if first.count >= 2 && first.count <= 4 && first == first.uppercased() && first.allSatisfy(\.isLetter) { return first }
        return w.prefix(2).compactMap { $0.first.map { String($0).uppercased() } }.joined()
    }
    var body: some View {
        let l = Self.letters(name)
        Text(l)
            .font(.system(size: size * (l.count > 2 ? 0.27 : 0.36), weight: .semibold, design: .rounded))
            .foregroundStyle(.secondary)
            .lineLimit(1)
            .minimumScaleFactor(0.6)
            .frame(width: size, height: size)
            .background(Color(.tertiarySystemFill), in: RoundedRectangle(cornerRadius: size * 0.28, style: .continuous))
            .accessibilityHidden(true)
    }
}

extension View {
    /// a small round mark on an icon's corner: the kind of cover, a lock, a tick
    func cornerMark(_ symbol: String, color: Color, size: CGFloat) -> some View {
        overlay(alignment: .bottomTrailing) {
            Image(systemName: symbol)
                .font(.system(size: size * 0.24, weight: .bold))
                .foregroundStyle(.white)
                .frame(width: size * 0.46, height: size * 0.46)
                .background(color, in: Circle())
                .overlay(Circle().stroke(Color(.systemBackground), lineWidth: max(1.5, size * 0.04)))
                .offset(x: size * 0.12, y: size * 0.12)
        }
        .padding(.trailing, size * 0.1)
    }
}

/// A vector logo drawn at full size, once, so it's sharp at any size kosh shows it. Drawn by WebKit off
/// screen (UIKit can't read SVG); what it draws is kept as a PNG like any other icon.
@MainActor
enum SVGRaster {
    final class Loaded: NSObject, WKNavigationDelegate {
        var done: CheckedContinuation<Void, Never>?
        func finish() { done?.resume(); done = nil }
        func webView(_ w: WKWebView, didFinish n: WKNavigation!) { finish() }
        func webView(_ w: WKWebView, didFail n: WKNavigation!, withError e: Error) { finish() }
        func webView(_ w: WKWebView, didFailProvisionalNavigation n: WKNavigation!, withError e: Error) { finish() }
    }
    static func render(_ data: Data, size: CGFloat) async -> UIImage? {
        guard let text = String(data: data.prefix(4000), encoding: .utf8), text.lowercased().contains("<svg") else { return nil }
        let cfg = WKWebViewConfiguration()
        cfg.websiteDataStore = .nonPersistent()
        let web = WKWebView(frame: CGRect(x: -2000, y: -2000, width: size, height: size), configuration: cfg)
        web.isOpaque = false
        web.backgroundColor = .clear
        web.scrollView.backgroundColor = .clear
        web.scrollView.isScrollEnabled = false
        // a snapshot needs a window; the view sits far off screen, invisible
        let window = UIApplication.shared.connectedScenes.compactMap { ($0 as? UIWindowScene)?.keyWindow }.first
        window?.addSubview(web)
        defer { web.removeFromSuperview() }
        let n = Int(size)
        let html = "<html><head><meta name=viewport content='width=\(n),initial-scale=1'><style>html,body{margin:0;background:transparent}img{width:\(n)px;height:\(n)px;object-fit:contain;display:block}</style></head><body><img src='data:image/svg+xml;base64,\(data.base64EncodedString())'></body></html>"
        let loaded = Loaded()
        web.navigationDelegate = loaded
        await withCheckedContinuation { (c: CheckedContinuation<Void, Never>) in
            loaded.done = c
            web.loadHTMLString(html, baseURL: nil)
            DispatchQueue.main.asyncAfter(deadline: .now() + 5) { loaded.finish() }
        }
        try? await Task.sleep(for: .milliseconds(200))
        let snap = WKSnapshotConfiguration()
        snap.rect = CGRect(x: 0, y: 0, width: size, height: size)
        snap.snapshotWidth = NSNumber(value: Double(size))
        guard let img = try? await web.takeSnapshot(configuration: snap) else { return nil }
        // a blank drawing (the logo didn't load) is no logo
        return Self.blank(img) ? nil : img
    }
    static func blank(_ img: UIImage) -> Bool {
        guard let cg = img.cgImage, let d = cg.dataProvider?.data, let p = CFDataGetBytePtr(d) else { return true }
        let n = CFDataGetLength(d)
        var i = 0, inked = 0
        while i + 3 < n { if p[i + 3] > 16 && (p[i] < 235 || p[i + 1] < 235 || p[i + 2] < 235) { inked += 1 }; i += 4 * 7 }
        return inked < 20
    }
}

// MARK: - Apps' own icons, for the apps and stores you shop in
//
// A shopping or travel app's home-screen icon is what people know it by, and the App Store has every one at the same
// size and shape. Every app kosh can name a payment by (engine.js › PLATFORMS) comes with its App Store id, and kosh
// asks Apple for all of them in one request: the same list for everyone, so the asking says nothing about where you
// shop. An app added to the list without an id is found by its name in the App Store search (the same for everyone
// too); then its website's icon; then its initials. What's found is kept on this phone; what isn't is asked again the
// next day, so an icon that was missing turns up on its own. engine-test/ledger.js checks every app on the list has
// an id or a website.

enum AppIcons {
    struct App { let name: String; let site: String; let id: String }
    /// the list, from the engine: the same for everyone
    static let apps: [String: App] = {
        guard let s = try? Engine.shared.call("platformSites", []), let d = s.data(using: .utf8),
              let o = try? JSONSerialization.jsonObject(with: d) as? [String: [String: String]] else { return [:] }
        var out: [String: App] = [:]
        for (k, v) in o { out[k] = App(name: k, site: v["site"] ?? "", id: v["app"] ?? "") }
        return out
    }()
    /// apps by the same company that mustn't be taken for the one (the driver's app, the seller's app)
    static let notTheApp = try? NSRegularExpression(pattern: "partner|seller|supplier|driver|captain|merchant|business|delivery|fleet|restaurant|wholesale", options: .caseInsensitive)

    static func results(_ url: URL) async -> [[String: Any]] {
        guard let (d, r) = try? await IconStore.session.data(for: URLRequest(url: url)), (r as? HTTPURLResponse)?.statusCode == 200,
              let o = try? JSONSerialization.jsonObject(with: d) as? [String: Any] else { return [] }
        return o["results"] as? [[String: Any]] ?? []
    }
    static func art(_ x: [String: Any]) -> String? { (x["artworkUrl512"] as? String) ?? (x["artworkUrl100"] as? String) }

    /// every app with an id, in one request: trackId → its icon's address
    static func lookup(_ ids: [String]) async -> [String: String] {
        guard !ids.isEmpty else { return [:] }
        var c = URLComponents(string: "https://itunes.apple.com/lookup")!
        c.queryItems = [URLQueryItem(name: "id", value: ids.joined(separator: ",")), URLQueryItem(name: "country", value: "in"), URLQueryItem(name: "entity", value: "software")]
        guard let u = c.url else { return [:] }
        var out: [String: String] = [:]
        for x in await results(u) {
            if let tid = (x["trackId"] as? Int).map(String.init) ?? (x["trackId"] as? String), let a = art(x) { out[tid] = a }
        }
        return out
    }

    /// an app with no id: the App Store's search by its name, the first result whose name starts with the app's own
    /// first word and isn't one of the company's other apps
    static func search(_ name: String) async -> String? {
        var c = URLComponents(string: "https://itunes.apple.com/search")!
        c.queryItems = [URLQueryItem(name: "term", value: name), URLQueryItem(name: "country", value: "in"),
                        URLQueryItem(name: "entity", value: "software"), URLQueryItem(name: "limit", value: "10")]
        guard let u = c.url else { return nil }
        let word = name.lowercased().split(whereSeparator: { !$0.isLetter && !$0.isNumber }).first.map(String.init) ?? ""
        guard word.count >= 2 else { return nil }
        for x in await results(u) {
            let t = ((x["trackName"] as? String) ?? "").lowercased()
            let first = t.split(whereSeparator: { !$0.isLetter && !$0.isNumber }).first.map(String.init) ?? ""
            guard first == word || t.hasPrefix(word) else { continue }
            if let re = notTheApp, re.firstMatch(in: t, range: NSRange(t.startIndex..., in: t)) != nil { continue }
            if let a = art(x) { return a }
        }
        return nil
    }

    /// every app on the list: those with an id in one request, the rest by name a little apart. Once, then kept.
    static func warmAll() async {
        let all = apps.values.sorted { $0.name < $1.name }
        var missing: [App] = []
        for a in all {
            if await IconStore.shared.hasApp(a.name) { continue }
            missing.append(a)
        }
        guard !missing.isEmpty else { return }
        let arts = await lookup(missing.compactMap { $0.id.isEmpty ? nil : $0.id })
        for a in missing {
            if let url = arts[a.id] { await IconStore.shared.keepApp(a.name, from: url); continue }
            if a.id.isEmpty, let url = await search(a.name) { await IconStore.shared.keepApp(a.name, from: url); try? await Task.sleep(for: .seconds(3)); continue }
            await IconStore.shared.missApp(a.name)
        }
    }
}

extension IconStore {
    private func appFile(_ name: String) -> (URL, URL) {
        let key = "app2-" + name.lowercased().filter { $0.isLetter || $0.isNumber }
        let f = LiveSession.folder.appendingPathComponent("icons2", isDirectory: true)
        try? FileManager.default.createDirectory(at: f, withIntermediateDirectories: true)
        return (f.appendingPathComponent(key + ".png"), f.appendingPathComponent(key + ".none"))
    }
    func hasApp(_ name: String) -> Bool {
        let (file, miss) = appFile(name)
        if FileManager.default.fileExists(atPath: file.path) { return true }
        if let a = try? FileManager.default.attributesOfItem(atPath: miss.path), let t = a[.modificationDate] as? Date, Date().timeIntervalSince(t) < 86400 { return true }
        return false
    }
    func keepApp(_ name: String, from url: String) async {
        guard let img = await IconStore.image(at: url), let png = img.pngData() else { missApp(name); return }
        try? png.write(to: appFile(name).0, options: .atomic)
        appMem[name] = img
    }
    func missApp(_ name: String) { try? Data().write(to: appFile(name).1) }
    /// an app's icon: kept, or found now (its id, else its name), else nothing until tomorrow
    func appIcon(_ name: String) async -> UIImage? {
        if let m = appMem[name] { return m }
        let (file, miss) = appFile(name)
        if let d = try? Data(contentsOf: file), let img = UIImage(data: d) { appMem[name] = img; return img }
        if let at = try? FileManager.default.attributesOfItem(atPath: miss.path), let t = at[.modificationDate] as? Date, Date().timeIntervalSince(t) < 86400 { return nil }
        guard let a = AppIcons.apps[name] else { return nil }
        if let r = appRunning[name] { return await r.value }
        let task = Task<UIImage?, Never> {
            let url: String? = a.id.isEmpty ? await AppIcons.search(a.name) : (await AppIcons.lookup([a.id]))[a.id]
            guard let url, let img = await IconStore.image(at: url) else { return nil }
            return img
        }
        appRunning[name] = task
        let img = await task.value
        appRunning[name] = nil
        if let img, let png = img.pngData() { try? png.write(to: file, options: .atomic); appMem[name] = img } else { missApp(name) }
        return img
    }
}

/// An app or store's mark: its App Store icon, else its website's, else its initials
struct AppMark: View {
    let name: String
    /// its website, for the fallback icon (the list's own when not given)
    var site: String? = nil
    var size: CGFloat = 38
    @AppStorage("kosh.icons") private var on = true
    @State private var img: UIImage?
    @State private var looked = false

    var body: some View {
        Group {
            if on, let img {
                Image(uiImage: img)
                    .resizable()
                    .interpolation(.high)
                    .scaledToFill()
                    .frame(width: size, height: size)
                    .clipShape(RoundedRectangle(cornerRadius: size * 0.24, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: size * 0.24, style: .continuous).stroke(Color.primary.opacity(0.08), lineWidth: 0.5))
            } else if looked || !on {
                InstIcon(name: name, color: Color(uiColor: .systemGray3), size: size, site: site ?? AppIcons.apps[name].map(\.site), plain: true)
            } else {
                RoundedRectangle(cornerRadius: size * 0.24, style: .continuous).fill(Color(.tertiarySystemFill)).frame(width: size, height: size)
            }
        }
        .task(id: name + (on ? "|on" : "")) {
            guard on else { return }
            let got = await IconStore.shared.appIcon(name)
            withAnimation(Motion.base) { img = got; looked = true }
        }
        .accessibilityHidden(true)
    }
}
