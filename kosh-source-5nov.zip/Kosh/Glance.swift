import SwiftUI

// MARK: - A month's figure, and the months around today

struct MonthAmount: Identifiable, Hashable {
    let m: String          // yyyy-MM
    let short: String      // "Oct"
    let v: Double
    var note: String = ""
    var id: String { m }
}

enum MonthsAround {
    /// "yyyy-MM" for the month `n` months after the one `today` sits in
    static func key(_ today: String, _ n: Int) -> String {
        let start = Day.date(String(today.prefix(7)) + "-01")
        let d = Day.cal.date(byAdding: .month, value: n, to: start) ?? start
        return String(Day.parser.string(from: d).prefix(7))
    }
    static func short(_ m: String) -> String { Day.fmt(m + "-01", "MMM") }
    /// the last `count` months up to this one, oldest first
    static func past(_ today: String, _ count: Int) -> [String] { (0..<count).map { key(today, $0 - count + 1) } }
    /// this month and the `count - 1` after it
    static func ahead(_ today: String, _ count: Int) -> [String] { (0..<count).map { key(today, $0) } }
}

/// one thing worth knowing, with the figure behind it
struct SmartNote: Identifiable, Hashable {
    let id: String
    let sym: String
    let color: Color
    let text: String
}

struct SmartNotes: View {
    let notes: [SmartNote]
    var body: some View {
        if !notes.isEmpty {
            VStack(alignment: .leading, spacing: 0) {
                ForEach(Array(notes.enumerated()), id: \.element.id) { i, n in
                    if i > 0 { Divider().padding(.leading, 50) }
                    HStack(alignment: .top, spacing: 12) {
                        Image(systemName: n.sym)
                            .font(.system(size: 15, weight: .semibold))
                            .foregroundStyle(n.color)
                            .frame(width: 26, height: 26)
                            .background(n.color.opacity(0.13), in: Circle())
                        Text(n.text).font(.subheadline).fixedSize(horizontal: false, vertical: true).privacySensitive()
                        Spacer(minLength: 0)
                    }
                    .padding(.vertical, 11)
                    .padding(.horizontal, 14)
                }
            }
            .background(CardFill(), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        }
    }
}

// MARK: - Insurance, at a glance

enum PremiumPlan {
    /// months between premiums, from how the policy says it's paid
    static func step(_ p: Policy) -> Int {
        let f = (p.frequency ?? "").lowercased()
        if f.contains("month") { return 1 }
        if f.contains("quarter") { return 3 }
        if f.contains("half") { return 6 }
        if f.contains("single") { return 0 }
        return 12
    }
    /// what falls due in each of the next 12 months
    static func ahead(_ pols: [Policy], today: String) -> [MonthAmount] {
        let keys = MonthsAround.ahead(today, 12)
        var sums: [String: Double] = [:]
        var who: [String: [String]] = [:]
        for p in pols where p.premium > 0 && !p.nextDue.isEmpty {
            let step = step(p)
            guard step > 0 else { continue }
            // (the premium is each instalment)
            let each = p.premium
            var m = String(p.nextDue.prefix(7))
            // an overdue premium shows in this month; then every `step` months after
            var guardN = 0
            if m < keys[0] && p.status == "overdue" { m = keys[0] }
            while m < keys[0] && guardN < 400 { m = MonthsAround.key(m + "-01", step); guardN += 1 }
            while m <= keys[keys.count - 1] {
                sums[m, default: 0] += each
                who[m, default: []].append(p.insurer)
                m = MonthsAround.key(m + "-01", step)
            }
        }
        return keys.map { k in
            let names = who[k] ?? []
            let note = names.count == 1 ? names[0] : names.count > 1 ? "\(names.count) policies" : ""
            return MonthAmount(m: k, short: MonthsAround.short(k), v: sums[k] ?? 0, note: note)
        }
    }
}

// MARK: - Home, at a glance: four figures that matter this week

/// a small figure with a word on what it means, for the grids of smart tiles
struct GlanceTile: View {
    let sym: String
    let color: Color
    let label: String
    let value: String
    var sub: String = ""
    var tone: Color? = nil
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(spacing: 6) {
                Image(systemName: sym).font(.footnote.weight(.semibold)).foregroundStyle(color)
                Text(label).font(.caption.weight(.semibold)).foregroundStyle(.secondary).lineLimit(1)
            }
            Text(value)
                .font(.system(.title2, design: .rounded, weight: .bold))
                .foregroundStyle(tone ?? Color.primary)
                .lineLimit(1)
                .minimumScaleFactor(0.6)
                .privacySensitive()
            if !sub.isEmpty {
                Text(sub).font(.caption).foregroundStyle(.secondary).lineLimit(2).fixedSize(horizontal: false, vertical: true)
            }
            Spacer(minLength: 0)
        }
        .padding(14)
        .frame(maxWidth: .infinity, minHeight: 112, alignment: .topLeading)
        .background(CardFill(), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
    }
}
