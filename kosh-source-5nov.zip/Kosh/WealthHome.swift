import SwiftUI

// MARK: - Wealth: net worth, what it's in, what's coming back, everything owned (W1)
//
// The mockup "kosh · Wealth (Obsidian)", W1. One figure big; the line under it you can drag across; one split bar and a
// tile a kind (each opens its Holdings tab); the map of everything owned and how concentrated it is (WealthMap.swift,
// since 1 Nov, in place of the ranked bars); deposits coming back soon. Every figure is one the build already made
// (Store+Wealth.swift says whose); a part with nothing real to show isn't drawn.

struct WealthHome: View {
    @Environment(Store.self) private var store
    @Environment(\.accessibilityReduceMotion) private var still

    var body: some View {
        let p: Person = store.who
        ScrollView {
            VStack(alignment: .leading, spacing: 38) {
                WealthHead(p: p)
                if store.live != nil {
                    // a missing or locked fund statement says so once (CASFailsafe.swift)
                    CASGapCard { EmptyView() }
                }
                WealthKinds(p: p)
                // the map of everything owned, and how concentrated it is (WealthMap.swift): in place of the ranked bars
                WealthMapCard(p: p)
                WealthSpreadCard(p: p)
                WealthComingBack(p: p)
                WealthElsewhere(p: p)
            }
            .padding(.horizontal, 20)
            .padding(.top, 8)
            .padding(.bottom, 40)
            .animation(still ? nil : Motion.base, value: store.who)
        }
        .scrollIndicators(.hidden)
    }
}

// MARK: the figure and its line

struct WealthHead: View {
    @Environment(Store.self) private var store
    let p: Person
    @State private var range: Int = 12
    @State private var pick: Int? = nil

    static let ranges: [(Int, String)] = [(6, "6M"), (12, "1Y"), (36, "3Y")]

    /// the ranges the line truly reaches back to; none when it's shorter than six months
    static func reachable(_ pts: [NWPoint]) -> [Int] {
        guard let first = pts.first else { return [] }
        return ranges.map(\.0).filter { (r: Int) -> Bool in
            guard let open = NetWorthTrend.opening(pts, range: r) else { return false }
            return first.m <= open
        }
    }

    var body: some View {
        let all: [NWPoint] = store.worthSeries(p)
        let can: [Int] = Self.reachable(all)
        let r: Int = can.contains(range) ? range : (can.filter { $0 <= 12 }.last ?? can.first ?? 0)
        let pts: [NWPoint] = r > 0 ? NetWorthTrend.window(all, range: r) : all
        let net: Double = store.netWorth(p)
        let up: Bool = (pts.last?.v ?? 0) >= (pts.first?.v ?? 0)
        let color: Color = up ? Obsidian.health : Color(hex: "#FF7A7A")
        VStack(alignment: .leading, spacing: 0) {
            // whose money, a dropdown on the title's line (1 Nov: the segments under it took a line of their own)
            HStack(alignment: .center, spacing: 12) {
                Text("Net worth")
                    .font(.system(size: 30, weight: .semibold))
                    .tracking(-0.7)
                    .foregroundStyle(Obsidian.ink)
                    .accessibilityAddTraits(.isHeader)
                Spacer(minLength: 8)
                WhoseMenu()
            }
            Text("Today · " + Day.fmt(store.snap.today, "d MMM yyyy"))
                .caption()
                .padding(.top, 12)
            WealthFigure(value: net, signed: true)
                .padding(.top, 8)
            if let line = Self.change(pts, net: net, range: r) {
                Self.changeText(line)
                    .padding(.top, 12)
                    .privacySensitive()
            }
            if pts.count >= 3 {
                chart(pts, color: color)
                    .padding(.top, 18)
                HStack {
                    Text("drag across the line").font(.system(size: 10.5, design: .monospaced)).foregroundStyle(Color(hex: "#71717A"))
                    Spacer()
                    if can.count > 1 {
                        WealthPills(options: Self.rangeOptions(can), selection: rangeBinding(r), mono: true, height: 36)
                    }
                }
                .padding(.top, 14)
            }
            if p == .family, let s = store.snap.smarts?.portfolio, !s.line.isEmpty {
                // since the end of last month, and what's coming (TabSmarts.swift): the household's, so on the family's page
                Text(s.line)
                    .font(.system(size: 13.5))
                    .foregroundStyle(Obsidian.ink2)
                    .fixedSize(horizontal: false, vertical: true)
                    .padding(.top, 18)
                    .privacySensitive()
            }
        }
    }

    @ViewBuilder func chart(_ pts: [NWPoint], color: Color) -> some View {
        ZStack(alignment: .topLeading) {
            WealthLine(pts: pts, color: color, pick: $pick)
                .frame(height: 170)
            if let i = pick, i < pts.count {
                GeometryReader { geo in
                    let w: CGFloat = geo.size.width
                    let x: CGFloat = pts.count > 1 ? w * CGFloat(i) / CGFloat(pts.count - 1) : 0
                    Text(Self.label(pts[i]))
                        .font(.system(size: 11, design: .monospaced))
                        .monospacedDigit()
                        .foregroundStyle(Obsidian.ink)
                        .padding(.horizontal, 9)
                        .padding(.vertical, 4)
                        .background(RoundedRectangle(cornerRadius: 9).fill(Color(hex: "#141419")))
                        .overlay(RoundedRectangle(cornerRadius: 9).stroke(Color.white.opacity(0.1), lineWidth: 1))
                        .fixedSize()
                        .position(x: min(max(x, 70), w - 70), y: -16)
                        .privacySensitive()
                }
                .frame(height: 0)
            }
        }
    }

    static func rangeOptions(_ can: [Int]) -> [(id: String, label: String)] {
        var out: [(id: String, label: String)] = []
        for r in ranges where can.contains(r.0) { out.append((id: String(r.0), label: r.1)) }
        return out
    }
    func rangeBinding(_ shown: Int) -> Binding<String> {
        Binding<String>(get: { String(shown) }, set: { (v: String) in
            range = Int(v) ?? 12
            pick = nil
        })
    }

    /// the change in its colour, then what it's over in grey
    static func changeText(_ line: (String, Bool, String)) -> Text {
        let mono: Font = .system(size: 12.5, design: .monospaced)
        let figure: Text = Text(line.0).font(mono).foregroundStyle(line.1 ? Obsidian.health : Color(hex: "#FF7A7A"))
        let span: Text = Text(" " + line.2).font(mono).foregroundStyle(Obsidian.ink3)
        return figure + span
    }

    /// "Mar 2026 · ₹1.42CR", or "Today · …" for the line's last point
    static func label(_ p: NWPoint) -> String {
        let when: String = p.day != nil ? "Today" : Day.fmt(p.m + "-01", "MMM yyyy")
        return when + " · " + Fmt.signedWords(p.v)
    }

    /// "▲ +₹12.4L · 8.1%" and "in a year" (or "since 1 Mar" when kosh's line starts later); nil with one point
    static func change(_ pts: [NWPoint], net: Double, range: Int) -> (String, Bool, String)? {
        guard pts.count > 1, let first = pts.first else { return nil }
        let d: Double = net - first.v
        let up: Bool = d >= 0
        let pct: String = first.v > 0 ? " · " + Fmt.trim(abs(d) / first.v * 100, 1) + "%" : ""
        let figure: String = (up ? "▲ +" : "▼ −") + Fmt.words(abs(d)) + pct
        let today: String = pts.last?.day ?? Day.monthEnd(pts.last?.m ?? first.m)
        let words: [Int: String] = [6: "in 6 months", 12: "in a year", 36: "in 3 years"]
        let span: String = range > 0 ? (words[range] ?? "") : "since " + NetWorthTrend.since(first, today: today)
        return (figure, up, span)
    }
}

// MARK: what it's in

struct WealthKinds: View {
    @Environment(Store.self) private var store
    let p: Person

    var body: some View {
        let kinds: [(key: String, v: Double)] = store.wealthKinds(p)
        let total: Double = kinds.reduce(0) { $0 + $1.v }
        if !kinds.isEmpty && total > 0 {
            VStack(alignment: .leading, spacing: 0) {
                WealthSectionHead(title: "What it’s in") {
                    Text(kinds.count == 1 ? "1 kind" : "\(kinds.count) kinds").font(.system(size: 11, design: .monospaced)).foregroundStyle(Obsidian.ink3)
                }
                WealthSplitBar(parts: Self.parts(kinds))
                    .padding(.top, 14)
                LazyVGrid(columns: [GridItem(.flexible(), spacing: 10), GridItem(.flexible(), spacing: 10)], spacing: 10) {
                    ForEach(kinds.indices, id: \.self) { (i: Int) in
                        let key: String = kinds[i].key
                        let v: Double = kinds[i].v
                        WealthKindTile(key: key, v: v, share: WealthBook.share(v, of: total), sub: sub(key)) { go(key) }
                    }
                }
                .padding(.top, 16)
            }
        }
    }

    static func parts(_ kinds: [(key: String, v: Double)]) -> [(id: String, v: Double, color: Color)] {
        kinds.map { (k: (key: String, v: Double)) -> (id: String, v: Double, color: Color) in (id: k.key, v: k.v, color: WealthKind.color(k.key)) }
    }

    /// the tile's quiet line: what the kind holds, by count and name, from the holdings themselves
    func sub(_ key: String) -> String {
        let items: [Holding] = store.holdings(p).filter { $0.cls == key }
        let n: Int = items.count
        switch key {
        case "dep":
            let accts: Int = store.wealthAccounts(p).filter { Store.accountWorth($0) > 0 }.count
            let fd: String = n == 0 ? "" : (n == 1 ? "1 deposit" : "\(n) deposits")
            let ba: String = accts == 0 ? "" : (accts == 1 ? "1 bank account" : "\(accts) bank accounts")
            return [fd, ba].filter { !$0.isEmpty }.joined(separator: " + ")
        case "stk":
            return n == 1 ? "1 company" : "\(n) companies"
        case "mf":
            let regular: Int = items.filter { WealthKind.plan($0.bank) == "Regular" }.count
            let direct: Int = items.filter { WealthKind.plan($0.bank) == "Direct" }.count
            let funds: String = n == 1 ? "1 fund" : "\(n) funds"
            if regular > 0 { return funds + " · \(regular) Regular" }
            return direct == n && n > 0 ? funds + " · all Direct" : funds
        case "ret":
            let types: [String] = Array(Set(items.map { $0.type.uppercased() })).sorted()
            return types.isEmpty ? "Locked till retirement" : types.joined(separator: " + ")
        case "gold":
            return n == 1 ? "1 holding" : "\(n) holdings"
        case "ins":
            return n == 1 ? "1 policy’s fund" : "\(n) policies’ funds"
        case "prop":
            let k: Int = store.properties(p).filter { ($0.worth ?? 0) > 0 }.count
            return (k == 1 ? "1 property" : "\(k) properties") + ", at your rate"
        default:
            return ""
        }
    }

    /// a kind's tile opens its Holdings tab (insurance funds their tab, land its own)
    func go(_ key: String) {
        switch key {
        case "ins": store.open(.insurance)
        case "prop": store.open(.property)
        case "dep", "mf", "ret", "stk", "gold": store.openHoldings(key)
        default: store.openHoldings("other")
        }
    }
}

struct WealthKindTile: View {
    let key: String
    let v: Double
    let share: String
    let sub: String
    let action: () -> Void

    var body: some View {
        let color: Color = WealthKind.color(key)
        Button(action: action) {
            VStack(alignment: .leading, spacing: 16) {
                HStack {
                    HStack(spacing: 7) {
                        Circle().fill(color).frame(width: 8, height: 8)
                        Text(WealthKind.title(key)).font(.system(size: 13)).foregroundStyle(Obsidian.ink2).lineLimit(1)
                    }
                    Spacer(minLength: 4)
                    Text(share)
                        .font(.system(size: 11.5, design: .monospaced)).monospacedDigit().foregroundStyle(color)
                }
                VStack(alignment: .leading, spacing: 4) {
                    Text(Fmt.words(v))
                        .font(.system(size: 23, weight: .semibold)).tracking(-0.7).monospacedDigit()
                        .foregroundStyle(Obsidian.ink).privacySensitive()
                    Text(sub).font(.system(size: 11.5)).foregroundStyle(Obsidian.ink3).lineLimit(1)
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(15)
            .background(alignment: .bottomTrailing) {
                RadialGradient(colors: [color.opacity(0.32), Color.clear], center: .center, startRadius: 0, endRadius: 75)
                    .frame(width: 150, height: 150)
                    .offset(x: 50, y: 70)
                    .allowsHitTesting(false)
            }
            .background(Obsidian.card)
            .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous).stroke(Obsidian.cardBorder, lineWidth: 1))
            .contentShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
        }
        .buttonStyle(.press)
        .accessibilityElement(children: .combine)
    }
}

// MARK: coming back to you

struct WealthComingBack: View {
    @Environment(Store.self) private var store
    let p: Person

    var body: some View {
        let today: String = store.snap.today
        let soon: [WealthMaturing] = Array(store.wealthMaturing(p).filter { $0.day >= today }.sorted { $0.day < $1.day }.prefix(8))
        if !soon.isEmpty {
            VStack(alignment: .leading, spacing: 14) {
                WealthSectionHead(title: "Coming back to you") {
                    WealthMore(label: "Deposits") { store.openHoldings("dep") }
                }
                ScrollView(.horizontal) {
                    HStack(spacing: 10) {
                        ForEach(soon) { m in
                            Button { store.openHoldings("dep") } label: { WealthBackCard(m: m, today: today, showWho: p == .family, who: store.ownerName(m.who)) }
                                .buttonStyle(.press)
                        }
                    }
                    .padding(.horizontal, 20)
                }
                .scrollIndicators(.hidden)
                .padding(.horizontal, -20)
            }
        }
    }
}

struct WealthBackCard: View {
    let m: WealthMaturing
    let today: String
    let showWho: Bool
    let who: String

    var body: some View {
        let date: String = Day.fmt(m.day, Day.fmt(m.day, "yyyy") == Day.fmt(today, "yyyy") ? "d MMM" : "d MMM yyyy")
        VStack(alignment: .leading, spacing: 0) {
            Text(WealthDays.until(m.day, today: today))
                .font(.system(size: 11, design: .monospaced)).foregroundStyle(Obsidian.health)
            Text(m.name).font(.system(size: 14, weight: .medium)).foregroundStyle(Obsidian.ink).lineLimit(2)
                .padding(.top, 16)
            Text(showWho ? who + " · " + date : date).font(.system(size: 12)).foregroundStyle(Obsidian.ink3)
                .padding(.top, 3)
            Spacer(minLength: 12)
            if let back = m.back {
                Text(Fmt.rupees(back)).font(.system(size: 22, weight: .semibold)).tracking(-0.4).monospacedDigit()
                    .foregroundStyle(Obsidian.ink).privacySensitive()
            } else if let now = m.now {
                // what it pays isn't in its mail: what it's worth today, said so
                VStack(alignment: .leading, spacing: 2) {
                    Text(Fmt.rupees(now)).font(.system(size: 17, weight: .semibold)).monospacedDigit().foregroundStyle(Obsidian.ink2).privacySensitive()
                    Text("worth today").font(.system(size: 11)).foregroundStyle(Obsidian.ink3)
                }
            }
        }
        .frame(width: 140, height: 140, alignment: .topLeading)
        .padding(16)
        .background(alignment: .topTrailing) {
            RadialGradient(colors: [Obsidian.health.opacity(ObsidianAura.card), Color.clear], center: .center, startRadius: 0, endRadius: 65)
                .frame(width: 130, height: 130)
                .offset(x: 50, y: -50)
                .allowsHitTesting(false)
        }
        .background(Obsidian.card)
        .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous).stroke(Obsidian.cardBorder, lineWidth: 1))
        .accessibilityElement(children: .combine)
    }
}

// MARK: the rest of Wealth: dividends and what's owed

struct WealthElsewhere: View {
    @Environment(Store.self) private var store
    let p: Person

    var body: some View {
        let div: DividendBook? = store.dividends(p)
        let loans: [Loan] = store.snap.loans.filter { $0.active && p.owns($0.owner ?? "me") }
        let owed: Double = store.debts(p)
        if div?.years.first != nil || !loans.isEmpty {
            VStack(spacing: 0) {
                if let b = div, let now = b.years.first {
                    let today: String = store.snap.today
                    WealthLinkRow(title: "Dividends",
                                  sub: DividendWords.money(now.total) + (now.to == today ? " so far in " : " in ") + now.label + ", " + DividendWords.range(now.from, now.to),
                                  color: Obsidian.ulip) { store.push(.dividends) }
                }
                if !loans.isEmpty {
                    if div?.years.first != nil { Rectangle().fill(Color.white.opacity(0.06)).frame(height: 1).padding(.leading, 36) }
                    let emi: Double = loans.reduce(0) { $0 + $1.emi }
                    let left: String = owed > 0 ? Fmt.words(owed) + " owed, taken off net worth · " : ""
                    WealthLinkRow(title: "Debts", sub: left + Fmt.rupees(emi) + " EMI a month", color: Obsidian.motor) {
                        withAnimation(Motion.open) { store.portSub = .loans }
                    }
                }
            }
            .background(RoundedRectangle(cornerRadius: 22, style: .continuous).fill(Obsidian.card))
            .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous).stroke(Obsidian.cardBorder, lineWidth: 1))
        }
    }
}
