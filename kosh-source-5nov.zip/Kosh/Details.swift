import SwiftUI
import UIKit
import LocalAuthentication
import UniformTypeIdentifiers

// MARK: - Your details
//
// Every detail a bank, card, fund house, depository, insurer or lender prints about you in its mail and statements:
// a Customer ID or CRN in the institution's own word for it, account numbers and IFSC, a folio, a DP and client ID, a
// PRAN or UAN, a policy number, a loan account, a PAN, the mobile and email they have on record. The engine reads
// them from the mail (snapshot facts, each with how many mails printed it and which) and the statements opened on
// the phone hand theirs over too (DetailsStore.docs). Shown by person and by what they're for; masked until Face ID
// or the passcode says it's you; copied for a minute, on this phone only. What you add or correct is kept as you
// typed it and always wins. They also open statements: each person's details with a sender go into the password
// tries (Papers.swift tryProfiles). All of it stays in this phone's Keychain; diagnostics never carry any of it.

// (DetailEntry, and the rules that say which account a number belongs to, are in Kosh/DetailsCore.swift: that file
//  holds no screens, so engine-test/details.js compiles and checks it without Xcode)

/// a detail you added, or one you corrected (under its new value's key; the one it corrects is taken out)
struct TypedDetail: Codable, Hashable {
    var key: String
    var who: String
    var inst: String
    var cat: String
    var k: String
    var label: String
    var v: String
    var at: String
}

/// the details a statement printed, read from it on the phone: whose, from which sender, the day it was sent
struct DocDetails: Codable, Hashable {
    var source: String
    var who: String
    var inst: String
    var domain: String
    var date: String
    var cat: String
    var items: [ReadingFact]
}

/// where Your details keeps what the person typed or took out, and what statements printed: this phone's Keychain
enum DetailsStore {
    static let typedKey: String = "details.typed"
    static let goneKey: String = "details.gone"
    static let docsKey: String = "details.docs"

    static func typed() -> [TypedDetail] {
        guard let s = Keychain.get(typedKey), let d = try? JSONText.decode([TypedDetail].self, s) else { return [] }
        return d
    }
    static func saveTyped(_ list: [TypedDetail]) { Keychain.set(list.isEmpty ? nil : JSONText.encode(list), for: typedKey) }

    static func gone() -> Set<String> {
        guard let s = Keychain.get(goneKey), let d = try? JSONText.decode([String].self, s) else { return [] }
        return Set(d)
    }
    static func saveGone(_ g: Set<String>) { Keychain.set(g.isEmpty ? nil : JSONText.encode(g.sorted()), for: goneKey) }

    static func docs() -> [String: DocDetails] {
        guard let s = Keychain.get(docsKey), let d = try? JSONText.decode([String: DocDetails].self, s) else { return [:] }
        return d
    }
    /// a statement's details, newest reading of it replacing the last; the 300 newest statements are kept
    static func saveDoc(_ d: DocDetails) {
        var all: [String: DocDetails] = docs()
        var one: DocDetails = d
        one.items = Array(d.items.prefix(40))
        all[d.source] = one
        if all.count > 300 {
            let keep: [String] = all.values.sorted { $0.date > $1.date }.prefix(300).map(\.source)
            all = all.filter { keep.contains($0.key) }
        }
        Keychain.set(JSONText.encode(all), for: docsKey)
    }

    /// a detail as the person gives it: a new one, or a correction (the detail it corrects is taken out)
    static func put(_ t: TypedDetail, replacing old: String?) {
        var list: [TypedDetail] = typed().filter { $0.key != t.key && $0.key != (old ?? "") }
        list.append(t)
        saveTyped(list)
        var g: Set<String> = gone()
        g.remove(t.key)
        if let old, old != t.key { g.insert(old) }
        saveGone(g)
    }
    /// taken out: what you typed goes, and what the mail printed isn't shown again
    static func remove(_ key: String) {
        saveTyped(typed().filter { $0.key != key })
        var g: Set<String> = gone()
        g.insert(key)
        saveGone(g)
    }
    static func forgetAll() {
        Keychain.set(nil, for: typedKey)
        Keychain.set(nil, for: goneKey)
        Keychain.set(nil, for: docsKey)
        PwFormats.clear()
    }
}

/// the password format that last opened each sender's statements (the engine's id for it), by the sender's domain:
/// tried first on that sender's next statement
enum PwFormats {
    static let key: String = "pw.formats"
    static func all() -> [String: String] {
        guard let s = Keychain.get(key), let d = try? JSONText.decode([String: String].self, s) else { return [:] }
        return d
    }
    static func get(_ domain: String) -> String? { all()[domain.lowercased()] }
    static func set(_ domain: String, _ format: String) {
        guard !domain.isEmpty, !format.isEmpty else { return }
        var a: [String: String] = all()
        a[domain.lowercased()] = format
        Keychain.set(JSONText.encode(a), for: key)
    }
    static func clear() { Keychain.set(nil, for: key) }
}

/// Every detail found, the mail's and the statements' together, with what the person typed or took out
enum DetailsBook {
    static func entries(groups: [FactGroup]) -> [DetailEntry] {
        var by: [String: DetailEntry] = [:]
        var order: [String] = []
        func merge(_ e: DetailEntry) {
            if let old = by[e.key] { by[e.key] = old.merged(with: e) } else { by[e.key] = e; order.append(e.key) }
        }
        for g in groups {
            for it in g.items {
                let key: String = Details.key(who: g.who, inst: g.inst, k: it.k, v: it.v, last4: it.last4)
                merge(DetailEntry(key: key, who: g.who, inst: g.inst, cat: g.cat, k: it.k, label: Details.label(it.k, it.label), v: it.v,
                                  masked: it.masked == true, last4: it.last4 ?? Details.tail(it.v), n: it.n ?? 1,
                                  last: it.last ?? "", src: it.src ?? [], domain: "", typed: false, fromDoc: false,
                                  sub: it.sub ?? "", ok: it.ok ?? true))
            }
        }
        for d in DetailsStore.docs().values.sorted(by: { $0.date < $1.date }) {
            for it in d.items {
                let who: String = it.who ?? d.who
                let inst: String = it.inst ?? d.inst
                let cat: String = it.cat ?? d.cat
                let key: String = Details.key(who: who, inst: inst, k: it.k, v: it.v, last4: it.last4)
                merge(DetailEntry(key: key, who: who, inst: inst, cat: cat, k: it.k, label: Details.label(it.k, it.label), v: it.v,
                                  masked: it.masked == true, last4: it.last4 ?? Details.tail(it.v), n: 1, last: d.date,
                                  src: [], domain: d.domain, typed: false, fromDoc: true))
            }
        }
        for t in DetailsStore.typed() {
            let old: DetailEntry? = by[t.key]
            if old == nil { order.append(t.key) }
            by[t.key] = DetailEntry(key: t.key, who: t.who, inst: t.inst, cat: t.cat, k: t.k, label: t.label, v: t.v,
                                    masked: false, last4: Details.tail(t.v), n: old?.n ?? 0, last: old?.last ?? t.at,
                                    src: old?.src ?? [], domain: old?.domain ?? "", typed: true, fromDoc: old?.fromDoc ?? false)
        }
        let gone: Set<String> = DetailsStore.gone()
        return order.compactMap { by[$0] }.filter { $0.typed || !gone.contains($0.key) }
    }
}

/// The parts of Your details that need the screens: how a detail reads, who is on the page, and the
/// pasteboard. The rest — which account a number belongs to — is in Kosh/DetailsCore.swift.
extension Details {
    /// a sender's name from the domain its statements come from
    static func instOf(_ domain: String) -> String { PersonPage.bankOf(domain) }
    /// "Found in 3 mails, last on 20 Oct", "Read from a statement, 18 Oct", "You added it"
    static func foundLine(_ e: DetailEntry) -> String {
        let day: String = e.last.count >= 10 ? Day.fmt(String(e.last.prefix(10)), "d MMM") : ""
        if e.typed && e.n == 0 && !e.fromDoc { return "You added it" }
        if e.n > 0 && !e.src.isEmpty {
            let mails: String = e.src.count == 1 && e.n <= 1 ? "Found in 1 mail" : "Found in \(max(e.n, e.src.count)) mails"
            return mails + (day.isEmpty ? "" : ", last on " + day) + (e.typed ? ", corrected by you" : "")
        }
        if e.fromDoc { return "Read from a statement" + (day.isEmpty ? "" : ", " + day) + (e.typed ? ", corrected by you" : "") }
        return e.typed ? "Corrected by you" : (day.isEmpty ? "Found in your mail" : "Found in your mail, " + day)
    }
    /// whose details kosh couldn't tell: the engine leaves who empty rather than guess (engine/21j-build-facts.js),
    /// and the page shows them under this name instead of hiding them
    static let noOne: String = ""
    static let noOneName: String = "Not said whose yet"
    /// the people with details, you first, then the household in its order, then anyone else the mail names, and
    /// last the details kosh can't say whose they are (they exist, so they are never left off the page)
    static func people(_ all: [DetailEntry], store: Store) -> [String] {
        var out: [String] = ["me"]
        for p in store.snap.people where p.id != "me" && all.contains(where: { $0.who == p.id }) { out.append(p.id) }
        for e in all where !out.contains(e.who) && !e.who.isEmpty { out.append(e.who) }
        if all.contains(where: { $0.who.isEmpty }) { out.append(noOne) }
        return out
    }
    static func personName(_ id: String, _ store: Store) -> String {
        if id.isEmpty { return noOneName }
        if id == "me" { return "You" }
        if let p = store.snap.people.first(where: { $0.id == id }) { return p.full.isEmpty ? p.name : p.full }
        if id.hasPrefix("n:") { return String(id.dropFirst(2)).split(separator: " ").map { $0.prefix(1).uppercased() + $0.dropFirst() }.joined(separator: " ") }
        return store.ownerName(id)
    }
    /// what the password formats get with a person's details for one locked statement: their details with this sender
    /// (by institution, matched whole, or by the domain its statements come from), and their identity, tax and
    /// contact details
    static func pwFacts(who: String, inst: String, domain: String, groups: [FactGroup]) -> [PwFact] {
        guard !who.isEmpty else { return [] }
        let dom: String = domain.lowercased()
        var out: [PwFact] = []
        for e in DetailsBook.entries(groups: groups) where e.who == who && !e.masked && !e.v.isEmpty {
            let atInst: Bool = sameInst(e.inst, inst)
            let sameDomain: Bool = !dom.isEmpty && e.domain.lowercased() == dom
            let theirs: Bool = e.cat == "identity" || e.cat == "tax" || e.cat == "contact"
            guard atInst || sameDomain || theirs else { continue }
            let f: PwFact = PwFact(k: e.k, v: e.v, inst: e.inst, domain: e.domain)
            if !out.contains(f) { out.append(f) }
        }
        return Array(out.prefix(24))
    }
    /// a value on the pasteboard for a minute, on this phone only (never to your other devices)
    static func copy(_ v: String) {
        UIPasteboard.general.setItems([[UTType.utf8PlainText.identifier: v]],
                                      options: [.localOnly: true, .expirationDate: Date().addingTimeInterval(60)])
    }
}

/// Face ID, Touch ID or the passcode, once a visit, before a detail is shown in full or copied
enum DetailsLock {
    @MainActor
    static func ask() async -> Bool {
        let c: LAContext = LAContext()
        var err: NSError? = nil
        // (a phone with no passcode at all has nothing to ask)
        guard c.canEvaluatePolicy(.deviceOwnerAuthentication, error: &err) else { return true }
        do {
            return try await c.evaluatePolicy(.deviceOwnerAuthentication, localizedReason: "Show your saved details in full")
        } catch {
            return false
        }
    }
}

/// where a detail was found: the mails that printed it, and whether a statement did too
struct DetailSourceRef: Identifiable, Hashable {
    let id: String
    let title: String
    let mails: [String]
    let fromDoc: Bool
    init(_ e: DetailEntry) {
        id = e.key
        title = e.label
        mails = e.src
        fromDoc = e.fromDoc
    }
}

// MARK: - The page

struct DetailsPage: View {
    @Environment(Store.self) private var store
    /// opened from Wealth or Insurance: its sheets in the black look too
    @Environment(\.obsidian) private var obsidian
    /// whose details to start on (nil: yours)
    var person: String? = nil
    /// whose details are being looked at; nil until a choice is made (an empty string is a real answer here: the
    /// details kosh can't say whose they are)
    @State private var who: String? = nil
    /// the institution the strip is narrowed to ("": all of them)
    @State private var bank: String = ""
    @State private var shown: Bool = false
    @State private var editing: DetailEntry? = nil
    @State private var adding: Bool = false
    @State private var sources: DetailSourceRef? = nil
    @State private var copied: Int = 0

    var body: some View {
        let all: [DetailEntry] = store.details
        let people: [String] = Details.people(all, store: store)
        let current: String = who ?? person ?? "me"
        let mine: [DetailEntry] = all.filter { $0.who == current }
        // the institutions this person has details with, the one with the most first; the strip hides at one
        let insts: [String] = Details.instsIn(all, who: current)
        let picked: String = insts.contains(where: { Details.sameInst($0, bank) }) ? bank : ""
        let here: [DetailEntry] = picked.isEmpty ? mine : mine.filter { Details.sameInst($0.inst, picked) }
        // every figure under the account, card or loan that owns it, so none can be read against the wrong account
        let blocks: [DetailBlock] = Details.blocks(holders: Self.holders(store, who: current), who: current, from: here)
        let placed: Set<String> = Set(blocks.flatMap { $0.rows.map(\.key) })
        let rest: [DetailEntry] = here.filter { !placed.contains($0.key) }
        ObsidianList {
            if people.count > 1 {
                Section {
                    Picker("Whose details", selection: Binding(get: { current }, set: { who = $0 })) {
                        ForEach(people, id: \.self) { p in Text(Details.personName(p, store)).tag(p) }
                    }
                }
            }
            if insts.count > 1 {
                Section {
                    BankStrip(banks: Self.strip(insts, mine, store), pick: $bank, logos: Self.logos(insts), noun: "details")
                        .listRowInsets(EdgeInsets())
                        .listRowBackground(Color.clear)
                }
            }
            if mine.isEmpty {
                Section {
                    ContentUnavailableView("Nothing found yet", systemImage: "person.text.rectangle",
                                           description: Text("As kosh reads the mail and opens statements, the IDs and numbers they print show here."))
                }
            }
            ForEach(blocks) { b in
                DetailsBlockSection(b: b, head: Self.head(b, blocks), shown: shown, reveal: reveal, copy: copy,
                                    edit: edit, sources: { sources = DetailSourceRef($0) }, remove: remove)
            }
            ForEach(Details.sections.indices, id: \.self) { si in
                DetailsSection(title: Details.sections[si].title, rows: Self.rows(rest, si), shown: shown,
                               reveal: reveal, copy: copy, edit: edit, sources: { sources = DetailSourceRef($0) }, remove: remove)
            }
            Section {
            } footer: {
                Text("Kept in this phone’s Keychain. Shown in full after Face ID; copied for a minute. Never sent anywhere.")
            }
        }
        .settingsPage("Your details")
        .toolbar {
            ToolbarItem(placement: .primaryAction) {
                Button { adding = true } label: { Image(systemName: "plus") }
                    .accessibilityLabel("Add a detail")
            }
        }
        .sensoryFeedback(.success, trigger: copied)
        .sheet(item: $editing) { e in
            DetailEditor(entry: e, who: e.who) { store.refreshDetails() }.obsidianSheet(obsidian)
        }
        .sheet(isPresented: $adding) {
            DetailEditor(entry: nil, who: current) { store.refreshDetails() }.obsidianSheet(obsidian)
        }
        .sheet(item: $sources) { s in
            DetailSourcesSheet(s: s).environment(store).obsidianSheet(obsidian)
        }
    }

    /// the accounts and cards on this phone as Your details needs them, this person's only. A wallet and a debit card
    /// whose account kosh can't tell yet are no account: their numbers are nobody's to show.
    static func holders(_ store: Store, who: String) -> [DetailHolder] {
        guard !who.isEmpty else { return [] }
        let whose: String = who == "me" ? "Yours" : Details.personName(who, store)
        func theirs(_ owner: String, _ joint: [String]) -> Bool { owner == who || owner == "family" || joint.contains(who) }
        var out: [DetailHolder] = []
        for a in store.snap.accounts where theirs(a.owner, a.joint ?? []) {
            if a.isDebitCardOnly || a.kind == "wallet" { continue }
            out.append(DetailHolder(group: Details.groupOf(atype: a.atype ?? ""), bank: a.bank, atype: a.atype ?? "",
                                    last4: a.last, alias: (a.alias ?? []) + (a.debit ?? []), who: who, whose: whose))
        }
        for c in store.snap.cards where theirs(c.owner, []) {
            out.append(DetailHolder(group: "card", bank: c.bank, last4: c.last, who: who, whose: whose))
        }
        return out
    }
    /// the strip: each institution with its mark, its colour and how many details it has here
    static func strip(_ insts: [String], _ mine: [DetailEntry], _ store: Store) -> [BankPick] {
        var color: [String: String] = [:]
        for a in store.snap.accounts { color[a.bank.lowercased()] = a.color }
        for c in store.snap.cards where color[c.bank.lowercased()] == nil { color[c.bank.lowercased()] = c.color }
        return insts.map { (i: String) -> BankPick in
            BankPick(id: i, color: color[i.lowercased()] ?? "#636366",
                     count: mine.filter { Details.sameInst($0.inst, i) }.count, hint: i)
        }
    }
    /// every chip shows a logo, or every chip its initials: a strip where some have one and some the other reads broken
    static func logos(_ insts: [String]) -> Bool { IconBook.shared.all(insts.map { ($0, $0) }) }
    /// the heading over a group, written once over the first of its blocks
    static func head(_ b: DetailBlock, _ blocks: [DetailBlock]) -> String {
        guard blocks.first(where: { $0.group == b.group })?.id == b.id else { return "" }
        return Details.groupTitle(b.group)
    }

    static func rows(_ mine: [DetailEntry], _ si: Int) -> [DetailEntry] {
        // (by institution, the ones the mail didn't name last; within one, in the engine's order: IDs before numbers)
        mine.filter { Details.section(of: $0.cat) == si }.sorted {
            let a: String = $0.inst.isEmpty ? "~" : $0.inst, b: String = $1.inst.isEmpty ? "~" : $1.inst
            return (a, Details.rank($0.k), $0.label, $0.v) < (b, Details.rank($1.k), $1.label, $1.v)
        }
    }

    @MainActor
    func reveal() async -> Bool {
        if shown { return true }
        let ok: Bool = await DetailsLock.ask()
        if ok { withAnimation(Motion.open) { shown = true } }
        return ok
    }
    func copy(_ e: DetailEntry) {
        Task { @MainActor in
            if !e.masked && !Details.open.contains(e.k) { guard await reveal() else { return } }
            Details.copy(e.v)
            copied += 1
        }
    }
    func edit(_ e: DetailEntry) {
        Task { @MainActor in
            guard await reveal() else { return }
            editing = e
        }
    }
    func remove(_ e: DetailEntry) {
        DetailsStore.remove(e.key)
        store.refreshDetails()
    }
}

/// one account, card or loan on the page: the line that names it by every part kosh has, what kosh can't say about
/// it (in its own words, never filled in), and only the numbers printed for it
struct DetailsBlockSection: View {
    @Environment(Store.self) private var store
    let b: DetailBlock
    /// the group's heading, over the first of its blocks only
    let head: String
    let shown: Bool
    let reveal: () async -> Bool
    let copy: (DetailEntry) -> Void
    let edit: (DetailEntry) -> Void
    let sources: (DetailEntry) -> Void
    let remove: (DetailEntry) -> Void
    var body: some View {
        Section {
            ForEach(b.rows) { e in
                DetailRow(e: e, shown: shown, reveal: reveal, copy: { copy(e) }, sources: { sources(e) })
                    .swipeActions(edge: .trailing) {
                        Button(role: .destructive) { remove(e) } label: { Label("Delete", systemImage: "trash") }
                        Button { edit(e) } label: { Label("Correct", systemImage: "pencil") }.tint(Color.kosh)
                    }
                    .contextMenu {
                        Button { copy(e) } label: { Label("Copy", systemImage: "doc.on.doc") }
                        Button { edit(e) } label: { Label("Correct it", systemImage: "pencil") }
                        if !e.src.isEmpty { Button { sources(e) } label: { Label("Where it was found", systemImage: "envelope") } }
                        Button(role: .destructive) { remove(e) } label: { Label("Delete", systemImage: "trash") }
                    }
            }
        } header: {
            // (the group once, then each instrument as its bank and a short name; whose is the picker's to say, and a
            // type the bank never printed is a small word, not a sentence)
            VStack(alignment: .leading, spacing: 12) {
                if !head.isEmpty { Text(head).font(.title3.weight(.bold)).foregroundStyle(Color.primary) }
                if b.group == "known" || b.group == "unplaced" {
                    SettingsHeader(b.group == "known" ? "Known to " + b.bank + " as" : b.bank + ": not tied to an account")
                } else {
                    HStack(spacing: 8) {
                        if !b.bank.isEmpty { InstIcon(name: b.bank, color: StatementsSettings.color(b.bank, store), size: 22, hint: b.bank) }
                        Text(b.bank.isEmpty ? (b.short.isEmpty ? b.title : b.short) : b.bank)
                            .font(.subheadline.weight(.semibold)).foregroundStyle(Color.primary)
                        Spacer(minLength: 6)
                        if !b.bank.isEmpty {
                            Text((b.short.isEmpty ? b.title : b.short) + (b.typeUnknown ? ", type unknown" : ""))
                                .font(SettingsType.caption).monospacedDigit().foregroundStyle(.secondary)
                        }
                    }
                }
            }
            .textCase(nil)
        } footer: {
            if !b.notes.isEmpty {
                Text(b.notes.joined(separator: " "))
            }
        }
    }
}

/// one category's details on the page
struct DetailsSection: View {
    @Environment(Store.self) private var store
    let title: String
    let rows: [DetailEntry]
    let shown: Bool
    let reveal: () async -> Bool
    let copy: (DetailEntry) -> Void
    let edit: (DetailEntry) -> Void
    let sources: (DetailEntry) -> Void
    let remove: (DetailEntry) -> Void
    /// the rows by where each is held, in the order they come (the page sorts them by institution)
    var byInst: [(inst: String, rows: [DetailEntry])] {
        var out: [(inst: String, rows: [DetailEntry])] = []
        for e in rows {
            if let i = out.firstIndex(where: { $0.inst == e.inst }) { out[i].rows.append(e) } else { out.append((e.inst, [e])) }
        }
        return out
    }
    var body: some View {
        ForEach(Array(byInst.enumerated()), id: \.element.inst) { gi, g in
            Section {
                ForEach(g.rows) { e in
                    DetailRow(e: e, shown: shown, reveal: reveal, copy: { copy(e) }, sources: { sources(e) })
                        .swipeActions(edge: .trailing) {
                            Button(role: .destructive) { remove(e) } label: { Label("Delete", systemImage: "trash") }
                            Button { edit(e) } label: { Label("Correct", systemImage: "pencil") }.tint(Color.kosh)
                        }
                        .contextMenu {
                            Button { copy(e) } label: { Label("Copy", systemImage: "doc.on.doc") }
                            Button { edit(e) } label: { Label("Correct it", systemImage: "pencil") }
                            if !e.src.isEmpty { Button { sources(e) } label: { Label("Where it was found", systemImage: "envelope") } }
                            Button(role: .destructive) { remove(e) } label: { Label("Delete", systemImage: "trash") }
                        }
                }
            } header: {
                // the category once, over its first institution; then each institution its own group
                VStack(alignment: .leading, spacing: 12) {
                    if gi == 0 {
                        Text(title).font(.title3.weight(.bold)).foregroundStyle(Color.primary)
                    }
                    HStack(spacing: 8) {
                        if !g.inst.isEmpty { InstIcon(name: g.inst, color: StatementsSettings.color(g.inst, store), size: 22, hint: g.inst) }
                        Text(g.inst.isEmpty ? "Not named in the mail" : g.inst).font(.subheadline.weight(.semibold)).foregroundStyle(Color.primary)
                    }
                }
                .textCase(nil)
            }
        }
    }
}

/// one detail: what the institution calls it and whose it is with, the value (last four until Face ID), a copy button,
/// and where it was found
struct DetailRow: View {
    let e: DetailEntry
    let shown: Bool
    let reveal: () async -> Bool
    let copy: () -> Void
    let sources: () -> Void
    var body: some View {
        let value: String = e.masked ? Details.partial(e.v) : shown || Details.open.contains(e.k) ? e.v : Details.masked(e)
        HStack(alignment: .center, spacing: 10) {
            VStack(alignment: .leading, spacing: 2) {
                Text(e.label.isEmpty ? "Detail" : e.label).font(SettingsType.title)
                Button(action: sources) {
                    Text(Details.foundLine(e)).font(SettingsType.caption).foregroundStyle(.secondary)
                }
                .buttonStyle(.borderless)
                .disabled(e.src.isEmpty)
            }
            Spacer(minLength: 8)
            Button {
                Task { @MainActor in _ = await reveal() }
            } label: {
                Text(value)
                    .font(SettingsType.value).monospacedDigit()
                    .foregroundStyle(Color.primary)
                    .lineLimit(1)
                    .minimumScaleFactor(0.7)
                    .contentTransition(.opacity)
            }
            .buttonStyle(.borderless)
            .accessibilityLabel(shown && !e.masked ? e.label + ", " + e.v : e.label + ", ending " + e.last4)
            .accessibilityHint(shown ? "" : "Shows it in full after Face ID")
            // (only a whole number is worth copying: one the mail printed in part has nothing more to give)
            if !e.masked {
                SettingsCopyButton(label: e.label, action: copy)
            } else {
                Color.clear.frame(width: 32, height: 44).accessibilityHidden(true)
            }
        }
        .frame(minHeight: 44)
    }
}

/// add a detail by hand, or correct one: kept exactly as typed, and it wins over what the mail printed
struct DetailEditor: View {
    @Environment(\.dismiss) private var dismiss
    let entry: DetailEntry?
    let who: String
    let done: () -> Void
    @State private var inst: String = ""
    @State private var label: String = ""
    @State private var value: String = ""
    @State private var cat: String = "bank"
    @State private var asking: Bool = false

    var body: some View {
        NavigationStack {
            ObsidianForm {
                Section {
                    TextField("Bank, fund house or insurer", text: $inst)
                    TextField("What they call it: CRN, Customer ID…", text: $label)
                    TextField("The number or ID", text: $value)
                        .font(.body).monospacedDigit()
                        .textInputAutocapitalization(.characters)
                        .autocorrectionDisabled()
                } footer: {
                    Text("Kept in this phone’s Keychain, used to open your statements. What you type here always wins over what kosh found.")
                }
                Section {
                    Picker("It’s for", selection: $cat) {
                        ForEach(Details.pickable, id: \.0) { p in Text(p.1).tag(p.0) }
                    }
                }
                if entry != nil {
                    Section {
                        Button("Delete this detail", role: .destructive) { asking = true }
                    }
                }
            }
            .navigationTitle(entry == nil ? "Add a detail" : "Correct a detail")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") { save() }.disabled(value.trimmingCharacters(in: .whitespaces).isEmpty)
                }
            }
            .confirmationDialog("Delete this detail?", isPresented: $asking, titleVisibility: .visible) {
                Button("Delete", role: .destructive) {
                    if let e = entry { DetailsStore.remove(e.key) }
                    done()
                    dismiss()
                }
            } message: {
                Text("It won’t be shown again, even if the mail prints it again.")
            }
            .onAppear {
                guard let e = entry else { return }
                inst = e.inst
                label = e.label
                value = e.masked ? "" : e.v
                cat = e.cat.isEmpty ? "bank" : e.cat
            }
        }
    }

    func save() {
        let v: String = value.trimmingCharacters(in: .whitespacesAndNewlines)
        let l: String = label.trimmingCharacters(in: .whitespacesAndNewlines)
        let i: String = inst.trimmingCharacters(in: .whitespacesAndNewlines)
        let k: String = entry?.k ?? Details.kindOf(l)
        let key: String = Details.key(who: who, inst: i, k: k, v: v, last4: nil)
        let t: TypedDetail = TypedDetail(key: key, who: who, inst: i, cat: cat, k: k, label: l.isEmpty ? "Detail" : l, v: v, at: Day.iso(Date()))
        DetailsStore.put(t, replacing: entry?.key)
        done()
        dismiss()
    }
}

/// the mails a detail was found in
struct DetailSourcesSheet: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    let s: DetailSourceRef
    var body: some View {
        NavigationStack {
            ObsidianList {
                if !s.mails.isEmpty {
                    Section(s.mails.count == 1 ? "Found in this mail" : "Found in these mails") {
                        ForEach(s.mails, id: \.self) { id in
                            if let r = store.live?.records.first(where: { $0.id == id }) {
                                MailSourceRow(r: r, type: "detail")
                            } else {
                                Text("A mail kosh no longer keeps").foregroundStyle(.secondary)
                            }
                        }
                    }
                }
                if s.fromDoc {
                    Section {
                        Label("A statement kosh opened printed it too", systemImage: "doc.text")
                    }
                }
            }
            .navigationTitle(s.title)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } } }
        }
    }
}

/// this one account's or card's own numbers, on its page: the ones printed for its digits, then what the institution
/// knows the person by, then what it printed without saying which account. Nothing another account's mail printed is
/// ever shown here as this one's.
struct InstitutionDetails: View {
    @Environment(Store.self) private var store
    @Environment(\.obsidian) private var obsidian
    let inst: String
    let who: String
    /// this row's own last four, and the other ways its mail wrote them: without them the page would show the bank's
    /// other accounts' and its card's numbers as this account's
    var last4: String = ""
    var alias: [String] = []
    @State private var shown: Bool = false
    @State private var sources: DetailSourceRef? = nil
    @State private var copied: Int = 0

    var body: some View {
        let all: [DetailEntry] = store.details
        let own: [DetailEntry] = Details.forInst(inst, who: who, last4: last4, alias: alias, from: all)
        let known: [DetailEntry] = last4.isEmpty ? [] : Details.instWide(inst, who: who, from: all)
        let loose: [DetailEntry] = last4.isEmpty ? [] : Details.unplaced(inst, who: who, from: all)
        if !own.isEmpty || !known.isEmpty || !loose.isEmpty {
            VStack(alignment: .leading, spacing: 14) {
                card("Details", own)
                card("Known to " + inst + " as", known)
                card("Printed, but kosh can’t say which account", loose)
                // (a part missing is said, never filled in: a borrowed IFSC would be worse than a blank)
                if !loose.isEmpty && !own.contains(where: { $0.k == "ifsc" }) {
                    Text("No IFSC for this account yet. " + inst + " printed the one above without saying which account it is for, so kosh leaves it there.")
                        .font(.footnote).foregroundStyle(.secondary)
                }
            }
            .sensoryFeedback(.success, trigger: copied)
            .sheet(item: $sources) { s in
                DetailSourcesSheet(s: s).environment(store).obsidianSheet(obsidian)
            }
        }
    }

    @ViewBuilder
    func card(_ title: String, _ rows: [DetailEntry]) -> some View {
        if !rows.isEmpty {
            VStack(alignment: .leading, spacing: 8) {
                Text(title).font(.system(.footnote, weight: .semibold)).foregroundStyle(.secondary)
                VStack(spacing: 0) {
                    ForEach(Array(rows.enumerated()), id: \.element.id) { n, e in
                        if n > 0 { Divider() }
                        DetailRow(e: e, shown: shown, reveal: reveal, copy: { copy(e) }, sources: { sources = DetailSourceRef(e) })
                            .padding(.vertical, 6)
                    }
                }
                .padding(.horizontal, 14)
                .padding(.vertical, 4)
                .background(CardFill(), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            }
        }
    }

    @MainActor
    func reveal() async -> Bool {
        if shown { return true }
        let ok: Bool = await DetailsLock.ask()
        if ok { withAnimation(Motion.open) { shown = true } }
        return ok
    }
    func copy(_ e: DetailEntry) {
        Task { @MainActor in
            if !e.masked { guard await reveal() else { return } }
            Details.copy(e.v)
            copied += 1
        }
    }
}
