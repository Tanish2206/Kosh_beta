import SwiftUI
import Charts

// MARK: - Home, the calm cards
//
// Overview opens on hello, said in one language after another with the name you gave kosh. Beside the sub-tabs a
// bell counts what kosh noticed; it opens one sheet with those, most pressing first, and the money threads coming up.
// Under hello: net worth, spending, cash flow (in and out, six months) and this week. Genie, the other sub-tab, holds
// what needs you and what kosh is chasing.

// MARK: hello

struct HelloLine: View {
    @Environment(Store.self) private var store
    @Environment(\.accessibilityReduceMotion) private var still
    @AppStorage("home.callName") private var callName = ""
    @State private var i = 0

    /// hello around India and the world, one after another
    static let words: [String] = [
        "Hello", "नमस्ते", "Hola", "வணக்கம்", "Bonjour", "নমস্কার", "こんにちは", "ನಮಸ್ಕಾರ", "Ciao", "నమస్కారం",
        "你好", "કેમ છો", "Olá", "നമസ്കാരം", "Hallo", "ਸਤ ਸ੍ਰੀ ਅਕਾਲ", "안녕하세요", "नमस्कार", "مرحبا", "ନମସ୍କାର",
        "Привет", "آداب", "Merhaba", "নমস্কাৰ", "Xin chào", "สวัสดี", "Jambo", "שלום", "Γεια σου", "Halo", "Hej", "Aloha",
    ]

    /// what kosh calls you: the name you set in Settings, else your first name
    var name: String {
        let set = callName.trimmingCharacters(in: .whitespacesAndNewlines)
        if !set.isEmpty { return set }
        let first = store.snap.people.first?.name ?? ""
        return first == "You" ? "" : first
    }

    var body: some View {
        let name = self.name
        HStack(alignment: .center, spacing: 12) {
            HStack(alignment: .firstTextBaseline, spacing: 0) {
                // the old word and the new overlap as one fades into the other, so nothing beside them jumps
                ZStack(alignment: .leading) {
                    Text(Self.words[i])
                        .id(i)
                        .transition(.asymmetric(insertion: .opacity.combined(with: .offset(y: 10)),
                                                removal: .opacity.combined(with: .offset(y: -10))))
                }
                if !name.isEmpty {
                    Text(", " + name).truncationMode(.tail)
                }
            }
            .font(.system(.title, design: .rounded, weight: .bold))
            .lineLimit(1)
            .minimumScaleFactor(0.6)
            .frame(minHeight: 42, alignment: .leading)
            .animation(Motion.reveal, value: i)
            .frame(maxWidth: .infinity, alignment: .leading)
            // the day, in type, which opens the calendar
            Button { store.push(.calendar) } label: { DayPage(day: store.snap.today) }
                .buttonStyle(PulsePress())
                .accessibilityLabel(Day.long(store.snap.today) + ". Opens the calendar")
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .accessibilityElement(children: .contain)
        .accessibilityLabel((name.isEmpty ? "Hello" : "Hello, " + name) + ". " + Day.long(store.snap.today))
        .accessibilityAddTraits(.isHeader)
        .task(id: still) {
            guard !still else { i = 0; return }
            while !Task.isCancelled {
                try? await Task.sleep(for: .seconds(1.8))
                if Task.isCancelled { break }
                withAnimation(Motion.reveal) { i = (i + 1) % Self.words.count }
            }
        }
    }
}

/// Under hello, while a first read is still going back through the year: how far it has got, in one calm line. Home
/// stands on what's read so far; the notes that need months of history wait for them (profile readFrom, engine.js)
struct ReadingBackLine: View {
    let live: LiveSession

    var body: some View {
        if live.signedIn && !live.yearIn && live.scanFrom.count == 10 {
            // the month being read now, else the oldest read so far
            let month: String = live.bgMonth.isEmpty ? String(live.scanFrom.prefix(7)) : live.bgMonth
            let text: String = live.backfilling ? "Reading back to " + Day.monthName(month) + "…" : "Read back to " + Day.monthName(month) + " so far; the rest of the year comes in the background."
            Label(text, systemImage: "clock.arrow.circlepath")
                .font(.footnote)
                .foregroundStyle(.secondary)
                .frame(maxWidth: .infinity, alignment: .leading)
        }
    }
}

/// today in type alone: the weekday in small caps in kosh's colour over the date, big and plain
struct DayPage: View {
    let day: String
    var body: some View {
        VStack(alignment: .trailing, spacing: -3) {
            Text(Day.fmt(day, "EEE").uppercased())
                .font(.system(.caption, design: .rounded, weight: .heavy))
                .tracking(1.8)
                .foregroundStyle(Color.kosh)
            Text(String(Day.dayNumber(day)))
                .font(.system(size: 40, weight: .bold, design: .rounded))
                .monospacedDigit()
                .tracking(-1)
                .foregroundStyle(Color.primary)
        }
        .padding(.vertical, 2)
        .frame(minWidth: 48, minHeight: 46, alignment: .trailing)
    }
}

// MARK: the bell

/// how many things kosh noticed, and how pressing the most pressing is (3 act now, 2 worth a look, 1 good to know)
struct BellInfo: Equatable {
    let count: Int
    let top: Int
}

extension Store {
    var bellInfo: BellInfo {
        let w: [WatchItem] = watchShown
        return BellInfo(count: w.count, top: w.map { min(3, $0.sev) }.max() ?? 0)
    }

    /// what kosh noticed, less what you marked done or paid, and what you snoozed (till it wakes)
    var watchShown: [WatchItem] {
        let now: Double = Date().timeIntervalSince1970
        return (snap.watch ?? []).filter { (hushed[$0.id] ?? 0) <= now }
    }

    /// a bill or a premium is paid; anything else is done
    static func doneWord(_ f: WatchItem) -> String { ["due", "renewal"].contains(f.kind) ? "Paid" : "Done" }

    /// the calendar's bill behind a "due" heads-up (its id is due|name|date)
    func agendaItem(for f: WatchItem) -> AgendaItem? {
        guard f.kind == "due" else { return nil }
        let parts: [String] = f.id.components(separatedBy: "|")
        guard parts.count >= 3, let date = parts.last else { return nil }
        let name: String = parts.dropFirst().dropLast().joined(separator: "|")
        return snap.agenda.first { $0.name == name && $0.date == date && $0.kind == "out" }
    }

    /// done, or paid: it goes from the heads-up; a bill is marked paid on the calendar too (its reminders go). Undo.
    func watchDone(_ f: WatchItem) {
        let was: Double? = hushed[f.id]
        let bill: AgendaItem? = agendaItem(for: f)
        if let bill { markPaid(bill.id) }
        hush(f.id, until: Date().timeIntervalSince1970 + 120 * 86400)
        let paid: Bool = Self.doneWord(f) == "Paid"
        undoNote = UndoNote(text: paid ? "Marked as paid" : "Marked done") { [weak self] in
            self?.hushed[f.id] = was
            if let bill { self?.markPaid(bill.id, false) }
        }
    }

    /// snoozed: back in three hours when it's due today and still daytime, otherwise tomorrow at nine. Undo.
    func watchSnooze(_ f: WatchItem) {
        let was: Double? = hushed[f.id]
        let at: Date = Reminders.snoozeTime(due: f.kind == "due" ? f.date : "")
        hush(f.id, until: at.timeIntervalSince1970)
        let later: Bool = Day.iso(at) == Day.iso(Date())
        undoNote = UndoNote(text: later ? "Snoozed for three hours" : "Snoozed till tomorrow morning") { [weak self] in
            self?.hushed[f.id] = was
        }
    }

    /// gone from the heads-up for good, nothing else changed. Undo.
    func watchRemove(_ f: WatchItem) {
        let was: Double? = hushed[f.id]
        hush(f.id, until: Date().timeIntervalSince1970 + 120 * 86400)
        undoNote = UndoNote(text: "Removed") { [weak self] in self?.hushed[f.id] = was }
    }

    /// the answer to a heads-up's question: rent came in, the refund came back, a charge was twice. Undo.
    func watchYes(_ f: WatchItem) {
        let was: Double? = hushed[f.id]
        let parts: [String] = f.id.components(separatedBy: "|")
        switch f.kind {
        case "rent":
            // rent|property|unit: marked received for the month it's late for
            guard parts.count >= 3, let idx = Int(parts[2]) else { watchDone(f); return }
            let pid: String = parts[1]
            let unit: PropUnit? = snap.prop.props.first(where: { $0.pid == pid })?.units.first(where: { $0.idx == idx })
            let month: String = unit?.now?.m ?? snap.cm
            markRent(property: pid, unit: idx, month: month)
            hush(f.id, until: Date().timeIntervalSince1970 + 120 * 86400)
            undoNote = UndoNote(text: "Rent marked received") { [weak self] in
                self?.markRent(property: pid, unit: idx, month: month)
                self?.hushed[f.id] = was
            }
        case "refund":
            // refund|payment: it came back without kosh seeing the credit
            let id: String = parts.dropFirst().joined(separator: "|")
            if refund(id) != nil { refundBack(id, true) }
            hush(f.id, until: Date().timeIntervalSince1970 + 120 * 86400)
            undoNote = UndoNote(text: "Marked as back") { [weak self] in
                if self?.refund(id) != nil { self?.refundBack(id, false) }
                self?.hushed[f.id] = was
            }
        case "dup":
            // charged twice: the second charge is a refund to wait for
            if let second = f.rows.last {
                expectRefund(second, amount: f.amt, by: nil, note: "Charged twice")
                live?.rebuildSoon(force: true)
            }
            hush(f.id, until: Date().timeIntervalSince1970 + 120 * 86400)
            undoNote = UndoNote(text: "Waiting for one back") { [weak self] in
                if let second = f.rows.last { self?.stopRefund(second) }
                self?.hushed[f.id] = was
            }
        default:
            watchDone(f)
        }
    }

    private func hush(_ id: String, until t: Double) {
        let now: Double = Date().timeIntervalSince1970
        var h: [String: Double] = hushed.filter { $0.value > now }
        h[id] = t
        hushed = h
    }
}

struct BellButton: View {
    @Environment(Store.self) private var store
    let info: BellInfo
    /// the count on red or orange when it's urgent, else on the accent's fill (the accent's own ink is light by night:
    /// white on it can't be read), each with the words that read on it
    var tint: Color { info.top >= 3 ? Color.red : info.top == 2 ? Color.orange : Color.koshFill }
    var ink: Color { info.top >= 2 ? Color.white : Color.onKosh }
    var body: some View {
        Button { store.betaSheet = .headsUp } label: {
            HeaderCircle(symbol: "bell")
                .overlay(alignment: .topTrailing) {
                    if info.count > 0 {
                        Text(info.count > 9 ? "9+" : String(info.count))
                            .font(.system(.caption2, design: .rounded, weight: .bold))
                            .monospacedDigit()
                            .foregroundStyle(ink)
                            .padding(.horizontal, 5)
                            .frame(minWidth: 19, minHeight: 19)
                            .background(tint, in: Capsule())
                            .overlay(Capsule().stroke(Color(uiColor: .systemBackground), lineWidth: 2))
                            .offset(x: 5, y: -5)
                            .transition(.scale.combined(with: .opacity))
                    }
                }
                .animation(Motion.large, value: info.count)
        }
        .buttonStyle(.press)
        .accessibilityLabel(info.count == 0 ? "Heads-up: nothing new" : "Heads-up: kosh noticed \(info.count) thing\(info.count == 1 ? "" : "s")")
    }
}

/// the bell opened: kosh's line for the day, what it noticed by how pressing, and the money threads coming up. A list,
/// so only what's on screen is drawn, and each row swipes: right for done (paid, for a bill), left to snooze it
struct HeadsUpSheet: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    @Environment(\.askKosh) private var askKosh
    @State private var open: String?
    /// a heads-up opened on its own page, over the list
    @State private var path: [String] = []
    @State private var brief: String?
    @State private var settled: Int = 0

    struct Level: Identifiable {
        let sev: Int; let name: String; let tint: Color; let items: [WatchItem]
        var id: Int { sev }
    }

    static func levels(_ items: [WatchItem]) -> [Level] {
        let names: [Int: String] = [3: "Act now", 2: "Worth a look", 1: "Good to know"]
        let tints: [Int: Color] = [3: Color.red, 2: Color.orange, 1: Color.kosh]
        return [3, 2, 1].compactMap { sev in
            let group = items.filter { min(3, max(1, $0.sev)) == sev }
            return group.isEmpty ? nil : Level(sev: sev, name: names[sev] ?? "", tint: tints[sev] ?? Color.kosh, items: group)
        }
    }

    var body: some View {
        let items: [WatchItem] = store.watchShown
        let levels: [Level] = Self.levels(items)
        let coming: [JourneyItem] = Array((store.snap.journey?.coming ?? []).prefix(4))
        let line: String? = brief ?? KoshAgent.savedBrief(store.snap.today)
        NavigationStack(path: $path) {
            ScrollViewReader { proxy in
                List {
                    Section { header(items, levels, proxy) }
                        .listRowBackground(Color.clear)
                        .listRowInsets(EdgeInsets(top: 0, leading: 20, bottom: 0, trailing: 20))
                        .listRowSeparator(.hidden)
                    if let line {
                        Section { briefCard(line) }
                            .listRowBackground(Color.clear)
                            .listRowInsets(EdgeInsets(top: 0, leading: 20, bottom: 0, trailing: 20))
                    }
                    if items.isEmpty {
                        Section { allClear }.listRowBackground(Color.clear)
                    }
                    ForEach(levels) { g in
                        Section {
                            ForEach(g.items) { f in row(f, g) }
                        } header: {
                            HStack(spacing: 6) {
                                Circle().fill(g.tint).frame(width: 8, height: 8)
                                Text(g.name.uppercased()).font(.caption.weight(.bold)).tracking(0.6).foregroundStyle(g.tint)
                            }
                        }
                    }
                    if !coming.isEmpty { threads(coming) }
                }
                .listStyle(.insetGrouped)
                .scrollContentBackground(.hidden)
                .listSectionSpacing(14)
                .contentMargins(.top, 0, for: .scrollContent)
                // what scrolls up under Done is hidden by the bar, never read through it
                .scrollEdgeEffectStyle(.hard, for: .top)
                .navigationDestination(for: String.self) { id in page(id) }
            }
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } } }
        }
        // the brief only once the sheet has settled, and only when today's isn't made yet
        .task(id: store.snap.today) {
            guard KoshAgent.savedBrief(store.snap.today) == nil else { return }
            try? await Task.sleep(for: .milliseconds(700))
            if let b = await KoshAgent.brief(store) { withAnimation(Motion.open) { brief = b } }
        }
        .modifier(UndoBar(lift: 16))
        .sensoryFeedback(.selection, trigger: open)
        .sensoryFeedback(.success, trigger: settled)
    }

    func header(_ items: [WatchItem], _ levels: [Level], _ proxy: ScrollViewProxy) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            VStack(alignment: .leading, spacing: 3) {
                Text("Heads-up").font(.system(.largeTitle, design: .rounded, weight: .bold))
                Text(items.isEmpty ? "Nothing needs a look" : Words.cap(Words.number(items.count)) + " thing" + (items.count == 1 ? "" : "s") + " kosh noticed")
                    .font(.subheadline).foregroundStyle(.secondary)
                    .contentTransition(.numericText())
            }
            if levels.count > 1 {
                ScrollView(.horizontal) {
                    HStack(spacing: 8) {
                        ForEach(levels) { g in
                            Button {
                                if let first = g.items.first { withAnimation(Motion.large) { proxy.scrollTo(first.id, anchor: .top) } }
                            } label: {
                                HStack(spacing: 5) {
                                    Text(String(g.items.count)).fontWeight(.bold).monospacedDigit()
                                    Text(g.name)
                                }
                                .font(.footnote.weight(.medium))
                                .lineLimit(1)
                                .fixedSize()
                                .foregroundStyle(g.tint)
                                .padding(.horizontal, 11)
                                .frame(height: 32)
                                .background(g.tint.opacity(0.12), in: Capsule())
                                .frame(minHeight: 44)
                                .contentShape(Rectangle())
                            }
                            .buttonStyle(.press)
                        }
                    }
                }
                .scrollIndicators(.hidden)
                .scrollClipDisabled()
            }
        }
        .padding(.bottom, 4)
    }

    func briefCard(_ text: String) -> some View {
        Button {
            ask("Tell me more about today's brief, and what I should do first.")
        } label: {
            HStack(alignment: .top, spacing: 10) {
                Image(systemName: "sparkles").font(.subheadline.weight(.semibold)).foregroundStyle(Color.kosh)
                Text(AskSheet.rich(text)).font(.subheadline).foregroundStyle(Color.primary).multilineTextAlignment(.leading)
                    .lineLimit(4)
                Spacer(minLength: 0)
            }
            .padding(14)
            .background(Color.kosh.opacity(0.08), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            .privacySensitive()
        }
        .buttonStyle(.press)
        .accessibilityHint("Opens Ask kosh about today's brief")
    }

    var allClear: some View {
        VStack(spacing: 10) {
            Image(systemName: "checkmark.seal.fill").font(.system(size: 42)).foregroundStyle(Color.green)
            Text("All clear").font(.title3.weight(.bold))
            Text("kosh looks again whenever new mail comes in.").font(.subheadline).foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 28)
    }

    /// what kosh asks about one thing, and what each answer does: yes settles it, no keeps it (or asks kosh)
    struct Question { let q: String; let yes: String; let no: String; var noAsks: String? = nil }

    func question(_ f: WatchItem) -> Question? {
        switch f.kind {
        case "due": return Question(q: "Paid it already?", yes: "Paid", no: "Not yet")
        case "renewal": return Question(q: "Paid the premium?", yes: "Paid", no: "Not yet")
        case "rent": return Question(q: "Has it come in?", yes: "Received", no: "Not yet")
        case "refund": return Question(q: "Got it back?", yes: "Got it", no: "Not yet")
        case "dup": return Question(q: "Charged twice?", yes: "Yes, twice", no: "It was two", noAsks: nil)
        case "unusual": return Question(q: "Was this you?", yes: "Yes", no: "No", noAsks: "I don't recognise this: " + f.title + ". What should I do?")
        case "pricerise": return Question(q: "Expected the rise?", yes: "Yes", no: "No", noAsks: f.title + ". Why, and how do I bring it down?")
        case "newsub": return Question(q: "Keeping it?", yes: "Keep", no: "Cancel it", noAsks: "How do I cancel " + f.title.replacingOccurrences(of: "New every month: ", with: "") + "?")
        case "stopped": return Question(q: "Did you stop it?", yes: "Yes", no: "No", noAsks: f.title + ". What should I do?")
        case "short": return Question(q: "Moved money in?", yes: "Done", no: "Not yet")
        case "salary": return Question(q: "Looks right?", yes: "Yes", no: "No", noAsks: f.ask.isEmpty ? nil : f.ask)
        default: return nil
        }
    }

    /// a swipe right's word: the question's yes
    func yesWord(_ f: WatchItem) -> String { question(f)?.yes ?? "Done" }

    func ask(_ seed: String) {
        if let askKosh { askKosh(seed) } else { store.openAsk(seed) }
    }

    /// what a row says: a bill is its name and when it's due; anything else as kosh put it
    func display(_ f: WatchItem) -> (title: String, detail: String) {
        if let a = store.agendaItem(for: f), let d = a.date {
            let n: Int = Day.between(store.snap.today, d)
            let when: String = n <= 0 ? "Due today" : n == 1 ? "Due tomorrow" : "Due " + Day.short(d) + ", in \(n) days"
            return (Self.nameCase(a.name), a.sub.isEmpty ? when : when + " · " + a.sub)
        }
        return (f.title, f.detail)
    }

    /// a payee written all in small letters ("razorpay payments") starts with a capital
    static func nameCase(_ s: String) -> String {
        guard s == s.lowercased(), let f = s.first else { return s }
        return String(f).uppercased() + s.dropFirst()
    }

    /// one thing noticed: tap to open its page; swipe right to answer yes, left to snooze or remove
    func row(_ f: WatchItem, _ g: Level) -> some View {
        let shown = display(f)
        return Button { path.append(f.id) } label: {
            HeadsUpRow(f: f, title: shown.title, detail: shown.detail, tint: g.tint, open: false)
        }
        .buttonStyle(.press)
        .listRowBackground(Color.surface)
        .listRowInsets(EdgeInsets(top: 0, leading: 14, bottom: 0, trailing: 14))
        .listRowSeparatorTint(Color.primary.opacity(0.08))
        .alignmentGuide(.listRowSeparatorLeading) { _ in 48 }
        .swipeActions(edge: .leading, allowsFullSwipe: true) {
            Button { settle(f) { store.watchYes(f) } } label: { Label(yesWord(f), systemImage: "checkmark") }
                .tint(Color.green)
        }
        .swipeActions(edge: .trailing, allowsFullSwipe: false) {
            Button { settle(f) { store.watchRemove(f) } } label: { Label("Remove", systemImage: "xmark") }
                .tint(Color.gray)
            Button { settle(f) { store.watchSnooze(f) } } label: { Label("Snooze", systemImage: "moon.zzz.fill") }
                .tint(Color.indigo)
        }
    }

    func settle(_ f: WatchItem, _ act: () -> Void) {
        withAnimation(Motion.base) {
            if open == f.id { open = nil }
            act()
        }
        settled += 1
        // answered on its own page: back to the list, where it has gone
        if !path.isEmpty { path.removeAll() }
    }

    /// one heads-up on its own page: what it is, in a sentence; the payments behind it; kosh's one question with its two
    /// answers, large; and Snooze, Remove and Ask kosh along the foot
    @ViewBuilder func page(_ id: String) -> some View {
        if let f = (store.snap.watch ?? []).first(where: { $0.id == id }) {
            let g: Level? = Self.levels([f]).first
            let tint: Color = g?.tint ?? Color.kosh
            let shown = display(f)
            let set = Set(f.rows)
            let rows: [Txn] = store.tx.filter { set.contains($0.id) }
            let q: Question? = question(f)
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    VStack(alignment: .leading, spacing: 10) {
                        HStack(spacing: 10) {
                            Image(systemName: f.sym)
                                .font(.system(size: 17, weight: .semibold))
                                .foregroundStyle(tint)
                                .frame(width: 42, height: 42)
                                .background(tint.opacity(0.13), in: Circle())
                            Text((g?.name ?? "").uppercased()).font(.caption.weight(.bold)).tracking(0.6).foregroundStyle(tint)
                            Spacer(minLength: 8)
                            if f.amt > 0 {
                                Text(Fmt.rupees(f.amt)).font(.system(.title2, design: .rounded, weight: .bold)).monospacedDigit()
                            }
                        }
                        Text(shown.title).font(.title3.weight(.bold)).fixedSize(horizontal: false, vertical: true)
                        if !shown.detail.isEmpty {
                            Text(shown.detail).font(.body).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                        }
                    }
                    .privacySensitive()
                    if !rows.isEmpty {
                        VStack(alignment: .leading, spacing: 8) {
                            Text(rows.count == 1 ? "THE PAYMENT" : "THE PAYMENTS").font(.caption.weight(.bold)).tracking(0.6).foregroundStyle(.secondary)
                            VStack(spacing: 0) {
                                ForEach(rows) { t in TxRow(t: t, when: Day.short(t.d)).allowsHitTesting(false) }
                            }
                            .padding(.horizontal, 14)
                            .background(Color.surface, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                        }
                    }
                    if let q {
                        VStack(alignment: .leading, spacing: 10) {
                            Text(q.q).font(.headline)
                            HStack(spacing: 10) {
                                action(q.yes, "checkmark", ink: Self.doneInk, fill: Color.green.opacity(0.14), tall: true) { settle(f) { store.watchYes(f) } }
                                action(q.no, q.noAsks == nil ? "clock" : "sparkles", ink: Color.primary, fill: Color.primary.opacity(0.07), tall: true) {
                                    if let seed = q.noAsks { ask(seed) } else { path.removeAll() }
                                }
                            }
                        }
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 8)
                .padding(.bottom, 24)
            }
            .safeAreaInset(edge: .bottom) {
                HStack(spacing: 10) {
                    foot("Snooze", "moon.zzz") { settle(f) { store.watchSnooze(f) } }
                    foot("Remove", "xmark") { settle(f) { store.watchRemove(f) } }
                    if !f.ask.isEmpty { foot("Ask kosh", "sparkles", ink: Color.kosh) { ask(f.ask) } }
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 8)
            }
            .navigationBarTitleDisplayMode(.inline)
        } else {
            // answered or gone meanwhile
            allClear
        }
    }

    /// one of the three at a page's foot: an icon over its word, on glass
    func foot(_ title: String, _ sym: String, ink: Color = Color.primary, _ act: @escaping () -> Void) -> some View {
        Button(action: act) {
            VStack(spacing: 3) {
                Image(systemName: sym).font(.system(.callout, weight: .semibold))
                Text(title).font(.caption.weight(.semibold)).lineLimit(1)
            }
            .foregroundStyle(ink)
            .frame(maxWidth: .infinity, minHeight: 50)
            .contentShape(Rectangle())
        }
        .buttonStyle(.glass)
    }

    static let doneInk: Color = Color(light: "#17703A", dark: "#5FD38A")

    func action(_ title: String, _ sym: String, ink: Color, fill: Color, tall: Bool = false, _ act: @escaping () -> Void) -> some View {
        Button(action: act) {
            HStack(spacing: 6) {
                Image(systemName: sym).font(.footnote.weight(.bold))
                Text(title).font(tall ? .body.weight(.semibold) : .subheadline.weight(.semibold))
            }
            .foregroundStyle(ink)
            .frame(maxWidth: .infinity, minHeight: tall ? 52 : 44)
            .background(fill, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
            .contentShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
        }
        .buttonStyle(PulsePress())
    }

    func threads(_ coming: [JourneyItem]) -> some View {
        Section {
            ForEach(coming, id: \.id) { item in
                Button { store.betaSheet = .threads(item.id) } label: { JourneyRow(item: item, today: store.snap.today) }
                    .buttonStyle(.press)
                    .listRowBackground(Color.surface)
                    .listRowInsets(EdgeInsets(top: 0, leading: 14, bottom: 0, trailing: 14))
            }
        } header: {
            HStack {
                HStack(spacing: 6) {
                    Circle().fill(Color.kosh).frame(width: 8, height: 8)
                    Text("MONEY THREADS, COMING UP").font(.caption.weight(.bold)).tracking(0.6).foregroundStyle(Color.kosh)
                }
                Spacer()
                Button("See all") { store.betaSheet = .threads(nil) }.font(.subheadline.weight(.semibold)).textCase(nil)
            }
        }
    }
}

struct HeadsUpRow: View {
    let f: WatchItem
    let title: String
    let detail: String
    let tint: Color
    let open: Bool
    var body: some View {
        HStack(alignment: .center, spacing: 12) {
            Image(systemName: f.sym)
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(tint)
                .frame(width: 36, height: 36)
                .background(tint.opacity(0.13), in: Circle())
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(.subheadline.weight(.semibold)).foregroundStyle(Color.primary)
                    .lineLimit(open ? nil : 2)
                    .fixedSize(horizontal: false, vertical: true)
                if !detail.isEmpty {
                    Text(detail).font(.footnote).foregroundStyle(.secondary)
                        .lineLimit(open ? nil : 1)
                        .fixedSize(horizontal: false, vertical: true)
                }
            }
            Spacer(minLength: 6)
            if f.amt > 0 {
                Text(Fmt.short(f.amt)).font(.subheadline.weight(.semibold)).monospacedDigit()
                    .foregroundStyle(Color.primary)
            }
            Image(systemName: "chevron.right").font(.caption.weight(.semibold)).foregroundStyle(.tertiary)
        }
        .padding(.vertical, 12)
        .contentShape(Rectangle())
        .privacySensitive()
    }
}

// MARK: cash flow

/// what came in and what went out: this month so far, the last three months or the last six, as two lines. This month
/// runs day by day (the totals by each day, to today, on the whole month's width); three or six run month by month
struct CashFlowCard: View {
    @Environment(Store.self) private var store
    @AppStorage("home.flowSpan") private var span: Int = 1
    @AppStorage("home.fold.flow") private var folded = false

    struct Point: Identifiable { let x: Int; let label: String; let inn: Double; let out: Double; var id: Int { x } }

    /// this month day by day: what had come in (not transfers in) and gone out (spending and investing) by each day
    func days() -> [Point] {
        let cm: String = store.snap.cm
        let today: Int = Day.dayNumber(store.snap.today)
        // (the month's payments summed by day once a change to them, not a pass over every payment each redraw)
        let key: String = cm + "|" + String(today)
        var inD: [Double]
        var invD: [Double]
        if store.cashDaysMemo.gen == store.txGen && store.cashDaysMemo.key == key {
            inD = store.cashDaysMemo.inD; invD = store.cashDaysMemo.invD
        } else {
            inD = [Double](repeating: 0, count: today + 1)
            invD = [Double](repeating: 0, count: today + 1)
            for t in store.tx where t.d.hasPrefix(cm) {
                let n: Int = Day.dayNumber(t.d)
                guard n >= 1, n <= today else { continue }
                if t.k == "in" { if t.c != "Transfer in" && t.ex == nil { inD[n] += t.a } }
                else if t.investedOut { invD[n] += t.a }
            }
            store.cashDaysMemo = (store.txGen, key, inD, invD)
        }
        // spending by each day is the month's own running line (money back taken off), so the line ends on the
        // figure the card states, not the payments summed again
        let spentBy: [Double] = store.current.map { store.actualPoints($0).map(\.v) } ?? []
        var a: Double = 0, b: Double = 0, last: Double = 0
        return (1...max(1, today)).map { n in
            if n - 1 < spentBy.count { last = spentBy[n - 1] }
            a += inD[n]; b += invD[n]
            return Point(x: n, label: String(n), inn: a, out: last + b)
        }
    }

    var body: some View {
        let all: [CashMonth] = (store.snap.cashflow ?? []).filter { $0.m <= store.snap.cm }
        let n: Int = [1, 3, 6].contains(span) ? span : 1
        let picked: [CashMonth] = Array(all.suffix(n))
        let inn: Double = picked.reduce(0) { $0 + $1.inn }
        let inv: Double = picked.reduce(0) { $0 + $1.inv }
        let spent: Double = picked.reduce(0) { $0 + ($1.live ? store.spentNow : $1.out) }
        let out: Double = spent + inv
        let now: String = Day.fmt(store.snap.cm + "-01", "MMM")
        let each: Int = max(1, picked.count)
        let points: [Point] = n == 1
            ? days()
            : picked.enumerated().map { i, m in
                Point(x: i, label: Day.fmt(m.m + "-01", "MMM"), inn: m.inn, out: (m.live ? store.spentNow : m.out) + m.inv)
            }
        let monthDays: Int = store.current?.days ?? 31
        let sub: String? = inv > 0 ? Fmt.short(inv) + " of it invested" : (n > 1 ? Fmt.short(out / Double(each)) + " a month" : nil)
        let inSub: String? = n > 1 && inn > 0 ? Fmt.short(inn / Double(each)) + " a month" : nil
        let label: String = n == 1 ? now + " so far" : "Last " + String(n) + " months"
        let tag: String = n == 1 ? now : String(n) + "M"
        VStack(alignment: .leading, spacing: 12) {
            SectionHeader(title: "Cash flow", folded: $folded)
            VStack(alignment: .leading, spacing: 0) {
                Unfold(open: !folded, keep: true) {
                    opened(now: now, inn: inn, out: out, inSub: inSub, sub: sub, points: points, daily: n == 1, monthDays: monthDays)
                }
                Unfold(open: folded) {
                    FlowFold(label: label, tag: tag, inn: inn, out: out, inv: inv, bars: Self.bars(all, count: n == 6 ? 6 : 4, spentNow: store.spentNow)) {
                        withAnimation(Fold.spring) { folded = false }
                    }
                }
            }
        }
        .sensoryFeedback(.selection, trigger: span)
    }

    func opened(now: String, inn: Double, out: Double, inSub: String?, sub: String?, points: [Point], daily: Bool, monthDays: Int) -> some View {
        VStack(alignment: .leading, spacing: 16) {
            Picker("Period", selection: $span.animation(Motion.base)) {
                Text(now + " so far").tag(1)
                Text("3M").tag(3)
                Text("6M").tag(6)
            }
            .pickerStyle(.segmented)
            HStack(spacing: 10) {
                figure("Came in", inn > 0 ? Fmt.short(inn) : "—", AnyShapeStyle(Self.inC), inSub)
                figure("Went out", Fmt.short(out), AnyShapeStyle(FlowLines.outInk), sub)
            }
            if points.count > 1 || daily {
                FlowLines(points: points, daily: daily, monthDays: monthDays)
                    .frame(height: 150)
                    .padding(.top, 4)
                    .id(span)
                    .transition(.opacity)
            }
        }
        .card(18)
    }

    static let inC: Color = Color.primary.opacity(0.32)

    /// the last months for the folded card's bars, this one's spending as it stands today
    static func bars(_ all: [CashMonth], count: Int, spentNow: Double) -> [FlowFold.Bar] {
        Array(all.suffix(count)).map { m in
            FlowFold.Bar(id: m.m, letter: String(Day.fmt(m.m + "-01", "MMM").prefix(1)), inn: m.inn,
                         spent: m.live ? spentNow : m.out, inv: m.inv, live: m.live)
        }
    }

    func figure(_ label: String, _ value: String, _ ink: AnyShapeStyle, _ sub: String?) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            HStack(spacing: 6) {
                Capsule().fill(ink).frame(width: 16, height: 4)
                Text(label).font(.footnote).foregroundStyle(.secondary)
            }
            Text(value).font(.system(.title2, design: .rounded, weight: .bold)).monospacedDigit()
                .lineLimit(1).minimumScaleFactor(0.7)
                .contentTransition(.numericText())
                .privacySensitive()
            if let sub { Text(sub).font(.caption).foregroundStyle(.secondary).lineLimit(1) }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.horizontal, 14)
        .padding(.vertical, 12)
        .background(Color(uiColor: .systemBackground), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
    }
}

/// Cash flow, folded, read as Net worth and Spending fold: what went out, big; what came in and what of it was
/// invested, quietly under it; and the last months as pairs of bars (in, then out with its invested part lighter on
/// top), this month lit
struct FlowFold: View {
    struct Bar: Identifiable {
        let id: String
        let letter: String
        let inn: Double
        let spent: Double
        let inv: Double
        let live: Bool
    }
    let label: String
    let tag: String
    let inn: Double
    let out: Double
    let inv: Double
    let bars: [Bar]
    let open: () -> Void

    var body: some View {
        let sub: String = (inn > 0 ? Fmt.words(inn) + " came in" : "nothing came in") + (inv > 0 ? " · " + Fmt.words(inv) + " invested" : "")
        Button(action: open) {
            HStack(alignment: .center, spacing: 14) {
                VStack(alignment: .leading, spacing: 3) {
                    Text("Went out · " + label).font(.system(.footnote, weight: .semibold)).foregroundStyle(.secondary).lineLimit(1)
                    Text(Fmt.words(out))
                        .font(.system(.title, design: .rounded, weight: .bold))
                        .monospacedDigit()
                        .lineLimit(1).minimumScaleFactor(0.7)
                        .contentTransition(.numericText(value: out))
                        .privacySensitive()
                    Text(sub).font(.system(.caption)).foregroundStyle(.secondary).lineLimit(1).minimumScaleFactor(0.8).privacySensitive()
                }
                Spacer(minLength: 8)
                VStack(alignment: .trailing, spacing: 6) {
                    FoldTag(text: tag)
                    if bars.count > 1 {
                        FlowBars(bars: bars)
                            .id(tag)
                            .frame(width: 116, height: 50)
                    }
                }
            }
            .padding(16)
            .background { FoldWash() }
            .contentShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
        }
        .buttonStyle(.press)
        .accessibilityElement(children: .combine)
        .accessibilityHint("Opens cash flow")
    }
}

/// each month as two slim bars side by side: what came in, and what went out (spent, the invested part lighter on top);
/// the months before quiet, this one in kosh's colour; grown from the floor when the card shows
struct FlowBars: View {
    let bars: [FlowFold.Bar]
    @State private var grown = false
    @Environment(\.accessibilityReduceMotion) private var still

    var body: some View {
        let top: Double = max(1, bars.map { max($0.inn, $0.spent + $0.inv) }.max() ?? 1)
        HStack(alignment: .bottom, spacing: 8) {
            ForEach(bars) { b in
                VStack(spacing: 4) {
                    GeometryReader { g in
                        let h: CGFloat = g.size.height
                        let grow: CGFloat = grown ? 1 : 0.05
                        let inH: CGFloat = max(3, h * CGFloat(b.inn / top) * grow)
                        let spentH: CGFloat = h * CGFloat(b.spent / top) * grow
                        let invH: CGFloat = h * CGFloat(b.inv / top) * grow
                        HStack(alignment: .bottom, spacing: 2) {
                            RoundedRectangle(cornerRadius: 3, style: .continuous)
                                .fill(b.live ? Color.primary.opacity(0.28) : Color.rule.opacity(0.16))
                                .frame(height: inH)
                            VStack(spacing: 0) {
                                if invH > 0.5 {
                                    Rectangle().fill(b.live ? Color.kosh.opacity(0.32) : Color.rule.opacity(0.12)).frame(height: invH)
                                }
                                Rectangle()
                                    .fill(b.live ? AnyShapeStyle(LinearGradient(colors: [Color.sky, Color.kosh], startPoint: .top, endPoint: .bottom)) : AnyShapeStyle(Color.rule.opacity(0.26)))
                                    .frame(height: max(0, spentH))
                            }
                            .frame(height: max(3, spentH + invH))
                            .clipShape(RoundedRectangle(cornerRadius: 3, style: .continuous))
                        }
                        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottom)
                    }
                    Text(b.letter)
                        .font(.system(size: 9.5, weight: b.live ? .bold : .medium))
                        .foregroundStyle(b.live ? Color.primary : Color.secondary)
                }
            }
        }
        .onAppear {
            if still { grown = true } else { withAnimation(Motion.reveal.delay(0.05)) { grown = true } }
        }
        .accessibilityHidden(true)
    }
}

/// in and out as two lines: this month's running totals by day, or months side by side
struct FlowLines: View {
    let points: [CashFlowCard.Point]
    let daily: Bool
    let monthDays: Int
    @State private var reveal: CGFloat = 0

    /// what went out: the same glowing line as spending, sky into kosh's colour
    static var outInk: LinearGradient { MiniChart.ink }

    var body: some View {
        let top: Double = max(1, points.map { max($0.inn, $0.out) }.max() ?? 1) * 1.15
        let last: CashFlowCard.Point? = points.last
        let curve: InterpolationMethod = daily ? InterpolationMethod.stepEnd : InterpolationMethod.monotone
        Chart {
            // a soft fill under what went out
            ForEach(points) { p in
                AreaMark(x: .value("When", p.x), y: .value("Amount", p.out), series: .value("Series", "outFill"))
                    .foregroundStyle(LinearGradient(colors: [Color.kosh.opacity(0.2), Color.kosh.opacity(0)], startPoint: .top, endPoint: .bottom))
                    .interpolationMethod(.monotone)
            }
            // what came in: a quiet grey line, in steps as money lands
            ForEach(points) { p in
                LineMark(x: .value("When", p.x), y: .value("Amount", p.inn), series: .value("Series", "in"))
                    .foregroundStyle(CashFlowCard.inC)
                    .lineStyle(StrokeStyle(lineWidth: 2.5, lineCap: .round, lineJoin: .round))
                    .interpolationMethod(curve)
            }
            // what went out: the glowing line
            ForEach(points) { p in
                LineMark(x: .value("When", p.x), y: .value("Amount", p.out), series: .value("Series", "out"))
                    .foregroundStyle(Self.outInk)
                    .lineStyle(StrokeStyle(lineWidth: 3, lineCap: .round, lineJoin: .round))
                    .interpolationMethod(.monotone)
                    .shadow(color: Color.kosh.opacity(0.5), radius: 6, y: 2)
            }
            if let last {
                PointMark(x: .value("When", last.x), y: .value("Amount", last.inn))
                    .foregroundStyle(Color.primary.opacity(0.45))
                    .symbolSize(40)
                PointMark(x: .value("When", last.x), y: .value("Amount", last.out))
                    .foregroundStyle(Color.kosh.opacity(0.18))
                    .symbolSize(240)
                PointMark(x: .value("When", last.x), y: .value("Amount", last.out))
                    .foregroundStyle(Color.kosh)
                    .symbolSize(52)
                    .shadow(color: Color.kosh.opacity(0.7), radius: 5)
            }
        }
        .chartXScale(domain: daily ? 1...max(2, monthDays) : 0...max(1, points.count - 1))
        .chartYScale(domain: 0...top)
        .chartYAxis(.hidden)
        .chartLegend(.hidden)
        .chartXAxis {
            AxisMarks(values: ticks(last?.x ?? 1)) { v in
                AxisValueLabel {
                    Text(label(v.as(Int.self) ?? 0, today: last?.x ?? 1))
                        .font(.caption2.weight(.medium))
                        .foregroundStyle(.secondary)
                }
            }
        }
        .chartPlotStyle { plot in plot.padding(.horizontal, 4).padding(.top, 8) }
        .mask(alignment: .leading) {
            GeometryReader { g in Rectangle().frame(width: g.size.width * reveal) }
        }
        .onAppear { withAnimation(Motion.reveal.delay(0.1)) { reveal = 1 } }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(daily ? "This month day by day, money in and money out" : "Month by month, money in and money out")
        .privacySensitive()
    }

    /// the 1st, today and the month's last day; or every month
    func ticks(_ today: Int) -> [Int] {
        daily ? Array(Set([1, today, monthDays])).sorted() : points.map(\.x)
    }

    func label(_ x: Int, today: Int) -> String {
        if daily { return x == today && x != 1 && x != monthDays ? "today" : String(x) }
        return x >= 0 && x < points.count ? points[x].label : ""
    }
}

// MARK: this week

/// Monday to Sunday: what went out on the days gone, what's due on the days to come; a day tapped shows its list
struct WeekCard: View {
    @Environment(Store.self) private var store
    @State private var picked: String = ""
    @Namespace private var ns

    static func days(_ today: String) -> [String] {
        let w: Int = Day.cal.component(.weekday, from: Day.date(today))
        let back: Int = (w + 5) % 7
        let monday: String = Day.add(today, -back)
        return (0..<7).map { Day.add(monday, $0) }
    }

    /// what went out on a day gone by, from its month's running total
    func spent(_ d: String) -> Double {
        guard let mo = store.month(String(d.prefix(7))) else { return 0 }
        let n: Int = Day.dayNumber(d)
        guard n >= 1, n <= mo.cum.count else { return 0 }
        return max(0, mo.cum[n - 1] - (n >= 2 ? mo.cum[n - 2] : 0))
    }

    var body: some View {
        let today: String = store.snap.today
        let days: [String] = Self.days(today)
        let dated: [AgendaItem] = store.datedAhead
        let end: String = days.last ?? today
        let goingOut: Double = dated.filter { ($0.date ?? "") <= end && $0.kind != "in" }.reduce(0) { $0 + $1.amt }
        let day: String = picked.isEmpty ? today : picked
        VStack(alignment: .leading, spacing: 12) {
            SectionHeader(title: "This week", detail: goingOut > 0 ? Fmt.short(goingOut) + " to go out" : nil, action: "Calendar") {
                store.push(.calendar)
            }
            HStack(spacing: 6) {
                ForEach(days, id: \.self) { d in tile(d, today: today, items: dated.filter { $0.date == d }, on: d == day) }
            }
            dayList(day, today: today, items: dated.filter { $0.date == day })
                .id(day)
                .transition(.blurReplace)
        }
        .animation(Motion.base, value: day)
        .sensoryFeedback(.selection, trigger: picked)
    }

    func tile(_ d: String, today: String, items: [AgendaItem], on: Bool) -> some View {
        let past: Bool = d < today
        let dots: [Color] = items.prefix(3).map { $0.kind == "in" ? Color.green : store.catColor($0.cat) }
        let went: Double = past ? spent(d) : 0
        return Button { picked = d } label: {
            VStack(spacing: 5) {
                Text(Day.fmt(d, "EEE").uppercased())
                    .font(.system(.caption2, weight: .bold))
                    .foregroundStyle(on ? Color.onKosh.opacity(0.85) : (d == today ? Color.kosh : Color.secondary))
                Text(String(Day.dayNumber(d)))
                    .font(.system(.body, design: .rounded, weight: .semibold))
                    .foregroundStyle(on ? Color.onKosh : (past ? Color.secondary : Color.primary))
                if past {
                    Text(went > 0 ? Fmt.short(went).replacingOccurrences(of: "₹", with: "") : "–")
                        .font(.system(size: 9.5, weight: .semibold)).monospacedDigit()
                        .foregroundStyle(on ? Color.onKosh.opacity(0.85) : Color.secondary)
                        .lineLimit(1).minimumScaleFactor(0.7)
                        .frame(height: 12)
                        .privacySensitive()
                } else {
                    HStack(spacing: 3) {
                        ForEach(0..<dots.count, id: \.self) { k in Circle().fill(on ? Color.onKosh : dots[k]).frame(width: 5, height: 5) }
                    }
                    .frame(height: 12)
                }
            }
            .frame(maxWidth: .infinity)
            .frame(height: 76)
            .background {
                if on {
                    RoundedRectangle(cornerRadius: 16, style: .continuous).fill(Color.koshFill).matchedGeometryEffect(id: "day", in: ns)
                } else {
                    RoundedRectangle(cornerRadius: 16, style: .continuous).fill(past ? Color.clear : Color.surface)
                        .overlay { if past { RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(Color.primary.opacity(0.08), lineWidth: 1) } }
                }
            }
            .contentShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
        }
        .buttonStyle(.press)
        .accessibilityLabel(Day.long(d))
    }

    @ViewBuilder func dayList(_ d: String, today: String, items: [AgendaItem]) -> some View {
        let label: String = d == today ? "Today" : Day.fmt(d, "EEEE")
        if d < today {
            let went: Double = spent(d)
            HStack {
                Text(label).font(.subheadline.weight(.semibold))
                Spacer()
                Text(went > 0 ? Fmt.rupees(went) + " went out" : "Nothing went out").font(.subheadline).foregroundStyle(.secondary)
                    .privacySensitive()
            }
            .padding(.horizontal, 14).frame(minHeight: 48)
            .background(Color.surface, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        } else if items.isEmpty {
            HStack {
                Text(label).font(.subheadline.weight(.semibold))
                Spacer()
                Text("Nothing due").font(.subheadline).foregroundStyle(.secondary)
            }
            .padding(.horizontal, 14).frame(minHeight: 48)
            .background(Color.surface, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        } else {
            VStack(spacing: 0) {
                ForEach(Array(items.prefix(3).enumerated()), id: \.element.id) { n, a in
                    if n > 0 { Divider().padding(.leading, 14) }
                    HStack(spacing: 10) {
                        Circle().fill(a.kind == "in" ? Color.green : store.catColor(a.cat)).frame(width: 7, height: 7)
                        Text(a.name).font(.subheadline).lineLimit(1)
                        Spacer(minLength: 8)
                        Text((a.kind == "in" ? "+" : "") + Fmt.rupees(a.amt)).font(.subheadline.weight(.semibold)).monospacedDigit()
                            .foregroundStyle(a.kind == "in" ? Color.green : Color.primary)
                            .privacySensitive()
                    }
                    .frame(minHeight: 46)
                }
                if items.count > 3 {
                    Button { store.calendarDay = d; store.push(.calendar) } label: {
                        Text("\(items.count - 3) more on \(label.lowercased() == "today" ? "today" : label)").font(.footnote.weight(.semibold))
                            .frame(maxWidth: .infinity, alignment: .leading).frame(minHeight: 40)
                    }
                    .buttonStyle(.press)
                    .foregroundStyle(Color.kosh)
                }
            }
            .padding(.horizontal, 14)
            .background(Color.surface, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        }
    }
}

// MARK: Genie

/// what needs you and what kosh is chasing for you: claims, refunds, money to come back
struct GenieView: View {
    @Environment(Store.self) private var store
    var body: some View {
        let cases: Bool = store.live != nil && (!(store.snap.cases ?? []).isEmpty || !(store.snap.docs ?? []).isEmpty)
        let refunds: Bool = !store.refundsWaiting.isEmpty
        ScrollView {
            VStack(alignment: .leading, spacing: 0) {
                Text("What kosh is doing for you: the claims, refunds and money it follows until they’re done.")
                    .font(.subheadline).foregroundStyle(.secondary)
                    .padding(.horizontal, 20).padding(.top, 6)
                if cases { HomeBlock { CasesCard() } }
                if refunds { HomeBlock { RefundsCard() } }
                if !cases && !refunds {
                    VStack(spacing: 12) {
                        Image(systemName: "sparkles").font(.system(.largeTitle, weight: .semibold)).foregroundStyle(Color.kosh)
                        Text("Nothing to chase right now").font(.title3.weight(.bold))
                        Text("Ask kosh to make a travel claim, find a refund or remind a friend.")
                            .font(.subheadline).foregroundStyle(.secondary).multilineTextAlignment(.center)
                        Button { store.sheet = .ask } label: {
                            Label("Ask kosh", systemImage: "sparkles").font(.body.weight(.semibold)).frame(minHeight: 44).padding(.horizontal, 8)
                        }
                        .buttonStyle(.glassProminent)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.horizontal, 32)
                    .padding(.top, 60)
                }
            }
            .padding(.top, 8)
            .padding(.bottom, 32)
        }
        .background(Color(uiColor: .systemBackground))
    }
}

// MARK: where a month went

/// one way of looking at a month's spending, picked under its line; the pick holds for every month
enum MonthLens: String, CaseIterable, Identifiable {
    case cats, places, fixed, paid, who
    var id: String { rawValue }
    var title: String {
        switch self {
        case .cats: return "Category"
        case .places: return "Places"
        case .fixed: return "Fixed"
        case .paid: return "Paid by"
        case .who: return "Who"
        }
    }
}

/// a month's spending seen one way at a time: by category, the places it went, fixed against everyday, how it was
/// paid, or who spent it. Each is a strip of shares and its three biggest, or (places) the three biggest places.
struct MonthLenses: View {
    @Environment(Store.self) private var store
    let mo: MonthInfo
    @AppStorage("home.monthLens") private var lensRaw: String = MonthLens.cats.rawValue
    @State private var grown = false

    struct Part: Identifiable { let label: String; let v: Double; let color: Color; var sub: String = ""; var id: String { label } }

    var lens: MonthLens { MonthLens(rawValue: lensRaw) ?? .cats }

    /// "Who" only when more than one person spends in this household, and the whole family is shown
    var lenses: [MonthLens] {
        store.who == .family && store.snap.people.count > 1 ? MonthLens.allCases : MonthLens.allCases.filter { $0 != .who }
    }

    var body: some View {
        let shown: MonthLens = lenses.contains(lens) ? lens : .cats
        let spends: [Txn] = shown == .cats && store.who == .family ? [] : store.txs(in: mo.m).filter { $0.sp }
        VStack(alignment: .leading, spacing: 10) {
            ViewThatFits(in: .horizontal) {
                chips(lenses, font: .footnote, pad: 11)
                chips(lenses, font: .caption, pad: 9)
                chips(lenses.filter { $0 != .who }, font: .caption, pad: 9)
            }
            Group {
                if shown == .places { places(spends) } else { split(parts(shown, spends)) }
            }
            .frame(height: 96, alignment: .top)
            .id(shown.rawValue + mo.m)
            .transition(.opacity.combined(with: .offset(y: 6)))
        }
        .animation(Motion.open, value: lensRaw)
        .sensoryFeedback(.selection, trigger: lensRaw)
        .onAppear { withAnimation(Motion.reveal.delay(0.25)) { grown = true } }
    }

    func chips(_ list: [MonthLens], font: Font, pad: CGFloat) -> some View {
        HStack(spacing: 5) {
            ForEach(list) { l in
                let on: Bool = l == lens || (l == .cats && !list.contains(lens))
                Button { lensRaw = l.rawValue } label: {
                    Text(l.title)
                        .font(font.weight(.semibold))
                        .lineLimit(1)
                        .fixedSize()
                        .foregroundStyle(on ? Color(uiColor: .systemBackground) : Color.primary)
                        .padding(.horizontal, pad)
                        .frame(height: 30)
                        .background(Capsule().fill(on ? Color.primary : Color(uiColor: .systemBackground)))
                        .frame(minHeight: 44)
                        .contentShape(Rectangle())
                }
                .buttonStyle(.press)
                .accessibilityAddTraits(on ? .isSelected : [])
                .accessibilityHint("Shows the month by " + l.title.lowercased())
            }
        }
    }

    // MARK: the shares

    func parts(_ l: MonthLens, _ spends: [Txn]) -> [Part] {
        switch l {
        case .cats:
            if store.who == .family {
                return mo.cats.filter { $0.v > 0 }.sorted { $0.v > $1.v }.map { Part(label: $0.cat, v: $0.v, color: Color(hex: $0.color)) }
            }
            if let mine = store.spentCats(mo) { return mine.map { Part(label: $0.cat, v: $0.v, color: store.catColor($0.cat)) } }
            return Self.group(spends) { $0.c }.map { Part(label: $0.key, v: $0.value, color: store.catColor($0.key)) }
        case .fixed:
            let fixed: Double = spends.filter(Self.isFixed).reduce(0) { $0 + $1.a }
            let all: Double = spends.reduce(0) { $0 + $1.a }
            return [Part(label: "Everyday", v: all - fixed, color: Color.kosh, sub: "food, shopping, travel, the rest"),
                    Part(label: "Fixed", v: fixed, color: Color.secondary.opacity(0.55), sub: "EMIs, bills, rent, subscriptions")].filter { $0.v > 0 }
        case .paid:
            return Self.group(spends) { Self.how($0.md) }.map { Part(label: $0.key, v: $0.value, color: Self.howColor($0.key)) }
        case .who:
            // each person's part as the picker shows it (the engine's, money back taken off), so a person's slice here is
            // their figure when they are picked; the payments summed again only for a build from before it was sent
            var byWho: [(key: String, value: Double)] = []
            if let w = mo.who {
                for x in w where x.v > 0 { byWho.append((key: x.o, value: x.v)) }
                byWho.sort { $0.value > $1.value }
            } else {
                byWho = Self.group(spends) { $0.o }
            }
            return byWho.map { (e: (key: String, value: Double)) -> Part in
                let p: PersonInfo? = store.snap.people.first { $0.id == e.key }
                // (a joint account's spending is the household's; a name still to confirm by the name its mail gives)
                let other: String = e.key == "family" ? "Joint" : (store.snap.personName(e.key) ?? e.key.capitalized)
                return Part(label: e.key == "me" ? "You" : (p?.name ?? other), v: e.value, color: p.map { Color(hex: $0.color) } ?? Color.kosh)
            }
        case .places:
            return []
        }
    }

    static func group(_ list: [Txn], by key: (Txn) -> String) -> [(key: String, value: Double)] {
        var by: [String: Double] = [:]
        for t in list { by[key(t), default: 0] += t.a }
        return by.filter { $0.value > 0 }.sorted { $0.value > $1.value }
    }

    /// what comes round whatever you do: EMIs, bills, subscriptions, insurance, rent and the house's running costs, fees
    static func isFixed(_ t: Txn) -> Bool {
        if ["EMI", "Bills", "Subscriptions", "Insurance"].contains(t.c) { return true }
        if t.c == "Home" && ["Rent", "Maintenance", "Domestic help"].contains(t.s) { return true }
        return t.c == "Education" && t.s == "Fees"
    }

    static func how(_ md: String?) -> String {
        switch md ?? "" {
        case "upi": return "UPI"
        case "card": return "Cards"
        case "transfer", "auto", "bank": return "Bank and auto-pay"
        case "cash", "atm": return "Cash"
        case "wallet": return "Wallets"
        default: return "Other"
        }
    }

    static func howColor(_ how: String) -> Color {
        switch how {
        case "UPI": return Color(hex: "#1F9E89")
        case "Cards": return Color.kosh
        case "Bank and auto-pay": return Color(hex: "#7A5AF8")
        case "Cash": return Color(hex: "#E8833A")
        case "Wallets": return Color(hex: "#C2459B")
        default: return Color.secondary.opacity(0.5)
        }
    }

    /// the five biggest in their colours, the rest as one grey
    static func strip(_ all: [Part]) -> [Part] {
        let top = Array(all.prefix(5))
        let rest: Double = all.dropFirst(5).reduce(0) { $0 + $1.v }
        return rest > 0 ? top + [Part(label: "Everything else", v: rest, color: Color.secondary.opacity(0.3))] : top
    }

    @ViewBuilder func split(_ all: [Part]) -> some View {
        let sum: Double = all.reduce(0) { $0 + $1.v }
        if sum > 0 {
            let strip: [Part] = Self.strip(all)
            VStack(alignment: .leading, spacing: 10) {
                GeometryReader { g in
                    let room: CGFloat = g.size.width - CGFloat(max(0, strip.count - 1)) * 3
                    HStack(spacing: 3) {
                        ForEach(strip) { p in
                            Capsule().fill(p.color)
                                .frame(width: max(4, room * CGFloat(p.v / sum) * (grown ? 1 : 0.02)))
                        }
                    }
                }
                .frame(height: 8)
                VStack(spacing: 4) {
                    ForEach(all.prefix(3)) { p in
                        HStack(spacing: 8) {
                            Circle().fill(p.color).frame(width: 8, height: 8)
                            Text(p.label).font(.subheadline).lineLimit(1)
                            if !p.sub.isEmpty {
                                Text(p.sub).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                            }
                            Spacer(minLength: 6)
                            Text(Fmt.pct(p.v / sum)).font(.caption.weight(.medium)).foregroundStyle(.secondary).monospacedDigit()
                            Text(Fmt.short(p.v)).font(.subheadline.weight(.semibold)).monospacedDigit()
                                .frame(minWidth: 58, alignment: .trailing)
                        }
                        .frame(height: 22)
                    }
                }
            }
            .privacySensitive()
            .accessibilityElement(children: .ignore)
            .accessibilityLabel(all.prefix(4).map { $0.label + " " + Fmt.pct($0.v / sum) }.joined(separator: ", "))
        } else {
            Text("Nothing to show for this month yet.").font(.subheadline).foregroundStyle(.secondary)
        }
    }

    // MARK: the places

    struct Place: Identifiable { let name: String; let v: Double; let n: Int; let cat: String; var id: String { name } }

    /// the three places most of the month went: the app or store when kosh knows it, else the payee
    static func topPlaces(_ spends: [Txn]) -> [Place] {
        var by: [String: Place] = [:]
        for t in spends {
            let k: String = (t.pf ?? "").isEmpty ? t.m : (t.pf ?? t.m)
            let o: Place = by[k] ?? Place(name: k, v: 0, n: 0, cat: t.c)
            by[k] = Place(name: k, v: o.v + t.a, n: o.n + 1, cat: o.cat)
        }
        return Array(by.values.sorted { $0.v > $1.v }.prefix(3))
    }

    @ViewBuilder func places(_ spends: [Txn]) -> some View {
        let top: [Place] = Self.topPlaces(spends)
        if top.isEmpty {
            Text("Nothing to show for this month yet.").font(.subheadline).foregroundStyle(.secondary)
        } else {
            VStack(spacing: 4) {
                ForEach(top) { p in
                    HStack(spacing: 10) {
                        Text(String(p.name.prefix(1)).uppercased())
                            .font(.caption.weight(.bold))
                            .foregroundStyle(store.catColor(p.cat))
                            .frame(width: 26, height: 26)
                            .background(store.catColor(p.cat).opacity(0.15), in: Circle())
                        VStack(alignment: .leading, spacing: 0) {
                            Text(p.name).font(.subheadline.weight(.medium)).oneLineUnlessLarge()
                            Text(p.n == 1 ? "once" : String(p.n) + " times").font(.caption2).foregroundStyle(.secondary)
                        }
                        Spacer(minLength: 6)
                        Text(Fmt.short(p.v)).font(.subheadline.weight(.semibold)).monospacedDigit()
                    }
                    .frame(height: 29)
                }
            }
            .privacySensitive()
        }
    }
}
