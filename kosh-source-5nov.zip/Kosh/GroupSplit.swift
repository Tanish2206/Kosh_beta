import SwiftUI

// MARK: - Several payments split at once (3 Nov 2026)
//
// An outing is rarely one payment: lunch at one place, a cab, coffee somewhere else. Tick them in Transactions, then
// Split together: say who was out with you and how it's shared (equally, by shares, or your own share as a %), leave
// anyone out of a payment they weren't in on (the cab only two of you took), and kosh splits each payment the way the
// single split does: their shares leave your spending and wait under Owed to you, one line a payment. It can also put
// them all in a chapter of their own, and gives each person one message with their total.

enum GroupWay: String, CaseIterable, Hashable {
    case equal, shares, mine
    var title: String {
        switch self {
        case .equal: return "Equally"
        case .shares: return "By shares"
        case .mine: return "My share %"
        }
    }
}

enum GroupSplitMath {
    static let you: String = "You"
    static func paisa(_ v: Double) -> Double { (v * 100).rounded() / 100 }
    /// one payment's parts: who's in it (you among them or not), by the way chosen; the payer (you) takes the paisa left
    /// over, so the parts come to the payment. Names not in it take nothing
    static func parts(amount: Double, inIt: [String], way: GroupWay, weight: [String: Int], minePct: Double) -> [String: Double] {
        var out: [String: Double] = [:]
        let whole: Double = paisa(max(0, amount))
        let others: [String] = inIt.filter { $0 != you }
        let meIn: Bool = inIt.contains(you)
        guard !inIt.isEmpty else { return [you: whole] }
        switch way {
        case .equal, .shares:
            let w: (String) -> Double = { way == .equal ? 1 : Double(max(1, weight[$0] ?? 1)) }
            let total: Double = inIt.reduce(0) { $0 + w($1) }
            for o in others { out[o] = paisa(whole * w(o) / total) }
        case .mine:
            let mine: Double = meIn ? paisa(whole * min(100, max(0, minePct)) / 100) : 0
            let rest: Double = whole - mine
            if !others.isEmpty { for o in others { out[o] = paisa(rest / Double(others.count)) } }
        }
        // (you paid: whatever the others don't take is yours, to the paisa)
        let theirs: Double = out.values.reduce(0, +)
        out[you] = paisa(max(0, whole - theirs))
        return out
    }
}

struct GroupSplitSheet: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    let ids: [String]
    /// who was out with you (you're always there, as the one who paid)
    @State private var people: [String] = []
    @State private var way: GroupWay = .equal
    @State private var weight: [String: Int] = [:]
    @State private var minePct: Double = 50
    /// per payment: the people not in on it ("You" among them when it wasn't yours at all)
    @State private var outOf: [String: Set<String>] = [:]
    @State private var title: String = ""
    @State private var chapter = true
    @State private var newName = ""
    @State private var open: String? = nil
    @State private var done = false

    var rows: [Txn] { ids.compactMap { store.txn($0) }.filter { $0.k == "out" && $0.partOf == nil && $0.refOf == nil }.sorted { ($0.d, $0.t) < ($1.d, $1.t) } }
    var splittable: [Txn] { rows.filter { store.shares(of: $0.id).isEmpty } }
    var skipped: Int { ids.count - splittable.count }
    var everyone: [String] { [GroupSplitMath.you] + people }

    func inIt(_ t: Txn) -> [String] { everyone.filter { !(outOf[t.id] ?? []).contains($0) } }
    func parts(_ t: Txn) -> [String: Double] { GroupSplitMath.parts(amount: t.a, inIt: inIt(t), way: way, weight: weight, minePct: minePct) }
    /// each person's total across the payments, you first
    var totals: [(String, Double)] {
        var by: [String: Double] = [:]
        for t in splittable { for (k, v) in parts(t) { by[k, default: 0] += v } }
        return everyone.map { ($0, GroupSplitMath.paisa(by[$0] ?? 0)) }
    }
    var whole: Double { splittable.reduce(0) { $0 + $1.a } }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    HStack {
                        VStack(alignment: .leading, spacing: 2) {
                            Text(Fmt.rupees(whole)).font(.system(.title, design: .rounded, weight: .bold)).privacySensitive()
                            Text(WalletCards.count(splittable.count, "payment") + spanLine).font(.subheadline).foregroundStyle(.secondary)
                        }
                        Spacer()
                        Image(systemName: "person.3.fill").font(.title2).foregroundStyle(Color.kosh)
                    }
                    TextField("What was it? (Saturday outing)", text: $title)
                    if skipped > 0 {
                        Text(skipped == 1 ? "1 ticked payment is already split or isn’t money out: left as it is." : "\(skipped) ticked payments are already split or aren’t money out: left as they are.")
                            .font(.footnote).foregroundStyle(.secondary)
                    }
                }
                Section("Who was out with you") {
                    ForEach(people, id: \.self) { p in
                        HStack {
                            Image(systemName: "person.crop.circle.fill").foregroundStyle(Color.sky)
                            Text(p)
                            Spacer()
                            if way == .shares { Stepper(String(weight[p] ?? 1) + "×", value: Binding(get: { weight[p] ?? 1 }, set: { weight[p] = $0 }), in: 1...SplitWays.mostShares).fixedSize() }
                        }
                        .swipeActions { Button("Remove", role: .destructive) { people.removeAll { $0 == p }; for k in outOf.keys { outOf[k]?.remove(p) } } }
                    }
                    if way == .shares {
                        HStack {
                            Image(systemName: "person.crop.circle.fill").foregroundStyle(Color.kosh)
                            Text("You")
                            Spacer()
                            Stepper(String(weight[GroupSplitMath.you] ?? 1) + "×", value: Binding(get: { weight[GroupSplitMath.you] ?? 1 }, set: { weight[GroupSplitMath.you] = $0 }), in: 1...SplitWays.mostShares).fixedSize()
                        }
                    }
                    let offer: [String] = store.splitPeople.filter { n in !people.contains { $0.lowercased() == n.lowercased() } }.prefix(10).map { $0 }
                    if !offer.isEmpty {
                        ScrollView(.horizontal) {
                            HStack(spacing: 8) {
                                ForEach(offer, id: \.self) { n in
                                    Button { withAnimation(Motion.base) { add(n) } } label: {
                                        Label(n, systemImage: "plus").font(.footnote.weight(.semibold))
                                            .padding(.horizontal, 11).padding(.vertical, 7)
                                            .background(Color.secondary.opacity(0.12), in: Capsule())
                                    }
                                    .buttonStyle(.plain)
                                }
                            }
                        }
                        .scrollIndicators(.hidden)
                    }
                    HStack {
                        TextField("Add a name", text: $newName).textInputAutocapitalization(.words).submitLabel(.done).onSubmit { add(newName) }
                        Button("Add") { add(newName) }.disabled(newName.trimmingCharacters(in: .whitespaces).isEmpty)
                    }
                }
                Section {
                    Picker("Shared", selection: $way) { ForEach(GroupWay.allCases, id: \.self) { Text($0.title).tag($0) } }
                        .pickerStyle(.segmented)
                    if way == .mine {
                        VStack(alignment: .leading) {
                            Text("Your share: \(Int(minePct))% of each payment you were in on").font(.subheadline)
                            Slider(value: $minePct, in: 0...100, step: 5)
                        }
                    }
                } header: { Text("How it’s shared") } footer: {
                    Text(way == .equal ? "Each payment is shared equally between whoever was in on it." : way == .shares ? "Someone who counts for two (a couple) takes twice the share of each payment." : "You take this much of each payment; the rest is shared equally between the others in it.")
                }
                Section {
                    ForEach(splittable) { t in
                        GroupPayRow(t: t, everyone: everyone, parts: parts(t), inCount: inIt(t).count,
                                    out: Binding(get: { outOf[t.id] ?? [] }, set: { outOf[t.id] = $0 }),
                                    expanded: Binding(get: { open == t.id }, set: { open = $0 ? t.id : nil }))
                    }
                } header: { Text("Each payment") } footer: { Text("Open a payment to leave out anyone who wasn’t in on it, you included.") }
                Section("Who owes what") {
                    ForEach(totals, id: \.0) { (n, v) in
                        HStack {
                            Text(n == GroupSplitMath.you ? "Your spending" : n)
                            Spacer()
                            Text(Fmt.rupees(v)).monospacedDigit().foregroundStyle(n == GroupSplitMath.you ? Color.primary : Color.green).privacySensitive()
                        }
                    }
                    if !people.isEmpty {
                        ShareLink(item: message) { Label("Send everyone their share", systemImage: "square.and.arrow.up") }
                    }
                }
                Section {
                    Toggle("Keep them together as a chapter", isOn: $chapter)
                } footer: {
                    Text("A chapter of their own (an event), so the outing shows as one thing in Chapters and Insights.")
                }
            }
            .navigationTitle("Split together")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Split") { commit() }.disabled(people.isEmpty || splittable.isEmpty || store.live == nil)
                }
            }
            .onAppear(perform: start)
        }
    }

    var spanLine: String {
        guard let a = splittable.first?.d, let b = splittable.last?.d else { return "" }
        return a == b ? ", " + Day.fmt(a, "EEE d MMM") : ", " + Day.fmt(a, "d MMM") + " – " + Day.fmt(b, "d MMM")
    }
    var message: String {
        let name: String = label
        var lines: [String] = [name + ": " + Fmt.rupees(whole) + " in all."]
        for (n, v) in totals where n != GroupSplitMath.you && v > 0 { lines.append(n + ": " + Fmt.rupees(v)) }
        return lines.joined(separator: "\n")
    }
    var label: String {
        let t: String = title.trimmingCharacters(in: .whitespacesAndNewlines)
        if !t.isEmpty { return t }
        return "Outing" + (splittable.first.map { " on " + Day.fmt($0.d, "EEE d MMM") } ?? "")
    }

    func start() {
        guard people.isEmpty else { return }
        // (the people you split the last of these payees with, as a single split guesses: a good start)
        var guess: [String] = []
        for t in splittable { for n in store.splitGuess(for: t).names where !guess.contains(n) { guess.append(n) } }
        people = Array(guess.prefix(6))
    }
    func add(_ raw: String) {
        let n: String = String(raw.trimmingCharacters(in: .whitespacesAndNewlines).prefix(30))
        guard !n.isEmpty, n.lowercased() != "you", !people.contains(where: { $0.lowercased() == n.lowercased() }), people.count < SplitWays.most - 1 else { newName = ""; return }
        people.append(n)
        newName = ""
    }
    func commit() {
        let name: String = label
        var ids: [String] = []
        for t in splittable {
            let p: [String: Double] = parts(t)
            let shares: [(name: String, amount: Double)] = people.compactMap { n in
                let v: Double = p[n] ?? 0
                return v > 0 ? (name: n, amount: v) : nil
            }
            guard !shares.isEmpty else { continue }
            store.shareCharge(t.id, shares: shares, title: name)
            ids.append(t.id)
        }
        var made: String? = nil
        if chapter, !ids.isEmpty, let first = splittable.first?.d, let last = splittable.last?.d {
            let id: String = "trip-" + String(UUID().uuidString.prefix(8)).lowercased()
            made = id
            var u = UserTrip(id: id, name: name, kind: "event", from: first, to: last)
            u.sym = "person.3.fill"; u.color = "#5856D6"; u.auto = false
            u.note = "Split with " + people.joined(separator: ", ")
            store.saveTrip(u)
            store.addToTrip(ids, id)
        }
        let n: Int = ids.count
        store.undoNote = UndoNote(text: "Split \(n) payment\(n == 1 ? "" : "s") with " + people.joined(separator: ", ")) { [weak store] in
            for id in ids { store?.unshare(id) }
            if let made {
                store?.live?.removeTrip(made)
                for id in ids { store?.live?.override(id) { $0.tr = nil } }
                store?.live?.rebuildSoon()
            }
        }
        withAnimation(Motion.open) { store.ledgerSelecting = false; store.ledgerSelected = [] }
        dismiss()
    }
}

/// one payment of a group split: what it was, your part, and (opened) who was in on it
struct GroupPayRow: View {
    let t: Txn
    let everyone: [String]
    let parts: [String: Double]
    let inCount: Int
    @Binding var out: Set<String>
    @Binding var expanded: Bool
    var body: some View {
        DisclosureGroup(isExpanded: $expanded) {
            ForEach(everyone, id: \.self) { n in
                person(n)
            }
        } label: {
            label
        }
    }
    func person(_ n: String) -> some View {
        let on: Bool = !out.contains(n)
        let amt: String = on ? Fmt.rupees(parts[n] ?? 0) : "not in it"
        return Button {
            withAnimation(Motion.base) { if on { out.insert(n) } else { out.remove(n) } }
        } label: {
            HStack {
                Image(systemName: on ? "checkmark.circle.fill" : "circle").foregroundStyle(on ? Color.kosh : Color.secondary)
                Text(n).foregroundStyle(Color.primary)
                Spacer()
                Text(amt).foregroundStyle(.secondary).monospacedDigit().privacySensitive()
            }
        }
    }
    var label: some View {
        let when: String = Day.fmt(t.d, "EEE d MMM") + (t.t.isEmpty ? "" : " · " + Day.time12(t.t))
        let sub: String = when + " · " + String(inCount) + " in it"
        let mine: String = "yours " + Fmt.rupees(parts[GroupSplitMath.you] ?? 0)
        return HStack {
            VStack(alignment: .leading, spacing: 1) {
                Text(t.m).lineLimit(1)
                Text(sub).font(.caption).foregroundStyle(.secondary)
            }
            Spacer()
            VStack(alignment: .trailing, spacing: 1) {
                Text(Fmt.rupees(t.a)).monospacedDigit().privacySensitive()
                Text(mine).font(.caption).foregroundStyle(.secondary).monospacedDigit().privacySensitive()
            }
        }
    }
}
