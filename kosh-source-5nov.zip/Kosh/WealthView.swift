import SwiftUI
import Charts

// MARK: - Wealth (the tab was Portfolio until 1 Nov 2026): what the family holds and owes
//
// Its Overview is WealthHome (WealthHome.swift, the Obsidian look, with the map of everything owned: WealthMap.swift);
// Holdings is a view a kind (WealthHoldings.swift, since 1 Nov); Debts is as it was. The whole tab,
// and every page pushed in it, is drawn dark whatever the phone is set to (obsidianPage, Obsidian.swift), as
// Insurance is.

struct PortfolioView: View {
    @Environment(Store.self) private var store
    var body: some View {
        @Bindable var store = store
        NavigationStack(path: $store.portPath) {
            PortfolioPage()
                // every page opened from Wealth is drawn black too (an account, a property, a month...)
                .navigationDestination(for: Route.self) { route in RouteDestination(route: route, zoom: nil).obsidianPage() }
        }
        .environment(\.colorScheme, .dark)
    }
}

struct PortfolioPage: View {
    @Environment(Store.self) private var store
    var body: some View {
        @Bindable var store = store
        Group {
            switch store.portSub {
            case .overview: WealthHome()
            // a view a kind, no "All": the whole picture is Overview's map (WealthHoldings.swift)
            case .investments: WealthHoldings()
            case .loans: LoansView()
            }
        }
        .subSlide(store.portSub)
        .barFollows()
        .safeAreaInset(edge: .top, spacing: 0) {
            SubTabBar(selection: $store.portSub, arrange: .portfolio)
        }
        .tabHeader("Wealth", add: adds, ownTitle: true)
        .obsidianPage(aura: Obsidian.health)
    }

    /// what + adds here (the beta only: the snapshot build reads, it doesn't add)
    var adds: [HeaderAction] {
        guard store.live != nil else { return [] }
        let s: Store = store
        var out: [HeaderAction] = []
        out.append(HeaderAction(title: "Fixed deposit", symbol: "building.columns") { s.betaSheet = .holding("new:FD") })
        out.append(HeaderAction(title: "EPF, from the EPFO passbook", symbol: "briefcase") { s.betaSheet = .epf })
        out.append(HeaderAction(title: "PPF or NPS", symbol: "lock") { s.betaSheet = .holding("new:PPF") })
        out.append(HeaderAction(title: "Shares or a fund", symbol: "chart.line.uptrend.xyaxis") { s.betaSheet = .holding(nil) })
        out.append(HeaderAction(title: "Physical gold", symbol: "seal") { s.betaSheet = .holding("new:gold") })
        out.append(HeaderAction(title: "Insurance policy", symbol: "shield", newGroup: true) { s.betaSheet = .policy(nil) })
        out.append(HeaderAction(title: "Loan", symbol: "building.columns.circle") { s.betaSheet = .loan(nil) })
        return out
    }
}

struct HoldingRow: View {
    @Environment(Store.self) private var store
    let h: Holding
    let sym: String
    let color: Color
    let showWho: Bool
    var total: Double = 0
    /// one quiet line: share, kind, whose, rate, maturity
    var detail: String {
        var bits: [String] = []
        if total > 0 && h.amt < total * 0.995 { bits.append(Fmt.pct(h.amt / total) + " of these") }
        if h.cls == "mf" { bits.append(FundKind.of(h.bank).rawValue) }
        if showWho { bits.append(store.ownerName(h.person)) }
        if h.rate > 0 { bits.append("\(Fmt.trim(h.rate, 2))%") }
        if let m = h.mat { bits.append((m < store.snap.cm ? "matured " : "matures ") + Day.fmt(m + "-01", "MMM yyyy")) }
        // still at its statement's figure while the rest of its kind are at the day's price (once the build says how
        // fresh each figure is, HoldingAsOf says it on its own line instead)
        if h.fresh == nil, let a = store.holdingAsOf(h) { bits.append(a) }
        return bits.joined(separator: " · ")
    }
    var body: some View {
        HStack(spacing: 12) {
            HoldingMark(h: h)
            VStack(alignment: .leading, spacing: 2) {
                Text(HoldingName.pretty(h.bank)).font(.body.weight(.medium)).lineLimit(1)
                if !detail.isEmpty {
                    Text(detail).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                }
                // what its figure was read from, and when (PortfolioViews.swift)
                HoldingAsOf(h: h)
                // a deposit's maturity amount, an EPF account's last credit (a fund's or share's is its ISIN: not shown)
                if (h.cls == "ret" || h.cls == "dep") && !h.rem.isEmpty {
                    Text(h.rem).font(.caption).foregroundStyle(.tertiary).lineLimit(1).privacySensitive()
                }
            }
            Spacer(minLength: 8)
            VStack(alignment: .trailing, spacing: 2) {
                Text(Fmt.words(h.amt)).font(.body.weight(.semibold)).privacySensitive()
                // up or down against what went in, where the statement says what went in
                if let g = h.gain, let c = h.cost, c > 0 {
                    Text(Gains.line(g, g / c)).font(.caption.weight(.semibold)).monospacedDigit()
                        .foregroundStyle(g >= 0 ? Color.green : Color.red).lineLimit(1).privacySensitive()
                }
                // and what that comes to a year, where kosh has the dated money behind it
                if let r = h.xirr {
                    Text(Gains.yearly(r)).font(.caption).monospacedDigit().foregroundStyle(.secondary).lineLimit(1).privacySensitive()
                }
            }
            .fixedSize(horizontal: true, vertical: false)
        }
    }
}

/// what stands beside a holding: the bank's icon for a deposit, the fund house's for a fund,
/// the company's initials for a share
struct HoldingMark: View {
    let h: Holding
    var size: CGFloat = 36
    var body: some View {
        let name = HoldingName.pretty(h.bank)
        switch h.cls {
        case "mf":
            if let house = InstSites.fundHouse(for: h.bank) {
                InstIcon(name: name, color: Color.gray, size: size, site: house, plain: true)
            } else {
                Monogram(name: name, size: size)
            }
        case "stk":
            if let site = CompanySites.shared.domain(name: h.bank, isin: h.isin) {
                InstIcon(name: name, color: Color.gray, size: size, site: site, plain: true)
            } else {
                Monogram(name: name, size: size)
            }
        default:
            InstIcon(name: name, color: Color.gray, size: size, site: InstSites.domain(for: h.bank + " " + h.type), plain: true)
        }
    }
}

// MARK: - Insurance

struct InsuranceTabView: View {
    @Environment(Store.self) private var store
    var body: some View {
        @Bindable var store = store
        NavigationStack(path: $store.insPath) {
            // (the four parts keep their order: nothing to arrange)
            InsuranceBook()
                .tabHeader("Insurance", add: store.live == nil ? [] : [
                    HeaderAction(title: "Add a policy", symbol: "shield") { store.betaSheet = .policy(nil) },
                ])
                // (the black look: its top row too)
                .obsidianPage(aura: Obsidian.savings)
                .navigationDestination(for: Route.self) { route in RouteDestination(route: route, zoom: nil).obsidianPage() }
        }
    }
}

enum PolicyLook {
    static func sym(_ type: String) -> String {
        switch type {
        case "Health": return "cross.case.fill"
        case "Life": return "heart.fill"
        case "Motor": return "car.fill"
        default: return "shield.fill"
        }
    }
    static func color(_ type: String) -> Color {
        // (Insurance's kind colours, as its Obsidian home draws them: InsLook)
        switch type {
        case "Health": return Obsidian.health
        case "Life": return Obsidian.term
        case "Motor": return Obsidian.motor
        default: return Obsidian.ink2
        }
    }
}

/// the kinds of cover, in the order a person thinks of them, the part of Insurance each is in, and what each one is
enum PolicyKinds {
    static let order = ["Health", "Top-up", "Accident", "Term", "ULIP", "Endowment", "Savings", "Money back", "Pension", "Whole life", "Life",
                        "Car", "Two-wheeler", "Vehicle", "Home", "Travel", "Other"]
    static let healthKinds: Set<String> = ["Health", "Top-up"]
    static let lifeKinds: Set<String> = ["Term", "ULIP", "Endowment", "Savings", "Money back", "Pension", "Whole life", "Life"]
    static let motorKinds: Set<String> = ["Car", "Two-wheeler", "Vehicle"]
    static func of(_ p: Policy) -> String {
        if let k = p.kind, !k.isEmpty { return k }
        switch p.type { case "Motor": return "Vehicle"; case "Policy": return "Other"; default: return p.type }
    }
    /// Health, Life, Motor, or Other (travel, home, accident and the like)
    static func part(_ p: Policy) -> String {
        let k: String = of(p)
        if healthKinds.contains(k) { return "Health" }
        if lifeKinds.contains(k) { return "Life" }
        if motorKinds.contains(k) || p.type == "Motor" { return "Motor" }
        return "Other"
    }
    /// a policy kosh knows only from what was paid to its insurer: no number, no cover. It waits in Needs a look
    /// (add its number, or say it's ended), never a row of blanks
    static func onlyPaid(_ p: Policy) -> Bool { p.source == "payments" && (p.policyNo ?? "").isEmpty && (p.cover ?? 0) <= 0 }
    /// only the kinds this household holds
    static func present(_ all: [Policy]) -> [String] {
        let have = Set(all.map(of))
        return order.filter { have.contains($0) } + have.subtracting(order).sorted()
    }
    static func title(_ k: String) -> String {
        switch k {
        case "Top-up": return "Health top-up"
        case "Savings": return "Savings plan"
        case "Life": return "Life"
        case "Accident": return "Personal accident"
        case "Vehicle": return "Motor"
        case "Other": return "Other cover"
        default: return k
        }
    }
    static func blurb(_ k: String) -> String {
        switch k {
        case "Health": return "Pays hospital bills, up to the sum insured each year. Renews every year."
        case "Top-up": return "Pays once a bill crosses its deductible, on top of the base health cover."
        case "Accident": return "Pays on death or disability from an accident."
        case "Term": return "Pure life cover: pays the sum assured if the insured dies within the term, nothing at the end."
        case "ULIP": return "Life cover plus an investment in funds: what it's worth moves with the market."
        case "Endowment": return "Life cover plus savings: pays the sum assured and bonuses at maturity."
        case "Savings": return "Life cover that's a small part of what you pay: the rest is saved and paid back."
        case "Money back": return "Pays part of the sum assured back at set points during the term."
        case "Pension": return "Builds a corpus that pays a pension after retirement."
        case "Whole life": return "Life cover that lasts to age 99 or 100."
        case "Car", "Two-wheeler", "Vehicle": return "Third-party cover is required by law; own damage pays for your vehicle. Renews every year, with no grace period."
        case "Home": return "Covers the building or what's in it against fire, theft and disasters."
        case "Travel": return "Covers medical bills and mishaps on a trip."
        default: return ""
        }
    }
}

/// a part of Insurance at a glance: what it covers, or, while that isn't read, what kosh found and what's missing.
/// Never a ₹0 headline
struct KindHead: View {
    @Environment(Store.self) private var store
    /// "Health", "Life", "Motor" or "Other"
    let part: String
    let pols: [Policy]
    var vehicles: Int = 0
    var body: some View {
        let cover: Double = pols.reduce(0) { $0 + max(0, $1.cover ?? 0) }
        let known: Int = pols.filter { ($0.cover ?? 0) > 0 }.count
        let yearly: Double = pols.reduce(0) { $0 + max(0, $1.yearly) }
        let n: Int = pols.count
        let many: String = n == 1 ? "1 policy" : "\(n) policies"
        let premiums: String = yearly > 0 ? ", " + Fmt.words(yearly) + " a year in premiums" : ""
        let what: String = n == 1 ? "it covers" : "they cover"
        let whatCost: String = n == 1 ? "it covers or costs" : "they cover or cost"
        let name: String = part == "Other" ? "Other cover" : part
        if part == "Motor" {
            PageHead(label: "Motor", value: vehicles == 1 ? "1 vehicle" : "\(vehicles) vehicles",
                     note: "Motor cover has no grace period: it ends on its renewal day. Renew before then to keep driving insured.")
        } else if cover > 0 {
            let label: String = part == "Health" ? "Health cover" : part == "Life" ? "Life cover" : "Cover"
            let unread: String = known < n ? " The cover of \(n - known) is still to be read." : ""
            PageHead(label: label, value: Fmt.words(cover), note: many + premiums + "." + unread)
        } else if yearly > 0 {
            PageHead(label: name + " · premiums a year", value: Fmt.words(yearly),
                     note: "kosh found " + many + " but not yet what " + what + ". Needs a look says where that is.")
        } else {
            VStack(alignment: .leading, spacing: 4) {
                Text(name).font(.title2.weight(.bold)).accessibilityAddTraits(.isHeader)
                Text("kosh found " + many + " but not yet what " + whatCost + ". Each one says what's missing and where it is.")
                    .font(.subheadline).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
    }
}

/// the insurer's own icon, with a small mark for the kind of cover
struct PolicyBadge: View {
    let p: Policy
    var size: CGFloat = 36
    var body: some View {
        InstIcon(name: p.insurer, color: PolicyLook.color(p.type), size: size)
            .cornerMark(PolicyLook.sym(p.type), color: PolicyLook.color(p.type), size: size)
    }
}

/// one policy as a row. Health: its plan, insurer, whom it covers, when it renews; on the right its cover and its
/// premium (or its term, when bought for years at once). Life: its kind and insurer, whose, its cover and premium a year.
/// What isn't known says so, never ₹0
struct PolicyRow: View {
    @Environment(Store.self) private var store
    @Environment(\.dynamicTypeSize) private var type
    let p: Policy
    var title: String {
        PolicyKinds.part(p) == "Life" ? PolicyKinds.title(PolicyKinds.of(p)) + " · " + p.insurer : InsBook.name(p)
    }
    var detail: String {
        switch PolicyKinds.part(p) {
        case "Health": return p.insurer + " · " + InsBook.covers(p, store.snap)
        case "Life": return store.ownerName(p.owner) + ((p.plan ?? "").isEmpty ? "" : " · " + (p.plan ?? ""))
        default: return p.insurer + " · " + store.ownerName(p.owner)
        }
    }
    var when: String {
        if let st = PolicyStatus.chip(p), p.status != "due" { return st.0 }
        if !p.nextDue.isEmpty {
            let word: String = p.nextDue < store.snap.today ? "Was due " : PolicyKinds.part(p) == "Life" ? "Next premium " : "Renews "
            return word + Day.fmt(p.nextDue, "d MMM yyyy")
        }
        if !p.lastPaid.isEmpty { return "Last paid " + Day.fmt(p.lastPaid, "d MMM yyyy") }
        return "Renewal date not in mail yet"
    }
    var coverText: String {
        if let c = p.cover, c > 0 { return Fmt.words(c) }
        // (its paper came locked: the figure shows once it opens, said plainly)
        if InsBook.locked(p) { return "Paper locked" }
        return PolicyKinds.part(p) == "Motor" ? "IDV not read" : "Cover not read"
    }
    var costText: String {
        if let y = p.years, y >= 2 { return "\(y)-year cover" }
        if p.yearly > 0 { return Fmt.rupees(p.yearly) + " a year" }
        if p.premium > 0 { return Fmt.rupees(p.premium) + " " + p.premiumEvery }
        return InsBook.locked(p) ? "Premium in its paper" : "Premium not in mail"
    }
    var body: some View {
        let stacked: Bool = type.isAccessibilitySize
        let layout: AnyLayout = stacked ? AnyLayout(VStackLayout(alignment: .leading, spacing: 6)) : AnyLayout(HStackLayout(alignment: .top, spacing: 12))
        let hasCover: Bool = (p.cover ?? 0) > 0
        let figures: String = (hasCover ? "cover " : "") + coverText
        let said: String = [title, detail, when, figures, costText].joined(separator: ", ")
        layout {
            HStack(alignment: .top, spacing: 12) {
                PolicyBadge(p: p, size: 36)
                VStack(alignment: .leading, spacing: 2) {
                    Text(title).font(.body.weight(.semibold)).foregroundStyle(Color.primary).lineLimit(stacked ? nil : 2)
                    Text(detail).font(.caption).foregroundStyle(.secondary).lineLimit(stacked ? nil : 2)
                    Text(when).font(.caption).foregroundStyle(p.status == "due" || p.status == "overdue" ? Color.orange : Color.secondary)
                }
            }
            if !stacked { Spacer(minLength: 8) }
            VStack(alignment: stacked ? .leading : .trailing, spacing: 2) {
                Text(coverText).font(hasCover ? Font.body.weight(.bold) : Font.caption).monospacedDigit()
                    .foregroundStyle(hasCover ? Color.primary : Color.secondary).privacySensitive()
                Text(costText).font(.caption).foregroundStyle(.secondary).privacySensitive()
            }
            .fixedSize(horizontal: !stacked, vertical: false)
        }
        .contentShape(Rectangle())
        .accessibilityElement(children: .ignore)
        .spokenFigures(said, hidden: [title, detail, when].joined(separator: ", "))
        .accessibilityAddTraits(.isButton)
    }
}

/// one policy, opened: what it covers and costs (or what's missing and where), where it stands, the policy itself,
/// and what kosh knows of its premiums
struct PolicyDetail: View {
    @Environment(Store.self) private var store
    let id: String
    var body: some View {
        if let p = store.snap.policies.first(where: { $0.id == id }) {
            let added = store.captures.filter { $0.kind == "policy:" + p.id }
            let part: String = PolicyKinds.part(p)
            let coverWord: String = part == "Health" ? "Sum insured" : part == "Motor" ? "IDV" : part == "Life" ? "Life cover" : "Cover"
            ObsidianList {
                Section {
                    VStack(spacing: 8) {
                        PolicyBadge(p: p, size: 62)
                        Text(InsBook.name(p)).font(.title3.weight(.semibold)).multilineTextAlignment(.center)
                        Text(p.insurer + " · " + PolicyKinds.title(PolicyKinds.of(p)) + " · " + store.ownerName(p.owner)).font(.subheadline).foregroundStyle(.secondary).multilineTextAlignment(.center)
                        if let c = p.cover, c > 0 {
                            Text(Fmt.words(c))
                                .scaledFont(size: 40, weight: .bold, design: .rounded, relativeTo: .largeTitle)
                                .privacySensitive()
                            Text(part == "Motor" ? coverWord : coverWord.lowercased()).font(.subheadline).foregroundStyle(.secondary)
                        } else {
                            Text(InsBook.unknown(p, "Cover", coverWord)).font(.headline).foregroundStyle(.secondary).multilineTextAlignment(.center)
                        }
                        Text(p.premium > 0 ? InsBook.premiumLine(p) : InsBook.unknown(p, "Premium", "Premium"))
                            .font(.subheadline).foregroundStyle(.secondary).privacySensitive()
                    }
                    .frame(maxWidth: .infinity)
                    .listRowBackground(Color.clear)
                }
                // its paper came locked: what the mail told is below, and the rest shows once the paper opens
                if InsBook.locked(p) {
                    Section {
                        LockedPaperNote(p: p)
                    } footer: {
                        Text("What its mail told is below. Nothing is filled in from a guess.")
                    }
                }
                PolicyStanding(p: p)
                if part == "Motor" {
                    Section {
                        if let r = p.vehicle, !r.isEmpty { LabeledContent("Registration", value: r) } else { LabeledContent("Registration", value: "Not in its mail") }
                        LabeledContent("Cover", value: (p.coverType ?? "").isEmpty ? "Not in its mail" : (p.coverType ?? ""))
                        if let a = p.addOns, !a.isEmpty { LabeledContent("Add-ons", value: a.joined(separator: ", ")) }
                    } header: { Text("The vehicle") } footer: {
                        Text("Motor cover has no grace period: it ends on its renewal day, and driving after that is uninsured.")
                    }
                }
                if let v = p.verdict, !v.isEmpty {
                    Section {
                        HStack(alignment: .top, spacing: 12) {
                            VerdictChip(v: v)
                            Text(p.verdictWhy ?? "").font(.subheadline).fixedSize(horizontal: false, vertical: true)
                        }
                        if let t = p.totalN, t > 0, let n = p.paidN {
                            LabeledContent("Premiums", value: "\(n) of \(t) paid" + ((p.leftN ?? 0) > 0 ? ", \(p.leftN ?? 0) left" : ""))
                            if let x = p.paidIn, x > 0 { LabeledContent("Paid in so far", value: Fmt.words(x)).privacySensitive() }
                            if let e = p.payEnd, !e.isEmpty { LabeledContent("Last premium", value: Day.fmt(e, "MMM yyyy")) }
                        }
                        if let fv = p.fundValue, fv > 0 { LabeledContent("Fund value", value: Fmt.words(fv) + ((p.fundAsOf ?? "").isEmpty ? "" : " · " + Day.fmt(p.fundAsOf ?? "", "d MMM yyyy"))).privacySensitive() }
                        if let m = p.maturity, m > 0 { LabeledContent("At maturity", value: Fmt.words(m)).privacySensitive() }
                        if let x = p.xirr { LabeledContent("Earns a year", value: Fmt.trim(x, 1) + "%") }
                    } header: { Text("The story") }
                }
                Section("The policy") {
                    LabeledContent(coverWord, value: (p.cover ?? 0) > 0 ? Fmt.words(p.cover ?? 0) : Words.cap(InsBook.whereIs(p, "Cover"))).privacySensitive()
                    LabeledContent("Premium", value: p.premium > 0 ? InsBook.premiumLine(p) : Words.cap(InsBook.whereIs(p, "Premium"))).privacySensitive()
                    // (what each ₹1,000 a year of premium buys in cover: the policy's own figures, divided)
                    if let r = CoverPerRupee.of(p) { LabeledContent("Cover per ₹1,000 a year", value: CoverPerRupee.words(r)).privacySensitive() }
                    if let f = p.filled, !f.isEmpty {
                        Text("You added its " + Words.list(f.map { (k: String) -> String in k == "policyNo" ? "policy number" : k == "frequency" ? "premium’s timing" : k })).font(.caption).foregroundStyle(.secondary)
                    }
                    if let y = p.years, y >= 2 { LabeledContent("Term", value: "\(y) years, bought at once") }
                    else if let t = p.term, t > 0 { LabeledContent("Policy term", value: "\(t) years") }
                    if let t = p.ppt, t > 0 { LabeledContent("Pay for", value: "\(t) years") }
                    if let v = p.plan, !v.isEmpty { LabeledContent("Plan", value: v) }
                    if let v = p.policyNo, !v.isEmpty { LabeledContent("Policy number", value: v.count > 4 ? "••" + String(v.suffix(4)) : v) }
                    if let v = p.holder, !v.isEmpty { LabeledContent("Held by", value: v) }
                    if part == "Health" { LabeledContent("Covers", value: Words.cap(InsBook.covers(p, store.snap).replacingOccurrences(of: "covers ", with: ""))) }
                    else if let v = p.insured, !v.isEmpty, v != p.holder { LabeledContent("Insured", value: v) }
                    if PolicyKinds.of(p) == "Top-up" { LabeledContent("Pays", value: "Above its deductible") }
                    if part == "Health", let a = p.addOns, !a.isEmpty { LabeledContent("Add-ons", value: a.joined(separator: ", ")) }
                    if let v = p.nominee, !v.isEmpty { LabeledContent("Nominee", value: v) }
                    if let v = p.frequency, !v.isEmpty { LabeledContent("Premium paid", value: v) }
                    if let v = p.start, !v.isEmpty { LabeledContent("Started", value: Day.fmt(v, "d MMM yyyy")) }
                    if let v = p.end, !v.isEmpty { LabeledContent(part == "Life" ? "Matures" : "Ends", value: Day.fmt(v, "d MMM yyyy")) }
                }
                Section {
                    LabeledContent("Last paid", value: p.lastPaid.isEmpty ? "Not seen yet" : Day.fmt(p.lastPaid, "d MMM yyyy"))
                    LabeledContent(part == "Life" ? "Next premium" : "Renews", value: p.nextDue.isEmpty ? "Not in mail yet" : Day.fmt(p.nextDue, "d MMM yyyy"))
                    if !p.via.isEmpty { LabeledContent("Found", value: p.via) }
                } header: {
                    Text("What kosh knows")
                } footer: {
                    if !p.note.isEmpty { Text(p.note).privacySensitive() }
                }
                if !added.isEmpty {
                    Section("You added") {
                        ForEach(added) { c in
                            VStack(alignment: .leading, spacing: 4) {
                                if let a = c.amount { LabeledContent("Cover", value: Fmt.words(a)).privacySensitive() }
                                if !c.text.isEmpty { Text(c.text).font(.subheadline).foregroundStyle(.secondary) }
                            }
                        }
                    }
                }
                if store.live != nil && !(p.key ?? "").isEmpty {
                    PolicyFillSection(p: p)
                } else if added.isEmpty && !(p.gaps ?? []).isEmpty {
                    Section {
                        ForEach(p.gaps ?? [], id: \.self) { (g: Policy.Gap) in
                            Label(g.what + ": " + InsBook.whereIs(p, g.what), systemImage: "questionmark.circle").foregroundStyle(Color.orange)
                        }
                    } header: {
                        Text("Still missing")
                    } footer: {
                        Text("Its policy schedule says these. Snap it, or open its PDF, and kosh reads them off it.")
                    }
                }
                Section {
                    Button {
                        store.sheet = .capture("policy:" + p.id)
                    } label: {
                        Label(added.isEmpty ? "Add from the policy document" : "Add more details", systemImage: "doc.viewfinder")
                    }
                }
                if let live = store.live, p.source != "manual" {
                    Section {
                        Button("Not mine: leave it out", role: .destructive) {
                            live.hidePolicy(key: p.key ?? "", id: p.id)
                            store.pop()
                        }
                    } footer: {
                        Text("kosh found this in your mail or payments. If it isn’t a policy you hold, it stays out from now on, whatever mail mentions it.")
                    }
                }
            }
            .navigationTitle(PolicyKinds.title(PolicyKinds.of(p)))
            .navigationBarTitleDisplayMode(.inline)
        } else {
            ContentUnavailableView("No such policy", systemImage: "shield")
        }
    }
}


// MARK: - Loans

struct LoansTabView: View {
    @Environment(Store.self) private var store
    var body: some View {
        @Bindable var store = store
        NavigationStack(path: $store.loanPath) {
            LoansView()
                .tabHeader("Loans", add: store.live == nil ? [] : [
                    HeaderAction(title: "Add a loan", symbol: "building.columns.circle") { store.betaSheet = .loan(nil) },
                ], extra: HeaderAction.arrange(.loans) { store.sheet = .arrange(.loans) })
                .navigationDestination(for: Route.self) { route in RouteDestination(route: route, zoom: nil) }
        }
    }
}


struct LoansView: View {
    @Environment(Store.self) private var store
    var body: some View {
        let active = store.loans.filter { $0.active }
        let closed = store.loans.filter { !$0.active }
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                if store.live != nil && store.snap.loans.isEmpty {
                    BetaEmpty(sym: "building.columns.fill", title: "No loans yet", text: "kosh spots EMIs in your mail. Add a loan to track the EMI and what’s left to pay.", add: "Add a loan") { store.betaSheet = .loan(nil) }
                } else {
                    PlanStack(.portDebts, spacing: 22) { id in
                        switch id {
                        case "head":
                            Group {
                                PageHead(label: "EMIs a month", value: Fmt.rupees(active.reduce(0) { $0 + $1.emi }),
                                         note: active.isEmpty ? "No loans running." : "\(Words.cap(Words.number(active.count))) loan\(active.count == 1 ? "" : "s") running, found from the EMIs leaving your accounts.")
                                if store.live != nil && !store.snap.loans.isEmpty {
                                    Button { store.betaSheet = .loan(nil) } label: { Label("Add a loan", systemImage: "plus.circle").font(.subheadline.weight(.semibold)) }
                                }
                            }
                        case "active":
                            VStack(alignment: .leading, spacing: 22) {
                                ForEach(active) { l in
                                    if let live = store.live, let mine = live.userLoans.first(where: { $0.id == l.id }) {
                                        Button { store.betaSheet = .loan(mine.id) } label: { LoanCard(l: l) }.buttonStyle(.press)
                                    } else { LoanCard(l: l) }
                                }
                            }
                        case "closed":
                            if !closed.isEmpty {
                                VStack(alignment: .leading, spacing: 12) {
                                    SectionHeader(title: "Closed")
                                    RowsCard(items: closed, inset: 62) { l in
                                        HStack(spacing: 12) {
                                            IconTile(symbol: "checkmark", color: Color.gray)
                                            VStack(alignment: .leading, spacing: 2) {
                                                Text(l.name).font(.body.weight(.medium))
                                                Text(l.note).font(.subheadline).foregroundStyle(.secondary).lineLimit(2)
                                            }
                                            Spacer()
                                            Text(Fmt.rupees(l.emi)).font(.subheadline.weight(.semibold)).foregroundStyle(.secondary).strikethrough().privacySensitive()
                                        }
                                    }
                                }
                            }
                        default: EmptyView()
                        }
                    }
                }
            }
            .padding(.horizontal, 20)
            .padding(.top, 8)
            .padding(.bottom, 30)
        }
    }
}

struct LoanCard: View {
    @Environment(Store.self) private var store
    let l: Loan
    var body: some View {
        let bal = store.loanBalance(l)
        let rate = l.rate
        VStack(alignment: .leading, spacing: 14) {
            HStack(spacing: 12) {
                IconTile(symbol: l.name.lowercased().contains("home") ? "house.fill" : "building.columns.fill", color: moduleColor(.loans), size: 42)
                VStack(alignment: .leading, spacing: 2) {
                    Text(l.name).font(.headline)
                    Text(l.bank.isEmpty ? "Lender not named" : l.bank).font(.subheadline).foregroundStyle(.secondary)
                }
                Spacer()
                VStack(alignment: .trailing, spacing: 2) {
                    Text(Fmt.rupees(l.emi)).font(.title3.weight(.bold)).monospacedDigit().privacySensitive()
                    Text("on the \(ordinal(l.day))").font(.caption).foregroundStyle(.secondary)
                }
            }
            HStack(spacing: 10) {
                LoanFact(title: "Paid", value: "\(l.paidMonths) months")
                LoanFact(title: "Outstanding", value: bal.map { Fmt.words($0) } ?? "Not added")
                LoanFact(title: "Rate", value: rate.map { "\(Fmt.trim($0, 2))%" } ?? "—")
            }
            if !l.from.isEmpty {
                Text("Leaves \(l.from) every month, last on \(Day.monthName(l.lastPaid)).")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }
            if bal == nil {
                Button {
                    store.sheet = .capture("loan:" + l.id)
                } label: {
                    Label("Add the balance from a loan statement", systemImage: "doc.viewfinder")
                        .font(.subheadline.weight(.semibold))
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.glass)
                .controlSize(.large)
            }
        }
        .card(16)
    }
}

struct LoanFact: View {
    let title: String
    let value: String
    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(title).font(.caption).foregroundStyle(.secondary)
            Text(value).font(.subheadline.weight(.semibold)).lineLimit(1).minimumScaleFactor(0.8).privacySensitive()
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(10)
        .background(CardFill(raised: true), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
    }
}

// MARK: - Property, drawn as itself

// MARK: - Holdings

struct HoldingsView: View {
    @Environment(Store.self) private var store
    let cls: String
    @State private var query = ""
    var body: some View {
        let parts = cls.split(separator: ":").map(String.init)
        let key = parts.first ?? "dep"
        let person = store.personFor(parts.count > 1 ? parts[1] : "family")
        let sum = store.classes(person).first { $0.key == key }
        let all = store.holdings(person).filter { $0.cls == key }.sorted { $0.amt > $1.amt }
        let q = query.trimmingCharacters(in: .whitespaces).lowercased()
        let items = q.isEmpty ? all : all.filter { $0.bank.lowercased().contains(q) }
        ObsidianList {
            Section {
                VStack(alignment: .leading, spacing: 2) {
                    Text(Fmt.words(items.reduce(0) { $0 + $1.amt }))
                        .font(.system(size: 40, weight: .bold, design: .rounded))
                        .privacySensitive()
                    // holdings, not accounts: a bank account never lists here
                    Text(Self.count(items.count, key, family: person == .family))
                        .font(.subheadline).foregroundStyle(.secondary)
                    GainLine(g: Gains(all), ret: store.yearly(person, key), cls: key)
                    if let u = store.classUpdated(key, person) {
                        Label(u.line, systemImage: u.stale ? "exclamationmark.circle" : "clock")
                            .font(.footnote).foregroundStyle(u.stale ? Color.orange : Color.secondary)
                            .padding(.top, 2)
                    }
                }
                .listRowBackground(Color.clear)
            }
            // retirement: every job under the UAN, year by year, the months to look at, PPF and NPS, the passbook
            // (RetirementView.swift); Holdings' Retirement tab links here for all of it
            if key == "ret" { RetirementSections(person: person) }
            // deposits: Live, Needs a look, Closed, each opening to its journey (Deposits.swift)
            if key == "dep" && store.snap.deposits != nil {
                DepositSections(person: person)
            } else {
            Section {
                ForEach(items) { h in
                    HStack(spacing: 12) {
                        IconTile(symbol: sum?.sym ?? "building.columns.fill", color: sum?.kindColor ?? Obsidian.ink2)
                        VStack(alignment: .leading, spacing: 2) {
                            Text(HoldingName.pretty(h.bank)).font(.body.weight(.medium)).lineLimit(1)
                            HStack(spacing: 6) {
                                Text(Fmt.pct(h.amt / max(1, all.reduce(0) { $0 + $1.amt })))
                                if person == .family {
                                    Text(store.ownerName(h.person)).fontWeight(.semibold)
                                }
                                if h.rate > 0 { Text("\(Fmt.trim(h.rate, 2))%") }
                                if let m = h.mat { Text((m < store.snap.cm ? "matured " : "matures ") + Day.fmt(m + "-01", "MMM yyyy")) }
                                if h.fresh == nil, let a = store.holdingAsOf(h) { Text(a) }
                            }
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            HoldingAsOf(h: h)
                        }
                        Spacer()
                        VStack(alignment: .trailing, spacing: 2) {
                            Text(Fmt.words(h.amt)).font(.body.weight(.semibold)).privacySensitive()
                            if let r = h.xirr {
                                Text(Gains.yearly(r)).font(.caption).monospacedDigit().foregroundStyle(.secondary).lineLimit(1).privacySensitive()
                            }
                        }
                    }
                }
            }
            }
        }
        .searchable(text: $query, prompt: "Find a holding")
        .navigationTitle(sum?.title ?? "Holdings")
        // (a Wealth page wherever it's opened from: Home's links too)
        .obsidianPage()
    }
    /// "1 deposit", "68 holdings across the family": what the list holds, by its kind
    static func count(_ n: Int, _ key: String, family: Bool) -> String {
        let noun: String = key == "dep" ? "deposit" : "holding"
        let plural: String = n == 1 ? "" : "s"
        let whose: String = family ? " across the family" : ""
        return String(n) + " " + noun + plural + whose
    }
}



/// where a policy stands, why, and your word on it when kosh can't see the whole story (a premium paid some other way)
struct PolicyStanding: View {
    @Environment(Store.self) private var store
    let p: Policy
    var body: some View {
        let mark: String = store.live?.policyMarks[p.key ?? ""] ?? ""
        let ulip: Bool = (p.kind ?? "") == "ULIP"
        Section {
            HStack(alignment: .top, spacing: 12) {
                if let st = PolicyStatus.chip(p) { Chip(text: st.0, color: st.1) } else { Chip(text: "In force", color: Color.green) }
                Text((p.statusWhy ?? "").isEmpty ? "Premiums are up to date, as far as your mail shows." : (p.statusWhy ?? ""))
                    .font(.subheadline).fixedSize(horizontal: false, vertical: true)
            }
            if ulip {
                Text("A ULIP: part of each premium buys units in market-linked funds; its fund value counts with your investments.")
                    .font(.footnote).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            }
            if let u = p.uin, !u.isEmpty { LabeledContent("Product code (UIN)", value: u + ((p.linked ?? false) ? " · unit-linked" : "")) }
            if let b = p.bonus, b > 0 { LabeledContent("Bonus accrued", value: Fmt.words(b)).privacySensitive() }
            ForEach(p.claims ?? [], id: \.self) { (c: Policy.Claim) in
                let word: String = ["registered": "Registered", "query": "Waiting on documents", "approved": "Approved", "settled": "Settled", "rejected": "Rejected"][c.status] ?? c.status.capitalized
                let amount: String = c.amt > 0 ? " · " + Fmt.words(c.amt) : ""
                let since: String = c.from.count >= 10 ? " · since " + Day.fmt(c.from, "d MMM yyyy") : ""
                LabeledContent("Claim" + (c.no.isEmpty ? "" : " " + c.no), value: word + amount + since).privacySensitive()
            }
            if let live = store.live, let key = p.key, !key.isEmpty {
                if !mark.isEmpty {
                    Button { live.markPolicy(key, nil) } label: { Label("Let kosh work it out from the mail", systemImage: "arrow.uturn.backward") }
                } else if p.isEnded {
                    Button { live.markPolicy(key, "active") } label: { Label("Mark it as still running", systemImage: "checkmark.shield") }
                } else {
                    Button(role: .destructive) { live.markPolicy(key, "ended") } label: { Label("Mark it as ended", systemImage: "archivebox") }
                }
            }
        } header: { Text("Where it stands") }
    }
}
