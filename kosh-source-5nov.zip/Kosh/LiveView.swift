import SwiftUI

// MARK: - Ask kosh, drawn: a question becomes a live view
//
// One canvas, not a chat. You ask; kosh (or Apple's on-device model) chooses what to show; the engine works out every
// figure; the view draws itself in on kosh's motion scale. A follow-up ("and last month?", "as a calendar", "split by
// category") reshapes the same canvas, and the step before stays one tap back. Every figure states its dates and where
// it came from; tap that line for the payments behind it. A view can be pinned to Home, where it's the question asked
// again on each build. The plan and the fill come from LiveViewPlanner (viewplan.js); nothing here adds anything up.

struct LiveViewScreen: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    /// the question to draw at once (from Ask kosh, a pin on Home), and a plan to start from (a pin)
    var seed: String? = nil
    var seedPlan: String? = nil

    @State private var shown: LiveAnswer?
    /// the views before this one, newest last: one tap back
    @State private var back: [LiveAnswer] = []
    @State private var question = ""
    @State private var working = false
    @State private var rows: AskRowsSheet.Ids?
    @State private var task: Task<Void, Never>?
    @FocusState private var focused: Bool
    private var pins: LivePins { LivePins.shared }

    static let starters = ["Where did my money go this month?", "Spending month by month", "What’s due this month?",
                           "Compare this month with last month", "Who did I pay the most?", "Any refunds pending?"]

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    if let a = shown { canvas(a).id(a.plan ?? a.question) } else if !working { empty }
                    if working { drawing }
                }
                .padding(.horizontal, 20)
                .padding(.top, 8)
                .padding(.bottom, 24)
                .animation(Motion.open, value: shown?.plan)
            }
            .scrollDismissesKeyboard(.interactively)
            .background(Color.liveCanvas.ignoresSafeArea())
            .safeAreaInset(edge: .bottom) { composer }
            .navigationTitle("Ask, drawn")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } }
                if !back.isEmpty && !working {
                    ToolbarItem(placement: .topBarLeading) {
                        Button {
                            withAnimation(Motion.close) { shown = back.popLast() }
                        } label: { Image(systemName: "arrow.uturn.backward") }
                            .accessibilityLabel("The view before")
                    }
                }
                if let plan = shown?.plan, shown?.fill != nil, store.live != nil {
                    ToolbarItem(placement: .topBarTrailing) {
                        let on: Bool = pins.isPinned(plan)
                        Button {
                            withAnimation(Motion.base) {
                                if on { pins.unpin(plan, store: store) } else { pins.pin(plan, question: shown?.question ?? "", title: shown?.fill?.title ?? "", store: store) }
                            }
                        } label: { Image(systemName: on ? "pin.fill" : "pin") }
                            .accessibilityLabel(on ? "Unpin from Home" : "Pin to Home")
                    }
                }
            }
            .sheet(item: $rows) { r in
                AskRowsSheet(ids: r.ids).environment(store).redacted(reason: store.hidden ? .privacy : [])
            }
        }
        .onAppear {
            pins.load(store)
            if let p = seedPlan, shown == nil { refill(p, question: seed ?? "") }
            else if let s = seed, shown == nil { ask(s) }
        }
        .onDisappear { task?.cancel() }
    }

    // MARK: the canvas

    @ViewBuilder func canvas(_ a: LiveAnswer) -> some View {
        VStack(alignment: .leading, spacing: 18) {
            VStack(alignment: .leading, spacing: 6) {
                Eyebrow(text: a.fill?.title.isEmpty == false ? a.fill!.title : "You asked")
                Text(a.question).font(.system(.title3, design: .rounded, weight: .semibold)).foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
            if let f = a.fill {
                LiveAnswerLine(text: f.answer)
                    .transition(.opacity.combined(with: .offset(y: 8)))
                if !f.isBlank || f.fact == "refunds" {
                    LivePicture(fill: f, compact: false)
                        .card(18)
                        .transition(.opacity.combined(with: .scale(scale: 0.98)))
                }
                sourceLine(f)
                if let n = f.note, !n.isEmpty { Text(n).font(.footnote).foregroundStyle(.secondary) }
                follow(f.follow)
                Text(a.how == "model" ? "Planned on this phone by Apple Intelligence; every figure worked out by kosh." : "Worked out on this phone from your ledger. Nothing is sent anywhere.")
                    .font(.caption).foregroundStyle(.tertiary)
            } else {
                // a question for words: said so, with Ask kosh one tap away
                VStack(alignment: .leading, spacing: 10) {
                    Text("This one is better said than drawn.").font(.headline)
                    Text("kosh draws spending, money in, investments, balances, bills and refunds. Ask kosh can answer this in words.")
                        .font(.subheadline).foregroundStyle(.secondary)
                    Button {
                        dismiss()
                        let q: String = a.question
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { store.openAsk(q) }
                    } label: { Label("Ask kosh in words", systemImage: "text.bubble") }
                        .buttonStyle(.press)
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(Color.kosh)
                }
                .card(18)
                follow(Self.starters.prefix(3).map { $0 })
            }
        }
    }

    func sourceLine(_ f: LiveFill) -> some View {
        Button {
            if !f.rows.isEmpty && f.fact != "refunds" && f.fact != "bills" { rows = AskRowsSheet.Ids(ids: f.rows) }
        } label: {
            HStack(alignment: .firstTextBaseline, spacing: 6) {
                Image(systemName: "doc.text.magnifyingglass").font(.caption)
                Text(f.source).font(.footnote).multilineTextAlignment(.leading)
                if !f.rows.isEmpty && f.fact != "refunds" && f.fact != "bills" { Image(systemName: "chevron.right").font(.caption2.weight(.semibold)) }
            }
            .foregroundStyle(.secondary)
        }
        .buttonStyle(.press)
        .accessibilityHint(f.rows.isEmpty ? "" : "Shows the payments behind it")
    }

    func follow(_ qs: [String]) -> some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(Array(qs.enumerated()), id: \.offset) { i, q in
                    Button { ask(q) } label: {
                        Text(q).font(.subheadline.weight(.medium))
                            .padding(.horizontal, 14).padding(.vertical, 9)
                            .background(Color.surface, in: Capsule())
                            .overlay(Capsule().strokeBorder(Color.hairline, lineWidth: 1))
                    }
                    .buttonStyle(.press)
                    .foregroundStyle(Color.primary)
                    .transition(.opacity.animation(Motion.base.delay(Motion.stagger(i, after: 0.2))))
                }
            }
        }
        .scrollClipDisabled()
    }

    var empty: some View {
        VStack(alignment: .leading, spacing: 14) {
            Image(systemName: "chart.bar.xaxis").font(.system(size: 34, weight: .medium)).foregroundStyle(Color.kosh)
            Text("Ask anything about your money, and kosh draws it.").font(.system(.title2, design: .rounded, weight: .bold))
            Text("Every figure is worked out on this phone from your own mail, with its dates beside it.")
                .font(.subheadline).foregroundStyle(.secondary)
            VStack(alignment: .leading, spacing: 8) {
                ForEach(Array(Self.starters.enumerated()), id: \.offset) { _, q in
                    Button { ask(q) } label: {
                        HStack { Text(q).font(.body); Spacer(); Image(systemName: "arrow.up.right").font(.footnote).foregroundStyle(.tertiary) }
                            .padding(.vertical, 12).padding(.horizontal, 14)
                            .background(Color.surface, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                    }
                    .buttonStyle(.press)
                    .foregroundStyle(Color.primary)
                }
            }
        }
        .padding(.top, 20)
    }

    var drawing: some View {
        HStack(spacing: 10) {
            ProgressView()
            Text(LiveViewPlanner.modelReady ? "Choosing what to show…" : "Working it out…").font(.subheadline).foregroundStyle(.secondary)
        }
        .padding(.vertical, 12)
    }

    var composer: some View {
        HStack(spacing: 10) {
            TextField(shown == nil ? "Ask anything about your money" : "Ask a follow-up, or another question", text: $question, axis: .vertical)
                .lineLimit(1...3)
                .focused($focused)
                .submitLabel(.send)
                .onSubmit { send() }
                .padding(.horizontal, 16).padding(.vertical, 11)
                .background(Color.surface, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
            Button { send() } label: {
                Image(systemName: "arrow.up").font(.system(size: 16, weight: .bold)).foregroundStyle(Color.onKosh)
                    .frame(width: 40, height: 40).background(Color.koshFill, in: Circle())
            }
            .buttonStyle(.press)
            .disabled(question.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || working)
            .accessibilityLabel("Draw it")
        }
        .padding(.horizontal, 16).padding(.vertical, 10)
        .background(.bar)
    }

    // MARK: asking

    func send() {
        let q: String = question.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !q.isEmpty, !working else { return }
        question = ""
        focused = false
        ask(q)
    }

    func ask(_ q: String) {
        guard !working else { return }
        working = true
        let prev: String? = shown?.plan
        task = Task {
            let a: LiveAnswer = await LiveViewPlanner.draw(q, prev: prev, store: store)
            guard !Task.isCancelled else { return }
            withAnimation(Motion.open) {
                if let s = shown { back.append(s) }
                shown = a
                working = false
            }
        }
    }

    func refill(_ plan: String, question q: String) {
        working = true
        task = Task {
            let f: LiveFill? = await LiveViewPlanner.refill(plan, store: store)
            guard !Task.isCancelled else { return }
            withAnimation(Motion.open) { shown = LiveAnswer(question: q, plan: plan, fill: f, how: "rules"); working = false }
        }
    }
}

extension AskRowsSheet {
    struct Ids: Identifiable { let id = UUID(); let ids: [String] }
}

extension Color {
    /// the live view's ground: a warm off-white, deep ink at night
    static let liveCanvas = Color(light: Color(red: 0.975, green: 0.968, blue: 0.955), dark: Color(red: 0.07, green: 0.07, blue: 0.08))
}

/// the answer under the question, its figures set in bold (each is the engine's)
struct LiveAnswerLine: View {
    let text: String
    var size: Font = .system(.title2, design: .rounded, weight: .regular)
    var body: some View {
        var out = AttributedString()
        for run in LiveViewCore.figureRuns(text) {
            var a = AttributedString(run.text)
            if run.figure { a.font = size.weight(.bold); a.foregroundColor = Color.primary }
            out += a
        }
        return Text(out).font(size).fixedSize(horizontal: false, vertical: true).privacySensitive()
    }
}
