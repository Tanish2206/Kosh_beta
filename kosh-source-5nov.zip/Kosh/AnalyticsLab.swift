import SwiftUI

// MARK: - Analytics testing: the Insights reel, on the phone, to try out
//
// Insights as one analytic at a time instead of one long page. A glass film strip at the bottom holds them; slide it
// or tap one to move, with a tick for each, and the room takes that analytic's colour. Every view is the app's own
// (Pace, Where it goes, Category × month, Up close, Where you shop, How you paid, Budgets, Repeats), unchanged, plus
// Days, which is new. The sliders button chooses which are on the strip and in what order (kept on the phone).
// Worth a look, Spend trend and Keep rate are not in it.

enum LabCard: String, CaseIterable, Identifiable {
    case pace, where_, grid, close, shops, days, paid, budgets, repeats
    var id: String { rawValue }
    var title: String {
        switch self {
        case .pace: return "Pace"
        case .where_: return "Where it goes"
        case .grid: return "Cat × month"
        case .close: return "Up close"
        case .shops: return "Shops"
        case .days: return "Days"
        case .paid: return "Paid with"
        case .budgets: return "Budgets"
        case .repeats: return "Repeats"
        }
    }
    var what: String {
        switch self {
        case .pace: return "This month against last, and where it's heading"
        case .where_: return "Each category with its trend and change"
        case .grid: return "Every category, month by month"
        case .close: return "One category over time, and what's inside it"
        case .shops: return "Which apps and stores get your spending"
        case .days: return "Which days of the week cost the most"
        case .paid: return "UPI, cards, wallets, the bank and cash"
        case .budgets: return "Your budgets, and which are running out"
        case .repeats: return "Subscriptions and bills that come round"
        }
    }
    var symbol: String {
        switch self {
        case .pace: return "speedometer"
        case .where_: return "chart.pie"
        case .grid: return "square.grid.3x3"
        case .close: return "magnifyingglass"
        case .shops: return "bag"
        case .days: return "calendar"
        case .paid: return "creditcard"
        case .budgets: return "checkmark.shield"
        case .repeats: return "repeat"
        }
    }
    var tint: Color {
        switch self {
        case .pace: return Color(red: 0.36, green: 0.49, blue: 1.0)
        case .where_: return Color(red: 0.65, green: 0.55, blue: 0.98)
        case .grid: return Color(red: 0.96, green: 0.45, blue: 0.71)
        case .close: return Color(red: 0.96, green: 0.64, blue: 0.36)
        case .shops: return Color(red: 0.96, green: 0.62, blue: 0.04)
        case .days: return Color(red: 0.18, green: 0.83, blue: 0.75)
        case .paid: return Color(red: 1.0, green: 0.54, blue: 0.40)
        case .budgets: return Color(red: 1.0, green: 0.82, blue: 0.40)
        case .repeats: return Color(red: 0.96, green: 0.45, blue: 0.71)
        }
    }
}

struct AnalyticsLab: View {
    @Environment(Store.self) private var store
    @Environment(\.accessibilityReduceMotion) private var still
    @AppStorage("insights.focus") private var focus = ""
    @AppStorage("insights.side") private var side = 3
    /// the strip's cards in order, and the ones switched off ("pace,where_,…" / "days,repeats")
    @AppStorage("lab.order") private var orderRaw = ""
    @AppStorage("lab.off") private var offRaw = ""
    @State private var current: LabCard = .pace
    @State private var editing = false
    /// kosh's own tab bar floats over the pages: the strip stands clear above its top
    @Environment(\.barTop) private var barTop
    @State private var bottomY: CGFloat = 0
    var lift: CGFloat {
        guard let top = barTop, bottomY > top else { return 10 }
        return bottomY - top + 10
    }

    var cards: [LabCard] {
        let saved: [LabCard] = orderRaw.split(separator: ",").compactMap { LabCard(rawValue: String($0)) }
        let all: [LabCard] = saved + LabCard.allCases.filter { !saved.contains($0) }
        let off: Set<String> = Set(offRaw.split(separator: ",").map(String.init))
        let on: [LabCard] = all.filter { !off.contains($0.rawValue) }
        return on.isEmpty ? [.pace] : on
    }

    var body: some View {
        let shown: [LabCard] = cards
        let card: LabCard = shown.contains(current) ? current : shown[0]
        ZStack {
            // the room takes the analytic's one colour, deep and soft; moving on, it fades into the next
            LabWash(cards: shown, current: card)
            // one analytic a page, edge to edge: swipe across and the page follows your finger. Each page scrolls
            // under the strip and the bar to the screen's foot, its title row going with it
            TabView(selection: Binding(get: { card }, set: { c in current = c })) {
                ForEach(shown) { c in
                    ScrollView {
                        VStack(alignment: .leading, spacing: 12) {
                            HStack {
                                Text(c.title.uppercased())
                                    .font(.caption.weight(.bold)).tracking(1.4)
                                    .foregroundStyle(c.tint)
                                Spacer()
                                Button { editing = true } label: {
                                    Image(systemName: "slider.horizontal.3")
                                        .font(.subheadline.weight(.semibold))
                                        .frame(width: 36, height: 36)
                                        .glassEffect(.regular.interactive(), in: .circle)
                                }
                                .buttonStyle(.plain)
                                .accessibilityLabel("Choose which analytics to show")
                            }
                            content(c)
                                // the views' cards turn to glass over the colour (Insights keeps its own look)
                                .environment(\.labGlass, c.tint)
                        }
                        .padding(.horizontal, 16)
                        .padding(.top, 8)
                    }
                    .scrollIndicators(.hidden)
                    // room under the last card for the strip and the bar over it
                    .contentMargins(.bottom, LabStrip.height + lift + 20, for: .scrollContent)
                    .tag(c)
                }
            }
            .tabViewStyle(.page(indexDisplayMode: .never))
            .ignoresSafeArea(.container, edges: .bottom)
        }
        .background {
            Color.clear.ignoresSafeArea()
                .onGeometryChange(for: CGFloat.self) { g in g.frame(in: .global).maxY } action: { y in bottomY = y }
        }
        .overlay(alignment: .bottom) {
            LabStrip(cards: shown, current: card) { c in
                withAnimation(still ? nil : Motion.large) { current = c }
            }
                .padding(.horizontal, 16)
                .padding(.bottom, lift)
                .animation(Motion.open, value: lift)
                .ignoresSafeArea(.container, edges: .bottom)
        }
        .sheet(isPresented: $editing) {
            LabEdit(orderRaw: $orderRaw, offRaw: $offRaw)
                .presentationDetents([.medium, .large])
                .presentationDragIndicator(.visible)
        }
    }

    /// the app's own views, as Insights has them
    @ViewBuilder func content(_ c: LabCard) -> some View {
        let cm: String = store.snap.cm
        let allMonths: [String] = store.snap.months.map(\.m)
        let chosen: String = InsightMonths.chosen(store.ledgerMonth, all: allMonths, cm: cm)
        switch c {
        case .pace:
            PaceHero(menu: InsightMonthMenu(month: Binding(get: { chosen }, set: { store.ledgerMonth = $0 }),
                                            months: allMonths, cm: cm, tint: InsightInk.blue))
                .environment(\.insightMonth, chosen)
        case .where_, .grid, .close:
            let back: Int = max(12, allMonths.filter { $0 >= chosen && $0 <= cm }.count + 5)
            let year: CatMonths = store.catMonths(InsightMonths.ending(cm, n: back, all: allMonths))
            let picked: String = InsightsMath.month(store.ledgerMonth, in: year.window(6, ending: chosen).months, cm: cm)
            switch c {
            case .where_:
                WhereItGoes(data: year, month: Binding(get: { store.ledgerMonth }, set: { store.ledgerMonth = $0 })) { cat in
                    focus = cat
                    withAnimation(Motion.large) { current = .close }
                }
            case .grid:
                CategoryMonthGrid(data: year.window(6, ending: chosen), n: $side) { cat, m in
                    if let m { store.ledgerMonth = m }
                    focus = cat
                    withAnimation(Motion.large) { current = .close }
                }
            default:
                UpClose(focus: $focus, month: picked, span: year)
            }
        case .shops: WhereYouShop()
        case .days: LabDays(month: chosen)
        case .paid: HowYouPaid()
        case .budgets: BudgetsCard()
        case .repeats: InsightsRepeats()
        }
    }
}

/// the analytics strip: a row of chips from the left, scrolled like any list (it coasts and settles on a chip), with
/// a tick for each chip that passes. Tap one, or swipe the page above, and it glides there and keeps it in view
struct LabStrip: View {
    let cards: [LabCard]
    let current: LabCard
    let pick: (LabCard) -> Void
    static let height: CGFloat = 54
    @State private var feel = LabFeel()
    @Namespace private var ns

    var body: some View {
        ScrollViewReader { proxy in
            ScrollView(.horizontal) {
                HStack(spacing: 2) {
                    ForEach(cards) { c in
                        let on: Bool = c == current
                        HStack(spacing: 7) {
                            Image(systemName: c.symbol).font(.system(size: 14, weight: .semibold))
                            Text(c.title).font(.system(size: 14, weight: .semibold)).lineLimit(1).fixedSize()
                        }
                        .foregroundStyle(on ? Color.white : Color.white.opacity(0.6))
                        .padding(.horizontal, 14)
                        .frame(height: 42)
                        .background {
                            if on {
                                Capsule().fill(c.tint.opacity(0.26))
                                    .overlay(Capsule().strokeBorder(c.tint.opacity(0.85), lineWidth: 1))
                                    .shadow(color: c.tint.opacity(0.35), radius: 8)
                                    .matchedGeometryEffect(id: "lab.on", in: ns)
                            }
                        }
                        .contentShape(Capsule())
                        .onTapGesture { pick(c) }
                        .id(c)
                        // a chip passing the left edge while you scroll: one tick
                        .onGeometryChange(for: Bool.self) { g in g.frame(in: .scrollView).minX < 10 } action: { _, _ in
                            if feel.live { LensHaptics.tick(over: false) }
                        }
                        .accessibilityAddTraits(on ? .isSelected : [])
                    }
                }
                .padding(.horizontal, 6)
                .scrollTargetLayout()
            }
            .scrollIndicators(.hidden)
            .scrollTargetBehavior(.viewAligned)
            .onScrollPhaseChange { _, phase in
                feel.live = phase == .interacting || phase == .decelerating
                if phase == .interacting { LensHaptics.ready() }
            }
            .frame(height: Self.height)
            .onChange(of: current) { _, c in
                withAnimation(Motion.large) { proxy.scrollTo(c, anchor: .center) }
            }
        }
        .glassEffect(.regular.tint(current.tint.opacity(0.1)).interactive(), in: .capsule)
        .animation(Motion.open, value: current)
        .sensoryFeedback(.selection, trigger: current)
        .accessibilityElement(children: .contain)
        .accessibilityLabel("Analytics")
    }
}

/// what the strip's ticks need to know, kept out of view state so scrolling never re-renders it
final class LabFeel { var live = false }

/// which analytics are on the strip, and in what order
struct LabEdit: View {
    @Binding var orderRaw: String
    @Binding var offRaw: String
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        let saved: [LabCard] = orderRaw.split(separator: ",").compactMap { LabCard(rawValue: String($0)) }
        let all: [LabCard] = saved + LabCard.allCases.filter { !saved.contains($0) }
        let off: Set<String> = Set(offRaw.split(separator: ",").map(String.init))
        NavigationStack {
            List {
                Section {
                    ForEach(all) { c in
                        HStack(spacing: 12) {
                            Image(systemName: c.symbol)
                                .font(.subheadline.weight(.semibold))
                                .foregroundStyle(c.tint)
                                .frame(width: 34, height: 34)
                                .background(c.tint.opacity(0.16), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
                            VStack(alignment: .leading, spacing: 1) {
                                Text(c.title).font(.subheadline.weight(.semibold))
                                Text(c.what).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                            }
                            Spacer()
                            Toggle("", isOn: Binding(get: { !off.contains(c.rawValue) }, set: { on in
                                var o = off
                                if on { o.remove(c.rawValue) } else if all.count - o.count > 1 { o.insert(c.rawValue) }
                                offRaw = o.sorted().joined(separator: ",")
                            }))
                            .labelsHidden()
                        }
                    }
                    .onMove { from, to in
                        var a = all
                        a.move(fromOffsets: from, toOffset: to)
                        orderRaw = a.map(\.rawValue).joined(separator: ",")
                    }
                } footer: {
                    Text("Drag to set the order on the strip. At least one stays on.")
                }
            }
            .environment(\.editMode, .constant(.active))
            .navigationTitle("Your analytics")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } } }
        }
    }
}

/// Days (new): what an average weekday costs this month, and every day of the month as a heat grid
struct LabDays: View {
    @Environment(Store.self) private var store
    let month: String

    var body: some View {
        let byDay: [String: Double] = Self.spend(store.txs(in: month))
        let days: Int = store.month(month)?.days ?? 30
        let first: String = month + "-01"
        // 0 = Monday … 6 = Sunday
        let lead: Int = (Int(Day.fmt(first, "e")) ?? 1) - 1
        let vals: [Double] = (1...max(1, days)).map { byDay[month + "-" + String(format: "%02d", $0)] ?? 0 }
        let mx: Double = max(1, vals.max() ?? 1)
        let avg: [Double] = Self.weekdays(vals, lead: lead, live: month == store.snap.cm)
        let amx: Double = max(1, avg.max() ?? 1)
        let teal: Color = Color(red: 0.18, green: 0.83, blue: 0.75)
        let names: [String] = ["M", "T", "W", "T", "F", "S", "S"]
        let top: Int = avg.firstIndex(of: avg.max() ?? 0) ?? 5
        let low: Int = avg.indices.filter { avg[$0] > 0 }.min { avg[$0] < avg[$1] } ?? 1
        let full: [String] = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]

        VStack(alignment: .leading, spacing: 16) {
            VStack(alignment: .leading, spacing: 2) {
                Text(full[top] + "s cost the most")
                    .font(.system(.title2, design: .rounded, weight: .bold))
                Text(Fmt.rupees(avg[top]) + " on an average " + full[top] + ", against " + Fmt.rupees(avg[low]) + " on a " + full[low])
                    .font(.subheadline).foregroundStyle(.secondary)
            }
            HStack(alignment: .bottom, spacing: 8) {
                ForEach(0..<7, id: \.self) { w in
                    VStack(spacing: 6) {
                        Text(Fmt.short(avg[w])).font(.caption2.weight(.semibold)).foregroundStyle(.secondary).monospacedDigit()
                        RoundedRectangle(cornerRadius: 8, style: .continuous)
                            .fill(w >= 5 ? AnyShapeStyle(teal.gradient) : AnyShapeStyle(Color.primary.opacity(0.18)))
                            .frame(height: max(8, 110 * avg[w] / amx))
                        Text(names[w]).font(.caption.weight(.bold)).foregroundStyle(w >= 5 ? teal : .secondary)
                    }
                    .frame(maxWidth: .infinity)
                }
            }
            .frame(height: 160, alignment: .bottom)
            Text("Every day of " + Day.monthName(month))
                .font(.subheadline.weight(.semibold))
            LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 5), count: 7), spacing: 5) {
                ForEach(0..<(lead + vals.count), id: \.self) { k in
                    if k < lead {
                        Color.clear.frame(height: 34)
                    } else {
                        let v: Double = vals[k - lead]
                        let a: Double = v > 0 ? 0.12 + 0.85 * v / mx : 0.04
                        Text(String(k - lead + 1))
                            .font(.caption.weight(.semibold)).monospacedDigit()
                            .foregroundStyle(a > 0.55 ? Color.black.opacity(0.75) : Color.primary)
                            .frame(maxWidth: .infinity, minHeight: 34)
                            .background(teal.opacity(a), in: RoundedRectangle(cornerRadius: 9, style: .continuous))
                    }
                }
            }
            .privacySensitive()
        }
        .padding(16)
        .insightCard(26)
    }

    /// the average day for each weekday (0 = Monday); in the running month, days still to come don't count
    static func weekdays(_ vals: [Double], lead: Int, live: Bool) -> [Double] {
        var sum: [Double] = Array(repeating: 0, count: 7)
        var cnt: [Double] = Array(repeating: 0, count: 7)
        for (i, v) in vals.enumerated() where v > 0 || !live {
            let w: Int = (lead + i) % 7
            sum[w] += v
            cnt[w] += 1
        }
        return (0..<7).map { cnt[$0] > 0 ? sum[$0] / cnt[$0] : 0 }
    }

    static func spend(_ rows: [Txn]) -> [String: Double] {
        var out: [String: Double] = [:]
        for t in rows where t.sp && t.a > 0 { out[t.d, default: 0] += t.a }
        return out
    }
}


// MARK: - The colour and the glass

/// the room behind Analytics testing: one colour an analytic, a deep wash from the top corner and a softer one low on
/// the other side, over near-black. Every analytic's wash is laid once and only the one in view shows, so moving on
/// is a cross-fade of two layers on the compositor, nothing redrawn
struct LabWash: View {
    let cards: [LabCard]
    let current: LabCard
    var body: some View {
        ZStack {
            Color(red: 0.016, green: 0.016, blue: 0.024)
            ForEach(cards) { c in
                ZStack {
                    RadialGradient(stops: [.init(color: c.tint.opacity(0.34), location: 0),
                                           .init(color: c.tint.opacity(0.12), location: 0.45),
                                           .init(color: .clear, location: 1)],
                                   center: UnitPoint(x: 0.88, y: -0.04), startRadius: 0, endRadius: 620)
                    RadialGradient(stops: [.init(color: c.tint.opacity(0.16), location: 0),
                                           .init(color: .clear, location: 1)],
                                   center: UnitPoint(x: 0.08, y: 1.02), startRadius: 0, endRadius: 440)
                }
                .opacity(c == current ? 1 : 0)
            }
        }
        .animation(Motion.out(0.6), value: current)
        .ignoresSafeArea()
        .allowsHitTesting(false)
        .accessibilityHidden(true)
    }
}
