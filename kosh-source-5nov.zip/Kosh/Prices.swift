import Foundation

// MARK: - The day's prices for funds and shares
//
// A statement values a fund or a share on its own date, and the next one can be a month away. AMFI publishes every
// fund's NAV each evening in one file, and NSE every share's and ETF's close in its daily bhavcopy, with its lists
// of what trades there: public files, the same for everyone, so asking for them says nothing about what you hold
// (the requests carry only the day's date). kosh fetches them at most once a day, and again on a pull to refresh,
// keeps only the prices of what's held (prices.json), and the engine values each fund and share at units × that
// price when it's newer than the statement (engine.js freshValue). Holdings without units stay as they were read.

final class Prices: @unchecked Sendable {
    static let shared = Prices()

    /// a price, the day it's for (yyyy-MM-dd), and where it's from: "AMFI" (a fund's NAV) or "NSE" (the day's close)
    struct Price: Codable, Hashable { var p: Double; var d: String; var src: String }
    /// one fund or share to price: its ISIN (empty for a fund a statement printed without one), its name, kind and type
    struct Want: Codable, Hashable {
        var isin: String; var name: String; var cls: String; var type: String
        var id: String { isin.isEmpty ? "n:" + name.lowercased() : isin }
    }
    struct Saved: Codable {
        /// the day every price was last fetched, and when they were last asked for (fetched or not)
        var at: String = ""; var tried: Date = .distantPast
        /// the holdings they were fetched for, and what each file gave (by the engine's key: ISIN, or a fund's name)
        var want: [String] = []; var amfi: [String: Price] = [:]; var nse: [String: Price] = [:]
        /// each listed ISIN's NSE symbol, the ISINs NSE's lists were read for (found or not), and when
        var syms: [String: String] = [:]; var looked: [String] = []; var symsAt: String = ""
    }

    static let amfiURL = "https://www.amfiindia.com/spages/NAVAll.txt"
    static let equitiesURL = "https://archives.nseindia.com/content/equities/EQUITY_L.csv"
    static let etfsURL = "https://nsearchives.nseindia.com/content/equities/eq_etfseclist.csv"
    static let bhavURL = "https://nsearchives.nseindia.com/products/content/sec_bhavdata_full_"
    /// the sites turn plain requests away: a phone's browser asks
    static let agent = "Mozilla/5.0 (iPhone; CPU iPhone OS 26_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0 Mobile/15E148 Safari/604.1"

    private let lock = NSLock()
    private var saved = Saved()
    private var running = false
    /// counts up on Erase, so a fetch that was under way then doesn't write its prices back
    private var gen = 0
    private var url: URL { LiveSession.folder.appendingPathComponent("prices.json") }

    init() {
        if let d = try? Data(contentsOf: url), let s = try? JSONDecoder().decode(Saved.self, from: d) { saved = s }
    }

    /// what the engine takes as prof.prices: key → { p, d, src }. A fund's NAV, unless NSE has a close for it as new
    /// (an ETF is bought and sold at its close)
    var forEngine: [String: [String: Any]] {
        lock.lock(); defer { lock.unlock() }
        var all: [String: Price] = saved.amfi
        for (k, q) in saved.nse where q.d >= (all[k]?.d ?? "") { all[k] = q }
        return all.mapValues { ["p": $0.p, "d": $0.d, "src": $0.src] as [String: Any] }
    }
    var isEmpty: Bool { lock.lock(); defer { lock.unlock() }; return saved.amfi.isEmpty && saved.nse.isEmpty }

    /// Erase: the prices go with everything else (their keys say what was held)
    func clear() {
        lock.lock(); saved = Saved(); gen += 1; lock.unlock()
        try? FileManager.default.removeItem(at: url)
    }

    /// the funds and shares worth pricing: those with units, and an ISIN or (a fund) a name
    static func wants(_ hs: [UserHolding]) -> [Want] {
        var seen: Set<String> = [], out: [Want] = []
        for h in hs where (h.cls == "mf" || h.cls == "stk") && (h.units ?? 0) > 0 {
            let isin: String = (h.isin ?? "").trimmingCharacters(in: .whitespaces).uppercased()
            if isin.isEmpty && h.cls != "mf" { continue }
            let w = Want(isin: isin, name: h.bank, cls: h.cls, type: h.type)
            if seen.insert(w.id).inserted { out.append(w) }
        }
        return out
    }

    /// Fetch the day's prices for these holdings: when they weren't fetched today (a failed try waits an hour), on a
    /// pull (not twice in a quarter of an hour), or soon for a holding not asked about before (a new statement). True
    /// when a price changed, so the screens are laid out again only then.
    func refresh(_ want: [Want], pulled: Bool = false) async -> Bool {
        guard !want.isEmpty else { return false }
        let today: String = LiveSession.today
        let ids: Set<String> = Set(want.map(\.id))
        let (go, s, reloaded, era) = start(ids, pulled: pulled, today: today)
        guard go else { return reloaded }

        var next: Saved = s
        next.tried = Date()
        var allOK = true
        // funds: AMFI's one file of every NAV
        let funds: [Want] = want.filter { $0.cls == "mf" }
        if funds.isEmpty { next.amfi = [:] } else {
            // a page that isn't the file (a site under maintenance) is no answer: the last prices stay
            if let text = await Self.text(Self.amfiURL), text.prefix(2000).contains("Net Asset Value"),
               let out = try? Engine.builder.call("amfiPricesJSON", [text, JSONText.encode(funds)]),
               let got = try? JSONText.decode([String: Price].self, out) {
                next.amfi = got
            } else { allOK = false }
        }
        // shares and ETFs: each ISIN's NSE symbol (NSE's lists, read again only for an ISIN not looked up yet, or
        // monthly), then the closes in the newest bhavcopy
        let listed: [Want] = want.filter { ($0.cls == "stk" || $0.type == "ETF") && !$0.isin.isEmpty }
        if listed.isEmpty { next.nse = [:] } else {
            let isins: [String] = listed.map(\.isin)
            if isins.contains(where: { !s.looked.contains($0) }) || LiveSession.daysSince(s.symsAt) > 30 {
                async let eq: String? = Self.text(Self.equitiesURL)
                async let etf: String? = Self.text(Self.etfsURL)
                let (a, b) = await (eq, etf)
                // both lists, or the ISINs looked for would count as not on NSE for a month
                if let a, let b, a.prefix(500).contains("ISIN"), b.prefix(500).contains("ISIN"),
                   let out = try? Engine.builder.call("nseSymbolsJSON", [a + "\n" + b, JSONText.encode(isins)]),
                   let got = try? JSONText.decode([String: String].self, out) {
                    next.syms = got; next.looked = isins; next.symsAt = today
                } else { allOK = false }
            }
            let syms: [String: String] = next.syms.filter { isins.contains($0.key) }
            if !syms.isEmpty {
                if let bhav = await Self.bhavcopy(),
                   let out = try? Engine.builder.call("bhavPricesJSON", [bhav, JSONText.encode(syms)]),
                   let got = try? JSONText.decode([String: Price].self, out) {
                    next.nse = got
                } else { allOK = false }
            }
        }
        // a file that couldn't be had keeps the prices it gave last time; the day counts as done once all came
        if allOK { next.at = today; next.want = Array(ids).sorted() }
        let changed: Bool = reloaded || next.amfi != s.amfi || next.nse != s.nse
        return finish(next, era) && changed
    }

    /// whether a fetch is due (none is running, and see refresh), with what's kept; it marks one as running
    private func start(_ ids: Set<String>, pulled: Bool, today: String) -> (Bool, Saved, Bool, Int) {
        lock.lock(); defer { lock.unlock() }
        // kosh started while the phone was locked (its files can't be read until it's unlocked): read them now
        var reloaded = false
        if saved.tried == .distantPast, let d = try? Data(contentsOf: url), let x = try? JSONDecoder().decode(Saved.self, from: d) { saved = x; reloaded = true }
        let since: TimeInterval = Date().timeIntervalSince(saved.tried)
        let covered: Bool = ids.isSubset(of: Set(saved.want))
        let due: Bool = !covered ? since > 300 : pulled ? since > 15 * 60 : (saved.at != today && since > 3600)
        guard due, !running else { return (false, saved, reloaded, gen) }
        running = true
        saved.tried = Date()
        return (true, saved, reloaded, gen)
    }
    /// what the fetch came to, kept and written down (false when everything was erased meanwhile)
    private func finish(_ next: Saved, _ era: Int) -> Bool {
        lock.lock()
        running = false
        guard era == gen else { lock.unlock(); return false }
        saved = next
        lock.unlock()
        if let d = try? JSONEncoder().encode(next) { try? d.write(to: url, options: [.atomic, LiveSession.protection]) }
        return true
    }

    /// The newest bhavcopy NSE has put up: today's once the evening's file is there (after about 6 pm), else the
    /// trading day before; weekends and holidays have none, so up to a week back is tried.
    private static func bhavcopy() async -> String? {
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX"); f.timeZone = Day.zone; f.dateFormat = "ddMMyyyy"
        var day: Date = Date()
        if Day.cal.component(.hour, from: day) < 18 { day = day.addingTimeInterval(-86400) }
        for _ in 0..<7 {
            let wd: Int = Day.cal.component(.weekday, from: day)
            if wd != 1 && wd != 7, let t = await text(bhavURL + f.string(from: day) + ".csv"), t.prefix(300).contains("CLOSE_PRICE") { return t }
            day = day.addingTimeInterval(-86400)
        }
        return nil
    }

    /// one public file, as text (nil when it isn't there)
    private static func text(_ s: String) async -> String? {
        guard let u = URL(string: s) else { return nil }
        // the day's file, never a copy kept from an earlier day (AMFI's is a couple of MB)
        var req = URLRequest(url: u, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 60)
        req.setValue(agent, forHTTPHeaderField: "User-Agent")
        guard let (data, resp) = try? await URLSession.shared.data(for: req), (resp as? HTTPURLResponse)?.statusCode == 200, !data.isEmpty else { return nil }
        return String(data: data, encoding: .utf8) ?? String(data: data, encoding: .isoLatin1)
    }
}
