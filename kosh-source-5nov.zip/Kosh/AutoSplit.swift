import Foundation

/// an order's mixed share filed by itself (fb 2 Nov): once per payment, past and new
@MainActor
enum AutoSplit {
    static let key: String = "autosplit.done"
    static func apply(_ store: Store) {
        guard let live = store.live else { return }
        var done: Set<String> = Set(UserDefaults.standard.stringArray(forKey: key) ?? [])
        var changed: Bool = false
        for t in store.snap.tx {
            guard let m = t.mix, t.partOf == nil, t.full == nil, !done.contains(t.id), m.c != t.c else { continue }
            // (a payment you filed or split yourself is yours)
            if let o = live.overrides[t.id], o.c == m.c || !(o.parts ?? []).isEmpty { done.insert(t.id); changed = true; continue }
            done.insert(t.id); changed = true
            let s: String = m.s ?? ""
            if m.all == true {
                live.override(t.id) { o in o.c = m.c; o.s = s; o.by = "kosh"; o.only = Store.with(o.only, "c") }
            } else if m.g > 0 && m.g < t.a {
                store.splitOut(t.id, amount: (m.g * 100).rounded() / 100, c: m.c, s: s, refunded: false)
            }
        }
        if changed {
            UserDefaults.standard.set(Array(done), forKey: key)
            live.rebuildSoon()
        }
    }
}

/// what a split's rows are, in words
@MainActor
enum SplitWords {
    /// "Yogabar 26% High Protein Oats 1kg, Pack of 3" → "Yogabar 26% High Protein Oats 1kg"
    static func short(_ n: String) -> String {
        var s: String = n.components(separatedBy: CharacterSet(charactersIn: ",(|")).first ?? n
        s = s.trimmingCharacters(in: .whitespaces)
        return s.count > 34 ? String(s.prefix(32)).trimmingCharacters(in: .whitespaces) + "…" : s
    }
    static func key(_ n: String) -> String { String(n.lowercased().filter { $0.isLetter || $0.isNumber }.prefix(20)) }
    /// the part: "Split from ₹2,619 · Yogabar oats, rice paper sheets"
    static func part(_ t: Txn, _ store: Store) -> String {
        guard let pid = t.partOf, let p = store.txn(pid) else { return "Split out of a bigger charge" }
        let whole: Double = p.full ?? (p.a + t.a)
        var s: String = "Split from " + Fmt.rupees(whole)
        if let names = p.mix?.n, !names.isEmpty, p.mix?.c == t.c { s += " · " + names.map { short($0) }.joined(separator: ", ") }
        return s
    }
    /// the rest of a split order: what else it held
    static func rest(_ t: Txn, _ store: Store) -> String? {
        guard let names = t.mix?.n, !names.isEmpty, let items = store.payFact(t)?.items, !items.isEmpty else { return nil }
        let out: Set<String> = Set(names.map { key($0) })
        let rest: [String] = items.map { $0.n }.filter { !out.contains(key($0)) }.map { short($0) }
        guard !rest.isEmpty else { return nil }
        return "With it: " + rest.prefix(3).joined(separator: ", ") + (rest.count > 3 ? " +" + String(rest.count - 3) : "")
    }
    /// "Order 407-…" or "5 orders: 407-…, 407-…, 407-… +2"
    static func orders(_ items: [PayFacts.Item]) -> String? {
        var nos: [String] = []
        for it in items { if let o = it.o, !o.isEmpty, !nos.contains(o) { nos.append(o) } }
        guard !nos.isEmpty else { return nil }
        let head: String = nos.count == 1 ? "Order " : String(nos.count) + " orders: "
        let tail: String = nos.count > 3 ? " +" + String(nos.count - 3) : ""
        return head + nos.prefix(3).joined(separator: ", ") + tail
    }
    /// an order paid from a wallet and a card: "Order ₹3,414 · ₹3,000 Myntra Credit + ₹414 card"
    static func paidHow(_ t: Txn, _ store: Store) -> String? {
        if let uses = t.wu, !uses.isEmpty, let whole = t.ot {
            let card: String = (t.bk ?? "card") + ((t.l4 ?? "").isEmpty ? "" : " ••" + (t.l4 ?? ""))
            let parts: [String] = uses.map { Fmt.rupees($0.a) + " " + $0.w } + [Fmt.rupees(t.a) + " " + card]
            _ = whole
            return "Paid " + parts.joined(separator: " + ")
        }
        if let from = t.wf, let card = store.txn(from) {
            return "From " + t.card + " · " + Fmt.rupees(card.a) + " of the order on the card"
        }
        return nil
    }
    /// what of a payment went back: "Returned: RupeeRise 3 Pcs Mi Band 8 Strap"
    static func returned(_ t: Txn, _ store: Store) -> String? {
        let items: [PayFacts.Item] = (store.payFact(t)?.items ?? []).filter { $0.ret != nil }
        guard !items.isEmpty else { return nil }
        let food: Bool = t.c == "Food & Drinks" || t.c == "Groceries"
        return (food ? "Refunded: " : "Returned: ") + items.prefix(2).map { short($0.n) }.joined(separator: ", ") + (items.count > 2 ? " +" + String(items.count - 2) : "")
    }
}

enum GoesWithWords {
    /// "2026-09-20" → "Sep 2026"
    static func when(_ iso: String) -> String {
        let p = iso.split(separator: "-"); guard p.count >= 2, let m = Int(p[1]), (1...12).contains(m) else { return iso }
        return ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"][m - 1] + " " + String(p[0])
    }
}
