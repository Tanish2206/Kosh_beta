import SwiftUI

// MARK: - Wealth › Mutual funds (W2)
//
// What the funds are worth today and, where the statements say what went in, what went in and what it made, and the
// yearly return over the funds whose dated money kosh has; what goes in every month; each fund as a card (its kind,
// its plan when its name says it, whose, its worth, its return, what went in against what it made), sortable; and
// one note, only when there is something true to say (a Regular plan). The mockup's "put in against worth" line
// waits on a dated record of what each fund was worth: kosh keeps what was put in, fund by fund, but only the funds'
// total month by month, so a gap drawn from the two would mix funds sold with funds held. Not drawn until it's true.
// Since 1 Nov it is also Holdings' Mutual funds and Stocks tab (one layout, `cls`): each card's bar is its XIRR against
// the best in the list. The mockup's "What you really own" (a look-through of the funds' own shares) and the category
// average beside each bar need data kosh doesn't have (the funds' portfolios, AMFI's category returns): left out.

struct WealthFunds: View {
    @Environment(Store.self) private var store
    @Environment(\.accessibilityReduceMotion) private var still
    @State private var sort: String = "value"
    /// "mf" for the funds, "stk" for the shares: one layout for both (Holdings' Stocks tab)
    let cls: String
    /// inside Holdings, under its kinds row; on its own page otherwise (the old route, kept for links into it)
    let embedded: Bool
    let tabs: [String]
    let kind: String

    init(cls: String = "mf", embedded: Bool = false, tabs: [String] = [], kind: String = "") {
        self.cls = cls
        self.embedded = embedded
        self.tabs = tabs
        self.kind = kind
    }

    var body: some View {
        if embedded {
            scroller
        } else {
            scroller
                .background(alignment: .top) {
                    RadialGradient(colors: [Obsidian.term.opacity(0.17), Obsidian.term.opacity(0.04), Color.clear], center: .center, startRadius: 0, endRadius: 300)
                        .frame(width: 510, height: 600)
                        .offset(x: -40, y: -260)
                        .allowsHitTesting(false)
                }
                .navigationTitle(cls == "stk" ? "Stocks" : "Mutual funds")
                .navigationBarTitleDisplayMode(.inline)
                .obsidianPage(aura: Obsidian.term)
        }
    }

    var scroller: some View {
        let p: Person = store.who
        let funds: [Holding] = store.holdings(p).filter { $0.cls == cls && $0.amt > 0 }
        return ScrollView {
            VStack(alignment: .leading, spacing: 0) {
                top
                if funds.isEmpty {
                    Text(Self.empty(cls, p))
                        .font(.body).foregroundStyle(Obsidian.ink2)
                        .fixedSize(horizontal: false, vertical: true)
                        .padding(.top, 30)
                } else {
                    FundsHead(p: p, funds: funds, cls: cls)
                    if cls == "mf" {
                        FundsMonthly(p: p)
                            .padding(.top, 12)
                    }
                    FundsList(p: p, funds: funds, cls: cls, sort: $sort)
                        .padding(.top, 34)
                    if cls == "mf" {
                        FundsNote(funds: funds)
                            .padding(.top, 14)
                    }
                    FundsAfter(p: p, cls: cls)
                        .padding(.top, 14)
                }
            }
            .padding(.horizontal, 20)
            .padding(.bottom, 40)
            .animation(still ? nil : Motion.base, value: store.who)
            .animation(still ? nil : Motion.base, value: sort)
        }
        .scrollIndicators(.hidden)
    }

    @ViewBuilder var top: some View {
        if embedded {
            HoldingsTop(tabs: tabs, kind: kind).padding(.bottom, 18)
        } else {
            WhoseSwitch()
        }
    }

    static func empty(_ cls: String, _ p: Person) -> String {
        let what: String = cls == "stk" ? "shares" : "mutual funds"
        if p == .family { return "No " + what + " in the statements kosh has read." }
        return "No " + what + " in " + (p == .me ? "your" : p.title + "’s") + " name in the statements kosh has read."
    }
}

/// after the list: the dividends the shares paid (Stocks), what Regular plans cost against Direct (funds, from AMFI's
/// fee list when kosh has it)
struct FundsAfter: View {
    @Environment(Store.self) private var store
    let p: Person
    let cls: String
    var body: some View {
        let div: DividendBook? = cls == "stk" ? store.dividends(p) : nil
        if let b = div, let now = b.years.first {
            let today: String = store.snap.today
            WealthLinkRow(title: "Dividends",
                          sub: DividendWords.money(now.total) + (now.to == today ? " so far in " : " in ") + now.label + ", " + DividendWords.range(now.from, now.to),
                          color: Obsidian.ulip) { store.push(.dividends) }
                .background(RoundedRectangle(cornerRadius: 22, style: .continuous).fill(Obsidian.card))
                .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous).stroke(Obsidian.cardBorder, lineWidth: 1))
        }
    }
}

/// the tag, worth today, put in against made, and the year's return
struct FundsHead: View {
    @Environment(Store.self) private var store
    let p: Person
    let funds: [Holding]
    var cls: String = "mf"

    var body: some View {
        let worth: Double = funds.reduce(0) { $0 + $1.amt }
        let g: Gains = Gains(funds)
        let ret: HoldReturn? = store.yearly(p, cls)
        let when: String? = store.classUpdated(cls, p)?.line
        let tone: Color = WealthKind.color(cls)
        VStack(alignment: .leading, spacing: 0) {
            HStack(spacing: 6) {
                Circle().fill(tone).frame(width: 6, height: 6)
                Text(Self.tag(cls, funds.count))
                    .font(.system(size: 11, design: .monospaced)).tracking(0.7).textCase(.uppercase)
                    .foregroundStyle(tone)
            }
            .padding(.horizontal, 10)
            .padding(.vertical, 5)
            .background(RoundedRectangle(cornerRadius: 10).fill(tone.opacity(0.13)))
            .padding(.top, 6)
            Text("Worth today").caption().padding(.top, 18)
            WealthFigure(value: worth)
                .padding(.top, 6)
            if let when {
                Text(when).font(.system(size: 11, design: .monospaced)).foregroundStyle(Obsidian.ink3).padding(.top, 8)
            }
            if g.covered && g.cost > 0 {
                WealthSplitBar(parts: [(id: "in", v: min(g.cost, g.worth), color: tone.opacity(0.32)),
                                       (id: "made", v: max(0, g.gain), color: Obsidian.health)], height: 14, gap: 0)
                    .clipShape(Capsule())
                    .shadow(color: tone.opacity(0.35), radius: 9)
                    .padding(.top, 20)
            }
            HStack(alignment: .top, spacing: 14) {
                if g.covered && g.cost > 0 {
                    FundsFact(title: "You put in", value: Fmt.words(g.cost), tone: Obsidian.ink)
                    FundsFact(title: "It made", value: (g.gain >= 0 ? "+" : "−") + Fmt.words(abs(g.gain)), tone: g.gain >= 0 ? Obsidian.health : Color(hex: "#FF7A7A"), rule: true)
                }
                if let r = ret {
                    FundsFact(title: "A year, XIRR", value: Fmt.trim(r.r, 1) + "%", tone: Obsidian.ink, rule: g.covered && g.cost > 0,
                              note: r.n < r.of ? "over \(r.n) of \(r.of)" : nil)
                }
            }
            .padding(.top, 14)
            if g.covered && g.known < g.all {
                Text("Put in and made over the \(g.known) of \(g.all) " + (cls == "stk" ? "shares" : "funds") + " whose statements say what went in.")
                    .font(.system(size: 12)).foregroundStyle(Obsidian.ink3).padding(.top, 10)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
    }

    /// "Mutual funds · 6 funds", "Stocks · 8 companies"
    static func tag(_ cls: String, _ n: Int) -> String {
        if cls == "stk" { return "Stocks · " + (n == 1 ? "1 company" : "\(n) companies") }
        return "Mutual funds · " + (n == 1 ? "1 fund" : "\(n) funds")
    }
}

struct FundsFact: View {
    let title: String
    let value: String
    let tone: Color
    var rule: Bool = false
    var note: String? = nil
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title).font(.system(size: 12)).foregroundStyle(Obsidian.ink3)
            Text(value).font(.system(size: 17, weight: .semibold)).monospacedDigit().foregroundStyle(tone).privacySensitive()
            if let note { Text(note).font(.system(size: 10.5, design: .monospaced)).foregroundStyle(Obsidian.ink3) }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.leading, rule ? 14 : 0)
        .overlay(alignment: .leading) {
            if rule { Rectangle().fill(Color.white.opacity(0.08)).frame(width: 1) }
        }
    }
}

/// what goes into investments every month, from the repeats kosh found (SIPs and the like), and the next day one goes
struct FundsMonthly: View {
    @Environment(Store.self) private var store
    let p: Person
    var body: some View {
        let reps: [Recurring] = store.investRepeats(p)
        let flows: [(amt: Double, per: Int, next: String)] = reps.map { (r: Recurring) -> (amt: Double, per: Int, next: String) in (amt: r.amount, per: r.per ?? 1, next: r.date) }
        let m: (amt: Double, next: String?) = WealthBook.monthly(flows, today: store.snap.today)
        if m.amt > 0 {
            HStack {
                VStack(alignment: .leading, spacing: 3) {
                    Text(reps.count == 1 ? "1 SIP running" : "\(reps.count) SIPs running").font(.system(size: 12)).foregroundStyle(Obsidian.ink3)
                    Text(Fmt.rupees(m.amt) + " a month").font(.system(size: 16, weight: .semibold)).monospacedDigit().foregroundStyle(Obsidian.ink).privacySensitive()
                }
                Spacer()
                if let n = m.next {
                    Text("next on " + Day.fmt(n, "d MMM"))
                        .font(.system(size: 11, design: .monospaced)).foregroundStyle(Obsidian.ink2)
                        .padding(.horizontal, 10).padding(.vertical, 6)
                        .background(RoundedRectangle(cornerRadius: 10).fill(Color(hex: "#141419")))
                }
            }
            .obsidianCard(20, padding: 16)
            .accessibilityElement(children: .combine)
        }
    }
}

/// every fund as a card, sorted by what's worth most, what returns most a year, or what made most
struct FundsList: View {
    @Environment(Store.self) private var store
    let p: Person
    let funds: [Holding]
    var cls: String = "mf"
    @Binding var sort: String

    var body: some View {
        let sorts: [(id: String, label: String)] = Self.sorts(funds)
        let by: String = sorts.contains { $0.id == sort } ? sort : "value"
        let shown: [Holding] = Self.sorted(funds, by: by)
        let topX: Double = Self.topReturn(funds)
        let showWho: Bool = p == .family && store.whoOptions.count > 2
        VStack(alignment: .leading, spacing: 12) {
            ViewThatFits(in: .horizontal) {
                WealthSectionHead(title: cls == "stk" ? "Each company" : "Each fund") {
                    if sorts.count > 1 { WealthPills(options: sorts, selection: $sort, height: 32) }
                }
                VStack(alignment: .leading, spacing: 10) {
                    WealthSectionHead(title: cls == "stk" ? "Each company" : "Each fund") { EmptyView() }
                    if sorts.count > 1 { WealthPills(options: sorts, selection: $sort, height: 32) }
                }
            }
            VStack(spacing: 10) {
                ForEach(shown) { h in
                    FundCard(h: h, topX: topX, who: showWho ? store.ownerName(h.person) : nil, cls: cls)
                }
            }
            if topX > 0 {
                Text("Each bar is its return a year (XIRR), against the best of them. kosh has no category averages to set beside it.")
                    .font(.caption).foregroundStyle(Obsidian.ink3)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
    }

    /// the longest bar: the best yearly return among them (nothing when none has one)
    static func topReturn(_ funds: [Holding]) -> Double {
        funds.compactMap(\.xirr).filter { $0 > 0 }.max() ?? 0
    }

    /// Value always; XIRR when a fund has its yearly return; Gain when a fund's statement says what went in
    static func sorts(_ funds: [Holding]) -> [(id: String, label: String)] {
        var out: [(id: String, label: String)] = [(id: "value", label: "Value")]
        if funds.contains(where: { $0.xirr != nil }) { out.append((id: "returns", label: "XIRR")) }
        if funds.contains(where: { $0.gain != nil }) { out.append((id: "gain", label: "Gain")) }
        return out
    }
    /// (a fund without the figure sorted on goes after those with it, by its worth)
    static func sorted(_ funds: [Holding], by: String) -> [Holding] {
        funds.sorted { (a: Holding, b: Holding) -> Bool in
            switch by {
            case "returns":
                if (a.xirr == nil) != (b.xirr == nil) { return a.xirr != nil }
                if let x = a.xirr, let y = b.xirr, x != y { return x > y }
            case "gain":
                if (a.gain == nil) != (b.gain == nil) { return a.gain != nil }
                if let x = a.gain, let y = b.gain, x != y { return x > y }
            default: break
            }
            return a.amt > b.amt
        }
    }
}

struct FundCard: View {
    let h: Holding
    /// the best return among the list: the full length of a bar
    let topX: Double
    let who: String?
    var cls: String = "mf"

    var body: some View {
        let plan: String? = cls == "mf" ? WealthKind.plan(h.bank) : nil
        let regular: Bool = plan == "Regular"
        let cost: Double = h.cost ?? 0
        let tone: Color = WealthKind.color(cls)
        VStack(alignment: .leading, spacing: 0) {
            HStack(alignment: .top, spacing: 12) {
                VStack(alignment: .leading, spacing: 8) {
                    Text(HoldingName.pretty(h.bank)).font(.system(size: 15, weight: .medium)).foregroundStyle(Obsidian.ink)
                        .fixedSize(horizontal: false, vertical: true)
                    HStack(spacing: 5) {
                        if cls == "mf" { FundPill(text: FundKind.of(h.bank).rawValue, tone: Obsidian.ink2, fill: Color(hex: "#141419")) }
                        if let plan { FundPill(text: plan, tone: regular ? Obsidian.savings : Obsidian.ink2, fill: regular ? Obsidian.savings.opacity(0.13) : Color(hex: "#141419")) }
                        if let who { FundPill(text: who, tone: Obsidian.ink2, fill: Color(hex: "#141419")) }
                    }
                }
                Spacer(minLength: 8)
                VStack(alignment: .trailing, spacing: 4) {
                    Text(Fmt.rupees(h.amt)).font(.system(size: 17, weight: .semibold)).monospacedDigit().foregroundStyle(Obsidian.ink).privacySensitive()
                    if let x = h.xirr {
                        Text(Fmt.trim(x, 1) + "% XIRR").font(.system(size: 11.5, design: .monospaced)).foregroundStyle(x >= 0 ? Obsidian.health : Color(hex: "#FF7A7A"))
                    }
                }
                .fixedSize()
            }
            if let x = h.xirr, topX > 0 {
                FundReturnBar(x: x, top: topX, tone: tone)
                    .padding(.top, 14)
            }
            if regular {
                Text("Regular plan: a distributor is paid out of it every year")
                    .font(.system(size: 12, weight: .semibold)).foregroundStyle(Obsidian.savings)
                    .fixedSize(horizontal: false, vertical: true)
                    .padding(.top, 10)
            }
            if cost > 0 {
                let made: Double = h.amt - cost
                HStack {
                    Text("put in " + Fmt.rupees(cost))
                    Spacer()
                    Text((made >= 0 ? "+" : "−") + Fmt.rupees(abs(made)))
                }
                .font(.system(size: 10.5, design: .monospaced)).monospacedDigit().foregroundStyle(Obsidian.ink3)
                .padding(.top, 7)
                .privacySensitive()
            }
        }
        .obsidianCard(22, padding: 16)
        .accessibilityElement(children: .combine)
    }
}

/// a fund's yearly return as a bar against the best in the list; a loss is a short red bar
struct FundReturnBar: View {
    let x: Double
    let top: Double
    let tone: Color
    var body: some View {
        let f: Double = x > 0 ? min(1, x / max(top, 0.01)) : 0.04
        let fill: Color = x >= 0 ? tone : Color(hex: "#FF7A7A")
        GeometryReader { geo in
            Capsule().fill(fill).frame(width: max(4, geo.size.width * CGFloat(f)))
        }
        .frame(height: 6)
        .background(Capsule().fill(Color(hex: "#1C1C22")))
        .accessibilityHidden(true)
    }
}

struct FundPill: View {
    let text: String
    let tone: Color
    let fill: Color
    var body: some View {
        Text(text).font(.system(size: 10.5, design: .monospaced)).foregroundStyle(tone).lineLimit(1)
            .padding(.horizontal, 7).padding(.vertical, 3)
            .background(RoundedRectangle(cornerRadius: 7).fill(fill))
    }
}

/// one quiet thing worth knowing, only when it's true: a Regular plan (what its Direct plan costs less, from AMFI's
/// fee list when kosh has it). Facts only, never what to do
struct FundsNote: View {
    @Environment(Store.self) private var store
    let funds: [Holding]
    var body: some View {
        let regular: [Holding] = funds.filter { WealthKind.plan($0.bank) == "Regular" }.sorted { $0.amt > $1.amt }
        if let first = regular.first {
            let fees: [FundFeesInfo.Row] = regular.compactMap { store.regularFee($0) }
            let year: Double = fees.reduce(0) { $0 + $1.year }
            HStack(alignment: .top, spacing: 12) {
                Circle().fill(Obsidian.savings).frame(width: 8, height: 8).padding(.top, 6)
                Self.words(first: first, count: regular.count, fees: fees, year: year)
                    .font(.system(size: 13)).foregroundStyle(Color(hex: "#D4D4D8"))
                    .lineSpacing(3)
                    .fixedSize(horizontal: false, vertical: true)
                    .privacySensitive()
            }
            .padding(16)
            .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).stroke(Obsidian.savings.opacity(0.25), lineWidth: 1))
        }
    }

    static func words(first: Holding, count: Int, fees: [FundFeesInfo.Row], year: Double) -> Text {
        let name: String = HoldingName.pretty(first.bank).components(separatedBy: " · ").first ?? first.bank
        let lead: String = count == 1 ? name + " is a Regular plan." : "\(count) of your funds are Regular plans."
        var rest: String = " A Regular plan pays a distributor out of the fund every year; the Direct plan of the same fund doesn’t."
        if year >= 1 {
            rest = " By AMFI’s fee list, the Direct " + (count == 1 ? "plan" : "plans") + " would cost about " + Fmt.rupees(Fmt.roundish(year)) + " a year less at today’s value."
        }
        let bold: Text = Text(lead).fontWeight(.semibold).foregroundStyle(Obsidian.ink)
        return bold + Text(rest)
    }
}
