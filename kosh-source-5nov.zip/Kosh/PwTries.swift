import Foundation

// MARK: - The order passwords are tried in on a locked paper
//
// Screen-free, so engine-test/pw-tries.js compiles it with swiftc and checks it without Xcode (as PaperShelf.swift is).
// Papers.swift tryProfiles hands it what the engine made (agent.js pwBuild for the sender's rule, pwGuess for the usual
// formats, each person's in turn, the paper's likely holder first); LockedFiles.swift asks it what to try on a statement
// inside a zip. It decides only the order and how many: the passwords themselves are the engine's.

enum PwTries {
    /// one password the engine made, with the id of the format that made it ("hint" for the sender's own rule)
    struct Made: Equatable { var pw: String; var format: String? }

    /// Every password to try on a locked paper, in order, at most `cap` of them: the one saved for its sender (it opens
    /// most of its papers); then the sender's own rule made from each person's details (the email's words win over
    /// any guess); then the format that opened this sender's last paper, made from each person's; then the usual
    /// formats, the likely holder's in full (`takeFirst`), everyone else's commonest (`takeRest`). Each once.
    static func order(saved: String?, built: [[Made]], guessed: [[Made]], learnt: String, takeFirst: Int, takeRest: Int, cap: Int)
        -> (list: [String], formatOf: [String: String]) {
        var list: [String] = []
        var formatOf: [String: String] = [:]
        func add(_ m: Made) {
            guard !m.pw.isEmpty, !list.contains(m.pw) else { return }
            list.append(m.pw)
            if let f = m.format, !f.isEmpty { formatOf[m.pw] = f }
        }
        if let s = saved { add(Made(pw: s, format: nil)) }
        for person in built { for m in person { add(Made(pw: m.pw, format: m.format ?? "hint")) } }
        var guesses: [Made] = []
        for (i, person) in guessed.enumerated() { guesses += person.prefix(i == 0 ? takeFirst : takeRest) }
        // (the format that opened the sender's last paper, before the other guesses: never before the rule's own)
        if !learnt.isEmpty { for m in guesses where m.format == learnt { add(m) } }
        for m in guesses { add(m) }
        return (Array(list.prefix(max(0, cap))), formatOf)
    }

    /// What to try on a statement inside a zip, in order: the password you typed (it may be the statement's own, when
    /// the zip opened with a saved one), the one that opened the zip, then every other password worked out for the
    /// sender. A statement locked another way than its zip opens by itself when kosh can make its password too;
    /// handed only the zip's, it stayed locked however well kosh knew your details. Each once, none empty.
    static func inner(typed: String?, opener: String?, also: [String]) -> [String] {
        var out: [String] = []
        for p in [typed ?? "", opener ?? ""] + also where !p.isEmpty && !out.contains(p) { out.append(p) }
        return out
    }
}
