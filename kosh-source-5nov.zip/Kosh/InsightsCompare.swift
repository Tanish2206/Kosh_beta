import SwiftUI
import UIKit
import Charts

// MARK: - Insights: categories across months, and one category up close
//
// Everything here is worked out from the payments themselves, for whoever is shown (Family, You, …) and under
// the Actual/True lens, so it moves with every correction and every new payment.

// (CatMonths, the months side by side, and the rest of the page's arithmetic live in InsightsMath.swift)

extension Store {
    /// the n latest months kosh has, oldest first (this month, so far, is the last)
    func latestMonths(_ n: Int) -> [String] { Array(snap.months.map(\.m).sorted().suffix(n)) }

    /// each month's kinds and total as the month itself has them (money back taken off), not the payments summed again:
    /// the grid, Where it goes and Up close then agree with Home and the month's own page
    func catMonths(_ months: [String]) -> CatMonths {
        CatMonths.make(months, kinds: { m in month(m).map { catsSpent($0) } }, total: { spent($0) }, partial: partMonths)
    }
    /// the month the mail starts in, when it was read from a day past the 1st: shown as it is, never a usual month
    var partMonths: Set<String> { Set(snap.months.filter { $0.partial == true }.map(\.m)) }

    func catSymbol(_ c: String) -> String { snap.cats[c]?.symbol ?? "square.grid.2x2.fill" }

    /// "Sep"; "Oct so far" for the month still running; "Jul from 17" for the part-month the mail starts in
    func monthLabel(_ m: String) -> String {
        if m == snap.cm { return Day.monthShort(m) + " so far" }
        if let day = partFrom(m) { return Day.monthShort(m) + " from " + String(day) }
        return Day.monthShort(m)
    }
    /// the day the part-month the mail starts in is read from (17 for "from 17 Jul"); nil for a whole month
    func partFrom(_ m: String) -> Int? {
        guard let mo = month(m), mo.partial == true, let since = mo.since, since.count >= 10 else { return nil }
        return Int(since.suffix(2))
    }
}

enum Compact {
    /// "12.3k", "1.2L", "850": a figure for a narrow cell
    static func amount(_ v: Double) -> String {
        let a = abs(v)
        if a >= 1e7 { return Fmt.trim(a / 1e7, 1) + "Cr" }
        if a >= 1e5 { return Fmt.trim(a / 1e5, 1) + "L" }
        if a >= 1e4 { return Fmt.trim(a / 1000, 0) + "k" }
        if a >= 1000 { return Fmt.trim(a / 1000, 1) + "k" }
        return a > 0 ? String(Int(safe: a.rounded())) : "–"
    }
}

/// how many months to put side by side: two to six, as many as there are (InsightsMath.sideBySide); its label is the
/// number the table shows, and with one or two months there is nothing to choose, so it isn't there
struct MonthsPicker: View {
    @Binding var n: Int
    let available: Int
    var body: some View {
        let s = InsightsMath.sideBySide(asked: n, available: available)
        Menu {
            // (its selection is the number shown, always one of its own choices)
            Picker("Months", selection: Binding(get: { s.shown }, set: { n = $0 })) {
                ForEach(s.choices, id: \.self) { k in Text("\(k) months").tag(k) }
            }
        } label: {
            HStack(spacing: 6) {
                Text("\(s.shown) months").font(.subheadline.weight(.semibold)).lineLimit(1)
                Image(systemName: "chevron.up.chevron.down").font(.caption2.weight(.bold))
            }
            .padding(.leading, 14)
            .padding(.trailing, 12)
            .frame(minHeight: 36)
            .background(Color.kosh.opacity(0.12), in: Capsule())
            .foregroundStyle(InsightInk.blue)
        }
        .accessibilityLabel("Months side by side, now \(s.shown)")
        .sensoryFeedback(.selection, trigger: n)
    }
}

// MARK: Category × month

/// a category's name where room is short: the word people say ("Food", "Cash out", "Subs"). The full name stays for
/// VoiceOver and wherever there's room.
enum CatShort {
    static let names: [String: String] = [
        "Cash Withdrawal": "Cash out", "Miscellaneous": "Misc", "Subscriptions": "Subs", "Food & Drinks": "Food",
        "Entertainment": "Fun", "Family Support": "Family", "Hidden Charges": "Charges", "Wallet & Gift Cards": "Wallets",
        "Investments": "Invest", "Personal": "Personal", "Education": "Study",
    ]
    static func of(_ c: String) -> String { names[c] ?? c }
}

/// every category's spending, month by month, newest first, as a heat table: each row shaded against its own
/// biggest month, its usual month at the end. Two or three months (and Usual) share the card's width evenly; more
/// than fit scroll, the names staying put. Names are the short ones, never cut off. Tap a cell to look inside that
/// category in that month.
struct CategoryMonthGrid: View {
    @Environment(Store.self) private var store
    @Environment(\.accessibilityReduceMotion) private var still
    let data: CatMonths
    @Binding var n: Int
    /// a category, and the month of the cell tapped (nil for its name or its usual): Up close takes it from here
    let open: (String, String?) -> Void
    @State private var showAll = false
    @State private var atEnd = false
    /// the table's width (names and months together), measured once it's laid out
    @State private var room: CGFloat = 0
    @ScaledMetric(relativeTo: .footnote) private var cellW: CGFloat = 46
    @ScaledMetric(relativeTo: .footnote) private var cellH: CGFloat = 30
    @ScaledMetric(relativeTo: .footnote) private var rowH: CGFloat = 38
    @ScaledMetric(relativeTo: .footnote) private var headH: CGFloat = 40
    @ScaledMetric(relativeTo: .footnote) private var totH: CGFloat = 44
    @ScaledMetric(relativeTo: .footnote) private var usualW: CGFloat = 52
    /// the names' type size (footnote) at the text size in use, to measure them by
    @ScaledMetric(relativeTo: .footnote) private var nameFont: CGFloat = 13

    /// the table's measures, grown with the text size but only so far
    struct Geo { let cellW, cellH, rowH, headH, totH, nameW, usualW: CGFloat; var pad: CGFloat = 14 }

    /// the gap between columns, Usual's rule, and the room left at the right end
    static let gap: CGFloat = 4
    static let rule: CGFloat = 2
    static let endPad: CGFloat = 14
    static let fillPad: CGFloat = 8
    static let icon: CGFloat = 24

    var body: some View {
        let cm: String = store.snap.cm
        let side = InsightsMath.sideBySide(asked: n, available: data.months.count)
        let k: Int = side.shown
        let months: [String] = Array(data.months.suffix(k).reversed())
        // Usual: the finished whole months shown (never the running month, never the part-month the mail starts in)
        let full: [String] = InsightsMath.usualMonths(months, cm: cm, partial: data.partial)
        let cats: [String] = data.cats.filter { c in months.contains { data.at(c, $0) > 0 } }
        let rows: [String] = showAll ? cats : Array(cats.prefix(8))
        let usual: [String: Double] = CategoryMonthGrid.usuals(cats, full: full, data: data)
        let usualAll: Double = InsightsMath.usualTotal(data, over: full)
        // the name column as wide as its longest short name (all of them, so it holds still when the list opens out)
        let cap: CGFloat = room > 0 ? max(120, room * 0.42) : 190
        let nameW: CGFloat = CategoryMonthGrid.nameWidth(cats.map(CatShort.of), font: nameFont, cap: cap)
        // the months and Usual share what's left evenly when each still gets a cell's width; otherwise they scroll
        let even: CGFloat = CategoryMonthGrid.evenWidth(room: room - nameW, columns: k)
        let fits: Bool = room > 0 && even >= min(cellW, 84)
        let g = Geo(cellW: fits ? even : min(cellW, 84), cellH: min(cellH, 54), rowH: min(rowH, 64), headH: min(headH, 64),
                    totH: min(totH, 70), nameW: nameW, usualW: fits ? even : min(usualW, 92),
                    pad: fits ? CategoryMonthGrid.fillPad : CategoryMonthGrid.endPad)
        if !cats.isEmpty {
            VStack(alignment: .leading, spacing: 12) {
                HStack(alignment: .center) {
                    InsightTitle(text: "Category × month")
                    Spacer(minLength: 8)
                    if !side.choices.isEmpty { MonthsPicker(n: $n, available: data.months.count) }
                }
                HStack(alignment: .top, spacing: 0) {
                    names(rows, usual: usual, g: g)
                    ScrollView(.horizontal) {
                        cells(rows, months: months, cm: cm, usual: usual, usualAll: usualAll, g: g)
                    }
                    .scrollIndicators(.hidden)
                    .scrollDisabled(fits)
                    .scrollBounceBehavior(.basedOnSize, axes: .horizontal)
                    .onScrollGeometryChange(for: Bool.self) { s in
                        s.visibleRect.maxX >= s.contentSize.width - 2
                    } action: { _, end in
                        atEnd = end
                    }
                }
                .onGeometryChange(for: CGFloat.self) { geo in
                    geo.size.width
                } action: { w in
                    if abs(w - room) > 0.5 { room = w }
                }
                .padding(.top, 6)
                .padding(.bottom, 4)
                .background(Color.surface)
                .overlay(alignment: .trailing) {
                    LinearGradient(stops: [.init(color: Color.surface.opacity(0), location: 0),
                                           .init(color: Color.surface.opacity(0.92), location: 0.7),
                                           .init(color: Color.surface, location: 1)], startPoint: .leading, endPoint: .trailing)
                        .frame(width: 34)
                        .opacity(atEnd || fits ? 0 : 1)
                        .animation(Motion.quick, value: atEnd)
                        .allowsHitTesting(false)
                        .accessibilityHidden(true)
                }
                .clipShape(RoundedRectangle(cornerRadius: 26, style: .continuous))
                .privacySensitive()
                .animation(still ? nil : Motion.base, value: k)
                HStack(alignment: .firstTextBaseline, spacing: 10) {
                    if cats.count > 8 {
                        Button(showAll ? "Fewer" : "All \(cats.count) categories") {
                            withAnimation(still ? nil : Motion.open) { showAll.toggle() }
                        }
                        .font(.subheadline.weight(.semibold))
                    }
                    Spacer(minLength: 0)
                    Text("Tap a cell to look inside it.").font(.footnote).foregroundStyle(.secondary).multilineTextAlignment(.trailing)
                }
                legend(live: months.contains(cm), full: full, scrolls: !fits)
            }
        }
    }

    /// the names, which stay put while the months scroll: the short ones, whole
    private func names(_ rows: [String], usual: [String: Double], g: Geo) -> some View {
        VStack(alignment: .leading, spacing: 0) {
            Text("₹").font(.caption.weight(.semibold)).foregroundStyle(.secondary)
                .padding(.leading, 12)
                .frame(width: g.nameW, height: g.headH, alignment: .leading)
                .accessibilityHidden(true)
            ForEach(rows, id: \.self) { c in
                Button { open(c, nil) } label: {
                    HStack(spacing: 8) {
                        IconTile(symbol: store.catSymbol(c), color: store.catColor(c), size: CategoryMonthGrid.icon)
                        // sized to fit; a name of your own too long for the column shrinks a little, then takes two lines
                        Text(CatShort.of(c)).font(.footnote.weight(.semibold))
                            .lineLimit(2).minimumScaleFactor(0.85)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                    .padding(.leading, 12)
                    .padding(.trailing, 6)
                    .frame(width: g.nameW, height: g.rowH, alignment: .leading)
                    .contentShape(Rectangle())
                }
                .buttonStyle(.press)
                .spokenFigures(CategoryMonthGrid.spokenName(c, usual: usual[c] ?? 0), hidden: c)
                .accessibilityHint("Looks at it up close")
            }
            InsightDivider().padding(.top, 4)
            Text("All spending").font(.footnote.weight(.bold)).lineLimit(1).minimumScaleFactor(0.8)
                .padding(.leading, 12)
                .frame(width: g.nameW, height: g.totH, alignment: .leading)
        }
        .frame(width: g.nameW)
    }

    /// the months, newest first, and the usual month
    private func cells(_ rows: [String], months: [String], cm: String, usual: [String: Double], usualAll: Double, g: Geo) -> some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack(spacing: CategoryMonthGrid.gap) {
                ForEach(months, id: \.self) { m in
                    let live: Bool = m == cm
                    VStack(spacing: 0) {
                        Text(Day.monthShort(m)).font(.caption.weight(live ? .bold : .semibold))
                        if live {
                            Text("so far").font(.caption2.weight(.semibold))
                        } else if let day = store.partFrom(m) {
                            // the part-month the mail starts in: from the day it's read
                            Text("from " + String(day)).font(.caption2)
                        } else if m.hasSuffix("-01") {
                            Text("’" + String(m.prefix(4).suffix(2))).font(.caption2)
                        }
                    }
                    .foregroundStyle(live ? InsightInk.blue : Color.secondary)
                    .lineLimit(1)
                    .minimumScaleFactor(0.7)
                    .frame(width: g.cellW, height: g.headH)
                }
                Text("Usual").font(.caption.weight(.semibold)).foregroundStyle(.secondary)
                    .lineLimit(1).minimumScaleFactor(0.7)
                    .frame(width: g.usualW, height: g.headH)
                    .overlay(alignment: .leading) { Rectangle().fill(Color.primary.opacity(0.15)).frame(width: 0.5) }
                    .padding(.leading, CategoryMonthGrid.rule)
            }
            .accessibilityHidden(true)
            ForEach(rows, id: \.self) { c in
                let color: Color = store.catColor(c)
                let top: Double = max(1, months.map { data.at(c, $0) }.max() ?? 1)
                HStack(spacing: CategoryMonthGrid.gap) {
                    ForEach(months, id: \.self) { m in
                        let v: Double = data.at(c, m)
                        Button { open(c, m) } label: {
                            GridCell(text: Compact.amount(v), strong: v > 0 && v >= top, empty: v <= 0,
                                     tint: color.opacity(v > 0 ? 0.06 + 0.30 * v / top : 0), live: m == cm, g: g)
                                .frame(height: g.rowH)
                                .contentShape(Rectangle())
                        }
                        .buttonStyle(.press)
                        .spokenFigures(CategoryMonthGrid.spokenCell(c, m: m, v: v, live: m == cm), hidden: c + ", " + Day.monthName(m))
                        .accessibilityHint("Looks inside it")
                    }
                    Text(Compact.amount(usual[c] ?? 0))
                        .font(.system(.caption, design: .rounded)).monospacedDigit()
                        .foregroundStyle(.secondary)
                        .lineLimit(1).minimumScaleFactor(0.6)
                        .frame(width: g.usualW, height: g.rowH)
                        .overlay(alignment: .leading) { Rectangle().fill(Color.primary.opacity(0.15)).frame(width: 0.5) }
                        .padding(.leading, CategoryMonthGrid.rule)
                        .accessibilityHidden(true)
                }
            }
            InsightDivider().padding(.top, 4)
            HStack(spacing: CategoryMonthGrid.gap) {
                ForEach(months, id: \.self) { m in
                    GridCell(text: Compact.amount(data.total[m] ?? 0), strong: true, empty: false, tint: Color.clear, live: m == cm, g: g)
                        .frame(height: g.totH)
                        .spokenFigures(CategoryMonthGrid.spokenCell("All spending", m: m, v: data.total[m] ?? 0, live: m == cm), hidden: "All spending, " + Day.monthName(m))
                }
                Text(Compact.amount(usualAll))
                    .font(.system(.caption, design: .rounded, weight: .bold)).monospacedDigit()
                    .lineLimit(1).minimumScaleFactor(0.6)
                    .frame(width: g.usualW, height: g.totH)
                    .overlay(alignment: .leading) { Rectangle().fill(Color.primary.opacity(0.15)).frame(width: 0.5) }
                    .padding(.leading, CategoryMonthGrid.rule)
                    .spokenFigures("A usual month, all spending: " + Fmt.rupees(usualAll), hidden: "A usual month, all spending")
            }
        }
        .padding(.trailing, g.pad)
    }

    private func legend(live: Bool, full: [String], scrolls: Bool) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            WrapRow(spacing: 16, lineSpacing: 8) {
                HStack(spacing: 7) {
                    HStack(spacing: 2) {
                        ForEach([0.08, 0.17, 0.27, 0.38], id: \.self) { o in
                            RoundedRectangle(cornerRadius: 3, style: .continuous).fill(Color.kosh.opacity(o)).frame(width: 11, height: 11)
                        }
                    }
                    Text("darker = more that month")
                }
                if live {
                    HStack(spacing: 7) {
                        RoundedRectangle(cornerRadius: 3, style: .continuous)
                            .strokeBorder(Color.kosh.opacity(0.7), style: StrokeStyle(lineWidth: 1, dash: [2, 2]))
                            .frame(width: 11, height: 11)
                        Text("still going")
                    }
                }
            }
            Text(CategoryMonthGrid.note(full: full, scrolls: scrolls)).fixedSize(horizontal: false, vertical: true)
        }
        .font(.footnote)
        .foregroundStyle(.secondary)
        .padding(.horizontal, 4)
        .accessibilityElement(children: .combine)
    }

    /// the name column: the row's padding, the icon and the longest name at this size (or "All spending", whichever
    /// is wider), never more than `cap`
    static func nameWidth(_ shown: [String], font: CGFloat, cap: CGFloat) -> CGFloat {
        let semibold = UIFont.systemFont(ofSize: font, weight: .semibold)
        let bold = UIFont.systemFont(ofSize: font, weight: .bold)
        var widest: CGFloat = 0
        for s in shown { widest = max(widest, (s as NSString).size(withAttributes: [.font: semibold]).width) }
        let named: CGFloat = 12 + icon + 8 + ceil(widest) + 6 + 4
        let total: CGFloat = 12 + ceil(("All spending" as NSString).size(withAttributes: [.font: bold]).width * 0.8) + 6
        return min(cap, max(named, total))
    }

    /// each column's width when the months and Usual share `room` evenly
    static func evenWidth(room: CGFloat, columns k: Int) -> CGFloat {
        let fixed: CGFloat = gap * CGFloat(k) + rule + fillPad
        return floor((room - fixed) / CGFloat(k + 1) * 2) / 2
    }

    /// each category's usual month: the average over the finished months shown, the empty ones counted too
    static func usuals(_ cats: [String], full: [String], data: CatMonths) -> [String: Double] {
        var out: [String: Double] = [:]
        guard !full.isEmpty else { return out }
        for c in cats { out[c] = InsightsMath.usual(c, data, over: full) }
        return out
    }

    static func note(full: [String], scrolls: Bool) -> String {
        var s: String = "Each row against its own biggest month."
        let sorted: [String] = full.sorted()
        if let a = sorted.first, let b = sorted.last {
            s += a == b ? " Usual is " + Day.monthName(a) + "." : " Usual is the average full month, " + Day.monthShort(a) + " to " + Day.monthShort(b) + "."
        }
        return scrolls ? s + " Swipe for more." : s
    }

    static func spokenName(_ c: String, usual: Double) -> String {
        usual > 0 ? c + ", usually " + Fmt.rupees(Fmt.roundish(usual)) + " a month" : c
    }

    static func spokenCell(_ c: String, m: String, v: Double, live: Bool) -> String {
        let when: String = Day.monthName(m) + (live ? " so far" : "")
        let amount: String = v > 0 ? Fmt.rupees(v) : "nothing"
        return c + ", " + when + ": " + amount
    }
}

/// one figure in the table, on its shade; the running month's outlined in dashes
private struct GridCell: View {
    let text: String
    let strong: Bool
    let empty: Bool
    let tint: Color
    let live: Bool
    let g: CategoryMonthGrid.Geo
    var body: some View {
        let shape = RoundedRectangle(cornerRadius: 8, style: .continuous)
        Text(text)
            .font(.system(.caption, design: .rounded, weight: strong ? .bold : .medium)).monospacedDigit()
            .lineLimit(1).minimumScaleFactor(0.6)
            .foregroundStyle(empty ? Color.secondary : Color.primary)
            .frame(width: g.cellW, height: g.cellH)
            .background(tint, in: shape)
            .overlay {
                if live { shape.strokeBorder(Color.kosh.opacity(0.55), style: StrokeStyle(lineWidth: 1, dash: [3, 2])) }
            }
    }
}

// MARK: Inside one category

/// what's inside a category's payments, by sub-category or by place (Up close's Inside and Places). The old "Inside one
/// category" card that lived here had no caller left; Up close is that card now.
enum CategoryDive {
    /// one line of the breakdown: its name, a caption of what is in it (the shops in a kind, the kinds at a shop), and
    /// the payments behind it (newest first) so it can open into them
    struct Part: Identifiable { let name: String; let v: Double; let n: Int; var sub: String = ""; var rows: [Txn] = []; var id: String { name } }

    static func parts(_ rows: [Txn], by key: (Txn) -> String, caption: (Txn) -> String = { _ in "" }) -> [Part] {
        var v: [String: Double] = [:], n: [String: Int] = [:], r: [String: [Txn]] = [:]
        for t in rows { let k = key(t); v[k, default: 0] += t.a; n[k, default: 0] += 1; r[k, default: []].append(t) }
        return v.keys.map { (k: String) -> Part in
            let xs: [Txn] = r[k] ?? []
            // the caption: the top three of what's inside, by money, each once
            var by: [String: Double] = [:]
            for t in xs { let c: String = caption(t); if !c.isEmpty && c != k { by[c, default: 0] += t.a } }
            let ranked: [(key: String, value: Double)] = by.sorted { $0.value != $1.value ? $0.value > $1.value : $0.key < $1.key }
            let top: [String] = ranked.prefix(3).map { $0.key }
            let more: Int = max(0, ranked.count - 3)
            let line: String = top.joined(separator: ", ") + (more > 0 ? " +" + String(more) : "")
            return Part(name: k, v: v[k] ?? 0, n: n[k] ?? 0, sub: line, rows: xs.sorted { ($0.d, $0.t) > ($1.d, $1.t) })
        }.sorted { (a: Part, b: Part) -> Bool in
            // (what kosh couldn't tell goes last, whatever its size: the known kinds lead)
            let ua: Bool = a.name == unknown, ub: Bool = b.name == unknown
            if ua != ub { return ub }
            return a.v != b.v ? a.v > b.v : a.name < b.name
        }
    }

    /// where a payment went, as a person says it: the app or store kosh knows it by ("Myntra"), else its payee cleaned
    /// of what the bank's alert cut short or added ("Uniqlo Indi" → Uniqlo, "Flipkart Pa" → Flipkart)
    static func place(_ t: Txn) -> String {
        let p: String = (t.pf ?? "").trimmingCharacters(in: .whitespaces)
        return ShopName.clean(p.isEmpty ? t.m : p)
    }

    /// a sub-category that says nothing about what was bought
    static func vague(_ s: String, cat: String) -> Bool {
        let k: String = s.trimmingCharacters(in: .whitespaces).lowercased()
        return k.isEmpty || k == cat.lowercased() || ["other", "others", "general", "misc", "miscellaneous", "uncategorised", "uncategorized", "not split further"].contains(k)
    }
    /// what it was. Shopping: what was bought, as kosh worked it out from the order's items, your word, its kind or its
    /// shop (engine.js › whatWasBought), where it was bought never being a kind; else its sub-category
    static func kind(_ t: Txn, cat: String) -> String {
        if cat == "Shopping" { return t.wk ?? unknown }
        let s: String = t.s.trimmingCharacters(in: .whitespaces)
        return vague(s, cat: cat) ? "Other " + cat.lowercased() : s
    }
    /// the shopping kosh couldn't tell the kind of: its mail named no items and its shop sells everything
    static let unknown: String = "Not known yet"
}

/// one kind of thing you buy, over the last nine months: how many times, in all and usually, how often (every: the middle
/// gap in days; steady: most gaps near it), the shops, the latest items, the next one when steady
struct BuyPattern: Decodable, Hashable, Identifiable {
    let k: String; let n: Int; let total: Double; let usual: Double; let share: Double
    let shops: [String]; let last: String; let items: [String]
    var every: Int? = nil; var steady: Bool? = nil; var next: String? = nil
    var id: String { k }
    /// "every ~3 weeks", "about monthly", "every ~10 days"; nil with too few to tell
    var rhythm: String? {
        guard let e = every, e > 0 else { return nil }
        let pre: String = steady == true ? "every " : "roughly every "
        if e < 11 { return pre + String(e) + " days" }
        if e < 25 { return pre + String(Int((Double(e) / 7).rounded())) + " weeks" }
        if e < 45 { return steady == true ? "about monthly" : "roughly monthly" }
        return pre + String(Int((Double(e) / 30).rounded())) + " months"
    }
    /// the shops as people say them, each once
    var places: [String] {
        var out: [String] = []
        for s in shops { let c: String = ShopName.clean(s); if !out.contains(c) { out.append(c) } }
        return out
    }
}

/// a shop's name from a payee as the bank printed it: corporate words and the alert's cut-off tail dropped, a few known
/// legal names said the way people say them, capitals evened out
enum ShopName {
    static let known: [String: String] = [
        "hennes n mauritz": "H&M", "hennes & mauritz": "H&M", "hennes and mauritz": "H&M",
        "amazonsellerservices": "Amazon", "amazon seller services": "Amazon", "amazon pay": "Amazon", "amazon india": "Amazon",
        "myntradesignsprivatelim": "Myntra", "myntradesignspvtltd": "Myntra", "flipkart internet": "Flipkart",
        "bundl technologies": "Swiggy", "zomato media": "Zomato", "avenue supermarts": "DMart",
    ]
    /// words a payee's legal name ends in, and that a cut-off alert leaves a piece of ("Indi", "Pvt", "Ap", "Desi")
    static let tails: [String] = ["india", "private", "pvt", "limited", "ltd", "llp", "apparels", "apparel", "app", "pay", "payments",
                                  "designs", "design", "sports", "services", "service", "technologies", "technology", "tech",
                                  "retail", "retails", "works", "shop", "shoppe", "store", "stores", "beauty", "online",
                                  "internet", "enterprises", "enterprise", "ventures", "solutions", "industries", "corporation", "co"]
    static let joins: Set<String> = ["and", "&", "n", "of", "the"]

    static func clean(_ raw: String) -> String {
        var s: String = raw.replacingOccurrences(of: "_", with: " ").trimmingCharacters(in: .whitespacesAndNewlines)
        if s.isEmpty { return "Unnamed" }
        let low0: String = s.lowercased()
        for (k, v) in known where low0 == k || low0.hasPrefix(k + " ") { return v }
        // one word run together: cut at the first legal word inside it ("Ampletechnologiesp" → Ample)
        if !s.contains(" ") {
            let low: String = s.lowercased()
            for w in ["technologies", "designs", "private", "pvt", "india", "retail", "services", "solutions", "enterprises"] {
                if let r = low.range(of: w) {
                    let cut: Int = low.distance(from: low.startIndex, to: r.lowerBound)
                    if cut >= 3 { s = String(s.prefix(cut)); break }
                }
            }
        }
        var words: [String] = s.split(separator: " ").map(String.init)
        while words.count > 1 {
            let last: String = words[words.count - 1].lowercased().trimmingCharacters(in: CharacterSet(charactersIn: ".,"))
            let digits: Bool = !last.isEmpty && last.allSatisfy { $0.isNumber }
            let cutTail: Bool = last.count >= 2 && last.count <= 5 && tails.contains { $0.count > last.count && $0.hasPrefix(last) }
            if digits || tails.contains(last) || cutTail || joins.contains(last) { words.removeLast() } else { break }
        }
        let joined: String = words.joined(separator: " ")
        for (k, v) in known where joined.lowercased() == k { return v }
        if (joined == joined.uppercased() && joined.count > 4) || joined == joined.lowercased() {
            return words.map { (w: String) -> String in
                (w.count <= 3 && w == w.uppercased()) ? w : w.prefix(1).uppercased() + w.dropFirst().lowercased()
            }.joined(separator: " ")
        }
        return joined
    }
}
