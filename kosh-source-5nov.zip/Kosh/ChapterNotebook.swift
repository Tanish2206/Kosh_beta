import SwiftUI

// MARK: - Your chapters, as notebook pages
//
// The notebook Chapters opens on is filled with your own chapters: each trip or event with dates becomes a page,
// oldest first, then a blank one that's yours to start. A page says what the chapter cost and over how many
// payments, its three biggest categories (a category that's most of it is told by its parts, so a trip reads
// "Stays" and "Flights" rather than "Travel"), a headline made from those numbers and a margin note. The jokes are
// kept kind and the facts are all its own; "so far" while it's still being written.

extension Store {
    /// your own chapters as the notebook's pages, oldest first; empty until you have one
    func notebookPages() -> [NotebookChapter] {
        let items: [Chapter] = chapterItems(samples: false).sorted { a, b in
            a.from == b.from ? a.title < b.title : a.from < b.from
        }
        if items.isEmpty { return [] }
        // every counted payment, by the chapter it's in, in one pass
        var rows: [String: [Txn]] = [:]
        for t in tx where t.sp || t.ev == true {
            if let tr = t.tr, !tr.isEmpty { rows[tr, default: []].append(t) }
        }
        let today: String = snap.today
        return items.map { c in NotebookMaker.page(c, trip: trip(c.id), rows: rows[c.id] ?? [], today: today) }
    }

    /// the blank page after yours, in this year (or the last chapter's, if that's later)
    func notebookNext(after pages: [NotebookChapter]) -> NotebookChapter {
        let now: Int = Int(snap.today.prefix(4)) ?? 2026
        return NotebookChapter(id: NotebookMaker.nextID, year: max(now, pages.last?.year ?? now), title: "Your next chapter", when: "",
                               months: 0, pays: 0, amount: 0, ink: "#3B5BFD", wash: "#EEF2FF", rot: 2,
                               head: "Blank page, fresh chai. What’s it going to be?", isNext: true, sample: false)
    }
}

enum NotebookMaker {
    /// the blank page's id: no trip has one like it
    static let nextID: String = "kosh.notebook.next"

    /// a category, or a part of one, and what it came to
    struct Part {
        let name: String
        let v: Double
    }

    // MARK: a page

    static func page(_ c: Chapter, trip t: TripInfo?, rows: [Txn], today: String) -> NotebookChapter {
        let total: Double = t?.total ?? c.amount
        let n: Int = t?.n ?? rows.count
        let state: String = t?.state ?? (c.from > today ? "soon" : c.to < today ? "done" : "now")
        let journey: Bool = c.fam == .journey
        let rawTo: String = t?.to ?? c.to
        let days: Int = t?.days ?? c.days
        let seed: Int = Self.seed(c.id)

        let parts: [Part] = Self.parts(rows, fallback: t?.cats ?? [])
        let sum: Double = parts.reduce(0) { $0 + $1.v }
        var top: [(String, Int)] = []
        var amounts: [Double] = []
        if sum > 0 {
            var used: Int = 0
            for p in parts.prefix(3) {
                let share: Int = min(100 - used, Int(safe: (p.v / sum * 100).rounded()))
                if share <= 0 { break }
                used += share
                top.append((p.name, share))
                // what it came to, scaled to the chapter's own total so the parts add up to what the page says
                amounts.append((p.v / sum * total).rounded())
            }
        }

        var cap: String = "spent"
        if state == "now" { cap = "so far" } else if state == "soon" { cap = total > 0 ? "paid ahead" : "so far" }

        let scene: String = Self.scene(kind: c.kind, journey: journey, title: c.title)
        return NotebookChapter(
            id: c.id,
            year: Int(c.from.prefix(4)) ?? Int(today.prefix(4)) ?? 2026,
            title: c.title,
            when: Self.when(c.from, rawTo, state: state, today: today),
            months: Self.months(c.from, c.to),
            pays: n,
            amount: total,
            cap: cap,
            ink: InkMath.deeper(c.ink, 0.22),
            wash: InkMath.paler(c.ink, 0.88),
            rot: Self.rot(seed),
            head: Self.headline(total: total, n: n, parts: parts, state: state, days: days, journey: journey, seed: seed),
            note: Self.note(total: total, parts: parts, state: state, trip: t, journey: journey, seed: seed),
            top: top,
            from: c.from,
            span: Self.span(days: days, from: c.from, to: rawTo, state: state),
            scene: scene,
            tint: NotebookScenes.tint(scene, ink: c.ink),
            sample: false,
            chapterID: c.id,
            topAmounts: amounts)
    }

    /// "12 – 18 Mar", "since 2 Oct" while it runs with no end set, the year added when it isn't this one
    static func when(_ from: String, _ to: String, state: String, today: String) -> String {
        if to.isEmpty {
            let year: String = from.prefix(4) == today.prefix(4) ? "" : " " + String(from.prefix(4))
            return (state == "now" ? "since " : "") + Day.fmt(from, "d MMM") + year
        }
        return TripWhen.range(from, to, today: today)
    }

    /// how long it ran: days for anything up to two months, then months
    static func span(days: Int, from: String, to: String, state: String) -> String {
        if days > 61 {
            let m: Int = max(2, Int((Double(days) / 30.4).rounded()))
            return String(m) + " months"
        }
        if days > 0 { return TripWhen.days(days) }
        return state == "soon" ? "still to come" : "one day"
    }

    /// the calendar months it touches, first to last
    static func months(_ from: String, _ to: String) -> Int {
        let a: Int = (Int(from.prefix(4)) ?? 0) * 12 + (Int(from.dropFirst(5).prefix(2)) ?? 1)
        let b: Int = (Int(to.prefix(4)) ?? 0) * 12 + (Int(to.dropFirst(5).prefix(2)) ?? 1)
        return max(1, b - a + 1)
    }

    // MARK: its categories

    /// what it went on, biggest first: by category, except a category that's 40% or more of it and has parts of
    /// its own, which is told by its parts (Travel becomes Flights, Stays). With no payments to hand, the totals
    /// kosh keeps for it.
    static func parts(_ rows: [Txn], fallback: [TripInfo.Cat]) -> [Part] {
        var byCat: [String: Double] = [:]
        var bySub: [String: [String: Double]] = [:]
        var total: Double = 0
        for r in rows where r.a > 0 {
            let cat: String = r.c.isEmpty ? "Other" : r.c
            byCat[cat, default: 0] += r.a
            if !r.s.isEmpty { bySub[cat, default: [:]][r.s, default: 0] += r.a }
            total += r.a
        }
        if total <= 0 {
            return fallback.filter { $0.v > 0 }.sorted { $0.v > $1.v }.map { Part(name: $0.cat, v: $0.v) }
        }
        var named: [String: Double] = [:]
        for (cat, v) in byCat {
            let subs: [String: Double] = bySub[cat] ?? [:]
            if v / total >= 0.4 && subs.count >= 2 {
                var rest: Double = v
                for (sub, sv) in subs {
                    named[sub, default: 0] += sv
                    rest -= sv
                }
                if rest >= 1 { named[cat, default: 0] += rest }
            } else {
                named[cat, default: 0] += v
            }
        }
        return named.map { Part(name: $0.key, v: $0.value) }.sorted { a, b in a.v == b.v ? a.name < b.name : a.v > b.v }
    }

    // MARK: what the page says

    /// the line under the title: "₹1.2L across 46 payments, mostly Stays."
    static func headline(total: Double, n: Int, parts: [Part], state: String, days: Int, journey: Bool, seed: Int) -> String {
        if total <= 0 {
            return state == "soon" ? "Nothing paid yet. All of it still ahead." : "Nothing in it yet. Plenty of page left."
        }
        let amt: String = Fmt.short(total)
        let pays: String = n == 1 ? "1 payment" : "\(n) payments"
        let sum: Double = parts.reduce(0) { $0 + $1.v }
        guard let first = parts.first, sum > 0 else {
            return state == "now" ? "\(amt) so far, across \(pays)." : "\(amt) across \(pays)."
        }
        let share: Double = first.v / sum
        if state == "soon" { return "\(amt) paid ahead, mostly \(first.name). The rest is still to come." }
        if n == 1 { return "\(amt) in one go, on \(first.name)." }

        // "mostly Stays"; "mostly Stays and Flights" when two run close; "led by Stays" when it's spread wider
        var lead: String = "mostly " + first.name
        if share < 0.5 && parts.count > 1 {
            let second: Part = parts[1]
            lead = second.v / sum >= share - 0.12 ? "mostly \(first.name) and \(second.name)" : "led by \(first.name)"
        }
        // a trip that's over can be told by the day, now and then
        if journey && state == "done" && days > 1 && days <= 60 && seed % 2 == 1 {
            return "\(Fmt.short(total / Double(days))) a day for \(days) days, \(lead)."
        }
        let so: String = state == "now" ? " so far" : ""
        return "\(amt)\(so) across \(pays), \(lead)."
    }

    /// kosh's note in the margin: its biggest category's share, then one more true thing, or a kind joke
    static func note(total: Double, parts: [Part], state: String, trip t: TripInfo?, journey: Bool, seed: Int) -> String {
        let sum: Double = parts.reduce(0) { $0 + $1.v }
        guard total > 0, let first = parts.first, sum > 0 else {
            if state == "soon" { return journey ? "Nothing in it yet. What you spend there goes in on its own." : "Nothing in it yet. Put payments in it from Transactions." }
            return "A quiet chapter so far. kosh is keeping an eye out."
        }
        let p: Int = Int(safe: (first.v / sum * 100).rounded())
        let now: Bool = state == "now"
        let verb: String = plural(first.name) ? (now ? "are" : "were") : (now ? "is" : "was")
        var opener: String = "\(first.name) \(verb) \(p)% of it\(now ? " so far" : "")."
        if p >= 98 { opener = "It was all \(first.name)\(now ? ", so far" : "")." }
        let fact: String? = Self.fact(total: total, state: state, trip: t, journey: journey, seed: seed)
        return opener + " " + (fact ?? quip(first.name))
    }

    /// one more thing that's true of it, if there's one worth saying: the budget, money on its way back, what was
    /// paid before it began, its biggest day
    static func fact(total: Double, state: String, trip t: TripInfo?, journey: Bool, seed: Int) -> String? {
        guard let t else { return nil }
        if t.budget > 0 && state != "soon" {
            let over: Double = total - t.budget
            if over >= 500 { return "It ran \(Fmt.short(over)) over budget. Good chapters often do." }
            if over <= -500 && state == "done" { return "\(Fmt.short(-over)) under budget. Quietly impressive." }
        }
        if t.rx > 0 { return "\(Fmt.short(t.rx)) of it is still on its way back." }
        // the rest only now and then, so the jokes get a turn
        if seed % 3 == 0 { return nil }
        if journey && t.before > 0 && t.before < total {
            let q: Int = Int(safe: (t.before / total * 100).rounded())
            if q >= 10 { return "\(q)% was paid before it even began." }
        }
        if state == "done" && t.byDay.count > 2, let big = t.byDay.max(by: { $0.v < $1.v }), big.v > 0 {
            return "The big day was \(Day.fmt(big.d, "EEE d MMM")), at \(Fmt.short(big.v))."
        }
        return nil
    }

    /// a light word on what most of it went on
    static func quip(_ name: String) -> String {
        let words: [String] = name.lowercased().split { !$0.isLetter }.map(String.init)
        func has(_ keys: [String]) -> Bool { words.contains { w in keys.contains { w.hasPrefix($0) } } }
        if has(["flight", "train", "bus", "cab", "fuel", "transport", "travel", "toll", "metro", "auto", "car"]) { return "Getting there is half the story." }
        if has(["stay", "hotel", "rent", "holiday"]) { return "Good sleep is never cheap." }
        if has(["food", "restaurant", "delivery", "snack", "sweet", "bakery", "grocer", "tea", "coffee", "street", "bar"]) { return "Worth every bite, we assume." }
        if has(["shopping", "cloth", "jewel", "electronic", "footwear", "beauty", "online", "outfit"]) { return "Souvenirs count as memories." }
        if has(["gift", "shagun", "donation", "temple", "charity"]) { return "Generosity, itemised." }
        if has(["home", "furniture", "decor", "repair", "interior", "maintenance", "appliance"]) { return "It all lives in the walls now." }
        if has(["medical", "doctor", "hospital", "pharmacy", "tests", "dental", "health"]) { return "Here’s to good health from here." }
        if has(["education", "fees", "course", "books", "exam", "school", "coaching"]) { return "An investment, technically." }
        if has(["entertainment", "movie", "events", "concert", "tours", "activities", "outing"]) { return "Fun is a line item too." }
        return "The rest was snacks, probably."
    }

    /// "Flights were", "Shopping was"
    static func plural(_ name: String) -> Bool {
        if name.contains("&") { return true }
        let last: String = name.lowercased().split(separator: " ").last.map(String.init) ?? ""
        if ["miscellaneous", "news", "gas", "fitness", "business", "bus", "tax", "insurance"].contains(last) { return false }
        return last.hasSuffix("s") && !last.hasSuffix("ss")
    }

    // MARK: its photo

    /// The drawing on a chapter's photo: every trip gets the travel scene; an event its kind's (a wedding, a
    /// festival or a party the mandap; a move or a renovation the house; a baby the crib; studies the campus; a
    /// venture the studio; a new vehicle the car with a bow on it); one of your own kind is read by its name;
    /// anything else, the sun over the hills.
    static func scene(kind: String, journey: Bool, title: String) -> String {
        if journey { return "travel" }
        switch kind {
        case "wedding", "guest", "festival", "party", "ceremony": return "wedding"
        case "home", "move", "reno": return "home"
        case "baby": return "baby"
        case "study", "course": return "msc"
        case "venture": return "studio"
        case "vehicle": return "car"
        case "intl", "getaway", "road", "yatra", "work": return "travel"
        default: break
        }
        let words: [String] = title.lowercased().split { !$0.isLetter }.map(String.init)
        let by: [(String, [String])] = [
            ("travel", ["trip", "travel", "tour", "holiday", "vacation", "flight", "trek", "getaway"]),
            ("wedding", ["wedding", "shaadi", "sangeet", "mehendi", "engagement", "anniversary", "birthday", "party", "diwali", "holi", "eid", "christmas", "festival", "puja", "celebration"]),
            ("home", ["home", "house", "flat", "move", "moving", "shifting", "renovation", "interiors", "kitchen"]),
            ("baby", ["baby", "kids", "newborn"]),
            ("msc", ["course", "exam", "college", "degree", "study", "studies", "mba", "university"]),
            ("studio", ["office", "studio", "startup", "business", "venture"]),
            ("car", ["car", "bike", "scooter", "suv", "motorcycle", "vehicle"])
        ]
        for (key, keys) in by where words.contains(where: { keys.contains($0) }) {
            return key
        }
        return "hills"
    }

    // MARK: a little variety, the same every time

    static func seed(_ id: String) -> Int {
        var h: UInt32 = 2166136261
        for u in id.unicodeScalars { h = (h ^ u.value) &* 16777619 }
        return Int(h % 1000)
    }

    /// how the photo is taped on: a little crooked, never quite the same as its neighbour
    static func rot(_ seed: Int) -> Double {
        let turns: [Double] = [-5, 4, -3, 5, -4, 3, -6, 2]
        return turns[seed % turns.count]
    }
}
