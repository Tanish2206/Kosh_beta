import Foundation
import Observation
import UIKit
import Network

// MARK: - LiveSession: reading again when the rules change: the plan, the re-read, cut mail fetched whole
// (split out of LiveSession+Reading.swift, 30 Oct 2026; its stored state stays in the class in LiveSession.swift)

extension LiveSession {
    /// When the code that reads mail changes, every reading it made before is read again, by itself:
    /// each reading remembers the fingerprint of the code that read it (Reading.rp, ReadingPrint.mail, worked out
    /// from the app's own scripts when it starts), and one read by other code is read again from this phone's sealed
    /// copy (MailVault: no inbox call), newest first, in the background, a few at a time, carrying on after a relaunch
    /// (the "reingest" plan). Nothing is bumped by hand for it.
    /// Mail read before kosh sealed mail has no sealed copy: it is fetched from the inbox again (and sealed then), so every
    /// fix reaches the whole year. rulesVersion still names what an older version must read again. A statement already
    /// opened stays opened.
    /// 30: a free trial's reminder says it's a trial (plan.js's heads-up), and every bank's alerts as the catalogue reads them
    /// 31: whom bank, card and wallet mail is written to (whose the account is), and a debit card's account
    /// 32: a name printed as a worked example (a password hint), in a nominee's or manager's section, or only in a
    ///     holder field is no one to give the account to
    /// 33: a contract note's table gives every trade, a registrar's NPS mail is the pension's (one contribution one
    ///     buy), a quick-commerce invoice is the order; a holdings or contract-note statement sent as a spreadsheet is
    ///     read for investment senders (engine/08 docWanted). Round two (27 Oct) rides the same, still unreleased, 33 so a
    ///     phone re-reads once for both: mail in an Indian script, a statement sent as a zip picked like a PDF, and the
    ///     senders never tuned to (a table's Credit/Debit, a deposit's maturity money, a broker's funds added, an EPF
    ///     contribution, a depository's debit, an insurer by its name). Round three (27 Oct) rides it as well: a parcel's
    ///     steps read from a shop's or a courier's mail (reader.js parcels, beside the money, never in it), a time no
    ///     longer read as a two-figure year, order numbers the shop's name stands before. Every one is a read-part
    ///     change, so the reading fingerprint re-reads every mail, sealed or fetched again; no scope below needs
    ///     widening for them.
    static let rulesVersion = 35

    /// mail read by older code or older rules, waiting to be read again (reingestIfRulesChanged)
    var rulesChanged: Bool {
        guard signedIn, !records.isEmpty else { return false }
        return ud.integer(forKey: "beta.rules") < Self.rulesVersion || ud.string(forKey: "beta.readPrint") != ReadingPrint.mail
    }

    /// The mail to read again, newest first: every reading made by other code that has a sealed copy, and, without a
    /// sealed copy, only what the per-version scopes name (or a cut-short plan already held). Worked out off the main
    /// thread (a file check per mail).
    @MainActor

    func rereadPlan(since was: Int, carry: [String]) async -> [String] {
        let want: String = ReadingPrint.mail
        let rows: [(String, String?, String)] = records.map { ($0.id, $0.rp, $0.sent ?? $0.date ?? "") }
        let scoped: Set<String> = was < Self.rulesVersion ? Set(toReread(since: was).map { records[$0].id }) : []
        let carried: Set<String> = Set(carry)
        return await Task.detached(priority: .utility) { () -> [String] in
            var picked: [(String, String)] = []
            var seen = Set<String>()
            // (an SMS or a notification has no inbox to fetch it from: it is read again by its own fingerprint, takeAlerts)
            for (id, rp, sent) in rows where !id.hasPrefix(AlertIntake.prefix) && seen.insert(id).inserted {
                // every reading made by other code is read again: from its sealed copy, or (mail read before kosh sealed
                // mail) fetched from the inbox once more and sealed then, so a reader's fix reaches the whole year, not
                // only the mail that came after it
                if rp != want || scoped.contains(id) || carried.contains(id) { picked.append((id, sent)) }
            }
            picked.sort { $0.1 > $1.1 }
            return picked.map { $0.0 }
        }.value
    }

    /// a reading made again that says what the kept one said: the same everywhere but what only says when and how it was
    /// read (the code's fingerprint, the check's state, the mail's own text and Claude's answer kept beside it)
    nonisolated static func sameReading(_ fresh: Reading, _ kept: Reading) -> Bool {
        var a = fresh
        a.rp = kept.rp; a.check = kept.check; a.text = kept.text; a.html = kept.html
        a.cl = kept.cl; a.clv = kept.clv; a.claude = kept.claude; a.use = kept.use
        return a == kept
    }

    @MainActor

    func reingestIfRulesChanged() async {
        let was = ud.integer(forKey: "beta.rules")
        let want: String = ReadingPrint.mail
        let printChanged: Bool = ud.string(forKey: "beta.readPrint") != want
        guard signedIn, !running, !reingesting, was < Self.rulesVersion || printChanged || plan("reingest") != nil else {
            if signedIn && (was < Self.rulesVersion || printChanged) { note("reingest: waits (" + (running ? "a scan is running" : reingesting ? "already under way" : "?") + ")") }
            return
        }
        note("reingest: starting")
        reingesting = true
        defer { reingesting = false }
        var ids: [String]
        if let p = plan("reingest"), let left = p.ids, ud.string(forKey: "beta.readPrintPlan") == want {
            // cut short last time: on from the same email
            ids = left
            againDone = p.done
            againTotal = p.total
            pickUp("reingest")
        } else {
            // a new plan (the code changed again while one was under way: what that plan had left is folded in)
            let carry: [String] = plan("reingest")?.ids ?? []
            ids = await rereadPlan(since: was, carry: carry)
            againDone = 0
            againTotal = ids.count
            ud.set(want, forKey: "beta.readPrintPlan")
            if !ids.isEmpty {
                plans["reingest"] = ReadingPlan(job: "reingest", accounts: allAccounts, ids: ids, total: ids.count)
                writePlans()
            } else {
                plans["reingest"] = nil
            }
        }
        note("reingest: \(ids.count) to read again")
        // (reading the sealed copies again is kosh's own business: the "caught up" note is for mail fetched again)
        if !ids.isEmpty && was < Self.rulesVersion { stretchSeen = true }
        var at: [String: Int] = [:]
        for i in records.indices where at[records[i].id] == nil { at[records[i].id] = i }
        var fetchedAgain = 0
        /* the readings made again, put into the records a batch at a time: each write to the records redraws whatever
           shows them, and one a mail (a dozen a second) made the screens stutter while kosh read */
        var made: [String: Reading] = [:]
        /* the smart re-read: most mail reads the same under new code. A reading that comes out the same as the one kept
           never touches the records (no redraw, no build): only its fingerprint is noted, and set on every one of them
           in one write at the end. Only readings that changed go into the records, a batch at a time, and only they
           ask for a build. A re-read cut short carries on from its plan, so nothing is read twice */
        var same: [String] = []
        var changedSinceBuild = 0, changedTotal = 0
        var lastFlush = Date()
        func settleSame() {
            guard !same.isEmpty else { return }
            let ids = Set(same)
            same = []
            Perf.shared.measure("reread settle") {
                // (straight to each record by the index map, not a walk of every record: the same answer, a hundredth of the time)
                var next = records
                for id in ids { if let j = indexIn(next, id) { next[j].rp = want } }
                records = next
            }
        }
        func flush() {
            lastFlush = Date()
            guard !made.isEmpty else { return }
            Perf.shared.measure("reread flush") { flushNow() }
            let shown: CFAbsoluteTime = CFAbsoluteTimeGetCurrent()
            DispatchQueue.main.async { Perf.shared.record("screens redrawn after a flush", ms: (CFAbsoluteTimeGetCurrent() - shown) * 1000) }
        }
        /// the record for an id in this copy of the records: the index map built above first, a search only if the
        /// records moved under it (a row added or removed meanwhile)
        func indexIn(_ list: [Reading], _ id: String) -> Int? {
            if let h = at[id], h < list.count, list[h].id == id { return h }
            let j = list.firstIndex { $0.id == id }
            if let j { at[id] = j }
            return j
        }
        func flushNow() {
            var next = records
            for (id, r) in made { if let j = indexIn(next, id) { next[j] = r } }
            records = next
            made = [:]
        }
        // a few at a time, read side by side (Readers: each sender's mail on its own reader), newest first
        // (eight a reader: each sender's mail goes to one reader, so a bigger batch keeps all of them busy, not waiting on one)
        let batchSize: Int = Readers.count * 8
        while !ids.isEmpty {
            if halted { flush(); settleSame(); cutShort("reingest"); return }
            // (your hands first: the re-read holds while you touch the screen, Interaction.swift)
            if Interaction.shared.busy { flush(); await Interaction.yield() }
            let batch: [String] = Array(ids.prefix(batchSize))
            // each mail's sealed copy (or the inbox's, fetched again and sealed): what to read, in the batch's order
            var todo: [(rec: Reading, msg: MailMsg, acct: String, tag: String)] = []
            var taken: Int = 0
            var offline = false
            // (the batch's sealed copies opened together, off the main thread: one hop, not one per mail)
            let sealed: [String: MailMsg] = await Task.detached(priority: .utility) { () -> [String: MailMsg] in
                var out: [String: MailMsg] = [:]
                for id in batch { if let m = MailVault.get(id) { out[id] = m } }
                return out
            }.value
            for id in batch {
                // (a sealed copy is read again without the internet; only mail fetched from the inbox waits for it)
                if !Net.shared.online && !MailVault.has(id) { offline = true; break }
                taken += 1
                guard let i = recordIndex(id, hint: at[id]) else { continue }
                let r = records[i]
                let acct = (r.acct ?? "").isEmpty ? email : (r.acct ?? email)
                // the tag the record was stored under (an older one, if its inbox was shifted before tags lasted)
                let tag: String = acct == email ? "" : (Self.inboxPrefix(r.id) ?? inboxTag(acct))
                let msgId = tag.isEmpty || !r.id.hasPrefix(tag) ? r.id : String(r.id.dropFirst(tag.count))
                // the sealed copy opened off the main thread, so the screens stay smooth through thousands
                var got: MailMsg? = sealed[r.id]
                if got == nil {
                    var tries = 0
                    while got == nil {
                        do {
                            let fetched = try await fetchOne(msgId, acct: acct)
                            MailVault.put(fetched, id: r.id)
                            fetchedAgain += 1
                            got = fetched
                        } catch {
                            // without the internet it waits, then tries this one again; a passing failure gets a few more tries
                            if !Net.shared.online { offline = true; break }
                            if Self.transient(error) && tries < 3 { tries += 1; try? await Task.sleep(for: .seconds(Double(1 << tries))); continue }
                            let ns = error as NSError
                            note("reingest: a mail failed, " + ns.domain + " " + String(ns.code))
                            break
                        }
                    }
                    if offline { taken -= 1; break }
                }
                guard var m = got else { continue }
                // what Claude read of it is read again with it (asked again only when its rules change)
                if let cl = r.cl, r.clv == ClaudeReads.version { m.cl = cl }
                todo.append((r, m, acct, tag))
            }
            if offline && taken == 0 {
                guard await Net.shared.waitOnline() else { flush(); settleSame(); cutShort("reingest"); return }
                continue
            }
            // (below the screens' priority: the one-time re-read never makes taps wait)
            let me = email, mode = checkMode
            let jobs = todo
            let readOff: [Reading?] = await Task.detached(priority: .utility) { () -> [Reading?] in
                let box = ReadingsBox(jobs.count)
                var byReader: [[Int]] = Array(repeating: [], count: Readers.count)
                for (j, x) in jobs.enumerated() { byReader[Readers.index(from: x.msg.from)].append(j) }
                let groups: [[Int]] = byReader
                DispatchQueue.concurrentPerform(iterations: Readers.count) { g in
                    box.put(groups[g].map { j in (j, LiveSession.readingOf(jobs[j].msg, acct: jobs[j].acct, tag: jobs[j].tag, me: me, checkMode: mode)) })
                }
                return box.all
            }.value
            for (j, x) in jobs.enumerated() {
                guard var fresh = readOff[j] else { continue }
                let r = x.rec
                // the record keeps its id: what you changed and the sealed copy are filed under it
                fresh.id = r.id
                // what Claude read, and which reading you chose, stay with the mail
                if fresh.claude == nil, let cl = r.claude { fresh.claude = cl; fresh.use = r.use }
                if let old = r.doc, let new = fresh.doc, old.att == new.att, old.kind == new.kind {
                    fresh.doc = old
                    // a shop's invoices are what made the order: read them again with the new rules
                    if old.kind == "order" { fresh.doc?.state = ""; fresh.doc?.more = new.more }
                }
                stretchRead += 1
                // the same reading as the one kept: nothing to show, only its fingerprint to note
                if Self.sameReading(fresh, r) { same.append(r.id); continue }
                // (into the records with the rest of its batch)
                made[r.id] = fresh
                changedSinceBuild += 1; changedTotal += 1
            }
            ids.removeFirst(taken)
            againDone += taken
            plans["reingest"]?.ids = ids
            plans["reingest"]?.done = againDone
            // (what changed reaches the records in larger batches, at most every 20 seconds: each write redraws what shows them)
            if made.count >= 150 || (!made.isEmpty && Date().timeIntervalSince(lastFlush) >= 20) { flush() }
            checkpoint(taken)
            // from the inbox, a breath now and then; from the sealed copy, a moment every batch so the screens stay
            // smooth (reading every sealed mail again can be thousands)
            if fetchedAgain >= 10 { fetchedAgain = 0; try? await Task.sleep(for: .seconds(0.5)) }
            else { try? await Task.sleep(for: .milliseconds(8)) }
            // a long re-read shows its progress on the screens now and then, not only at the end
            // (a build only when a reading changed: the same readings lay out the same screens)
            if againDone / 300 != (againDone - taken) / 300 {
                if changedSinceBuild > 0 { flush(); rebuildSoon(); changedSinceBuild = 0 }
                note("reingest: \(againDone) of \(againTotal), \(changedTotal) changed")
            }
            if offline { guard await Net.shared.waitOnline() else { flush(); settleSame(); cutShort("reingest"); return } }
        }
        flush()
        settleSame()
        note("reingest: done, \(changedTotal) of \(againTotal) read differently")
        ud.set(Self.rulesVersion, forKey: "beta.rules")
        ud.set(want, forKey: "beta.readPrint")
        plans["reingest"] = nil
        save(); writePlans()
        if changedTotal > 0 || changedSinceBuild > 0 { rebuildSoon() }
    }

    /// Big emails kept before kosh trimmed their styling (MailMsg.compactHTML) were cut at 60,000 characters, some of
    /// them before the part that says how an order was paid (Nykaa's order mail: 157,000 characters, its "Wallet
    /// ₹1,410" at 88,000). Each sealed copy cut at the limit is fetched once more from its inbox (read-only), kept
    /// trimmed and read again, once; what it found goes to the diagnostics (beta.cutFound, beta.cutFixed).
    @MainActor
    func refetchCutMail() async {
        guard signedIn, ud.integer(forKey: "beta.cutFix") < 1, !running, !reingesting else { return }
        let rows: [(String, String)] = records.filter { !$0.id.hasPrefix(AlertIntake.prefix) }.map { ($0.id, $0.acct ?? "") }
        let cut: [(String, String)] = await Task.detached(priority: .utility) { () -> [(String, String)] in
            rows.filter { (MailVault.get($0.0)?.html.count ?? 0) >= MailMsg.htmlLimit }
        }.value
        ud.set(cut.count, forKey: "beta.cutFound")
        note("cut mail: \(cut.count) found")
        var fresh: [String: Reading] = [:]
        for (rid, acctRaw) in cut {
            // (cut short: tried again next time, the flag not set)
            if halted { break }
            let acct: String = acctRaw.isEmpty ? email : acctRaw
            let tag: String = acct == email ? "" : (Self.inboxPrefix(rid) ?? inboxTag(acct))
            let msgId: String = tag.isEmpty || !rid.hasPrefix(tag) ? rid : String(rid.dropFirst(tag.count))
            guard let m = try? await fetchOne(msgId, acct: acct) else { continue }
            MailVault.put(m, id: rid)
            let me = email, mode = checkMode
            let readOff: Reading? = await Task.detached(priority: .utility) { LiveSession.readingOf(m, acct: acct, tag: tag, me: me, checkMode: mode) }.value
            if var r = readOff { r.id = rid; fresh[rid] = r }
            try? await Task.sleep(for: .milliseconds(150))
        }
        // one write for all of them: the screens redraw once
        if !fresh.isEmpty {
            var next = records
            for i in next.indices {
                guard var r = fresh[next[i].id] else { continue }
                let old = next[i]
                if r.claude == nil, let cl = old.claude { r.claude = cl; r.use = old.use }
                if let o = old.doc, let n = r.doc, o.att == n.att, o.kind == n.kind { r.doc = o }
                next[i] = r
            }
            records = next
            save(); rebuildSoon()
        }
        ud.set(fresh.count, forKey: "beta.cutFixed")
        if !halted { ud.set(1, forKey: "beta.cutFix") }
        note("cut mail: \(fresh.count) read whole")
    }

    /// where a record is now: at the index it was at if it's still there, else found again
    func recordIndex(_ id: String, hint: Int?) -> Int? {
        if let h = hint, h < records.count, records[h].id == id { return h }
        return records.firstIndex { $0.id == id }
    }

    /// the records whose mail the changed rules should read again (indices, in order)
    func toReread(since was: Int) -> [Int] {
        var idx: [Int] = []
        if was < 3 {
            idx += records.indices.filter { i in
                let r = records[i]
                return r.kind == "policy" || r.instKind == "insurer" || r.doc?.kind == "policy" || r.claude?.r.kind == "policy"
            }
            // each bank account's two latest alerts, and balance mails: they carry the balance
            var latest: [String: [Int]] = [:]
            for i in records.indices {
                let r = records[i]
                guard r.instKind == "bank", r.bal == nil,
                      (r.kind == "txn" && r.instr == "account") || (r.subject ?? "").range(of: "balance", options: .caseInsensitive) != nil else { continue }
                latest[(r.inst ?? "") + "|" + (r.last4 ?? ""), default: []].append(i)
            }
            for (_, list) in latest {
                idx += list.sorted { (records[$0].date ?? records[$0].sent ?? "") > (records[$1].date ?? records[$1].sent ?? "") }.prefix(2)
            }
        }
        if was < 4 {
            // a bank's notes about fixed deposits, and each card's two latest mails (they name the card)
            idx += records.indices.filter { i in
                let r = records[i]
                let hay = (r.subject ?? "") + " " + (r.party ?? "") + " " + (r.info ?? "")
                return r.instKind == "bank" && hay.range(of: #"(?i)deposit|\bfd\b|\btd\b|premat"#, options: .regularExpression) != nil
            }
            var cards: [String: [Int]] = [:]
            for i in records.indices where records[i].instr == "card" || records[i].kind == "statement" {
                cards[(records[i].inst ?? "") + "|" + (records[i].last4 ?? ""), default: []].append(i)
            }
            for (_, list) in cards {
                idx += list.sorted { (records[$0].date ?? records[$0].sent ?? "") > (records[$1].date ?? records[$1].sent ?? "") }.prefix(2)
            }
        }
        if was < 9 {
            // shops' receipts and wallets' own mail read before kosh knew them (since 8 with their order numbers,
            // since 9 with the invoices of an order mail that has no amount in it): Zomato, Swiggy, Blinkit, Zepto,
            // Amazon Pay, Paytm, MobiKwik... read again so payments from their balances count
            let doms = (try? JSONText.decode([String].self, try Engine.shared.call("walletSendersJSON", []))) ?? []
            idx += records.indices.filter { i in
                let from = (records[i].from ?? "").lowercased()
                return records[i].instKind == "wallet" || doms.contains { from.contains("@" + $0) || from.contains("." + $0) }
            }
        }
        if was < 10 {
            // the rules learned to read any bank's or card's layout, cards known only from statements, bills and
            // payments, and the mail of payment apps and aggregators (CRED, Razorpay...): every statement, every
            // card's credit, and the unread or set-aside mail of apps, gateways and wallets, read again
            idx += records.indices.filter { i in
                let r = records[i]
                if r.kind == "statement" || (r.instr == "card" && r.dir == "in") { return true }
                let k = r.instKind ?? ""
                return (k == "app" || k == "gateway" || k == "wallet" || k == "lender") && (r.kind == "unknown" || r.kind == "noise")
            }
        }
        if was < 11 {
            // the card guardrails: a debit card's mail (it belongs to the account), every card statement (its file
            // name ends with the card's digits), and a card mail that named the card (the name has to be its bank's)
            idx += records.indices.filter { i in
                let r = records[i]
                guard r.instr == "card" || r.kind == "statement" else { return false }
                let hay = (r.subject ?? "") + " " + (r.info ?? "")
                return r.kind == "statement" || r.rule == "statement-unread" || r.kind == "unknown" || r.cardName != nil
                    || hay.range(of: "debit card", options: .caseInsensitive) != nil
            }
        }
        if was < 12 {
            // the papers beyond statements (payslips, Form 16, interest certificates, deposit advices, loan and NPS
            // statements, contract notes): mail already read whose PDF kosh didn't open before
            let papers = #"(?i)pay ?slip|salary slip|form[\s-]?16|certificate|fixed deposit|term deposit|deposit (?:advice|receipt|confirmation)|renewal advice|loan (?:account )?statement|repayment schedule|amorti[sz]|\bnps\b|\bpran\b|capital gain|tax p ?& ?l|contract note"#
            idx += records.indices.filter { i in
                let r = records[i]
                return r.doc == nil && (r.subject ?? "").range(of: papers, options: .regularExpression) != nil
            }
        }
        if was < 13 {
            // the reader (reader.js) reads every mail beside the rules and its events make the money threads: all the
            // mail kept sealed on this phone is read again (no inbox call); mail only in the inbox keeps its reading
            idx += records.indices.filter { MailVault.has(records[$0].id) }
        }
        if was < 17 {
            // 14: the reader learns each sender's templates as it reads (layouts.json); 15: every reading carries how sure
            // it is, and unsure money waits for a teacher; 16: money sent into a deposit ("TRF TO FD", an RD's
            // instalment) books it; 17: what the wild sweep found isn't money (a hotel's "Rd", a verification call, a
            // complaint, an insurer's notices) no longer reads as money. All the sealed mail is read again for each.
            idx += records.indices.filter { MailVault.has(records[$0].id) }
        }
        if was < 19 {
            // 19: one reader for a mail's HTML, the rules' and the reader's alike (a figure split over tags is one
            // figure, a label row keeps its column, a hidden preheader is left out), and a bank's statement printed
            // in the mail itself is opened like a PDF: the sealed mail is read again
            idx += records.indices.filter { MailVault.has(records[$0].id) }
        }
        if was < 20 && was >= 19 {
            // 20: a mail's day is India's (a mail at 2 a.m. was filed the day before), two payments of one amount on one
            // day stay two, and a charge in dollars keeps its currency: the sealed mail is read again (Claude's reading
            // goes with it, so Claude isn't asked again)
            idx += records.indices.filter { MailVault.has(records[$0].id) }
        }
        if was < 24 {
            // 24: a travel site's mail is read for a claim (its PDFs, the trip's kind, booking id, from and to, the
            // day): the cab, airline, rail, bus, hotel and booking sites' sealed mail is read again
            let doms: [String] = (try? JSONText.decode([String].self, try Engine.shared.call("travelDomainsJSON", []))) ?? []
            idx += records.indices.filter { i in
                let f = SenderPasswords.domain(records[i].from ?? "")
                return !f.isEmpty && doms.contains { f == $0 || f.hasSuffix("." + $0) } && MailVault.has(records[i].id)
            }
        }
        if was < 25 {
            // 25: a bank's daily balance mail is a note of the account's balance day to day, which places what left
            // it through an app (CRED) with no alert of its own: those mails are read again
            idx += records.indices.filter { i in
                let r = records[i]
                return r.instKind == "bank" && (r.subject ?? "").range(of: "balance", options: .caseInsensitive) != nil && MailVault.has(r.id)
            }
        }
        if was < 26 {
            // 26: the phone keeps what the engine reads of gift cards (each card, bought or from points, and where it was
            // bought), a policy's sum insured and a debit card's own digits; before, the phone dropped them when saving:
            // voucher stores', insurers' and debit cards' sealed mail is read again
            idx += records.indices.filter { i in
                let r = records[i]
                let k: String = r.instKind ?? ""
                let gift: Bool = k == "voucher" || r.kind == "voucher"
                let policy: Bool = r.kind == "policy" || k == "insurer"
                let debit: Bool = r.debit ?? false
                return (gift || policy || debit) && MailVault.has(r.id)
            }
        }
        if was < 27 {
            // 27: holdings are carried on from their statement by the trades and allotments mailed since, and a fund
            // house's allotment told as a sentence is read: registrars', fund houses' and brokers' sealed mail is read again
            idx += records.indices.filter { i in
                let r = records[i]
                let k: String = r.instKind ?? ""
                let house: Bool = k == "rta" || k == "broker" || k == "amc" || k == "exchange"
                let said: Bool = (r.subject ?? "").range(of: #"(?i)purchase|allot|units|redemption|\bsip\b|demat|contract note|transaction confirmation"#, options: .regularExpression) != nil
                return (house || said) && MailVault.has(r.id)
            }
        }
        if was < 28 {
            // 28: an insurer's mail says more of the policy (its product code, start, terms, fund value, bonus, a lapse
            // or maturity), and a bonus letter or annual statement is read: insurers' sealed mail is read again
            idx += records.indices.filter { i in
                let r = records[i]
                return (r.kind == "policy" || (r.instKind ?? "") == "insurer") && MailVault.has(r.id)
            }
        }
        if was < 29 {
            // 29: a policy told in a table ("PRODUCT | POLICY NUMBER") is read, so a health policy's welcome mail makes
            // the policy; banks' and cards' mail that isn't a plain payment (a cheque in clearing, a debit returned
            // unpaid, an overdue bill, an EMI conversion, a late fee, a balance, an e-statement) is read for what it is
            idx += records.indices.filter { i in
                let r = records[i]
                let k: String = r.instKind ?? ""
                return (r.kind == "policy" || k == "insurer" || k == "bank" || k == "card") && MailVault.has(r.id)
            }
        }
        if was < 32 {
            // 31, 32: whom a bank's, card's or wallet's mail is written to ("Dear Mr Rohan Example") says whose the account
            // is, and a debit card's mail that prints its account links the two: their sealed mail is read again
            idx += records.indices.filter { i in
                let r = records[i]
                let k: String = r.instKind ?? ""
                return (k == "bank" || k == "card" || k == "wallet" || r.instr == "account") && r.kind != "unknown" && MailVault.has(r.id)
            }
        }
        if was < 33 {
            // 33: a contract note's table gives every trade (not just the first), a CRA's NPS mail is the pension's and a
            // quick-commerce invoice is the order; and a holdings or contract-note statement sent as a spreadsheet is
            // picked for investment senders. The investment, pension and shop senders' sealed mail is read again (the
            // read-part fingerprint already re-reads all of it; this names the same mail for any without a sealed copy),
            // and mail from an investment sender with no paper yet is re-checked for a spreadsheet attachment.
            idx += records.indices.filter { i in
                let r = records[i]
                let k: String = r.instKind ?? ""
                let investish: Bool = k == "broker" || k == "rta" || k == "amc" || k == "depository" || k == "pension" || k == "exchange"
                let shoppish: Bool = k == "merchant"
                return (investish || shoppish || (investish && r.doc == nil)) && MailVault.has(r.id)
            }
        }
        if was < 35 {
            let paperish = #"(?i)polic(?:y|ies)|insurance|invoice|receipt|statement|certificate|schedule"#
            idx += records.indices.filter { i in
                let r = records[i]
                return r.doc == nil && (r.subject ?? "").range(of: paperish, options: .regularExpression) != nil
            }
        }
        if was < 34 {
            idx += records.indices.filter { i in
                let r = records[i]
                return r.doc == nil && (r.kind == "policy" || (r.instKind ?? "") == "insurer")
            }
        }
        do {
            // every time the rules learn a new way of writing an alert: the bank and card mail they
            // couldn't read before, newest first (a card's "was used for a transaction of", a deposit's closure)
            // what they couldn't read at all comes first, then alerts read without a payee, and only then
            // mail they set aside, so a bank's promotions don't use up the turn
            func newest(_ a: Int, _ b: Int) -> Bool { (records[a].sent ?? "") > (records[b].sent ?? "") }
            let bankish = records.indices.filter { records[$0].instKind == "bank" || records[$0].instKind == "card" }
            let unknown = bankish.filter { records[$0].kind == "unknown" }.sorted(by: newest)
            let bare = bankish.filter { let r = records[$0]; return r.kind == "txn" && (r.party ?? "").isEmpty && (r.info ?? "").isEmpty }.sorted(by: newest)
            let setAside = bankish.filter { records[$0].kind == "noise" }.sorted(by: newest)
            idx += unknown.prefix(800)
            idx += bare.prefix(200)
            idx += setAside.prefix(max(0, 300 - min(300, unknown.count)))
        }
        return Array(Set(idx)).sorted()
    }
}
