import Foundation

// MARK: - Who paid, who owes whom: the arithmetic of a Chapter's split, and of a share after money came back
//
// A Chapter's split is read from what kosh already has: each payment's payer and whole cost, and the shares split off
// it under Owed to you (open, or paid back). Every rupee lands on someone: whoever paid a payment paid all of it, its
// shares are the others' parts of it, and whatever nobody else took is the payer's own. So the parts always come to the
// whole, and each person's figure (what they paid less their part) is exactly what moves to and from them.
//
// Money that comes back on a split payment splits the same way the payment did (engine 21b, shareNow): a share still
// open is owed at its figure now; one paid back at the old figure before the money came back leaves you owing them
// the difference, as a line of its own under You owe.
//
// Nothing here knows about screens (engine-test/splits.js compiles it with swiftc), so this is the one place these
// figures come from.

/// one person in a split: what they paid, and their part of the cost
struct SplitPerson: Identifiable, Hashable {
    /// the name, lowercased: one line a person, however many payments they're on
    let id: String
    let name: String
    /// how many people the line stands for: one, or a share split without names ("2 others")
    var seats: Int = 1
    var paid: Double = 0
    var share: Double = 0
}

/// money from one to another: still owed, or paid back already
struct SplitMove: Identifiable, Hashable {
    let from: String
    let to: String
    var amount: Double
    /// a group without names: each of them pays their part of it
    var seats: Int = 1
    var id: String { from + "→" + to }
    var each: Double { seats > 1 ? (amount / Double(seats)).rounded() : amount }
}

enum SplitBook {
    /// a figure to the paisa
    static func paisa(_ v: Double) -> Double { (v * 100).rounded() / 100 }

    /// a share split without names ("2 others") stands for that many people; any other name for one
    static func seats(_ name: String) -> Int {
        let bits = name.split(separator: " ")
        if bits.count == 2, bits[1] == "others", let n = Int(bits[0]), n > 1 { return n }
        return 1
    }

    // MARK: a share after money came back on its payment

    /// the line under You owe for a share paid back at its old figure: its own id, so it can be settled like any other
    static func backID(_ share: String) -> String { "back:" + share }

    /// a share once money came back on its payment (`now`, the engine's figure; nil when none came back): still open,
    /// it is owed at `now`; paid back and kosh saw what came in (`paid`), the share stays as paid and anything paid over
    /// `now` is owed back to them; marked paid by hand, it is taken as paid at `now` (kosh can't tell when you marked it)
    static func afterBack(amount: Double, now: Double?, settled: Bool, paid: Double?) -> (amount: Double, owedBack: Double) {
        guard let now else { return (amount, 0) }
        if !settled { return (paisa(max(0, now)), 0) }
        guard let paid else { return (paisa(max(0, now)), 0) }
        let over: Double = paisa(paid - now)
        return (amount, over > 0.5 ? over : 0)
    }

    /// part of a share came in, after money came back on its payment: what came in, in the share's old terms, so that
    /// once the money back is taken off again (in proportion) the part received is what came and the rest is what's left
    static func inOldTerms(_ got: Double, now: Double, was: Double) -> Double {
        guard now > 0, was > 0 else { return got }
        return paisa(got * was / now)
    }

    // MARK: a chapter's split

    /// a payment in a chapter: whose money paid it, what stayed theirs (`a`), what was split off it (`shared`), whether
    /// it counts, and its day
    struct Row: Hashable {
        var id: String
        var payer: String
        var a: Double
        var shared: Double = 0
        var counted: Bool = true
        var day: String = ""
    }

    /// a share split off a payment: owed to the payer by someone ("in"), or owed by the payer back to them ("out": their
    /// part of money that came back after they paid), open or settled
    struct Share: Hashable {
        var tx: String
        var name: String
        var amount: Double
        var dir: String = "in"
        var settled: Bool = false
    }

    /// what a chapter's split comes to
    struct Tally: Hashable {
        var total: Double = 0
        var payments: Int = 0
        /// everyone in it, in the order they first appear
        var people: [SplitPerson] = []
        var owes: [SplitMove] = []
        var back: [SplitMove] = []
        var days: [String] = []
        /// the people in it as it stands, a group counted as its seats
        var known: Int = 0
        var hasShares: Bool = false
        var even: Bool = false
        var seats: Int = 0
        var each: Double = 0
    }

    /// who paid what, each one's part, and what's still to move: as split (the shares as they stand), or evenly between
    /// `seats` people (never fewer than are in it already), the shares paid back counting as money that has moved
    static func tally(_ rows: [Row], _ shares: [Share], even: Bool, seats: Int) -> Tally {
        var s = Tally()
        var by: [String: SplitPerson] = [:]
        var order: [String] = []
        func person(_ name: String, _ n: Int) -> String {
            let key: String = name.lowercased()
            if by[key] == nil {
                by[key] = SplitPerson(id: key, name: name, seats: max(1, n))
                order.append(key)
            }
            return key
        }
        var sharesOf: [String: [Share]] = [:]
        for o in shares where o.amount > 0 && (o.dir == "in" || o.dir == "out") { sharesOf[o.tx, default: []].append(o) }
        var owing: [String: SplitMove] = [:]
        var paidBack: [String: SplitMove] = [:]
        var owingOrder: [String] = []
        var backOrder: [String] = []
        /// (the money paid back, between whom, for the even split)
        var moved: [(from: String, to: String, amount: Double)] = []
        for t in rows {
            if !t.counted && t.shared <= 0 { continue }
            let cost: Double = t.a + max(0, t.shared)
            if cost <= 0 { continue }
            let who: String = person(t.payer, 1)
            by[who]?.paid += cost
            by[who]?.share += t.a
            s.total += cost
            s.payments += 1
            s.days.append(t.day)
            for o in sharesOf[t.id] ?? [] {
                let name: String = o.name.isEmpty ? "Someone" : o.name
                let n: Int = SplitBook.seats(name)
                let k: String = person(name, n)
                let toThem: Bool = o.dir == "out"
                by[k]?.share += toThem ? -o.amount : o.amount
                if k == who { continue }
                // in: they owe the payer; out: the payer owes them
                let from: String = toThem ? who : k
                let to: String = toThem ? k : who
                let key: String = from + "\u{1F}" + to
                let move = SplitMove(from: by[from]?.name ?? "", to: by[to]?.name ?? "", amount: 0, seats: toThem ? 1 : n)
                if o.settled {
                    if paidBack[key] == nil { backOrder.append(key) }
                    paidBack[key, default: move].amount += o.amount
                    moved.append((from: from, to: to, amount: o.amount))
                } else {
                    if owing[key] == nil { owingOrder.append(key) }
                    owing[key, default: move].amount += o.amount
                }
            }
        }
        s.total = paisa(s.total)
        for k in order {
            guard var p = by[k] else { continue }
            p.paid = paisa(p.paid)
            p.share = paisa(p.share)
            by[k] = p
        }
        s.days.sort()
        s.hasShares = !owing.isEmpty || !paidBack.isEmpty
        s.known = order.reduce(0) { $0 + (by[$1]?.seats ?? 1) }
        // (largest first; the same figure keeps the order it first came in, so the result never depends on hashing)
        s.back = backOrder.compactMap { paidBack[$0] }.map { var m = $0; m.amount = paisa(m.amount); return m }.enumerated()
            .sorted { $0.element.amount != $1.element.amount ? $0.element.amount > $1.element.amount : $0.offset < $1.offset }.map(\.element)
        s.owes = owingOrder.compactMap { owing[$0] }.map { var m = $0; m.amount = paisa(m.amount); return m }.enumerated()
            .sorted { $0.element.amount != $1.element.amount ? $0.element.amount > $1.element.amount : $0.offset < $1.offset }.map(\.element)

        let n: Int = max(seats, s.known)
        if even && n > 1 && s.total > 0 {
            let fair: Double = s.total / Double(n)
            let extra: Int = n - s.known
            if extra > 0 { _ = person(extra == 1 ? "1 more person" : String(extra) + " more people", extra) }
            var bal: [String: Double] = [:]
            for k in order {
                guard var p = by[k] else { continue }
                let part: Double = fair * Double(p.seats)
                p.share = part.rounded()
                by[k] = p
                bal[k] = p.paid - part
            }
            // a share paid back is money that has moved: it counts for whoever paid it, against whoever got it
            for m in moved {
                bal[m.from, default: 0] += m.amount
                bal[m.to, default: 0] -= m.amount
            }
            s.owes = squares(bal, by: by, order: order)
            s.even = true
            s.seats = n
            s.each = fair.rounded()
        }
        s.people = order.compactMap { by[$0] }
        return s
    }

    /// the fewest payments that square it: whoever owes most pays whoever is owed most, and on down
    static func squares(_ bal: [String: Double], by: [String: SplitPerson], order: [String]) -> [SplitMove] {
        var owe: [(key: String, v: Double)] = []
        var get: [(key: String, v: Double)] = []
        for k in order {
            let v: Double = bal[k] ?? 0
            if v < -0.5 { owe.append((key: k, v: -v)) } else if v > 0.5 { get.append((key: k, v: v)) }
        }
        owe.sort { $0.v > $1.v }
        get.sort { $0.v > $1.v }
        var out: [SplitMove] = []
        var i: Int = 0
        var j: Int = 0
        while i < owe.count && j < get.count {
            let amt: Double = min(owe[i].v, get[j].v)
            if amt >= 1, let f = by[owe[i].key], let t = by[get[j].key] {
                out.append(SplitMove(from: f.name, to: t.name, amount: amt.rounded(), seats: f.seats))
            }
            owe[i].v -= amt
            get[j].v -= amt
            if owe[i].v < 0.5 { i += 1 }
            if get[j].v < 0.5 { j += 1 }
        }
        return out
    }
}
