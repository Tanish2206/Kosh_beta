import Foundation

// MARK: - Which cards and statements the Cards page shows (1 Nov, his screenshots)
//
// Screen-free, so swiftc checks it without Xcode (engine-test/cards-cleanup.js compiles it with the phone's Snapshot
// types and asks it about each test household).
// - A card nothing has come from in 90 days (engine 21d: CardInfo.old, the day of its last mail) is kept out of the
//   piles, folded away under Old cards. Nothing counted from it changes; it is only out of the way.
// - The page's Statements list holds only what needs you: a statement still locked, or one kosh couldn't read, from
//   the last 90 days. Read ones and older ones are reached from See all. A locked one whose mail printed nothing to pay
//   (StmtStatus.nothingDue) goes last and never nags.

enum CardShelf {
    /// how far back a statement may still ask for you, and a card count as current
    static let days: Int = 90

    static func isOld(_ c: CardInfo) -> Bool { !(c.old ?? "").isEmpty }

    /// the cards in the piles, and the old ones, each in the order given
    static func split(_ cards: [CardInfo]) -> (live: [CardInfo], old: [CardInfo]) {
        var live: [CardInfo] = []
        var old: [CardInfo] = []
        for c in cards { if isOld(c) { old.append(c) } else { live.append(c) } }
        return (live, old)
    }

    /// how long an old card stays in the list before it is retired: a rolling year from its last mail
    static let retireDays: Int = 365

    /// the old cards still worth seeing (quiet under a year) and the retired ones, folded further away
    static func retire(_ old: [CardInfo], today: String) -> (quiet: [CardInfo], retired: [CardInfo]) {
        let since: String = isoAdd(today, -retireDays)
        var quiet: [CardInfo] = [], retired: [CardInfo] = []
        for c in old { if String((c.old ?? "").prefix(10)) < since { retired.append(c) } else { quiet.append(c) } }
        return (quiet, retired)
    }

    /// a statement that asks something of you: locked, or one kosh couldn't read, that came in the last 90 days
    static func needsYou(_ s: StmtStatus, today: String) -> Bool {
        guard s.state == "locked" || s.state == "empty" else { return false }
        let since: String = isoAdd(today, -days)
        return String(s.sent.prefix(10)) >= since
    }

    /// a locked statement that waits quietly: its mail printed nothing to pay
    static func quiet(_ s: StmtStatus) -> Bool { s.nothingDue == true }

    /// the statements (by their mail's id, Reading.id) that wait quietly
    static func quietIDs(_ all: [StmtStatus]) -> Set<String> {
        var out: Set<String> = []
        for s in all where quiet(s) { out.insert(s.id) }
        return out
    }

    /// what needs you, the loud ones first (locked before unreadable), quiet ones last, then by bank and newest
    static func needing(_ all: [StmtStatus], today: String) -> [StmtStatus] {
        let xs: [StmtStatus] = all.filter { needsYou($0, today: today) }
        return xs.sorted { (a: StmtStatus, b: StmtStatus) -> Bool in
            let ra: Int = rank(a), rb: Int = rank(b)
            if ra != rb { return ra < rb }
            if a.inst != b.inst { return a.inst < b.inst }
            return a.sent > b.sent
        }
    }
    static func rank(_ s: StmtStatus) -> Int {
        if quiet(s) { return 2 }
        return s.state == "locked" ? 0 : 1
    }

    /// "19 Nov", or "19 Nov 2024" when it isn't this year
    static func day(_ d: String, today: String) -> String {
        let p: [Substring] = d.prefix(10).split(separator: "-")
        guard p.count == 3, let m = Int(p[1]), let dd = Int(p[2]), m >= 1, m <= 12 else { return d }
        let names: [String] = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
        let base: String = String(dd) + " " + names[m - 1]
        return d.prefix(4) == today.prefix(4) ? base : base + " " + String(p[0])
    }

    /// an old card's line: "Last mail 19 Nov 2024"
    static func oldLine(_ c: CardInfo, today: String) -> String {
        let d: String = c.old ?? ""
        return d.isEmpty ? "" : "Nothing from it since " + day(d, today: today)
    }

    /// (made once: Cards asked for a new one on every redraw)
    private static let utcDay: DateFormatter = {
        let f: DateFormatter = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX")
        f.timeZone = TimeZone(identifier: "UTC")
        f.dateFormat = "yyyy-MM-dd"
        return f
    }()
    /// yyyy-MM-dd moved by n days, in UTC (the engine's days are calendar days)
    static func isoAdd(_ d: String, _ n: Int) -> String {
        let f: DateFormatter = utcDay
        guard let x = f.date(from: String(d.prefix(10))) else { return d }
        return f.string(from: x.addingTimeInterval(Double(n) * 86_400))
    }
}
