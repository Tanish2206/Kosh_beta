import SwiftUI

// MARK: - Find's filters, in a sheet
//
// Find is a search field first. Beside it sits one Filters button (with how many are on), and after it the filters
// that are on, each a chip you can take off with a tap. The button opens a sheet over the results: what to show,
// when, how it was paid, how big (a two-handled range over a small picture of how many payments sit at each size),
// the category, and who it was for. The results behind it change as you pick, and the button at its foot says how
// many there are.

/// the amount range's stops: ₹0 to ₹50,000 and over
enum FindAmount {
    static let steps: [Double] = [0, 100, 250, 500, 1000, 2000, 5000, 10000, 25000, 50000]
    static var top: Int { steps.count - 1 }
    static func word(_ i: Int) -> String { Fmt.rupees(steps[max(0, min(top, i))]) + (i >= top ? "+" : "") }
    /// "Any amount", "Over ₹5,000", "Under ₹500", "₹500 – ₹5,000"
    static func label(_ lo: Int, _ hi: Int) -> String {
        if lo <= 0 && hi >= top { return "Any amount" }
        if hi >= top { return "Over " + Fmt.rupees(steps[lo]) }
        if lo <= 0 { return "Under " + Fmt.rupees(steps[hi]) }
        return Fmt.rupees(steps[lo]) + " – " + Fmt.rupees(steps[hi])
    }
    static func fits(_ a: Double, _ lo: Int, _ hi: Int) -> Bool {
        a >= steps[max(0, lo)] && (hi >= top || a <= steps[hi])
    }
}

/// a filter that's on, as a chip under the search field
struct FindToken: Identifiable {
    let id: String
    let title: String
    let sym: String
    let off: (inout FindQuery) -> Void

    @MainActor static func of(_ q: FindQuery, _ store: Store) -> [FindToken] {
        var out: [FindToken] = []
        if !q.ids.isEmpty { out.append(FindToken(id: "ids", title: q.idsTitle.isEmpty ? String(q.ids.count) + " payments" : q.idsTitle, sym: "list.bullet") { $0.ids = []; $0.idsTitle = "" }) }
        if q.uncat { out.append(FindToken(id: "uncat", title: "Uncategorised", sym: "questionmark.square.dashed") { $0.uncat = false }) }
        if q.refunds { out.append(FindToken(id: "refunds", title: "Refunds", sym: "arrow.uturn.backward") { $0.refunds = false }) }
        if q.unnamed { out.append(FindToken(id: "unnamed", title: "Needs a name", sym: "questionmark.circle") { $0.unnamed = false }) }
        if q.flow != .any { out.append(FindToken(id: "flow", title: q.flow.title, sym: q.flow.sym) { $0.flow = .any }) }
        if q.chapter { out.append(FindToken(id: "chapter", title: "In a chapter", sym: "book.pages") { $0.chapter = false }) }
        if !q.months.isEmpty { out.append(FindToken(id: "months", title: FindFilters.monthsTitle(q.months), sym: "calendar") { $0.months = [] }) }
        if q.span != .all { out.append(FindToken(id: "span", title: q.span.title, sym: "calendar") { $0.span = .all }) }
        for w in FindFilters.whom(store) where q.whom.contains(w.0) {
            let key: String = w.0
            out.append(FindToken(id: "for:" + key, title: "For " + w.1.lowercased(), sym: w.2) { _ = $0.whom.remove(key) })
        }
        for c in q.cats.sorted() { out.append(FindToken(id: "cat:" + c, title: c, sym: store.symbol(c)) { _ = $0.cats.remove(c); $0.subs = [] }) }
        for s in q.subs.sorted() { out.append(FindToken(id: "sub:" + s, title: s, sym: "") { _ = $0.subs.remove(s) }) }
        for w in q.ways.sorted() {
            let sym: String = FindFilters.ways.first { $0.0 == w }?.2 ?? "wallet.bifold"
            out.append(FindToken(id: "way:" + w, title: w == "wallet" ? "Wallets" : PaidWith.title(w), sym: sym) { _ = $0.ways.remove(w) })
        }
        if q.ranged { out.append(FindToken(id: "amount", title: FindAmount.label(q.lo, q.hi), sym: "indianrupeesign") { $0.lo = 0; $0.hi = FindAmount.top }) }
        if q.size != .any { out.append(FindToken(id: "size", title: q.size.title, sym: "indianrupeesign") { $0.size = .any }) }
        return out
    }
}

/// under the search field: Filters, then what's on
struct FindBar: View {
    @Environment(Store.self) private var store
    @Binding var q: FindQuery
    let open: () -> Void

    var body: some View {
        let on: [FindToken] = FindToken.of(q, store)
        ScrollView(.horizontal) {
            HStack(spacing: 8) {
                Button(action: open) {
                    HStack(spacing: 7) {
                        Image(systemName: "line.3.horizontal.decrease").font(.system(.footnote, weight: .semibold))
                        Text("Filters").font(.system(.subheadline, weight: .semibold))
                        if q.on > 0 {
                            Text(String(q.on))
                                .font(.system(.caption, weight: .bold)).monospacedDigit()
                                .foregroundStyle(Color.onKosh)
                                .frame(minWidth: 20, minHeight: 20)
                                .background(Color.koshFill, in: Capsule())
                                .contentTransition(.numericText())
                        }
                    }
                    .padding(.leading, 14).padding(.trailing, q.on > 0 ? 8 : 14)
                    .frame(height: 38)
                    .contentShape(Capsule())
                }
                .buttonStyle(.glass)
                .accessibilityLabel(q.on > 0 ? "Filters, " + String(q.on) + " on" : "Filters")
                ForEach(on) { t in
                    Button {
                        withAnimation(Motion.base) { t.off(&q) }
                    } label: {
                        HStack(spacing: 6) {
                            if !t.sym.isEmpty { Image(systemName: t.sym).font(.system(size: 12, weight: .semibold)) }
                            Text(t.title).font(.system(.footnote, weight: .semibold)).lineLimit(1)
                            Image(systemName: "xmark").font(.system(size: 9, weight: .heavy))
                                .frame(width: 18, height: 18)
                                .background(Color.kosh.opacity(0.14), in: Circle())
                        }
                        .foregroundStyle(Color.kosh)
                        .padding(.leading, 12).padding(.trailing, 7)
                        .frame(height: 34)
                        .background(Color.kosh.opacity(0.12), in: Capsule())
                        .frame(minHeight: 44)
                        .contentShape(Capsule())
                    }
                    .buttonStyle(.press)
                    .transition(.opacity.combined(with: .scale(scale: 0.9)))
                    .accessibilityLabel(t.title)
                    .accessibilityHint("Takes this filter off")
                }
            }
            .padding(.horizontal, 20)
        }
        .scrollIndicators(.hidden)
        .animation(Motion.base, value: q)
    }
}

/// the sheet: every filter, the results changing behind it
struct FindSheet: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    @Binding var q: FindQuery
    @State private var everyCat = false

    var body: some View {
        let n: Int = q.blank ? 0 : q.run(store).count
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    show
                    when
                    paidWith
                    amount
                    category
                    forWhom
                }
                .padding(.horizontal, 20)
                .padding(.top, 6)
                .padding(.bottom, 24)
            }
            .scrollIndicators(.hidden)
            .safeAreaInset(edge: .bottom) {
                Button { dismiss() } label: {
                    Text(q.blank ? "Done" : n == 0 ? "Nothing matches yet" : "Show " + String(n) + (n == 1 ? " payment" : " payments"))
                        .font(.headline)
                        .monospacedDigit()
                        .contentTransition(.numericText(value: Double(n)))
                        .frame(maxWidth: .infinity)
                        .frame(height: 50)
                }
                .buttonStyle(.glassProminent)
                .koshFilled()
                .padding(.horizontal, 20)
                .padding(.bottom, 8)
            }
            .navigationTitle("Filters")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("Reset") { withAnimation(Motion.open) { q = FindQuery(text: q.text) } }
                        .disabled(q.on == 0)
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button { dismiss() } label: { Image(systemName: "xmark") }
                        .accessibilityLabel("Close filters")
                }
            }
        }
        .animation(Motion.base, value: q)
        .sensoryFeedback(.selection, trigger: q.on)
        .presentationDetents([.medium, .large])
        .presentationDragIndicator(.visible)
        .presentationBackgroundInteraction(.enabled(upThrough: .medium))
    }

    // MARK: the sections

    func head(_ title: String, _ right: String = "") -> some View {
        HStack(alignment: .firstTextBaseline) {
            Text(title).font(.subheadline.weight(.semibold))
            Spacer(minLength: 8)
            if !right.isEmpty {
                Text(right).font(.subheadline).foregroundStyle(.secondary).monospacedDigit().contentTransition(.numericText())
            }
        }
    }

    var show: some View {
        let unnamed: Int = store.tx.filter { $0.u && store.who.owns($0.o) }.count
        return VStack(alignment: .leading, spacing: 10) {
            head("Show")
            Picker("Show", selection: $q.flow) {
                Text("All").tag(FindFlow.any)
                Text("Money out").tag(FindFlow.out)
                Text("Money in").tag(FindFlow.moneyIn)
                Text("Moves").tag(FindFlow.moves)
            }
            .pickerStyle(.segmented)
            HStack(spacing: 8) {
                FindChip(title: unnamed > 0 ? "Needs a name · " + String(unnamed) : "Needs a name", sym: "questionmark.circle", tint: Color.orange, on: q.unnamed) { q.unnamed.toggle() }
                FindChip(title: "In a chapter", sym: "book.pages", tint: Color.purple, on: q.chapter) { q.chapter.toggle() }
            }
        }
    }

    var when: some View {
        let main: Binding<FindSpan> = Binding(
            get: { [.month, .three, .year, .all].contains(q.span) ? q.span : .all },
            set: { v in q.span = v; q.months = [] })
        return VStack(alignment: .leading, spacing: 10) {
            head("When", q.months.isEmpty ? "" : FindFilters.monthsTitle(q.months))
            Picker("When", selection: main) {
                Text("This month").tag(FindSpan.month)
                Text("3 months").tag(FindSpan.three)
                Text("This year").tag(FindSpan.year)
                Text("Any time").tag(FindSpan.all)
            }
            .pickerStyle(.segmented)
            // the tax year, for when it's taxes you're after
            HStack(spacing: 8) {
                FindChip(title: "This FY", sym: "building.columns", tint: Color.kosh, on: q.span == .fy) { q.span = q.span == .fy ? .all : .fy; q.months = [] }
                FindChip(title: "Last FY", sym: "building.columns", tint: Color.kosh, on: q.span == .lastFY) { q.span = q.span == .lastFY ? .all : .lastFY; q.months = [] }
            }
        }
    }

    var paidWith: some View {
        let ways: [(String, String, String)] = [("upi", "UPI", "qrcode"), ("card", "Card", "creditcard"), ("bank", "Bank", "building.columns"), ("cash", "Cash", "banknote"), ("wallet", "Wallet", "wallet.bifold")]
        let wallets: [String] = Array(store.walletsUsed.prefix(6))
        return VStack(alignment: .leading, spacing: 10) {
            head("Paid with", q.ways.isEmpty ? "Any" : String(q.ways.count) + " picked")
            HStack(spacing: 8) {
                ForEach(ways, id: \.0) { w in wayTile(w.0, w.1, w.2) }
            }
            if !wallets.isEmpty && q.ways.contains("wallet") {
                ScrollView(.horizontal) {
                    HStack(spacing: 8) {
                        ForEach(wallets, id: \.self) { w in
                            FindChip(title: w, sym: "wallet.bifold", tint: Color(hex: "#FF9F0A"), on: q.ways.contains("w:" + w)) { FindFilters.flip(&q.ways, "w:" + w) }
                        }
                    }
                }
                .scrollIndicators(.hidden)
                .transition(.opacity.combined(with: .move(edge: .top)))
            }
        }
    }

    func wayTile(_ key: String, _ title: String, _ sym: String) -> some View {
        let on: Bool = q.ways.contains(key)
        return Button {
            withAnimation(Motion.base) { FindFilters.flip(&q.ways, key) }
        } label: {
            VStack(spacing: 5) {
                Image(systemName: sym).font(.system(.title3, weight: .medium))
                Text(title).font(.caption.weight(.semibold)).lineLimit(1).minimumScaleFactor(0.8)
            }
            .foregroundStyle(on ? Color.kosh : Color.primary)
            .frame(maxWidth: .infinity)
            .frame(minHeight: 62)
            .background(on ? Color.kosh.opacity(0.13) : Color.primary.opacity(0.05), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).strokeBorder(on ? Color.kosh : Color.clear, lineWidth: 1.5))
            .contentShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
        }
        .buttonStyle(.press)
        .accessibilityLabel(title)
        .accessibilityAddTraits(on ? [.isButton, .isSelected] : [.isButton])
    }

    var amount: some View {
        // how many payments sit at each size, everything else picked as it is
        var rest: FindQuery = q
        rest.lo = 0; rest.hi = FindAmount.top; rest.size = .any
        let base: [Txn] = rest.blank ? store.tx.filter { $0.sp && store.who.owns($0.o) } : rest.run(store)
        let bands: [Int] = Self.bands(base.map(\.a))
        let lo: Binding<Int> = Binding(get: { q.lo }, set: { v in q.lo = v; q.size = .any })
        let hi: Binding<Int> = Binding(get: { q.hi }, set: { v in q.hi = v; q.size = .any })
        return VStack(alignment: .leading, spacing: 10) {
            head("Amount")
            Text(FindAmount.label(q.lo, q.hi))
                .font(.system(.title, design: .rounded, weight: .bold))
                .monospacedDigit()
                .contentTransition(.numericText())
            FindHistogram(bands: bands, lo: q.lo, hi: q.hi)
                .frame(minHeight: 56)
                .padding(.horizontal, 14)
            FindRange(lo: lo, hi: hi, top: FindAmount.top)
                .frame(height: 36)
                .padding(.top, -10)
            HStack {
                Text("₹0"); Spacer(); Text("₹1,000"); Spacer(); Text("₹10,000"); Spacer(); Text("₹50,000+")
            }
            .font(.caption2).foregroundStyle(.secondary).padding(.horizontal, 4)
            HStack(spacing: 8) {
                quick("Under ₹500", 0, 3)
                quick("₹500 – 5k", 3, 6)
                quick("Over ₹5k", 6, FindAmount.top)
            }
        }
    }

    func quick(_ title: String, _ a: Int, _ b: Int) -> some View {
        FindChip(title: title, sym: "", tint: Color.kosh, on: q.lo == a && q.hi == b) {
            if q.lo == a && q.hi == b { q.lo = 0; q.hi = FindAmount.top } else { q.lo = a; q.hi = b }
            q.size = .any
        }
    }

    /// how many of the amounts fall between each pair of stops
    static func bands(_ amounts: [Double]) -> [Int] {
        var out: [Int] = Array(repeating: 0, count: FindAmount.top)
        for a in amounts {
            var i: Int = FindAmount.top - 1
            for k in 1...FindAmount.top where a < FindAmount.steps[k] { i = k - 1; break }
            out[max(0, i)] += 1
        }
        return out
    }

    var category: some View {
        let cats: [String] = FindFilters.categories(store)
        let shown: [String] = everyCat ? cats : Array(cats.prefix(8))
        let subs: [String] = FindFilters.subcategories(store, of: q.cats)
        return VStack(alignment: .leading, spacing: 12) {
            head("Category", q.cats.isEmpty ? "Any" : String(q.cats.count) + " picked")
            LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 8, alignment: .top), count: 4), spacing: 14) {
                ForEach(shown, id: \.self) { c in catDot(c) }
            }
            if cats.count > 8 {
                Button(everyCat ? "Fewer" : "All " + String(cats.count) + " categories") { withAnimation(Motion.open) { everyCat.toggle() } }
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(Color.kosh)
                    .frame(minHeight: 44)
            }
            if !subs.isEmpty {
                ScrollView(.horizontal) {
                    HStack(spacing: 8) {
                        ForEach(subs, id: \.self) { s in
                            FindChip(title: s, sym: "", tint: Color.kosh, on: q.subs.contains(s)) { FindFilters.flip(&q.subs, s) }
                        }
                    }
                }
                .scrollIndicators(.hidden)
                .transition(.opacity.combined(with: .move(edge: .top)))
            }
        }
    }

    func catDot(_ c: String) -> some View {
        let on: Bool = q.cats.contains(c)
        let tint: Color = store.catColor(c)
        return Button {
            withAnimation(Motion.base) {
                FindFilters.flip(&q.cats, c)
                let keep: Set<String> = Set(FindFilters.subcategories(store, of: q.cats))
                q.subs = q.subs.intersection(keep)
            }
        } label: {
            VStack(spacing: 6) {
                Image(systemName: store.symbol(c))
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundStyle(Color.white)
                    .frame(width: 46, height: 46)
                    .background(tint.gradient, in: Circle())
                    .overlay(Circle().strokeBorder(Color.kosh, lineWidth: on ? 2.5 : 0).padding(-5))
                    .scaleEffect(on ? 1.04 : 1)
                Text(c)
                    .font(.caption2.weight(on ? .bold : .medium))
                    .foregroundStyle(on ? Color.kosh : Color.primary)
                    .lineLimit(1)
                    .minimumScaleFactor(0.75)
            }
            .frame(maxWidth: .infinity)
            .contentShape(Rectangle())
        }
        .buttonStyle(.press)
        .accessibilityLabel(c)
        .accessibilityAddTraits(on ? [.isButton, .isSelected] : [.isButton])
    }

    var forWhom: some View {
        let whom: [(String, String, String, Color)] = FindFilters.whom(store)
        let one: Binding<String> = Binding(get: { q.whom.count == 1 ? (q.whom.first ?? "") : "" }, set: { v in q.whom = v.isEmpty ? [] : [v] })
        return VStack(alignment: .leading, spacing: 10) {
            head("For")
            Picker("For", selection: one) {
                Text("Everyone").tag("")
                ForEach(whom, id: \.0) { w in Text(w.1).tag(w.0) }
            }
            .pickerStyle(.segmented)
        }
    }
}

/// how many payments sit at each size: lit inside the range picked, quiet outside it
struct FindHistogram: View {
    let bands: [Int]
    let lo: Int
    let hi: Int
    var body: some View {
        let top: Int = max(1, bands.max() ?? 1)
        HStack(alignment: .bottom, spacing: 4) {
            ForEach(Array(bands.enumerated()), id: \.offset) { i, n in
                let inside: Bool = i >= lo && i < hi
                UnevenRoundedRectangle(topLeadingRadius: 5, bottomLeadingRadius: 2, bottomTrailingRadius: 2, topTrailingRadius: 5, style: .continuous)
                    .fill(inside ? AnyShapeStyle(MiniChart.ink) : AnyShapeStyle(Color.primary.opacity(0.1)))
                    .frame(height: max(4, 56 * CGFloat(n) / CGFloat(top)))
                    .frame(maxWidth: .infinity)
            }
        }
        .animation(Motion.open, value: lo)
        .animation(Motion.open, value: hi)
        .accessibilityHidden(true)
    }
}

/// two handles on one track, each stopping at the amount stops
struct FindRange: View {
    @Binding var lo: Int
    @Binding var hi: Int
    let top: Int

    var body: some View {
        GeometryReader { g in
            let inset: CGFloat = 14
            let w: CGFloat = max(1, g.size.width - inset * 2)
            let x: (Int) -> CGFloat = { i in inset + w * CGFloat(i) / CGFloat(top) }
            let at: (CGFloat) -> Int = { px in Int(((px - inset) / w * CGFloat(top)).rounded()) }
            ZStack(alignment: .leading) {
                Capsule().fill(Color.primary.opacity(0.1)).frame(width: w, height: 4).offset(x: inset)
                Capsule().fill(MiniChart.ink).frame(width: max(0, x(hi) - x(lo)), height: 4).offset(x: x(lo))
                knob("Lowest amount", FindAmount.word(lo))
                    .position(x: x(lo), y: g.size.height / 2)
                    .gesture(DragGesture(minimumDistance: 0, coordinateSpace: .named("findRange")).onChanged { v in
                        lo = min(max(0, at(v.location.x)), hi - 1)
                    })
                    .accessibilityAdjustableAction { d in lo = d == .increment ? min(hi - 1, lo + 1) : max(0, lo - 1) }
                knob("Highest amount", FindAmount.word(hi))
                    .position(x: x(hi), y: g.size.height / 2)
                    .gesture(DragGesture(minimumDistance: 0, coordinateSpace: .named("findRange")).onChanged { v in
                        hi = max(min(top, at(v.location.x)), lo + 1)
                    })
                    .accessibilityAdjustableAction { d in hi = d == .increment ? min(top, hi + 1) : max(lo + 1, hi - 1) }
            }
            .coordinateSpace(.named("findRange"))
        }
        .sensoryFeedback(.selection, trigger: lo)
        .sensoryFeedback(.selection, trigger: hi)
    }

    func knob(_ label: String, _ value: String) -> some View {
        Circle()
            .fill(Color.white)
            .frame(width: 28, height: 28)
            .shadow(color: Color.black.opacity(0.18), radius: 4, y: 2)
            .overlay(Circle().strokeBorder(Color.black.opacity(0.06), lineWidth: 0.5))
            .frame(width: 44, height: 44)
            .contentShape(Rectangle())
            .accessibilityElement()
            .accessibilityLabel(label)
            .accessibilityValue(value)
    }
}
