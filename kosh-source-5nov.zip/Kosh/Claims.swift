import SwiftUI
import PDFKit
import MessageUI

// MARK: - Claims: what a travel claim is made from, the claims you made, and what kosh follows up for you
//
// The engine (packs.js) lays out every travel payment beside the mail that proves it (snap.docs), says which look
// like work and why, and keeps the cases kosh is following up (snap.cases): a month's claim ready to make, a claim
// made and not sent, one sent and waiting for its money, one paid. Here: the Home card, the claim you tick and
// make (a PDF of a summary and every invoice, an Excel sheet, a mail to finance you send yourself), and a claim's
// own page. What you decide (the claims, your company's rules, what you ticked) is kept in ClaimBook, on this
// phone, and goes back to the engine with the profile.

/// a key any JSON field can be read by, for the lenient readers below
struct PackKey: CodingKey {
    var stringValue: String; var intValue: Int? { nil }
    init(_ s: String) { stringValue = s }
    init?(stringValue: String) { self.stringValue = stringValue }
    init?(intValue: Int) { nil }
}

/// one travel payment and the mail that proves it (packs.js index): what it was, what a claim form asks for, the
/// mail and PDF to put in the claim, and whether kosh thinks it's work and why. Read leniently: a field the engine
/// leaves out or changes never stops the screens.
struct ClaimDoc: Decodable, Identifiable, Hashable {
    var tx = ""; var d = ""; var t = ""; var m = ""; var a: Double = 0; var k = "travel"
    var ev = ""; var acct = ""; var from = ""
    var att: AttRef? = nil; var more: [String] = []
    var doc = ""; var ref = ""; var fromP = ""; var toP = ""; var on = ""; var until = ""; var place = ""; var nights: Int? = nil
    var tax: Double? = nil; var p = ""; var md = ""; var card = ""; var fx = ""; var tr = ""
    var refunded = false; var cl = ""; var inc = false; var why = ""; var how = ""; var nopay = false
    var id: String { tx.isEmpty ? "ev:" + ev : tx }

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: PackKey.self)
        func s(_ k: String) -> String { (try? c.decode(String.self, forKey: PackKey(k))) ?? "" }
        func n(_ k: String) -> Double? { try? c.decode(Double.self, forKey: PackKey(k)) }
        func b(_ k: String) -> Bool { (try? c.decode(Bool.self, forKey: PackKey(k))) ?? false }
        tx = s("tx"); d = s("d"); t = s("t"); m = s("m"); a = n("a") ?? 0; k = s("k").isEmpty ? "travel" : s("k")
        ev = s("ev"); acct = s("acct"); from = s("from")
        att = try? c.decode(AttRef.self, forKey: PackKey("att"))
        more = (try? c.decode([String].self, forKey: PackKey("more"))) ?? []
        doc = s("doc"); ref = s("ref"); fromP = s("fromP"); toP = s("toP"); on = s("on"); until = s("until"); place = s("place")
        nights = try? c.decode(Int.self, forKey: PackKey("nights"))
        tax = n("tax"); p = s("p"); md = s("md"); card = s("card"); fx = s("fx"); tr = s("tr")
        refunded = b("refunded"); cl = s("cl"); inc = b("inc"); why = s("why"); how = s("how"); nopay = b("nopay")
    }

    /// what the assistant's claim tool reads (agent.js → packs.js claimTool)
    var json: [String: Any] {
        ["tx": tx, "d": d, "t": t, "m": m, "a": a, "k": k, "ev": ev, "inc": inc, "cl": cl, "why": why]
    }
    /// the trip in a few words: from and to, the stay's place and nights, or the booking id
    var details: String {
        var bits: [String] = []
        if !fromP.isEmpty && !toP.isEmpty { bits.append(fromP + " → " + toP) }
        if !place.isEmpty { bits.append(place) }
        if let n = nights, n > 0 { bits.append("\(n) night" + (n == 1 ? "" : "s")) }
        if bits.isEmpty && !ref.isEmpty { bits.append(ref) }
        return bits.joined(separator: " · ")
    }
    var kindName: String { ClaimDoc.kindName(k) }
    static func kindName(_ k: String) -> String {
        switch k {
        case "cab": return "Cab"
        case "flight": return "Flight"
        case "train": return "Train"
        case "bus": return "Bus"
        case "stay": return "Stay"
        case "car": return "Car rental"
        default: return "Travel"
        }
    }
    var sym: String {
        switch k {
        case "cab": return "car.fill"
        case "flight": return "airplane"
        case "train": return "tram.fill"
        case "bus": return "bus.fill"
        case "stay": return "bed.double.fill"
        case "car": return "car.side.fill"
        default: return "suitcase.fill"
        }
    }
    /// which paper proves it, in words
    var proof: String {
        if ev.isEmpty { return "No invoice yet" }
        if att != nil { return doc == "ticket" ? "E-ticket PDF" : "Invoice PDF" }
        return doc == "receipt" ? "Receipt in mail" : doc == "invoice" ? "Invoice in mail" : "Booking in mail"
    }
}

/// something kosh is following up for you (packs.js cases): what it is, where it stands, what's next
struct CaseItem: Decodable, Identifiable, Hashable {
    struct Step: Decodable, Hashable {
        var d = ""; var t = ""
        init(from decoder: Decoder) throws {
            let c = try decoder.container(keyedBy: PackKey.self)
            d = (try? c.decode(String.self, forKey: PackKey("d"))) ?? ""; t = (try? c.decode(String.self, forKey: PackKey("t"))) ?? ""
        }
    }
    var id = ""; var kind = ""; var st = "needs"; var title = ""; var detail = ""; var amt: Double = 0; var d = ""
    var sym = "checkmark.seal"; var act = ""; var from = ""; var to = ""; var claim = ""; var steps: [Step] = []

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: PackKey.self)
        func s(_ k: String) -> String { (try? c.decode(String.self, forKey: PackKey(k))) ?? "" }
        id = s("id"); kind = s("kind"); st = s("st").isEmpty ? "needs" : s("st"); title = s("title"); detail = s("detail")
        amt = (try? c.decode(Double.self, forKey: PackKey("amt"))) ?? 0; d = s("d")
        sym = s("sym").isEmpty ? "checkmark.seal" : s("sym"); act = s("act"); from = s("from"); to = s("to"); claim = s("claim")
        steps = (try? c.decode([Step].self, forKey: PackKey("steps"))) ?? []
    }
    var tint: Color { st == "needs" ? Color.orange : st == "done" ? Color.green : Color.kosh }
}

// MARK: - what you decided: the claims, your company's rules, what you ticked

/// your company's rules for a travel claim: the kinds it pays for, cabs only after a time, weekdays only, where
/// claims go, and whether kosh should say when a month's claim is ready
struct ClaimPolicy: Codable, Equatable {
    var kinds: [String] = ["cab", "flight", "train", "bus", "stay"]
    var cabAfter: String = ""
    var weekdays: Bool = false
    var to: String = ""
    var on: Bool = false
    var json: [String: Any] { ["kinds": kinds, "cabAfter": cabAfter, "weekdays": weekdays, "to": to, "on": on] }
}

/// a claim you made: its days, what was in it, when it was made, sent and paid
struct Claim: Codable, Identifiable, Hashable {
    var id: String; var title: String; var from: String; var to: String
    var amount: Double; var items: [String]; var made: String
    var sent: String = ""; var sentTo: String = ""; var st: String = "made"; var paidOn: String = ""
    var json: [String: Any] {
        ["id": id, "title": title, "from": from, "to": to, "amount": amount, "items": items, "made": made, "sent": sent, "sentTo": sentTo, "st": st, "paidOn": paidOn]
    }
}

// read leniently, so a field added later never loses what was kept
extension ClaimPolicy {
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: PackKey.self)
        kinds = (try? c.decode([String].self, forKey: PackKey("kinds"))) ?? ["cab", "flight", "train", "bus", "stay"]
        cabAfter = (try? c.decode(String.self, forKey: PackKey("cabAfter"))) ?? ""
        weekdays = (try? c.decode(Bool.self, forKey: PackKey("weekdays"))) ?? false
        to = (try? c.decode(String.self, forKey: PackKey("to"))) ?? ""
        on = (try? c.decode(Bool.self, forKey: PackKey("on"))) ?? false
    }
}
extension Claim {
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: PackKey.self)
        func s(_ k: String) -> String { (try? c.decode(String.self, forKey: PackKey(k))) ?? "" }
        id = s("id"); title = s("title"); from = s("from"); to = s("to")
        amount = (try? c.decode(Double.self, forKey: PackKey("amount"))) ?? 0
        items = (try? c.decode([String].self, forKey: PackKey("items"))) ?? []
        made = s("made"); sent = s("sent"); sentTo = s("sentTo"); st = s("st").isEmpty ? "made" : s("st"); paidOn = s("paidOn")
    }
}

/// kept on this phone (claims.json beside the profile, encrypted like it), handed to the engine with the profile
final class ClaimBook: @unchecked Sendable {
    static let shared = ClaimBook()
    private let lock = NSLock()
    private var claims0: [Claim] = []
    private var policy0 = ClaimPolicy()
    private var prefs0: [String: [Int]] = [:]
    private var marks0: [String: String] = [:]
    private struct File: Codable { var claims: [Claim]; var policy: ClaimPolicy; var prefs: [String: [Int]]; var marks: [String: String] }
    private var url: URL { LiveSession.folder.appendingPathComponent("claims.json") }
    /// read from the file (or there was none): until then nothing is written over it, so a start before the phone's
    /// first unlock (the file can't be read yet) never loses what was kept
    private var loaded = false
    private let queue = DispatchQueue(label: "kosh.claims")

    /// (under the lock) the file read, once it can be
    private func loadIfNeeded() {
        guard !loaded else { return }
        let u = url
        guard FileManager.default.fileExists(atPath: u.path) else { loaded = true; return }
        guard let d = try? Data(contentsOf: u) else { return }
        // (in whatever shape a kosh wrote it: SavedFormat)
        if let f = try? SavedFormat.decode(File.self, d, .claims).value { claims0 = f.claims; policy0 = f.policy; prefs0 = f.prefs; marks0 = f.marks }
        else {
            // a file this kosh can't read (damaged, or a newer kosh's in a shape it doesn't know) is set aside, dated, as
            // the decisions are: the next claim you add starts a new file and never writes over the ones it held
            let aside: URL = u.deletingPathExtension().appendingPathExtension("unread-" + Day.iso(Date()) + ".json")
            if !FileManager.default.fileExists(atPath: aside.path) { try? FileManager.default.copyItem(at: u, to: aside) }
        }
        loaded = true
    }
    var claims: [Claim] { lock.lock(); defer { lock.unlock() }; loadIfNeeded(); return claims0 }
    var policy: ClaimPolicy { lock.lock(); defer { lock.unlock() }; loadIfNeeded(); return policy0 }
    func claim(_ id: String) -> Claim? { claims.first { $0.id == id } }

    private func save() {
        lock.lock()
        guard loaded else { lock.unlock(); return }
        let f = File(claims: claims0, policy: policy0, prefs: prefs0, marks: marks0)
        lock.unlock()
        let u = url
        queue.async {
            if let d = try? JSONEncoder().encode(f) { try? SavedFormat.write(d, .claims, to: u, options: [.atomic, LiveSession.protection]) }
        }
    }
    private func change(_ body: () -> Void) { lock.lock(); loadIfNeeded(); body(); lock.unlock(); save() }

    /// into the profile the engine builds with
    func add(to p: inout [String: Any]) {
        lock.lock(); defer { lock.unlock() }
        loadIfNeeded()
        if !claims0.isEmpty {
            p["claims"] = claims0.map { $0.json }
        }
        p["claimPolicy"] = policy0.json
        if !prefs0.isEmpty { p["packPrefs"] = prefs0 }
        if !marks0.isEmpty { p["caseMarks"] = marks0 }
    }

    func setPolicy(_ p: ClaimPolicy) { change { policy0 = p } }
    /// a claim made from the claim sheet (a new one, or one made again with other items)
    func made(_ c: Claim) {
        change {
            if let i = claims0.firstIndex(where: { $0.id == c.id }) { claims0[i] = c } else { claims0.append(c) }
            // once you've made one, kosh says when the next month's is ready
            policy0.on = true
        }
    }
    func markSent(_ id: String, to: String) {
        change {
            guard let i = claims0.firstIndex(where: { $0.id == id }) else { return }
            claims0[i].sent = LiveSession.today; claims0[i].sentTo = to
            if claims0[i].st == "made" { claims0[i].st = "sent" }
        }
    }
    func markPaid(_ id: String) {
        change {
            guard let i = claims0.firstIndex(where: { $0.id == id }) else { return }
            claims0[i].st = "paid"; claims0[i].paidOn = LiveSession.today
            if claims0[i].sent.isEmpty { claims0[i].sent = LiveSession.today }
        }
    }
    /// set aside (not claiming it after all): its items can go in another claim
    func close(_ id: String) { change { if let i = claims0.firstIndex(where: { $0.id == id }) { claims0[i].st = "closed" } } }
    func reopen(_ id: String) { change { if let i = claims0.firstIndex(where: { $0.id == id }) { claims0[i].st = claims0[i].sent.isEmpty ? "made" : "sent" } } }
    func mark(_ key: String, _ value: String?) { change { marks0[key] = value } }

    /// what you ticked against what kosh suggested, by payee and by kind on weekdays and weekends: the next claim's
    /// suggestions follow you (packs.js suggest)
    func learn(shown: [ClaimDoc], picked: Set<String>) {
        change {
            for e in shown {
                let inn = picked.contains(e.id)
                let we = Self.weekend(e.d)
                let day: String = we ? "we" : "wd"
                for key in ["m:" + e.m.lowercased() + "|" + day, "k:" + e.k + "|" + day] {
                    var v = prefs0[key] ?? [0, 0]
                    if v.count != 2 { v = [0, 0] }
                    if inn { v[0] += 1 } else { v[1] += 1 }
                    prefs0[key] = v
                }
            }
        }
    }
    static func weekend(_ d: String) -> Bool { let w = Day.weekday(d); return w == 1 || w == 7 }

    func reset() {
        lock.lock(); claims0 = []; policy0 = ClaimPolicy(); prefs0 = [:]; marks0 = [:]; loaded = true; lock.unlock()
        let u = url
        queue.async { try? FileManager.default.removeItem(at: u) }
    }
}

// MARK: - Home: what needs you, and what kosh is handling

struct CasesCard: View {
    @Environment(Store.self) private var store
    @AppStorage("home.fold.cases") private var folded = false
    var body: some View {
        let all: [CaseItem] = store.snap.cases ?? []
        let needs: [CaseItem] = all.filter { $0.st == "needs" }
        let rest: [CaseItem] = all.filter { $0.st != "needs" }
        let title: String = needs.isEmpty ? (rest.isEmpty ? "Travel claims" : "kosh is handling") : "Needs you"
        VStack(alignment: .leading, spacing: 12) {
            SectionHeader(title: title, action: "New claim", folded: $folded) { store.betaSheet = .pack(PackSheet.defaultPeriod(store.snap.today)) }
            Unfold(open: !folded) {
                VStack(alignment: .leading, spacing: 0) {
                    if !needs.isEmpty {
                        ForEach(Array(needs.enumerated()), id: \.element.id) { i, c in
                            if i > 0 { Divider().padding(.leading, 46) }
                            CaseRowButton(c: c)
                        }
                    }
                    if !rest.isEmpty {
                        if !needs.isEmpty {
                            Text("KOSH IS HANDLING").font(.caption2.weight(.bold)).foregroundStyle(.secondary).padding(.top, 12).padding(.bottom, 2)
                        }
                        ForEach(Array(rest.enumerated()), id: \.element.id) { i, c in
                            if i > 0 { Divider().padding(.leading, 46) }
                            CaseRowButton(c: c)
                        }
                    }
                    if all.isEmpty { StartClaimRow() }
                }
                .padding(.horizontal, 14)
                .padding(.vertical, 4)
                .background(CardFill(), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
            }
            Unfold(open: folded) {
                if let top = all.first {
                    HStack(spacing: 8) {
                        Circle().fill(top.tint).frame(width: 8, height: 8)
                        Text(top.title).font(.subheadline).lineLimit(1)
                        Spacer(minLength: 0)
                        if all.count > 1 { Text("+\(all.count - 1)").font(.footnote.weight(.semibold)).foregroundStyle(.secondary) }
                    }
                    .onTapGesture { withAnimation(Fold.spring) { folded = false } }
                }
            }
        }
    }
}

/// one case: tap to act on it; a ready claim can be set aside for the month, or for good
struct CaseRowButton: View {
    let c: CaseItem
    @Environment(Store.self) private var store
    var body: some View {
        Button { open() } label: { CaseRow(c: c) }
            .buttonStyle(.press)
            .contextMenu {
                if c.kind == "ready" {
                    Button("Not this month", systemImage: "clock") { setAside("ready|" + String(c.from.prefix(7))) }
                    Button("I don’t make travel claims", systemImage: "hand.raised") { setAside("ready") }
                }
            }
    }
    func open() {
        if c.act == "pack" { store.betaSheet = .pack(c.from + "|" + c.to) }
        else if c.act == "claim", !c.claim.isEmpty { store.betaSheet = .claim(c.claim) }
    }
    func setAside(_ key: String) {
        ClaimBook.shared.mark(key, key == "ready" ? "off" : "no")
        store.live?.rebuildSoon(force: true)
    }
}

struct CaseRow: View {
    let c: CaseItem
    var body: some View {
        let level: String = c.st == "needs" ? "NEEDS YOU" : c.st == "done" ? "DONE" : "KOSH IS ON IT"
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: c.sym)
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(c.tint)
                .frame(width: 34, height: 34)
                .background(c.tint.opacity(0.12), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
            VStack(alignment: .leading, spacing: 3) {
                Text(level).font(.caption2.weight(.bold)).foregroundStyle(c.tint)
                Text(c.title).font(.subheadline.weight(.semibold)).foregroundStyle(Color.primary)
                    .fixedSize(horizontal: false, vertical: true)
                if !c.detail.isEmpty {
                    Text(c.detail).font(.footnote).foregroundStyle(.secondary).lineLimit(3)
                        .fixedSize(horizontal: false, vertical: true)
                }
            }
            Spacer(minLength: 0)
            Image(systemName: "chevron.right").font(.footnote.weight(.semibold)).foregroundStyle(.tertiary).padding(.top, 10)
        }
        .padding(.vertical, 10)
        .contentShape(Rectangle())
        .privacySensitive()
    }
}

/// no case yet: this month's travel, one tap from a claim
struct StartClaimRow: View {
    @Environment(Store.self) private var store
    var body: some View {
        let period: String = PackSheet.defaultPeriod(store.snap.today)
        let parts: [String] = period.components(separatedBy: "|")
        let docs: [ClaimDoc] = (store.snap.docs ?? []).filter { $0.d >= parts[0] && $0.d <= parts[1] && $0.cl.isEmpty }
        let total: Double = docs.filter { $0.inc }.reduce(0) { $0 + $1.a }
        let month: String = Day.fmt(parts[0], "MMMM")
        let trips: String = "\(docs.count) trip" + (docs.count == 1 ? "" : "s")
        let found: String = trips + " in " + month + " · " + Fmt.rupees(total) + " looks like work"
        let line: String = docs.isEmpty ? "Cabs, flights, trains and stays, with their invoices, in one PDF and an Excel sheet." : found
        Button { store.betaSheet = .pack(period) } label: {
            HStack(alignment: .top, spacing: 12) {
                Image(systemName: "doc.badge.plus")
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(Color.kosh)
                    .frame(width: 34, height: 34)
                    .background(Color.kosh.opacity(0.12), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
                VStack(alignment: .leading, spacing: 3) {
                    Text("Make a travel claim").font(.subheadline.weight(.semibold)).foregroundStyle(Color.primary)
                    Text(line).font(.footnote).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                }
                Spacer(minLength: 0)
                Image(systemName: "chevron.right").font(.footnote.weight(.semibold)).foregroundStyle(.tertiary).padding(.top, 10)
            }
            .padding(.vertical, 10)
            .contentShape(Rectangle())
            .privacySensitive()
        }
        .buttonStyle(.press)
    }
}

// MARK: - The claim: tick what's in it, then make it

struct PackSheet: View {
    /// "from|to", or "from|to|claim id" to make a claim again
    let period: String
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    @State private var from = ""
    @State private var to = ""
    @State private var again: Claim? = nil
    @State private var picked: Set<String> = []
    @State private var started = false
    @State private var policy = ClaimPolicy()
    @State private var rulesOpen = false
    @State private var building = false
    @State private var progress = ""
    @State private var made: PackMaker.Output? = nil
    @State private var madeClaim: Claim? = nil
    @State private var problem: String? = nil
    /// your rules changed: when the engine has picked again, the ticks follow
    @State private var repick = false

    /// last month in a month's first twelve days, else this one
    static func defaultPeriod(_ today: String) -> String {
        let day: Int = Day.dayNumber(today)
        let m: String = day <= 12 ? String(Day.add(String(today.prefix(7)) + "-01", -1).prefix(7)) : String(today.prefix(7))
        return m + "-01|" + monthEnd(m)
    }
    static func monthEnd(_ m: String) -> String { m + "-" + String(format: "%02d", Day.daysIn(m)) }

    var body: some View {
        NavigationStack {
            Group {
                if let made, let c = madeClaim {
                    PackResultView(output: made, claim: c, policy: policy) { dismiss() }
                } else {
                    picker
                }
            }
            .navigationTitle(made == nil ? "Travel claim" : "Claim made")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { if made == nil { Button("Cancel") { dismiss() }.disabled(building) } }
                ToolbarItem(placement: .confirmationAction) { if made != nil { Button("Done") { dismiss() } } }
            }
        }
        .interactiveDismissDisabled(building)
        .onAppear(perform: start)
        .onChange(of: store.snap.generated) { _, _ in
            // your rules changed and kosh picked again: the ticks follow (a background read leaves them as you set them)
            guard repick else { return }
            repick = false
            if again == nil && !building && made == nil { picked = Set(shown.filter { $0.inc }.map { $0.id }) }
        }
    }

    func start() {
        guard !started else { return }
        started = true
        let p: [String] = period.components(separatedBy: "|")
        from = p.first ?? ""; to = p.count > 1 ? p[1] : from
        if p.count > 2, let c = ClaimBook.shared.claim(p[2]) { again = c; picked = Set(c.items) }
        policy = ClaimBook.shared.policy
        if again == nil { picked = Set(shown.filter { $0.inc }.map { $0.id }) }
    }

    /// the travel in the days chosen, not already in another claim (a claim made again shows its own items)
    var shown: [ClaimDoc] {
        let docs: [ClaimDoc] = store.snap.docs ?? []
        let mine: Set<String> = Set(again?.items ?? [])
        return docs.filter { e in
            guard e.d >= from && e.d <= to else { return false }
            return e.cl.isEmpty || mine.contains(e.id)
        }
    }
    var inClaim: [ClaimDoc] { shown.filter { picked.contains($0.id) } }
    var leftOut: [ClaimDoc] { shown.filter { !picked.contains($0.id) } }
    var total: Double { inClaim.reduce(0) { $0 + $1.a } }

    var months: [String] {
        let today: String = store.snap.today
        var out: [String] = []
        var m: String = String(today.prefix(7))
        for _ in 0..<12 {
            out.append(m)
            m = String(Day.add(m + "-01", -1).prefix(7))
        }
        return out
    }

    var picker: some View {
        ObsidianList {
            Section {
                VStack(alignment: .leading, spacing: 6) {
                    Menu {
                        ForEach(months, id: \.self) { m in
                            Button(Day.fmt(m + "-01", "MMMM yyyy")) {
                                from = m + "-01"; to = Self.monthEnd(m)
                                picked = Set(shown.filter { $0.inc }.map { $0.id })
                            }
                        }
                    } label: {
                        HStack(spacing: 4) {
                            Text(periodName).font(.subheadline.weight(.semibold))
                            Image(systemName: "chevron.up.chevron.down").font(.caption2.weight(.bold))
                        }
                    }
                    Text(Fmt.rupees(total)).font(.system(size: 40, weight: .semibold, design: .rounded)).monospacedDigit()
                        .contentTransition(.numericText()).privacySensitive()
                    Text(summaryLine).font(.footnote).foregroundStyle(.secondary)
                }
                .padding(.vertical, 4)
            }
            if shown.isEmpty {
                Section {
                    Text("No cabs, flights, trains, buses or stays in " + periodName + " that kosh can see in your mail and payments.")
                        .foregroundStyle(.secondary)
                }
            }
            if !inClaim.isEmpty {
                Section("In the claim") {
                    ForEach(inClaim) { e in PackRow(e: e, on: true) { toggle(e) } }
                }
            }
            if !leftOut.isEmpty {
                Section {
                    ForEach(leftOut) { e in PackRow(e: e, on: false) { toggle(e) } }
                } header: {
                    Text("Left out")
                } footer: {
                    Text("Tap one to put it in. kosh learns from what you tick.")
                }
            }
            Section {
                DisclosureGroup("Your company’s rules", isExpanded: $rulesOpen) { rules }
            } footer: {
                Text("kosh picks with these, and remembers them for every claim.")
            }
            if let problem { Section { Text(problem).foregroundStyle(.red) } }
        }
        .listStyle(.insetGrouped)
        .safeAreaInset(edge: .bottom) { makeBar }
        .overlay { if building { buildingCover } }
    }

    var periodName: String {
        if from.hasSuffix("-01") && to == Self.monthEnd(String(from.prefix(7))) { return Day.fmt(from, "MMMM yyyy") }
        return Day.fmt(from, "d MMM") + " to " + Day.fmt(to, "d MMM yyyy")
    }
    var summaryLine: String {
        let n: Int = inClaim.count
        let missing: Int = inClaim.filter { $0.ev.isEmpty }.count
        var s: String = "\(n) item" + (n == 1 ? "" : "s")
        if n > 0 { s += missing > 0 ? " · \(missing) without an invoice yet" : " · every invoice found" }
        return s
    }

    func toggle(_ e: ClaimDoc) {
        withAnimation(Motion.base) {
            if picked.contains(e.id) { picked.remove(e.id) } else { picked.insert(e.id) }
        }
    }

    @ViewBuilder var rules: some View {
        let kinds: [(String, String)] = [("cab", "Cabs"), ("flight", "Flights"), ("train", "Trains"), ("bus", "Buses"), ("stay", "Stays"), ("car", "Car rentals")]
        ForEach(kinds, id: \.0) { k in
            Toggle(k.1, isOn: Binding(get: { policy.kinds.contains(k.0) }, set: { on in
                if on { if !policy.kinds.contains(k.0) { policy.kinds.append(k.0) } } else { policy.kinds.removeAll { $0 == k.0 } }
                savePolicy()
            }))
        }
        Picker("Cabs only after", selection: Binding(get: { policy.cabAfter }, set: { policy.cabAfter = $0; savePolicy() })) {
            Text("Any time").tag("")
            ForEach(["18:00", "19:00", "20:00", "21:00", "22:00"], id: \.self) { t in Text(Self.hourName(t)).tag(t) }
        }
        Toggle("Weekdays only", isOn: Binding(get: { policy.weekdays }, set: { policy.weekdays = $0; savePolicy() }))
        TextField("Finance’s email (optional)", text: Binding(get: { policy.to }, set: { policy.to = $0 }))
            .keyboardType(.emailAddress).textInputAutocapitalization(.never).autocorrectionDisabled()
            .onSubmit { savePolicy() }
    }
    static func hourName(_ t: String) -> String {
        let h: Int = Int(t.prefix(2)) ?? 0
        return "\(h % 12 == 0 ? 12 : h % 12) " + (h >= 12 ? "pm" : "am")
    }
    func savePolicy() {
        ClaimBook.shared.setPolicy(policy)
        repick = true
        store.live?.rebuildSoon(force: true)
    }

    var makeBar: some View {
        let label: String = inClaim.isEmpty ? "Tick what’s in the claim" : "Make claim · " + Fmt.rupees(total)
        return Button { make() } label: {
            Text(label).font(.headline).frame(maxWidth: .infinity).padding(.vertical, 6)
        }
        .buttonStyle(.glassProminent).koshFilled()
        .disabled(inClaim.isEmpty || building)
        .padding(.horizontal, 20).padding(.vertical, 10)
    }

    var buildingCover: some View {
        VStack(spacing: 12) {
            ProgressView()
            Text(progress.isEmpty ? "Making the claim…" : progress).font(.subheadline).foregroundStyle(.secondary)
        }
        .padding(24)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
    }

    func make() {
        guard let live = store.live, !inClaim.isEmpty else { return }
        if policy.to != ClaimBook.shared.policy.to { ClaimBook.shared.setPolicy(policy) }
        building = true; problem = nil
        let items: [ClaimDoc] = inClaim
        let title: String = "Travel claim, " + periodName
        let who: String = live.name.isEmpty ? "" : live.name
        Task { @MainActor in
            let out = await PackMaker.make(title: title, period: periodName, name: who, items: items, live: live) { i, n in
                progress = "Gathering invoices: \(i) of \(n)"
            }
            building = false
            guard let out else { problem = "kosh couldn’t make the claim. Try again in a moment."; return }
            let c = Claim(id: again?.id ?? UUID().uuidString, title: periodName + " travel claim", from: from, to: to,
                          amount: (total * 100).rounded() / 100, items: items.map { $0.id }, made: LiveSession.today,
                          sent: again?.sent ?? "", sentTo: again?.sentTo ?? "", st: again?.st ?? "made")
            ClaimBook.shared.made(c)
            // a claim made again teaches nothing new
            if again == nil { ClaimBook.shared.learn(shown: shown, picked: picked) }
            live.rebuildSoon(force: true)
            withAnimation(Motion.base) { madeClaim = c; made = out }
        }
    }
}

/// one payment in the claim: what and when, the trip in a few words, the paper behind it, the amount, the tick
struct PackRow: View {
    let e: ClaimDoc
    let on: Bool
    let tap: () -> Void
    var body: some View {
        let when: String = Day.fmt(e.d, "EEE d MMM") + (e.t.isEmpty ? "" : ", " + Self.time(e.t))
        let detail: String = e.details
        let proofTint: Color = e.ev.isEmpty ? Color.orange : Color.secondary
        let proofSym: String = e.ev.isEmpty ? "exclamationmark.triangle.fill" : (e.att != nil ? "doc.fill" : "envelope.fill")
        let line2: String = detail.isEmpty ? when : when + " · " + detail
        let place: String = on ? ", in the claim" : ", left out"
        let spoken: String = e.m + ", " + Fmt.rupees(e.a) + ", " + when + place
        let quiet: String = e.m + ", " + when + place
        Button(action: tap) {
            HStack(alignment: .top, spacing: 12) {
                Image(systemName: e.sym)
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(on ? Color.kosh : Color.secondary)
                    .frame(width: 32, height: 32)
                    .background((on ? Color.kosh : Color.secondary).opacity(0.12), in: RoundedRectangle(cornerRadius: 9, style: .continuous))
                VStack(alignment: .leading, spacing: 2) {
                    Text(e.m).font(.subheadline.weight(.semibold)).foregroundStyle(Color.primary).lineLimit(1)
                    Text(line2).font(.footnote).foregroundStyle(.secondary).lineLimit(2)
                    HStack(spacing: 4) {
                        Image(systemName: proofSym)
                        Text(e.proof)
                    }
                    .font(.caption.weight(.medium)).foregroundStyle(proofTint)
                    if !on && !e.why.isEmpty {
                        Text(e.why).font(.caption).foregroundStyle(.secondary)
                    } else if on && e.ev.isEmpty && !e.how.isEmpty {
                        Text(e.how).font(.caption).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                    }
                }
                Spacer(minLength: 8)
                VStack(alignment: .trailing, spacing: 6) {
                    Text(Fmt.rupees(e.a)).font(.subheadline.weight(.semibold)).monospacedDigit().foregroundStyle(on ? Color.primary : Color.secondary)
                    Image(systemName: on ? "checkmark.circle.fill" : "circle")
                        .font(.title3).foregroundStyle(on ? Color.kosh : Color.secondary.opacity(0.5))
                }
            }
            .padding(.vertical, 4)
            .contentShape(Rectangle())
        }
        .buttonStyle(.press)
        .privacySensitive()
        .spokenFigures(spoken, hidden: quiet)
    }
    static func time(_ t: String) -> String {
        let h: Int = Int(t.prefix(2)) ?? 0
        let m: String = String(t.dropFirst(3).prefix(2))
        return "\(h % 12 == 0 ? 12 : h % 12):" + (m.isEmpty ? "00" : m) + (h >= 12 ? " pm" : " am")
    }
}

// MARK: - The claim made: look at it, send it

struct PackResultView: View {
    let output: PackMaker.Output
    let claim: Claim
    let policy: ClaimPolicy
    let done: () -> Void
    @Environment(Store.self) private var store
    @State private var mailing = false
    @State private var sent = false

    var body: some View {
        let n: Int = claim.items.count
        let items: String = "\(n) item" + (n == 1 ? "" : "s")
        let what: String = items + " · \(output.pages) pages · a PDF and an Excel sheet"
        let gaps: String = "\(output.missing) item" + (output.missing == 1 ? " has" : "s have")
        let missingLine: String = gaps + " no invoice yet. They're listed in the summary; kosh adds an invoice when it reaches your mail."
        let mailLabel: String = policy.to.isEmpty ? "Email the claim" : "Email to " + policy.to
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                VStack(alignment: .leading, spacing: 4) {
                    Text(Fmt.rupees(claim.amount)).font(.system(.largeTitle, design: .rounded, weight: .semibold)).monospacedDigit().privacySensitive()
                    Text(what).font(.footnote).foregroundStyle(.secondary)
                }
                PDFPreview(url: output.pdf)
                    .frame(height: 380)
                    .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(Color.secondary.opacity(0.2), lineWidth: 1))
                    .privacySensitive()
                if output.missing > 0 || !output.notes.isEmpty {
                    VStack(alignment: .leading, spacing: 6) {
                        if output.missing > 0 {
                            Label(missingLine, systemImage: "exclamationmark.triangle.fill")
                                .foregroundStyle(Color.orange)
                        }
                        ForEach(output.notes, id: \.self) { n in Label(n, systemImage: "info.circle").foregroundStyle(.secondary) }
                    }
                    .font(.footnote)
                }
                VStack(spacing: 10) {
                    if MFMailComposeViewController.canSendMail() {
                        Button { mailing = true } label: {
                            Label(mailLabel, systemImage: "envelope.fill").frame(maxWidth: .infinity).padding(.vertical, 4)
                        }
                        .buttonStyle(.glassProminent).koshFilled()
                    }
                    ShareLink(items: [output.pdf, output.xlsx]) {
                        Label("Share or save the files", systemImage: "square.and.arrow.up").frame(maxWidth: .infinity).padding(.vertical, 4)
                    }
                    .buttonStyle(.glass)
                    if !sent {
                        Button("I’ve sent it") { markSent(to: policy.to) }
                            .font(.subheadline.weight(.semibold))
                            .padding(.top, 2)
                    }
                }
                Text(sent ? "kosh is watching for the money: on its own, or with your salary. It's on Home until it comes." : "Once it's sent, kosh watches for the money and tells you when it comes.")
                    .font(.footnote).foregroundStyle(.secondary)
            }
            .padding(20)
        }
        .sheet(isPresented: $mailing) {
            MailComposer(to: policy.to, subject: subject, text: mailBody, files: [output.pdf, output.xlsx]) { didSend in
                mailing = false
                if didSend { markSent(to: policy.to) }
            }
            .ignoresSafeArea()
        }
    }

    var subject: String { "Travel claim · " + Fmt.rupees(claim.amount) + " · " + claim.title.replacingOccurrences(of: " travel claim", with: "") }
    var mailBody: String {
        let n: Int = claim.items.count
        let items: String = "\(n) item" + (n == 1 ? "" : "s")
        let first: String = "Please find my travel claim attached: " + items + ", " + Fmt.rupees(claim.amount) + " in all."
        var lines: [String] = ["Hi,", "", first]
        lines.append("The PDF has a summary followed by each invoice; the Excel sheet has the same items.")
        lines.append("")
        lines.append("Thanks")
        return lines.joined(separator: "\n")
    }
    func markSent(to: String) {
        ClaimBook.shared.markSent(claim.id, to: to)
        store.live?.rebuildSoon(force: true)
        withAnimation(Motion.base) { sent = true }
    }
}

/// a claim already made: where it stands, what was in it, and what you can do with it
struct ClaimSheet: View {
    let id: String
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        let c: Claim? = ClaimBook.shared.claim(id)
        let kase: CaseItem? = (store.snap.cases ?? []).first { $0.claim == id }
        NavigationStack {
            ObsidianList {
                if let c {
                    Section {
                        VStack(alignment: .leading, spacing: 4) {
                            Text(Fmt.rupees(c.amount)).font(.system(.largeTitle, design: .rounded, weight: .semibold)).monospacedDigit().privacySensitive()
                            Text(kase?.detail ?? stateLine(c)).font(.footnote).foregroundStyle(.secondary)
                        }
                        .padding(.vertical, 4)
                    }
                    if let steps = kase?.steps, !steps.isEmpty {
                        Section("Where it stands") {
                            ForEach(Array(steps.enumerated()), id: \.offset) { _, s in
                                HStack {
                                    Text(s.t)
                                    Spacer()
                                    Text(s.d.isEmpty ? "" : Day.fmt(s.d, "d MMM")).foregroundStyle(.secondary).monospacedDigit()
                                }
                                .font(.subheadline)
                            }
                        }
                    }
                    Section("In it") {
                        let set: Set<String> = Set(c.items)
                        let docs: [ClaimDoc] = (store.snap.docs ?? []).filter { set.contains($0.id) }
                        ForEach(docs) { e in PackRow(e: e, on: true) {}.allowsHitTesting(false) }
                        if docs.count < c.items.count {
                            Text("\(c.items.count - docs.count) more from before kosh's reading starts.").font(.footnote).foregroundStyle(.secondary)
                        }
                    }
                    Section {
                        if c.sent.isEmpty {
                            Button("I’ve sent it", systemImage: "paperplane") { act { ClaimBook.shared.markSent(id, to: ClaimBook.shared.policy.to) } }
                        }
                        if c.st != "paid" && c.st != "closed" {
                            Button("It’s been paid", systemImage: "checkmark.seal") { act { ClaimBook.shared.markPaid(id) } }
                        }
                        Button("Make the PDF again", systemImage: "doc.on.doc") {
                            dismiss()
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) { store.betaSheet = .pack(c.from + "|" + c.to + "|" + c.id) }
                        }
                        if c.st == "closed" {
                            Button("Open it again", systemImage: "arrow.uturn.backward") { act { ClaimBook.shared.reopen(id) } }
                        } else {
                            Button("Not claiming this after all", systemImage: "xmark.circle", role: .destructive) { act { ClaimBook.shared.close(id) }; dismiss() }
                        }
                    } footer: {
                        Text("kosh closes a claim by itself when its money comes: as its own credit, or with your salary.")
                    }
                } else {
                    Text("This claim is no longer on this phone.").foregroundStyle(.secondary)
                }
            }
            .listStyle(.insetGrouped)
            .navigationTitle(c.map { PackMaker.capital($0.title) } ?? "Claim")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } } }
        }
    }
    func stateLine(_ c: Claim) -> String {
        if c.st == "closed" { return "Set aside on this phone." }
        if c.st == "paid" { return "Paid." }
        if c.sent.isEmpty { return "Made on " + Day.fmt(c.made, "d MMM") + ", not sent yet." }
        return "Sent on " + Day.fmt(c.sent, "d MMM") + "."
    }
    func act(_ body: () -> Void) {
        body()
        store.live?.rebuildSoon(force: true)
    }
}

// MARK: - small bridges to UIKit: the PDF, and a mail you send yourself

struct PDFPreview: UIViewRepresentable {
    let url: URL
    func makeUIView(context: Context) -> PDFView {
        let v = PDFView()
        v.autoScales = true
        v.displayMode = .singlePageContinuous
        v.backgroundColor = .secondarySystemBackground
        v.document = PDFDocument(url: url)
        return v
    }
    func updateUIView(_ v: PDFView, context: Context) {
        if v.document?.documentURL != url { v.document = PDFDocument(url: url) }
    }
}

/// Mail's own compose sheet with the claim attached: you read it and press Send; kosh sends nothing itself
struct MailComposer: UIViewControllerRepresentable {
    let to: String
    let subject: String
    let text: String
    let files: [URL]
    let finished: (Bool) -> Void
    func makeCoordinator() -> Coordinator { Coordinator(finished) }
    func makeUIViewController(context: Context) -> MFMailComposeViewController {
        let vc = MFMailComposeViewController()
        vc.mailComposeDelegate = context.coordinator
        if !to.isEmpty { vc.setToRecipients([to]) }
        vc.setSubject(subject)
        vc.setMessageBody(text, isHTML: false)
        for f in files {
            guard let d = try? Data(contentsOf: f) else { continue }
            let mime: String = f.pathExtension.lowercased() == "pdf" ? "application/pdf" : "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            vc.addAttachmentData(d, mimeType: mime, fileName: f.lastPathComponent)
        }
        return vc
    }
    func updateUIViewController(_ vc: MFMailComposeViewController, context: Context) {}
    final class Coordinator: NSObject, MFMailComposeViewControllerDelegate {
        let finished: (Bool) -> Void
        init(_ f: @escaping (Bool) -> Void) { finished = f }
        func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
            finished(result == .sent)
        }
    }
}
