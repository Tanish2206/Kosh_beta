import SwiftUI

// MARK: - A chapter's split, to send to the family
//
// Who paid what on a chapter, who owes whom, and what it all came to over its dates, from what kosh already has:
// each payment's payer (whose money it was in the household) and its whole cost, and the shares split off it under
// Owed to you (open, or paid back). "As split" reads those shares as they stand; "Evenly" shares the whole cost
// equally between everyone in it (and anyone more you count) and works out the fewest payments that square it.
// It goes out as a picture with its words, or the words alone, through the share sheet: nothing leaves the phone any
// other way, and no one needs kosh to read it.

/// "Kabir pays Ria ₹5,900", "2 others pay Ria ₹1,500 each" (SplitPerson and SplitMove themselves, and the
/// arithmetic, are in SplitBook.swift, which holds no screens)
extension SplitMove {
    var line: String {
        if seats > 1 { return from + " pay " + to + " " + Fmt.rupees(each) + " each" }
        return from + " pays " + to + " " + Fmt.rupees(amount)
    }
    var backLine: String { from + " paid " + to + " back " + Fmt.rupees(amount) }
}

struct ChapterSplit {
    var title: String = ""
    /// the chapter's days, and the days its payments ran over, both with their year
    var dates: String = ""
    var paidSpan: String = ""
    var total: Double = 0
    var payments: Int = 0
    var people: [SplitPerson] = []
    /// still to square, and squared already
    var owes: [SplitMove] = []
    var back: [SplitMove] = []
    /// split evenly: between how many, and each one's part
    var even: Bool = false
    var seats: Int = 0
    var each: Double = 0
    /// the people in it as it stands, a group counted as its seats
    var known: Int = 0
    var hasShares: Bool = false

    var payers: [SplitPerson] { people.filter { $0.paid > 0 } }

    /// over who owes whom, or why nobody does
    var owesTitle: String {
        if !owes.isEmpty { return "Who owes whom" }
        if even { return "All square" }
        return "Nobody owes anything as it was split"
    }

    /// "over 23 payments, paid 1 Feb – 6 Mar 2026", and with the total in front
    var countLine: String {
        let count: String = payments == 1 ? "1 payment" : String(payments) + " payments"
        return "over " + count + (paidSpan.isEmpty ? "" : ", paid " + paidSpan)
    }
    var totalLine: String { Fmt.rupees(total) + " " + countLine }

    /// each person's line: "Ria paid ₹30,000 · share ₹24,100"
    static func personLine(_ p: SplitPerson) -> String {
        var part: String = Fmt.rupees(p.share)
        if p.seats > 1 { part += " (" + Fmt.rupees(eachOf(p)) + " each)" }
        if p.paid > 0 { return p.name + " paid " + Fmt.rupees(p.paid) + " · share " + part }
        return p.name + " · share " + part
    }
    /// a group's share, a person each
    static func eachOf(_ p: SplitPerson) -> Double { (p.share / Double(max(1, p.seats))).rounded() }

    /// the words that go with the picture, or on their own
    var text: String {
        var out: [String] = [title + " · " + dates, "Total " + totalLine, ""]
        if even { out.append("Split evenly between " + String(seats) + ": " + Fmt.rupees(each) + " each") }
        for p in people { out.append(Self.personLine(p)) }
        out.append("")
        out.append(owesTitle)
        for m in owes { out.append(m.line) }
        if !back.isEmpty {
            out.append("")
            out.append("Paid back already")
            for m in back { out.append(m.backLine) }
        }
        out.append("")
        out.append("Worked out in kosh")
        return out.joined(separator: "\n")
    }

    /// the split of these payments: each one's payer and whole cost, and the shares split off them (owed to the payer,
    /// or owed back by the payer once money came back: SplitBook.tally, the arithmetic). Evenly, the cost is shared
    /// between `seats` people (never fewer than are in it already), the shares paid back counting as money that has moved
    static func make(title: String, dates: String, rows: [Txn], owed: [OwedItem], payer: (String) -> String, even: Bool, seats: Int) -> ChapterSplit {
        var s = ChapterSplit()
        s.title = title
        s.dates = dates
        // (a payment left out of spending is out of the split; one with shares split off it is in, even when what stayed
        // yours doesn't count: a trip's, under Everyday)
        let book: [SplitBook.Row] = rows.filter { ($0.ex ?? "").isEmpty }.map { t in
            SplitBook.Row(id: t.id, payer: payer(t.o), a: t.a, shared: t.shared ?? 0, counted: t.sp || t.ev == true, day: t.od ?? t.d)
        }
        let shares: [SplitBook.Share] = owed.compactMap { o in
            guard let tx = o.tx else { return nil }
            return SplitBook.Share(tx: tx, name: o.name, amount: o.amount, dir: o.dir, settled: o.settled)
        }
        let t: SplitBook.Tally = SplitBook.tally(book, shares, even: even, seats: seats)
        s.total = t.total
        s.payments = t.payments
        s.paidSpan = DraftWords.span(t.days.first ?? "", t.days.last ?? "")
        s.hasShares = t.hasShares
        s.known = t.known
        s.back = t.back
        s.owes = t.owes
        s.even = t.even
        s.seats = t.seats
        s.each = t.each
        s.people = t.people.sorted { a, b in a.paid != b.paid ? a.paid > b.paid : a.name < b.name }
        return s
    }

    /// the fewest payments that square it (SplitBook.squares)
    static func squares(_ bal: [String: Double], by: [String: SplitPerson], order: [String]) -> [SplitMove] {
        SplitBook.squares(bal, by: by, order: order)
    }
}

extension Store {
    /// a chapter's split, worked out once a change to its payments or to what's owed, not once a redraw
    func chapterSplit(_ id: String, even: Bool, seats: Int) -> ChapterSplit {
        if splitMemo.gen != txGen || splitMemo.owed != owedGen { splitMemo = (txGen, owedGen, [:]) }
        let key: String = id + (even ? "|even|" + String(seats) : "|as")
        if let known = splitMemo.by[key] { return known }
        let made: ChapterSplit = makeSplit(id, even: even, seats: seats)
        splitMemo.by[key] = made
        return made
    }

    private func makeSplit(_ id: String, even: Bool, seats: Int) -> ChapterSplit {
        guard let t = trip(id) else { return ChapterSplit() }
        if tripTxMemo.gen != txGen { tripTxMemo = (txGen, tx.filter { $0.tr != nil }) }
        let rows: [Txn] = tripTxMemo.list.filter { $0.tr == id }
        let ids: Set<String> = Set(rows.map(\.id))
        let shares: [OwedItem] = owed.filter { ids.contains($0.tx ?? "") }
        let today: String = snap.today
        var dates: String = ""
        if !t.from.isEmpty { dates = DraftWords.span(t.from, t.to.isEmpty ? max(t.from, today) : t.to) }
        var s: ChapterSplit = ChapterSplit.make(title: t.name, dates: dates, rows: rows, owed: shares, payer: { o in self.splitName(o) }, even: even, seats: seats)
        if s.dates.isEmpty { s.dates = s.paidSpan }
        return s
    }

    /// a payer as the family knows them: their own name (never "You", which reads wrong to whoever it's sent to)
    func splitName(_ o: String) -> String {
        let named: String = snap.people.first { $0.id == o }?.name ?? ""
        if !named.isEmpty { return named }
        if o.isEmpty || o == "me" { return "Me" }
        return ownerName(o)
    }
}

// MARK: on a chapter's page

/// who paid, who owes whom, and the way to send it
struct ChapterSplitPart: View {
    @Environment(Store.self) private var store
    let id: String
    let n: Int
    @State private var sharing = false
    var body: some View {
        let s: ChapterSplit = store.chapterSplit(id, even: false, seats: 0)
        VStack(alignment: .leading, spacing: 14) {
            PartTitle(n: n, text: "Who paid, who owes")
            VStack(spacing: 0) {
                ForEach(s.people.prefix(6)) { p in
                    SplitPersonRow(p: p).overlay(alignment: .bottom) { Rule() }
                }
            }
            if !s.owes.isEmpty {
                VStack(alignment: .leading, spacing: 8) {
                    ForEach(s.owes.prefix(6)) { m in
                        Label(m.line, systemImage: "arrow.right.circle").font(.subheadline).privacySensitive()
                    }
                }
            }
            Text(Self.note(s)).font(.footnote).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            Button { sharing = true } label: {
                Label("Share the split", systemImage: "square.and.arrow.up")
                    .font(.body.weight(.semibold))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 4)
            }
            .buttonStyle(.glass)
            .controlSize(.large)
        }
        .sheet(isPresented: $sharing) {
            SplitShareSheet(id: id).environment(store).presentationDragIndicator(.visible)
        }
    }
    static func note(_ s: ChapterSplit) -> String {
        if s.hasShares { return "From the shares you split off its payments. Send it as it is, or split the whole of " + s.totalLine + " evenly." }
        if s.payers.count > 1 { return "Nothing split off its payments yet. Split the whole of " + s.totalLine + " evenly to see who owes whom." }
        return s.totalLine + ". Share it with the family, split evenly between however many were on it."
    }
}

struct SplitPersonRow: View {
    let p: SplitPerson
    var body: some View {
        HStack(spacing: 12) {
            Text(String(p.name.prefix(1)).uppercased())
                .font(.system(size: 14, weight: .bold))
                .foregroundStyle(Color.white)
                .frame(width: 34, height: 34)
                .background(Color.tripInk.mix(with: .black, by: 0.2), in: Circle())
            VStack(alignment: .leading, spacing: 1) {
                Text(p.name).font(.system(.callout, weight: .semibold)).lineLimit(1)
                Text(Self.shareLine(p)).font(.caption).foregroundStyle(.secondary).privacySensitive()
            }
            Spacer(minLength: 8)
            VStack(alignment: .trailing, spacing: 1) {
                Text(Fmt.rupees(p.paid)).font(.system(.subheadline, weight: .semibold)).monospacedDigit().privacySensitive()
                Text("paid").font(.caption).foregroundStyle(.secondary)
            }
        }
        .padding(.vertical, 10)
    }
    /// "Share ₹12,050", "Share ₹6,000 between 2"
    static func shareLine(_ p: SplitPerson) -> String {
        let base: String = "Share " + Fmt.rupees(p.share)
        if p.seats > 1 { return base + " between " + String(p.seats) }
        return base
    }
}

// MARK: sending it

struct SplitShareSheet: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    let id: String
    /// as split, or evenly; between how many
    @State private var even = false
    @State private var seats = 2
    @State private var ready = false
    /// the picture, drawn once for each way of splitting it (never in the body)
    @State private var picture: UIImage? = nil

    var body: some View {
        let base: ChapterSplit = store.chapterSplit(id, even: false, seats: 0)
        let s: ChapterSplit = even ? store.chapterSplit(id, even: true, seats: seats) : base
        let ink: Color = Self.ink(store.trip(id))
        let low: Int = min(20, max(2, base.known))
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    HStack(spacing: 4) {
                        modeButton("As split", on: !even) { even = false }
                        modeButton("Evenly", on: even) { even = true }
                    }
                    .padding(4)
                    .background(Color(uiColor: .secondarySystemFill), in: Capsule())
                    if even {
                        Stepper(value: $seats, in: low...20) {
                            VStack(alignment: .leading, spacing: 1) {
                                Text("Between " + String(seats) + " people").font(.body.weight(.semibold))
                                Text(Fmt.rupees(s.each) + " each").font(.footnote).foregroundStyle(.secondary).privacySensitive()
                            }
                        }
                    } else if !base.hasShares {
                        Text("Nothing has been split off its payments yet, so nobody owes anything as it stands. Split it evenly to send each person their share.")
                            .font(.footnote).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                    }
                    // the picture itself, as it will be sent, fitted to the screen (the card until it's drawn)
                    Group {
                        if let img = picture {
                            Image(uiImage: img).resizable().scaledToFit()
                                .frame(maxWidth: ChapterSplitCard.width)
                        } else {
                            ChapterSplitCard(split: s, ink: ink)
                        }
                    }
                    .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
                    .shadow(color: Color.black.opacity(0.08), radius: 14, y: 5)
                    .frame(maxWidth: .infinity)
                    .privacySensitive()
                    .accessibilityElement(children: .ignore)
                    .accessibilityLabel(s.text)
                    Text("Sent through your phone's share sheet, as a picture and its words. Only what's on this card goes: no accounts, no shops' details beyond the totals.")
                        .font(.footnote).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                }
                .padding(.horizontal, 20)
                .padding(.vertical, 12)
            }
            .scrollIndicators(.hidden)
            .safeAreaInset(edge: .bottom, spacing: 0) {
                VStack(spacing: 10) {
                    if let img = picture {
                        let image: Image = Image(uiImage: img)
                        ShareLink(item: image, subject: Text(s.title), message: Text(s.text), preview: SharePreview(s.title, image: image)) {
                            Label("Send the picture", systemImage: "photo")
                                .font(.body.weight(.semibold))
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 4)
                        }
                        .buttonStyle(.glassProminent).koshFilled()
                        .controlSize(.large)
                    }
                    ShareLink(item: s.text, subject: Text(s.title)) {
                        Label("Send as text", systemImage: "text.alignleft")
                            .font(.body.weight(.semibold))
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 4)
                    }
                    .buttonStyle(.glass)
                    .controlSize(.large)
                }
                .padding(.horizontal, 20)
                .padding(.top, 10)
                .padding(.bottom, 8)
                .background(.bar)
            }
            .navigationTitle("Share the split")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Close") { dismiss() } }
            }
        }
        .sensoryFeedback(.selection, trigger: seats)
        .onAppear {
            guard !ready else { return }
            ready = true
            // as split when there's something split; else evenly, between the household (or two)
            even = !base.hasShares
            seats = min(20, max(low, store.snap.people.count))
            draw()
        }
        .onChange(of: even) { _, _ in draw() }
        .onChange(of: seats) { _, _ in draw() }
    }

    func draw() {
        let s: ChapterSplit = even ? store.chapterSplit(id, even: true, seats: seats) : store.chapterSplit(id, even: false, seats: 0)
        picture = ChapterSplitCard.render(s, ink: Self.ink(store.trip(id)))
    }

    static func ink(_ t: TripInfo?) -> Color {
        Color(hex: t?.color ?? "#FF9500").mix(with: .black, by: 0.22)
    }

    func modeButton(_ title: String, on: Bool, _ tap: @escaping () -> Void) -> some View {
        Button {
            withAnimation(Motion.base) { tap() }
        } label: {
            Text(title)
                .font(.system(.footnote, weight: .semibold))
                .foregroundStyle(Color.primary)
                .frame(maxWidth: .infinity)
                .frame(minHeight: 36)
                .background {
                    if on {
                        Capsule().fill(Color(uiColor: .systemBackground))
                            .shadow(color: Color.black.opacity(0.12), radius: 3, y: 1)
                    }
                }
        }
        .buttonStyle(.press)
        .accessibilityAddTraits(on ? .isSelected : [])
    }
}

/// the split as a card, drawn the same on screen and in the picture sent: its name and days, the total and the days
/// it was paid over, each person's line, then who owes whom. Its own light colours, so the picture reads the same on
/// anyone's phone; fixed sizes, so it never reflows with the sender's text size
struct ChapterSplitCard: View {
    let split: ChapterSplit
    let ink: Color
    static let width: CGFloat = 340

    var body: some View {
        let s: ChapterSplit = split
        let paper: Color = Color(hex: "#FFFDF8")
        let text: Color = Color(hex: "#1C1B19")
        let soft: Color = Color(hex: "#6B6862")
        let line: Color = Color(hex: "#E6E1D8")
        VStack(alignment: .leading, spacing: 0) {
            HStack(alignment: .top, spacing: 12) {
                VStack(alignment: .leading, spacing: 3) {
                    Text(s.even ? "THE SPLIT · EVENLY" : "THE SPLIT")
                        .font(.system(size: 11, weight: .bold)).tracking(1.3).foregroundStyle(ink)
                    Text(s.title).font(.system(size: 23, weight: .semibold, design: .serif)).foregroundStyle(text)
                        .fixedSize(horizontal: false, vertical: true)
                    Text(s.dates).font(.system(size: 14)).foregroundStyle(soft)
                }
                Spacer(minLength: 0)
                // (hung from the card's top edge, as the chapters' ribbons are)
                Ribbon().fill(ink).frame(width: 14, height: 34).padding(.top, -22)
            }
            Text(Fmt.rupees(s.total))
                .font(.system(size: 36, weight: .bold, design: .serif)).foregroundStyle(text)
                .lineLimit(1).minimumScaleFactor(0.6)
                .padding(.top, 16)
            Text(Words.cap(s.countLine))
                .font(.system(size: 13)).foregroundStyle(soft)
                .fixedSize(horizontal: false, vertical: true)
            if s.even {
                Text("Split evenly between " + String(s.seats) + ": " + Fmt.rupees(s.each) + " each")
                    .font(.system(size: 13, weight: .semibold)).foregroundStyle(ink)
                    .padding(.top, 6)
            }
            Rectangle().fill(line).frame(height: 1).padding(.vertical, 14)
            ForEach(s.people.prefix(8)) { p in
                HStack(alignment: .firstTextBaseline, spacing: 8) {
                    Text(p.name).font(.system(size: 15, weight: .semibold)).foregroundStyle(text).lineLimit(1)
                    Spacer(minLength: 6)
                    VStack(alignment: .trailing, spacing: 1) {
                        Text(Self.paid(p)).font(.system(size: 14, weight: .semibold)).foregroundStyle(text)
                        Text(Self.share(p)).font(.system(size: 12)).foregroundStyle(soft)
                    }
                }
                .padding(.bottom, 9)
            }
            if s.people.count > 8 {
                Text("and " + String(s.people.count - 8) + " more").font(.system(size: 12)).foregroundStyle(soft).padding(.bottom, 9)
            }
            Rectangle().fill(line).frame(height: 1).padding(.bottom, 14)
            Text(s.owesTitle)
                .font(.system(size: 11, weight: .bold)).tracking(1.1).textCase(.uppercase).foregroundStyle(soft)
            ForEach(s.owes.prefix(10)) { m in
                HStack(alignment: .firstTextBaseline, spacing: 8) {
                    Text(Self.from(m)).font(.system(size: 15, weight: .semibold)).foregroundStyle(text).lineLimit(1)
                    Image(systemName: "arrow.right").font(.system(size: 11, weight: .bold)).foregroundStyle(ink)
                    Text(m.to).font(.system(size: 15)).foregroundStyle(text).lineLimit(1)
                    Spacer(minLength: 6)
                    Text(Fmt.rupees(m.each)).font(.system(size: 15, weight: .bold)).foregroundStyle(text)
                }
                .padding(.top, 8)
            }
            if !s.back.isEmpty {
                Text("Paid back already").font(.system(size: 11, weight: .bold)).tracking(1.1).textCase(.uppercase).foregroundStyle(soft)
                    .padding(.top, 14)
                ForEach(s.back.prefix(6)) { m in
                    Text(m.backLine).font(.system(size: 13)).foregroundStyle(soft).padding(.top, 5)
                }
            }
            Text("Worked out in kosh").font(.system(size: 11, weight: .medium)).foregroundStyle(soft.opacity(0.8))
                .padding(.top, 18)
        }
        .padding(22)
        .frame(width: Self.width, alignment: .leading)
        .background(paper)
        .overlay(alignment: .top) { Rectangle().fill(ink).frame(height: 4) }
        .environment(\.colorScheme, .light)
    }

    static func paid(_ p: SplitPerson) -> String {
        if p.paid > 0 { return "paid " + Fmt.rupees(p.paid) }
        return "paid nothing yet"
    }
    static func share(_ p: SplitPerson) -> String {
        let base: String = "share " + Fmt.rupees(p.share)
        if p.seats > 1 { return base + " · " + Fmt.rupees(ChapterSplit.eachOf(p)) + " each" }
        return base
    }
    /// who pays: a group without names pays each
    static func from(_ m: SplitMove) -> String {
        if m.seats > 1 { return m.from + ", each" }
        return m.from
    }

    /// the card as a picture, sharp on any screen
    @MainActor static func render(_ s: ChapterSplit, ink: Color) -> UIImage? {
        let r = ImageRenderer(content: ChapterSplitCard(split: s, ink: ink))
        r.scale = 3
        return r.uiImage
    }
}
