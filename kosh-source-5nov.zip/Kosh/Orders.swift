import Foundation

/// What each order was (engine/21r-build-orders.js, `snap.orders`): every mail kosh read of it, what it cost as the mail
/// printed it, what was bought (an event, a trip, items, a gift), its tags, and the month in review. Facts beside the
/// payment, never a second figure: only the payment's own amount counts anywhere. Screen-free: the screens and Ask kosh
/// read it through `Store` (Store+Orders.swift); the words are made here so they can be tested without the screens.
struct OrdersBook: Decodable, Hashable {
    /// one mail of the order and the step it is in the order's story
    struct Mail: Decodable, Hashable, Identifiable {
        let id: String
        let d: String
        /// placed · booked · paid · receipt · invoice · fee invoice · shipped · out for delivery · delivery attempted ·
        /// rescheduled · held · delivered · review · cancelled · returned · return pickup booked · return picked up · refund · mail
        let step: String
    }
    /// one line of the bill as printed: k sub · disc · fee · tax · tip · paid; p 1 when it came from a paper (a fee's invoice)
    struct BillLine: Decodable, Hashable {
        let k: String
        let n: String
        let amt: Double
        var p: Int? = nil
    }
    /// an event booked: concert · movie · event
    struct Show: Decodable, Hashable {
        let name: String
        let k: String
        var perf: String? = nil
        var on: String? = nil
        var n: Int? = nil
        var venue: String? = nil
        var city: String? = nil
        var time: String? = nil
        var till: String? = nil
        var tier: String? = nil
    }
    /// a journey or a stay booked (the phone's trip pass)
    struct Trip: Decodable, Hashable {
        var k: String? = nil
        var from: String? = nil
        var to: String? = nil
        var on: String? = nil
        var until: String? = nil
        var place: String? = nil
    }
    struct Gift: Decodable, Hashable {
        var to: String? = nil
    }
    /// what it was, in a word: by kosh · you · learnt
    struct Tag: Decodable, Hashable {
        let t: String
        var w: String? = nil
        let by: String
    }
    struct Order: Decodable, Hashable {
        var o: String? = nil
        var mails: [Mail]? = nil
        var bill: [BillLine]? = nil
        var fees: Double? = nil
        var taxes: Double? = nil
        var disc: Double? = nil
        var show: Show? = nil
        var trip: Trip? = nil
        var gift: Gift? = nil
        var to: String? = nil
        var tags: [Tag]? = nil
        /// the mail each fact came from: bill, paper, show, gift → mail id
        var src: [String: String]? = nil
        /// who told kosh of the payment ("HSBC", "Amazon Pay"), and when none of them is the shop, that the shop mailed
        /// nothing (nm 1) and its name: why no items show (engine details-3nov)
        var by: [String]? = nil
        var nm: Int? = nil
        var shop: String? = nil
    }
    /// the month in review: each figure a sum of payments the ledger counts, the month's spending its one figure
    struct Month: Decodable, Hashable, Identifiable {
        struct Exp: Decodable, Hashable {
            let id: String
            /// Concert · Movie · Event · Travel
            let t: String
            var name: String? = nil
            var perf: String? = nil
            var n: Int? = nil
            var on: String? = nil
            var city: String? = nil
            let amt: Double
        }
        struct GiftLine: Decodable, Hashable {
            let id: String
            let name: String
            var to: String? = nil
            let amt: Double
        }
        struct Gifts: Decodable, Hashable {
            let amt: Double
            let list: [GiftLine]
            /// percent of the month's spending, one decimal
            var share: Double? = nil
        }
        struct Fees: Decodable, Hashable {
            let n: Int
            var fees: Double? = nil
            var taxes: Double? = nil
            var disc: Double? = nil
            /// the orders' payments, for the card's list
            var ids: [String]? = nil
        }
        struct Big: Decodable, Hashable {
            let id: String
            let name: String
            let amt: Double
            let d: String
            var what: String? = nil
        }
        struct Brand: Decodable, Hashable {
            let name: String
            let amt: Double
            let n: Int
            /// its payments that month, for the card's list
            var ids: [String]? = nil
        }
        struct TagSum: Decodable, Hashable {
            let t: String
            let amt: Double
            let n: Int
        }
        /// money sent to family that month: moved, not spent (1 Nov), so never in `spent`
        struct Family: Decodable, Hashable {
            let amt: Double
            let n: Int
            var ids: [String]? = nil
        }
        let m: String
        let from: String
        let to: String
        let spent: Double
        var exp: [Exp]? = nil
        var gifts: Gifts? = nil
        var fees: Fees? = nil
        var big: Big? = nil
        var brands: [Brand]? = nil
        var tags: [TagSum]? = nil
        var family: Family? = nil
        var id: String { m }
    }
    let v: Int
    let pay: [String: Order]
    let months: [Month]

    func month(_ m: String) -> Month? { months.first { $0.m == m } }
}

/// one headline of the month in review: what, the figure, and the payment it opens (if one)
struct ReviewLine: Hashable, Identifiable {
    let id: String
    let sym: String
    let text: String
    var pay: String? = nil
}

enum OrderWords {
    /// "Delivery attempted", "Fee invoice": a step as a person says it
    static func step(_ s: String) -> String {
        switch s {
        case "placed": return "Order placed"
        case "booked": return "Booked"
        case "paid": return "Paid"
        case "receipt": return "Receipt"
        case "invoice": return "Invoice"
        case "fee invoice": return "Fee invoice"
        case "shipped": return "Shipped"
        case "out for delivery": return "Out for delivery"
        case "delivery attempted": return "Delivery attempted"
        case "rescheduled": return "Delivery rescheduled"
        case "held": return "Held for pickup"
        case "delivered": return "Delivered"
        case "review": return "Asked for a review"
        case "cancelled": return "Cancelled"
        case "returned": return "Returned"
        case "return pickup booked": return "Return pickup booked"
        case "return picked up": return "Return picked up"
        case "refund": return "Refund"
        default: return "Mail"
        }
    }
    /// an SF Symbol for a tag
    /// why a payment's card lists nothing bought: "Zepto doesn't email its orders, so what was bought isn't in your mail.
    /// kosh read this payment from HSBC."
    static func noItems(_ o: OrdersBook.Order, payee: String) -> String? {
        let by: [String] = o.by ?? []
        let from: String = by.isEmpty ? "" : " kosh read this payment from " + by.joined(separator: " and ") + "."
        if o.nm == 1 {
            let shop: String = o.shop ?? payee
            return shop + " didn’t email this order, so what was bought isn’t in your mail." + from
        }
        return nil
    }
    static func sym(_ tag: String) -> String {
        switch tag {
        case "Concert": return "music.mic"
        case "Movie": return "film"
        case "Event": return "ticket"
        case "Gift": return "gift"
        case "Travel": return "airplane"
        case "Food": return "fork.knife"
        case "Groceries": return "basket"
        case "Beauty": return "sparkles"
        case "Electronics": return "desktopcomputer"
        case "Fashion": return "tshirt"
        case "Books": return "book"
        default: return "tag"
        }
    }
    /// "Sample Live Concert · 2 tickets · Sat 25 Oct · Chandigarh"
    static func show(_ s: OrdersBook.Show, day: (String) -> String) -> String {
        var parts: [String] = [s.name]
        if let n = s.n, n > 0 { parts.append(n == 1 ? "1 ticket" : String(n) + " tickets") }
        if let on = s.on, !on.isEmpty { parts.append(day(on) + (s.time.map { ", " + $0 } ?? "") + EventWords.countdown(on)) }
        if let c = s.city, !c.isEmpty { parts.append(c) } else if let v = s.venue, !v.isEmpty { parts.append(v) }
        return parts.joined(separator: " · ")
    }
    /// "Pune to Goa · 20 Nov", "Stay in Goa · 20 Nov"
    static func trip(_ t: OrdersBook.Trip, day: (String) -> String) -> String? {
        var head: String
        if let f = t.from, let to = t.to, !f.isEmpty, !to.isEmpty { head = f + " to " + to }
        else if let p = t.place ?? t.to, !p.isEmpty { head = (t.k == "stay" ? "Stay in " : "To ") + p }
        else { return nil }
        if let on = t.on, !on.isEmpty { head += " · " + day(on) }
        return head
    }
    /// the label a bill line's kind goes by, when the line's own name is missing
    static func billName(_ l: OrdersBook.BillLine) -> String {
        if !l.n.isEmpty { return l.n }
        switch l.k {
        case "sub": return "Items"
        case "disc": return "Discount"
        case "fee": return "Fee"
        case "tax": return "Tax"
        case "tip": return "Tip"
        default: return "Paid"
        }
    }

    /// the month's headlines, each figure the engine's, each with its range said once above them (the screen says
    /// "1 – 31 Oct"). `money` writes rupees in the Indian way (₹5,258, ₹1.2L); `day` a day ("6 Feb")
    static func lines(_ r: OrdersBook.Month, money: (Double) -> String, day: (String) -> String) -> [ReviewLine] {
        var out: [ReviewLine] = []
        for e in r.exp ?? [] {
            var t: String = e.t + ": " + (e.perf ?? e.name ?? "")
            if let n = e.n, n > 0 { t += ", " + (n == 1 ? "1 ticket" : String(n) + " tickets") }
            t += ", " + money(e.amt)
            if let on = e.on, !on.isEmpty { t += ", " + day(on) }
            if let c = e.city, !c.isEmpty { t += " in " + c }
            out.append(ReviewLine(id: "exp:" + e.id, sym: sym(e.t), text: t, pay: e.id))
        }
        if let g = r.gifts {
            var t: String = "Gifts " + money(g.amt)
            if let s = g.share { t += " (" + pct(s) + " of the month)" }
            let named: [String] = g.list.prefix(3).map { x in x.name + (x.to.map { " for " + $0 } ?? "") + " " + money(x.amt) }
            if !named.isEmpty { t += ": " + named.joined(separator: ", ") }
            out.append(ReviewLine(id: "gifts", sym: "gift", text: t, pay: g.list.count == 1 ? g.list[0].id : nil))
        }
        if let f = r.fees {
            var bits: [String] = []
            if let x = f.fees, x > 0 { bits.append(money(x) + " in fees") }
            if let x = f.taxes, x > 0 { bits.append(money(x) + " in taxes") }
            if let x = f.disc, x > 0 { bits.append(money(x) + " off") }
            if !bits.isEmpty {
                let on: String = f.n == 1 ? "on 1 order" : "on " + String(f.n) + " orders"
                out.append(ReviewLine(id: "fees", sym: "percent", text: bits.joined(separator: ", ") + " " + on + ", as their bills printed"))
            }
        }
        if let b = r.big {
            let what: String = b.what.map { $0 + " from " + b.name } ?? b.name
            out.append(ReviewLine(id: "big", sym: "star", text: "Biggest new buy: " + what + ", " + money(b.amt) + ", " + day(b.d), pay: b.id))
        }
        if let bs = r.brands, !bs.isEmpty {
            out.append(ReviewLine(id: "brands", sym: "bag", text: "Top brands: " + bs.map { $0.name + " " + money($0.amt) }.joined(separator: ", ")))
        }
        return out
    }
    /// 9.1 → "9.1%", 21.0 → "21%"
    static func pct(_ v: Double) -> String {
        let r: Double = (v * 10).rounded() / 10
        return (r == r.rounded() ? String(Int(r)) : String(r)) + "%"
    }
}
