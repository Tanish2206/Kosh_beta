import SwiftUI

// MARK: - Statements: the newest for each bank or card, open or waiting on its password

struct StatementsGroup: View {
    @Environment(Store.self) private var store
    /// "stmt" for bank accounts, "cardstmt" for cards
    let kind: String
    var bank: String = ""
    var logos: Bool = false
    /// only what needs you (CardShelf: locked or unreadable, in the last 90 days); the rest are under See all.
    /// The Cards page's list; an account's page keeps every statement, with what each closed on
    var needsOnly: Bool = false
    var body: some View {
        let every: [StmtStatus] = Self.shown(store.snap.stmts ?? [], kind: kind, bank: bank, who: store.who)
        let list: [StmtStatus] = needsOnly ? CardShelf.needing(every, today: store.snap.today) : every
        let cards: [CardInfo] = CardShelf.split(store.cards).live
        let banks: [String] = kind == "stmt" ? Self.names(store.accounts) : Self.names(cards)
        let missing: [String] = Self.missing(banks, bank: bank, list: every)
        let allOpen: Bool = needsOnly && list.isEmpty && !every.isEmpty
        if !list.isEmpty || !missing.isEmpty || allOpen {
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    GroupLabel(title: "Statements")
                    Spacer()
                    if store.live != nil {
                        Button("See all") { store.betaSheet = .documents }.font(.footnote.weight(.semibold))
                            .padding(.trailing, 4)
                    }
                }
                ForEach(list) { s in StatementCard(s: s, logos: logos) }
                if allOpen {
                    Text("Nothing here needs you: every statement kosh has is open.")
                        .font(.system(.caption)).foregroundStyle(.secondary).padding(.horizontal, 4).fixedSize(horizontal: false, vertical: true)
                }
                if !missing.isEmpty {
                    Text(Self.missingLine(missing))
                        .font(.system(.caption)).foregroundStyle(.secondary).padding(.horizontal, 4).fixedSize(horizontal: false, vertical: true)
                }
            }
        }
    }
    /// this page's statements: of this kind, whose they are, this bank (or every bank), not an older one
    static func shown(_ all: [StmtStatus], kind: String, bank: String, who: Person) -> [StmtStatus] {
        var out: [StmtStatus] = []
        for s in all {
            if s.kind != kind { continue }
            if s.state == "older" { continue }
            if !bank.isEmpty && s.inst != bank { continue }
            if !who.owns(s.owner) { continue }
            out.append(s)
        }
        return order(out)
    }
    static func names(_ xs: [Account]) -> [String] { var out: [String] = []; for a in xs { out.append(a.bank) }; return out }
    static func names(_ xs: [CardInfo]) -> [String] { var out: [String] = []; for c in xs { out.append(c.bank) }; return out }
    /// banks kosh tracks here that have no statement in the mail yet
    static func missing(_ banks: [String], bank: String, list: [StmtStatus]) -> [String] {
        var seen = Set<String>()
        var out: [String] = []
        for b in banks {
            if seen.contains(b) { continue }
            seen.insert(b)
            if !bank.isEmpty && b != bank { continue }
            var has = false
            for s in list where s.inst == b { has = true }
            if !has { out.append(b) }
        }
        return out.sorted()
    }
    /// waiting on a password first, then by bank, newest first
    static func order(_ xs: [StmtStatus]) -> [StmtStatus] {
        xs.sorted { a, b in
            let la: Int = a.state == "locked" ? 0 : 1
            let lb: Int = b.state == "locked" ? 0 : 1
            if la != lb { return la < lb }
            if a.inst != b.inst { return a.inst < b.inst }
            return a.sent > b.sent
        }
    }
    static func missingLine(_ xs: [String]) -> String {
        let who: String = Self.list(xs)
        return "No statement in your mail yet from " + who + ". Banks email one each month once e-statements are on in their app."
    }
    static func list(_ xs: [String]) -> String {
        if xs.isEmpty { return "" }
        if xs.count == 1 { return xs[0] }
        let head: String = xs.dropLast().joined(separator: ", ")
        let last: String = xs[xs.count - 1]
        return head + " or " + last
    }
}

// MARK: - Shared bits

/// a titled group: a small caps header (with an optional figure on the right) over a rounded block of rows
struct GroupedSection<Content: View>: View {
    let title: String
    let trailing: String?
    @ViewBuilder let content: Content
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text(title.uppercased()).font(.footnote.weight(.semibold)).foregroundStyle(.secondary)
                Spacer()
                if let trailing { Text(trailing).font(.footnote.weight(.semibold)).monospacedDigit().foregroundStyle(.secondary).privacySensitive() }
            }
            .padding(.horizontal, 16)
            VStack(spacing: 0) { content }
                .background(Color.surface, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
        }
    }
}

/// shares of a whole as one thin bar
struct SplitBar: View {
    let parts: [(Color, Double)]
    let grown: Bool
    var height: CGFloat = 8
    var body: some View {
        GeometryReader { g in
            HStack(spacing: 2) {
                ForEach(Array(parts.enumerated()), id: \.offset) { _, p in
                    RoundedRectangle(cornerRadius: 2, style: .continuous).fill(p.0)
                        .frame(width: width(p.1, in: g.size.width))
                }
                Spacer(minLength: 0)
            }
        }
        .frame(height: height)
        .background(Color.primary.opacity(0.06))
        .clipShape(Capsule())
        .accessibilityHidden(true)
    }
    func width(_ share: Double, in w: CGFloat) -> CGFloat {
        let n: Int = parts.count > 1 ? parts.count - 1 : 0
        let gaps: CGFloat = CGFloat(n) * 2
        let grow: CGFloat = grown ? 1 : 0.02
        let x: CGFloat = (w - gaps) * CGFloat(share) * grow
        return x > 2 ? x : 2
    }
}
