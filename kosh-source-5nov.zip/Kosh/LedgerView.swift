import SwiftUI
import Charts

// MARK: - Transactions: every rupee, the cards, the people, the repeats

struct TransactionsView: View {
    @Environment(Store.self) private var store
    var body: some View {
        @Bindable var store = store
        NavigationStack(path: $store.txPath) {
            TransactionsPage()
                .navigationDestination(for: Route.self) { route in RouteDestination(route: route, zoom: nil) }
        }
    }
}

struct TransactionsPage: View {
    @Environment(Store.self) private var store
    var body: some View {
        @Bindable var store = store
        Group {
            switch store.txSub {
            case .all: LedgerList()
            case .accounts: AccountsAndCards()
            case .insights: InsightsView()
            case .lab: AnalyticsLab()
            }
        }
        .subSlide(store.txSub)
        .barFollows()
        .pullForMail(store.live)
        .safeAreaInset(edge: .top, spacing: 0) {
            // on All, the row ends in Find (search and filters); on the others, in Arrange
            SubTabBar(selection: $store.txSub, arrange: .transactions, find: store.txSub == .all ? { store.push(.find) } : nil)
        }
        .tabHeader("Transactions", add: adds)
        // select mode belongs to All: another sub-tab leaves it, with nothing left ticked
        .onChange(of: store.txSub) { _, sub in
            if sub != .all && store.ledgerSelecting { store.ledgerSelecting = false; store.ledgerSelected = [] }
        }
    }

    /// what + adds here: a spend, a split, money lent or borrowed
    var adds: [HeaderAction] {
        let s: Store = store
        return [
            HeaderAction(title: "Add a spend", symbol: "plus.circle") { s.sheet = .add(nil) },
            HeaderAction(title: "Split a bill", symbol: "person.2") { s.sheet = .split(nil) },
            HeaderAction(title: "Lent or borrowed", symbol: "arrow.left.arrow.right") { s.sheet = .lend },
            HeaderAction(title: "Select payments", symbol: "checkmark.circle") { s.txSub = .all; s.ledgerSelected = []; withAnimation(Motion.open) { s.ledgerSelecting = true } },
        ]
    }
}

// MARK: - All: a month at a time, or search everything

struct LedgerList: View {
    @Environment(Store.self) private var store
    /// the tab's intro, once you've closed it: no empty row left where it was
    @AppStorage("intro.transactions") private var introGone = false
    /// what the day lens knows about the list; only the lens reads it, so scrolling never re-renders this view
    @State private var lens = LensTracker()
    /// (smooth-5nov-b) moves the list with the day strip, frame for frame
    @State private var glide = LedgerGlide()

    var body: some View {
        @Bindable var store = store
        let inChapter: Bool = store.ledgerChapter.flatMap { store.trip($0) } != nil
        // worked out once here and shared by the list and the day lens
        let groups: [DayGroup] = inChapter ? [] : store.groups(month: store.ledgerMonth, filter: .all)
        ScrollViewReader { proxy in
            List {
                if let id = store.ledgerChapter, let trip = store.trip(id) {
                    chapterSections(trip)
                } else {
                    monthSections(groups, chips: $store.ledgerMonth)
                }
            }
            .listStyle(.insetGrouped)
            .safeAreaInset(edge: .bottom, spacing: 0) {
                if store.ledgerSelecting { SelectBar() }
            }
            // the month strip sits right under the sub-tab row, and the days follow close behind
            .contentMargins(.top, 4, for: .scrollContent)
            .listSectionSpacing(14)
            .animation(Motion.open, value: store.ledgerMonth)
            .animation(Motion.open, value: store.ledgerChapter)
            // the day lens (Look 4): the month's days as a strip at the bottom edge while you scroll (the tab bar steps
            // out of its way); it follows the list frame by frame, and dragging it jumps the list a day at a time
            .onScrollPhaseChange { _, phase in
                let moving: Bool = phase.isScrolling
                if moving != lens.scrolling { lens.scrolling = moving }
                // (smooth-5nov-c) every frame of the scroll timed, into the diagnostics
                FrameMeter.shared.run(moving, "ledger scroll")
            }
            // straight into the tracker, never into this view's state, so scrolling never re-runs this body
            .onScrollGeometryChange(for: CGFloat.self) { g in g.contentInsets.top } action: { _, inset in lens.listInset(inset) }
            .onScrollGeometryChange(for: CGFloat.self) { g in g.contentOffset.y + g.contentInsets.top } action: { _, y in lens.moved(y) }
            .onGeometryChange(for: CGFloat.self) { g in g.frame(in: .global).minY } action: { y in lens.listFrame(top: y) }
            .onAppear { glide.tracker = lens; lens.glide = glide }
            .onDisappear { glide.stop() }
            .overlay(alignment: .bottom) {
                if !inChapter && !store.ledgerSelecting && groups.count > 1 {
                    DayLens(groups: groups, tracker: lens) { day in
                        // glides there; jumps only when the list can't be moved directly
                        if !glide.go(day) { proxy.scrollTo("lens." + day, anchor: .top) }
                    }
                        // down to the bottom edge, into the room the tab bar leaves
                        .ignoresSafeArea(.container, edges: .bottom)
                }
            }
        }
    }

    /// one chapter's payments, all its days, in place of the month
    @ViewBuilder func chapterSections(_ trip: TripInfo) -> some View {
        let groups: [DayGroup] = TripPage.byDay(store.tripRows(trip.id))
        Section {
            LedgerChapterHeader(trip: trip)
                .listRowInsets(EdgeInsets())
                .listRowBackground(Color.clear)
        }
        if groups.isEmpty {
            ContentUnavailableView("Nothing in it yet", systemImage: "book.pages", description: Text("Put a payment in it from its sheet, under Chapter."))
                .listRowBackground(Color.clear)
        }
        ForEach(groups) { g in
            Section {
                ForEach(g.items) { t in
                    TxRow(t: t, when: Day.time12(t.t), showTrip: false)
                        .modifier(TxSwipes(t: t))
                        .contextMenu {
                            Button(role: .destructive) { store.setTrip(t.id, "none") } label: {
                                Label("Take out of " + trip.name, systemImage: "minus.circle")
                            }
                        }
                }
            } header: {
                DayHeader(label: TripPayments.dayTitle(g.day, trip: trip), total: g.total, share: nil)
            }
        }
    }

    @ViewBuilder func monthSections(_ groups: [DayGroup], chips: Binding<String>) -> some View {
        Section {
            // rows only when they have something in them: an empty row still takes a row's height
            if store.live != nil && !introGone {
                Intro.transactions().listRowInsets(EdgeInsets(top: 0, leading: 0, bottom: 8, trailing: 0)).listRowBackground(Color.clear)
            }
            MonthChips(selection: chips)
                // (finds the List's scroll view for the glide; draws nothing)
                .background(GlideHook(glide: glide))
                .listRowInsets(EdgeInsets())
                .listRowBackground(Color.clear)
                .listRowSeparator(.hidden)
            // the payees kosh couldn't place, named a swipe at a time (TagStackSheet)
            if !store.weeklyToName.isEmpty {
                NameTheseRow()
                    .listRowInsets(EdgeInsets(top: 6, leading: 0, bottom: 4, trailing: 0))
                    .listRowBackground(Color.clear)
                    .listRowSeparator(.hidden)
            }
            // (no "Sort N payments" card here: his call, 30 Oct. Sort these opens from Insights' Miscellaneous up close)
            if !store.tripShare(store.ledgerMonth).list.isEmpty {
                LedgerChapterChips(m: store.ledgerMonth)
                    .listRowBackground(Color.clear)
                    .listRowInsets(EdgeInsets(top: 4, leading: 0, bottom: 2, trailing: 0))
                    .listRowSeparator(.hidden)
            }
        }
        // the first day's heading sits close under the month tiles, not a section's gap away
        .listSectionSpacing(2)
        if groups.isEmpty {
            ContentUnavailableView("Nothing here", systemImage: "tray", description: Text("No payments in \(Day.monthName(store.ledgerMonth))."))
                .listRowBackground(Color.clear)
        }
        // each day's place in the month: the share of the month's spending that had gone out by its end,
        // so the newest day is at 100% and you can see how the month built up to it
        let cum = Self.cumulative(groups)
        ForEach(groups) { g in
            Section {
                ForEach(g.items) { t in
                    Group {
                    if store.ledgerSelecting {
                        // (ticking payments to put in a chapter together: a tap ticks, nothing opens)
                        LedgerPickRow(t: t)
                    } else {
                        TxRow(t: t, when: Day.time12(t.t)).modifier(TxSwipes(t: t))
                            // a hold starts select mode with this payment ticked, as Mail and Files do
                            .contextMenu {
                                if store.live != nil {
                                    Button {
                                        store.ledgerSelected = [t.id]
                                        withAnimation(Motion.open) { store.ledgerSelecting = true }
                                    } label: { Label("Select", systemImage: "checkmark.circle") }
                                }
                            }
                    }
                    }
                }
            } header: {
                DayHeader(label: Day.label(g.day, today: store.snap.today), total: g.total, share: g.items.compactMap { cum[$0.id] }.max())
                    .id("lens." + g.day)
                    // (smooth-5nov) the day lens follows the day headings alone: two to four on screen, where every
                    // payment row used to report its frame on every scroll frame
                    .onGeometryChange(for: CGFloat.self) { p in p.frame(in: .global).minY } action: { y in lens.head(g.day, minY: y) }
                    .onDisappear { lens.headGone(g.day) }
            }
        }
    }

    /// payment id → the share (0…1) of the month's spending that had gone out up to and including it,
    /// in the order the list shows them (newest first), so the newest is 1
    static func cumulative(_ groups: [DayGroup]) -> [String: Double] {
        let spent = groups.flatMap(\.items).filter { $0.sp && $0.a > 0 }
        let total = spent.reduce(0) { $0 + $1.a }
        guard total > 0, spent.count > 1 else { return [:] }
        var out: [String: Double] = [:]
        var sum: Double = 0
        for t in spent.reversed() { sum += t.a; out[t.id] = min(1, sum / total) }
        return out
    }

}

/// a payment in select mode: it reads the ticks itself, so a tick redraws this row and not the whole month's list
private struct LedgerPickRow: View {
    @Environment(Store.self) private var store
    let t: Txn

    var body: some View {
        let on: Bool = store.ledgerSelected.contains(t.id)
        Button {
            if store.ledgerSelected.contains(t.id) { store.ledgerSelected.remove(t.id) } else { store.ledgerSelected.insert(t.id) }
        } label: {
            HStack(spacing: 10) {
                Image(systemName: on ? "checkmark.circle.fill" : "circle")
                    .font(.title3).foregroundStyle(on ? Color.kosh : Color.secondary)
                TxRow(t: t, when: Day.time12(t.t)).allowsHitTesting(false)
            }
        }
        .buttonStyle(.press)
    }
}

/// The months as glass tiles over the list, each with what went out over what came in, so no line of figures is needed
struct MonthChips: View {
    /// the figures' column, wide enough for ₹99.9L at the tile's size, so tiles line up whatever a month spent
    static let figures: CGFloat = 66
    @Environment(Store.self) private var store
    @Environment(\.askKosh) private var askKosh
    @Binding var selection: String
    @Namespace private var glass

    var body: some View {
        ScrollView(.horizontal) {
            GlassEffectContainer(spacing: 10) {
                HStack(spacing: 8) {
                    ForEach(store.snap.months) { mo in tile(mo) }
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 8)
            }
        }
        .scrollIndicators(.hidden)
        .sensoryFeedback(.selection, trigger: selection)
    }

    @ViewBuilder func tile(_ mo: MonthInfo) -> some View {
        let on: Bool = mo.m == selection
        let out: Double = store.total(of: mo)
        let came: Double = store.moneyIn(mo.m)
        let name: String = Day.monthName(mo.m)
        let lit: Glass = on ? Glass.regular.tint(Color.koshFill).interactive() : Glass.regular.interactive()
        Button {
            withAnimation(Motion.base) { selection = mo.m }
        } label: {
            face(mo.short, on: on, out: out, came: came)
        }
        .buttonStyle(.press)
        .glassEffect(lit, in: .capsule)
        .glassEffectID(mo.m, in: glass)
        .contextMenu {
            Button { ask(name) } label: { Label("Ask kosh about " + name, systemImage: "sparkles") }
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(Self.said(name, out: out, came: came))
        .accessibilityAddTraits(on ? .isSelected : [])
    }

    /// the month, a hairline, then what went out over what came in
    func face(_ short: String, on: Bool, out: Double, came: Double) -> some View {
        let ink: Color = on ? Color.onKosh : Color.primary
        let rule: Color = on ? Color.onKosh.opacity(0.4) : Color.primary.opacity(0.16)
        // green for money in; on the lit tile, its ink with a breath of green so it reads on any accent
        let green: Color = on ? Color.onKosh.mix(with: .green, by: 0.22) : Color(light: "#1A7F37", dark: "#5FD38A")
        let inText: String = came > 0 ? Fmt.short(came) : "–"
        return HStack(spacing: 11) {
            Text(short).font(.subheadline.weight(.semibold))
            Capsule().fill(rule).frame(width: 1, height: 26)
            VStack(alignment: .leading, spacing: 1) {
                HStack(spacing: 3) {
                    Image(systemName: "arrow.down").font(.system(.caption2, weight: .heavy))
                    Text(Fmt.short(out)).font(.system(.subheadline, design: .rounded, weight: .bold))
                }
                HStack(spacing: 3) {
                    Image(systemName: "arrow.up").font(.system(size: 9, weight: .heavy))
                    Text(inText).font(.system(.caption, design: .rounded, weight: .semibold))
                }
                .foregroundStyle(green)
            }
            .monospacedDigit()
            .lineLimit(1)
            .minimumScaleFactor(0.7)
            .frame(minWidth: MonthChips.figures, alignment: .leading)
            .privacySensitive()
        }
        .foregroundStyle(ink)
        .padding(.leading, 16)
        .padding(.trailing, 18)
        .frame(height: 52)
        .contentShape(.capsule)
    }

    func ask(_ name: String) {
        let seed: String = "How did " + name + " go? What stood out in my spending compared with usual, and why?"
        if let askKosh { askKosh(seed) } else { store.openAsk(seed) }
    }

    static func said(_ name: String, out: Double, came: Double) -> String {
        var s: String = name + ", " + Fmt.short(out) + " out"
        if came > 0 { s += ", " + Fmt.short(came) + " in" }
        return s
    }
}

struct RecallCard: View {
    @Environment(Store.self) private var store
    let query: String
    let hits: [Txn]

    struct Bar: Identifiable { let short: String; let v: Double; var id: String { short } }

    var body: some View {
        let spend = hits.filter { $0.sp }
        let main = spend.isEmpty ? hits.filter { $0.k == "in" } : spend
        let total = main.reduce(0) { $0 + $1.a }
        let months = store.snap.months.reversed()
        let bars = months.map { mo in Bar(short: mo.short, v: main.filter { $0.d.hasPrefix(mo.m) }.reduce(0) { $0 + $1.a }) }
        let first = main.last
        let active = max(1, months.filter { mo in first.map { mo.m >= String($0.d.prefix(7)) } ?? false }.count)
        VStack(alignment: .leading, spacing: 8) {
            Text("\(spend.isEmpty ? "Came in from" : "Spent on") “\(query)”")
                .font(.subheadline)
                .foregroundStyle(.secondary)
            Text(Fmt.words(total))
                .font(.system(size: 40, weight: .bold, design: .rounded))
                .contentTransition(.numericText(value: total))
                .privacySensitive()
            if let first, let last = main.first {
                Text("\(main.count) time\(main.count == 1 ? "" : "s") since \(Day.fmt(first.d, "d MMM")), about \(Fmt.rupees(Fmt.roundish(total / Double(active)))) a month. Last on \(Day.label(last.d, today: store.snap.today)).")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .privacySensitive()
            }
            Chart(bars) { b in
                BarMark(x: .value("Month", b.short), y: .value("Amount", b.v))
                    .foregroundStyle(Color.kosh.gradient)
                    .cornerRadius(5)
            }
            .chartYAxis(.hidden)
            .frame(height: 110)
            .padding(.top, 6)
        }
        .padding(.vertical, 6)
    }
}


/// a day's heading: the day, what it spent, and how far into the month's spending it had got by then
struct DayHeader: View {
    let label: String
    let total: Double
    var share: Double? = nil
    var body: some View {
        HStack(alignment: .center, spacing: 8) {
            Text(label)
            Spacer()
            if total > 0 { Text(Fmt.rupees(total)).monospacedDigit().privacySensitive() }
            if let f = share {
                let w: CGFloat = max(2, 28 * CGFloat(f))
                let fill: Double = f >= 0.999 ? 0.8 : 0.5
                HStack(spacing: 5) {
                    ZStack(alignment: .leading) {
                        Capsule().fill(Color.primary.opacity(0.22))
                        Capsule().fill(Color.kosh.opacity(fill)).frame(width: w)
                    }
                    .frame(width: 28, height: 4)
                    // small and bold, in the heading's own colour, like the day and its amount beside it
                    Text(Fmt.pct(f)).font(.caption.weight(.semibold)).monospacedDigit()
                        .frame(minWidth: 34, alignment: .trailing)
                }
                .accessibilityElement(children: .ignore)
                .accessibilityLabel(Fmt.pct(f) + " of the month's spending had gone out by the end of this day")
            }
        }
    }
}

/// the chapters a month's payments are in; a tap shows one chapter's payments here
struct LedgerChapterChips: View {
    @Environment(Store.self) private var store
    let m: String
    var body: some View {
        let share: TripShare = store.tripShare(m)
        if !share.list.isEmpty {
            ScrollView(.horizontal) {
                HStack(spacing: 8) {
                    ForEach(share.list) { p in
                        Button { withAnimation(Motion.open) { store.ledgerChapter = p.trip.id } } label: {
                            HStack(spacing: 6) {
                                Image(systemName: p.trip.sym).font(.caption.weight(.bold)).foregroundStyle(p.trip.tint)
                                Text(p.trip.name).font(.caption.weight(.semibold)).lineLimit(1)
                                Text(Fmt.words(p.v)).font(.caption.weight(.semibold)).monospacedDigit().foregroundStyle(.secondary).privacySensitive()
                            }
                            .foregroundStyle(Color.primary)
                            .padding(.horizontal, 11).padding(.vertical, 7)
                            .background(p.trip.tint.opacity(0.13), in: Capsule())
                        }
                        .buttonStyle(.press)
                        .accessibilityHint("Shows this chapter's payments")
                    }
                }
                .padding(.horizontal, 4)
            }
            .scrollIndicators(.hidden)
        }
    }
}

/// a chapter at the top of Transactions: what it cost, the way back to the month, and its own page
struct LedgerChapterHeader: View {
    @Environment(Store.self) private var store
    let trip: TripInfo
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 12) {
                IconTile(symbol: trip.sym, color: trip.tint, size: 40)
                VStack(alignment: .leading, spacing: 1) {
                    Text("CHAPTER").font(.system(.caption2, weight: .semibold)).tracking(1.1).foregroundStyle(trip.tint)
                    Text(trip.name).font(.headline).lineLimit(1)
                    Text(TripWhen.line(trip, today: store.snap.today)).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                }
                Spacer(minLength: 8)
                Button { withAnimation(Motion.open) { store.ledgerChapter = nil } } label: {
                    Image(systemName: "xmark")
                        .font(.footnote.weight(.bold))
                        .foregroundStyle(Color.primary)
                        .frame(width: 30, height: 30)
                        .background(Color(uiColor: .tertiarySystemFill), in: Circle())
                }
                .buttonStyle(.press)
                .accessibilityLabel("Back to the month")
            }
            HStack(alignment: .firstTextBaseline, spacing: 8) {
                Text(Fmt.rupees(trip.total)).font(.system(.title, design: .rounded, weight: .bold)).privacySensitive()
                Text(trip.n == 1 ? "1 payment" : String(trip.n) + " payments").font(.subheadline).foregroundStyle(.secondary)
                Spacer(minLength: 8)
                Button { store.push(.trip(trip.id)) } label: {
                    Label("Its story", systemImage: "book.pages").font(.subheadline.weight(.semibold))
                }
                .buttonStyle(.glass)
            }
        }
        .padding(16)
        .background(trip.tint.opacity(0.1), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
    }
}

/// "This week: 5 to name": the few payees behind the most money of the last 30 days that kosh couldn't place, one
/// swipe each (TagStackSheet). At most five a week, never the whole backlog; "Not now" puts it away for a week.
struct NameTheseRow: View {
    @Environment(Store.self) private var store
    @AppStorage("nameThese.snoozedAt") private var snoozedAt: Double = 0
    var body: some View {
        let few: [PayeeGroup] = store.weeklyToName
        let since: String = Day.add(store.snap.today, -30)
        let total: Double = few.reduce(0) { s, g in g.rows.reduce(s) { $1.d >= since ? $0 + $1.a : $0 } }
        let away: Bool = Date().timeIntervalSince1970 - snoozedAt < 7 * 86_400
        if !few.isEmpty && !away {
            HStack(spacing: 12) {
                Button { store.sheet = .tag } label: {
                    HStack(spacing: 12) {
                        Image(systemName: "questionmark.circle.fill").font(.title2).foregroundStyle(Color.kosh)
                        VStack(alignment: .leading, spacing: 2) {
                            Text(few.count == 1 ? "This week: 1 payee to name" : "This week: \(few.count) payees to name").font(.subheadline.weight(.semibold)).foregroundStyle(.primary)
                            Text(Fmt.words(total) + " in the last 30 days. About a minute.").font(.caption).foregroundStyle(.secondary)
                        }
                        Spacer(minLength: 8)
                    }
                    .contentShape(Rectangle())
                }
                .buttonStyle(.press)
                Button("Not now") { withAnimation(Motion.open) { snoozedAt = Date().timeIntervalSince1970 } }
                    .font(.subheadline).foregroundStyle(.secondary)
                    .buttonStyle(.press)
            }
            .padding(.horizontal, 16).padding(.vertical, 12)
            .background(Color.surface, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        }
    }
}

/// Transactions' select mode: how many are ticked and what they add up to, then what to do with them together: file
/// them (and a sub-category), say whom they were for, or put them in a chapter. A change shows at once with one Undo,
/// and the payments stay ticked, so a category and a "for" can both be set before Done.
struct SelectBar: View {
    @Environment(Store.self) private var store
    /// Split together (GroupSplit.swift): the ticked payments shared out in one go
    @State private var splitting = false
    var body: some View {
        let n: Int = store.ledgerSelected.count
        let rows: [Txn] = store.ledgerSelected.compactMap { store.txn($0) }.sorted { $0.d < $1.d }
        let out: Double = rows.reduce(0) { $1.k == "out" ? $0 + $1.a : $0 }
        let span: String = Store.sortSpan(rows.first?.d ?? "", rows.last?.d ?? "", today: store.snap.today)
        let line: String = (out > 0 ? Fmt.rupees(out) + " out · " : "") + span
        let count: String = n == 1 ? "1 payment" : String(n) + " payments"
        let chapters: [TripInfo] = (store.snap.trips ?? []).sorted { $0.from > $1.from }
        HStack(spacing: 12) {
            Button("Done") { withAnimation(Motion.open) { store.ledgerSelecting = false; store.ledgerSelected = [] } }
                .font(.body.weight(.semibold))
            Spacer(minLength: 8)
            VStack(spacing: 1) {
                Text(n == 0 ? "Tick payments" : count).font(.subheadline.weight(.semibold))
                if n > 0 {
                    Text(line).font(.caption).foregroundStyle(.secondary).privacySensitive()
                }
            }
            .lineLimit(1)
            .minimumScaleFactor(0.8)
            .contentTransition(.numericText())
            Spacer(minLength: 8)
            Menu {
                Section(n == 1 ? "Change this payment" : "Change these " + String(n)) {
                    if store.live != nil { RefileItems(rows: rows) }
                    if store.live != nil && rows.contains(where: { $0.k == "out" }) {
                        Button { splitting = true } label: {
                            Label(n == 1 ? "Split it…" : "Split together…", systemImage: "person.3")
                        }
                    }
                    Menu {
                        ForEach(chapters) { c in
                            Button(c.name) {
                                store.addToTrip(Array(store.ledgerSelected), c.id)
                                withAnimation(Motion.open) { store.ledgerSelecting = false; store.ledgerSelected = [] }
                            }
                        }
                        if chapters.isEmpty { Text("Start a chapter first, in Chapters") }
                    } label: {
                        Label("Add to chapter", systemImage: "book.pages")
                    }
                }
            } label: {
                Label("Change", systemImage: "checklist")
                    .font(.subheadline.weight(.semibold))
                    .padding(.horizontal, 14).padding(.vertical, 9)
                    .background(n > 0 ? Color.kosh : Color.secondary.opacity(0.3), in: Capsule())
                    .foregroundStyle(n > 0 ? Color.onKosh : Color.secondary)
            }
            .disabled(n == 0)
        }
        .padding(.horizontal, 20).padding(.vertical, 12)
        .background(.bar)
        .animation(Motion.base, value: n)
        .sheet(isPresented: $splitting) {
            GroupSplitSheet(ids: Array(store.ledgerSelected))
                .presentationDetents([.large])
        }
    }
}
