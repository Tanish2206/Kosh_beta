import SwiftUI
import UIKit
import Combine

/// kosh, test mode: the family's money from a bundled snapshot of the ledger.
@main
struct KoshApp: App {
    @UIApplicationDelegateAdaptor(KoshAppDelegate.self) private var appDelegate
    @State private var store: Store

    init() {
        // the household, made once; a reminder answered from the Lock Screen works on the same one (Notify), even
        // when iOS starts kosh in the background for it
        // (Perf first: its clock starts here, so "startup · first screen" counts from kosh's first line)
        let s: Store = Perf.shared.measure("startup · store made") { Store() }
        _store = State(initialValue: s)
        Notify.shared.store = s
        // kosh's own crash reports, from iOS on the next launch, for the diagnostics (CrashWatch.swift)
        CrashWatch.shared.start()
        // reading carries on when the phone is locked: the mail still to read is downloaded in the background
        // (BackgroundMail; its session is made again at every launch, so what it brought back while kosh wasn't
        // running is read in), and iOS gives kosh time later to finish a read that was cut short and to look at new
        // mail (BackgroundReading)
        MainActor.assumeIsolated { BackgroundMail.shared.start() }
        BackgroundReading.register()
    }

    var body: some Scene {
        WindowGroup {
            // the tint is the accent; light, dark or the phone's, as Settings › Appearance says (Appearance.swift)
            RootView()
                .environment(store)
                .modifier(LookApplied())
        }
    }
}

/// What SwiftUI's App doesn't hand over: iOS waking kosh because the background downloads have mail for it, and
/// the reminders' buttons and taps, which must have someone to answer them before kosh has finished starting
final class KoshAppDelegate: NSObject, UIApplicationDelegate {
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]? = nil) -> Bool {
        Notify.register()
        return true
    }

    func application(_ application: UIApplication, handleEventsForBackgroundURLSession identifier: String,
                     completionHandler: @escaping () -> Void) {
        guard identifier == BackgroundMail.identifier else { completionHandler(); return }
        // the session (made as kosh launched) hands over what came; this is called once it's all read in
        MainActor.assumeIsolated { BackgroundMail.shared.relaunched(completionHandler) }
    }
}

struct RootView: View {
    @Environment(Store.self) private var store
    @Environment(\.scenePhase) private var scenePhase

    /// one catch-up at a time (kosh coming to the front and its first appearance both ask for one)
    @MainActor static var catching = false

    /// what kosh does when it comes to the front: whatever was cut short last time first, from where it
    /// stopped; then statements (they're quick), then new mail, then the rest of the year if it hasn't finished
    @MainActor
    static func catchUp(_ live: LiveSession) async {
        // the phone's files first: nothing is read or fetched into an empty ledger while they're locked away
        live.reloadIfNeeded()
        guard live.loadedFromDisk, !catching else { return }
        catching = true
        live.note("catch-up: start")
        defer { catching = false; live.note("catch-up: end" + (KeepGoing.shared.stopped ? " (time ran out)" : "")) }
        KeepGoing.shared.begin("Catching up on your mail")
        defer { KeepGoing.shared.end() }
        // a read that was cut short (kosh closed, the phone locked too long) carries on before anything else,
        // whenever the last read of new mail was
        live.note("catch-up: resume plans \(live.plans.keys.sorted().joined(separator: ","))")
        // payments an SMS or a notification handed over while kosh wasn't running: quick, and first
        live.takeAlerts()
        await live.resumeReading()
        if KeepGoing.shared.stopped { return }
        await live.reingestIfRulesChanged()
        if KeepGoing.shared.stopped { return }
        // big emails kept before kosh trimmed their styling, cut before their payment part: fetched once more
        await live.refetchCutMail()
        // (the bookings in the travel mail, for the trips kosh offers as chapters: only the travel mail, once)
        await live.tripPass()
        if KeepGoing.shared.stopped { return }
        // statements read before kosh read them by their columns: opened once more
        live.reopenStatementsIfReaderChanged()
        // statements not opened yet, or locked ones whose sender's password rule hasn't been read
        if live.records.contains(where: { $0.doc?.state == "" || ($0.doc?.state == "locked" && ($0.doc?.hinted ?? 0) < 2) })
            || live.localDocs.contains(where: { $0.state.isEmpty }) || live.pastHoldingsWaiting {
            await live.readDocuments()
        }
        if KeepGoing.shared.stopped { return }
        await live.refreshIfStale()
        if KeepGoing.shared.stopped { return }
        // once, when kosh learns new wallets and shops: their mail from as far back as the rest was read
        if !live.running { await live.findWallets(); await live.findWider() }
        if KeepGoing.shared.stopped { return }
        // shops' order mails whose amount is only in their invoices (Blinkit, Zepto): open those invoices
        if live.records.contains(where: { $0.doc?.kind == "order" && $0.doc?.state == "" }) { await live.readDocuments() }
        if KeepGoing.shared.stopped { return }
        // the last three months first, and the statements found meanwhile opened, then the rest of the year
        if !live.recentIn && !live.backfilling && !live.running {
            await live.backfill(back: LiveSession.recentDays)
            if KeepGoing.shared.stopped { return }
            await live.readDocuments()
            if KeepGoing.shared.stopped { return }
        }
        if !live.backfillDone && !live.backfilling && !live.running { await live.backfill() }
        // anything stopped part-way meanwhile (and given time again since) carries on
        if live.hasPlans && !KeepGoing.shared.stopped { await live.resumeReading() }
    }

    /// kosh is on screen: catch up once set up; during setup, only carry on a first read that was cut short
    @MainActor
    static func cameToFront(_ store: Store) async {
        guard let live = store.live else { return }
        if store.onboarded {
            await catchUp(live)
            // payees the rules couldn't place, named by Claude when it's set up (at most every six hours)
            await KoshAgent.nameUnknown(store)
        }
        else {
            live.reloadIfNeeded()
            if live.hasPlans { await live.resumeReading() }
        }
    }

    var body: some View {
        @Bindable var store = store
        Group {
            if store.glassBar {
                // six tabs, or icons chosen: kosh's own bar, icons alone
                IconTabs()
            } else {
                TabView(selection: $store.tab) {
                    ForEach(store.tabs) { t in
                        Tab(t.title, systemImage: t.symbol, value: t) {
                            TabRoot(tab: t)
                        }
                    }
                }
                .tabBarMinimizeBehavior(.onScrollDown)
                .modifier(PulseAccessory(on: store.tab != .chapters && store.readingShown))
            }
        }
        .redacted(reason: store.hidden ? .privacy : [])
        .sheet(item: $store.sheet) { kind in
            SheetHost(kind: kind)
                .obsidianSheet(ObsidianSheets.on(kind, tab: store.tab))
                .closesForAsk()
                .environment(store)
                .tint(Color.kosh)
                .redacted(reason: store.hidden ? .privacy : [])
        }
        .fullScreenCover(isPresented: Binding(get: { !store.onboarded || store.showcase != nil }, set: { v in
            if !v {
                store.showcase = nil
                store.onboarded = true
            }
        })) {
            OnboardingView(start: store.showcase == .cards ? .privacy : .intro)
                .environment(store)
                .tint(Color.kosh)
        }
        .sheet(item: $store.betaSheet) { kind in
            // the figures in these sheets (what kosh noticed, the threads, accounts, claims, packs, papers, where a
            // figure was read from) hide with the rest. Only views marked privacy-sensitive are hidden, and no text
            // field is one, so the editors stay typeable
            BetaSheetHost(kind: kind)
                .obsidianSheet(ObsidianSheets.on(kind, tab: store.tab))
                .closesForAsk()
                .environment(store)
                .tint(Color.kosh)
                .redacted(reason: store.hidden ? .privacy : [])
        }
        // "Ask kosh about it" from any screen: each sheet on the way closes (closesForAsk), then Ask opens. Set outside
        // the sheets above, so what they show inherits it
        .environment(\.askKosh, AskKoshAction(root: true) { seed, closed in store.openAsk(seed, afterClosing: closed) })
        // (as a spend you add lands, never as the build that counts it lets the figure go back: Store+Shown)
        .sensoryFeedback(.success, trigger: store.added) { (old: Double, new: Double) -> Bool in new > old }
        .onReceive(NotificationCenter.default.publisher(for: .koshShake)) { _ in
            FeedbackPresenter.shared.show(screen: store.screenName)
        }
        // (how long a tab switch keeps the screens busy, and where: the diagnostics' probes)
        .onChange(of: store.tab) { _, t in
            Perf.shared.probe("tab switch")
            Perf.shared.probe("tab switch to " + t.title, seconds: 0)
        }
        .onChange(of: store.tabs) { _, _ in
            if !store.tabs.contains(store.tab) { store.tab = .home }
        }
        // back to the front: new mail since the last read (if it's been a while), and the year
        // carries on filling in where it stopped
        .onChange(of: scenePhase) { old, p in
            // the app switcher's picture of kosh shows no figures, open sheets included
            if p == .active { PrivacyShield.shared.hide() } else { PrivacyShield.shared.show() }
            // leaving kosh with reading under way (the phone locks, you switch apps): kosh's own Lock Screen entry,
            // and the mail still to read handed to the background downloads, both while kosh is still in front
            // (iOS allows neither once it's in the background). The Face ID sheet makes kosh inactive too, and
            // coming back passes through inactive: neither is leaving.
            if p == .inactive && old == .active && !AppLock.shared.authenticating { KeepGoing.shared.leaving() }
            if p == .background {
                AppLock.shared.didHide()
                // the reminders and the widgets now, not on a timer iOS may never let fire
                store.afterBuildNow()
                // what's been read is saved now, with what's still to read; the reading carries on while iOS
                // allows, and iOS is asked for time later to finish it and to look at new mail
                store.live?.checkpointIfReading()
                // and every change made in kosh is on the disk before iOS can stop it
                store.live?.flushSaves()
                // (if the moment above was missed, the hand-over happens now)
                KeepGoing.shared.leaving()
                KeepGoing.shared.toBackground()
                BackgroundReading.leaving(store.live)
            }
            if p == .active {
                Interaction.install()
                AppLock.shared.didShow()
                KeepGoing.shared.backInFront()
                Task { @MainActor in await Self.cameToFront(store) }
            }
        }
        .modifier(UndoBar(lift: 96))
        // (filing a payment outside its sheet still asks before the payee's other payments follow)
        .modifier(ApplyAskOutside())
        // (each sub-tab switch, page and sheet timed as a tab switch is; a view of its own, so the root never redraws
        // for them)
        .background { PerfWatch() }
        // (a light tap under your finger when a change you made shows at once: Store+Shown)
        .background { ShownFeel() }
        .overlay {
            if AppLock.shared.locked { LockScreen(lock: AppLock.shared).transition(.opacity) }
        }
        // locked: nothing stays open above the lock screen
        .onChange(of: AppLock.shared.locked) { _, locked in
            if locked { store.sheet = nil; store.betaSheet = nil }
        }
        .onAppear { AppLock.shared.lockIfOn() }
        // (the reminders and the widgets follow every build from Store.apply, in the background too)
        // amounts hidden or kosh locked: reminders say less from now on, and the ones on the Lock Screen with figures go
        .onChange(of: store.hidden) { _, _ in Reminders.reschedule(store); BriefNotes.reschedule(store) }
        .onChange(of: AppLock.shared.on) { _, _ in Reminders.reschedule(store); BriefNotes.reschedule(store) }
        // a tap on a widget opens the screen it showed
        .onOpenURL { url in WidgetLink.open(url, store) }
        // on opening, too: statements waiting to be read again are read straight away
        .task {
            // opened in front: a Lock Screen entry or downloads left from an earlier run go (the reading carries on
            // here from the plan). Woken by iOS in the background, they're left as they are.
            if UIApplication.shared.applicationState != .background { KeepGoing.shared.backInFront() }
            // kosh's own measure of where the screens wait (Perf.swift: times and names only, into the diagnostics)
            Perf.shared.context = { [weak store] in
                guard let store else { return "" }
                let state: String = UIApplication.shared.applicationState == .active ? "on screen" : UIApplication.shared.applicationState == .background ? "background" : "inactive"
                let live = store.live
                var doing: [String] = []
                if live?.reingesting == true { doing.append("rereading") }
                if live?.running == true { doing.append("reading") }
                if live?.buildRunning == true { doing.append("building") }
                if live?.findingDocs == true || live?.readingDocs == true { doing.append("statements") }
                return state + " · " + store.tab.title + (store.sheet != nil || store.betaSheet != nil ? " + sheet" : "") + (doing.isEmpty ? "" : " · " + doing.joined(separator: ", "))
            }
            Perf.shared.start()
            // the engine for the screens' quick questions, made off the main thread so none of them waits on a build
            Engine.warmQuick()
            // your hands first: kosh's own work waits while you touch the screen (Interaction.swift)
            Interaction.install()
            // turning on Payments by SMS was under way when iOS closed kosh (you were in Shortcuts): back to that step
            if AlertSetup.pendingStage != nil && store.sheet == nil && store.betaSheet == nil { store.betaSheet = .alertsSetup }
            WidgetLink.publish(store)
            // the reminders from the snapshot kosh opened with (a build may not come for a while)
            Reminders.reschedule(store)
            await Self.cameToFront(store)
        }
        // the reader stops when the phone gets warm; once it has cooled, it carries on
        // iOS posts this one off the main thread: it's heard on the main thread, where the screens may change
        .onReceive(NotificationCenter.default.publisher(for: ProcessInfo.thermalStateDidChangeNotification).receive(on: DispatchQueue.main)) { _ in
            guard let live = store.live, live.pausedForHeat else { return }
            Task { @MainActor in
                if LiveSession.coolEnough() && !live.running { live.pausedForHeat = false; live.message = nil; await live.aiPass() }
            }
        }
    }
}

/// Where a tap waits, for the diagnostics: each sub-tab switch, each page opened or closed, each sheet, timed as a tab
/// switch is (Perf.probe: how long until the main thread is free, and with Beta › "Look closely at slow taps" on,
/// where it spent that time); the first screen once a launch. It reads what it watches in its own body, so a switch
/// redraws this empty view and never the root
struct PerfWatch: View {
    @Environment(Store.self) private var store
    var body: some View {
        let pages: Int = store.homePath.count + store.txPath.count + store.portPath.count + store.propPath.count
            + store.commPath.count + store.peoplePath.count + store.insPath.count + store.loanPath.count + store.chapPath.count
        let sheets: Int = (store.sheet == nil ? 0 : 1) + (store.betaSheet == nil ? 0 : 1)
        Color.clear
            .onChange(of: store.homeSub) { _, s in Self.sub("Home", s.title) }
            .onChange(of: store.txSub) { _, s in Self.sub("Transactions", s.title) }
            .onChange(of: store.portSub) { _, s in Self.sub("Wealth", s.title) }
            .onChange(of: store.propSub) { _, s in Self.sub("Property", s.title) }
            .onChange(of: store.commSub) { _, s in Self.sub("Committees", s.title) }
            .onChange(of: pages) { (old: Int, now: Int) in Perf.shared.probe(now > old ? "page opened" : "page closed") }
            .onChange(of: sheets) { (old: Int, now: Int) in Perf.shared.probe(now > old ? "sheet opened" : "sheet closed") }
            .onAppear { Perf.shared.firstScreen() }
    }
    static func sub(_ tab: String, _ title: String) {
        Perf.shared.probe("sub-tab switch")
        Perf.shared.probe("sub-tab " + tab + " › " + title, seconds: 0)
    }
}

/// The light tap you feel when a change you made shows at once (Store.showNow): a view of its own, so the count it
/// watches redraws nothing else
struct ShownFeel: View {
    @Environment(Store.self) private var store
    var body: some View {
        Color.clear.sensoryFeedback(.selection, trigger: store.felt)
    }
}

/// Each tab's own navigation
struct TabRoot: View {
    let tab: AppTab
    var body: some View {
        switch tab {
        case .home: HomeView()
        case .transactions: TransactionsView()
        case .portfolio: PortfolioView()
        case .property: PropertyTabView()
        case .committees: CommitteesTabView()
        case .people: PeopleTabView()
        case .insurance: InsuranceTabView()
        case .loans: LoansTabView()
        case .chapters: ChaptersTabView()
        }
    }
}

/// A module's page without its own navigation: a tab when pinned, pushed from Home when not
struct ModulePage: View {
    let tab: AppTab
    var body: some View {
        Group {
            switch tab {
            case .property: PropertyPage()
            case .committees: CommitteesHome()
            case .people: PeopleView().navigationTitle("People")
            case .insurance: InsuranceBook().navigationTitle("Insurance")
            case .loans: PortfolioPage()
            case .portfolio: PortfolioPage()
            case .transactions: TransactionsPage()
            case .home: HomeOverview(zoom: nil)
            case .chapters: ChaptersHome(zoom: nil, asTab: false)
            }
        }
        // pushed from Home: the page's title sits under the back button, its buttons stay on the top row
        .environment(\.pushedModule, true)
    }
}

struct SheetHost: View {
    @Environment(Store.self) private var store
    let kind: SheetKind
    var body: some View {
        switch kind {
        case .arrange(let t):
            if let first = PlanPage.pages(t).first {
                ArrangeSheet(tab: t, page: PlanPage.showing(t, store) ?? first).presentationDetents([.medium, .large])
            }
        case .tx(let id): TxSheet(id: id, start: store.txStart)
        case .add(let preset): AddSheet(preset: preset).presentationDetents([.large])
        case .tag: TagStackSheet().presentationDetents([.large])
        case .sort: SortSheet().presentationDetents([.large])
        case .dups: DupsSheet().presentationDetents([.medium, .large])
        case .split(let id):
            if let id { AdjustSheet(txID: id).presentationDetents([.large]) } else { SplitSheet(txID: nil).presentationDetents([.large]) }
        case .lend: LendSheet().presentationDetents([.medium, .large])
        case .settings: SettingsView().presentationDetents([.large])
        case .capture(let k): CaptureSheet(kind: k).presentationDetents([.large])
        case .parser: ParserSheet().presentationDetents([.large])
        case .ask: AskSheet().presentationDetents([.large])
        case .tabs: TabBarSheet().presentationDetents([.large])
        }
    }
}

// MARK: Ask kosh, from anywhere

/// "Ask kosh about it" from any screen, a sheet over a sheet included: every sheet on the way closes, then Ask opens
/// with the question ready. RootView sets it; each sheet passes it on with closesForAsk, so a button only calls
/// `askKosh(seed)` and never needs to know how deep it sits. (`closed`: a sheet closed on the way, so Ask waits for it.)
/// (the app's own action is the same every time the root redraws: equal, so a tab switch doesn't redraw every page that
/// holds it. A sheet's, which closes that sheet first, is new each time, as before)
struct AskKoshAction: Equatable {
    var root: Bool = false
    let run: (_ seed: String, _ closed: Bool) -> Void
    func callAsFunction(_ seed: String) { run(seed, false) }
    static func == (a: AskKoshAction, b: AskKoshAction) -> Bool { a.root && b.root }
}

private struct AskKoshKey: EnvironmentKey {
    static var defaultValue: AskKoshAction? { nil }
}

extension EnvironmentValues {
    var askKosh: AskKoshAction? {
        get { self[AskKoshKey.self] }
        set { self[AskKoshKey.self] = newValue }
    }
}

/// on a sheet's content: Ask kosh closes this sheet, then hands on to the ones under it (the store's own, if nothing
/// was handed down)
struct ClosesForAsk: ViewModifier {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.askKosh) private var under
    @Environment(Store.self) private var store: Store?
    func body(content: Content) -> some View {
        content.environment(\.askKosh, AskKoshAction { seed, _ in
            dismiss()
            if let under { under.run(seed, true) } else { store?.openAsk(seed, afterClosing: true) }
        })
    }
}

extension View {
    /// a sheet's content: "Ask kosh about it" inside it closes it first (put before the sheet's .environment(store))
    func closesForAsk() -> some View { modifier(ClosesForAsk()) }
}

extension Store {
    /// Ask opens with `seed` once every sheet is out of the way
    func openAsk(_ seed: String, afterClosing closed: Bool = false) {
        askSeed = seed
        let wait: Bool = closed || sheet != nil || betaSheet != nil
        if sheet != nil { sheet = nil }
        if betaSheet != nil { betaSheet = nil }
        guard wait else { sheet = .ask; return }
        // (a sheet still sliding away can't have another shown over the screen it leaves)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) { [weak self] in self?.sheet = .ask }
    }
}

/// the reading bar over the system tab bar, only while kosh reads: nothing sits over the pages otherwise. Chapters
/// has its own button there, so it steps aside on that tab
struct PulseAccessory: ViewModifier {
    let on: Bool
    func body(content: Content) -> some View {
        if #available(iOS 26.2, *) {
            content.tabViewBottomAccessory(isEnabled: on) { MonthPulse() }
        } else if on {
            content.tabViewBottomAccessory { MonthPulse() }
        } else {
            content
        }
    }
}

extension Store {
    /// what kosh is reading now (and for a moment after, "All caught up"); nil when it isn't
    @MainActor var readingNow: ReadingNow? {
        guard let live, onboarded || live.backfilling else { return nil }
        return ReadingNow.of(live)
    }
    /// whether the reading bar is up, from the reading's switches alone (not its counts), so the tab bar isn't drawn
    /// again for every email read
    @MainActor var readingShown: Bool {
        guard let live, onboarded || live.backfilling else { return false }
        return live.phase == .claude || live.phase == .listing || live.phase == .reading || live.reingesting || live.findingWallets || live.findingDocs
            || live.readingInbox || live.findingWider || live.lookingFor != nil || live.readingDocs || live.backfilling || live.caughtUp != nil
    }
}

/// Above the tab bar while kosh reads: how far it has got. The month itself lives on Home: a bar that stayed over
/// every page hid the rows under it
struct MonthPulse: View {
    @Environment(Store.self) private var store

    var body: some View {
        if let now = store.readingNow { ReadingBar(now: now) }
    }
}

/// The cover over everything kosh shows (sheets too), in a window of its own, while kosh isn't in front
@MainActor
final class PrivacyShield {
    static let shared = PrivacyShield()
    private var window: UIWindow?
    func show() {
        guard window == nil, let scene = UIApplication.shared.connectedScenes.compactMap({ $0 as? UIWindowScene }).first else { return }
        let w = UIWindow(windowScene: scene)
        w.windowLevel = .alert + 2
        w.rootViewController = UIHostingController(rootView: PrivacyCover())
        w.isHidden = false
        window = w
    }
    func hide() {
        window?.isHidden = true
        window = nil
    }
}

/// What the app switcher shows of kosh: its mark on a plain ground, never the figures behind it
struct PrivacyCover: View {
    var body: some View {
        ZStack {
            Color(uiColor: .systemBackground).ignoresSafeArea()
            Image(systemName: "lock.shield.fill").font(.system(size: 44, weight: .semibold)).foregroundStyle(Color.kosh)
        }
        .accessibilityHidden(true)
    }
}

/// The parser check on its own, opened from Home's "Needs you"
struct ParserSheet: View {
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            ParserCheckView()
                .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } } }
        }
    }
}
