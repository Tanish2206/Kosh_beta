import SwiftUI
import Charts

// MARK: - Trips and events
//
// A trip is a second label over the category, never instead of it: fuel bought on a holiday stays
// Transport · Fuel, so a year's fuel stays honest, and it's the holiday's too. A trip has days; while it
// runs, what its people spend goes into it on its own (kosh's guess, taken out with a tap), except what
// belongs to life at home: rent, bills, EMIs, subscriptions, insurance, tax, fees. An event (a wedding,
// a renovation, Diwali) takes only what you put in it. Anything can be put in either by hand: the flights
// booked weeks before. Trips count in spending like anything else, unless you choose Everyday: then the
// months, the charts and the forecast leave them out, so months compare on ordinary life, and each month
// says what it left out. Cash flow and balances keep everything: the money did leave.

/// a trip's share of a month
struct TripPart: Identifiable {
    let trip: TripInfo
    let v: Double
    var id: String { trip.id }
}

/// what a month spent on trips and events: counted in its spending, or left out of it (Everyday), by trip
struct TripShare {
    let inn: Double
    let out: Double
    let list: [TripPart]
}

extension Store {
    var trips: [TripInfo] { snap.trips ?? [] }
    func trip(_ id: String?) -> TripInfo? {
        guard let id, !id.isEmpty else { return nil }
        return trips.first { $0.id == id }
    }
    /// trips and events left out of spending
    var everyday: Bool { live?.everyday ?? (snap.everyday ?? false) }
    func setEveryday(_ on: Bool) { live?.everyday = on }
    /// the trip Home shows: one under way, one starting within a fortnight, or one back within ten days
    var homeTrip: TripInfo? {
        let today: String = snap.today
        if let t = trips.first(where: { $0.state == "now" }) { return t }
        if let t = trips.first(where: { $0.state == "soon" && Day.between(today, $0.from) <= 14 }) { return t }
        return trips.first { t in t.state == "done" && !t.to.isEmpty && Day.between(t.to, today) <= 10 }
    }
    /// put a row in a trip, or ("none") in no trip, whatever its day
    func setTrip(_ id: String, _ trip: String) {
        live?.override(id) { $0.tr = trip }
        live?.rebuildSoon()
    }
    /// a trip found in the mail becomes a chapter: its days, its place, the payments that booked it and what was spent
    /// around it, less any you unticked. Those go in no chapter, so its days don't put them back as kosh's guess
    func startDraft(_ d: TripDraft, skip: Set<String> = []) -> String {
        let id: String = "trip-" + String(UUID().uuidString.prefix(8)).lowercased()
        guard let live else { return id }
        let offered: [String] = d.pay + (d.near ?? [])
        let filed: [String] = offered.filter { !skip.contains($0) }
        let left: [String] = offered.filter { skip.contains($0) }
        // (each saved once, then the chapter, whose saving builds them in together)
        if !filed.isEmpty { live.overrideMany(filed) { $0.tr = id } }
        if !left.isEmpty { live.overrideMany(left) { $0.tr = "none" } }
        var u = UserTrip(id: id, name: d.place + " trip", kind: "trip", from: d.from, to: d.to)
        u.note = d.place
        live.upsertTrip(u)
        return id
    }
    /// what a found trip offers, in the order its sheet lists it: what booked it, forex bought before it, then its days
    func draftRows(_ d: TripDraft) -> [Txn] {
        var out: [Txn] = d.pay.compactMap { txn($0) }
        let near: [Txn] = (d.near ?? []).compactMap { txn($0) }
        out += near.filter { ($0.od ?? $0.d) < d.from }
        out += near.filter { ($0.od ?? $0.d) >= d.from }
        return out
    }
    func addToTrip(_ ids: [String], _ trip: String) {
        for id in ids { live?.override(id) { $0.tr = trip } }
        live?.rebuildSoon()
    }
    /// what kosh put in by its days, kept as yours
    func confirmTrip(_ trip: String) {
        for t in tx where t.tr == trip && t.trg == true { live?.override(t.id) { $0.tr = trip } }
        live?.rebuildSoon()
    }
    /// trips are the household's, like the month figures they sit in
    func tripRows(_ id: String) -> [Txn] { tx.filter { $0.tr == id } }
    func tripShare(_ m: String) -> TripShare {
        if tripShareMemo.gen != txGen { tripShareMemo = (txGen, [:]) }
        if let known = tripShareMemo.by[m] { return known }
        let made: TripShare = makeTripShare(m)
        tripShareMemo.by[m] = made
        return made
    }
    private func makeTripShare(_ m: String) -> TripShare {
        var inn: Double = 0
        var out: Double = 0
        var by: [String: Double] = [:]
        // (the few payments filed to a chapter, picked out of every payment once a build or a change, not once a month)
        if tripTxMemo.gen != txGen { tripTxMemo = (txGen, tx.filter { $0.tr != nil }) }
        for t in tripTxMemo.list where t.d.hasPrefix(m) {
            let left: Bool = t.ev == true
            if !t.sp && !left { continue }
            if t.sp { inn += t.a } else { out += t.a }
            by[t.tr ?? "", default: 0] += t.a
        }
        var list: [TripPart] = []
        for (id, v) in by {
            if let tr = trip(id) { list.append(TripPart(trip: tr, v: v)) }
        }
        list.sort { $0.v > $1.v }
        return TripShare(inn: inn, out: out, list: list)
    }
    func saveTrip(_ t: UserTrip) { live?.upsertTrip(t) }
    /// the chapter goes, its payments back to ordinary spending; Undo puts it back with what was in it
    func deleteTrip(_ id: String) {
        guard let live, let u = live.userTrips.first(where: { $0.id == id }) else { live?.removeTrip(id); return }
        var saved: [String: Override?] = [:]
        for (k, o) in live.overrides where o.tr == id { saved[k] = o }
        live.removeTrip(id)
        undoNote = UndoNote(text: u.name + " deleted") { [weak self] in
            self?.live?.upsertTrip(u)
            self?.restore(saved)
        }
    }
    func userTrip(_ id: String) -> UserTrip? { live?.userTrips.first { $0.id == id } }
}

extension Color {
    /// the colour trips and events wear in charts and on the switch
    static let tripInk: Color = Color(hex: "#FF9F0A")
}

/// when a trip is: "Day 3 of 6 · 2 – 7 Oct", "12 – 18 Nov · in 9 days", "2 – 6 Oct · 5 days"
enum TripWhen {
    static func line(_ t: TripInfo, today: String) -> String {
        if t.from.isEmpty { return t.isEvent ? "No dates" : "No dates yet" }
        let span: String = range(t.from, t.to, today: today)
        if t.state == "now" {
            let day: Int = Day.between(t.from, today) + 1
            if t.to.isEmpty { return "Day " + String(day) + " · since " + Day.fmt(t.from, "d MMM") }
            let all: Int = Day.between(t.from, t.to) + 1
            return "Day " + String(day) + " of " + String(all) + " · " + span
        }
        if t.state == "soon" {
            let n: Int = Day.between(today, t.from)
            let when: String = n == 1 ? "tomorrow" : "in " + String(n) + " days"
            return span + " · " + when
        }
        return span + " · " + days(t.days)
    }
    static func range(_ a: String, _ b: String, today: String) -> String {
        let year: String = a.prefix(4) == today.prefix(4) ? "" : " " + String(a.prefix(4))
        if b.isEmpty || b == a { return Day.fmt(a, "d MMM") + year }
        if a.prefix(7) == b.prefix(7) { return Day.fmt(a, "d") + " – " + Day.fmt(b, "d MMM") + year }
        return Day.fmt(a, "d MMM") + " – " + Day.fmt(b, "d MMM") + year
    }
    static func days(_ n: Int) -> String { n == 1 ? "1 day" : String(n) + " days" }
}

// MARK: on a payment's sheet

struct TripPicker: View {
    @Environment(Store.self) private var store
    let id: String
    @Binding var path: [String]
    @State private var making = false
    /// a chapter swiped to be changed, or to go
    @State private var changing: String?
    @State private var deleting: TripInfo?
    var body: some View {
        let t: Txn? = store.txn(id)
        let current: String? = t?.tr
        let guessed: Bool = t?.trg == true
        let today: String = store.snap.today
        let all: [TripInfo] = store.trips
        List {
            if !all.isEmpty {
                Section {
                    ForEach(all) { trip in
                        Button { pick(trip.id) } label: {
                            TripPickRow(trip: trip, on: current == trip.id, today: today)
                        }
                        .swipeActions(edge: .trailing) {
                            Button(role: .destructive) { deleting = trip } label: { Label("Delete", systemImage: "trash") }
                            Button { changing = trip.id } label: { Label("Edit", systemImage: "pencil") }
                                .tint(Color.kosh)
                        }
                        .contextMenu {
                            Button { changing = trip.id } label: { Label("Edit chapter", systemImage: "pencil") }
                            Button(role: .destructive) { deleting = trip } label: { Label("Delete chapter", systemImage: "trash") }
                        }
                    }
                } footer: {
                    Text(Self.footer(guessed: guessed, name: store.trip(current)?.name))
                }
            }
            Section {
                Button { making = true } label: {
                    Label("Start a chapter", systemImage: "plus.circle.fill")
                }
                if current != nil {
                    Button(role: .destructive) { pick("none") } label: {
                        Label("Not in a chapter", systemImage: "xmark.circle")
                    }
                }
            } footer: {
                if all.isEmpty {
                    Text("A chapter puts a trip's or an event's spending together, on top of each payment's category: a holiday's fuel stays Fuel, and is the holiday's too.")
                }
            }
        }
        .navigationTitle("Chapter")
        .navigationBarTitleDisplayMode(.inline)
        .sheet(isPresented: $making) {
            TripEditor(editing: nil, putIn: id, onSaved: { _ in path = [] })
        }
        .sheet(isPresented: Binding(get: { changing != nil }, set: { if !$0 { changing = nil } })) {
            if let c = changing { TripEditor(editing: c) }
        }
        .confirmationDialog(deleting.map { "Delete " + $0.name + "?" } ?? "", isPresented: Binding(get: { deleting != nil }, set: { if !$0 { deleting = nil } }),
                            titleVisibility: .visible) {
            Button("Delete", role: .destructive) {
                if let d = deleting { withAnimation(Motion.open) { store.deleteTrip(d.id) } }
                deleting = nil
            }
        } message: {
            Text("Its payments stay where they are, back to ordinary spending.")
        }
    }
    func pick(_ trip: String) {
        store.setTrip(id, trip)
        path = []
    }
    static func footer(guessed: Bool, name: String?) -> String {
        if guessed, let name { return "kosh put this in " + name + " because it was spent on its days. Choose another, or take it out." }
        return "The category stays as it is; the chapter is a second label on top. Swipe a chapter to edit or delete it."
    }
}

struct TripPickRow: View {
    let trip: TripInfo
    let on: Bool
    let today: String
    var body: some View {
        HStack(spacing: 12) {
            IconTile(symbol: trip.sym, color: trip.tint, size: 32)
            VStack(alignment: .leading, spacing: 1) {
                Text(trip.name).foregroundStyle(Color.primary)
                Text(TripWhen.line(trip, today: today)).font(.caption).foregroundStyle(.secondary)
            }
            Spacer(minLength: 8)
            if on {
                Image(systemName: "checkmark").font(.footnote.weight(.bold)).foregroundStyle(Color.kosh)
            }
        }
    }
}

// MARK: setting one up

struct TripEditor: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    /// the trip being changed; nil for a new one
    let editing: String?
    /// a payment to put in the new trip
    var putIn: String? = nil
    /// the kind of chapter it was started as, from Chapters
    var preset: ChapterPreset? = nil
    var onSaved: ((String) -> Void)? = nil
    /// a name to start with, from one of Chapters' ideas ("Diwali 2026", "The new car"); yours to change
    var suggested: String = ""
    /// opened from the chapter's own page: deleting it closes that page too
    var fromPage: Bool = false
    @State private var name = ""
    @State private var kind = "trip"
    @State private var sym = "airplane"
    @State private var color = "#FF9500"
    @State private var from = Date()
    @State private var dated = true
    @State private var hasEnd = false
    @State private var to = Date()
    @State private var budget = ""
    @State private var auto = true
    @State private var who: Set<String> = []
    @State private var note = ""
    @State private var loaded = false
    @State private var confirmDelete = false

    /// journeys, then events: every kind of chapter's own icon is here, so changing the look never changes its kind
    static let symbols: [String] = {
        var out: [String] = []
        for s in ChapterKinds.table.map(\.3) + ["figure.hiking", "tram.fill", "sailboat.fill", "tent.fill", "pawprint.fill"] where !out.contains(s) { out.append(s) }
        return out
    }()
    static let colors: [String] = ["#FF9500", "#FF2D55", "#AF52DE", "#007AFF", "#30B0C7", "#34C759", "#A2845E"]

    var isTrip: Bool { kind == "trip" }
    var usesDates: Bool { isTrip || dated }
    var title: String {
        if editing != nil { return name.isEmpty ? "Edit" : name }
        if let p = preset, p.key != "own" { return "New " + p.label.lowercased() }
        return "New chapter"
    }
    var kindBinding: Binding<String> {
        Binding(get: { kind }, set: { k in
            kind = k
            auto = k == "trip"
            if k == "trip" {
                dated = true
                // a journey that sweeps up its days needs a last day, or it takes everything from then on
                if !hasEnd { hasEnd = true; to = Calendar.current.date(byAdding: .day, value: 4, to: from) ?? from }
            }
            if k == "trip" && sym == "sparkles" { sym = "airplane" }
        })
    }

    var body: some View {
        let people: [PersonInfo] = store.snap.people
        let tint: Color = Color(hex: color)
        NavigationStack {
            Form {
                Section {
                    TextField(isTrip ? "Goa with friends, Japan in spring" : "The wedding, Diwali, new kitchen", text: $name)
                    TextField(isTrip ? "Where: Goa, Kyoto" : "Where, if anywhere", text: $note)
                    Picker("Kind", selection: kindBinding) {
                        Text("Journey").tag("trip")
                        Text("Event").tag("event")
                    }
                    .pickerStyle(.segmented)
                } header: {
                    Text("Name")
                } footer: {
                    Text(isTrip ? "A journey has days: what you spend on them goes in on its own." : "An event takes what you put in it: a wedding, a renovation, a festival.")
                }
                Section("Looks") {
                    LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 8), count: 6), spacing: 12) {
                        ForEach(Self.symbols, id: \.self) { s in
                            SymbolDot(sym: s, color: tint, on: s == sym) { sym = s }
                        }
                    }
                    .padding(.vertical, 4)
                    HStack(spacing: 0) {
                        ForEach(Self.colors, id: \.self) { c in
                            ColorDot(color: Color(hex: c), on: c == color) { color = c }
                                .frame(maxWidth: .infinity)
                        }
                    }
                    .padding(.vertical, 4)
                }
                Section {
                    if !isTrip { Toggle("Has dates", isOn: $dated) }
                    if usesDates {
                        DatePicker(isTrip ? "Leaving" : "From", selection: $from, displayedComponents: .date)
                        Toggle(isTrip ? "Back on a set day" : "Ends on a set day", isOn: $hasEnd)
                        if hasEnd {
                            DatePicker(isTrip ? "Back" : "Until", selection: $to, in: from..., displayedComponents: .date)
                        }
                    }
                } header: {
                    Text("When")
                } footer: {
                    if usesDates && !hasEnd { Text("It runs till you set the day it ends.") }
                }
                if usesDates {
                    Section {
                        Toggle("Put spending on these days in it", isOn: $auto)
                        if auto && people.count > 1 {
                            ForEach(people) { p in
                                Button { flip(p.id) } label: {
                                    HStack {
                                        Text(p.name).foregroundStyle(Color.primary)
                                        Spacer()
                                        if who.contains(p.id) {
                                            Image(systemName: "checkmark").font(.footnote.weight(.bold)).foregroundStyle(Color.kosh)
                                        }
                                    }
                                }
                            }
                        }
                    } footer: {
                        Text(auto ? Self.autoNote(people.count > 1) : "Only what you put in it, from each payment's sheet.")
                    }
                }
                Section {
                    HStack(spacing: 4) {
                        Text("₹").foregroundStyle(.secondary)
                        TextField("Budget, if you have one", text: $budget).keyboardType(.numberPad)
                    }
                } footer: {
                    Text("kosh shows what's left of it as you go.")
                }
                if editing != nil {
                    Section {
                        Button(role: .destructive) { confirmDelete = true } label: {
                            Label("Delete chapter", systemImage: "trash")
                        }
                    } footer: {
                        Text("Its payments stay, with their categories; they just aren't in it any more.")
                    }
                }
            }
            .navigationTitle(title)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") { save() }.disabled(name.trimmingCharacters(in: .whitespaces).isEmpty)
                }
            }
            .confirmationDialog("Delete " + name + "?", isPresented: $confirmDelete, titleVisibility: .visible) {
                Button("Delete", role: .destructive) { remove() }
            }
            .onAppear { load() }
        }
    }

    static func autoNote(_ many: Bool) -> String {
        let base: String = "Food, stays, fuel, shopping and the like on these days go in on their own, as kosh's guess. Rent, bills, EMIs, subscriptions, insurance and tax at home stay out. Move anything in or out from its sheet."
        return many ? base + " Only the spending of whoever's ticked goes in." : base
    }
    func flip(_ id: String) {
        if who.contains(id) { who.remove(id) } else { who.insert(id) }
    }
    func load() {
        guard !loaded else { return }
        loaded = true
        let today: Date = Day.date(store.snap.today)
        if let id = editing, let u = store.userTrip(id) {
            name = u.name; kind = u.kind; sym = u.sym; color = u.color; auto = u.auto; who = Set(u.who); note = u.note
            budget = u.budget > 0 ? Fmt.trim(u.budget, 0) : ""
            dated = !u.from.isEmpty
            from = u.from.isEmpty ? today : Day.date(u.from)
            hasEnd = !u.to.isEmpty
            to = u.to.isEmpty ? from : Day.date(u.to)
            return
        }
        from = today
        to = Day.date(Day.add(store.snap.today, 4))
        if let p = preset {
            kind = p.kind
            sym = p.sym
            color = p.color
            auto = p.kind == "trip"
            dated = true
            hasEnd = p.kind == "trip"
        }
        if name.isEmpty { name = suggested }
        // started from a payment: an event that begins on its day and takes only what you put in it (a journey
        // started from a flight booked weeks ago would sweep up every payment since)
        if let p = putIn, let t = store.txn(p) {
            from = Day.date(t.od ?? t.d)
            to = Calendar.current.date(byAdding: .day, value: 4, to: from) ?? from
            if preset == nil { kind = "event"; auto = false; dated = true; hasEnd = false }
        }
        if store.who != .family { who = [store.who.id] } else if let first = store.snap.people.first { who = [first.id] }
    }
    func save() {
        let id: String = editing ?? ("trip-" + String(UUID().uuidString.prefix(8)).lowercased())
        var u = UserTrip(id: id, name: name.trimmingCharacters(in: .whitespacesAndNewlines))
        u.kind = kind
        u.sym = sym
        u.color = color
        u.note = note
        u.from = usesDates ? Day.iso(from) : ""
        u.to = usesDates && hasEnd ? Day.iso(max(from, to)) : ""
        u.budget = TypedAmount.cap(Double(budget.filter { $0.isNumber || $0 == "." }) ?? 0)
        u.auto = usesDates && auto
        u.who = store.snap.people.count > 1 ? Array(who).sorted() : []
        store.saveTrip(u)
        if let p = putIn { store.setTrip(p, id) }
        onSaved?(id)
        dismiss()
    }
    func remove() {
        guard let id = editing else { return }
        store.deleteTrip(id)
        dismiss()
        if fromPage { store.pop() }
    }
}

struct SymbolDot: View {
    let sym: String
    let color: Color
    let on: Bool
    let tap: () -> Void
    var body: some View {
        Button(action: tap) {
            Image(systemName: sym)
                .font(.system(size: 17, weight: .semibold))
                .foregroundStyle(on ? Color.white : color)
                .frame(width: 42, height: 42)
                .background(on ? AnyShapeStyle(color.gradient) : AnyShapeStyle(color.opacity(0.12)), in: Circle())
        }
        .buttonStyle(.press)
        .accessibilityLabel(sym.replacingOccurrences(of: ".fill", with: "").replacingOccurrences(of: ".", with: " "))
    }
}

struct ColorDot: View {
    let color: Color
    let on: Bool
    let tap: () -> Void
    var body: some View {
        Button(action: tap) {
            Circle()
                .fill(color.gradient)
                .frame(width: 28, height: 28)
                .overlay(Circle().stroke(color, lineWidth: on ? 2.5 : 0).padding(-4))
        }
        .buttonStyle(.press)
    }
}

// MARK: everyday spending, and the way in on Home

struct EverydayToggle: View {
    @Environment(Store.self) private var store
    var body: some View {
        Toggle(isOn: Binding(get: { !store.everyday }, set: { v in withAnimation(Motion.open) { store.setEveryday(!v) } })) {
            VStack(alignment: .leading, spacing: 2) {
                Text("Count chapters in monthly spending")
                Text(store.everyday ? "Left out: months show ordinary life" : "Counted, like any spending")
                    .font(.caption).foregroundStyle(.secondary)
            }
        }
    }
}

/// Spending's title line: Chapters on counts trips and events in the months; off leaves them out (Everyday). A hold
/// opens Chapters.
struct ChaptersToggle: View {
    @Environment(Store.self) private var store
    /// what the switch shows while the months catch up: it moves the moment you tap, and the months (a rebuild of
    /// every figure on Home) change once its knob has landed, so the tap never waits on them
    @State private var shown: Bool? = nil
    var body: some View {
        let on: Bool = shown ?? !store.everyday
        Button {
            let next: Bool = !on
            withAnimation(Motion.base) { shown = next }
            Task { @MainActor in
                try? await Task.sleep(for: .milliseconds(260))
                // tapped again meanwhile: that tap's own wait applies it
                guard shown == next else { return }
                var quiet = Transaction(); quiet.disablesAnimations = true
                withTransaction(quiet) { store.live?.everyday = !next }
                shown = nil
            }
        } label: {
            HStack(spacing: 7) {
                Image(systemName: "book.pages")
                    .font(.footnote.weight(.semibold))
                Text("Chapters").font(.footnote.weight(.semibold))
                // a small switch, drawn
                Capsule()
                    .fill(on ? Color.kosh : Color.primary.opacity(0.18))
                    .frame(width: 26, height: 16)
                    .overlay(alignment: on ? .trailing : .leading) {
                        Circle().fill(Color.white).frame(width: 12, height: 12).padding(2)
                            .shadow(color: .black.opacity(0.15), radius: 1, y: 0.5)
                    }
            }
            .foregroundStyle(on ? Color.primary : Color.secondary)
            .padding(.leading, 12).padding(.trailing, 6)
            .frame(height: 32)
            .background(Color.surface, in: Capsule())
            .frame(minHeight: 44)
            .contentShape(Rectangle())
            .animation(Motion.base, value: on)
        }
        .buttonStyle(.press)
        .sensoryFeedback(.selection, trigger: on)
        .contextMenu {
            Button { store.open(.chapters) } label: { Label("Open Chapters", systemImage: "book.pages") }
        }
        .accessibilityLabel("Chapters in spending")
        .accessibilityValue(on ? "Counted" : "Left out")
        .accessibilityAddTraits(.isToggle)
        .accessibilityHint("Counts trips and events in the months, or leaves them out. Hold to open Chapters")
    }
}

/// Home: the chapter under way, about to start, or just back from, drawn as Chapters draws it
struct TripHomeCard: View {
    @Environment(Store.self) private var store
    @Environment(\.colorScheme) private var scheme
    let trip: TripInfo
    var body: some View {
        let today: String = store.snap.today
        let c: Chapter = store.chapterItem(trip)
        let ink: Color = c.inkColor.ink(scheme)
        let state: String = trip.state == "now" ? "Under way" : trip.state == "soon" ? "Coming up" : "Just back"
        VStack(alignment: .leading, spacing: 12) {
            SectionHeader(title: "Chapters", action: "All", onAction: { store.open(.chapters) })
            Button { store.push(.trip(trip.id)) } label: {
                VStack(alignment: .leading, spacing: 14) {
                    HStack(alignment: .top, spacing: 12) {
                        VStack(alignment: .leading, spacing: 0) {
                            Eyebrow(text: "Chapter · " + state, color: ink)
                            Text(trip.name)
                                .font(.title3.weight(.bold))
                                .lineLimit(2)
                                .padding(.top, 4)
                            Text(TripWhen.line(trip, today: today)).font(.subheadline).foregroundStyle(.secondary).lineLimit(1).padding(.top, 2)
                            HStack(alignment: .firstTextBaseline, spacing: 8) {
                                Text(Fmt.rupees(trip.total))
                                    .font(.system(.title, design: .rounded, weight: .bold)).monospacedDigit()
                                    .privacySensitive()
                                Text(Self.side(trip)).font(.subheadline).foregroundStyle(.secondary).lineLimit(1).privacySensitive()
                            }
                            .padding(.top, 12)
                        }
                        Spacer(minLength: 0)
                        StampView(art: c.art, size: 88, rotation: -6)
                            .padding(.top, 14)
                    }
                    if trip.budget > 0 { TripBudget(trip: trip) }
                    if !trip.cats.isEmpty { TripCatChips(cats: Array(trip.cats.prefix(3))) }
                }
                .foregroundStyle(Color.primary)
                .padding(18)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(c.wash(scheme), in: RoundedRectangle(cornerRadius: 26, style: .continuous))
                .overlay(alignment: .topTrailing) {
                    Ribbon().fill(ink).frame(width: 13, height: 28).padding(.trailing, 24)
                }
            }
            .buttonStyle(PulsePress())
        }
    }
    static func side(_ t: TripInfo) -> String {
        if t.n == 0 { return "nothing in it yet" }
        if t.days > 1 && t.total > 0 { return Fmt.words(t.total / Double(t.days)) + " a day" }
        return t.n == 1 ? "1 payment" : String(t.n) + " payments"
    }
}

/// what's spent against the budget, as a thread, and what's left
struct TripBudget: View {
    let trip: TripInfo
    @State private var grown = false
    var body: some View {
        let share: Double = trip.budget > 0 ? min(1, trip.total / trip.budget) : 0
        let over: Bool = trip.total > trip.budget
        let fill: AnyShapeStyle = over ? AnyShapeStyle(Color.orange.gradient) : AnyShapeStyle(trip.tint.gradient)
        VStack(alignment: .leading, spacing: 6) {
            GeometryReader { g in
                ZStack(alignment: .leading) {
                    Capsule().fill(trip.tint.opacity(0.15))
                    Capsule().fill(fill).frame(width: max(6, g.size.width * CGFloat(share) * (grown ? 1 : 0.02)))
                }
            }
            .frame(height: 8)
            Text(Self.line(trip)).font(.footnote.weight(.semibold))
                .foregroundStyle(over ? Color.orange : Color.secondary)
                .privacySensitive()
        }
        .onAppear { withAnimation(Motion.reveal.delay(0.15)) { grown = true } }
    }
    static func line(_ t: TripInfo) -> String {
        let left: Double = t.budget - t.total
        if left >= 0 { return Fmt.rupees(left) + " left of " + Fmt.rupees(t.budget) }
        return Fmt.rupees(-left) + " over the " + Fmt.rupees(t.budget) + " budget"
    }
}

struct TripCatChips: View {
    let cats: [TripInfo.Cat]
    var body: some View {
        HStack(spacing: 6) {
            ForEach(cats) { c in
                HStack(spacing: 5) {
                    Image(systemName: c.sym).font(.caption2.weight(.bold)).foregroundStyle(Color(hex: c.color))
                    Text(Fmt.words(c.v)).font(.caption.weight(.semibold)).monospacedDigit().privacySensitive()
                }
                .padding(.horizontal, 9).padding(.vertical, 5)
                .background(Color(hex: c.color).opacity(0.12), in: Capsule())
                .accessibilityLabel(c.cat)
            }
            Spacer(minLength: 0)
        }
    }
}

// MARK: every trip

struct TripsPage: View {
    @Environment(Store.self) private var store
    @State private var making = false
    /// a trip found in the mail, being looked over
    @State private var draftOpen: TripDraft?
    var body: some View {
        let all: [TripInfo] = store.trips
        let today: String = store.snap.today
        let drafts: [TripDraft] = store.snap.tripDrafts ?? []
        List {
            // trips the bookings in the mail make, first: each opens onto what kosh would file in it
            if !drafts.isEmpty {
                Section {
                    ForEach(drafts) { d in
                        Button { draftOpen = d } label: {
                            TripDraftRow(draft: d).foregroundStyle(Color.primary)
                        }
                        .swipeActions(edge: .trailing) {
                            Button("Not a trip") { withAnimation(Motion.open) { store.live?.dropTripDraft(d.id) } }
                                .tint(Color.secondary)
                        }
                    }
                } header: {
                    Text("Found in your mail")
                } footer: {
                    Text("From your flight, train and stay bookings, with what was spent around them. Look one over, untick anything that wasn't part of it, and make it a chapter.")
                }
            }
            Section {
                EverydayToggle()
            } footer: {
                Text("Off, months, charts and the forecast leave chapters out, so months compare on ordinary life; each month still says what it left out. Cash flow and balances keep everything.")
            }
            ForEach(Self.groups(all), id: \.0) { g in
                Section(g.0) {
                    ForEach(g.1) { t in
                        Button { store.push(.trip(t.id)) } label: {
                            TripListRow(trip: t, today: today).foregroundStyle(Color.primary)
                        }
                    }
                }
            }
            if all.isEmpty {
                Section {
                    VStack(spacing: 12) {
                        Image(systemName: "book.pages").font(.system(.largeTitle, weight: .semibold)).foregroundStyle(Color.tripInk)
                        Text("Put a trip's or an event's spending together").font(.headline)
                        Text("Start a chapter: a journey takes what you spend on its days, an event takes what you put in it. Flights and stays booked before you leave, you add from their sheets.")
                            .font(.subheadline).foregroundStyle(.secondary).multilineTextAlignment(.center)
                        Button { making = true } label: { Text("Start a chapter").font(.body.weight(.semibold)).padding(.horizontal, 8) }
                            .buttonStyle(.glassProminent).koshFilled()
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 18)
                }
            }
        }
        .listStyle(.insetGrouped)
        .navigationTitle("Chapters")
        .toolbar {
            ToolbarItem(placement: .primaryAction) {
                Button { making = true } label: { Image(systemName: "plus") }
                    .accessibilityLabel("Start a chapter")
            }
        }
        .sheet(isPresented: $making) { TripEditor(editing: nil) }
        .modifier(TripDraftPresenter(draft: $draftOpen))
    }
    static func groups(_ all: [TripInfo]) -> [(String, [TripInfo])] {
        let names: [(String, String)] = [("now", "Under way"), ("soon", "Coming up"), ("open", "No dates"), ("done", "Done")]
        var out: [(String, [TripInfo])] = []
        for (k, title) in names {
            let xs: [TripInfo] = all.filter { $0.state == k }
            if !xs.isEmpty { out.append((title, xs)) }
        }
        return out
    }
}

struct TripListRow: View {
    let trip: TripInfo
    let today: String
    var body: some View {
        HStack(spacing: 12) {
            IconTile(symbol: trip.sym, color: trip.tint, size: 38)
            VStack(alignment: .leading, spacing: 2) {
                Text(trip.name).font(.body.weight(.semibold)).lineLimit(1)
                Text(TripWhen.line(trip, today: today)).font(.caption).foregroundStyle(.secondary).lineLimit(1)
            }
            Spacer(minLength: 8)
            VStack(alignment: .trailing, spacing: 2) {
                Text(Fmt.rupees(trip.total)).font(.body.weight(.semibold)).monospacedDigit().privacySensitive()
                if trip.budget > 0 {
                    Text("of " + Fmt.words(trip.budget)).font(.caption).foregroundStyle(trip.total > trip.budget ? Color.orange : Color.secondary)
                }
            }
        }
    }
}

// MARK: one trip

struct TripPage: View {
    @Environment(Store.self) private var store
    let id: String
    @State private var editing = false
    var body: some View {
        if let trip = store.trip(id) {
            content(trip)
        } else {
            ContentUnavailableView("Not here any more", systemImage: "airplane")
        }
    }
    func content(_ trip: TripInfo) -> some View {
        let rows: [Txn] = store.tripRows(trip.id)
        let groups: [DayGroup] = Self.byDay(rows)
        let today: String = store.snap.today
        return ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                TripHero(trip: trip, today: today)
                if trip.guesses > 0 { TripGuessNote(trip: trip) }
                TripTiles(trip: trip)
                if trip.byDay.count > 1 { TripDayChart(trip: trip).card(16) }
                if !trip.cats.isEmpty { TripCats(trip: trip).card(16) }
                if trip.people.count > 1 { TripWho(trip: trip).card(16) }
                if !trip.maybe.isEmpty { TripMaybe(trip: trip) }
                TripPayments(trip: trip, groups: groups)
            }
            .padding(.horizontal, 20)
            .padding(.top, 4)
            .padding(.bottom, 30)
        }
        .navigationTitle(trip.name)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .primaryAction) { Button("Edit") { editing = true } }
        }
        .sheet(isPresented: $editing) { TripEditor(editing: trip.id) }
    }
    /// its payments by the day they happened, newest first
    static func byDay(_ rows: [Txn]) -> [DayGroup] {
        var by: [String: [Txn]] = [:]
        for t in rows { by[t.od ?? t.d, default: []].append(t) }
        var out: [DayGroup] = []
        for (d, xs) in by {
            let counted: [Txn] = xs.filter { $0.sp || $0.ev == true }
            let total: Double = counted.reduce(0) { $0 + $1.a }
            out.append(DayGroup(day: d, items: xs.sorted { $0.t > $1.t }, total: total))
        }
        out.sort { $0.day > $1.day }
        return out
    }
}

struct TripHero: View {
    let trip: TripInfo
    let today: String
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack(spacing: 12) {
                IconTile(symbol: trip.sym, color: trip.tint, size: 48)
                VStack(alignment: .leading, spacing: 2) {
                    Text(trip.name).font(.title3.weight(.bold)).lineLimit(2)
                    Text(TripWhen.line(trip, today: today)).font(.subheadline).foregroundStyle(.secondary)
                }
                Spacer(minLength: 0)
                if trip.state == "now" {
                    HStack(spacing: 6) {
                        Image(systemName: "circle.fill").font(.system(size: 7)).foregroundStyle(Color.green)
                            .symbolEffect(.pulse, options: .repeating)
                        Text("Now")
                    }
                    .font(.footnote.weight(.semibold))
                    .padding(.horizontal, 10).padding(.vertical, 5)
                    .background(Color.raised, in: Capsule())
                }
            }
            VStack(alignment: .leading, spacing: 2) {
                Text(Self.caption(trip)).font(.subheadline.weight(.medium)).foregroundStyle(.secondary)
                Text(Fmt.rupees(trip.total))
                    .font(.system(size: 46, weight: .bold, design: .rounded)).monospacedDigit()
                    .contentTransition(.numericText(value: trip.total))
                    .privacySensitive()
            }
            if trip.budget > 0 { TripBudget(trip: trip) }
        }
        .padding(18)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(LinearGradient(colors: [trip.tint.opacity(0.18), trip.tint.opacity(0.05)], startPoint: .topLeading, endPoint: .bottomTrailing),
                    in: RoundedRectangle(cornerRadius: 26, style: .continuous))
    }
    static func caption(_ t: TripInfo) -> String {
        if t.state == "now" { return "Spent so far" }
        if t.state == "soon" { return "Paid ahead" }
        return t.isEvent ? "What it cost" : "What the trip cost"
    }
}

/// what kosh put in on its own, to keep with one tap
struct TripGuessNote: View {
    @Environment(Store.self) private var store
    let trip: TripInfo
    @State private var review = false
    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: "sparkles").font(.body.weight(.semibold)).foregroundStyle(Color.kosh)
            VStack(alignment: .leading, spacing: 10) {
                Text(Self.line(trip.guesses)).font(.subheadline).fixedSize(horizontal: false, vertical: true)
                HStack(spacing: 10) {
                    Button { review = true } label: {
                        Text("Go through them").font(.subheadline.weight(.semibold))
                    }
                    .buttonStyle(.glassProminent)
                    Button { store.confirmTrip(trip.id) } label: {
                        Text("They're all right").font(.subheadline.weight(.semibold))
                    }
                    .buttonStyle(.glass)
                }
            }
            Spacer(minLength: 0)
        }
        .card(14)
        .sheet(isPresented: $review) { TripReviewSheet(trip: trip).environment(store).presentationDetents([.large]) }
    }
    static func line(_ n: Int) -> String {
        let what: String = n == 1 ? "1 payment" : String(n) + " payments"
        return "kosh put " + what + " in by their dates. Press and hold any that wasn't part of it to take it out."
    }
}

/// a day's cost, the payments, what was paid ahead, what's still to come back
struct TripTiles: View {
    let trip: TripInfo
    var body: some View {
        let tiles: [TripTile] = Self.tiles(trip)
        LazyVGrid(columns: [GridItem(.flexible(), spacing: 10), GridItem(.flexible(), spacing: 10)], spacing: 10) {
            ForEach(tiles) { t in
                VStack(alignment: .leading, spacing: 4) {
                    Label(t.label, systemImage: t.sym).font(.caption.weight(.semibold)).foregroundStyle(t.tint).lineLimit(1)
                    Text(t.value).font(.title3.weight(.bold)).monospacedDigit().lineLimit(1).minimumScaleFactor(0.8).privacySensitive()
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(14)
                .background(Color.surface, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            }
        }
    }
    static func tiles(_ t: TripInfo) -> [TripTile] {
        var out: [TripTile] = []
        if t.days > 0 && t.total > 0 {
            out.append(TripTile(label: "A day", value: Fmt.rupees((t.total / Double(t.days)).rounded()), sym: "sun.max.fill", tint: Color.orange))
        }
        out.append(TripTile(label: "Payments", value: String(t.n), sym: "list.bullet", tint: Color.kosh))
        if t.before > 0 { out.append(TripTile(label: "Paid ahead", value: Fmt.rupees(t.before), sym: "calendar.badge.clock", tint: Color(hex: "#30B0C7"))) }
        if t.rx > 0 { out.append(TripTile(label: "To come back", value: Fmt.rupees(t.rx), sym: "arrow.uturn.backward", tint: Color.green)) }
        return out
    }
}

struct TripTile: Identifiable {
    let label: String
    let value: String
    let sym: String
    let tint: Color
    var id: String { label }
}

/// what each day cost, the average dashed
struct TripDayChart: View {
    let trip: TripInfo
    /// what VoiceOver says of the bars
    static func spoken(_ pts: [TripInfo.DayV], avg: Double) -> String {
        let days: String = SpokenWords.count(pts.count, "day", "days")
        let range: String = SpokenWords.range(pts.map(\.v))
        let usual: String = avg > 0 ? ", about " + Fmt.rupees(avg) + " a day" : ""
        return "What each day cost, " + days + ", " + range + usual
    }
    var body: some View {
        let pts: [TripInfo.DayV] = trip.byDay
        let avg: Double = pts.isEmpty ? 0 : pts.reduce(0) { $0 + $1.v } / Double(pts.count)
        VStack(alignment: .leading, spacing: 10) {
            Text("Day by day").font(.headline)
            Chart {
                ForEach(pts) { p in
                    BarMark(x: .value("Day", Day.date(p.d), unit: .day), y: .value("Spent", p.v))
                        .foregroundStyle(trip.tint.gradient)
                        .cornerRadius(4)
                }
                if avg > 0 && pts.count > 2 {
                    RuleMark(y: .value("Average", avg))
                        .foregroundStyle(Color.secondary.opacity(0.7))
                        .lineStyle(StrokeStyle(lineWidth: 1, dash: [3, 3]))
                }
            }
            .chartYAxis(.hidden)
            .chartXAxis {
                AxisMarks(values: .automatic(desiredCount: 5)) { _ in
                    AxisValueLabel(format: .dateTime.day().month(.abbreviated))
                }
            }
            .frame(height: 140)
            .accessibilityElement(children: .ignore)
            .spokenFigures(Self.spoken(pts, avg: avg), hidden: "What each day cost, " + SpokenWords.count(pts.count, "day", "days"))
        }
    }
}

/// what it went on, biggest first
struct TripCats: View {
    let trip: TripInfo
    var body: some View {
        let top: Double = max(1, trip.cats.first?.v ?? 1)
        VStack(alignment: .leading, spacing: 12) {
            Text("Where it went").font(.headline)
            ForEach(trip.cats) { c in
                VStack(alignment: .leading, spacing: 5) {
                    HStack(spacing: 8) {
                        Image(systemName: c.sym).font(.caption.weight(.bold)).foregroundStyle(Color(hex: c.color)).frame(width: 18)
                        Text(c.cat).font(.subheadline)
                        Spacer(minLength: 8)
                        Text(Fmt.rupees(c.v)).font(.subheadline.weight(.semibold)).monospacedDigit().privacySensitive()
                    }
                    GeometryReader { g in
                        Capsule().fill(Color(hex: c.color).gradient).frame(width: max(4, g.size.width * CGFloat(c.v / top)))
                    }
                    .frame(height: 5)
                    .padding(.leading, 26)
                }
            }
        }
    }
}

/// whose money went on it, when more than one person's did
struct TripWho: View {
    @Environment(Store.self) private var store
    let trip: TripInfo
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Whose money").font(.headline)
            ForEach(trip.people) { p in
                HStack {
                    Text(store.ownerName(p.o)).font(.subheadline)
                    Spacer()
                    Text(Fmt.rupees(p.v)).font(.subheadline.weight(.semibold)).monospacedDigit().privacySensitive()
                }
            }
        }
    }
}

/// travel paid in the weeks before, not in any trip yet: one tap to add
struct TripMaybe: View {
    @Environment(Store.self) private var store
    let trip: TripInfo
    var body: some View {
        let rows: [Txn] = trip.maybe.compactMap { store.txn($0) }
        if !rows.isEmpty {
            VStack(alignment: .leading, spacing: 12) {
                HStack(alignment: .firstTextBaseline) {
                    Text("Booked before you left?").font(.headline)
                    Spacer()
                    Button("Add all") { store.addToTrip(rows.map(\.id), trip.id) }
                        .font(.subheadline.weight(.semibold))
                }
                Text("Travel paid for in the weeks before " + Day.fmt(trip.from, "d MMM") + ", not in any trip yet.")
                    .font(.footnote).foregroundStyle(.secondary)
                ForEach(rows) { t in
                    HStack(spacing: 12) {
                        IconTile(symbol: t.sym, color: store.color(for: t), size: 32)
                        VStack(alignment: .leading, spacing: 1) {
                            Text(t.m).font(.subheadline.weight(.semibold)).oneLineUnlessLarge()
                            Text(store.catLine(t) + " · " + Day.fmt(t.od ?? t.d, "d MMM")).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                        }
                        Spacer(minLength: 8)
                        Text(Fmt.rupees(t.a)).font(.subheadline.weight(.semibold)).monospacedDigit().privacySensitive()
                        Button { store.setTrip(t.id, trip.id) } label: {
                            Image(systemName: "plus.circle.fill").font(.title3).foregroundStyle(trip.tint)
                        }
                        .buttonStyle(.press)
                        .accessibilityLabel("Add to " + trip.name)
                        Button { store.setTrip(t.id, "none") } label: {
                            Image(systemName: "xmark.circle").font(.title3).foregroundStyle(.tertiary)
                        }
                        .buttonStyle(.press)
                        .accessibilityLabel("Not for this trip")
                    }
                }
            }
            .card(16)
        }
    }
}

/// its payments, day by day; press and hold one to take it out
struct TripPayments: View {
    @Environment(Store.self) private var store
    let trip: TripInfo
    let groups: [DayGroup]
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Payments").font(.title3.weight(.bold))
            if groups.isEmpty {
                Text(trip.auto ? "Nothing yet. What's spent on its days comes in on its own; add anything else from its sheet." : "Nothing yet. Add payments from their sheets, under Chapter.")
                    .font(.subheadline).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            }
            ForEach(groups) { g in
                VStack(alignment: .leading, spacing: 10) {
                    HStack {
                        Text(Self.dayTitle(g.day, trip: trip)).font(.subheadline.weight(.semibold))
                        Spacer()
                        Text(Fmt.rupees(g.total)).font(.subheadline.weight(.semibold)).monospacedDigit().foregroundStyle(.secondary).privacySensitive()
                    }
                    VStack(spacing: 14) {
                        ForEach(g.items) { t in
                            TxRow(t: t, when: t.t.isEmpty ? "" : Day.time12(t.t), showTrip: false)
                                .contextMenu {
                                    Button(role: .destructive) { store.setTrip(t.id, "none") } label: {
                                        Label("Take out of " + trip.name, systemImage: "minus.circle")
                                    }
                                }
                        }
                    }
                    .card(14)
                }
            }
        }
    }
    static func dayTitle(_ d: String, trip: TripInfo) -> String {
        let day: String = Day.fmt(d, "EEE d MMM")
        if !trip.from.isEmpty && d < trip.from { return day + " · before" }
        return day
    }
}

/// a month's trips, under its figure: in it, or left out of it
struct TripMonthLine: View {
    @Environment(Store.self) private var store
    let m: String
    var body: some View {
        let share: TripShare = store.tripShare(m)
        if !share.list.isEmpty {
            VStack(alignment: .leading, spacing: 8) {
                Text(Self.line(share)).font(.footnote).foregroundStyle(.secondary).privacySensitive()
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(share.list) { p in
                            Button { store.push(.trip(p.trip.id)) } label: {
                                HStack(spacing: 6) {
                                    Image(systemName: p.trip.sym).font(.caption.weight(.bold)).foregroundStyle(p.trip.tint)
                                    Text(p.trip.name).font(.caption.weight(.semibold)).lineLimit(1)
                                    Text(Fmt.words(p.v)).font(.caption.weight(.semibold)).monospacedDigit().foregroundStyle(.secondary).privacySensitive()
                                }
                                .foregroundStyle(Color.primary)
                                .padding(.horizontal, 10).padding(.vertical, 6)
                                .background(p.trip.tint.opacity(0.12), in: Capsule())
                            }
                            .buttonStyle(.press)
                        }
                    }
                }
            }
        }
    }
    static func line(_ s: TripShare) -> String {
        if s.inn <= 0 && s.out > 0 { return "Everyday spending: " + Fmt.rupees(s.out) + " on chapters left out" }
        return "Takes in " + Fmt.rupees(s.inn) + " on chapters"
    }
    /// the month card's one line: "₹62k of it on Goa", "₹62k on trips left out"
    static func short(_ s: TripShare) -> String {
        var name: String = "chapters"
        if s.list.count == 1, let only = s.list.first { name = only.trip.name }
        if s.inn <= 0 && s.out > 0 { return Fmt.words(s.out) + " on " + name + " left out" }
        return Fmt.words(s.inn) + " of it on " + name
    }
}

/// After a trip: what kosh put in by its days, one card at a time. Swipe right to keep it in the chapter, left to leave
/// it out (or tap the buttons); twenty take under a minute.
struct TripReviewSheet: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    let trip: TripInfo
    @State private var queue: [Txn] = []
    @State private var index = 0
    @State private var drag: CGSize = .zero
    @State private var kept = 0
    @State private var left = 0

    func decide(_ keep: Bool) {
        guard index < queue.count else { return }
        let t = queue[index]
        store.live?.override(t.id) { $0.tr = keep ? trip.id : "none" }
        if keep { kept += 1 } else { left += 1 }
        withAnimation(Motion.open) { drag = .zero; index += 1 }
        if index >= queue.count { store.live?.rebuildSoon() }
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 20) {
                if index < queue.count {
                    Text("\(queue.count - index) to go").font(.subheadline).foregroundStyle(.secondary)
                    ZStack {
                        ForEach(Array(queue.enumerated()).reversed().filter { $0.offset >= index && $0.offset < index + 3 }, id: \.element.id) { i, t in
                            card(t)
                                .offset(i == index ? drag : .zero)
                                .rotationEffect(.degrees(i == index ? Double(drag.width / 18) : 0))
                                .scaleEffect(i == index ? 1 : 1 - CGFloat(i - index) * 0.04)
                                .offset(y: CGFloat(i - index) * 10)
                                .gesture(i == index ? DragGesture()
                                    .onChanged { drag = $0.translation }
                                    .onEnded { v in
                                        if v.translation.width > 110 { decide(true) } else if v.translation.width < -110 { decide(false) } else { withAnimation(Motion.settle) { drag = .zero } }
                                    } : nil)
                        }
                    }
                    .frame(height: 260)
                    HStack(spacing: 16) {
                        Button { decide(false) } label: { Label("Leave out", systemImage: "xmark").frame(maxWidth: .infinity) }
                            .buttonStyle(.glass).controlSize(.large)
                        Button { decide(true) } label: { Label("Keep in", systemImage: "checkmark").frame(maxWidth: .infinity) }
                            .buttonStyle(.glassProminent).controlSize(.large)
                    }
                    .padding(.horizontal, 24)
                } else {
                    Spacer()
                    Image(systemName: "checkmark.circle.fill").font(.system(size: 64)).foregroundStyle(Color.green)
                    Text("All sorted").font(.title2.weight(.semibold))
                    Text("\(kept) kept in \(trip.name), \(left) left out.").foregroundStyle(.secondary)
                    Spacer()
                    Button("Done") { dismiss() }.buttonStyle(.glassProminent).controlSize(.large)
                }
            }
            .padding(.vertical, 24)
            .navigationTitle(trip.name)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Close") { store.live?.rebuildSoon(); dismiss() } } }
        }
        .onAppear { queue = store.tx.filter { $0.tr == trip.id && $0.trg == true }.sorted { $0.d < $1.d } }
        .sensoryFeedback(.selection, trigger: index)
    }

    func card(_ t: Txn) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Image(systemName: t.sym).font(.title2).foregroundStyle(store.color(for: t))
                Spacer()
                Text(Day.fmt(t.d, "EEE d MMM")).font(.subheadline).foregroundStyle(.secondary)
            }
            Spacer(minLength: 0)
            Text(t.m).font(.title3.weight(.semibold)).lineLimit(2)
            Text(Fmt.rupees(t.a)).font(.system(.largeTitle, design: .rounded, weight: .bold)).privacySensitive()
            Text(t.c + (t.s.isEmpty ? "" : " · " + t.s)).font(.subheadline).foregroundStyle(.secondary)
        }
        .padding(20)
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .leading)
        .background(Color.surface, in: RoundedRectangle(cornerRadius: 26, style: .continuous))
        .overlay(alignment: .topLeading) {
            Text(drag.width > 40 ? "KEEP" : drag.width < -40 ? "LEAVE OUT" : "")
                .font(.caption.weight(.heavy)).tracking(1)
                .foregroundStyle(drag.width > 0 ? Color.green : Color.red)
                .padding(14)
        }
        .padding(.horizontal, 24)
    }
}
