import Foundation

// MARK: - Insights' arithmetic, with no screen in it
//
// What Transactions › Insights works out before it draws anything: each month's kinds of spending side by side
// (CatMonths), which months a "usual" is taken over, the one month Where it goes and Up close both look at, what each
// control on the page may choose, and the keep rate's months. The screens (InsightsBook, InsightsCompare,
// InsightsShops) only draw what this says. Foundation only, so engine-test/insights.js compiles it with swiftc beside
// engine-test/insights.swift and holds it to the engine's own months, household by household and person by person (as
// split-ways.js holds SplitWays.swift).

/// spending by category in the months being compared, for whoever is shown
struct CatMonths {
    let months: [String]                    // oldest first; the last may be this month, so far
    let cats: [String]                      // biggest first over the window
    let v: [String: [String: Double]]       // category → month → amount
    let total: [String: Double]             // month → amount
    /// the month the mail starts in, read from a day past the 1st: shown as it is, never a usual month
    var partial: Set<String> = []
    func at(_ c: String, _ m: String) -> Double { v[c]?[m] ?? 0 }
    func sum(_ c: String) -> Double { v[c]?.values.reduce(0, +) ?? 0 }

    /// the last n of these months, its categories ranked over just those: the page works a year out once and
    /// takes its six months from it, rather than going through every payment twice
    /// the last n of these months that end at `ending` (the newest when it isn't one of them)
    func window(_ n: Int, ending: String) -> CatMonths {
        let upTo: [String] = months.filter { $0 <= ending }
        let take: [String] = upTo.isEmpty ? months : upTo
        return window(n, months: Array(take.suffix(max(0, n))))
    }
    func window(_ n: Int) -> CatMonths { window(n, months: Array(months.suffix(max(0, n)))) }
    private func window(_ n: Int, months ms: [String]) -> CatMonths {
        let keep: Set<String> = Set(ms)
        var v2: [String: [String: Double]] = [:]
        for (c, byMonth) in v {
            let kept: [String: Double] = byMonth.filter { keep.contains($0.key) }
            if !kept.isEmpty { v2[c] = kept }
        }
        let t2: [String: Double] = total.filter { keep.contains($0.key) }
        return CatMonths(months: ms, cats: CatMonths.ranked(v2), v: v2, total: t2, partial: partial.intersection(keep))
    }

    /// biggest first; ties by name, so the order holds still from one look to the next
    static func ranked(_ v: [String: [String: Double]]) -> [String] {
        let sums: [String: Double] = v.mapValues { $0.values.reduce(0, +) }
        return v.keys.sorted { a, b in
            let x: Double = sums[a] ?? 0, y: Double = sums[b] ?? 0
            return x != y ? x > y : a < b
        }
    }

    /// made from each month's own kinds and total (Store.catsSpent and Store.spent: money back taken off, for whoever
    /// is shown); a month kosh doesn't have (nil kinds) is left out of the figures, not counted as nothing spent
    static func make(_ months: [String], kinds: (String) -> [String: Double]?, total: (String) -> Double, partial: Set<String>) -> CatMonths {
        var v: [String: [String: Double]] = [:]
        var t: [String: Double] = [:]
        for m in months {
            guard let ks = kinds(m) else { continue }
            for (c, x) in ks where x > 0 { v[InsightsMath.kind(c), default: [:]][m, default: 0] += x }
            let x: Double = total(m)
            if x > 0 { t[m] = x }
        }
        return CatMonths(months: months, cats: ranked(v), v: v, total: t, partial: partial.intersection(Set(months)))
    }
}

enum InsightsMath {
    /// a payment's kind as every part of the page files it: one with none is Other (never "", which is "All" on a chip)
    static func kind(_ c: String) -> String { c.isEmpty ? "Other" : c }

    /// the finished months a usual is taken over: never the running month, never the part-month the mail starts in
    static func usualMonths(_ months: [String], cm: String, partial: Set<String>) -> [String] {
        months.filter { $0 != cm && !partial.contains($0) }
    }

    /// the one month Where it goes and Up close look at: the month picked on All or here ("" is this month) when the
    /// cards have it, else the newest they have
    static func month(_ picked: String, in months: [String], cm: String) -> String {
        let want: String = picked.isEmpty ? cm : picked
        if months.contains(want) { return want }
        return months.last ?? cm
    }

    /// a category's usual month over these months, the empty ones counted (the table's Usual column)
    static func usual(_ c: String, _ data: CatMonths, over: [String]) -> Double {
        guard !over.isEmpty else { return 0 }
        return over.reduce(0) { $0 + data.at(c, $1) } / Double(over.count)
    }
    /// a usual month of all spending over these months (the table's Usual under All spending)
    static func usualTotal(_ data: CatMonths, over: [String]) -> Double {
        guard !over.isEmpty else { return 0 }
        return over.reduce(0) { $0 + (data.total[$1] ?? 0) } / Double(over.count)
    }

    /// how far a finished month's category is from its usual (the other finished months on the cards, empty ones
    /// counted); nil when there's nothing to go by, or the month is the part-month the mail starts in (half a month
    /// set against whole ones says nothing). The running month isn't one: it goes by where the forecast has it heading.
    static func delta(_ c: String, m: String, data: CatMonths, cm: String) -> Double? {
        if m == cm || data.partial.contains(m) { return nil }
        let others: [String] = usualMonths(data.months, cm: cm, partial: data.partial).filter { $0 != m }
        guard !others.isEmpty else { return nil }
        let u: Double = usual(c, data, over: others)
        return u > 0 ? data.at(c, m) / u - 1 : nil
    }

    /// Up close's usual: the average of the finished months the category came up in (its foot says so)
    static func cameUpUsual(_ c: String, _ data: CatMonths, cm: String) -> Double {
        let done: [Double] = usualMonths(data.months, cm: cm, partial: data.partial).map { data.at(c, $0) }.filter { $0 > 0 }
        return done.isEmpty ? 0 : done.reduce(0, +) / Double(done.count)
    }

    /// Up close's stretch: the last n months, ending with the page's month
    static func window(_ all: [String], end: String, n: Int) -> [String] {
        guard !all.isEmpty else { return [] }
        let last: Int = all.lastIndex(of: end) ?? (all.count - 1)
        return Array(all[max(0, last - max(1, n) + 1)...last])
    }

    /// the months side by side: how many the table shows for the number asked, and the numbers its picker offers (none
    /// when there's nothing to choose: one or two months). The picker's label is `shown`, never more than there is.
    static func sideBySide(asked: Int, available: Int) -> (shown: Int, choices: [Int]) {
        let most: Int = min(6, available)
        let shown: Int = max(1, min(max(2, asked), most))
        return (available <= 0 ? 0 : shown, most > 2 ? Array(2...most) : [])
    }

    /// a picker's choice is always one of its own: what was asked when it's there, else the first ("" when there are none)
    static func chosen(_ asked: String, among: [String]) -> String {
        among.contains(asked) ? asked : (among.first ?? "")
    }

    /// a chip row's choices: "" (All) and the kinds that have something, with the one chosen kept even when it has
    /// nothing in these months, so the row always shows what is chosen
    static func chips(_ kinds: [String], chosen: String) -> [String] {
        var out: [String] = [""]
        for k in kinds where !k.isEmpty && !out.contains(k) { out.append(k) }
        if !chosen.isEmpty && !out.contains(chosen) { out.append(chosen) }
        return out
    }

    /// one month of the keep rate's six
    struct KeepMonth: Equatable {
        let m: String; let inn: Double; let kept: Double; let live: Bool; let noPay: Bool; let partial: Bool
    }
    /// the months the keep rate draws, and the ones it leaves out and why: a month whose salary mail never came
    /// (noPay), a month next to nothing came in (under a quarter of the middle month's: between jobs, say, where the
    /// share would read −50,000%), and the part-month the mail starts in (half a month's money says nothing)
    static func keep(_ rows: [KeepMonth]) -> (kept: [KeepMonth], noPay: [String], thin: [String], partial: [String]) {
        let seen: [KeepMonth] = rows.filter { $0.inn > 0 || $0.noPay }
        let part: [KeepMonth] = seen.filter { $0.partial && !$0.noPay }
        let whole: [KeepMonth] = seen.filter { !$0.noPay && !$0.partial }
        let ins: [Double] = whole.map(\.inn).sorted()
        let mid: Double = ins.isEmpty ? 0 : ins[ins.count / 2]
        let kept: [KeepMonth] = whole.filter { $0.inn >= mid * 0.25 }
        let thin: [String] = whole.filter { $0.inn < mid * 0.25 && !$0.live }.map(\.m)
        let noPay: [String] = seen.filter { $0.noPay && !$0.live }.map(\.m)
        return (kept, noPay, thin, part.filter { !$0.live }.map(\.m))
    }
}

/// one app or store, over the months looked at
struct ShopUse: Identifiable {
    let id: String
    var v: Double = 0
    var n: Int = 0
    var avg: Double { n > 0 ? v / Double(n) : 0 }
}

/// spending by app or store, overall or in one category (Where you shop)
struct ShopSplit {
    /// the apps, the most spent first
    let shops: [ShopUse]
    /// everything else in the category: local shops, UPI to people, cash
    let elsewhere: ShopUse
    /// the categories there is app spending in, the most first
    let cats: [String]
    var onApps: Double { shops.reduce(0) { $0 + $1.v } }
    func share(_ s: ShopUse) -> Double { onApps > 0 ? s.v / onApps : 0 }

    /// from the spending payments of the months looked at (each its app, kind and amount): one pass
    static func make(_ rows: [(pf: String, c: String, a: Double)], cat: String) -> ShopSplit {
        var by: [String: ShopUse] = [:]
        var catV: [String: Double] = [:]
        var rest = ShopUse(id: "")
        for t in rows {
            let k: String = InsightsMath.kind(t.c)
            if !t.pf.isEmpty { catV[k, default: 0] += t.a }
            guard cat.isEmpty || k == cat else { continue }
            if t.pf.isEmpty { rest.v += t.a; rest.n += 1; continue }
            var u: ShopUse = by[t.pf] ?? ShopUse(id: t.pf)
            u.v += t.a
            u.n += 1
            by[t.pf] = u
        }
        let shops: [ShopUse] = by.values.filter { $0.v > 0.5 }.sorted { $0.v != $1.v ? $0.v > $1.v : $0.id < $1.id }
        let cats: [String] = catV.filter { $0.value > 0.5 }.sorted { $0.value != $1.value ? $0.value > $1.value : $0.key < $1.key }.map(\.key)
        return ShopSplit(shops: shops, elsewhere: rest, cats: cats)
    }
}
