import SwiftUI

// MARK: - The month in review, one month at a time (find-review, 1 Nov; redrawn in the black look, insights-obsidian)
//
// The months as ObsidianChips (the newest four; older ones under "Earlier"), then the hero: what was spent (the same
// figure Insights shows for that month, Store.spent), how it stands against the usual as a pill (a running month against
// the usual by the same day, and not at all before the 7th), and six months of bars with this one lit. Where it went:
// one bar cut by kind and a row each in the same colours. Then the cards the shops' own mail gave (engine/21r): the
// biggest new buy, the top brands, events and trips, money sent to family (moved, not spent: apart from the figure),
// gifts, fees against discounts. Every card opens its payments. Arithmetic: MonthReviewMath (MonthReview.swift).

/// what one month's page shows, gathered once from the store
struct ReviewMonthData {
    let m: String
    let cm: String
    let from: String
    let to: String
    let spent: Double
    /// the usual it is held against: the usual month, or for a running month the usual by the same day
    let usual: Double?
    /// the day a running month has reached (nil for a whole month)
    let day: Int?
    let bars: [MonthReviewMath.Bar]
    let kinds: [MonthReviewMath.Kind]
    let r: OrdersBook.Month?

    @MainActor static func make(_ store: Store, _ m: String) -> ReviewMonthData {
        let months: [String] = store.snap.months.map(\.m)
        let partial: Set<String> = Set(store.snap.months.filter { $0.partial == true }.map(\.m))
        let cm: String = store.snap.cm
        let spentOf: (String) -> Double = { (x: String) -> Double in store.spent(x) }
        let end: String = Day.monthEnd(m)
        let to: String = end > store.snap.today ? store.snap.today : end
        let mo: MonthInfo? = store.snap.months.first { $0.m == m }
        let cats: [String: Double] = mo.map { store.catsSpent($0) } ?? [:]
        let day: Int? = m == cm ? Day.dayNumber(to) : nil
        let usual: Double? = usualOf(store, m, day: day, months: months, cm: cm, partial: partial)
        return ReviewMonthData(m: m, cm: cm, from: m + "-01", to: to, spent: store.spent(m), usual: usual, day: day,
                               bars: MonthReviewMath.six(m, months: months, cm: cm, partial: partial, spent: spentOf),
                               kinds: MonthReviewMath.kinds(cats),
                               r: store.monthReviews.first { $0.m == m })
    }
    /// the usual it is held against: a running month's by the same day (never a whole month's), a whole month's whole
    @MainActor static func usualOf(_ store: Store, _ m: String, day: Int?, months: [String], cm: String, partial: Set<String>) -> Double? {
        if let d = day {
            let by: (String, Int) -> Double? = { (x: String, n: Int) -> Double? in ReviewMonthData.through(store, x, n) }
            return MonthReviewMath.usualByDay(m, day: d, months: months, cm: cm, partial: partial, through: by)
        }
        let spentOf: (String) -> Double = { (x: String) -> Double in store.spent(x) }
        return MonthReviewMath.usual(m, months: months, cm: cm, partial: partial, spent: spentOf)
    }
    /// a whole month's spending up to a day of it, for whoever is shown (its own day-by-day line)
    @MainActor static func through(_ store: Store, _ m: String, _ day: Int) -> Double? {
        guard let mo = store.snap.months.first(where: { $0.m == m }), let line = store.linePoints(mo), !line.isEmpty else { return nil }
        return line[min(day, line.count) - 1].v
    }
    /// "1 – 31 Oct 2026", "1 – 12 Nov so far", "1 Nov so far"
    var range: String {
        MonthReviewMath.range(from: from, to: to, running: m == cm, day: { (d: String, f: String) -> String in Day.fmt(d, f) })
    }
    var delta: MonthReviewMath.Delta? { MonthReviewMath.delta(spent, usual: usual, day: day, money: Fmt.rupees) }
    /// the kinds as one bar's parts, each in its rank's colour
    var segs: [ObsSegBar.Seg] {
        kinds.enumerated().map { (pair: EnumeratedSequence<[MonthReviewMath.Kind]>.Element) -> ObsSegBar.Seg in
            ObsSegBar.Seg(id: pair.element.cat, v: pair.element.v, tint: ReviewMonthData.tint(pair.element.cat, pair.offset))
        }
    }
    static func tint(_ cat: String, _ i: Int) -> Color { cat == "Everything else" ? Obsidian.ink3 : InsightsInk.kind(i) }
    /// the six bars as the strip draws them
    var strip: [ObsBarStrip.Bar] {
        bars.map { (b: MonthReviewMath.Bar) -> ObsBarStrip.Bar in
            ObsBarStrip.Bar(id: b.m, label: String(Day.monthShort(b.m).prefix(3)).uppercased(), v: b.v, on: b.picked, faint: b.part)
        }
    }
}

/// a delta's colour: more in orange, less in green, about usual grey
func reviewTint(_ d: MonthReviewMath.Delta) -> Color {
    d.dir > 0 ? InsightsInk.more : d.dir < 0 ? InsightsInk.less : Obsidian.ink2
}
func reviewSym(_ d: MonthReviewMath.Delta) -> String {
    d.dir > 0 ? "arrow.up.right" : d.dir < 0 ? "arrow.down.right" : ""
}

/// Insights' section: a dark card that previews the page (the month picked at the top of Insights, else the last whole)
struct MonthReviewSection: View {
    @Environment(Store.self) private var store
    @Environment(\.insightMonth) private var pickedMonth
    var body: some View {
        let months: [String] = store.snap.months.map(\.m)
        let partial: Set<String> = Set(store.snap.months.filter { $0.partial == true }.map(\.m))
        let m: String = pickedMonth.isEmpty ? MonthReviewMath.start(months, cm: store.snap.cm, partial: partial) : pickedMonth
        let d: ReviewMonthData = ReviewMonthData.make(store, m)
        ObsFeatureCard(caption: "Month in review", title: Day.monthName(d.m) + (d.m == d.cm ? ", so far" : ", in review"), chips: Self.chips(d),
                       hint: "Opens one month at a time: what you spent, where it went, the biggest buy, brands, events and fees", tap: { store.push(.review) }) {
            ReviewHeroFigures(d: d, size: 36)
        }
        .privacySensitive()
    }
    /// two or three chips: what most went on, money sent to family, the biggest new buy
    static func chips(_ d: ReviewMonthData) -> [ObsChip] {
        var out: [ObsChip] = []
        if let k = d.kinds.first(where: { $0.cat != "Everything else" }) {
            out.append(ObsChip(id: "top", label: "Most on", value: k.cat, tint: InsightsInk.kind(0)))
        }
        if let f = d.r?.family, f.amt > 0 { out.append(ObsChip(id: "family", label: "To family", value: Fmt.rupees(f.amt), tint: InsightsInk.family)) }
        if let b = d.r?.big { out.append(ObsChip(id: "big", label: "Biggest buy", value: Fmt.rupees(b.amt))) }
        return Array(out.prefix(3))
    }
}

/// the page
struct MonthReviewPage: View {
    @Environment(Store.self) private var store
    @State private var month: String = ""
    var body: some View {
        let months: [String] = store.snap.months.map(\.m)
        let partial: Set<String> = Set(store.snap.months.filter { $0.partial == true }.map(\.m))
        let m: String = month.isEmpty ? MonthReviewMath.start(months, cm: store.snap.cm, partial: partial) : month
        let d: ReviewMonthData = ReviewMonthData.make(store, m)
        ObsScroll(title: "Month in review", inline: false) {
            if months.isEmpty {
                ObsEmpty(title: "Nothing to review yet", sym: "sparkles.rectangle.stack", text: "Months fill in as kosh reads your payments.")
            } else {
                ReviewMonthPills(month: Binding(get: { m }, set: { month = $0 }), months: months, cm: store.snap.cm)
                ReviewHero(d: d)
                ReviewWhere(d: d)
                ReviewHighlights(d: d)
                ObsNote(text: Self.foot(store.who == .family))
            }
        }
        .animation(Motion.base, value: m)
    }
    static func foot(_ family: Bool) -> String {
        "Spent is the same figure Insights shows for the month: card bills paid, money between your own accounts, money sent to family, investments and refunds are never in it." +
            (family ? "" : " The highlights are the household's, read from the shops' own mail.")
    }
}

/// the newest four months as the boxed chips; older months under "Earlier"
struct ReviewMonthPills: View {
    @Binding var month: String
    let months: [String]
    let cm: String
    var body: some View {
        let newest: [String] = months.sorted(by: >)
        let shown: [String] = Array(newest.prefix(4))
        let older: [String] = Array(newest.dropFirst(4))
        HStack(spacing: 8) {
            ObsidianChips(items: shown.map { (x: String) -> (String, String) in (x, Self.name(x, cm: cm)) }, picked: $month)
            if !older.isEmpty { ReviewEarlier(month: $month, older: older, cm: cm) }
        }
    }
    /// "Oct", "Dec 25" (another year)
    static func name(_ m: String, cm: String) -> String {
        m.prefix(4) == cm.prefix(4) ? Day.monthShort(m) : Day.fmt(m + "-01", "MMM yy")
    }
}

struct ReviewEarlier: View {
    @Binding var month: String
    let older: [String]
    let cm: String
    var body: some View {
        let on: Bool = older.contains(month)
        Menu {
            ForEach(older, id: \.self) { (x: String) in
                Button(Day.fmt(x + "-01", "MMMM yyyy")) { withAnimation(Motion.base) { month = x } }
            }
        } label: {
            HStack(spacing: 4) {
                Text(on ? ReviewMonthPills.name(month, cm: cm) : "Earlier").font(.system(size: 13, weight: on ? .semibold : .medium)).lineLimit(1)
                Image(systemName: "chevron.down").font(.caption2.weight(.bold))
            }
            .foregroundStyle(on ? Color.black : Obsidian.ink2)
            .padding(.horizontal, 14)
            .frame(minHeight: 52)
            .background(on ? Obsidian.ink : Obsidian.card, in: Capsule())
            .overlay(Capsule().strokeBorder(Color.white.opacity(0.08), lineWidth: 1))
        }
        .accessibilityLabel("Earlier months")
    }
}

/// the figure, its dates and its pill: the hero's words, shared with Insights' card
struct ReviewHeroFigures: View {
    let d: ReviewMonthData
    var size: CGFloat = 46
    var body: some View {
        let delta: MonthReviewMath.Delta? = d.delta
        VStack(alignment: .leading, spacing: 8) {
            ObsFigure(text: Fmt.rupees(d.spent), size: size)
            Text(d.range).font(.footnote).foregroundStyle(Obsidian.ink2)
            if let delta {
                ViewThatFits(in: .horizontal) {
                    HStack(spacing: 8) { ReviewDeltaPill(delta: delta); ReviewDeltaWords(delta: delta) }
                    VStack(alignment: .leading, spacing: 6) { ReviewDeltaPill(delta: delta); ReviewDeltaWords(delta: delta) }
                }
            }
        }
    }
}

struct ReviewDeltaPill: View {
    let delta: MonthReviewMath.Delta
    var body: some View { ObsPill(text: delta.text, tint: reviewTint(delta), sym: reviewSym(delta)) }
}

struct ReviewDeltaWords: View {
    let delta: MonthReviewMath.Delta
    var body: some View {
        if !delta.against.isEmpty {
            Text(delta.against).font(.caption).foregroundStyle(Obsidian.ink3).fixedSize(horizontal: false, vertical: true)
        }
    }
}

/// spent, against the usual, and six months of bars with this one lit
struct ReviewHero: View {
    let d: ReviewMonthData
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Spent in " + Day.monthName(d.m) + (d.m == d.cm ? " so far" : "")).caption()
            ReviewHeroFigures(d: d)
            if d.bars.count > 1 {
                ObsRule()
                ObsBarStrip(bars: d.strip, height: 56)
                    .accessibilityElement(children: .ignore)
                    .accessibilityLabel("Six months of spending, " + Day.monthName(d.bars.last?.m ?? "") + " last")
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .obsidianCard(24, padding: 18)
        .privacySensitive()
    }
}

/// where it went: one bar cut by kind, and a row a kind in the same colours; tap a row for its payments that month
struct ReviewWhere: View {
    @Environment(Store.self) private var store
    let d: ReviewMonthData
    var body: some View {
        if !d.kinds.isEmpty {
            let most: Double = max(1, d.kinds.map(\.v).max() ?? 1)
            ObsHead(text: "Where it went", trailing: String(d.kinds.filter { $0.cat != "Everything else" }.count) + " kinds")
            VStack(alignment: .leading, spacing: 16) {
                ObsSegBar(segs: d.segs, height: 14)
                ForEach(Array(d.kinds.enumerated()), id: \.element.id) { (pair: EnumeratedSequence<[MonthReviewMath.Kind]>.Element) in
                    Button { open(pair.element.cat) } label: {
                        ObsKindRow(name: pair.element.cat, value: Fmt.rupees(pair.element.v), share: pair.element.v / most,
                                   tint: ReviewMonthData.tint(pair.element.cat, pair.offset), sub: Self.share(pair.element.v, d.spent),
                                   chevron: pair.element.cat != "Everything else")
                    }
                    .buttonStyle(.press)
                    .disabled(pair.element.cat == "Everything else")
                    .obsArrive(pair.offset)
                }
            }
            .obsidianCard(24, padding: 18)
            .privacySensitive()
        }
    }
    /// "32% of the month"
    static func share(_ v: Double, _ total: Double) -> String {
        guard total > 0 else { return "" }
        let p: Int = Int((v / total * 100).rounded())
        return p < 1 ? "under 1% of the month" : String(p) + "% of the month"
    }
    /// the kind's counted payments that month, for whoever is shown, on a page of their own
    private func open(_ c: String) {
        // (and the money back Insights took off this kind that month, so the page adds up to the bar)
        let rows: [Txn] = store.txs(in: d.m)
        let ids: [String] = rows.filter { ($0.sp && InsightsMath.kind($0.c) == c) || ($0.nt == c && ($0.nta ?? 0) > 0) }.map(\.id)
        openReviewPayments(store, ids, c + " · " + Day.monthShort(d.m), d.range)
    }
}

// MARK: the highlights

struct ReviewHighlights: View {
    let d: ReviewMonthData
    var body: some View {
        if let r = d.r {
            ObsHead(text: "Highlights", trailing: Day.monthShort(d.m))
            ReviewHighlightCards(d: d, r: r)
        } else {
            ObsNote(text: "No highlights for " + Day.monthName(d.m) + " yet: they come from the shops’ own mail about what you bought (orders, tickets, bookings).")
        }
    }
}

/// the cards, each only when the month has it (split out so no one body holds them all)
struct ReviewHighlightCards: View {
    let d: ReviewMonthData
    let r: OrdersBook.Month
    var body: some View {
        if let b = r.big { ReviewBigCard(b: b).obsArrive(0) }
        if let bs = r.brands, !bs.isEmpty { ReviewBrandsCard(m: d.m, brands: bs).obsArrive(1) }
        if let ex = r.exp, !ex.isEmpty { ReviewEventsCard(exp: ex).obsArrive(2) }
        if let f = r.family, f.amt > 0 { ReviewFamilyCard(m: d.m, f: f, spent: d.spent).obsArrive(3) }
        if let g = r.gifts { ReviewGiftsCard(g: g).obsArrive(4) }
        if let f = r.fees, ReviewFeesCard.has(f) { ReviewFeesCard(m: d.m, f: f).obsArrive(5) }
    }
}

/// open the payments behind a card: one opens its sheet, more their page (DeepPages.swift PaymentsPage)
@MainActor func openReviewPayments(_ store: Store, _ ids: [String], _ title: String, _ sub: String = "") {
    guard !ids.isEmpty else { return }
    if ids.count == 1 { store.sheet = .tx(ids[0]); return }
    store.push(.payments(title, sub, ids))
}

struct ReviewBigCard: View {
    @Environment(Store.self) private var store
    let b: OrdersBook.Month.Big
    var body: some View {
        Button { store.sheet = .tx(b.id) } label: {
            VStack(alignment: .leading, spacing: 12) {
                ObsCardHead(title: "Biggest new buy", tint: Obsidian.savings)
                Text(b.what ?? b.name).font(.title3.weight(.semibold)).foregroundStyle(Obsidian.ink).lineLimit(3).multilineTextAlignment(.leading)
                HStack(alignment: .firstTextBaseline) {
                    Text((b.what == nil ? "" : b.name + " · ") + Day.fmt(b.d, "d MMM")).font(.footnote).foregroundStyle(Obsidian.ink2).lineLimit(2)
                    Spacer(minLength: 8)
                    ObsFigure(text: Fmt.rupees(b.amt), size: 24)
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .obsidianCard(22, padding: 16)
            .contentShape(Rectangle())
        }
        .buttonStyle(.press)
        .privacySensitive()
    }
}

struct ReviewBrandsCard: View {
    @Environment(Store.self) private var store
    let m: String
    let brands: [OrdersBook.Month.Brand]
    var body: some View {
        let ids: [String] = brands.flatMap { $0.ids ?? [] }
        let most: Double = max(1, brands.map(\.amt).max() ?? 1)
        VStack(alignment: .leading, spacing: 14) {
            Button { openReviewPayments(store, ids, "Top brands · " + Day.monthShort(m)) } label: {
                ObsCardHead(title: "Top brands", tint: Obsidian.property).contentShape(Rectangle())
            }
            .buttonStyle(.press)
            .disabled(ids.isEmpty)
            ForEach(Array(brands.enumerated()), id: \.element.name) { (pair: EnumeratedSequence<[OrdersBook.Month.Brand]>.Element) in
                Button { openReviewPayments(store, pair.element.ids ?? [], pair.element.name + " · " + Day.monthShort(m)) } label: {
                    ReviewBrandRow(b: pair.element, share: pair.element.amt / most, tint: InsightsInk.kind(pair.offset)).contentShape(Rectangle())
                }
                .buttonStyle(.press)
                .disabled((pair.element.ids ?? []).isEmpty)
            }
        }
        .obsidianCard(22, padding: 16)
        .privacySensitive()
    }
}

struct ReviewBrandRow: View {
    let b: OrdersBook.Month.Brand
    let share: Double
    let tint: Color
    var body: some View {
        HStack(spacing: 12) {
            ObsAvatar(text: MonthReviewMath.initials(b.name), tint: tint, size: 34)
            VStack(alignment: .leading, spacing: 6) {
                HStack(alignment: .firstTextBaseline) {
                    Text(b.name).font(.subheadline).foregroundStyle(Obsidian.ink).lineLimit(1)
                    Spacer(minLength: 8)
                    Text(Fmt.rupees(b.amt)).font(.subheadline.weight(.semibold)).monospacedDigit().foregroundStyle(Obsidian.ink)
                }
                ObsTrack(share: share, tint: tint)
                Text(String(b.n) + (b.n == 1 ? " payment" : " payments")).caption()
            }
        }
    }
}

struct ReviewEventsCard: View {
    @Environment(Store.self) private var store
    let exp: [OrdersBook.Month.Exp]
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Button { openReviewPayments(store, exp.map(\.id), "Events and trips") } label: {
                ObsCardHead(title: "Events & trips", tint: Obsidian.term).contentShape(Rectangle())
            }
            .buttonStyle(.press)
            ForEach(Array(exp.enumerated()), id: \.element.id) { (pair: EnumeratedSequence<[OrdersBook.Month.Exp]>.Element) in
                if pair.offset > 0 { ObsRule(inset: 44) }
                Button { store.sheet = .tx(pair.element.id) } label: { ReviewEventRow(e: pair.element) }
                    .buttonStyle(.press)
            }
        }
        .obsidianCard(22, padding: 16)
        .privacySensitive()
    }
}

struct ReviewEventRow: View {
    let e: OrdersBook.Month.Exp
    static func line(_ e: OrdersBook.Month.Exp) -> String {
        var bits: [String] = [e.t]
        if let n = e.n, n > 0 { bits.append(n == 1 ? "1 ticket" : String(n) + " tickets") }
        if let on = e.on, !on.isEmpty { bits.append(Day.fmt(on, "d MMM")) }
        if let c = e.city, !c.isEmpty { bits.append(c) }
        return bits.joined(separator: " · ")
    }
    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: OrderWords.sym(e.t)).font(.subheadline.weight(.semibold)).foregroundStyle(Obsidian.term)
                .frame(width: 32, height: 32).background(Obsidian.term.opacity(0.14), in: RoundedRectangle(cornerRadius: 9, style: .continuous))
            VStack(alignment: .leading, spacing: 2) {
                Text(e.perf ?? e.name ?? e.t).font(.subheadline).foregroundStyle(Obsidian.ink).lineLimit(2)
                Text(Self.line(e)).font(.caption).foregroundStyle(Obsidian.ink2).lineLimit(2)
            }
            Spacer(minLength: 8)
            Text(Fmt.rupees(e.amt)).font(.subheadline.weight(.semibold)).monospacedDigit().foregroundStyle(Obsidian.ink)
        }
        .contentShape(Rectangle())
    }
}

/// money sent to family that month: said apart, because it is moved within the family, never spent
struct ReviewFamilyCard: View {
    @Environment(Store.self) private var store
    let m: String
    let f: OrdersBook.Month.Family
    let spent: Double
    var body: some View {
        Button { openReviewPayments(store, f.ids ?? [], "Sent to family · " + Day.monthShort(m)) } label: {
            VStack(alignment: .leading, spacing: 12) {
                ObsCardHead(title: "Sent to family", tint: InsightsInk.family)
                HStack(alignment: .firstTextBaseline, spacing: 10) {
                    ObsFigure(text: Fmt.rupees(f.amt), size: 30, color: InsightsInk.family)
                    Text(f.n == 1 ? "1 transfer" : String(f.n) + " transfers").font(.footnote).foregroundStyle(Obsidian.ink2)
                }
                Text("Moved within the family, not spent: it is not in the " + Fmt.rupees(spent) + " above.")
                    .font(.footnote).foregroundStyle(Obsidian.ink2).multilineTextAlignment(.leading).fixedSize(horizontal: false, vertical: true)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .obsidianCard(22, padding: 16)
            .contentShape(Rectangle())
        }
        .buttonStyle(.press)
        .disabled((f.ids ?? []).isEmpty)
        .privacySensitive()
    }
}

struct ReviewGiftsCard: View {
    @Environment(Store.self) private var store
    let g: OrdersBook.Month.Gifts
    var body: some View {
        let ids: [String] = g.list.map(\.id)
        Button { openReviewPayments(store, ids, "Gifts") } label: {
            VStack(alignment: .leading, spacing: 12) {
                ObsCardHead(title: "Gifts", tint: Obsidian.property)
                HStack(alignment: .firstTextBaseline, spacing: 10) {
                    ObsFigure(text: Fmt.rupees(g.amt), size: 30)
                    if let s = g.share { Text(OrderWords.pct(s) + " of the month").font(.footnote).foregroundStyle(Obsidian.ink2) }
                }
                Text(g.list.prefix(3).map { (x: OrdersBook.Month.GiftLine) -> String in x.name + (x.to.map { " for " + $0 } ?? "") }.joined(separator: ", "))
                    .font(.footnote).foregroundStyle(Obsidian.ink2).lineLimit(3).multilineTextAlignment(.leading)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .obsidianCard(22, padding: 16)
            .contentShape(Rectangle())
        }
        .buttonStyle(.press)
        .privacySensitive()
    }
}

/// fees and taxes the bills printed, against the discounts they printed: two figures and one bar between them
struct ReviewFeesCard: View {
    @Environment(Store.self) private var store
    let m: String
    let f: OrdersBook.Month.Fees
    static func has(_ f: OrdersBook.Month.Fees) -> Bool { (f.fees ?? 0) + (f.taxes ?? 0) + (f.disc ?? 0) > 0 }
    var body: some View {
        let paid: Double = (f.fees ?? 0) + (f.taxes ?? 0)
        let saved: Double = f.disc ?? 0
        Button { openReviewPayments(store, f.ids ?? [], "Orders with fees · " + Day.monthShort(m)) } label: {
            VStack(alignment: .leading, spacing: 14) {
                ObsCardHead(title: "Fees vs saved", tint: Obsidian.motor)
                HStack(alignment: .top, spacing: 12) {
                    ReviewFigure(label: "Fees & taxes", value: paid > 0 ? Fmt.rupees(paid) : "None", tint: Obsidian.motor)
                    ReviewFigure(label: "Discounts", value: saved > 0 ? Fmt.rupees(saved) : "None", tint: Obsidian.health)
                }
                if paid + saved > 0 {
                    ObsSegBar(segs: [ObsSegBar.Seg(id: "paid", v: paid, tint: Obsidian.motor), ObsSegBar.Seg(id: "saved", v: saved, tint: Obsidian.health)].filter { $0.v > 0 }, height: 8)
                }
                Text("On " + (f.n == 1 ? "1 order" : String(f.n) + " orders") + ", as their bills printed").caption()
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .obsidianCard(22, padding: 16)
            .contentShape(Rectangle())
        }
        .buttonStyle(.press)
        .disabled((f.ids ?? []).isEmpty)
        .privacySensitive()
    }
}

struct ReviewFigure: View {
    let label: String
    let value: String
    let tint: Color
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(label).caption()
            Text(value).font(.system(.title3, design: .rounded, weight: .semibold)).monospacedDigit().foregroundStyle(tint).lineLimit(1).minimumScaleFactor(0.6)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}
