import Foundation

// MARK: - Saved files that survive updates
//
// Every file that holds the household's book carries the version of its shape, so an updated kosh opens what an older
// one wrote, in every shape there has ever been, and loses nothing. A file starts with its head, written in this order
// by hand (JSONEncoder doesn't promise an order), so the version is read off the first bytes without reading the rest:
//
//     {"kosh":"<file>","v":<version>, …the object's own members…}       its own keys (File.ownKeys)
//     {"kosh":"<file>","v":<version>,"body":<what the file holds>}       in an envelope (the rest)
//
// A file keeps the head as its own first keys where an older kosh would read the file anyway: what you set (the
// profile, the claims) and each sealed mail. An older kosh ignores keys it doesn't know, so a build put back (a
// TestFlight build, an older branch built on the Mac) still reads them whole; in an envelope its decoder would have
// found nothing it knows, taken that as empty, and saved the empty book over yours. A list, a map of items, or a body
// that already has a "v" of its own goes in an envelope: an older kosh fails to read it outright, sets it aside and
// reads again from the inbox (records, decisions) or makes it again (the plans, trip legs, the screens, the reader's
// templates). A file with no head was written before versions (27 Oct 2026): it is version 0 and all of it is its body.
//
// Opening a file brings its body up to today's shape one step at a time (`step`), then decodes it as before, item by
// item (LiveSession.Lossy). A file written by a newer kosh is read as well as this one can, and its reader keeps a copy
// aside before writing over it. The next save of a file writes today's shape.
//
// To change what a file holds: raise its version, add the step that turns the last shape's body into the new one (a
// field renamed moved across, a value said the new way) and keep that step for good, and freeze an invented file of
// the new shape in engine-test/saved/ (engine-test/saved-files.js opens every one of them and checks nothing is lost).
// Screen-free (Foundation only): engine-test/saved-files.swift compiles it with swiftc on the Mac.

enum SavedFormat {
    /// the files of the book, each with the version of the shape written today
    enum File: String, CaseIterable {
        case records, profile, plans, snapshot, tripLegs, decisions, claims, layouts, mail

        /// the shape written today. Version 1 (27 Oct 2026) gave each file its head; what each holds didn't change
        var version: Int {
            switch self {
            case .records, .profile, .plans, .snapshot, .tripLegs, .decisions, .claims, .layouts, .mail: return 1
            }
        }

        /// the head as the object's own first keys (an older kosh reads the file whole), rather than an envelope
        var ownKeys: Bool {
            switch self {
            case .profile, .claims, .mail: return true
            case .records, .plans, .snapshot, .tripLegs, .decisions, .layouts: return false
            }
        }

        /// where it lives in kosh's folder
        var name: String {
            switch self {
            case .records: return "records.json"
            case .profile: return "profile.json"
            case .plans: return "reading.json"
            case .snapshot: return "snapshot.json"
            case .tripLegs: return "tripLegs.json"
            case .decisions: return "decisions.json"
            case .claims: return "claims.json"
            case .layouts: return "layouts.json"
            case .mail: return "vault/*.mail"
            }
        }
    }

    /// The files kosh keeps that carry no version, and why none is needed: none of them is the book. A new file kosh
    /// saves is either a File above or named here (engine-test/saved-files.js fails on one that is neither).
    static let unversioned: [String: String] = [
        "prices.json": "fund and share prices, fetched again from AMFI and NSE",
        "fx.json": "exchange rates, fetched again",
        "fees.json": "fund houses' expense ratios, fetched again from AMFI",
        "company-sites.json": "which site is a company's, for its icon; asked again",
        "widgets.json": "the widgets' feed, written again by every build",
        "kosh-diagnostics.json": "the diagnostics report, made again each time",
        "kosh-beta-diagnostics.json": "the diagnostics you send, made when you send them",
        "kosh-training-*.jsonl": "the beta's training export, made when you send it (not in a public build)",
        "notes.json": "the beta's feedback notes (not in a public build)",
        // (the one exception that is the book: a database, not a JSON file, so it carries its shape inside, in PRAGMA
        // user_version and each row's v, and each row's body is a reading as records.json holds it: RecordStore)
        "records.sqlite": "every email's reading, a row each, since 5 Nov 2026 (records.json is kept as it was at the move)",
        "records.sqlite-wal": "the database's write-ahead log (SQLite)",
        "records.sqlite-shm": "the database's shared-memory index (SQLite)",
        "records.*.sqlite": "a copy of the database set aside: damaged, written by a newer kosh, or holding rows this one couldn't read",
        "vault/doc-*.text":"a statement's text as it was opened: the paper's own words, read again by the .doc reading print",
    ]

    /// the head: the file's name and today's version, ending in the comma before what follows
    static func head(_ f: File) -> Data {
        Data(("{\"kosh\":\"" + f.rawValue + "\",\"v\":" + String(f.version) + ",").utf8)
    }

    /// a body as kosh writes it today, with its head: as the object's own first keys, or around it as "body"
    static func seal(_ body: Data, _ f: File) -> Data {
        let h: Data = head(f)
        var out = Data(capacity: h.count + body.count + 8)
        out.append(h)
        if f.ownKeys, let first = body.firstIndex(where: { !savedSpace($0) }), body[first] == UInt8(ascii: "{") {
            // the object's members after the head's (an empty object: the head alone)
            let rest: Data = body[(first + 1)...]
            if let next = rest.firstIndex(where: { !savedSpace($0) }), rest[next] == UInt8(ascii: "}") {
                out.removeLast()
                out.append(UInt8(ascii: "}"))
            } else {
                out.append(rest)
            }
            return out
        }
        out.append(Data("\"body\":".utf8))
        out.append(body)
        out.append(UInt8(ascii: "}"))
        return out
    }

    /// what a saved file says of itself: its version (0: written before versions) and where its body is (nil: the whole
    /// file, as for a file before versions and one with the head as its own keys). nil when it has a head that isn't
    /// this file's, or can't be read: damaged, and treated so.
    struct Found: Equatable {
        let version: Int
        let body: Range<Int>?
    }

    static func found(_ d: Data, _ f: File) -> Found? {
        let lead: String = String(decoding: d.prefix(96), as: UTF8.self)
        let start: String = "{\"kosh\":\""
        guard lead.hasPrefix(start) else { return Found(version: 0, body: nil) }
        let rest: Substring = lead.dropFirst(start.count)
        guard let q = rest.firstIndex(of: "\""), String(rest[rest.startIndex..<q]) == f.rawValue else { return nil }
        let afterName: Substring = rest[rest.index(after: q)...]
        let vKey: String = ",\"v\":"
        guard afterName.hasPrefix(vKey) else { return nil }
        let digits: Substring = afterName.dropFirst(vKey.count).prefix { $0 >= "0" && $0 <= "9" }
        guard !digits.isEmpty, digits.count < 7, let v = Int(digits) else { return nil }
        let after: Substring = afterName.dropFirst(vKey.count + digits.count)
        // the object's own keys go on (or it ends): all of the file is the body, its decoder passing over the head
        if !after.hasPrefix(",\"body\":") {
            guard after.hasPrefix(",") || after.hasPrefix("}") else { return nil }
            var end: Int = d.endIndex
            while end > d.startIndex, savedSpace(d[end - 1]) { end -= 1 }
            guard end > d.startIndex, d[end - 1] == UInt8(ascii: "}") else { return nil }
            return Found(version: v, body: nil)
        }
        // (every character of the head is ASCII: its length in bytes is its length in characters)
        let headLength: Int = start.count + f.rawValue.count + 1 + vKey.count + digits.count + ",\"body\":".count
        let from: Int = d.startIndex + headLength
        var end: Int = d.endIndex
        // the body ends before the closing brace (and any space after it)
        while end > from, savedSpace(d[end - 1]) { end -= 1 }
        guard end > from, d[end - 1] == UInt8(ascii: "}") else { return nil }
        return Found(version: v, body: from..<(end - 1))
    }

    /// The step from one version of a file to the next: the body as the older shape held it, in, the body as the next
    /// holds it, out. nil when the body can't be read as the older shape. Every step ever written stays here.
    static func step(_ f: File, from v: Int, _ body: Data) -> Data? {
        switch v {
        // 0 → 1 (27 Oct 2026): the head was added; the body is the file as it was
        case 0: return body
        default: return nil
        }
    }

    /// a saved file's body in today's shape, from any shape a kosh ever wrote it in, and the version it was found at.
    /// nil: not this file (damaged, or another's), for the caller to fall back as it does for any damaged file
    static func open(_ d: Data, _ f: File) -> (body: Data, found: Int)? {
        guard let at = found(d, f) else { return nil }
        var body: Data = at.body.map { Data(d[$0]) } ?? d
        var v: Int = at.version
        while v < f.version {
            guard let next = step(f, from: v, body) else { return nil }
            body = next
            v += 1
        }
        return (body, at.version)
    }

    /// a file that isn't this file, or can't be read as any of its shapes
    struct Damaged: Error {}

    /// today's shape decoded straight from its envelope, in one pass (the records can be tens of MB)
    private struct Box<T: Decodable>: Decodable { let body: T }

    /// A saved file decoded as T, from whichever shape it is in, and the version it was found at (above this kosh's:
    /// written by a newer one, so its reader keeps a copy aside before writing over it).
    static func decode<T: Decodable>(_ type: T.Type, _ d: Data, _ f: File) throws -> (value: T, found: Int) {
        guard let at = found(d, f) else { throw Damaged() }
        if at.version == f.version {
            if let _ = at.body {
                let box: Box<T> = try JSONDecoder().decode(Box<T>.self, from: d)
                return (box.body, at.version)
            }
            // the head as the object's own keys: the decoder passes over them
            let value: T = try JSONDecoder().decode(T.self, from: d)
            return (value, at.version)
        }
        guard let o = open(d, f) else { throw Damaged() }
        let value: T = try JSONDecoder().decode(T.self, from: o.body)
        return (value, o.found)
    }

    /// The version a saved file's first bytes say it was written at (0: before versions), or nil when the head there
    /// isn't this file's or can't be read. Only the head is looked at: what `write` checks before writing over a file.
    static func headVersion(_ d: Data, _ f: File) -> Int? {
        let lead: String = String(decoding: d.prefix(96), as: UTF8.self)
        let start: String = "{\"kosh\":\""
        guard lead.hasPrefix(start) else { return 0 }
        let rest: Substring = lead.dropFirst(start.count)
        guard let q = rest.firstIndex(of: "\""), String(rest[rest.startIndex..<q]) == f.rawValue else { return nil }
        let afterName: Substring = rest[rest.index(after: q)...]
        let vKey: String = ",\"v\":"
        guard afterName.hasPrefix(vKey) else { return nil }
        let digits: Substring = afterName.dropFirst(vKey.count).prefix { $0 >= "0" && $0 <= "9" }
        guard !digits.isEmpty, digits.count < 7, let v = Int(digits) else { return nil }
        return v
    }

    /// A body written over a saved file in today's shape (seal). A file there that a newer kosh wrote (a build put back:
    /// TestFlight rolled back, an older branch built on the Mac) is kept beside it first, once ("claims.v2.json"):
    /// this kosh read what it could of it, and whatever it couldn't is never lost to its next save
    static func write(_ body: Data, _ f: File, to url: URL, options: Data.WritingOptions) throws {
        if let h = try? FileHandle(forReadingFrom: url) {
            let lead: Data = (try? h.read(upToCount: 96)) ?? Data()
            try? h.close()
            if let v = headVersion(lead, f), v > f.version { keepBefore(url, version: v) }
        }
        try seal(body, f).write(to: url, options: options)
    }

    /// kept beside a file, once, as the kosh of another version wrote it: before the first save in today's shape of a
    /// file an older kosh wrote ("profile.v0.json", so an update that went wrong can be put right by hand), and before
    /// writing over one a newer kosh wrote (`write`)
    static func keepBefore(_ url: URL, version: Int) {
        let copy: URL = url.deletingPathExtension().appendingPathExtension("v" + String(version) + ".json")
        let fm = FileManager.default
        if !fm.fileExists(atPath: copy.path) { try? fm.copyItem(at: url, to: copy) }
    }
}

/// a space, tab or line end between JSON's tokens
private func savedSpace(_ b: UInt8) -> Bool { b == 0x20 || b == 0x0A || b == 0x0D || b == 0x09 }
