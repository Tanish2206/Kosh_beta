import SwiftUI
import Charts

// MARK: - People: splits, loans to and from friends, refunds

/// everything still open with one person, netted into the one payment that settles the lot
struct SettleUp: Identifiable, Hashable {
    let name: String
    /// who pays whom, and how much, once everything nets off
    let move: SplitMove
    /// the open things it nets (settled together, with an Undo)
    let items: [String]
    /// money owed to you, after everything
    let toYou: Bool
    var id: String { name }
    /// what the one figure is made of: "4 things"
    var madeOf: String { items.count == 1 ? "1 thing" : String(items.count) + " things" }
}

extension Store {
    /// everything still open with one person, netted into the one payment that would settle it: "Kabir pays you
    /// ₹3,400". Worked out with the arithmetic a chapter's split already uses (ChapterSplit.squares), pointed at
    /// everything owed instead of one chapter's payments — with only the two of you in it, the fewest payments that
    /// square it is the one. One line a person, and only where there is more than one thing to net off.
    var settleUps: [SettleUp] {
        var open: [String: [OwedItem]] = [:]
        var order: [String] = []
        // (a share split without names stands for several people, and nobody is netted against themselves)
        for o in owed where !o.settled && !o.name.isEmpty && Self.seats(o) == 1 && o.name.lowercased() != "me" {
            let k: String = o.name.lowercased()
            if open[k] == nil { order.append(k) }
            open[k, default: []].append(o)
        }
        var out: [SettleUp] = []
        for k in order {
            guard let rows = open[k], rows.count > 1, let name = rows.first?.name else { continue }
            let net: Double = SplitWays.netted(rows.map { (dir: $0.dir, amount: $0.amount) })
            let by: [String: SplitPerson] = ["me": SplitPerson(id: "me", name: "You"), k: SplitPerson(id: k, name: name)]
            // whoever is behind pays whoever is ahead: the one payment that leaves you both square
            guard let move = ChapterSplit.squares(["me": net, k: -net], by: by, order: ["me", k]).first else { continue }
            out.append(SettleUp(name: name, move: move, items: rows.map(\.id), toYou: net > 0))
        }
        return out.sorted { $0.move.amount != $1.move.amount ? $0.move.amount > $1.move.amount : $0.name < $1.name }
    }

    /// everything open with one person, settled at once, with an Undo
    func settleEverything(_ s: SettleUp) {
        let was: Set<String> = settledIDs
        var now: Set<String> = settledIDs
        for id in s.items { now.insert(id) }
        settledIDs = now
        live?.rebuildSoon()
        undoNote = UndoNote(text: "Settled everything with " + s.name) { [weak self] in
            self?.settledIDs = was
            self?.live?.rebuildSoon()
        }
    }

    /// the reminder for everything at once: the net figure, what it nets, and a link to pay you in one tap
    func reminder(_ s: SettleUp) -> String {
        var out: String = "Hi " + s.name + ", everything between us nets off, across " + s.madeOf + ", to "
        out += Fmt.rupees(s.move.amount) + (s.toYou ? " owed to me." : " owed to you.")
        out += " Thanks!"
        if s.toYou, let link = upiLink(amount: s.move.amount, note: "Settling up") { out += "\n\nPay in one tap: " + link }
        return out
    }
}

struct PeopleTabView: View {
    @Environment(Store.self) private var store
    var body: some View {
        @Bindable var store = store
        NavigationStack(path: $store.peoplePath) {
            PeopleView()
                .householdOnly("Splits, lent and borrowed are the household's: this tab is the same whoever is picked.")
                .tabHeader("People", add: [
                    HeaderAction(title: "Split a bill", symbol: "person.2") { store.sheet = .split(nil) },
                    HeaderAction(title: "Lent or borrowed", symbol: "arrow.left.arrow.right") { store.sheet = .lend },
                ], extra: HeaderAction.arrange(.people) { store.sheet = .arrange(.people) })
                .navigationDestination(for: Route.self) { route in RouteDestination(route: route, zoom: nil) }
        }
    }
}

struct PeopleView: View {
    @Environment(Store.self) private var store

    var body: some View {
        let toYou = store.owedToYou
        let youOwe = store.youOwe
        let settled = Array(store.settledOwed.prefix(12))
        let nets = store.settleUps
        List {
            if store.live != nil {
                Section { Intro.people() }.listRowInsets(EdgeInsets()).listRowBackground(Color.clear)
            }
            PlanSections(.people) { id in
                switch id {
                case "tiles":
                    Section {
                        HStack(spacing: 12) {
                            OwedTile(title: "Owed to you", value: toYou.reduce(0) { $0 + $1.amount }, count: toYou.count, color: Color.green, fill: Color(uiColor: .secondarySystemGroupedBackground))
                            OwedTile(title: "You owe", value: youOwe.reduce(0) { $0 + $1.amount }, count: youOwe.count, color: Color.orange, fill: Color(uiColor: .secondarySystemGroupedBackground))
                        }
                        .listRowInsets(EdgeInsets())
                        .listRowBackground(Color.clear)
                    }
                case "actions":
                    Section {
                        HStack(spacing: 10) {
                            Button {
                                store.sheet = .split(nil)
                            } label: {
                                HStack(spacing: 6) {
                                    Image(systemName: "person.2.fill")
                                    Text("Split a bill")
                                }
                                .font(.subheadline.weight(.semibold))
                                .frame(maxWidth: .infinity)
                            }
                            .buttonStyle(.glassProminent).koshFilled()
                            Button {
                                store.sheet = .lend
                            } label: {
                                HStack(spacing: 6) {
                                    Image(systemName: "arrow.left.arrow.right")
                                    Text("Lent or borrowed")
                                }
                                .font(.subheadline.weight(.semibold))
                                .lineLimit(1)
                                .minimumScaleFactor(0.75)
                                .frame(maxWidth: .infinity)
                            }
                            .buttonStyle(.glass)
                        }
                        .controlSize(.large)
                        .listRowInsets(EdgeInsets())
                        .listRowBackground(Color.clear)
                    } footer: {
                        Text("When money comes in from the person for what they owe, kosh settles it on its own (Undo if it guessed wrong); else tap Received, for all of it or part. Remind opens WhatsApp with a short note and, once Settings has your UPI ID, a link to pay you in one tap.")
                    }
                case "settle":
                    if !nets.isEmpty {
                        Section {
                            ForEach(nets) { s in SettleUpRow(s: s) }
                        } header: {
                            Text("Settle up in one")
                        } footer: {
                            Text("Everything with one person, netted: what they owe you less what you owe them, across every split and loan. One tap settles the lot (with an Undo).")
                        }
                    }
                case "toYou":
                    if !toYou.isEmpty {
                        Section("Owed to you") {
                            ForEach(toYou) { o in OwedRow(o: o) }
                        }
                    }
                case "youOwe":
                    if !youOwe.isEmpty {
                        Section("You owe") {
                            ForEach(youOwe) { o in OwedRow(o: o) }
                        }
                    }
                case "settled":
                    if !settled.isEmpty {
                        Section("Settled") {
                            ForEach(settled) { o in OwedRow(o: o) }
                        }
                    }
                default: EmptyView()
                }
            }
        }
        .listStyle(.insetGrouped)
        .animation(Motion.open, value: store.settledIDs)
        .animation(Motion.open, value: store.userOwed)
    }
}

/// everything with one person in a line: the one payment that squares it, a tap to settle the lot at once (with an
/// Undo), and a reminder for the net figure
struct SettleUpRow: View {
    @Environment(Store.self) private var store
    let s: SettleUp
    @State private var asking = false

    var body: some View {
        let color: Color = s.toYou ? Color.green : Color.orange
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 12) {
                Avatar(name: s.name, color: s.toYou ? Color.koshFill : Color.orange, size: 36, ink: s.toYou ? Color.onKosh : Color.white)
                VStack(alignment: .leading, spacing: 2) {
                    Text("Settle everything with " + s.name)
                        .font(.body.weight(.medium))
                        .lineLimit(1)
                    Text(s.madeOf + " net off · " + (s.toYou ? "owed to you" : "you owe"))
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }
                Spacer(minLength: 8)
                Text(Fmt.rupees(s.move.amount))
                    .font(.body.weight(.semibold))
                    .monospacedDigit()
                    .foregroundStyle(color)
                    .privacySensitive()
                    .accessibilityElement(children: .ignore)
                    .spokenFigures(s.move.line, hidden: "amount hidden")
            }
            HStack(spacing: 8) {
                Button { asking = true } label: {
                    Label("All settled", systemImage: "checkmark.circle.fill")
                        .font(.footnote.weight(.semibold))
                        .padding(.horizontal, 12).padding(.vertical, 7)
                        .background(Color.green.opacity(0.13), in: Capsule())
                        .foregroundStyle(Color.green)
                }
                .buttonStyle(.press)
                if s.toYou {
                    remind
                }
                Spacer()
            }
            .padding(.leading, 48)
        }
        .padding(.vertical, 2)
        .confirmationDialog("Settle everything with \(s.name)?", isPresented: $asking, titleVisibility: .visible) {
            Button("Yes, all \(s.madeOf)") { withAnimation(Motion.open) { store.settleEverything(s) } }
            Button("Not yet", role: .cancel) {}
        }
    }

    /// the reminder for the net figure: WhatsApp with the note typed in, and the share sheet for any other app
    @ViewBuilder var remind: some View {
        let note: String = store.reminder(s)
        if let url = NudgeWords.whatsapp(note, phone: nil) {
            Link(destination: url) {
                Label("Remind", systemImage: "paperplane.fill")
                    .font(.footnote.weight(.semibold))
                    .padding(.horizontal, 12).padding(.vertical, 7)
                    .background(Color.kosh.opacity(0.1), in: Capsule())
                    .foregroundStyle(Color.kosh)
            }
            .buttonStyle(.press)
            .accessibilityHint("Opens WhatsApp with a short note; nothing goes until you press send")
        }
        ShareLink(item: note) {
            Image(systemName: "square.and.arrow.up")
                .font(.footnote.weight(.semibold))
                .padding(.horizontal, 10).padding(.vertical, 7)
                .background(Color.kosh.opacity(0.1), in: Capsule())
                .foregroundStyle(Color.kosh)
        }
        .buttonStyle(.press)
        .accessibilityLabel("Share the reminder another way")
    }
}

struct OwedRow: View {
    @Environment(Store.self) private var store
    let o: OwedItem
    @State private var asking = false
    @State private var partly = false
    @State private var part = ""

    var sym: String {
        switch o.kind {
        case "split": return "person.2.fill"
        case "refund": return "arrow.uturn.backward"
        default: return o.dir == "in" ? "arrow.up.right" : "arrow.down.left"
        }
    }
    var line: String {
        let when = Day.short(o.date)
        switch o.kind {
        case "split": return "Split · \(when)"
        case "refund": return o.settled ? "Refund · \(when)" : "Refund expected · since \(when)"
        default: return (o.dir == "in" ? "You lent · " : "You borrowed · ") + when
        }
    }

    var body: some View {
        let isIn = o.dir == "in"
        let color: Color = o.settled ? Color.secondary : (isIn ? Color.green : Color.orange)
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 12) {
                if o.name.isEmpty {
                    IconTile(symbol: sym, color: o.settled ? Color.gray : (isIn ? Color.kosh : Color.orange))
                } else {
                    Avatar(name: o.name, color: o.settled ? Color.gray : (isIn ? Color.koshFill : Color.orange), size: 36, ink: !o.settled && isIn ? Color.onKosh : Color.white)
                }
                VStack(alignment: .leading, spacing: 2) {
                    Text(o.name.isEmpty ? o.title : o.name)
                        .font(.body.weight(.medium))
                        .foregroundStyle(o.settled ? Color.secondary : Color.primary)
                        .lineLimit(1)
                    Text(o.settled ? "Settled · " + (o.name.isEmpty ? line : o.title) : (o.name.isEmpty ? line : "\(o.title) · \(Day.short(o.date))"))
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }
                Spacer(minLength: 8)
                Text(Fmt.rupees(o.amount))
                    .font(.body.weight(.semibold))
                    .monospacedDigit()
                    .strikethrough(o.settled)
                    .foregroundStyle(color)
                    .privacySensitive()
            }
            if o.settled && o.settledBy != nil {
                autoNote
            }
            if !o.settled {
                HStack(spacing: 8) {
                    Button { asking = true } label: {
                        Label(isIn ? "Received" : "Paid back", systemImage: "checkmark.circle.fill")
                            .font(.footnote.weight(.semibold))
                            .padding(.horizontal, 12).padding(.vertical, 7)
                            .background(Color.green.opacity(0.13), in: Capsule())
                            .foregroundStyle(Color.green)
                    }
                    .buttonStyle(.press)
                    if isIn {
                        remind
                    }
                    Spacer()
                }
                .padding(.leading, 48)
            }
        }
        .padding(.vertical, 2)
        .confirmationDialog(isIn ? "Did \(o.name.isEmpty ? "it" : o.name) pay you?" : "Paid \(o.name.isEmpty ? "it" : o.name) back?", isPresented: $asking, titleVisibility: .visible) {
            Button(isIn ? "Yes, all \(Fmt.rupees(o.amount))" : "Yes, all \(Fmt.rupees(o.amount))") { withAnimation(Motion.open) { store.settle(o.id) } }
            if store.canSplitReceive(o.id) {
                Button(isIn ? "Only part of it…" : "Only part of it…") { part = ""; partly = true }
            }
            Button("Not yet", role: .cancel) {}
        }
        .alert("How much came in?", isPresented: $partly) {
            TextField("Amount", text: $part).keyboardType(.decimalPad)
            Button("Save") {
                if let v = Double(part.replacingOccurrences(of: ",", with: "")).map(TypedAmount.cap), v > 0 { withAnimation(Motion.open) { store.receivePart(o.id, v) } }
            }
            Button("Cancel", role: .cancel) {}
        } message: {
            Text("The rest stays open as owed.")
        }
        .swipeActions(edge: .trailing) {
            Button {
                withAnimation(Motion.open) { store.settle(o.id, !o.settled) }
            } label: {
                Label(o.settled ? "Reopen" : (isIn ? "Received" : "Paid back"), systemImage: o.settled ? "arrow.uturn.backward" : "checkmark")
            }
            .tint(o.settled ? Color.gray : Color.green)
        }
        .contextMenu {
            Button {
                withAnimation(Motion.open) { store.settle(o.id, !o.settled) }
            } label: {
                Label(o.settled ? (o.settledBy != nil ? "Undo the match" : "Mark as open") : (isIn ? "Money received" : "Paid back"), systemImage: o.settled ? "arrow.uturn.backward" : "checkmark.circle")
            }
            if !o.settled && isIn {
                if let url = store.reminderURL(o) {
                    Link(destination: url) { Label("Remind on WhatsApp", systemImage: "paperplane") }
                }
                ShareLink(item: store.reminder(o)) { Label("Send a reminder", systemImage: "square.and.arrow.up") }
            }
        }
    }

    /// settled from a credit kosh saw come in: when, from whom, and Undo (it opens again, and that credit is money in)
    var autoNote: some View {
        HStack(alignment: .center, spacing: 8) {
            Image(systemName: "sparkles")
                .font(.footnote)
                .foregroundStyle(Color.green)
            VStack(alignment: .leading, spacing: 1) {
                Text("Settled automatically")
                    .font(.footnote.weight(.semibold))
                    .foregroundStyle(Color.secondary)
                Text(o.note)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
            }
            Spacer(minLength: 8)
            Button {
                withAnimation(Motion.open) { store.settle(o.id, false) }
            } label: {
                Text("Undo")
                    .font(.footnote.weight(.semibold))
                    .padding(.horizontal, 12).padding(.vertical, 6)
                    .background(Color.kosh.opacity(0.1), in: Capsule())
                    .foregroundStyle(Color.kosh)
            }
            .buttonStyle(.press)
            .accessibilityHint("Opens it again; that money counts as money in")
        }
        .padding(.leading, 48)
    }

    /// Remind: WhatsApp with the note typed in (you pick the chat, nothing goes until you press send), and the share
    /// sheet for any other app
    @ViewBuilder var remind: some View {
        if let url = store.reminderURL(o) {
            Link(destination: url) {
                Label("Remind", systemImage: "paperplane.fill")
                    .font(.footnote.weight(.semibold))
                    .padding(.horizontal, 12).padding(.vertical, 7)
                    .background(Color.kosh.opacity(0.1), in: Capsule())
                    .foregroundStyle(Color.kosh)
            }
            .buttonStyle(.press)
            .accessibilityHint("Opens WhatsApp with a short note; nothing goes until you press send")
            ShareLink(item: store.reminder(o)) {
                Image(systemName: "square.and.arrow.up")
                    .font(.footnote.weight(.semibold))
                    .padding(.horizontal, 10).padding(.vertical, 7)
                    .background(Color.kosh.opacity(0.1), in: Capsule())
                    .foregroundStyle(Color.kosh)
            }
            .buttonStyle(.press)
            .accessibilityLabel("Share the reminder another way")
        } else {
            ShareLink(item: store.reminder(o)) {
                Label("Remind", systemImage: "paperplane.fill")
                    .font(.footnote.weight(.semibold))
                    .padding(.horizontal, 12).padding(.vertical, 7)
                    .background(Color.kosh.opacity(0.1), in: Capsule())
                    .foregroundStyle(Color.kosh)
            }
            .buttonStyle(.press)
        }
    }
}

// MARK: - Split a bill

struct SplitSheet: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    let txID: String?
    @State private var amount = ""
    @State private var title = ""
    @State private var names: [String] = ["", ""]
    @State private var includeMe = true

    var total: Double { TypedAmount.cap(Double(amount.replacingOccurrences(of: ",", with: "")) ?? 0) }
    var people: [String] { names.map { $0.trimmingCharacters(in: .whitespaces) }.filter { !$0.isEmpty } }
    var share: Double {
        let n = people.count + (includeMe ? 1 : 0)
        return n > 0 ? (total / Double(n)).rounded() : 0
    }

    func binding(_ i: Int) -> Binding<String> {
        Binding(get: { i < names.count ? names[i] : "" }, set: { v in if i < names.count { names[i] = v } })
    }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    HStack {
                        Text("₹").font(.system(.largeTitle, design: .rounded, weight: .bold)).foregroundStyle(.secondary)
                        TextField("0", text: $amount)
                            .keyboardType(.decimalPad)
                            .font(.system(.largeTitle, design: .rounded, weight: .bold))
                    }
                    TextField("What was it? Dinner, cab, groceries", text: $title)
                } header: {
                    Text("The bill")
                }
                Section {
                    ForEach(Array(names.enumerated()), id: \.offset) { i, _ in
                        HStack {
                            Image(systemName: "person.crop.circle").foregroundStyle(.secondary)
                            TextField("Name", text: binding(i))
                                .textInputAutocapitalization(.words)
                            if names.count > 1 {
                                Button {
                                    if i < names.count { names.remove(at: i) }
                                } label: {
                                    Image(systemName: "minus.circle.fill").foregroundStyle(Color.red)
                                }
                                .buttonStyle(.borderless)
                                .accessibilityLabel("Remove this name")
                            }
                        }
                    }
                    Button {
                        names.append("")
                    } label: {
                        Label("Add someone", systemImage: "plus")
                    }
                    let known = store.knownNames.filter { !people.contains($0) }
                    if !known.isEmpty {
                        ScrollView(.horizontal) {
                            HStack(spacing: 8) {
                                ForEach(known, id: \.self) { n in
                                    Button {
                                        if let empty = names.firstIndex(where: { $0.trimmingCharacters(in: .whitespaces).isEmpty }) {
                                            names[empty] = n
                                        } else {
                                            names.append(n)
                                        }
                                    } label: {
                                        Text(n).font(.subheadline.weight(.medium))
                                    }
                                    .buttonStyle(.bordered)
                                    .buttonBorderShape(.capsule)
                                }
                            }
                        }
                        .scrollIndicators(.hidden)
                    }
                    Toggle("Include me", isOn: $includeMe)
                } header: {
                    Text("Split with")
                } footer: {
                    Text("Split equally. Each person’s share shows up under Owed to you until they pay.")
                }
                if total > 0 && !people.isEmpty {
                    Section {
                        HStack {
                            Text("Each pays")
                            Spacer()
                            Text(Fmt.rupees(share))
                                .font(.title3.weight(.bold))
                                .contentTransition(.numericText(value: share))
                                .privacySensitive()
                        }
                        HStack {
                            Text("Coming back to you")
                            Spacer()
                            Text(Fmt.rupees(share * Double(people.count))).foregroundStyle(Color.green).fontWeight(.semibold)
                                .privacySensitive()
                        }
                    }
                }
            }
            .navigationTitle("Split a bill")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Split") {
                        let what = title.trimmingCharacters(in: .whitespaces).isEmpty ? "Split bill" : title
                        for p in people {
                            store.addOwed(name: p, title: what, amount: share, dir: "in", kind: "split",
                                          note: "Split of \(Fmt.rupees(total)) between \(people.count + (includeMe ? 1 : 0))")
                        }
                        dismiss()
                    }
                    .fontWeight(.semibold)
                    .disabled(!(total > 0 && !people.isEmpty))
                }
            }
            .onAppear {
                if let id = txID, let t = store.txn(id), amount.isEmpty {
                    amount = String(Int(safe: t.a.rounded()))
                    title = t.m
                }
            }
        }
    }
}

// MARK: - Adjust one charge: the web app's split, on the phone
//
// Four things you can do to a charge without breaking the card's total, in the order you reach for
// them: someone owes you part of it; part of it was something else; part came back; or the whole
// thing shouldn't count as spending.

struct AdjustSheet: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    let txID: String

    enum Mode: String { case even, exact }
    @State private var names: [String] = [""]
    @State private var exact: [String] = [""]
    @State private var mode: Mode = .even
    @State private var includeMe = true
    @State private var partAmount = ""
    @State private var partCat = ""
    @State private var refundAmount = ""
    @State private var done: String?

    static let reasons = ["Reimbursed by work", "Refunded", "Gift card or wallet load", "Paid for someone else", "Not mine", "Business expense"]

    var people: [String] { names.map { $0.trimmingCharacters(in: .whitespaces) }.filter { !$0.isEmpty } }
    func money(_ s: String) -> Double { TypedAmount.cap(Double(s.replacingOccurrences(of: ",", with: "").replacingOccurrences(of: "₹", with: "")) ?? 0) }

    func shares(_ t: Txn) -> [(name: String, amount: Double)] {
        switch mode {
        case .even:
            let n = people.count + (includeMe ? 1 : 0)
            guard n > 0 else { return [] }
            let each = (t.a / Double(n) * 100).rounded() / 100
            return people.map { (name: $0, amount: each) }
        case .exact:
            return names.indices.compactMap { i -> (name: String, amount: Double)? in
                let nm = names[i].trimmingCharacters(in: .whitespaces)
                let a = i < exact.count ? money(exact[i]) : 0
                return nm.isEmpty || a <= 0 ? nil : (name: nm, amount: a)
            }
        }
    }

    var body: some View {
        NavigationStack {
            if let t = store.txn(txID) {
                form(t)
            } else {
                ContentUnavailableView("Gone", systemImage: "tray")
            }
        }
    }

    func form(_ t: Txn) -> some View {
        let sh = shares(t)
        let back = sh.reduce(0) { $0 + $1.amount }
        let isPart = t.partOf != nil
        let touched = t.full != nil || t.ex != nil || isPart
        return Form {
            Section {
                VStack(spacing: 6) {
                    IconTile(symbol: t.sym, color: store.color(for: t), size: 54)
                    Text(t.m).font(.headline)
                    Text(Fmt.rupees(t.a))
                        .font(.system(size: 40, weight: .bold, design: .rounded))
                        .contentTransition(.numericText(value: t.a))
                        .privacySensitive()
                    if let full = t.full, full != t.a {
                        Text("of \(Fmt.rupees(full)) on \(t.card)").font(.subheadline).foregroundStyle(.secondary).privacySensitive()
                    } else {
                        Text(t.card.isEmpty ? Day.long(t.d) : t.card + " · " + Day.short(t.d)).font(.subheadline).foregroundStyle(.secondary)
                    }
                    if let done {
                        Label(done, systemImage: "checkmark.circle.fill")
                            .font(.subheadline.weight(.semibold))
                            .foregroundStyle(Color.green)
                            .privacySensitive()
                            .transition(.scale.combined(with: .opacity))
                            .padding(.top, 4)
                    }
                }
                .frame(maxWidth: .infinity)
                .listRowBackground(Color.clear)
            }

            if !isPart {
                Section {
                    ForEach(names.indices, id: \.self) { i in
                        HStack {
                            Image(systemName: "person.crop.circle").foregroundStyle(.secondary)
                            TextField("Name", text: Binding(get: { i < names.count ? names[i] : "" }, set: { v in if i < names.count { names[i] = v } }))
                                .textInputAutocapitalization(.words)
                            if mode == .exact {
                                TextField("₹", text: Binding(get: { i < exact.count ? exact[i] : "" }, set: { v in while exact.count <= i { exact.append("") }; exact[i] = v }))
                                    .keyboardType(.decimalPad)
                                    .multilineTextAlignment(.trailing)
                                    .frame(width: 90)
                            }
                            if names.count > 1 {
                                Button { if i < names.count { names.remove(at: i); if i < exact.count { exact.remove(at: i) } } } label: {
                                    Image(systemName: "minus.circle.fill").foregroundStyle(Color.red)
                                }
                                .buttonStyle(.borderless)
                                .accessibilityLabel("Remove this name")
                            }
                        }
                    }
                    Button { names.append(""); exact.append("") } label: { Label("Add someone", systemImage: "plus") }
                    let known = store.knownNames.filter { !people.contains($0) }
                    if !known.isEmpty {
                        ScrollView(.horizontal) {
                            HStack(spacing: 8) {
                                ForEach(known, id: \.self) { n in
                                    Button {
                                        if let e = names.firstIndex(where: { $0.trimmingCharacters(in: .whitespaces).isEmpty }) { names[e] = n } else { names.append(n); exact.append("") }
                                    } label: { Text(n).font(.subheadline.weight(.medium)) }
                                    .buttonStyle(.bordered)
                                    .buttonBorderShape(.capsule)
                                }
                            }
                        }
                        .scrollIndicators(.hidden)
                    }
                    Picker("How", selection: $mode) {
                        Text("Split evenly").tag(Mode.even)
                        Text("Exact amounts").tag(Mode.exact)
                    }
                    .pickerStyle(.segmented)
                    if mode == .even { Toggle("Include me", isOn: $includeMe) }
                    if back > 0 {
                        HStack {
                            VStack(alignment: .leading, spacing: 2) {
                                Text("Comes back to you").font(.subheadline).foregroundStyle(.secondary)
                                Text(Fmt.rupees(back)).font(.title3.weight(.bold)).foregroundStyle(Color.green)
                                    .contentTransition(.numericText(value: back))
                            }
                            Spacer()
                            VStack(alignment: .trailing, spacing: 2) {
                                Text("Counts as yours").font(.subheadline).foregroundStyle(.secondary)
                                Text(Fmt.rupees(max(0, t.a - back))).font(.title3.weight(.bold))
                                    .contentTransition(.numericText(value: t.a - back))
                            }
                        }
                        .privacySensitive()
                    }
                    Button {
                        store.shareCharge(t.id, shares: sh, title: t.m)
                        withAnimation(Motion.large) { done = "\(Fmt.rupees(back)) moved to Owed to you" }
                        names = [""]; exact = [""]
                    } label: {
                        Label(back > 0 ? "Move \(Fmt.rupees(back)) to Owed to you" : "Move their share to Owed to you", systemImage: "arrow.uturn.backward.circle.fill")
                            .frame(maxWidth: .infinity)
                            .fontWeight(.semibold)
                            .privacySensitive()
                    }
                    .buttonStyle(.borderedProminent).koshFilled()
                    .disabled(back <= 0 || back > t.a + 0.5)
                    .listRowBackground(Color.clear)
                    .listRowInsets(EdgeInsets())
                    if people.count == 1 {
                        Button("The whole \(Fmt.rupees(t.a)) is owed to me") {
                            store.shareCharge(t.id, shares: [(name: people[0], amount: t.a)], title: t.m)
                            withAnimation(Motion.open) { done = "\(Fmt.rupees(t.a)) moved to Owed to you" }
                            names = [""]; exact = [""]
                        }
                        .privacySensitive()
                    }
                } header: {
                    Label("Someone owes me part of it", systemImage: "person.2.fill")
                } footer: {
                    Text("Their share leaves your spending and waits under Owed to you, with a reminder you can send, until you tick it settled.")
                }

                Section {
                    HStack {
                        TextField("₹ amount", text: $partAmount).keyboardType(.decimalPad)
                        Picker("as", selection: $partCat) {
                            Text("Category").tag("")
                            ForEach(store.spendCategories, id: \.self) { Text($0).tag($0) }
                        }
                        .labelsHidden()
                    }
                    Button("Split it out") {
                        store.splitOut(t.id, amount: money(partAmount), c: partCat.isEmpty ? nil : partCat, s: nil, refunded: false)
                        withAnimation(Motion.open) { done = "Split into two rows on the same card" }
                        partAmount = ""
                    }
                    .disabled(money(partAmount) <= 0 || money(partAmount) >= t.a)
                    HStack {
                        TextField("₹ that came back", text: $refundAmount).keyboardType(.decimalPad)
                        Button("Split out as refunded") {
                            store.splitOut(t.id, amount: money(refundAmount), c: nil, s: nil, refunded: true)
                            withAnimation(Motion.open) { done = "Refunded part left out of spending" }
                            refundAmount = ""
                        }
                        .disabled(money(refundAmount) <= 0 || money(refundAmount) >= t.a)
                    }
                } header: {
                    Label("Part of it was something else", systemImage: "square.split.2x1.fill")
                } footer: {
                    Text("A Blinkit order that was half groceries, half home: split the home part out. Both rows keep the card and the day, so the statement still adds up. Use the second line when part came back and no alert said so.")
                }
            }

            Section {
                ForEach(Self.reasons, id: \.self) { r in
                    Button {
                        store.excludeCharge(t.id, reason: t.ex == r ? nil : r)
                        withAnimation(Motion.open) { done = t.ex == r ? "Counted as spending again" : "Left out of spending" }
                    } label: {
                        HStack {
                            Text(r).foregroundStyle(Color.primary)
                            Spacer()
                            if t.ex == r { Image(systemName: "checkmark").foregroundStyle(Color.kosh) }
                        }
                    }
                }
            } header: {
                Label("Don’t count it as spending", systemImage: "eye.slash.fill")
            } footer: {
                Text("It stays in the ledger and on the card; only your spending totals, budgets and patterns leave it out.")
            }

            if touched {
                Section {
                    Button(role: .destructive) {
                        store.resetCharge(t.id)
                        if isPart { dismiss() } else { withAnimation(Motion.open) { done = "Back to one charge" } }
                    } label: {
                        Label(isPart ? "Merge this part back" : "Undo the changes to this charge", systemImage: "arrow.uturn.backward")
                    }
                } footer: {
                    Text(isPart ? "It goes back into the charge it came from." : "Shares not yet paid back are removed from Owed to you.")
                }
            }
        }
        .navigationTitle(isPart ? "Part of a charge" : "Split or adjust")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } } }
        .sensoryFeedback(.success, trigger: done)
        .animation(Motion.open, value: mode)
    }
}


// MARK: - Lent or borrowed

struct LendSheet: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    @State private var dir = "in"
    @State private var name = ""
    @State private var amount = ""
    @State private var note = ""

    var value: Double { TypedAmount.cap(Double(amount.replacingOccurrences(of: ",", with: "")) ?? 0) }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Picker("Which way", selection: $dir) {
                        Text("I lent").tag("in")
                        Text("I borrowed").tag("out")
                    }
                    .pickerStyle(.segmented)
                    .listRowBackground(Color.clear)
                    .listRowInsets(EdgeInsets())
                }
                Section {
                    TextField(dir == "in" ? "Who has it?" : "Who from?", text: $name)
                        .textInputAutocapitalization(.words)
                    HStack {
                        Text("₹").foregroundStyle(.secondary)
                        TextField("Amount", text: $amount).keyboardType(.decimalPad)
                    }
                    TextField("What for (optional)", text: $note)
                } footer: {
                    Text(dir == "in" ? "kosh keeps it under Owed to you and lets you send a reminder with your UPI ID." : "kosh keeps it under You owe until you mark it paid.")
                }
            }
            .navigationTitle(dir == "in" ? "Money lent" : "Money borrowed")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        let what = note.trimmingCharacters(in: .whitespaces)
                        store.addOwed(name: name.trimmingCharacters(in: .whitespaces),
                                      title: what.isEmpty ? (dir == "in" ? "Lent" : "Borrowed") : what,
                                      amount: value, dir: dir, kind: "lent", note: "")
                        dismiss()
                    }
                    .fontWeight(.semibold)
                    .disabled(!(value > 0 && !name.trimmingCharacters(in: .whitespaces).isEmpty))
                }
            }
        }
    }
}

// MARK: - Cards

struct CardsView: View {
    @Environment(Store.self) private var store
    /// the bank picked last time, so its cards are the ones that open first
    @AppStorage("cards.bank") private var bank = ""
    var body: some View {
        let all = store.cards.sorted { $0.last30 > $1.last30 }
        let banks = Self.banks(all)
        let pick = banks.contains(bank) ? bank : ""
        let cards = pick.isEmpty ? all : all.filter { $0.bank == pick }
        let total = cards.reduce(0) { $0 + $1.last30 }
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                // the household's cards today: the longest to pay, and any left unused (TabSmarts.swift)
                if store.who == .family, pick.isEmpty, let s = store.snap.smarts?.cards { TabSmartLine(line: s.line, notes: s.notes ?? []) }
                PageHead(label: pick.isEmpty ? "On cards, last 30 days" : "On \(pick) cards, last 30 days", value: Fmt.words(total),
                         note: pick.isEmpty ? "\(all.count) cards found in your mail. Bills and due dates come with each statement email."
                                            : "\(cards.count) of your \(all.count) cards. kosh opens on \(pick) until you pick another.")
                    .padding(.bottom, 2)
                if banks.count > 1 { BankChips(banks: banks, cards: all, selection: $bank) }
                ForEach(cards) { c in CardTile(c: c) }
                if all.isEmpty {
                    ContentUnavailableView("No cards", systemImage: "creditcard", description: Text("Nothing for \(store.who.title)."))
                }
            }
            .padding(.horizontal, 20)
            .padding(.top, 8)
            .padding(.bottom, 30)
        }
        .animation(Motion.open, value: store.who)
        .animation(Motion.open, value: pick)
    }
    /// each bank that has issued a card, the most used first
    static func banks(_ cards: [CardInfo]) -> [String] {
        var seen: [String: Double] = [:]
        for c in cards where !c.bank.isEmpty { seen[c.bank, default: 0] += c.last30 }
        return seen.sorted { $0.value == $1.value ? $0.key < $1.key : $0.value > $1.value }.map(\.key)
    }
}

/// All, then each bank with its icon: one tap to just that bank's cards
struct BankChips: View {
    let banks: [String]
    let cards: [CardInfo]
    @Binding var selection: String
    var body: some View {
        ScrollView(.horizontal) {
            HStack(spacing: 8) {
                chip("", label: "All") { EmptyView() }
                ForEach(banks, id: \.self) { b in
                    chip(b, label: b) {
                        InstIcon(name: b, color: Color(hex: cards.first { $0.bank == b }?.color ?? "#8E8E93"), size: 20)
                    }
                }
            }
            .padding(.horizontal, 2)
        }
        .scrollIndicators(.hidden)
    }
    func chip<I: View>(_ id: String, label: String, @ViewBuilder icon: () -> I) -> some View {
        let on = selection == id
        return Button { withAnimation(Motion.open) { selection = id } } label: {
            HStack(spacing: 6) {
                icon()
                Text(label).font(.subheadline.weight(.semibold)).lineLimit(1)
            }
            .padding(.leading, id.isEmpty ? 14 : 6).padding(.trailing, 14).padding(.vertical, 6)
            .frame(minHeight: 34)
            .foregroundStyle(on ? Color(.systemBackground) : Color.primary)
            .background(on ? AnyShapeStyle(Color.primary) : AnyShapeStyle(Color.surface), in: Capsule())
        }
        .buttonStyle(.press)
        .accessibilityAddTraits(on ? .isSelected : [])
    }
}

struct CardTile: View {
    @Environment(Store.self) private var store
    let c: CardInfo
    var body: some View {
        let col = Color(hex: c.color)
        VStack(alignment: .leading, spacing: 0) {
            HStack(alignment: .top, spacing: 10) {
                InstIcon(name: c.bank, color: col, size: 30, hint: c.name, glass: true)
                VStack(alignment: .leading, spacing: 1) {
                    Text((c.product ?? "").isEmpty ? c.name : c.product!).font(.headline).lineLimit(1)
                    if !(c.product ?? "").isEmpty { Text(c.name).font(.caption).opacity(0.8) }
                }
                Spacer()
                VStack(alignment: .trailing, spacing: 1) {
                    Text("•• " + c.last).font(.subheadline.monospacedDigit()).opacity(0.9)
                    if let n = c.network, !n.isEmpty {
                        Text(n.uppercased()).font(.system(.caption2, design: .rounded, weight: .heavy)).italic().tracking(1.2).opacity(0.85)
                    }
                }
            }
            Spacer(minLength: 16)
            HStack(alignment: .lastTextBaseline) {
                VStack(alignment: .leading, spacing: 2) {
                    Text("Last 30 days").font(.caption).opacity(0.8)
                    Text(Fmt.rupees(c.last30))
                        .font(.system(.title2, design: .rounded, weight: .bold))
                        .privacySensitive()
                }
                Spacer()
                VStack(alignment: .trailing, spacing: 2) {
                    if !c.top.isEmpty { Text("Mostly \(c.top.lowercased())") }
                    Text(c.lastUsed.isEmpty ? "\(c.count) payments" : "Used " + Day.when(c.lastUsed, today: store.snap.today))
                }
                .font(.caption)
                .opacity(0.85)
            }
        }
        .foregroundStyle(.white)
        .padding(18)
        .frame(height: 148)
        .background {
            LinearGradient(colors: [col, col.opacity(0.72)], startPoint: .topLeading, endPoint: .bottomTrailing)
                .overlay(alignment: .topTrailing) {
                    Circle().fill(Color.white.opacity(0.08)).frame(width: 180, height: 180).offset(x: 60, y: -70)
                }
                .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
        }
        .shadow(color: col.opacity(0.25), radius: 12, y: 6)
    }
}

// MARK: - Accounts: banks, wallets and cash, by person

// MARK: - Insights: the months side by side

struct InsightsView: View {
    @Environment(Store.self) private var store
    /// the category looked at up close, and how many months the category × month table puts side by side (three to
    /// start; the picker goes to six): both kept when you go to another sub-tab and come back
    @AppStorage("insights.focus") private var focus = ""
    @AppStorage("insights.side") private var side = 3
    /// the page's arrangement (Arrange): with Up close hidden, a row or a cell tapped opens its payments instead
    @AppStorage(SectionPlan.key(.txInsights)) private var plan = ""
    @Environment(\.accessibilityReduceMotion) private var still

    var body: some View {
        // the month the page looks at (InsightMonth.swift): any month kosh has, picked at the top; this month to start
        let cm: String = store.snap.cm
        let allMonths: [String] = store.snap.months.map(\.m)
        let chosen: String = InsightMonths.chosen(store.ledgerMonth, all: allMonths, cm: cm)
        // one pass over the payments for the year up to that month (Up close); its last six months come out of it
        // (the year of months always runs to this month, reaching back far enough to hold the one picked, so picking
        // June never hides July to now: 1 Nov; the category table's six end at the month picked)
        let back: Int = max(12, allMonths.filter { $0 >= chosen && $0 <= cm }.count + 5)
        let year: CatMonths = store.catMonths(InsightMonths.ending(cm, n: back, all: allMonths))
        let data: CatMonths = year.window(6, ending: chosen)
        // one month for All and Insights: the one picked on either; Where it goes and Up close both look at it, or at
        // the newest month the cards have when the one picked on All is older than they reach
        let month: Binding<String> = Binding(get: { store.ledgerMonth }, set: { store.ledgerMonth = $0 })
        let picked: String = InsightsMath.month(store.ledgerMonth, in: data.months, cm: store.snap.cm)
        let close: Bool = SectionPlan.shown(.txInsights, raw: plan).contains("close")
        ScrollViewReader { proxy in
            ScrollView {
              VStack(alignment: .leading, spacing: 26) {
                // (the one-line read of the month, TabSmartLine, is off the page: 1 Nov, his ask)
                // (the month is picked on the pace card's right, 1 Nov; at the top only when that card is hidden)
                if !SectionPlan.shown(.txInsights, raw: plan).contains("pace") {
                    HStack {
                        InsightMonthMenu(month: Binding(get: { chosen }, set: { store.ledgerMonth = $0 }), months: allMonths, cm: cm)
                        Spacer(minLength: 0)
                    }
                    .padding(.bottom, -12)
                }
                PlanStack(.txInsights, spacing: 26) { id in
                    switch id {
                    case "pace":
                        PaceHero(menu: InsightMonthMenu(month: Binding(get: { chosen }, set: { store.ledgerMonth = $0 }),
                                                        months: allMonths, cm: cm, tint: InsightInk.blue))
                    case "paid": HowYouPaid()
                    case "shops": WhereYouShop()
                    case "review": MonthReviewSection()
                    case "you": PersonaSection()
                    case "homes": BillsByHomeSection()
                    case "where":
                        WhereItGoes(data: year, month: month) { c in
                            guard close else { return payments(c, picked) }
                            focus = c
                            withAnimation(still ? nil : Motion.open) { proxy.scrollTo("dive", anchor: .top) }
                        }
                    case "grid":
                        CategoryMonthGrid(data: data, n: $side) { c, m in
                            if let m { store.ledgerMonth = m }
                            guard close else { return payments(c, m ?? picked) }
                            focus = c
                            withAnimation(still ? nil : Motion.open) { proxy.scrollTo("dive", anchor: .top) }
                        }
                    case "close": UpClose(focus: $focus, month: picked, span: year).id("dive")
                    case "repeats": InsightsRepeats()
                    case "keep": KeepRate()
                    case "budgets": if chosen == cm { BudgetsCard() }
                    case "look": WorthALook()
                    default: EmptyView()
                    }
                }
              }
                .padding(.horizontal, 20)
                .padding(.top, 14)
                .padding(.bottom, 36)
            }
            .contentMargins(.bottom, 72, for: .scrollContent)
            .environment(\.insightMonth, chosen)
        }
    }

    /// a kind's payments in a month, in Find (as Where it goes' press-and-hold does)
    func payments(_ c: String, _ m: String) {
        var q = FindQuery()
        q.cats = [c]
        q.months = [m]
        q.flow = .out
        store.findPreset = q
        store.push(.find)
    }
}


/// what's in the bank, what's on the cards and what's in the wallets, one page with three parts. (Bills was a fourth
/// until 1 Nov, his ask: each card's bill is on its card here, and every bill by its day is on Home's calendar)
struct AccountsAndCards: View {
    @Environment(Store.self) private var store
    @AppStorage("accts.part") private var part = "accounts"
    /// the card open on Cards, and one to open there from elsewhere (a bill's reminder, the calendar)
    @State private var openCard: String?
    @State private var jump: String?
    var body: some View {
        // (a phone left on the old Bills part opens on Cards, where each bill now is)
        let shown: Binding<String> = Binding(get: { part == "bills" ? "cards" : part }, set: { part = $0 })
        VStack(spacing: 0) {
            Picker("Show", selection: shown) {
                Text("Banks").tag("accounts")
                Text("Cards").tag("cards")
                Text("Wallets").tag("wallets")
            }
            .pickerStyle(.segmented)
            .padding(.horizontal, 20).padding(.top, 6).padding(.bottom, 4)
            .sensoryFeedback(.selection, trigger: part)
            switch shown.wrappedValue {
            case "cards": WalletCards(open: $openCard, jump: $jump)
            case "wallets": WalletsView()
            default: WalletAccounts()
            }
        }
        .onAppear { takeJump() }
        .onChange(of: store.cardJump) { _, _ in takeJump() }
    }

    /// a card to open from elsewhere (a card bill's reminder tapped, Notify); taken once
    func takeJump() {
        guard let id = store.cardJump else { return }
        store.cardJump = nil
        jump = id
        withAnimation(Motion.base) { part = "cards" }
    }
}
