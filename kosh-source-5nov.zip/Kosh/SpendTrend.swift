import SwiftUI
import Charts

// MARK: - Spending over time: the net worth card's twin, for what goes out
//
// One bar a month. The headline is what a full month costs on average over the span; the running month
// stands at what's gone so far, with a faint bar up to where it's heading. The span counts back from
// today like net worth's: 3M on 7 October takes in July, August and September whole, and October so far.
// Under it, what the span went on, as one bar in proportion.

struct SpendBar: Identifiable, Hashable {
    let m: String
    let v: Double
    /// the running month: where it's heading (0 for a month that's done)
    let likely: Double
    let live: Bool
    /// what trips and events took of it, and (Everyday) what was left out of it
    var trip: Double = 0
    var out: Double = 0
    var id: String { m }
    var date: Date { Day.date(m + "-01") }
}

struct SpendSlice: Identifiable, Hashable {
    let cat: String
    let v: Double
    let color: Color
    var id: String { cat }
}

struct SpendTrend: View {
    @Environment(Store.self) private var store
    @AppStorage("home.spend.range") private var range = 6
    @State private var picked: Date?

    var body: some View {
        let all: [SpendBar] = Self.bars(store)
        let shown: [SpendBar] = Self.window(all, range: range, today: store.snap.today)
        let done: [SpendBar] = shown.filter { !$0.live }
        let avg: Double = Self.average(done)
        let before: [SpendBar] = Self.before(all, shown: shown, count: done.count)
        let chosen: SpendBar? = Self.nearest(shown, to: picked)
        let hero: Double = Self.hero(chosen, avg: avg, shown: shown, done: done)
        VStack(alignment: .leading, spacing: 16) {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 2) {
                    Text(Self.caption(chosen, months: done.count))
                        .font(.subheadline.weight(.medium)).foregroundStyle(.secondary)
                    Text(Fmt.rupees(hero))
                        .font(.system(size: 38, weight: .bold, design: .rounded))
                        .contentTransition(.numericText(value: hero))
                        .privacySensitive()
                    if let c = chosen {
                        Text(Self.versusLine(c, avg: avg))
                            .font(.subheadline.weight(.semibold))
                            .foregroundStyle(Self.versusInk(c.v, avg))
                            .privacySensitive()
                    } else if let line = Self.changeLine(avg: avg, before: before) {
                        Text(line.0).font(.subheadline.weight(.semibold))
                            .foregroundStyle(line.1 ? Color.orange : Color.green)
                            .privacySensitive()
                    }
                }
                Spacer(minLength: 8)
                if all.count > 2 { RangeMenu(range: $range, ranges: NetWorthTrend.ranges) }
            }
            if shown.isEmpty {
                Label("kosh draws this month by month as your spending comes in.", systemImage: "chart.bar.xaxis")
                    .font(.footnote).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            } else {
                SpendChart(bars: shown, average: avg, chosen: chosen, picked: $picked)
                    .frame(height: 160)
                    .animation(Motion.open, value: range)
                if shown.contains(where: { $0.trip > 0 || $0.out > 0 }) {
                    SpendTripKey(left: shown.contains { $0.out > 0 })
                }
                SpendStats(bars: done, live: shown.first { $0.live })
                    .padding(.horizontal, -18)
                SpendSplit(slices: Self.slices(store, months: shown))
            }
        }
        .sensoryFeedback(.selection, trigger: chosen?.m)
        .sensoryFeedback(.selection, trigger: range)
    }

    /// every month kosh has, oldest first: what went out, and for this month where it's heading
    static func bars(_ store: Store) -> [SpendBar] {
        var out: [SpendBar] = []
        for mo in store.snap.months {
            let v: Double = store.total(of: mo)
            let likely: Double = mo.live ? max(v, store.likelyNow) : 0
            let share: TripShare = store.tripShare(mo.m)
            out.append(SpendBar(m: mo.m, v: v, likely: likely, live: mo.live, trip: min(v, share.inn), out: share.out))
        }
        out.sort { $0.m < $1.m }
        return out
    }
    /// the span back from today: the months it reaches into, whole, and this month so far
    static func window(_ bars: [SpendBar], range: Int, today: String) -> [SpendBar] {
        guard range > 0 else { return bars }
        let back: Date = Day.cal.date(byAdding: .month, value: -range, to: Day.date(today)) ?? Day.date(today)
        let first: String = String(Day.iso(back).prefix(7))
        return bars.filter { $0.m >= first }
    }
    static func average(_ xs: [SpendBar]) -> Double {
        if xs.isEmpty { return 0 }
        var t: Double = 0
        for x in xs { t += x.v }
        return t / Double(xs.count)
    }
    /// as many full months again, just before the span: what the average is set against
    static func before(_ all: [SpendBar], shown: [SpendBar], count: Int) -> [SpendBar] {
        guard let first = shown.first, count > 0 else { return [] }
        let earlier: [SpendBar] = all.filter { $0.m < first.m && !$0.live }
        return Array(earlier.suffix(count))
    }
    static func nearest(_ xs: [SpendBar], to d: Date?) -> SpendBar? {
        guard let d, xs.count > 1 else { return nil }
        let m: String = String(Day.iso(d).prefix(7))
        return xs.first { $0.m == m }
    }
    static func caption(_ c: SpendBar?, months: Int) -> String {
        if let c {
            let name: String = Day.fmt(c.m + "-01", "MMMM yyyy")
            return c.live ? name + " so far" : name
        }
        if months == 0 { return "Spent this month" }
        if months == 1 { return "Spent last month" }
        return "Spent a month · average of " + String(months) + " months"
    }
    /// the picked month, else the average full month, else this month so far
    static func hero(_ c: SpendBar?, avg: Double, shown: [SpendBar], done: [SpendBar]) -> Double {
        if let c { return c.v }
        if !done.isEmpty { return avg }
        return shown.last?.v ?? 0
    }
    /// ▲ 12% more than the 3 months before; nil when there's nothing before to set it against
    static func changeLine(avg: Double, before: [SpendBar]) -> (String, Bool)? {
        let prior: Double = average(before)
        guard prior > 0, avg > 0, before.count > 0 else { return nil }
        let x: Double = (avg - prior) / prior
        var n: String = "the month before"
        if before.count > 1 { n = "the " + String(before.count) + " months before" }
        if abs(x) < 0.03 { return ("About the same as " + n, false) }
        let pct: String = Fmt.trim(abs(x) * 100, 0) + "%"
        if x > 0 { return ("▲ " + pct + " more than " + n, true) }
        return ("▼ " + pct + " less than " + n, false)
    }
    static func versusLine(_ c: SpendBar, avg: Double) -> String {
        if c.live {
            if c.likely > c.v { return "Heading for " + Fmt.words(Fmt.roundish(c.likely)) }
            return "So far this month"
        }
        guard avg > 0 else { return "" }
        let x: Double = (c.v - avg) / avg
        if abs(x) < 0.03 { return "About the average" }
        let pct: String = Fmt.trim(abs(x) * 100, 0) + "%"
        if x > 0 { return pct + " above the average" }
        return pct + " below the average"
    }
    static func versusInk(_ v: Double, _ avg: Double) -> Color {
        if avg <= 0 { return Color.secondary }
        return v > avg * 1.03 ? Color.orange : Color.green
    }
    /// what the span went on: the five biggest, the rest together
    static func slices(_ store: Store, months: [SpendBar]) -> [SpendSlice] {
        let keep: Set<String> = Set(months.map(\.m))
        var by: [String: Double] = [:]
        for mo in store.snap.months where keep.contains(mo.m) {
            for c in mo.cats where c.v > 0 { by[c.cat, default: 0] += c.v }
        }
        let sorted: [(String, Double)] = by.sorted { $0.value > $1.value }
        var out: [SpendSlice] = []
        var rest: Double = 0
        for (i, kv) in sorted.enumerated() {
            if i < 5 { out.append(SpendSlice(cat: kv.0, v: kv.1, color: store.catColor(kv.0))) } else { rest += kv.1 }
        }
        if rest > 0 { out.append(SpendSlice(cat: "The rest", v: rest, color: Color(white: 0.72))) }
        return out
    }
}

/// a bar a month: done months solid, this month solid to today and faint to where it's heading, the average dashed
struct SpendChart: View {
    let bars: [SpendBar]
    let average: Double
    let chosen: SpendBar?
    @Binding var picked: Date?
    var body: some View {
        let every: Int = max(1, Int((Double(bars.count) / 6).rounded(.up)))
        Chart {
            ForEach(bars) { b in
                if b.live && b.likely > b.v {
                    BarMark(x: .value("Month", b.date, unit: .month), yStart: .value("From", SpendChart.zero), yEnd: .value("Heading for", b.likely), width: .ratio(0.62))
                        .foregroundStyle(Color.kosh.opacity(0.14))
                        .cornerRadius(6)
                }
                BarMark(x: .value("Month", b.date, unit: .month), yStart: .value("From", SpendChart.zero), yEnd: .value("Spent", b.v - b.trip), width: .ratio(0.62))
                    .foregroundStyle(SpendChart.fill(b, chosen: chosen))
                    .cornerRadius(6)
                if b.trip > 0 {
                    BarMark(x: .value("Month", b.date, unit: .month), yStart: .value("From", b.v - b.trip), yEnd: .value("Trips", b.v), width: .ratio(0.62))
                        .foregroundStyle(SpendChart.tripFill(b, chosen: chosen))
                        .cornerRadius(6)
                }
                if b.out > 0 {
                    BarMark(x: .value("Month", b.date, unit: .month), yStart: .value("From", b.v), yEnd: .value("Left out", b.v + b.out), width: .ratio(0.62))
                        .foregroundStyle(Color.tripInk.opacity(0.2))
                        .cornerRadius(6)
                }
            }
            if average > 0 {
                RuleMark(y: .value("Average", average))
                    .foregroundStyle(Color.secondary.opacity(0.7))
                    .lineStyle(StrokeStyle(lineWidth: 1, dash: [3, 3]))
                    .annotation(position: .top, alignment: .leading, spacing: 2) {
                        Text("avg").font(.system(size: 9, weight: .semibold)).foregroundStyle(.secondary)
                    }
            }
        }
        .chartYAxis(.hidden)
        .chartXAxis {
            AxisMarks(values: .stride(by: .month, count: every)) { _ in
                AxisValueLabel(format: .dateTime.month(.abbreviated), centered: true)
            }
        }
        .chartXSelection(value: $picked)
        .accessibilityElement(children: .ignore)
        .spokenFigures(Self.spoken(bars, average: average, figures: true), hidden: Self.spoken(bars, average: average, figures: false))
    }
    /// what VoiceOver says of the bars: how many months, and (while amounts show) the average, the highest and this month
    static func spoken(_ bars: [SpendBar], average: Double, figures: Bool) -> String {
        let span: String = "Spending month by month, " + SpokenWords.count(bars.count, "month", "months")
        guard figures else { return span }
        var parts: [String] = [span]
        if average > 0 { parts.append("about " + Fmt.rupees(average) + " on average") }
        parts.append(SpokenWords.highest(bars.filter { !$0.live }.map { (m: $0.m, v: $0.v) }))
        if let now = bars.last(where: { $0.live }) {
            let heading: String = now.likely > now.v ? ", heading for " + Fmt.rupees(now.likely) : ""
            parts.append("this month " + Fmt.rupees(now.v) + " so far" + heading)
        }
        return parts.joined(separator: "; ")
    }
    static let zero: Double = 0
    static func fill(_ b: SpendBar, chosen: SpendBar?) -> AnyShapeStyle {
        if let c = chosen, c.m != b.m { return AnyShapeStyle(Color.kosh.opacity(0.3)) }
        return AnyShapeStyle(Color.kosh.gradient)
    }
    static func tripFill(_ b: SpendBar, chosen: SpendBar?) -> AnyShapeStyle {
        if let c = chosen, c.m != b.m { return AnyShapeStyle(Color.tripInk.opacity(0.3)) }
        return AnyShapeStyle(Color.tripInk.gradient)
    }
}

/// the key under the bars when trips are in them, or left out of them
struct SpendTripKey: View {
    let left: Bool
    var body: some View {
        HStack(spacing: 14) {
            HStack(spacing: 6) {
                RoundedRectangle(cornerRadius: 2).fill(Color.kosh).frame(width: 10, height: 10)
                Text("Everyday")
            }
            HStack(spacing: 6) {
                RoundedRectangle(cornerRadius: 2).fill(left ? Color.tripInk.opacity(0.25) : Color.tripInk).frame(width: 10, height: 10)
                Text(left ? "Chapters, left out" : "Chapters")
            }
            Spacer(minLength: 0)
        }
        .font(.caption)
        .foregroundStyle(.secondary)
        .padding(.top, -6)
    }
}

/// the span's high, low and this month, in the same swipeable strip as net worth's
struct SpendStats: View {
    @Environment(Store.self) private var store
    let bars: [SpendBar]
    let live: SpendBar?
    var body: some View {
        let hi: SpendBar? = bars.max { $0.v < $1.v }
        let lo: SpendBar? = bars.min { $0.v < $1.v }
        PulseStats(tiles: tiles(hi: hi, lo: lo))
    }
    /// each opens its month
    func tiles(hi: SpendBar?, lo: SpendBar?) -> [PulseTile] {
        let s: Store = store
        var out: [PulseTile] = []
        if let live {
            let m: String = live.m
            out.append(PulseTile(id: "now", label: Day.fmt(m + "-01", "MMMM") + " so far", value: Fmt.words(live.v), sub: "", color: Color.kosh, sym: "calendar", go: { s.push(.month(m)) }))
        }
        if bars.count > 1, let hi {
            let m: String = hi.m
            out.append(PulseTile(id: "hi", label: "Highest · " + Day.fmt(m + "-01", "MMM"), value: Fmt.words(hi.v), sub: "", color: Color.orange, sym: "arrow.up", go: { s.push(.month(m)) }))
        }
        if bars.count > 1, let lo {
            let m: String = lo.m
            out.append(PulseTile(id: "lo", label: "Lowest · " + Day.fmt(m + "-01", "MMM"), value: Fmt.words(lo.v), sub: "", color: Color.green, sym: "arrow.down", go: { s.push(.month(m)) }))
        }
        return out
    }
}

/// what the span went on, as one bar in proportion with its legend
struct SpendSplit: View {
    let slices: [SpendSlice]
    @State private var grown = false
    var body: some View {
        let total: Double = max(1, slices.reduce(0) { $0 + $1.v })
        if !slices.isEmpty {
            VStack(alignment: .leading, spacing: 12) {
                GeometryReader { g in
                    let gaps: CGFloat = CGFloat(max(0, slices.count - 1)) * 3
                    HStack(spacing: 3) {
                        ForEach(slices) { s in
                            RoundedRectangle(cornerRadius: 5, style: .continuous)
                                .fill(s.color.gradient)
                                .frame(width: Self.width(s.v, total: total, room: g.size.width - gaps, grown: grown))
                        }
                    }
                }
                .frame(height: 14)
                LazyVGrid(columns: [GridItem(.flexible(), spacing: 10, alignment: .leading), GridItem(.flexible(), spacing: 10, alignment: .leading)], alignment: .leading, spacing: 8) {
                    ForEach(slices) { s in
                        HStack(spacing: 6) {
                            Circle().fill(s.color).frame(width: 8, height: 8)
                            Text(s.cat).font(.subheadline).foregroundStyle(.secondary).lineLimit(1)
                            Text(Self.share(s.v, total)).font(.subheadline.weight(.semibold)).monospacedDigit()
                        }
                    }
                }
            }
            .onAppear { withAnimation(Motion.reveal.delay(0.1)) { grown = true } }
        }
    }
    static func width(_ v: Double, total: Double, room: CGFloat, grown: Bool) -> CGFloat {
        let grow: CGFloat = grown ? 1 : 0.02
        return max(0, room * CGFloat(v / total) * grow)
    }
    static func share(_ v: Double, _ total: Double) -> String {
        let n: Int = Int(safe: (v / total * 100).rounded())
        return String(n) + "%"
    }
}
