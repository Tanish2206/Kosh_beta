import SwiftUI

// MARK: - Habits: how you eat, what you stock, how you fuel (fb 1 Nov 23:46)
// The persona's everyday layer, read from the payments of the months Up close shows and what their mails and invoices
// said was bought (payFacts items, the restaurant behind a delivery app). Every line is counted from those payments;
// nothing is guessed past them. Shown under Up close for Food & Drinks, Groceries and Transport (fuel).

/// one line of a habit card: a figure-led sentence
struct HabitLine: Identifiable, Hashable {
    let id: String
    let sym: String
    let text: String
}

/// one habit card's content: its lines, and the names it lists (places, dishes, items)
struct Habit: Hashable {
    let title: String
    let lines: [HabitLine]
    var tags: [String] = []
    var tagsTitle: String = ""
}

enum Habits {
    // ------------------------------------------------------------- shared
    static func mid(_ v: [Double]) -> Double {
        guard !v.isEmpty else { return 0 }
        let s: [Double] = v.sorted()
        return s.count % 2 == 1 ? s[s.count / 2] : (s[s.count / 2 - 1] + s[s.count / 2]) / 2
    }
    /// the middle gap between days, in days (two gaps at least)
    static func every(_ days: [String]) -> Int? {
        let ds: [String] = Array(Set(days)).sorted()
        guard ds.count >= 3 else { return nil }
        var gaps: [Double] = []
        for i in 1..<ds.count { gaps.append(Double(Day.between(ds[i - 1], ds[i]))) }
        let m: Double = mid(gaps)
        return m >= 1 ? Int(m.rounded()) : nil
    }
    static func everyWords(_ e: Int) -> String {
        if e <= 1 { return "almost daily" }
        if e < 11 { return "every ~" + String(e) + " days" }
        if e < 25 { return "every ~" + String(Int((Double(e) / 7).rounded())) + " weeks" }
        if e < 45 { return "about monthly" }
        return "every ~" + String(Int((Double(e) / 30).rounded())) + " months"
    }
    static func weekday(_ iso: String) -> Int { Calendar(identifier: .gregorian).component(.weekday, from: Day.date(iso)) }
    static let dayNames: [String] = ["", "Sundays", "Mondays", "Tuesdays", "Wednesdays", "Thursdays", "Fridays", "Saturdays"]
    /// the top keys of a count, most first
    static func top(_ c: [String: Double], _ n: Int) -> [String] {
        c.keys.sorted { (c[$0] ?? 0) > (c[$1] ?? 0) || ((c[$0] ?? 0) == (c[$1] ?? 0) && $0 < $1) }.prefix(n).map { $0 }
    }
    static func hour(_ t: Txn) -> Int? {
        let p = t.t.split(separator: ":")
        guard let h = p.first.flatMap({ Int($0) }) else { return nil }
        return h
    }
    @MainActor static func items(_ t: Txn, _ store: Store) -> [PayFacts.Item] { store.payFact(t)?.items ?? [] }
    static func clean(_ n: String) -> String {
        var s: String = n.trimmingCharacters(in: .whitespacesAndNewlines)
        if let r = s.range(of: #"\s*[\(\[|,].*$"#, options: .regularExpression) { s = String(s[..<r.lowerBound]) }
        if s.count > 34 { s = String(s.prefix(32)).trimmingCharacters(in: .whitespaces) + "…" }
        return s
    }

    // ------------------------------------------------------------- food
    @MainActor static func food(_ rows: [Txn], store: Store) -> Habit? {
        let xs: [Txn] = rows.filter { $0.sp && $0.c == "Food & Drinks" && $0.a > 0 }
        guard xs.count >= 3 else { return nil }
        let delivered: [Txn] = xs.filter { $0.s == "Delivery" }
        let out: [Txn] = xs.filter { $0.s != "Delivery" }
        var lines: [HabitLine] = []
        var head: [String] = []
        if !delivered.isEmpty { head.append("Ordered in " + String(delivered.count) + (delivered.count == 1 ? " time" : " times")) }
        if !out.isEmpty { head.append("ate or drank out " + String(out.count) + (out.count == 1 ? " time" : " times")) }
        lines.append(HabitLine(id: "n", sym: "fork.knife", text: head.joined(separator: ", ")))
        if delivered.count >= 2 {
            let usual: Double = mid(delivered.map { $0.a })
            var d: String = "Usually " + Fmt.rupees(usual) + " an order"
            if let e = every(delivered.map { $0.d }) { d += ", " + everyWords(e) }
            lines.append(HabitLine(id: "u", sym: "bag", text: d))
        }
        // the day of the week it happens most, when one stands out
        var byDay: [Int: Int] = [:]
        for t in xs { byDay[weekday(t.d), default: 0] += 1 }
        if let best = byDay.max(by: { $0.value < $1.value }), Double(best.value) >= Double(xs.count) * 0.25, xs.count >= 6 {
            lines.append(HabitLine(id: "d", sym: "calendar", text: "Most often on " + dayNames[best.key] + " (" + String(best.value) + " of " + String(xs.count) + ")"))
        }
        // late nights
        let late: Int = delivered.filter { (hour($0) ?? 12) >= 23 || (hour($0) ?? 12) < 4 }.count
        if late >= 2 { lines.append(HabitLine(id: "l", sym: "moon.stars", text: String(late) + " late-night orders, after 11 pm")) }
        // where from: the restaurant behind a delivery app, else the place
        var places: [String: Double] = [:]
        for t in xs { let o: String = store.payFact(t)?.outlet ?? ShopName.clean(t.pf ?? t.m); if !o.isEmpty { places[o, default: 0] += 1 } }
        let fav: [String] = top(places, 3).filter { (places[$0] ?? 0) >= 2 }
        if !fav.isEmpty { lines.append(HabitLine(id: "p", sym: "mappin.and.ellipse", text: "Keeps going back to " + Words.list(fav))) }
        // what: the dishes ordered most
        var dishes: [String: Double] = [:]
        for t in xs { for it in items(t, store) { let n: String = clean(it.n); if !n.isEmpty { dishes[n, default: 0] += Double(it.q ?? 1) } } }
        let usual: [String] = top(dishes, 6)
        return Habit(title: "How you eat", lines: lines, tags: usual, tagsTitle: usual.isEmpty ? "" : "What you order most")
    }

    // ------------------------------------------------------------- groceries
    static let groups: [(String, String)] = [
        ("Dairy", #"(?i)\b(?:milk|curd|dahi|paneer|butter|cheese|ghee|yog(?:h)?urt|lassi|cream|buttermilk|chaas)\b"#),
        ("Fruits & veg", #"(?i)\b(?:banana|apple|mango|orange|grape|papaya|guava|pomegranate|kiwi|onion|potato|tomato|garlic|ginger|lemon|chilli|coriander|spinach|palak|carrot|cucumber|capsicum|cabbage|cauliflower|peas|beans|mushroom|lettuce|broccoli|fruit|vegetable|veg)s?\b"#),
        ("Staples", #"(?i)\b(?:atta|flour|rice|dal|daal|lentil|chana|rajma|besan|sooji|rava|poha|oil|ghee|sugar|salt|masala|spice|jeera|haldi|turmeric|bread|eggs?|maida)\b"#),
        ("Snacks & drinks", #"(?i)\b(?:chips|namkeen|biscuits?|cookies?|chocolate|candy|wafer|bhujia|cake|ice ?cream|juice|cola|coke|pepsi|soda|soft drink|energy drink|coffee|tea|chai|noodles|maggi|pasta|sauce|ketchup|cereal|oats|muesli|peanut|nuts|almonds?|cashew)\b"#),
        ("Household", #"(?i)\b(?:detergent|surf|ariel|tide|dishwash|vim|cleaner|harpic|lizol|phenyl|tissue|napkin|garbage|bin bag|foil|cling|mop|sponge|scrub|freshener|mosquito|repellent|bulb|battery|batteries|candle|agarbatti)\b"#),
        ("Personal care", #"(?i)\b(?:soap|shampoo|conditioner|toothpaste|toothbrush|face ?wash|body ?wash|deo|deodorant|lotion|moisturi[sz]er|sunscreen|razor|shaving|sanitary|pads?|diapers?|wipes|hair oil|cotton)\b"#),
        ("Meat & fish", #"(?i)\b(?:chicken|mutton|fish|prawns?|egg ?curry|salami|sausage)\b"#),
    ]
    static func group(_ n: String) -> String? {
        for (g, re) in groups where n.range(of: re, options: .regularExpression) != nil { return g }
        return nil
    }
    @MainActor static func groceries(_ rows: [Txn], store: Store) -> Habit? {
        let xs: [Txn] = rows.filter { $0.sp && $0.c == "Groceries" && $0.a > 0 }
        guard xs.count >= 3 else { return nil }
        var lines: [HabitLine] = []
        var first: String = String(xs.count) + " runs · usually " + Fmt.rupees(mid(xs.map { $0.a }))
        if let e = every(xs.map { $0.d }) { first += " · " + everyWords(e) }
        lines.append(HabitLine(id: "n", sym: "cart", text: first))
        // how: quick commerce against a store
        let quick: [Txn] = xs.filter { $0.s == "Quick commerce" }
        if !quick.isEmpty && quick.count < xs.count {
            let q: Double = quick.reduce(0) { $0 + $1.a }, all: Double = xs.reduce(0) { $0 + $1.a }
            lines.append(HabitLine(id: "q", sym: "bolt", text: Fmt.pct(q / max(all, 1)) + " of it through quick-commerce apps, the rest at stores"))
        } else if quick.count == xs.count {
            lines.append(HabitLine(id: "q", sym: "bolt", text: "All of it through quick-commerce apps"))
        }
        var shops: [String: Double] = [:]
        for t in xs { let s: String = ShopName.clean(t.pf ?? store.payFact(t)?.at ?? t.m); if !s.isEmpty { shops[s, default: 0] += t.a } }
        let where0: [String] = top(shops, 3)
        if !where0.isEmpty { lines.append(HabitLine(id: "w", sym: "storefront", text: "Mostly from " + Words.list(where0))) }
        // what: by group, by money where the lines carry it, else by count
        var byGroup: [String: Double] = [:], itemsC: [String: Double] = [:]
        var anyItems: Bool = false
        for t in xs {
            for it in items(t, store) {
                anyItems = true
                let n: String = clean(it.n)
                if !n.isEmpty { itemsC[n, default: 0] += Double(it.q ?? 1) }
                if let g = group(it.n) { byGroup[g, default: 0] += (it.amt ?? 0) > 0 ? (it.amt ?? 0) : 1 }
            }
        }
        let gs: [String] = top(byGroup, 3)
        if !gs.isEmpty { lines.append(HabitLine(id: "g", sym: "basket", text: "Mostly " + Words.list(gs.map { $0.lowercased() }))) }
        else if !anyItems { lines.append(HabitLine(id: "g", sym: "basket", text: "What's in the baskets shows once their invoices are read")) }
        let usual: [String] = top(itemsC, 6)
        return Habit(title: "What you stock", lines: lines, tags: usual, tagsTitle: usual.isEmpty ? "" : "Bought most")
    }

    // ------------------------------------------------------------- fuel
    @MainActor static func fuel(_ rows: [Txn], store: Store) -> Habit? {
        let xs: [Txn] = rows.filter { $0.sp && $0.c == "Transport" && $0.s == "Fuel" && $0.a > 0 }
        guard xs.count >= 2 else { return nil }
        var lines: [HabitLine] = []
        var first: String = String(xs.count) + " fill-ups · usually " + Fmt.rupees(mid(xs.map { $0.a }))
        if let e = every(xs.map { $0.d }) { first += " · " + everyWords(e) }
        lines.append(HabitLine(id: "n", sym: "fuelpump", text: first))
        let months: Int = max(1, Set(xs.map { String($0.d.prefix(7)) }).count)
        let total: Double = xs.reduce(0) { $0 + $1.a }
        lines.append(HabitLine(id: "m", sym: "chart.bar", text: Fmt.rupees(total / Double(months)) + " a month on fuel, over " + String(months) + (months == 1 ? " month" : " months")))
        var brands: [String: Double] = [:]
        for t in xs {
            let m: String = (t.m + " " + (t.pf ?? "")).lowercased()
            let b: String = m.contains("hpcl") || m.contains("hindustan petroleum") ? "HP" : m.contains("bpcl") || m.contains("bharat petroleum") ? "Bharat Petroleum"
                : m.contains("iocl") || m.contains("indian oil") ? "Indian Oil" : m.contains("shell") ? "Shell" : m.contains("nayara") ? "Nayara" : m.contains("jio-bp") || m.contains("jio bp") ? "Jio-bp" : ""
            if !b.isEmpty { brands[b, default: 0] += 1 }
        }
        if let b = top(brands, 1).first, (brands[b] ?? 0) >= Double(xs.count) * 0.5 { lines.append(HabitLine(id: "b", sym: "drop", text: "Mostly at " + b + " pumps")) }
        var pumps: [String: Double] = [:]
        for t in xs { let p: String = ShopName.clean(t.pf ?? t.m); if !p.isEmpty { pumps[p, default: 0] += 1 } }
        let fav: [String] = top(pumps, 3).filter { (pumps[$0] ?? 0) >= 2 }
        return Habit(title: "How you fuel", lines: lines, tags: fav, tagsTitle: fav.isEmpty ? "" : "Your usual pumps")
    }

    @MainActor static func of(_ cat: String, rows: [Txn], store: Store) -> Habit? {
        switch cat {
        case "Food & Drinks": return food(rows, store: store)
        case "Groceries": return groceries(rows, store: store)
        case "Transport": return fuel(rows, store: store)
        default: return nil
        }
    }
}

/// a habit as a card under Up close, in the category's colour
struct HabitCard: View {
    let h: Habit
    let span: String
    let color: Color
    let ink: Color
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .firstTextBaseline) {
                Text(h.title).font(.subheadline.weight(.semibold))
                Spacer(minLength: 6)
                Text(span).font(.caption).foregroundStyle(.secondary)
            }
            ForEach(h.lines) { (l: HabitLine) in
                HStack(alignment: .firstTextBaseline, spacing: 10) {
                    Image(systemName: l.sym).font(.footnote.weight(.semibold)).foregroundStyle(ink).frame(width: 18)
                    Text(l.text).font(.subheadline).fixedSize(horizontal: false, vertical: true)
                }
            }
            if !h.tags.isEmpty {
                Text(h.tagsTitle).font(.caption.weight(.semibold)).foregroundStyle(.secondary).padding(.top, 4)
                WrapRow(spacing: 6, lineSpacing: 6) {
                    ForEach(h.tags, id: \.self) { (t: String) in
                        Text(t).font(.caption.weight(.medium)).lineLimit(1)
                            .padding(.horizontal, 10).frame(minHeight: 26)
                            .background(color.opacity(0.14), in: Capsule())
                    }
                }
            }
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(color.opacity(0.07), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        .privacySensitive()
    }
}
