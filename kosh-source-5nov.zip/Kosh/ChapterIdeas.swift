import SwiftUI

// MARK: - Ideas for a chapter, over "Start a new chapter"
//
// A carousel of postcards, centred, gliding on every couple of seconds: a trip, a wedding, a new home, a baby,
// Diwali, a renovation, studies abroad, a new car, an anniversary, the parents' yatra. The one in the middle stands
// upright and its scene moves; its neighbours turn away in depth, smaller and softer. Under it, a big serif line
// and a line in small capitals ("A wedding." · "every shagun and caterer, in one place") blur into the next as
// the photo changes. Swipe it yourself and it waits; VoiceOver turns it with swipes instead of a timer. Tap the
// middle photo (or the words) and that kind of chapter starts, its name filled in; tap a neighbour to bring it to
// the middle. Reduce Motion: one photo, crossfading.

struct ChapterIdea: Identifiable, Equatable {
    let id: String
    /// the photo: a scene, re-inked in a colour when it can wear one, on a wash
    let scene: String
    var ink: String = ""
    let wash: String
    /// the big line, and the small one under it
    let line: String
    let note: String
    /// what starts: the kind, its look, and the name it's given (you can change it)
    let preset: ChapterPreset
    let name: String
    /// one of your own chapters, as a postcard: tapping it opens the chapter
    var chapterID: String? = nil
    /// the word on the postcard's pill ("Trip", "Wedding"), and the passport stamp pressed on its corner
    var kind: String = ""
    var stamp: StampArt? = nil
    /// on one of yours: its first day ("12 / 10") and what it came to, for the visa's fields
    var from: String = ""
    var spent: String = ""

    static func == (a: ChapterIdea, b: ChapterIdea) -> Bool { a.id == b.id }

    /// the book's opening spread, before the ideas: a line about the chapters of a life, and its stickers
    static let coverID = "cover"
    static var cover: ChapterIdea {
        ChapterIdea(id: coverID, scene: "travel", wash: "#F3EBDA", line: "Adventures, so far.", note: "every trip, wedding and move, a page of its own",
                    preset: ChapterKinds.preset("getaway"), name: "", kind: "Book")
    }
    var isCover: Bool { id == Self.coverID }

    var tint: SceneTint? { ink.isEmpty ? nil : NotebookScenes.tint(scene, ink: ink) }

    /// one of your chapters as a postcard: its photo, its name, when it was and what it came to, and its own stamp
    static func mine(_ p: NotebookChapter, _ c: Chapter?) -> ChapterIdea {
        let paid: String = p.amount > 0 ? Fmt.words(p.amount) + " " + p.cap : "nothing paid yet"
        let when: String = p.when.isEmpty ? "" : p.when + " · "
        let art: StampArt = c?.art ?? Stamps.get("own")
        let first: String = (c?.from ?? "").isEmpty ? "" : Day.fmt(c?.from ?? "", "dd / MM")
        return ChapterIdea(id: "mine-" + p.id, scene: p.sceneKey, ink: p.ink, wash: p.wash, line: p.title,
                           note: when + paid, preset: ChapterKinds.preset("own"), name: "", chapterID: p.chapterID,
                           kind: "Yours", stamp: art, from: first, spent: p.amount > 0 ? Fmt.words(p.amount) : "")
    }

    /// a passport stamp for an idea: its own words, drawing and ink
    static func stamp(_ o: StampOutline, _ script: String, _ art: String, _ foot: String, _ ink: String, _ label: String) -> StampArt {
        Stamps.make(o, script, art, foot, ink, label)
    }

    /// Diwali comes in October or November: this year's until it's gone by, then next year's
    static func diwali(_ today: String) -> String {
        let y: Int = Int(today.prefix(4)) ?? 2026
        let m: Int = Int(today.dropFirst(5).prefix(2)) ?? 1
        return "Diwali " + String(m >= 12 ? y + 1 : y)
    }

    static func all(today: String) -> [ChapterIdea] {
        [
            ChapterIdea(id: "trip", scene: "travel", wash: "#FCEEEA", line: "A trip.", note: "flights, stays and every chai on the way",
                        preset: ChapterKinds.preset("getaway"), name: "A getaway",
                        kind: "Trip", stamp: stamp(Stamps.hex, "यात्रा", "mountains", "BON VOYAGE", "#C2412D", "A trip")),
            ChapterIdea(id: "wedding", scene: "wedding", wash: "#FBEEF1", line: "A wedding.", note: "every shagun and caterer, in one place",
                        preset: ChapterKinds.preset("wedding"), name: "The wedding",
                        kind: "Wedding", stamp: stamp(Stamps.circle, "शुभ विवाह", "mandap", "THE BIG DAY", "#9F1D3A", "A wedding")),
            ChapterIdea(id: "home", scene: "home", wash: "#F6EFE6", line: "A new home.", note: "the deposit, the movers, the first gas cylinder",
                        preset: ChapterKinds.preset("home"), name: "The new home",
                        kind: "New home", stamp: stamp(Stamps.rrect, "गृह प्रवेश", "house", "NEW HOME", "#7A3418", "A new home")),
            ChapterIdea(id: "baby", scene: "baby", wash: "#F0EEFB", line: "A little one.", note: "from the first scan to the first birthday",
                        preset: ChapterKinds.preset("baby"), name: "The little one",
                        kind: "Baby", stamp: stamp(Stamps.circle, "WELCOME", "moon", "LITTLE ONE", "#4F46E5", "A little one")),
            ChapterIdea(id: "diwali", scene: "wedding", ink: "#D9480F", wash: "#FFF4E6", line: "Diwali.", note: "diyas, mithai and the gifts you lost count of",
                        preset: ChapterKinds.preset("festival"), name: diwali(today),
                        kind: "Festival", stamp: stamp(Stamps.scallop, "दीपावली", "diya", String(diwali(today).suffix(4)), "#C2410C", "Diwali")),
            ChapterIdea(id: "reno", scene: "studio", wash: "#EDF2FA", line: "A renovation.", note: "they said two weeks. keep the receipts",
                        preset: ChapterKinds.preset("reno"), name: "The renovation",
                        kind: "Renovation", stamp: stamp(Stamps.rrect, "KITCHEN", "pan", "RENOVATION", "#1D4ED8", "A renovation")),
            ChapterIdea(id: "abroad", scene: "msc", wash: "#EAF5EE", line: "Studies abroad.", note: "fees, forex and the first winter coat",
                        preset: ChapterKinds.preset("study"), name: "Studies abroad",
                        kind: "Studies", stamp: stamp(Stamps.shield, "ABROAD", "cap", "ADMITTED", "#166534", "Studies abroad")),
            ChapterIdea(id: "car", scene: "car", wash: "#EAF1FA", line: "A new car.", note: "the down payment, insurance and the first full tank",
                        preset: ChapterKinds.preset("vehicle"), name: "The new car",
                        kind: "New car", stamp: stamp(Stamps.hex, "NEW CAR", "car", "KEYS IN HAND", "#334155", "A new car")),
            ChapterIdea(id: "anniversary", scene: "wedding", ink: "#7C3AED", wash: "#F4F0FA", line: "An anniversary.", note: "the dinner, the gift, the trip you keep promising",
                        preset: ChapterPreset(key: "party", label: "Anniversary", kind: "event", sym: "heart.fill", color: "#AF52DE"), name: "Our anniversary",
                        kind: "Anniversary", stamp: stamp(Stamps.scallop, "सालगिरह", "lotus", "ANNIVERSARY", "#7C3AED", "An anniversary")),
            ChapterIdea(id: "yatra", scene: "hills", ink: "#C2410C", wash: "#FFF3E8", line: "Their yatra.", note: "tickets, the dharamshala, prasad for everyone back home",
                        preset: ChapterKinds.preset("yatra"), name: "Ma and Papa’s yatra",
                        kind: "Pilgrimage", stamp: stamp(Stamps.arch, "तीर्थ यात्रा", "temple", "PILGRIMAGE", "#B5502A", "Their yatra")),
        ]
    }
}

// MARK: - Chapters' page: one screen
//
// The postcards across the top (yours first, then ideas), what Chapters is in one line and a line under it, the four
// things it does as a 2 × 2 grid on one left edge, and "Start a new chapter" sitting just above the tab bar. The
// postcards take whatever height the words and the button leave (bigger on a tall phone, smaller on a short one).
// Only with very large text, when even small postcards don't fit, does it scroll, so the button is never hidden. The
// demo sits on the top row.

struct ChaptersPostcards: View {
    @Environment(Store.self) private var store
    let asTab: Bool
    /// your chapters, as postcards
    let mine: [ChapterIdea]
    let start: () -> Void
    let idea: (ChapterIdea) -> Void
    let open: (String) -> Void
    let demo: () -> Void
    /// every chapter of yours in a list (with its + and the switch that counts them in spending)
    var list: (() -> Void)? = nil

    /// kosh's tab bar floats over the page without giving it a safe area: the page stops short of it itself
    @Environment(\.barTop) private var barTop
    @State private var bottom: CGFloat = 0

    /// why a chapter: what it gives you that categories and months can't (symbol, tint, title, line)
    static let points: [(String, String, String, String)] = [
        ("chart.pie", "#3B82F6", "See it whole", "One total, however it was paid."),
        ("target", "#22A06B", "Budget it", "Set a number, watch it as you go."),
        ("clock.arrow.circlepath", "#E8A33D", "Ahead of time", "Paid early? It still lands here."),
        ("calendar", "#A78BFA", "Clean months", "Your usual month stays usual."),
    ]

    var body: some View {
        // the passport opens on its first spread, then turns to your chapters and the ideas
        let ideas: [ChapterIdea] = [ChapterIdea.cover] + mine + ChapterIdea.all(today: store.snap.today)
        let clear: CGFloat = barTop.map { max(0, bottom - $0 + 10) } ?? 0
        // the page as it is, the stage taking whatever height is left; at the largest text sizes, a page that scrolls
        ViewThatFits(in: .vertical) {
            VStack(spacing: 0) {
                ChapterStage(ideas: ideas, start: idea, open: open)
                    .padding(.top, 6)
                under
            }
            .padding(.bottom, clear)
            ScrollView {
                VStack(spacing: 0) {
                    ChapterStage(ideas: ideas, height: 230, start: idea, open: open)
                        .padding(.top, 6)
                    under
                }
            }
            .contentMargins(.bottom, clear, for: .scrollContent)
            .scrollIndicators(.hidden)
        }
        .onGeometryChange(for: CGFloat.self) { g in g.frame(in: .global).maxY } action: { y in bottom = y }
        .opacity(barTop == nil || bottom > 0 ? 1 : 0)
        .background(Color(uiColor: .systemBackground))
        .navigationTitle("Chapters")
        .toolbarTitleDisplayMode(asTab ? .inlineLarge : .large)
        .toolbar {
            // every chapter of yours, in a list: the way to one that isn't on the front postcard
            if let list, !store.trips.isEmpty {
                ToolbarItem(placement: .topBarTrailing) {
                    Button(action: list) { Label("Your chapters", systemImage: "list.bullet").labelStyle(.titleAndIcon) }
                        .accessibilityLabel("All your chapters")
                }
            }
            // the demo, tucked in a menu
            ToolbarItem(placement: .topBarTrailing) {
                Menu {
                    Button(action: demo) { Label("See a demo", systemImage: "play.fill") }
                } label: {
                    Label("More", systemImage: "ellipsis")
                }
                .accessibilityLabel("More: see a demo")
            }
        }
    }

    /// the line, the four things, and the button: one left edge for all of it
    var under: some View {
        VStack(alignment: .leading, spacing: 0) {
            VStack(alignment: .leading, spacing: 6) {
                Text("Life happens. Count it apart.")
                    .font(.system(.title2, design: .serif, weight: .semibold))
                    .tracking(-0.3)
                    .lineLimit(1)
                    .minimumScaleFactor(0.6)
                Text("Trips, weddings, moves: each gets its own page.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
                    .minimumScaleFactor(0.8)
            }
            .padding(.top, 20)
            Grid(alignment: .topLeading, horizontalSpacing: 14, verticalSpacing: 20) {
                GridRow {
                    point(0)
                    point(1)
                }
                GridRow {
                    point(2)
                    point(3)
                }
            }
            .padding(.top, 24)
            StartChapterBar(floating: false, action: start)
                .padding(.horizontal, -24)
                .padding(.top, 22)
        }
        .padding(.horizontal, 24)
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    func point(_ i: Int) -> some View {
        let p = Self.points[i]
        return ChapterPoint(symbol: p.0, tint: Color(hex: p.1), title: p.2, sub: p.3, i: i)
            .frame(maxWidth: .infinity, alignment: .leading)
    }
}

/// one thing Chapters does: its tile, a few words, a few more
struct ChapterPoint: View {
    let symbol: String
    let tint: Color
    let title: String
    let sub: String
    let i: Int
    @Environment(\.accessibilityReduceMotion) private var still
    @State private var shown = false
    var body: some View {
        // the tile centred against its words (the way the system's own feature lists sit); the title and its line
        // share one edge, and every line takes two rows, so the four tiles sit on one grid
        HStack(alignment: .center, spacing: 12) {
            IconTile(symbol: symbol, color: tint, size: 34)
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.system(.subheadline, weight: .semibold))
                    .lineLimit(1)
                    .minimumScaleFactor(0.8)
                Text(sub)
                    .font(.system(.footnote))
                    .foregroundStyle(.secondary)
                    .lineLimit(2, reservesSpace: true)
                    .minimumScaleFactor(0.85)
            }
        }
        .opacity(shown || still ? 1 : 0)
        .offset(y: shown || still ? 0 : 10)
        .accessibilityElement(children: .combine)
        .onAppear {
            guard !still else { return }
            withAnimation(Motion.reveal.delay(Motion.stagger(i, after: 0.35))) { shown = true }
        }
    }
}

extension NotebookScenes {
    /// a new car on the road out of town, a bow on its roof: the hills' sky over a road
    static let car: [SceneLayer] = [
        L("M148 50a30 30 0 1 0 60 0a30 30 0 1 0 -60 0", fill: "#E9A23B", alpha: 0.18, motion: .twinkle),
        L("M158 50a20 20 0 1 0 40 0a20 20 0 1 0 -40 0", fill: "#E9A23B", alpha: 0.88),
        L("M30 46a7 7 0 0 1 12 -4a9 9 0 0 1 17 3a6 6 0 0 1 -1 12H33a6 6 0 0 1 -3 -11z", fill: "#FFFDF8", alpha: 0.95, motion: .bob),
        L("M92 30a5 5 0 0 1 9 -3a7 7 0 0 1 13 2a4 4 0 0 1 -1 8H95a4 4 0 0 1 -3 -7z", fill: "#FFFDF8", alpha: 0.9, motion: .bob, delay: 1.6),
        L("M124 22q4-4 8 0q4-4 8 0M142 32q3-3 6 0q3-3 6 0", stroke: "#1F4F8A", lw: 1.4),
        L("M-300 96C-120 88 10 70 70 78S160 98 200 84S280 72 540 86V220H-300Z", fill: "#DCE7F5"),
        L("M-300 112C-80 104 30 90 104 96S206 112 540 100V220H-300Z", fill: "#C4D6EE"),
        L("M-300 128H540V220H-300Z", fill: "#8FA3BF"),
        L("M-300 128H540", stroke: "#6F84A3", lw: 1.4),
        L("M-4 141H244", stroke: "#FFFDF8", lw: 2, alpha: 0.85, dash: [10, 8]),
        L("M28 121V106", stroke: "#1F4F8A", lw: 1.8),
        L("M19 104a9 9 0 1 0 18 0a9 9 0 1 0 -18 0", fill: "#4E86C8"),
        L("M208 121V110", stroke: "#1F4F8A", lw: 1.6),
        L("M201 108a7 7 0 1 0 14 0a7 7 0 1 0 -14 0", fill: "#2F6DB5"),
        L("M74 127V116q0-5 6-6l17-2 14-12q3-2 7-2h27q4 0 7 2l12 12 7 1q5 1 5 7v9z", fill: "#2F6DB5"),
        L("M102 106.5l11-9.5q2-1.5 4.5-1.5H127v11z", fill: "#DCE7F5"),
        L("M131 95.5h14q3 0 5 2l9 9H131z", fill: "#DCE7F5"),
        L("M74 118h101", stroke: "#1F4F8A", lw: 1.2, alpha: 0.5),
        L("M167 111h6v4h-6z", fill: "#E9A23B"),
        L("M74 112h4v5h-4z", fill: "#C2412D", alpha: 0.9),
        L("M85 127a10 10 0 1 0 20 0a10 10 0 1 0 -20 0M143 127a10 10 0 1 0 20 0a10 10 0 1 0 -20 0", fill: "#1E2A3B"),
        L("M91 127a4 4 0 1 0 8 0a4 4 0 1 0 -8 0M149 127a4 4 0 1 0 8 0a4 4 0 1 0 -8 0", fill: "#DCE7F5"),
        L("M129 94V127", stroke: "#C2412D", lw: 3, alpha: 0.9),
        L("M129 90c-7-8-15-3-9 2zM129 90c7-8 15-3 9 2z", fill: "#C2412D", stroke: "#922E1F", lw: 1),
        L("M126.5 90a2.5 2.5 0 1 0 5 0a2.5 2.5 0 1 0 -5 0", fill: "#922E1F"),
        L("M58 70h4v4h-4z", fill: "#E9A23B", motion: .drift, delay: 1.3),
        L("M216 66a2 2 0 1 0 4 0a2 2 0 1 0 -4 0", fill: "#4E86C8", motion: .drift, delay: 2.4),
        L("M14 82l4-2 1 3-4 2z", fill: "#EE8A1E", motion: .drift, delay: 0.7),
        L("M146 10Q146 14 150 14Q146 14 146 18Q146 14 142 14Q146 14 146 10Z", fill: "#E9A23B", motion: .twinkle),
    ]
}
