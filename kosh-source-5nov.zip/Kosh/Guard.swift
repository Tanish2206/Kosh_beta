import SwiftUI
import LocalAuthentication
import UserNotifications

// MARK: - App lock, reminders and budgets
//
// Three things every money app owes its user and kosh didn't have: a lock on the door (Face ID or the phone's
// passcode, off until you turn it on), a nudge before money is due (reminders made on this phone from kosh's own
// calendar: nothing leaves the phone), and a budget to measure the month against (yours, or the usual month).

// MARK: App lock

@Observable
final class AppLock {
    static let shared = AppLock()
    static let key = "kosh.lock"
    var on: Bool = AppLock.startingOn() { didSet { UserDefaults.standard.set(on, forKey: Self.key) } }
    /// the lock as it was left, except once: an earlier lock could ask again and again and keep you out, so the
    /// first launch of this version opens with the lock off; turn it back on in Settings
    static func startingOn() -> Bool {
        let d = UserDefaults.standard
        if !d.bool(forKey: "kosh.lock.reset.v2") {
            d.set(true, forKey: "kosh.lock.reset.v2")
            d.set(false, forKey: key)
            return false
        }
        return d.bool(forKey: key)
    }
    /// the door is shut: the app's contents are covered until Face ID or the passcode opens it
    var locked = false
    private var hidAt: Date?
    private var opening = false
    /// the Face ID or passcode sheet is up: kosh is inactive, but hasn't left the screen
    var authenticating: Bool { opening }

    static var available: Bool {
        var e: NSError?
        return LAContext().canEvaluatePolicy(.deviceOwnerAuthentication, error: &e)
    }
    static var kind: String {
        let c = LAContext()
        _ = c.canEvaluatePolicy(.deviceOwnerAuthentication, error: nil)
        switch c.biometryType { case .faceID: return "Face ID"; case .touchID: return "Touch ID"; case .opticID: return "Optic ID"; default: return "your passcode" }
    }

    func lockIfOn() { if on { locked = true } }
    /// going to the background (not just inactive: the Face ID sheet makes the app inactive too)
    func didHide() { if !opening { hidAt = Date() } }
    /// back in front: lock only after a real trip to the background of more than a moment. Coming back from
    /// the Face ID or passcode sheet is not a trip away, so it never locks again on its own.
    func didShow() {
        guard on else { locked = false; return }
        guard !opening, let h = hidAt else { return }
        hidAt = nil
        if Date().timeIntervalSince(h) < 20 && !locked { return }
        locked = true
        Task { await open() }
    }

    /// Face ID (or Touch ID) first; the passcode only when you ask for it, or when Face ID can't be used
    @MainActor
    func open(passcode: Bool = false) async {
        guard locked, !opening else { return }
        opening = true
        defer { opening = false; hidAt = nil }
        if !passcode {
            let bio = LAContext()
            bio.localizedFallbackTitle = "Use passcode"
            bio.localizedCancelTitle = "Not now"
            if bio.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: nil) {
                do {
                    if try await bio.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, localizedReason: "Open kosh") { locked = false }
                    return
                } catch let e as LAError {
                    // "Use passcode", or Face ID locked after too many tries: go on to the passcode;
                    // cancelled: stay on the lock screen, where a tap tries again
                    guard e.code == .userFallback || e.code == .biometryLockout else { return }
                } catch {
                    return
                }
            }
        }
        let c = LAContext()
        c.localizedCancelTitle = "Not now"
        guard c.canEvaluatePolicy(.deviceOwnerAuthentication, error: nil) else { locked = false; return }
        if (try? await c.evaluatePolicy(.deviceOwnerAuthentication, localizedReason: "Open kosh")) == true { locked = false }
    }
}

/// the cover over the app while it's locked
struct LockScreen: View {
    @Bindable var lock: AppLock
    var body: some View {
        ZStack {
            Color(uiColor: .systemBackground).ignoresSafeArea()
            VStack(spacing: 18) {
                Image(systemName: "lock.fill").font(.system(size: 44, weight: .semibold)).foregroundStyle(Color.kosh.gradient)
                Text("kosh is locked").font(.title2.weight(.bold))
                Button { Task { await lock.open() } } label: {
                    Label("Open with " + AppLock.kind, systemImage: AppLock.kind == "Touch ID" ? "touchid" : "faceid")
                        .font(.body.weight(.semibold)).padding(.horizontal, 6)
                }
                .buttonStyle(.borderedProminent).koshFilled()
                Button("Use passcode") { Task { await lock.open(passcode: true) } }
                    .font(.subheadline.weight(.medium))
            }
        }
        .task { await lock.open() }
    }
}

// MARK: Reminders

enum Reminders {
    static let key = "kosh.reminders"
    static var on: Bool {
        get { UserDefaults.standard.bool(forKey: key) }
        set { UserDefaults.standard.set(newValue, forKey: key) }
    }

    /// ask the phone once; false when refused
    static func enable() async -> Bool {
        let c = UNUserNotificationCenter.current()
        let s = await c.notificationSettings()
        switch s.authorizationStatus {
        case .authorized, .provisional, .ephemeral: on = true; return true
        case .denied: return false
        default:
            let ok = (try? await c.requestAuthorization(options: [.alert, .sound, .badge])) ?? false
            on = ok
            return ok
        }
    }

    static func disable() {
        on = false
        UNUserNotificationCenter.current().removeAllPendingNotificationRequests()
    }

    /// kosh locked, or the amounts hidden: reminders keep the figures and the card's digits to themselves ("A card bill
    /// is due tomorrow."); open kosh for the rest
    static func quiet(_ store: Store) -> Bool { AppLock.shared.on || store.hidden }

    /// the reminders made again from what the store shows now. Never from a ledger not yet read in (kosh started while
    /// the phone was locked): an empty calendar would take every reminder away.
    static func reschedule(_ store: Store) {
        if let live = store.live, !live.loadedFromDisk { return }
        let marked: Set<String> = store.live.map { Set($0.paidMarks.keys) } ?? []
        schedule(store.snap.whole, left: store.leftNow, budget: store.snap.fc.budget, quiet: quiet(store), marked: marked)
    }

    /// what's coming, as the phone's own reminders: each dated outgoing (an EMI, a bill, a premium, a card bill,
    /// property tax, a committee's day) the evening before and the morning of; rent due the morning of; and one
    /// nudge when the month runs past its budget. Remade from scratch after every rebuild, so nothing stale rings,
    /// and each keeps its name, so remaking one replaces it. A bill's reminder carries the bill (Mark paid, Snooze, a
    /// tap opens it: see Notify); a bill now paid takes its reminders away, the ones already rung too. `marked`: bills
    /// you've marked paid, counted paid here even before the build that says so.
    static func schedule(_ snap: Snapshot, left: Double, budget: Double, quiet: Bool, marked: Set<String> = []) {
        guard on else { return }
        let c = UNUserNotificationCenter.current()
        var reqs: [UNNotificationRequest] = []
        var noticed: [UNNotificationRequest] = []
        var woken: [UNNotificationRequest] = []
        let today = snap.today
        let horizon = Day.add(today, 45)
        let open: [AgendaItem] = snap.agenda.filter { !$0.booked && $0.date != nil && !marked.contains($0.id) }
        // bills you snoozed and still to pay: when each rings again
        let snoozes: [String: Double] = snoozed(keeping: Set(open.map(\.id)))
        func content(_ title: String, _ body: String, thread: String, item: AgendaItem? = nil) -> UNMutableNotificationContent {
            let out = UNMutableNotificationContent()
            out.title = title; out.body = body; out.sound = .default
            out.threadIdentifier = thread
            var info: [String: Any] = ["quiet": quiet]
            if let a = item {
                let kind: String = a.kind == "in" ? "in" : a.cat == "Card Payments" ? "card" : a.cat == "committee" ? "committee" : "bill"
                info["item"] = a.id
                info["kind"] = kind
                info["due"] = a.date ?? ""
                // a committee's month is recorded in its book, not marked here: its reminder opens the day, nothing more
                if kind == "card" || kind == "bill" { out.categoryIdentifier = Notify.bill }
            }
            out.userInfo = info
            return out
        }
        func make(_ id: String, _ title: String, _ body: String, on date: String, hour: Int, minute: Int = 0, item: AgendaItem? = nil) {
            guard date >= today, date <= horizon, let d = Day.parser.date(from: date) else { return }
            var comps = Day.cal.dateComponents([.year, .month, .day], from: d)
            comps.hour = hour; comps.minute = minute
            let fire: Date? = Day.cal.date(from: comps)
            if date == today, let fire, fire <= Date() { return }
            // snoozed: not before the time you said
            if let a = item, let t = snoozes[a.id], let fire, fire.timeIntervalSince1970 < t { return }
            reqs.append(UNNotificationRequest(identifier: id, content: content(title, body, thread: "kosh", item: item),
                                              trigger: UNCalendarNotificationTrigger(dateMatching: comps, repeats: false)))
        }
        for a in open {
            guard let d = a.date else { continue }
            if a.kind == "in" {
                let coming: String = Fmt.rupees(a.amt) + " is due to come in today."
                make("in|" + a.id, quiet ? "" : a.name, quiet ? "Money is due to come in today." : coming, on: d, hour: 9, item: a)
            } else {
                let eve = words(a, ringing: Day.add(d, -1), quiet: quiet)
                make("eve|" + a.id, eve.title, eve.body, on: Day.add(d, -1), hour: 19, item: a)
                let day = words(a, ringing: d, quiet: quiet)
                make("day|" + a.id, day.title, day.body, on: d, hour: 8, minute: 30, item: a)
                if let t = snoozes[a.id] {
                    let at = Date(timeIntervalSince1970: t)
                    let w = words(a, ringing: Day.iso(at), quiet: quiet)
                    woken.append(UNNotificationRequest(identifier: "snooze|" + a.id, content: content(w.title, w.body, thread: "kosh", item: a),
                                                       trigger: UNTimeIntervalNotificationTrigger(timeInterval: max(5, at.timeIntervalSinceNow), repeats: false)))
                }
            }
        }
        // what kosh noticed that needs you (a late fee, a charge twice, a big spend, a bill the accounts can't cover):
        // once each, in the daytime. When each was set to ring is kept, so a rebuild never rings it twice
        let rang: [String: Double] = LiveSession.times(.noticedAt)
        var keep = rang.filter { Date().timeIntervalSince1970 - $0.value < 45 * 86_400 }
        for f in snap.watch ?? [] where f.sev >= 3 || ["dup", "fee", "unusual"].contains(f.kind) {
            let fire: Date
            if let t = rang[f.id] {
                fire = Date(timeIntervalSince1970: t)
                if fire <= Date() { continue }
            } else {
                let now = Date(), h = Day.cal.component(.hour, from: now)
                if h >= 9 && h < 21 { fire = now.addingTimeInterval(60) } else {
                    var c = Day.cal.dateComponents([.year, .month, .day], from: h >= 21 ? Day.cal.date(byAdding: .day, value: 1, to: now) ?? now : now)
                    c.hour = 9; c.minute = 30
                    fire = Day.cal.date(from: c) ?? now.addingTimeInterval(3600)
                }
                keep[f.id] = fire.timeIntervalSince1970
            }
            let note = content(quiet ? "" : f.title, quiet ? "kosh noticed something that needs a look." : f.detail, thread: "kosh.noticed")
            noticed.append(UNNotificationRequest(identifier: "noticed|" + f.id, content: note,
                                              trigger: UNTimeIntervalNotificationTrigger(timeInterval: max(5, fire.timeIntervalSinceNow), repeats: false)))
        }
        LiveSession.setTimes(.noticedAt, keep)
        if budget > 0 && left < 0 {
            let over: String = "Over by " + Fmt.rupees(-left) + " with " + String(snap.fc.left) + " days to go."
            make("over", "Past this month's budget", quiet ? "Open kosh to see where it went." : over, on: today, hour: 20)
        } else if budget > 0 && left < budget * 0.1 && snap.fc.left > 5 {
            let tight: String = Fmt.rupees(left) + " left for " + String(snap.fc.left) + " days."
            make("tight", "The month is running tight", quiet ? "Open kosh to see what's left." : tight, on: today, hour: 20)
        }
        // bills the snapshot shows paid (the bank's debit came, or you marked it): their reminders go, the ones
        // already on the Lock Screen too
        let paid: [String] = snap.agenda.filter { ($0.booked || marked.contains($0.id)) && $0.kind != "in" }
            .flatMap { (a: AgendaItem) -> [String] in ["eve|" + a.id, "day|" + a.id, "snooze|" + a.id] }
        if !paid.isEmpty { c.removeDeliveredNotifications(withIdentifiers: paid) }
        // figures hidden: reminders already on the Lock Screen with figures in them go
        if quiet {
            c.getDeliveredNotifications { shown in
                let loud: [String] = shown.filter { ($0.request.content.userInfo["quiet"] as? Bool) != true }.map(\.request.identifier)
                if !loud.isEmpty { c.removeDeliveredNotifications(withIdentifiers: loud) }
            }
        }
        // what's no longer coming goes (reminders you asked Ask kosh for stay); the rest are set again, snoozed and
        // noticed first
        let fresh = Array((woken + noticed + reqs).prefix(60))
        c.getPendingNotificationRequests { pending in
            // the phone keeps only the 64 soonest: room is left for the others' (Ask kosh's, and the two briefings,
            // set or about to be), so a Sunday digest isn't pushed out by reminders weeks away
            let others: Int = pending.filter { Reminders.ownedElsewhere($0.identifier) && !$0.identifier.hasPrefix("brief|") }.count + 2
            let toSet = Array(fresh.prefix(max(0, 64 - others)))
            let ids = Set(toSet.map(\.identifier))
            let stale = pending.map(\.identifier).filter { !ids.contains($0) && !Reminders.ownedElsewhere($0) }
            c.removePendingNotificationRequests(withIdentifiers: stale)
            for r in toSet { c.add(r) }
            // Ask kosh's reminders keep their day; with the figures hidden, they keep their words to themselves too
            if quiet {
                for r in pending where r.identifier.hasPrefix("agent|") && (r.content.userInfo["quiet"] as? Bool) != true {
                    c.add(UNNotificationRequest(identifier: r.identifier, content: Reminders.quietReminder(), trigger: r.trigger))
                }
            }
        }
    }

    /// what a bill's reminder says on the day it rings: "Tomorrow: HDFC card ••1234 bill", "₹12,400 · Minimum ₹910".
    /// With the figures hidden, only what kind of bill and when: "A card bill is due tomorrow."
    static func words(_ a: AgendaItem, ringing day: String, quiet: Bool) -> (title: String, body: String) {
        let due: String = a.date ?? day
        let n: Int = Day.between(day, due)
        var when: String = "is due " + Day.short(due)
        var title: String = a.name + " on " + Day.short(due)
        if n == 0 { when = "is due today"; title = a.name + " today" }
        else if n == 1 { when = "is due tomorrow"; title = "Tomorrow: " + a.name }
        else if n < 0 { when = "is late"; title = a.name + " is late" }
        if quiet { return ("", what(a) + " " + when + ".") }
        return (title, Fmt.rupees(a.amt) + " · " + a.sub)
    }

    /// a bill in a word or two, with nothing in it that's yours
    static func what(_ a: AgendaItem) -> String {
        switch a.cat {
        case "Card Payments": return "A card bill"
        case "committee": return "A committee instalment"
        case "Insurance": return "A premium"
        default: return "A payment"
        }
    }

    /// notifications other parts of kosh set and remake themselves, never stale here: Ask kosh's reminders, the
    /// briefings (Brief.swift) and the plan's (Plan.swift)
    static func ownedElsewhere(_ id: String) -> Bool { ["agent|", "brief|", "plan|", "prem|"].contains { id.hasPrefix($0) } }

    /// a reminder you asked Ask kosh for, with the figures hidden: its day stays, its words don't
    static func quietReminder() -> UNMutableNotificationContent {
        let content = UNMutableNotificationContent()
        content.title = "kosh reminder"
        content.body = "Something you asked kosh to remind you about."
        content.sound = .default
        content.threadIdentifier = "kosh.agent"
        content.userInfo = ["quiet": true]
        return content
    }

    // MARK: Snooze and paid

    /// snoozed bills: the calendar item's id → when it rings again (seconds since 1970). In the protected profile with
    /// kosh beta (LiveSession.OwnTimes)
    static var snoozes: [String: Double] {
        get { LiveSession.times(.snoozed) }
        set { LiveSession.setTimes(.snoozed, newValue) }
    }

    /// when a snoozed bill rings again: due today (or late), in three hours so the day isn't missed, if that's still
    /// daytime; otherwise the next morning at nine
    static func snoozeTime(due: String, now: Date = Date()) -> Date {
        var nine = Day.cal.dateComponents([.year, .month, .day], from: now)
        nine.hour = 9; nine.minute = 0
        var morning: Date = Day.cal.date(from: nine) ?? now.addingTimeInterval(12 * 3600)
        if morning <= now { morning = Day.cal.date(byAdding: .day, value: 1, to: morning) ?? now.addingTimeInterval(12 * 3600) }
        let today: String = Day.iso(now)
        if !due.isEmpty && due <= today {
            let soon: Date = now.addingTimeInterval(3 * 3600)
            let h: Int = Day.cal.component(.hour, from: soon)
            if Day.iso(soon) == today && h >= 9 && h < 22 { return soon }
        }
        return morning
    }

    /// Snooze, from a bill's reminder: kept, so every rebuild sets it again (and nothing of that bill rings before it)
    static func snooze(_ item: String, due: String) {
        snoozes[item] = snoozeTime(due: due).timeIntervalSince1970
    }

    /// the snoozes still to ring, of bills still to pay; the rest are let go
    static func snoozed(keeping open: Set<String>) -> [String: Double] {
        let now: Double = Date().timeIntervalSince1970
        let all: [String: Double] = snoozes
        let s: [String: Double] = all.filter { $0.value > now && open.contains($0.key) }
        if s.count != all.count { snoozes = s }
        return s
    }

    /// a bill's snooze still to ring, if it has one (what Undo of "Marked as paid" puts back)
    static func snoozeOf(_ item: String) -> Double? {
        guard let t = snoozes[item], t > Date().timeIntervalSince1970 else { return nil }
        return t
    }

    /// a snooze put back as it was: the next reminders made leave the bill quiet until then
    static func restoreSnooze(_ item: String, until t: Double) {
        snoozes[item] = t
    }

    /// a bill paid: its reminders go, still to ring and already rung, and its snooze with them
    static func clear(_ item: String) {
        let ids: [String] = ["eve|" + item, "day|" + item, "snooze|" + item]
        let c = UNUserNotificationCenter.current()
        c.removePendingNotificationRequests(withIdentifiers: ids)
        c.removeDeliveredNotifications(withIdentifiers: ids)
        if snoozes[item] != nil { snoozes[item] = nil }
    }
}

// MARK: Reminders you can act on

/// What a reminder does when you answer it. A bill's has Mark paid (after Face ID or the passcode: the bill counts as
/// paid until the bank's mail shows it, Store.markPaid) and Snooze (Reminders.snoozeTime). A tap opens what it's
/// about: a card bill on its card, any other bill or money coming in on its day in the calendar, something kosh
/// noticed in its sheet, the budget's nudge on the month. Set as kosh starts (KoshAppDelegate), before a reminder can
/// be answered; while kosh is open, reminders still show as banners.
final class Notify: NSObject, UNUserNotificationCenterDelegate {
    static let shared = Notify()
    /// a bill's reminder: its two buttons
    static let bill = "kosh.bill"
    /// the household the answers work on, handed over as kosh starts (KoshApp)
    weak var store: Store?

    static func register() {
        let paid = UNNotificationAction(identifier: "paid", title: "Mark paid", options: [.authenticationRequired],
                                        icon: UNNotificationActionIcon(systemImageName: "checkmark.circle"))
        let snooze = UNNotificationAction(identifier: "snooze", title: "Snooze", options: [],
                                          icon: UNNotificationActionIcon(systemImageName: "moon.zzz"))
        let c = UNUserNotificationCenter.current()
        c.setNotificationCategories([UNNotificationCategory(identifier: bill, actions: [paid, snooze], intentIdentifiers: [], options: [])])
        c.delegate = shared
    }

    /// kosh is open: the reminder shows all the same
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification,
                                withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        completionHandler([.banner, .list, .sound])
    }

    /// what was answered, taken off the reminder before going to the main thread
    struct Answer { let id: String; let action: String; let item: String; let kind: String; let due: String }

    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse,
                                withCompletionHandler completionHandler: @escaping () -> Void) {
        let info = response.notification.request.content.userInfo
        let a = Answer(id: response.notification.request.identifier, action: response.actionIdentifier,
                       item: info["item"] as? String ?? "", kind: info["kind"] as? String ?? "", due: info["due"] as? String ?? "")
        // the phone may ask on any thread: the store and the screens are the main thread's
        Task { @MainActor in
            Notify.shared.answer(a)
            completionHandler()
        }
    }

    @MainActor
    func answer(_ a: Answer) {
        guard let store else { return }
        switch a.action {
        case "paid":
            guard !a.item.isEmpty else { return }
            // Undo only when kosh is on screen; from the Lock Screen it's saved before iOS puts kosh away again
            store.markPaid(a.item, undo: UIApplication.shared.applicationState == .active)
            store.live?.flushSaves()
        case "snooze":
            guard !a.item.isEmpty else { return }
            Reminders.snooze(a.item, due: a.due)
            Reminders.reschedule(store)
        case UNNotificationDefaultActionIdentifier:
            open(a, store)
        default:
            break
        }
    }

    /// a tap: what the reminder was about, opened
    @MainActor
    func open(_ a: Answer, _ store: Store) {
        store.sheet = nil
        store.betaSheet = nil
        if a.id.hasPrefix("noticed|") {
            store.betaSheet = .noticed(String(a.id.dropFirst("noticed|".count)))
            return
        }
        // the Sunday digest opens the week; the morning briefing, Home, where it leads
        if a.id == BriefNotes.sundayID {
            store.betaSheet = .digest
            return
        }
        if a.id == BriefNotes.morningID {
            store.tab = .home
            store.homeSub = .overview
            store.homePath = []
            return
        }
        if a.id == "over" || a.id == "tight" {
            store.tab = .home
            store.homeSub = .overview
            store.homePath = [.month(store.snap.cm)]
            return
        }
        guard !a.item.isEmpty else { return }
        // a card's bill: its card on Cards (unfolded there), seen as the family when it's someone else's. A bill no card
        // of kosh's claims goes to its day on the calendar, as any other bill (Bills, its old place, is gone: 1 Nov)
        if a.kind == "card", let card = Notify.card(for: a.item, store.snap.cards) {
            store.txSub = .accounts
            if !store.cards.contains(where: { $0.id == card }) { store.who = .family }
            UserDefaults.standard.set("cards", forKey: "accts.part")
            store.cardJump = card
            store.land(.transactions)
            return
        }
        // any other bill, a committee's day or money coming in: its day on the calendar (today, once it's gone by)
        store.tab = .home
        store.homeSub = .overview
        store.homePath = [.calendar]
        let today: String = store.snap.today
        store.calendarDay = a.due.isEmpty || a.due < today ? today : a.due
    }

    /// the card row a card bill belongs to: the bill's name starts with the card's ("HDFC card ••1234 bill"), the
    /// way the Bills list pairs them (Store.billBook); the longest name wins
    static func card(for item: String, _ cards: [CardInfo]) -> String? {
        let name: String = item.split(separator: "|", maxSplits: 2, omittingEmptySubsequences: false).last.map(String.init) ?? item
        var best: (id: String, len: Int)? = nil
        for c in cards {
            let key: String = c.id.replacingOccurrences(of: " CC ", with: " card ")
            if name.hasPrefix(key) && key.count > (best?.len ?? 0) { best = (c.id, key.count) }
        }
        return best?.id
    }
}

// MARK: Budgets

/// the month's budget and each category's, set here; what's left shows on Home and in Insights
struct BudgetsSheet: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    @State private var month = ""
    @State private var edits: [String: String] = [:]

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    // the usual month as the hint, unless amounts are hidden (a placeholder can't be redacted)
                    let usual: String = Fmt.rupees(store.snap.fc.usual).replacingOccurrences(of: "₹", with: "")
                    HStack {
                        Text("₹").foregroundStyle(.secondary)
                        TextField(store.hidden ? "Your usual month" : usual, text: $month).keyboardType(.numberPad)
                    }
                } header: { Text("The month") } footer: {
                    Text(store.snap.fc.usual > 0 ? "Leave it empty and kosh uses your usual month, " + Fmt.rupees(store.snap.fc.usual) + ", worked out from the last three."
                                                : "Leave it empty and kosh uses your usual month once it has seen a few.")
                        .privacySensitive()
                }
                Section {
                    ForEach(store.snap.fc.cats.sorted(by: Self.order), id: \.cat) { c in
                        HStack(spacing: 12) {
                            IconTile(symbol: c.sym, color: Color(hex: c.color), size: 30)
                            VStack(alignment: .leading, spacing: 1) {
                                Text(c.cat).font(.body)
                                Text("usually " + Fmt.rupees(Fmt.roundish(c.usual))).font(.caption).foregroundStyle(.secondary)
                                    .privacySensitive()
                            }
                            Spacer()
                            TextField("none", text: Binding(get: { edits[c.cat] ?? "" }, set: { edits[c.cat] = $0 }))
                                .keyboardType(.numberPad).multilineTextAlignment(.trailing).frame(width: 96)
                        }
                    }
                } header: { Text("By category") } footer: {
                    Text("A category with a budget shows how much of it is left, and kosh tells you at 90%. The rest are measured against their usual month.")
                }
            }
            .navigationTitle("Budgets")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) { Button("Save") { save(); dismiss() } }
            }
            // opened from a card or from Settings, as its own sheet: it hides its figures itself
            .redacted(reason: store.hidden ? .privacy : [])
            .onAppear {
                guard let live = store.live else { return }
                if live.budget > 0 { month = String(Int(safe: live.budget)) }
                for (k, v) in live.budgets where v > 0 { edits[k] = String(Int(safe: v)) }
            }
        }
    }

    /// categories with a budget first, then by their usual month
    static func order(_ a: FcCat, _ b: FcCat) -> Bool {
        let ab: Bool = (a.limit ?? 0) > 0, bb: Bool = (b.limit ?? 0) > 0
        if ab != bb { return ab }
        return a.usual > b.usual
    }

    func save() {
        guard let live = store.live else { return }
        // up to ₹1,000 crore: a run of typed digits is a mistake, never a budget
        live.budget = TypedAmount.whole(month) ?? 0
        var b: [String: Double] = [:]
        for (k, v) in edits { if let n = TypedAmount.whole(v), n > 0 { b[k] = n } }
        live.budgets = b
    }
}

/// each category against its budget (or its usual month) with what's still to go out
struct BudgetsCard: View {
    @Environment(Store.self) private var store
    @State private var editing = false
    var body: some View {
        let cats: [FcCat] = store.snap.fc.cats.filter { ($0.limit ?? 0) > 0 || $0.usual > 500 }
        let rows: [FcCat] = Array(cats.sorted(by: BudgetsSheet.order).prefix(8))
        VStack(alignment: .leading, spacing: 8) {
            HStack(alignment: .center) {
                Text("Budgets").font(.title2.weight(.bold)).accessibilityAddTraits(.isHeader)
                Spacer(minLength: 8)
                if store.live != nil {
                    Button("Set") { editing = true }
                        .font(.body.weight(.semibold))
                        .frame(minWidth: 44, minHeight: 44)
                        .accessibilityLabel("Set budgets")
                }
            }
            .frame(minHeight: 44)
            // budgets are the household's: under one person they still count everyone's spending, and say so
            if store.who != .family && !rows.isEmpty {
                Label("The household’s budgets: everyone’s spending counts against them.", systemImage: "person.2")
                    .font(.footnote).foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
            if rows.isEmpty {
                Text("Once kosh has seen a month or two, each category shows here against its usual.").font(.subheadline).foregroundStyle(.secondary)
            } else {
                VStack(spacing: 0) {
                    ForEach(Array(rows.enumerated()), id: \.element.cat) { i, c in
                        if i > 0 { InsightDivider() }
                        BudgetRow(c: c, days: store.snap.fc.left)
                    }
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 4)
                .frame(maxWidth: .infinity, alignment: .leading)
                .insightCard(26)
                .privacySensitive()
            }
        }
        .sheet(isPresented: $editing) { BudgetsSheet().presentationDetents([.large]) }
    }
}

struct BudgetRow: View {
    let c: FcCat
    let days: Int
    @Environment(\.accessibilityReduceMotion) private var reduce
    @State private var grown = false
    var body: some View {
        let own: Bool = (c.limit ?? 0) > 0
        let lim: Double = own ? (c.limit ?? 0) : c.usual
        let due: Double = c.committed ?? 0
        let f: Double = lim > 0 ? min(1, c.sofar / lim) : 0
        let fc: Double = lim > 0 ? min(1, (c.sofar + due) / lim) : 0
        let col: Color = Color(hex: c.color)
        let over: Bool = lim > 0 && c.sofar > lim
        // near means what's actually been spent: repeats still due this month are expected, not used up
        let near: Bool = lim > 0 && !over && c.sofar >= lim * 0.9
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 12) {
                IconTile(symbol: c.sym, color: col, size: 38)
                HStack(spacing: 6) {
                    Text(c.cat).font(.subheadline.weight(.semibold)).lineLimit(1)
                    if own {
                        Text("budget")
                            .font(.caption2.weight(.semibold))
                            .foregroundStyle(InsightInk.blue)
                            .padding(.horizontal, 7)
                            .frame(minHeight: 20)
                            .background(Color.kosh.opacity(0.12), in: Capsule())
                            .fixedSize()
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                Text("\(Text(Fmt.short(c.sofar)).foregroundStyle(over ? InsightInk.warn : Color.primary))\(Text(" / " + Fmt.short(lim)).fontWeight(.medium).foregroundStyle(Color.secondary))")
                    .font(.system(.subheadline, design: .rounded, weight: .semibold))
                    .monospacedDigit()
                    .lineLimit(1)
                    .minimumScaleFactor(0.75)
                    .layoutPriority(1)
            }
            VStack(alignment: .leading, spacing: 6) {
                GeometryReader { g in
                    ZStack(alignment: .leading) {
                        Capsule().fill(Color.primary.opacity(0.08))
                        if !over {
                            Capsule().fill(col.opacity(0.32)).frame(width: max(0, g.size.width * fc * (grown ? 1 : 0)))
                        }
                        Capsule().fill(over ? Color.orange : col)
                            .frame(width: max(f > 0 ? 3 : 0, g.size.width * (over ? 1 : f) * (grown ? 1 : 0.02)))
                    }
                }
                .frame(height: 6)
                BudgetRow.note(c: c, lim: lim, due: due, own: own, over: over, near: near)
            }
            .padding(.leading, 50)
        }
        .padding(.vertical, 12)
        .accessibilityElement(children: .combine)
        .onAppear {
            if reduce { grown = true } else { withAnimation(Motion.reveal.delay(0.1)) { grown = true } }
        }
    }

    /// the line under the bar: over, nearly there, still to go out, or what's to spare
    @ViewBuilder
    static func note(c: FcCat, lim: Double, due: Double, own: Bool, over: Bool, near: Bool) -> some View {
        if over {
            HStack(spacing: 5) {
                Image(systemName: "exclamationmark.triangle").font(.caption2.weight(.bold))
                Text("Over by " + Fmt.short(c.sofar - lim))
            }
            .font(.footnote.weight(.semibold))
            .foregroundStyle(InsightInk.warn)
        } else if due > 0 {
            // what's still due (repeats, bills) is expected: it only warns if it would take the month past the line
            let total: Double = c.sofar + due
            let past: Bool = lim > 0 && total > lim * 1.02
            let dueText: String = Fmt.short(due)
            let overText: String = Fmt.short(total - lim)
            let line: String = past ? dueText + " still due · " + overText + " over once it goes"
                : dueText + " due later this month" + (near ? " · nearly used up" : "")
            let strong: Bool = past || near
            Text(line)
                .font(strong ? Font.footnote.weight(.semibold) : Font.footnote)
                .foregroundStyle(strong ? InsightInk.warn : Color.secondary)
        } else if near {
            Text("Nearly used up").font(.footnote.weight(.semibold)).foregroundStyle(InsightInk.warn)
        } else if lim > c.sofar {
            Text(Fmt.short(lim - c.sofar) + (own ? " to spare" : " under your usual"))
                .font(.footnote).foregroundStyle(.secondary)
        }
    }
}

/// the lock and reminders, in Settings
struct GuardSettings: View {
    @Environment(Store.self) private var store
    @State private var lock = AppLock.shared
    @State private var reminders = Reminders.on
    @State private var refused = false
    @State private var budgets = false
    var body: some View {
        Section {
            if AppLock.available {
                Toggle(isOn: Binding(get: { lock.on }, set: { lock.on = $0 })) {
                    SettingsRow(symbol: "faceid", color: Color(hex: "#34C759"), title: "Lock with " + AppLock.kind)
                }
            }
            Toggle(isOn: Binding(get: { reminders }, set: { v in
                // the briefings follow this unless set on their own (BriefNotes.isOn)
                if v { Task { @MainActor in let ok = await Reminders.enable(); reminders = ok; refused = !ok; if ok { Reminders.reschedule(store) }; BriefNotes.reschedule(store) } }
                else { Reminders.disable(); reminders = false; Task { @MainActor in BriefNotes.reschedule(store) } }
            })) {
                SettingsRow(symbol: "bell.badge.fill", color: Color(hex: "#FF3B30"), title: "Remind me before money is due")
            }
            if store.live != nil {
                Button { budgets = true } label: {
                    SettingsRow(symbol: "gauge.with.needle.fill", color: Color(hex: "#FF9500"), title: "Budgets",
                                value: store.snap.fc.own == true ? Fmt.rupees(store.snap.fc.budget) + " a month" : "Usual month",
                                sensitive: true)
                }
                .buttonStyle(.press)
            }
        } header: {
            SettingsHeader("Lock, reminders and budgets")
        } footer: {
            Text(refused ? "Notifications are off for kosh in the phone’s Settings › Notifications; turn them on there."
                         : "EMIs, bills, premiums and rent, the evening before and the morning of. Locked or hidden, they leave the figures out.")
        }
        .sheet(isPresented: $budgets) { BudgetsSheet().presentationDetents([.large]) }
    }
}
