import SwiftUI

// MARK: - Sort these: the payments still in Miscellaneous, a payee at a time
//
// About a sixth of spending payments end up in Miscellaneous. "Sort these" (a row on Transactions, and Up close on
// Insights when it shows Miscellaneous) goes through them a payee at a time, the most money first: one tap on a
// category files every payment to that payee, and kosh learns the payee so its other payments and the next ones
// follow. A sub-category is optional, picked straight after under "Filed". Skip passes a payee over; it waits at the
// end of the queue until kosh closes. Everything shows at once (the rows are laid over the list before the build
// that makes it real), with one Undo for each payee filed.
//
// The same quick refiling serves Transactions' select mode and Find's "Change all": many payments filed, or marked
// for someone, in one go, with one Undo.

/// a set of payments' changes as they were, to put back with Undo: their saved changes, and the rows as shown
struct RefileUndo {
    var saved: [String: Override?] = [:]
    var before: [Txn] = []
}

/// the queue Sort these works from, and what it adds up to: worked out once a build (Store.sortQueue)
struct SortQueue {
    var groups: [PayeeGroup] = []
    var count: Int = 0
    var total: Double = 0
    /// the first and last day of its payments (yyyy-MM-dd)
    var from: String = ""
    var to: String = ""
}

extension Store {
    /// what Sort these takes in: money out still in Miscellaneous (named or not), the whole charge (a split's parts are
    /// filed from the charge's sheet), not a refund, and not one you left out of spending
    static func needsSorting(_ t: Txn) -> Bool {
        t.c == "Miscellaneous" && t.k == "out" && t.partOf == nil && t.refOf == nil && (t.ex ?? "").isEmpty
    }
    /// the payee a payment is learnt under: its UPI ID or its name, as kosh keys it ("n:" and the name when it has neither)
    static func sortKey(_ t: Txn) -> String { (t.lk ?? "").isEmpty ? "n:" + t.m.lowercased() : (t.lk ?? "") }

    /// the payees whose payments are still in Miscellaneous, the most money first, for whoever is picked (one pass over
    /// the payments a build, not one a redraw)
    var sortQueue: SortQueue {
        let w: String = who.id
        if sortMemo.gen == txGen && sortMemo.who == w { return sortMemo.queue }
        let made: SortQueue = sortQueueNow
        sortMemo = (txGen, w, made)
        return made
    }
    private var sortQueueNow: SortQueue {
        var by: [String: [Txn]] = [:]
        var order: [String] = []
        var q = SortQueue()
        for t in tx where Self.needsSorting(t) && who.owns(t.o) {
            let k: String = Self.sortKey(t)
            if by[k] == nil { order.append(k) }
            by[k, default: []].append(t)
            q.count += 1
            q.total += t.a
            if q.from.isEmpty || t.d < q.from { q.from = t.d }
            if t.d > q.to { q.to = t.d }
        }
        let groups: [PayeeGroup] = order.compactMap { k -> PayeeGroup? in
            guard let rows = by[k]?.sorted(by: { $0.d > $1.d }), let top = rows.first else { return nil }
            let vpa: String? = rows.compactMap(\.vpa).first(where: { !$0.isEmpty })
            let total: Double = rows.reduce(0) { $0 + $1.a }
            return PayeeGroup(id: k, name: top.m, rows: rows, total: total, first: rows.last?.d ?? top.d, vpa: vpa,
                              person: PayeeGroup.looksLikePerson(top.m, vpa: vpa))
        }
        q.groups = groups.sorted { $0.total != $1.total ? $0.total > $1.total : $0.rows.count > $1.rows.count }
        return q
    }

    /// "3 Jan – 24 Oct", "3 – 24 Oct", "3 Dec 2025 – 24 Oct 2026": the year only when it isn't this one
    static func sortSpan(_ a: String, _ b: String, today: String) -> String {
        if a.isEmpty { return "" }
        let y: String = String(today.prefix(4))
        let ya: String = String(a.prefix(4))
        let yb: String = String(b.prefix(4))
        if b.isEmpty || a == b { return Day.fmt(a, "d MMM") + (ya == y ? "" : " " + ya) }
        if ya != yb { return Day.fmt(a, "d MMM yyyy") + " – " + Day.fmt(b, "d MMM yyyy") }
        let year: String = ya == y ? "" : " " + ya
        if a.prefix(7) == b.prefix(7) { return Day.fmt(a, "d") + " – " + Day.fmt(b, "d MMM") + year }
        return Day.fmt(a, "d MMM") + " – " + Day.fmt(b, "d MMM") + year
    }

    /// lay changed payments over the list at once, in one change to it (fifty rows filed together redraw once), and
    /// over any build that had already started (Store.edits): hands back the rows as they were
    func layOver(_ ids: Set<String>, _ change: (inout Txn) -> Void) -> [Txn] {
        let gen: Int = live?.buildGen ?? 0
        var rows: [Txn] = tx
        var was: [Txn] = []
        for i in rows.indices where ids.contains(rows[i].id) {
            was.append(rows[i])
            change(&rows[i])
            edits[rows[i].id] = rows[i]
            editGen[rows[i].id] = gen
        }
        if !was.isEmpty { tx = rows }
        return was
    }
    /// put rows back as they were (Undo), at once and over any build still on its way
    func layBack(_ rows: [Txn]) {
        guard !rows.isEmpty else { return }
        let gen: Int = live?.buildGen ?? 0
        var back: [String: Txn] = [:]
        for r in rows { back[r.id] = r }
        var all: [Txn] = tx
        for i in all.indices {
            guard let r = back[all[i].id] else { continue }
            all[i] = r
            edits[r.id] = r
            editGen[r.id] = gen
        }
        tx = all
    }

    /// the payments that follow a payee once you file it: those you never filed yourself (or that only the AI filed)
    func followers(of lk: String) -> Set<String> {
        guard let live, !lk.isEmpty else { return [] }
        var out: Set<String> = []
        for t in tx where t.lk == lk && t.partOf == nil {
            let o: Override? = live.overrides[t.id]
            let own: Bool = o?.c != nil && (o?.by == nil || (o?.only ?? "").contains("c"))
            if !own { out.insert(t.id) }
        }
        return out
    }

    /// file many payments at once: on screen now, one save, one build, one Undo. `learn`: they're one payee's, so kosh
    /// learns the payee and its other payments (and the next ones) follow; otherwise they're filed for themselves only.
    /// The parts of a split charge are filed on the charge, as their sheet does. `undoTo`: Undo goes back to this
    /// instead (a sub-category picked straight after the category takes both back together). Hands back what Undo uses.
    @discardableResult
    func fileMany(_ rows: [Txn], _ c: String, _ s: String, learn: Bool, what: String, undoTo: RefileUndo? = nil) -> RefileUndo {
        guard let live else { return RefileUndo() }
        let whole: [String] = rows.filter { Self.part($0.id) == nil }.map(\.id)
        // (a part's id, its charge's id, and which part it is)
        var parts: [(String, String, Int)] = []
        for t in rows { if let (parent, k) = Store.part(t.id) { parts.append((t.id, parent, k)) } }
        var undo = RefileUndo()
        for id in whole { undo.saved[id] = live.overrides[id] }
        for p in parts where undo.saved[p.1] == nil { undo.saved[p.1] = live.overrides[p.1] }
        // what shows at once: the rows themselves, and the payee's other payments that will follow it
        var show: Set<String> = Set(rows.map(\.id))
        let keys: Set<String> = Set(rows.compactMap { ($0.lk ?? "").isEmpty ? nil : $0.lk })
        if learn, keys.count == 1, let lk = keys.first { show.formUnion(followers(of: lk)) }
        let sym: String = symbol(c)
        undo.before = layOver(show) { t in t.c = c; t.s = s; t.u = false; t.g = false; t.sym = sym }
        if !whole.isEmpty {
            live.overrideMany(whole) { o in
                o.c = c; o.s = s; o.by = nil
                o.only = learn ? Self.without(o.only, "c") : Self.with(o.only, "c")
            }
        }
        for p in parts {
            live.override(p.1) { o in if var ps = o.parts, p.2 < ps.count { ps[p.2].c = c; ps[p.2].s = s; o.parts = ps } }
        }
        live.rebuildSoon()
        let back: RefileUndo = undoTo ?? undo
        undoNote = UndoNote(text: what) { [weak self] in
            self?.restore(back.saved)
            self?.layBack(back.before)
        }
        return back
    }

    /// mark many payments as for someone at once (me, mom, home, work): on screen now, one save, one build, one Undo;
    /// one payee's payments teach kosh the payee, a mix are marked for themselves only. A split's parts are left as
    /// they are.
    func markMany(_ rows: [Txn], for f: String, learn: Bool, what: String) {
        guard let live else { return }
        let ids: [String] = rows.filter { Self.part($0.id) == nil }.map(\.id)
        guard !ids.isEmpty else { return }
        var saved: [String: Override?] = [:]
        for id in ids { saved[id] = live.overrides[id] }
        let before: [Txn] = layOver(Set(ids)) { t in t.f = f; t.fs = true }
        live.overrideMany(ids) { o in o.f = f; o.only = learn ? Self.without(o.only, "f") : Self.with(o.only, "f") }
        live.rebuildSoon()
        undoNote = UndoNote(text: what) { [weak self] in
            self?.restore(saved)
            self?.layBack(before)
        }
    }

    /// one payee's payments (by its UPI ID or its name): kosh can learn it from them
    static func onePayee(_ rows: [Txn]) -> Bool { Set(rows.map { sortKey($0) }).count == 1 }

    /// "12 payments filed as Groceries · Kirana"
    static func filedWords(_ n: Int, _ c: String, _ s: String) -> String {
        let label: String = s.isEmpty ? (c == "Self Transfer" ? "your own account" : c) : c + " · " + s
        return (n == 1 ? "Filed" : String(n) + " payments filed") + " as " + label
    }
}

// MARK: the sheet

struct SortSheet: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    /// the payees as the sheet opened (filing one never reshuffles the rest), the ones skipped before at the end
    @State private var queue: [PayeeGroup] = []
    @State private var index = 0
    @State private var opened = false
    /// each payee's likely categories, and the categories in the order you use them: worked out once, not each redraw
    @State private var likely: [String: [Suggestion]] = [:]
    @State private var cats: [String] = []
    /// the payee just filed, for a sub-category straight after: who, as what, its sub-categories, and how to undo it all
    @State private var last: Filed? = nil
    @State private var payees = 0
    @State private var payments = 0
    @State private var skipped = 0

    struct Filed {
        let g: PayeeGroup
        let at: Int
        let c: String
        var s: String
        let subs: [String]
        let undo: RefileUndo
    }

    var current: PayeeGroup? { index < queue.count ? queue[index] : nil }
    var rest: [PayeeGroup] { Array(queue.dropFirst(index)) }

    var body: some View {
        VStack(spacing: 0) {
            header
                .padding(.horizontal, 20).padding(.top, 20).padding(.bottom, 10)
            ScrollViewReader { proxy in
                ScrollView {
                    VStack(alignment: .leading, spacing: 18) {
                        Color.clear.frame(height: 0).id("top")
                        if let f = last { filedStrip(f) }
                        if let g = current {
                            SortCard(g: g, today: store.snap.today)
                            picks(g)
                        } else if opened {
                            finished
                        }
                    }
                    .padding(.horizontal, 20)
                    .padding(.bottom, 24)
                }
                .onChange(of: index) { _, _ in withAnimation(Motion.base) { proxy.scrollTo("top", anchor: .top) } }
            }
            if current != nil {
                Button { skip() } label: { Text("Skip").frame(maxWidth: .infinity) }
                    .buttonStyle(.glass)
                    .controlSize(.large)
                    .font(.body.weight(.semibold))
                    .padding(.horizontal, 20).padding(.vertical, 12)
            }
        }
        .modifier(UndoBar(lift: current != nil ? 76 : 24))
        .onAppear { open() }
        .sensoryFeedback(.impact(weight: .light), trigger: index)
        .sensoryFeedback(.success, trigger: opened && current == nil && payees > 0)
    }

    // MARK: parts

    var header: some View {
        let left: [PayeeGroup] = rest
        let n: Int = left.reduce(0) { $0 + $1.rows.count }
        let total: Double = left.reduce(0) { $0 + $1.total }
        let from: String = left.map(\.first).min() ?? ""
        let to: String = left.compactMap { $0.rows.first?.d }.max() ?? ""
        let many: String = n == 1 ? "1 payment to sort" : String(n) + " payments to sort"
        let title: String = left.isEmpty ? "Sort these" : many
        let line: String = Fmt.words(total) + " in Miscellaneous · " + Store.sortSpan(from, to, today: store.snap.today)
        return VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .firstTextBaseline) {
                VStack(alignment: .leading, spacing: 2) {
                    Text(title).font(.title2.weight(.bold)).contentTransition(.numericText())
                    if !left.isEmpty {
                        Text(line).font(.subheadline).foregroundStyle(.secondary).contentTransition(.numericText()).privacySensitive()
                    }
                }
                Spacer()
                Button { dismiss() } label: { Image(systemName: "xmark") }
                    .buttonStyle(.glass)
                    .buttonBorderShape(.circle)
                    .accessibilityLabel("Close")
            }
            if queue.count > 1 {
                ProgressView(value: Double(index), total: Double(queue.count))
                    .tint(Color.green)
                    .animation(Motion.open, value: index)
            }
        }
    }

    /// the likely ones first (one tap files and moves on), then every spending category as round marks
    @ViewBuilder func picks(_ g: PayeeGroup) -> some View {
        let sg: [Suggestion] = likely[g.id] ?? []
        if !sg.isEmpty {
            VStack(alignment: .leading, spacing: 8) {
                Text("Likely").font(.footnote.weight(.semibold)).foregroundStyle(.secondary).textCase(.uppercase).padding(.leading, 4)
                ForEach(sg) { s in
                    Button { file(g, s.c, s.s) } label: {
                        HStack(spacing: 10) {
                            IconTile(symbol: s.sym, color: store.catColor(s.c), size: 30)
                            Text(s.label).font(.body.weight(.semibold)).foregroundStyle(Color.primary)
                            Spacer()
                            Text(s.s.isEmpty || s.label == s.c ? "" : s.c).font(.caption).foregroundStyle(.secondary)
                        }
                        .padding(.horizontal, 12).padding(.vertical, 10)
                        .background(Color.raised, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                        .contentShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                    }
                    .buttonStyle(.press)
                }
            }
        }
        VStack(alignment: .leading, spacing: 12) {
            Text("Every category").font(.footnote.weight(.semibold)).foregroundStyle(.secondary).textCase(.uppercase).padding(.leading, 4)
            LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 4), count: 4), alignment: .center, spacing: 14) {
                ForEach(cats, id: \.self) { c in
                    let mark = Suggestion(label: c == "Self Transfer" ? "My own account" : c, c: c, s: "", card: "", merchant: "", sym: store.symbol(c))
                    CategoryMark(p: mark, on: false, color: store.catColor(c), symbol: store.symbol(c)) { file(g, c, "") }
                }
            }
        }
    }

    /// what was just filed, with its sub-categories to pick from (optional; picking one files it again, Undo takes both)
    func filedStrip(_ f: Filed) -> some View {
        let col: Color = store.catColor(f.c)
        let label: String = f.c == "Self Transfer" ? "your own account" : (f.s.isEmpty ? f.c : f.c + " · " + f.s)
        return VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 8) {
                Image(systemName: "checkmark.circle.fill").foregroundStyle(Color.green)
                Text(f.g.name + " filed as " + label).font(.subheadline.weight(.medium)).lineLimit(2)
            }
            if !f.subs.isEmpty {
                ScrollView(.horizontal) {
                    HStack(spacing: 6) {
                        ForEach(f.subs, id: \.self) { s in
                            SubChip(name: s, on: f.s == s, color: col) { refine(f, f.s == s ? "" : s) }
                        }
                    }
                }
                .scrollIndicators(.hidden)
                .padding(.horizontal, -4)
            }
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(col.opacity(0.1), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        .transition(.opacity.combined(with: .move(edge: .top)))
    }

    @ViewBuilder var finished: some View {
        let left: Int = store.sortQueue.count
        VStack(spacing: 10) {
            Image(systemName: "checkmark.circle.fill")
                .font(.system(size: 56))
                .foregroundStyle(Color.green)
            Text(payees > 0 ? "All sorted" : "Nothing to sort").font(.title2.weight(.bold))
            Text(Self.doneWords(payees: payees, payments: payments, skipped: skipped, left: left))
                .font(.subheadline)
                .multilineTextAlignment(.center)
                .foregroundStyle(.secondary)
            Button("Close") { dismiss() }
                .buttonStyle(.glassProminent).koshFilled()
                .controlSize(.large)
                .padding(.top, 8)
        }
        .frame(maxWidth: .infinity)
        .padding(.top, 40)
        .transition(.opacity)
    }

    static func doneWords(payees: Int, payments: Int, skipped: Int, left: Int) -> String {
        if payees == 0 && skipped == 0 { return "Every payment has a category." }
        var s: String = ""
        if payees > 0 {
            let who: String = payees == 1 ? "1 payee" : String(payees) + " payees"
            let what: String = payments == 1 ? "1 payment" : String(payments) + " payments"
            s = who + ", " + what + " filed. New payments to them are filed the same way."
        }
        if left > 0 {
            let rest: String = left == 1 ? "1 payment is" : String(left) + " payments are"
            s += (s.isEmpty ? "" : " ") + rest + " still in Miscellaneous, for another time."
        }
        return s
    }

    // MARK: what the taps do

    func open() {
        guard !opened else { return }
        let all: [PayeeGroup] = store.sortQueue.groups
        let skippedBefore: Set<String> = store.sortSkipped
        queue = all.filter { !skippedBefore.contains($0.id) } + all.filter { skippedBefore.contains($0.id) }
        cats = store.spendCategories + ["Self Transfer"]
        prepare(0)
        opened = true
    }

    /// the likely categories for this payee and the next, ready before they show
    func prepare(_ i: Int) {
        guard i >= 0 && i < queue.count else { return }
        for k in i..<min(queue.count, i + 2) where likely[queue[k].id] == nil {
            likely[queue[k].id] = store.suggestions(for: queue[k]).filter { $0.c != "Miscellaneous" }
        }
    }

    func file(_ g: PayeeGroup, _ c: String, _ s: String) {
        let what: String = Store.filedWords(g.rows.count, c, s) + (g.rows.count > 1 ? " (" + g.name + ")" : "")
        let undo: RefileUndo = store.fileMany(g.rows, c, s, learn: true, what: what)
        hook(at: index)
        let subs: [String] = s.isEmpty && c != "Self Transfer" ? store.quickSubs(c).filter { $0 != "Other" } : []
        payees += 1
        payments += g.rows.count
        store.sortSkipped.remove(g.id)
        withAnimation(Motion.base) {
            last = Filed(g: g, at: index, c: c, s: s, subs: subs, undo: undo)
            index += 1
        }
        prepare(index)
    }

    /// a sub-category for the payee just filed: filed again, and Undo still goes back to before the category
    func refine(_ f: Filed, _ s: String) {
        let what: String = Store.filedWords(f.g.rows.count, f.c, s) + (f.g.rows.count > 1 ? " (" + f.g.name + ")" : "")
        store.fileMany(f.g.rows, f.c, s, learn: true, what: what, undoTo: f.undo)
        hook(at: f.at)
        var g: Filed = f
        g.s = s
        withAnimation(Motion.quick) { last = g }
    }

    /// Undo on this sheet also brings the payee back to the front, to file again
    func hook(at i: Int) {
        guard let n = store.undoNote else { return }
        let rows: Int = queue.indices.contains(i) ? queue[i].rows.count : 0
        store.undoNote = UndoNote(text: n.text) {
            n.undo()
            withAnimation(Motion.base) {
                if i < index {
                    index = i
                    payees = max(0, payees - 1)
                    payments = max(0, payments - rows)
                }
                last = nil
            }
        }
    }

    func skip() {
        guard let g = current else { return }
        store.sortSkipped.insert(g.id)
        skipped += 1
        withAnimation(Motion.base) {
            last = nil
            index += 1
        }
        prepare(index)
    }
}

/// the payee being sorted: who, how much over which days, and its last few payments
struct SortCard: View {
    let g: PayeeGroup
    let today: String
    var body: some View {
        let n: Int = g.rows.count
        let latest: Txn = g.rows[0]
        let way: String = PayWay.line(latest) ?? latest.card
        let span: String = Store.sortSpan(g.first, latest.d, today: today)
        let when: String = (n == 1 ? "1 payment" : String(n) + " payments") + " · " + span
        let amounts: String = g.rows.prefix(4).map { Fmt.rupees($0.a) }.joined(separator: " · ") + (n > 4 ? " …" : "")
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 8) {
                Image(systemName: g.person ? "person.fill" : "storefront.fill").font(.subheadline).foregroundStyle(.secondary)
                Text(g.name).font(.title3.weight(.semibold)).lineLimit(2)
            }
            if let v = g.vpa, !v.isEmpty {
                Text(v).font(.footnote.monospaced()).foregroundStyle(.secondary).lineLimit(1).privacySensitive()
            }
            Text(Fmt.rupees(g.total))
                .scaledFont(size: 40, weight: .bold, design: .rounded, relativeTo: .largeTitle)
                .minimumScaleFactor(0.6)
                .lineLimit(1)
                .privacySensitive()
            Text(when + (way.isEmpty ? "" : " · " + way))
                .font(.subheadline).foregroundStyle(.secondary).lineLimit(1).minimumScaleFactor(0.85)
            if n > 1 {
                Text(amounts).font(.footnote).foregroundStyle(.secondary).lineLimit(1).privacySensitive()
            }
            Text(n == 1 ? "Filing it files the next payments to this payee too." : "Filing it files all \(n), and the next payments to \(g.person ? "them" : "this payee").")
                .font(.footnote).foregroundStyle(.secondary)
                .padding(.top, 2)
        }
        .padding(18)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.surface, in: RoundedRectangle(cornerRadius: 26, style: .continuous))
        .id(g.id)
        .transition(.asymmetric(insertion: .move(edge: .trailing).combined(with: .opacity), removal: .opacity))
    }
}
