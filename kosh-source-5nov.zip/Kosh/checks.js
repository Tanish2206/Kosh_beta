/* kosh checks: whether a reading agrees with itself, before any of its money counts.

   Every reading says how sure it is (`sure`: high, medium, low, or unsure). Then the checks that need nothing but
   the mail and the household's own other mail:
     a receipt's parts      what the wallet paid and what the card or UPI paid make the total it says was paid;
     a receipt's total      what kosh read as paid is not above the order's own total;
     a card bill            its minimum due is not above the total due;
     a balance              an account alert that prints the balance after it moves that balance the way the
                            payment's direction says (the balance went up by exactly a "debit": it was a credit);
     a statement            opening + credits − debits = closing (for a card: what was owed + spends − payments);
     a policy               has its premium, cover and due date, or says which is missing and where it would be
                            (not in its mail; in a PDF that is locked, or not opened yet).
   A reading that fails a check never books money quietly: it waits as unsure (kind unknown, `heldKind` the kind it
   would have been, `doubt` the plain reasons, `reason` the first), which is kosh's existing "not sure" path: the phone
   keeps the mail's words for a teacher (Claude, or you) to settle. Each build says how the reading went
   (snap.readHealth): how many readings are unsure and of what, what failed and why, which statements don't
   reconcile, which policies miss what and where.
   Loaded after packs.js on the phone (LiveCore.swift) and in the phone-path tests; nothing here reads a mail's text. */

var KoshChecks = (function (E) {
  'use strict';
  function num(x) { return typeof x === 'number' && isFinite(x) ? x : null; }
  function evsOf(r) { if (!r || typeof r.evs !== 'string') return []; try { return JSON.parse(r.evs) || []; } catch (e) { return []; } }
  function inr(n) { var a = Math.round(Math.abs(n) * 100) / 100; var s = a % 1 ? a.toFixed(2) : String(a); var p = s.split('.'), x = p[0]; if (x.length > 3) { var last = x.slice(-3), rest = x.slice(0, -3); x = rest.replace(/\B(?=(\d{2})+(?!\d))/g, ',') + ',' + last; } return '₹' + x + (p[1] ? '.' + p[1] : ''); }
  var MONEY = { txn: 1, confirm: 1 };
  var TOL = 1;

  /* ------------------------------------------------------------ how sure a reading is */
  function sureOf(r, evs) {
    if (r.doubt && r.doubt.length) return 'unsure';
    if (r.kind === 'unknown') return 'unsure';
    var main = evs.filter(function (e) { return e && e.type !== 'noise' && e.type !== 'account'; });
    if (r.kind === 'noise') return main.some(function (e) { return e.unsure; }) ? 'low' : 'high';
    if (r.by === 'claude' || r.src === 'claude') return 'high';
    var c = String(r.conf || '').toLowerCase();
    if (c === 'high' || c === 'medium' || c === 'low') return main.some(function (e) { return e.unsure; }) && c === 'high' ? 'medium' : c;
    var p = main.reduce(function (m, e) { return typeof e.p === 'number' ? Math.max(m, e.p) : m; }, -1);
    if (p >= 0) return p >= 0.9 ? 'high' : p >= 0.7 ? 'medium' : 'low';
    return 'medium';
  }

  /* ------------------------------------------------------------ one reading against itself */
  function selfDoubts(r, evs) {
    var out = [];
    if (!r || !MONEY[r.kind]) {
      if (r && r.kind === 'statement') {
        var tot = num(r.amt), mn = num(r.min);
        if (tot !== null && mn !== null && tot > 0 && mn > tot + TOL) out.push('its minimum due (' + inr(mn) + ') is more than its total due (' + inr(tot) + ')');
      }
      return out;
    }
    if (r.cur) return out;   // a charge in another currency: the rupee figures are estimates
    var amt = num(r.amt);
    var order = evs.filter(function (e) { return e && e.type === 'order' && num(e.total) > 0 && !e.cur; })[0];
    var paid = evs.filter(function (e) { return e && e.type === 'move' && e.dir === 'out' && num(e.amt) > 0 && !e.cur; });
    if (Array.isArray(r.also) && r.also.length && amt !== null) {
      var sum = amt + r.also.reduce(function (s, x) { return s + (num(x && x.amt) || 0); }, 0);
      var whole = order ? order.total : paid.length ? Math.max.apply(null, paid.map(function (e) { return e.amt; })) : null;
      if (whole !== null && Math.abs(sum - whole) > TOL) {
        out.push('its parts (' + [amt].concat(r.also.map(function (x) { return num(x && x.amt) || 0; })).map(inr).join(' + ') + ') don’t add up to the ' + inr(whole) + ' it says was paid');
      }
    } else if (r.kind === 'confirm' && order && amt !== null && amt > order.total + TOL && !paid.some(function (e) { return Math.abs(e.amt - amt) <= TOL; })) {
      out.push('kosh read ' + inr(amt) + ' paid, but the order’s own total is ' + inr(order.total));
    }
    return out;
  }

  function hold(r, why) {
    var o = Object.assign({}, r);
    o.heldKind = r.heldKind || r.kind;
    o.kind = 'unknown';
    o.doubt = (r.doubt || []).concat(why.filter(function (w) { return (r.doubt || []).indexOf(w) < 0; }));
    o.reason = 'kosh isn’t sure: ' + o.doubt[0];
    o.sure = 'unsure';
    return o;
  }

  // once per mail as it's read (engine.parse → POST_PARSE): how sure, and whether it agrees with itself
  function afterParse(out) {
    if (!out || typeof out !== 'object') return;
    var evs = evsOf(out);
    var why = selfDoubts(out, evs);
    if (why.length) {
      var h = hold(out, why);
      for (var k in h) if (Object.prototype.hasOwnProperty.call(h, k)) out[k] = h[k];
      return;
    }
    out.sure = sureOf(out, evs);
  }

  /* ------------------------------------------------------------ readings against each other */
  // an account's alerts that print the balance after them: consecutive ones, the gap between their balances, and the
  // later payment's figure. The gap equal to the figure with the other sign (to the paisa) says the direction was misread
  function directionDoubts(records) {
    var by = {};
    records.forEach(function (r, i) {
      if (!r || r.kind !== 'txn' || r.instr !== 'account' || r.cur || num(r.after) === null || !(num(r.amt) > 0) || !r.last4) return;
      if (r.dir !== 'in' && r.dir !== 'out') return;
      var k = (r.inst || '') + '|' + r.last4 + '|' + (r.acct || '');
      (by[k] = by[k] || []).push(i);
    });
    var out = {};
    Object.keys(by).forEach(function (k) {
      var L = by[k].slice().sort(function (a, b) { return String(records[a].sent || records[a].date || '').localeCompare(String(records[b].sent || records[b].date || '')); });
      for (var j = 1; j < L.length; j++) {
        var a = records[L[j - 1]], b = records[L[j]];
        var gap = Math.round((b.after - a.after) * 100) / 100, s = b.dir === 'in' ? 1 : -1;
        if (!gap || Math.abs(gap - s * b.amt) <= 0.01) continue;
        if (Math.abs(gap + s * b.amt) <= 0.01) {
          out[L[j]] = 'it says money ' + (b.dir === 'in' ? 'came in' : 'went out') + ', but the balance it prints ' + (gap > 0 ? 'went up' : 'went down') + ' by exactly ' + inr(b.amt);
        }
      }
    });
    return out;
  }

  function beforeBuild(records) {
    var bad = directionDoubts(records);
    var any = false;
    for (var k in bad) { any = true; break; }
    if (!any) return records;
    return records.map(function (r, i) { return bad[i] ? hold(r, [bad[i]]) : r; });
  }

  /* ------------------------------------------------------------ the build, summed up */
  function stmtReconciles(s) {
    var open = num(s.open), close = num(s.close);
    if (open === null || close === null || !Array.isArray(s.rows) || !s.rows.length) return null;
    var inn = 0, outn = 0;
    s.rows.forEach(function (x) { var a = num(x && x.amt) || 0; if (x && x.dir === 'in') inn += a; else outn += a; });
    var card = s.instr === 'card';
    var want = card ? open + outn - inn : open + inn - outn;
    return Math.abs(want - close) <= TOL ? { ok: true } : { ok: false, want: Math.round(want * 100) / 100, close: close };
  }

  function mask(no) { var s = String(no || '').replace(/\s/g, ''); return s.length > 4 ? '••' + s.slice(-4) : s; }

  function afterBuild(snap, prof, records) {
    records = records || [];
    var sure = { high: 0, medium: 0, low: 0, unsure: 0 };
    var unsureBy = {}, doubts = [];
    records.forEach(function (r) {
      if (!r) return;
      var s = r.sure || (r.kind === 'unknown' ? 'unsure' : '');
      if (sure[s] !== undefined) sure[s]++;
      var unsure = r.kind === 'unknown' || (r.doubt && r.doubt.length);
      if (unsure) {
        var k = r.heldKind || r.instKind || 'other';
        unsureBy[k] = (unsureBy[k] || 0) + 1;
      }
      if (r.doubt && r.doubt.length && doubts.length < 50) doubts.push({ id: r.id, what: r.heldKind || r.kind, from: r.inst || '', why: r.doubt.join('; ') });
    });
    // statements
    var stmts = (prof && Array.isArray(prof.statements)) ? prof.statements : [];
    var unrec = [];
    stmts.forEach(function (s) {
      if (!s) return;
      var c = stmtReconciles(s);
      if (s.ok === false || (c && !c.ok)) unrec.push({ from: s.from || '', last4: s.last4 || '', period: (s.periodFrom || '') + '…' + (s.periodTo || ''),
        why: c && !c.ok ? 'opening and lines come to ' + inr(c.want) + ', it closes at ' + inr(c.close) : (s.note || 'its lines don’t add up to its own figures') });
    });
    // policies: what's missing, and where it would be
    var pol = { n: 0, missing: 0, byWhat: {}, list: [] };
    // (the mail a policy could be in, sorted out once, when the first policy misses something: the readings whose events
    // name a policy, each insurer's mail, the policy papers; and each one's events without their punctuation, worked
    // out once. Every policy walking all the mail, and flattening every reading's events again, grew with the mail times
    // the policies)
    var look = null;
    function mailOf() {
      if (look) return look;
      look = { told: [], byIns: new Map(), papers: [], flat: [] };
      var into = function (k, i) { var l = look.byIns.get(k); if (l) l.push(i); else look.byIns.set(k, [i]); };
      records.forEach(function (r, i) {
        if (!r) return;
        if (typeof r.evs === 'string' && r.evs.indexOf('"policy"') >= 0) look.told.push(i);
        if (r.kind === 'policy' || r.instKind === 'insurer') { into(r.insurer, i); if (r.inst !== r.insurer) into(r.inst, i); }
        if (r.doc && r.doc.kind === 'policy') look.papers.push(i);
      });
      return look;
    }
    function flat(i) { var f = look.flat[i]; if (f === undefined) f = look.flat[i] = records[i].evs.replace(/\W/g, '').toUpperCase(); return f; }
    (Array.isArray(snap.policies) ? snap.policies : []).forEach(function (p) {
      pol.n++;
      var miss = (p.missing || []).slice();
      if (!(p.premium > 0) && miss.indexOf('Premium') < 0) miss.push('Premium');
      if (!(p.cover > 0) && miss.indexOf('Cover') < 0 && !/motor|vehicle/i.test(p.type || '')) miss.push('Cover');
      if (!p.nextDue && !p.ended && miss.indexOf('Due date') < 0) miss.push('Due date');
      if (!miss.length) return;
      pol.missing++;
      miss.forEach(function (m) { pol.byWhat[m] = (pol.byWhat[m] || 0) + 1; });
      var no = String(p.policyNo || '').replace(/\W/g, '').toUpperCase(), M = mailOf();
      // the mail it came from: its number in the reading, else its insurer's mail
      var byNo = no ? M.told.filter(function (i) { return flat(i).indexOf(no) >= 0; }).map(function (i) { return records[i]; }) : [];
      var mine = byNo.length ? byNo : p.insurer ? (M.byIns.get(p.insurer) || []).map(function (i) { return records[i]; }) : [];
      var docs = M.papers.filter(function (i) {
        var r = records[i];
        if (no && typeof r.evs === 'string' && flat(i).indexOf(no) >= 0) return true;
        return !!p.insurer && (r.insurer === p.insurer || r.inst === p.insurer);
      }).map(function (i) { return records[i].doc.state || ''; });
      var where = docs.indexOf('locked') >= 0 ? 'in its PDF, which is locked (a password opens it)'
        : docs.some(function (s) { return s === '' || s === 'older'; }) ? 'in its PDF, not opened yet'
        : docs.indexOf('read') >= 0 ? 'not in its mail or its PDF'
        : docs.indexOf('empty') >= 0 ? 'in a PDF kosh couldn’t read'
        : 'not in its mail (no policy PDF came with it)';
      p.gaps = miss.map(function (m) { return { what: m, at: where }; });
      if (pol.list.length < 40) pol.list.push({ insurer: p.insurer || '', type: p.type || '', no: mask(p.policyNo), missing: miss, where: where, via: p.via || '',
        mails: mine.slice(0, 6).map(function (r) { return { id: r.id, kind: r.kind, rule: r.rule || '', sent: String(r.sent || '').slice(0, 10), sure: r.sure || '' }; }) });
    });
    snap.readHealth = {
      readings: records.length, sure: sure,
      unsure: { n: Object.keys(unsureBy).reduce(function (a, k) { return a + unsureBy[k]; }, 0), byKind: unsureBy },
      doubts: doubts,
      statements: { n: stmts.length, unreconciled: unrec.length, list: unrec.slice(0, 30) },
      policies: pol,
    };
  }

  if (E && E.postParse) E.postParse.push(afterParse);
  if (E && E.preBuild) E.preBuild.push(beforeBuild);
  if (E && E.postBuild) E.postBuild.push(afterBuild);
  var api = { sureOf: sureOf, selfDoubts: selfDoubts, directionDoubts: directionDoubts, stmtReconciles: stmtReconciles, afterParse: afterParse, beforeBuild: beforeBuild, afterBuild: afterBuild };
  if (E) E.checks = api;
  return api;
})(typeof KoshEngine !== 'undefined' ? KoshEngine : require('./engine.js'));
if (typeof module !== 'undefined' && module.exports) module.exports = KoshChecks;
