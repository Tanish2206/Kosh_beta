import SwiftUI

// MARK: - A nudge: a reminder ready for a tenant whose rent is late or due within the week
//
// Opened from the tenant's row under their building (Send a nudge): a draft in three tones (sweet, straight, firm)
// naming the tenant, the month, the amount and the due day, with your UPI ID when Settings has one. Send on WhatsApp
// opens WhatsApp with the draft typed in (straight into their chat when kosh has their number, else you pick the
// chat), Share hands it to any other app, and nothing is ever sent without you pressing send there. Mark received
// is here too, for rent that came in cash.
//
// What counts: this month's rent when it's late, or due in the next seven days; and last month's when it's
// still late (older months stay in the year's windows, so a lease kosh only half saw doesn't read as arrears).

/// a tenant to remind, and what for
struct Nudge: Identifiable {
    let l: TenantsView.Let
    /// the months still owed, oldest first
    let months: [RollMonth]
    /// late, or only due soon
    let late: Bool
    /// late: days since the oldest month's due day; due: days until this month's (below 0 once it's gone by)
    let days: Int
    var id: String { l.id }
    var amount: Double { months.reduce(0) { $0 + $1.amt } }
    /// the oldest owed month's due day
    var due: String { months.first?.due ?? "" }

    /// late ones first (longest late at the top), then the ones due soonest
    static func list(_ lets: [TenantsView.Let], today: String, cm: String) -> [Nudge] {
        let prev: String = Day.addMonths(cm, -1)
        var out: [Nudge] = []
        for l in lets {
            let owed: [RollMonth] = l.u.roll.filter { $0.st == "late" && ($0.m == cm || $0.m == prev) }.sorted { $0.m < $1.m }
            if let first = owed.first {
                out.append(Nudge(l: l, months: owed, late: true, days: max(1, Day.between(first.due ?? today, today))))
                continue
            }
            if let n = l.u.now, n.st == "due", let d = n.due {
                let left: Int = Day.between(today, d)
                if left <= 7 { out.append(Nudge(l: l, months: [n], late: false, days: left)) }
            }
        }
        return out.sorted { a, b in
            if a.late != b.late { return a.late }
            return a.late ? a.days > b.days : a.days < b.days
        }
    }
}

/// how the reminder sounds
enum NudgeTone: String, CaseIterable, Identifiable {
    case sweet, straight, firm
    var id: String { rawValue }
    var title: String {
        switch self {
        case .sweet: return "Sweet"
        case .straight: return "Straight"
        case .firm: return "Firm"
        }
    }
}

// MARK: - The words

enum NudgeWords {
    /// the tenant's name as written, less any phone number typed into it
    static func name(_ u: PropUnit) -> String {
        var s: String = u.tenant
        if let r = s.range(of: phonePattern, options: .regularExpression) { s.removeSubrange(r) }
        s = s.trimmingCharacters(in: CharacterSet(charactersIn: " ,-–·:()"))
        return s
    }
    static let businessWords: Set<String> = ["ltd", "ltd.", "limited", "pvt", "pvt.", "private", "co", "co.", "company", "bank", "store", "stores",
        "traders", "trading", "enterprises", "clinic", "dental", "mobiles", "agency", "agencies", "services", "shop", "mart", "industries",
        "pharma", "medical", "medicos", "chemists", "branch", "hospital", "school", "academy", "studio", "salon", "restaurant", "cafe", "café",
        "foods", "sweets", "hotel", "llp", "inc", "brothers", "bros", "sons", "electronics", "garments", "jewellers", "motors", "office"]
    static let titles: Set<String> = ["mr", "mr.", "mrs", "mrs.", "ms", "ms.", "dr", "dr.", "shri", "smt", "smt.", "sri"]

    /// "Rajesh ji", "Sharma ji" (for "R. K. Sharma"), "Dr Sharma", "Sharma Dental team", or "" when there's no name
    static func greet(_ u: PropUnit) -> String {
        let s: String = name(u)
        var words: [String] = s.split(separator: " ").map(String.init)
        if words.isEmpty { return "" }
        if words.contains(where: { businessWords.contains($0.lowercased()) }) { return s + " team" }
        if words.first?.lowercased() == "the" { words.removeFirst(); return words.isEmpty ? "" : words.joined(separator: " ") }
        if let t = words.first, titles.contains(t.lowercased()) { return s }
        // initials first: the surname is the name to use
        if words[0].count <= 2 || words[0].hasSuffix("."), let last = words.last, last.count > 2 { return last + " ji" }
        return words[0] + " ji"
    }

    /// "Shop 2, SCO 114", or "the ground floor at H1/10"
    static func place(_ l: TenantsView.Let) -> String {
        let label: String = l.u.label.trimmingCharacters(in: .whitespaces)
        if label.isEmpty { return l.p.short }
        if label.lowercased().contains("floor") { return "the " + label.lowercased() + " at " + l.p.short }
        return label + ", " + l.p.short
    }

    /// what's owed and for where: "October’s rent of ₹12,200 for Shop 2, SCO 114", or "the rent for September
    /// and October for Shop 2, SCO 114 (₹24,400 in all)"
    static func owed(_ n: Nudge) -> String {
        let at: String = " for " + place(n.l)
        if n.months.count == 1, let m = n.months.first {
            return Day.monthName(m.m) + "’s rent of " + Fmt.rupees(m.amt) + at
        }
        let names: [String] = n.months.map { Day.monthName($0.m) }
        let list: String = names.dropLast().joined(separator: ", ") + " and " + (names.last ?? "")
        return "the rent for " + list + at + " (" + Fmt.rupees(n.amount) + " in all)"
    }

    /// the reminder, in one of three tones: warm Indian English, the tenant by name, the month, the amount, the
    /// due day, and your UPI ID when Settings has one
    static func draft(_ n: Nudge, tone: NudgeTone, upi: String, today: String) -> String {
        let who: String = greet(n.l.u)
        let rent: String = owed(n)
        let dueOn: String = Day.fmt(n.due, "d MMM")
        let by: String = Day.fmt(Day.add(today, 3), "d MMM")
        let pay: String = upi.trimmingCharacters(in: .whitespaces)
        let many: Bool = n.months.count > 1
        // past its day: late, or in the two days' grace kosh gives before calling it late
        let gone: Bool = n.late || n.days < 0
        let dueBit: String = gone ? "was due on " + dueOn : (n.days == 0 ? "is due today" : "is due on " + dueOn)
        var s: String = ""
        switch tone {
        case .sweet:
            s = (who.isEmpty ? "Namaste!" : "Namaste " + who + "!") + " Hope sab badhiya hai. "
            if n.late {
                s += "Just a gentle reminder that " + rent + (many ? " is still pending." : " " + dueBit + ".")
            } else {
                s += "A small heads-up that " + rent + " " + dueBit + "."
            }
            s += pay.isEmpty ? " Whenever you get a moment, please send it across." : " Whenever you get a moment, you can send it to my UPI ID " + pay + "."
            s += " Thank you so much! 🙏"
        case .straight:
            s = who.isEmpty ? "Hi," : "Hi " + who + ","
            if n.late {
                s += " " + rent + (many ? " hasn’t reached me yet. Could you send it this week?" : " " + dueBit + " and hasn’t reached me yet. Could you send it today?")
            } else {
                s += " a quick reminder that " + rent + " " + dueBit + "."
            }
            s += pay.isEmpty ? " UPI or bank transfer, whichever’s easier." : " My UPI ID is " + pay + "."
            s += " Thanks!"
        case .firm:
            s = who.isEmpty ? "Hello," : "Hello " + who + ","
            if n.late {
                if many {
                    s += " " + rent + " is overdue; the first of it was due on " + dueOn + "."
                } else {
                    s += " " + rent + " is now " + (n.days == 1 ? "1 day" : String(n.days) + " days") + " past its due date of " + dueOn + "."
                }
                s += " Please clear it by " + by + "."
            } else {
                s += " " + rent + " " + dueBit + "." + (gone ? " Please send it today." : " Please make sure it reaches me on time.")
            }
            if !pay.isEmpty { s += " You can pay on UPI at " + pay + "." }
            s += " Thank you."
        }
        return s
    }

    // MARK: WhatsApp

    /// an Indian mobile number: 98xxxxxxxx, +91 98xxx xxxxx, 091-98xxxxxxxx
    static let phonePattern: String = #"(?:\+?0?91[\s-]?)?[6-9]\d{4}[\s-]?\d{5}"#
    /// the tenant's mobile as WhatsApp wants it ("919812345678"), when kosh has one. Floors have no phone field
    /// yet, so this reads a number typed in with the tenant's name ("Rajesh Kumar 98123 45678")
    static func phone(_ u: PropUnit) -> String? {
        guard let r = u.tenant.range(of: phonePattern, options: .regularExpression) else { return nil }
        let digits: String = String(u.tenant[r]).filter { $0.isASCII && $0.isNumber }
        guard digits.count >= 10 else { return nil }
        return "91" + String(digits.suffix(10))
    }
    /// wa.me with the message typed in: straight to their chat with a number, else WhatsApp asks whom to send it to
    static func whatsapp(_ text: String, phone: String?) -> URL? {
        let safe = CharacterSet(charactersIn: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~")
        guard let q = text.addingPercentEncoding(withAllowedCharacters: safe) else { return nil }
        return URL(string: "https://wa.me/" + (phone ?? "") + "?text=" + q)
    }
}

// MARK: - The reminder

/// a reminder ready to send: the draft in three tones as a chat bubble, and the ways to send it (nothing is sent
/// until you press send in WhatsApp or the app you share it to); Mark received too, for rent that came in cash
struct NudgePanel: View {
    @Environment(Store.self) private var store
    let n: Nudge
    /// once the rent's marked received
    let done: () -> Void
    @State private var tone: NudgeTone = .sweet

    /// the draft as a chat bubble on WhatsApp's wallpaper, the tones above it, and the ways to send it below
    var body: some View {
        let today: String = store.snap.today
        let text: String = NudgeWords.draft(n, tone: tone, upi: store.upi, today: today)
        let phone: String? = NudgeWords.phone(n.l.u)
        let url: URL? = NudgeWords.whatsapp(text, phone: phone)
        let canMark: Bool = store.live != nil
        return VStack(alignment: .leading, spacing: 0) {
            HStack(spacing: 6) {
                ForEach(NudgeTone.allCases) { t in
                    let picked: Bool = t == tone
                    let traits: AccessibilityTraits = picked ? [.isButton, .isSelected] : [.isButton]
                    Button {
                        withAnimation(Motion.base) { tone = t }
                    } label: {
                        Text(t.title)
                            .font(.system(.footnote, weight: .semibold))
                            .lineLimit(1).minimumScaleFactor(0.85)
                            .foregroundStyle(picked ? Color.primary : Color.secondary)
                            .frame(maxWidth: .infinity)
                            .frame(minHeight: 34)
                            .background(picked ? Color.raised : Color.lift(0.35), in: Capsule())
                            .shadow(color: .black.opacity(picked ? 0.1 : 0), radius: 3, y: 1)
                            .contentShape(Capsule())
                    }
                    .buttonStyle(.press)
                    .accessibilityAddTraits(traits)
                }
            }
            .padding(.horizontal, 10)
            .padding(.top, 10)
            .accessibilityElement(children: .contain)
            .accessibilityLabel("Tone of the message")

            VStack(alignment: .trailing, spacing: 4) {
                Text(text)
                    .font(.system(.footnote))
                    .foregroundStyle(Color.primary)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .fixedSize(horizontal: false, vertical: true)
                    .contentTransition(.opacity)
                    .privacySensitive()
                Text("draft, not sent").font(.system(.caption2)).foregroundStyle(NudgeLook.note)
            }
            .padding(.horizontal, 12).padding(.top, 10).padding(.bottom, 6)
            .background(NudgeLook.bubble, in: UnevenRoundedRectangle(topLeadingRadius: 16, bottomLeadingRadius: 16, bottomTrailingRadius: 4, topTrailingRadius: 16, style: .continuous))
            .shadow(color: .black.opacity(0.08), radius: 1, y: 1)
            .padding(.leading, 30)
            .padding(.horizontal, 10)
            .padding(.top, 12)

            HStack(spacing: 8) {
                if let url {
                    Link(destination: url) {
                        ViewThatFits(in: .horizontal) {
                            Label("Send on WhatsApp", systemImage: "paperplane.fill")
                            Label("WhatsApp", systemImage: "paperplane.fill")
                            Image(systemName: "paperplane.fill")
                        }
                        .font(.system(.footnote, weight: .semibold))
                        .lineLimit(1)
                        .foregroundStyle(Color.white)
                        .padding(.horizontal, 10)
                        .frame(maxWidth: .infinity)
                        .frame(minHeight: 42)
                        .background(NudgeLook.send, in: Capsule())
                    }
                    .accessibilityLabel("Open WhatsApp with this message")
                    .accessibilityHint(phone == nil ? "You pick the chat; nothing sends until you press send" : "Opens their chat; nothing sends until you press send")
                }
                ShareLink(item: text) {
                    Image(systemName: "square.and.arrow.up")
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundStyle(Color.kosh)
                        .frame(width: 42, height: 42)
                        .background(Color.raised, in: Circle())
                }
                .accessibilityLabel("Share the message another way")
                if canMark {
                    Button { received() } label: {
                        ViewThatFits(in: .horizontal) {
                            Text(n.months.count > 1 ? "Mark all received" : "Mark received")
                            Text("Received")
                        }
                        .font(.system(.footnote, weight: .semibold))
                        .lineLimit(1)
                        .foregroundStyle(n.late ? RentInk.lateDeep : Color.kosh)
                        .padding(.horizontal, 10)
                        .frame(maxWidth: .infinity)
                        .frame(minHeight: 42)
                        .background(Color.raised, in: Capsule())
                    }
                    .buttonStyle(.press)
                    .accessibilityLabel(n.months.count > 1 ? "Mark all of it received" : "Mark the rent received")
                }
            }
            .padding(10)

            Text(phone == nil ? "WhatsApp opens with this typed in; pick their chat and press send." : "WhatsApp opens their chat with this typed in. Nothing goes until you press send.")
                .font(.system(.caption2)).foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
                .padding(.horizontal, 12)
                .padding(.bottom, 10)
        }
        .background(NudgeLook.paper, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
        .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
        .sensoryFeedback(.selection, trigger: tone)
    }

    /// cash rent, or a credit kosh couldn't match: every month in the nudge marked received
    func received() {
        let p: Prop = n.l.p
        let idx: Int = n.l.u.idx ?? 0
        withAnimation(Motion.open) {
            for m in n.months { store.markRent(property: p.uid ?? p.pid, unit: idx, month: m.m) }
        }
        done()
    }
}

/// WhatsApp's look, by day and by night
enum NudgeLook {
    static let paper = Color(light: "#EFE7DC", dark: "#111B21")
    static let bubble = Color(light: "#D9FDD3", dark: "#144D37")
    static let note = Color(light: "#2A6B3F", dark: "#8FD9A8")
    static let send = Color(light: "#075E54", dark: "#0B7A68")
}
