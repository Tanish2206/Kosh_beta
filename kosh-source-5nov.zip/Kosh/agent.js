/* kosh agent: what kosh notices on its own, the tools the assistant looks things up with, the reading rules it
   learns from mail the built-in rules couldn't read, and statement passwords made from the sender's own rule.

   Everything here is arithmetic on the household's own ledger, done on the phone. The assistant (Claude, or
   Apple's model on the phone) never adds up anything itself: it asks these tools, and every figure in its
   answer has to be one a tool gave (agentCheck). What kosh notices is found by code, not by a model: the
   model only words it and puts it in order.

   Loaded after engine.js and docread.js, like mailwire.js; Swift calls the JSON functions through KoshEngine. */

var KoshAgent = (function (E) {
  'use strict';
  var L = E.lib || {};
  var inr = L.inr || function (n) { return '₹' + Math.round(n); };

  /* ------------------------------------------------------------ small things */
  function lc(s) { return String(s == null ? '' : s).toLowerCase(); }
  function r0(n) { return Math.round(+n || 0); }
  function sum(list, f) { var s = 0; for (var i = 0; i < list.length; i++) s += +(f ? f(list[i]) : list[i]) || 0; return s; }
  function median(xs) { if (!xs.length) return 0; var s = xs.slice().sort(function (a, b) { return a - b; }), m = Math.floor(s.length / 2); return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2; }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  /* the date helpers are total: a day (YYYY-MM-DD), a month alone (YYYY-MM, as a deposit's maturity can be), or
     anything else (empty, a number, nonsense) never throws. A month alone counts as its first day; nonsense is no day
     (NaN in, '' out). */
  var DAY_RE = /^(\d{4})-(\d{2})(?:-(\d{2}))?/;
  function dayOf(iso) { var p = DAY_RE.exec(String(iso == null ? '' : iso)); return p ? Date.UTC(+p[1], +p[2] - 1, p[3] ? +p[3] : 1) : NaN; }
  function isDay(iso) { return /^\d{4}-\d{2}-\d{2}/.test(String(iso == null ? '' : iso)) && isFinite(dayOf(iso)); }
  function isMonth(iso) { return /^\d{4}-(?:0[1-9]|1[0-2])$/.test(String(iso == null ? '' : iso)); }
  function addDays(iso, n) { var t = dayOf(iso) + (+n || 0) * 864e5; if (!isFinite(t)) return ''; var d = new Date(t); return d.getUTCFullYear() + '-' + pad(d.getUTCMonth() + 1) + '-' + pad(d.getUTCDate()); }
  function daysBetween(a, b) { return Math.round((dayOf(b) - dayOf(a)) / 864e5); }
  var MON3 = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  var MONF = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  function dShort(iso) {
    var s = String(iso == null ? '' : iso);
    if (isDay(s)) return +s.slice(8, 10) + ' ' + MON3[+s.slice(5, 7) - 1];
    if (isMonth(s)) return MON3[+s.slice(5, 7) - 1] + ' ' + s.slice(0, 4);
    return '';
  }
  function ordinal(n) { n = +n; var s = ['th', 'st', 'nd', 'rd'], v = n % 100; return n + (s[(v - 20) % 10] || s[v] || s[0]); }
  function mLong(m) { var s = String(m == null ? '' : m); return MONF[+s.slice(5, 7) - 1] ? MONF[+s.slice(5, 7) - 1] + ' ' + s.slice(0, 4) : ''; }
  function lakh(n) {
    var a = Math.abs(n);
    if (a >= 1e7) return '₹' + (Math.round(a / 1e5) / 100) + 'Cr';
    if (a >= 1e5) return '₹' + (Math.round(a / 1e3) / 100) + 'L';
    return inr(a);
  }
  function mins(t) { var m = /^(\d{1,2}):(\d{2})/.exec(String(t || '')); return m ? +m[1] * 60 + +m[2] : -1; }
  function spendRows(tx) { return (tx || []).filter(function (t) { return t.sp && t.k === 'out' && !(t.ex); }); }
  /* decide.js ("Should I…?" with the working shown): on the phone it loads after this file and hangs off KoshEngine */
  function decideAPI() {
    if (E.decideAPI) return E.decideAPI;
    try { return typeof require === 'function' ? require('./decide.js') : null; } catch (e) { return null; }
  }

  /* ================================================================ what kosh noticed
     Each finding: { id, kind, sev (3 act now, 2 worth a look, 1 good to know), title, detail, amt, date, rows (the
     payments behind it), sym, ask (a question to take it further) }. Found by rules on the ledger, never by a
     model; the newest and most pressing first. */
  // a fee by what the line says it is: whole phrases, so a shop's name ("EXAMPLE FOREX SERVICES", "MARKUP STUDIO")
  // is never a fee; a forex or currency markup only as a charge
  var FEE = /\bannual (?:fee|membership)|\bmembership fee|\brenewal fee|\bjoining fee|\blate (?:payment )?(?:fee|charge)|\bfinance charges?|\binterest charged|\bover ?limit (?:fee|charge)|\boverlimit\b|\b(?:forex|fx|foreign currency|cross[- ]currency|currency conversion) (?:mark-?up|markup fee|fee|charges?)|\bmark-?up (?:fee|charges?)|\bcross[- ]currency\b|\bcash advance (?:fee|charges?)|\bbounce (?:fee|charges?)|\breturn(?:ed)? charges?|\b(?:ecs|nach) return|\bmin(?:imum)? bal(?:ance)?\.? charge|\bnon[- ]?maint|\bsms (?:alert )?charges?|\bdebit card (?:annual )?fee|\bamc charges?|\bpenal (?:charges?|interest)|\bgst on\b/i;
  var LATE = /late (?:payment )?(?:fee|charge)|finance charges?|interest charged|penal|overlimit|over limit|bounce|return(?:ed)? charges?/i;
  var UNDONE = /revers|refund|waive|waiver|chargeback/i;

  function watch(snap, prof) {
    var today = snap.today || (prof && prof.today) || '';
    if (!today) return [];
    var tx = snap.tx || [], out = [], spend = spendRows(tx);
    // (each day worked out once: the filters below ask it of every payment, and without a JIT that was most of watch)
    var sinceAt = {};
    var since = function (n) { var d = sinceAt[n]; return d !== undefined ? d : (sinceAt[n] = addDays(today, -n)); };
    function add(f) { if (f && f.title) out.push(f); }
    /* GUARDRAIL while a first read is still going back through the year (engine.js › historyThin: prof.readFrom, under
       four months read), the notes that lean on months of history wait: a spend bigger than usual or a first, a repeat
       that went up or is new, rent that usually comes, the month's pace, money idle against a usual month, an SIP or
       EMI not seen this month, a salary different or late. What's due, fees, the same charge twice, balances,
       maturities, premiums and refunds speak as ever. */
    var thin = !!(L.historyThin && L.historyThin(prof, today));

    // 1. fees and charges: late fees and interest (their own finding), then the card's other fees. What's still owed:
    // a fee refunded or reversed comes off (the ledger sets a matched reversal against it; one it couldn't match, a
    // credit naming the fee on the same card, comes off here)
    var fees = tx.filter(function (t) { return t.k === 'out' && t.d > since(60) && t.a > 0 && FEE.test([t.m, t.s, t.n].join(' ')); });
    var undone = tx.filter(function (t) { return t.k === 'in' && !t.refOf && t.d > since(60) && UNDONE.test(t.m || '') && FEE.test(t.m || ''); });
    var byCard = {};
    fees.forEach(function (t) { (byCard[t.card || t.bk || 'An account'] = byCard[t.card || t.bk || 'An account'] || []).push(t); });
    Object.keys(byCard).forEach(function (card) {
      var lateRows = byCard[card].filter(function (t) { return LATE.test([t.m, t.s, t.n].join(' ')); });
      var rest = byCard[card].filter(function (t) { return lateRows.indexOf(t) < 0; });
      var back = undone.filter(function (t) { return (t.card || t.bk || 'An account') === card; });
      [[lateRows, true], [rest, false]].forEach(function (part) {
        var rows = part[0], late = part[1];
        if (!rows.length) return;
        var off = sum(back.filter(function (t) { return LATE.test(t.m || '') === late; }), function (t) { return t.a; });
        var total = sum(rows, function (t) { return t.a; }) - off;
        if (!(total >= 1)) return;
        add({ id: 'fee|' + card + (late || !lateRows.length ? '' : '|other'), kind: 'fee', sev: late ? 3 : 2, sym: 'exclamationmark.triangle.fill',
              title: inr(total) + ' in ' + (late ? 'late fees and interest' : 'fees') + ' on ' + card,
              detail: rows.length + ' charge' + (rows.length === 1 ? '' : 's') + ' in the last 60 days: ' + rows.slice(0, 3).map(function (t) { return t.m + ' ' + inr(t.a); }).join(', ') + (off > 0 ? '; ' + inr(off) + ' of it came back' : '') + '.',
              amt: r0(total), date: rows[rows.length - 1].d, rows: rows.map(function (t) { return t.id; }),
              ask: late ? 'Why was I charged late fees on ' + card + ', and how do I avoid them?' : 'Which fees did I pay on ' + card + ' this year?' });
      });
    });

    // 2. the same payment twice: same place (the same app, or a name that starts the same: "PYU*ZEPTO MARKETPLACE" and
    // "ZEPTO MARKETPLACE PRIV"), same amount, same card, within a day
    var seen = {};
    spend.filter(function (t) { return t.d > since(30) && t.a >= 100; }).forEach(function (t) {
      var place = t.pf || lc(t.m).replace(/[^a-z ]/g, ' ').replace(/\s+/g, ' ').trim().split(' ').slice(0, 2).join(' ');
      var k = place + '|' + Math.round(t.a * 100) + '|' + (t.card || '');
      (seen[k] = seen[k] || []).push(t);
    });
    Object.keys(seen).forEach(function (k) {
      var g = seen[k].sort(function (a, b) { return (a.d + (a.t || '')).localeCompare(b.d + (b.t || '')); });
      for (var i = 1; i < g.length; i++) {
        if (daysBetween(g[i - 1].d, g[i].d) > 1 || g[i].refunded || g[i - 1].refunded) continue;
        // when both times are known, a charge twice is minutes apart: two coffees at 09:10 and 17:40 are two coffees
        var m1 = mins(g[i - 1].t), m2 = mins(g[i].t);
        if (m1 >= 0 && m2 >= 0 && Math.abs(daysBetween(g[i - 1].d, g[i].d) * 1440 + m2 - m1) > 15) continue;
        add({ id: 'dup|' + g[i].id, kind: 'dup', sev: 2, sym: 'doc.on.doc.fill', title: inr(g[i].a) + ' at ' + g[i].m + ' twice',
              detail: 'Charged on ' + dShort(g[i - 1].d) + (g[i].d !== g[i - 1].d ? ' and ' + dShort(g[i].d) : ' and again the same day') + (g[i].card ? ' on ' + g[i].card : '') + '. If you only paid once, ask for one back.',
              amt: r0(g[i].a), date: g[i].d, rows: [g[i - 1].id, g[i].id], ask: 'Was the ' + inr(g[i].a) + ' at ' + g[i].m + ' charged twice?' });
        break;
      }
    });

    // 3. a spend far bigger than usual: at a place you go to, or the first time anywhere
    var hist = {};
    spend.forEach(function (t) { (hist[lc(t.m)] = hist[lc(t.m)] || []).push(t); });
    var allAmts = spend.filter(function (t) { return t.d > since(180); }).map(function (t) { return t.a; }).sort(function (a, b) { return a - b; });
    var p90 = allAmts.length >= 20 ? allAmts[Math.floor(allAmts.length * 0.9)] : 0;
    spend.filter(function (t) { return !thin && t.d > since(10) && t.a >= 2000; }).forEach(function (t) {
      var before = (hist[lc(t.m)] || []).filter(function (x) { return x.d < t.d; }).map(function (x) { return x.a; });
      if (before.length >= 3) {
        var m = median(before);
        if (m > 0 && t.a >= 3 * m) add({ id: 'big|' + t.id, kind: 'unusual', sev: 2, sym: 'arrow.up.right.circle.fill', title: inr(t.a) + ' at ' + t.m,
          detail: 'About ' + Math.round(t.a / m) + ' times what you usually spend there (' + inr(m) + ' a time), on ' + dShort(t.d) + '.', amt: r0(t.a), date: t.d, rows: [t.id],
          ask: 'What did I spend at ' + t.m + ' over the last six months?' });
      } else if (!before.length && p90 > 0 && t.a >= Math.max(10000, 3 * p90)) {
        add({ id: 'new|' + t.id, kind: 'unusual', sev: 2, sym: 'sparkle.magnifyingglass', title: inr(t.a) + ' at ' + t.m + ', a first',
          detail: 'A new place, and among the biggest payments in six months. Paid on ' + dShort(t.d) + (t.card ? ' with ' + t.card : '') + '.', amt: r0(t.a), date: t.d, rows: [t.id],
          ask: 'What were my biggest payments in the last three months?' });
      }
    });

    // 4. a repeat that went up, and new repeats
    var BNPL = /\b(?:lazy ?pay|get ?simpl|simpl|pay ?later|paylater|zestmoney|slice (?:card|pay)|uni ?pay|mobikwik zip|zip ?pay|ola money postpaid|snapmint|kreditbee|freecharge pay later)\b/i;
    Object.keys(hist).forEach(function (k) {
      if (thin) return;
      var g = hist[k].slice().sort(function (a, b) { return a.d.localeCompare(b.d); });
      if (g.length < 3 || /^upi|^payment$/i.test(g[0].m)) return;
      // GUARDRAIL a buy-now-pay-later bill (LazyPay, Simpl, a Pay Later) is what was bought on it, settled: it rises and
      // falls with the shopping, never a price that went up
      if (BNPL.test(k) || BNPL.test(g[0].m) || /^(?:Card Payments|EMI|Investments|Transfer in|Self Transfer)$/.test(g[0].c || '')) return;
      var gaps = [];
      for (var i = 1; i < g.length; i++) gaps.push(daysBetween(g[i - 1].d, g[i].d));
      if (gaps.filter(function (x) { return x >= 25 && x <= 35; }).length < Math.max(2, Math.floor(gaps.length * 0.6))) return;
      var last = g[g.length - 1], prev = median(g.slice(Math.max(0, g.length - 5), g.length - 1).map(function (t) { return t.a; }));
      if (last.d < since(40) || !(prev > 0)) return;
      if (last.a >= prev * 1.08 && last.a - prev >= 30) { add({ id: 'rise|' + k, kind: 'pricerise', sev: 2, sym: 'arrow.up.circle.fill', title: last.m + ' went up to ' + inr(last.a),
        detail: 'It was ' + inr(prev) + ' a month; the ' + dShort(last.d) + ' charge was ' + inr(last.a) + ', ' + Math.round((last.a / prev - 1) * 100) + '% more, about ' + inr((last.a - prev) * 12) + ' a year.',
        amt: r0(last.a - prev), date: last.d, rows: g.slice(-3).map(function (t) { return t.id; }), ask: 'What do I pay every month for subscriptions and bills?' }); return; }
      /* GUARDRAIL a price that went up some months ago and has stayed up (₹499 a month until March, ₹649 every month
         since April): the rise is still news within six months of it, said once, at the new price */
      var at = -1;
      for (var j = g.length - 1; j >= 2; j--) {
        var before = median(g.slice(Math.max(0, j - 4), j).map(function (t) { return t.a; })), after = g.slice(j);
        if (before > 0 && g[j].a >= before * 1.08 && g[j].a - before >= 30 && after.every(function (t) { return Math.abs(t.a - g[j].a) <= g[j].a * 0.02; })) { at = j; break; }
      }
      // (it is news for six months from when the new price was seen holding; it dates from the first charge at the new
      // price: a median over the months before can lag that by one)
      if (at < 0 || g[at].d < since(190)) return;
      while (at > 1 && Math.abs(g[at - 1].a - g[at].a) <= g[at].a * 0.02) at--;
      var was = median(g.slice(Math.max(0, at - 4), at).map(function (t) { return t.a; })), now = g[at].a;
      add({ id: 'rise|' + k, kind: 'pricerise', sev: 2, sym: 'arrow.up.circle.fill', title: last.m + ' went up to ' + inr(now),
        detail: 'It was ' + inr(was) + ' a month until ' + MON3[+g[at - 1].d.slice(5, 7) - 1] + '; ' + inr(now) + ' since ' + dShort(g[at].d) + ', ' + Math.round((now / was - 1) * 100) + '% more, about ' + inr((now - was) * 12) + ' a year.',
        amt: r0(now - was), date: g[at].d, rows: g.slice(at - 1, at + 2).map(function (t) { return t.id; }), ask: 'What do I pay every month for subscriptions and bills?' });
    });
    (snap.recurring || []).forEach(function (r) {
      if (thin || r.seen !== 2 || !(r.kind === 'sub' || r.kind === 'bill') || !r.last || r.last < since(45)) return;
      add({ id: 'newrep|' + r.id, kind: 'newsub', sev: 1, sym: 'repeat.circle.fill', title: 'New every month: ' + r.name + ' ' + inr(r.amount),
            detail: 'Seen twice now, a month apart; next around ' + dShort(r.date) + '. About ' + inr(r.amount * 12) + ' a year.', amt: r0(r.amount), date: r.last, rows: [],
            ask: 'What new subscriptions have started in the last three months?' });
    });

    // 5. what's due soon, and whether the money is there for it
    var agenda = (snap.agenda || []).filter(function (a) { return a.kind === 'out' && !a.booked && a.date && a.date >= today; });
    // (a free trial about to charge has its own heads-up, with how to cancel: plan.js)
    agenda.filter(function (a) { return a.date <= addDays(today, 3) && a.amt > 0 && !a.trial; }).forEach(function (a) {
      // one kosh worked out from your spending (no bill in the mail) is a heads-up, not an alarm: its day is a guess
      var guess = !!a.learnt;
      add({ id: 'due|' + a.name + '|' + a.date, kind: 'due', sev: guess ? 2 : 3, sym: 'calendar.badge.exclamationmark',
            title: a.name + ' ' + inr(a.amt) + (guess ? ' usually around ' + dShort(a.date) : a.date === today ? ' due today' : ' due ' + dShort(a.date)),
            detail: a.sub || '', amt: r0(a.amt), date: a.date, rows: [], ask: 'What do I have to pay in the next two weeks?' });
    });
    var week = agenda.filter(function (a) { return a.date <= addDays(today, 7); });
    var dueWeek = sum(week, function (a) { return a.amt; });
    var fresh = (snap.accounts || []).filter(function (a) { return a.balance !== null && a.balance !== undefined && a.asOf && a.asOf >= since(10); });
    var have = sum(fresh, function (a) { return a.balance; });
    if (dueWeek > 0 && fresh.length && have < dueWeek) add({ id: 'short|' + today, kind: 'short', sev: 3, sym: 'exclamationmark.circle.fill', title: inr(dueWeek) + ' due this week, ' + inr(have) + ' in the accounts',
      detail: week.length + ' payment' + (week.length === 1 ? '' : 's') + ' due by ' + dShort(addDays(today, 7)) + '; the accounts kosh has a recent balance for hold ' + inr(have) + '. Move money in before the due dates.',
      amt: r0(dueWeek - have), date: today, rows: [], ask: 'Which payments are due this week and from which account do they usually go?' });

    // 5b. an account whose latest balances don't add up with its payments (engine.js › acctLedger): money moved that
    // kosh has no payment for, said while it's recent, with its dates; the balance shown is then the bank's own
    (snap.accounts || []).forEach(function (a) {
      var b = a.bal, gs = a.gaps || [], g = gs[gs.length - 1];
      if (true) return; // (livebal-4nov) gaps are never raised to the user
      if (!b || b.check !== 'gap' || !g || String(g.to).slice(0, 10) < since(45)) return;
      var name = a.bank + (a.last ? ' ••' + a.last : ''), from = String(g.from).slice(0, 10), to = String(g.to).slice(0, 10);
      add({ id: 'gap|' + a.id + '|' + to, kind: 'gap', sev: 2, sym: 'exclamationmark.triangle.fill',
            title: name + ': ' + inr(Math.abs(g.amt)) + (g.amt < 0 ? ' left' : ' came in') + ' with no payment kosh has',
            detail: 'Between ' + dShort(from) + ' and ' + dShort(to) + ' its balance moved by more than the payments kosh read: one your bank told only by SMS, or one filed under another account. The balance shown is the bank’s own.',
            amt: r0(Math.abs(g.amt)), date: to, rows: [], ask: 'What moved in my ' + name + ' account between ' + dShort(from) + ' and ' + dShort(to) + '?' });
    });

    // 6. deposits maturing and premiums renewing within a month
    var hold = (snap.hold || []);
    hold.forEach(function (h) {
      // a maturity the profile carries as a month alone (YYYY-MM) counts as that month's end
      var md = /^\d{4}-\d{2}-\d{2}$/.test(h.matDay || '') ? h.matDay : /^\d{4}-\d{2}-\d{2}$/.test(h.mat || '') ? h.mat : /^\d{4}-\d{2}$/.test(h.mat || '') ? h.mat + '-28' : '';
      if (!md || md < today || md > addDays(today, 30)) return;
      var when = md === h.mat || md === h.matDay ? dShort(md) : 'in ' + MONF[+md.slice(5, 7) - 1];
      add({ id: 'mat|' + h.bank + '|' + md + '|' + r0(h.amt), kind: 'maturity', sev: 2, sym: 'building.columns.fill', title: lakh(h.amt) + ' ' + (h.type || 'deposit') + ' at ' + h.bank + ' matures ' + when,
            detail: (h.matAmt ? inr(h.matAmt) + ' comes back' : 'It comes back') + (h.rate ? ', booked at ' + h.rate + '%' : '') + '. Decide whether to renew it or move it.', amt: r0(h.matAmt || h.amt), date: md, rows: [],
            ask: 'My ' + (h.type || 'deposit') + ' at ' + h.bank + ' matures ' + when + '. What else do I hold in deposits and at what rates?' });
    });
    (snap.policies || []).forEach(function (p) {
      // past its due day, in the grace period: pay now and the cover carries on
      if (p.status === 'overdue') {
        add({ id: 'over|' + p.id, kind: 'renewal', sev: 3, sym: 'exclamationmark.shield.fill', title: p.insurer + ' premium is past due' + (p.premium > 0 ? ': ' + inr(p.premium) : ''),
              detail: (p.statusWhy || '') + ' Paying within it keeps the cover going.', amt: r0(p.premium || 0), date: today, rows: [],
              ask: 'Which of my insurance premiums are overdue?' });
        return;
      }
      // a life policy that looks to have lapsed lately: worth a look, it may have been paid some other way
      if (p.status === 'lapsed' && p.lastPaid && p.lastPaid >= addDays(today, -500)) {
        add({ id: 'lapse|' + p.id, kind: 'renewal', sev: 2, sym: 'shield.slash.fill', title: p.insurer + (p.plan ? ' ' + p.plan : '') + ' may have lapsed',
              detail: (p.statusWhy || '') + ' If it was paid, say so on the policy; if not, it can usually be revived.', amt: r0(p.premium || 0), date: today, rows: [],
              ask: 'Has my ' + p.insurer + ' policy lapsed, and how do I revive it?' });
        return;
      }
      // a renewal that asks more than last year: said while the notice is fresh, before it is paid
      if (p.rise && p.rise.to > p.rise.from && p.rise.on >= since(60)) {
        var up = p.rise.to - p.rise.from;
        add({ id: 'prem-rise|' + p.id + '|' + p.rise.on, kind: 'pricerise', sev: 2, sym: 'arrow.up.circle.fill', title: p.insurer + ' premium went up to ' + inr(p.rise.to),
              detail: 'Last time it was ' + inr(p.rise.from) + '; the renewal notice asks ' + inr(p.rise.to) + ', ' + inr(up) + ' (' + Math.round(up / p.rise.from * 100) + '%) more' + (p.nextDue && p.nextDue >= today ? ', due ' + dShort(p.nextDue) : '') + '. Worth comparing the cover with other insurers before you renew.',
              amt: r0(up), date: p.rise.on, rows: [], ask: 'Why did my ' + p.insurer + ' premium go up, and what does it cover?' });
      }
      /* GUARDRAIL a renewal falls due within 30 days, or the insurer's reminder for it came within the last 30 days
         (due further ahead, within 75): noticed, not only on bills ahead */
      var reminded = p.noticeOn && p.noticeOn >= since(30) && p.nextDue && p.nextDue <= addDays(today, 75);
      if (!p.nextDue || p.nextDue < today || (p.nextDue > addDays(today, 30) && !reminded) || !(p.premium > 0)) return;
      add({ id: 'ren|' + p.id, kind: 'renewal', sev: 2, sym: 'shield.lefthalf.filled', title: p.insurer + ' ' + lc(p.type) + ' premium ' + inr(p.premium) + ' due ' + dShort(p.nextDue),
            detail: (p.cover ? 'Cover ' + lakh(p.cover) + '. ' : '') + 'Paying on time keeps the cover going.', amt: r0(p.premium), date: p.nextDue, rows: [],
            ask: 'What insurance premiums are due in the next three months?' });
    });

    // 7. rent that hasn't come
    ((snap.prop || {}).props || []).forEach(function (p) {
      (p.units || []).forEach(function (u) {
        if (!u.now || u.now.st !== 'late' || !(u.rent > 0)) return;
        // every month that hasn't come, not this month's alone: "₹36,000 behind: September and October"
        var owed = (u.roll || []).filter(function (x) { return x.st === 'late' && x.m <= today.slice(0, 7); }), who = u.tenant || p.short + ' ' + u.label;
        var tot = owed.length > 1 ? sum(owed, function (x) { return x.amt || u.rent; }) : u.rent;
        var title = owed.length > 1 ? 'Rent from ' + who + ' is ' + inr(tot) + ' behind: ' + joinAnd(owed.map(function (x) { return MONF[+x.m.slice(5, 7) - 1]; }))
          : 'Rent from ' + who + ' is ' + (u.now.late || 0) + ' days late';
        add({ id: 'rent|' + p.pid + '|' + u.idx, kind: 'rent', sev: 2, sym: 'house.fill', title: title,
              detail: owed.length > 1 ? inr(u.rent) + ' a month, due ' + (u.day ? 'on the ' + ordinal(u.day) : 'each month') + '; the oldest is ' + (owed[0].late || 0) + ' days late.'
                : inr(u.rent) + ' was due ' + (u.day ? 'on the ' + ordinal(u.day) : 'this month') + ' and hasn’t come in.', amt: r0(tot), date: today, rows: [],
              ask: 'Which tenants are behind on rent?' });
      });
    });

    /* 7b. GUARDRAIL rent you receive with no property set up for it (a shop's rent into savings, "NEFT/…/EXAMPLE
       TRADERS/SHOP RENT SEP"): the same payer, every month for three months or more, around the same day. When this
       month's hasn't come a week past that day, it is rent that's late (never "salary"), however busy the ledger */
    var tenants = {};
    ((snap.prop || {}).props || []).forEach(function (p) { (p.units || []).forEach(function (u) { if (u.tenant) tenants[lc(u.tenant).replace(/[^a-z]/g, '')] = 1; }); });
    var rentBy = {};
    tx.filter(function (t) { return t.k === 'in' && t.c === 'Rent received' && t.a >= 1000 && !t.ex; }).forEach(function (t) {
      var k = lc(t.m).replace(/[^a-z]/g, '');
      if (k.length >= 4 && !tenants[k]) (rentBy[k] = rentBy[k] || []).push(t);
    });
    Object.keys(rentBy).forEach(function (k) {
      if (thin) return;
      var g = rentBy[k].slice().sort(function (a, b) { return a.d.localeCompare(b.d); });
      var months = {};
      g.forEach(function (t) { months[t.d.slice(0, 7)] = t; });
      var ms = Object.keys(months).sort(), cmR = today.slice(0, 7);
      if (months[cmR]) return;
      var past = ms.filter(function (m) { return m < cmR; }).slice(-4);
      if (past.length < 3) return;
      // every month running up to this one (none missed), the last of them last month
      var prevM = addDays(cmR + '-01', -1).slice(0, 7);
      if (past[past.length - 1] !== prevM) return;
      for (var i = 1; i < past.length; i++) if (addDays(past[i] + '-01', -1).slice(0, 7) !== past[i - 1]) return;
      var day = Math.round(median(past.slice(-3).map(function (m) { return Math.min(+months[m].d.slice(8, 10), 28); })));
      var late = +today.slice(8, 10) - day;
      if (late < 7) return;
      var lastR = months[past[past.length - 1]], amtR = median(past.slice(-3).map(function (m) { return months[m].a; }));
      add({ id: 'rentin|' + k + '|' + cmR, kind: 'rent', sev: 2, sym: 'house.fill', title: 'Rent from ' + lastR.m + ' is ' + late + ' days late',
            detail: inr(amtR) + ' usually comes in around the ' + ordinal(day) + '; this month’s hasn’t. The last was on ' + dShort(lastR.d) + '.', amt: r0(amtR), date: today, rows: [lastR.id],
            ask: 'When did ' + lastR.m + '’s rent come in each month?' });
    });

    // 8. refunds overdue
    (snap.refunds || []).forEach(function (r) {
      if (r.state !== 'late') return;
      add({ id: 'refund|' + (r.id || r.m), kind: 'refund', sev: 2, sym: 'arrow.uturn.backward.circle.fill', title: inr(r.exp - (r.back || 0)) + ' refund from ' + r.m + ' is late',
            detail: 'Expected back by ' + dShort(r.by) + '.', amt: r0(r.exp - (r.back || 0)), date: r.by || today, rows: [], ask: 'Which refunds am I still waiting for?' });
    });

    // 9. the month's pace against the budget
    var fc = snap.fc || {};
    /* GUARDRAIL a payment known to come every few months (school fees each quarter, a yearly premium), paid this month
       as expected, is no overspending; and with fewer than three whole months read (a first sync), there is no usual
       month to be on pace against, unless you set a budget */
    var cmP = snap.cm || today.slice(0, 7), lumpy = 0;
    (snap.recurring || []).filter(function (r) { return (r.per || 1) >= 2 && r.amount > 0; }).forEach(function (r) {
      var nk = lc(r.name).replace(/[^a-z0-9]/g, '');
      spend.forEach(function (t) { if (t.d.slice(0, 7) === cmP && lc(t.m).replace(/[^a-z0-9]/g, '') === nk && Math.abs(t.a - r.amount) <= r.amount * 0.1) lumpy += t.a; });
    });
    var historyOk = fc.own || !(fc.hist >= 0) || fc.hist >= 3;
    // (and spending that comes early each month is on pace when no more has gone than had by this day in a usual month)
    var aheadOfUsual = fc.own || !(fc.byNow > 0) || fc.spent - lumpy > fc.byNow * 1.1;
    if (!thin && historyOk && aheadOfUsual && fc.budget > 0 && fc.likely - lumpy > fc.budget * 1.1 && fc.d >= 7 && fc.left > 3) add({ id: 'pace|' + (snap.cm || today.slice(0, 7)), kind: 'pace', sev: 2, sym: 'speedometer',
      title: 'On pace for ' + inr(fc.likely) + ' against ' + inr(fc.budget), detail: inr(fc.spent) + ' spent with ' + fc.left + ' days to go. ' + inr(fc.likely - fc.budget) + ' over if it carries on.',
      amt: r0(fc.likely - fc.budget), date: today, rows: [], ask: 'Where is my money going this month compared with last month?' });

    // 10. money sitting idle in savings, beyond what the month needs
    // (your own accounts: a parent's or a spouse's savings aren't yours to move)
    // (and never a business's current account: its money is the business's working money, not household savings)
    var freshMine = fresh.filter(function (a) { return (a.owner || 'me') === 'me' && !a.biz; }), haveMine = sum(freshMine, function (a) { return a.balance; });
    var usual = +fc.usual || 0, need = usual + sum(agenda.filter(function (a) { return a.date <= addDays(today, 30); }), function (a) { return a.amt; });
    var idle = haveMine - Math.max(need, usual * 3);
    if (!thin && freshMine.length && usual > 0 && idle >= 200000) {
      var rates = hold.filter(function (h) { return h.cls === 'dep' && h.rate > 0; }).map(function (h) { return h.rate; });
      var best = rates.length ? Math.max.apply(null, rates) : 0;
      add({ id: 'idle|' + today.slice(0, 7), kind: 'idle', sev: 1, sym: 'tray.full.fill', title: lakh(idle) + ' more than you need sitting in savings',
            detail: 'In your own accounts, three months of spending and what’s due are covered with ' + lakh(idle) + ' to spare.' + (best ? ' At the ' + best + '% your best deposit earns, that’s about ' + inr(idle * best / 1200) + ' a month.' : ''),
            amt: r0(idle), date: today, rows: [], ask: 'How much do I keep in savings accounts, and what do my deposits earn?' });
    }

    // 11. an SIP or an EMI that went every month and hasn't this month: paused, failed, or the loan has ended
    (snap.recurring || []).forEach(function (r) {
      if (thin || (r.kind !== 'sip' && r.kind !== 'emi' && r.kind !== 'committee') || (r.seen || 0) < 3 || !r.last || r.gone || (r.per || 1) !== 1) return;
      var gap = daysBetween(r.last, today);
      if (gap < 38 || gap > 75) return;   // a week late; after a couple of months it has simply ended
      var sip = r.kind === 'sip', comm = r.kind === 'committee', what = sip ? 'SIP' : comm ? 'committee instalment' : 'EMI';
      add({ id: 'stopped|' + r.id + '|' + r.last, kind: 'stopped', sev: sip || comm ? 2 : 3, sym: sip ? 'chart.line.downtrend.xyaxis' : comm ? 'circle.dotted.circle' : 'calendar.badge.exclamationmark',
            title: 'The ' + r.name + ' ' + what + ' hasn’t gone this month',
            detail: 'It went ' + r.seen + ' months running, ' + inr(r.amount) + ', last on ' + dShort(r.last) + '. ' + (sip ? 'A paused or failed SIP is easy to miss.' : comm ? 'If you paid it another way, say so in Committees.' : 'If the loan isn’t closed, a missed EMI brings a bounce charge and a mark on your credit record.'),
            amt: r0(r.amount), date: r.last, rows: [], ask: 'Has my ' + r.name + ' ' + what + ' gone this month?' });
    });

    // 12. the salary, earner by earner (whose account, which employer): a different amount from that earner's usual,
    // or later than that earner's usual day and a few days' grace. Two people's salaries are never one "usual", and a
    // salary not yet due is never "less" or "late".
    var earners = {};
    tx.filter(function (t) { return t.k === 'in' && t.c === 'Salary' && t.a >= 5000 && isDay(t.d); }).forEach(function (t) {
      var who = (t.o || 'me') + '|' + lc(t.m).replace(/[^a-z ]/g, ' ').replace(/\s+/g, ' ').trim().split(' ').slice(0, 2).join(' ');
      var e = earners[who] || (earners[who] = { rows: [], byM: {} });
      e.rows.push(t);
      var m = t.d.slice(0, 7), o = e.byM[m] || (e.byM[m] = { a: 0, d: t.d, ids: [] });
      o.a += t.a; if (t.d < o.d) o.d = t.d; o.ids.push(t.id);
    });
    var lastSalOf = {};
    Object.keys(earners).forEach(function (k) { var o = k.split('|')[0]; earners[k].rows.forEach(function (t) { if (!lastSalOf[o] || t.d > lastSalOf[o]) lastSalOf[o] = t.d; }); });
    // (with one earner, the ids are the ones it always had, so a note set aside stays aside)
    var oneEarner = Object.keys(earners).length === 1;
    Object.keys(earners).forEach(function (k) {
      var e = earners[k], salM = Object.keys(e.byM).sort(), ek = oneEarner ? '' : '|' + k;
      if (thin || salM.length < 4) return;
      var owner = k.split('|')[0], whoP = (snap.people || []).filter(function (p) { return p.id === owner; })[0];
      var whose = owner === 'me' || !whoP ? '' : whoP.name + '’s ';
      var lastM = salM[salM.length - 1], before = salM.slice(-4, -1), got = e.byM[lastM];
      var usualAmt = median(before.map(function (m) { return e.byM[m].a; })), diff = got.a - usualAmt;
      if (daysBetween(got.d, today) <= 20 && usualAmt > 0 && Math.abs(diff) >= Math.max(1000, usualAmt * 0.05)) {
        add({ id: 'salary|' + lastM + ek, kind: 'salary', sev: diff < 0 ? 2 : 1, sym: diff < 0 ? 'arrow.down.circle.fill' : 'arrow.up.circle.fill',
              title: cap1(whose + 'salary ' + (diff < 0 ? inr(-diff) + ' less' : inr(diff) + ' more') + ' than usual'),
              detail: inr(got.a) + ' from ' + e.rows[0].m + ' on ' + dShort(got.d) + ', against a usual ' + inr(usualAmt) + '. ' + (diff < 0 ? 'Worth checking the payslip for a deduction or tax change.' : 'A raise, a bonus or arrears.'),
              amt: r0(Math.abs(diff)), date: got.d, rows: got.ids, ask: 'Why was ' + (whose ? whose : 'my ') + 'salary in ' + lastM + ' different from usual?' });
      }
      // when the next one is due: the last one and the usual gap between them (a month-end salary is due at the month's
      // end, whatever day of the month it fell on); late only once that day and four more have passed
      var days = salM.map(function (m) { return e.byM[m].d; }), gaps = [];
      for (var i = Math.max(1, days.length - 4); i < days.length; i++) gaps.push(daysBetween(days[i - 1], days[i]));
      var gapU = Math.round(median(gaps)), dueOn = addDays(got.d, gapU), since0 = daysBetween(got.d, today);
      if (!(gapU >= 25 && gapU <= 35) || !isDay(dueOn) || today <= addDays(dueOn, 4) || since0 > 70) return;
      // the same person paid by someone else since (a new job): not late
      if (lastSalOf[owner] && lastSalOf[owner] > got.d) return;
      add({ id: 'salary-late|' + today.slice(0, 7) + ek, kind: 'salary', sev: 2, sym: 'clock.badge.exclamationmark.fill',
            title: cap1(whose + 'salary hasn’t come this month'),
            detail: 'It usually lands about ' + gapU + ' days after the one before, so around ' + dShort(dueOn) + '; the last was ' + inr(got.a) + ' from ' + e.rows[0].m + ' on ' + dShort(got.d) + '. Bills due before it lands come from what’s in the accounts.',
            amt: r0(got.a), date: today, rows: [], ask: 'When does ' + (whose ? whose : 'my ') + 'salary usually come, and what’s due before it?' });
    });

    /* 13. GUARDRAIL advance tax: someone who pays it (an income-tax payment in the last six months on or just before
       one of its four dates, 15 June, 15 September, 15 December, 15 March, or a payment the bank calls advance tax) has
       the next instalment ahead; said once it is within ten weeks, with no amount, since kosh can't see what is owed */
    var ADV = ['06-15', '09-15', '12-15', '03-15'];
    var nearInstalment = function (d) { return ADV.some(function (md) { var y = +d.slice(0, 4); return [y - 1, y, y + 1].some(function (yy) { var on = yy + '-' + md, g = daysBetween(d, on); return g >= -1 && g <= 6; }); }); };
    var advPaid = tx.filter(function (t) { return t.k === 'out' && t.a > 0 && t.d > since(190) && t.c === 'Tax' && (t.s === 'Advance tax' || (t.s === 'Income tax' && nearInstalment(t.d))); });
    if (advPaid.length) {
      var nextAdv = '';
      [0, 1].forEach(function (k) { ADV.forEach(function (md) { var on = (+today.slice(0, 4) + k) + '-' + md; if (on > today && (!nextAdv || on < nextAdv)) nextAdv = on; }); });
      var lastAdv = advPaid.slice().sort(function (a, b) { return a.d.localeCompare(b.d); }).pop();
      if (nextAdv && nextAdv <= addDays(today, 70) && !(lastAdv.d >= addDays(nextAdv, -10))) {
        add({ id: 'advtax|' + nextAdv, kind: 'tax', sev: 2, sym: 'percent', title: 'Advance tax: the next instalment is due by ' + dShort(nextAdv),
              detail: 'You paid ' + inr(lastAdv.a) + ' on ' + dShort(lastAdv.d) + '. kosh can’t see how much you owe this time: it doesn’t read your tax filings. Paying late adds interest.',
              amt: 0, date: nextAdv, rows: [lastAdv.id], ask: 'How much advance tax have I paid this financial year?' });
      }
    }

    /* 14. GUARDRAIL charges in another currency on an Indian card (dollars at an online shop, dirhams abroad): the card
       adds a forex markup, usually about 3.5% with GST on it, on each one. Said when there were some in the last 60 days,
       with what the markup comes to at that rate */
    var fxBy = {};
    tx.filter(function (t) { return t.k === 'out' && t.fx && t.a > 0 && t.d > since(60) && t.md === 'card'; }).forEach(function (t) { (fxBy[t.card || 'A card'] = fxBy[t.card || 'A card'] || []).push(t); });
    Object.keys(fxBy).forEach(function (card) {
      var rows = fxBy[card], tot = sum(rows, function (t) { return t.a; });
      var curs = rows.map(function (t) { return String(t.fx).split(' ')[0]; }).filter(function (c, i, a) { return c && a.indexOf(c) === i; });
      add({ id: 'fx|' + card + '|' + today.slice(0, 7), kind: 'fx', sev: 1, sym: 'globe',
            title: inr(tot) + ' in foreign-currency charges on ' + card,
            detail: rows.length + ' charge' + (rows.length === 1 ? '' : 's') + ' in ' + joinAnd(curs) + ' in the last 60 days. Cards usually add a forex markup of about 3.5% plus GST on each: about ' + inr(tot * 0.035 * 1.18) + ' here. A card with no markup saves it.',
            amt: r0(tot * 0.035 * 1.18), date: rows[rows.length - 1].d, rows: rows.map(function (t) { return t.id; }), ask: 'How much did I spend in other currencies on ' + card + '?' });
    });

    out.sort(function (a, b) { return b.sev - a.sev || String(b.date).localeCompare(String(a.date)); });
    return out.slice(0, 14);
  }
  if (E.postBuild) E.postBuild.push(function (snap, prof) { snap.watch = watch(snap, prof); });

  /* ================================================================ the assistant's tools
     Plain JSON schemas (the Messages API's tool format); every tool runs here on the ledger the phone holds and
     answers in words plus the ids of the payments behind it. ctx is what Swift hands over: the snapshot's
     payments, accounts, cards, what's due, repeats, policies, holdings, what's owed, properties, what kosh
     noticed, budgets, and the papers' facts (payslips, tax certificates, gains). */
  function S(props, req) { return { type: 'object', properties: props, required: req || [] }; }
  var str = function (d) { return { type: 'string', description: d }; }, numb = function (d) { return { type: 'number', description: d }; };
  var PERIOD = { from: str('First day, YYYY-MM-DD (inclusive). Leave out for no lower limit.'), to: str('Last day, YYYY-MM-DD (inclusive). Leave out for today.') };
  function withP(o) { var x = {}; Object.keys(PERIOD).forEach(function (k) { x[k] = PERIOD[k]; }); Object.keys(o || {}).forEach(function (k) { x[k] = o[k]; }); return x; }
  var TOOLS = [
    { name: 'spending', description: 'Total spending in a period, optionally only one category, merchant (part of its name), card or account (part of its name) or person. Returns the total, the count, the biggest payments and the same length of time just before for comparison.',
      input_schema: S(withP({ category: str('A category such as Food & Drinks, Groceries, Shopping, Travel, Bills, Health, Home, Transport, Entertainment, Subscriptions, Education'), merchant: str('Part of a merchant name'), card: str('Part of a card or account name, e.g. "HDFC" or "••1234"'), person: str('Whose spending: a person’s name, or "me"') })) },
    { name: 'breakdown', description: 'Spending in a period split by category, merchant, card, person or month, biggest first.',
      input_schema: S(withP({ by: { type: 'string', enum: ['category', 'merchant', 'card', 'person', 'month', 'subcategory'] }, category: str('Only this category (for merchant or subcategory splits)'), top: numb('How many rows, default 10') }), ['by']) },
    { name: 'transactions', description: 'List individual payments (out) or credits (in) matching filters, with their ids. Use for "show me", "which", "biggest", "when did I last".',
      input_schema: S(withP({ dir: { type: 'string', enum: ['out', 'in', 'any'] }, category: str('Category'), merchant: str('Part of the merchant or payer name'), card: str('Part of the card or account name'), min: numb('Smallest amount'), max: numb('Largest amount'), sort: { type: 'string', enum: ['amount', 'date'] }, limit: numb('At most this many, default 15, max 50') })) },
    { name: 'income', description: 'Money that came in during a period (salary, rent, interest, refunds, transfers in), by source.', input_schema: S(withP({})) },
    { name: 'upcoming', description: 'Bills, card dues, premiums, EMIs, rent due in, and other dated items in the next N days.', input_schema: S({ days: numb('How many days ahead, default 30') }) },
    { name: 'repeats', description: 'Payments that repeat every month (subscriptions, bills, EMIs, SIPs, household staff) with amount and next date.', input_schema: S({}) },
    { name: 'balances', description: 'Bank account balances (with the date each is from), cards with this month’s and last 30 days’ spends, and wallets.', input_schema: S({}) },
    { name: 'wealth', description: 'What the household owns: deposits, stocks, mutual funds, retirement (EPF/PPF/NPS), gold; by kind and by person, biggest holdings, deposits maturing; and net worth as Home counts it (bank balances, holdings, cash and land, less loans).', input_schema: S({ person: str('Only this person') }) },
    { name: 'insurance', description: 'Insurance policies: insurer, type, cover, premium, next due date, nominee.', input_schema: S({}) },
    { name: 'property', description: 'Properties: each tenant, the rent, whether this month’s came, who is behind and by how much, property tax due.', input_schema: S({ late: { type: 'boolean', description: 'Only tenants behind on rent' }, tenant: str('Only this tenant: part of their name') }) },
    { name: 'owed', description: 'Money people owe the household, and what the household owes others.', input_schema: S({ person: str('Part of a person’s name') }) },
    { name: 'noticed', description: 'What kosh noticed on its own: fees, duplicate charges, unusual spends, price rises, dues, deposits maturing, late rent, budget pace.', input_schema: S({}) },
    { name: 'papers', description: 'Facts read from PDFs: payslips (gross, deductions, net, TDS, PF), tax certificates (Form 16, TDS, interest), capital gains by financial year.', input_schema: S({ kind: { type: 'string', enum: ['payslip', 'tax', 'gains', 'any'] } }) },
    { name: 'compare', description: 'Compare spending between two periods (this month so far against the same days last month, this year against last year…) or between two people, overall and by category, with the biggest changes first. Use for "what changed", "why is it higher", "more or less than".',
      input_schema: S({ from: str('First day of the period, YYYY-MM-DD'), to: str('Last day, YYYY-MM-DD; leave out for today'), from2: str('First day of the period to compare against; leave out for the same stretch just before'), to2: str('Last day of the period to compare against'), category: str('Only this category'), person: str('Whose spending'), person2: str('Compare against this person instead of another period') }) },
    { name: 'trend', description: 'A figure month by month for the last N months: spending (all, or one category, merchant or person), money in, or money invested; with the usual (median) month and which way it is heading.',
      input_schema: S({ months: numb('How many months, default 6, at most 24'), what: { type: 'string', enum: ['spending', 'income', 'invest'] }, category: str('Only this category'), merchant: str('Part of a merchant name'), person: str('Whose spending') }) },
    { name: 'cover', description: 'Whether the money in the bank accounts covers what is due in the next N days: the balances and how old each is, what goes out, what comes in, and the gap or what is spare.',
      input_schema: S({ days: numb('How many days ahead, default 7') }) },
    { name: 'whatif', description: 'Exact money maths for decisions: emi (the EMI and total interest of a loan), prepay (prepaying part of a loan against investing the same money), sip (what a monthly SIP grows to), lumpsum (what an amount grows to), save_for (how much to put away each month to reach an amount by a date, against what the household usually keeps each month). Give the numbers you know; ask the person for any that are missing rather than guessing.',
      input_schema: S({ kind: { type: 'string', enum: ['emi', 'prepay', 'sip', 'lumpsum', 'save_for'] }, principal: numb('Loan amount, or what is still outstanding'), rate: numb('Loan interest, % a year'), months: numb('Months of the loan left'), amount: numb('The sum in question: the prepayment, the monthly SIP, the lump sum'), ret: numb('Expected return, % a year (say what you assumed)'), years: numb('Years to grow'), target: numb('The amount to reach'), by: str('The date to reach it by, YYYY-MM-DD') }, ['kind']) },
    { name: 'decide', description: 'Weighs a money decision on the household’s own figures and shows the working: prepay (prepay a loan or invest the money), car (buy a car in cash or on a loan), afford (can they afford an amount, now or by a date), fd (break an FD or borrow against it), emergency (is the emergency fund enough), card (pay a card in full or the minimum). Leave out what the person didn’t say: it uses the household’s loans, balances, FDs, cards and what’s left each month, and says what it assumed. Give its verdict and the figures that decide it.',
      input_schema: S({ kind: { type: 'string', enum: ['prepay', 'car', 'afford', 'fd', 'emergency', 'card'] }, amount: numb('The sum in question: the prepayment, the car’s price, what they want to afford, what they need from the FD, the card bill'),
        loan: str('Which loan: part of its name, such as home or car'), principal: numb('A loan’s outstanding amount, if they said it'), rate: numb('A loan’s interest, % a year, if they said it'), months: numb('Months left on the loan, or how long they need the money'),
        ret: numb('What investing or savings would earn, % a year (say what you assumed)'), years: numb('Years for a car loan'), down: numb('A car’s down payment, % of its price'), by: str('YYYY-MM-DD: the date to afford it by'),
        which: str('Which FD: part of its bank’s name'), card: str('Which card: part of its name or bank'), cushion: numb('Months of spending to set aside for emergencies, default 6') }, ['kind']) },
    { name: 'calc', description: 'Arithmetic. Always use this for any sum, difference, percentage or average you state that no other tool gave you. Numbers, + - * / ( ) only.', input_schema: S({ expression: str('e.g. (45200 - 38100) / 38100 * 100') }, ['expression']) },
    { name: 'claim', description: 'A travel expense claim (reimbursement) for a period: the cabs, flights, trains, buses and stays kosh would put in it with the invoice behind each, the total, what has no invoice yet and what it left out (weekend rides, refunds, the person\u2019s own rules). Shows the person a card that opens the claim, where kosh makes the PDF and the Excel sheet. Use for "make my travel claim", "what can I claim", "reimbursement for October".',
      input_schema: S({ from: str('First day, YYYY-MM-DD'), to: str('Last day, YYYY-MM-DD') }) },
    { name: 'propose', description: 'Offer the person an action they confirm with one tap; nothing happens until they do. Use when they ask you to do something, or when an action clearly helps.',
      input_schema: S({ action: { type: 'string', enum: ['budget', 'recategorize', 'remind', 'chapter'] }, category: str('For budget: a category, or leave out for the whole month. For recategorize: the new category'), sub: str('For recategorize: the subcategory'),
        merchant: str('For recategorize: the merchant as it appears in transactions'), amount: numb('For budget: rupees a month; for remind: the amount'), date: str('For remind: YYYY-MM-DD; for chapter: the first day'), until: str('For chapter: the last day, YYYY-MM-DD'),
        title: str('For remind or chapter: what it is, in a few words'), why: str('One short sentence the person sees on the card') }, ['action', 'why']) },
  ];

  function within(t, a, today) {
    var from = /^\d{4}-\d{2}-\d{2}$/.test(a.from || '') ? a.from : '', to = /^\d{4}-\d{2}-\d{2}$/.test(a.to || '') ? a.to : today;
    return (!from || t.d >= from) && t.d <= to;
  }
  function periodLabel(a, today) {
    var from = a.from || '', to = a.to || today;
    if (!from) return 'up to ' + dShort(to) + ' ' + to.slice(0, 4);
    var monthEnd = addDays((+to.slice(5, 7) === 12 ? (+to.slice(0, 4) + 1) + '-01' : to.slice(0, 4) + '-' + pad(+to.slice(5, 7) + 1)) + '-01', -1);
    if (from.slice(0, 7) === to.slice(0, 7) && from.slice(8) === '01' && (to >= today || to === monthEnd)) return mLong(from.slice(0, 7)) + (to >= today ? ' so far' : '');
    if (from.slice(0, 7) === to.slice(0, 7)) return +from.slice(8) + '–' + dShort(to) + ' ' + to.slice(0, 4);
    return dShort(from) + ' ' + from.slice(0, 4) + ' to ' + dShort(to) + ' ' + to.slice(0, 4);
  }
  function before(a, today) {
    // the same length of time just before, for comparison; a month so far against the same days of the month before
    if (!a.from) return null;
    var to = a.to || today, n = daysBetween(a.from, to) + 1;
    if (a.from.slice(8) === '01' && a.from.slice(0, 7) === to.slice(0, 7)) {
      var last = addDays(a.from, -1), start = last.slice(0, 8) + '01', end = last.slice(0, 8) + to.slice(8);
      // a whole month against the whole month before; a month so far against the same days of it
      var wholeMonth = addDays(to, 1).slice(8) === '01';
      return { from: start, to: wholeMonth || end > last ? last : end };
    }
    // whole months ("Jul–Sep", "from August to September"): as many whole months before
    if (a.from.slice(8) === '01' && addDays(to, 1).slice(8) === '01') {
      var k = (+to.slice(0, 4) - +a.from.slice(0, 4)) * 12 + (+to.slice(5, 7) - +a.from.slice(5, 7)) + 1, yb = +a.from.slice(0, 4), mb = +a.from.slice(5, 7) - k;
      while (mb < 1) { mb += 12; yb--; }
      return { from: yb + '-' + pad(mb) + '-01', to: addDays(a.from, -1) };
    }
    return { from: addDays(a.from, -n), to: addDays(a.from, -1) };
  }
  function catOk(t, c) { return !c || (L.matchCat ? L.matchCat(t, c) : lc(t.c) === lc(c)); }
  // part of a name; a list of them is any one ("Swiggy" or "Zomato")
  function has(s, part) {
    if (Array.isArray(part)) return !part.length || part.some(function (p) { return has(s, p); });
    return !part || lc(s).indexOf(lc(part).replace(/^••/, '')) >= 0;
  }
  function personOk(t, p, ctx) {
    if (!p) return true;
    // "me" (or "you") is the user alone, never someone whose name has "me" in it; a name matches from the start of a word
    var who = lc(p).trim(), self = who === 'me' || who === 'you' || who === 'i' || who === 'myself';
    var starts = function (nm) { return (' ' + lc(nm)).indexOf(' ' + who) >= 0; };
    var ids = (ctx.people || []).filter(function (x) { return self ? x.id === 'me' : x.id === who || starts(x.name) || starts(x.full); }).map(function (x) { return x.id; });
    if (self && !ids.length) ids = ['me'];
    return ids.indexOf(t.o || 'me') >= 0 || ids.indexOf(t.f || '') >= 0;
  }
  function row(t) { return t.d + ' ' + t.m + ' ' + inr(t.a) + (t.c ? ' (' + t.c + ')' : '') + (t.card ? ' · ' + t.card : ''); }
  // refunds kosh couldn't set against a payment (nt), within what's asked, read as the spending they come off
  function backRows(tx, a, today, f) {
    return (tx || []).filter(function (t) { return t.nt && t.k === 'in' && t.nta > 0; }).map(function (t) { var x = {}; Object.keys(t).forEach(function (k) { x[k] = t[k]; }); x.c = t.nt; x.s = ''; x.a = t.nta; return x; })
      .filter(function (t) { return f(t, a); });
  }

  /* money into investments, and money back out of them: an Investments row with dr "in" is a payout or redemption
     (Zerodha's "funds withdrawn" to your bank), never money put in (the cash-flow screen counts it the same way) */
  /* a card's bill as the Cards screen has it (BillBook.bill): what went towards it since its statement (or 25 days
     before its due day), paid in full within ₹5 or 1%, and what's left to pay. A part paid is a part paid: ₹16,862 of
     a ₹38,469 bill leaves ₹21,607, never the whole bill nor nothing */
  function cardBill(c) {
    var amt = +c.due || 0, from = c.stmtOn || addDays(c.dueDate || '', -25), pAmt = +c.paid || 0;
    var after = pAmt > 0 && !!c.paidOn && c.paidOn >= from, part = after ? pAmt : 0;
    var full = after && pAmt >= amt - Math.max(5, amt * 0.01);
    return { amt: amt, paid: part, full: full, left: full ? 0 : Math.max(0, amt - part) };
  }
  function putIn(t) { return t.k === 'invest' && t.dr !== 'in' && !t.ex; }
  function takenOut(t) { return t.k === 'invest' && t.dr === 'in' && !t.ex; }
  function runTool(name, a, ctx) {
    a = a || {};
    var today = ctx.today, tx = ctx.tx || [], spend = spendRows(tx), rows, text = '', ids = [], data = {}, prev;
    switch (name) {
      case 'spending': {
        var f = function (t, w) { return within(t, w, today) && catOk(t, a.category) && has(t.m, a.merchant) && has(t.card, a.card) && personOk(t, a.person, ctx); };
        rows = spend.filter(function (t) { return f(t, a); });
        // less the money back kosh couldn't set against a payment (nt: the kind of spending it comes off), as the
        // months on the screens take it off
        var backAmt = sum(backRows(tx, a, today, f), function (t) { return t.a; });
        var total = Math.max(0, sum(rows, function (t) { return t.a; }) - backAmt);
        var what = [a.category ? 'on ' + a.category : '', a.merchant ? 'at ' + a.merchant : '', a.card ? 'with ' + a.card : '', a.person ? 'by/for ' + a.person : ''].filter(Boolean).join(' ') || 'in all';
        text = 'Spent ' + what + ', ' + periodLabel(a, today) + ': ' + inr(total) + ' across ' + rows.length + ' payment' + (rows.length === 1 ? '' : 's') + (backAmt > 0 ? ', after ' + inr(backAmt) + ' back' : '') + '.';
        if (rows.length) text += ' Biggest: ' + rows.slice().sort(function (x, y) { return y.a - x.a; }).slice(0, 5).map(row).join('; ') + '.';
        var b = before(a, today);
        if (b) { var pr = spend.filter(function (t) { return f(t, b); }); prev = sum(pr, function (t) { return t.a; }); text += ' The same stretch before (' + periodLabel(b, today) + '): ' + inr(prev) + '.'; data.prev = r0(prev); }
        ids = rows.map(function (t) { return t.id; }); data.total = r0(total); data.count = rows.length;
        break;
      }
      case 'breakdown': {
        rows = spend.filter(function (t) { return within(t, a, today) && catOk(t, a.category); });
        var key = { category: 'c', merchant: 'm', card: 'card', person: 'o', month: 'mon', subcategory: 's' }[a.by] || 'c';
        var g = {};
        rows.forEach(function (t) { var k = key === 'mon' ? t.d.slice(0, 7) : (t[key] || '(none)'); (g[k] = g[k] || []).push(t); });
        var keys = Object.keys(g);
        var topN = Math.min(30, +a.top || (key === 'mon' ? 24 : 10)), tot = sum(rows, function (t) { return t.a; });
        // (by kind, person or month: each less the money back kosh couldn't set against one payment, as the months take it off)
        var bOff = {}, bKey = { c: function (x) { return x.c; }, o: function (x) { return x.o || 'me'; }, mon: function (x) { return x.d.slice(0, 7); } }[key];
        if (bKey) backRows(tx, a, today, function (t, w) { return within(t, w, today) && catOk(t, w.category); }).forEach(function (x) { var k = bKey(x); bOff[k] = (bOff[k] || 0) + x.a; tot -= x.a; });
        tot = Math.max(0, tot);
        var vOf = function (k) { return Math.max(0, sum(g[k], function (t) { return t.a; }) - (bOff[k] || 0)); };
        keys.sort(key === 'mon' ? undefined : function (x, y) { return vOf(y) - vOf(x); });
        var name0 = function (k) { if (key !== 'o') return key === 'mon' ? mLong(k) : k; var p = (ctx.people || []).filter(function (x) { return x.id === k; })[0]; return p ? p.name : k; };
        text = 'Spending by ' + a.by + ', ' + periodLabel(a, today) + (a.category ? ', ' + a.category + ' only' : '') + ' (' + inr(tot) + ' in all): ' +
          keys.slice(0, topN).map(function (k) { var v = vOf(k); return name0(k) + ' ' + inr(v) + ' (' + g[k].length + ', ' + (tot ? Math.round(v / tot * 100) : 0) + '%)'; }).join('; ') + '.';
        if (keys.length > topN) text += ' And ' + (keys.length - topN) + ' more.';
        ids = rows.map(function (t) { return t.id; }); data.total = r0(tot);
        break;
      }
      case 'transactions': {
        var dir = a.dir || 'out';
        rows = tx.filter(function (t) {
          if (dir === 'out' && !(t.k === 'out' || t.sp)) return false;
          if (dir === 'in' && t.k !== 'in') return false;
          return within(t, a, today) && catOk(t, a.category) && has(t.m, a.merchant) && has(t.card, a.card) && (!(a.min > 0) || t.a >= a.min) && (!(a.max > 0) || t.a <= a.max);
        });
        rows.sort(a.sort === 'date' ? function (x, y) { return (y.d + (y.t || '')).localeCompare(x.d + (x.t || '')); } : function (x, y) { return y.a - x.a; });
        var lim = Math.max(1, Math.min(50, +a.limit || 15));
        text = rows.length ? rows.length + ' match' + (rows.length === 1 ? '' : 'es') + ' (' + inr(sum(rows, function (t) { return t.a; })) + ' in all)' + (rows.length > lim ? ', the first ' + lim + ':' : ':') + '\n' + rows.slice(0, lim).map(function (t) { return '- ' + row(t); }).join('\n')
          : 'Nothing matches.';
        ids = rows.slice(0, 200).map(function (t) { return t.id; });
        break;
      }
      case 'income': {
        rows = tx.filter(function (t) { return t.k === 'in' && within(t, a, today); });
        var by = {};
        rows.forEach(function (t) { var k = t.c && t.c !== 'Money in' ? t.c : t.m; by[k] = (by[k] || 0) + t.a; });
        var tot2 = sum(rows, function (t) { return t.a; });
        text = rows.length ? 'Came in, ' + periodLabel(a, today) + ': ' + inr(tot2) + '. By source: ' + Object.keys(by).sort(function (x, y) { return by[y] - by[x]; }).slice(0, 10).map(function (k) { return k + ' ' + inr(by[k]); }).join('; ') + '.' : 'Nothing came in, ' + periodLabel(a, today) + '.';
        ids = rows.map(function (t) { return t.id; }); data.total = r0(tot2);
        break;
      }
      case 'upcoming': {
        var n = Math.max(1, Math.min(120, +a.days || 30)), until = addDays(today, n);
        var due = (ctx.agenda || []).concat(loanDue(ctx, today)).filter(function (x) { return x.date && x.date >= today && x.date <= until; }).sort(function (x, y) { return x.date.localeCompare(y.date); });
        var outs = due.filter(function (x) { return x.kind !== 'in'; }), ins = due.filter(function (x) { return x.kind === 'in'; });
        text = due.length ? 'In the next ' + n + ' days: going out ' + inr(sum(outs, function (x) { return x.amt; })) + ' (' + outs.map(function (x) { return x.date + ' ' + x.name + ' ' + inr(x.amt) + (x.booked ? ' (paid)' : ''); }).join('; ') + ')' +
          (ins.length ? '; coming in ' + inr(sum(ins, function (x) { return x.amt; })) + ' (' + ins.map(function (x) { return x.date + ' ' + x.name + ' ' + inr(x.amt); }).join('; ') + ')' : '') + '.' : 'Nothing dated in the next ' + n + ' days.';
        break;
      }
      case 'repeats': {
        var rp = (ctx.recurring || []).filter(function (x) { return !x.lapsed; }), per = function (x) { return x.per > 1 ? x.amount / x.per : x.amount; };
        text = rp.length ? rp.length + ' repeating payments, about ' + inr(sum(rp, per)) + ' a month taken together: ' + rp.map(function (x) { return x.name + ' ' + inr(x.amount) + ' (' + (x.kind || 'repeat') + (x.per === 12 ? ', yearly' : x.per === 6 ? ', every six months' : x.per === 3 ? ', every three months' : '') + ', next ' + x.date + ')'; }).join('; ') + '.' : 'No repeating payments found yet.';
        break;
      }
      case 'balances': {
        var ac = ctx.accounts || [], cards = ctx.cards || [], ws = ctx.wallets || [];
        var known = ac.filter(function (x) { return x.balance !== null && x.balance !== undefined; });
        text = (known.length ? 'Bank balances (' + inr(sum(known, function (x) { return x.balance; })) + ' in all): ' + known.map(function (x) { return x.name + ' ••' + x.last + ' ' + inr(x.balance) + ' as of ' + x.asOf + (x.owner && x.owner !== 'me' ? ' (' + x.owner + ')' : ''); }).join('; ') + '. ' : 'No bank balances known yet. ') +
          (ac.length > known.length ? (ac.length - known.length) + ' more account(s) without a balance. ' : '') +
          (cards.length ? 'Cards: ' + cards.map(function (c) { return c.name + ' ••' + c.last + ' this month ' + inr(c.month || 0) + ', last 30 days ' + inr(c.last30 || 0) + (c.lastUsed ? ', last used ' + c.lastUsed : ', not used yet'); }).join('; ') + '. ' : '') +
          (ws.length ? 'Wallets: ' + ws.map(function (w) { return w.name + (w.balance !== null && w.balance !== undefined ? ' ' + inr(w.balance) : ''); }).join('; ') + '.' : '');
        break;
      }
      case 'wealth': {
        var hs = (ctx.hold || []).filter(function (h) { return !a.person || personOk({ o: h.person || h.owner }, a.person, ctx); });
        var cls = {}, names = { dep: 'Deposits', stk: 'Stocks', mf: 'Mutual funds', ret: 'Retirement', gold: 'Gold' };
        hs.forEach(function (h) { cls[h.cls] = (cls[h.cls] || 0) + h.amt; });
        var tot3 = sum(hs, function (h) { return h.amt; });
        // the day it matures when known (matDay), else its month (mat may be YYYY-MM)
        var mOf = function (h) { return isDay(h.matDay) ? String(h.matDay).slice(0, 10) : isDay(h.mat) || isMonth(h.mat) ? String(h.mat).slice(0, 10) : ''; };
        var mat = hs.filter(function (h) { var md = mOf(h); return md && md >= today.slice(0, md.length); }).sort(function (x, y) { return mOf(x).localeCompare(mOf(y)); }).slice(0, 5);
        text = hs.length ? 'Holdings ' + inr(tot3) + ': ' + Object.keys(cls).sort(function (x, y) { return cls[y] - cls[x]; }).map(function (k) { return (names[k] || k) + ' ' + inr(cls[k]); }).join('; ') +
          '. Biggest: ' + hs.slice().sort(function (x, y) { return y.amt - x.amt; }).slice(0, 8).map(function (h) { return h.bank + ' ' + h.type + ' ' + inr(h.amt) + (h.rate ? ' at ' + h.rate + '%' : ''); }).join('; ') + '.' +
          (mat.length ? ' Maturing next: ' + mat.map(function (h) { return h.bank + ' ' + inr(h.amt) + (isMonth(mOf(h)) ? ' in ' : ' on ') + mOf(h); }).join('; ') + '.' : '') : 'No holdings known yet.';
        data.total = r0(tot3);
        // net worth as Home counts it: bank balances, holdings, cash and land, less what's left on the loans
        var acN = (ctx.accounts || []).filter(function (x) { return x.balance !== null && x.balance !== undefined && isFinite(+x.balance) && (!a.person || personOk({ o: x.owner || 'me' }, a.person, ctx)); });
        var mineN = !a.person || personOk({ o: 'me' }, a.person, ctx), bankN = sum(acN, function (x) { return +x.balance; });
        var loanN = mineN ? sum((ctx.loans || []).filter(function (l) { return l.active !== false; }), function (l) { return +l.outstanding || 0; }) : 0;
        var netN = bankN + tot3 + (mineN ? (+ctx.cashInHand || 0) + (+ctx.land || 0) : 0) - loanN;
        text += ' Net worth (as Home counts it): ' + inr(netN) + ' = bank ' + inr(bankN) + ' + holdings ' + inr(tot3) + (mineN && ctx.cashInHand ? ' + cash ' + inr(ctx.cashInHand) : '') + (mineN && ctx.land ? ' + land ' + inr(ctx.land) : '') + (loanN ? ' − loans ' + inr(loanN) : '') + '; card bills aren’t taken off.';
        data.net = r0(netN);
        break;
      }
      case 'insurance': {
        var ps = ctx.policies || [];
        text = ps.length ? ps.map(function (p) { return p.insurer + ' ' + (p.kind || p.type) + (p.cover ? ', cover ' + inr(p.cover) : '') + (p.premium ? ', premium ' + inr(p.premium) : '') + (p.nextDue ? ', next due ' + p.nextDue : '') + (p.fundValue ? ', fund value ' + inr(p.fundValue) : '') + (p.nominee ? ', nominee ' + p.nominee : '') + ', ' + (p.status || 'active') + (p.statusWhy ? ' (' + p.statusWhy + ')' : ''); }).join('; ') + '.' : 'No policies found yet.';
        break;
      }
      case 'compare': {
        var A = { from: a.from || (today.slice(0, 7) + '-01'), to: a.to || today }, B;
        if (a.person2) B = { from: A.from, to: A.to };
        else if (a.from2) B = { from: a.from2, to: a.to2 || addDays(a.from2, daysBetween(A.from, A.to)) };
        else if (A.from.slice(8) === '01' && A.from.slice(0, 7) === A.to.slice(0, 7)) {
          // this month so far against the same days of the month before, not the whole of it
          var pmS = addDays(A.from, -1).slice(0, 7) + '-01', lastDay = addDays(A.from, -1);
          var endB = pmS.slice(0, 8) + A.to.slice(8); B = { from: pmS, to: endB > lastDay ? lastDay : endB };
        } else B = before(A, today);
        var pA = a.person || '', pB = a.person2 || a.person || '';
        var inA = spend.filter(function (t) { return within(t, A, today) && catOk(t, a.category) && personOk(t, pA, ctx); });
        var inB = spend.filter(function (t) { return within(t, B, today) && catOk(t, a.category) && personOk(t, pB, ctx); });
        var tA = sum(inA, function (t) { return t.a; }), tB = sum(inB, function (t) { return t.a; });
        var byA = {}, byB = {};
        inA.forEach(function (t) { byA[t.c] = (byA[t.c] || 0) + t.a; });
        inB.forEach(function (t) { byB[t.c] = (byB[t.c] || 0) + t.a; });
        var cats = Object.keys(Object.assign({}, byA, byB)).map(function (c) { return { c: c, a: byA[c] || 0, b: byB[c] || 0, d: (byA[c] || 0) - (byB[c] || 0) }; })
          .filter(function (x) { return Math.abs(x.d) >= 1; }).sort(function (x, y) { return Math.abs(y.d) - Math.abs(x.d); });
        var labA = (pA ? pA + ', ' : '') + periodLabel(A, today), labB = (a.person2 ? pB + ', ' : '') + periodLabel(B, today);
        var diff = tA - tB;
        text = 'Spent' + (a.category ? ' on ' + a.category : '') + ': ' + labA + ' ' + inr(tA) + ' (' + inA.length + ' payments) against ' + labB + ' ' + inr(tB) + ' (' + inB.length + '). ' +
          (Math.abs(diff) < 1 ? 'The same.' : inr(Math.abs(diff)) + (diff > 0 ? ' more' : ' less') + (tB > 0 ? ' (' + (diff > 0 ? '+' : '−') + Math.round(Math.abs(diff) / tB * 100) + '%)' : '') + '.') +
          (cats.length && !a.category ? ' Biggest changes: ' + cats.slice(0, 5).map(function (x) { return x.c + ' ' + (x.d > 0 ? '+' : '−') + inr(Math.abs(x.d)) + ' (' + inr(x.a) + ' against ' + inr(x.b) + ')'; }).join('; ') + '.' : '');
        ids = inA.map(function (t) { return t.id; }); data.a = r0(tA); data.b = r0(tB); data.diff = r0(diff);
        break;
      }
      case 'trend': {
        var nM = Math.max(2, Math.min(24, +a.months || 6)), what = a.what || 'spending', series = [];
        var cmT = today.slice(0, 7);
        for (var mi = nM - 1; mi >= 0; mi--) {
          var y0 = +cmT.slice(0, 4), m0 = +cmT.slice(5, 7) - mi;
          while (m0 < 1) { m0 += 12; y0--; }
          var mm = y0 + '-' + pad(m0);
          var rowsM = (what === 'income' ? tx.filter(function (t) { return t.k === 'in' && !t.ex && t.c !== 'Transfer in' && t.c !== 'Self Transfer'; })
            : what === 'invest' ? tx.filter(putIn)
            : spend.filter(function (t) { return catOk(t, a.category) && has(t.m, a.merchant) && personOk(t, a.person, ctx); }))
            .filter(function (t) { return t.d.slice(0, 7) === mm; });
          series.push({ m: mm, v: sum(rowsM, function (t) { return t.a; }), n: rowsM.length, live: mm === cmT });
        }
        // months before kosh's mail goes back aren't zeros
        var firstM = tx.reduce(function (lo, t) { return !lo || t.d < lo ? t.d : lo; }, '').slice(0, 7);
        if (firstM) series = series.filter(function (x) { return x.m >= firstM; });
        var full = series.filter(function (x) { return !x.live; }), usualT = median(full.map(function (x) { return x.v; }));
        var lastFull = full[full.length - 1];
        var nameT = what === 'income' ? 'Money in' : what === 'invest' ? 'Invested' : 'Spent' + (a.category ? ' on ' + a.category : '') + (a.merchant ? ' at ' + a.merchant : '') + (a.person ? ' by ' + a.person : '');
        text = nameT + ', month by month: ' + series.map(function (x) { return MON3[+x.m.slice(5, 7) - 1] + ' ' + x.m.slice(2, 4) + ' ' + inr(x.v) + (x.live ? ' (so far)' : ''); }).join('; ') +
          '. Usual month ' + inr(usualT) + '.' + (lastFull && usualT > 0 && full.length > 1 ? ' ' + MONF[+lastFull.m.slice(5, 7) - 1] + (Math.abs(lastFull.v - usualT) < 1 ? ' was the usual.' : ' was ' + (lastFull.v > usualT ? inr(lastFull.v - usualT) + ' above' : inr(usualT - lastFull.v) + ' below') + ' it.') : '');
        data.series = series.map(function (x) { return { m: x.m, v: r0(x.v) }; }); data.usual = r0(usualT);
        break;
      }
      case 'cover': {
        var nd = Math.max(1, Math.min(60, +a.days || 7)), untilC = addDays(today, nd);
        var acc = (ctx.accounts || []).filter(function (x) { return x.balance !== null && x.balance !== undefined; });
        var fresh = acc.filter(function (x) { return x.asOf && daysBetween(x.asOf.slice(0, 10), today) <= 10; });
        var have = sum(fresh, function (x) { return x.balance; });
        var dueC = (ctx.agenda || []).concat(loanDue(ctx, today)).filter(function (x) { return x.date && x.date >= today && x.date <= untilC && !x.booked; });
        var outC = dueC.filter(function (x) { return x.kind !== 'in'; }), inC = dueC.filter(function (x) { return x.kind === 'in'; });
        var goOut = sum(outC, function (x) { return x.amt; }), comeIn = sum(inC, function (x) { return x.amt; });
        var spare = have + comeIn - goOut;
        if (!acc.length) { text = 'kosh doesn’t know any bank balances yet, so it can’t say. Due in the next ' + nd + ' days: ' + inr(goOut) + '.'; break; }
        text = (spare >= 0 ? 'Covered: ' : 'Short by ' + inr(-spare) + ': ') + inr(have) + ' in ' + fresh.length + ' account' + (fresh.length === 1 ? '' : 's') + ' with a recent balance' +
          (comeIn ? ', ' + inr(comeIn) + ' coming in' : '') + ', against ' + inr(goOut) + ' going out in the next ' + nd + ' days' + (spare >= 0 ? ', ' + inr(spare) + ' to spare.' : '.') +
          (outC.length ? ' Going out: ' + outC.map(function (x) { return x.date.slice(8) + ' ' + MON3[+x.date.slice(5, 7) - 1] + ' ' + x.name + ' ' + inr(x.amt); }).join('; ') + '.' : '') +
          (acc.length > fresh.length ? ' Not counted: ' + (acc.length - fresh.length) + ' account(s) whose last balance is over 10 days old.' : '');
        data.spare = r0(spare); data.have = r0(have); data.out = r0(goOut);
        break;
      }
      case 'whatif': {
        var k = a.kind, R = (+a.rate || 0) / 1200, n = Math.round(+a.months || (+a.years || 0) * 12), P = +a.principal || 0, X = +a.amount || 0, ret = (+a.ret || 0) / 1200;
        var emiOf = function (p, r, m) { return r > 0 ? p * r * Math.pow(1 + r, m) / (Math.pow(1 + r, m) - 1) : p / m; };
        var monthsAt = function (p, r, e) { if (e <= p * r) return Infinity; return r > 0 ? Math.ceil(Math.log(e / (e - p * r)) / Math.log(1 + r)) : Math.ceil(p / e); };
        if (k === 'emi') {
          if (!(P > 0 && n > 0)) { text = 'For an EMI kosh needs the loan amount, the interest rate and the months.'; break; }
          var e1 = emiOf(P, R, n);
          text = 'EMI ' + inr(Math.round(e1)) + ' a month for ' + n + ' months on ' + inr(P) + ' at ' + a.rate + '%: ' + inr(Math.round(e1 * n)) + ' paid in all, ' + inr(Math.round(e1 * n - P)) + ' of it interest.';
          data.emi = r0(e1);
        } else if (k === 'prepay') {
          if (!(P > 0 && n > 0 && X > 0 && R > 0)) { text = 'To weigh prepaying, kosh needs what’s outstanding, the loan’s rate, the months left and the prepayment.'; break; }
          var e2 = emiOf(P, R, n), before0 = e2 * n - P, n2 = monthsAt(P - X, R, e2), after0 = e2 * n2 - (P - X);
          var saved = before0 - after0, grown = X * Math.pow(1 + ret, n) - X;
          text = 'Prepaying ' + inr(X) + ' on ' + inr(P) + ' at ' + a.rate + '% (EMI ' + inr(Math.round(e2)) + ' unchanged) saves ' + inr(Math.round(saved)) + ' of interest and ends the loan ' + (n - n2) + ' months early.' +
            (ret > 0 ? ' Investing it instead at ' + a.ret + '% a year for the same ' + n + ' months grows it by about ' + inr(Math.round(grown)) + ' before tax. ' + (grown > saved ? 'Investing comes out ahead by ' + inr(Math.round(grown - saved)) + ', if the return holds; prepaying is certain.' : 'Prepaying comes out ahead by ' + inr(Math.round(saved - grown)) + ', and it’s certain.') : ' Give an expected return to weigh it against investing.');
          data.saved = r0(saved); data.grown = r0(grown); data.monthsEarly = n - n2;
        } else if (k === 'sip') {
          var nm = Math.round((+a.years || 0) * 12) || n;
          if (!(X > 0 && nm > 0)) { text = 'For a SIP kosh needs the monthly amount and how many years.'; break; }
          var fv = ret > 0 ? X * ((Math.pow(1 + ret, nm) - 1) / ret) * (1 + ret) : X * nm;
          text = inr(X) + ' a month for ' + (nm / 12) + ' years at ' + (a.ret || 0) + '% a year grows to about ' + inr(Math.round(fv)) + ': ' + inr(X * nm) + ' put in, ' + inr(Math.round(fv - X * nm)) + ' earned.';
          data.fv = r0(fv);
        } else if (k === 'lumpsum') {
          var yrs = +a.years || n / 12;
          if (!(X > 0 && yrs > 0)) { text = 'kosh needs the amount and the years.'; break; }
          var fv2 = X * Math.pow(1 + (+a.ret || 0) / 100, yrs);
          text = inr(X) + ' at ' + (a.ret || 0) + '% a year for ' + yrs + ' years grows to about ' + inr(Math.round(fv2)) + '.';
          data.fv = r0(fv2);
        } else if (k === 'save_for') {
          var T = +a.target || 0, mLeft = a.by ? Math.max(1, Math.round(daysBetween(today, a.by) / 30.44)) : n;
          if (!(T > 0 && mLeft > 0)) { text = 'kosh needs the amount and the date to reach it by.'; break; }
          var need = ret > 0 ? T * ret / ((Math.pow(1 + ret, mLeft) - 1) * (1 + ret)) : T / mLeft;
          // (months whose income kosh saw: what came in covers at least half of what went out, as decide.js counts them)
          var kept = median((ctx.cashflow || []).filter(function (c) { return !c.live && !c.noPay && c.inn > 0 && c.inn * 2 >= (+c.out || 0) + (+c.ev || 0) + (+c.inv || 0); }).slice(-3).map(function (c) { return c.kept; }));
          var byD = a.by || addDays(today, mLeft * 30);
          text = 'To have ' + inr(T) + ' by ' + dShort(byD) + (byD.slice(0, 4) !== today.slice(0, 4) ? ' ' + byD.slice(0, 4) : '') + ' (' + mLeft + ' months), put away ' + inr(Math.round(need)) + ' a month' + (ret > 0 ? ' at ' + a.ret + '% a year' : '') + '.' +
            (kept ? ' Your household usually has ' + inr(kept) + ' a month left after spending and investing, so that’s ' + (kept >= need ? 'within reach, with ' + inr(Math.round(kept - need)) + ' a month to spare.' : inr(Math.round(need - kept)) + ' a month more than usual.') : '');
          data.need = r0(need); data.kept = r0(kept);
        } else text = 'Say which: emi, prepay, sip, lumpsum or save_for.';
        break;
      }
      case 'property': {
        var pp = ctx.props || [];
        if (!pp.length) {
          /* GUARDRAIL property tax asked with no property set up: what the ledger shows paid as property tax (the
             municipality's debit) in the last 12 months, rather than nothing */
          var ptx = (ctx.tx || []).filter(function (t) { return t.k === 'out' && t.a > 0 && t.d >= addDays(today, -364) && (/^property tax$/i.test(t.s || '') || /property ?tax|proptax/i.test((t.m || '') + ' ' + (t.n || ''))); }).sort(function (x, y) { return y.d.localeCompare(x.d); });
          if (ptx.length) {
            text = 'You paid **' + inr(sum(ptx, function (t) { return t.a; })) + '** in property tax in the last 12 months' + (ptx.length === 1 ? ': ' + inr(ptx[0].a) + ' to ' + ptx[0].m + ' on ' + dShort(ptx[0].d) : ', across ' + ptx.length + ' payments; the last ' + inr(ptx[0].a) + ' to ' + ptx[0].m + ' on ' + dShort(ptx[0].d)) + '. Add the property in Property to track its tax and rent.';
            ids = ids.concat(ptx.map(function (t) { return t.id; }));
          } else text = 'No properties are in kosh yet. Add one in Property to track rent and tax.';
          break;
        }
        var let_ = [], behind = [], paid = [];
        pp.forEach(function (p) {
          (p.units || []).forEach(function (u) {
            if (!(u.rent > 0)) return;
            var who = (u.tenant || u.label) + (pp.length > 1 || (p.units || []).length > 1 ? ' (' + p.name + (u.tenant && u.label ? ', ' + u.label : '') + ')' : '');
            var late = (u.late || []).filter(function (x) { return x.amt > 0; });
            let_.push(who);
            if (late.length) behind.push({ who: who, amt: sum(late, function (x) { return x.amt; }), months: late.map(function (x) { return MON3[+x.m.slice(5, 7) - 1]; }), days: Math.max.apply(null, late.map(function (x) { return x.days || 0; })) });
            else if (u.state === 'booked') paid.push(who);
          });
        });
        // one tenant: "did Kiran pay rent this month"
        var tw = lc(a.tenant || '').trim();
        var mineT = tw ? [] : null;
        if (tw) pp.forEach(function (p) { (p.units || []).forEach(function (u) { if (u.rent > 0 && (' ' + lc(u.tenant || '')).indexOf(' ' + tw) >= 0) mineT.push(u); }); });
        if (mineT && mineT.length) {
          var MONm = MONF[+today.slice(5, 7) - 1];
          text = mineT.map(function (u) {
            var lateU = (u.late || []).filter(function (x) { return x.amt > 0; }), owe = sum(lateU, function (x) { return x.amt; });
            var w1 = (u.tenant || '').split(/\s+/)[0].toLowerCase();
            var cr = (ctx.tx || []).filter(function (t) { return t.k === 'in' && t.c === 'Rent received' && t.d.slice(0, 7) === today.slice(0, 7) && lc(t.m).indexOf(w1) >= 0; }).sort(function (x, y) { return y.d.localeCompare(x.d); })[0];
            if (u.state === 'booked') return 'Yes: ' + u.tenant + '’s ' + inr(u.rent) + ' rent for ' + MONm + ' is paid this month' + (cr ? ', it came in on ' + cr.d : '') + '.';
            if (lateU.length) return 'Not yet: ' + u.tenant + '’s ' + inr(u.rent) + ' for ' + MONm + ' hasn’t come in' + (lateU.length > 1 || lateU[0].m !== today.slice(0, 7) ? '; they owe ' + inr(owe) + ' for ' + lateU.map(function (x) { return MON3[+x.m.slice(5, 7) - 1]; }).join(', ') : '') + '.';
            return 'Not yet: ' + u.tenant + '’s ' + inr(u.rent) + ' for ' + MONm + ' is due this month.';
          }).join(' ');
          data.behind = mineT.filter(function (u) { return (u.late || []).length; }).length;
          break;
        }
        if (a.late) {
          text = behind.length
            ? 'Behind on rent: ' + behind.sort(function (x, y) { return y.amt - x.amt; }).map(function (b) { return b.who + ' owes ' + inr(b.amt) + ' for ' + b.months.join(', ') + (b.days ? ' (' + b.days + ' days late)' : ''); }).join('; ') + '. Total ' + inr(sum(behind, function (b) { return b.amt; })) + '.'
            : 'No one is behind on rent' + (let_.length ? ': all ' + let_.length + ' tenant' + (let_.length === 1 ? '' : 's') + ' are paid up to this month.' : '. No tenants are set up yet.');
          if (behind.length && paid.length) text += ' Paid this month: ' + paid.join(', ') + '.';
        } else {
          text = pp.map(function (p) { return p.name + ': ' + ((p.units || []).filter(function (u) { return u.rent > 0; }).map(function (u) { return (u.tenant || u.label) + ' ' + inr(u.rent) + ' a month' + ((u.late || []).length ? ', behind ' + inr(sum(u.late, function (x) { return x.amt; })) : u.state === 'booked' ? ', paid this month' : u.state === 'due' ? ', due this month' : ''); }).join('; ') || 'no tenants') + (p.taxDue ? '; property tax due ' + inr(p.taxDue) : ''); }).join('. ') + '.';
        }
        data.behind = behind.length; data.owed = r0(sum(behind, function (b) { return b.amt; }));
        break;
      }
      case 'owed': {
        var ow = (ctx.owed || []).filter(function (o) { return !o.settled && (!a.person || has(o.name, a.person)); });
        var toMe = ow.filter(function (o) { return o.dir === 'in'; }), byMe = ow.filter(function (o) { return o.dir !== 'in'; });
        text = ow.length ? (toMe.length ? 'Owed to you ' + inr(sum(toMe, function (o) { return o.amount; })) + ': ' + toMe.map(function (o) { return (o.name || 'someone') + ' ' + inr(o.amount) + ' for ' + o.title; }).join('; ') + '. ' : '') +
          (byMe.length ? 'You owe ' + inr(sum(byMe, function (o) { return o.amount; })) + ': ' + byMe.map(function (o) { return o.name + ' ' + inr(o.amount) + ' for ' + o.title; }).join('; ') + '.' : '') : 'Nothing owed either way.';
        break;
      }
      case 'noticed': {
        var w = ctx.watch || [];
        text = w.length ? w.map(function (f) { return '[' + (f.sev === 3 ? 'act now' : f.sev === 2 ? 'worth a look' : 'good to know') + '] ' + f.title + '. ' + f.detail; }).join('\n') : 'Nothing stands out right now.';
        w.forEach(function (f) { ids = ids.concat(f.rows || []); });
        break;
      }
      case 'papers': {
        var facts = (ctx.facts || []).filter(function (x) { return !a.kind || a.kind === 'any' || x.k === a.kind || (a.kind === 'tax' && /form16|tds|interest/.test(x.k)); });
        var lines = facts.map(function (x) {
          if (x.k === 'payslip') return 'Payslip ' + x.month + ' from ' + (x.employer || 'employer') + ': gross ' + inr(x.gross) + ', deductions ' + inr(x.deductions) + ', net ' + inr(x.net) + (x.tds ? ', income tax ' + inr(x.tds) : '') + (x.pf ? ', PF ' + inr(x.pf) : '');
          if (x.k === 'gains') return 'Capital gains FY ' + x.fy + ': short term ' + inr(x.stcg || 0) + ', long term ' + inr(x.ltcg || 0);
          // (the mail's own: a deductor's line in the Form 26AS mail, a client's payment advice)
          if (x.k === 'tds' && (x.src === '26as' || x.src === 'advice')) return (x.src === '26as' ? 'Form 26AS' : 'Payment advice') + ' FY ' + (x.fy || '?') + (x.payer ? ' from ' + x.payer : '') + (x.amount ? ': paid ' + inr(x.amount) : '') + ', TDS ' + inr(x.tds || 0);
          return (x.k === 'form16' ? 'Form 16' : x.k === 'interest' ? 'Interest certificate' : 'TDS certificate') + ' FY ' + (x.fy || '?') + (x.payer ? ' from ' + x.payer : '') + (x.amount ? ': amount ' + inr(x.amount) : '') + (x.tds ? ', TDS ' + inr(x.tds) : '');
        });
        // the TDS of each year in all: the Form 26AS mail's own figure for a year it covers (the department's record of
        // every deductor), else what the payment advices add up to; never the two added together
        var tdsFy = {};
        facts.forEach(function (x) {
          if (x.k !== 'tds' || !(x.src === '26as' || x.src === 'advice') || !(x.tds > 0)) return;
          var g = tdsFy[x.fy || '?'] = tdsFy[x.fy || '?'] || { as: 0, adv: 0, n26: 0 };
          if (x.src === '26as') { g.as += x.tds; g.n26++; } else g.adv += x.tds;
        });
        Object.keys(tdsFy).sort().forEach(function (fy) {
          var g = tdsFy[fy];
          lines.push('TDS for FY ' + fy + ' in all: ' + inr(g.n26 ? g.as : g.adv) + (g.n26 ? ' (as Form 26AS shows it)' : ' (from the payment advices in your mail)'));
        });
        // (tax deducted at source is only in tax papers: with none read, kosh says plainly it can't see it)
        text = lines.length ? lines.join('\n') : a.kind === 'tax' ? 'kosh can’t see tax deducted at source yet: it reads it from tax papers in your mail (Form 16, Form 16A, 26AS), and none has come.' : 'No ' + (a.kind && a.kind !== 'any' ? a.kind + ' ' : '') + 'papers read yet.';
        break;
      }
      case 'decide': {
        var DA0 = decideAPI();
        if (!DA0) { text = 'Decisions aren’t available here.'; break; }
        var dArgs = {};
        Object.keys(a).forEach(function (k) { if (k !== 'kind') dArgs[k] = a[k]; });
        var dd0 = DA0.decide(a.kind, dArgs, ctx);
        if (!dd0) { text = 'Say which: prepay, car, afford, fd, emergency or card.'; break; }
        text = DA0.working(dd0);
        data.decision = dd0;
        break;
      }
      case 'calc': {
        var v = calc(String(a.expression || ''));
        text = v === null ? 'That isn’t plain arithmetic.' : String(a.expression) + ' = ' + fmtNum(v);
        data.value = v;
        break;
      }
      case 'claim': {
        if (!E.packs || !E.packs.claimTool) { text = 'Claims aren’t ready on this phone.'; break; }
        var co = E.packs.claimTool(a, ctx);
        text = co.text; ids = co.rows || []; data = co.data || {};
        break;
      }
      case 'propose': {
        var p = proposal(a, ctx);
        if (p.error) { text = p.error; break; }
        data.proposal = p;
        text = 'Shown to the person as a card to confirm: ' + p.title + '. Nothing is done until they tap it.';
        break;
      }
      default:
        if (L.askTool) { var o = L.askTool(name, a, ctx); return { text: o.text, rows: [], data: o.data || {} }; }
        text = 'No such tool.';
    }
    return { text: text, rows: ids.slice(0, 400), data: data };
  }

  /* arithmetic, and nothing else: numbers, + - * / ( ) and %, read by a small parser (never eval) */
  function calc(expr) {
    var s = expr.replace(/[,₹\s]|rs\.?/gi, ''), i = 0;
    if (!/^[\d.+\-*/()%]+$/.test(s) || s.length > 200) return null;
    function peek() { return s.charAt(i); }
    function num() { var m = /^\d+(?:\.\d+)?/.exec(s.slice(i)); if (!m) throw 0; i += m[0].length; var v = parseFloat(m[0]); if (peek() === '%') { i++; v /= 100; } return v; }
    function atom() { if (peek() === '(') { i++; var v = expr0(); if (peek() !== ')') throw 0; i++; return v; } if (peek() === '-') { i++; return -atom(); } return num(); }
    function term() { var v = atom(); while (peek() === '*' || peek() === '/') { var op = s.charAt(i++), r = atom(); v = op === '*' ? v * r : v / r; } return v; }
    function expr0() { var v = term(); while (peek() === '+' || peek() === '-') { var op = s.charAt(i++), r = term(); v = op === '+' ? v + r : v - r; } return v; }
    try { var v = expr0(); return i === s.length && isFinite(v) ? Math.round(v * 100) / 100 : null; } catch (e) { return null; }
  }
  function fmtNum(v) { var a = Math.abs(v); return a >= 1000 ? (v < 0 ? '-' : '') + inr(a).replace('₹', '') + (Math.round(a) !== a ? (a % 1).toFixed(2).slice(1) : '') : String(v); }

  /* an action for the person to confirm: what it is, in words they see, and what Swift does if they tap it */
  var CATS_OK = function (c) { return (E.CATS || []).some(function (x) { return lc(x.name || x[0] || x) === lc(c); }); };
  function proposal(a, ctx) {
    var why = String(a.why || '').slice(0, 160);
    switch (a.action) {
      case 'budget':
        if (!(a.amount > 0)) return { error: 'A budget needs an amount.' };
        return { action: 'budget', category: a.category || '', amount: r0(a.amount), title: 'Set ' + (a.category ? a.category + '’s' : 'the month’s') + ' budget to ' + inr(a.amount), why: why };
      case 'recategorize': {
        if (!a.merchant || !a.category) return { error: 'Say which merchant and which category.' };
        var hits = (ctx.tx || []).filter(function (t) { return lc(t.m) === lc(a.merchant); });
        if (!hits.length) hits = (ctx.tx || []).filter(function (t) { return has(t.m, a.merchant); });
        if (!hits.length) return { error: 'No payments to ' + a.merchant + ' in the ledger.' };
        if (E.CATS && !CATS_OK(a.category)) return { error: a.category + ' isn’t one of kosh’s categories.' };
        hits.sort(function (x, y) { return y.d.localeCompare(x.d); });
        return { action: 'recategorize', merchant: hits[0].m, category: a.category, sub: a.sub || '', tx: hits[0].id, count: hits.length,
                 title: 'File ' + hits[0].m + ' under ' + a.category + (a.sub ? ' › ' + a.sub : '') + ' (' + hits.length + ' payment' + (hits.length === 1 ? '' : 's') + ', and from now on)', why: why };
      }
      case 'remind':
        if (!/^\d{4}-\d{2}-\d{2}$/.test(a.date || '') || a.date < ctx.today) return { error: 'A reminder needs a date from today on (YYYY-MM-DD).' };
        return { action: 'remind', date: a.date, amount: r0(a.amount || 0), title: 'Remind me on ' + dShort(a.date) + ': ' + String(a.title || 'this').slice(0, 60), note: String(a.title || '').slice(0, 80), why: why };
      case 'chapter':
        if (!/^\d{4}-\d{2}-\d{2}$/.test(a.date || '')) return { error: 'A chapter needs a first day.' };
        return { action: 'chapter', date: a.date, until: /^\d{4}-\d{2}-\d{2}$/.test(a.until || '') ? a.until : '', title: 'Start a chapter: ' + String(a.title || 'Trip').slice(0, 40), name: String(a.title || 'Trip').slice(0, 40), why: why };
    }
    return { error: 'Not an action kosh can take.' };
  }

  /* every figure in the answer has to come from a tool (or the question): amounts, counts, percentages. Dates and
     years don't count. Rounded forms are fine: ₹1.2L for 1,20,431, ₹45,000 for 44,980, 18% for 17.6. */
  function agentCheck(answer, toolTexts, question) {
    var pool = [];
    function nums(s) {
      var out = [], re = /(₹\s?)?(\d[\d,]*(?:\.\d+)?)\s?(l\b|lakh|lac|cr\b|crore|k\b|%)?/gi, m;
      String(s || '').replace(/\b\d{4}-\d{2}-\d{2}\b|\b\d{1,2}:\d{2}\b|••\d+|\b(?:19|20)\d{2}\b(?![,\d])/g, ' ').replace(/\b\d{1,2}(?:st|nd|rd|th)\b/gi, ' ').replace(/\b\d{1,2} (?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\b/gi, ' ')
        .replace(re, function (all, cur, n, unit) {
          var v = parseFloat(n.replace(/,/g, '')), u = lc(unit || '');
          if (u === 'l' || u === 'lakh' || u === 'lac') v *= 1e5; else if (u === 'cr' || u === 'crore') v *= 1e7; else if (u === 'k') v *= 1e3;
          out.push({ v: v, raw: all, pct: u === '%', rough: !!u && u !== '%' });
          return all;
        });
      return out;
    }
    (toolTexts || []).forEach(function (t) { nums(t).forEach(function (x) { pool.push(x.v); }); });
    nums(question).forEach(function (x) { pool.push(x.v); });
    var bad = [];
    nums(answer).forEach(function (x) {
      if (x.v <= 12 && !x.pct && !/₹/.test(x.raw)) return;   // "two cards", "3 payments", "12 months"
      var ok = pool.some(function (p) {
        if (Math.abs(p - x.v) <= 1) return true;
        var tol = x.rough ? Math.max(Math.abs(p) * 0.01, x.v >= 1e7 ? 5e4 : 500) : x.pct ? 1 : Math.max(1, Math.abs(p) * 0.005);
        return Math.abs(p - x.v) <= tol || (x.v >= 1000 && Math.abs(Math.round(p / 1000) * 1000 - x.v) < 1) || (x.v >= 100 && Math.abs(Math.round(p / 100) * 100 - x.v) < 1);
      });
      if (!ok) bad.push(x.raw.trim());
    });
    return { ok: !bad.length, bad: bad };
  }

  function agentSystem(today, name, mode) {
    return [
      'You are kosh, the household money assistant inside the kosh app in India' + (name ? ', helping ' + name : '') + '. Today is ' + today + ' (' + dShort(today) + ' ' + today.slice(0, 4) + ').',
      'Everything you know about the household’s money comes from the tools, which read the ledger on the person’s phone. Look things up before answering; use several tools when the question needs it (compare periods, check balances against what’s due, look at the transactions behind a total).',
      'Never make up or estimate a figure, payee or date. Never do arithmetic in your head: any total, difference, percentage or average you state must come from a tool, and for anything the tools didn’t add up use calc.',
      'Before your first lookup, think about what the question really needs. "What changed" or "why is it higher" → compare (it lines up the same days of each month). "Am I spending more on X lately" → trend. "Can I pay what’s due" → cover. Loans, SIPs, saving for something → whatif (ask for any number you don’t have; never assume a loan’s rate). A decision (prepay a loan or invest, a car in cash or on a loan, can we afford something, break an FD, is the emergency fund enough, pay a card in full or the minimum) → decide: it shows the working on their own numbers. Then look at the payments behind a surprising figure before explaining it.',
      'Write rupees as ₹12,400, or ₹1.2L / ₹1.05Cr for big amounts. Dates as 12 Oct. Indian financial year runs April to March.',
      'Answer first, in one or two short sentences, then at most three short bullet points with the figures that matter. Plain, warm, a little wit is welcome; no lectures, no disclaimers, except one short closing line on a decision: the choice is theirs, and kosh isn’t a financial adviser.',
      'When the person asks you to do something (set a budget, file a merchant under a category, remind them, start a chapter for a trip), use propose; it becomes a card they confirm. Don’t claim it’s done.',
      'If the tools don’t have it, say so plainly and say what would let kosh know (a statement, a mail, adding it by hand).',
      mode === 'brief' ? 'You are writing the daily brief: rank what kosh noticed by what matters most today, three items at most, one line each.' : '',
    ].filter(Boolean).join('\n');
  }

  /* ================================================================ reading rules learned from mail
     When a bank's alert matches none of kosh's rules, the person can let the assistant look at a redacted copy
     and write a rule for that layout, as data: the sender's domain, the subject it applies to, and patterns for
     the amount, the account or card digits, the payee, the date and which way the money went. A rule is kept
     only if it reads every sample it was made from (and others like it) to an amount printed in the mail, and
     never disagrees with a built-in rule's reading of the same sender's mail. It's then applied to that
     sender's mail the built-in rules can't read, on this phone; shared rules come as the same data. */
  var LEARNED = [];
  var BAD_RE = /\((?:[^()]|\\\()*[+*](?:[^()]|\\\))*\)\s*[+*{]|(?:\.\*){2,}|\\[1-9]/;
  function re(src, flags) {
    if (!src || typeof src !== 'string' || src.length > 300 || BAD_RE.test(src)) return null;
    try { return new RegExp(src, flags || 'i'); } catch (e) { return null; }
  }
  function domainOf(from) { var m = /<([^>]+)>/.exec(from || ''), e = lc(m ? m[1] : from); return e.split('@')[1] || e; }
  function dirOf(rule, hay) {
    var o = re(rule.dirOut), i = re(rule.dirIn);
    if (i && i.test(hay)) return 'in';
    if (o && o.test(hay)) return 'out';
    return rule.dir === 'in' || rule.dir === 'out' ? rule.dir : '';
  }
  function applyRule(rule, msg, base) {
    var dom = domainOf(msg.from || '');
    if (!rule || !rule.domain || !(dom === rule.domain || dom.slice(-(rule.domain.length + 1)) === '.' + rule.domain)) return null;
    var subj = L.normalize ? L.normalize(msg.subject || '', '') : String(msg.subject || '');
    var text = (L.normalize ? L.normalize(msg.text || '', msg.html || '') : String(msg.text || '')).slice(0, 4000);
    var sr = rule.subject ? re(rule.subject) : null;
    if (rule.subject && (!sr || !sr.test(subj))) return null;
    var hay = subj + ' . ' + text;
    var am = re(rule.amount), m = am && am.exec(hay);
    if (!m || !m[1]) return null;
    var amt = L.amount ? L.amount(m[1]) : parseFloat(String(m[1]).replace(/,/g, ''));
    if (!(amt > 0) || amt >= 1e8) return null;
    var dir = dirOf(rule, hay);
    if (!dir) return null;
    var l4 = '', lm = re(rule.last4), mm = lm && lm.exec(hay);
    if (mm && mm[1]) l4 = String(mm[1]).replace(/\D/g, '').slice(-4);
    var party = '', pm = re(rule.party), pp = pm && pm.exec(hay);
    if (pp && pp[1]) party = String(pp[1]).replace(/\s+/g, ' ').trim().slice(0, 60);
    var date = '', dm = re(rule.date), dd = dm && dm.exec(hay);
    if (dd && dd[1] && L.isoDate) date = L.isoDate(dd[1], '');
    var sent = (msg.date || '').slice(0, 10);
    if (!date || !L.validDay || !L.validDay(date)) date = sent;
    return Object.assign({}, base || {}, { id: msg.id, sent: sent, kind: 'txn', src: 'learned', rule: 'learned:' + rule.id, dir: dir, amt: amt, date: date, time: '',
      instr: rule.instr || (l4 ? 'account' : ''), last4: l4, party: party, vpa: '', mode: '', conf: 'medium', reason: '' });
  }
  function learnedParse(msg, r) {
    for (var i = 0; i < LEARNED.length; i++) {
      var x = applyRule(LEARNED[i], msg, r);
      if (x) return x;
    }
    return null;
  }
  if (E.learnedHook) E.learnedHook(learnedParse);

  /* does a proposed rule hold? It must read every sample (the mails it was made from, and others from the sender
     with the same kind of subject) to an amount that is printed in the mail, and agree with every built-in
     reading of the same sender's mail it also matches */
  function ruleCheck(rule, samples, known) {
    var problems = [];
    if (!rule || !rule.domain || !/^[a-z0-9.-]+\.[a-z]{2,}$/i.test(rule.domain)) problems.push('no sender domain');
    ['subject', 'amount', 'last4', 'party', 'date', 'dirOut', 'dirIn'].forEach(function (k) { if (rule && rule[k] && !re(rule[k])) problems.push(k + ' pattern can’t be used'); });
    if (rule && !rule.amount) problems.push('no amount pattern');
    if (problems.length) return { ok: false, read: 0, of: (samples || []).length, problems: problems };
    var read = 0;
    (samples || []).forEach(function (msg, i) {
      var x = applyRule(rule, msg, {});
      if (!x) { problems.push('sample ' + (i + 1) + ' wasn’t read'); return; }
      var hay = (msg.subject || '') + ' ' + (L.normalize ? L.normalize(msg.text || '', msg.html || '') : msg.text || '');
      var printed = (hay.match(/\d[\d,]*(?:\.\d{1,2})?/g) || []).some(function (s) { return Math.abs(parseFloat(s.replace(/,/g, '')) - x.amt) < 0.005; });
      if (!printed) { problems.push('sample ' + (i + 1) + ': ' + x.amt + ' isn’t printed in the mail'); return; }
      if (x.last4 && !new RegExp(x.last4).test(hay)) { problems.push('sample ' + (i + 1) + ': digits not in the mail'); return; }
      // a pattern the rule gives has to find its value in every sample, or it's guessing at the layout
      if ((rule.last4 && !x.last4) || (rule.party && !x.party) || (rule.date && x.date === (msg.date || '').slice(0, 10) && !re(rule.date).test(hay))) { problems.push('sample ' + (i + 1) + ': a pattern found nothing'); return; }
      read++;
    });
    (known || []).forEach(function (k, i) {
      var x = applyRule(rule, k.msg, {});
      if (x && k.rec && k.rec.kind === 'txn' && (Math.abs(x.amt - k.rec.amt) > 0.5 || (k.rec.dir && x.dir !== k.rec.dir))) problems.push('disagrees with how kosh already reads mail ' + (i + 1));
    });
    return { ok: !problems.length && read > 0 && read === (samples || []).length, read: read, of: (samples || []).length, problems: problems };
  }

  /* what the assistant is asked, to write a rule: the redacted mails and the shape of a rule */
  var RULE_TOOL = {
    name: 'propose_rule',
    description: 'A reading rule for this sender’s alert layout, as JavaScript regular expressions (case-insensitive). Each pattern with a value captures it in group 1. The patterns run on the subject + " . " + the mail text with tags removed and spaces collapsed, exactly as shown.',
    input_schema: { type: 'object', required: ['domain', 'amount', 'why'], properties: {
      domain: { type: 'string', description: 'The sender’s domain, e.g. examplebank.co.in' },
      subject: { type: 'string', description: 'A pattern the subject must match, specific to this kind of alert' },
      amount: { type: 'string', description: 'Captures the amount, digits and commas, e.g. (?:Rs\\.?|INR|₹)\\s?([\\d,]+(?:\\.\\d{1,2})?) debited' },
      dirOut: { type: 'string', description: 'Matches when money went out' }, dirIn: { type: 'string', description: 'Matches when money came in' },
      dir: { type: 'string', enum: ['out', 'in', ''], description: 'Fixed direction if the layout only ever goes one way' },
      last4: { type: 'string', description: 'Captures the account or card digits (the masked number)' },
      party: { type: 'string', description: 'Captures who was paid or who paid' },
      date: { type: 'string', description: 'Captures the transaction date as printed' },
      instr: { type: 'string', enum: ['account', 'card', 'wallet', 'upi', ''] },
      why: { type: 'string', description: 'One sentence: what layout this reads' } } },
  };
  /* the sender's mail as Claude sees it to write a rule: masked as Claude's reading masks mail (your and your family's
     names as Name1, Name2..., personal addresses, PANs, long numbers but their last four) */
  function rulePrompt(samples, opts) {
    var RD = E.reader && E.reader.claude && E.reader.claude.masker ? E.reader.claude : null;
    var M = RD ? RD.masker((opts || {}).names || []) : null;
    function mask(s) { return M ? M.mask(s) : L.redact ? L.redact(s) : s; }
    var body = (samples || []).map(function (m, i) {
      var subj = L.normalize ? L.normalize(m.subject || '', '') : m.subject;
      var text = (L.normalize ? L.normalize(m.text || '', m.html || '') : m.text || '').slice(0, 2500);
      return 'Mail ' + (i + 1) + ' from ' + domainOf(m.from || '') + '\nSubject: ' + mask(subj) + '\nText: ' + mask(text);
    }).join('\n\n---\n\n');
    return 'kosh’s rules couldn’t read these alerts from one sender. Long numbers are masked except their last digits; names of people are Name1, Name2...; personal emails are (email), PANs (PAN). Write one rule (propose_rule) that reads all of them: the amount, which way the money went, the account or card digits, the payee and the date. Match the wording, not the masked values.\n\n' + body;
  }

  /* ================================================================ statement passwords from the sender's rule
     The sender's mail says what the password is made of ("first four letters of your name in capitals and your
     date of birth as DDMM"). With the details the person saved once on this phone (name, date of birth, PAN,
     mobile), kosh puts that together, exactly as the sentence says, and tries it once. A piece it doesn't have,
     or a rule it can't take apart, means it asks, as before. */
  function pwBuild(hint, profile, ctx) {
    var R0 = L.pwRecipe ? L.pwRecipe(hint || '') : { parts: [], example: '' };
    if (!R0.parts.length) return { ok: false, candidates: [], missing: [], note: 'The mail doesn’t say what the password is made of' };
    // each way the mail gives is built on its own; any that can be made is tried
    var alts = R0.alts && R0.alts.length ? R0.alts : [R0];
    var cands = [], missing = [], notes = [];
    alts.forEach(function (R) {
      var b = pwBuildOne(R, profile, ctx);
      b.candidates.forEach(function (c) { if (cands.indexOf(c) < 0) cands.push(c); });
      if (!b.ok) missing.push(b.missing.join(' and '));
      notes.push(b.note);
    });
    // (each made from the sender's own rule: its format is "hint", the one the phone remembers when it opens)
    if (cands.length) return { ok: true, candidates: cands.slice(0, 8), formats: cands.slice(0, 8).map(function () { return 'hint'; }), missing: [], note: 'Made from the sender’s rule' };
    // nothing could be made: what would make it, one way or the other
    missing = missing.filter(Boolean);
    return { ok: false, candidates: [], missing: missing.length > 1 ? [missing.join(', or ')] : missing, note: 'kosh needs ' + (missing.length > 1 ? missing.join(', or ') : missing[0] || 'more') };
  }
  // a Customer ID or CRN typed for the sender's address, or for its bank by name ("bank:hdfc bank"): one bank mails from
// several addresses, and a person adds the ID against the bank, before any statement from it has come
// (else the ID the sender's own mail printed: the person's details as kosh read them, P.facts)
function pwIdFor(P, C, kinds) {
  var ids = (P && P.ids) || {}, d = String(C.domain || '').toLowerCase(), b = String(C.inst || '').toLowerCase().trim();
  return ids[C.domain || ''] || ids[d] || (b ? ids['bank:' + b] : '') || pwFactOf(P, C, kinds || ['customerId', 'crn', 'cif', 'ucic', 'relationshipNo'])[0] || '';
}
/* The details kosh read from this person's mail and papers (the profile's facts: [{ k, v, inst, domain }]), of the
   kinds asked, that belong to the sender at hand: printed by the same institution, or mailed from the same address.
   Whole values only (a masked "XXXX6789" opens nothing), unless `digits` asks for the last digits of each. */
function pwFactOf(P, C, kinds, digits) {
  var fs = (P && P.facts) || [], d = String(C.domain || '').toLowerCase().replace(/^www\./, ''), b = String(C.inst || '').toLowerCase().trim(), out = [];
  var root = function (x) { var p = String(x || '').toLowerCase().split('.'); return p.length > 2 ? p.slice(-3).join('.') : p.join('.'); };
  fs.forEach(function (f) {
    if (!f || kinds.indexOf(f.k) < 0 || !f.v) return;
    var fd = String(f.domain || '').toLowerCase(), fi = String(f.inst || '').toLowerCase().trim();
    var ours = (b && fi && fi === b) || (d && fd && (fd === d || d.slice(-fd.length - 1) === '.' + fd || fd.slice(-d.length - 1) === '.' + d || root(fd) === root(d)));
    if (!ours) return;
    var v = String(f.v);
    if (digits) { v = v.replace(/\D/g, ''); if (v.length >= 4 && out.indexOf(v) < 0) out.push(v); return; }
    if (/[x*•]{2,}/i.test(v)) return;
    v = v.replace(/[\s\-]/g, '');
    if (v.length >= 4 && out.indexOf(v) < 0) out.push(v);
  });
  return out;
}
// (the details that are the person's wherever they were printed: a PAN, a date of birth, a mobile, a PIN code)
function pwOwn(P, k) {
  var fs = (P && P.facts) || [];
  for (var i = 0; i < fs.length; i++) if (fs[i] && fs[i].k === k && fs[i].v && !/[x*•]{2,}/i.test(String(fs[i].v))) return String(fs[i].v);
  return '';
}
/* A detail that can't be right is no detail: a date of birth that never was (31 April, 29 February 1990, a month 13,
   a day still to come), a PAN printed masked (its fourth letter, the holder's kind, is never X: "XXXXX1234X",
   "ABCXX1234X"). Kosh may have read either from a mail; built into a password it opens nothing and stands where kosh
   should ask. A name kept with its title ("Mr. Asha Example") is the name without it: banks build from the name. */
function pwDobOk(s) {
  var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(s || ''));
  if (!m) return false;
  var y = +m[1], mo = +m[2], d = +m[3], dt = new Date(Date.UTC(y, mo - 1, d));
  return y >= 1900 && mo >= 1 && mo <= 12 && d >= 1 && dt.getUTCMonth() === mo - 1 && dt.getTime() <= Date.now();
}
function pwPanOk(s) { var p = String(s || '').toUpperCase(); return /^[A-Z]{5}\d{4}[A-Z]$/.test(p) && p.charAt(3) !== 'X'; }
var PW_TITLE = /^(?:mr|mrs|ms|miss|mx|dr|shri|sri|smt|kumari|km|master|m\/s)\.?\s+/i;
function pwName(s) { var n = String(s || '').trim(), was; do { was = n; n = n.replace(PW_TITLE, ''); } while (n !== was); return n; }
// (a profile's own PAN, date of birth, mobile and PIN code: as saved, else as its mail printed them whole)
function pwWithOwn(profile) {
  var P = Object.assign({}, profile || {});
  P.name = pwName(P.name);
  if (P.dob && !pwDobOk(P.dob)) P.dob = '';
  if (P.pan && !pwPanOk(P.pan)) P.pan = '';
  if (!P.pan) { var pan = pwOwn(P, 'pan').toUpperCase(); if (pwPanOk(pan)) P.pan = pan; }
  if (!P.dob) { var dob = pwOwn(P, 'dob'); if (pwDobOk(dob)) P.dob = dob; }
  if (!P.mobile) { var mob = pwOwn(P, 'mobile').replace(/\D/g, '').slice(-10); if (mob.length === 10) P.mobile = mob; }
  if (!P.pin) { var pin = pwOwn(P, 'pinCode'); if (/^\d{6}$/.test(pin)) P.pin = pin; }
  return P;
}
function pwBuildOne(R, profile, ctx) {
    var P = pwWithOwn(profile), C = ctx || {};
    var ex = R.example || '', missing = [], pieces = [];
    var dob = /^(\d{4})-(\d{2})-(\d{2})$/.exec(P.dob || '');
    var offset = 0;
    R.parts.forEach(function (part) {
      var n = +(/(\d+)/.exec(part.label) || [])[1] || 0, opts = [];
      var exPart = ex ? ex.slice(offset) : '';
      switch (part.k) {
        case 'name': {
          var nm = String(/first name/i.test(part.label) ? (P.name || '').split(/\s+/)[0] : P.name || '').replace(/[^A-Za-z]/g, '');
          if (!nm) { missing.push('your name'); break; }
          // "first 5 letters ... if the name is shorter than 5, the whole first name": a short name uses all of it
          var s = n ? (nm.length >= n ? nm.slice(0, n) : nm) : nm, exL = exPart.slice(0, s.length);
          if (part.note === 'lowercase' || (/^[a-z]+$/.test(exL))) opts = [s.toLowerCase()];
          else if (part.note === 'CAPITALS' || (/^[A-Z]+$/.test(exL))) opts = [s.toUpperCase()];
          else opts = [s.toUpperCase(), s.toLowerCase()];
          offset += s.length;
          break;
        }
        case 'dob': {
          if (!dob) { missing.push(/year of birth/i.test(part.label) ? 'your year of birth' : 'your date of birth'); break; }
          var fmt = part.note || '', exD = (/^\d+/.exec(exPart) || [''])[0];
          if (!fmt && exD) fmt = exD.length === 8 ? 'DDMMYYYY' : exD.length === 6 ? 'DDMMYY' : exD.length === 4 ? 'DDMM' : '';
          if (!fmt && /year of birth/i.test(part.label)) fmt = 'YYYY';
          var y = dob[1], m = dob[2], d = dob[3];
          var MON3 = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'];
          var mon = MON3[(+m || 1) - 1];
          var made = { DDMMYYYY: d + m + y, DDMMYY: d + m + y.slice(2), DDMM: d + m, MMYYYY: m + y, YYYY: y };
          if (fmt === 'DDMMMYYYY') opts = [d + mon + y, d + mon.toUpperCase() + y];
          else opts = fmt && made[fmt] ? [made[fmt]] : [made.DDMMYYYY, made.DDMM];
          offset += opts[0].length;
          break;
        }
        case 'mobile': {
          var mob = String(P.mobile || '').replace(/\D/g, '').slice(-10);
          if (mob.length !== 10) { missing.push('your mobile number'); break; }
          // "your 10 digit registered mobile number" → the whole number; else the slice the rule names
          opts = [n ? (/^first/i.test(part.label) ? mob.slice(0, n) : mob.slice(-n)) : mob]; offset += opts[0].length;
          break;
        }
        case 'card': case 'acct': {
          var dg = String(C.last4 || '').replace(/\D/g, '');
          // (else the number the sender's own mail printed, when it printed one for it: as many digits as it showed)
          if (!n || n > dg.length) {
            var fdg = pwFactOf(P, C, part.k === 'card' ? ['cardNo'] : ['accountNo', 'loanAccount', 'ppfAccount'], true);
            for (var fi = 0; fi < fdg.length; fi++) if (n && fdg[fi].length >= n) { dg = fdg[fi]; break; }
          }
          if (!n || n > dg.length) { missing.push(part.k === 'card' ? 'the card’s digits' : 'the account number'); break; }
          opts = [dg.slice(-n)]; offset += n;
          break;
        }
        case 'pan': {
          var pan = String(P.pan || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
          if (!/^[A-Z]{5}\d{4}[A-Z]$/.test(pan)) { missing.push('your PAN'); break; }
          var pv = n ? pan.slice(0, n) : pan;
          opts = part.note === 'lowercase' ? [pv.toLowerCase()] : [pv]; offset += pv.length;
          break;
        }
        case 'crn': case 'cid': {
          var id = pwIdFor(P, C, part.k === 'crn' ? ['crn', 'customerId', 'cif', 'relationshipNo', 'ucic'] : ['customerId', 'crn', 'cif', 'ucic', 'relationshipNo']);
          if (!id) { missing.push(part.k === 'crn' ? 'your CRN' : 'your Customer ID'); break; }
          // ("Digits 4 to 9 of your Customer ID": that slice of it, counted from the left)
          var sl = /^Digits (\d+) to (\d+)/.exec(part.label), idS = String(id);
          if (sl) { if (+sl[2] > idS.length || +sl[1] < 1 || +sl[1] > +sl[2]) { missing.push('your Customer ID'); break; } idS = idS.slice(+sl[1] - 1, +sl[2]); }
          opts = [idS]; offset += idS.length;
          break;
        }
        case 'policy': {
          var pol = C.policy || pwFactOf(P, C, ['policyNo'])[0] || '';
          if (!pol) { missing.push('the policy number'); break; }
          opts = [String(pol)]; offset += String(pol).length; break;
        }
        case 'pin': { var pin = /^\d{6}$/.test(P.pin || '') ? P.pin : pwOwn(P, 'pinCode'); if (!/^\d{6}$/.test(pin || '')) { missing.push('your PIN code'); break; } opts = [pin]; offset += 6; break; }
        default: missing.push(part.label);
      }
      pieces.push(opts);
    });
    if (missing.length) return { ok: false, candidates: [], missing: missing, note: 'kosh needs ' + missing.join(', ') };
    var out = [''];
    pieces.forEach(function (opts) { var next = []; out.forEach(function (p) { opts.forEach(function (o) { next.push(p + o); }); }); out = next; });
    // the sender's example is the shape: a candidate of another length can't be right
    if (ex && /\d/.test(ex)) out = out.filter(function (c) { return c.length === ex.length; });
    return { ok: out.length > 0 && out.length <= 4, candidates: out.slice(0, 4), missing: [], note: out.length ? 'Made from the sender’s rule' : 'Doesn’t fit the sender’s example' };
  }

  /* ================================================================ answering without a model
     A question whose words say what it asks goes straight to the tool that answers it, with the period, the
     category, the merchant, the card or the person it names. The tool's own sentence is the answer: written by
     code from the ledger, so it's never wrong about a figure. Used on the phone when Claude isn't set up, and
     before any small model is asked; a question it can't place returns null and is said honestly. */
  var CAT_WORDS = [
    [/\b(?:food|eating out|restaurants?|dining|takeaway|cafes?|coffee|zomato|swiggy)\b/, 'Food & Drinks'],
    [/\b(?:groceries|grocery|kirana|ration|sabzi|sabji|vegetables|veggies|blinkit|zepto|instamart|bigbasket)\b/, 'Groceries'],
    [/\b(?:shopping|clothes|amazon|flipkart|myntra)\b/, 'Shopping'],
    // getting about where you live is Transport, not Travel (trips away): "travel around town", "local travel",
    // "travelling in the city", "getting around", "commuting"; asked before the Travel row, which "travel" alone takes
    [/\b(?:travel(?:l?ing)?\s+(?:around|within|in(?:side)?|across)\s+(?:the\s+)?(?:town|city)|local\s+(?:travel|transport|commute)|getting\s+around|commut(?:e|es|ing)|auto[\s-]?rickshaws?|rickshaws?|shahar\s+me(?:in)?\s+(?:aana\s+jaana|travel))\b/, 'Transport'],
    [/\b(?:travel|trips?|flights?|hotels?|holidays?|vacation)\b/, 'Travel'],
    [/\b(?:transport|cabs?|uber|ola|rapido|petrol|diesel|fuel|metro|commute)\b/, 'Transport'],
    [/\b(?:bills?|electricity|internet|broadband|mobile recharge|utilities)\b/, 'Bills'],
    [/\b(?:health|medical|medicines?|doctor|hospital|pharmacy)\b/, 'Medical'],
    [/\b(?:entertainment|movies?|concerts?|events?|games?)\b/, 'Entertainment'],
    [/\b(?:subscriptions?|netflix|spotify|prime|ott)\b/, 'Subscriptions'],
    [/\b(?:education|school fees?|tuition|courses?)\b/, 'Education'],
    [/\b(?:rent|house rent)\b/, 'Rent'],
    [/\b(?:emis?|home loan emis?|car loan emis?)\b/, 'EMI'],
    [/\b(?:home(?! loan)|household|maids?|cooks?|drivers?|nanny|cleaners?|domestic help|house help|furniture|repairs?)\b/, 'Home'],
    [/\b(?:personal care|salon|haircut|spa|grooming)\b/, 'Personal'],
    [/\b(?:atm|withdraw(?:al|als|n|s)?|cash withdrawals?)\b/, 'Cash Withdrawal'],
    [/\b(?:bank charges|late fees?|annual fees?|penalt(?:y|ies)|convenience fees?|hidden charges|forex markup)\b/, 'Hidden Charges'],
    [/\b(?:income tax|advance tax|property tax|tax(?:es)?)\b/, 'Tax'],
    [/\b(?:gifts?)\b/, 'Gift'],
    [/\b(?:donations?|charity|temple|gurudwara)\b/, 'Donation'],
    [/\b(?:gym|fitness|yoga)\b/, 'Fitness'],
  ];
  /* the second month a question names ("more in September than in August"): the stretch it is set against; null
     when it names fewer than two. A month without a year is the latest one that has begun. */
  function secondMonth(s, today) {
    var y = +today.slice(0, 4), mo = +today.slice(5, 7), hits = [], re = new RegExp('\\b' + MRE + '\\b(?:\\s+(20\\d{2}))?', 'g'), n;
    while ((n = re.exec(s))) { if (/^may$/.test(n[1]) && /^ i\b/.test(s.slice(n.index + 3))) continue; if (/^mar$/.test(n[1])) continue; hits.push(n); }
    if (hits.length < 2) return null;
    var i = monIx(hits[1][1]), yy = hits[1][2] ? +hits[1][2] : (i + 1 > mo ? y - 1 : y);
    var from = yy + '-' + ('0' + (i + 1)).slice(-2) + '-01';
    if (from > today) return null;
    var to = new Date(Date.UTC(yy, i + 1, 0)).toISOString().slice(0, 10);
    return { from: from, to: to > today ? today : to };
  }
  function periodOf(s, today) {
    var y = +today.slice(0, 4), mo = +today.slice(5, 7), n;
    var ms = function (yy, mm) { return yy + '-' + pad(mm) + '-01'; };
    var me = function (yy, mm) { return addDays(mm === 12 ? (yy + 1) + '-01-01' : yy + '-' + pad(mm + 1) + '-01', -1); };
    var mw = function (yy, mm) { return MONF[mm - 1] + (yy !== y ? ' ' + yy : ''); };
    var NUM = { a: 1, one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9, ten: 10, twelve: 12, fifteen: 15, thirty: 30 };
    if ((n = /\b(?:last|past|previous)\s+(\d+|[a-z]+)\s+(days?|weeks?|months?|years?)\b/.exec(s))) {
      var k = /^\d+$/.test(n[1]) ? +n[1] : NUM[n[1]] || 0;
      if (k) {
        var days = /^week/.test(n[2]) ? k * 7 : /^month/.test(n[2]) ? k * 30 : /^year/.test(n[2]) ? k * 365 : k;
        var unit = n[2].replace(/s$/, '');
        return { from: addDays(today, -(days - 1)), to: today, named: true, label: k === 1 ? 'in the last ' + unit : 'in the last ' + k + ' ' + unit + 's' };
      }
    }
    if (/\b(?:last|past|previous) (week|month|year)\b/.test(s) && /\b(?:in|over|during) the (?:last|past) (?:week|month|year)\b/.test(s)) {
      var u = /\b(?:last|past|previous) (week|month|year)\b/.exec(s)[1], dd = u === 'week' ? 7 : u === 'month' ? 30 : 365;
      return { from: addDays(today, -(dd - 1)), to: today, named: true, label: 'in the last ' + (u === 'week' ? '7 days' : u === 'month' ? '30 days' : '12 months') };
    }
    // dates the question names: "between 1 and 15 September", "since 1 April", "on 8 October", "from August to September"
    var named = datesOf(s, today);
    if (named) return named;
    if (/\bday before yesterday\b/.test(s)) { var d2 = addDays(today, -2); return { from: d2, to: d2, named: true, label: 'on ' + dShort(d2) }; }
    if (/\btoday\b/.test(s)) return { from: today, to: today, named: true, label: 'today' };
    if (/\byesterday\b/.test(s)) { var yd = addDays(today, -1); return { from: yd, to: yd, named: true, label: 'yesterday' }; }
    // quarters: the calendar's and India's financial year line up (Q1 is April to June)
    var cq = Math.floor((mo - 1) / 3), qFrom = function (yy, q) { return ms(yy, q * 3 + 1); }, qTo = function (yy, q) { return me(yy, q * 3 + 3); };
    var qLabel = function (yy, q) { return 'in ' + MON3[q * 3] + '–' + MON3[q * 3 + 2] + (yy !== y ? ' ' + yy : ''); };
    if (/\b(?:last|previous) quarter\b/.test(s)) { var lq = cq === 0 ? 3 : cq - 1, lqy = cq === 0 ? y - 1 : y; return { from: qFrom(lqy, lq), to: qTo(lqy, lq), named: true, label: qLabel(lqy, lq) }; }
    if (/\bthis quarter\b|\bcurrent quarter\b/.test(s)) return { from: qFrom(y, cq), to: today, named: true, label: 'this quarter' };
    if ((n = /\bq([1-4])\b(?: (?:of )?fy ?(?:20)?(\d{2}))?/.exec(s))) {
      // Q1 Apr–Jun, Q2 Jul–Sep, Q3 Oct–Dec, Q4 Jan–Mar; "FY27" is April 2026 to March 2027
      var fq = +n[1], fyEnd = n[2] ? 2000 + +n[2] : (mo >= 4 ? y + 1 : y), cal = fq === 4 ? 0 : fq, qy = fq === 4 ? fyEnd : fyEnd - 1;
      if (!n[2] && qFrom(qy, cal) > today) qy -= 1;
      if (qFrom(qy, cal) <= today) { var qt = qTo(qy, cal); return { from: qFrom(qy, cal), to: qt > today ? today : qt, named: true, label: 'in Q' + fq + ' (' + MON3[cal * 3] + '–' + MON3[cal * 3 + 2] + (qy !== y ? ' ' + qy : '') + ')' }; }
    }
    var dow = (new Date(dayOf(today)).getUTCDay() + 6) % 7;   // Monday = 0
    // "compare this month with last month": the one named first is the one asked about
    var first = function (a, b) { var i = s.search(a), j = s.search(b); return i >= 0 && (j < 0 || i < j); };
    if (/\bthis week\b/.test(s) && first(/\bthis week\b/, /\b(?:last|previous) week\b/)) return { from: addDays(today, -dow), to: today, named: true, label: 'this week' };
    if (/\b(?:last|previous) week\b/.test(s)) return { from: addDays(today, -dow - 7), to: addDays(today, -dow - 1), named: true, label: 'last week' };
    var thisM = /\bthis month\b|\bso far\b|\bmonth to date\b|\bcurrent month\b/;
    if (/\b(?:last|previous) month\b/.test(s) && !first(thisM, /\b(?:last|previous) month\b/)) { var py = mo === 1 ? y - 1 : y, pm = mo === 1 ? 12 : mo - 1; return { from: ms(py, pm), to: me(py, pm), named: true, label: 'in ' + mw(py, pm) }; }
    if (thisM.test(s)) return { from: ms(y, mo), to: today, named: true, label: 'this month' };
    if (/\b(?:this|current) (?:financial year|fy)\b|\bthis fy\b/.test(s)) { var fy = mo >= 4 ? y : y - 1; return { from: fy + '-04-01', to: today, named: true, label: 'this financial year' }; }
    if (/\b(?:last|previous) (?:financial year|fy)\b/.test(s)) { var lf = (mo >= 4 ? y : y - 1) - 1; return { from: lf + '-04-01', to: (lf + 1) + '-03-31', named: true, label: 'in FY ' + lf + '–' + String(lf + 1).slice(2) }; }
    if (/\bthis year\b|\bso far this year\b|\bytd\b/.test(s) && first(/\bthis year\b|\bytd\b/, /\blast year\b/)) return { from: y + '-01-01', to: today, named: true, label: 'this year' };
    if (/\blast year\b/.test(s)) return { from: (y - 1) + '-01-01', to: (y - 1) + '-12-31', named: true, label: 'in ' + (y - 1) };
    var mFirst = -1, nFirst = null;
    for (var i = 0; i < 12; i++) {
      var re1 = new RegExp('\\b(?:' + MONF[i].toLowerCase() + '|' + MON3[i].toLowerCase() + (i === 8 ? '|sept' : '') + ')\\b(?:\\s+(20\\d{2}))?');
      if ((n = re1.exec(s)) && !(MON3[i] === 'May' && /\bmay i\b/.test(s)) && !(i === 2 && /\bmar\b/.test(s) && !/\bmarch\b/.test(s)) && (!nFirst || n.index < nFirst.index)) { mFirst = i; nFirst = n; }
    }
    // two months named ("more in September than in August"): the one named first is the one asked about
    if (nFirst) {
      i = mFirst; n = nFirst;
      {
        var yy = n[1] ? +n[1] : (i + 1 > mo ? y - 1 : y);
        // a month still to come ("by May 2027") is a date to reach, not a stretch of the ledger
        if (ms(yy, i + 1) > today) return { from: ms(y, mo), to: today, named: false, label: '' };
        var to = me(yy, i + 1); if (to > today) to = today;
        return { from: ms(yy, i + 1), to: to, named: true, label: (yy === y && i + 1 === mo ? 'this month' : 'in ' + mw(yy, i + 1)) };
      }
    }
    if ((n = /\b(20\d{2})\b/.exec(s)) && +n[1] <= y) return { from: n[1] + '-01-01', to: n[1] === String(y) ? today : n[1] + '-12-31', named: true, label: n[1] === String(y) ? 'this year' : 'in ' + n[1] };
    return { from: ms(y, mo), to: today, named: false, label: '' };
  }
  /* a day or a stretch the question names by its dates: "on 8 October", "since 1 April", "between 1 and 15
     September", "from 5 Sep to 3 Oct", "from August to September". A day without a year is the latest one that has
     come (8 November, asked in October, is last year's). Null when it names none. */
  var MRE = '(jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|june?|july?|aug(?:ust)?|sep(?:t(?:ember)?)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)';
  var ORD = '(?:st|nd|rd|th)?';
  function monIx(w) { return ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'].indexOf(String(w).slice(0, 3)); }
  function datesOf(s, today) {
    var y = +today.slice(0, 4), n;
    var dayIso = function (d, mi, yy) {
      if (!(+d >= 1 && +d <= 31) || mi < 0) return '';
      var last = +monthEnd((yy || y) + '-' + pad(mi + 1) + '-01').slice(8);
      var iso = (yy || y) + '-' + pad(mi + 1) + '-' + pad(Math.min(+d, last));
      return !yy && iso > today ? (y - 1) + iso.slice(4) : iso;
    };
    var D = '(\\d{1,2})' + ORD, DM = D + ' (?:of )?' + MRE, YR = '(?: (20\\d{2}))?', TO = '(?: (?:and|to|till|until) | ?[-–] ?)';
    var span = function (a, b, label) { return a && b && a <= b && a <= today ? { from: a, to: b > today ? today : b, named: true, label: label } : null; };
    var words = function (a, b) {
      var yb = b.slice(0, 4) !== today.slice(0, 4) ? ' ' + b.slice(0, 4) : '';
      if (a.slice(0, 7) === b.slice(0, 7)) return 'from ' + +a.slice(8) + ' to ' + dShort(b) + yb;
      return 'from ' + dShort(a) + (a.slice(0, 4) !== b.slice(0, 4) ? ' ' + a.slice(0, 4) : '') + ' to ' + dShort(b) + yb;
    };
    // "between 1 and 15 September", "1 to 15 sep", "from 5 sep to 3 oct": day A, its month (or B's), day B, month B, year
    if ((n = new RegExp('\\b(?:between |from )?' + D + '(?: (?:of )?' + MRE + ')?' + TO + DM + YR + '\\b').exec(s))) {
      var mB = monIx(n[4]), mA = n[2] ? monIx(n[2]) : mB, yB = n[5] ? +n[5] : 0;
      var b = dayIso(n[3], mB, yB), a = dayIso(n[1], mA, yB);
      // "from 20 Dec to 5 Jan": the first day is in the year before
      if (a && b && a > b) a = (+a.slice(0, 4) - 1) + a.slice(4);
      var r = span(a, b, a && b ? words(a, b) : '');
      if (r) return r;
    }
    // "from August to September", "between July and September"
    if ((n = new RegExp('\\b(?:between|from) ' + MRE + ' (?:and|to|till|until|-|–) ' + MRE + YR + '\\b').exec(s))) {
      var m1 = monIx(n[1]), m2 = monIx(n[2]), y2 = n[3] ? +n[3] : (y + '-' + pad(m2 + 1) > today.slice(0, 7) ? y - 1 : y), y1 = m1 > m2 ? y2 - 1 : y2;
      var r2 = span(y1 + '-' + pad(m1 + 1) + '-01', monthEnd(y2 + '-' + pad(m2 + 1) + '-01'), 'from ' + MONF[m1] + ' to ' + MONF[m2] + (y2 !== y ? ' ' + y2 : ''));
      if (r2) return r2;
    }
    // "since 1 April", "since April", "from 1st April"
    if ((n = new RegExp('\\b(?:since|from) (?:(\\d{1,2})' + ORD + ' (?:of )?)?' + MRE + YR + '\\b').exec(s))) {
      var sf = dayIso(n[1] || 1, monIx(n[2]), n[3] ? +n[3] : 0);
      if (sf && sf <= today) return { from: sf, to: today, named: true, label: 'since ' + dShort(sf) + (sf.slice(0, 4) !== today.slice(0, 4) ? ' ' + sf.slice(0, 4) : '') };
    }
    // one day: "on 8 October", "8 oct", "october 8", "on the 5th"
    if ((n = new RegExp('(?:^| )(?:on )?' + DM + YR + '\\b').exec(s)) || (n = new RegExp('(?:^| )(?:on )?' + MRE + ' (\\d{1,2})' + ORD + '\\b' + YR).exec(s))) {
      var monFirst = !/^\d/.test(n[1]);
      var one = dayIso(monFirst ? n[2] : n[1], monIx(monFirst ? n[1] : n[2]), n[3] ? +n[3] : 0);
      if (one && one <= today) return { from: one, to: one, named: true, label: 'on ' + dShort(one) + (one.slice(0, 4) !== today.slice(0, 4) ? ' ' + one.slice(0, 4) : '') };
    }
    if ((n = /\bon the (\d{1,2})(?:st|nd|rd|th)\b/.exec(s))) {
      var dd = +n[1], cand = today.slice(0, 8) + pad(dd);
      if (cand > today) cand = addDays(today.slice(0, 8) + '01', -1).slice(0, 8) + pad(dd);
      if (dd >= 1 && dd <= 31 && cand <= today) return { from: cand, to: cand, named: true, label: 'on ' + dShort(cand) };
    }
    return null;
  }
  // an expense claim: "make my October travel claim", "what can I claim", "reimbursement for last month"
  var CLAIM_WORDS = /\breimburs\w*|\b(?:travel|expense|expenses|office|work) claims?\b|\bexpense (?:report|sheet|statement)\b|\bwhat can i claim\b|\bmake (?:my|a|the) (?:\w+ )?claim\b|\bclaim (?:for|my|the) (?:travel|cabs?|rides?|flights?|trip)/;
  var CLAIM_CAME = /\b(?:came|come|received|credited|got|arrived?|paid|when will)\b/;
  /* the tool a question goes to and what to ask it, read the way the phone reads the question (understand): the same
     period, category, payee, card and person, so kosh-bench measures what the phone runs. Null when the phone
     wouldn't place it, or when no single tool answers it (it's left to the model). */
  function route(q, ctx) {
    ctx = ctx || {};
    var today = ctx.today || '';
    if (!today || String(q || '').trim().length < 3) return null;
    var f;
    try { f = understand(q, ctx, null); } catch (e) { return null; }
    return f ? toolOf(f, ctx) : null;
  }
  function toolOf(f, ctx) {
    var today = ctx.today, thisM = { from: today.slice(0, 8) + '01', to: today };
    var keep = function (o) { var x = {}; Object.keys(o).forEach(function (k) { if (o[k] !== undefined && o[k] !== '' && o[k] !== null) x[k] = o[k]; }); return x; };
    var span = function (dflt) { return f.named ? { from: f.from, to: f.to } : dflt || {}; };
    var who = f.person ? (f.person === 'me' ? 'me' : f.person) : undefined;
    var payee = f.merchants && f.merchants.length > 1 ? f.merchants : f.merchant;
    var subj = function (o) { return keep(Object.assign(o, { category: f.category, merchant: payee, card: f.card, person: who })); };
    var BY = { category: 'category', payee: 'merchant', card: 'card', person: 'person', month: 'month' };
    switch (f.act) {
      case 'total': case 'pace': return { tool: 'spending', args: subj(span(thisM)) };
      case 'rank':
        if (!BY[f.by]) return null;
        return { tool: 'breakdown', args: keep(Object.assign(span(f.by === 'month' ? { from: addDays(today, -364), to: today } : thisM), { by: BY[f.by], category: f.by !== 'category' ? f.category : undefined, top: f.n })) };
      case 'biggest': return { tool: 'transactions', args: keep(Object.assign(span(thisM), { dir: f.dir === 'in' ? 'in' : 'out', category: f.category, merchant: payee, card: f.card, sort: 'amount', limit: f.n || 10 })) };
      case 'last': return { tool: 'transactions', args: keep(Object.assign(span(), { dir: /\b(?:received|credited|came|got|salary|refund|income)\b/.test(norm(f.q || '')) ? 'in' : 'out', category: f.category, merchant: payee, card: f.card, sort: 'date', limit: 10 })) };
      case 'count': case 'list': return { tool: 'transactions', args: keep(Object.assign(span(f.act === 'list' && hasSubject(f) ? { from: addDays(today, -89), to: today } : thisM), { dir: 'out', category: f.category, merchant: payee, card: f.card, min: f.min, max: f.max, sort: f.sort === 'amount' ? 'amount' : 'date', limit: f.n || 25 })) };
      case 'avg': return { tool: 'trend', args: keep({ months: 6, what: 'spending', category: f.category, merchant: payee, person: who }) };
      case 'compare':
        if (f.merchant2) return null;
        var against = secondMonth(norm(f.q || ''), today);
        return { tool: 'compare', args: keep(Object.assign(span(), { category: f.category, person: who, person2: f.person2 }, against ? { from2: against.from, to2: against.to } : {})) };
      case 'trend': {
        var nm = /\b(?:last|past) (\d+|two|three|four|six|nine|twelve) months\b/.exec(norm(f.q || ''));
        var cnt = nm ? (/^\d+$/.test(nm[1]) ? +nm[1] : { two: 2, three: 3, four: 4, six: 6, nine: 9, twelve: 12 }[nm[1]]) : 6;
        return { tool: 'trend', args: keep({ months: cnt, what: f.what === 'income' ? 'income' : 'spending', category: f.category, merchant: payee, person: who }) };
      }
      case 'due': return { tool: 'upcoming', args: { days: Math.max(1, daysBetween(today, dueWindow(f, today).to)) } };
      case 'carddue': return { tool: 'upcoming', args: { days: 45 } };
      case 'cover': return { tool: 'cover', args: { days: Math.max(1, daysBetween(today, (f.ahead && f.ahead.to) || addDays(today, 7))) } };
      case 'income': return { tool: 'income', args: span(thisM) };
      case 'invested': return { tool: 'trend', args: { months: 12, what: 'invest' } };
      case 'balances': case 'repeats': case 'insurance': case 'noticed': return { tool: f.act, args: {} };
      case 'price': case 'rise': case 'subcancel': return { tool: 'repeats', args: {} };
      case 'wealth': case 'owed': return { tool: f.act, args: keep({ person: f.act === 'owed' ? payee : who }) };
      case 'tax': return { tool: 'spending', args: keep(Object.assign(span({ from: (+today.slice(5, 7) >= 4 ? +today.slice(0, 4) : +today.slice(0, 4) - 1) + '-04-01', to: today }), { category: 'Tax', merchant: f.kind === 'gst' ? 'gst' : undefined })) };
      case 'remit': return { tool: 'income', args: span({ from: today.slice(0, 4) + '-01-01', to: today }) };
      case 'sent': return { tool: 'transactions', args: keep(Object.assign(span({ from: addDays(today, -364), to: today }), { merchant: ((ctx.people || []).filter(function (p) { return p.name === f.person; })[0] || {}).full || f.person, sort: 'date', limit: 25 })) };
      case 'tool': return { tool: f.tool, args: f.args || {} };
      case 'decide': return { tool: 'decide', args: Object.assign({ kind: f.kind }, f.args || {}) };
      case 'emi': return { tool: 'whatif', args: { kind: 'emi', principal: f.principal, rate: f.rate, months: f.months } };
    }
    return null;
  }
  /* Passwords to try on a locked statement when its email doesn't say how the password is made (or the rule
     didn't open it): what Indian banks, card issuers, depositories, brokers, the tax department and insurers
     commonly use, made from the details the user saved and the card or account digits kosh has seen from that
     sender. The sender's known habit goes first. Tried on the phone, against the user's own file; nothing is sent. */
  /* Each candidate comes with the id of its format (formats[i] for candidates[i]: "n4dm" is the first four letters of
     the name in capitals and the day and month of birth), so the phone can remember the one that opened a sender's
     statement and try it first next time (ctx.learnt). Order: the learnt format, then the sender's known habit, then
     the details the sender's own mail printed (its Customer ID or CRN, the policy, the PRAN, the client ID: the
     profile's facts), then the common formats. */
  var PW_FORMATS = {
    n4dm: 'NAME + DDMM', n4dm_l: 'name + DDMM', n4dm_c: 'Name + DDMM', n4_d8: 'NAME + DDMMYYYY', n4_d8_l: 'name + DDMMYYYY',
    n4_l4: 'NAME + last 4 digits', n4_l4_l: 'name + last 4 digits', n4_m4: 'NAME + mobile last 4',
    pan: 'PAN', pan_l: 'pan', pan_l_d8: 'pan + DDMMYYYY', pan_d8: 'PAN + DDMMYYYY', pan_dm: 'PAN + DDMM',
    d8: 'DDMMYYYY', d6: 'DDMMYY', d8_l4: 'DDMMYYYY + last 4 digits', d6_l6: 'DDMMYY + last 6 digits', d4_l4: 'DDMM + last 4 digits', l4_d4: 'last 4 digits + DDMM',
    m5d6: 'mobile last 5 + DDMMYY', mob: 'mobile number', n4_pin: 'NAME + PIN code',
    cid: 'Customer ID', crn: 'CRN', cif: 'CIF', ucic: 'UCIC', cid_dm: 'Customer ID + DDMM', policy: 'policy number', policy_d8: 'policy number + DDMMYYYY',
    pran: 'PRAN', client: 'client ID', client_pan: 'client ID + PAN', acct_full: 'account number', loan: 'loan account number', folio: 'folio number'
  };
  function pwGuess(profile, ctx) {
    var P = pwWithOwn(profile), C = ctx || {}, out = [], fmt = [];
    function push(x, f) { x = String(x || ''); if (x.length >= 4 && out.indexOf(x) < 0) { out.push(x); fmt.push(f); } }
    var nm = String(P.name || '').replace(/[^A-Za-z ]/g, ' ').trim(), first = nm.split(/\s+/)[0] || '', letters = nm.replace(/\s+/g, '');
    var n4 = [];
    [first.length >= 4 ? first.slice(0, 4) : '', letters.slice(0, 4)].forEach(function (x) { if (x.length === 4 && n4.indexOf(x.toLowerCase()) < 0) n4.push(x.toLowerCase()); });
    var dob = /^(\d{4})-(\d{2})-(\d{2})$/.exec(P.dob || '');
    var d8 = dob ? dob[3] + dob[2] + dob[1] : '', d6 = dob ? dob[3] + dob[2] + dob[1].slice(2) : '', d4 = dob ? dob[3] + dob[2] : '';
    var pan = String(P.pan || '').toUpperCase();
    if (!/^[A-Z]{5}\d{4}[A-Z]$/.test(pan)) pan = '';
    var mob = String(P.mobile || '').replace(/\D/g, '').slice(-10);
    if (mob.length !== 10) mob = '';
    var pin = /^\d{6}$/.test(P.pin || '') ? P.pin : '';
    // the card and account digits: those kosh has seen from the sender, and those its mail printed for this person
    var digits = [], long6 = [];
    (C.digits || []).concat(C.last4 ? [C.last4] : []).concat(pwFactOf(P, C, ['cardNo', 'accountNo'], true)).forEach(function (g0) {
      var g = String(g0 || '').replace(/\D/g, '');
      if (g.length >= 6 && long6.indexOf(g.slice(-6)) < 0) long6.push(g.slice(-6));
      g = g.slice(-4);
      if (g.length === 4 && digits.indexOf(g) < 0) digits.push(g);
    });
    digits = digits.slice(0, 4); long6 = long6.slice(0, 2);
    var dom = String(C.domain || '').toLowerCase(), cid = pwIdFor(P, C);
    var ids = function (kinds) { return pwFactOf(P, C, kinds).slice(0, 2); };
    var crn = ids(['crn']), cif = ids(['cif']), ucic = ids(['ucic']), cust = ids(['customerId', 'relationshipNo']);
    var pol = ids(['policyNo']), pran = ids(['pran']), client = ids(['clientId']), acct = ids(['accountNo']), loan = ids(['loanAccount']), folio = ids(['folio']);
    // every format this person's details can make, by id, in the common order
    var all = [];
    function f(id, v) { if (v) all.push([id, v]); }
    n4.forEach(function (n) { if (d4) { f('n4dm', n.toUpperCase() + d4); f('n4dm_l', n + d4); } });
    f('pan', pan); f('pan_l', pan.toLowerCase());
    f('d8', d8); f('d6', d6);
    digits.forEach(function (g) { if (d8) f('d8_l4', d8 + g); });
    if (pan && d8) { f('pan_l_d8', pan.toLowerCase() + d8); f('pan_d8', pan + d8); }
    if (mob && d6) f('m5d6', mob.slice(-5) + d6);
    long6.forEach(function (g) { if (d6) f('d6_l6', d6 + g); });
    n4.forEach(function (n) {
      var cap = n.charAt(0).toUpperCase() + n.slice(1);
      if (d4) f('n4dm_c', cap + d4);
      if (d8) { f('n4_d8', n.toUpperCase() + d8); f('n4_d8_l', n + d8); }
      digits.forEach(function (g) { f('n4_l4', n.toUpperCase() + g); f('n4_l4_l', n + g); });
      if (mob) f('n4_m4', n.toUpperCase() + mob.slice(-4));
      if (pin) f('n4_pin', n.toUpperCase() + pin);
    });
    digits.forEach(function (g) { if (d4) { f('d4_l4', d4 + g); f('l4_d4', g + d4); } });
    if (pan && d4) f('pan_dm', pan + d4);
    f('mob', mob);
    // (the IDs the sender printed, as the sender's own formats: they open its papers far more often than a guess)
    var own = [];
    function o(id, v) { if (v) own.push([id, v]); }
    if (cid) o('cid', cid);
    crn.forEach(function (v) { o('crn', v); }); cust.forEach(function (v) { o('cid', v); }); cif.forEach(function (v) { o('cif', v); }); ucic.forEach(function (v) { o('ucic', v); });
    if (cid && d4) o('cid_dm', cid + d4);
    pol.forEach(function (v) { o('policy', v); if (d8) o('policy_d8', v + d8); });
    pran.forEach(function (v) { o('pran', v); });
    client.forEach(function (v) { o('client', v); if (pan) o('client_pan', v + pan); });
    loan.forEach(function (v) { o('loan', v); });
    acct.forEach(function (v) { o('acct_full', v); });
    folio.forEach(function (v) { o('folio', v); });
    var byId = function (id) { return all.concat(own).filter(function (x) { return x[0] === id; }); };
    // 1. the format that opened this sender's statements before
    if (C.learnt) byId(String(C.learnt)).forEach(function (x) { push(x[1], x[0]); });
    // 2. the sender's own habit
    var habit = [];
    if (/sbicard/.test(dom)) habit = ['d8_l4'];
    else if (/nsdl|cdsl|camsonline|kfintech|karvy|mfcentral/.test(dom)) habit = ['pan'];
    else if (/zerodha|groww|upstox|angelone|angelbroking|5paisa|dhan|icicidirect|hdfcsec|kotaksecurities|sharekhan|motilal|paytmmoney|nse|bse/.test(dom)) habit = ['pan', 'client', 'client_pan'];
    else if (/npscra|nps-?trust|cra-?nsdl|kfintech-?nps|pfrda/.test(dom)) habit = ['pran', 'pan'];
    else if (/incometax|tdscpc|traces/.test(dom)) habit = ['pan_l_d8'];
    else if (/(^|\.)sbi\.|onlinesbi/.test(dom)) habit = ['m5d6'];
    else if (/hdfcbank/.test(dom)) habit = ['cid'];
    else if (/kotak/.test(dom)) habit = ['crn', 'cid'];
    else if (/icicibank/.test(dom)) habit = ['n4dm_l'];
    else if (/hsbc/.test(dom)) habit = ['d6_l6'];
    else if (/lic|life|insur|allianz|ergo|bajaj|health|tataaig|godigit|acko/.test(dom)) habit = ['d8', 'policy', 'policy_d8'];
    habit.forEach(function (id) { byId(id).forEach(function (x) { push(x[1], x[0]); }); });
    // 3. what the sender printed, 4. the common formats
    own.forEach(function (x) { push(x[1], x[0]); });
    all.forEach(function (x) { push(x[1], x[0]); });
    return { candidates: out.slice(0, 30), formats: fmt.slice(0, 30) };
  }

  /* One ranked list of passwords to try on a locked statement, for the whole household, the way Swift tries them:
     the sender's own rule first (for each person, the paper's likely holder leading the list), then the formats
     issuers commonly use (for each person). Deduped and capped. Pure code, tried on the phone: nothing is sent,
     no password is logged. `profiles` is one person's details or an array of the household's (likely holder first). */
  function pwCandidates(hint, profiles, ctx, cap) {
    profiles = Array.isArray(profiles) ? profiles : (profiles ? [profiles] : []);
    cap = cap > 0 ? cap : 60;
    var out = [], fmt = [], seen = {};
    function add(c, f) { c = String(c || ''); if (c.length >= 4 && !seen[c] && out.length < cap) { seen[c] = 1; out.push(c); fmt.push(f || ''); } }
    if (hint) profiles.forEach(function (p) { var b = pwBuild(hint, p, ctx); if (b.ok) b.candidates.forEach(function (c) { add(c, 'hint'); }); });
    profiles.forEach(function (p) { var g = pwGuess(p, ctx); g.candidates.forEach(function (c, i) { add(c, g.formats[i]); }); });
    return { candidates: out, formats: fmt };
  }

  /* ================================================================ answering on the phone, on its own
     Without Claude, and on phones without Apple's model, kosh still answers in plain words. It reads a question
     for what it asks (a total, who or what came top, the biggest payment, the last time, how often, an average,
     a comparison, a trend, what's due, balances, what came in, what was kept...) and for what it names (a
     period, a category, a payee, a card, a person in the household, how it was paid, an amount), works the
     answer out from the ledger, and says it. A short follow-up ("and last month?", "show them", "why?", "by
     category") carries on from the question before. A question it can't place gets one short line and a few
     questions near it to tap, never the same paragraph twice. */

  /* A question asked in an Indian script, or typed in English letters the way Tamil, Malayalam and Bengali speakers
     type ("ee maasam ethra chilavayi?", "last month koto khoroch holo?", "இந்த மாதம் எவ்வளவு செலவு?"): its words
     put in the English the router reads, as Hinglish is below. Whole phrases first (the month, the year), then the
     words; a script word may carry its ending ("செலவழித்தேன்", "ചെലവായി"). The script's own digits read as 0-9. */
  var IW_ = '[\\p{L}\\p{M}]*';
  function SW(src, to) { return [new RegExp('(?<![\\p{L}\\p{M}])(?:' + src + ')(?![\\p{L}\\p{M}])', 'gu'), ' ' + to + ' ']; }
  var SCRIPT_SWAP = [
    // this month, last month, next month; this year, last year
    SW('இந்த\\s+(?:மாதம்|மாசம்)|ഈ\\s+മാസ' + IW_ + '|এই\\s+মাস' + IW_ + '|এ\\s+মাস' + IW_ + '|इस\\s+महीने|इस\\s+माह|ఈ\\s+నెల' + IW_ + '|ಈ\\s+ತಿಂಗಳ' + IW_ + '|આ\\s+મહિને', 'this month'),
    SW('(?:கடந்த|போன|சென்ற)\\s+(?:மாதம்|மாசம்)|കഴിഞ്ഞ\\s+മാസ' + IW_ + '|(?:গত|আগের)\\s+মাস' + IW_ + '|(?:पिछले|पिछला|गत)\\s+(?:महीने|माह)|గత\\s+నెల' + IW_ + '|ಕಳೆದ\\s+ತಿಂಗಳ' + IW_ + '|ગયા\\s+મહિને', 'last month'),
    SW('அடுத்த\\s+(?:மாதம்|மாசம்)|അടുത്ത\\s+മാസ' + IW_ + '|(?:পরের|আগামী)\\s+মাস' + IW_ + '|अगले\\s+(?:महीने|माह)|వచ్చే\\s+నెల' + IW_ + '|ಮುಂದಿನ\\s+ತಿಂಗಳ' + IW_, 'next month'),
    SW('இந்த\\s+(?:வருடம்|ஆண்டு|வருஷம்)|ഈ\\s+(?:വർഷ|കൊല്ല)' + IW_ + '|এই\\s+বছর' + IW_ + '|इस\\s+(?:साल|वर्ष)|ఈ\\s+సంవత్సర' + IW_ + '|ಈ\\s+ವರ್ಷ' + IW_, 'this year'),
    SW('(?:கடந்த|போன)\\s+(?:வருடம்|ஆண்டு|வருஷம்)|കഴിഞ്ഞ\\s+(?:വർഷ|കൊല്ല)' + IW_ + '|গত\\s+বছর' + IW_ + '|(?:पिछले|गत)\\s+(?:साल|वर्ष)|గత\\s+సంవత్సర' + IW_ + '|ಕಳೆದ\\s+ವರ್ಷ' + IW_, 'last year'),
    SW('நிகர\\s+(?:சொத்து\\s+)?மதிப்பு|ആകെ\\s+ആസ്തി|നെറ്റ്\\s+വർത്ത്|নেট\\s+ওয়ার্থ|মোট\\s+সম্পদ|नेट\\s+वर्थ|कुल\\s+संपत्ति', 'net worth'),
    // how much, how many, when, what
    SW('எவ்வளவு|எத்தனை\\s+ரூபாய்|എത്ര|কত|কতো|कितना|कितने|कितनी|ఎంత|ಎಷ್ಟು|કેટલા|કેટલું', 'how much'),
    SW('எத்தனை|എത്ര\\s+തവണ|কতবার|कितनी\\s+बार', 'how many'),
    SW('எப்போது|எப்பொழுது|എപ്പോൾ|কবে|कब|ఎప్పుడు|ಯಾವಾಗ|ક્યારે', 'when'),
    SW('என்ன|എന്ത്|এখন\\s+কী|কী|কি|क्या|ఏమిటి|ಏನು|શું', 'what'),
    // spent, sent, came, paid
    SW('செலவ' + IW_ + '|ചെലവ' + IW_ + '|ചിലവ' + IW_ + '|খরচ' + IW_ + '|खर्च' + IW_ + '|ఖర్చు' + IW_ + '|ಖರ್ಚು' + IW_ + '|ખર્ચ' + IW_, 'spent'),
    SW('அனுப்ப' + IW_ + '|അയച്ച' + IW_ + '|পাঠিয়ে' + IW_ + '|পাঠাল' + IW_ + '|भेज' + IW_, 'sent'),
    SW('வந்த' + IW_ + '|വന്ന' + IW_ + '|এসেছে|এল|এলো|आया|आई|आए', 'came'),
    SW('கட்டின' + IW_ + '|செலுத்த' + IW_ + '|അടച്ച' + IW_ + '|দিয়েছি|জমা\\s+দিয়েছি|भरा|भरे|चुकाया', 'paid'),
    // the money's own words
    SW('இருப்பு|ബാലൻസ്' + IW_ + '|ব্যালেন্স|ব্যালান্স|बैलेंस|शेष', 'balance'),
    SW('சம்பள' + IW_ + '|ശമ്പള' + IW_ + '|বেতন|মাইনে|सैलरी|वेतन|तनख्वाह|జీతం|ಸಂಬಳ|પગાર', 'salary'),
    SW('வருமான' + IW_ + '|വരുമാന' + IW_ + '|আয়|उत्पन्न|आय|कमाई|ఆదాయం|ಆದಾಯ|આવક', 'income'),
    SW('பில்' + IW_ + '|ബിൽ' + IW_ + '|বিল|बिल', 'bill'),
    SW('கடன்' + IW_ + '|വായ്പ' + IW_ + '|ലോൺ' + IW_ + '|ঋণ|লোন|कर्ज|लोन', 'loan'),
    SW('காப்பீ' + IW_ + '|ഇൻഷുറൻസ്' + IW_ + '|বিমা|बीमा', 'insurance'),
    SW('கணக்க' + IW_ + '|கணக்கு|അക്ക(?:ൗ|ൌ)ണ്ട' + IW_ + '|অ্যাকাউন্ট' + IW_ + '|खात' + IW_, 'account'),
    SW('வங்கி' + IW_ + '|ബാങ്ക്' + IW_ + '|ব্যাংক' + IW_ + '|ব্যাঙ্ক' + IW_ + '|बैंक', 'bank'),
    SW('பணம்|പണം|টাকা|पैसा|पैसे', 'money'),
    SW('என்\\s|என்னுடைய|எனது|എന്റെ|আমার|मेरा|मेरे|मेरी', 'my'),
    SW('எங்கள்' + IW_ + '|ഞങ്ങളുടെ|আমাদের|हमारा|हमारी|हमारे', 'our'),
  ];
  var LATIN_SWAP = [
    // Tamil, Malayalam and Bengali typed in English letters: whole phrases, then words
    [/\b(?:indha|intha|inda|inthe) (?:maasam|masam|maasathula|masathula)\b|\bee (?:maasam|masam|masathil|maasathil)\b|\b(?:ei|e) (?:mashe|mase|masher|maase|mas)\b/g, 'this month'],
    [/\b(?:pona|poina|kadantha|kadandha|pochu) (?:maasam|masam|maasathula|masathula)\b|\bkazhinj?h?a (?:maasam|masam|masathil|maasathil)\b|\b(?:gato|goto|gata|ager|aager) (?:mashe|mase|masher|maase|mas)\b/g, 'last month'],
    [/\badutha (?:maasam|masam)\b|\b(?:porer|samner) (?:mashe|mase|mas)\b/g, 'next month'],
    [/\b(?:indha|intha) (?:varusham|varsham|varudam)\b|\bee (?:varsham|kollam)\b|\bei (?:bochhor|bochor|bochhore|bochore|bachhar|bachar)\b/g, 'this year'],
    [/\b(?:pona|kadantha) (?:varusham|varsham|varudam)\b|\bkazhinj?h?a (?:varsham|kollam)\b|\b(?:gato|goto) (?:bochhor|bochor|bachhar)\b/g, 'last year'],
    [/\b(?:evvalavu|evalavu|evlo|evlavu|evvlo|yevlo|ethra|etra|ethre|koto|kotto)\b/g, 'how much'],
    [/\b(?:eppo|eppol|eppozhu|kokhon)\b/g, 'when'],
    // ("kobe" is Bengali for when, and a restaurant's name too: only where a question asks when)
    [/\bkobe(?= (?:due|ashbe|asbe|ache|hobe|debo|dite|pay)\b| $)/g, 'when'],
    [/\b(?:selavu|chelavu|selavaachu|selavachu|selavu aachu|chilavayi|chelavayi|chilavu|chilavaayi|chelavaayi|khoroch|khorocha|khorch|khoroc)\b(?: (?:holo|hoyeche|hoyechhe|aachu|achu|aayi))?/g, 'spent'],
    [/\b(?:sambalam|shambalam)\b/g, 'salary'], [/\b(?:varumanam|ayam|aay)\b/g, 'income'],
    [/\b(?:ayachu|ayache|anuppinen|anuppunen|anupchen|pathiyechi|pathalam|pathiyecho)\b/g, 'sent'],
    [/\b(?:adachu|adacha|kattinen|kattunen|dilam|diyechi)\b/g, 'paid'], [/\badakkanam\b|\bkattanum\b/g, 'is due'],
    [/\b(?:vandhuchu|vanthuchu|vandhadhu|vanthathu|vandhurukku|vannu|vannath|elo|eshechhe|esechhe|eshechhe)\b/g, 'came'],
    [/\b(?:baaki irukku|baaki iruku|baaki und|baaki undu|baki ache|baaki ache)\b/g, 'pending'],
    [/\btaka\b|\bpanam\b/g, 'money'], [/\btheke\b|\blirundhu\b/g, 'from'],
    [/\b(?:ente|ennoda|ennudaya)\b/g, 'my'],
    // ("amar" is Bengali for my, and a name too: only before what a person has)
    [/\bamar (?=(?:net worth|balance|salary|account|income|loan|card|bill|bank|savings|spending|investments?)\b)/g, 'my '], [/\b(?:engal|engaloda|amader)\b/g, 'our'],
    [/\b(?:enna|entha|enthu)\b/g, 'what'],
    // the endings of a name or a word typed on with a hyphen ("Meena-oda", "account-il", "Bank-e"): the word itself
    [/([a-z0-9])-(?:oda|ode|il|ile|ilu|e|er|te|ke|kku|ku|la|le)\b/g, '$1'],
    [/\b(?:irukku|iruku|irukka|und|undu|ache|achhe|aache|holo|hoyeche|hoyechhe|aachu|achu|ayirunnu|ithuvare)\b/g, ' '],
  ];
  function scriptQ(s) {
    // the script's own digits as 0-9 (as the mail's gloss reads them, engine.js indCanon)
    s = s.replace(/[\u0966-\u096F\u09E6-\u09EF\u0A66-\u0A6F\u0AE6-\u0AEF\u0B66-\u0B6F\u0BE6-\u0BEF\u0C66-\u0C6F\u0CE6-\u0CEF\u0D66-\u0D6F]/g, function (c) { return String((c.charCodeAt(0) & 0x7F) - 0x66); });
    if (/[\u0900-\u0D7F]/.test(s)) {
      s = s.replace(/[\u09DC\u09DD\u09DF]/g, function (c) { return { '\u09DC': '\u09A1', '\u09DD': '\u09A2', '\u09DF': '\u09AF' }[c] + '\u09BC'; }).replace(/\u0D46\u0D57|\u0D4C/g, '\u0D57');
      SCRIPT_SWAP.forEach(function (w) { s = s.replace(w[0], w[1]); });
      // (the words of a question it doesn't know, in a script, are no payee's name)
      s = s.replace(/(?<![\p{L}\p{M}])[\u0900-\u0D7F]+(?![\p{L}\p{M}])/gu, ' ');
    }
    LATIN_SWAP.forEach(function (w) { s = s.replace(w[0], w[1]); });
    return s;
  }
  var PAST_HI = '(?:hua|hui|hue|gaya|gayi|gaye|tha|thi|kiya|kiye|laga|lagi|lage|diya|diye|kata|kati|aaya|aayi|mila|mili|spent|paid|did|was)';
  var SWAP = [
    // Hinglish: whole phrases first, then the words in them
    [/\bmere (?:paas|pas) (?:kitne|kitna) (?:paise|paisa) (?:hai|hain)\b|\b(?:kitne|kitna) (?:paise|paisa) (?:hai|hain) mere (?:paas|pas)\b/g, 'how much money do i have'],
    [/\b(?:mera |hamara |humara |sara )?(?:paisa|paise) (?:kahan|kahaan|kidhar) (?:ja raha|ja rha|jaa raha|jata|jaata|ja rahe|ja rahi|gaya)(?: hai| hain)?\b/g, 'where is my money going'],
    [/\bsabse (?:bada|badi|bade|bara|bari|bare) (?:kharcha|kharch|payment|expense)\b/g, 'biggest expense'],
    [/\bsabse (?:zyada|jyada|jada|zada) (?:kharcha|kharch) kis (?:pe|par|cheez pe|cheez par)\b|\bsabse (?:zyada|jyada|jada|zada) kis (?:pe|par) (?:kharcha|kharch)\b/g, 'what did i spend the most on'],
    [/\bpic?hh?l[ae] mahine se (?:zyada|jyada|jada|kam)\b/g, 'compared with last month'],
    // "light bill", "bijli ka bill": the electricity bill; a bill that "aaya" came as a bill (its amount), not money in
    [/\blight bill\b|\bbijli (?:ka |ki )?bill\b|\bbijli\b/g, 'electricity bill'],
    // a jewel loan is a gold loan (a loan against jewellery, as South Indian banks name it)
    [/\bjewell?(?:ery|lery)? loans?\b/g, 'gold loan'],
    [/\b(bills?)\b((?: [a-z]+){0,3}?) (?:aaya|aayi|aaye|aya|ayi)\b/g, '$1$2 is'],
    [/\bkitn[ie] (?:baar|bar|dafa)\b|\bkitne (?:baar|bar|dafa)\b|\bkitne hue\b/g, 'how many times'],
    [/\b(?:last )?kab (?:kata|kati|kate|gaya|gayi|bhara|bhari|diya)\b/g, 'when was the last payment'],
    [/\bkab tak\b/g, 'by when'], [/\bpoo?ra (?:hoga|hogi|ho jayega)\b/g, 'be reached'], [/\bmil(?:ega|egi|enge)\b/g, 'will i get'],
    // "kal" is yesterday said of what happened, tomorrow said of what's coming; "parso" the day before or after
    [new RegExp('\\bkal\\b(?=.*\\b' + PAST_HI + '\\b)', 'g'), 'yesterday'], [/\bkal\b/g, 'tomorrow'],
    [new RegExp('\\bpar(?:so|son)\\b(?=.*\\b' + PAST_HI + '\\b)', 'g'), 'day before yesterday'], [/\bpar(?:so|son)\b/g, 'day after tomorrow'],
    [/\biss? hafte\b/g, 'this week'], [/\bpic?hh?l[ae] hafte\b/g, 'last week'], [/\bagl[ae] hafte\b/g, 'next week'],
    [/\biss? saal\b/g, 'this year'], [/\bpic?hh?l[ae] saal\b/g, 'last year'], [/\bagl[ae] saal\b/g, 'next year'],
    [/\biss? mahine\b/g, 'this month'], [/\bpic?hh?l[ae] mahine\b/g, 'last month'], [/\bagl[ae] mahine\b/g, 'next month'],
    [/\bnahi?n? (?:diya|di|diye|bhara|bhari|aaya|aayi)\b/g, 'did not pay'], [/\bkira+y[ae]\b/g, 'rent'], [/\bkhaa?n[ae]\b/g, 'food'],
    [/\bbadh (?:gaya|gayi|gaye|raha|rahi)\b|\bbadh[aie]\b/g, 'went up'], [/\bl(?:eta|eti|ete) (?:hai|hain)\b/g, 'charges'],
    [/\bbharn[aei]\b/g, 'to pay'], [/\bbaa?ki\b/g, 'pending'], [/\bbach[aei]\b|\bbachat\b/g, 'saved'],
    // "aai" is Mother (Marathi) when it names someone ("Aai ko", "Aai's", "sent Aai"), else it came ("salary aai")
    [/\baai\b/g, function (m, at, str) { return /\b(?:my|to|sent|send|paid|pay|for|meri|mere|apni|apne|and|aur|with)\s$/.test(str.slice(Math.max(0, at - 8), at)) || /^(?:'s)?\s(?:ko|ne|ka|ki|ke|se|mein|me|par|pe|and|aur)\b/.test(str.slice(at + 3, at + 12)) ? m : 'came'; }],
    [/\bbyaa?j\b|\bsood\b/g, 'interest'], [/\baa?t[aie] (?:hai|hain)\b/g, 'comes'],
    [/\bbhej(?:a|i|e|na|ti|ta|te|diya|di)\b/g, 'sent'], [/\bbhar(?:a|i|e)\b/g, 'paid'], [/\bbijli\b/g, 'electricity'], [/\biss? baa?r\b/g, 'this time'],
    [/\b(?:aaya|aayi|aaye|mila|mili|mile)\b/g, 'came'], [/\bjaa?t[aie] (?:hai|hain)\b|\bkat(?:ta|ti|te) (?:hai|hain)\b/g, 'goes every month'],
    [/\b(?:gaya|gayi|gaye|laga|lagi|lage)\b/g, 'went'], [/\bkis (?:pe|par)\b/g, 'on what'], [/\bse (?:zyada|jyada|jada)\b/g, 'more than'], [/\bse kam\b/g, 'less than'],
    [/\bcard k[ae] bill\b/g, 'card bill'], [/\b(?:le|kharid) sakt[aei](?: hoon| hu| hain| hai)?\b/g, 'can i buy'],
    [/\bkahaa?n\b|\bkidhar\b/g, 'where'], [/\bkaun ?s[aei]\b/g, 'which'], [/\bkya kya\b/g, 'what'], [/\b(?:diya|diye)\b/g, 'paid'],
    [/\bkitn[aei]\b/g, 'how much'], [/\bhow much (?:hai|hain|he)\b/g, 'how much is'], [/\bkharch[ae]?\b|\bkharcha\b/g, 'spent'], [/\bkab\b/g, 'when'], [/\bkis(?:ko|e|ne)\b/g, 'who'],
    [/\bsabse (?:zyada|jyada|jada|zada)\b/g, 'the most'], [/\bpais[ae]\b/g, 'money'], [/\baaj\b/g, 'today'],
    [/\b(?:spnd|spned|spedn|sepnd|spemd)\b/g, 'spend'], [/\b(?:spnt|spnet|spendt|sepnt)\b/g, 'spent'], [/\b(?:moeny|mony|monye|mney)\b/g, 'money'],
    [/\b(?:mnth|monht|mont)\b/g, 'month'], [/\b(?:payed|paied)\b/g, 'paid'], [/\bwhom\b/g, 'who'], [/\bu\b/g, 'you'], [/\bur\b/g, 'your'],
    [/\bi've\b/g, 'i have'], [/\bi'm\b|\bim\b/g, 'i am'], [/\bwhat's\b|\bwhats\b/g, 'what is'], [/\bwho's\b/g, 'who is'], [/\bwhere's\b/g, 'where is'],
    [/\bdidn't\b|\bdidnt\b/g, 'did not'], [/\bhaven't\b|\bhavent\b/g, 'have not'], [/\bhasn't\b|\bhasnt\b/g, 'has not'], [/\bisn't\b|\bisnt\b/g, 'is not'],
    [/\bcan't\b|\bcant\b/g, 'can not'], [/\bdon't\b|\bdont\b/g, 'do not'],
    [/\btxns?\b|\btransactions?\b|\btrxns?\b|\btrans\b/g, 'payments'], [/\bpls\b|\bplease\b|\bplz\b|\bkindly\b/g, ' '],
    [/\b(?:rs|inr|rupees?)\s*(?=\d)/g, '₹'],
    [/(\d+(?:\.\d+)?)\s*k\b/g, function (m, n) { return String(Math.round(+n * 1000)); }],
    [/(\d+(?:\.\d+)?)\s*(?:cr|crore|crores)\b/g, function (m, n) { return String(Math.round(+n * 1e7)); }],
    [/(\d+(?:\.\d+)?)\s*(?:l|lakh|lakhs|lac|lacs)\b/g, function (m, n) { return String(Math.round(+n * 100000)); }],
  ];
  function norm(q) {
    var s = lc(q).replace(/[’‘`´]/g, "'").replace(/(\d),(?=\d)/g, '$1').replace(/₹\s*/g, ' ₹').replace(/(\d)\.(\d)/g, '$1§$2');
    s = ' ' + s.replace(/[?!.,;:()"“”\u0964\u0965]/g, ' ').replace(/§/g, '.').replace(/\s+/g, ' ').trim() + ' ';
    s = scriptQ(s);
    SWAP.forEach(function (w) { s = s.replace(w[0], w[1]); });
    return ' ' + s.replace(/\s+/g, ' ').trim() + ' ';
  }
  // words that are never a payee's name, however a payee happens to be called
  var STOP = {};
  ('a an the i me my we us our you your it its is are was were be been am do does did done have has had will would can could should shall may might ' +
   'what when where which who why how much many most more less least top bottom biggest largest smallest highest lowest big large small high low ' +
   'and or but so to on at in of for from with by about into than then also just only same all any each every some other others both ' +
   'this that these those last next past previous recent recently latest first second today yesterday tomorrow day days week weeks month months year years ' +
   'spend spent spending spends paid pay pays paying payment payments money cost costs costing bought buy buying order ordered orders purchase purchases ' +
   'total sum amount amounts times time often usual usually average avg normal typical daily weekly monthly yearly per show list tell give see let know ' +
   'expense expenses bill bills due upcoming coming go went goes going get got gets getting send sent transfer transferred received receive came come ' +
   'category categories merchant merchants shop shops store stores place places payee payees people person compare compared versus trend breakdown split ' +
   'card cards account accounts upi cash wallet wallets bank banks salary income save saved saving savings budget left over under above below ' +
   'not no yes ok okay please thanks thank hi hello hey there here again more one two three four five ten twenty hundred thousand lakh crore ' +
   'kosh claude app phone mean meant tell explain help say said ask asked question answer things thing stuff something anything everything').split(' ').forEach(function (w) { if (w) STOP[w] = 1; });

  function payeeIndex(ctx) {
    if (ctx.__payees) return ctx.__payees;
    var count = {}, shown = {}, person = {};
    (ctx.tx || []).forEach(function (t) {
      if (t.k === 'move' || t.k === 'cardpay') return;
      var m = lc(t.m).replace(/\s+/g, ' ').trim();
      if (m.length < 3) return;
      count[m] = (count[m] || 0) + 1;
      if (!shown[m]) shown[m] = t.m;
      if (t.u || /^(?:money out|transfers?|family|friends)$/i.test(t.c || '') || t.s === 'Domestic help') person[m] = (person[m] || 0) + 1;
    });
    var list = Object.keys(count).sort(function (a, b) { return b.length - a.length || count[b] - count[a]; });
    ctx.__payees = { list: list, count: count, shown: shown, person: person };
    return ctx.__payees;
  }
  /* the payee a question names: a whole name the ledger knows, else a word that is a whole word of one ("swiggy"
     for "Swiggy Instamart", "rohan" for "Rohan Kumar") */
  /* every payee the question names, where it's said: a whole name the ledger knows, else words of one ("swiggy" for
     "Swiggy Instamart", "example bistro" for "Example Bistro Restaurant", "ola" for "Ola Cabs"). A word half the
     ledger's payees share ("example", "india") is a last resort, never a pick over a word that names one or two. */
  function payeeHits(s, ctx) {
    if (ctx.__hits && ctx.__hits.s === s) return ctx.__hits.out;
    var ix = payeeIndex(ctx), whole = [], taken = [];
    ix.list.forEach(function (m) {
      if (m.length < 4) return;
      var at = s.indexOf(' ' + m + ' ');
      if (at >= 0 && !taken.some(function (r) { return at < r[1] && at + m.length + 1 > r[0]; })) { whole.push({ k: m, at: at, n: 1 }); taken.push([at, at + m.length + 1]); }
    });
    // each word, at the space before it (as a whole name's place is)
    var toks = [], pos = 0;
    s.split(' ').forEach(function (w) { if (w) toks.push({ w: w, at: pos - 1 }); pos += w.length + 1; });
    var payeesOf = function (part, short) { return ix.list.filter(function (m) { var at = (' ' + m + ' ').indexOf(' ' + part + ' '); return short ? at === 0 && (BRANDS.test(part) || ix.count[m] >= 2) : at >= 0; }); };
    var words = [];
    for (var i = 0; i < toks.length; i++) {
      var t = toks[i], w = t.w;
      if (STOP[w] || HI_STOP[w] || /^\d|^₹/.test(w) || w.length < 3 || taken.some(function (r) { return t.at >= r[0] && t.at < r[1]; })) continue;
      // two words of one name together say more than either ("example bistro")
      var two = toks[i + 1] && !STOP[toks[i + 1].w] && !HI_STOP[toks[i + 1].w] ? w + ' ' + toks[i + 1].w : '';
      var ms2 = two ? payeesOf(two, false) : [];
      if (ms2.length) { words.push({ k: two, at: t.at, n: ms2.length }); i++; continue; }
      // a three-letter brand people say on its own ("ola", "jio") counts when it starts a payee's name
      var ms1 = payeesOf(w, w.length === 3);
      if (ms1.length) words.push({ k: w, at: t.at, n: ms1.length });
    }
    var spare = Math.max(3, Math.round(ix.list.length * 0.2));
    var sharp = words.filter(function (x) { return x.n < spare; });
    var out = whole.concat(sharp.length ? sharp : words.slice(0, 1)).sort(function (a, b) { return a.at - b.at; });
    ctx.__hits = { s: s, out: out };
    return out;
  }
  function findPayee(s, ctx) {
    var hits = payeeHits(s, ctx), whole = hits.filter(function (h) { return h.n === 1 && payeeIndex(ctx).count[h.k]; });
    return (whole[0] || hits[0] || { k: '' }).k;
  }
  /* every payee a question names when it joins them ("Swiggy and Zomato", "Ola vs Uber"), in the order said */
  function findPayees(s, ctx) {
    var hits = payeeHits(s, ctx), first = findPayee(s, ctx);
    if (!first) return [];
    var out = [first], i0 = hits.map(function (h) { return h.k; }).indexOf(first);
    for (var i = i0 + 1; i < hits.length && out.length < 4; i++) {
      var prevH = hits[i - 1], between = s.slice(prevH.at + prevH.k.length + 1, hits[i].at + 1);
      if (!/^ (?:\w+ )?(?:and|aur|or|vs|versus|with|against|\+|&|plus) $/.test(between)) break;
      if (out.some(function (o) { return o.indexOf(hits[i].k) >= 0 || hits[i].k.indexOf(o) >= 0; })) break;
      out.push(hits[i].k);
    }
    return out;
  }
  // words of Hindi said in Latin letters that are never a payee's name
  var HI_STOP = {};
  ('hai hain hoon hu tha thi kya kyu kyun kaise aur ya bhi toh ka ki ke ko se pe par mein main mai mera meri mere hamara humara apna apni ' +
   'sab kuch hua hui hue kar kiya kiye liya liye wala wali wale nahi nahin ji bas abhi ne wahan yahan').split(' ').forEach(function (w) { if (w) HI_STOP[w] = 1; });
  function isPerson(part, ctx) {
    var ix = payeeIndex(ctx), p = 0, n = 0;
    ix.list.forEach(function (m) { if (m.indexOf(part) >= 0) { n += ix.count[m]; p += ix.person[m] || 0; } });
    return n > 0 && p * 2 >= n;
  }
  function payeeName(part, ctx) {
    var ix = payeeIndex(ctx), best = '', n = 0;
    ix.list.forEach(function (m) { if (m.indexOf(part) >= 0 && ix.count[m] > n) { best = m; n = ix.count[m]; } });
    if (!best) return part.replace(/\b\w/g, function (c) { return c.toUpperCase(); });
    return joinAnd(payeeNames(part, ctx));
  }
  /* one payee: its own name; a word several payees share ("swiggy"): each of them by name, so the figure says what it
     covers ("Swiggy and Swiggy Instamart") */
  function payeeNames(part, ctx) {
    var ix = payeeIndex(ctx), all = ix.list.filter(function (m) { return m.indexOf(part) >= 0; }).sort(function (a, b) { return ix.count[b] - ix.count[a]; });
    if (!all.length) return [part.replace(/\b\w/g, function (c) { return c.toUpperCase(); })];
    return all.slice(0, 3).map(function (k) { return ix.shown[k]; }).concat(all.length > 3 ? [(all.length - 3) + ' more'] : []);
  }
  /* a payee as a question to tap says it: its own name, or the word several share ("Swiggy") */
  function payeeShort(part, ctx) { var ns = payeeNames(part, ctx); return ns.length === 1 ? ns[0] : part.replace(/\b\w/g, function (c) { return c.toUpperCase(); }); }
  /* the payee or payees a frame is about, in words: "Swiggy, Swiggy Instamart and Zomato" */
  function payeesWord(f, ctx) {
    var names = [];
    (f.merchants && f.merchants.length ? f.merchants : f.merchant ? [f.merchant] : []).forEach(function (m) { payeeNames(m, ctx).forEach(function (n) { if (names.indexOf(n) < 0) names.push(n); }); });
    return joinAnd(names);
  }

  function slotsOf(s, ctx, today) {
    var f = {};
    var per = periodOf(s, today);
    f.from = per.from; f.to = per.to; f.named = !!per.named; f.label = per.label || '';
    for (var i = 0; i < CAT_WORDS.length; i++) if (CAT_WORDS[i][0].test(s)) { f.category = CAT_WORDS[i][1]; break; }
    if (f.category) {
      // "fuel": the ledger's own Fuel under Transport, not all of Transport ("petrol" is fuel, "the cook" household help)
      var subs = {}, s2 = s.replace(/\b(?:petrol|diesel|cng)\b/g, 'fuel').replace(/\b(?:cooks?|maids?|drivers?|nannies|nanny|cleaners?|househelp|house help|household help|domestic help|bai)\b/g, 'domestic help')
        .replace(/\b(?:cabs?|taxis?|autos?|rides?)\b/g, 'cabs').replace(/\bfood delivery\b/g, 'delivery');
      (ctx.tx || []).forEach(function (t) { if (t.s && lc(t.c) === lc(f.category)) subs[t.s] = 1; });
      Object.keys(subs).some(function (x) { var w = lc(x).replace(/&/g, 'and'); if (w.length >= 3 && (s2.indexOf(' ' + w + ' ') >= 0 || s2.indexOf(' ' + lc(x) + ' ') >= 0)) { f.category = x; return true; } return false; });
      // one kind of bill named ("electricity"): that kind alone, never every bill in its place, and its payments by the
      // company's name too (a power company's payment kosh filed under another category)
      var billKind = /\belectric\w*\b/.test(s) ? 'Electricity' : /\bbroadband\b|\binternet\b/.test(s) ? 'Internet' : /\bwater\b/.test(s) ? 'Water' : '';
      if (billKind && (f.category === 'Bills' || lc(f.category) === lc(billKind))) { f.category = billKind; f.billKind = billKind; }
    }
    if (!f.category) {
      var seen = {};
      (ctx.tx || []).forEach(function (t) { if (t.c) seen[t.c] = 1; if (t.s) seen[t.s] = 1; });
      Object.keys(seen).sort(function (a, b) { return b.length - a.length; }).some(function (c) {
        var w = lc(c).replace(/&/g, 'and');
        if (w.length >= 3 && (s.indexOf(' ' + w + ' ') >= 0 || s.indexOf(' ' + lc(c) + ' ') >= 0)) { f.category = c; return true; }
        return false;
      });
    }
    var ms = findPayees(s, ctx), m = ms[0] || '';
    if (m) {
      f.merchant = m;
      if (f.category) {
        // "zomato" names a payee, not the category it's in; "fuel" names the category, whatever a payee is called
        if (BRANDS.test(m.split(' ')[0])) delete f.category;
        else if (m.indexOf(' ') < 0 || lc(f.category) === m) { delete f.merchant; ms = []; }
      }
      // two payees joined: both together ("Swiggy and Zomato"), or one against the other ("Ola vs Uber")
      if (f.merchant && ms.length > 1) {
        if (/\b(?:vs|versus|or|against|compare|compared)\b/.test(s)) f.merchant2 = ms[1];
        else f.merchants = ms;
      }
    }
    // a person by name, by how they're related ("my wife", "Mom", "papa"), or the user by their own name
    (ctx.people || []).forEach(function (p) {
      var kin = KIN[lc(p.rel || '')];
      if (p.id !== 'me' && kin && kin.test(s)) f.person = p.name;
      [p.name, p.full].forEach(function (nm) { var w = lc(nm).split(/\s+/)[0]; if (w.length >= 3 && w !== 'you' && new RegExp(' ' + w + "(?:'s)? ").test(s)) f.person = p.id === 'me' ? 'me' : p.name; });
    });
    if (f.person && f.merchant && (lc(f.person).indexOf(f.merchant) === 0 || (f.person === 'me' && lc(meOf(ctx).name || '').indexOf(f.merchant) === 0))) { delete f.merchant; delete f.merchants; delete f.merchant2; }
    // "how much did my husband spend" with no husband in the household: said so, never the user's own figure instead
    if (!f.person) {
      var kinAsked = /\b(wife|husband|spouse|hubby|biwi|patni|pati|mom|mum|mummy|mother|maa|amma|dad|daddy|papa|father|pitaji|son|daughter|beta|beti|brother|sister|bhai|didi|behen)(?:'s)?\b(?=(?: \w+){0,3} (?:spen[dt]|spending|spends|ka|ki|ke|ne|card|cards|salary|account)\b)/.exec(s);
      if (kinAsked) f.kin = { biwi: 'wife', patni: 'wife', pati: 'husband', hubby: 'husband', maa: 'mother', amma: 'mother', mummy: 'mother', mum: 'mother', mom: 'mother', papa: 'father', pitaji: 'father', dad: 'father', daddy: 'father',
        beta: 'son', beti: 'daughter', bhai: 'brother', didi: 'sister', behen: 'sister' }[kinAsked[1]] || kinAsked[1];
    }
    var bank = /\b(hdfc|icici|sbi|axis|kotak|idfc|indusind|yes bank|au|amex|hsbc|rbl|federal|onecard|scapia|bob|pnb|canara|citi)\b/.exec(s);
    if (bank && /\b(?:card|account|bank|a\/c)\b/.test(s)) {
      // "my HDFC credit card" is the card, "my HDFC account" the account, "HDFC" alone either (rows read "HDFC CC ••1234", "HDFC A/c ••4821")
      var isCard = /\bcards?\b/.test(s), isAcct = /\baccounts?\b|\ba\/c\b|\bsavings\b/.test(s);
      f.card = bank[1].replace(' bank', '') + (isCard && !isAcct ? ' cc' : isAcct && !isCard ? ' a/c' : '');
      if (f.merchant && f.merchant.indexOf(bank[1]) === 0) { delete f.merchant; delete f.merchants; delete f.merchant2; }
    }
    // fees, a school or tuition for someone in the household are paid for them, not by them: the payments that name them
    if (f.person && f.person !== 'me' && (/^(?:Education|Fees|School fees|Tuition)$/i.test(f.category || '') || /\bfees?\b|\bschool\b|\btuition\b|\bcoaching\b/.test(s))) {
      var pf0 = (ctx.people || []).filter(function (p) { return p.name === f.person; })[0];
      if (pf0) { f.forName = lc(pf0.name); f.forWho = pf0.name; delete f.person; }
    }
    // the family business, on its own account (an account in the business's name): its customers and suppliers
    if (/\bbusiness\b|\bshop\b|\bfirm\b|\bdukaa?n\b|\bcustomers?\b|\bclients?\b|\bsuppliers?\b|\bvendors?\b/.test(s) && bizOwners(ctx).length) f.biz = true;
    if (/\bupi\b|\bgpay\b|\bphonepe\b|\bpaytm\b/.test(s)) f.method = 'upi';
    else if (/\bcash\b/.test(s) && !/\bcash ?back\b|\bwithdr|\batm\b/.test(s)) f.method = 'cash';
    else if (/\b(?:credit|debit) cards?\b|\bby card\b|\bon (?:my |the )?cards?\b|\bcards? (?:pe|par|se)\b|\bcard payments?\b|\bcard spends?\b/.test(s) && !f.card) f.method = 'card';
    else if (/\bwallets?\b/.test(s)) f.method = 'wallet';
    else if (/\bauto ?debits?\b|\bautopay\b|\bmandates?\b/.test(s)) f.method = 'auto';
    else if (/\bnet ?banking\b|\bneft\b|\bimps\b|\brtgs\b|\bbank transfers?\b/.test(s)) f.method = 'transfer';
    // amounts, never the days of a date ("between 10 and 20 September")
    var notDay = '(?!\\s*(?:st|nd|rd|th)?\\s*(?:of )?' + MRE + '\\b)';
    var lo = new RegExp('\\b(?:over|above|more than|greater than|bigger than|at least|>)\\s*₹?\\s*(\\d{2,})\\b' + notDay).exec(s), hi = new RegExp('\\b(?:under|below|less than|smaller than|at most|<)\\s*₹?\\s*(\\d{2,})\\b' + notDay).exec(s);
    var btw = new RegExp('\\bbetween\\s*₹?\\s*(\\d{2,})\\s*(?:and|to|-)\\s*₹?\\s*(\\d{2,})\\b' + notDay).exec(s);
    if (btw && /\b(?:and|to|-)\s*₹?\s*\d{2,}\s*(?:st|nd|rd|th)?\s*(?:of )?(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)/.test(s)) btw = null;
    if (btw) { f.min = +btw[1]; f.max = +btw[2]; } else { if (lo) f.min = +lo[1]; if (hi) f.max = +hi[1]; }
    if (/\b(?:need|needs|needing|without) (?:a )?names?\b|\bunnamed\b|\bnot named\b|\buntagged\b/.test(s)) f.unnamed = true;
    var top = /\btop (\d+|three|five|ten|twenty)\b/.exec(s);
    if (top) f.n = /^\d+$/.test(top[1]) ? +top[1] : { three: 3, five: 5, ten: 10, twenty: 20 }[top[1]];
    if (/\b(?:least|lowest|smallest|fewest|cheapest)\b/.test(s)) f.order = 'asc';
    if (/\bon weekends?\b|\bweekend (?:spend|spending)\b|\bsaturdays? and sundays?\b/.test(s) && !/\bvs\b|\bversus\b|\bor\b/.test(s)) f.weekend = 'yes';
    else if (/\bon weekdays?\b|\bweekday (?:spend|spending)\b/.test(s) && !/\bvs\b|\bversus\b|\bor\b/.test(s)) f.weekend = 'no';
    return f;
  }
  var BRANDS = /^(?:zomato|swiggy|blinkit|zepto|instamart|bigbasket|dunzo|amazon|flipkart|myntra|ajio|nykaa|meesho|uber|ola|rapido|netflix|spotify|hotstar|jiohotstar|jio|airtel|prime|youtube|apple|google|makemytrip|irctc|bookmyshow|dmart|kfc|lic)$/;
  // how a person is related, as kosh's Household screen names it (Spouse, Mom, Papa, Child, Sibling) or as typed
  var SPOUSE = /\b(?:wife|husband|spouse|partner|hubby|missus|biwi|patni|pati|better half)\b/, MOM = /\b(?:mom|mum|mummy|mumma|mother|maa|amma|ammi|aai)\b/,
      DAD = /\b(?:dad|daddy|papa|pappa|father|pitaji|abba|appa)\b/, KID = /\b(?:son|daughter|kid|kids|child|beta|beti)\b/, SIB = /\b(?:brother|sister|sibling|bhai|bhaiya|didi|behen)\b/;
  var KIN = { spouse: SPOUSE, wife: /\b(?:wife|spouse|missus|biwi|patni|better half)\b/, husband: /\b(?:husband|spouse|hubby|pati)\b/, partner: SPOUSE,
    mom: MOM, mother: MOM, papa: DAD, dad: DAD, father: DAD, child: KID, son: /\b(?:son|beta)\b/, daughter: /\b(?:daughter|beti)\b/,
    sibling: SIB, brother: /\b(?:brother|bhai|bhaiya)\b/, sister: /\b(?:sister|didi|behen)\b/ };
  function meOf(ctx) { return (ctx.people || []).filter(function (p) { return p.id === 'me'; })[0] || { id: 'me', name: 'You' }; }
  /* the owners that are a business, not a person: an account kosh files under a name no one in the household has
     ("n:example traders", the family firm's current account) */
  function bizOwners(ctx) {
    if (ctx.__biz) return ctx.__biz;
    var ids = (ctx.people || []).map(function (p) { return p.id; }), out = [];
    (ctx.accounts || []).forEach(function (a) { var o = String(a.owner || ''); if (/^n:/.test(o) && ids.indexOf(o) < 0 && out.indexOf(o) < 0) out.push(o); });
    ctx.__biz = out;
    return out;
  }
  // someone in the household a word names: by name, first name or how they're related
  function personOf2(w, ctx) {
    return (ctx.people || []).filter(function (p) { var kin = KIN[lc(p.rel || '')]; return lc(p.name) === w || lc(p.full || '').split(/\s+/)[0] === w || (kin && kin.test(' ' + w + ' ')); })[0] || null;
  }
  // a payment to the company behind a kind of bill ("mahadiscom" for electricity), whatever category kosh filed it under
  function billNameOk(t, kind) {
    if (!kind) return false;
    var K = BILL_KIND.filter(function (k) { return k[0] === lc(kind); })[0];
    return !!K && (t.k === 'out' || t.k === 'prepaid') && K[2].test(t.m || '') && !/^(?:Food & Drinks|Groceries|Shopping|Travel|Transport|Fitness|Entertainment|Investments|Salary|Medical|Education)$/i.test(t.c || '');
  }
  // a word said whole in a payee's name ("kabir" in "Example Academy-Kabir", never in "Kabirdas Stores")
  function wordIn(m, w) { return !!w && (' ' + lc(m).replace(/[^a-z0-9]+/g, ' ') + ' ').indexOf(' ' + lc(w) + ' ') >= 0; }
  // a bank as it writes its own name
  var BANK_NAME = { hdfc: 'HDFC', icici: 'ICICI', sbi: 'SBI', axis: 'Axis', kotak: 'Kotak', idfc: 'IDFC FIRST', indusind: 'IndusInd', yes: 'Yes Bank', au: 'AU', amex: 'Amex',
    hsbc: 'HSBC', rbl: 'RBL', federal: 'Federal', onecard: 'OneCard', scapia: 'Scapia', bob: 'Bank of Baroda', pnb: 'PNB', canara: 'Canara', citi: 'Citi' };
  /* banks as a question names them, short or in full: [what the question says, what the bank's accounts are called,
     the longer name of another bank it must not be read inside, the bank in words]. A bank whose name sits inside
     another's comes after it (South Indian Bank and Indian Overseas Bank before Indian Bank; State Bank of India is not
     Bank of India). A bank not here is still found by its own name among the accounts kosh knows (bankAsked). */
  var BANK_ALIAS = [
    ['sib|south indian(?: bank)?', /south indian bank|\bsib\b/i, null, 'South Indian Bank'],
    ['iob|indian overseas(?: bank)?', /indian overseas|\biob\b/i, null, 'Indian Overseas Bank'],
    ['indian bank', /\bindian bank\b/i, /south indian|indian overseas/i, 'Indian Bank'],
    ['sbi|state bank(?: of india)?', /state bank of india|\bsbi\b/i, null, 'SBI'],
    ['cub|city union(?: bank)?', /city union|\bcub\b/i, null, 'City Union Bank'],
    ['ubi|union bank(?: of india)?|union(?= (?:account|accounts|a\\/c|balance|khata))', /union bank|\bubi\b/i, /city union/i, 'Union Bank'],
    ['cbi|central bank(?: of india)?', /central bank of india|\bcbi\b/i, null, 'Central Bank of India'],
    ['boi|bank of india', /\bbank of india\b|\bboi\b/i, /(?:state|union|central) bank of india/i, 'Bank of India'],
    ['bob|bank of baroda|baroda', /baroda|\bbob\b/i, null, 'Bank of Baroda'],
    ['pnb|punjab national(?: bank)?', /punjab national|\bpnb\b/i, null, 'PNB'],
    ['psb|punjab (?:and|&) sind(?: bank)?', /punjab (?:and|&) sind|\bpsb\b/i, null, 'Punjab & Sind Bank'],
    ['uco(?: bank)?', /\buco\b/i, null, 'UCO Bank'],
    ['ippb|india post(?: payments?)?(?: bank)?|post office (?:savings|account|bank)', /india post|\bippb\b/i, null, 'India Post Payments Bank'],
    ['kvb|karur vysya(?: bank)?', /karur vysya|\bkvb\b/i, null, 'Karur Vysya Bank'],
    ['tmb|tamilnad mercantile(?: bank)?', /tamilnad mercantile|\btmb\b/i, null, 'Tamilnad Mercantile Bank'],
    ['csb(?: bank)?|catholic syrian(?: bank)?', /\bcsb\b|catholic syrian/i, null, 'CSB Bank'],
    ['kbl|karnataka bank', /karnataka bank|\bkbl\b/i, null, 'Karnataka Bank'],
    ['dhanlaxmi(?: bank)?|dhanalakshmi(?: bank)?', /dhan(?:a)?la(?:x|ksh)mi/i, null, 'Dhanlaxmi Bank'],
    ['j ?& ?k bank|jk bank|jammu (?:and|&) kashmir bank', /j ?& ?k bank|jammu/i, null, 'J&K Bank'],
    ['airtel(?: payments?)?(?: bank)?', /airtel/i, null, 'Airtel Payments Bank'],
    ['paytm payments?(?: bank)?|paytm bank', /paytm payments|paytm bank/i, null, 'Paytm Payments Bank'],
    ['fino(?: payments?)?(?: bank)?', /\bfino\b/i, null, 'Fino Payments Bank'],
    ['jio payments?(?: bank)?', /jio payments/i, null, 'Jio Payments Bank'],
    ['standard chartered|stanchart|scb', /standard chartered|\bscb\b/i, null, 'Standard Chartered'],
    ['federal(?: bank)?', /federal/i, null, 'Federal'], ['canara(?: bank)?', /canara/i, null, 'Canara'], ['idbi(?: bank)?', /\bidbi\b/i, null, 'IDBI'],
    ['bandhan(?: bank)?', /bandhan/i, null, 'Bandhan'], ['ujjivan(?: bank)?', /ujjivan/i, null, 'Ujjivan'], ['equitas(?: bank)?', /equitas/i, null, 'Equitas'],
    ['hdfc', /\bhdfc\b/i, null, 'HDFC'], ['icici', /\bicici\b/i, null, 'ICICI'], ['axis', /\baxis\b/i, null, 'Axis'], ['kotak', /\bkotak\b/i, null, 'Kotak'],
    ['idfc', /\bidfc\b/i, null, 'IDFC FIRST'], ['indusind', /indusind/i, null, 'IndusInd'], ['yes bank', /\byes bank\b/i, null, 'Yes Bank'], ['au(?: small finance)?(?: bank)?', /\bau\b/i, null, 'AU'],
    ['rbl', /\brbl\b/i, null, 'RBL'], ['dbs', /\bdbs\b/i, null, 'DBS'], ['hsbc', /\bhsbc\b/i, null, 'HSBC'], ['citi(?:bank)?', /\bciti/i, null, 'Citi'],
  ].map(function (b) { return { q: new RegExp('\\b(?:' + b[0] + ')\\b'), acct: b[1], not: b[2], word: b[3] }; });
  // an account's own words: its bank, its name, what you named it, how kosh tagged it, its kind
  // an account as its page names it: the name you gave it, else its bank's ("The South Indian Bank" without "The")
  function acctLabel(a) { return (a.nick || String(a.name || a.bank || '').replace(/^the\s+/i, '')) + ' ••' + a.last; }
  function acctWords(a) { return [a.bank, a.name, a.nick, a.tag, a.kind, a.type, a.sub].concat(a.alias || []).filter(Boolean).join(' '); }
  /* the bank a question names, among the accounts kosh knows: { word, test(account) }, or null. Its short form or its
     name ("SIB", "Karur Vysya", "Bandhan"); a bank not in BANK_ALIAS by a word of its own name ("Saraswat balance") */
  function bankAsked(s, ctx) {
    for (var i = 0; i < BANK_ALIAS.length; i++) {
      var B = BANK_ALIAS[i];
      if (B.q.test(s)) return { word: B.word, test: function (a) { var w = acctWords(a); return B.acct.test(w) && !(B.not && B.not.test(w)); } };
    }
    var hit = null;
    s.trim().split(' ').some(function (w) {
      if (w.length < 3 || STOP[w] || HI_STOP[w] || ACCT_KIND_WORD.test(' ' + w + ' ') || /^(?:bank|balance|account|khata|money|net|worth)$/.test(w) || personOf2(w, ctx)) return false;
      var re = new RegExp('(?:^|[^a-z])' + w.replace(/[^a-z0-9]/g, ''), 'i');
      if (!/^[a-z][a-z0-9]+$/.test(w) || !(ctx.accounts || []).some(function (a) { return re.test(lc(a.bank) + ' ' + lc(a.name)); })) return false;
      hit = { word: cap1(w), test: function (a) { return re.test(lc(a.bank) + ' ' + lc(a.name)); } };
      return true;
    });
    return hit;
  }
  /* the kind of account a question names: NRE, NRO, FCNR, salary, savings, joint ('' when none; the current account
     is the business's, asked apart). Whether an account is of that kind: what it's called says so, or for a salary
     account, salary coming into it */
  var ACCT_KIND_WORD = /\b(nre|nro|fcnr|salary|savings?|sb|joint)(?: (?:account|accounts|a\/c|khata|khate))\b|\b(nre|nro|fcnr)\b/;
  var ACCT_KIND_NAME = { nre: 'NRE', nro: 'NRO', fcnr: 'FCNR', salary: 'salary', savings: 'savings', joint: 'joint' };
  function kindAsked(s) { var m = ACCT_KIND_WORD.exec(s); if (!m) return ''; var k = m[1] || m[2]; return k === 'saving' || k === 'sb' ? 'savings' : k; }
  function acctIsKind(a, kind, ctx) {
    var w = lc(acctWords(a));
    if (kind === 'savings') return /\bsavings?\b|\bsb\b/.test(w) ? true : null;
    if (new RegExp('\\b' + kind + '\\b').test(w)) return true;
    if (kind === 'salary') return (ctx.tx || []).some(function (t) { return t.k === 'in' && t.c === 'Salary' && new RegExp('••' + a.last + '\\b').test(t.card || '') && lc(t.card).indexOf(lc(String(a.bank || '').split(' ')[0])) >= 0; }) || null;
    return null;
  }
  /* a person in words: the user is "You", whatever their name */
  function personWord(p) { return !p || p === 'me' || lc(p) === 'you' ? 'You' : p; }
  var SUBJECT = ['category', 'merchant', 'merchants', 'merchant2', 'person', 'person2', 'card', 'method', 'min', 'max', 'unnamed', 'weekend', 'forName', 'forWho', 'biz', 'billKind'];
  function hasSubject(f) { return SUBJECT.some(function (k) { return f[k] !== undefined && f[k] !== ''; }); }

  /* the stretch ahead a question looks at, from today: { from, to, words }. "today" and "tomorrow" are that day,
     "this week" runs to Sunday (on a Saturday or a Sunday, to the Sunday after), "next week" Monday to Sunday, "this
     month" to its last day, "before my salary" to the day before it's due, "the next 10 days" ten days on; else the
     next 30 days (def: nothing said) */
  function aheadOf(s, today, ctx) {
    var NUM = { a: 1, one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, ten: 10, fifteen: 15, thirty: 30 };
    var at = function (n, words, def) { return { from: today, to: addDays(today, n), words: words, def: !!def }; };
    var m = /\b(?:next|coming|in the next|within|over the next)\s+(\d+|[a-z]+)\s+(days?|weeks?|months?)\b/.exec(s);
    if (m) {
      var k = /^\d+$/.test(m[1]) ? +m[1] : NUM[m[1]] || 0;
      if (k) { var d = Math.min(120, /^week/.test(m[2]) ? k * 7 : /^month/.test(m[2]) ? k * 30 : k); return at(d, d === 14 ? 'in the next two weeks' : 'in the next ' + d + ' days'); }
    }
    if (/\bfortnight\b/.test(s)) return at(14, 'in the next two weeks');
    if (/\bday after tomorrow\b/.test(s)) { var d2 = addDays(today, 2); return { from: d2, to: d2, words: 'on ' + on(d2, today) }; }
    if (/\btomorrow\b/.test(s)) { var tm = addDays(today, 1); return { from: tm, to: tm, words: 'tomorrow' }; }
    if (/\btoday\b/.test(s)) return { from: today, to: today, words: 'today' };
    var dow = dowOf(today);
    if (/\bnext week\b/.test(s)) { var mon = addDays(today, 7 - dow); return { from: mon, to: addDays(mon, 6), words: 'next week' }; }
    if (/\bthis week\b/.test(s)) { var sun = addDays(today, 6 - dow + (dow >= 5 ? 7 : 0)); return { from: today, to: sun, words: dow >= 5 ? 'by Sun ' + dShort(sun) : 'this week', week: true }; }
    if (/\bthis month\b|\bmonth end\b|\bend of (?:the |this )?month\b|\brest of (?:the |this )?month\b/.test(s)) return { from: today, to: monthEnd(today), words: 'by ' + dShort(monthEnd(today)) };
    if (/\bnext month\b/.test(s)) { var nm1 = addDays(monthEnd(today), 1); return { from: nm1, to: monthEnd(nm1), words: 'in ' + MONF[+nm1.slice(5, 7) - 1] }; }
    if (/\b(?:before|till|until|by the time) (?:my |the |our )?(?:next )?salary\b|\bbefore (?:i|we) get paid\b|\bbefore pay ?day\b/.test(s)) {
      var nx = nextSalary(ctx, today);
      if (nx && nx > today) return { from: today, to: addDays(nx, -1), words: 'before your salary (due about ' + dShort(nx) + ')' };
    }
    return at(30, 'in the next 30 days', true);
  }
  /* a due question's window: what aheadOf read, or a number of days (a frame from before) */
  function dueWindow(f, today) {
    if (f.ahead && f.ahead.from) return f.ahead;
    var nd = f.days !== undefined && f.days !== null ? Math.max(0, +f.days || 0) : 30;
    return { from: today, to: addDays(today, nd), words: nd === 14 ? 'in the next two weeks' : 'in the next ' + nd + ' days', def: f.days === undefined || f.days === null };
  }
  var DUE_WORD = { emi: 'EMI', sip: 'SIP', card: 'card bill', premium: 'premium', insurance: 'premium', rent: 'rent', electricity: 'electricity bill' };
  /* which calendar items a due question is about. An EMI or an SIP is what repeats as one (the calendar names it by its
     payee: "Axis Bank Car Loan", "Example Midcap Fund"); anything else by its own word, never a word inside a name
     ("emi" in "Premium"); "car loan", "home loan" and a bank ("HDFC card") narrow it */
  function dueFilter(f, ctx) {
    var wf = f.what || '', kindOf = {};
    (ctx.recurring || []).forEach(function (r) { kindOf[lc(r.name)] = r.kind; });
    var WORD = { emi: /\bemis?\b|\bloans?\b/i, sip: /\bsips?\b/i, card: /\bcards?\b/i, premium: /\bpremiums?\b|\binsurance\b/i, insurance: /\bpremiums?\b|\binsurance\b/i, rent: /\brent\b/i, electricity: /\belectric|\bpower\b/i };
    var whichRe = f.which ? new RegExp(f.which === 'home' || f.which === 'housing' ? 'home|housing' : f.which === 'car' ? 'car|vehicle|auto' : f.which, 'i') : null;
    var bankRe = f.card ? new RegExp('\\b' + f.card.replace(/ (?:cc|a\/c)$/, '') + '\\b', 'i') : null;
    return function (x) {
      var nm = x.name + ' ' + (x.sub || ''), k = kindOf[lc(x.name)];
      if (wf === 'emi' || wf === 'sip') { if (k ? k !== wf : !WORD[wf].test(x.name) || /\bpremium\b/i.test(x.name)) return false; }
      else if (wf && !(WORD[wf] || new RegExp('\\b' + wf + '\\b', 'i')).test(nm)) return false;
      if (whichRe && !whichRe.test(x.name)) return false;
      if (bankRe && !bankRe.test(x.name)) return false;
      return true;
    };
  }
  /* one goal in words: what's saved against it, what each month needs, and whether it's on pace (plan.js worked it out) */
  function goalLine(g, today) {
    var head = '**' + g.name + '**';
    if (g.state === 'done') return head + ': done, ' + lakh(g.saved) + (g.target > 0 ? ' of ' + lakh(g.target) : '') + '.';
    var have = g.target > 0 ? ': ' + lakh(g.saved || 0) + ' of ' + lakh(g.target) + ' saved (' + (g.pct || 0) + '%).' : ': ' + lakh(g.saved || 0) + ' saved.';
    var by = g.by ? dShort(g.by) + (g.by.slice(0, 4) !== today.slice(0, 4) ? ' ' + g.by.slice(0, 4) : '') : '';
    var how = '';
    if (g.state === 'late') how = ' Its date, ' + by + ', has gone by.';
    else if (g.perMonth > 0 && by) how = ' ' + inr(g.perMonth) + ' a month gets there by ' + by + '.';
    if (g.state === 'on') how += ' You’re on pace' + (g.pace > 0 ? ': it grew about ' + inr(g.pace) + ' a month lately' : '') + '.';
    else if (g.state === 'behind') how += ' You’re behind' + (g.pace > 0 ? ': it grew about ' + inr(g.pace) + ' a month lately' : '') + '.';
    else if (g.pace > 0 && g.paceOf === 'kind' && by) how += ' Your balances as a whole grew about ' + inr(g.pace) + ' a month lately; kosh can’t tell how much of that is for this goal.';
    else if (g.eta && !by && g.pace > 0) how += ' At about ' + inr(g.pace) + ' a month it gets there around ' + MONF[+g.eta.slice(5, 7) - 1] + ' ' + g.eta.slice(0, 4) + '.';
    return head + have + how;
  }
  /* the day the user's next salary is due: its usual day, the month after the last one came */
  function nextSalary(ctx, today) {
    var sal = (ctx.tx || []).filter(function (t) { return t.k === 'in' && t.c === 'Salary' && t.a >= 5000; });
    var mine = sal.filter(function (t) { return (t.o || 'me') === 'me'; });
    if (mine.length) sal = mine;
    if (!sal.length) return '';
    sal.sort(function (a, b) { return a.d.localeCompare(b.d); });
    var last = sal[sal.length - 1].d, day = Math.round(median(sal.slice(-3).map(function (t) { return +t.d.slice(8, 10); })));
    var nm = addDays(monthEnd(last), 1);
    return nm.slice(0, 8) + pad(Math.min(day, +monthEnd(nm).slice(8)));
  }
  /* what this phone's answers can't see, and plainly why: tax sections, credit scores; goals, committees and trials
     when the phone hasn't handed them over (an older app) */
  // a jeweller's monthly gold savings scheme, and the payees that are one (a jeweller, a "nidhi", a named scheme)
  var GOLD_SCHEME_ASK = /\bgold (?:savings? |chit |monthly )?(?:scheme|plan)s?\b|\bjewell?(?:er|ery|ers|ry)?(?:'s)? (?:savings? )?(?:scheme|plan)s?\b|\bswarna ?nidhi\b|\bgolden harvest\b/;
  var GOLD_SCHEME_ROW = /jewel|\bgold\b|swarna|\bnidhi\b|golden harvest|tanishq|kalyan jewel|malabar gold|joyalukkas|bhima|lalithaa? jewel|\bgrt\b|scheme/i;
  // cash a bank took in over the counter or at a machine
  var CASH_DEP_ROW = /cash ?dep|\bcdm\b|by cash|cash credit|cash (?:paid )?in\b|\bbna\b|deposit by cash/i;
  var TAX_REFUND_ASK =/\b(?:income ?tax|i-t|itr|tax) refunds?\b|\brefunds? (?:of|from|for) (?:my |the )?(?:income ?tax|itr|tax|the tax department|cbdt)\b/;
  // a credit the income-tax department sent: CBDT, ITD, "TAX REFUND", "IT REFUND"
  var TAX_REFUND_ROW = /\bcbdt\b|\bitd\b|income ?tax|\btax ?refund|\bit ?refund|\brefund\b.*\bay ?20\d\d\b|\btin\b.*\brefund/i;
  function topicOf(s, ctx) {
    if (/\b80 ?(?:c|ccd|d|e|g|tta|ttb)\b|\bsection 80\b|\bhra\b|\btax regimes?\b|\b(?:old|new) regime\b|\bitr\b|\btax (?:return|filing)s?\b/.test(s)) return 'tax';
    if (/\badvance tax\b/.test(s) && /\b(?:when|due|next|date|deadline|last day|instal+ments?)\b/.test(s) && !/\b(?:did|have) (?:i|we) pay\b|\bpaid\b/.test(s)) return 'advtax';
    if (/\bcibil\b|\bcredit (?:score|report|rating)\b/.test(s)) return 'score';
    if (/\b(?:parcels?|packages?|couriers?|shipments?|deliver(?:y|ies)|return pickups?|pickups?)\b|\bwhere (?:is|are) (?:my|the) orders?\b|\borders? (?:kab|when|where)\b|\b(?:order|parcel|package)s? (?:kab )?(?:aayega|aayegi|aaega|aaegi|ayega|arrive|arriving|coming|come|will come)\b/.test(s) &&
        !/\bspen[dt]\b|\bspending\b|\bhow much\b|\bfood delivery\b|\bdelivery (?:charges?|fees?)\b|\bcash on delivery\b/.test(s)) return 'parcel';
    if (!ctx.goals && /\bgoals?\b/.test(s)) return 'goals';
    if (!ctx.subs && /\b(?:free )?trials?\b/.test(s)) return 'trials';
    return '';
  }
  /* the household member a question sends money to: "sent Papa", "paid to my wife", "Aai ko … sent", "Priya ko …
     paid"; never one who did the spending ("how much did Papa spend") */
  function recipientOf(s, ctx) {
    if (!/\b(?:sent|send|sending|paid|pay|paying|transferred|transfer|given|gave|give)\b/.test(s) || /\bspen[dt]\b|\bspending\b/.test(s)) return null;
    var hit = null;
    (ctx.people || []).forEach(function (p) {
      if (hit || p.id === 'me') return;
      var ws = [lc(p.name), lc(p.full).split(/\s+/)[0]].filter(function (w) { return w.length >= 3 && /^[a-z]+$/.test(w); });
      var kin = KIN[lc(p.rel || '')], kinSrc = kin ? kin.source.replace(/^\\b\(\?:/, '').replace(/\)\\b$/, '') : '';
      var alt = ws.join('|') + (kinSrc ? (ws.length ? '|' : '') + kinSrc : '');
      if (!alt) return;
      var to = new RegExp('\\b(?:sent|send|sending|paid|pay|paying|transferred|transfer|given|gave|give)(?: (?:money|to|for|my|our))* (?:' + alt + ')\\b(?!\'s)');
      var ko = new RegExp('\\b(?:' + alt + ') ko\\b|\\bto (?:my |our )?(?:' + alt + ')\\b(?!\'s)');
      if (to.test(s) || ko.test(s)) hit = p;
    });
    return hit;
  }
  // a committee (a chit fund, a BC)
  var COMM_WORDS = /\bcommittees?\b|\bchit(?: ?funds?)?\b|\bchits\b|\bchitt[yi]\b|\bkur[iy]\b|\bbc\b|\bkitty\b|\bbisi\b|\bbh?ishi\b/;
  function actOf(s, f, today, ctx) {
    ctx = ctx || {};
    // a decision kosh can weigh on the household's own numbers: "should I prepay or invest", "can I afford a 12 lakh car"
    var DA = decideAPI(), di = DA ? DA.intentOf(s, today) : null;
    if (di) return { act: 'decide', kind: di.kind, args: di.args };
    // loan maths with the numbers given: "a 10 lakh loan at 9% for 10 years"
    var pct = /(\d+(?:\.\d+)?)\s*%/.exec(s), yrs = /(\d+)\s*(?:years?|yrs?)\b/.exec(s), mos = /(\d+)\s*months?\b/.exec(s);
    if (/\b(?:emi|loan)\b/.test(s) && pct && (yrs || mos)) {
      var nums = (s.match(/₹?\d{4,}/g) || []).map(function (x) { return +x.replace('₹', ''); }).sort(function (a, b) { return b - a; });
      if (nums.length) return { act: 'emi', principal: nums[0], rate: +pct[1], months: yrs ? +yrs[1] * 12 : +mos[1] };
    }
    // what the phone can't see: said plainly, never another figure in its place
    // an income-tax refund: the credit from the tax department in the ledger ("did I get my income tax refund")
    if (TAX_REFUND_ASK.test(s)) return { act: 'taxrefund' };
    var tp = topicOf(s, ctx);
    if (tp) return { act: 'none', topic: tp };
    // tax by its kind: GST paid ("how much GST did I pay"), advance tax paid ("advance tax kitna bhara")
    if (/\bgst\b/.test(s) && !/\bgst on\b/.test(s) && /\bhow much\b|\bpaid\b|\bpay\b|\btotal\b|\bdid i\b/.test(s)) return { act: 'tax', kind: 'gst' };
    if (/\badvance tax\b/.test(s) && /\bhow much\b|\bpaid\b|\btotal\b|\bdid i\b/.test(s)) return { act: 'tax', kind: 'adv' };
    // crypto: what kosh can see of it is what went to an exchange, never a holding
    if (/\bbitcoins?\b|\bbtc\b|\bcrypto\w*\b|\bethereum\b|\bether\b|\bdogecoin\b|\busdt\b|\bsolana\b/.test(s)) return { act: 'crypto', coin: (/\b(bitcoin|btc|ethereum|ether|dogecoin|usdt|solana)\b/.exec(s) || [])[1] || '' };
    // the full and final settlement from a job left: the old employer's last credit
    if (/\bfull (?:and|&) final\b|\bf ?(?:&|n) ?f\b|\bfnf\b|\bfinal settlement\b|\bsettlement from (?:my )?(?:old|last|previous|former) (?:job|employer|company|office)\b/.test(s)) return { act: 'fnf' };
    // a policy by its insurer's name ("the Star Health renewal", "did the LIC premium go up"): the policy, never spending
    // at the insurer; money from it (a claim, a maturity) is money in, below
    var insW = insurerNamed(s, ctx);
    // what an insurer paid out (a claim, a reimbursement): money from it, never spending at it
    if (insW && /\bpa(?:y|id|ys) (?:for|out)\b|\bclaims?\b|\bsettled?\b|\breimburs\w*/.test(s) && /\bhow much\b|\bdid\b|\bwhen\b|\btotal\b/.test(s) && !/\bpremiums?\b/.test(s)) {
      var insP = (ctx.policies || []).filter(function (p) { return insurerWord(p) === insW; })[0];
      return { act: 'from', who: insP ? insP.insurer : cap1(insW), word: insW, ins: true };
    }
    // a small-savings scheme's interest, asked when: the scheme's own dates (SCSS quarterly, POMIS monthly, PPF yearly)
    if (/\bscss\b|\bsenior citizens?(?:'s)? savings?\b|\bpomis\b|\bpost office (?:monthly income|mis)\b|\bppf\b/.test(s) && /\binterest\b/.test(s) && /\bwhen\b|\bdates?\b|\bhow often\b/.test(s))
      return { act: 'scheme', which: /\bpomis\b|\bpost office\b/.test(s) ? 'pomis' : /\bppf\b/.test(s) ? 'ppf' : 'scss' };
    // what's been prepaid on a loan: kosh can't tell a prepayment from an EMI in what the bank's mail says
    if (/\bprepa(?:id|y|yments?)\b|\bpart[- ]?pa(?:id|yments?)\b|\bforeclos\w*/.test(s) && /\bloans?\b/.test(s) && /\bhow much\b|\bdid\b|\btotal\b|\bhave\b/.test(s) && !/\bshould\b/.test(s))
      return { act: 'loans', which: (/\b(home|housing|car|bike|personal|education|gold|vehicle)\b/.exec(s) || [])[1] || '', ask: 'prepaid' };
    if (insW && /\brenew\w*\b|\bpremiums?\b|\bcover(?:age|ed)?\b|\bpolic(?:y|ies)\b|\bdue\b|\bexpir\w*\b|\bwhen is\b|\bnext\b|\bwent up\b|\bgone up\b|\bgo(?:ing)? up\b|\bincrease[ds]?\b|\bhike[ds]?\b|\bcostlier\b/.test(s) &&
        !/\bcame\b|\bcome\b|\breceived\b|\bcredited\b|\bpaid (?:for|out)\b|\bpay (?:for|out)\b|\bclaims?\b|\bmaturity\b|\bmatured\b|\bspen[dt]\b/.test(s)) {
      var riseQ = /\bwent up\b|\bgone up\b|\bgo(?:ing)? up\b|\bincrease[ds]?\b|\bhike[ds]?\b|\bcostlier\b/.test(s);
      return { act: 'insurance', ins: insW, ptype: (/\b(health|mediclaim|term|ulip|life|motor|car|bike|vehicle|home|travel)\b/.exec(s) || [])[1] || undefined,
               ask: riseQ ? 'rise' : /\bcover(?:age)?\b|\bsum assured\b|\bcovered\b/.test(s) ? 'cover' : /\bwhen\b|\bdue\b|\bnext\b|\brenew|\bexpir/.test(s) ? 'due' : undefined };
    }
    // property tax paid is in the ledger, whether or not a property is set up in kosh (what's due is the property's)
    if (/\bproperty tax\b|\bhouse tax\b/.test(s) && /\bhow much\b|\bpaid\b|\bpay\b|\btotal\b/.test(s) && !/\bdue\b|\bpending\b|\bowe\b|\bwhen\b|\bnext\b|\bunpaid\b/.test(s)) return { act: 'ptax' };
    // what clients paid a freelancer or a practice: the money in kosh files as business income
    if (!f.biz && /\bclients?\b|\bcustomers?\b/.test(s) && /\bpaid\b|\bpay\b|\bcame\b|\bget\b|\bgot\b|\breceived\b|\bhow much\b|\bearn\w*\b/.test(s)) {
      var bizCat = '';
      (ctx.tx || []).some(function (t) { if (t.k === 'in' && /business|professional|freelanc|consult/i.test(t.c || '')) { bizCat = t.c; return true; } return false; });
      if (bizCat) return { act: 'income', category: bizCat };
    }
    // money someone sent: "how much has Amit sent us", "Amit ne kitne paise bheje", "how much does Nirav give every month"
    var snd = senderOf(s, ctx);
    if (snd) return { act: 'from', who: snd.name, pid: snd.id || '', monthly: /\b(?:every|each|per|a|har) month\b|\bmonthly\b/.test(s) || undefined };
    // the family business's own account: what customers paid it, what it paid suppliers
    if (f.biz && /\bsuppliers?\b|\bvendors?\b|\bpurchases?\b/.test(s)) return { act: 'supplier' };
    if (f.biz && /\bcustomers?\b|\bclients?\b|\bsales\b|\brevenue\b|\bturnover\b|\bcame in\b|\breceived\b|\bget\b|\bgot\b|\bearn\w*\b|\bincome\b/.test(s)) return { act: 'income', biz: true };
    // money sent home from abroad: "how much have I remitted to India", "how much did I send home"
    // cash paid into the bank ("How much cash have I deposited this year?"): the Cash deposit rows, never cash spent
    if (/\bcash\b/.test(s) && /\bdeposit(?:ed|s|ing)?\b|\bjama\b/.test(s) && !/\bfixed deposits?\b|\bterm deposits?\b|\bfds?\b|\bcash ?back\b/.test(s)) return { act: 'cashdep' };
    if (/\bremit\w*\b|\bremittances?\b|\bsen[dt] (?:money )?home\b|\bsen(?:d|t|ding) (?:money )?(?:back )?to india\b|\bghar sent\b/.test(s) && !/\bspen[dt]\b/.test(s)) return { act: 'remit' };
    // money sent to someone in the household: "Aai ko is saal kitna bheja", "how much have I sent Papa"
    var rcpt = recipientOf(s, ctx);
    if (rcpt) return { act: 'sent', person: rcpt.name };
    // money sent, to no one named ("how much did I send this month", "is mahine kitna bheja"): the transfers to people
    if (/\b(?:sent|send|sending|transferred)\b/.test(s) && /\bhow much\b|\btotal\b/.test(s) && !f.merchant && !f.category && !/\bspen[dt]\b|\bhome\b|\bindia\b|\babroad\b/.test(s)) return { act: 'sentall' };
    // saving towards an amount by a date: what to put away each month
    if (/\b(?:need to|have to|should|must|want to) (?:save|put (?:away|aside))\b|\bsave (?:each|every|per|a) month\b|\bhow much (?:to|should i|do i need to|must i) save\b|\bsave up\b|\bto have ₹?\d/.test(s) && /₹?\d{4,}/.test(s)) {
      var tg = (s.match(/₹?\d{4,}/g) || []).map(function (x) { return +x.replace('₹', ''); }).filter(function (v) { return !(v >= 1900 && v <= 2100); });
      if (tg.length) { var by = byDateOf(s, today); return { act: 'tool', tool: 'whatif', args: by ? { kind: 'save_for', target: Math.max.apply(null, tg), by: by } : { kind: 'save_for', target: Math.max.apply(null, tg), months: 12 } }; }
    }
    // a decision, not a figure: the phone says so rather than answering something else
    if (/\bshould i\b|\bshould we\b|\bis it (?:better|worth|wise|smart|a good idea)\b|\bworth it\b|\bprepay|\badvice\b|\badvise\b|\brecommend|\bwhich is better\b/.test(s)) return { act: 'none' };
    // the household's other things first: these say plainly what they're about
    if (COMM_WORDS.test(s)) return { act: 'committee', what: /\b(?:did|have) (?:i|we) (?:get|got|receive)\b|\bgot\b|\breceived\b|\bcame\b|\bprize\b|\bwon\b|\bpayout (?:was|came|amount)\b/.test(s) && !/\bwill\b/.test(s) ? 'got' : /\bwill i get\b|\bdraw\b|\bpay ?out\b|\bpool\b|\bmy turn\b|\blift\b|\bwhen (?:do|will|can) (?:i|we) (?:get|take|receive)\b/.test(s) ? 'draw'
      : /\bnext\b|\binstal+ments?\b|\bwhen\b|\bdue\b/.test(s) ? 'next' : /\bhow much\b|\bpaid\b|\bput\b|\bcontribut/.test(s) ? 'paid' : 'all' };
    if (/\bgoals?\b/.test(s) || ((ctx.goals || []).some(function (g) { var w = lc(g.name).split(/\s+/)[0]; return w.length >= 4 && s.indexOf(' ' + w + ' ') >= 0; }) && /\bon track\b|\breach\b|\bbe reached\b|\bget there\b|\bsaved? (?:for|towards)\b|\bprogress\b|\bby when\b/.test(s))) return { act: 'goal' };
    if (/\b(?:free )?trials?\b/.test(s)) return { act: 'trials' };
    if (/\bsubscriptions?\b|\bsubs\b/.test(s) && /\bcancel|\bdrop\b|\bstop\b|\bcut\b|\bdo not (?:need|use)\b|\bunused\b|\boverlap|\bduplicate|\btoo many\b|\bget rid\b/.test(s)) return { act: 'subcancel' };
    // how many EMIs are left: the loans, each with its count ("How many EMIs are left on my iPhone?", "kitni EMI baaki hai")
    if (/\bemis?\b/.test(s) && /\b(?:left|remaining|baaki|bachi|to go|more to pay|pending)\b/.test(s) && /\bhow many\b|\bkitn[ie]\b|\bcount\b|\bnumber of\b/.test(s)) return { act: 'loans', emisLeft: true, which: (/\b(home|housing|car|bike|personal|education|gold|vehicle)\b/.exec(s) || [])[1] || '' };
    // what's left on a loan (Wealth › Debts), before a repeat of the same name: "how much is left on the car loan" asks what's owed, not its EMI
    if (/\bloans?\b/.test(s) && /\b(?:left|outstanding|remaining|balance|pending|owe|pay off|principal|still)\b/.test(s) && !/\bemis?\b|\bwhen\b/.test(s)) return { act: 'loans', which: (/\b(home|housing|car|bike|personal|education|gold|vehicle)\b/.exec(s) || [])[1] || '' };
    // a bill's amount: "light bill kitna aaya", "how much is the electricity bill", "my Simpl bill"
    // whether a bill is paid: "Is the KSEB bill paid?", "did I pay the electricity bill?"
    var bp = billPaidAsk(s);
    if (bp) return { act: 'billamt', kind: bp.kind, word: bp.word, paidQ: true };
    var bq = billAsk(s, f, ctx);
    if (bq) return { act: 'billamt', kind: bq.kind, word: bq.word };
    // what's still owed to a pay-later app or a shop ("LazyPay pe kitna baaki hai"): kosh sees what was paid, not what's owed
    if (f.merchant && !(ctx.owed || []).some(function (x) { return has(x.name, f.merchant); }) && !/\b(?:rent|tenants?)\b/.test(s) && /\bpending\b|\boutstanding\b|\bleft to pay\b|\bstill owe\b|\bowe\b|\bto repay\b/.test(s) && !/\bloans?\b|\bemis?\b|\bcards?\b/.test(s)) return { act: 'owing' };
    // interest paid on a loan: a loan question, never investments
    if (/\binterest\b/.test(s) && /\bloans?\b/.test(s) && /\bpaid\b|\bpay\b|\bhow much\b|\btotal\b/.test(s) && !/\brates?\b/.test(s)) return { act: 'loans', which: (/\b(home|housing|car|bike|personal|education|gold|vehicle)\b/.exec(s) || [])[1] || '', ask: 'interest' };
    // a repeat's price: "how much is Netflix", "Netflix kitna leta hai"; "did Spotify's price go up"
    var rep = recurringNamed(s, f, ctx);
    // "did my electricity bill go up": that kind of spending this month against last
    if (!rep && f.category && !/^Subscriptions$/.test(f.category) && /\bwent up\b|\bgone up\b|\bgo(?:ing)? up\b|\bincrease[ds]?\b|\bhike[ds]?\b|\brose\b|\brisen\b|\bcostlier\b|\bmore expensive\b/.test(s)) return { act: 'compare', bills: /\bbills?\b/.test(s) || undefined };
    if (/\bwent up\b|\bgone up\b|\bgo(?:ing)? up\b|\bincrease[ds]?\b|\bhike[ds]?\b|\brose\b|\brisen\b|\bcostlier\b|\bmore expensive\b|\bprice (?:change|rise)s?\b|\braised\b/.test(s) && (rep || /\bsubscriptions?\b|\bbills?\b|\brepeats?\b|\bprices?\b/.test(s))) return { act: 'rise' };
    if (rep && /\bcharges\b|\bcosts?\b|\bprice\b|\bhow much (?:is|does|do)\b|\bhow much (?:for|a month)\b|\bplan\b/.test(s) && !/\bspen[dt]\b|\bspending\b|\bpaid\b/.test(s) && !f.named &&
        !/\bhow much (?:money )?is (?:there )?in\b/.test(s) &&
        !(/\bloans?\b/.test(s) && /\b(?:left|outstanding|remaining|pending|balance|owe)\b/.test(s))) return { act: 'price' };
    // what's left on a loan (Wealth › Debts)
    if (/\bloans?\b/.test(s) && /\b(?:left|outstanding|remaining|balance|pending|owe|pay off|principal|still)\b/.test(s) && !/\bemis?\b|\bwhen\b/.test(s)) return { act: 'loans', which: (/\b(home|housing|car|bike|personal|education|gold|vehicle)\b/.exec(s) || [])[1] || '' };
    // rent: who hasn't paid, whether one tenant has, and what came in (rent you get, not rent you pay)
    var rentIn = /\brent\b|\blease\b/.test(s) && !/\b(?:i|we) (?:pay|paid)\b|\bmy rent\b|\bpay(?:ing)? (?:my |the |our )?rent\b(?! (?:this|last))/.test(s);
    if (/\brent\b/.test(s) && /\bwho\b.*\b(?:did not|has not|have not|not) pay|\bnot paid\b|\bunpaid\b/.test(s)) return { act: 'tool', tool: 'property', args: { late: true } };
    var tn = /\b(?:did|has|have) ([a-z]+)(?: [a-z]+)? (?:pay|paid) (?:the |his |her |their |this month's )?rent\b/.exec(s);
    if (tn && !/^(?:i|we|you|the|my|our|a)$/.test(tn[1])) return { act: 'tool', tool: 'property', args: { tenant: tn[1] } };
    if (rentIn && /\b(?:came|come|received|receive|got|get|collected|income|earned|credited|given|gave|gives|brought|brings|fetched)\b/.test(s)) return { act: 'income', category: 'Rent received' };
    // refunds still to come ("any refunds pending?", "which refunds are still due?", "am I still waiting on a refund?",
    // "kaunsa refund abhi tak nahi aaya"): the Refunds list (snap.refunds, and the shop's promises with no payment kosh
    // can see), never bills due nor the ledger's credits
    if (/\brefunds?\b/.test(s) && /\b(?:waiting|pending|late|still|due|owed|outstanding|overdue|yet to|not (?:yet )?(?:come|came|received|credited|back)|abhi tak|nahi|nahin)\b/.test(s)) return { act: 'refundsDue', shop: (/\b(?:my|the) ([a-z0-9][a-z0-9 .&'-]{1,30}?) refunds?\b/.exec(s) || [])[1] || '' };
    // refunds that came in
    if (/\brefunds?\b/.test(s) && /\b(?:get|got|any|came|come|received|credited|aaya|aayi|mila|mili)\b/.test(s) && !/\bwaiting\b|\bpending\b|\blate\b|\bstill\b|\bnot (?:yet|come)\b/.test(s)) return { act: 'income', category: 'Refund' };
    if (/\btenants?\b|\brent (?:due|pending|late|collected|received|came|from)\b|\b(?:behind|late|pending) on rent\b|\bwho (?:has not|did not) pay (?:the )?rent\b|\bproperty tax\b|\bmy propert(?:y|ies)\b/.test(s)) return { act: 'tool', tool: 'property', args: { late: /\bbehind|late|pending|owes?|has not|did not|due\b/.test(s) || undefined } };
    if (/\b(?:insurance|insured|polic(?:y|ies)|premiums?|coverage|sum assured|nominees?|term plan|health plan|mediclaim)\b/.test(s) && !/\bspen[dt]\b|\bspending\b|\bpaid\b|\bhow much (?:did|have)\b/.test(s))
      return { act: 'insurance', yearly: /\b(?:a|every|per|each) year\b|\byearly\b|\bannual(?:ly)?\b|\bin (?:a|one) year\b|\bsaal(?:ana)? (?:ka|ki|ke|bhar)\b|\b(?:per|har|ek) saal\b|\bsaalana\b/.test(s) || undefined,
               ptype: (/\b(health|mediclaim|term|ulip|life|motor|car|bike|vehicle|home|travel)\b/.exec(s) || [])[1] || undefined,
               ask: /\bcover(?:age)?\b|\bsum assured\b|\bcovered\b/.test(s) ? 'cover' : /\bwhen\b|\bdue\b|\bnext\b|\brenew/.test(s) ? 'due' : undefined };
    if (CLAIM_WORDS.test(s) && !CLAIM_CAME.test(s) && !/\binsurance|mediclaim|polic(?:y|ies)\b/.test(s)) return { act: 'tool', tool: 'claim', args: f && f.named && f.from ? { from: f.from, to: f.to } : {} };
    // a reimbursement that came ("how much reimbursement came last month"): money in that says so
    if (CLAIM_WORDS.test(s) && CLAIM_CAME.test(s) && /\breimburs/.test(s) && !/\binsurance|mediclaim|polic(?:y|ies)\b/.test(s) && !insurerNamed(s, ctx)) return { act: 'income', reimb: true };
    /* GUARDRAIL money someone sent you, asked as what they paid you ("how much did clients pay me last month", "how
       much has Ankit paid me back"): money in from them, never your spending at them. Clients and customers are the
       business's income */
    if (/\b(?:paid|pay|sent|send|transferred|returned|gave|given) (?:me|us)\b/.test(s) && !/\bi owe\b|\bdo i owe\b|\bwho owes\b|\bspen[dt]\b/.test(s) && (f.merchant || /\bclients?\b|\bcustomers?\b/.test(s)) && !(ctx.owed || []).some(function (o) { return !o.settled && f.merchant && lc(o.name || '').indexOf(f.merchant) >= 0; })) {
      var inA = { act: 'income' };
      if (/\bclients?\b|\bcustomers?\b|\binvoices?\b/.test(s)) inA.category = 'Business income';
      return inA;
    }
    if (/\bwho owes\b|\bowes? me\b|\bi owe\b|\bdo i owe\b|\blent\b|\bborrowed\b|\bpay me back\b|\bsplits?\b|\bsettle up\b/.test(s) && !/\b(?:credit )?cards?\b/.test(s)) return { act: 'owed' };
    if (/\b(?:payslips?|salary slip|form ?16|tds|26as|ais|capital gains?|tax (?:paid|deducted))\b/.test(s))
      return { act: 'tool', tool: 'papers', args: { kind: /gains?/.test(s) ? 'gains' : /payslip|salary slip/.test(s) ? 'payslip' : 'tax' } };
    // money put in, not what it's worth: "how much did I invest this year", "SIPs this month"
    if (/\bhow much (?:did|have|do) (?:i|we) (?:invest(?:ed)?|put)\b|\bhow much invested\b|\binvested (?:this|last|in)\b|\b(?:sips?|investments?) (?:this|last) (?:month|year|fy|financial year)\b|\bmoney (?:i|we) invested\b|\binvest(?:ed|ing)? (?:so far|every month|a month|per month)\b/.test(s)) return { act: 'invested' };
    // what a deposit, a bond or an account paid in interest ("how much interest did Papa's FD pay"): money that came in
    if (/\binterest\b/.test(s) && /\bhow much\b|\bpaid\b|\bpay\b|\bearn\w*\b|\bcame\b|\bcredited\b|\bgot\b|\bgive[ns]?\b|\bgave\b/.test(s) && !/\binterest rates?\b|\brate of interest\b|\bloans?\b|\bemis?\b|\bcards?\b|\bcharged\b|\bowe\b/.test(s)) return { act: 'income', category: 'Interest' };
    // a jeweller's gold savings scheme ("how much have we paid into the gold scheme"): the instalments paid to it
    if (GOLD_SCHEME_ASK.test(s) && /\bhow much\b|\bpaid\b|\bput\b|\btotal\b|\bpaying\b/.test(s)) return { act: 'goldscheme' };
    // cash put into the bank ("how much cash have I deposited"): credits the bank marks as cash, never cash spent
    if (/\bcash\b/.test(s) && /\bdeposit(?:ed|s)?\b|\bput (?:in|into)\b|\bcdm\b/.test(s) && !/\bfixed deposit|\bfds?\b/.test(s)) return { act: 'cashdep' };
    if (/\b(?:net ?worth|portfolio|investments?|invested|mutual funds?|stocks|shares|holdings?|fds?|fixed deposits?|deposits?|epf|pf|ppf|nps|provident(?: fund)?|retirement (?:savings|money|corpus|funds?)|gold|sgb|ulips?|how much (?:am i|are we) worth|maturing|matures?|wealth)\b/.test(s) && !/\bspen[dt]\b|\bspending\b|\bgold loans?\b/.test(s)) return { act: 'wealth' };
    if (/\b(?:card|cards|credit card)s? (?:dues?|outstanding|bills?|balance)\b|\b(?:how much|what) do (?:i|we) owe (?:on|to) (?:my |our )?(?:credit )?cards?\b|\boutstanding on (?:my )?cards?\b|\bcard bills? (?:this|due)\b/.test(s) && !/\bspen[dt]\b/.test(s)) return { act: 'carddue' };
    if (/\bwhere (?:can|should|could) (?:i|we) (?:cut|save|reduce|spend less)\b|\bhow (?:can|do|could) (?:i|we) (?:save|cut|spend less|reduce)\b|\bcut (?:back|down)\b|\breduce (?:my )?(?:spending|expenses)\b|\bsave more\b|\bspending less\b/.test(s)) return { act: 'cut' };
    var topN = /\btop (\d+|three|five|ten) (?:payments|expenses|spends|purchases|debits|charges|bills)\b/.exec(s);
    if (topN) return { act: 'biggest', n: /^\d+$/.test(topN[1]) ? +topN[1] : { three: 3, five: 5, ten: 10 }[topN[1]] };
    var ahead = aheadOf(s, today, ctx);
    if (/\b(?:cover|afford|do i have enough|enough (?:money|balance|in (?:my|the) accounts?)|can i pay|will i be able to pay)\b/.test(s) && /\b(?:due|bills?|pay|emi|rent|this week|next week|month|everything)\b/.test(s) && !/\bspent\b/.test(s)) {
      // nothing said about when: the next 7 days
      return { act: 'cover', ahead: ahead.def ? { from: today, to: addDays(today, 7), words: 'in the next 7 days' } : { from: today, to: ahead.to, words: ahead.words } };
    }
    if (/\b(?:due|upcoming|coming up|to pay|need to pay|have to pay|bills? (?:due|coming|pending|this (?:week|month))|pending (?:bills?|payments?|dues?)|next (?:bill|emi|sip|payment|premium|instal+ment)|next (?:credit )?card (?:bill|payment|due)|when is (?:my|the) .*(?:bill|emi|premium|rent|sip)|card bill)\b|\b(?:bills?|emis?|sips?|instal+ments?)\b.*\bwhen (?:hai|is|are)\b/.test(s) && !/\bspent\b|\bpaid\b|\blast\b/.test(s)) {
      var w0 = (/\b(credit cards?|cards?|emis?|loans?|rent|premiums?|sips?|electricity|insurance)\b/.exec(s) || [])[1] || '';
      var what = w0.replace(/^credit cards?$/, 'card').replace(/s$/, '').replace(/^loan$/, 'emi');
      // "the next one", "when is it" (not "the next 10 days", "next week")
      var nextOne = (/\bnext\b/.test(s) && !/\bnext (?:\d+|a|one|two|three|four|five|six|seven|ten|fifteen|thirty|few|couple of) (?:days?|weeks?|months?)\b|\bnext (?:week|month|fortnight)\b/.test(s)) || /\bwhen\b/.test(s);
      // a kind of loan kosh doesn't know at all ("when is the gold loan interest due"): said, not another loan's EMI
      var whichD = (/\b(home|housing|car|bike|personal|education|gold|vehicle)\b/.exec(s) || [])[1] || '';
      if (whichD && /\bloans?\b/.test(s) && !(ctx.loans || []).concat(ctx.recurring || []).some(function (l) { return new RegExp(whichD, 'i').test((l.name || '') + ' ' + (l.bank || '')); })) return { act: 'loans', which: whichD };
      return { act: 'due', ahead: ahead, what: what, next: nextOne && !/\bwhat\b|\bwhich (?:bills|payments)\b|\ball\b/.test(s) || undefined,
               which: (/\b(home|housing|car|bike|personal|education|gold)\b/.exec(s) || [])[1] || undefined };
    }
    // "Mummy ke account mein kitna paisa hai", "Kotak account mein kitna hai": what's in it, not what went out of it
    if ((/\bbalances?\b|\bhow much (?:money )?(?:do (?:i|we) have|is there|is in|have (?:i|we) got)\b|\bin (?:all )?(?:my|our|the) (?:bank )?accounts?\b|\bmoney in (?:the )?banks?\b|\bcash in hand\b/.test(s) ||
         /\b(?:accounts?|a\/c|khat[ae]|banks?) (?:mein|me|main|men|pe|par)\b.*\bhow much\b|\bhow much\b.*\b(?:accounts?|a\/c|khat[ae]) (?:mein|me|main|men)\b/.test(s)) && !/\bspen[dt]\b|\bwent\b|\bpaid\b|\bcame\b/.test(s)) return { act: 'balances' };
    if (/\b(?:subscriptions?|recurring|repeats?|repeating|every month|monthly payments?|sips?|emis|my emi|autopay|standing instructions?|regular payments?)\b/.test(s) && !/\bhow much\b.*\bspen[dt]\b|\bon subscriptions?\b/.test(s))
      return { act: 'repeats', subs: /\bsubscriptions?\b/.test(s) || undefined, kind: /\bsips?\b/.test(s) ? 'sip' : /\bemis?\b/.test(s) ? 'emi' : /\b(?:staff|household help|domestic help|maids?|cooks?|drivers?)\b/.test(s) ? 'staff' : /\bbills?\b/.test(s) ? 'bill' : undefined };
    if (/\b(?:brief me|needs me|noticed|unusual|odd|suspicious|fees|late fee|charged twice|duplicate|anything (?:wrong|off|i should)|should i (?:act|worry)|act on|alerts?|red flags?)\b/.test(s) && !/\bhow much\b|\btotal\b/.test(s)) return { act: 'noticed' };
    if (/\b(?:save|saved|saving|savings rate|kept|keep rate|left over|leftover|surplus)\b/.test(s) && !/\bsavings? accounts?\b/.test(s)) return { act: 'saved' };
    if (/\bbudget\b|\bon track\b|\bover ?spen(?:d|t|ding)\b|\bovershoot\b|\bpace\b|\bhow much (?:can|should) i (?:still )?spend\b|\bleft to spend\b|\bhow am i doing\b|\bhow is (?:the|this) month (?:going|looking)\b/.test(s)) return { act: 'pace' };
    // money in from a payee, asked with when ("LIC maturity ka paisa kab aaya"): the last that came
    if (f.merchant && /\bwhen\b/.test(s) && /\b(?:came|come|credited|received)\b/.test(s) && !/\bspen[dt]\b|\bpaid\b/.test(s)) return { act: 'last' };
    if (/\b(?:income|salary|earned|earn|earnings|came in|money in|inflow)\b/.test(s) && /\btrend\b|\bmonth by month\b|\bmonth on month\b|\beach month\b|\bover (?:the )?(?:last|past) \w+ months\b/.test(s)) return { act: 'trend', what: 'income' };
    /* GUARDRAIL money in from a name kosh has no payee for ("how much came from Payoneer this year"): money from that
       name, said plainly when none came, never all money in given as theirs */
    var fromX = /\b(?:came|come|received|credited|got|get)\b/.test(s) && !f.merchant && !f.category && !f.person && /\bfrom ([a-z][a-z0-9]{2,})\b/.exec(s);
    if (fromX && !STOP[fromX[1]] && !HI_STOP[fromX[1]] && !NOT_GIVER[fromX[1]] && !new RegExp('^' + MRE + '$').test(fromX[1]) && !/^(?:abroad|outside|india|work|job|office|freelanc\w*|fds?|deposits?|savings?|investments?|sips?|funds?|shares|stocks|insurance|tax|govt|loan|loans)$/.test(fromX[1]) &&
        !BANK_ALIAS.some(function (B) { return B.q.test(' ' + fromX[1] + ' '); }) && !personOf2(fromX[1], ctx)) return { act: 'from', who: cap1(fromX[1]), word: fromX[1] };
    if (/\b(?:income|salary|earned|earn|earnings|came in|came|received|credited|got paid|interest|dividends?|cashback|money in|inflow|refunds? (?:came|received|got)|(?:get|got|receive) from)\b/.test(s) && !/\bspen[dt]\b|\bspending\b|\bpaid to\b|\bwhen\b|\blast (?:time|credit|one)\b/.test(s))
    {
      var kindIn = /\binterest\b/.test(s) ? 'Interest' : /\bdividends?\b/.test(s) ? 'Dividend' : /\bcashback\b/.test(s) ? 'Cashback' : '';
      return kindIn ? { act: 'income', category: kindIn } : { act: 'income' };
    }
    if (/\baverage\b|\bavg\b|\bper (?:day|week|month|order|ride|visit)\b|\ba (?:day|week)\b|\bdaily (?:spend|spending|average)\b|\b(?:usual|normal|typical|regular) (?:month|spend|spending|amount)\b|\busually spend\b|\bnormally spend\b|\btoo much\b|\bhow much do (?:i|we) (?:usually |normally |generally )?spend\b(?!.*\b(?:last|this|today|yesterday|in (?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)))|\bevery month\b.*\bspend\b|\bspend\b.*\bevery month\b|\bis (?:that|this|it) (?:a lot|normal|ok|high|much)\b/.test(s))
      return { act: 'avg', unit: /\baverage (?:[a-z]+ )?(?:order|bill|ride|payment|ticket|visit|trip)s?\b|\bper (?:order|ride|visit)\b|\beach order\b/.test(s) ? 'order' : /\bday\b|\bdaily\b/.test(s) ? 'day' : /\bweek\b|\bweekly\b/.test(s) ? 'week' : 'month' };
    if (/\bcompared? (?:to|with)\b|\bcompare\b|\bvs\b|\bversus\b|\b(?:more|less) than (?:last|usual|before|the month)\b|\b(?:more|less|costlier|cheaper|higher|lower|more expensive)\b(?:(?!\bthan\b).)*\bthan (?:in )?(?:the month before|(?:last|this) (?:month|year|week)|(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*)\b|\bwhat (?:is|has|have)? ?changed\b|\bwhy (?:is|was|did|are|am|has)\b.*\b(?:higher|more|up|lower|less|down|so much|high|low)\b|\bhow come\b|\bdifference\b/.test(s) || f.merchant2) return { act: 'compare' };
    if (/\btrend\b|\bmonth by month\b|\bmonth on month\b|\bmonthly trend\b|\bover (?:the )?(?:last|past) (?:\d+|[a-z]+) months\b|\beach month\b|\bevery month\b|\bover time\b|\bhistory\b/.test(s)) return { act: 'trend' };
    // rankings: who or what came top
    if (/\bwho (?:in (?:the|my) (?:family|household) )?(?:spends?|spent|is spending|spending) (?:the )?most\b|\bwhich of us\b/.test(s)) return { act: 'rank', by: 'person' };
    if (/\bwho (?:did|do|have|has) (?:i|we) (?:pay|paid|send|sent|give|gave|transfer|transferred)\b|\bwho (?:got|gets|received|receives|took|takes) (?:the )?most\b|\bwho (?:am i|are we) paying\b|\bpaid (?:the )?most (?:to|money to)\b|\bmost (?:money|payments?) (?:to|went to)\b|\b(?:top|biggest|main|largest|frequent)(?: \d+| (?:five|ten|three))? (?:payees?|merchants?|shops?|stores?|places?|brands?|vendors?|restaurants?|apps?|people)\b|\bwhich (?:shops?|stores?|merchants?|places?|apps?|brands?|vendors?|restaurants?|payees?|person|people|companies)\b|\bwhere (?:do|did|have) (?:i|we) (?:spend|spent|shop|order|ordered|buy|bought)\w* (?:the )?most\b|\bwho (?:do|did) i (?:order|buy) from (?:the )?most\b|\bby (?:payee|merchant|shop|store|place)\b/.test(s)) return { act: 'rank', by: 'payee', shops: /\b(?:shops?|stores?|merchants?|places?|apps?|brands?|vendors?|restaurants?|companies)\b|\bwhere (?:do|did|have) (?:i|we)\b|\border\b|\bbuy\b|\bbought\b/.test(s) || undefined };
    if (/\bwhich categor|\bwhat categor|\bwhat (?:do|did|have) (?:i|we) (?:spend|spent) (?:the )?most (?:on|money on)\b|\b(?:top|biggest|main)(?: \d+| (?:five|ten|three))? (?:spending )?categor|\bby categor|\bper categor|\bcategory ?wise\b|\bwhere (?:did|does|has|is|do) (?:all )?(?:my|our|the) money go(?:ne|ing)?\b|\bbreak ?down\b|\bsplit\b|\bwhat (?:did|do) i spend (?:it |my money )?on\b|\bwhat (?:am i|are we) spending on\b|\bspent on what\b|\bon what\b.*\bspent\b/.test(s)) return { act: 'rank', by: 'category' };
    if (/\bwhich (?:credit )?card\b|\bby card\b|\bcard (?:do|did) i use (?:the )?most\b|\bmost used card\b/.test(s)) return { act: 'rank', by: 'card' };
    if (/\bhow (?:do|did) (?:i|we) (?:usually |mostly )?pay\b|\bupi or card\b|\bcard or upi\b|\bpayment (?:methods?|modes?)\b|\bby (?:payment )?(?:method|mode)\b/.test(s)) return { act: 'rank', by: 'method' };
    if (/\bwhich (?:day|days)\b|\bwhat day of\b|\bday of (?:the )?week\b|\bweekends? (?:or|vs|versus) weekdays?\b|\bweekdays? (?:or|vs|versus) weekends?\b/.test(s)) return { act: 'rank', by: 'weekday' };
    if (/\bwhich month\b|\bwhat month\b|\b(?:biggest|costliest|most expensive|worst|best|cheapest) month\b/.test(s)) return { act: 'rank', by: 'month' };
    // one payment: "biggest payment", "biggest Amazon order", "largest single purchase"
    if (/\b(?:biggest|largest|highest|most expensive|costliest|priciest|smallest|cheapest|lowest)\s+(?:single |one |ever |)(?:[a-z]+ ){0,2}(?:payments?|expenses?|spends?|purchases?|bills?|orders?|debits?|charges?|buys?|items?)\b|\bmost (?:i|we) (?:have )?(?:spent|paid) (?:at once|in one go|on one|at one go)\b|^ (?:what is |what was )?(?:my |the )?(?:biggest|largest) (?:one )?$/.test(s)) return { act: 'biggest' };
    if (/\b(?:when|what day) (?:did|was|were) (?:i|we|my)\b.*\blast\b|\blast time (?:i|we)\b|\bwhen (?:did|was) (?:i|we|my) (?:last )?(?:pay|paid|order|ordered|buy|bought|go|went|visit|spend|spent|recharge|refuel|fill|get|send|sent|transfer)\b|\b(?:my |the )?(?:last|latest|most recent) (?:payment|spend|expense|order|purchase|debit|credit|transfer)\b|\bwhen (?:did|was) .* last\b|\bwhen (?:did|does|was|is) (?:my |the |[a-z]+'s )?(?:salary|rent|refund|interest|dividend|bonus)\b.*\b(?:come|came|credited|received|paid|in)\b/.test(s)) return { act: 'last' };
    if (/\bhow many (?:times|payments|orders|purchases|visits|debits|rides)\b|\bhow often\b|\bnumber of (?:payments|orders|times|rides)\b|\bhow many (?:\w+ ){0,3}(?:did i|have i|do i)\b/.test(s)) return { act: 'count' };
    if ((f.min || f.max) && /\b(?:payments|spends?|expenses?|debits?|purchases?|orders?)\b/.test(s) && !/\bhow (?:much|many)\b/.test(s)) return { act: 'list', sort: 'amount' };
    if (/\b(?:show|list|see|display|give me|pull up|find|search)\b.*\b(?:payments|spends?|expenses?|orders?|purchases?|debits?|credits?|charges?|them|those|it|all)\b|\bwhat (?:did|have) (?:i|we) (?:buy|bought|pay for|order|ordered)\b|\b(?:recent|latest|last few|last \d+) (?:payments|spends|expenses|orders|purchases)\b|^ (?:my |all |the )?payments (?:on|from|between|since|made|in|this|last)\b/.test(s)) return { act: 'list' };
    // a total is asked with a verb of spending; "how much" alone is not one (it may be about anything)
    if (/\bspen[dt]\b|\bspending\b|\bspends\b|\bexpenses?\b|\bexpenditure\b|\bpaid\b|\bpay\b|\bcost\b|\bcosts\b|\bbought\b|\bpurchases?\b|\border(?:ed|s)?\b|\bouts?go(?:ing)?\b|\bburn(?:ed|t)?\b|\bwent\b|\bgone on\b|\bwasted?\b/.test(s)) return { act: 'total' };
    return null;
  }
  /* "by May 2027", "by March", "in 8 months", "by next year": the day to reach something by (the end of that month) */
  function byDateOf(s, today) {
    var y = +today.slice(0, 4), mo = +today.slice(5, 7), n;
    if ((n = new RegExp('\\b(?:by|before|till|until|in) (?:end of |the end of )?' + MRE + '(?: (20\\d{2}))?\\b').exec(s))) {
      var mi = monIx(n[1]), yy = n[2] ? +n[2] : (mi + 1 > mo ? y : y + 1);
      return monthEnd(yy + '-' + pad(mi + 1) + '-01');
    }
    if ((n = /\bin (\d+) (months?|years?)\b/.exec(s))) return addDays(today, Math.round(+n[1] * (/^year/.test(n[2]) ? 365.25 : 30.44)));
    if ((n = /\bby (20\d{2})\b/.exec(s)) && +n[1] >= y) return n[1] + '-12-31';
    if (/\bby next year\b|\bin a year\b/.test(s)) return addDays(today, 365);
    return '';
  }
  /* the repeat a question names ("netflix", "spotify"), from the payee it names */
  function recurringNamed(s, f, ctx) {
    var p = f && (f.merchant || '');
    if (!p) return null;
    return (ctx.recurring || []).filter(function (r) { return lc(r.name).indexOf(p) >= 0; }).sort(function (a, b) { return (b.seen || 0) - (a.seen || 0); })[0] || null;
  }
  /* the insurer a question names, by the word its name is known by ("star" for Star Health, "lic", "suraksha"), from
     the policies kosh knows; '' when none */
  function insurerWord(p) { return lc(p.insurer || '').replace(/\b(?:life|health|general|insurance|co|company|ltd|limited|of|india|the|and|allied|&)\b/g, ' ').trim().split(/\s+/)[0] || ''; }
  function insurerNamed(s, ctx) {
    var hit = '';
    (ctx.policies || []).some(function (p) { var w = insurerWord(p); if (w.length >= 3 && s.indexOf(' ' + w + ' ') >= 0) { hit = w; return true; } return false; });
    return hit;
  }
  /* who a question says sent money: "how much has Amit sent us", "Amit ne kitne paise bheje", "how much does Nirav give
     every month", "how much came from Papa". Someone in the household by name or by how they're related, or a name the
     household doesn't have; null when no one is named as the giver */
  var NOT_GIVER = { salary: 1, pension: 1, bank: 1, money: 1, company: 1, employer: 1, office: 1, tenant: 1, tenants: 1, someone: 1, anyone: 1, everyone: 1, family: 1, she: 1, they: 1, them: 1, who: 1, kosh: 1, interest: 1, refund: 1, insurance: 1, clients: 1, client: 1, customers: 1, customer: 1, flat: 1, house: 1, property: 1, shop: 1, business: 1, govt: 1, government: 1 };
  function senderOf(s, ctx) {
    if (/\b(?:rent|interest|dividends?|salary|pension|refunds?|cashback)\b/.test(s)) return null;
    var cand = [], m;
    var GIVE = '(?:sent|send|sends|sending|gave|give|gives|given|giving|transferred|transfers|transfer)';
    var re1 = new RegExp('\\b(?:has|have|did|does|do|will|would) (?:my |our |the )?([a-z]{3,}) (?:[a-z]+ )?(?:' + GIVE + '\\b|(?:paid|pay|returned|return) (?:us|me)\\b)', 'g');
    while ((m = re1.exec(s))) cand.push(m[1]);
    // "Amit ne bheje": "ne" marks who did it (sent, gave; paid only of money: "kitne paise diye")
    if (/\bsent\b|\bgave\b|\bgiven\b|\btransferred\b|\bmoney paid\b|\bmoney given\b/.test(s)) { var re2 = /\b([a-z]{3,}) ne\b/g; while ((m = re2.exec(s))) cand.push(m[1]); }
    var re3 = /\b([a-z]{3,}) (?:sends|gives|transfers)\b/g;
    while ((m = re3.exec(s))) cand.push(m[1]);
    var fromHH = /\b(?:came|come|got|get|received|receive|credited)\b/.test(s) ? (s.match(/\b(?:from|se) ([a-z]{3,})\b/g) || []).map(function (x) { return x.split(' ')[1]; }) : [];
    var people = (ctx.people || []).filter(function (p) { return p.id !== 'me'; });
    var personOf = function (w) {
      return people.filter(function (p) { var kin = KIN[lc(p.rel || '')]; return lc(p.name) === w || lc(p.full || '').split(/\s+/)[0] === w || (kin && kin.test(' ' + w + ' ')); })[0] || null;
    };
    for (var i = 0; i < cand.length + fromHH.length; i++) {
      var w = i < cand.length ? cand[i] : fromHH[i - cand.length], hh = i >= cand.length;
      if (STOP[w] || HI_STOP[w] || NOT_GIVER[w]) continue;
      var p = personOf(w);
      if (p) return { name: p.name, id: p.id };
      if (!hh && !/^(?:mom|mum|mummy|mother|maa|dad|papa|father|wife|husband|son|daughter|brother|sister|bhai|didi)$/.test(w)) return { name: cap1(w) };
    }
    return null;
  }
  /* a bill's amount, asked: "how much is the electricity bill", "light bill kitna aaya" (made "electricity bill how much
     is"), "my Simpl bill right now". Not a card's bill, not what was paid over a stretch, not what's due in a window */
  var BILL_KIND = [
    ['electricity', /\belectric\w*\b|\bpower\b|\benergy\b/, /electric|power|energy|bijli|discom|mseb|msedcl|bescom|bses|tneb|tangedco|kseb|hescom|gescom|mescom|cescom|apspdcl|apepdcl|tsspdcl|tgspdcl|wbsedcl|jvvnl|avvnl|pspcl|uppcl|dhbvn|uhbvn|tpddl|bypl|brpl|cesc|torrent|tata power|adani electricity/i, /^electricity$/i],
    ['water', /\bwater\b/, /\bwater\b|\bjal\b/i, /^water$/i],
    ['gas', /\b(?:piped )?gas\b|\bpng\b/, /\bgas\b|\bpng\b/i, /\bgas\b/i],
    ['internet', /\binternet\b|\bbroadband\b|\bwi-?fi\b|\bfib(?:er|re)\b/, /broadband|fib(?:er|re)|internet/i, /internet|broadband/i],
    ['mobile', /\bmobile\b|\bpostpaid\b/, /postpaid|mobile/i, /mobile|phone/i],
    ['maintenance', /\bmaintenance\b|\bsociety\b/, /maintenance|society|\bsoc\b|\bhsg\b/i, /maintenance|society/i],
  ];
  /* GUARDRAIL "Is the KSEB bill paid?": one bill's paid or not, yes or no (a card's bill is the card's question) */
  function billPaidAsk(s) {
    if (/\bcards?\b|\bcredit\b|\bemis?\b|\bloans?\b|\brent\b/.test(s)) return null;
    var m = /\b(?:is|was|has|have|are) (?:my |our |the |this month'?s? |last month'?s? )?([a-z][a-z0-9 ]{1,30}?) bills? (?:been |got |already )?paid\b/.exec(s) || /\bdid (?:i|we) pay (?:my |our |the |this month'?s? )?([a-z][a-z0-9 ]{1,30}?) bills?\b/.exec(s);
    if (!m) return null;
    var what = m[1].trim(), kind = '';
    for (var i = 0; i < BILL_KIND.length; i++) if (BILL_KIND[i][1].test(what)) { kind = BILL_KIND[i][0]; break; }
    var w = what.split(' ').filter(function (x) { return x.length >= 3 && !STOP[x] && !HI_STOP[x] && !/^(?:my|our|the|this|last|month|monthly)$/.test(x); })[0] || '';
    return kind || w ? { kind: kind, word: kind ? '' : w } : null;
  }
  function billAsk(s, f, ctx) {
    if (!/\bbills?\b/.test(s) || /\bcards?\b|\bcredit\b/.test(s)) return null;
    if (/\bspen[dt]\b|\bspending\b|\bpaid\b|\bdid (?:i|we) pay\b|\bwent up\b|\bgone up\b|\bgo(?:ing)? up\b|\bincrease|\bhike|\bdue (?:this|next|in|on)\b|\bnext \d+\b|\bwhat bills\b|\bwhich bills\b|\ball (?:my |our |the )?bills\b|\bbills (?:due|coming|pending)\b|\bupcoming\b|\bwhen\b/.test(s)) return null;
    if (!/\bhow much\b|\bwhat (?:is|was|are) (?:my|our|the|this)\b|\bright now\b|\bamount\b/.test(s)) return null;
    var kind = '';
    for (var i = 0; i < BILL_KIND.length; i++) if (BILL_KIND[i][1].test(s)) { kind = BILL_KIND[i][0]; break; }
    var bw = /\b([a-z][a-z0-9]{2,}) bills?\b/.exec(s);
    var word = !kind && bw && !STOP[bw[1]] && !HI_STOP[bw[1]] && !/^(?:my|our|the|this|last|month|monthly|total|phone|current|latest|recent|pending)$/.test(bw[1]) ? bw[1] : '';
    return kind || word ? { kind: kind, word: word } : null;
  }
  /* the loans' EMIs (Wealth › Debts, with the day they go) that the calendar doesn't already carry: this month's or
     next month's, and the one after */
  /* the payment that looks like rent: the same amount to one person (not a firm) on about the same day, three months
     or more in the last seven; the biggest of those */
  function rentGuess(ctx, today) {
    var since = addDays(today, -213), g = {};
    (ctx.tx || []).forEach(function (t) {
      if (t.k !== 'out' || !(t.a >= 1000) || t.d < since || t.d > today) return;
      if (/^(?:Bills|EMI|Investments|Subscriptions|Insurance|Tax|Education|Groceries|Food & Drinks|Shopping|Transport|Travel|Medical|Card Payments?)$/i.test(t.c || '')) return;
      var k = lc(t.m).trim();
      if (/\b(?:ltd|pvt|limited|llp|bank|insurance|finance|services|technolog\w*|retail|stores?|mart|pay|india|com|enterprises?|traders?|school|trust|society)\b/.test(k) || !isPerson(k, ctx) && !/^[a-z]+ [a-z]+$/.test(k)) return;
      (g[k] = g[k] || []).push(t);
    });
    var best = null;
    Object.keys(g).forEach(function (k) {
      // the amount paid most often (rent beside smaller payments to the same person), the bigger on a tie
      var rows = g[k], amt = 0, most = 0;
      rows.forEach(function (r) { var c = rows.filter(function (t) { return Math.abs(t.a - r.a) <= r.a * 0.02; }).length; if (c > most || (c === most && r.a > amt)) { most = c; amt = r.a; } });
      var same = rows.filter(function (t) { return Math.abs(t.a - amt) <= amt * 0.02; }), months = {};
      same.forEach(function (t) { months[t.d.slice(0, 7)] = 1; });
      var days = same.map(function (t) { return +t.d.slice(8, 10); }), spread = days.length ? Math.max.apply(null, days) - Math.min.apply(null, days) : 99;
      if (Object.keys(months).length >= 3 && spread <= 6 && (!best || amt > best.amt)) {
        var srt = same.slice().sort(byDate);
        best = { name: srt[0].m, amt: amt, day: Math.round(median(days)), n: same.length, since: srt[srt.length - 1].d, rows: srt };
      }
    });
    return best;
  }
  function loanDue(ctx, today) {
    var ag = ctx.agenda || [], out = [];
    (ctx.loans || []).forEach(function (l) {
      var day = +l.day || 0, emi = +l.emi || 0;
      if (l.active === false || !(emi > 0) || !(day >= 1 && day <= 31)) return;
      var clamp = function (mo) { return mo + '-' + pad(Math.min(day, +monthEnd(mo + '-01').slice(8))); };
      var d = clamp(today.slice(0, 7));
      if (d < today) d = clamp(addDays(monthEnd(today), 1).slice(0, 7));
      var same = function (a) { return Math.abs((+a || 0) - emi) <= emi * 0.02; };
      if (ag.some(function (x) { return x.kind !== 'in' && x.date && Math.abs(daysBetween(x.date, d)) <= 6 && same(x.amt); }) ||
          (ctx.recurring || []).some(function (r) { return !r.lapsed && r.kind === 'emi' && same(r.amount); })) return;
      [d, clamp(addDays(monthEnd(d), 1).slice(0, 7))].forEach(function (dd) { out.push({ date: dd, name: l.name + ' EMI', amt: emi, sub: '', kind: 'out', booked: false, cat: 'EMI' }); });
    });
    return out;
  }
  function understand(q, ctx, prev) {
    var today = ctx.today, s = norm(q), words = s.trim().split(' ').filter(Boolean);
    if (!s.trim()) return { act: 'clarify' };
    // a word or two that asks what was meant
    if (/^ (?:what|wat|wut|huh|hmm+|eh|sorry|pardon|what do you mean|what does that mean|meaning|i do not understand|did not get (?:it|that)|explain|explain that|come again|again|\?+) $/.test(s)) return { act: 'clarify' };
    if (/^ (?:hi|hii+|hello|hey|hey there|namaste|good (?:morning|afternoon|evening)|yo|sup) $/.test(s)) return { act: 'hello' };
    if (/^ (?:thanks|thank you|thanks a lot|thx|ty|ok|okay|cool|great|nice|perfect|got it|awesome|fine|good|alright|k) $/.test(s)) return { act: 'thanks' };
    if (/^ (?:help|what can you do|what can i ask(?: you)?|how does this work|what do you know|what are you|who are you) $/.test(s)) return { act: 'help' };

    var f = slotsOf(s, ctx, today), a = actOf(s, f, today, ctx);
    // a short follow-up to a decision ("what if it earns 8%?", "and 5 lakh?", "with 25% down", or the loan's figures
    // kosh asked for: "20 lakh at 8.5%"): the same decision, that changed. A ledger question with a number in it
    // ("payments above 5000", "show transactions over 10000") stays a ledger question; "with" carries on only before a
    // down payment, a rate, a tenure or an EMI.
    if (prev && prev.act === 'decide' && !(a && a.act === 'decide') && decideAPI() &&
        /\bwhat if\b|\bif\b|\binstead\b|\bwhat about\b|\bhow about\b|^ and\b|\btry\b|\bmake it\b|\bsay\b|\bagar\b|\bsuppose\b|\bwith (?:a |an |the )?(?:₹?\d|down\b|emi\b)|\bat \d|\bemi\b|^ ₹?\d[\d.]*%? $|^ ₹?\d+ (?:years?|months?) $/.test(s) &&
        !/\bspen[dt]\b|\bpaid\b|\bspending\b|\bpayments?\b|\btransactions?\b|\bshow\b|\blist\b|\babove\b|\bover\b|\bbelow\b|\bunder\b|\bbought\b/.test(s)) {
      var fu = decideAPI().followUp(s, prev);
      // (the question it carries on from, so a saved decision keeps the one that started it)
      if (fu) return { act: 'decide', kind: fu.kind, args: fu.args, q: q, first: prev.first || prev.q };
    }
    if (a && a.act === 'decide') return { act: 'decide', kind: a.kind, args: a.args, q: q };
    if (a && a.act === 'none') return a.topic ? { act: 'none', q: q, topic: a.topic } : { act: 'none', q: q, merchant: f.merchant, category: f.category, decide: true };
    if (f.kin && (!a || /^(?:total|compare|rank|avg|count|list|biggest|last|income|pace|balances|sent)$/.test(a.act))) return { act: 'none', q: q, topic: 'kin', kin: f.kin };
    var follow = prev && prev.act && !/^(?:clarify|hello|thanks|help|none)$/.test(prev.act);
    var marker = /^ (?:and|what about|how about|ok and|okay and|also|same for|same|then|now|but|for|in|on|at|by|only|just|vs|versus|so) /.test(s);
    var showThem = /\b(?:show|list|see) (?:them|those|these|it|all|me those|me them|me these|the payments|these payments|those payments)\b|\bwhich (?:ones|payments)\b|\bwhat were (?:they|those)\b|\bbehind (?:it|that|this)\b|^ (?:the )?payments $/.test(s);
    var why = /^ why\b|\bwhy (?:so|is that|is it|was it|did it|that)\b|\bhow come\b/.test(s);
    var more = /^ (?:more|show more|the rest|rest|all of them|all|everything|full list|next) $/.test(s);
    var byOnly = /^ (?:(?:and |now |split |break it down |broken down )?(?:by|per) (?:category|categories|payee|payees|merchant|merchants|shop|shops|card|cards|person|people|month|months|day|method|mode) )$/.exec(s);

    if (follow && (showThem || more || why)) {
      var g = JSON.parse(JSON.stringify(prev));
      if (f.named) { g.from = f.from; g.to = f.to; g.named = true; g.label = f.label; }
      if (why) return Object.assign(g, { act: 'compare' });
      if (more && /^(?:list|rank|biggest)$/.test(g.act)) { g.n = Math.max(15, (g.n || 5) * 3); return g; }
      // the payments behind it: behind a ranking, the top one's
      if (g.act === 'rank' && g.top) { if (g.by === 'payee') g.merchant = g.top; else if (g.by === 'category') { if (g.top === '(unnamed)') g.unnamed = true; else g.category = g.top; } else if (g.by === 'person') g.person = g.top; else if (g.by === 'card') g.card = g.top; }
      // the same stretch the answer was about
      if (!g.named && g.from) { g.named = true; g.label = ''; }
      return Object.assign(g, { act: 'list', n: 15, sort: g.act === 'biggest' ? 'amount' : 'date' });
    }
    if (follow && byOnly) {
      var b = { category: 'category', categories: 'category', payee: 'payee', payees: 'payee', merchant: 'payee', merchants: 'payee', shop: 'payee', shops: 'payee', card: 'card', cards: 'card', person: 'person', people: 'person', month: 'month', months: 'month', day: 'weekday', method: 'method', mode: 'method' }[byOnly[0].trim().split(' ').pop()];
      var h = JSON.parse(JSON.stringify(prev));
      if (b === 'category' && h.category) b = 'payee';
      // splitting one payee's payments by payee (or a category's by category) says nothing: the split is of everything
      if ((b === 'category' || b === 'payee') && h.merchant) delete h.merchant;
      return Object.assign(h, { act: 'rank', by: b, n: undefined, top: undefined });
    }
    if (follow && !a && (marker || words.length <= 5) && (f.named || hasSubject(f))) {
      // "and last month?", "what about swiggy?", "only upi": the question before, with this changed
      var c = JSON.parse(JSON.stringify(prev));
      if (f.named) { c.from = f.from; c.to = f.to; c.named = true; c.label = f.label; }
      if (f.merchant || f.category || f.person || f.forName) { delete c.merchant; delete c.merchants; delete c.merchant2; delete c.category; delete c.person; delete c.person2; delete c.forName; delete c.forWho; delete c.billKind; }
      SUBJECT.forEach(function (k) { if (f[k] !== undefined) c[k] = f[k]; });
      if (f.order) c.order = f.order;
      delete c.top;
      return c;
    }
    if (!a) {
      // nothing asked, but a payee, a category or a period named: what went there
      if ((f.min || f.max) && /\b(?:payments|spends?|expenses?|debits?|purchases?|orders?|anything)\b/.test(s)) a = { act: 'list', sort: 'amount' };
      else if (f.merchant || f.category || f.person || f.method || f.card) a = { act: 'total' };
      else if (f.named && words.length <= 4) a = { act: 'total' };
      else return { act: 'none', q: q, merchant: f.merchant, category: f.category };
    }
    // "what did I spend on transport", "...on weekends": the total on it, not a ranking of one
    if (a.act === 'rank' && a.by === 'category' && (f.category || f.weekend) && !/\bby categor|\bsplit|\bbreak ?down|\bcategory ?wise|\bwhich categor|\bper categor/.test(s)) a = { act: 'total' };
    var out = Object.assign(f, a);
    // "how much is my salary", "how much pension does Mummy get": what usually comes, not what came this month
    // ("how much is Meena's salary", and "Meena salary how much" as Hinglish puts it, "Meena salary kitna")
    if (out.act === 'income' && !f.named && (f.category || f.person) && /\bhow much (?:is|are|was) (?:my|our|his|her|their|the|[a-z]+'s)\b|\bhow much is $|\b(?:salary|pension|stipend) how much(?: is| was)? $|\bhow much (?:[a-z]+ )?(?:do|does) (?:i|we|he|she|they|[a-z]+) (?:get|earn|receive|draw|make)\b|\b(?:every|each|per|a) month\b|\bmonthly\b/.test(s)) out.usual = true;
    // "compare my spending with my wife's": two people over the same stretch
    if (out.act === 'compare' && f.person && f.person !== 'me' && /\bmy (?:spending|spends?|expenses?)\b|\bme\b|\bmine\b|\bmyself\b/.test(s)) { out.person2 = f.person; out.person = 'me'; }
    // a short question that names no subject, straight after one that did, is about the same thing
    if (follow && !hasSubject(f) && words.length <= 5 && /^(?:total|compare|trend|rank|avg|count|list|biggest)$/.test(out.act)) {
      SUBJECT.forEach(function (k) { if (prev[k] !== undefined && out[k] === undefined) out[k] = prev[k]; });
      if (!f.named && prev.named) { out.from = prev.from; out.to = prev.to; out.named = true; out.label = prev.label; }
      if (out.act === 'rank' && out.by === 'category' && out.category) out.by = 'payee';
    }
    out.q = q;
    return out;
  }

  /* ------------------------------------------------------------ the words */
  var DOW = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
  function dowOf(iso) { var t = dayOf(iso); return isFinite(t) ? (new Date(t).getUTCDay() + 6) % 7 : -1; }
  /* "today", "yesterday", "Fri 9 Oct"; a month alone is "January 2027"; no day at all is '' */
  function on(iso, today) {
    var s = String(iso == null ? '' : iso), td = String(today == null ? '' : today);
    if (isMonth(s)) return MONF[+s.slice(5, 7) - 1] + (s.slice(0, 4) !== td.slice(0, 4) ? ' ' + s.slice(0, 4) : '');
    if (!isDay(s)) return '';
    s = s.slice(0, 10);
    if (s === td) return 'today';
    if (s === addDays(td, -1)) return 'yesterday';
    return (DOW[dowOf(s)] || '').slice(0, 3) + ' ' + dShort(s) + (s.slice(0, 4) !== td.slice(0, 4) ? ' ' + s.slice(0, 4) : '');
  }
  /* a shop's beat as the build worked it out (engine/21o, ctx.rhythms, by each payment's rh): "every week", its next day
     and usual sum. The beat of the rows asked about, when most of them share one; else none, and the answer counts gaps
     itself as before */
  var EVERY_WORDS = { 'twice a week': 'twice a week', week: 'every week', fortnight: 'every two weeks', month: 'every month', 'two months': 'every two months', quarter: 'every three months', 'half year': 'every six months', year: 'every year' };
  function beatOf(rows, ctx) {
    var by = {}, top = '', n = 0;
    (rows || []).forEach(function (t) { if (t.rh) { by[t.rh] = (by[t.rh] || 0) + 1; if (by[t.rh] > n) { n = by[t.rh]; top = t.rh; } } });
    if (!top || n * 2 < (rows || []).length) return null;
    return (ctx.rhythms || []).filter(function (r) { return r.id === top; })[0] || null;
  }
  function beatWords(r, today) {
    var w = (EVERY_WORDS[r.every] || 'about every ' + r.days + ' days');
    var out = 'On a steady beat: ' + w + (r.n ? ' (' + r.n + ' times)' : '');
    if (r.quiet) return out + ', though not since ' + on(r.last, today) + '.';
    if (r.next) out += '; the next is due about ' + on(r.next, today);
    if (r.usual > 0) out += ', usually ' + inr(r.usual);
    return out + '.';
  }
  /* "today", "yesterday", "on Fri 9 Oct", "in January 2027" */
  function at(iso, today) { var w = on(iso, today); return !w ? '' : w === 'today' || w === 'yesterday' ? w : isMonth(iso) ? 'in ' + w : 'on ' + w; }
  function monthEnd(iso) { var s = String(iso == null ? '' : iso); if (!DAY_RE.test(s)) return ''; var y = +s.slice(0, 4), m = +s.slice(5, 7); return addDays(m === 12 ? (y + 1) + '-01-01' : y + '-' + pad(m + 1) + '-01', -1); }
  function monthWord(m, today) { var s = String(m == null ? '' : m); return (MONF[+s.slice(5, 7) - 1] || '') + (s.slice(0, 4) !== String(today || '').slice(0, 4) ? ' ' + s.slice(0, 4) : ''); }
  /* "this month", "in September", "last week", "in the last 30 days", "from 2 Sep to 9 Oct" */
  function spanWords(p, today) {
    if (p.label) return p.label;
    var from = p.from || '', to = p.to || today;
    if (!from) return 'so far';
    if (from === to) return from === today ? 'today' : from === addDays(today, -1) ? 'yesterday' : 'on ' + on(from, today);
    if (from.slice(8) === '01' && from.slice(0, 7) === to.slice(0, 7)) {
      if (from.slice(0, 7) === today.slice(0, 7)) return 'this month';
      return to === monthEnd(from) ? 'in ' + monthWord(from.slice(0, 7), today) : 'from 1 to ' + dShort(to);
    }
    if (to === today) return 'in the last ' + (daysBetween(from, today) + 1) + ' days';
    return 'from ' + dShort(from) + ' to ' + dShort(to) + (to.slice(0, 4) !== today.slice(0, 4) ? ' ' + to.slice(0, 4) : '');
  }
  /* what the stretch before is called, for "₹2,100 more than …" */
  function beforeWords(b, a, today) {
    var aw = a.from && a.from.slice(8) === '01' && a.from.slice(0, 7) === (a.to || today).slice(0, 7);
    if (aw && b.from.slice(8) === '01') return b.to === monthEnd(b.from) ? monthWord(b.from.slice(0, 7), today) : 'the same days of ' + monthWord(b.from.slice(0, 7), today);
    // whole months before whole months: "Apr–Jun"
    if (b.from.slice(8) === '01' && addDays(b.to, 1).slice(8) === '01' && b.from.slice(0, 7) !== b.to.slice(0, 7))
      return MON3[+b.from.slice(5, 7) - 1] + (b.from.slice(0, 4) !== b.to.slice(0, 4) ? ' ' + b.from.slice(0, 4) : '') + '–' + MON3[+b.to.slice(5, 7) - 1] + (b.to.slice(0, 4) !== today.slice(0, 4) ? ' ' + b.to.slice(0, 4) : '');
    var nb = daysBetween(b.from, b.to) + 1;
    return nb === 1 ? 'the day before' : nb === 7 ? 'the week before' : 'the ' + nb + ' days before';
  }
  function n_(n, one, many) { return (n === 1 ? 'one' : String(n)) + ' ' + (n === 1 ? one : (many || one + 's')); }
  function joinAnd(xs) { return xs.length <= 1 ? (xs[0] || '') : xs.slice(0, -1).join(', ') + ' and ' + xs[xs.length - 1]; }
  function cap1(x) { return x ? x.charAt(0).toUpperCase() + x.slice(1) : x; }
  var METHOD = { upi: 'UPI', card: 'card', cash: 'cash', wallet: 'a wallet', auto: 'auto-debit', transfer: 'bank transfer' };
  var METHOD_N = { upi: 'UPI', card: 'Cards', cash: 'Cash', wallet: 'Wallets', auto: 'Auto-debits', transfer: 'Bank transfers', '': 'Other' };
  function about(f, ctx) {
    var bits = [];
    if (f.category) bits.push({ 'Tax': 'in tax', 'Income tax': 'in income tax', 'EMI': 'in EMIs', 'Rent': 'in rent', 'Domestic help': 'to household help', 'Donation': 'in donations' }[f.category] || 'on ' + f.category);
    if (f.merchant) bits.push((f.dir === 'in' ? 'from ' : isPerson(f.merchant, ctx) ? 'to ' : 'at ') + payeesWord(f, ctx));
    if (f.forWho) bits.push('for ' + f.forWho);
    if (f.biz) bits.push(f.dir === 'in' ? 'to the business' : 'from the business');
    if (f.card) {
      var bk0 = f.card.replace(/ (?:cc|a\/c)$/, ''), bk = BANK_NAME[bk0] || cap1(bk0);
      bits.push(/ cc$/.test(f.card) ? 'on your ' + bk + ' credit card' : / a\/c$/.test(f.card) ? 'from your ' + bk + ' account' : 'on your ' + bk + ' card or account');
    }
    if (f.method) bits.push(f.method === 'wallet' ? 'from wallets' : 'by ' + METHOD[f.method]);
    if (f.unnamed) bits.push('without a name');
    if (f.weekend) bits.push(f.weekend === 'yes' ? 'on weekends' : 'on weekdays');
    if (f.min && f.max) bits.push('between ' + inr(f.min) + ' and ' + inr(f.max));
    else if (f.min) bits.push('over ' + inr(f.min));
    else if (f.max) bits.push('under ' + inr(f.max));
    return bits.length ? ' ' + bits.join(' ') : '';
  }

  /* ------------------------------------------------------------ the rows a frame is about */
  function within2(t, f, today) { return (!f.from || t.d >= f.from) && t.d <= (f.to || today); }
  function fits(t, f, ctx) {
    var we = f.weekend ? dowOf(t.d) >= 5 : null;
    var payee = f.merchants && f.merchants.length ? f.merchants.some(function (m) { return has(t.m, m); }) : has(t.m, f.merchant);
    return (!f.unnamed || t.u) && (!f.weekend || (f.weekend === 'yes') === we) && (catOk(t, f.category) || billNameOk(t, f.billKind)) && payee && has(t.card, f.card) && personOk(t, f.person, ctx) &&
      (!f.forName || wordIn(t.m, f.forName)) && (!f.biz || bizOwners(ctx).indexOf(t.o || '') >= 0) &&
      (!f.method || (t.md || '') === f.method) && (!(f.min > 0) || t.a >= f.min) && (!(f.max > 0) || t.a <= f.max);
  }
  function spentRows(ctx, f, span) { var today = ctx.today; return spendRows(ctx.tx).filter(function (t) { return within2(t, span || f, today) && fits(t, f, ctx); }); }
  /* the money back kosh couldn't set against one payment, as the months take it off (engine/21c backIn: nta is what
     each refund took off its kind, nt): within the stretch, the kind and the person asked. A figure cut by payee, card,
     way paid, size or day is a list of payments and keeps them whole, as the screens' lists do */
  function backFor(ctx, f, span) {
    var today = ctx.today;
    if (f.merchant || (f.merchants && f.merchants.length) || f.card || f.method || f.unnamed || f.weekend || f.forName || f.min > 0 || f.max > 0 || f.billKind) return [];
    return (ctx.tx || []).filter(function (t) { return t.nt && t.k === 'in' && t.nta > 0 && within2(t, span || f, today) && catOk({ c: t.nt, s: '' }, f.category) && personOk(t, f.person, ctx) && (!f.biz || bizOwners(ctx).indexOf(t.o || '') >= 0); })
      .map(function (t) { return { d: t.d, c: t.nt, o: t.o || 'me', a: t.nta }; });
  }
  /* what was spent in a stretch, the month's way: the payments less that money back, never below nothing */
  function spentSum(ctx, f, span) { return Math.max(0, sumA(spentRows(ctx, f, span)) - sumA(backFor(ctx, f, span))); }
  /* a ranking by kind, person or month with that money back taken off each, as Home's lenses and Insights show them;
     other cuts (payee, card, way paid, weekday) are lists and keep the payments whole */
  function lessBack(groups, back, by) {
    var keyOf = { category: function (b) { return b.c || 'Other'; }, person: function (b) { return b.o; }, month: function (b) { return b.d.slice(0, 7); } }[by];
    if (!keyOf || !back.length) return groups;
    var off = {};
    back.forEach(function (b) { var k = keyOf(b); off[k] = (off[k] || 0) + b.a; });
    return groups.map(function (g) { return off[g.k] ? Object.assign({}, g, { v: Math.max(0, g.v - off[g.k]) }) : g; }).sort(function (a, b) { return b.v - a.v; });
  }
  // everything that went out to someone, counted in spending or not (a payment kosh left out is still paid)
  function paidRows(ctx, f, span) { var today = ctx.today; return (ctx.tx || []).filter(function (t) { return (t.k === 'out' || t.k === 'prepaid') && t.a > 0 && within2(t, span || f, today) && fits(t, f, ctx); }); }
  function idsOf(rows) { return rows.slice(0, 400).map(function (t) { return t.id; }); }
  function byDate(a, b) { return (b.d + (b.t || '')).localeCompare(a.d + (a.t || '')); }
  function byAmt(a, b) { return b.a - a.a; }
  function line(t, today, ctx) { return inr(t.a) + ' to ' + t.m + ', ' + on(t.d, today) + (t.c && t.c !== 'Money out' ? ' · ' + t.c : ''); }
  function months12(today) { var m = today.slice(0, 7), out = []; for (var i = 0; i < 12; i++) { out.unshift(m); m = addDays(m + '-01', -1).slice(0, 7); } return out; }
  function firstDay(ctx) { return (ctx.tx || []).reduce(function (lo, t) { return !lo || t.d < lo ? t.d : lo; }, ''); }
  /* a stretch that starts before the mail kosh has read: from when the figure counts */
  function sinceNote(sp, ctx) {
    var fd = firstDay(ctx);
    if (!fd || !sp || !sp.from || sp.from >= fd || (sp.to || ctx.today) < fd || daysBetween(sp.from, fd) < 2) return '';
    return ' kosh’s mail goes back to ' + dShort(fd) + ' ' + fd.slice(0, 4) + ', so that’s from then.';
  }
  /* full months the ledger covers, before this one, newest last (at most n) */
  function fullMonths(ctx, n) {
    var today = ctx.today, first = firstDay(ctx).slice(0, 7), out = [], m = addDays(today.slice(0, 7) + '-01', -1).slice(0, 7);
    while (out.length < n && first && m >= first) { if (m > first || firstDay(ctx).slice(8) <= '05') out.unshift(m); m = addDays(m + '-01', -1).slice(0, 7); }
    return out;
  }
  function groupBy(rows, by, ctx) {
    var g = {}, names = {};
    rows.forEach(function (t) {
      var k, nm;
      if (by === 'payee') { k = lc(t.m).trim(); nm = t.m; }
      else if (by === 'category') { k = t.u ? '(unnamed)' : t.c || 'Other'; nm = t.u ? 'Not named yet' : k; }
      else if (by === 'subcategory') { k = t.s || 'Not split further'; nm = k; }
      else if (by === 'card') { k = t.card || 'Unknown'; nm = k; }
      else if (by === 'method') { k = t.md || ''; nm = METHOD_N[k] || cap1(k); }
      else if (by === 'person') { k = t.o || 'me'; var p = (ctx.people || []).filter(function (x) { return x.id === k; })[0]; nm = k === 'me' ? 'You' : p ? p.name : k; }
      else if (by === 'weekday') { k = String(dowOf(t.d)); nm = DOW[+k] + 's'; }
      else if (by === 'month') { k = t.d.slice(0, 7); nm = monthWord(k, ctx.today); }
      else { k = t.c; nm = k; }
      (g[k] = g[k] || []).push(t); names[k] = names[k] || nm;
    });
    return Object.keys(g).map(function (k) { return { k: k, name: names[k], v: sumA(g[k]), n: g[k].length, rows: g[k] }; }).sort(function (a, b) { return b.v - a.v; });
  }
  /* who a credit is from, without the bank's words and reference numbers ("Neft-Citin25966811-Kaveri Global Service"
     is Kaveri Global Service): payerName to say it, payerKey to tell one payer's credits from another's */
  function payerName(m) {
    return String(m || '').split(/[\s\-\/:]+/).filter(function (w) { return w && !/\d/.test(w) && !/^(?:neft|imps|rtgs|upi|nach|ach|cr|dr|credit|trf|transfer|by|from|inb|mb|ib|sal|salary|ref)$/i.test(w); }).join(' ').trim();
  }
  function payerKey(m) { var n = lc(payerName(m)).split(' ').slice(0, 2).join(' '); return n || lc(m); }
  function sumA(rows) { return sum(rows, function (t) { return t.a; }); }
  function pctOf(a, b) { return b > 0 ? Math.round(a / b * 100) : 0; }

  /* ------------------------------------------------------------ each kind of answer */
  function answerOf(f, ctx, prevAct) {
    var today = ctx.today, o = { text: '', rows: [], steps: [], suggest: [], frame: f };
    var step = function (tool, label, result) { o.steps.push({ tool: tool, label: label, result: result }); };
    var thisMonth = { from: today.slice(0, 8) + '01', to: today };
    var span = f.named ? { from: f.from, to: f.to, label: f.label } : null;
    var subj = about(f, ctx);
    switch (f.act) {
      case 'total': {
        // a person you pay (a friend, the cook, the landlord) is "paid", whether kosh counts it as spending or not
        var toPerson = f.merchant && isPerson(f.merchant, ctx), pick = toPerson ? paidRows : spentRows;
        var sp = span || thisMonth, rows = pick(ctx, f, sp), tot = toPerson ? sumA(rows) : spentSum(ctx, f, sp), words = spanWords(sp, today);
        // what's owed rather than chosen (tax, EMIs, rent, fees) is paid, not spent
        var dues = toPerson || /^(?:Tax|Income tax|EMI|Rent|Education|Fees|Insurance|Domestic help)$/.test(f.category || '');
        var fd0 = firstDay(ctx);
        if (!rows.length && fd0 && (sp.to || today) < fd0) { o.text = 'kosh’s mail starts on ' + dShort(fd0) + ' ' + fd0.slice(0, 4) + ', so it can’t see ' + words.replace(/^in /, '') + '.'; o.suggest = ['How much did I spend last month?']; break; }
        if (!rows.length) {
          o.text = (dues ? 'Nothing paid' : 'Nothing spent') + (f.person && personWord(f.person) !== 'You' ? ' by ' + f.person : '') + subj + ' ' + words + '.';
          if (hasSubject(f)) {
            var ever = pick(ctx, f, { from: addDays(today, -365), to: today }).sort(byDate);
            if (ever.length) {
              o.text += ' Over the last 12 months: **' + inr(sumA(ever)) + '** across ' + n_(ever.length, 'payment') + ', the last ' + line(ever[0], today, ctx) + '.';
              o.rows = idsOf(ever);
            } else if (f.category === 'Rent' && !f.merchant) {
              // rent paid by name to a landlord is rarely marked as rent: the biggest regular payment to a person, offered as it
              var rc = rentGuess(ctx, today);
              if (rc) { o.text = 'kosh hasn’t seen a payment marked as rent. The biggest regular payment to a person is **' + inr(rc.amt) + '** to ' + rc.name + ', around the ' + ordinal(rc.day) + ' each month (' + n_(rc.n, 'time') + ' since ' + MONF[+rc.since.slice(5, 7) - 1] + '): if that’s your rent, mark it as Rent and kosh counts it as rent.'; o.rows = idsOf(rc.rows); }
            }
          }
          o.suggest = [f.merchant ? 'Who did I pay the most this month?' : 'How much have I spent this month?', 'What were my biggest payments last month?'];
          break;
        }
        var past = (sp.to || today) < today, other = f.person && personWord(f.person) !== 'You';
        o.text = (other ? f.person + (dues ? ' paid' : ' spent') : dues ? (past ? 'You paid' : 'You’ve paid') : past ? 'You spent' : 'You’ve spent') + ' **' + inr(tot) + '**' + subj + ' ' + words + ', across ' + n_(rows.length, 'payment') + '.';
        // "the cook": household help is who kosh sees; which of them cooks isn't in the payments
        var role = f.category === 'Domestic help' && /\b(cook|maid|driver|nanny|cleaner|gardener)s?\b/.exec(norm(f.q || '')), helpers = role ? groupBy(rows, 'payee', ctx) : [];
        if (helpers.length > 1) o.text = 'Your household help came to **' + inr(tot) + '** ' + words + ': ' + joinAnd(helpers.slice(0, 4).map(function (x) { return x.name + ' ' + inr(x.v); })) + '. Which of them is the ' + role[1] + ' isn’t in your payments.';
        o.text += sinceNote(sp, ctx);
        var b = before(sp, today);
        // nothing to hold it against before the mail kosh has read (or when the answer is who it went to)
        if (b && (b.from < firstDay(ctx) || helpers.length > 1)) b = null;
        if (b) {
          var pr = toPerson ? sumA(pick(ctx, f, b)) : spentSum(ctx, f, b), d = tot - pr;
          if (pr > 0) o.text += ' That’s ' + (Math.abs(d) < 1 ? 'the same as ' : inr(Math.abs(d)) + (d > 0 ? ' more than ' : ' less than ')) + beforeWords(b, sp, today) + ' (' + inr(pr) + ').';
          else if (!hasSubject(f)) o.text += ' Nothing was spent ' + beforeWords(b, sp, today) + '.';
        }
        if (rows.length > 1 && helpers.length < 2) {
          if (!f.merchant || (f.merchants && f.merchants.length > 1)) {
            var tops = groupBy(rows, 'payee', ctx).slice(0, 3);
            o.text += ' Most of it went to ' + joinAnd(tops.map(function (x) { return x.name + ' (' + inr(x.v) + ')'; })) + '.';
          } else {
            var big = rows.slice().sort(byAmt)[0];
            o.text += ' The biggest was ' + inr(big.a) + ' ' + at(big.d, today) + '.';
          }
        }
        o.rows = idsOf(rows);
        step('spending', 'Spending' + subj, rows.length + ' payments ' + words + ', ' + inr(tot) + (b ? '; ' + beforeWords(b, sp, today) + ' ' + inr(toPerson ? sumA(pick(ctx, f, b)) : spentSum(ctx, f, b)) : '') + '.');
        o.suggest = ['Show these payments', 'Compare with last month', f.category || f.merchant ? 'Month by month' : 'Split by category'];
        break;
      }
      case 'rank': {
        var by = f.by || 'category', sp2 = span || (by === 'month' ? { from: months12(today)[0] + '-01', to: today, label: 'over the last 12 months' } : thisMonth);
        var fr = by === 'method' ? Object.assign({}, f, { method: '' }) : f;
        var base = by === 'payee' ? paidRows(ctx, fr, sp2) : spentRows(ctx, fr, sp2);
        if (by === 'card' && base.some(function (t) { return t.md === 'card'; })) base = base.filter(function (t) { return t.md === 'card'; });
        if (by === 'payee' && f.shops) base = base.filter(function (t) { return !isPerson(lc(t.m).trim(), ctx); });
        if (by === 'month') base = base.filter(function (t) { return t.d.slice(0, 7) !== today.slice(0, 7) || f.named; });
        var gs = groupBy(base, by, ctx), tot2 = sumA(base), w2 = spanWords(sp2, today), asc = f.order === 'asc';
        // (by kind, person or month: each less the money back that comes off it, as Home's month and Insights show it)
        if (by === 'category' || by === 'person' || by === 'month') {
          var back2 = backFor(ctx, fr, sp2).filter(function (x) { return by !== 'month' || x.d.slice(0, 7) !== today.slice(0, 7) || f.named; });
          gs = lessBack(gs, back2, by); tot2 = Math.max(0, tot2 - sumA(back2));
        }
        if (asc) gs = gs.slice().reverse();
        if (!gs.length) { o.text = 'Nothing' + subj + ' ' + w2 + ' to go by yet.'; o.suggest = ['How much have I spent this month?']; break; }
        var t0 = gs[0], share = pctOf(t0.v, tot2), cnt = ' (' + n_(t0.n, 'payment') + (gs.length > 1 && share ? ', ' + share + '% of ' + (by === 'payee' ? 'what went out' : by === 'card' ? 'what went on cards' : by === 'person' ? 'the household’s spending' : 'your spending') : '') + ')';
        var lead = {
          payee: (asc ? 'The least went to **' + t0.name + '**' : f.shops ? '**' + t0.name + '** got the most from you' : 'You paid **' + t0.name + '** the most') + subj + ' ' + w2 + ': **' + inr(t0.v) + '**' + cnt + '.',
          category: '**' + t0.name + '** ' + (asc ? 'took the least' : 'took the most') + subj + ' ' + w2 + ': **' + inr(t0.v) + '**' + cnt + '.',
          card: 'You used **' + t0.name + '** ' + (asc ? 'the least' : 'the most') + subj + ' ' + w2 + ': **' + inr(t0.v) + '**' + cnt + '.',
          method: (asc ? 'Least by ' : 'Mostly by ') + '**' + t0.name + '** ' + w2 + ': **' + inr(t0.v) + '** of ' + inr(tot2) + ' (' + share + '%).',
          person: '**' + t0.name + '** ' + (t0.name === 'You' ? 'spent' : 'spent') + (asc ? ' the least' : ' the most') + subj + ' ' + w2 + ': **' + inr(t0.v) + '**' + cnt + '.',
          weekday: '**' + t0.name + '** ' + (asc ? 'cost the least' : 'cost the most') + subj + ' ' + w2 + ': **' + inr(t0.v) + '** across ' + n_(t0.n, 'payment') + '.',
          month: '**' + t0.name + '** was ' + (asc ? 'the lightest' : 'the biggest') + ' month' + subj + ' ' + w2 + ': **' + inr(t0.v) + '**.',
        }[by];
        var shown = Math.max(1, Math.min(gs.length, f.n || (gs.length > 6 ? 5 : gs.length)));
        var rest = gs.slice(1, shown).map(function (x) { return x.name + ' · ' + inr(x.v) + (by === 'month' || by === 'weekday' || x.n === 1 ? '' : ' · ' + x.n + ' payments'); });
        o.text = lead + (rest.length ? '\n\nThen:\n- ' + rest.join('\n- ') : '');
        if (gs.length > shown) o.text += (rest.length > 3 ? '\n' : ' ') + 'And ' + (gs.length - shown) + ' more.';
        // no period asked for: the year's leader too, when it's someone else
        if (!f.named && !asc && (by === 'payee' || by === 'category')) {
          var yr = by === 'payee' ? paidRows(ctx, f, { from: addDays(today, -364), to: today }) : spentRows(ctx, f, { from: addDays(today, -364), to: today });
          var gy = by === 'category' ? lessBack(groupBy(yr, by, ctx), backFor(ctx, f, { from: addDays(today, -364), to: today }), by) : groupBy(yr, by, ctx);
          if (gy.length && gy[0].k !== t0.k) o.text += '\n\nOver the last 12 months it’s **' + gy[0].name + '**: ' + inr(gy[0].v) + ' across ' + n_(gy[0].n, 'payment') + '.';
        }
        o.rows = idsOf(t0.rows);
        f.top = t0.k === '' ? '' : (by === 'payee' ? t0.k : by === 'person' ? t0.name : t0.k);
        step('breakdown', 'By ' + by, w2 + ', ' + inr(tot2) + ' in all: ' + gs.slice(0, 10).map(function (x) { return x.name + ' ' + inr(x.v) + ' (' + x.n + ')'; }).join('; ') + '.');
        o.suggest = by === 'payee' ? ['Show the payments to ' + t0.name, 'Split by category', f.named ? 'And this month?' : 'And last month?']
          : by === 'category' ? [t0.k === '(unnamed)' ? 'Show the payments that need a name' : 'Show the ' + t0.name + ' payments', 'Who did I pay the most?', 'Compare with last month']
          : ['Show these payments', 'Split by category'];
        break;
      }
      case 'biggest': {
        var q3 = norm(f.q || ''), spendOnly = f.dir !== 'in' && /\bexpenses?\b|\bspends?\b|\bspending\b|\bspent\b|\bpurchases?\b/.test(q3) && !/\bpayments?\b|\btransfers?\b|\bsent\b|\bpaid\b/.test(q3);
        var asSpend = function (rows) { return spendOnly ? rows.filter(function (t) { return t.sp !== false; }) : rows; };
        var sp3 = span || thisMonth, base3 = (f.dir === 'in' ? (ctx.tx || []).filter(function (t) { return t.k === 'in' && within2(t, sp3, today) && fits(t, f, ctx); }) : asSpend(paidRows(ctx, f, sp3))).sort(byAmt);
        if (f.order === 'asc') base3.reverse();
        var w3 = spanWords(sp3, today);
        if (!base3.length) { o.text = 'No payments' + subj + ' ' + w3 + '.'; o.suggest = ['What were my biggest payments last month?']; break; }
        var b0 = base3[0], small = f.order === 'asc';
        if (f.n > 1) {
          // "top 5 expenses": the list itself
          var topK = base3.slice(0, f.n);
          o.text = 'Your ' + (topK.length > 1 ? topK.length + ' ' : '') + (small ? 'smallest' : 'biggest') + ' payment' + (topK.length === 1 ? '' : 's') + subj + ' ' + w3 + ', ' + inr(sumA(topK)) + ' together:\n- ' + topK.map(function (t) { return line(t, today, ctx); }).join('\n- ');
        } else {
          o.text = 'Your ' + (small ? 'smallest' : 'biggest') + ' payment' + subj + ' ' + w3 + ' was **' + inr(b0.a) + ' to ' + b0.m + '** ' + at(b0.d, today) + (b0.c ? ' (' + b0.c + ')' : '') + '.';
          var more3 = base3.slice(1, 4).map(function (t) { return line(t, today, ctx); });
          if (more3.length) o.text += '\n\nNext:\n- ' + more3.join('\n- ');
        }
        if (!f.named && !small && !(f.n > 1)) {
          var yr3 = asSpend(paidRows(ctx, f, { from: addDays(today, -364), to: today })).sort(byAmt)[0];
          if (yr3 && yr3.id !== b0.id) o.text += '\n\nThe biggest in the last 12 months: ' + line(yr3, today, ctx) + '.';
        }
        o.rows = idsOf(base3.slice(0, Math.max(4, f.n || 4)));
        f.n = f.n || 4;
        step('transactions', 'Payments by size', base3.length + ' payments ' + w3 + '; largest ' + base3.slice(0, 5).map(function (t) { return inr(t.a) + ' ' + t.m; }).join(', ') + '.');
        o.suggest = ['Who did I pay the most this month?', 'Show all payments over ' + inr(Math.max(1000, Math.round(b0.a / 2000) * 1000))];
        break;
      }
      case 'last': {
        var dirIn = /\b(?:received|credited|came|got|salary|refund|income)\b/.test(norm(f.q || ''));
        var all = (ctx.tx || []).filter(function (t) { return (dirIn ? t.k === 'in' || takenOut(t) : (t.k === 'out' || t.k === 'prepaid' || putIn(t))) && t.a > 0 && t.d <= today && fits(t, f, ctx) && (!f.named || within2(t, f, today)); }).sort(byDate);
        if (!all.length) { o.text = 'I can’t find ' + (dirIn ? 'any money in' : 'a payment') + subj + (f.named ? ' ' + spanWords(f, today) : ' in what kosh has read') + '.'; o.suggest = ['Who did I pay the most this month?']; break; }
        var salary = dirIn && /salary/i.test((f.category || '') + ' ' + norm(f.q || ''));
        // "my salary": the user's own, when two salaries come into the household
        if (salary && !f.person) { var mine0 = all.filter(function (t) { return (t.o || 'me') === 'me'; }); if (mine0.length) all = mine0; }
        var l0 = all[0], who = f.merchant ? payeeName(f.merchant, ctx) : '', ago = daysBetween(l0.d, today);
        var tail = (!dirIn && l0.md && METHOD[l0.md] ? ' by ' + METHOD[l0.md] : '') + (ago >= 2 ? ' (' + ago + ' days ago)' : '') + '.';
        if (salary) o.text = (f.person && personWord(f.person) !== 'You' ? f.person + '’s' : 'Your') + ' last salary was **' + inr(l0.a) + '** from ' + l0.m + ' ' + at(l0.d, today) + tail;
        else if (f.merchant) o.text = (dirIn ? 'The last money in from **' : 'Your last payment to **') + l0.m + '** was **' + inr(l0.a) + '** ' + at(l0.d, today) + tail;
        else o.text = (dirIn ? 'The last money in' : 'Your last payment') + (dirIn && f.category ? ' as ' + f.category : subj) + ' was **' + inr(l0.a) + '** ' + (dirIn ? 'from ' : 'to ') + l0.m + ' ' + at(l0.d, today) + tail;
        if (all.length > 1) o.text += ' Before that: ' + joinAnd(all.slice(1, 3).map(function (t) { return inr(t.a) + ' ' + at(t.d, today); })) + '.';
        var beat0 = !dirIn && hasSubject(f) ? beatOf(all, ctx) : null;
        if (beat0) o.text += ' ' + beatWords(beat0, today);
        else if (all.length >= 3 && hasSubject(f)) {
          var gaps = []; for (var i = 1; i < Math.min(all.length, 13); i++) gaps.push(daysBetween(all[i].d, all[i - 1].d));
          var gm = Math.round(median(gaps)), every = gm === 1 ? 'day' : gm >= 27 && gm <= 33 ? 'month' : gm >= 6 && gm <= 8 ? 'week' : gm + ' days';
          if (gm >= 1) o.text += dirIn ? ' It comes about every ' + every + '.' : ' You pay ' + (who || 'them') + ' about every ' + every + '.';
        }
        o.rows = idsOf(all.slice(0, 10));
        step('transactions', 'Latest payments' + subj, all.slice(0, 5).map(function (t) { return t.d + ' ' + t.m + ' ' + inr(t.a); }).join('; ') + '.');
        var shortW = f.merchant ? payeeShort(f.merchant, ctx) : '';
        o.suggest = dirIn ? ['How much came in this month?', 'Money in, month by month'] : hasSubject(f) ? [(f.merchant && isPerson(f.merchant, ctx) ? 'How much have I paid ' + shortW : 'How much have I spent' + (f.merchant ? ' at ' + shortW : subj)) + ' this year?', 'How many times' + (f.merchant ? ' did I pay ' + shortW : '') + ' this month?'] : ['Show my recent payments', 'What were my biggest payments this month?'];
        break;
      }
      case 'count': {
        var often = /\bhow often\b/.test(norm(f.q || '')) && !f.named;
        var sp4 = span || (often ? { from: addDays(today, -89), to: today, label: 'in the last 3 months' } : thisMonth), base4 = paidRows(ctx, f, sp4).sort(byDate), w4 = spanWords(sp4, today);
        var who4 = f.merchant ? payeeName(f.merchant, ctx) : '';
        o.text = (who4 ? 'You paid ' + who4 + ' ' : 'You made ') + '**' + (base4.length === 1 ? 'once' : base4.length + (who4 ? ' times' : ' payments')) + '**' + (who4 ? about(Object.assign({}, f, { merchant: '' }), ctx) : subj) + ' ' + w4 +
          (base4.length ? ', ' + inr(sumA(base4)) + ' in all' + (base4.length > 1 ? ', about ' + inr(sumA(base4) / base4.length) + ' each' : '') : '') + '.';
        var beat4 = often && f.merchant ? beatOf(base4, ctx) : null;
        if (beat4) o.text += ' ' + beatWords(beat4, today) + ' The last was ' + at(base4[0].d, today) + '.';
        else if (often && base4.length >= 3) {
          var gaps4 = []; for (var j = 1; j < base4.length; j++) gaps4.push(daysBetween(base4[j].d, base4[j - 1].d));
          var g4 = Math.round(median(gaps4));
          o.text += ' That’s about ' + (g4 <= 1 ? 'every day' : g4 >= 6 && g4 <= 8 ? 'once a week' : g4 >= 27 && g4 <= 33 ? 'once a month' : 'every ' + g4 + ' days') + '; the last was ' + at(base4[0].d, today) + '.';
        } else {
          var fm = fullMonths(ctx, 6);
          if (fm.length >= 2) {
            var per = fm.map(function (m) { return paidRows(ctx, f, { from: m + '-01', to: monthEnd(m + '-01') }).length; });
            var avgN = per.reduce(function (a, b) { return a + b; }, 0) / per.length;
            if (avgN >= 0.5) o.text += ' Over the last ' + fm.length + ' full months that’s about ' + (Math.round(avgN * 10) / 10) + ' a month.';
          }
        }
        o.rows = idsOf(base4);
        step('transactions', 'Counted payments' + subj, base4.length + ' ' + w4 + ', ' + inr(sumA(base4)) + '.');
        o.suggest = ['Show them', 'Month by month'];
        break;
      }
      case 'avg': {
        var fm5 = fullMonths(ctx, 6), vals = fm5.map(function (m) { return spentSum(ctx, f, { from: m + '-01', to: monthEnd(m + '-01') }); });
        var usual = median(vals), cmRows = spentRows(ctx, f, thisMonth), cmTot = spentSum(ctx, f, thisMonth), dayN = +today.slice(8, 10);
        var dim = +monthEnd(today).slice(8, 10);
        if (f.unit === 'order') {
          // a payment's size, not a month's: over what's asked, else the last three months
          var spO = span || { from: addDays(today, -89), to: today, label: 'in the last 3 months' }, rO = paidRows(ctx, f, spO);
          o.text = rO.length ? 'About **' + inr(sumA(rO) / rO.length) + ' a payment**' + subj + ' ' + spanWords(spO, today) + ' (' + n_(rO.length, 'payment') + ', ' + inr(sumA(rO)) + ' in all).'
            : 'No payments' + subj + ' ' + spanWords(spO, today) + '.';
          if (rO.length >= 2) { var srt = rO.slice().sort(byAmt); o.text += ' The biggest was ' + inr(srt[0].a) + ', the smallest ' + inr(srt[srt.length - 1].a) + '.'; }
          cmRows = rO;
        } else if (f.unit === 'day') {
          o.text = 'About **' + inr(cmTot / dayN) + ' a day**' + subj + ' this month (' + inr(cmTot) + ' over ' + dayN + ' days).';
          if (usual > 0) o.text += ' A usual month works out to about ' + inr(usual / 30.4) + ' a day.';
        } else if (f.unit === 'week') {
          o.text = 'About **' + inr(cmTot / dayN * 7) + ' a week**' + subj + ' this month.' + (usual > 0 ? ' A usual month works out to about ' + inr(usual / 4.35) + ' a week.' : '');
        } else if (usual > 0) {
          o.text = 'A usual month' + subj + ' is about **' + inr(usual) + '** (the middle of the last ' + n_(fm5.length, 'full month') + ': ' + fm5.map(function (m, i) { return MON3[+m.slice(5, 7) - 1] + ' ' + inr(vals[i]); }).join(', ') + ').';
          var likely = dayN >= (hasSubject(f) ? 15 : 5) ? cmTot / dayN * dim : 0;
          o.text += ' This month so far: ' + inr(cmTot) + (likely > 0 ? ', heading for about ' + inr(Math.round(likely / 100) * 100) + (likely > usual * 1.15 ? ', above usual' : likely < usual * 0.85 ? ', below usual' : ', about usual') : '') + '.';
        } else {
          o.text = 'There isn’t a full month' + subj + ' to go by yet. This month so far: **' + inr(cmTot) + '**.';
        }
        o.rows = idsOf(cmRows);
        step('trend', 'Usual month' + subj, fm5.map(function (m, i) { return m + ' ' + inr(vals[i]); }).join('; ') + '; this month ' + inr(cmTot) + '.');
        o.suggest = ['Month by month', 'Am I on track this month?'];
        break;
      }
      case 'list': {
        var sp6 = span || (hasSubject(f) ? { from: addDays(today, -89), to: today, label: 'in the last 3 months' } : thisMonth);
        var base6 = paidRows(ctx, f, sp6).sort(f.sort === 'amount' ? byAmt : byDate), lim = Math.min(25, f.n || 10), w6 = spanWords(sp6, today);
        if (!base6.length) { o.text = 'No payments' + subj + ' ' + w6 + '.'; o.suggest = nearQuestions(f, ctx); break; }
        o.text = '**' + cap1(n_(base6.length, 'payment')) + '**' + subj + ' ' + w6 + ', ' + inr(sumA(base6)) + ' in all' + (base6.length > lim ? '. The ' + (f.sort === 'amount' ? 'biggest ' : 'latest ') + lim + ':' : ':') + '\n- ' +
          base6.slice(0, lim).map(function (t) { return on(t.d, today) + ' · ' + t.m + ' · ' + inr(t.a); }).join('\n- ');
        o.rows = idsOf(base6);
        if (base6.length > lim) o.suggest = ['More'];
        o.suggest = o.suggest.concat(['Split by category', 'Compare with last month']);
        break;
      }
      case 'compare': {
        /* "this month against last", "September vs August", "compared with last year": what's named after "than",
           "with" or "vs" is what it's held against; the rest (or this month) is what's looked at */
        var qs = norm(f.q || ''), cut = /\b(?:compared? (?:to|with)|against|vs|versus|than)\b/.exec(qs), A0 = null, B0 = null;
        // "compare this month with last month", "compare this month and last month"
        if (!cut && /\bcompare\b/.test(qs) && / with /.test(qs)) { var wi = qs.indexOf(' with '); cut = { index: wi, 0: ' with ' }; }
        if (!cut && /\bcompare\b/.test(qs) && / and /.test(qs)) { var ai = qs.lastIndexOf(' and '); cut = { index: ai, 0: ' and ' }; }
        if (cut) {
          var head = periodOf(qs.slice(0, cut.index) + ' ', today), tail = periodOf(' ' + qs.slice(cut.index + cut[0].length), today);
          if (head.named) A0 = { from: head.from, to: head.to, label: head.label };
          if (tail.named) B0 = { from: tail.from, to: tail.to, label: tail.label };
          if (!A0 && B0) A0 = thisMonth;
        }
        // a bill that went up: the last whole month against the one before (a month's bill comes once)
        if (!A0 && f.bills && !span) { var lm0 = addDays(thisMonth.from, -1), lm1 = addDays(lm0.slice(0, 8) + '01', -1); A0 = { from: lm0.slice(0, 8) + '01', to: lm0 }; B0 = { from: lm1.slice(0, 8) + '01', to: lm1 }; }
        if (!A0) A0 = span ? { from: f.from, to: f.to, label: f.label } : thisMonth;
        if (!B0) {
          if (A0.from.slice(8) === '01' && A0.from.slice(0, 7) === A0.to.slice(0, 7)) {
            var pm = addDays(A0.from, -1), endB = pm.slice(0, 8) + A0.to.slice(8);
            B0 = { from: pm.slice(0, 8) + '01', to: A0.to === monthEnd(A0.from) || endB > pm ? pm : endB };
          } else B0 = before(A0, today) || { from: addDays(A0.from, -30), to: addDays(A0.from, -1) };
        } else if (A0.to === today && A0.from.slice(8) === '01' && B0.from.slice(8) === '01' && B0.to === monthEnd(B0.from) && A0.from.slice(0, 7) !== B0.from.slice(0, 7)) {
          // a month so far against a whole month: the same days of it, so the two are fair
          var cutB = B0.from.slice(0, 8) + today.slice(8); if (cutB < B0.to) B0 = { from: B0.from, to: cutB };
        }
        // two people, or two payees, over the same stretch: "my spending against my wife's", "Ola vs Uber this year"
        var two = f.person2 ? 'person' : f.merchant2 ? 'payee' : '', fA = f, fB = f;
        if (two) {
          A0 = span ? { from: f.from, to: f.to, label: f.label } : thisMonth; B0 = A0;
          fA = Object.assign({}, f, { merchants: undefined, merchant2: undefined, person2: undefined });
          fB = two === 'person' ? Object.assign({}, fA, { person: f.person2 }) : Object.assign({}, fA, { merchant: f.merchant2 });
        }
        var inA = spentRows(ctx, fA, A0), inB = spentRows(ctx, fB, B0), tA = spentSum(ctx, fA, A0), tB = spentSum(ctx, fB, B0), dd = tA - tB;
        if (two) {
          var nA = two === 'person' ? personWord(f.person) : payeeName(f.merchant, ctx), nB = two === 'person' ? personWord(f.person2) : payeeName(f.merchant2, ctx), wS = spanWords(A0, today);
          var part = function (n, t, k) { return two === 'person' ? (n === 'You' ? 'you' : n) + ' **' + inr(t) + '**' : '**' + inr(t) + '** at ' + n + ' (' + n_(k, 'payment') + ')'; };
          o.text = cap1(wS) + ': ' + part(nA, tA, inA.length) + (two === 'person' ? ', ' : ' and ') + part(nB, tB, inB.length) + '.' +
            (Math.abs(dd) < 1 ? ' The same.' : ' ' + (dd > 0 ? nA : nB) + (two === 'person' ? ' spent ' : ' came to ') + inr(Math.abs(dd)) + ' more.');
          o.rows = idsOf(inA.concat(inB));
          f.from = A0.from; f.to = A0.to; f.named = true; f.label = A0.label || '';
          step('compare', 'Compared' + (two === 'person' ? ' people' : ' payees'), nA + ' ' + inr(tA) + ' (' + inA.length + ') against ' + nB + ' ' + inr(tB) + ' (' + inB.length + ') ' + wS + '.');
          o.suggest = ['Show these payments', 'Month by month'];
          break;
        }
        var wA = spanWords(A0, today), wB = B0.label && !/same days/.test(beforeWords(B0, A0, today)) ? B0.label.replace(/^in /, '') : beforeWords(B0, A0, today);
        if (tA < 1 && tB < 1) { o.text = 'Nothing' + subj + ' ' + wA + ', or ' + wB + '.'; o.suggest = nearQuestions(f, ctx); break; }
        o.text = cap1(wA) + ': **' + inr(tA) + '**' + subj + (Math.abs(dd) < 1 ? ', the same as ' + wB + '.' : ', **' + inr(Math.abs(dd)) + (dd > 0 ? ' more' : ' less') + '** than ' + wB + ' (' + inr(tB) + (tB > 0 ? ', ' + (dd > 0 ? 'up ' : 'down ') + pctOf(Math.abs(dd), tB) + '%' : '') + ').');
        // a stretch kosh only partly sees: the comparison says so
        var fdC = firstDay(ctx);
        if (fdC && B0.from < fdC && B0.to >= fdC && daysBetween(B0.from, fdC) >= 2) o.text += ' kosh’s mail goes back to ' + dShort(fdC) + ' ' + fdC.slice(0, 4) + ', so ' + wB + ' is from then.';
        var key = f.category ? 'payee' : 'category', gA = groupBy(inA, key, ctx), gB = groupBy(inB, key, ctx), mapB = {};
        gB.forEach(function (x) { mapB[x.k] = x; });
        var ch = gA.map(function (x) { return { name: x.name, d: x.v - (mapB[x.k] ? mapB[x.k].v : 0), a: x.v }; });
        gB.forEach(function (x) { if (!gA.some(function (y) { return y.k === x.k; })) ch.push({ name: x.name, d: -x.v, a: 0 }); });
        ch = ch.filter(function (x) { return Math.abs(x.d) >= 1; }).sort(function (x, y) { return Math.abs(y.d) - Math.abs(x.d); }).slice(0, 4);
        if (ch.length) o.text += '\n\nWhat moved most:\n- ' + ch.map(function (x) { return x.name + ' ' + (x.d > 0 ? '+' : '−') + inr(Math.abs(x.d)) + (x.a ? ' (' + inr(x.a) + ' now)' : ' (none now)'); }).join('\n- ');
        o.rows = idsOf(inA);
        f.from = A0.from; f.to = A0.to; f.named = true; f.label = '';
        step('compare', 'Compared' + subj, wA + ' ' + inr(tA) + ' (' + inA.length + ') against ' + wB + ' ' + inr(tB) + ' (' + inB.length + ').');
        o.suggest = ch.length && ch[0].d > 0 ? ['Show the ' + ch[0].name + ' payments', 'Month by month'] : ['Month by month', 'Split by category'];
        break;
      }
      case 'trend': {
        var nM = /\b(?:last|past) (\d+|three|four|six|twelve) months\b/.exec(norm(f.q || '')), cntM = nM ? (/^\d+$/.test(nM[1]) ? +nM[1] : { three: 3, four: 4, six: 6, twelve: 12 }[nM[1]]) : 6;
        var ms = months12(today).slice(-Math.min(12, Math.max(2, cntM))), first = firstDay(ctx).slice(0, 7);
        ms = ms.filter(function (m) { return !first || m >= first; });
        var inc = f.what === 'income';
        var rowsIn = function (m) {
          var w = { from: m + '-01', to: m === today.slice(0, 7) ? today : monthEnd(m + '-01') };
          return inc ? (ctx.tx || []).filter(function (t) { return t.k === 'in' && !t.ex && t.c !== 'Transfer in' && t.c !== 'Self Transfer' && within2(t, w, today); }) : spentRows(ctx, f, w);
        };
        var vs = ms.map(function (m) { return sumA(rowsIn(m)); });
        var full = ms.map(function (m, i) { return { m: m, v: vs[i] }; }).filter(function (x) { return x.m !== today.slice(0, 7); });
        var us = median(full.map(function (x) { return x.v; })), lf = full[full.length - 1];
        o.text = (inc ? 'Money in' : 'Spending' + subj) + ', month by month:\n- ' + ms.map(function (m, i) { return MON3[+m.slice(5, 7) - 1] + ' ' + inr(vs[i]) + (m === today.slice(0, 7) ? ' (so far)' : ''); }).join('\n- ');
        if (us > 0 && lf) o.text += '\n\nA usual month is **' + inr(us) + '**; ' + MONF[+lf.m.slice(5, 7) - 1] + ' was ' + (Math.abs(lf.v - us) < us * 0.05 ? 'about that.' : inr(Math.abs(lf.v - us)) + (lf.v > us ? ' above it.' : ' below it.'));
        step('trend', 'Month by month' + subj, ms.map(function (m, i) { return m + ' ' + inr(vs[i]); }).join('; ') + '.');
        o.suggest = inc ? ['How much did I save last month?'] : ['Compare with last month', f.category ? 'Who did I pay the most?' : 'Split by category'];
        break;
      }
      case 'due': {
        var win = dueWindow(f, today), wf = f.what || '', wd = win.words;
        var fitsW = dueFilter(f, ctx);
        var dated = (ctx.agenda || []).concat(loanDue(ctx, today)).filter(function (x) { return x.date && x.date >= today && fitsW(x); }).sort(function (a, b) { return a.date.localeCompare(b.date); });
        var due = dated.filter(function (x) { return x.date >= win.from && x.date <= win.to; });
        var outs = due.filter(function (x) { return x.kind !== 'in'; }), ins = wf && wf !== 'rent' ? [] : due.filter(function (x) { return x.kind === 'in'; }), open = outs.filter(function (x) { return !x.booked; });
        var later = dated.filter(function (x) { return x.kind !== 'in' && !x.booked && x.date > win.to && x.date <= addDays(today, 120); });
        var label = DUE_WORD[wf] || '', dueLine = function (x) { return on(x.date, today) + ' · ' + x.name + ' · ' + inr(x.amt) + (x.booked ? ' (paid)' : ''); };
        var first = (f.next ? open : [])[0] || (f.next && win.def ? later[0] : null);
        if (first) {
          // "which SIP is due next", "when is my car loan EMI": the next one first
          o.text = 'Next: **' + first.name + ' · ' + inr(first.amt) + '** ' + at(first.date, today) + (first.sub && !/learnt|from your mail|^Minimum/i.test(first.sub) ? ' (' + first.sub + ')' : '') + '.';
          var rest = outs.filter(function (x) { return x !== first; });
          if (rest.length) o.text += '\n\nAlso ' + wd + ':\n- ' + rest.slice(0, 4).map(dueLine).join('\n- ') + (rest.length > 4 ? '\n- and ' + (rest.length - 4) + ' more, ' + inr(sum(rest.slice(4), function (x) { return x.amt; })) : '');
        } else if (!outs.length) {
          o.text = (label ? 'No ' + label + ' due ' : 'Nothing due ') + wd + '.';
          if (later.length) o.text += ' The next is ' + later[0].name + ', ' + inr(later[0].amt) + ' ' + at(later[0].date, today) + '.';
        } else o.text = '**' + inr(sumA(open.map(function (x) { return { a: x.amt }; }))) + '** to go out ' + wd + ':\n- ' + outs.map(dueLine).join('\n- ');
        // a week that ends before the bills a few days on: say what comes straight after
        var soon = win.words === 'this week' ? later.filter(function (x) { return x.date <= addDays(today, 7); }) : [];
        if (soon.length) o.text += '\n\nEarly next week: ' + inr(sum(soon, function (x) { return x.amt; })) + ' more, starting with ' + soon[0].name + ' ' + inr(soon[0].amt) + ' ' + at(soon[0].date, today) + '.';
        if (ins.length) o.text += '\n\nComing in: ' + joinAnd(ins.map(function (x) { return x.name + ' ' + inr(x.amt) + ' (' + on(x.date, today) + ')'; })) + '.';
        step('upcoming', 'What’s due', due.length + ' dated items ' + wd + '.');
        o.suggest = win.week ? ['Can I cover what’s due this week?', 'What’s due this month?'] : ['Can I cover what’s due this week?', 'What repeats every month?'];
        break;
      }
      case 'cover': {
        var winC = f.ahead && f.ahead.to ? f.ahead : dueWindow({ days: f.days || 7 }, today), untilC = winC.to, wd2 = winC.words;
        var acc = (ctx.accounts || []).filter(function (x) { return x.balance !== null && x.balance !== undefined; });
        var fresh = acc.filter(function (x) { return x.asOf && daysBetween(String(x.asOf).slice(0, 10), today) <= 10; }), stale = acc.filter(function (x) { return fresh.indexOf(x) < 0; });
        var dueC = (ctx.agenda || []).concat(loanDue(ctx, today)).filter(function (x) { return x.date && x.date >= today && x.date <= untilC && !x.booked; }).sort(function (a, b) { return a.date.localeCompare(b.date); });
        var outC = dueC.filter(function (x) { return x.kind !== 'in'; }), inC = dueC.filter(function (x) { return x.kind === 'in'; });
        var have = sum(fresh, function (x) { return x.balance; }), goOut = sum(outC, function (x) { return x.amt; }), comeIn = sum(inC, function (x) { return x.amt; }), spare = have + comeIn - goOut;
        if (!outC.length) o.text = 'Nothing is due ' + wd2 + ', so yes.';
        else if (!acc.length) o.text = inr(goOut) + ' goes out ' + wd2 + ', but kosh hasn’t seen a balance for your accounts yet, so it can’t say whether that’s covered.';
        else if (!fresh.length) o.text = inr(goOut) + ' goes out ' + wd2 + '. Your balances are all over 10 days old, so I can’t say for sure; the last ones add up to ' + inr(sum(acc, function (x) { return x.balance; })) + '.';
        else o.text = (spare >= 0 ? '**Yes.** ' : '**Not quite: ' + inr(-spare) + ' short.** ') + inr(have) + ' in ' + (fresh.length === 1 ? 'your ' + fresh[0].name + ' account' : fresh.length + ' accounts') + (comeIn ? ' and ' + inr(comeIn) + ' coming in' : '') +
          (spare >= 0 ? ' cover the ' : ' against the ') + inr(goOut) + ' going out ' + wd2 + (spare >= 0 ? ', with **' + inr(spare) + '** to spare.' : '.');
        if (outC.length) o.text += '\n\nGoing out:\n- ' + outC.map(function (x) { return on(x.date, today) + ' · ' + x.name + ' · ' + inr(x.amt); }).join('\n- ');
        // a week that ends in a day or two: what lands straight after, and whether the same money covers it too
        var afterC = winC.words === 'this week' ? (ctx.agenda || []).concat(loanDue(ctx, today)).filter(function (x) { return x.date && x.date > untilC && x.date <= addDays(today, 7) && !x.booked && x.kind !== 'in'; }).sort(function (a, b) { return a.date.localeCompare(b.date); }) : [];
        if (afterC.length && fresh.length) {
          var aOut = sum(afterC, function (x) { return x.amt; }), left2 = spare - aOut;
          o.text += '\n\nEarly next week: ' + inr(aOut) + ' more, starting with ' + afterC[0].name + ' ' + inr(afterC[0].amt) + ' ' + at(afterC[0].date, today) + '. With it, ' + (left2 >= 0 ? inr(left2) + ' would be left.' : 'you’d be ' + inr(-left2) + ' short.');
        }
        if (fresh.length && stale.length) o.text += '\n\n' + joinAnd(stale.map(function (x) { return x.name; })) + (stale.length === 1 ? '’s balance is' : ' balances are') + ' over 10 days old, so not counted.';
        step('cover', 'Balances against what’s due', inr(have) + ' in ' + fresh.length + ' fresh account(s), ' + inr(comeIn) + ' in, ' + inr(goOut) + ' out ' + wd2 + '.');
        o.suggest = ['What’s due this month?', 'What are my balances?'];
        break;
      }
      case 'balances': {
        // one person's accounts ("Papa's account", "Mummy ke account mein"), one bank's ("my HDFC balance", "Kotak
        // account mein kitna hai"): that account's balance, never the household's total in its place
        // one kind of account ("the NRE account", "my salary account"): those of that kind, first
        var qb = norm(f.q || ''), bkB = bankAsked(qb, ctx), kindB = kindAsked(qb);
        var bankOk = function (x) { return !bkB || bkB.test(x); };
        var whoB = f.person && personWord(f.person) !== 'You' ? f.person : '';
        var kindKnown = kindB ? (ctx.accounts || []).filter(function (x) { return bankOk(x) && acctIsKind(x, kindB, ctx) === true; }) : [];
        var inScope = function (x) { return (!f.person || personOk({ o: x.owner || 'me' }, f.person, ctx)) && bankOk(x) && (!kindKnown.length || kindKnown.indexOf(x) >= 0); };
        var scoped = !!(f.person || bkB || kindKnown.length);
        var acAll = (ctx.accounts || []).filter(inScope), ac = acAll.filter(function (x) { return x.balance !== null && x.balance !== undefined; });
        var bkWord = bkB ? bkB.word + ' ' : '';
        var whose = whoB ? whoB + '’s ' : 'your ';
        var asOfB0 = function (x) { var d = String(x.asOf || '').slice(0, 10), age = isDay(d) ? daysBetween(d, today) : 99; return isDay(d) ? ' (' + (age <= 1 ? 'as of ' + on(d, today) : age <= 10 ? 'as of ' + dShort(d) : dShort(d) + ', may be out of date') + ')' : ''; };
        // GUARDRAIL an NRE, NRO or salary account asked for when no account kosh knows says which it is: said so, with
        // each account's balance, never the household's total given as that account's
        if (kindB && kindB !== 'savings' && !kindKnown.length) {
          var cand = (ctx.accounts || []).filter(function (x) { return bankOk(x) && (!f.person || personOk({ o: x.owner || 'me' }, f.person, ctx)) && x.balance !== null && x.balance !== undefined; });
          var whoseA = function (x) { var ow = x.owner || 'me', p = (ctx.people || []).filter(function (y) { return y.id === ow; })[0]; return ow === 'me' || !p ? '' : p.name + '’s '; };
          o.text = 'kosh can’t tell which ' + (bkWord ? bkWord + 'account' : 'account') + ' is ' + (whoB ? whoB + '’s ' : 'the ') + ACCT_KIND_NAME[kindB] + ' one: nothing kosh has read names it' + (kindB === 'salary' ? ', and no salary has come into one' : '') + '.' +
            (cand.length ? ' The ' + (cand.length === 1 ? 'account' : 'accounts') + ' it knows' + (bkWord ? ' at ' + bkWord.trim() : '') + ':\n- ' + cand.map(function (x) { return whoseA(x) + acctLabel(x) + ' · ' + inr(x.balance) + asOfB0(x); }).join('\n- ') + '\n\nGive the ' + ACCT_KIND_NAME[kindB] + ' one a name with “' + ACCT_KIND_NAME[kindB] + '” in it on its page, and kosh answers for it.' : '');
          step('balances', 'Balances', 'no account named as ' + ACCT_KIND_NAME[kindB] + '.');
          o.suggest = ['What are my balances?'];
          break;
        }
        // "the current account": the account in the business's name (a household's savings accounts are in a person's)
        if (/\bcurrent (?:account|a\/c|khata)\b|\bbusiness(?:'s)? (?:account|a\/c)\b|\bshop(?:'s)? (?:account|a\/c)\b|\bfirm(?:'s)? (?:account|a\/c)\b/.test(qb)) {
          var curA = (ctx.accounts || []).filter(function (x) { return (x.biz || bizOwners(ctx).indexOf(x.owner || '') >= 0 || /\bcurrent\b/i.test(acctWords(x))) && x.balance !== null && x.balance !== undefined && bankOk(x); });
          if (curA.length) {
            o.text = curA.length === 1 ? '**' + inr(curA[0].balance) + '** in the current account, ' + acctLabel(curA[0]) + asOfB0(curA[0]) + '.'
              : '**' + inr(sumA(curA.map(function (x) { return { a: x.balance }; }))) + '** across ' + n_(curA.length, 'current account') + ':\n- ' + curA.map(function (x) { return acctLabel(x) + ' · ' + inr(x.balance) + asOfB0(x); }).join('\n- ');
            step('balances', 'The current account', curA.length + ' in the business’s name.');
            o.suggest = ['How much did the business get from customers last month?', 'What are my balances?'];
            break;
          }
        }
        // a person's account at a bank kosh files as someone else's ("Sunita ke HDFC account" with the HDFC account filed as
        // yours): that bank's account, said whose kosh has it as
        if (!acAll.length && whoB && bkB) {
          var atBank = (ctx.accounts || []).filter(function (x) { return bkB.test(x) && x.balance !== null && x.balance !== undefined; });
          if (atBank.length === 1) {
            var ow = atBank[0].owner || 'me', owP = (ctx.people || []).filter(function (x) { return x.id === ow; })[0];
            o.text = '**' + inr(atBank[0].balance) + '** in ' + acctLabel(atBank[0]) + asOfB0(atBank[0]) + ', the one ' + bkWord + 'account kosh knows. It’s filed as ' + (ow === 'me' ? 'yours' : owP ? owP.name + '’s' : 'someone else’s') + ', not ' + whoB + '’s: if it’s ' + whoB + '’s, change its owner on the account’s page.';
            step('balances', 'Balances', 'one ' + bkWord.trim() + ' account, filed under ' + ow + '.');
            o.suggest = ['What are my balances?'];
            break;
          }
        }
        // a bank or app kosh has no account at ("my Orbit balance"): said, never another account's balance in its place
        var unk = !bkB && !whoB && /\b([a-z]{3,}) (?:balance|account|a\/c)\b/.exec(qb);
        if (unk && !STOP[unk[1]] && !HI_STOP[unk[1]] && !/^(?:bank|savings?|current|salary|joint|nre|nro|business|shop|firm|total|wallet|credit|debit|demat|trading|loan|cash|minimum|available|closing|opening|average|remaining|outstanding|family|household|everyone|whose|kiske|kis|their|his|her|mummy|papa|personal|main|other|second|old|new|both|which)$/.test(unk[1]) &&
            !(ctx.accounts || []).concat(ctx.wallets || []).concat(ctx.cards || []).some(function (x) { return (lc(x.name) + ' ' + lc(x.bank || '')).indexOf(unk[1]) >= 0; }) && !personOf2(unk[1], ctx)) {
          o.text = 'kosh doesn’t know ' + (/^[aeiou]/.test(unk[1]) ? 'an ' : 'a ') + cap1(unk[1]) + ' account yet: no alert or statement from it is in the mail kosh reads. Once one comes in, its balance shows here.';
          o.suggest = ['What are my balances?'];
          break;
        }
        if (!ac.length) {
          o.text = !scoped ? 'kosh hasn’t seen a balance for your accounts yet. A bank’s statement or a balance alert brings it in, or you can type it on the account’s page.'
            : acAll.length ? 'kosh hasn’t seen a balance for ' + whose + bkWord + 'account' + (acAll.length > 1 ? 's' : '') + ' (' + acAll.map(function (x) { return acctLabel(x); }).join(', ') + ') yet. A balance alert or a statement brings it in.'
            : 'kosh doesn’t know ' + (whoB ? 'an account of ' + whoB + '’s' + (bkWord ? ' at ' + bkWord.trim() : '') : (/^[AEIOU]/.test(bkWord) ? 'an ' : 'a ') + bkWord + 'account of yours') + ' yet.';
          break;
        }
        var fresh = ac.filter(function (x) { return x.asOf && daysBetween(String(x.asOf).slice(0, 10), today) <= 10; });
        var asOfB = function (x) { var d = String(x.asOf || '').slice(0, 10), age = isDay(d) ? daysBetween(d, today) : 99; return isDay(d) ? ' (' + (age <= 1 ? 'as of ' + on(d, today) : age <= 10 ? 'as of ' + dShort(d) : dShort(d) + ', may be out of date') + ')' : ''; };
        var nameB = function (x) { return acctLabel(x); };
        if (scoped && ac.length === 1) o.text = '**' + inr(ac[0].balance) + '** in ' + whose + nameB(ac[0]) + asOfB(ac[0]) + '.';
        else o.text = '**' + inr(sumA(ac.map(function (x) { return { a: x.balance }; }))) + '** across ' + (scoped ? whose + bkWord : '') + n_(ac.length, 'account') + ':\n- ' + ac.map(function (x) { return nameB(x) + ' · ' + inr(x.balance) + asOfB(x); }).join('\n- ');
        if (scoped && acAll.length > ac.length) o.text += '\n\n' + cap1(n_(acAll.length - ac.length, 'more account')) + ' without a balance kosh has seen.';
        if (fresh.length < ac.length) o.text += '\n\nBalances over 10 days old may have moved since.';
        step('balances', 'Balances', ac.length + ' accounts with a balance' + (scoped ? ' (' + (whoB ? whoB + '’s' : '') + (bkWord ? ' ' + bkWord.trim() : '') + ')' : '') + '.');
        o.suggest = ['Can I cover what’s due this week?', 'How much have I spent this month?'];
        break;
      }
      case 'repeats': {
        // "how much SIP goes every month", "my EMIs": that kind alone (a committee is its own kind, never an SIP)
        var kd = f.subs ? 'sub' : f.kind || '';
        var rp = (ctx.recurring || []).filter(function (x) { return !x.lapsed && (!kd || x.kind === kd); }).sort(function (a, b) { return b.amount / (b.per || 1) - a.amount / (a.per || 1); });
        // EMIs kosh hasn't seen repeat yet: the loans added in Wealth › Debts
        if (kd === 'emi' && !rp.length) rp = (ctx.loans || []).filter(function (l) { return l.active !== false && l.emi > 0; }).map(function (l) { return { name: l.name, amount: l.emi, per: 1, date: '' }; });
        var KN = { sub: ['subscription'], sip: ['SIP'], emi: ['EMI'], bill: ['bill'], staff: ['payment to household help', 'payments to household help'] }[kd] || ['repeat'];
        if (!rp.length) { o.text = kd === 'sub' ? 'No subscriptions found yet. kosh spots one once it has come twice, about a month apart.' : kd ? 'No ' + KN[0] + 's found yet. kosh spots one once it has come twice, about a month apart.' : 'No repeating payments found yet.'; break; }
        var cyc = function (x) { return x.per === 12 ? ' a year' : x.per === 6 ? ' every six months' : x.per === 3 ? ' every three months' : ''; };
        o.text = '**' + cap1(n_(rp.length, KN[0], KN[1])) + '**, about **' + inr(sum(rp, function (x) { return x.amount / (x.per || 1); })) + '** a month' + (rp.length > 1 ? ' taken together' : '') + ':\n- ' + rp.slice(0, 12).map(function (x) { return x.name + ' · ' + inr(x.amount) + cyc(x) + (x.date ? ' · next ' + on(x.date, today) : ''); }).join('\n- ') +
          (rp.length > 12 ? '\n- and ' + (rp.length - 12) + ' more' : '');
        step('repeats', 'Repeats', rp.length + ' found.');
        o.suggest = f.subs ? ['What repeats every month?', 'How much do I spend on subscriptions a month?'] : ['Which subscriptions do I pay for?', 'What’s due this week?'];
        break;
      }
      case 'income': {
        /* GUARDRAIL money from someone named ("how much has Ankit paid me back"): with no stretch said, all of the last
           12 months, and their transfers in count (money from them is what was asked) */
        var fromWho = !!f.merchant && (!f.category || f.category === 'Refund');
        var sp7 = span || (fromWho ? { from: addDays(today, -364), to: today, label: 'in the last 12 months' } : thisMonth), w7 = span || !fromWho ? spanWords(sp7, today) : 'in the last 12 months';
        // (money back on a payment isn't money in, ex; a question about refunds is about exactly that)
        // (the business's customers pay it by transfer: that's its money in)
        var ins7 = (ctx.tx || []).filter(function (t) { return t.k === 'in' && (!t.ex || f.category === 'Refund') && (f.biz || fromWho || t.c !== 'Transfer in') && t.c !== 'Self Transfer' && within2(t, sp7, today) && fits(t, f, ctx); });
        /* GUARDRAIL a reimbursement asked as what came in ("how much reimbursement came last month"): the credits that
           say so (a transfer in counts), never everything that came in given as the reimbursement */
        if (f.reimb) {
          var reR = (ctx.tx || []).filter(function (t) { return (t.k === 'in' || (t.k === 'move' && /^transfer in$/i.test(t.c || ''))) && t.a > 0 && within2(t, sp7, today) && /reimb|\bclaims?\b|\bexp(?:ense)?s? (?:claim|settle|reimb)|\bta ?\/? ?da\b|\bconveyance\b/i.test((t.m || '') + ' ' + (t.n || '') + ' ' + (t.s || '')); }).sort(byDate);
          if (!reR.length) { o.text = 'kosh hasn’t seen a reimbursement come in ' + spanWords(sp7, today) + '. It looks for credits that say reimbursement or claim; one paid with your salary is part of the salary credit.'; o.suggest = ['How much salary did I get last month?', 'What came in last month?']; break; }
          o.text = '**' + inr(sumA(reR)) + '** came in as reimbursement ' + spanWords(sp7, today) + (reR.length === 1 ? ', ' + at(reR[0].d, today) : ', across ' + n_(reR.length, 'credit') + '; the last ' + inr(reR[0].a) + ' ' + at(reR[0].d, today)) + '.';
          o.rows = idsOf(reR);
          step('income', 'Reimbursements', reR.length + ' credits, ' + inr(sumA(reR)) + '.');
          o.suggest = ['Make my travel claim for this month', 'What came in last month?'];
          break;
        }
        // rent and refunds by what they are: "rent that came in", never rent you pay
        var asWord = { 'Rent received': 'rent', 'Refund': 'a refund', 'Salary': 'salary', 'Interest': 'interest', 'Dividend': 'dividends', 'Cashback': 'cashback' }[f.category] || '';
        if (f.usual && !span && !f.biz) {
          // what usually comes: each stream (who pays it, into which account), the latest first
          var yr7 = { from: addDays(today, -364), to: today };
          var base7 = function (ff) { return (ctx.tx || []).filter(function (t) { return t.k === 'in' && !t.ex && t.c !== 'Transfer in' && t.c !== 'Self Transfer' && within2(t, yr7, today) && fits(t, ff, ctx); }).sort(byDate); };
          var u7 = base7(f), noteU = '';
          if (!u7.length && f.person && personWord(f.person) !== 'You') { u7 = base7(Object.assign({}, f, { person: undefined })); if (u7.length) noteU = 'kosh files all of it as yours, so it can’t tell which is ' + f.person + '’s. '; }
          if (u7.length) {
            var st7 = {}, keys7 = [];
            u7.forEach(function (t) { var k = payerKey(t.m) + '|' + (t.card || ''); if (!st7[k]) { st7[k] = []; keys7.push(k); } st7[k].push(t); });
            var streams = keys7.map(function (k) { return st7[k]; }).sort(function (a, b) { var ra = daysBetween(a[0].d, today) <= 45, rb = daysBetween(b[0].d, today) <= 45; if (ra !== rb) return ra ? -1 : 1; return median(b.slice(0, 3).map(function (t) { return t.a; })) - median(a.slice(0, 3).map(function (t) { return t.a; })); });
            var wordU = asWord || (f.category ? lc(f.category) : 'money in'), plain = function (m) { return /^(?:money in|neft credit|credit|transfer in|imps credit|upi credit|nach credit)$/i.test(String(m || '').trim()); };
            // (a payer's own regular credit: its smaller ones, a reimbursement beside a salary, aren't what it pays)
            var oneU = function (sx0) { var top = Math.max.apply(null, sx0.map(function (t) { return t.a; })), sx = sx0.filter(function (t) { return t.a >= top * 0.5; }); var a0 = sx[0].a, same = sx.slice(0, 3).every(function (t) { return Math.abs(t.a - a0) < 1; }), gap = sx.length > 1 ? daysBetween(sx[1].d, sx[0].d) : 0;
              return (same ? '**' + inr(a0) + '**' : 'about **' + inr(median(sx.slice(0, 3).map(function (t) { return t.a; }))) + '**') + (gap >= 25 && gap <= 35 ? ' a month' : '') + (plain(sx[0].m) || !payerName(sx[0].m) ? '' : ', from ' + payerName(sx[0].m)) + ': the last came ' + at(sx[0].d, today) + (same ? '' : ' (' + inr(a0) + ')'); };
            if (streams.length === 1 || (f.category === 'Salary' && !noteU)) o.text = noteU + (noteU ? 'The ' : f.person && personWord(f.person) !== 'You' ? f.person + '’s ' : 'Your ') + wordU + ' is ' + oneU(streams[0]) + '.';
            else o.text = noteU + cap1(wordU) + ' comes in ' + streams.length + ' ways:\n- ' + streams.slice(0, 5).map(function (sx) { return oneU(sx).replace(/: the last came/, ', into ' + (sx[0].card || 'an account') + '; the last came'); }).join('\n- ');
            o.rows = idsOf(u7);
            step('income', 'What usually comes in' + (f.category ? ' as ' + wordU : ''), u7.slice(0, 6).map(function (t) { return t.d + ' ' + t.m + ' ' + inr(t.a); }).join('; ') + '.');
            o.suggest = ['When did my salary come last?', 'Money in, month by month'];
            break;
          }
        }
        if (!ins7.length) {
          o.text = f.category === 'Rent received' ? 'No rent has come in ' + w7 + ' yet.' : asWord ? 'Nothing came in as ' + asWord + ' ' + w7 + '.' : 'Nothing has come in' + subj + ' ' + w7 + ' yet.';
          /* GUARDRAIL no stretch named and nothing yet this month: interest, rent, dividends come a few times a year, so
             the answer goes on to the last one and the last 12 months, and says when rent is late */
          if (!span && f.category) {
            var yr7 = (ctx.tx || []).filter(function (t) { return t.k === 'in' && !t.ex && t.c !== 'Transfer in' && t.c !== 'Self Transfer' && within2(t, { from: addDays(today, -364), to: today }, today) && fits(t, f, ctx); }).sort(byDate);
            if (yr7.length) { o.text += ' The last was ' + inr(yr7[0].a) + ' from ' + yr7[0].m + ' ' + at(yr7[0].d, today) + '; ' + inr(sumA(yr7)) + ' in the last 12 months.'; o.rows = idsOf(yr7); }
          }
          if (f.category === 'Rent received' && sp7.to >= today) (ctx.watch || []).filter(function (w) { return /^Rent from .* (?:late|behind)/.test(w.title || ''); }).slice(0, 2).forEach(function (w) { o.text += ' ' + w.title + '.'; });
          /* GUARDRAIL nothing filed as income, but money came in by transfer (a freelancer's PayPal, a client's NEFT):
             said, with what came, never "nothing came in" alone */
          if (!f.category && !fromWho && !f.biz && !f.person) {
            var trIn = (ctx.tx || []).filter(function (t) { return t.k === 'in' && !t.ex && t.a > 0 && t.c === 'Transfer in' && within2(t, sp7, today); }).sort(byAmt);
            if (trIn.length) {
              var trBy = groupBy(trIn, 'payee', ctx).slice(0, 3);
              o.text = 'kosh hasn’t filed anything that came in ' + w7 + ' as income. **' + inr(sumA(trIn)) + '** came in as transfers' + (trBy.length ? ': ' + joinAnd(trBy.map(function (x) { return (payerName(x.name) || x.name) + ' ' + inr(x.v); })) + (groupBy(trIn, 'payee', ctx).length > 3 ? ' and more' : '') : '') + '. If some of it is what you earned, mark it as income and kosh counts it.';
              o.rows = idsOf(trIn);
              step('income', 'Money in by transfer', trIn.length + ' credits ' + w7 + ', ' + inr(sumA(trIn)) + '.');
              break;
            }
          }
          if (!span && !f.category && !fromWho) { var lm = addDays(thisMonth.from, -1); var prevIn = (ctx.tx || []).filter(function (t) { return t.k === 'in' && !t.ex && t.c !== 'Transfer in' && t.c !== 'Self Transfer' && t.d.slice(0, 7) === lm.slice(0, 7) && fits(t, f, ctx); }); if (prevIn.length) o.text += ' In ' + MONF[+lm.slice(5, 7) - 1] + ': ' + inr(sumA(prevIn)) + '.'; }
          break;
        }
        /* GUARDRAIL "did my Zepto refund come?" (a shop's refund, no stretch named) is asked of the latest: it leads, with
           the payment it paid back (the refund tracker's own row, refOf), then the shop's last 12 months; a refund kosh
           couldn't tie to a payment (one for a purchase from before the mail it read, nt) is said as such, so the
           12 months' sum and the Refunds screen's rows plainly agree */
        if (f.category === 'Refund' && f.merchant && !span) {
          var rf7 = ins7.slice().sort(byDate), last7 = rf7[0], forT = last7.refOf ? (ctx.tx || []).filter(function (t) { return t.id === last7.refOf; })[0] : null;
          var loose7 = rf7.filter(function (t) { return !t.refOf; }), shop7 = payerName(last7.pf || last7.m) || last7.pf || last7.m;
          o.text = 'Yes: **' + inr(last7.a) + '** came back from ' + shop7 + ' ' + at(last7.d, today) + (forT ? ', for the ' + inr(forT.full !== undefined ? forT.full : forT.a + (forT.refunded || 0)) + ' payment of ' + dShort(forT.d) : '') + '.' +
            (rf7.length > 1 ? ' In all, ' + inr(sumA(rf7)) + ' came back from ' + shop7 + ' ' + w7 + ' in ' + n_(rf7.length, 'refund') + (loose7.length ? '; ' + inr(sumA(loose7)) + ' of it kosh couldn’t tie to a payment (bought before the mail it read), so it’s off your ' + lc(loose7[0].nt || 'spending') + ', not on the Refunds list' : '') + '.' : '');
          o.rows = idsOf(rf7);
          step('income', 'Refunds from ' + shop7, rf7.length + ' credits ' + w7 + ', ' + inr(sumA(rf7)) + '; the last ' + inr(last7.a) + ' on ' + last7.d + '.');
          o.suggest = ['What came in last month?'];
          break;
        }
        var src = groupBy(ins7, f.category || f.biz ? 'payee' : 'category', ctx), subjIn = about(Object.assign({}, f, { dir: 'in', category: asWord ? '' : f.category }), ctx);
        o.text = '**' + inr(sumA(ins7)) + '** came in' + (asWord ? ' as ' + asWord : '') + subjIn + ' ' + w7 + (f.merchant && src.length === 1 ? (f.category ? '' : ', as ' + ({ 'Rent received': 'rent', 'Refund': 'a refund', 'Transfer in': 'a transfer', 'Money in': 'money in' }[src[0].name] || lc(src[0].name))) + '.' : ': ' + joinAnd(src.slice(0, 5).map(function (x) { return x.name + ' ' + inr(x.v); })) + '.') + sinceNote(sp7, ctx);
        o.rows = idsOf(ins7);
        step('income', 'Money in', w7 + ' ' + inr(sumA(ins7)) + ' from ' + ins7.length + ' credits.');
        o.suggest = ['How much did I save last month?', 'Money in, month by month'];
        break;
      }
      case 'sentall': {
        // money sent to people (family, friends, anyone paid by name), never shops: transfers out, by whom they went to
        var spA = span || thisMonth, wA = spanWords(spA, today);
        var famA = (ctx.people || []).filter(function (p) { return p.id !== 'me'; }).map(function (p) { return lc(p.full || p.name); }).filter(function (n) { return n.length >= 5; });
        var rowsA = (ctx.tx || []).filter(function (t) {
          if (!(t.a > 0) || !within2(t, spA, today) || !personOk(t, f.person, ctx)) return false;
          if (!(t.k === 'out' || (t.k === 'move' && t.c !== 'Self Transfer' && !/^transfer in$/i.test(t.c || '')))) return false;
          return /^(?:money out|transfers?|family|friends|gifts?)$/i.test(t.c || '') || famA.some(function (n) { return lc(t.m).indexOf(n) >= 0; });
        }).sort(byDate);
        if (!rowsA.length) { o.text = 'kosh hasn’t seen money sent to anyone ' + wA + '.'; o.suggest = ['Who did I pay the most this month?']; break; }
        var toA = groupBy(rowsA, 'payee', ctx);
        o.text = 'You sent **' + inr(sumA(rowsA)) + '** ' + wA + ', across ' + n_(rowsA.length, 'transfer') + ': ' + joinAnd(toA.slice(0, 4).map(function (x) { return x.name + ' ' + inr(x.v); })) + (toA.length > 4 ? ' and ' + n_(toA.length - 4, 'other') : '') + '.' + sinceNote(spA, ctx);
        o.rows = idsOf(rowsA);
        step('transactions', 'Money sent', rowsA.length + ' transfers ' + wA + ', ' + inr(sumA(rowsA)) + '.');
        o.suggest = ['Show these payments', 'Who did I pay the most this month?'];
        break;
      }
      case 'billpaid': {
        /* GUARDRAIL one bill, paid or not: a payment made in the weeks before the bill's due date pays it (the calendar
           can still carry a bill paid early), so it's said as paid; a bill due with no payment since is said as not paid */
        var wP = f.word || '', kindP = BILL_KIND.filter(function (k) { return k[1].test(' ' + wP + ' '); })[0];
        var payP = (ctx.tx || []).filter(function (t) { return (t.k === 'out' || t.k === 'prepaid') && t.a > 0 && t.d <= today && (has(t.m, wP) || (kindP && (billNameOk(t, kindP[0]) || kindP[3].test(t.s || '')))); }).sort(byDate);
        var dueP = (ctx.agenda || []).filter(function (x) { return x.kind !== 'in' && x.date && x.date >= addDays(today, -20) && (has(x.name, wP) || (kindP && (kindP[3].test(x.cat || '') || kindP[2].test(x.name || '')))); }).sort(function (a, b) { return a.date.localeCompare(b.date); })[0];
        var nameP = payP.length ? payP[0].m : dueP ? dueP.name : wP.toUpperCase().length <= 5 ? wP.toUpperCase() : cap1(wP);
        var lastP = payP[0];
        if (dueP && lastP && lastP.d >= addDays(dueP.date, -25)) o.text = 'Yes: **' + inr(lastP.a) + '** paid to ' + lastP.m + ' ' + at(lastP.d, today) + ', for the bill due ' + on(dueP.date, today) + '.';
        else if (dueP) o.text = 'Not yet: the ' + nameP + ' bill' + (dueP.amt ? ' of **' + inr(dueP.amt) + '**' : '') + ' is due ' + on(dueP.date, today) + '.' + (lastP ? ' The last payment was ' + inr(lastP.a) + ' ' + at(lastP.d, today) + '.' : '');
        else if (lastP && daysBetween(lastP.d, today) <= 45) o.text = 'Yes: the last ' + nameP + ' payment was **' + inr(lastP.a) + '** ' + at(lastP.d, today) + ', and kosh hasn’t seen a newer bill.';
        else if (lastP) o.text = 'kosh hasn’t seen a ' + nameP + ' bill due now. The last payment was ' + inr(lastP.a) + ' ' + at(lastP.d, today) + '.';
        else o.text = 'kosh hasn’t seen a payment or a bill for ' + nameP + '.';
        o.rows = idsOf(payP.slice(0, 6));
        step('bills', 'The ' + nameP + ' bill', (lastP ? 'last paid ' + lastP.d + ' ' + inr(lastP.a) : 'no payment') + (dueP ? '; due ' + dueP.date : '') + '.');
        o.suggest = ['What bills are due this week?', 'How much did we pay for electricity this year?'];
        break;
      }
      case 'goldscheme': {
        // the instalments into a jeweller's gold scheme: from its first one, unless a stretch is named
        // (a scheme is paid the same amount again and again; one buy at a jeweller is shopping, not an instalment)
        var gAll = (ctx.tx || []).filter(function (t) { return (t.k === 'out' || putIn(t)) && t.a > 0 && t.d <= today && GOLD_SCHEME_ROW.test(t.m || '') && (!f.merchant || /^gold$/.test(f.merchant) || has(t.m, f.merchant)); });
        var gBy = {}; gAll.forEach(function (t) { (gBy[lc(t.m).trim()] = gBy[lc(t.m).trim()] || []).push(t); });
        var schemeP = Object.keys(gBy).filter(function (k) { var xs = gBy[k]; return xs.filter(function (t) { return xs.filter(function (u) { return Math.abs(u.a - t.a) < 1; }).length >= 3; }).length >= 3; });
        var rowsG = gAll.filter(function (t) { return schemeP.indexOf(lc(t.m).trim()) >= 0 && (!span || within2(t, span, today)); }).sort(byDate);
        if (!rowsG.length) { o.text = 'kosh hasn’t seen a payment into a gold scheme' + (span ? ' ' + spanWords(span, today) : '') + '. It looks for payments to a jeweller or a scheme by name.'; o.suggest = ['What do I have to pay in the next two weeks?']; break; }
        var toG = []; rowsG.forEach(function (t) { if (toG.indexOf(t.m) < 0) toG.push(t.m); });
        var sameG = rowsG.every(function (t) { return Math.abs(t.a - rowsG[0].a) < 1; });
        o.text = 'You’ve paid **' + inr(sumA(rowsG)) + '** into ' + joinAnd(toG.slice(0, 3)) + (span ? ' ' + spanWords(span, today) : ' so far') + ', ' + n_(rowsG.length, 'instalment') + (sameG ? ' of ' + inr(rowsG[0].a) : '') + ', the first ' + at(rowsG[rowsG.length - 1].d, today) + ' and the last ' + at(rowsG[0].d, today) + '.' + sinceNote(span || { from: rowsG[rowsG.length - 1].d, to: today }, ctx);
        o.rows = idsOf(rowsG);
        step('transactions', 'Gold scheme instalments', rowsG.length + ' payments, ' + inr(sumA(rowsG)) + '.');
        o.suggest = ['Show these payments', 'What do I have to pay in the next two weeks?'];
        break;
      }
      case 'cashdep': {
        // cash put into an account: credits marked as cash ("BY CASH", "CASH DEP", a deposit machine), this year unless said
        var spD = span || { from: today.slice(0, 4) + '-01-01', to: today, label: 'this year' }, wD = spanWords(spD, today);
        var rowsD = (ctx.tx || []).filter(function (t) { return (t.k === 'in' || t.k === 'move') && t.a > 0 && within2(t, spD, today) && CASH_DEP_ROW.test((t.m || '') + ' ' + (t.n || '') + ' ' + (t.s || '')) && personOk(t, f.person, ctx); }).sort(byDate);
        if (!rowsD.length) { o.text = 'kosh hasn’t seen cash deposited ' + wD + '. It counts credits your bank marks as cash (“BY CASH”, “CASH DEP”, a deposit machine).'; o.suggest = ['How much cash did I withdraw this year?']; break; }
        o.text = 'You deposited **' + inr(sumA(rowsD)) + '** in cash ' + wD + ', ' + (rowsD.length === 1 ? 'once, ' + at(rowsD[0].d, today) : 'across ' + n_(rowsD.length, 'deposit') + ', the last ' + inr(rowsD[0].a) + ' ' + at(rowsD[0].d, today)) + '.' + sinceNote(spD, ctx);
        o.rows = idsOf(rowsD);
        step('income', 'Cash deposits', rowsD.length + ' ' + wD + ', ' + inr(sumA(rowsD)) + '.');
        o.suggest = ['How much cash did I withdraw this year?'];
        break;
      }
      case 'refundsDue': {
        /* GUARDRAIL refunds still to come: the rows of the Refunds list as Home shows them (snap.refunds: a payment with
           money owed back on it, state not "back"), then the shop's word on a refund kosh can see no payment for
           (snap.refundPromises), each with what is left, since when and by when. The figure is each row's own (exp -
           back), never a sum of credits from the ledger. With no Refunds list in the context (an older phone), kosh
           says it can't see it, not that none is owed */
        if (!Array.isArray(ctx.refunds)) { o.text = 'kosh can’t see the Refunds list from here. Open Home › Genie › Refunds to see what is still to come back.'; break; }
        var squash = function (x) { return String(x || '').toLowerCase().replace(/[^a-z0-9]/g, ''); };
        var leftR = function (r) { return Math.max(0, (+r.exp || 0) - (+r.back || 0)); };
        var shopR = squash(f.shop || '');
        // (a shop named, "is my Exampleshop refund late": its rows; a name no row has is no filter at all)
        var shopOk = function (r) { var m = squash(r.m); return m.length >= 3 && (m.indexOf(shopR) >= 0 || shopR.indexOf(m) >= 0); };
        if (shopR.length < 3 || !ctx.refunds.some(shopOk)) shopR = '';
        var openR = ctx.refunds.filter(function (r) { return r.state !== 'back' && leftR(r) > 0.5 && (!shopR || shopOk(r)); });
        var paidR = openR.filter(function (r) { return r.list !== 'promise'; }), wordR = openR.filter(function (r) { return r.list === 'promise'; });
        var lineR = function (r) {
          var late = r.state === 'late';
          return (r.m || 'A shop') + ' ' + inr(leftR(r)) + (r.list === 'promise' ? (r.order ? ' (order ' + r.order + ')' : '') : r.a > 0 ? ' for the ' + inr(r.a) + ' payment of ' + dShort(r.d) : '') +
            (+r.back > 0.5 ? ', ' + inr(r.back) + ' of ' + inr(r.exp) + ' back so far' : '') + (r.by ? (late ? ', late: due by ' : ', due by ') + dShort(r.by) : late ? ', late' : '');
        };
        // the headline is the Refunds list's own figure, as Home shows it; the shop's word on a refund for a payment kosh
        // can't see (bought before the mail it read) is said apart, never added into it
        var wordLine = wordR.length ? 'The shop’s word on ' + (wordR.length === 1 ? 'one more' : n_(wordR.length, 'more')) + ', for a payment kosh can’t see:\n- ' + wordR.slice(0, 5).map(lineR).join('\n- ') : '';
        if (!paidR.length) {
          var doneR = ctx.refunds.filter(function (r) { return r.state === 'back' && r.list !== 'promise'; }).length;
          o.text = (wordR.length ? 'Nothing on your Refunds list is still to come.' : 'No refund is pending' + (doneR ? ': the ' + n_(doneR, 'refund') + ' kosh is tracking ' + (doneR === 1 ? 'has' : 'have') + ' come back.' : '. kosh isn’t tracking any refund owed to you.')) +
            (wordLine ? ' ' + wordLine : '');
          if (wordR.length) step('refunds', 'The shop’s word', wordR.map(function (r) { return (r.m || '') + ' ' + inr(leftR(r)); }).join('; ') + '.');
          break;
        }
        o.text = '**' + inr(sumA(paidR.map(function (r) { return { a: leftR(r) }; }))) + '** still to come back on ' + n_(paidR.length, 'payment') + ':\n- ' + paidR.slice(0, 8).map(lineR).join('\n- ') + (wordLine ? '\n\n' + wordLine : '');
        step('refunds', 'Refunds still to come', openR.map(function (r) { return (r.m || '') + ' ' + inr(leftR(r)); }).join('; ') + '.');
        o.suggest = ['Did my last refund come?'];
        break;
      }
      case 'taxrefund': {
        /* GUARDRAIL an income-tax refund asked: the credit from the tax department in the ledger (CBDT, ITD, "TAX
           REFUND"), never the tax papers kosh can't read. A refund by bank transfer that isn't money back on a purchase
           is offered as likely it when no credit names the department; nothing is made up when neither came */
        var yrF = { from: addDays(today, -540), to: today };
        var txtF = function (t) { return (t.m || '') + ' ' + (t.n || '') + ' ' + (t.s || '') + ' ' + (t.c || ''); };
        var namedF = (ctx.tx || []).filter(function (t) { return t.k === 'in' && t.a > 0 && within2(t, span || yrF, today) && TAX_REFUND_ROW.test(txtF(t)) && !/\btds\b/i.test(t.m || ''); }).sort(byDate);
        var intoF = function (t) { return t.card ? ' into ' + t.card : ''; };
        if (namedF.length) {
          o.text = namedF.length === 1 ? 'Yes: **' + inr(namedF[0].a) + '** came as an income-tax refund ' + at(namedF[0].d, today) + intoF(namedF[0]) + '.'
            : 'Yes: ' + n_(namedF.length, 'income-tax refund') + ', **' + inr(sumA(namedF)) + '** in all:\n- ' + namedF.slice(0, 5).map(function (t) { return inr(t.a) + ' ' + at(t.d, today) + intoF(t); }).join('\n- ');
          o.rows = idsOf(namedF);
          step('income', 'Income-tax refunds', namedF.map(function (t) { return t.d + ' ' + inr(t.a); }).join('; ') + '.');
        } else {
          var likelyF = (ctx.tx || []).filter(function (t) { return t.k === 'in' && t.a >= 100 && t.c === 'Refund' && !t.refOf && /^(?:transfer|bank)$/.test(t.md || '') && within2(t, span || yrF, today); }).sort(byDate);
          if (likelyF.length) {
            o.text = 'kosh hasn’t seen a credit that names the income-tax department. A refund came by bank transfer, not against a purchase: **' + inr(likelyF[0].a) + '** ' + at(likelyF[0].d, today) + intoF(likelyF[0]) + (likelyF[0].m && !/^(?:neft|imps|rtgs|upi)? ?credit$|^money in$/i.test(likelyF[0].m) ? ', from ' + likelyF[0].m : '') + '. If that’s your tax refund, it has come.';
            o.rows = idsOf(likelyF.slice(0, 1));
            step('income', 'Refunds by transfer', likelyF.slice(0, 3).map(function (t) { return t.d + ' ' + inr(t.a); }).join('; ') + '.');
          } else o.text = 'kosh hasn’t seen an income-tax refund come in ' + (span ? spanWords(span, today) : 'over the last 18 months') + '. It looks for the credit from the tax department (CBDT, “TAX REFUND”) in your bank’s alerts.';
        }
        o.suggest = ['How much advance tax have I paid this financial year?', 'What came in this month?'];
        break;
      }
      case 'tax': {
        // tax by its kind, over the financial year it belongs to ("is saal", "this year": the financial year so far)
        var fyS = (+today.slice(5, 7) >= 4 ? +today.slice(0, 4) : +today.slice(0, 4) - 1) + '-04-01';
        var spT = span && !(f.label === 'this year' && span.from === today.slice(0, 4) + '-01-01') ? span : { from: fyS, to: today, label: 'this financial year' };
        var wT = spT.from === fyS && (spT.to || today) >= today ? 'this financial year (since ' + dShort(fyS) + ' ' + fyS.slice(0, 4) + ')' : spanWords(spT, today);
        var taxish = function (t) { return t.k === 'out' && t.a > 0 && (/^(?:tax|income tax)$/i.test(t.c || '') || /tax/i.test(t.s || '') || /\bgst\b|income ?tax|advance tax|itns|challan/i.test((t.m || '') + ' ' + (t.n || ''))); };
        // (GST by the engine's own word for it, Tax · GST, as well as by its name: a netbanking "GST PAYMENT-CPIN" is
        // shown as "Payment")
        var isGst = function (t) { return (t.c === 'Tax' && t.s === 'GST') || (/\bgst\b|\bgstn\b|goods and services tax|\bcpin\b/i.test((t.m || '') + ' ' + (t.n || '')) && !/\bgst on\b/i.test((t.m || '') + ' ' + (t.n || ''))); };
        var isOther = function (t) { return /\btds\b|property tax|professional tax|municipal|road tax|stamp duty/i.test((t.m || '') + ' ' + (t.n || '') + ' ' + (t.s || '')); };
        var rowsT = (ctx.tx || []).filter(function (t) { return within2(t, spT, today) && taxish(t) && (f.kind === 'gst' ? isGst(t) : !isGst(t) && !isOther(t)) && personOk(t, f.person, ctx); }).sort(byDate);
        var wordT = f.kind === 'gst' ? 'GST' : 'advance tax';
        if (!rowsT.length) o.text = 'kosh hasn’t seen any ' + wordT + ' paid ' + wT + '.' + (f.kind === 'gst' ? '' : ' It counts income tax paid by challan from your bank; what was deducted at source (TDS) isn’t in the mail it reads.');
        else {
          var totT = sumA(rowsT);
          o.text = 'You paid **' + inr(totT) + '** in ' + wordT + ' ' + wT + ', across ' + n_(rowsT.length, 'payment') + (rowsT.length <= 4 ? ': ' + joinAnd(rowsT.slice().reverse().map(function (t) { return inr(t.a) + ' ' + at(t.d, today); })) : '; the last ' + inr(rowsT[0].a) + ' ' + at(rowsT[0].d, today)) + '.';
          if (f.kind !== 'gst') o.text += ' That’s income tax paid by challan; what was deducted at source (TDS) isn’t in it.';
        }
        if (f.kind !== 'gst') {
          var yA = +today.slice(0, 4), daysA = [yA + '-03-15', yA + '-06-15', yA + '-09-15', yA + '-12-15', (yA + 1) + '-03-15'].filter(function (d) { return d >= today; });
          o.text += ' The next instalment is due by ' + dShort(daysA[0]) + (daysA[0].slice(0, 4) !== today.slice(0, 4) ? ' ' + daysA[0].slice(0, 4) : '') + '.';
        }
        o.rows = idsOf(rowsT);
        step('spending', wordT, rowsT.length + ' payments ' + wT + ', ' + inr(sumA(rowsT)) + '.');
        o.suggest = [f.kind === 'gst' ? 'How much advance tax did I pay this year?' : 'How much GST did I pay this financial year?', 'How much tax did I pay this year?'];
        break;
      }
      case 'cashdep': {
        // cash paid into your accounts (a cash deposit machine, the counter): your own cash put in the bank
        var spC = span || { from: today.slice(0, 4) + '-01-01', to: today, label: 'this year' }, wC = spanWords(spC, today);
        var rowsC = (ctx.tx || []).filter(function (t) { return t.a > 0 && t.k !== 'out' && within2(t, spC, today) && (t.s === 'Cash deposit' || /\bcash deposit\b|\bcdm\b/i.test((t.m || '') + ' ' + (t.n || ''))) && personOk(t, f.person, ctx); }).sort(byDate);
        if (!rowsC.length) o.text = 'kosh hasn’t seen cash deposited ' + wC + '. It looks for credits your bank calls a cash deposit (at a machine or the counter).';
        else o.text = 'You deposited **' + inr(sumA(rowsC)) + '** in cash ' + wC + ', ' + (rowsC.length === 1 ? 'once, ' + at(rowsC[0].d, today) : 'across ' + n_(rowsC.length, 'deposit') + '; the last ' + inr(rowsC[0].a) + ' ' + at(rowsC[0].d, today)) + '.' + sinceNote(spC, ctx);
        o.rows = idsOf(rowsC);
        step('income', 'Cash deposited', rowsC.length + ' deposits ' + wC + ', ' + inr(sumA(rowsC)) + '.');
        o.suggest = ['How much cash did I withdraw this year?', 'What came in this month?'];
        break;
      }
      case 'remit': {
        // money sent home from abroad: transfers in from a remittance service or marked inward remittance. It's the
        // person's own money moving, so it isn't income.
        var spR = span || { from: today.slice(0, 4) + '-01-01', to: today, label: 'this year' }, wR = spanWords(spR, today);
        var rowsR = (ctx.tx || []).filter(function (t) { return (t.k === 'in' || t.k === 'move') && t.a > 0 && within2(t, spR, today) && /remit|\bwise\b|transferwise|remitly|western union|moneygram|instarem|\bxoom\b|inward|\bswift\b/i.test((t.m || '') + ' ' + (t.n || '') + ' ' + (t.s || '')); }).sort(byDate);
        if (!rowsR.length) { o.text = 'kosh hasn’t seen money sent to India from abroad ' + wR + '. It looks for credits from a remittance service (Wise, Remitly and the like) or marked inward remittance.'; break; }
        var intoR = []; rowsR.forEach(function (t) { if (t.card && intoR.indexOf(t.card) < 0) intoR.push(t.card); });
        o.text = 'You sent **' + inr(sumA(rowsR)) + '** to India ' + wR + ', ' + (rowsR.length === 1 ? 'in one transfer ' + at(rowsR[0].d, today) : 'across ' + n_(rowsR.length, 'transfer')) + (intoR.length ? ' into ' + joinAnd(intoR.slice(0, 3)) : '') + (rowsR.length > 1 ? '; the last ' + inr(rowsR[0].a) + ' ' + at(rowsR[0].d, today) : '') + '. It’s your own money moving, so kosh doesn’t count it as income.' + sinceNote(spR, ctx);
        o.rows = idsOf(rowsR);
        step('income', 'Money sent home', rowsR.length + ' transfers ' + wR + ', ' + inr(sumA(rowsR)) + '.');
        o.suggest = ['What came in this month?', 'What is my NRE account balance?'];
        break;
      }
      case 'sent': {
        // money sent to someone in the household (Papa, Aai, a wife): transfers to them by name, from anyone else
        var pS = (ctx.people || []).filter(function (p) { return p.name === f.person; })[0];
        if (!pS) { o.text = 'kosh doesn’t know who that is yet. Add them in Settings › Household.'; break; }
        var spS = span || { from: addDays(today, -364), to: today, label: 'in the last 12 months' }, wS = span ? spanWords(spS, today) : 'in the last 12 months';
        var fullS = lc(pS.full || ''), firstS = fullS.split(/\s+/)[0] || '';
        var toS = function (t) { var m = ' ' + lc(t.m).replace(/[^a-z ]/g, ' ').replace(/\s+/g, ' ') + ' '; return (fullS.length >= 5 && m.indexOf(' ' + fullS + ' ') >= 0) || (firstS.length >= 3 && m.indexOf(' ' + firstS + ' ') >= 0) || (lc(pS.name).length >= 3 && m.indexOf(' ' + lc(pS.name) + ' ') >= 0); };
        var rowsS = (ctx.tx || []).filter(function (t) { return t.a > 0 && (t.k === 'out' || (t.k === 'move' && !/^transfer in$/i.test(t.c || ''))) && (t.o || 'me') !== pS.id && within2(t, spS, today) && toS(t); }).sort(byDate);
        if (!rowsS.length) { o.text = 'kosh hasn’t seen money sent to ' + pS.name + ' ' + wS + '. It looks for transfers to ' + (pS.full || pS.name) + ' by name.'; o.suggest = ['How much did ' + pS.name + ' spend this month?']; break; }
        o.text = 'You sent ' + pS.name + ' **' + inr(sumA(rowsS)) + '** ' + wS + (rowsS.length === 1 ? ', in one transfer ' + at(rowsS[0].d, today) : ', across ' + n_(rowsS.length, 'transfer') + '; the last ' + inr(rowsS[0].a) + ' ' + at(rowsS[0].d, today)) + '.' + sinceNote(spS, ctx);
        o.rows = idsOf(rowsS);
        step('transactions', 'Sent to ' + pS.name, rowsS.length + ' transfers ' + wS + ', ' + inr(sumA(rowsS)) + '.');
        o.suggest = ['Show these payments', 'How much did ' + pS.name + ' spend this month?'];
        break;
      }
      case 'saved': {
        var cf = (ctx.cashflow || []).slice();
        var pick = span ? cf.filter(function (c) { return c.m === span.from.slice(0, 7); })[0] : cf.filter(function (c) { return !c.live; }).slice(-1)[0];
        // "this year", "this FY", "the last 3 months": every month in it added up, not its first month alone
        if (span && span.from.slice(0, 7) !== (span.to || today).slice(0, 7)) {
          var inSpan = cf.filter(function (c) { return c.m >= span.from.slice(0, 7) && c.m <= (span.to || today).slice(0, 7) && c.inn > 0; });
          pick = inSpan.length ? { m: inSpan[0].m, inn: sum(inSpan, function (c) { return c.inn; }), out: sum(inSpan, function (c) { return c.out; }), inv: sum(inSpan, function (c) { return c.inv; }), kept: sum(inSpan, function (c) { return c.kept; }), live: false, n: inSpan.length } : null;
        }
        if (!pick) { o.text = 'There isn’t a month with money in to work that out from yet.'; break; }
        var left = pick.kept, mw = pick.n ? spanWords(span, today) : pick.live ? 'this month so far' : 'in ' + monthWord(pick.m, today);
        var how = inr(pick.inn) + ' came in, ' + inr(pick.out) + ' was spent' + (pick.inv ? ' and ' + inr(pick.inv) + ' invested' : '');
        o.text = left >= 0 ? 'You saved **' + inr(left) + '** ' + mw + (pick.inn > 0 ? ', ' + pctOf(left, pick.inn) + '% of what came in' : '') + ': ' + how + '.'
          : cap1(mw) + ' **' + inr(-left) + ' more went out** than came in: ' + how + '.';
        if (pick.n) o.text += ' That’s across ' + n_(pick.n, 'month') + ' with money in.';
        // (a month whose salary mail never came: the shortfall is the mail's, not yours)
        if (!pick.n && pick.noPay) o.text += ' Your salary for ' + monthWord(pick.m, today) + ' isn’t in your email, so what came in is short of what you earned.';
        else if (pick.n) { var gaps = cf.filter(function (c) { return c.noPay && c.m >= span.from.slice(0, 7) && c.m <= (span.to || today).slice(0, 7); }); if (gaps.length) o.text += ' Salary for ' + gaps.map(function (c) { return monthWord(c.m, today); }).join(' and ') + ' isn’t in your email.'; }
        var past = cf.filter(function (c) { return !c.live && !c.noPay && c.inn > 0; }).slice(-6);
        if (!pick.n && past.length >= 3) o.text += ' Over the last ' + past.length + ' months you saved ' + pctOf(sum(past, function (c) { return c.kept; }), sum(past, function (c) { return c.inn; })) + '% of what came in.';
        step('cashflow', 'Left after spending and investing', cf.map(function (c) { return c.m + ' in ' + inr(c.inn) + ' left ' + inr(c.kept); }).join('; ') + '.');
        o.suggest = ['Where did my money go last month?', 'How much came in this month?'];
        break;
      }
      case 'pace': {
        var fc = ctx.fc || {}, spent = spentSum(ctx, {}, thisMonth), dN = +today.slice(8, 10), dM = +monthEnd(today).slice(8, 10);
        var likely2 = fc.likely > 0 ? fc.likely : dN >= 5 ? spent / dN * dM : 0, usual2 = fc.usual > 0 ? fc.usual : median(fullMonths(ctx, 6).map(function (m) { return spentSum(ctx, {}, { from: m + '-01', to: monthEnd(m + '-01') }); }));
        o.text = '**' + inr(spent) + '** spent this month, ' + (dM - dN) + ' days to go.';
        if (fc.budget > 0) o.text += ' Against your **' + inr(fc.budget) + '** budget: ' + (spent <= fc.budget ? inr(fc.budget - spent) + ' left' : inr(spent - fc.budget) + ' over') + (likely2 > 0 ? ', heading for about ' + inr(Math.round(likely2 / 100) * 100) + (likely2 > fc.budget ? ', over it.' : ', within it.') : '.');
        else if (usual2 > 0) o.text += (likely2 > 0 ? ' Heading for about ' + inr(Math.round(likely2 / 100) * 100) + ' against a usual ' + inr(usual2) + (likely2 > usual2 * 1.1 ? ': running above usual.' : likely2 < usual2 * 0.9 ? ': running below usual.' : ': about usual.') : ' A usual month is ' + inr(usual2) + '.');
        step('spending', 'This month so far', inr(spent) + ' by day ' + dN + '.');
        o.suggest = ['What changed in my spending this month?', 'Split by category'];
        break;
      }
      case 'owed': {
        var ow = (ctx.owed || []).filter(function (x) { return !x.settled; }), toMe = ow.filter(function (x) { return x.dir === 'in'; }), byMe = ow.filter(function (x) { return x.dir !== 'in'; });
        if (!ow.length) { o.text = 'Nothing owed either way.'; break; }
        // "how much do I owe" is what you owe; "who owes me" what's owed to you (each says so when there's none)
        var qo = norm(f.q || ''), mineO = /\b(?:i|we) owe\b|\bdo (?:i|we) owe\b/.test(qo), theirsO = /\bowes? (?:me|us)\b|\bwho owes\b/.test(qo);
        if (mineO && !theirsO) { if (!byMe.length) { o.text = 'You don’t owe anyone, as far as kosh knows.'; break; } toMe = []; }
        else if (theirsO && !mineO) { if (!toMe.length) { o.text = 'No one owes you anything, as far as kosh knows.'; break; } byMe = []; }
        if (toMe.length) o.text = 'Owed to you: **' + inr(sum(toMe, function (x) { return x.amount; })) + '**\n- ' + toMe.map(function (x) { return (x.name || 'Someone') + ' · ' + inr(x.amount) + ' for ' + x.title; }).join('\n- ');
        if (byMe.length) o.text += (o.text ? '\n\n' : '') + 'You owe: **' + inr(sum(byMe, function (x) { return x.amount; })) + '**\n- ' + byMe.map(function (x) { return x.name + ' · ' + inr(x.amount) + ' for ' + x.title; }).join('\n- ');
        step('owed', 'Who owes what', ow.length + ' open.');
        break;
      }
      case 'wealth': {
        var qw = norm(f.q || ''), names = { dep: 'Deposits', stk: 'Stocks', mf: 'Mutual funds', ret: 'Retirement (EPF, PPF, NPS)', gold: 'Gold', bank: 'Bank', ins: 'Insurance savings (ULIPs)' };
        var hs = (ctx.hold || []).filter(function (h) { return !f.person || personOk({ o: h.person || h.owner }, f.person, ctx); });
        // a ULIP's fund the holdings don't carry: its insurer's statement, on the policy
        if (!hs.some(function (h) { return h.cls === 'ins'; })) (ctx.policies || []).forEach(function (p) { if (!p.ended && p.fundValue > 0 && /ulip|unit.?linked/i.test((p.kind || '') + ' ' + (p.type || ''))) hs.push({ bank: p.insurer, type: 'ULIP', cls: 'ins', amt: p.fundValue, rate: 0, person: 'me' }); });
        var hName = function (h) { return h.bank + (lc(h.bank).indexOf(lc(h.type || '')) >= 0 ? '' : ' ' + h.type); };
        var matOf = function (h) { return isDay(h.matDay) ? String(h.matDay).slice(0, 10) : isDay(h.mat) ? String(h.mat).slice(0, 10) : isMonth(h.mat) ? h.mat : ''; };
        // net worth, as Home has it: what's in the bank, what's held, cash and land, less what's left on the loans
        if (/\bnet ?worth\b|\bhow much (?:am i|are we) worth\b|\bwhat (?:am i|are we) worth\b|\btotal (?:assets|wealth)\b/.test(qw)) {
          var other = f.person && personWord(f.person) !== 'You', mineW = !f.person || personOk({ o: 'me' }, f.person, ctx);
          var acW = (ctx.accounts || []).filter(function (x) { return x.balance !== null && x.balance !== undefined && isFinite(+x.balance) && (!f.person || personOk({ o: x.owner || 'me' }, f.person, ctx)); });
          var bankW = sum(acW, function (x) { return +x.balance; }), heldW = sum(hs, function (h) { return +h.amt || 0; });
          var cashW = mineW ? +ctx.cashInHand || 0 : 0, landW = mineW ? +ctx.land || 0 : 0;
          var loansW = mineW ? (ctx.loans || []).filter(function (l) { return l.active !== false && +l.outstanding > 0; }) : [], owedW = sum(loansW, function (l) { return +l.outstanding; });
          var netW = bankW + heldW + cashW + landW - owedW;
          if (!acW.length && !hs.length && !loansW.length) { o.text = 'kosh doesn’t know enough for a net worth yet: a balance alert, a CAS statement or a loan added in Wealth › Debts brings it in.'; break; }
          var sgn = function (v) { return (v < 0 ? '−' : '') + lakh(v); };
          var parts = [];
          if (bankW) parts.push(lakh(bankW) + ' in the bank');
          if (heldW) parts.push(lakh(heldW) + ' invested');
          if (cashW) parts.push(lakh(cashW) + ' in cash');
          if (landW) parts.push(lakh(landW) + ' in land');
          o.text = (other ? f.person + '’s net worth' : 'Net worth') + ': **' + sgn(netW) + '**' + (parts.length ? ', ' + joinAnd(parts) : '') + (owedW ? ', less ' + lakh(owedW) + ' left on ' + (loansW.length === 1 ? 'the ' + loansW[0].name : n_(loansW.length, 'loan')) : '') + '.';
          var clsW = {}; hs.forEach(function (h) { clsW[h.cls] = (clsW[h.cls] || 0) + (+h.amt || 0); });
          var linesW = (bankW ? ['In the bank · ' + lakh(bankW) + ' across ' + n_(acW.length, 'account')] : []).concat(Object.keys(clsW).sort(function (a, b) { return clsW[b] - clsW[a]; }).map(function (k) { return (names[k] || cap1(k)) + ' · ' + lakh(clsW[k]); }))
            .concat(cashW ? ['Cash · ' + lakh(cashW)] : []).concat(landW ? ['Land · ' + lakh(landW)] : []).concat(loansW.map(function (l) { return l.name + ' · −' + lakh(+l.outstanding); }));
          if (linesW.length > 1) o.text += '\n- ' + linesW.join('\n- ');
          // card bills still to pay: shown, not taken off (Home doesn't take them off either)
          var openC = (ctx.cards || []).filter(function (c) { return c.due > 0 && (!f.person || personOk({ o: c.owner || 'me' }, f.person, ctx)) && cardBill(c).left > 0; });
          if (openC.length) o.text += '\n\nCard bills still to pay: ' + inr(sum(openC, function (c) { return cardBill(c).left; })) + '. Like Home, this figure doesn’t take them off.';
          if (!acW.length) o.text += '\n\nkosh hasn’t seen a bank balance yet, so the bank isn’t in it.';
          step('wealth', 'Net worth', 'bank ' + inr(bankW) + ', holdings ' + inr(heldW) + (cashW ? ', cash ' + inr(cashW) : '') + (landW ? ', land ' + inr(landW) : '') + (owedW ? ', loans −' + inr(owedW) : '') + '.');
          o.suggest = ['What are my investments worth?', 'How much of my home loan is left?'];
          break;
        }
        // one kind: "my FDs", "how much gold", "my ULIP", "mutual funds"; a bank named ("the Kotak FD")
        var kindW = /\bulips?\b|\bunit linked\b/.test(qw) ? 'ins' : /\bfds?\b|\bfixed deposits?\b|\bdeposits?\b|\brds?\b|\brecurring deposits?\b|\bmatur/.test(qw) ? 'dep' : /\bgold\b|\bsgbs?\b|\bgold bonds?\b/.test(qw) ? 'gold'
          : /\bmutual funds?\b|\bmfs?\b|\bfunds\b/.test(qw) ? 'mf' : /\bstocks?\b|\bshares\b|\bequit(?:y|ies)\b/.test(qw) ? 'stk' : /\bepf\b|\bpf\b|\bppf\b|\bnps\b|\bprovident\b|\bretirement\b/.test(qw) ? 'ret' : '';
        var bankW2 = /\b(hdfc|icici|sbi|axis|kotak|idfc|indusind|yes bank|au|hsbc|rbl|federal|bob|pnb|canara|citi|lic|post office)\b/.exec(qw);
        var bankRe = bankW2 ? new RegExp('\\b' + ({ sbi: 'sbi|state bank', bob: 'bob|bank of baroda', pnb: 'pnb|punjab national' }[bankW2[1]] || bankW2[1]) + '\\b', 'i') : null;
        if (!hs.length) { o.text = 'kosh doesn’t know your investments yet. A CAS statement from CAMS or NSDL brings in your funds and shares.'; break; }
        if (kindW || bankRe) {
          // (a fixed deposit asked for is a fixed deposit, never the gold bond that pays interest beside them; gold is
          // all the gold, the bond among it)
          var fdOnly = kindW === 'dep' && /\bfds?\b|\bfixed deposits?\b/.test(qw);
          var pickW = hs.filter(function (h) { var goldish = /\bgold\b|\bsgb\b/i.test((h.type || '') + ' ' + (h.bank || '')); return (!kindW || (h.cls === kindW && !(fdOnly && goldish)) || (kindW === 'ins' && /ulip/i.test(h.type || '')) || (kindW === 'gold' && goldish)) && (!bankRe || bankRe.test(h.bank + ' ' + (h.type || ''))); });
          var kw = { dep: 'deposits', gold: 'gold', mf: 'mutual funds', stk: 'shares', ret: 'retirement savings', ins: 'ULIPs' }[kindW] || 'holdings';
          /* GUARDRAIL one retirement account named is that one: "my EPF", "PF me kitna", "provident fund" (the
             employees' fund; "public provident fund" is the PPF), "PPF", "NPS". Never another's figure in its place: a
             household with a PPF and no EPF is told kosh hasn't seen its EPF, not shown the PPF as if it were */
          var retW = kindW !== 'ret' ? '' : /\bppf\b|\bpublic provident\b/.test(qw) ? 'PPF' : /\bnps\b|\bnational pension\b/.test(qw) ? 'NPS' : /\bepf\b|\bpf\b|\bprovident\b|\bepfo\b/.test(qw) ? 'EPF' : '';
          if (retW) {
            var others = pickW.filter(function (h) { return !new RegExp('\\b' + retW + '\\b', 'i').test(h.type || ''); });
            pickW = pickW.filter(function (h) { return new RegExp('\\b' + retW + '\\b', 'i').test(h.type || ''); });
            if (!pickW.length) {
              var otherKinds = others.map(function (h) { return (/\b(EPF|PPF|NPS)\b/i.exec(h.type || '') || [])[1]; }).filter(function (k, i, a) { return k && a.indexOf(k) === i; });
              o.text = 'kosh hasn’t seen ' + (retW === 'EPF' ? 'an EPF' : retW === 'NPS' ? 'an NPS' : 'a PPF') + ' balance of yours yet' + (otherKinds.length ? ' (it knows your ' + joinAnd(otherKinds) + ')' : '') + '.' +
                (retW === 'EPF' ? ' Your EPF passbook from the EPFO, or the EPFO’s own mail, brings it in.' : retW === 'NPS' ? ' A statement from your NPS record keeper brings it in.' : ' Your bank’s PPF statement brings it in.');
              break;
            }
            kw = retW;
          }
          if (!pickW.length) { o.text = 'kosh doesn’t know of any ' + (bankW2 ? (BANK_NAME[bankW2[1]] || bankW2[1].toUpperCase()) + ' ' : '') + kw + ' of yours yet.' + (kindW === 'dep' ? ' A deposit’s advice in your mail brings it in.' : ''); break; }
          var lineW = function (h) { var md = matOf(h); return hName(h) + ' · ' + inr(h.amt) + (h.cls === 'dep' && h.cost > 0 && Math.abs(h.cost - h.amt) >= 1 ? ' (' + inr(h.cost) + ' put in)' : '') + (h.rate ? ' at ' + h.rate + '%' : '') + (md ? (md < today && isDay(md) ? ', matured ' : ', matures ') + on(md, today) : ''); };
          if (/\bmatur/.test(qw) || (/\bwhen\b/.test(qw) && kindW === 'dep')) {
            var mats = pickW.filter(function (h) { return matOf(h) && matOf(h) >= today.slice(0, matOf(h).length); }).sort(function (a, b) { return matOf(a).localeCompare(matOf(b)); });
            if (!mats.length) { o.text = 'kosh doesn’t know when ' + (pickW.length === 1 ? 'your ' + hName(pickW[0]) : 'these') + ' mature' + (pickW.length === 1 ? 's' : '') + ': its advice hasn’t said.'; break; }
            // what comes back: today's worth grown at its rate, compounded quarterly as banks do, to the day it matures
            var m0 = mats[0], md0 = matOf(m0), yrs0 = isDay(md0) ? daysBetween(today, md0) / 365 : 0;
            var back0 = m0.cls === 'dep' && m0.rate > 0 && yrs0 > 0 ? Math.round(m0.amt * Math.pow(1 + m0.rate / 400, 4 * yrs0) / 100) * 100 : 0;
            o.text = 'Your ' + hName(m0) + ' (' + inr(m0.amt) + ' today' + (m0.rate ? ', at ' + m0.rate + '%' : '') + ') matures **' + at(md0, today) + '**' + (back0 ? ', when about ' + inr(back0) + ' comes back' : '') + '.' + (mats.length > 1 ? '\n\nAfter it:\n- ' + mats.slice(1, 6).map(lineW).join('\n- ') : '');
          } else if (pickW.length === 1) {
            var p0 = pickW[0];
            o.text = 'Your ' + hName(p0) + ' is worth **' + inr(p0.amt) + '**' + (p0.cls === 'dep' && p0.cost > 0 && Math.abs(p0.cost - p0.amt) >= 1 ? ' (' + inr(p0.cost) + ' put in)' : '') + (p0.rate ? ', at ' + p0.rate + '%' : '') + (matOf(p0) ? '; it matures ' + at(matOf(p0), today) : '') + '.';
          } else {
            o.text = '**' + inr(sum(pickW, function (h) { return h.amt; })) + '** in ' + n_(pickW.length, kindW === 'dep' ? 'deposit' : 'holding') + ':\n- ' + pickW.slice().sort(function (a, b) { return b.amt - a.amt; }).slice(0, 10).map(lineW).join('\n- ');
          }
          step('wealth', 'Holdings', pickW.length + ' ' + kw + '.');
          o.suggest = ['What is my net worth?', 'What are my investments worth?'];
          break;
        }
        var cls = {}; hs.forEach(function (h) { cls[h.cls] = (cls[h.cls] || 0) + h.amt; });
        o.text = '**' + lakh(sum(hs, function (h) { return h.amt; })) + '** in what kosh knows of:\n- ' + Object.keys(cls).sort(function (a, b) { return cls[b] - cls[a]; }).map(function (k) { return (names[k] || cap1(k)) + ' · ' + lakh(cls[k]); }).join('\n- ');
        var mat = hs.filter(function (h) { var md = matOf(h); return md && md >= today.slice(0, md.length); }).sort(function (a, b) { return matOf(a).localeCompare(matOf(b)); })[0];
        if (mat) o.text += '\n\nNext to mature: ' + hName(mat) + ', ' + lakh(mat.amt) + ' ' + at(matOf(mat), today) + '.';
        step('wealth', 'Holdings', hs.length + ' holdings.');
        o.suggest = ['What is my net worth?', 'How much did I invest this year?'];
        break;
      }
      case 'insurance': {
        var all = ctx.policies || [], ps = all.filter(function (p) { return !p.ended; }), gone = all.filter(function (p) { return p.ended; });
        if (!all.length) { o.text = 'No policies found yet. A policy’s PDF or its premium receipt in your mail brings it in.'; break; }
        // an insurer named whose policy kosh read has ended, while payments to it still repeat: another of its policies
        if (f.ins && !ps.some(function (p) { return insurerWord(p) === f.ins; })) {
          var endI = all.filter(function (p) { return insurerWord(p) === f.ins; })[0];
          var repI = (ctx.recurring || []).filter(function (r) { return !r.lapsed && wordIn(r.name, f.ins) && r.date; }).sort(function (a, b) { return a.date.localeCompare(b.date); })[0];
          if (endI && repI) {
            var perI = repI.per || 1, cycI = perI === 12 ? ' a year' : perI === 6 ? ' every six months' : perI === 3 ? ' every three months' : ' a month';
            o.text = 'kosh read that your ' + endI.insurer + ' policy ' + (endI.status === 'matured' ? 'matured' : 'ended') + (endI.statusWhy ? ' (' + endI.statusWhy.replace(/\.$/, '') + ')' : '') + '. Your payments to ' + endI.insurer + ' repeat, **' + inr(repI.amount) + '**' + cycI + (repI.last ? ', the last ' + on(repI.last, today) : '') +
              ': if another ' + endI.insurer + ' policy is running, its next premium is due about **' + on(repI.date, today) + '**.';
            step('insurance', 'Policies and repeats', endI.insurer + ' ended; repeat ' + inr(repI.amount) + ' next ' + repI.date + '.');
            break;
          }
        }
        // a premium is one instalment: a year of it by how often it's paid (a single premium isn't yearly)
        var perYear = function (p) { var fq = lc(p.frequency || ''); return /single|one/.test(fq) ? 0 : (p.premium || 0) * (/month/.test(fq) ? 12 : /quarter/.test(fq) ? 4 : /half|semi/.test(fq) ? 2 : 1); };
        var yearly = sum(ps, perYear), every = function (p) { var fq = lc(p.frequency || ''); return /month/.test(fq) ? ' a month' : /quarter/.test(fq) ? ' a quarter' : /half|semi/.test(fq) ? ' every six months' : /single|one/.test(fq) ? ' once' : ''; };
        var list = ps.map(function (p) { return p.insurer + (lc(p.insurer).indexOf(lc(p.type)) >= 0 ? '' : ' ' + p.type) + (p.cover ? ' · cover ' + lakh(p.cover) : '') + (p.premium ? ' · ' + inr(p.premium) + every(p) + ' premium' : '') + (p.nextDue ? ', next ' + on(p.nextDue, today) : '') + (p.status === 'overdue' || p.status === 'due' ? ' · ' + (p.statusWhy || p.status) : ''); }).join('\n- ');
        // "when is my health premium due", "term plan ka cover kitna hai": that policy first, then the rest
        // "my LIC premium": that insurer's policies alone (every policy's total is not one insurer's)
        var insNamed = ps.filter(function (p) { var w = lc(p.insurer).replace(/\b(?:life|health|general|insurance|co|company|ltd|limited|of|india|the)\b/g, ' ').trim().split(/\s+/)[0] || '';
          var q0 = norm(f.q || ''); return (w.length >= 3 && new RegExp('\\b' + w + '\\b').test(q0)) || q0.indexOf(' ' + lc(p.insurer) + ' ') >= 0; });
        var insWord = insNamed.length && insNamed.length < ps.length ? insNamed[0].insurer : '';
        if (insWord) { ps = insNamed; yearly = sum(ps, perYear); list = ps.map(function (p) { return p.insurer + (lc(p.insurer).indexOf(lc(p.type)) >= 0 ? '' : ' ' + p.type) + (p.cover ? ' · cover ' + lakh(p.cover) : '') + (p.premium ? ' · ' + inr(p.premium) + every(p) + ' premium' : '') + (p.nextDue ? ', next ' + on(p.nextDue, today) : ''); }).join('\n- '); }
        var TYPE_RE = { health: /health|medi/i, mediclaim: /health|medi/i, term: /term/i, ulip: /ulip|unit.?linked/i, life: /life|term|endow|ulip|money back|whole life|pension/i, motor: /motor|car|vehicle|two.?wheeler|bike/i,
          car: /motor|car|vehicle/i, bike: /motor|bike|two.?wheeler/i, vehicle: /motor|car|vehicle|bike/i, home: /home|house|property/i, travel: /travel/i }[f.ptype || ''];
        var pick0 = TYPE_RE ? ps.filter(function (p) { return TYPE_RE.test((p.type || '') + ' ' + (p.kind || '') + ' ' + (p.insurer || '')); }) : [];
        // "when is my next premium": the one that comes first
        if (!pick0.length && f.ask === 'due') pick0 = ps.filter(function (p) { return p.nextDue && p.nextDue >= today; }).sort(function (a, b) { return a.nextDue.localeCompare(b.nextDue); }).slice(0, 1);
        var polName = function (p) { return p.insurer + (lc(p.insurer).indexOf(lc(p.type)) >= 0 ? '' : ' ' + (lc(p.type) === 'term' ? 'term plan' : lc(p.type) + ' policy')); };
        var lead0 = pick0.map(function (p) {
          var nm = polName(p);
          if (f.ask === 'cover') return 'Your ' + nm + (p.cover ? ' covers **' + lakh(p.cover) + '**' : ': kosh hasn’t read its cover yet') + (p.premium ? ', for a premium of ' + inr(p.premium) + every(p) : '') + '.';
          if (f.ask === 'due') return 'Your ' + nm + ' premium' + (p.premium ? ', **' + inr(p.premium) + '**' + every(p) + ',' : '') + (p.nextDue ? ' is due ' + at(p.nextDue, today) : ' has no date kosh knows') + '.';
          return 'Your ' + nm + ': ' + (p.cover ? 'cover **' + lakh(p.cover) + '**' : 'cover not read yet') + (p.premium ? ', ' + inr(p.premium) + every(p) + ' premium' : '') + (p.nextDue ? ', next ' + on(p.nextDue, today) : '') + '.';
        }).join('\n');
        if (f.ask === 'rise') {
          // the premium now against what was last paid to that insurer (a renewal notice's premium is the new one)
          var pR = (insNamed.length ? insNamed : pick0.length ? pick0 : ps)[0];
          if (pR) {
            var wR = insurerWord(pR), paidR = (ctx.tx || []).filter(function (t) { return (t.k === 'out' || t.k === 'prepaid') && t.a > 0 && t.d <= today && t.d >= addDays(today, -430) && wordIn(t.m, wR); }).sort(byDate)[0];
            if (!paidR) o.text = 'kosh hasn’t seen what you last paid ' + pR.insurer + ', so it can’t compare. The premium now is **' + inr(pR.premium) + '**' + (pR.nextDue ? ', due ' + on(pR.nextDue, today) : '') + '.';
            else {
              var dR = pR.premium - paidR.a;
              o.text = (dR >= 1 ? 'Yes: ' : dR <= -1 ? 'No, it went down: ' : 'No: ') + polName(pR) + '’s premium is **' + inr(pR.premium) + '**' + (pR.nextDue ? ', due ' + on(pR.nextDue, today) : '') + (Math.abs(dR) < 1 ? ', the same as the ' : ', against the ') + inr(paidR.a) + ' paid ' + at(paidR.d, today) + (Math.abs(dR) >= 1 ? ': ' + inr(Math.abs(dR)) + (dR > 0 ? ' more' : ' less') + ' (' + pctOf(Math.abs(dR), paidR.a) + '%).' : '.');
              o.rows = [paidR.id];
            }
            step('insurance', 'Premium against the last paid', pR.insurer + ' ' + inr(pR.premium) + (paidR ? ' against ' + inr(paidR.a) + ' on ' + paidR.d : '') + '.');
            break;
          }
        }
        var others = pick0.length ? ps.filter(function (p) { return pick0.indexOf(p) < 0; }) : ps;
        if (lead0) o.text = lead0 + (others.length && !f.ask ? '\n\nAlso running: ' + joinAnd(others.map(polName)) + '.' : '');
        else o.text = (f.yearly || insWord) && yearly > 0 ? 'Your ' + (insWord ? insWord + ' ' : '') + 'premiums come to **' + inr(yearly) + ' a year** across ' + n_(ps.length, 'policy', 'policies') + ':\n- ' + list
          : '**' + cap1(n_(ps.length, 'policy', 'policies')) + ' running**:\n- ' + list + (yearly > 0 && ps.length > 1 ? '\n\nPremiums: **' + inr(yearly) + '** a year.' : '');
        // who a policy covers, by name ("who is covered", a floater's members), when kosh read it off the policy
        var whoQ = /\bcovered\b|\bwho (?:all )?(?:does it|do they|does (?:it|the policy)) cover\b|\bmembers?\b|\bwho (?:all )?(?:is|are) insured\b/.test(norm(f.q || ''));
        var covP = (pick0.length ? pick0 : ps).filter(function (p) { return (p.covers || []).length && (whoQ || (f.ask === 'cover' && p.covers.length > 1)); });
        var nameOfId = function (id) { if (id === 'me') return 'you'; var pp = (ctx.people || []).filter(function (x) { return x.id === id; })[0]; return pp ? (pp.name || pp.full || pp.rel || cap1(String(id))) : cap1(String(id).replace(/^n:/, '')); };
        if (covP.length) o.text += '\n\n' + covP.map(function (p) { return (covP.length > 1 ? polName(p) : 'It') + ' covers ' + joinAnd(p.covers.map(nameOfId)) + '.'; }).join(' ');
        else if (whoQ && (pick0.length ? pick0 : ps).some(function (p) { return p.insured; })) o.text += '\n\n' + (pick0.length ? pick0 : ps).filter(function (p) { return p.insured; }).map(function (p) { return cap1(polName(p).replace(/\bpolicy policy\b/i, 'policy')) + ' covers ' + joinAnd(String(p.insured).split(/\s*,\s*/).filter(Boolean)) + '.'; }).join(' ');
        else if (whoQ && (pick0.length ? pick0 : ps).length) o.text += '\n\nkosh hasn’t read who ' + ((pick0.length ? pick0 : ps).length > 1 ? 'they cover' : 'it covers') + ' yet: the policy’s schedule says.';
        o.text += gone.length && !f.ins ? '\n\nNo longer running: ' + gone.map(function (p) { return p.insurer + ' (' + (p.status || 'ended') + ')'; }).join(', ') + '.' : '';
        step('insurance', 'Policies', ps.length + ' policies.');
        break;
      }
      case 'noticed': {
        var wl = ctx.watch || [];
        o.text = wl.length ? '**' + n_(wl.length, 'thing') + ' worth a look**, most pressing first:\n- ' + wl.slice(0, 6).map(function (x) { return x.title; }).join('\n- ') : 'Nothing stands out right now. kosh looks again whenever new mail comes in.';
        wl.forEach(function (x) { o.rows = o.rows.concat(x.rows || []); });
        step('noticed', 'What kosh noticed', wl.length + ' items.');
        break;
      }
      case 'invested': {
        var sp8 = span || { from: today.slice(0, 4) + '-01-01', to: today, label: 'this year' }, w8 = spanWords(sp8, today);
        var inv0 = (ctx.tx || []).filter(function (t) { return putIn(t) && t.a > 0 && within2(t, sp8, today) && fits(t, f, ctx); }).sort(byDate);
        // what came back out of investments in the same days (a broker's payout to your bank): said, never netted
        var back8 = (ctx.tx || []).filter(function (t) { return takenOut(t) && t.a > 0 && within2(t, sp8, today) && fits(t, f, ctx); });
        var backW = back8.length ? '\n\n' + inr(sumA(back8)) + ' came back out of investments ' + w8 + ' (' + groupBy(back8, 'payee', ctx).slice(0, 3).map(function (x) { return x.name; }).join(', ') + '); that isn’t counted above.' : '';
        // a committee's instalments go in the same column, but a committee isn't an investment: said apart
        var chit = inv0.filter(function (t) { return t.s === 'Chit fund'; }), inv = inv0.filter(function (t) { return t.s !== 'Chit fund'; });
        var chitW = chit.length ? '. Another ' + inr(sumA(chit)) + ' went into your committee, ' + inr(sumA(inv0)) + ' in all' : '';
        if (!inv.length) { o.text = 'Nothing went into investments ' + w8 + (chit.length ? ' apart from ' + inr(sumA(chit)) + ' into your committee' : ', as far as your mail shows') + '.' + backW; o.suggest = ['What are my investments worth?']; break; }
        var gi = groupBy(inv, 'payee', ctx), tot8 = sumA(inv), mo8 = Math.max(1, Math.round((daysBetween(sp8.from, sp8.to || today) + 1) / 30.4));
        o.text = 'You put **' + inr(tot8) + '** into investments ' + w8 + ', across ' + n_(inv.length, 'payment') + (mo8 >= 2 ? ' (about ' + inr(tot8 / mo8) + ' a month)' : '') + chitW + '.\n\n- ' +
          gi.slice(0, 6).map(function (x) { return x.name + ' · ' + inr(x.v) + (x.n > 1 ? ' · ' + x.n + ' payments' : ''); }).join('\n- ') + (gi.length > 6 ? '\n- and ' + (gi.length - 6) + ' more' : '') + backW;
        var sips = (ctx.recurring || []).filter(function (r) { return r.kind === 'sip' && !r.lapsed; });
        if (sips.length) o.text += '\n\n' + cap1(n_(sips.length, 'SIP')) + ' running, ' + inr(sum(sips, function (r) { return r.amount / (r.per || 1); })) + ' a month.';
        o.rows = idsOf(inv);
        step('transactions', 'Money put into investments', w8 + ' ' + inr(tot8) + ' in ' + inv.length + ' payments.');
        o.suggest = ['What are my investments worth?', 'How much did I save last month?'];
        break;
      }
      case 'carddue': {
        // "HDFC card ka bill": that bank's cards alone; "Meena's card bill": hers
        var bankC = f.card ? new RegExp('\\b' + f.card.replace(/ (?:cc|a\/c)$/, '') + '\\b', 'i') : null;
        var whoC = f.person && personWord(f.person) !== 'You' ? f.person : '';
        var allC = (ctx.cards || []).filter(function (c) { return c.due > 0 && c.dueDate; });
        var cs = allC.filter(function (c) { return (!bankC || bankC.test((c.bank || '') + ' ' + (c.name || ''))) && (!whoC || personOk({ o: c.owner || 'me' }, whoC, ctx)); }).sort(function (a, b) { return String(a.dueDate).localeCompare(String(b.dueDate)); });
        // no statement read yet: the card bills on the calendar say it
        if (!cs.length) { o = answerOf(Object.assign({}, f, { act: 'due', what: 'card', days: 45, next: /\bwhen\b|\bnext\b/.test(norm(f.q || '')) || undefined }), ctx, prevAct); break; }
        // GUARDRAIL as the card screen has it: a bill not paid since its statement is open, and one whose due date has
        // passed in the last six weeks is overdue (never "paid"); an older one is the card's history
        var isOpen = function (c) { return !cardBill(c).full && c.dueDate >= addDays(today, -45); };
        var open8 = cs.filter(isOpen);
        var leftOf = function (c) { return cardBill(c).left; };
        // (part paid: what's left of it, and what went towards it)
        var partW = function (c) { var b = cardBill(c); return b.paid > 0 && !b.full ? ', ' + inr(b.paid) + ' of ' + inr(b.amt) + ' paid' : ''; };
        var totDue = sum(open8, leftOf);
        var dueW = function (c) { return c.dueDate < today ? 'overdue since ' + on(c.dueDate, today) : 'due ' + at(c.dueDate, today); };
        // whose card it is, when it isn't the user's own
        var cardWho = function (c) { var ow = c.owner || 'me', p = (ctx.people || []).filter(function (x) { return x.id === ow; })[0]; return ow === 'me' || !p ? '' : p.name + '’s '; };
        var cName = function (c) { return cardWho(c) + c.name + ' ••' + c.last; };
        if (bankC || whoC) {
          // GUARDRAIL one card asked for (by its bank or its holder): its latest bill, when it's due and whether it's
          // paid, never "every bill is paid" in its place
          o.text = cs.map(function (c) {
            var head = cName(c) + ': **' + inr(c.due) + '**' + (c.stmtOn ? ' on the statement of ' + dShort(c.stmtOn) : '');
            if (!isOpen(c)) return head + ', due ' + dShort(c.dueDate) + '; paid' + (c.paidOn ? ' ' + at(c.paidOn, today) : '') + (c.paid > 0 && Math.abs(c.paid - c.due) >= 1 ? ' (' + inr(c.paid) + ')' : '') + '.';
            var bp = cardBill(c);
            return head + ', ' + dueW(c) + (c.minDue ? ' (minimum ' + inr(c.minDue) + ')' : '') + (bp.paid > 0 ? ', ' + inr(bp.paid) + ' paid so far, ' + inr(bp.left) + ' to go.' : ', not paid yet.');
          }).join('\n');
        } else {
          o.text = open8.length === 1 ? cName(open8[0]) + ': **' + inr(leftOf(open8[0])) + '** ' + dueW(open8[0]) + partW(open8[0]) + (open8[0].minDue ? ' (minimum ' + inr(open8[0].minDue) + ')' : '') + '.'
            : open8.length ? '**' + inr(totDue) + '** left to pay on ' + n_(open8.length, 'card') + ':\n- ' + open8.map(function (c) { return on(c.dueDate, today) + (c.dueDate < today ? ' (overdue)' : '') + ' · ' + cName(c) + ' · ' + inr(leftOf(c)) + partW(c) + (c.minDue ? ' (minimum ' + inr(c.minDue) + ')' : ''); }).join('\n- ')
            : 'Every card bill kosh has seen is paid.';
          var paidC = cs.filter(function (c) { return open8.indexOf(c) < 0; });
          if (open8.length && paidC.length) o.text += '\n\nPaid already: ' + joinAnd(paidC.map(cName)) + '.';
        }
        // GUARDRAIL another card's bill still open (someone else's in the household): said, with whose, never left out
        var otherOpen = allC.filter(function (c) { return cs.indexOf(c) < 0 && isOpen(c); });
        if ((bankC || whoC) && otherOpen.length && !open8.length) o.text += '\n\nStill to pay on ' + (otherOpen.length === 1 ? 'another card' : 'other cards') + ': ' + joinAnd(otherOpen.map(function (c) { return cName(c) + ' ' + inr(cardBill(c).left) + ', ' + dueW(c); })) + '.';
        step('cards', 'Card statements', cs.length + ' cards with a statement.');
        o.suggest = ['Can I cover what’s due this week?', 'Which card do I use the most?'];
        break;
      }
      case 'cut': {
        // where the month is running above usual, the repeats, and the biggest optional spends
        var fm9 = fullMonths(ctx, 6), cmRows9 = spentRows(ctx, {}, thisMonth), dN9 = +today.slice(8, 10), dM9 = +monthEnd(today).slice(8, 10);
        var FIXED = /^(?:EMI|Insurance|Tax|Home|Bills|Education|Family Support|Investments)$/;
        var cats9 = groupBy(spentRows(ctx, {}, { from: (fm9[0] || today.slice(0, 7)) + '-01', to: today }), 'category', ctx).filter(function (x) { return !FIXED.test(x.k) && x.k !== '(unnamed)'; });
        var lines9 = [];
        cats9.forEach(function (x) {
          var usual9 = median(fm9.map(function (m) { return sumA(x.rows.filter(function (t) { return t.d.slice(0, 7) === m; })); }));
          var now9 = sumA(cmRows9.filter(function (t) { return t.c === x.k; }));
          var pace9 = dN9 >= 7 ? now9 / dN9 * dM9 : 0;
          if (usual9 >= 1000) lines9.push({ c: x.name, usual: usual9, pace: pace9 });
        });
        lines9.sort(function (a, b) { return b.usual - a.usual; });
        var subs9 = (ctx.recurring || []).filter(function (r) { return !r.lapsed && r.kind === 'sub'; });
        var over9 = lines9.filter(function (x) { return x.pace > x.usual * 1.15; });
        var parts9 = [];
        if (over9.length) parts9.push('**Running above usual this month:** ' + joinAnd(over9.slice(0, 3).map(function (x) { return x.c + ' (heading for ' + inr(Math.round(x.pace / 100) * 100) + ' against ' + inr(x.usual) + ')'; })) + '.');
        if (lines9.length) parts9.push('**Your biggest optional spends, a usual month:**\n- ' + lines9.slice(0, 4).map(function (x) { return x.c + ' · ' + inr(x.usual); }).join('\n- '));
        if (subs9.length) parts9.push('**Subscriptions:** ' + n_(subs9.length, 'subscription') + ', ' + inr(sum(subs9, function (r) { return r.amount / (r.per || 1); })) + ' a month (' + joinAnd(subs9.slice(0, 4).map(function (r) { return r.name; })) + '). One you don’t use is the easiest cut.');
        o.text = parts9.length ? parts9.join('\n\n') : 'There isn’t enough of your spending yet to say where to cut.';
        step('breakdown', 'Optional spending against usual', lines9.slice(0, 6).map(function (x) { return x.c + ' usual ' + inr(x.usual) + (x.pace ? ', pace ' + inr(x.pace) : ''); }).join('; ') + '.');
        o.suggest = ['Which subscriptions do I pay for?', 'What changed in my spending this month?', 'Who did I pay the most this month?'];
        break;
      }
      case 'decide': {
        var DA = decideAPI(), dd = DA ? DA.decide(f.kind, f.args || {}, ctx) : null;
        if (!dd) { o.text = 'I couldn’t work that out on this phone.'; break; }
        // the question that started it (saved with it); the frame carries what kosh worked it out with (an amount it
        // picked included) and what it still needs, for the next follow-up
        dd.question = f.first || f.q || '';
        f.first = dd.question;
        try { f.args = JSON.parse(dd.args); } catch (e) { /* as asked */ }
        f.need = dd.needs && dd.needs.length ? dd.needs.slice() : undefined;
        o.text = DA.summary(dd);
        o.decision = dd;
        step('decide', dd.title, DA.working(dd));
        o.suggest = {
          prepay: ['What if it earns 8%?', 'What are my investments worth?', 'How much did I save last month?'],
          car: ['What if I take the loan for 3 years?', 'How much did I save last month?', 'What’s due this week?'],
          afford: ['What’s due this week?', 'How much did I save last month?', 'What are my investments worth?'],
          fd: ['What if I need it for 12 months?', 'What are my investments worth?', 'What’s due this week?'],
          emergency: ['How much did I save last month?', 'What are my investments worth?', 'What’s due this week?'],
          card: ['What’s due this week?', 'Can I cover what’s due this week?', 'How much did I save last month?'],
        }[f.kind] || [];
        break;
      }
      case 'loans': {
        // what's left on each loan, as added in Wealth › Debts, and how long the EMI takes to clear it
        var wl = f.which ? new RegExp(f.which === 'home' || f.which === 'housing' ? 'home|housing' : f.which === 'car' || f.which === 'vehicle' ? 'car|vehicle|auto' : f.which, 'i') : null;
        var ls = (ctx.loans || []).filter(function (l) { return l.active !== false && (!wl || wl.test(l.name + ' ' + (l.bank || ''))); });
        var loanW = f.which ? 'your ' + f.which + ' loan' : ls.length === 1 ? 'your ' + ls[0].name : 'your loans';
        if (f.ask === 'prepaid') { o.text = 'kosh can’t tell a prepayment on ' + loanW + ' from its EMIs in what the bank’s mail says.' + (ls.length === 1 && ls[0].outstanding > 0 ? ' What’s left on it: **' + inr(ls[0].outstanding) + '**' + (ls[0].rate ? ' at ' + ls[0].rate + '%' : '') + '.' : '') + ' A prepayment you add on the loan’s page in Wealth › Debts is counted.'; o.suggest = ['How much of my home loan is left?']; break; }
        if (f.ask === 'interest') { o.text ='kosh can’t see how much of what you paid on ' + loanW + ' was interest: the lender’s mail kosh reads doesn’t split it out.' + (ls.length === 1 && ls[0].outstanding > 0 ? ' What’s left on it: ' + inr(ls[0].outstanding) + (ls[0].rate ? ' at ' + ls[0].rate + '%' : '') + '.' : ''); o.suggest = ['What repeats every month?']; break; }
        // a loan kosh only knows by its EMI: what's left on it is said not to be known, with the EMI it does know
        var emiR = !ls.length ? (ctx.recurring || []).filter(function (r) { return !r.lapsed && r.kind === 'emi' && (!wl || wl.test(r.name)); })[0] : null;
        if (emiR) { o.text = 'kosh can’t see what’s left on ' + loanW + ': the lender’s statement isn’t in the mail kosh reads. Its EMI is **' + inr(emiR.amount) + '** a month (' + emiR.name + (emiR.date ? ', next ' + on(emiR.date, today) : '') + '). Add what’s outstanding in Wealth › Debts and kosh keeps count.'; o.suggest = ['What repeats every month?']; break; }
        if (!ls.length) { o.text = 'kosh doesn’t know ' + (f.which ? 'your ' + f.which + ' loan' : 'your loans') + ' yet. Add ' + (f.which ? 'it' : 'them') + ' in Wealth › Debts with what’s outstanding and the rate.'; o.suggest = ['What repeats every month?']; break; }
        var toGo = function (l) {
          var r = (+l.rate || 0) / 1200, P = +l.outstanding || 0, e = +l.emi || 0;
          if (!(P > 0 && e > 0) || (r > 0 && e <= P * r)) return '';
          var n = r > 0 ? Math.ceil(Math.log(e / (e - P * r)) / Math.log(1 + r)) : Math.ceil(P / e), yy = Math.floor(n / 12), mm = n % 12;
          return ', about ' + (yy ? n_(yy, 'year') + (mm ? ' ' + n_(mm, 'month') : '') : n_(mm, 'month')) + ' to go at this EMI';
        };
        var lineL = function (l) {
          // (an estimate, said as one: what's owed isn't in its mail)
          if (l.est && l.outstanding > 0) return l.name + ' · about **' + inr(l.outstanding) + '** left' + (l.emi ? ', EMI ' + inr(l.emi) : '') + ' — an estimate: kosh can’t see what’s owed in its mail, so it takes a loan of the usual length from the first EMI it saw. Add what’s owed in Wealth › Debts for the exact figure';
          return l.outstanding > 0 ? l.name + ' · **' + inr(l.outstanding) + '** left' + (l.rate ? ' at ' + l.rate + '%' : '') + (l.emi ? ', EMI ' + inr(l.emi) : '') + (l.due ? ', due in one go on ' + dShort(l.due) + (l.due.slice(0, 4) !== String(ctx.today || '').slice(0, 4) ? ' ' + l.due.slice(0, 4) : '') : toGo(l)) : l.name + (l.emi ? ' · EMI ' + inr(l.emi) : '') + ': what’s left on it isn’t known yet (add it in Wealth › Debts)';
        };
        var knownL = ls.filter(function (l) { return l.outstanding > 0; });
        // how many EMIs are left: a card purchase on EMIs counts them; a loan, about how many at its EMI
        if (f.emisLeft) {
          var counted = ls.filter(function (l) { return l.n > 0 && l.left >= 0; });
          var lineN = function (l) { return l.name + ': **' + n_(l.left, 'EMI') + ' left** of ' + l.n + ', ' + inr(l.emi) + ' each' + (l.outstanding > 0 ? ' (about ' + inr(l.outstanding) + ' still owed)' : ''); };
          if (counted.length) {
            o.text = counted.length === 1 ? lineN(counted[0]) + '.' : counted.map(lineN).join('\n- ').replace(/^/, '- ');
            var others = ls.filter(function (l) { return counted.indexOf(l) < 0; });
            if (others.length) o.text += '\n\nAnd ' + others.map(function (l) { return l.name + (toGo(l) ? toGo(l).replace(/^, /, ': ') : ''); }).join('; ') + '.';
            step('loans', 'Loans', counted.length + ' counted EMI plans.');
            o.suggest = ['What’s due this week?', 'What is our net worth?'];
            break;
          }
        }
        o.text = ls.length === 1 ? lineL(ls[0]).replace(' · ', ': ') + '.' : (knownL.length > 1 ? '**' + inr(sum(knownL, function (l) { return l.outstanding; })) + '** left on ' + n_(knownL.length, 'loan') + ':\n- ' : 'Your loans:\n- ') + ls.map(lineL).join('\n- ');
        step('loans', 'Loans', ls.length + ' loans.');
        o.suggest = ['Should I prepay my home loan?', 'What’s due this week?'];
        break;
      }
      case 'committee': {
        var cm0 = ctx.committees, cms = (cm0 || []).filter(function (c) { return !c.done; });
        var paidC = (ctx.tx || []).filter(function (t) { return t.s === 'Chit fund' && t.a > 0; }).sort(byDate);
        var repC = (ctx.recurring || []).filter(function (r) { return r.kind === 'committee' && !r.lapsed; });
        if (!cms.length && !paidC.length && !repC.length) {
          // a committee kosh knows only from the ledger: the pool from the organiser names it ("…-Bhishi Aug"), and the
          // instalments are the payments to that organiser
          // (a chit company by its name: KSFE, Shriram Chits, Margadarsi; or the organiser the question names, "KSFE chitty")
          var CW = /\b(?:bh?ishi|bisi|chits?|chitt[yi]|kur[iy]|committee|kitty|ksfe|margadarsi|kapil chits?|shriram chits?)\b/i, orgs = [];
          (ctx.tx || []).forEach(function (t) { if (CW.test(t.m || '')) { var nm = lc(t.m).split(/\s*[-–\/|]\s*/)[0].replace(CW, '').replace(/\s+/g, ' ').trim(); if (nm.length >= 4 && orgs.indexOf(nm) < 0) orgs.push(nm); } });
          var namesOne = f.merchant && !String(f.merchant).toLowerCase().split(/\s+/).every(function (w) { return STOP[w]; });
          if (namesOne && !CW.test(f.merchant)) (ctx.tx || []).forEach(function (t) { var m = lc(t.m).trim(); if (has(t.m, f.merchant) && orgs.indexOf(m) < 0) orgs.push(m); });
          var orgOk = function (t) { return CW.test(t.m || '') || orgs.indexOf(lc(t.m).trim()) >= 0; };
          var spCm = f.named ? { from: f.from, to: f.to, label: f.label } : null, wCm = spCm ? ' ' + spanWords(spCm, today) : ' so far';
          var poolR = (ctx.tx || []).filter(function (t) { return t.a > 0 && (t.k === 'in' || (t.k === 'move' && /^transfer in$/i.test(t.c || ''))) && orgOk(t) && (!spCm || within2(t, spCm, today)); }).sort(byDate);
          var instR = (ctx.tx || []).filter(function (t) { return (t.k === 'out' || putIn(t)) && t.a > 0 && t.d <= today && (!spCm || within2(t, spCm, today)) && orgOk(t); }).sort(byDate);
          // the next instalment: the calendar's, else a month after the last one paid
          if (f.what === 'next' && instR.length) {
            var agC = (ctx.agenda || []).filter(function (x) { return x.kind !== 'in' && x.date >= today && orgOk({ m: x.name }); }).sort(function (a, b) { return a.date.localeCompare(b.date); })[0];
            var lastI = instR[0], dayI = +lastI.d.slice(8, 10);
            var nextD = agC ? agC.date : (function () { var m0 = addDays(monthEnd(lastI.d), 1).slice(0, 7); while (m0 + '-' + pad(Math.min(dayI, +monthEnd(m0 + '-01').slice(8))) < today) m0 = addDays(monthEnd(m0 + '-01'), 1).slice(0, 7); return m0 + '-' + pad(Math.min(dayI, +monthEnd(m0 + '-01').slice(8))); })();
            o.text = 'Your next instalment to ' + lastI.m + ': **' + inr(agC ? agC.amt : lastI.a) + '** ' + at(nextD, today) + (agC ? '' : ', a month after the last one (' + inr(lastI.a) + ' ' + at(lastI.d, today) + ')') + '. kosh knows the committee from these payments: add it in Committees to follow its months.';
            o.rows = idsOf(instR.slice(0, 6));
            step('committees', 'Committee from the ledger', instR.length + ' instalments; next ' + nextD + '.');
            o.suggest = ['How much have I paid into the committee?', 'What’s due this week?'];
            break;
          }
          if (poolR.length || instR.length) {
            var orgW = instR.length ? instR[0].m : poolR[0].m.split(/\s*[-–]\s*/)[0];
            var gotFirst = f.what === 'got' && poolR.length, withW = ' your committee with ' + orgW;
            var gotW = poolR.length ? '**' + inr(sumA(poolR)) + '** came from' + (gotFirst || !instR.length ? withW : ' it') + (poolR.length === 1 ? ', ' + at(poolR[0].d, today) : ', across ' + n_(poolR.length, 'payout') + ', the last ' + at(poolR[0].d, today)) + '.' : '';
            var paidW = instR.length ? 'You’ve paid ' + (gotFirst ? inr(sumA(instR)) : '**' + inr(sumA(instR)) + '**') + ' into' + (gotFirst ? ' it' : withW) + wCm + ', ' + n_(instR.length, 'instalment') + (instR.every(function (t) { return Math.abs(t.a - instR[0].a) < 1; }) ? ' of ' + inr(instR[0].a) : '') + '.' : '';
            o.text = (f.what === 'got' && !poolR.length ? 'kosh hasn’t seen money come from your committee' + wCm + '. ' : '') + (gotFirst ? [gotW, paidW] : [paidW, gotW]).filter(Boolean).join(' ') + ' kosh knows it from these payments: add it in Committees to follow its months.';
            o.rows = idsOf(poolR.concat(instR));
            step('committees', 'Committee from the ledger', instR.length + ' instalments, ' + poolR.length + ' payouts.');
            o.suggest = ['What’s due this week?'];
            break;
          }
          o.text = cm0 ? 'kosh doesn’t know a committee of yours yet. Add one in Committees, with who you pay it to, and kosh follows it.' : 'kosh can’t see your committees on this phone yet: the Committees tab has them.'; break; }
        var nextOf = function (c) {
          var r = repC.filter(function (x) { return c && c.payee && lc(x.name) === lc(c.payee); })[0] || (cms.length <= 1 ? repC[0] : null);
          var m = c && c.next ? c.next.m : '', day = r && (!m || r.date.slice(0, 7) === m) ? r.date : m ? m + '-' + pad(Math.min(28, c.day || 10)) : r ? r.date : '';
          return day ? { date: day, amt: c && c.next ? c.next.amt : r.amount, to: c && c.payee ? c.payee : r ? r.name : '' } : null;
        };
        var nmC = function (c) { return c && c.name ? c.name : 'your committee'; };
        // the month to take the pool lives in Committees: a phone that hasn't handed it over can't say it
        var noDraw = !cms.length && f.what === 'draw' ? 'kosh can’t see your committee’s month to take the pool on this phone yet: the Committees tab has it. ' : '';
        if (f.what === 'paid' || (!cms.length && f.what !== 'next')) {
          var cpaid = cms.length ? sum(cms, function (c) { return c.contributed || 0; }) : sumA(paidC), cn = cms.length ? sum(cms, function (c) { return c.paid || 0; }) : paidC.length;
          o.text = noDraw + (noDraw ? 'You’ve paid ' : 'You’ve paid **') + inr(cpaid) + (noDraw ? '' : '**') + ' into ' + (cms.length === 1 ? nmC(cms[0]) : cms.length ? n_(cms.length, 'committee') : noDraw ? 'it' : 'your committee') + ' so far' + (cn ? ', ' + n_(cn, 'instalment') : '') + (paidC.length ? ', the first ' + at(paidC[paidC.length - 1].d, today) : '') + '.';
          if (cms.length === 1 && cms[0].outstanding > 0) o.text += ' ' + inr(cms[0].outstanding) + ' to go over ' + n_(cms[0].left || 0, 'more month') + '.';
          o.rows = idsOf(paidC);
        } else if (f.what === 'next') {
          var nx0 = nextOf(cms[0]);
          o.text = nx0 ? 'Your next ' + (cms[0] ? nmC(cms[0]) + ' ' : 'committee ') + 'instalment: **' + inr(nx0.amt) + '** ' + at(nx0.date, today) + (nx0.to ? ', to ' + nx0.to : '') + '.' : 'Every instalment of ' + nmC(cms[0]) + ' is paid.';
        } else {
          o.text = cms.map(function (c) {
            var drawW = c.draw ? MONF[+c.draw.slice(5, 7) - 1] + ' ' + c.draw.slice(0, 4) : '';
            var gets = c.taken ? 'You took the pool' + (drawW ? ' in ' + drawW : '') + '.' : drawW ? 'Your turn to take the pool: **' + drawW + '**' + (c.net > 0 ? ', about **' + inr(c.net) + '**' : '') + '.' : c.kind === 'auction' ? 'It’s an auction: when you take it depends on the bidding.' : 'kosh doesn’t know your month yet: set it in Committees.';
            return '**' + c.name + '**: ' + gets + ' ' + inr(c.contributed || 0) + ' paid in so far' + (c.outstanding > 0 ? ', ' + inr(c.outstanding) + ' to go' : '') + '.';
          }).join('\n\n');
          var nx1 = cms.length === 1 ? nextOf(cms[0]) : null;
          if (nx1) o.text += ' Next instalment ' + inr(nx1.amt) + ' ' + at(nx1.date, today) + '.';
        }
        step('committees', 'Committees', (cms.length || repC.length) + ' running.');
        o.suggest = ['How much have I paid into the committee?', 'What’s due this week?'];
        break;
      }
      case 'goal': {
        var gl = ctx.goals || [], qn = norm(f.q || '');
        if (!gl.length) { o.text = 'You haven’t set a goal yet. Plan › Goals is where you set one: an amount and a date, and kosh keeps count.'; break; }
        var namedG = gl.filter(function (g) { return lc(g.name).split(/\s+/).some(function (w) { return w.length >= 4 && qn.indexOf(' ' + w + ' ') >= 0; }); });
        o.text = (namedG.length ? namedG : gl).map(function (g) { return goalLine(g, today); }).join('\n\n');
        step('goals', 'Goals', gl.length + ' goals.');
        o.suggest = ['How much did I save last month?', 'What are my investments worth?'];
        break;
      }
      case 'trials': {
        var sub0 = ctx.subs || {}, trs = (sub0.trials || []).filter(function (t) { return !t.date || t.date >= today; });
        // a subscription about to charge that has never charged before: maybe a trial turning into a payment
        var known0 = (ctx.recurring || []).filter(function (r) { return r.kind === 'sub'; }).map(function (r) { return lc(r.name); });
        var firsts = (ctx.agenda || []).filter(function (a) {
          return a.kind === 'out' && !a.booked && a.date >= today && a.date <= addDays(today, 30) && (a.trial || a.cat === 'Subscriptions') &&
            known0.indexOf(lc(a.name)) < 0 && !trs.some(function (t) { return lc(t.name) === lc(a.name); });
        });
        if (!trs.length && !firsts.length) { o.text = 'No free trials kosh can see ending in the next month.'; break; }
        var parts0 = [];
        if (trs.length) parts0.push('**' + cap1(n_(trs.length, 'free trial')) + '** about to turn into a charge:\n- ' + trs.map(function (t) { return t.name + (t.amt > 0 ? ' · ' + inr(t.amt) + (t.every ? ' ' + t.every : '') : '') + (t.date ? ' · ' + on(t.date, today) : ''); }).join('\n- '));
        if (firsts.length) parts0.push((trs.length ? 'Also charging for the first time' : 'Charging for the first time, maybe at the end of a trial') + ':\n- ' + firsts.map(function (a) { return a.name + ' · ' + inr(a.amt) + ' · ' + on(a.date, today); }).join('\n- '));
        o.text = parts0.join('\n\n') + '\n\nIf you don’t want one, cancel it before that day: Plan › Subscriptions shows how.';
        o.suggest = ['Which subscriptions can I cancel?', 'What’s due this week?'];
        break;
      }
      case 'subcancel': {
        var sb0 = ctx.subs || {}, sbs = (sb0.subs || []).slice(), ovs = sb0.overlaps || [];
        if (!sbs.length) sbs = (ctx.recurring || []).filter(function (r) { return r.kind === 'sub' && !r.lapsed; }).map(function (r) { return { name: r.name, amount: r.amount, monthly: r.amount / (r.per || 1), yearly: r.amount * 12 / (r.per || 1) }; });
        if (!sbs.length) { o.text = 'No subscriptions found yet. kosh spots one once it has come twice, about a month apart.'; break; }
        sbs.sort(function (a, b) { return (b.yearly || 0) - (a.yearly || 0); });
        var partsS = [];
        if (ovs.length) partsS.push('**Doing the same job**:\n- ' + ovs.map(function (x) { return joinAnd(x.names || []) + (x.yearly ? ', ' + inr(x.yearly) + ' a year together' : ''); }).join('\n- ') + '\nIf one does the job, the other can go.');
        partsS.push('**Your subscriptions**, the costliest first:\n- ' + sbs.slice(0, 8).map(function (x) { return x.name + ' · ' + inr(x.monthly || x.amount) + ' a month (' + inr(x.yearly || (x.monthly || x.amount) * 12) + ' a year)'; }).join('\n- '));
        o.text = partsS.join('\n\n') + '\n\nPlan › Subscriptions has how to cancel each one.';
        o.suggest = ['Any free trials ending soon?', 'How much do I spend on subscriptions a month?'];
        break;
      }
      case 'rise': {
        // repeats that cost more than they did: from the payments themselves (the old amount at least twice, then the
        // new one), else the rise the engine worked out
        var rises = (ctx.recurring || []).filter(function (r) { return !r.lapsed && (!f.merchant || has(r.name, f.merchant)); }).map(function (r) {
          var rr = (ctx.tx || []).filter(function (t) { return lc(t.m) === lc(r.name) && t.a > 0 && (t.k === 'out' || putIn(t)); }).sort(function (a, b) { return a.d.localeCompare(b.d); });
          for (var i = rr.length - 1; i >= 2; i--) {
            if (Math.abs(rr[i].a - rr[i - 1].a) >= 1) {
              var newA = rr[i].a, oldA = rr[i - 1].a, stable = Math.abs(rr[i - 2].a - oldA) < 1 && rr.slice(i).every(function (t) { return Math.abs(t.a - newA) < 1; });
              return stable && newA > oldA ? { r: r, from: oldA, to: newA, when: rr[i].d } : null;
            }
          }
          return r.rise > 0 && r.riseFrom > 0 ? { r: r, from: r.riseFrom, to: r.amount, when: '' } : null;
        }).filter(Boolean);
        var rNamed = f.merchant ? recurringNamed(norm(f.q || ''), f, ctx) : null;
        if (f.merchant && !rises.length) { o.text = rNamed ? 'No: ' + rNamed.name + ' has cost ' + inr(rNamed.amount) + ' every time kosh has seen it.' : 'kosh hasn’t seen ' + payeeName(f.merchant, ctx) + ' charge you on a schedule, so it can’t say.'; break; }
        if (!rises.length) { o.text = 'None of your repeats costs more than it used to, in what kosh has seen.'; break; }
        var lineR = function (x) { var per = x.r.per || 1; return x.r.name + ' · ' + inr(x.from) + ' → ' + inr(x.to) + (x.when ? ' from ' + MON3[+x.when.slice(5, 7) - 1] + (x.when.slice(0, 4) !== today.slice(0, 4) ? ' ' + x.when.slice(0, 4) : '') : '') + ' (' + inr((x.to - x.from) * 12 / per) + ' a year more)'; };
        o.text = f.merchant && rises.length === 1 ? 'Yes: **' + rises[0].r.name + '** went up from ' + inr(rises[0].from) + ' to **' + inr(rises[0].to) + '**' + (rises[0].when ? ' in ' + monthWord(rises[0].when.slice(0, 7), today) : '') + ', ' + inr((rises[0].to - rises[0].from) * 12 / (rises[0].r.per || 1)) + ' a year more.'
          : '**' + cap1(n_(rises.length, 'repeat')) + ' ' + (rises.length === 1 ? 'costs' : 'cost') + ' more than ' + (rises.length === 1 ? 'it' : 'they') + ' used to**:\n- ' + rises.map(lineR).join('\n- ');
        o.suggest = ['Which subscriptions can I cancel?', 'What repeats every month?'];
        break;
      }
      case 'price': {
        var rp1 = recurringNamed(norm(f.q || ''), f, ctx);
        if (!rp1) { o = answerOf(Object.assign({}, f, { act: 'total' }), ctx, prevAct); break; }
        var per1 = rp1.per || 1, every1 = per1 === 12 ? ' a year' : per1 === 6 ? ' every six months' : per1 === 3 ? ' every three months' : ' a month';
        o.text = '**' + rp1.name + '** is **' + inr(rp1.amount) + every1 + '**' + (rp1.date ? ', next ' + at(rp1.date, today) : '') + '.' + (per1 < 12 ? ' That’s ' + inr(rp1.amount * 12 / per1) + ' a year.' : '');
        if (rp1.rise > 0 && rp1.riseFrom > 0) o.text += ' It was ' + inr(rp1.riseFrom) + ' before.';
        o.suggest = ['Which subscriptions can I cancel?', 'Did any subscription go up?'];
        break;
      }
      case 'emi': {
        var we = runTool('whatif', { kind: 'emi', principal: f.principal, rate: f.rate, months: f.months }, ctx);
        var e = we.data && we.data.emi;
        o.text = e ? 'About **' + inr(e) + ' a month** for ' + (f.months % 12 === 0 ? f.months / 12 + ' years' : f.months + ' months') + ' on ' + lakh(f.principal) + ' at ' + f.rate + '%. ' +
          'You’d pay ' + inr(Math.round(e * f.months)) + ' in all, ' + inr(Math.round(e * f.months - f.principal)) + ' of it interest.' : we.text;
        step('whatif', 'Worked out the EMI', we.text);
        o.suggest = ['What repeats every month?', 'How much did I save last month?'];
        break;
      }
      case 'scheme': {
        // the scheme's own rule for when interest is paid, and the last such credit kosh has seen
        var y0 = +today.slice(0, 4), qd = [y0 + '-01-01', y0 + '-04-01', y0 + '-07-01', y0 + '-10-01', (y0 + 1) + '-01-01'].filter(function (d) { return d > today; })[0];
        var nmS = { scss: 'SCSS', pomis: 'Post Office Monthly Income Scheme', ppf: 'PPF' }[f.which];
        var reS = { scss: /\bscss\b|senior cit/i, pomis: /\bpomis\b|\bmis\b|monthly income/i, ppf: /\bppf\b|public provident/i }[f.which];
        var seenS = (ctx.tx || []).filter(function (t) { return t.a > 0 && (t.k === 'in' || t.k === 'move') && reS.test((t.m || '') + ' ' + (t.n || '')); }).sort(byDate);
        o.text = f.which === 'scss' ? 'SCSS interest is paid every quarter, on 1 April, 1 July, 1 October and 1 January (the next working day when that’s a holiday). The next is **' + dShort(qd) + (qd.slice(0, 4) !== today.slice(0, 4) ? ' ' + qd.slice(0, 4) : '') + '**.'
          : f.which === 'pomis' ? 'Post Office Monthly Income Scheme interest is paid every month, on the day of the month the account was opened.'
          : 'PPF interest is added once a year, on 31 March, into the account itself: it doesn’t come to your bank.';
        if (seenS.length) o.text += ' The last kosh saw: ' + inr(seenS[0].a) + ' ' + at(seenS[0].d, today) + '.';
        else if (f.which !== 'ppf') o.text += ' kosh hasn’t seen a ' + nmS + ' interest credit in your mail yet.';
        o.rows = idsOf(seenS);
        o.suggest = ['How much interest did I earn this financial year?', 'What FDs do we have?'];
        break;
      }
      case 'crypto': {
        // an exchange's mail says what was bought at what price, never what's held now: kosh says so, and what it saw go
        var coinW = f.coin === 'btc' || !f.coin ? (f.coin ? 'bitcoin' : 'crypto') : f.coin;
        var EXCH = /coindcx|wazirx|zebpay|coinswitch|binance|mudrex|bitbns|giottus|unocoin|coinbase|\bcrypto\b|bitcoin/i;
        var cOut = (ctx.tx || []).filter(function (t) { return t.a > 0 && t.d <= today && (t.k === 'out' || putIn(t) || t.k === 'prepaid') && EXCH.test(t.m || ''); }).sort(byDate);
        var cIn = (ctx.tx || []).filter(function (t) { return t.a > 0 && t.d <= today && t.k === 'in' && EXCH.test(t.m || ''); });
        o.text = 'kosh can’t see how much ' + coinW + ' you hold: an exchange’s mail says what was bought and at what price, not what you have now, and kosh doesn’t read your exchange account.';
        if (cOut.length) o.text += '\n\nWhat it has seen go to crypto: **' + inr(sumA(cOut)) + '**' + (cOut.length === 1 ? ' to ' + cOut[0].m + ' ' + at(cOut[0].d, today) : ' across ' + n_(cOut.length, 'payment') + ', the last ' + inr(cOut[0].a) + ' to ' + cOut[0].m + ' ' + at(cOut[0].d, today)) + (cIn.length ? '; ' + inr(sumA(cIn)) + ' came back from an exchange' : '') + '.';
        o.rows = idsOf(cOut.concat(cIn));
        step('transactions', 'Money to crypto exchanges', cOut.length + ' payments, ' + inr(sumA(cOut)) + '.');
        o.suggest = ['What are my investments worth?', 'How much did I invest this year?'];
        break;
      }
      case 'fnf': {
        // a job left: the employer whose salary stopped, and its last credit (the settlement comes after the last salary)
        var salR = (ctx.tx || []).filter(function (t) { return t.k === 'in' && t.c === 'Salary' && t.a > 0 && (!f.person || personOk(t, f.person, ctx)); });
        var payers = {}; salR.forEach(function (t) { payers[lc(t.m).trim()] = 1; });
        var stopped = Object.keys(payers).map(function (k) {
          var all = (ctx.tx || []).filter(function (t) { return t.k === 'in' && t.a > 0 && lc(t.m).trim() === k; }).sort(byDate);
          var sal = all.filter(function (t) { return t.c === 'Salary'; });
          return { k: k, all: all, lastSal: sal[0] };
        }).filter(function (x) { return x.all.length && daysBetween(x.all[0].d, today) > 40; }).sort(function (a, b) { return b.all[0].d.localeCompare(a.all[0].d); });
        if (!stopped.length) { o.text = 'kosh hasn’t seen a full and final settlement' + (salR.length ? ': your salary from ' + salR.sort(byDate)[0].m + ' still comes in.' : ', or a salary, in your mail.'); break; }
        var st0 = stopped[0], last0 = st0.all[0];
        if (st0.lastSal && last0.id === st0.lastSal.id) o.text = 'kosh hasn’t seen a separate settlement from ' + last0.m + ': the last that came from it was your salary, **' + inr(last0.a) + '** ' + at(last0.d, today) + '.';
        else o.text = 'Your full and final settlement looks like **' + inr(last0.a) + '** from ' + last0.m + ' ' + at(last0.d, today) + ': its last credit' + (st0.lastSal ? ', after your last salary from it (' + inr(st0.lastSal.a) + ' ' + at(st0.lastSal.d, today) + ')' : '') + '.';
        o.rows = idsOf(st0.all.slice(0, 4));
        step('income', 'The last credits from ' + last0.m, st0.all.slice(0, 4).map(function (t) { return t.d + ' ' + inr(t.a) + ' (' + t.c + ')'; }).join('; ') + '.');
        o.suggest = ['How much is my salary?', 'When did my salary come last?'];
        break;
      }
      case 'ptax': {
        // property tax paid, from the ledger: over a year when no stretch is asked (it's paid once or twice a year)
        var spP = span || { from: addDays(today, -364), to: today, label: 'in the last 12 months' }, wP = spanWords(spP, today);
        var rowsP = (ctx.tx || []).filter(function (t) { return (t.k === 'out' || t.k === 'prepaid') && t.a > 0 && within2(t, spP, today) && /property tax|house tax/i.test((t.s || '') + ' ' + (t.m || '') + ' ' + (t.n || '')) && personOk(t, f.person, ctx); }).sort(byDate);
        var dueP = (ctx.props || []).filter(function (p) { return p.taxDue > 0; });
        if (!rowsP.length) o.text = 'kosh hasn’t seen property tax paid ' + wP + '.';
        else o.text = 'You paid **' + inr(sumA(rowsP)) + '** in property tax ' + wP + ': ' + joinAnd(rowsP.slice(0, 4).reverse().map(function (t) { return inr(t.a) + ' to ' + t.m + ' ' + at(t.d, today); })) + (rowsP.length > 4 ? ' and ' + (rowsP.length - 4) + ' more' : '') + '.' + sinceNote(spP, ctx);
        if (dueP.length) o.text += ' Still due: ' + joinAnd(dueP.map(function (p) { return inr(p.taxDue) + ' on ' + p.name; })) + '.';
        o.rows = idsOf(rowsP);
        step('spending', 'Property tax', rowsP.length + ' payments ' + wP + ', ' + inr(sumA(rowsP)) + '.');
        o.suggest = ['How much tax did I pay this year?', 'What’s due this month?'];
        break;
      }
      case 'from': {
        // money from someone: credits that name them (a transfer in from a brother, a friend's NEFT); from abroad, the
        // bank's alert rarely names who sent it, so that is said
        var pF = f.pid ? (ctx.people || []).filter(function (p) { return p.id === f.pid; })[0] : null;
        var wordsF = (pF ? [pF.name, String(pF.full || '').split(/\s+/)[0]] : [f.word || f.who]).map(lc).filter(function (w, i, a) { return w.length >= 3 && /^[a-z]+$/.test(w) && a.indexOf(w) === i; });
        var whoF = pF ? pF.name : cap1(f.who || '');
        var spF = span || { from: addDays(today, -364), to: today, label: 'in the last 12 months' }, wF = spanWords(spF, today);
        var isIn = function (t) { return t.a > 0 && !t.ex && (t.k === 'in' || (t.k === 'move' && /^transfer in$/i.test(t.c || ''))); };
        var rowsF = (ctx.tx || []).filter(function (t) { return isIn(t) && (!pF || (t.o || 'me') !== pF.id) && within2(t, spF, today) && wordsF.some(function (w) { return wordIn(t.m, w); }); }).sort(byDate);
        if (rowsF.length) {
          if (f.monthly && !span) {
            var md = median(rowsF.slice(0, 3).map(function (t) { return t.a; }));
            o.text = whoF + ' sends about **' + inr(md) + '** a month: the last ' + inr(rowsF[0].a) + ' came ' + at(rowsF[0].d, today) + '; ' + inr(sumA(rowsF)) + ' across ' + n_(rowsF.length, 'transfer') + ' in the last 12 months.';
          } else o.text = '**' + inr(sumA(rowsF)) + '** came from ' + whoF + ' ' + wF + (rowsF.length === 1 ? ', ' + at(rowsF[0].d, today) : ', across ' + n_(rowsF.length, 'credit') + '; the last ' + inr(rowsF[0].a) + ' ' + at(rowsF[0].d, today)) + '.' + sinceNote(spF, ctx);
          o.rows = idsOf(rowsF);
          step('income', 'Money from ' + whoF, rowsF.length + ' credits ' + wF + ', ' + inr(sumA(rowsF)) + '.');
          o.suggest = ['Show these payments', 'How much came in this month?'];
          break;
        }
        var remF = pF || f.ins ? [] : (ctx.tx || []).filter(function (t) { return isIn(t) && within2(t, spF, today) && /remit|\bwise\b|transferwise|remitly|western union|moneygram|instarem|\bxoom\b|inward|\bswift\b/i.test((t.m || '') + ' ' + (t.n || '')); }).sort(byDate);
        if (remF.length) {
          o.text = 'kosh hasn’t seen money from ' + whoF + ' by name: the bank’s alerts for money from abroad don’t say who sent it. Money from abroad ' + wF + ': **' + inr(sumA(remF)) + '**' + (remF.length === 1 ? ', ' + at(remF[0].d, today) : ' across ' + n_(remF.length, 'credit') + '; the last ' + inr(remF[0].a) + ' ' + at(remF[0].d, today)) + '.' + sinceNote(spF, ctx);
          o.rows = idsOf(remF);
          step('income', 'Money from abroad', remF.length + ' credits ' + wF + ', ' + inr(sumA(remF)) + '.');
        } else o.text = 'kosh hasn’t seen money from ' + whoF + ' ' + wF + '.' + (f.ins ? ' A cashless claim is settled with the hospital directly, so it never reaches your account; a reimbursement would show here as money in.' : ' It looks for credits that name ' + (pF ? (pF.full || pF.name) : whoF) + '.');
        o.suggest = ['How much came in this month?', 'Money in, month by month'];
        break;
      }
      case 'supplier': {
        // the business's payments that aren't tax, bills, salaries, loans or drawings
        var spSu = span || thisMonth, wSu = spanWords(spSu, today), bo = bizOwners(ctx);
        var rowsSu = (ctx.tx || []).filter(function (t) { return (t.k === 'out' || t.k === 'prepaid') && t.a > 0 && within2(t, spSu, today) && bo.indexOf(t.o || '') >= 0 &&
          !/^(?:Tax|Income tax|Bills|EMI|Insurance|Self Transfer|Transfer|Card Payments?|Investments|Cash Withdrawal|Rent)$/i.test(t.c || '') && !/salar|wages|payroll|staff|drawings?|\bgst\b|\btds\b|\btax\b|electric|power ltd/i.test(t.m || ''); }).sort(byAmt);
        if (!rowsSu.length) { o.text = 'kosh hasn’t seen the business pay a supplier ' + wSu + '.'; break; }
        var gSu = groupBy(rowsSu, 'payee', ctx);
        o.text = 'The business paid **' + inr(sumA(rowsSu)) + '** to suppliers ' + wSu + ': ' + joinAnd(gSu.slice(0, 4).map(function (x) { return x.name + ' ' + inr(x.v); })) + (gSu.length > 4 ? ' and ' + (gSu.length - 4) + ' more' : '') + '. Tax, bills, salaries and drawings aren’t in it.';
        o.rows = idsOf(rowsSu);
        step('spending', 'The business’s payments to suppliers', rowsSu.length + ' payments ' + wSu + ', ' + inr(sumA(rowsSu)) + '.');
        o.suggest = ['How much did the business get from customers last month?', 'How much GST did we pay this financial year?'];
        break;
      }
      case 'billamt': {
        // the bill that came (on the calendar, from its mail), else the last one paid; a bill kosh sees no trace of is said
        var K = BILL_KIND.filter(function (k) { return k[0] === f.kind; })[0], wB = f.word || '';
        var alnum = function (x) { return lc(x).replace(/[^a-z0-9]/g, ''); };
        var billTx = function (t) { return (t.k === 'out' || t.k === 'prepaid') && t.a > 0 && (K ? K[3].test(t.s || '') || K[2].test(t.m || '') : wordIn(t.m, wB) || alnum(t.m).indexOf(wB) === 0); };
        var rowsB = (ctx.tx || []).filter(function (t) { return t.d >= addDays(today, -365) && t.d <= today && billTx(t) && personOk(t, f.person, ctx); }).sort(byDate);
        var payB = rowsB.map(function (t) { return alnum(t.m); });
        var agB = (ctx.agenda || []).filter(function (x) {
          if (x.kind === 'in' || x.booked || !x.date || x.date < addDays(today, -7) || x.date > addDays(today, 45)) return false;
          var nm = x.name + ' ' + (x.sub || ''), an = alnum(x.name);
          return K ? K[2].test(nm) || (an.length >= 4 && payB.some(function (p) { return p.indexOf(an) >= 0; })) : wordIn(nm, wB) || an.indexOf(wB) === 0;
        }).sort(function (a, b) { return a.date.localeCompare(b.date); });
        var whatB = K ? f.kind + ' bill' : (rowsB[0] ? rowsB[0].m : cap1(wB)) + ' bill';
        if (f.paidQ) {
          // paid or not: a bill still due on the calendar is not paid (a paid one leaves it); else the last payment to it
          // within the last 45 days is its bill paid
          var dueB = agB.filter(function (x) { return x.date >= addDays(today, -7); })[0];
          var lastB = rowsB.filter(function (t) { return t.d >= addDays(today, -45); })[0];
          if (dueB && !(lastB && lastB.d >= addDays(dueB.date, -40) && Math.abs(lastB.a - dueB.amt) <= 1)) o.text = 'No: your ' + whatB + ' of **' + inr(dueB.amt) + '** (' + dueB.name + ') is due ' + on(dueB.date, today) + (dueB.date < today ? ', and kosh hasn’t seen it paid.' : '.');
          else if (lastB) o.text = 'Yes: **' + inr(lastB.a) + '** paid to ' + lastB.m + ' ' + at(lastB.d, today) + '.';
          else if (rowsB.length) o.text = 'kosh hasn’t seen your ' + whatB + ' paid lately: the last was **' + inr(rowsB[0].a) + '** to ' + rowsB[0].m + ' ' + at(rowsB[0].d, today) + '.';
          else o.text = 'kosh can’t see ' + (/^[aeiou]/i.test(whatB) ? 'an ' : 'a ') + whatB + ' yet: no bill or payment for it is in the mail kosh reads.';
          o.rows = idsOf(lastB ? [lastB] : []);
          step('upcoming', 'The ' + whatB, (dueB ? 'one due on the calendar; ' : 'none due on the calendar; ') + rowsB.length + ' paid in the last 12 months.');
          o.suggest = ['What’s due this week?', 'What bills are due this month?'];
          break;
        }
        if (agB.length) {
          o.text = agB.length === 1 ? 'Your ' + whatB + ': **' + inr(agB[0].amt) + '** (' + agB[0].name + '), due ' + on(agB[0].date, today) + '.'
            : '**' + inr(sum(agB, function (x) { return x.amt; })) + '** in ' + whatB + 's:\n- ' + agB.map(function (x) { return on(x.date, today) + ' · ' + x.name + ' · ' + inr(x.amt); }).join('\n- ');
          if (rowsB.length) o.text += (agB.length === 1 ? ' ' : '\n\n') + 'The last one paid: ' + inr(rowsB[0].a) + ' to ' + rowsB[0].m + ' ' + at(rowsB[0].d, today) + '.';
        } else if (rowsB.length && K) {
          o.text = 'Your last ' + whatB + ' was **' + inr(rowsB[0].a) + '**, paid to ' + rowsB[0].m + ' ' + at(rowsB[0].d, today) + '.' + (rowsB.length >= 3 ? ' Over the last 12 months they ran about ' + inr(median(rowsB.map(function (t) { return t.a; }))) + ' each.' : '');
        } else if (rowsB.length) {
          o.text = 'kosh can’t see what’s due on your ' + rowsB[0].m + ' bill now: no bill from it has come in the mail kosh reads. The last you paid ' + rowsB[0].m + ' was **' + inr(rowsB[0].a) + '** ' + at(rowsB[0].d, today) + '.';
        } else o.text = 'kosh can’t see ' + (/^[aeiou]/i.test(whatB) ? 'an ' : 'a ') + whatB + ' yet: no bill or payment for it is in the mail kosh reads.';
        o.rows = idsOf(rowsB);
        step('upcoming', 'The ' + whatB, agB.length + ' on the calendar; ' + rowsB.length + ' paid in the last 12 months.');
        o.suggest = ['What’s due this week?', 'What bills are due this month?'];
        break;
      }
      case 'owing': {
        var nmO = payeeName(f.merchant, ctx);
        var agO = (ctx.agenda || []).filter(function (x) { return x.kind !== 'in' && !x.booked && x.date >= today && has(x.name, f.merchant); }).sort(function (a, b) { return a.date.localeCompare(b.date); });
        var rowsO = paidRows(ctx, Object.assign({}, f, { category: undefined }), { from: addDays(today, -364), to: today }).sort(byDate);
        o.text = agO.length ? '**' + inr(agO[0].amt) + '** is due to ' + nmO + ' ' + at(agO[0].date, today) + ', from its mail.'
          : 'kosh can’t see what’s still to pay on ' + nmO + ': what you owe it isn’t in the mail kosh reads.' + (rowsO.length ? ' What it has seen: you last paid **' + inr(rowsO[0].a) + '** ' + at(rowsO[0].d, today) + (rowsO.length > 1 ? ', ' + inr(sumA(rowsO)) + ' across ' + n_(rowsO.length, 'payment') + ' in the last 12 months' : '') + '.' : '');
        o.rows = idsOf(rowsO);
        o.suggest = ['What’s due this week?', 'How much have I paid ' + payeeShort(f.merchant, ctx) + ' this year?'];
        break;
      }
      case 'tool': {
        var rt = runTool(f.tool, f.args || {}, ctx);
        o.text = rt.text.replace(/\b(20\d\d-\d\d-\d\d)\b/g, function (x) { return on(x, today); });
        o.rows = rt.rows || [];
        if (rt.data && rt.data.proposal) o.proposals = [rt.data.proposal];
        step(f.tool, f.tool, rt.text);
        break;
      }
      case 'hello':
        o.text = 'Hi! Ask me anything about your money: what you spent and where, who you paid, what’s due, what came in.';
        o.suggest = ['Who did I pay the most this month?', 'How much have I spent this month?', 'What’s due this week?'];
        o.frame = null;
        break;
      case 'thanks':
        o.text = 'Any time.';
        o.suggest = ['What changed in my spending this month?', 'What’s due this week?'];
        o.frame = null;
        break;
      case 'help':
        o.text = 'I work things out from your own ledger, on this phone. For example:\n- How much did I spend on food last month?\n- Who did I pay the most this month?\n- When did I last pay the electricity bill?\n- What were my biggest payments in September?\n- What’s due this week, and can I cover it?\n- How much do I spend a month on groceries, usually?\n\nShort follow-ups work too: “and last month?”, “show them”, “by category”, “why?”.';
        o.suggest = ['Who did I pay the most this month?', 'How much did I spend on food last month?'];
        o.frame = null;
        break;
    }
    if (/^(?:total|list|compare|biggest|rank)$/.test(f.act || '')) fxNote(f, ctx, o, span, today);
    return o;
  }
  /* GUARDRAIL spending asked in another currency or a place abroad ("on my HDFC card in dollars", "in Dubai last
     month"): the charges in that currency on Indian cards, in that currency (their rupees are kosh's estimate until
     the statement says), and the accounts and cards held abroad in it, which no rupee total counts, said as such */
  var CCY_WORDS = [['USD', /\b(?:dollars?|usd|us\$)\b|\$/, /\b(?:usa|us|america|new york|california)\b/], ['AED', /\b(?:dirhams?|aed)\b/, /\b(?:dubai|abu dhabi|sharjah|uae|emirates)\b/],
    ['GBP', /\b(?:pounds?|gbp)\b/, /\b(?:uk|london|england|britain)\b/], ['EUR', /\b(?:euros?|eur)\b/, /\b(?:europe|paris|germany|france|italy|spain)\b/], ['SGD', /\bsgd\b|\bsingapore dollars?\b/, /\bsingapore\b/]];
  function fxNote(f, ctx, o, span, today) {
    var q = norm(f.q || ''), hit = null, byPlace = false;
    CCY_WORDS.some(function (c) { if (c[1].test(q)) { hit = c[0]; return true; } if (c[2].test(q)) { hit = c[0]; byPlace = true; return true; } return false; });
    if (!hit) return;
    var sp = span || { from: addDays(today, -364), to: today }, w = span ? spanWords(span, today) : 'in the last 12 months';
    var rows = (ctx.tx || []).filter(function (t) { return t.fx && String(t.fx).indexOf(hit + ' ') === 0 && t.k === 'out' && within2(t, sp, today) && (!f.card || lc(t.card || '').indexOf(lc(f.card).replace(/ (?:cc|a\/c)$/, '')) >= 0); });
    var abroad = (ctx.accounts || []).concat(ctx.cards || []).filter(function (a) { return a.ccy === hit; });
    var add = [];
    if (rows.length) {
      var fxSum = sum(rows, function (t) { return +String(t.fx).split(' ')[1] || 0; });
      add.push('In ' + hit + ': **' + hit + ' ' + Number(fxSum.toFixed(2)).toLocaleString('en-IN') + '** across ' + n_(rows.length, 'charge') + ' ' + w + ', about ' + inr(sumA(rows)) + ' in rupees (kosh’s estimate until the statement says).');
      o.rows = (o.rows || []).concat(idsOf(rows));
    } else if (!byPlace) add.push('kosh hasn’t seen a charge in ' + hit + ' ' + w + ' on your Indian cards.');
    if (abroad.length) add.push('Your ' + joinAnd(abroad.map(function (a) { return a.bank + ' ' + (a.balance !== undefined || a.fbal !== undefined ? 'account' : 'card') + ' ••' + a.last; })) + ' ' + (abroad.length === 1 ? 'is' : 'are') + ' in ' + hit + ': kosh counts rupees, so what you spend from ' + (abroad.length === 1 ? 'it' : 'them') + ' isn’t in these figures.');
    if (add.length) o.text = (o.text ? o.text + '\n\n' : '') + add.join(' ');
  }

  /* what the phone can't see, said plainly and once: no figure stands in for it */
  function topicText(t, ctx, f) {
    var today = ctx.today || '';
    if (t === 'kin') return 'kosh doesn’t know who your ' + ((f && f.kin) || 'family member') + ' is yet. Add them in Settings › Household, and kosh tells their spending from yours.';
    if (t === 'advtax') {
      // the four instalments the Income Tax Act sets (15 June, 15 September, 15 December, 15 March)
      var y = +today.slice(0, 4), days = [y + '-03-15', y + '-06-15', y + '-09-15', y + '-12-15', (y + 1) + '-03-15'].filter(function (d) { return d >= today; });
      return 'Advance tax is paid in four instalments: by 15 June, 15 September, 15 December and 15 March. The next is **' + dShort(days[0]) + (days[0].slice(0, 4) !== today.slice(0, 4) ? ' ' + days[0].slice(0, 4) : '') + '**. kosh can’t see how much you owe: it doesn’t read your tax filings.';
    }
    return {
      tax: 'kosh can’t see your tax sections (80C, 80D, HRA and the like) yet: it doesn’t read your tax declarations or returns.',
      score: 'kosh can’t see your credit score: it isn’t in the mail kosh reads.',
      goals: 'kosh can’t see your goals in this phone’s answers yet: Plan › Goals has them.',
      trials: 'kosh can’t see free trials in this phone’s answers yet: Plan › Subscriptions has them.',
      parcel: 'kosh can’t see where a parcel is in this phone’s answers yet: it doesn’t follow deliveries or return pickups here.',
    }[t] || 'kosh can’t see that yet.';
  }
  var TOPIC_NEAR = {
    tax: ['How much did I invest this financial year?', 'How much tax did I pay this year?', 'My insurance policies'],
    advtax: ['How much tax did I pay this year?', 'What’s due this month?'],
    score: ['What’s due this week?', 'How much is my credit card bill?'],
  };
  /* the questions to offer when one couldn't be placed: near the words asked, else the common ones */
  function nearQuestions(f, ctx) {
    if (f && f.decide) return ['How much did I save last month?', 'What are my investments worth?', 'What repeats every month?'];
    var who = f && f.merchant ? payeeShort(f.merchant, ctx) : '';
    if (who) return [(isPerson(f.merchant, ctx) ? 'How much have I paid ' : 'How much have I spent at ') + who + ' this year?', 'When did I last pay ' + who + '?', 'How many times did I pay ' + who + ' this month?'];
    if (f && f.category) return ['How much did I spend on ' + f.category + ' this month?', 'How much do I usually spend on ' + f.category + ' a month?', 'Show my ' + f.category + ' payments'];
    return ['Who did I pay the most this month?', 'How much have I spent this month?', 'What were my biggest payments last month?', 'What’s due this week?'];
  }

  /* one question, start to finish, on the phone: { understood, text, rows, steps, suggest, frame } */
  function phoneAnswer(q, ctx, prev, opts) {
    opts = opts || {};
    var f = understand(q, ctx, prev);
    if (f.act === 'clarify') {
      if (prev && prev.act && prev.act !== 'none') {
        var o1 = { understood: true, text: 'Which part? I can show the payments behind it, compare it with last month, or split it another way.', rows: [], steps: [], frame: prev,
          suggest: ['Show these payments', 'Compare with last month', prev.by === 'category' || prev.category ? 'Who did I pay the most?' : 'Split by category'] };
        return o1;
      }
      return { understood: true, text: prev && prev.act === 'none' ? 'Sorry, I didn’t follow “' + String(prev.q || '').slice(0, 60) + '”. Did you mean one of these?' : 'Ask me about your money: what you spent, who you paid, what’s due, what came in.',
        rows: [], steps: [], frame: prev && prev.act === 'none' ? prev : null, suggest: nearQuestions(prev, ctx) };
    }
    // the note about Claude is said once in a conversation, not under every answer it couldn't give
    var noted = !!(prev && prev.noted);
    if (f.act === 'none') {
      var again = prev && prev.act === 'none' && !f.topic;
      var text = f.topic ? topicText(f.topic, ctx, f) : again ? 'Still not with you, sorry. Try one of these, or put it another way.'
        : f.decide ? 'That’s a judgement call, and on this phone I only work out figures from your ledger. These might help you weigh it:'
        : 'I couldn’t place “' + String(q).trim().slice(0, 80) + '” in your ledger. Here’s what I can work out:' ;
      if (!again && !opts.cloud && !f.topic && !noted) { text += '\n\n_For questions like this, add an AI key in Settings › Ask kosh._'; noted = true; }
      if (noted) f.noted = true;
      return { understood: !!f.topic, text: text, rows: [], steps: [], frame: f, suggest: f.topic ? TOPIC_NEAR[f.topic] || nearQuestions({}, ctx) : nearQuestions(f, ctx) };
    }
    var o = answerOf(f, ctx, prev && prev.act);
    o.understood = true;
    // the frame goes back with the answer, for the follow-up; kept small
    if (o.frame) { var fr = {}; Object.keys(o.frame).forEach(function (k) { if (k.indexOf('__') !== 0 && o.frame[k] !== undefined && o.frame[k] !== '') fr[k] = o.frame[k]; }); if (noted) fr.noted = true; o.frame = fr; }
    o.suggest = (o.suggest || []).filter(Boolean).slice(0, 3);
    return o;
  }

  var api = {
    watch: watch, runTool: runTool, calc: calc, agentCheck: agentCheck, agentSystem: agentSystem, applyRule: applyRule, ruleCheck: ruleCheck, rulePrompt: rulePrompt, pwBuild: pwBuild, pwGuess: pwGuess, pwCandidates: pwCandidates, pwFormats: PW_FORMATS, route: route, periodOf: periodOf, understand: understand, phoneAnswer: phoneAnswer, TOOLS: TOOLS, RULE_TOOL: RULE_TOOL,
    watchJSON: function (snap, prof) { return JSON.stringify(watch(JSON.parse(snap || '{}'), JSON.parse(prof || '{}'))); },
    agentToolsJSON: function () { return JSON.stringify(TOOLS); },
    agentToolJSON: function (name, args, ctx) { var o; try { o = runTool(name, JSON.parse(args || '{}'), JSON.parse(ctx || '{}')); } catch (e) { o = { text: 'That lookup failed: ' + (e && e.message || e), rows: [], data: {} }; } return JSON.stringify(o); },
    agentCheckJSON: function (answer, texts, q) { return JSON.stringify(agentCheck(answer || '', JSON.parse(texts || '[]'), q || '')); },
    agentSystemText: function (today, name, mode) { return agentSystem(today || '', name || '', mode || ''); },
    setLearnedRulesJSON: function (j) { try { var a = JSON.parse(j || '[]'); LEARNED = Array.isArray(a) ? a.filter(function (r) { return r && r.domain && r.amount; }) : []; } catch (e) { LEARNED = []; } return String(LEARNED.length); },
    ruleCheckJSON: function (rule, samples, known) { return JSON.stringify(ruleCheck(JSON.parse(rule || '{}'), JSON.parse(samples || '[]'), JSON.parse(known || '[]'))); },
    rulePromptText: function (samples, opts) { return rulePrompt(JSON.parse(samples || '[]'), opts ? JSON.parse(opts) : {}); },
    ruleToolJSON: function () { return JSON.stringify(RULE_TOOL); },
    // (for the diagnostics export: the pieces each way of the sender's rule is made of, by name only)
    pwPartsJSON: function (hint) { var R = L.pwRecipe ? L.pwRecipe(hint || '') : { parts: [] }; return JSON.stringify((R.alts || [R]).map(function (a) { return a.parts.map(function (p) { return p.label + (p.note ? ' (' + p.note + ')' : ''); }); })); },
    pwBuildJSON: function (hint, profile, ctx) { return JSON.stringify(pwBuild(hint || '', JSON.parse(profile || '{}'), JSON.parse(ctx || '{}'))); },
    agentRouteJSON: function (q, ctx) { var r = null; try { r = route(q || '', JSON.parse(ctx || '{}')); } catch (e) { r = null; } return JSON.stringify(r); },
    pwGuessJSON: function (profile, ctx) { return JSON.stringify(pwGuess(JSON.parse(profile || '{}'), JSON.parse(ctx || '{}'))); },
    pwCandidatesJSON: function (hint, profiles, ctx, cap) { return JSON.stringify(pwCandidates(hint || '', JSON.parse(profiles || '[]'), JSON.parse(ctx || '{}'), +cap || 0)); },
    agentPhoneJSON: function (q, ctx, prev, opts) {
      var o;
      try { o = phoneAnswer(q || '', JSON.parse(ctx || '{}'), prev ? JSON.parse(prev) : null, JSON.parse(opts || '{}')); }
      catch (e) { o = { understood: false, text: '', error: String(e && e.message || e) }; }
      return JSON.stringify(o);
    },
  };
  /* the live view (viewplan.js) draws what these answers say: the rows a question is about, the month's rule for money
     back and the words for a stretch of days, lent as they are so a figure is worked out in one place */
  api.figures = { spentRows: spentRows, spentSum: spentSum, paidRows: paidRows, backFor: backFor, lessBack: lessBack, groupBy: groupBy, fits: fits, within2: within2,
    putIn: putIn, takenOut: takenOut, loanDue: loanDue, dueFilter: dueFilter, spanWords: spanWords, beforeWords: beforeWords, before: before, about: about,
    payeeName: payeeName, isPerson: isPerson, personWord: personWord, firstDay: firstDay, monthEnd: monthEnd, monthWord: monthWord, on: on, inr: inr, lakh: lakh,
    addDays: addDays, daysBetween: daysBetween, median: median };
  for (var k in api) if (Object.prototype.hasOwnProperty.call(api, k) && /JSON$|Text$/.test(k)) E[k] = api[k];
  return api;
})(typeof KoshEngine !== 'undefined' ? KoshEngine : require('./engine.js'));
if (typeof module !== 'undefined' && module.exports) module.exports = KoshAgent;
