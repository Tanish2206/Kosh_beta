import Foundation

// MARK: - One inbox's pace with Gmail, as plain arithmetic
//
// What each Gmail call costs, Google's allowance for an inbox, the ceiling kosh keeps under it, and one inbox's bucket:
// how it refills, how it climbs while Google says yes and steps down when it says "too many". No clock of its own and
// nothing but Foundation, so engine-test/gmail-pace.swift compiles it alone with swiftc (the Mac) and runs it on
// made-up hours. QuotaGate (QuotaGate.swift) keeps one per inbox and waits on it.

/// One inbox's pace, as plain arithmetic on the time it is told (screen-free, for engine-test/gmail-pace.swift)
struct QuotaPace {
    /// Google's allowance for one inbox in a project made on or after 1 May 2026, units a minute
    static let published: Double = 6_000
    /// the most a project kept on its older allowance may say (Google's earlier per-user figure, 250 units a second)
    static let older: Double = 15_000
    /// what a bundled figure may be: none (or nonsense) is today's published one
    static func limit(bundled: Double?) -> Double {
        guard let b = bundled, b.isFinite, b >= 1_000 else { return published }
        return Swift.min(b, older)
    }
    /// the bucket holds at most this many seconds' worth (and always one whole email)
    static let burst: Double = 5
    /// what is kept back from the allowance, for Google's minute not starting when kosh's does
    static let margin: Double = 0.05
    /// the steady pace that keeps any sixty seconds under the allowance: a full bucket plus a minute's refill
    static func ceiling(_ limit: Double) -> Double { limit * (1 - margin) * 60 / (60 + burst) }
    /// where a new inbox starts: a little under the ceiling, to climb from while Google says yes
    static func start(_ limit: Double) -> Double { ceiling(limit) * 0.9 }
    static let floor: Double = 1_500
    /// the dearest request kosh makes: one whole email
    static let fullMail: Double = 60

    /// Google's cost of each call kosh makes, by its path under users/me/ (the quota page above)
    static func cost(_ path: String) -> Double {
        if path.hasPrefix("history") { return 2 }            // history.list
        if path.hasPrefix("profile") { return 1 }            // getProfile
        if path.hasPrefix("messages?") { return 5 }          // messages.list
        if path.hasPrefix("messages/") {
            if path.contains("/attachments/") { return 20 }  // messages.attachments.get
            // messages.get: 20 for headers only (metadata, minimal), 60 for the whole email (full, the default; raw; html)
            if path.contains("format=metadata") || path.contains("format=minimal") { return 20 }
            return fullMail
        }
        // a call this table doesn't know: counted as the dearest, so the pace stays under
        return fullMail
    }

    /// Google's "too many": 429, or 403 with rateLimitExceeded / userRateLimitExceeded. (403 dailyLimitExceeded is the
    /// project's day used up: waiting a minute doesn't help, so it isn't one; the read stops and keeps its plan.)
    static func tooMany(_ code: Int, _ body: String) -> Bool {
        code == 429 || (code == 403 && (body.contains("rateLimitExceeded") || body.contains("userRateLimitExceeded")))
    }

    var rate: Double          // units a minute
    var tokens: Double
    var at: Date
    var calmSince: Date       // since the last "too many", or the last step up
    var waited = false        // kosh waited on the bucket since then: worth trying a little faster
    var pausedUntil: Date = .distantPast
    var strikes = 0           // "too many" one after another, each pausing twice as long
    let top: Double           // the ceiling for this inbox's allowance

    init(rate: Double, now: Date, limit: Double) {
        top = QuotaPace.ceiling(limit)
        self.rate = Swift.min(top, Swift.max(QuotaPace.floor, rate))
        tokens = 0
        at = now
        calmSince = now
        tokens = cap
    }

    /// at most `burst` seconds' worth at once (and always room for one whole email)
    var cap: Double { Swift.max(QuotaPace.fullMail, rate * QuotaPace.burst / 60) }

    /// Spend `units` now if the bucket holds them: 0 when spent, else the seconds to wait before asking again. `stepped`
    /// says the pace went up (to be kept for the next launch).
    mutating func take(_ units: Double, now: Date) -> (wait: Double, stepped: Bool) {
        if pausedUntil > now { return (pausedUntil.timeIntervalSince(now), false) }
        tokens = Swift.min(cap, tokens + Swift.max(0, now.timeIntervalSince(at)) * rate / 60)
        at = now
        let need: Double = Swift.min(units, cap)
        if tokens >= need {
            tokens -= units
            // Google has said yes for a while and kosh was waiting on the bucket: a little faster, never past the ceiling
            if waited && now.timeIntervalSince(calmSince) > 30 && rate < top {
                rate = Swift.min(top, rate * 1.15)
                calmSince = now
                waited = false
                strikes = 0
                return (0, true)
            }
            return (0, false)
        }
        waited = true
        return (Swift.max(0.05, (need - tokens) / (rate / 60)), false)
    }

    /// Google said too many: slower, and a pause of at least what it asked (Retry-After), else 2, 4, 8… up to 64 seconds
    /// for "too many" after "too many", as Google asks (start at a second or more, double each time)
    mutating func throttled(retryAfter: Double?, now: Date) {
        // several requests in flight hear "too many" together: the first steps down and pauses; the rest arrive while it
        // pauses and change nothing more. One after the pause is another "too many": a longer pause
        if now >= pausedUntil {
            rate = Swift.max(QuotaPace.floor, rate * 0.6)
            strikes = now.timeIntervalSince(calmSince) < 90 ? strikes + 1 : 1
            calmSince = now
        }
        tokens = 0
        at = now
        waited = false
        let backoff: Double = Swift.min(64, pow(2, Double(Swift.max(1, Swift.min(strikes, 6)))))
        let asked: Double = retryAfter.map { Swift.min(120, Swift.max(1, $0)) } ?? 0
        pausedUntil = Swift.max(pausedUntil, now.addingTimeInterval(Swift.max(backoff, asked)))
    }

    /// spent outside the bucket (the background downloads): later requests wait for it
    mutating func spend(_ units: Double) { tokens -= units }
}
