import SwiftUI
import CoreImage.CIFilterBuiltins

// MARK: - The drawings Chapters is made of
//
// Line drawings kept as SVG path strings (one coordinate box each) and drawn as SwiftUI shapes, so a stamp
// or a tile is crisp at any size and can take any ink. A stamp is one ink in fine lines: an outline (hexagon,
// circle, arch, shield…), the place in its own script, a landmark, and a small line at the foot. A tile is the
// quieter cousin: a pale square with a drawing standing on a ground line.

// MARK: SVG path strings → Path

enum SVGPath {
    private static var cache: [String: Path] = [:]

    static func path(_ d: String) -> Path {
        if let p = cache[d] { return p }
        let p = parse(d)
        cache[d] = p
        return p
    }

    enum Token { case cmd(Character), num(CGFloat) }

    static func tokens(_ d: String) -> [Token] {
        var out: [Token] = []
        var buf: String = ""
        func flush() {
            if !buf.isEmpty, let v = Double(buf) { out.append(.num(CGFloat(v))) }
            buf = ""
        }
        for ch in d {
            if ch.isLetter && ch != "e" && ch != "E" {
                flush()
                out.append(.cmd(ch))
            } else if ch == "-" {
                if let last = buf.last, last == "e" || last == "E" { buf.append(ch) } else { flush(); buf.append(ch) }
            } else if ch == "." {
                if buf.contains(".") { flush() }
                buf.append(ch)
            } else if ch.isNumber || ch == "e" || ch == "E" {
                buf.append(ch)
            } else {
                flush()
            }
        }
        flush()
        return out
    }

    static func parse(_ d: String) -> Path {
        let t: [Token] = tokens(d)
        var p = Path()
        var i: Int = 0
        var cmd: Character = "M"
        var cur = CGPoint.zero
        var start = CGPoint.zero
        var lastC: CGPoint? = nil
        var lastQ: CGPoint? = nil
        func isNum(_ k: Int) -> Bool {
            if k < t.count, case .num = t[k] { return true }
            return false
        }
        func n() -> CGFloat {
            if i < t.count, case .num(let v) = t[i] { i += 1; return v }
            i += 1
            return 0
        }
        while i < t.count {
            if case .cmd(let c) = t[i] {
                cmd = c
                i += 1
                if c == "Z" || c == "z" {
                    p.closeSubpath()
                    cur = start
                    lastC = nil
                    lastQ = nil
                    continue
                }
            }
            if !isNum(i) { continue }
            let rel: Bool = cmd.isLowercase
            let o: CGPoint = rel ? cur : .zero
            let up: String = String(cmd).uppercased()
            switch up {
            case "M":
                let x = n(), y = n()
                cur = CGPoint(x: o.x + x, y: o.y + y)
                p.move(to: cur)
                start = cur
                cmd = rel ? "l" : "L"
                lastC = nil; lastQ = nil
            case "L":
                let x = n(), y = n()
                cur = CGPoint(x: o.x + x, y: o.y + y)
                p.addLine(to: cur)
                lastC = nil; lastQ = nil
            case "H":
                let x = n()
                cur = CGPoint(x: (rel ? cur.x : 0) + x, y: cur.y)
                p.addLine(to: cur)
                lastC = nil; lastQ = nil
            case "V":
                let y = n()
                cur = CGPoint(x: cur.x, y: (rel ? cur.y : 0) + y)
                p.addLine(to: cur)
                lastC = nil; lastQ = nil
            case "C":
                let x1 = n(), y1 = n(), x2 = n(), y2 = n(), x = n(), y = n()
                let c1 = CGPoint(x: o.x + x1, y: o.y + y1)
                let c2 = CGPoint(x: o.x + x2, y: o.y + y2)
                cur = CGPoint(x: o.x + x, y: o.y + y)
                p.addCurve(to: cur, control1: c1, control2: c2)
                lastC = c2; lastQ = nil
            case "S":
                let x2 = n(), y2 = n(), x = n(), y = n()
                var c1: CGPoint = cur
                if let lc = lastC { c1 = CGPoint(x: 2 * cur.x - lc.x, y: 2 * cur.y - lc.y) }
                let c2 = CGPoint(x: o.x + x2, y: o.y + y2)
                cur = CGPoint(x: o.x + x, y: o.y + y)
                p.addCurve(to: cur, control1: c1, control2: c2)
                lastC = c2; lastQ = nil
            case "Q":
                let x1 = n(), y1 = n(), x = n(), y = n()
                let c = CGPoint(x: o.x + x1, y: o.y + y1)
                cur = CGPoint(x: o.x + x, y: o.y + y)
                p.addQuadCurve(to: cur, control: c)
                lastQ = c; lastC = nil
            case "T":
                let x = n(), y = n()
                var c: CGPoint = cur
                if let lq = lastQ { c = CGPoint(x: 2 * cur.x - lq.x, y: 2 * cur.y - lq.y) }
                cur = CGPoint(x: o.x + x, y: o.y + y)
                p.addQuadCurve(to: cur, control: c)
                lastQ = c; lastC = nil
            case "A":
                let rx = n(), ry = n(), rot = n(), large = n(), sweep = n(), x = n(), y = n()
                let end = CGPoint(x: o.x + x, y: o.y + y)
                arc(&p, from: cur, rx: rx, ry: ry, degrees: rot, large: large != 0, sweep: sweep != 0, to: end)
                cur = end
                lastC = nil; lastQ = nil
            default:
                i += 1
            }
        }
        return p
    }

    /// an SVG arc as cubic curves (the endpoint form turned to centre form, then quarter turns at most)
    static func arc(_ p: inout Path, from p0: CGPoint, rx rxIn: CGFloat, ry ryIn: CGFloat, degrees: CGFloat, large: Bool, sweep: Bool, to p1: CGPoint) {
        if p0 == p1 { return }
        var rx: CGFloat = abs(rxIn)
        var ry: CGFloat = abs(ryIn)
        if rx == 0 || ry == 0 { p.addLine(to: p1); return }
        let phi: CGFloat = degrees * .pi / 180
        let cosP: CGFloat = cos(phi)
        let sinP: CGFloat = sin(phi)
        let dx: CGFloat = (p0.x - p1.x) / 2
        let dy: CGFloat = (p0.y - p1.y) / 2
        let x1: CGFloat = cosP * dx + sinP * dy
        let y1: CGFloat = -sinP * dx + cosP * dy
        let lam: CGFloat = (x1 * x1) / (rx * rx) + (y1 * y1) / (ry * ry)
        if lam > 1 { let s: CGFloat = sqrt(lam); rx *= s; ry *= s }
        let num: CGFloat = rx * rx * ry * ry - rx * rx * y1 * y1 - ry * ry * x1 * x1
        let den: CGFloat = rx * rx * y1 * y1 + ry * ry * x1 * x1
        let sign: CGFloat = large == sweep ? -1 : 1
        let coef: CGFloat = den == 0 ? 0 : sign * sqrt(max(0, num / den))
        let cxp: CGFloat = coef * (rx * y1 / ry)
        let cyp: CGFloat = coef * (-ry * x1 / rx)
        let cx: CGFloat = cosP * cxp - sinP * cyp + (p0.x + p1.x) / 2
        let cy: CGFloat = sinP * cxp + cosP * cyp + (p0.y + p1.y) / 2
        func angle(_ ux: CGFloat, _ uy: CGFloat, _ vx: CGFloat, _ vy: CGFloat) -> CGFloat {
            atan2(ux * vy - uy * vx, ux * vx + uy * vy)
        }
        let ux: CGFloat = (x1 - cxp) / rx
        let uy: CGFloat = (y1 - cyp) / ry
        let vx: CGFloat = (-x1 - cxp) / rx
        let vy: CGFloat = (-y1 - cyp) / ry
        let theta: CGFloat = angle(1, 0, ux, uy)
        var delta: CGFloat = angle(ux, uy, vx, vy)
        if !sweep && delta > 0 { delta -= 2 * .pi }
        if sweep && delta < 0 { delta += 2 * .pi }
        let parts: Int = max(1, Int(ceil(abs(delta) / (.pi / 2))))
        let step: CGFloat = delta / CGFloat(parts)
        let k: CGFloat = 4.0 / 3.0 * tan(step / 4)
        func point(_ a: CGFloat) -> CGPoint {
            CGPoint(x: cx + rx * cosP * cos(a) - ry * sinP * sin(a), y: cy + rx * sinP * cos(a) + ry * cosP * sin(a))
        }
        func slope(_ a: CGFloat) -> CGPoint {
            CGPoint(x: -rx * cosP * sin(a) - ry * sinP * cos(a), y: -rx * sinP * sin(a) + ry * cosP * cos(a))
        }
        var a: CGFloat = theta
        for _ in 0..<parts {
            let b: CGFloat = a + step
            let pa: CGPoint = point(a)
            let pb: CGPoint = point(b)
            let da: CGPoint = slope(a)
            let db: CGPoint = slope(b)
            let c1 = CGPoint(x: pa.x + k * da.x, y: pa.y + k * da.y)
            let c2 = CGPoint(x: pb.x - k * db.x, y: pb.y - k * db.y)
            p.addCurve(to: pb, control1: c1, control2: c2)
            a = b
        }
    }
}

/// a path string drawn to fit: `box` is the drawing's width in its own units
struct SVGShape: Shape {
    let d: String
    var box: CGFloat = 40
    func path(in rect: CGRect) -> Path {
        let s: CGFloat = rect.width / box
        return SVGPath.path(d).applying(CGAffineTransform(a: s, b: 0, c: 0, d: s, tx: rect.minX, ty: rect.minY))
    }
}

extension Color {
    /// a drawing's ink, lifted in dark mode so it still reads
    func ink(_ scheme: ColorScheme) -> Color { scheme == .dark ? self.mix(with: .white, by: 0.45) : self }
}

// MARK: stamps

struct StampOutline {
    let d: String
    let inner: String
    let ty: CGFloat
    let ay: CGFloat
    let fy: CGFloat
}

struct StampArt {
    let outline: StampOutline
    let script: String
    let art: String
    let foot: String
    let ink: Color
    let label: String
}

enum Stamps {
    static let hex = StampOutline(d: "M30 10h60l26 50-26 50H30L4 60z", inner: "", ty: 37, ay: 42, fy: 97)
    static let circle = StampOutline(d: "M60 5a55 55 0 1 1 0 110a55 55 0 1 1 0-110z", inner: "M60 13a47 47 0 1 1 0 94a47 47 0 1 1 0-94z", ty: 38, ay: 42, fy: 96)
    static let rrect = StampOutline(d: "M28 8h64a20 20 0 0 1 20 20v64a20 20 0 0 1-20 20H28a20 20 0 0 1-20-20V28A20 20 0 0 1 28 8z", inner: "", ty: 36, ay: 42, fy: 98)
    static let arch = StampOutline(d: "M10 113V58a50 50 0 0 1 100 0v55z", inner: "", ty: 46, ay: 50, fy: 104)
    static let shield = StampOutline(d: "M60 5l49 16v37c0 29-21 49-49 57C32 107 11 87 11 58V21z", inner: "", ty: 36, ay: 40, fy: 92)
    static let octagon = StampOutline(d: "M38 5h44l33 33v44l-33 33H38L5 82V38z", inner: "", ty: 37, ay: 42, fy: 98)
    static let scallop = StampOutline(d: scallopPath(), inner: "M60 16a44 44 0 1 1 0 88a44 44 0 1 1 0-88z", ty: 40, ay: 43, fy: 95)

    static func scallopPath() -> String {
        let cx: Double = 60, cy: Double = 60, r: Double = 52, rr: Double = 59
        let n: Int = 18
        var d: String = "M" + String(cx + r) + " " + String(cy) + " "
        for i in 1...n {
            let a: Double = Double(i) / Double(n) * 2 * .pi
            let m: Double = (Double(i) - 0.5) / Double(n) * 2 * .pi
            d += "Q" + f(cx + rr * cos(m)) + " " + f(cy + rr * sin(m)) + " " + f(cx + r * cos(a)) + " " + f(cy + r * sin(a)) + " "
        }
        return d + "Z"
    }
    private static func f(_ v: Double) -> String { String(format: "%.1f", v) }

    static let art: [String: String] = [
        "tower": "M20 2v6 M18 8h4 M18 8 12 38 M22 8 28 38 M16.5 18h7 M14.6 27h10.8 M8 38h24 M14.6 27 20 18l5.4 9",
        "pagoda": "M20 2v4 M11 10h18l-3-4H14z M13 10v4 M27 10v4 M9 18h22l-3-4H12z M12 18v5 M28 18v5 M7 27h26l-3-4H10z M11 27v9 M29 27v9 M17 36v-5h6v5 M5 36h30",
        "castle": "M6 38h28 M9 38V29h22v9 M11 29v-4h18v4 M9 25h22l-3-4H12z M14 21v-3h12v3 M12 18h16l-3-4H15z M17 14v-3h6v3 M16 11h8l-2-3h-4z M18 38v-4h4v4",
        "fuji": "M3 34 15 12c2-3 8-3 10 0l12 22z M15 12l3 4 2-2 2 2 3-4 M30 8a3 3 0 1 0 6 0a3 3 0 1 0-6 0 M3 34h34",
        "gate": "M4 38h32 M7 38V18l4-6V6 M7 18h8 M15 38V18l-4-6 M33 38V18l-4-6V6 M33 18h-8 M25 38V18l4-6 M9 24h4 M9 30h4 M27 24h4 M27 30h4",
        "bridge": "M2 26h36 M7 26V10 M33 26V10 M7 10c4 11 22 11 26 0 M12 17v9 M16 19.5v6.5 M20 20v6 M24 19.5v6.5 M28 17v9 M2 33c3-2 6-2 9 0s6 2 9 0 6-2 9 0 6 2 9 0",
        "mountains": "M2 34 14 12l6 9 5-7 13 20z M14 12l3 5 2-2 M27 16l-2 3 3 1 M2 34h36",
        "temple": "M20 2v4 M14 13c0-4 3-7 6-7s6 3 6 7 M12 13h16 M13 13v8 M27 13v8 M10 21h20 M9 21v15 M31 21v15 M17 36v-7a3 3 0 0 1 6 0v7 M5 36h30",
        "skyline": "M3 37h34 M5 37V21h7v16 M12 37V11h8v26 M20 37V16h6v21 M26 37V24h9v13 M14.5 15h3 M14.5 20h3 M14.5 25h3 M22 21h2 M22 26h2 M7.5 25h2 M7.5 30h2 M29 28h3 M29 32h3",
        "house": "M4 20 20 6l16 14 M8 17v19h24V17 M16 36v-9h8v9 M2 36h36",
        "palace": "M4 37h32 M7 37V20h26v17 M7 20c0-5 4-8 8-8 M33 20c0-5-4-8-8-8 M15 12c0-4 2-6 5-9 3 3 5 5 5 9z M20 3V1 M11 26v5 M17 26v5 M23 26v5 M29 26v5",
        "mandap": "M4 37h32 M7 37V16 M33 37V16 M4 16h32 M6 16c0-5 6-9 14-11 8 2 14 6 14 11 M20 5V2 M13 27a3.5 3.5 0 1 0 7 0a3.5 3.5 0 1 0-7 0 M20 27a3.5 3.5 0 1 0 7 0a3.5 3.5 0 1 0-7 0",
        "diya": "M5 23c2 7 28 7 30 0z M20 20c-3-3-3-7 0-12 3 5 3 9 0 12z M14 35h12 M20 30v5 M9 13 7 11 M31 13l2-2 M20 5V2",
        "moon": "M23 5a14 14 0 1 0 12 20A12 12 0 0 1 23 5z M32 4v6 M29 7h6",
        "cap": "M38 15 20 7 2 15l18 8 18-8z M10 19v8c5 5 15 5 20 0v-8 M38 15v10",
        "pan": "M4 20h24v2a10 10 0 0 1-10 10h-4A10 10 0 0 1 4 22z M28 21h9 M10 14c1-2-1-3 0-5 M16 14c1-2-1-3 0-5 M22 14c1-2-1-3 0-5",
        "car": "M4 28v-7l5-9h22l5 9v7z M4 21h32 M7 28v4h5v-4 M28 28v4h5v-4 M9 24.5h3 M28 24.5h3",
        "award": "M10 14a10 10 0 1 0 20 0a10 10 0 1 0-20 0 M15 23l-3 14 8-4 8 4-3-14 M16 14l3 3 5-6",
        "bars": "M6 34v-8 M14 34V18 M22 34v-11 M30 34V8 M3 34h34 M26 12l4-4 4 4",
        "burst": "M20 3v6 M20 31v6 M3 20h6 M31 20h6 M8 8l4 4 M28 28l4 4 M8 32l4-4 M28 12l4-4 M20 14a6 6 0 1 0 0 12a6 6 0 1 0 0-12",
        "lotus": "M20 34c-8 0-15-5-17-13 6 0 12 2 17 8 5-6 11-8 17-8-2 8-9 13-17 13z M20 28c-4-6-4-13 0-20 4 7 4 14 0 20z",
        "envelope": "M4 10h32v22H4z M4 10l16 12 16-12",
        "star": "M20 4l4.5 9.5 10.5 1.3-7.7 7.2 2 10.4L20 27.3l-9.3 5.1 2-10.4-7.7-7.2 10.5-1.3z"
    ]

    static func make(_ o: StampOutline, _ script: String, _ art: String, _ foot: String, _ ink: String, _ label: String) -> StampArt {
        StampArt(outline: o, script: script, art: Self.art[art] ?? "", foot: foot, ink: Color(hex: ink), label: label)
    }

    static let all: [String: StampArt] = [
        "tokyo": make(circle, "東京", "tower", "JP · 2025", "#3730A3", "Tokyo"),
        "kyoto": make(hex, "京都", "pagoda", "JP · 2025", "#C2412D", "Kyoto"),
        "osaka": make(octagon, "大阪", "castle", "JP · 2025", "#B45309", "Osaka"),
        "japan": make(hex, "日本", "fuji", "JP · 2025", "#C2412D", "Japan"),
        "bali": make(arch, "BALI", "gate", "ID · 2026", "#0E7490", "Bali"),
        "rishikesh": make(circle, "ऋषिकेश", "bridge", "IN · 2026", "#0F766E", "Rishikesh"),
        "spiti": make(shield, "स्पीति", "mountains", "IN · 2026", "#4D7C0F", "Spiti"),
        "vaishno": make(arch, "वैष्णो देवी", "temple", "IN · 2025", "#B5502A", "Vaishno Devi"),
        "bengaluru": make(rrect, "ಬೆಂಗಳೂರು", "skyline", "WORK · 2026", "#374151", "Bengaluru"),
        "pune": make(hex, "पुणे", "house", "NEW CITY · 2026", "#4338CA", "Pune"),
        "jaipur": make(octagon, "जयपुर", "palace", "IN · 2026", "#BE185D", "Jaipur"),
        "wedding": make(circle, "शुभ विवाह", "mandap", "A & R · 2026", "#9F1D3A", "The wedding"),
        "diwali25": make(scallop, "दीपावली", "diya", "2025", "#C2410C", "Diwali 2025"),
        "diwali26": make(scallop, "दीपावली", "diya", "2026", "#C2410C", "Diwali 2026"),
        "home": make(rrect, "गृह प्रवेश", "house", "NEW HOME", "#7A3418", "New home"),
        "baby": make(circle, "WELCOME", "moon", "FIRST YEAR", "#4F46E5", "New baby"),
        "studies": make(shield, "MSc", "cap", "ADMITTED", "#166534", "Studies"),
        "kitchen": make(rrect, "KITCHEN", "pan", "RENOVATION", "#1D4ED8", "Kitchen"),
        "car": make(hex, "NEW CAR", "car", "AUG · 2025", "#334155", "New car"),
        "course": make(scallop, "PASSED", "award", "COURSE · 2026", "#3F6212", "Course"),
        "venture": make(octagon, "DAY ONE", "bars", "VENTURE", "#78350F", "Side venture"),
        "party": make(scallop, "60!", "burst", "CELEBRATION", "#A21CAF", "Celebration"),
        "ceremony": make(arch, "शुभ", "lotus", "CEREMONY", "#B91C1C", "Ceremony"),
        "guest": make(rrect, "RSVP", "envelope", "WEDDING GUEST", "#6D28D9", "Wedding guest"),
        "own": make(circle, "MY OWN", "star", "CHAPTER", "#3F3F46", "Your own")
    ]

    static func get(_ key: String) -> StampArt { all[key] ?? all["own"]! }

    /// a stamp for a chapter of your own: its family's outline, its name, its kind's drawing, its month
    static func custom(title: String, kind: String, fam: ChapterFam, from: String, ink: Color) -> StampArt {
        let outline: StampOutline
        switch fam {
        case .life: outline = arch
        case .occasion: outline = scallop
        case .project: outline = rrect
        default: outline = circle
        }
        let foot: String = from.isEmpty ? "CHAPTER" : Day.fmt(from, "MMM · yyyy").uppercased()
        return StampArt(outline: outline, script: shortName(title), art: Kinds.get(kind).d, foot: foot, ink: ink, label: title)
    }
    /// the word or two a stamp has room for
    static func shortName(_ title: String) -> String {
        var words: [String] = title.split(separator: " ").map(String.init)
        if words.count > 1, ["the", "a", "an", "our", "my"].contains(words[0].lowercased()) { words.removeFirst() }
        guard let first = words.first else { return "MY OWN" }
        var out: String = first
        if out.count <= 3 && words.count > 1 { out += " " + words[1] }
        if out.count > 11 { out = String(out.prefix(10)) + "." }
        return isLatin(out) ? out.uppercased() : out
    }
    static func isLatin(_ s: String) -> Bool { s.unicodeScalars.allSatisfy { $0.isASCII } }
    static func textSize(_ s: String) -> CGFloat {
        let latin: Bool = isLatin(s)
        if latin { return s.count > 6 ? 11.5 : 13.5 }
        return s.count > 6 ? 13 : 16
    }
}

/// one stamp: an outline, the place in its own script, a landmark, a line at the foot, in one ink
struct StampView: View {
    let art: StampArt
    var size: CGFloat = 140
    var rotation: Double = -5
    var dashed: Bool = false
    @Environment(\.colorScheme) private var scheme

    init(key: String, size: CGFloat = 140, rotation: Double = -5, dashed: Bool = false) {
        self.art = Stamps.get(key)
        self.size = size
        self.rotation = rotation
        self.dashed = dashed
    }
    init(art: StampArt, size: CGFloat = 140, rotation: Double = -5, dashed: Bool = false) {
        self.art = art
        self.size = size
        self.rotation = rotation
        self.dashed = dashed
    }

    var body: some View {
        let st: StampArt = art
        let s: CGFloat = size / 120
        let ink: Color = st.ink.ink(scheme)
        let latin: Bool = Stamps.isLatin(st.script)
        let tsize: CGFloat = Stamps.textSize(st.script)
        let dash: [CGFloat] = dashed ? [7 * s, 5 * s] : []
        ZStack(alignment: .topLeading) {
            SVGShape(d: st.outline.d, box: 120)
                .stroke(ink, style: StrokeStyle(lineWidth: 3.2 * s, lineJoin: .round, dash: dash))
            if !st.outline.inner.isEmpty {
                SVGShape(d: st.outline.inner, box: 120)
                    .stroke(ink.opacity(0.8), lineWidth: 1.1 * s)
            }
            Text(st.script)
                .font(.system(size: tsize * s, weight: .bold))
                .tracking((latin ? 1.6 : 0.3) * s)
                .foregroundStyle(ink)
                .lineLimit(1)
                .fixedSize()
                .position(x: 60 * s, y: (st.outline.ty - tsize * 0.36) * s)
            SVGShape(d: st.art, box: 40)
                .stroke(ink, style: StrokeStyle(lineWidth: 2.1 * s, lineCap: .round, lineJoin: .round))
                .frame(width: 40 * s, height: 40 * s)
                .position(x: 60 * s, y: (st.outline.ay + 20) * s)
            Text(st.foot)
                .font(.system(size: 7.6 * s, weight: .semibold, design: .monospaced))
                .tracking(1.3 * s)
                .foregroundStyle(ink)
                .lineLimit(1)
                .fixedSize()
                .position(x: 60 * s, y: (st.outline.fy - 2.8) * s)
        }
        .frame(width: size, height: size)
        .rotationEffect(.degrees(rotation))
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(st.label + " stamp")
    }
}

/// a stamp that lands: it comes down a little large and turned, and settles with a small bounce
struct LandingStamp: View {
    let art: StampArt
    var size: CGFloat = 140
    var rotation: Double = -5
    var dashed: Bool = false
    var delay: Double = 0
    @State private var landed = false
    @Environment(\.accessibilityReduceMotion) private var still

    init(key: String, size: CGFloat = 140, rotation: Double = -5, dashed: Bool = false, delay: Double = 0) {
        self.art = Stamps.get(key)
        self.size = size
        self.rotation = rotation
        self.dashed = dashed
        self.delay = delay
    }
    init(art: StampArt, size: CGFloat = 140, rotation: Double = -5, dashed: Bool = false, delay: Double = 0) {
        self.art = art
        self.size = size
        self.rotation = rotation
        self.dashed = dashed
        self.delay = delay
    }

    var body: some View {
        StampView(art: art, size: size, rotation: rotation, dashed: dashed)
            .scaleEffect(landed ? 1 : 1.32)
            .rotationEffect(.degrees(landed ? 0 : 10))
            .opacity(landed ? 1 : 0)
            .onAppear {
                if still { landed = true; return }
                withAnimation(Motion.pop.delay(delay)) { landed = true }
            }
            .sensoryFeedback(.impact(weight: .light, intensity: 0.6), trigger: landed) { _, now in now }
    }
}

// MARK: tiles

struct KindArt {
    let bg: Color
    let ink: Color
    let d: String
}

enum Kinds {
    static let ground: String = " M3 34.5h34 M7 37.5h26"
    static let waves: String = " M4 37.5c2-1.2 4-1.2 6 0s4 1.2 6 0 4-1.2 6 0 4 1.2 6 0 4-1.2 6 0"

    static func k(_ bg: String, _ ink: String, _ d: String) -> KindArt { KindArt(bg: Color(hex: bg), ink: Color(hex: ink), d: d) }

    static let all: [String: KindArt] = [
        "intl": k("#EEF3FB", "#2D4F8E", "M20 5.5a9.5 9.5 0 1 0 0 19a9.5 9.5 0 1 0 0-19 M10.5 15h19 M20 5.5c-3.6 3-3.6 16 0 19 M20 5.5c3.6 3 3.6 16 0 19 M12 10h16 M12 20h16 M8.6 16.5A11.6 11.6 0 0 0 27.4 25 M20 27v3.5 M14.5 30.5h11" + ground),
        "getaway": k("#EBF6F3", "#1E6A5B", "M16 33c0-7 1.5-12 5-16 M21 17c-4-3-9-3-12 0 M21 17c3-4 8-5 12-2 M21 17c-1-4-4-7-8-8 M21 17c2-3 5-5 9-5 M28 7a3 3 0 1 0 6 0a3 3 0 1 0-6 0 M4 33.5h32" + waves),
        "road": k("#F1F5EA", "#46662A", "M3 27 13 15l6 7 5-6 13 11 M16 37.5l3-10.5h2l3 10.5 M20 30v1.6 M20 34v1.6 M3 27h11 M26 27h11 M29 9a2.5 2.5 0 1 0 5 0a2.5 2.5 0 1 0-5 0"),
        "yatra": k("#FBF2EA", "#97481E", "M20 3v3 M14.5 12.5c0-4 2.5-6.5 5.5-6.5s5.5 2.5 5.5 6.5 M12.5 12.5h15 M13.5 12.5v7 M26.5 12.5v7 M9.5 19.5h21 M11 19.5v15 M29 19.5v15 M17.5 34.5v-6a2.5 2.5 0 0 1 5 0v6" + ground),
        "work": k("#F1F3F6", "#364052", "M4 34.5V21h7v13.5 M11 34.5V10h8v24.5 M19 34.5V15h6v19.5 M25 34.5V23h9v11.5 M13.5 14h3 M13.5 18.5h3 M13.5 23h3 M13.5 27.5h3 M21 19h2 M21 23.5h2 M21 28h2 M6.5 25h2 M6.5 29h2 M28 27h3 M28 30.5h3" + ground),
        "wedding": k("#FBEFF2", "#8C2944", "M5 34.5V15 M35 34.5V15 M3 15h34 M5 15c0-5 6.5-9 15-11 8.5 2 15 6 15 11 M20 4V1.5 M12.5 26a3.5 3.5 0 1 0 7 0a3.5 3.5 0 1 0-7 0 M20.5 26a3.5 3.5 0 1 0 7 0a3.5 3.5 0 1 0-7 0 M9 15v3.5 M31 15v3.5" + ground),
        "move": k("#F0F1FB", "#3E449E", "M3 24l7-6 7 6v10.5H3z M23 24l7-6 7 6v10.5H23z M8 34.5v-5h4v5 M28 34.5v-5h4v5 M13 9.5h14 M24 6.5l3 3-3 3" + ground),
        "home": k("#F8F0EA", "#894323", "M4 19 17 8l13 11 M7 16.5v18h20v-18 M14 34.5v-8h6v8 M22 12V7h3v7.5 M30.5 25.5a3.5 4 0 1 0 7 0a3.5 4 0 1 0-7 0 M34 29.5v5" + ground),
        "baby": k("#F2F0FB", "#5A4BAE", "M7 19a13 13 0 0 0 26 0z M20 19V6a13 13 0 0 1 13 13 M12 31a2.6 2.6 0 1 0 .01 0 M28 31a2.6 2.6 0 1 0 .01 0 M33 19l4-5 M13 28.6 15 26 M27 28.6 25 26 M3 37.5h34"),
        "study": k("#EDF6F0", "#1F6A3E", "M34 12 20 6 6 12l14 6 14-6z M11 14.5v5c4 3 14 3 18 0v-5 M34 12v6 M8 34.5V30h24v4.5 M10 30v-4h20v4" + ground),
        "festival": k("#FFF5E8", "#B3530E", "M5 23c2 7 28 7 30 0z M20 20c-3-3-3-7 0-12 3 5 3 9 0 12z M15 34.5h10 M20 29.5v5 M8 12l-2-2 M32 12l2-2 M20 5.5V3 M3 37.5h34"),
        "party": k("#FBF0F8", "#94307C", "M13 4c-4 0-6 3-6 6 0 4 3 7 6 8 3-1 6-4 6-8 0-3-2-6-6-6z M12 18l1 2 1-2 M13 20c0 5 3 8 3 14.5 M27 8c-4 0-6 3-6 6 0 4 3 7 6 8 3-1 6-4 6-8 0-3-2-6-6-6z M26 22l1 2 1-2 M27 24c0 4-3 6-3 10.5 M33 4l1.2 1.2 M35.5 9h1.5 M4.5 25l1.2 1.2" + ground),
        "ceremony": k("#FDF1ED", "#A33A24", "M20 31c-8 0-15-5-17-13 6 0 12 2 17 8 5-6 11-8 17-8-2 8-9 13-17 13z M20 25c-4-6-4-13 0-20 4 7 4 14 0 20z M8 34.5c2-1.2 4-1.2 6 0s4 1.2 6 0 4-1.2 6 0 4 1.2 6 0 M12 37.5c2-1.2 4-1.2 6 0s4 1.2 6 0 4-1.2 6 0"),
        "guest": k("#F4F0FA", "#5C3A99", "M5 14h30v20.5H5z M5 14l15 11 15-11 M20 9.5c-1.2-2-4-1.6-4 .4 0 1.6 2 2.8 4 4.4 2-1.6 4-2.8 4-4.4 0-2-2.8-2.4-4-.4z M7 37.5h26"),
        "reno": k("#EEF3FA", "#24508E", "M4 6h22v28.5H4z M4 15h9v19.5 M13 22h13 M31 7l4 4-11 11h-4v-4z M28 10l4 4 M7 37.5h26"),
        "vehicle": k("#F2F3F5", "#2F3541", "M4 27v-7l5-9h22l5 9v7z M4 20h32 M7 27v3.5h5V27 M28 27v3.5h5V27 M9 23.5h3 M28 23.5h3 M15 11l-1.5 9 M25 11l1.5 9 M2 34.5h36 M8 37.5h4 M18 37.5h4 M28 37.5h4"),
        "course": k("#F0F6EA", "#48681D", "M5 7h30v21H5z M9 12h16 M9 16h12 M9 20h8 M24.5 21a3.5 3.5 0 1 0 7 0a3.5 3.5 0 1 0-7 0 M26 24.2 24.5 31l3.5-1.8 3.5 1.8-1.5-6.8" + ground),
        "venture": k("#F8F2E9", "#7A4D1C", "M5 14h30l-2.5-7h-25z M5 14c0 2.2 1.7 3.5 3.75 3.5S12.5 16.2 12.5 14c0 2.2 1.7 3.5 3.75 3.5S20 16.2 20 14c0 2.2 1.7 3.5 3.75 3.5S27.5 16.2 27.5 14c0 2.2 1.7 3.5 3.75 3.5S35 16.2 35 14 M7 17.5v17 M33 17.5v17 M16 34.5v-9h8v9 M10 22h3v4h-3z M27 22h3v4h-3z" + ground),
        "own": k("#F4F4F2", "#3F3F46", "M18 8l2.4 6.6L27 17l-6.6 2.4L18 26l-2.4-6.6L9 17l6.6-2.4z M30 6l1 2.8 2.8 1-2.8 1-1 2.8-1-2.8-2.8-1 2.8-1z M29 24l.8 2 2 .8-2 .8-.8 2-.8-2-2-.8 2-.8z" + ground),
        "mail": k("#EEF2FF", "#3A4ED6", "M5 13h30v21H5z M5 13l15 11 15-11 M33 3v6 M30 6h6 M7 37.5h26"),
        "flight": k("#EEF3FB", "#2D4F8E", "M27.9 29.9 25.4 18.4l4.9-4.9C32.4 11.4 33.1 8.6 32.4 7.2c-1.4-.7-4.2 0-6.3 2.1L21.2 14.2 9.7 11.7c-.7-.14-1.26.14-1.54.7l-.42.7c-.28.7-.14 1.4.42 1.82L15.6 19.8l-2.8 4.2H8.6l-1.4 1.4 4.2 2.8 2.8 4.2 1.4-1.4v-4.2l4.2-2.8 4.9 7.42c.42.56 1.12.7 1.82.42l.7-.28c.56-.42.84-.98.7-1.68z"),
        "stay": k("#F4F0FA", "#5C3E98", "M4 31V11 M4 24h32v7 M36 24a5 5 0 0 0-5-5H18v5 M8 19a2.5 2.5 0 1 0 5 0a2.5 2.5 0 1 0-5 0 M2 34.5h36"),
        "food": k("#FFF5E8", "#B3530E", "M5 19h30a15 15 0 0 1-30 0z M14 34.5h12 M24 4l-6 12 M31 5l-9 11 M10 15c1-2-1-3 0-5"),
        "shop": k("#FCEFF4", "#A2255A", "M8 13h24l-2 21.5H10z M15 13v-3a5 5 0 0 1 10 0v3 M3 37.5h34"),
        "train": k("#EEF5F8", "#1F5E78", "M10 5h20a4 4 0 0 1 4 4v15a4 4 0 0 1-4 4H10a4 4 0 0 1-4-4V9a4 4 0 0 1 4-4z M6 17h28 M20 5v12 M12 23h.01 M28 23h.01 M13 28l-4 6 M27 28l4 6 M3 34.5h34"),
        "fun": k("#FDF0F0", "#A3302A", "M5 12h30v5a3 3 0 0 0 0 6v5H5v-5a3 3 0 0 0 0-6z M25 13v2 M25 18.5v3 M25 25v2"),
        "fee": k("#F7F3EC", "#7A5A1E", "M30 9 10 31 M12 9a3 3 0 1 0 0 6a3 3 0 1 0 0-6 M28 25a3 3 0 1 0 0 6a3 3 0 1 0 0-6"),
        "doc": k("#F1F3F6", "#3D4657", "M10 4h14l7 7v25H10z M24 4v7h7 M14 18h12 M14 23h12 M14 28h8"),
        "shield": k("#EDF6F5", "#1D6660", "M20 4l13 5v9c0 8-5.5 13.5-13 16-7.5-2.5-13-8-13-16V9z M15 19l3.5 3.5L26 15")
    ]

    static func get(_ key: String) -> KindArt { all[key] ?? all["own"]! }
}

/// a pale square with a fine drawing standing on a ground line
struct KindTile: View {
    let kind: String
    var size: CGFloat = 64
    @Environment(\.colorScheme) private var scheme

    var body: some View {
        let k: KindArt = Kinds.get(kind)
        let ink: Color = k.ink.ink(scheme)
        let art: CGFloat = size * 0.64
        let lw: CGFloat = (size >= 56 ? 1.35 : 1.6) * art / 40
        let bg: Color = scheme == .dark ? k.ink.opacity(0.26) : k.bg
        RoundedRectangle(cornerRadius: size * 0.27, style: .continuous)
            .fill(bg)
            .frame(width: size, height: size)
            .overlay {
                SVGShape(d: k.d, box: 40)
                    .stroke(ink, style: StrokeStyle(lineWidth: lw, lineCap: .round, lineJoin: .round))
                    .frame(width: art, height: art)
            }
    }
}

// MARK: the families' little illustrated icons

enum ChapterFam: String, CaseIterable, Identifiable {
    case all, journey, life, occasion, project
    var id: String { rawValue }
    var title: String {
        switch self {
        case .all: return "All"
        case .journey: return "Journeys"
        case .life: return "Life events"
        case .occasion: return "Occasions"
        case .project: return "Projects"
        }
    }
}

struct FamIcon: View {
    let fam: ChapterFam
    var size: CGFloat = 32

    var body: some View {
        Canvas { ctx, sz in
            let s: CGFloat = sz.width / 36
            ctx.scaleBy(x: s, y: s)
            switch fam {
            case .all: Self.all(&ctx)
            case .journey: Self.suitcase(&ctx)
            case .life: Self.rings(&ctx)
            case .occasion: Self.diya(&ctx)
            case .project: Self.house(&ctx)
            }
        }
        .frame(width: size, height: size)
        .shadow(color: Color.black.opacity(0.16), radius: 1.2, x: 0, y: 1.4)
        .accessibilityHidden(true)
    }

    static func grad(_ a: String, _ b: String, _ p0: CGPoint, _ p1: CGPoint) -> GraphicsContext.Shading {
        .linearGradient(Gradient(colors: [Color(hex: a), Color(hex: b)]), startPoint: p0, endPoint: p1)
    }
    static func rr(_ x: CGFloat, _ y: CGFloat, _ w: CGFloat, _ h: CGFloat, _ r: CGFloat) -> Path {
        Path(roundedRect: CGRect(x: x, y: y, width: w, height: h), cornerRadius: r, style: .continuous)
    }
    static func all(_ ctx: inout GraphicsContext) {
        ctx.fill(rr(5, 5, 12, 12, 3.5), with: grad("#7C93FF", "#3B5BFD", CGPoint(x: 5, y: 5), CGPoint(x: 17, y: 17)))
        ctx.fill(rr(19, 5, 12, 12, 3.5), with: grad("#FCD34D", "#F59E0B", CGPoint(x: 19, y: 5), CGPoint(x: 31, y: 17)))
        ctx.fill(rr(5, 19, 12, 12, 3.5), with: grad("#FDA4AF", "#E11D48", CGPoint(x: 5, y: 19), CGPoint(x: 17, y: 31)))
        ctx.fill(rr(19, 19, 12, 12, 3.5), with: grad("#5EEAD4", "#0D9488", CGPoint(x: 19, y: 19), CGPoint(x: 31, y: 31)))
    }
    static func suitcase(_ ctx: inout GraphicsContext) {
        ctx.stroke(SVGPath.path("M14 11V8.5A2.5 2.5 0 0 1 16.5 6h3A2.5 2.5 0 0 1 22 8.5V11"), with: .color(Color(hex: "#78350F")), style: StrokeStyle(lineWidth: 2, lineCap: .round))
        ctx.fill(rr(7, 11, 22, 19, 4.5), with: .linearGradient(Gradient(colors: [Color(hex: "#FDE68A"), Color(hex: "#F59E0B"), Color(hex: "#D97706")]), startPoint: CGPoint(x: 7, y: 11), endPoint: CGPoint(x: 29, y: 30)))
        ctx.stroke(SVGPath.path("M13 11v19 M23 11v19"), with: .color(Color(hex: "#B45309").opacity(0.55)), lineWidth: 1.6)
        ctx.fill(rr(9, 13, 7, 3, 1.5), with: .color(.white.opacity(0.45)))
        ctx.fill(Path(ellipseIn: CGRect(x: 9.7, y: 30.2, width: 3.6, height: 3.6)), with: .color(Color(hex: "#44403C")))
        ctx.fill(Path(ellipseIn: CGRect(x: 22.7, y: 30.2, width: 3.6, height: 3.6)), with: .color(Color(hex: "#44403C")))
    }
    static func rings(_ ctx: inout GraphicsContext) {
        let gold: GraphicsContext.Shading = .linearGradient(Gradient(colors: [Color(hex: "#FDE68A"), Color(hex: "#EAB308"), Color(hex: "#A16207")]), startPoint: CGPoint(x: 6, y: 14), endPoint: CGPoint(x: 30, y: 30))
        ctx.stroke(Path(ellipseIn: CGRect(x: 6.5, y: 14.5, width: 15, height: 15)), with: gold, lineWidth: 3.2)
        ctx.stroke(Path(ellipseIn: CGRect(x: 14.5, y: 14.5, width: 15, height: 15)), with: gold, lineWidth: 3.2)
        let gem: Path = SVGPath.path("M11 8.5 14 5l3 3.5-3 4z")
        ctx.fill(gem, with: grad("#E0F2FE", "#7DD3FC", CGPoint(x: 11, y: 5), CGPoint(x: 17, y: 12)))
        ctx.stroke(gem, with: .color(Color(hex: "#38BDF8")), lineWidth: 0.8)
    }
    static func diya(_ ctx: inout GraphicsContext) {
        ctx.fill(Path(ellipseIn: CGRect(x: 10, y: 6, width: 16, height: 16)), with: .color(Color(hex: "#FDE68A").opacity(0.45)))
        ctx.fill(SVGPath.path("M18 19c-3.2-3-3.2-7.5 0-12 3.2 4.5 3.2 9 0 12z"), with: grad("#FEF08A", "#F97316", CGPoint(x: 18, y: 7), CGPoint(x: 18, y: 19)))
        ctx.fill(SVGPath.path("M4 21c2 8 26 8 28 0z"), with: grad("#FDBA74", "#C2410C", CGPoint(x: 18, y: 21), CGPoint(x: 18, y: 27)))
        ctx.stroke(SVGPath.path("M8 22.5c3 2 17 2 20 0"), with: .color(.white.opacity(0.45)), style: StrokeStyle(lineWidth: 1, lineCap: .round))
        ctx.fill(rr(13, 29, 10, 3, 1.5), with: .color(Color(hex: "#9A3412")))
    }
    static func house(_ ctx: inout GraphicsContext) {
        let walls: Path = rr(8, 16, 20, 15, 1.5)
        ctx.fill(walls, with: grad("#FFFFFF", "#E2E8F0", CGPoint(x: 18, y: 16), CGPoint(x: 18, y: 31)))
        ctx.stroke(walls, with: .color(Color(hex: "#CBD5E1")), lineWidth: 0.8)
        ctx.fill(SVGPath.path("M4.5 17.5 18 6l13.5 11.5z"), with: grad("#93C5FD", "#1D4ED8", CGPoint(x: 4, y: 6), CGPoint(x: 31, y: 18)))
        ctx.fill(rr(15.5, 23, 5, 8, 1), with: .color(Color(hex: "#B45309")))
        ctx.fill(rr(10.5, 20, 3.5, 3.5, 0.8), with: .color(Color(hex: "#BAE6FD")))
        ctx.fill(rr(22, 20, 3.5, 3.5, 0.8), with: .color(Color(hex: "#BAE6FD")))
    }
}

/// a real QR code for a group pass
enum QRMaker {
    static func image(_ text: String) -> UIImage? {
        let f = CIFilter.qrCodeGenerator()
        f.message = Data(text.utf8)
        f.correctionLevel = "M"
        guard let out = f.outputImage else { return nil }
        let big: CIImage = out.transformed(by: CGAffineTransform(scaleX: 12, y: 12))
        guard let cg = CIContext().createCGImage(big, from: big.extent) else { return nil }
        return UIImage(cgImage: cg)
    }
}

/// the zoom from a card into its page, when there's a namespace to zoom in
struct ZoomSource: ViewModifier {
    let id: String
    let ns: Namespace.ID?
    func body(content: Content) -> some View {
        if let ns {
            content.matchedTransitionSource(id: id, in: ns)
        } else {
            content
        }
    }
}

/// kosh's gradient button
struct GradientFill: View {
    var radius: CGFloat = 14
    var body: some View {
        RoundedRectangle(cornerRadius: radius, style: .continuous)
            .fill(KoshGradient.fill)
    }
}

/// The button gradient: the accent as it's drawn by day (deep enough for white words on it, by night too), running
/// a little toward violet and a little deeper. For kosh blue that's #3B5BFD to about #5B3FE0; whichever accent is
/// picked, the far end follows it.
@MainActor
enum KoshGradient {
    static var fill: LinearGradient {
        let day: UIColor = UIColor(Color.kosh).resolvedColor(with: UITraitCollection(userInterfaceStyle: .light))
        return LinearGradient(colors: [Color(uiColor: day), end(day)], startPoint: .leading, endPoint: .trailing)
    }

    static func end(_ day: UIColor) -> Color {
        var h: CGFloat = 0
        var s: CGFloat = 0
        var b: CGFloat = 0
        var a: CGFloat = 0
        guard day.getHue(&h, saturation: &s, brightness: &b, alpha: &a) else { return Color(uiColor: day) }
        var turned: CGFloat = h + 22.0 / 360.0
        if turned > 1 { turned -= 1 }
        return Color(hue: Double(turned), saturation: Double(min(1, s * 0.95)), brightness: Double(b * 0.89), opacity: Double(a))
    }
}
