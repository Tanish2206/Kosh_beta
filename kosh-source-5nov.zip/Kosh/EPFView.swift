import SwiftUI

// MARK: - EPF, read off the EPFO passbook
//
// The EPFO's passbook site opens here as it would in Safari. You log in yourself: kosh puts in the UAN it already
// read from your mail, and you type the password and the captcha, which kosh never sees, never types and never
// keeps. (The captcha is there to stop software signing in, so no stored password would make this hands-free; which
// is why kosh doesn't store one. Decided 26 Oct 2026.) Nothing is submitted and nothing is sent anywhere.
//
// Once you are in, kosh reads the balances on the page — your share, your employer's, and the pension part — and
// opens your service history for each employer's name. The page carries today's totals only. **Download the
// passbook PDF and share it into kosh** (the button below) and kosh reads every month since you joined: your
// share, the employer's, the pension part and the interest credited each year. That is the path that matters.

struct EPFSheet: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    @State private var read: [String] = []
    @State private var loading = true
    @State private var reloadTick = 0
    /// what kosh made of the page you're on, so a page never passes in silence
    @State private var status = ""
    /// the status is the site letting kosh down (a page that didn't load, or a tab that says it isn't working)
    @State private var trouble = false
    /// the pages kosh opens by itself after you log in (service history, passbook), each once
    @State private var walked: [String] = []
    @State private var follow: String?
    @State private var followTick = 0
    /// the UAN kosh remembers, put into the login's UAN box once the page is up (never asked for, never typed twice)
    @State private var fillTick = 0
    @State private var filled = false

    /// once a page is read, open the next one the EPFO's own menu offers, as a tap would
    func walk(_ text: String) {
        guard store.live != nil, let next = try? Engine.shared.call("epfNext", [text, walked.joined(separator: "|")]), !next.isEmpty else { return }
        walked.append(next)
        status = next == "Service History" ? "Opening your service history for each employer's name…" : "Opening your passbook…"
        Task { @MainActor in
            try? await Task.sleep(for: .seconds(1.2))
            follow = next; followTick += 1
        }
    }

    func add(_ lines: [String]) { for l in lines where !read.contains(l) { read.append(l) } }

    /// the rules found nothing on this page: say what to do next (the model that used to read such pages is gone;
    /// EPF is read by the rules alone)
    func noFigures(_ text: String) {
        trouble = EPFKeep.siteDown(text)
        status = trouble ? EPFKeep.downLine(held: held) : Self.nothingLine(text, uan: store.rememberedUAN)
    }

    /// what kosh still holds of your EPF, and from when: said beside every failure, so a site that is down never
    /// reads as money gone
    var held: String {
        let jobs: [LiveSession.EPFJob] = store.live?.epfJobs ?? []
        let have: [LiveSession.EPFJob] = jobs.filter { $0.balance > 0 }
        let uan: UserHolding? = store.live?.docHoldings.first { $0.source == "epf|uan" }
        if have.isEmpty, let u = uan, u.amt > 0 {
            return EPFKeep.heldLine(amount: Fmt.rupees(u.amt), jobs: 1, of: 1, day: u.asOf.map { Day.fmt(String($0.prefix(10)), "d MMM yyyy") } ?? "")
        }
        let day: String = have.map(\.asOf).filter { $0.count >= 10 }.max().map { Day.fmt(String($0.prefix(10)), "d MMM yyyy") } ?? ""
        return EPFKeep.heldLine(amount: have.isEmpty ? "" : Fmt.rupees(have.reduce(0) { $0 + $1.balance }), jobs: have.count, of: jobs.count, day: day)
    }

    static func nothingLine(_ page: String, uan: String = "") -> String {
        let low = page.lowercased()
        if low.contains("captcha") || low.contains("password") || low.contains("sign in") || low.contains("login") {
            return uan.isEmpty ? "Log in with your UAN, password and the captcha."
                               : "Your UAN is in. Type your password and the captcha — kosh never sees either."
        }
        return "No EPF figures on this page yet. Open Passbook and pick a member ID."
    }

    static let passbook = URL(string: "https://passbook.epfindia.gov.in/MemberPassBook/login")!

    var body: some View {
        NavigationStack {
            PortalWebView(url: Self.passbook, reload: reloadTick, follow: follow, followTick: followTick,
                          fill: store.rememberedUAN, fillLabel: "uan", fillTick: fillTick,
                          onFail: { why in trouble = true; status = EPFKeep.failLine(why: why, held: held) },
                          loading: $loading) { text, _, _ in
                guard let live = store.live else { return }
                let lines = live.applyEPF(text)
                if lines.isEmpty { noFigures(text) } else { add(lines); trouble = false; status = "Read from this page: " + lines[0] }
                walk(text)
                // the UAN goes in once, when the login page is up: a box you have typed in is never touched
                if !filled, !store.rememberedUAN.isEmpty, text.lowercased().contains("uan") {
                    filled = true
                    fillTick += 1
                }
            }
            .ignoresSafeArea(edges: .bottom)
            .safeAreaInset(edge: .bottom, spacing: 0) { tray }
            .navigationTitle("EPF passbook")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Done") { dismiss() } }
                ToolbarItem(placement: .primaryAction) {
                    Button { reloadTick += 1 } label: { Image(systemName: loading ? "hourglass" : "arrow.clockwise") }
                        .accessibilityLabel(loading ? "Loading" : "Load the page again")
                }
            }
        }
    }

    var tray: some View {
        let jobs = store.live?.epfJobs ?? []
        let latest = store.live?.epfLatest ?? ("", 0)
        let uan = store.live?.docHoldings.first { $0.source == "epf|uan" }?.amt ?? 0
        return VStack(alignment: .leading, spacing: 8) {
            if !status.isEmpty {
                Label(status, systemImage: trouble ? "exclamationmark.triangle.fill" : (status.hasPrefix("Read") ? "checkmark.circle.fill" : "info.circle"))
                    .font(.footnote).foregroundStyle(trouble ? Color.orange : (status.hasPrefix("Read") ? Color.green : Color.secondary))
                    .lineLimit(trouble ? 4 : 2)
            }
            if jobs.isEmpty && uan > 0 {
                HStack {
                    Label("EPF balance", systemImage: "briefcase.fill").font(.subheadline.weight(.semibold))
                    Spacer()
                    Text(Fmt.rupees(uan)).font(.subheadline.weight(.semibold)).monospacedDigit().privacySensitive()
                }
                Text("Open Passbook and pick each member ID: kosh then shows each job, the last entry and the interest.")
                    .font(.caption).foregroundStyle(.secondary)
            } else if jobs.isEmpty && read.isEmpty {
                Label(Self.openingLine(uan: store.rememberedUAN), systemImage: "info.circle")
                    .font(.footnote).foregroundStyle(.secondary)
            } else {
                EPFSummary(jobs: jobs, latest: latest)
                let unread = jobs.filter { $0.balance == 0 && $0.known != true }
                if !unread.isEmpty {
                    Text(Self.pickLine(unread.count)).font(.caption).foregroundStyle(.secondary)
                }
            }
            // the page carries today's totals; the PDF carries every month since you joined
            Text("The page shows today's totals. For every month — your share, your employer's, the pension part and each year's interest — tap Download in the passbook and share the PDF into kosh.")
                .font(.caption).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.horizontal, 16)
        .padding(.vertical, 10)
        .background(.bar)
    }
}

extension EPFSheet {
    /// what to do on the login page, with the UAN already in where kosh has one
    static func openingLine(uan: String) -> String {
        (uan.isEmpty ? "Log in with your UAN, password and the captcha."
                     : "kosh has put your UAN in. Type your password and the captcha — kosh never sees, types or keeps either.")
            + " It then reads every job's balance, opens your service history for each employer's name, and your passbook for the last credit and interest. It only reads; it never submits anything."
    }

    static func pickLine(_ n: Int) -> String {
        n == 1 ? "Pick the other member ID in the passbook so kosh can read it too."
               : "Pick each of the other " + String(n) + " member IDs in the passbook so kosh can read them too."
    }
}

/// jobs, the latest passbook entry and the interest, in three lines
struct EPFSummary: View {
    @Environment(Store.self) private var store
    let jobs: [LiveSession.EPFJob]
    let latest: (fy: String, rate: Double)
    var body: some View {
        let total = jobs.reduce(0) { $0 + $1.balance }
        // a job not read yet makes this a part, never the whole
        let part: Bool = jobs.contains { $0.balance == 0 && $0.known != true }
        let last = jobs.filter { !$0.lastCredit.isEmpty }.max { $0.lastCredit < $1.lastCredit }
        let credited = jobs.filter { !$0.interestFY.isEmpty }.max { $0.interestFY < $1.interestFY }
        VStack(alignment: .leading, spacing: 6) {
            HStack(alignment: .firstTextBaseline) {
                Label(jobs.count == 1 ? "1 job under your UAN" : "\(jobs.count) jobs under your UAN", systemImage: "briefcase.fill")
                    .font(.subheadline.weight(.semibold))
                Spacer()
                if total > 0 { Text(Fmt.rupees(total) + (part ? " so far" : "")).font(.subheadline.weight(.semibold)).monospacedDigit().privacySensitive() }
            }
            ForEach(jobs) { j in
                HStack {
                    VStack(alignment: .leading, spacing: 0) {
                        Text(j.name).lineLimit(1)
                        if !j.span.isEmpty { Text(j.span).foregroundStyle(.secondary) }
                    }
                    Spacer()
                    Text(j.balance > 0 ? Fmt.rupees(j.balance) : (j.known == true ? "₹0 · no transactions" : "not opened yet")).monospacedDigit()
                        .foregroundStyle(j.balance > 0 ? Color.primary : Color.secondary).privacySensitive()
                }
                .font(.caption)
            }
            if let l = last {
                Text(Self.lastLine(l)).font(.caption).foregroundStyle(.secondary)
            }
            Text(Self.interestLine(credited, latest: latest))
                .font(.caption).foregroundStyle(.secondary)
            // when the passbook was last read, gently orange once it's over 45 days old (PortfolioViews.swift's words)
            if let r = Self.readLine(jobs, today: store.snap.today) {
                Text(r.0).font(.caption).foregroundStyle(r.1 ? Color.orange : Color.secondary)
            }
        }
    }

    /// "Read from the EPFO passbook on 2 Oct", "… on 30 Jun, 3 months ago"
    static func readLine(_ jobs: [LiveSession.EPFJob], today: String) -> (String, Bool)? {
        guard let d = jobs.map(\.asOf).filter({ $0.count >= 10 }).max() else { return nil }
        let day: String = String(d.prefix(10))
        let days: Int = Day.between(day, today)
        let old: Bool = days > 45
        return ("Read from the EPFO passbook on " + FreshWords.day(day, today: today) + (old ? ", " + FreshWords.ago(days) : ""), old)
    }

    static func lastLine(_ l: LiveSession.EPFJob) -> String {
        var s = "Last passbook entry: " + Day.fmt(l.lastCredit, "d MMM yyyy")
        if !l.lastMonth.isEmpty { s += ", for " + Day.fmt(l.lastMonth + "-01", "MMMM yyyy") + "'s wages" }
        if l.monthly > 0 { s += " · " + Fmt.rupees(l.monthly) + " from you" }
        return s
    }
    static func interestLine(_ c: LiveSession.EPFJob?, latest: (fy: String, rate: Double)) -> String {
        guard let c else { return "Interest: " + Fmt.trim(latest.rate, 2) + "% for " + latest.fy + ", as the EPFO declared it" }
        let rate: Double = c.rate > 0 ? c.rate : latest.rate
        return "Interest: " + Fmt.trim(rate, 2) + "% for " + c.interestFY + ", " + Fmt.rupees(c.interest) + " credited"
    }
}
