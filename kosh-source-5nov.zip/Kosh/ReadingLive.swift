import ActivityKit
import SwiftUI
import UIKit

// MARK: - kosh's own Lock Screen entry while it reads with the phone locked
//
// On screen, the bar above the tab bar says what kosh is reading. When kosh leaves the screen with reading under
// way, the same words go to the Lock Screen as kosh's own Live Activity (drawn by KoshWidgets/ReadingLiveActivity.swift):
// the title, now and then a lighter line, the count, kosh's gradient filling as it reads.
//  • It starts as kosh leaves (iOS lets an app start one only while it's still in front), never while kosh is on
//    screen, so the same thing is never said twice; and not for a read that's all but done.
//  • While kosh runs (its half-minute, or woken to read in what the background downloads brought back) it's kept up
//    to date, at most every 3 s; each update says when it goes stale, and the Lock Screen says "Still reading in the
//    background" if kosh hasn't been heard from since (it's suspended while the downloads carry on).
//  • The reading finished away from the screen: "All caught up · 1,240 read", gone after two minutes.
//  • The reading stopped with nothing on its way: it ends on "Paused · carries on by itself" (iOS gives kosh time
//    later, and it carries on from the plan when kosh is opened). Waiting for the internet is a pause that passes:
//    the entry stays up for it.
//  • kosh back in front: gone at once (the bar takes over).

@MainActor
final class ReadingLive {
    static let shared = ReadingLive()

    /// reading; paused for now (the internet, a batch being handed over); paused until kosh is opened or iOS gives
    /// it time (the entry ends on it); all read (the entry ends on it, and goes after two minutes)
    enum Stage { case reading, paused, stopped, finished }

    private var activity: Activity<ReadingAttributes>?
    private var shown: ReadingAttributes.ContentState?
    private var pushedAt = Date.distantPast
    /// when kosh left the screen: the lighter lines take their turns from here
    private var since = Date()
    /// entries being ended (kosh came back to the front): never taken up again while they go
    private var ending: Set<String> = []

    /// kosh is leaving the screen: its own Lock Screen entry, if there's reading under way
    func leaving() {
        guard ActivityAuthorizationInfo().areActivitiesEnabled else { return }
        adopt()
        if activity != nil { refresh(force: true); return }
        guard let snap = snapshot(leaving: true), snap.stage == .reading else { return }
        // a read that's all but done finishes in the half-minute iOS gives kosh: no entry for it
        if let live = LiveSession.current, !snap.now.indeterminate, snap.now.total > 0, snap.now.total - snap.now.done < 40,
           live.leftToDownload < 40 { return }
        since = Date()
        let state: ReadingAttributes.ContentState = content(snap.now, snap.stage)
        do {
            activity = try Activity.request(attributes: ReadingAttributes(),
                                            content: ActivityContent(state: state, staleDate: staleDate(snap.stage)),
                                            pushType: nil)
            shown = state
            pushedAt = Date()
        } catch {
            // not allowed now (kosh already in the background, or Live Activities turned off for it): the reading goes
            // on regardless, and the bar shows it when kosh is opened
        }
    }

    /// kosh is on screen again: the bar above the tab bar says it now, so the Lock Screen entry goes at once
    /// (any left over from an earlier run too)
    func backInFront() {
        activity = nil
        shown = nil
        for a in Activity<ReadingAttributes>.activities {
            let id: String = a.id
            ending.insert(id)
            Task { @MainActor in
                await a.end(nil, dismissalPolicy: .immediate)
                self.ending.remove(id)
            }
        }
    }

    /// each second while kosh's own work runs (KeepGoing's tick): kept up to date, at most every 3 s
    func tick() { refresh() }

    /// something ended or changed course (the work on the phone stopped or finished, a batch of downloads came
    /// back): what the Lock Screen says next, now
    func settle() { refresh(force: true) }

    /// the Lock Screen entry brought up to date: only while it's up and kosh isn't on screen
    func refresh(force: Bool = false) {
        guard UIApplication.shared.applicationState != .active else { return }
        adopt()
        guard let a = activity else { return }
        guard force || Date().timeIntervalSince(pushedAt) >= 3 else { return }
        // nothing to say this moment (between one piece of work and the next): left as it is
        guard let snap = snapshot(leaving: false) else { return }
        let state: ReadingAttributes.ContentState = content(snap.now, snap.stage)
        // unchanged: sent again now and then all the same, so it doesn't go stale while kosh is still at it
        if state == shown && snap.stage == .reading && Date().timeIntervalSince(pushedAt) < 45 { return }
        if state == shown && snap.stage == .paused { return }
        // a stop is only final once nothing more is on its way or being handed over (only then does the entry end)
        if snap.stage == .stopped && !force { return }
        push(a, state, snap.stage)
    }

    /// the one this app started, if kosh was closed and opened again (woken by iOS) since
    private func adopt() {
        guard activity == nil else { return }
        activity = Activity<ReadingAttributes>.activities.first {
            !ending.contains($0.id) && ($0.activityState == .active || $0.activityState == .stale)
        }
    }

    private func push(_ a: Activity<ReadingAttributes>, _ state: ReadingAttributes.ContentState, _ stage: Stage) {
        shown = state
        pushedAt = Date()
        let content = ActivityContent(state: state, staleDate: staleDate(stage))
        if stage == .finished {
            // all caught up: said for two minutes, then it goes by itself
            activity = nil
            Task { await a.end(content, dismissalPolicy: .after(Date().addingTimeInterval(120))) }
        } else if stage == .stopped {
            // stopped with nothing on its way: it ends on "Paused", and stays on the Lock Screen until it's cleared
            // or kosh is opened
            activity = nil
            Task { await a.end(content, dismissalPolicy: .default) }
        } else {
            Task { await a.update(content) }
        }
    }

    /// while it reads: stale if kosh isn't heard from for a couple of minutes (it's suspended while the downloads
    /// carry on, and wakes when they're back)
    private func staleDate(_ stage: Stage) -> Date? {
        stage == .reading ? Date().addingTimeInterval(150) : nil
    }

    // MARK: what to say

    /// what's being read, and whether it's reading, paused or done: the work on the phone first (the same words as
    /// the bar), then the background downloads (from the plan they're reading), then all caught up
    private func snapshot(leaving: Bool) -> (now: ReadingNow, stage: Stage)? {
        guard let live = LiveSession.current, live.loadedFromDisk else { return nil }
        let keep: KeepGoing = KeepGoing.shared
        let mail: BackgroundMail = BackgroundMail.shared
        if keep.busy && !keep.stopped {
            // (between one piece of work and the next there's nothing to say: it's left as it is)
            guard let s = keep.status?() ?? ReadingNow.of(live), !s.finished else { return nil }
            return (s, s.paused ? .paused : .reading)
        }
        if var s = ReadingNow.downloading(live) {
            if !Net.shared.online {
                s.kind = .waiting; s.sym = "wifi.slash"; s.title = "Waiting for the internet"; s.paused = true
                return (s, .paused)
            }
            // on their way, or about to be (kosh is handing them over as it leaves)
            if mail.inFlight > 0 || leaving { return (s, .reading) }
            s.paused = true
            return (s, mail.busy || keep.busy && !keep.stopped ? .paused : .stopped)
        }
        // the mail is read; statements or the reader still to go wait for kosh to be opened, or for time from iOS
        if let s = ReadingNow.waitingOnPhone(live) { return (s, mail.busy ? .paused : .stopped) }
        // (the plans the downloads read to the end are still there until kosh is opened and wraps them up)
        let planned: Int = live.plans.reduce(0) { n, e in LiveSession.downloadable(e.key) ? n + e.value.total : n }
        let read: Int = planned > 0 ? planned : max(mail.readAway, live.caughtUp?.read ?? 0)
        // the work on the phone was cut short with nothing listed for the downloads to carry on: paused where it was
        if keep.stopped && read == 0 {
            guard let s = shown else { return nil }
            return (ReadingNow(kind: .reading, sym: s.sym, title: s.title, short: s.title, count: s.count, done: s.done,
                               total: s.total, paused: true, detail: s.count), mail.busy ? .paused : .stopped)
        }
        return (ReadingNow.allRead(read, rest: keep.stopped), .finished)
    }

    private func content(_ s: ReadingNow, _ stage: Stage) -> ReadingAttributes.ContentState {
        let hex: (String, String, String) = Self.colours(KoshAccent.saved)
        let turn: Int = Int(Date().timeIntervalSince(since) / 7)
        let extra: [String] = s.lighter
        let line: String
        switch stage {
        case .finished:
            // (with the work on the phone cut short, what it hadn't got to yet waits for kosh to be opened)
            line = s.kind != .done ? "The rest when you open kosh" : extra.isEmpty ? "Every rupee home" : extra[turn % extra.count]
        case .paused, .stopped:
            line = s.kind == .waiting ? "Carries on by itself once you’re online" : "Paused · carries on by itself"
        case .reading:
            // the plain line first, then a lighter one, and back, as the bar does
            let plain: String = s.aside.isEmpty ? "Keeps reading while you’re away" : s.aside.prefix(1).uppercased() + String(s.aside.dropFirst())
            line = turn % 2 == 0 || extra.isEmpty ? plain : extra[(turn / 2) % extra.count]
        }
        return ReadingAttributes.ContentState(
            title: s.title,
            line: line,
            count: s.count,
            done: s.done,
            total: s.total,
            sym: s.sym,
            paused: stage == .paused || stage == .stopped,
            finished: stage == .finished,
            seeking: s.indeterminate && stage == .reading,
            accentHex: hex.0,
            midHex: hex.1,
            skyHex: hex.2)
    }

    /// kosh's gradient for the Lock Screen's dark ground: the accent, a step between, and its sky (Graphite's night
    /// greys, its day ones would vanish on the dark)
    static func colours(_ a: KoshAccent) -> (String, String, String) {
        switch a {
        case .kosh: return ("#3B5BFD", "#4C86FB", "#5AC8FA")
        case .graphite: return ("#E5E5EA", mix("#E5E5EA", "#8E8E93"), "#8E8E93")
        default:
            let h = a.lineHex
            return (h.0, mix(h.0, h.1), h.1)
        }
    }

    /// halfway between two colours, as "#RRGGBB"
    static func mix(_ a: String, _ b: String) -> String {
        var x: (CGFloat, CGFloat, CGFloat, CGFloat) = (0, 0, 0, 0)
        var y: (CGFloat, CGFloat, CGFloat, CGFloat) = (0, 0, 0, 0)
        UIColor(koshHex: a).getRed(&x.0, green: &x.1, blue: &x.2, alpha: &x.3)
        UIColor(koshHex: b).getRed(&y.0, green: &y.1, blue: &y.2, alpha: &y.3)
        func ch(_ p: CGFloat, _ q: CGFloat) -> Int { Int((((p + q) / 2) * 255).rounded()) }
        return String(format: "#%02X%02X%02X", ch(x.0, y.0), ch(x.1, y.1), ch(x.2, y.2))
    }
}

// MARK: - What the Lock Screen says when the work on the phone has stopped

extension ReadingNow {
    /// what the background downloads are reading, from its plan: the first read (in the order reads carry on) with
    /// mail still to read
    @MainActor
    static func downloading(_ live: LiveSession) -> ReadingNow? {
        guard let d = live.downloading else { return nil }
        let p: ReadingPlan = d.plan
        // counted from what's still to read: the downloads' emails count as soon as they're read in, even while the
        // list still holds them for the read on the phone to strike off
        let total: Int = max(p.total, d.left)
        let done: Int = max(0, total - d.left)
        let c: String = pair(done, total)
        let job: String = d.job
        if job == "backfill" {
            // the month the downloads are on
            let month: String = d.window.map { SetupProgress.monthName(String($0.after.prefix(7))) } ?? ""
            return ReadingNow(kind: .year, sym: "calendar", title: "Filling in the year", short: "The year", aside: month,
                              count: c, done: done, total: total, detail: c + " emails")
        }
        let kind: Kind
        let sym: String
        let title: String
        let short: String
        switch job {
        case "scan": kind = .reading; sym = "envelope.fill"; title = "Reading new mail"; short = "Reading"
        case "wallets": kind = .wallets; sym = "wallet.bifold.fill"; title = "Reading wallet and shop mail"; short = "Wallets"
        case "statements": kind = .statements; sym = "doc.text.fill"; title = "Finding statements and policies"; short = "Statements"
        case "wider": kind = .wider; sym = "scope"; title = "Looking wider for money mail"; short = "Wider"
        case "older": kind = .statements; sym = "doc.text.fill"; title = "Finding earlier years’ statements"; short = "Statements"
        case "missing": kind = .wider; sym = "scope"; title = "Looking for more mail"; short = "Looking"
        default: kind = .inbox; sym = "envelope.fill"; title = "Reading the new inbox"; short = "Inbox"
        }
        return ReadingNow(kind: kind, sym: sym, title: title, short: short, count: c, done: done, total: total, detail: c + " emails")
    }

    /// the mail is all read, but work only the phone itself can do is left over (mail read again with new rules,
    /// statements, the reader): it waits for kosh to be opened, or for time from iOS
    @MainActor
    static func waitingOnPhone(_ live: LiveSession) -> ReadingNow? {
        let order: [String] = ["reingest", "docs", "reader"]
        guard let job = order.first(where: { live.plans[$0] != nil }), let p = live.plans[job] else { return nil }
        let done: Int = min(p.done, p.total)
        let c: String = p.total > 0 ? pair(done, p.total) : ""
        switch job {
        case "reingest":
            return ReadingNow(kind: .again, sym: "envelope.open.fill", title: "Rereading with new rules", short: "Rereading",
                              count: c, done: done, total: p.total, paused: true, detail: c)
        case "docs":
            return ReadingNow(kind: .docs, sym: "doc.text.fill", title: "Opening statements and invoices", short: "Statements",
                              count: c, done: done, total: p.total, paused: true, detail: c)
        default:
            return ReadingNow(kind: .reader, sym: "sparkles", title: live.aiReadingTitle, short: "Reader",
                              count: c, done: done, total: p.total, paused: true, detail: c)
        }
    }

    /// "All caught up · 1,240 read"; or, when the work on the phone was cut short before it got to everything (what
    /// was listed is read, the rest waits for kosh to be opened), "Read while you were away"
    static func allRead(_ read: Int, rest: Bool = false) -> ReadingNow {
        let count: String = read > 0 ? n(read) + " read" : "Nothing new"
        return ReadingNow(kind: rest ? .reading : .done, sym: "checkmark", title: rest ? "Read while you were away" : "All caught up",
                          short: "Caught up", count: count, done: max(1, read), total: max(1, read), finished: true, detail: count)
    }
}
