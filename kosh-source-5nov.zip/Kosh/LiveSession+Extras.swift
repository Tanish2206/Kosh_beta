import Foundation
import Observation
import UIKit
import Network

// MARK: - LiveSession: your corrections, gold, EPF, people and property, the property-tax portal, export and erase
// (split out of LiveSession.swift, 17 Oct 2026; its stored state stays in the class there)

extension LiveSession {
    // MARK: your corrections

    func choose(_ id: String, claude: Bool) {
        guard let i = records.firstIndex(where: { $0.id == id }) else { return }
        records[i].use = claude ? "claude" : "rule"
        records[i].text = nil
        records[i].html = nil
        save()
        rebuild()
    }

    /// a payment's changes put back as they were (nil: none)
    func setOverride(_ id: String, _ o: Override?) {
        if let o { overrides[id] = o } else { overrides.removeValue(forKey: id) }
        save()
    }

    /// the same change to many payments, saved once
    func overrideMany(_ ids: [String], _ change: (inout Override) -> Void) {
        for id in ids {
            var o = overrides[id] ?? Override()
            change(&o)
            overrides[id] = o
        }
        save()
    }

    func override(_ id: String, _ change: (inout Override) -> Void) {
        var o = overrides[id] ?? Override()
        change(&o)
        overrides[id] = o
        save()
    }

    /// (id and time: the ones Store already showed the row with, Store.addSpend)
    func addManual(amount: Double, c: String, s: String, merchant: String, card: String, id given: String? = nil, time: String? = nil) {
        let id: String = given ?? "m-" + UUID().uuidString
        let at: String = time ?? Store.clock.string(from: Date())
        let r = Reading(id: id, kind: "txn", sent: Self.today, from: "", inst: card.isEmpty ? "Cash" : card, instKind: "manual", subject: merchant,
                        src: "manual", rule: "", conf: "high", dir: "out", amt: amount, date: Self.today, time: at,
                        instr: "other", last4: "", party: merchant)
        records.append(r)
        overrides[id] = Override(c: c, s: s)
        save()
        rebuild()
    }

    // things you add by hand or from a photo or a statement
    func upsertPolicy(_ p: UserPolicy) { if let i = userPolicies.firstIndex(where: { $0.id == p.id }) { userPolicies[i] = p } else { userPolicies.append(p) }; save(); rebuild() }

    func removePolicy(_ id: String) { userPolicies.removeAll { $0.id == id }; save(); rebuild() }

    /// "this isn't a deposit" (a payment, a policy...): the mails' readings of that kind leave every screen, and each
    /// mail's template learns it, so the next mail of the same shape isn't read that way either
    func reject(mails: [String], type: String) {
        guard !type.isEmpty else { return }
        for id in mails where !id.isEmpty {
            var kinds: [String] = rejected[id] ?? []
            if !kinds.contains(type) { kinds.append(type) }
            rejected[id] = kinds
        }
        // (each mail's template taught off the main thread, then the book saved: LayoutBook.teachSoon)
        LayoutBook.teachSoon("teachNotJSON", mails: mails, type: type)
        save(); rebuild()
    }

    /// changed your mind: the readings come back, and the templates forget the correction
    /// a payment counted twice (the statement has it once): left out of every total, without teaching its template
    /// anything (the alert itself reads payments right; this one was a second telling)
    func leaveOut(_ id: String) {
        guard !id.isEmpty else { return }
        var kinds: [String] = rejected[id] ?? []
        if !kinds.contains("twice") { kinds.append("twice") }
        rejected[id] = kinds
        save(); rebuild()
    }

    /// what you left out as counted twice, put back
    func putBackLeftOut() {
        for (id, kinds) in rejected where kinds.contains("twice") {
            let rest = kinds.filter { $0 != "twice" }
            rejected[id] = rest.isEmpty ? nil : rest
        }
        save(); rebuild()
    }

    var leftOutCount: Int { rejected.values.filter { $0.contains("twice") }.count }

    func unreject(mails: [String], type: String) {
        var taught: [String] = []
        for id in mails {
            guard var kinds = rejected[id] else { continue }
            kinds.removeAll { $0 == type }
            rejected[id] = kinds.isEmpty ? nil : kinds
            taught.append(id)
        }
        LayoutBook.teachSoon("teachUndoJSON", mails: taught, type: type)
        save(); rebuild()
    }

    /// "not mine": the policy stays out, whichever mail or paper mentions it again
    func hidePolicy(key: String, id: String) {
        if !key.isEmpty && !hiddenPolicies.contains(key) { hiddenPolicies.append(key) }
        userPolicies.removeAll { $0.id == id && $0.source != "manual" }
        showNow("hide|" + key) { s in ShownRules.hidePolicy(&s, key: key) }
        save(); rebuild()
    }

    func upsertLoan(_ l: UserLoan) { if let i = userLoans.firstIndex(where: { $0.id == l.id }) { userLoans[i] = l } else { userLoans.append(l) }; save(); rebuild() }

    func removeLoan(_ id: String) { userLoans.removeAll { $0.id == id }; save(); rebuild() }

    func upsertHolding(_ h0: UserHolding) {
        // the day you entered it, so its row can say "Your entry, 2 Oct" (engine/21k-build-portfolio.js)
        var h: UserHolding = h0
        h.said = Self.today
        if let i = userHoldings.firstIndex(where: { $0.id == h.id }) { userHoldings[i] = h } else { userHoldings.append(h) }
        save(); rebuild()
        if h.cls == "gold" { Task { await refreshGold() } }
    }

    // MARK: physical gold, at today's rate

    /// today's gold rate per gram by purity, from the India Bullion and Jewellers Association (the rate banks
    /// and RBI use), without GST and making charges; fetched once a day while you hold physical gold
    struct GoldPrice: Codable { var d: String; var g: [String: Double] }

    struct GoldRead: Decodable { let ok: Bool; let g: [String: Double] }

    static let purities: [(Int, String)] = [(999, "24 carat (999)"), (995, "24 carat (995)"), (916, "22 carat (916)"), (750, "18 carat (750)"), (585, "14 carat (585)")]

    static func carat(_ p: Int) -> String { p >= 995 ? "24K" : p >= 916 ? "22K" : p >= 750 ? "18K" : "14K" }

    @MainActor

    func refreshGold(force: Bool = false) async {
        guard userHoldings.contains(where: { $0.cls == "gold" }) else { return }
        if !force, let p = goldPrice, p.d == Self.today { applyGold(); return }
        var req = URLRequest(url: URL(string: "https://www.ibjarates.com/")!)
        req.timeoutInterval = 20
        req.setValue("Mozilla/5.0 (iPhone; CPU iPhone OS 26_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0 Mobile/15E148 Safari/604.1", forHTTPHeaderField: "User-Agent")
        guard let (data, _) = try? await URLSession.shared.data(for: req),
              let html = String(data: data, encoding: .utf8) ?? String(data: data, encoding: .isoLatin1),
              let out = try? Engine.shared.call("goldRatesJSON", [html]), let r = try? JSONText.decode(GoldRead.self, out), r.ok else { applyGold(); return }
        let p = GoldPrice(d: Self.today, g: r.g)
        goldPrice = p
        if let d = try? JSONEncoder().encode(p) { ud.set(d, forKey: "beta.goldPrice") }
        applyGold()
    }

    /// every piece of physical gold at the latest rate: weight × the rate for its purity
    func applyGold() {
        guard let p = goldPrice else { return }
        var changed = false
        for i in userHoldings.indices where userHoldings[i].cls == "gold" {
            var h = userHoldings[i]
            let g = h.grams ?? 0, pur = h.purity ?? 916
            guard g > 0, let rate = p.g[String(pur)] ?? p.g["916"] else { continue }
            let amt = (g * rate).rounded()
            let rem = Self.carat(pur) + " · " + Fmt.trim(g, 3) + " g · " + Fmt.rupees(rate) + "/g on " + Day.fmt(p.d, "d MMM")
            if h.amt != amt || h.rem != rem || h.asOf != p.d { h.amt = amt; h.rem = rem; h.asOf = p.d; userHoldings[i] = h; changed = true }
            noteReading(src: "gold|" + h.id, date: p.d, owner: h.owner, values: ["gold": amt])
        }
        if changed { save(); rebuildSoon() }
    }

    func removeHolding(_ id: String) { userHoldings.removeAll { $0.id == id }; save(); rebuild() }

    /// the holding you added that a row shows, by the id the engine carries through (never by its figure: a deposit
    /// shows what it has grown to, not what you typed)
    func typedHolding(_ h: Holding) -> UserHolding? {
        guard let uid = h.uid else { return nil }
        return userHoldings.first { $0.id == uid }
    }

    func upsertCommittee(_ c: UserCommittee) { if let i = userCommittees.firstIndex(where: { $0.id == c.id }) { userCommittees[i] = c } else { userCommittees.append(c) }; save(); rebuild() }

    func removeCommittee(_ id: String) { userCommittees.removeAll { $0.id == id }; save(); rebuild() }

    /// what one month actually cost (nil clears it back to face value / the bank's payments)
    func recordInstalment(_ id: String, month: String, amount: Double?) {
        guard let i = userCommittees.firstIndex(where: { $0.id == id }) else { return }
        var p = userCommittees[i].paid ?? [:]
        p[month] = amount
        userCommittees[i].paid = p.isEmpty ? nil : p
        save(); rebuild()
    }

    /// payments to this payee are this committee's instalments from now on (nil unlinks)
    func linkCommittee(_ id: String, payee: String?, name: String?) {
        guard let i = userCommittees.firstIndex(where: { $0.id == id }) else { return }
        userCommittees[i].payee = payee; userCommittees[i].payeeName = name
        save(); rebuild()
    }

    func upsertProperty(_ p: UserProperty) { if let i = properties.firstIndex(where: { $0.id == p.id }) { properties[i] = p } else { properties.append(p) }; save(); rebuild() }

    func removeProperty(_ id: String) {
        lastRemoved = properties.first { $0.id == id }
        properties.removeAll { $0.id == id }; save(); rebuild()
    }

    /// The EPFO passbook, read off the page you opened after logging in yourself: each member ID
    /// (one per employer) becomes a retirement holding, replaced each time it's read again.
    struct EPFRead: Decodable {
        struct M: Decodable {
            let memberId: String; let estId: String; let establishment: String
            let employee: Double; let employer: Double; let pension: Double; let total: Double; let asOf: String
            let lastCredit: String; let lastMonth: String; let firstMonth: String; let monthly: Double
            let interest: Double; let interestFY: String; let rate: Double
            var known: Bool? = nil
            /// joined and left that employer (yyyy-MM-dd), from the service history
            var joined: String? = nil; var left: String? = nil
        }
        struct Sum: Decodable { let total: Double; let employee: Double; let employer: Double; let pension: Double; let member: String }
        struct Latest: Decodable { let fy: String; let rate: Double }
        let members: [M]; let summary: Sum; let latest: Latest
    }

    /// one job's EPF account (a member ID under your UAN), as far as the passbook pages have shown it
    struct EPFJob: Codable, Identifiable, Hashable {
        var id: String                 // the member ID
        var establishment = ""
        var balance: Double = 0; var employee: Double = 0; var employer: Double = 0; var pension: Double = 0
        var asOf = ""; var lastCredit = ""; var lastMonth = ""; var firstMonth = ""; var monthly: Double = 0
        var interest: Double = 0; var interestFY = ""; var rate: Double = 0
        /// its balance has been read (₹0 when the account has no transactions)
        var known: Bool? = nil
        /// when you joined and left that employer (yyyy-MM-dd), from the EPFO's service history
        var joined: String? = nil; var left: String? = nil
        /// read off the passbook PDF, not the portal page: so it carries its whole history, and its figure is the
        /// closing balance the paper prints on its own day (never today's)
        var book: Bool? = nil
        /// one financial year of this job's passbook: what went in, and the interest the EPFO credited at its end
        struct FYRow: Codable, Hashable { var fy: String; var ee: Double; var er: Double; var pen: Double; var trf: Double; var interest: Double; var months: Int }
        var years: [FYRow]? = nil
        /// every month of wages the passbook carries ("2024-04"), so a payslip's PF for a month with no row shows
        var wageMonths: [String]? = nil
        /// what went in each wage month off the passbook, your share and your employer's (its contribution rows only, a
        /// month's rows added up): the build draws EPF month by month from these (engine/21u-build-epf-months.js)
        struct MonthRow: Codable, Hashable { var m: String; var ee: Double; var er: Double }
        var mrows: [MonthRow]? = nil
        /// a previous job's balance moved into this account (its own rows say so), so the two are never one pot twice
        var trfIn: Double? = nil
        /// how many months of wages the passbook shows
        var months: Int? = nil
        /// which paper the passbook figures came from, so removing that paper takes its figures with it
        var src: String? = nil
        /// "Apr 2019 – Jun 2022", or "since Sep 2026" while you're still there
        var span: String {
            guard let j = joined, !j.isEmpty else { return "" }
            let from: String = Day.fmt(j, "MMM yyyy")
            if let l = left, !l.isEmpty { return from + " – " + Day.fmt(l, "MMM yyyy") }
            return "since " + from
        }
        var name: String { establishment.isEmpty ? "Member ID ••" + String(id.suffix(5)) : LiveSession.titleCase(establishment) }
    }

    static func titleCase(_ s: String) -> String {
        s.lowercased().split(separator: " ").map { w -> String in
            let x = String(w)
            if ["pvt", "ltd", "llp", "inc"].contains(x.replacingOccurrences(of: ".", with: "")) { return x.prefix(1).uppercased() + x.dropFirst() }
            if x.count <= 3 && ["and", "of", "the", "for"].contains(x) { return x }
            return x.prefix(1).uppercased() + x.dropFirst()
        }.joined(separator: " ")
    }

    /// What an EPFO passbook page shows, kept: every member ID (one per job) with its employer, and the
    /// balance, last credit and interest of each passbook opened. Returns a line per account read.
    @discardableResult

    func applyEPF(_ text: String, owner: String = "me") -> [String] {
        guard let out = try? Engine.shared.call("epfJSON", [text]), let r = try? JSONText.decode(EPFRead.self, out) else { return [] }
        return applyEPF(r, owner: owner)
    }

    @discardableResult

    func applyEPF(_ r: EPFRead, owner: String = "me") -> [String] {
        epfLatest = (r.latest.fy, r.latest.rate)
        var lines: [String] = []
        var named: [String] = []
        var changed = false
        for m in r.members {
            var j = epfJobs.first { $0.id == m.memberId } ?? EPFJob(id: m.memberId)
            let renamed = !m.establishment.isEmpty && m.establishment != j.establishment
            if !m.establishment.isEmpty { j.establishment = m.establishment }
            if let d = m.joined, !d.isEmpty { j.joined = d }
            if let d = m.left, !d.isEmpty { j.left = d }
            if renamed || (m.joined ?? "") != "" { named.append(j.span.isEmpty ? j.name : j.name + " · " + j.span) }
            let bal = m.total > 0 ? m.total : m.employee + m.employer
            // (a page never clears a figure kosh holds, nor overwrites the passbook PDF's: EPFKeep.swift)
            if (bal > 0 || m.known == true) && EPFKeep.pageMayReplace(held: j.balance, book: j.book == true, page: bal) {
                j.balance = bal; j.known = true
                if m.employee + m.employer > 0 { j.employee = m.employee; j.employer = m.employer; j.pension = m.pension }
                j.asOf = m.asOf.isEmpty ? Self.today : m.asOf
            }
            if !m.lastCredit.isEmpty && m.lastCredit >= j.lastCredit { j.lastCredit = m.lastCredit; j.lastMonth = m.lastMonth; j.monthly = m.monthly }
            if !m.firstMonth.isEmpty && (j.firstMonth.isEmpty || m.firstMonth < j.firstMonth) { j.firstMonth = m.firstMonth }
            if !m.interestFY.isEmpty && m.interestFY >= j.interestFY { j.interest = m.interest; j.interestFY = m.interestFY; j.rate = m.rate }
            if let i = epfJobs.firstIndex(where: { $0.id == j.id }) { if epfJobs[i] != j { epfJobs[i] = j; changed = true } } else { epfJobs.append(j); changed = true }
        }
        // a summary card with no member ID on the page stands for the UAN as a whole
        var uanTotal: Double = 0
        if r.summary.member.isEmpty && r.summary.total > 0 { uanTotal = r.summary.total }

        // Portfolio: one holding per job with money in it; the UAN's total only while no job's is known
        for j in epfJobs where j.balance <= 0 && docHoldings.contains(where: { $0.source == "epf|" + j.id }) {
            docHoldings.removeAll { $0.source == "epf|" + j.id }; changed = true
        }
        for j in epfJobs where j.balance > 0 {
            let tag = "epf|" + j.id
            var bits: [String] = []
            if !j.lastCredit.isEmpty { bits.append("last credit " + Day.fmt(j.lastCredit, "d MMM yyyy")) }
            if j.pension > 0 { bits.append("pension (EPS) " + Fmt.rupees(j.pension) + " on top") }
            var h = UserHolding(bank: "EPF · " + j.name, type: "EPF", cls: "ret", amt: j.balance, rate: j.rate > 0 ? j.rate : r.latest.rate,
                                rem: bits.joined(separator: " · "), owner: owner, source: tag)
            h.asOf = j.asOf.isEmpty ? Self.today : j.asOf
            if let i = docHoldings.firstIndex(where: { $0.source == tag }) {
                if docHoldings[i].amt != h.amt || docHoldings[i].rem != h.rem || docHoldings[i].bank != h.bank { docHoldings[i] = h; changed = true }
            } else { docHoldings.append(h); changed = true }
            noteReading(src: tag, date: h.asOf ?? Self.today, owner: owner, values: ["ret": j.balance])
            lines.append(j.name + " · " + Fmt.rupees(j.balance))
        }
        if epfJobs.contains(where: { $0.balance > 0 }) {
            if docHoldings.contains(where: { $0.source == "epf|uan" }) { docHoldings.removeAll { $0.source == "epf|uan" }; changed = true }
        } else if uanTotal > 0 {
            var h = UserHolding(bank: "EPF", type: "EPF", cls: "ret", amt: uanTotal, rate: r.latest.rate, rem: "", owner: owner, source: "epf|uan")
            h.asOf = Self.today
            if let i = docHoldings.firstIndex(where: { $0.source == "epf|uan" }) { if docHoldings[i].amt != uanTotal { docHoldings[i] = h; changed = true } }
            else { docHoldings.append(h); changed = true }
            // the UAN's own total is a dated reading too, as each job's is: without it an EPF balance read off the
            // summary card alone was missing from net worth over time
            noteReading(src: "epf|uan", date: h.asOf ?? Self.today, owner: owner, values: ["ret": uanTotal])
            lines.append("EPF · " + Fmt.rupees(uanTotal))
        }
        if changed { save(); rebuildSoon() }
        // a page with employers' names and dates but no balances (the service history) still says what it read
        if lines.isEmpty && !named.isEmpty { lines = named.count == 1 ? named : [String(named.count) + " employers: " + named.joined(separator: ", ")] }
        return lines
    }

    /// what a typed password for an EPFO passbook is remembered by: the EPFO, not the one file it opened, so the
    /// next passbook shared in opens by itself
    static let epfDomain = "epfindia.gov.in"

    /// The passbook PDF, read (docread.js READERS.epf): every job under the UAN with its whole month-by-month
    /// history, each one's closing balance on the paper's own day, and the interest credited each year. The portal
    /// page's figure for the same member ID gives way to this one in the build (engine/21l-build-retirement.js),
    /// because the paper says which day it is for and the page says only "now".
    @MainActor
    @discardableResult

    func applyEPFBook(_ book: DocParsed.EPFBook, source: String = "", owner: String = "me") -> [String] {
        var lines: [String] = []
        for m in book.members where m.ok {
            guard let close = m.close else { continue }
            var j = epfJobs.first { $0.id == m.memberId } ?? EPFJob(id: m.memberId)
            if !m.establishment.isEmpty { j.establishment = m.establishment }
            if !m.joined.isEmpty { j.joined = m.joined }
            if !m.left.isEmpty { j.left = m.left }
            j.employee = close.ee; j.employer = close.er; j.pension = close.pen
            j.balance = close.ee + close.er
            j.known = true
            j.book = true
            j.asOf = m.asOf.isEmpty ? Self.today : m.asOf
            j.months = m.rows
            j.src = source.isEmpty ? nil : source
            j.trfIn = m.trfIn > 0 ? m.trfIn : nil
            j.years = m.years.map { EPFJob.FYRow(fy: $0.fy, ee: $0.ee, er: $0.er, pen: $0.pen, trf: $0.trf, interest: $0.interest, months: $0.months) }
            j.wageMonths = Array(Set(m.months.filter { $0.k == "cont" && !$0.m.isEmpty }.map(\.m))).sorted()
            let conts: [(m: String, ee: Double, er: Double)] = m.months.filter { $0.k == "cont" && !$0.m.isEmpty }.map { (r: DocParsed.EPFBook.Mo) -> (m: String, ee: Double, er: Double) in (m: r.m, ee: r.ee, er: r.er) }
            j.mrows = Self.epfMonthRows(conts)
            // the last month of wages the passbook carries, and what went in for it
            if let last = m.months.filter({ $0.k == "cont" && !$0.m.isEmpty }).max(by: { $0.m < $1.m }) {
                j.lastMonth = last.m
                j.monthly = last.ee
                if !last.d.isEmpty { j.lastCredit = last.d }
            }
            if let first = m.months.filter({ $0.k == "cont" && !$0.m.isEmpty }).min(by: { $0.m < $1.m }) { j.firstMonth = first.m }
            if let y = m.years.filter({ $0.interest > 0 }).max(by: { $0.fy < $1.fy }) { j.interest = y.interest; j.interestFY = y.fy }
            if let i = epfJobs.firstIndex(where: { $0.id == j.id }) { epfJobs[i] = j } else { epfJobs.append(j) }
            // the paper's own figure, under its own tag: the build keeps this one and drops the page's (via stays "epf",
            // so every screen still says "EPFO passbook" and how old the figure is)
            let tag: String = "epf|book|" + m.memberId
            var bits: [String] = []
            if !j.lastCredit.isEmpty { bits.append("last credit " + Day.fmt(j.lastCredit, "d MMM yyyy")) }
            if close.pen > 0 { bits.append("pension (EPS) " + Fmt.rupees(close.pen) + " on top") }
            var h = UserHolding(bank: "EPF · " + j.name, type: "EPF", cls: "ret", amt: j.balance, rate: epfLatest.rate,
                                rem: bits.joined(separator: " · "), owner: owner, source: tag)
            h.asOf = j.asOf
            if let i = docHoldings.firstIndex(where: { $0.source == tag }) { docHoldings[i] = h } else { docHoldings.append(h) }
            noteReading(src: tag, date: j.asOf, owner: owner, values: ["ret": j.balance])
            lines.append(j.name + " · " + Fmt.rupees(j.balance))
        }
        if !lines.isEmpty { save(); rebuildSoon() }
        return lines
    }

    /// a passbook's contribution rows, one a wage month (two rows for one month, an arrear, added up), oldest first
    static func epfMonthRows(_ rows: [(m: String, ee: Double, er: Double)]) -> [EPFJob.MonthRow]? {
        var by: [String: (ee: Double, er: Double)] = [:]
        for r in rows {
            let had: (ee: Double, er: Double) = by[r.m] ?? (ee: 0, er: 0)
            by[r.m] = (ee: had.ee + r.ee, er: had.er + r.er)
        }
        let out: [EPFJob.MonthRow] = by.keys.sorted().map { (k: String) -> EPFJob.MonthRow in
            EPFJob.MonthRow(m: k, ee: by[k]?.ee ?? 0, er: by[k]?.er ?? 0)
        }
        return out.isEmpty ? nil : out
    }

    /// A passbook shared in from Files, removed: the figures it stood behind go with it. Each job's name and the
    /// dates it ran keep their row — those came from the EPFO's own service history, not from this paper.
    func forgetEPFBook(source: String) {
        for (i, j) in epfJobs.enumerated() where j.src == source {
            docHoldings.removeAll { $0.source == "epf|book|" + j.id }
            var x = j
            x.src = nil; x.book = nil; x.years = nil; x.trfIn = nil; x.months = nil; x.wageMonths = nil; x.mrows = nil
            x.balance = 0; x.employee = 0; x.employer = 0; x.pension = 0; x.known = nil; x.asOf = ""
            epfJobs[i] = x
        }
    }

    /// "GF", "1F", "2nd Floor" as a person would write them
    static func floorName(_ raw: String) -> String {
        let t = raw.trimmingCharacters(in: .whitespaces).uppercased()
        if t == "GF" || t.hasPrefix("GROUND") { return "Ground floor" }
        if t == "BF" || t.hasPrefix("BASEMENT") { return "Basement" }
        if t.hasPrefix("MEZZ") { return "Mezzanine" }
        let digits = t.prefix { $0.isNumber }
        let rest = String(t.dropFirst(digits.count)).trimmingCharacters(in: .whitespaces)
        if let n = Int(digits), n >= 1, n < PropertyEditor.floorNames.count,
           rest.range(of: "^(ST|ND|RD|TH)?\\s*(F|FLR|FLOOR)?$", options: .regularExpression) != nil {
            return PropertyEditor.floorNames[n]
        }
        return raw.lowercased().split(separator: " ").map { $0.prefix(1).uppercased() + $0.dropFirst() }.joined(separator: " ")
    }

    func undoRemove() {
        guard let p = lastRemoved else { return }
        lastRemoved = nil
        upsertProperty(p)
    }

    /// this month's rent from one floor: received (by hand), or not after all
    func toggleRentPaid(property uid: String, unit idx: Int, month: String) {
        guard let i = properties.firstIndex(where: { $0.id == uid || $0.pid == uid }), idx < properties[i].units.count else { return }
        var paid = properties[i].units[idx].paidMonths ?? []
        if let k = paid.firstIndex(of: month) { paid.remove(at: k) } else { paid.append(month) }
        properties[i].units[idx].paidMonths = paid
        save(); rebuild()
    }

    /// when a holding's figure is from: its statement's date, the EPFO read, or nothing for one you typed
    static func asOfOf(_ h: UserHolding) -> String? {
        if let a = h.asOf, Self.isDay(a) { return String(a.prefix(10)) }
        if h.source.hasPrefix("cas|"), let last = h.source.split(separator: "|").last, Self.isDay(String(last)) { return String(last.prefix(10)) }
        return nil
    }

    static func isDay(_ s: String) -> Bool {
        let p: [Substring] = s.prefix(10).split(separator: "-")
        return p.count == 3 && p[0].count == 4 && p[1].count == 2 && p[2].count == 2 && p.allSatisfy { $0.allSatisfy(\.isNumber) }
    }

    /// a credit kosh took for a floor's rent that wasn't: it stops counting for that floor (and any other)
    func notRent(property uid: String, unit idx: Int, tx: String) {
        guard !tx.isEmpty, let i = properties.firstIndex(where: { $0.id == uid || $0.pid == uid }), idx < properties[i].units.count else { return }
        var xs = properties[i].units[idx].notRent ?? []
        if !xs.contains(tx) { xs.append(tx) }
        properties[i].units[idx].notRent = xs
        save(); rebuild()
    }

    /// a property's photo, as the portal shows it
    static var photoFolder: URL {
        let f = folder.appendingPathComponent("photos", isDirectory: true)
        try? FileManager.default.createDirectory(at: f, withIntermediateDirectories: true)
        return f
    }

    @MainActor

    func savePropertyPhoto(pid: String, jpeg: Data) {
        guard jpeg.count > 1000 else { return }
        guard let i = properties.firstIndex(where: { $0.pid == pid }) else { pendingPhotos[pid] = jpeg; return }
        pendingPhotos[pid] = nil
        let name = pid + ".jpg"
        do { try jpeg.write(to: Self.photoFolder.appendingPathComponent(name), options: [.atomic, Self.protection]) } catch { return }
        if properties[i].photo != name { properties[i].photo = name; save(); rebuild() }
    }

    /// the state tax portals, from the engine's research
    struct Portal: Decodable, Hashable { let state: String; let city: String; let name: String; let url: String; let findBy: String; let dues: String; let login: String; let conf: String }

    static let portals: [Portal] = {
        (try? JSONText.decode([Portal].self, try Engine.shared.call("portalsJSON", []))) ?? []
    }()

    static var states: [String] { Array(NSOrderedSet(array: portals.map(\.state)).array as! [String]) }

    static func portal(for state: String) -> Portal? { portals.first { $0.state == state } }

    /// the portal for a property in a city: the city's own corporation where kosh knows one (Pune's, not Mumbai's,
    /// in Maharashtra), else the state's statewide one, else the state's first. No city set: the state's first, as before
    static func portal(for state: String, city: String) -> Portal? {
        let c: String = city.lowercased().trimmingCharacters(in: .whitespaces)
        let here: [Portal] = portals.filter { $0.state == state }
        guard !c.isEmpty else { return here.first }
        // (the words that name a place: "Pimpri-Chinchwad", "Jaipur, Udaipur, Kota"; never "area", "city" or "statewide")
        let plain: Set<String> = ["area", "city", "cities", "other", "statewide", "councils", "incl"]
        let own: Portal? = here.first { p in
            p.city.lowercased().split(whereSeparator: { !$0.isLetter }).map(String.init)
                .contains { w in w.count >= 4 && !plain.contains(w) && c.contains(w) }
        }
        return own ?? here.first { $0.city.lowercased().contains("statewide") } ?? here.first
    }

    /// the portal a "State|City" key names (a property's), or a state's alone
    static func portal(key: String) -> Portal? {
        let bits: [String] = key.components(separatedBy: "|")
        return bits.count > 1 ? portal(for: bits[0], city: bits[1]) : portal(for: key)
    }

    // household
    func addPerson(name: String, rel: String) {
        let n = name.trimmingCharacters(in: .whitespaces)
        guard !n.isEmpty else { return }
        if people.isEmpty { people = [PersonInfo(id: "me", name: firstName, full: self.name.isEmpty ? "You" : self.name, rel: "You", color: Self.palette[0])] }
        var id = rel.lowercased().replacingOccurrences(of: " ", with: "")
        // (an id no one has, even after someone left: a new person never takes over another's details)
        if id.isEmpty || id == "me" || people.contains(where: { $0.id == id }) {
            var n: Int = people.count
            while people.contains(where: { $0.id == "p\(n)" }) || PasswordProfile.load(for: "p\(n)") != nil || PasswordProfile.harvested()["p\(n)"] != nil { n += 1 }
            id = "p\(n)"
        }
        people.append(PersonInfo(id: id, name: n.split(separator: " ").first.map(String.init) ?? n, full: n, rel: rel, color: Self.palette[people.count % Self.palette.count]))
        save()
    }

    /// someone leaves the household: everything that was theirs becomes yours (their inboxes, the accounts and cards
    /// filed under them, what you added for them, what was read from their mail), never left pointing at someone
    /// who isn't there; then the screens are laid out again
    func removePerson(_ id: String) {
        guard id != "me" else { return }
        // (their statement details go with them, typed and found)
        PasswordProfile.save(nil, for: id)
        var hv = PasswordProfile.harvested()
        if hv.removeValue(forKey: id) != nil { PasswordProfile.saveHarvested(hv) }
        people.removeAll { $0.id == id }
        for (k, v) in owners where v == id { owners[k] = nil }
        for i in accounts.indices where accounts[i].person == id { accounts[i].person = nil }
        for i in userPolicies.indices where userPolicies[i].owner == id { userPolicies[i].owner = "me" }
        for i in userHoldings.indices where userHoldings[i].owner == id { userHoldings[i].owner = "me" }
        for i in docHoldings.indices where docHoldings[i].owner == id { docHoldings[i].owner = "me" }
        for i in userCommittees.indices where userCommittees[i].owner == id { userCommittees[i].owner = "me" }
        for i in localDocs.indices where localDocs[i].owner == id { localDocs[i].owner = "me" }
        for i in statements.indices where statements[i].owner == id { statements[i].owner = "me" }
        for i in docDeposits.indices where docDeposits[i].owner == id { docDeposits[i].owner = "me" }
        for i in fundSegs.indices where fundSegs[i].owner == id { fundSegs[i].owner = "me" }
        for i in trades.indices where trades[i].owner == id { trades[i].owner = "me" }
        for i in readings.indices where readings[i].o == id { readings[i].o = "me" }
        for i in userTrips.indices { userTrips[i].who.removeAll { $0 == id } }
        // whose a property or committee is goes by the record and the payments, never moved to you by default: they come
        // off a joint one, and one that was theirs alone goes back to kosh working it out (the household's until it can tell)
        for i in properties.indices { properties[i].whose = WhoseSaid.without(properties[i].whose, id) }
        for i in userCommittees.indices { userCommittees[i].whose = WhoseSaid.without(userCommittees[i].whose, id) }
        save()
        rebuild()
    }

    // "You" is stored as said: without it the names on the mail (or whose inbox it came to) would decide again
    func setOwner(_ key: String, _ person: String) { owners[key] = person.isEmpty ? nil : person; save() }

    func setHidden(_ key: String, _ on: Bool) { if on { hidden.insert(key) } else { hidden.remove(key) }; save() }

    // MARK: a state's property-tax portal, read page by page as the user moves through it

    struct PortalParsed: Decodable {
        struct P: Decodable {
            let pid: String; let oldPid: String?; let owner: String?; let guardian: String?; let address: String?; let colony: String?
            let category: String?; let type: String?; let municipality: String?
            let plotArea: Double?; let plotUnit: String?; let covered: Double?; let coveredUnit: String?
            let total: Double?; let arrears: Double?; let demand: Double?; let interest: Double?; let swm: Double?; let payableTill: String?
            let taxDue: Double?; let dev: Double?; let charge: String?; let floors: Int?
            struct Floor: Decodable { let name: String; let use: String?; let area: Double?; let tenant: String? }
            let floorList: [Floor]?
        }
        let properties: [P]
    }

    /// Anything on the page that is a property's record (a PID with its owner, area, address or
    /// dues) is filed under Property, matched by PID. Returns a line per property read.
    @MainActor

    func applyPortalPage(_ text: String, state: String, portal: Portal) -> [String: String] {
        guard let out = try? Engine.shared.call("parseDocJSON", [text, "portal", ""]) else { return [:] }
        return applyPortalParsed(out, state: state, portal: portal)
    }

    /// A portal page the rules found no property on (another state's layout, say) goes to
    /// kosh-reader, if it names a property ID and shows figures. One page at a time, each page once.
    @MainActor

    func readPortalPageWithModel(_ text: String, state: String, portal: Portal) async -> [String: String] {
        guard (aiMode == "apple" && AppleBrain.available) || (aiMode == "reader" && KoshReader.available), !portalReading,
              (try? Engine.shared.call("portalWorthReading", [text])) == "yes" else { return [:] }
        let h = text.hashValue
        guard !portalAsked.contains(h) else { return [:] }
        portalAsked.insert(h)
        portalReading = true
        defer { portalReading = false }
        guard let read = await readPagesWithModel(text: text, from: portal.name, title: "Property Details", pieces: 3) else { return [:] }
        return applyPortalParsed(read, state: state, portal: portal)
    }

    @MainActor

    func applyPortalParsed(_ out: String, state: String, portal: Portal) -> [String: String] {
        guard let parsed = try? JSONText.decode(PortalParsed.self, out) else { return [:] }
        var lines: [String: String] = [:]
        for p in parsed.properties where !p.pid.isEmpty {
            let detail = !(p.owner ?? "").isEmpty || (p.total ?? 0) > 0 || (p.plotArea ?? 0) > 0 || !(p.address ?? "").isEmpty
            guard detail else { continue }
            var prop = properties.first { $0.pid == p.pid } ?? UserProperty()
            let isNew = !properties.contains { $0.id == prop.id }
            prop.pid = p.pid
            func cap(_ s: String) -> String { s.lowercased().split(separator: " ").map { $0.prefix(1).uppercased() + $0.dropFirst() }.joined(separator: " ") }
            if isNew {
                prop.state = state; prop.portalName = portal.name; prop.portalUrl = portal.url; prop.findBy = portal.findBy
                prop.city = cap(p.municipality ?? "")
                let addr = (p.address ?? "").split(separator: ",").map { $0.trimmingCharacters(in: .whitespaces) }.filter { !$0.isEmpty }
                prop.name = addr.isEmpty ? "PID " + p.pid : addr.prefix(2).joined(separator: ", ")
                prop.short = (p.colony ?? "").isEmpty ? prop.name : cap(p.colony!)
                let cat = (p.category ?? "").lowercased(), ty = (p.type ?? "").lowercased()
                prop.type = ty.contains("flat") || ty.contains("apartment") ? "Flat" : ty.contains("plot") || ty.contains("vacant") ? "Plot"
                    : cat.contains("commercial") ? (ty.contains("sco") ? "SCO" : "Shop") : cat.contains("industrial") || cat.contains("institution") ? "Other" : "House"
                prop.use = "own"
            }
            if let v = p.owner, !v.isEmpty { prop.owner = cap(v) }
            if let v = p.address, !v.isEmpty { prop.address = v }
            if let v = p.category, !v.isEmpty { prop.category = cap(v) }
            if let a = p.plotArea, a > 0 { prop.plotArea = Fmt.trim(a, 2) + " " + (p.plotUnit ?? "") }
            if let c = p.covered, c > 0 { prop.covered = Fmt.trim(c, 0) + " " + (p.coveredUnit ?? "") }
            if let v = p.oldPid, !v.isEmpty { prop.oldPid = v }
            if let v = p.arrears { prop.arrears = v }
            if let v = p.demand, v > 0 { prop.demand = v; prop.tax = v }
            if let v = p.interest { prop.interest = v }
            if let v = p.swm { prop.swm = v }
            if let v = p.total { prop.dueTotal = v }
            if let v = p.taxDue { prop.taxDue = v }
            if let v = p.dev { prop.dev = v }
            if let v = p.charge, !v.isEmpty { prop.charge = v.replacingOccurrences(of: "mortgaged to ", with: "", options: .caseInsensitive) }
            if let v = p.payableTill, !v.isEmpty { prop.payableTill = v }
            // the floors as the portal lists them, until you've set them up yourself
            if let fl = p.floorList, !fl.isEmpty,
               !prop.units.contains(where: { !$0.tenant.isEmpty || $0.rent > 0 || $0.status == "let" }) {
                prop.units = fl.map { f in
                    var u = UserUnit()
                    u.label = Self.floorName(f.name)
                    u.status = (f.use ?? "").isEmpty ? "self" : f.use
                    u.tenant = cap(f.tenant ?? "")
                    u.day = 5
                    if u.status == "let" { u.months = 11 }
                    return u
                }
                prop.floors = fl.count
            }
            // a reading a day, so the tax tab can show how the dues move
            if let total = p.total {
                let snap = TaxSnap(d: Self.today, total: total, arrears: p.arrears ?? prop.arrears ?? 0, interest: p.interest ?? prop.interest ?? 0, demand: p.demand ?? prop.demand ?? 0)
                var h = prop.taxHistory ?? []
                if h.last?.d == Self.today { h[h.count - 1] = snap } else { h.append(snap) }
                prop.taxHistory = Array(h.suffix(60))
            }
            prop.portalReadAt = Self.today
            if let i = properties.firstIndex(where: { $0.id == prop.id }) { properties[i] = prop } else { properties.append(prop) }
            if let photo = pendingPhotos[p.pid] { savePropertyPhoto(pid: p.pid, jpeg: photo) }
            lines[p.pid] = [p.pid, prop.owner ?? "", (p.total ?? 0) > 0 ? Fmt.rupees(p.total!) + " due" : ""].filter { !$0.isEmpty }.joined(separator: " · ")
        }
        if !lines.isEmpty { save(); rebuild() }
        return lines
    }

    // MARK: export, for Claude to read back here and fix the rules

    /// a step of the reading, for the diagnostics' trace (and the diagnostics written again, at most once a minute)
    func note(_ s: String) {
        let f = DateFormatter(); f.dateFormat = "HH:mm:ss"
        trace.append(f.string(from: Date()) + " " + s)
        if trace.count > 60 { trace.removeFirst(trace.count - 60) }
        keepDiagnosticsSoon()
    }

    /// The diagnostics file kept up to date in the app's own Documents, at most every three minutes after a build: the
    /// Mac that builds kosh copies it from there (devicectl, the app's data container), so the latest is always to hand
    /// without exporting by hand. Long numbers cut, as the export; nothing leaves the phone by itself.
    static let diagnosticsKept: URL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("kosh-diagnostics.json")
    private static var diagnosticsAt: Date = .distantPast
    /// The diagnostics kept for the Mac to pull, at most once a minute. What they need is taken on the main thread in
    /// a moment (still after a quiet spell on screen, no touch for 15 seconds); making them (seconds with a year of mail)
    /// is off it
    nonisolated(unsafe) static var diagnosticsWaiting = false
    func keepDiagnosticsSoon(force: Bool = false) {
        guard Date().timeIntervalSince(Self.diagnosticsAt) > 60 || force, loadedFromDisk, !records.isEmpty else { return }
        let onScreen: Bool = MainActor.assumeIsolated { UIApplication.shared.applicationState == .active }
        if onScreen && !force && CFAbsoluteTimeGetCurrent() - Interaction.shared.lastTouch < 15 {
            guard !Self.diagnosticsWaiting else { return }
            Self.diagnosticsWaiting = true
            DispatchQueue.main.asyncAfter(deadline: .now() + 15) { [weak self] in Self.diagnosticsWaiting = false; self?.keepDiagnosticsSoon() }
            return
        }
        Self.diagnosticsAt = Date()
        // (the inputs taken here in a moment; every row, shape and the last build read back off the main thread, so
        // making them never freezes the screens)
        let inputs: DiagInputs = Perf.shared.measure("diagnostics inputs") { diagnosticsInputs(fresh: force) }
        let kept: URL = Self.diagnosticsKept
        DispatchQueue.global(qos: .utility).async {
            let t0 = CFAbsoluteTimeGetCurrent()
            guard let url = Self.makeDiagnostics(inputs), let d = try? Data(contentsOf: url) else { return }
            try? d.write(to: kept, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
            Perf.shared.record("diagnostics, off screen", ms: (CFAbsoluteTimeGetCurrent() - t0) * 1000)
        }
    }

    /// What the diagnostics need from this session, taken on the main thread in a moment (copies of values); the
    /// heavy part (every email's row, the statements' shapes, the last build read back) is made off it
    final class DiagInputs: @unchecked Sendable {
        var records: [Reading] = []; var statements: [StmtDoc] = []; var plans: [String: ReadingPlan] = [:]; var trace: [String] = []
        var built: String?; var head: [String: Any] = [:]; var reading: [String: Any] = [:]; var perf: [String: Any] = [:]
    }
    /// fresh: what each locked sender needs worked out now (an export you asked for); else the last worked out, said
    /// as such (the file kept every minute: worked out here, it held the main thread for a second at 5,000 mails)
    func diagnosticsInputs(fresh: Bool = true) -> DiagInputs {
        let x = DiagInputs()
        x.records = records; x.statements = statements; x.plans = plans; x.trace = trace
        recordsLock.lock(); x.built = lastBuild; recordsLock.unlock()
        x.head = [
            "app": "kosh beta", "when": ISO8601DateFormatter().string(from: Date()),
            "build": (Bundle.main.infoDictionary?["CFBundleVersion"] as? String ?? "") + " · " + String(ReadingPrint.mail.prefix(8)),
            "accounts": allAccounts.count, "emails": records.count, "byRule": ruleCount, "byClaude": claudeRead,
            "noise": noiseCount, "waiting": waitingCount, "agree": agreeCount, "differ": differs.count,
            "payments": snapCounts.tx, "accountsFound": snapCounts.acc, "cards": snapCounts.cards,
            "docsSeen": docCount, "docsRead": docsRead, "locked": lockedDocs.count,
            "coverage": coverage.map { ["inst": $0.inst, "read": $0.rules, "missed": $0.missed] },
            // where the records are saved (the database, or records.json this launch) and what the last save wrote
            "recordStore": RecordStore.shared.summary(),
        ]
        x.reading = ["reingesting": reingesting, "scanning": running, "signedIn": signedIn]
        if Thread.isMainThread {
            MainActor.assumeIsolated {
                x.reading["catching"] = RootView.catching; x.reading["online"] = Net.shared.online
                x.reading["keepGoing"] = ["busy": KeepGoing.shared.busy, "stopped": KeepGoing.shared.stopped]
                // (what each sender's locked statements wait on, in kosh's own words: "Needs your date of birth"; never
                // a detail's value, nor the sender's hint)
                var kept: (needs: [LockedNeed], fresh: Bool)? = self.lockedNeedsKept
                if fresh { kept = (needs: self.lockedNeeds(), fresh: true) }
                x.head["lockedNeeds"] = (kept?.needs ?? []).map { (n: LockedNeed) -> [String: Any] in ["sender": n.sender, "count": n.count, "need": n.need, "hinted": !n.hint.isEmpty] }
                let are: String = kept == nil ? "not worked out yet" : (kept?.fresh == true ? "current" : "from before the latest mail")
                x.head["lockedNeedsAre"] = are
                x.head["autonote"] = UserDefaults.standard.string(forKey: "autonote.debug") ?? "none"
                x.head["crashes"] = CrashWatch.reports()
                x.head["probe3"] = self.probe2()
                x.head["probe2"] = ["lines": UserDefaults.standard.integer(forKey: "orderdoc.lines"), "none": UserDefaults.standard.integer(forKey: "orderdoc.none"), "samples": UserDefaults.standard.stringArray(forKey: "orderdoc.samples2") ?? []] as [String: Any]
                if let st = Notify.shared.store {
                    x.head["goesWith"] = st.snap.tx.filter { $0.gw != nil }.prefix(8).map { $0.m + " " + String(Int($0.a)) + " → " + ($0.gw ?? "") }
                    var kindOf: [String: String] = [:]
                    for r in self.records { kindOf[r.id] = r.kind + ":" + (r.rule ?? "") + ":" + String((r.subject ?? "").prefix(36)) }
                    let outs: [Txn] = st.snap.tx.filter { $0.k == "out" && $0.partOf == nil }
                    func shopKey(_ t: Txn) -> String { String(t.m.lowercased().filter { $0.isLetter }.prefix(5)) }
                    var sus: [[String: Any]] = []
                    let byShop: [String: [Txn]] = Dictionary(grouping: outs.filter { shopKey($0).count >= 4 }) { shopKey($0) }
                    for (_, g) in byShop where g.count > 1 {
                        let xs: [Txn] = g.sorted { $0.d < $1.d }
                        for i in 0..<xs.count { for j in (i + 1)..<xs.count where Day.between(xs[i].d, xs[j].d) <= 7 {
                            let ka: String = kindOf[xs[i].id] ?? "?", kb: String = kindOf[xs[j].id] ?? "?"
                            if !(ka.hasPrefix("confirm") || kb.hasPrefix("confirm")) { continue }
                            sus.append(["a": [xs[i].d, String(xs[i].a), xs[i].m, ka], "b": [xs[j].d, String(xs[j].a), xs[j].m, kb]])
                        } }
                    }
                    x.head["dupSuspects"] = Array(sus.prefix(60))
                    let done: Set<String> = Set(UserDefaults.standard.stringArray(forKey: AutoSplit.key) ?? [])
                    x.head["mixes"] = st.snap.tx.filter { $0.mix != nil || $0.d >= "2026-11-01" && $0.c == "Shopping" }.prefix(30).map { (t: Txn) -> [String: Any] in
                        ["d": t.d, "a": t.a, "c": t.c, "s": t.s, "wk": t.wk ?? "", "mix": t.mix.map { [$0.c, String($0.g), $0.all == true ? "all" : ""] } ?? [], "done": done.contains(t.id), "full": t.full ?? 0, "items": (st.payFact(t)?.items ?? []).prefix(8).map { String($0.n.prefix(24)) + "=" + String($0.amt ?? -1) }]
                    }
                }
                // (the papers opened that nothing could read, by sender and kind, with kosh's note on why: never the text)
                var un: [String: (n: Int, note: String)] = [:]
                for d in self.unreadDocs { let k: String = d.domain + "|" + d.kind; un[k] = ((un[k]?.n ?? 0) + 1, un[k]?.note ?? String(d.note.prefix(90))) }
                x.head["unreadDocs"] = un.map { ["sender": $0.key, "count": $0.value.n, "note": $0.value.note] }
            }
        }
        x.perf = ["lastBuildSecs": (lastBuildSecs * 100).rounded() / 100, "builds": buildsDone, "records": records.count, "tx": snapCounts.0]
        return x
    }
    /// A diagnostics file: what the rules made of each email, the ones they couldn't read, and the
    /// coverage by sender. Long numbers are cut to their last four digits; no full statement text.
    func exportForClaude() -> URL? { Self.makeDiagnostics(diagnosticsInputs()) }

    static func makeDiagnostics(_ x: DiagInputs) -> URL? {
        let records: [Reading] = x.records, statements: [StmtDoc] = x.statements, plans: [String: ReadingPlan] = x.plans, trace: [String] = x.trace
        let ud = UserDefaults.standard
        func redact(_ s: String?) -> String {
            guard let s else { return "" }
            return s.replacingOccurrences(of: #"\d[\d -]{6,}\d"#, with: "••redacted", options: .regularExpression)
        }
        let rows: [[String: Any]] = records.map { r in
            var d: [String: Any] = ["id": r.id, "kind": r.kind, "inst": r.inst ?? "", "from": r.from ?? "", "rule": r.rule ?? "", "src": r.src ?? ""]
            d["subject"] = redact(r.subject)
            if let a = r.amt { d["amt"] = a }
            if let dir = r.dir { d["dir"] = dir }
            if let dt = r.date { d["date"] = dt }
            if let l4 = r.last4, !l4.isEmpty { d["last4"] = l4 }
            if let c = r.check { d["check"] = c.status; if !c.fields.isEmpty { d["differ"] = c.fields } }
            if r.kind == "unknown", let t = r.text { d["couldNotRead"] = redact(String(t.prefix(1500))) }
            if let doc = r.doc { d["doc"] = ["kind": doc.kind, "state": doc.state, "file": doc.file] }
            // how sure, why not, which code read it, and what it holds with no typed place (names only)
            if let s = r.sure { d["sure"] = s }
            if let w = r.doubt, !w.isEmpty { d["doubt"] = w.map { redact($0) } }
            if let h = r.heldKind { d["heldKind"] = h }
            d["rp"] = r.rp ?? ""
            if (r.evs ?? "").contains("walletUse") { d["wu"] = true }
            if r.id == "1a1743f3e75a1319", let e = r.evs { d["evsTail"] = String(e.suffix(700)) }
            if let x = r.xtra, let xd = x.data(using: .utf8), let xo = (try? JSONSerialization.jsonObject(with: xd)) as? [String: Any] { d["xtra"] = xo.keys.sorted() }
            return d
        }
        var summary: [String: Any] = x.head
        summary["records"] = rows
        // which code read the mail, and how much of it is still from older code (read again in the background)
        let want: String = ReadingPrint.mail
        let stale: Int = records.count(where: { ($0.rp ?? "") != want })
        var reading: [String: Any] = ["print": want, "olderCode": stale, "docPrint": ReadingPrint.doc, "rulesVersion": Self.rulesVersion]
        reading["doneAt"] = ud.string(forKey: "beta.readPrint") ?? ""
        reading["docDoneAt"] = ud.string(forKey: "beta.docPrint") ?? ""
        reading["rulesAt"] = ud.integer(forKey: "beta.rules")
        // how much of the mail has a sealed copy on this phone (read again without the inbox), and what is under way
        reading["sealed"] = records.count(where: { MailVault.has($0.id) })
        reading["plans"] = plans.mapValues { p -> [String: Any] in ["left": p.ids?.count ?? -1, "total": p.total, "done": p.done] }
        for (k, v) in x.reading { reading[k] = v }
        reading["trace"] = trace
        if let p = plans["reingest"] {
            let left: Int = p.ids?.count ?? 0
            let plan: [String: Any] = ["left": left, "total": p.total, "done": p.done]
            reading["plan"] = plan
        }
        summary["reading"] = reading
        // what came by SMS or a notification (counts and when, never the messages), and the big emails kept cut before
        // kosh trimmed their styling: found and read whole again (refetchCutMail)
        let alertRecs = records.filter { $0.id.hasPrefix(AlertIntake.prefix) }
        summary["alerts"] = ["records": alertRecs.count, "taken": AlertIntake.count, "dropped": ud.integer(forKey: AlertIntake.droppedKey),
                             "pending": (ud.stringArray(forKey: AlertIntake.pendingKey) ?? []).count, "held": AlertIntake.heldCount,
                             "reached": ud.integer(forKey: AlertIntake.reachedKey), "empty": ud.integer(forKey: AlertIntake.emptyKey),
                             "noSender": ud.integer(forKey: AlertIntake.noSenderKey), "ran": ud.double(forKey: AlertSetup.ranKey), "contains": AlertSetup.contains,
                             "last": AlertIntake.lastAt.map { Gmail.isoStamp.string(from: $0) } ?? "",
                             "byRule": Dictionary(grouping: alertRecs, by: { $0.rule ?? "" }).mapValues(\.count),
                             "drops": ud.stringArray(forKey: AlertIntake.dropLogKey) ?? [],
                             "arrivals": ud.stringArray(forKey: AlertIntake.arrivalsKey) ?? [],
                             "verified": ud.double(forKey: AlertSetup.verifiedKey),
                             // (the pattern the shortcut matches each message against: here so rebuilding it never means guessing)
                             "filter": AlertSetup.filter] as [String: Any]
        var perf: [String: Any] = Perf.shared.summary()
        for (k, v) in x.perf { perf[k] = v }
        summary["perf"] = perf
        summary["cutMail"] = ["found": ud.integer(forKey: "beta.cutFound"), "fixed": ud.integer(forKey: "beta.cutFixed"), "done": ud.integer(forKey: "beta.cutFix")]
        // the statements: every one the mail brought and where it stands (opened, locked, waiting, an older month), the
        // pieces its sender's password is made of, and what each one opened said (its account's last four, its period,
        // its closing balance and whether its lines added up), so a net worth that looks off can be traced to the paper
        summary["statementDocs"] = records.compactMap { r -> [String: Any]? in
            guard let doc = r.doc, doc.kind == "stmt" || doc.kind == "cardstmt" || doc.kind == "cas" else { return nil }
            var o: [String: Any] = ["id": r.id, "kind": doc.kind, "state": doc.state, "from": SenderPasswords.domain(doc.from.isEmpty ? (r.from ?? "") : doc.from), "sent": String((r.sent ?? "").prefix(10))]
            o["file"] = (doc.file as NSString).pathExtension.lowercased()
            if let n = doc.note, !n.isEmpty { o["note"] = redact(n) }
            if !doc.hint.isEmpty, let out = try? Engine.shared.call("pwPartsJSON", [doc.hint]), let d = out.data(using: .utf8), let parts = try? JSONSerialization.jsonObject(with: d) { o["pwParts"] = parts }
            if doc.tried != nil { o["tried"] = true }
            return o
        }
        // (a statement's layout, as shapes only: the newest three a sender's statements each, to see how its lines are laid)
        let docOf: [String: DocRef] = Dictionary(records.compactMap { r in r.doc.map { ($0.msg, $0) } }, uniquingKeysWith: { a, _ in a })
        var shown: [String: Int] = [:]
        let newestFirst: [StmtDoc] = statements.sorted { $0.periodTo > $1.periodTo }
        var shapes: [String: Any] = [:]
        // (why a statement has no layout in the export, counted: no mail for it, its text not kept, the shape not made)
        var shapeMiss: [String: Int] = [:]
        for S in newestFirst {
            let msg: String = String(S.src.replacingOccurrences(of: "doc:", with: "").split(separator: "#").first ?? "")
            // (each sender's newest three of each kind: accounts and cards are laid out differently)
            let who: String = SenderPasswords.domain(S.from) + "|" + S.instr
            guard (shown[who] ?? 0) < 3, shapes[msg] == nil else { continue }
            guard let d = docOf[msg] else { shapeMiss["no mail", default: 0] += 1; continue }
            guard let text = MailVault.getText(Self.docTextKey(d)) ?? MailVault.getText(d.msg + "|" + d.att) else { shapeMiss["text not kept", default: 0] += 1; continue }
            do {
                let out: String = try Engine.shared.call("docShapeJSON", [text, "70"])
                guard let od = out.data(using: .utf8), let o = try? JSONSerialization.jsonObject(with: od) else { shapeMiss["shape unreadable", default: 0] += 1; continue }
                shapes[msg] = o; shown[who, default: 0] += 1
            } catch {
                shapeMiss["engine: " + String(String(describing: error).prefix(60)), default: 0] += 1
            }
        }
        summary["layoutMissing"] = shapeMiss
        /* the papers opened that nothing could read, laid out the same way (shapes only, three a sender and kind): a
           quiet month has no line with a date and an amount; one with many such lines and nothing read is a reader to
           fix */
        var unreadShown: [String: Int] = [:]
        var unreadLayouts: [[String: Any]] = []
        for r in records {
            guard let d = r.doc, d.unread == true, d.state == "read" else { continue }
            let who: String = SenderPasswords.domain(d.from.isEmpty ? (r.from ?? "") : d.from) + "|" + d.kind
            guard (unreadShown[who] ?? 0) < 3 else { continue }
            guard let text = MailVault.getText(Self.docTextKey(d)) ?? MailVault.getText(d.msg + "|" + d.att),
                  let out = try? Engine.shared.call("docShapeJSON", [text, "70"]), let od = out.data(using: .utf8),
                  let o = try? JSONSerialization.jsonObject(with: od) else { continue }
            unreadShown[who, default: 0] += 1
            var row: [String: Any] = ["sender": who, "sent": String((r.sent ?? "").prefix(10)), "layout": o]
            if let n = d.note, !n.isEmpty { row["note"] = redact(n) }
            unreadLayouts.append(row)
        }
        summary["unreadLayouts"] = unreadLayouts
        summary["statementsRead"] = statements.map { S -> [String: Any] in
            var o: [String: Any] = ["src": String(S.src.split(separator: "#").first ?? ""), "from": SenderPasswords.domain(S.from), "instr": S.instr, "last4": S.last4,
                                    "periodFrom": S.periodFrom, "periodTo": S.periodTo, "rows": S.rows.count, "owner": S.owner]
            if let v = S.close { o["close"] = v }
            if let v = S.closeDate { o["closeDate"] = v }
            if let v = S.open { o["open"] = v }
            if let v = S.ok { o["addsUp"] = v }
            // (cardbill2-4nov) a card statement's own bill, so the Mac can check it against the issuer's figures
            if let v = S.billAmt { o["bill"] = [v, S.billMin ?? 0, S.billDue ?? ""] as [Any] }
            if let n = S.note, !n.isEmpty { o["note"] = redact(n) }
            if let sh = shapes[String(S.src.replacingOccurrences(of: "doc:", with: "").split(separator: "#").first ?? "")] { o["layout"] = sh }
            return o
        }
        #if DEBUG
        // (phone-4nov-b, dev builds only, never a release) the text kosh kept from each sender's newest bank and card
        // statement, exactly as the readers get it (both readings and the grid), so the Mac bench reads what the phone
        // reads. It stays in this file on the phone until the Mac's auto-build copies it
        var texts: [[String: Any]] = []
        var seenDom = Set<String>()
        for r in records.sorted(by: { ($0.sent ?? "") > ($1.sent ?? "") }) {
            guard let d = r.doc, d.kind == "stmt" || d.kind == "cardstmt" else { continue }
            let dom = SenderPasswords.domain(d.from)
            // (cardbill3-4nov: one per card too — a bank's two cards' statements differ by the file's name before its date)
            let run: String = String(d.file.split(separator: "_").first ?? "")
            guard seenDom.insert(dom + "|" + d.kind + "|" + run).inserted, let kept = MailVault.getText(Self.docTextKey(d)), !kept.isEmpty else { continue }
            texts.append(["from": d.from, "kind": d.kind, "sent": String((r.sent ?? "").prefix(10)), "msg": d.msg, "note": d.note ?? "", "text": String(kept.prefix(400_000))])
            if texts.count >= 40 { break }
        }
        summary["stmtTexts"] = texts
        #endif
        // the last build's own account of the reading (unsure, unreconciled, missing details by kind), and the policies and
        // holdings it made, each with the mail it came from and the rule that read it (numbers cut to their last digits)
        let built: String? = x.built
        if let built, let bd = built.data(using: .utf8), let snap = (try? JSONSerialization.jsonObject(with: bd)) as? [String: Any] {
            if let h = snap["readHealth"] { summary["readHealth"] = h }
            // each bank account's balance in net worth, and where it came from (an alert, a statement, worked out)
            if let accts = snap["accounts"] as? [[String: Any]] {
                summary["balances"] = accts.map { a -> [String: Any] in
                    var o: [String: Any] = [:]
                    for k in ["bank", "last", "kind", "balance", "asOf", "owner", "lastSeen"] { if let v = a[k] { o[k] = v } }
                    if let b = a["bal"] as? [String: Any] { for k in ["src", "at", "n", "net", "check", "stale", "ok", "bad", "v"] { if let v = b[k] { o["bal." + k] = v } } }
                    if let g = a["gaps"] { o["gaps"] = g }   // (baltrust-5nov)
                    return o
                }
            }
            if let h = snap["health"] { summary["held"] = h }
            let byId: [String: Reading] = Dictionary(records.map { ($0.id, $0) }, uniquingKeysWith: { a, _ in a })
            func source(_ ids: [String]) -> [[String: Any]] {
                ids.prefix(6).compactMap { id -> [String: Any]? in
                    guard let r = byId[String(id.split(separator: "#").first ?? "")] else { return nil }
                    return ["id": r.id, "kind": r.kind, "rule": r.rule ?? "", "from": SenderPasswords.domain(r.from ?? ""), "sent": String((r.sent ?? "").prefix(10)), "sure": r.sure ?? "", "rp": r.rp ?? ""]
                }
            }
            if let pols = snap["policies"] as? [[String: Any]] {
                summary["policies"] = pols.map { p -> [String: Any] in
                    var o: [String: Any] = [:]
                    for k in ["insurer", "type", "kind", "premium", "perYear", "cover", "nextDue", "lastPaid", "missing", "gaps", "via", "source", "status", "frequency", "start", "end"] { if let v = p[k] { o[k] = v } }
                    if let no = p["policyNo"] as? String, !no.isEmpty { o["policyNo"] = "••" + String(no.suffix(4)) }
                    return o
                }
            }
            if let hold = snap["hold"] as? [[String: Any]] {
                summary["holdings"] = hold.map { h -> [String: Any] in
                    var o: [String: Any] = [:]
                    for k in ["type", "cls", "amt", "rate", "mat", "cost", "asOf", "via", "pending", "inst", "person"] { if let v = h[k] { o[k] = v } }
                    o["name"] = redact(h["bank"] as? String)
                    if let src = h["src"] as? [String] { o["mails"] = source(src) }
                    return o
                }
            }
        }
        guard let data = try? JSONSerialization.data(withJSONObject: summary, options: [.prettyPrinted, .sortedKeys]) else { return nil }
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("kosh-beta-diagnostics.json")
        try? data.write(to: url)
        return url
    }

    /// Training material for kosh-reader, the small model that will run on the phone: each money email
    /// exactly as the model will see it (long numbers already cut to the last four digits) and what the
    /// bank rules read from it. One JSON object per line. Mail that isn't about money is left out.
    func exportForTraining() -> URL? {
        var lines: [String] = []
        for r in records where r.kind != "noise" {
            guard let text = r.text, !text.isEmpty else { continue }
            let m = MailMsg(id: r.id, from: r.from ?? "", date: (r.sent ?? Self.today) + "T00:00:00Z", subject: r.subject ?? "", text: text, html: r.html ?? "")
            guard let pj = try? Engine.shared.call("localPromptJSON", [JSONText.encode(m), "1800"]),
                  let pd = pj.data(using: .utf8),
                  let p = try? JSONSerialization.jsonObject(with: pd) as? [String: Any],
                  let input = p["prompt"] as? String else { continue }
            var read: [String: Any] = ["kind": r.kind]
            func put(_ k: String, _ v: Any?) {
                if let s = v as? String, !s.isEmpty { read[k] = s }
                else if let d = v as? Double, d != 0 { read[k] = d }
            }
            put("dir", r.dir); put("amt", r.amt); put("date", r.date); put("time", r.time); put("instr", r.instr)
            put("last4", r.last4); put("inst", r.inst); put("party", r.party); put("vpa", r.vpa); put("mode", r.mode)
            put("cat", r.cat); put("sub", r.sub); put("due", r.due); put("min", r.min)
            put("insurer", r.insurer); put("ptype", r.ptype); put("premium", r.premium)
            var row: [String: Any] = ["id": r.id, "from": r.from ?? "", "sent": r.sent ?? "", "rule": r.rule ?? "", "input": input, "rules": read]
            // the rules' reading written as the answer kosh-reader learns (what it can see in the email, nothing more)
            var slim = r; slim.text = nil; slim.html = nil; slim.claude = nil
            if let out = try? Engine.shared.call("trainingLabelJSON", [JSONText.encode(slim), input]), !out.isEmpty,
               let od = out.data(using: .utf8), let label = try? JSONSerialization.jsonObject(with: od) {
                row["output"] = out
                row["label"] = label
            }
            if r.kind == "unknown" { row["reason"] = r.reason ?? "" }
            if let c = r.claude?.r { row["ai"] = ["kind": c.kind, "amt": c.amt ?? 0, "dir": c.dir ?? "", "date": c.date ?? "", "party": c.party ?? ""] }
            if let o = overrides[r.id] { row["you"] = ["c": o.c ?? "", "s": o.s ?? "", "n": o.n ?? ""] }
            if let u = r.use { row["use"] = u }
            if let d = try? JSONSerialization.data(withJSONObject: row, options: [.sortedKeys]), let s = String(data: d, encoding: .utf8) { lines.append(s) }
        }
        guard !lines.isEmpty else { return nil }
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("kosh-training-\(Self.today).jsonl")
        try? (lines.joined(separator: "\n") + "\n").data(using: .utf8)?.write(to: url, options: .atomic)
        return url
    }

    var trainingCount: Int { records.count(where: { $0.kind != "noise" && !($0.text ?? "").isEmpty }) }

    /// everything kosh beta knows, gone
    func eraseAll() {
        // Google's access ends with it, for every Gmail inbox, not just kosh's copy of the token
        for a in accounts { if let t = Keychain.get(refreshKey(a.id)) { GoogleOAuth.revoke(t) } }
        if let t = Keychain.get("google.refresh") { GoogleOAuth.revoke(t) }
        for a in accounts { Keychain.set(nil, for: refreshKey(a.id)); Keychain.set(nil, for: Self.credentialKey(config(a.id).provider, a.id, primary: false)) }
        signOut()
        setClaudeKey(nil)
        SenderPasswords.clear()
        // the sealed copies of mail and statements and their key, the details banks lock statements with, the rules
        // learned on this phone, and what the widgets show: all of it goes
        MailVault.erase()
        PasswordProfile.forgetAll()
        DetailsStore.forgetAll()
        LearnedRules.clear()
        LayoutBook.clear()
        WFStore.clear()
        Prices.shared.clear()
        FXRates.shared.clear()
        FundFees.shared.clear()
        ClaimBook.shared.reset()
        // writes still on their way finish first, so none lands after the folder is gone
        // a build of what was there before, still running, is dropped when it lands; nothing of it is kept
        buildGen &+= 1
        recordsLock.lock(); lastBuild = nil; lastNameGroups = []; recordsLock.unlock()
        flushSaves()
        // the records' database closed first, then it, its -wal and its -shm gone (the folder after them)
        RecordStore.shared.erase()
        try? FileManager.default.removeItem(at: Self.folder)
        Self.folderGone()
        MailVault.folderGone()
        KoshReader.folderGone()
        // and what lived outside the folder: the service's pass, the agent's key and its saved brief and naming, the
        // feedback notes and their screenshots, diagnostics and training exports, Lock Screen notifications and the
        // portals' cookies
        Keychain.set(nil, for: "agent.pass")
        Keychain.set(nil, for: AgentCloud.askKeyName)
        MainActor.assumeIsolated { EraseExtras.run() }
        plans = [:]; interrupted = []; readInBackground = []
        // nothing the background downloads bring back afterwards is read into the empty ledger
        MainActor.assumeIsolated { BackgroundMail.shared.cancelAll() }
        records = []; people = []; owners = [:]; hidden = []; overrides = [:]; repeatMarks = [:]; paidMarks = [:]; policyMarks = [:]; policyFill = [:]; healthElsewhere = [:]; cardLimit = [:]; payeeNames = [:]
        depFix = DepFix()
        accounts = []; userPolicies = []; userLoans = []; userHoldings = []; docHoldings = []; properties = []
        statements = []; typedBalances = [:]; docFacts = []; docDeposits = []; trades = []; fifoCost = [:]; gainsFY = [:]; discovered = []
        fundSegs = []
        // and the rest of what you set or added: trips and events, committees, EPF, papers from Files, readings,
        // policies you set aside, readings you said were wrong, how kosh counts, CRED's account
        userTrips = []; userCommittees = []; epfJobs = []; localDocs = []; readings = []; hiddenPolicies = []; rejected = [:]
        owedOpen = []; owedDone = []; owedNot = []; madeHoldings = []; lastRemoved = nil; pendingPhotos = [:]; docUnderstood = [:]
        countPrepaid = false; everyday = false; ledgerFrom = ""
        // the budgets, the plan, the briefings, what Store added and Claude's brief, CRED's account, what you said about
        // your accounts, the payees asked about, what's hushed, rung and snoozed (the profile's money bits)
        loadingProfile = true
        budget = 0; budgets = [:]; planJSON = ""; briefJSON = ""; railFrom = [:]; acctFixJSON = ""; own = MoneyBits(); moneyFromDefaults = false
        loadingProfile = false
        email = ""; name = ""; scanFrom = ""; lastScan = ""
        // every key kosh wrote in the phone's defaults, the ones just written back by the lines above included (one list:
        // KoshDefaults); the lock, Hide amounts and the tab bar stay
        KoshDefaults.erase(ud)
        phase = .idle; message = nil
        found = 0; total = 0; fetched = 0; claudeTotal = 0; claudeDone = 0
        rebuild()
    }
}


// MARK: - The trip pass: each booking's journey, for the trips kosh offers as chapters

/// one booking's journey, as trips.js reads it off the mail: a flight, train or bus from and to, a stay's town, the days
struct TripLeg: Codable, Hashable {
    var k: String?; var p: String?; var from: String?; var to: String?; var on: String?; var until: String?
    var place: String?; var ref: String?; var amt: Double?; var off: String?
    /// the day its mail came (where the payment that booked it is looked for)
    var sent: String?
}

extension LiveSession {
    static let tripDraftsOffKey = "beta.tripDraftsOff"
    static var tripLegsURL: URL { folder.appendingPathComponent("tripLegs.json") }
    /// what read the bookings: trips.js, so a change to it reads only the travel mail again (never the year's)
    static var tripPrint: String { ReadingPrint.of([("trips", "js"), ("directory", "json")], salt: "trips|1") }

    static func loadTripLegs() -> [String: TripLeg] {
        guard let d = try? Data(contentsOf: tripLegsURL), let v = try? SavedFormat.decode([String: TripLeg].self, d, .tripLegs).value else { return [:] }
        return v
    }

    /// The travel mail (what the reading marked as a trip's: a flight, a stay, a train, a bus) read for where and when,
    /// off this phone's sealed copies, a few at a time and off the main thread; once per version of trips.js
    @MainActor
    func tripPass() async {
        guard signedIn, !running, !reingesting else { return }
        if tripLegs.isEmpty { tripLegs = Self.loadTripLegs() }
        let print: String = Self.tripPrint
        let fresh: Bool = ud.string(forKey: "beta.tripPrint") != print
        let todo: [(String, String, String, String)] = records.compactMap { r -> (String, String, String, String)? in
            guard let t = r.trip, (t.k ?? "") != "cab", fresh || tripLegs[r.id] == nil else { return nil }
            return (r.id, t.k ?? "", t.p ?? "", r.sent ?? r.date ?? "")
        }
        guard !todo.isEmpty || fresh else { return }
        let got: [String: TripLeg] = await Task.detached(priority: .utility) { () -> [String: TripLeg] in
            var out: [String: TripLeg] = [:]
            for (id, k, p, sent) in todo {
                guard let m = MailVault.get(id), let s = try? Engine.shared.call("tripLegsJSON", [JSONText.encode(m), k, p]),
                      s != "null", var leg = try? JSONText.decode(TripLeg.self, s) else { continue }
                leg.sent = String(sent.prefix(10))
                out[id] = leg
            }
            return out
        }.value
        if fresh { tripLegs = [:] }
        for (k, v) in got { tripLegs[k] = v }
        let legs = tripLegs
        let url = Self.tripLegsURL
        Self.saveQueue.async { if let d = try? JSONEncoder().encode(legs) { try? SavedFormat.write(d, .tripLegs, to: url, options: [.atomic, Self.protection]) } }
        ud.set(print, forKey: "beta.tripPrint")
        note("trip pass: \(got.count) bookings read of \(todo.count) travel mails")
        rebuildSoon()
    }

    /// a draft isn't a trip: it isn't offered again
    func dropTripDraft(_ id: String) {
        var off: [String] = ud.stringArray(forKey: Self.tripDraftsOffKey) ?? []
        if !off.contains(id) { off.append(id) }
        ud.set(off, forKey: Self.tripDraftsOffKey)
        showNow("draft|" + id) { s in ShownRules.dropDraft(&s, id: id) }
        rebuildSoon(force: true)
    }
}
