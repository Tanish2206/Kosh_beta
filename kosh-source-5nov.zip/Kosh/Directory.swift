import Foundation
import SwiftUI

// MARK: - India's banks, insurers and wallets
//
// One public list, the same for everyone and shipped inside the app (directory.json): every scheduled,
// small finance, payments, regional rural and co-operative bank; every life, general and health insurer with
// its plans; and the wallets and app balances people pay from (Amazon Pay, Paytm, PhonePe, Zomato Money,
// Swiggy Money, Zepto Cash...). The engine reads it to know who a mail is from; the screens read it for each
// institution's website (its icon) and colour. Nothing about you is in it.

final class Directory: @unchecked Sendable {
    static let shared = Directory()

    /// the file as it ships, for the engine
    let json: String
    struct Entry { let names: [String]; let site: String; let color: String; let kind: String }
    private(set) var entries: [Entry] = []
    /// an app or shop people order from: the directory's merchants (Zomato, Blinkit, Swiggy and Instamart, Zepto,
    /// BigBasket…) and the big shopping apps
    struct Shop: Hashable {
        let id: String
        let name: String
        let color: String
        /// how a payee names it: its name, and its mail's domains ("grofers" is Blinkit); the longest found wins
        let words: [String]
        /// the app balance its orders can be paid from ("zomato-money"), and the category its orders usually are
        let wallet: String
        let cat: String
    }
    private(set) var shops: [Shop] = []
    /// a wallet's names ("zomato money", "swiggy money") → its id ("zomato-money")
    private(set) var walletIDs: [String: String] = [:]
    private let lock = NSLock()
    private var cache: [String: Int] = [:]   // name → index in entries, -1 for none

    private init() {
        guard let url = Bundle.main.url(forResource: "directory", withExtension: "json"),
              let data = try? Data(contentsOf: url), let text = String(data: data, encoding: .utf8) else { json = "{}"; return }
        json = text
        guard let root = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] else { return }
        func list(_ key: String, kind: String) {
            for x in root[key] as? [[String: Any]] ?? [] {
                let site = Self.host(x["site"] as? String ?? "")
                if site.isEmpty { continue }
                var names = [x["name"] as? String ?? "", x["short"] as? String ?? ""]
                names += x["aliases"] as? [String] ?? []
                entries.append(Entry(names: names.map(Self.key).filter { $0.count >= 3 }, site: site, color: x["color"] as? String ?? "", kind: kind))
            }
        }
        // banks before wallets: "Airtel Payments Bank" is the bank; "Airtel Payments Bank Wallet" still matches it
        list("insurers", kind: "insurer")
        list("banks", kind: "bank")
        list("wallets", kind: "wallet")
        list("intermediaries", kind: "broker")
        // the shops: each in its own colour, or its wallet's; Swiggy's Instamart is an app of its own to whoever orders
        var walletColor: [String: String] = [:]
        for w in root["wallets"] as? [[String: Any]] ?? [] {
            guard let id = w["id"] as? String else { continue }
            walletColor[id] = w["color"] as? String ?? ""
            for n in [w["name"] as? String ?? "", w["short"] as? String ?? ""] where !n.isEmpty && walletIDs[Self.key(n)] == nil {
                walletIDs[Self.key(n)] = id
            }
        }
        for m in root["merchants"] as? [[String: Any]] ?? [] {
            guard let id = m["id"] as? String, let name = m["name"] as? String else { continue }
            let wallet: String = m["wallet"] as? String ?? ""
            let own: String = Self.shopColors[id] ?? walletColor[wallet] ?? ""
            let color: String = own.count == 7 ? own : "#8E8E93"
            var words: [String] = [Self.key(name)]
            for d in m["domains"] as? [String] ?? [] {
                let stem: String = Self.key(String(Self.host(d).split(separator: ".").first ?? ""))
                if stem.count >= 4 && !words.contains(stem) { words.append(stem) }
            }
            if let im = m["instamart"] as? [String: Any] {
                words.removeAll { $0 == "instamart" }
                shops.append(Shop(id: "instamart", name: "Instamart", color: Self.shopColors["instamart"] ?? color, words: ["instamart"],
                                  wallet: wallet, cat: im["cat"] as? String ?? "Groceries"))
            }
            shops.append(Shop(id: id, name: name, color: color, words: words, wallet: wallet, cat: m["cat"] as? String ?? ""))
        }
        for x in Self.shoppingApps where !shops.contains(where: { $0.id == x.id }) { shops.append(x) }
    }

    /// the shops' own colours, where the wallet's isn't theirs (Blinkit is paid from Zomato Money but is yellow)
    static let shopColors: [String: String] = ["blinkit": "#F8CB46", "zepto": "#5B1A99", "bigbasket": "#84C225"]
    /// the shopping apps whose receipts kosh doesn't read, known by the payee alone
    static let shoppingApps: [Shop] = [
        Shop(id: "amazon", name: "Amazon", color: "#FF9900", words: ["amazon", "amzn"], wallet: "", cat: "Shopping"),
        Shop(id: "flipkart", name: "Flipkart", color: "#2874F0", words: ["flipkart"], wallet: "", cat: "Shopping"),
        Shop(id: "myntra", name: "Myntra", color: "#FF3F6C", words: ["myntra"], wallet: "", cat: "Shopping"),
        Shop(id: "nykaa", name: "Nykaa", color: "#FC2779", words: ["nykaa"], wallet: "", cat: "Shopping"),
        Shop(id: "ajio", name: "AJIO", color: "#2C4152", words: ["ajio"], wallet: "", cat: "Shopping"),
        Shop(id: "meesho", name: "Meesho", color: "#9F2089", words: ["meesho", "fashnear"], wallet: "", cat: "Shopping"),
        Shop(id: "jiomart", name: "JioMart", color: "#0078AD", words: ["jiomart"], wallet: "", cat: "Groceries"),
    ]
    /// shop names that are everyday words too: they count only for a payment in the shop's own category
    static let commonWords: Set<String> = ["district"]

    /// the shop a payment went to: by its payee ("SWIGGY INSTAMART" is Instamart, "Grofers" is Blinkit); or, paid
    /// from an app's own balance with a restaurant's name on it, the app that balance belongs to (Zomato Money for
    /// food is Zomato, for groceries Blinkit). `wallet` is the balance it was paid from, if it was.
    func shop(payee: String, wallet: String, cat: String) -> Shop? {
        let k: String = Self.key(payee)
        if !k.isEmpty {
            let padded: String = " " + k + " "
            let tokens: [Substring] = k.split(separator: " ")
            var best: Shop? = nil
            var bestLen: Int = 0
            for s in shops {
                for w in s.words where w.count > bestLen {
                    let whole: Bool = padded.contains(" " + w + " ")
                    let joined: Bool = !w.contains(" ") && w.count >= 5 && tokens.contains { $0.hasPrefix(w) }
                    if !whole && !joined { continue }
                    if Self.commonWords.contains(w) && cat != s.cat { continue }
                    // Amazon Pay is a wallet and a bill counter; only a shopping payment there is an Amazon order
                    if s.id == "amazon" && (padded.contains(" amazon pay") || padded.contains(" amazonpay")) && cat != s.cat { continue }
                    best = s
                    bestLen = w.count
                }
            }
            if let best { return best }
        }
        guard !wallet.isEmpty, let wid = walletIDs[Self.key(PaidWith.walletKey(wallet))] ?? walletIDs[Self.key(wallet)] else { return nil }
        let linked: [Shop] = shops.filter { $0.wallet == wid }
        return linked.first { $0.cat == cat } ?? (linked.count == 1 ? linked.first : nil)
    }

    static func host(_ s: String) -> String {
        var h = s.lowercased().trimmingCharacters(in: .whitespaces)
        for p in ["https://", "http://", "www."] where h.hasPrefix(p) { h = String(h.dropFirst(p.count)) }
        if let slash = h.firstIndex(of: "/") { h = String(h[..<slash]) }
        return h.contains(".") ? h : ""
    }
    static func key(_ name: String) -> String {
        name.lowercased().replacingOccurrences(of: "[^a-z0-9 ]", with: " ", options: .regularExpression)
            .split(separator: " ").joined(separator: " ")
    }

    /// the institution a name belongs to: the longest of its names found whole in it
    /// ("Zomato Money" → Zomato Money, "Ujjivan SFB A/c" → Ujjivan Small Finance Bank via its short name)
    func entry(for name: String) -> Entry? {
        lock.lock(); defer { lock.unlock() }
        if let i = cache[name] { return i >= 0 ? entries[i] : nil }
        let n = " " + Self.key(name) + " "
        var best: (Int, Int)?
        for (i, e) in entries.enumerated() {
            for k in e.names where n.contains(" " + k + " ") && k.count > (best?.1 ?? 0) { best = (i, k.count) }
        }
        cache[name] = best?.0 ?? -1
        return best.map { entries[$0.0] }
    }
    func site(for name: String) -> String? { entry(for: name)?.site }
    func color(for name: String) -> Color? {
        guard let c = entry(for: name)?.color, c.count == 7 else { return nil }
        return Color(hex: c)
    }
}
