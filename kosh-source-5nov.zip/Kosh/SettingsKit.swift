import SwiftUI

// MARK: - The settings kit: one way to draw a settings page
//
// Every Settings page and sub-page is drawn from these few parts, so they read as one calm system at any text size:
//
// - one title style (body, primary), one value style (body, secondary, digits that line up), one caption style
//   (footnote, secondary, a few words, never louder than the value)
// - an inset grouped list on a warm off-white page, rows at least 44 pt tall, each led by the same mark: a small
//   circle washed in the row's colour with the glyph in its ink (`SettingsTile`), never a bare line icon beside one
// - a page may open with a two-tone header (a bold word and a muted phrase) and two status tiles, tinted only when
//   they carry a state (pale green: fine; pale orange: needs you)
// - a value on the right that never truncates (the title wraps first), a chevron only when the row goes somewhere
// - section headers a small semibold label, sentence case (never all caps); footers short
// - colour only for meaning: orange is "this needs you", green "done", red "couldn't"
// - SF Pro everywhere: numbers use `.monospacedDigit()`, never the typewriter design
//
// Built for Settings (28 Oct), written so any other screen can adopt it.

// MARK: Type

enum SettingsType {
    /// a row's name
    static let title: Font = .body
    /// what a row is set to, or holds
    static let value: Font = .body
    /// a few words under a title or a figure
    static let caption: Font = .footnote
}

// MARK: Tile

/// the one mark every settings row leads with: a small circle washed in its colour, the glyph in that colour's ink,
/// 30 pt at the default text size, growing with it a little but never past 38 pt
struct SettingsTile: View {
    let symbol: String
    let color: Color
    @ScaledMetric(relativeTo: .body) private var scaled: CGFloat = 30
    @Environment(\.colorScheme) private var scheme
    var body: some View {
        let side: CGFloat = min(max(scaled, 30), 38)
        let ink: Color = scheme == .dark ? color.mix(with: .white, by: 0.3) : color.mix(with: .black, by: 0.15)
        let wash: Color = scheme == .dark ? color.opacity(0.26) : color.mix(with: .white, by: 0.84)
        Image(systemName: symbol)
            .font(.system(size: side * 0.46, weight: .semibold))
            .symbolRenderingMode(.monochrome)
            .foregroundStyle(ink)
            .frame(width: side, height: side)
            .background(wash, in: Circle())
            .accessibilityHidden(true)
    }
}

// MARK: Rows

/// one settings row: a tile, a title (and an optional caption of a few words), and what it's set to on the right.
/// Put it inside a NavigationLink for the chevron, a Button for an action, or alone for a fact. The value never
/// truncates: the title and caption wrap first, and at the accessibility text sizes the value moves under the title.
struct SettingsRow: View {
    var symbol: String = ""
    var color: Color = Color.kosh
    let title: String
    var caption: String = ""
    var value: String = ""
    /// the value needs you: drawn as a small orange badge instead of grey text
    var alert: Bool = false
    /// the value is money or a number: hidden with the amounts (the title stays)
    var sensitive: Bool = false
    @Environment(\.dynamicTypeSize) private var type

    var body: some View {
        let stacked: Bool = type.isAccessibilitySize
        HStack(spacing: 12) {
            if !symbol.isEmpty { SettingsTile(symbol: symbol, color: color) }
            let layout: AnyLayout = stacked ? AnyLayout(VStackLayout(alignment: .leading, spacing: 4)) : AnyLayout(HStackLayout(spacing: 8))
            layout {
                VStack(alignment: .leading, spacing: 2) {
                    Text(title).font(SettingsType.title).foregroundStyle(Color.primary)
                        .fixedSize(horizontal: false, vertical: true)
                    if !caption.isEmpty {
                        Text(caption).font(SettingsType.caption).foregroundStyle(.secondary)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                }
                if !stacked { Spacer(minLength: 4) }
                SettingsValue(text: value, alert: alert)
                    .privacySensitive(sensitive)
            }
        }
        .frame(minHeight: 44)
        .contentShape(Rectangle())
    }
}

/// what a row holds, on its right: secondary text that never truncates, or a small orange badge when it needs you
struct SettingsValue: View {
    let text: String
    var alert: Bool = false
    var body: some View {
        if text.isEmpty {
            EmptyView()
        } else if alert {
            SettingsBadge(text: text)
        } else {
            Text(text).font(SettingsType.value).foregroundStyle(.secondary).monospacedDigit()
                .lineLimit(1).fixedSize()
        }
    }
}

/// a small solid badge for what waits on you ("3 locked"): white on orange, the way iOS marks what needs you
struct SettingsBadge: View {
    let text: String
    var tint: Color = Color.orange
    var body: some View {
        Text(text)
            .font(.footnote.weight(.semibold)).monospacedDigit()
            .foregroundStyle(Color.white)
            .padding(.horizontal, 8).padding(.vertical, 2)
            .background(tint, in: Capsule())
            .lineLimit(1).fixedSize()
    }
}

/// a fact with a quiet copy button: a title (and a caption), the value in SF digits, and the copy glyph last
struct SettingsCopyRow: View {
    let title: String
    var caption: String = ""
    let value: String
    var copy: (() -> Void)? = nil
    var body: some View {
        HStack(spacing: 10) {
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(SettingsType.title)
                if !caption.isEmpty { Text(caption).font(SettingsType.caption).foregroundStyle(.secondary) }
            }
            Spacer(minLength: 8)
            Text(value).font(SettingsType.value).monospacedDigit().foregroundStyle(.secondary).lineLimit(1).fixedSize()
            if let copy { SettingsCopyButton(label: title, action: copy) }
        }
        .frame(minHeight: 44)
    }
}

/// the copy glyph at the end of a row: quiet, tappable at 44 pt, never louder than the value beside it
struct SettingsCopyButton: View {
    let label: String
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            Image(systemName: "doc.on.doc")
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .frame(minWidth: 32, minHeight: 44)
                .contentShape(Rectangle())
        }
        .buttonStyle(.borderless)
        .accessibilityLabel("Copy " + label)
    }
}

// MARK: Headers

/// a section's header: a small semibold label in sentence case, and a muted action on the right when there is one
/// ("See all")
struct SettingsHeader: View {
    let text: String
    var action: String = ""
    var tap: (() -> Void)? = nil
    init(_ text: String, action: String = "", tap: (() -> Void)? = nil) { self.text = text; self.action = action; self.tap = tap }
    var body: some View {
        HStack(alignment: .firstTextBaseline) {
            Text(text)
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(Color.primary)
            Spacer(minLength: 8)
            if let tap, !action.isEmpty {
                Button(action, action: tap)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .buttonStyle(.press)
            }
        }
        .textCase(nil)
    }
}

// MARK: The page's head

/// a page's two-tone head: a tiny status line over a big bold word and a muted phrase beside it ("Settings", "mail
/// read 9:40 AM"). Sits as the list's first row, on the page itself (no card).
struct SettingsHero: View {
    var over: String = ""
    let title: String
    var muted: String = ""
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            if !over.isEmpty {
                Text(over).font(SettingsType.caption.weight(.medium)).foregroundStyle(.secondary)
            }
            (Text(title).foregroundStyle(Color.primary) + Text(muted.isEmpty ? "" : " " + muted).foregroundStyle(.secondary))
                .font(.largeTitle.weight(.bold))
                .fixedSize(horizontal: false, vertical: true)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .listRowBackground(Color.clear)
        .listRowSeparator(.hidden)
        .listRowInsets(EdgeInsets(top: 4, leading: 4, bottom: 4, trailing: 4))
        .accessibilityElement(children: .combine)
    }
}

/// a status tile: a small label top left, an arrow top right, a big figure with a small unit, and one muted word
/// under it. Tinted only when it carries a state: pale green when all is well, pale orange when it needs you.
struct SettingsStatusTile: View {
    enum Mood { case calm, fine, needs }
    let label: String
    let figure: String
    var unit: String = ""
    var word: String = ""
    var mood: Mood = .calm
    @Environment(\.colorScheme) private var scheme
    var body: some View {
        let tint: Color? = mood == .fine ? Color.green : mood == .needs ? Color.orange : nil
        let fill: Color = tint.map { scheme == .dark ? $0.opacity(0.18) : $0.mix(with: .white, by: 0.88) } ?? Color(uiColor: .secondarySystemGroupedBackground)
        VStack(alignment: .leading, spacing: 6) {
            HStack(alignment: .firstTextBaseline) {
                Text(label).font(SettingsType.caption.weight(.medium)).foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
                Spacer(minLength: 4)
                Image(systemName: "arrow.up.right").font(.caption.weight(.semibold)).foregroundStyle(.tertiary)
            }
            HStack(alignment: .firstTextBaseline, spacing: 4) {
                Text(figure).font(.title.weight(.bold)).monospacedDigit().foregroundStyle(Color.primary)
                    .lineLimit(1).minimumScaleFactor(0.6)
                if !unit.isEmpty { Text(unit).font(SettingsType.caption).foregroundStyle(.secondary).lineLimit(1) }
            }
            if !word.isEmpty {
                Text(word).font(SettingsType.caption).foregroundStyle(tint.map { scheme == .dark ? $0 : $0.mix(with: .black, by: 0.25) } ?? Color.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .padding(16)
        .frame(maxWidth: .infinity, minHeight: 112, alignment: .topLeading)
        .background(fill, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
        .shadow(color: Color.black.opacity(scheme == .dark ? 0 : 0.04), radius: 10, y: 3)
        .contentShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
    }
}

// MARK: A switch with its time

/// a switch that rings at a time: the tile, the title, the time as a compact picker beside the switch (shown only
/// while it's on), so on and when sit on one row. At the largest text sizes the time moves under the title.
struct TimedToggleRow: View {
    let symbol: String
    let color: Color
    let title: String
    @Binding var on: Bool
    let at: Binding<Date>
    @Environment(\.dynamicTypeSize) private var type

    var body: some View {
        let stacked: Bool = type.isAccessibilitySize
        HStack(spacing: 12) {
            SettingsTile(symbol: symbol, color: color)
            VStack(alignment: .leading, spacing: 6) {
                Text(title).font(SettingsType.title).fixedSize(horizontal: false, vertical: true)
                if stacked && on { picker }
            }
            Spacer(minLength: 4)
            if !stacked && on { picker }
            Toggle(title, isOn: $on.animation(Motion.base)).labelsHidden()
        }
        .frame(minHeight: 44)
    }

    var picker: some View {
        DatePicker(title + " at", selection: at, displayedComponents: .hourAndMinute)
            .labelsHidden()
            .fixedSize()
            .transition(.opacity)
    }
}

// MARK: A field with its button

/// one detail to type and the action it feeds: a rounded, filled field with the keyboard that suits it and the
/// primary button inline after it (under it, at the largest text sizes)
struct SettingsField: View {
    let placeholder: String
    @Binding var text: String
    var keyboard: UIKeyboardType = .default
    var caps: TextInputAutocapitalization = .never
    var secure: Bool = false
    var content: UITextContentType? = nil
    let button: String
    var busy: Bool = false
    var enabled: Bool = true
    let action: () -> Void
    @Environment(\.dynamicTypeSize) private var type

    var body: some View {
        let layout: AnyLayout = type.isAccessibilitySize ? AnyLayout(VStackLayout(alignment: .leading, spacing: 8)) : AnyLayout(HStackLayout(spacing: 8))
        layout {
            field
                .font(.body).monospacedDigit()
                .textInputAutocapitalization(caps)
                .autocorrectionDisabled()
                .keyboardType(keyboard)
                .textContentType(content)
                .submitLabel(.go)
                .onSubmit { if enabled && !busy { action() } }
                .padding(.horizontal, 12)
                .frame(minHeight: 44)
                .background(Color(.tertiarySystemFill), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
            Button(action: action) {
                ZStack {
                    // (the label keeps its width while it works, so the field never jumps)
                    Text(button).opacity(busy ? 0 : 1)
                    if busy { ProgressView().tint(Color.onKosh) }
                }
                .font(.body.weight(.semibold))
                .padding(.horizontal, 14)
                .frame(minHeight: 44)
            }
            .buttonStyle(.borderedProminent)
            .buttonBorderShape(.capsule)
            .tint(Color.koshFill)
            .foregroundStyle(Color.onKosh)
            .disabled(!enabled || busy)
        }
    }

    @ViewBuilder var field: some View {
        if secure { SecureField(placeholder, text: $text) } else { TextField(placeholder, text: $text) }
    }
}

// MARK: Progress in parts

/// one figure split into parts, as a single bar: each part its own colour, in proportion, with a one-line legend
/// under it (wrapping onto two lines at large text). A part with nothing is left out of both.
struct SegmentBar: View {
    struct Part: Identifiable {
        let id: String
        let count: Int
        let color: Color
        /// the legend's words after the count: "opened", "locked"
        let label: String
    }
    let parts: [Part]
    var height: CGFloat = 8

    var body: some View {
        let shown: [Part] = parts.filter { $0.count > 0 }
        let total: Int = max(1, shown.reduce(0) { $0 + $1.count })
        VStack(alignment: .leading, spacing: 10) {
            GeometryReader { g in
                let gaps: CGFloat = CGFloat(max(0, shown.count - 1)) * 2
                let room: CGFloat = max(0, g.size.width - gaps)
                HStack(spacing: 2) {
                    ForEach(shown) { (p: Part) in
                        Rectangle().fill(p.color)
                            .frame(width: max(height * 0.75, room * CGFloat(p.count) / CGFloat(total)))
                    }
                }
                .frame(width: g.size.width, alignment: .leading)
                .clipShape(Capsule())
            }
            .frame(height: height)
            ViewThatFits(in: .horizontal) {
                HStack(spacing: 14) { ForEach(shown) { (p: Part) in key(p) } }
                LazyVGrid(columns: [GridItem(.flexible(), alignment: .leading), GridItem(.flexible(), alignment: .leading)],
                          alignment: .leading, spacing: 6) {
                    ForEach(shown) { (p: Part) in key(p) }
                }
            }
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(shown.map { String($0.count) + " " + $0.label }.joined(separator: ", "))
    }

    func key(_ p: Part) -> some View {
        HStack(spacing: 5) {
            Circle().fill(p.color).frame(width: 7, height: 7)
            (Text(String(p.count)).monospacedDigit().foregroundStyle(Color.primary) + Text(" " + p.label).foregroundStyle(.secondary))
                .font(SettingsType.caption)
                .lineLimit(1)
        }
    }
}

// MARK: Why?

/// the words behind a short line, folded away until asked for ("Why?")
struct SettingsWhy: View {
    let text: String
    var title: String = "Why?"
    @State private var open: Bool = false
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Button {
                withAnimation(Motion.fold(!open)) { open.toggle() }
            } label: {
                HStack(spacing: 4) {
                    Text(title)
                    Image(systemName: "chevron.down").font(.caption2.weight(.semibold))
                        .rotationEffect(.degrees(open ? 180 : 0))
                }
                .font(SettingsType.caption.weight(.medium))
                .foregroundStyle(Color.kosh)
                .frame(minHeight: 32)
                .contentShape(Rectangle())
            }
            .buttonStyle(.press)
            .accessibilityHint(open ? "Hides the email’s words" : "Shows the email’s words")
            if open {
                Text(text)
                    .font(SettingsType.caption).foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
                    .transition(.opacity.combined(with: .move(edge: .top)))
            }
        }
    }
}

// MARK: The page

extension View {
    /// a settings page: inset grouped on the warm page, air between groups, titled inline, rows at least 44 pt
    func settingsPage(_ title: String) -> some View {
        self
            .listStyle(.insetGrouped)
            .listSectionSpacing(24)
            .scrollContentBackground(.hidden)
            .background(Color.settingsPage.ignoresSafeArea())
            .environment(\.defaultMinListRowHeight, 44)
            .navigationTitle(title)
            .navigationBarTitleDisplayMode(.inline)
    }
}

extension Color {
    /// the settings page: a warm off-white by day (white cards sit on it without a border), black by night
    static let settingsPage = Color(light: Color(hex: "#F6F5F1"), dark: Color.black)
}
