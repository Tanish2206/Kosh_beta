import SwiftUI

// MARK: - Tenants as a street at dusk
//
// The top tile is the street (drawn in isometric, TenantsIso.swift): one building per property, its windows lit warm
// when this month's rent is in, glowing red when it's late and dim while it's still to come. The family's floors are
// blue and an empty floor has its shutter down. Properties in more than one state float as islands, one per state.
// Tap an island to fly to it, tap a building to fly in to it; the back pill (and the button under the details)
// flies back out. What sits under the tile follows the camera (TenantsRent.swift): this month's rent for the
// street, then a state's, then the building's own tenants.

/// the street's colours: a dusk sky, the buildings in its shadow, and the lights
enum Dusk {
    static let sky: [Gradient.Stop] = [
        .init(color: Color(hex: "#1B1A47"), location: 0), .init(color: Color(hex: "#2B2560"), location: 0.42),
        .init(color: Color(hex: "#5A3A72"), location: 0.72), .init(color: Color(hex: "#A4566A"), location: 1),
    ]
    static let gold = Color(hex: "#FFD66B")
    static let red = Color(hex: "#FF6B57")
    static let amber = Color(hex: "#FFB04D")
    static let blue = Color(hex: "#A9C1FF")
    static let peach = Color(hex: "#FFD9A8")
    static let lilac = Color(hex: "#E6E1F5")
    static let mist = Color(hex: "#C9C2E6")
    static let moon = Color(hex: "#FFF1C9")
    static let shutter = Color(hex: "#463D66")
    static let slat = Color(hex: "#5A5078")
    static func pick(_ s: String, _ n: Int) -> Int {
        var h: Int = 0
        for c in s.unicodeScalars { h = (h &* 31 &+ Int(c.value)) & 0xFFFF }
        return h % max(1, n)
    }
}

/// how a window is lit
enum StreetLight: Equatable {
    /// this month's rent is in; late; due within its grace; not due yet (or no rent this month); the family's;
    /// empty, to let; a neighbour's window, not yours
    case paid, late, due, waiting, family, empty, neighbour

    static func of(_ u: PropUnit) -> StreetLight {
        switch Street.use(u) {
        case "self": return .family
        case "vacant": return .empty
        default:
            switch u.now?.st ?? "" {
            case "booked": return .paid
            case "late": return .late
            case "due": return .due
            default: return .waiting
            }
        }
    }
}

/// a property drawn on the street: its floors, top first, each a row of windows
struct StreetHouse: Identifiable {
    struct Window: Identifiable {
        let id: String
        /// the tenant, when the floor is let out
        let tenant: TenantsView.Let?
        let u: PropUnit?
        let light: StreetLight
        /// a shop front (an awning over the glass) rather than a home's window
        let shop: Bool
    }
    struct Floor: Identifiable {
        let level: Int
        let windows: [Window]
        var id: Int { level }
    }
    let p: Prop
    let kind: BuildingArt.Kind
    let floors: [Floor]
    /// floors above the ones drawn
    let more: Int
    /// its tenants, late first
    let lets: [TenantsView.Let]
    var id: String { Street.id(p) }
    var windows: [Window] { floors.flatMap { $0.windows } }
    /// floors it has to let, drawn or not
    var empty: [PropUnit] { p.units.filter { Street.use($0) == "vacant" } }
}

enum Street {
    static func id(_ p: Prop) -> String { p.pid + "|" + (p.uid ?? "") }
    static func use(_ u: PropUnit) -> String { u.status ?? (u.tenant.isEmpty ? "vacant" : "let") }
    static func name(_ p: Prop) -> String { p.short.isEmpty ? p.name : p.short }

    /// what came in for a month: the credit kosh matched, or the rent when you marked it
    static func got(_ n: RollMonth) -> Double {
        guard n.st == "booked" else { return 0 }
        let a: Double = n.fromAmt ?? 0
        return n.got != "marked" && a > 0 ? a : n.amt
    }

    /// the buildings on the street: every property with a floor let out or to let, shop complexes first, then
    /// houses, then the rest, each kind in the order you added them
    static func houses(_ P: PropertyBook) -> [StreetHouse] {
        let shown: [(Int, Prop)] = P.props.enumerated().filter { _, p in
            p.units.contains { use($0) == "let" || use($0) == "vacant" }
        }.map { ($0.offset, $0.element) }
        let ordered: [(Int, Prop)] = shown.sorted { a, b in
            let ra: Int = rank(a.1), rb: Int = rank(b.1)
            return ra != rb ? ra < rb : a.0 < b.0
        }
        return ordered.map { build($0.1) }
    }
    static func rank(_ p: Prop) -> Int {
        switch BuildingArt.kind(p) {
        case .shop: return 0
        case .house: return 1
        default: return 2
        }
    }

    // MARK: states

    /// the state a property is in, as its tax portal has it ("" when it isn't set)
    static func state(_ p: Prop) -> String { (p.state ?? "").trimmingCharacters(in: .whitespaces) }
    static func stateName(_ s: String) -> String { s.isEmpty ? "State not set" : s }
    static let plates: [String: String] = [
        "Andhra Pradesh": "AP", "Assam": "AS", "Bihar": "BR", "Chandigarh": "CH", "Chhattisgarh": "CG", "Delhi": "DL", "Goa": "GA",
        "Gujarat": "GJ", "Haryana": "HR", "Himachal Pradesh": "HP", "Jammu & Kashmir": "JK", "Jharkhand": "JH", "Karnataka": "KA",
        "Kerala": "KL", "Madhya Pradesh": "MP", "Maharashtra": "MH", "Odisha": "OD", "Puducherry": "PY", "Punjab": "PB",
        "Rajasthan": "RJ", "Tamil Nadu": "TN", "Telangana": "TG", "Uttar Pradesh": "UP", "Uttarakhand": "UK", "West Bengal": "WB",
    ]
    /// a state's letters on a number plate: HR, MH; for one kosh doesn't know, its initials
    static func plate(_ s: String) -> String {
        if let p = plates[s] { return p }
        let words: [Substring] = s.split(separator: " ").filter { $0 != "&" && $0.lowercased() != "and" }
        if words.count >= 2 { return words.prefix(2).map { String($0.prefix(1)) }.joined().uppercased() }
        return s.isEmpty ? "··" : String(s.prefix(2)).uppercased()
    }

    // MARK: how the rent stands

    /// a line for a set of tenants: "2 late", "1 due", "All in"
    static func status(_ lets: [TenantsView.Let]) -> (String, Color) {
        let late: Int = lets.filter { $0.u.now?.st == "late" }.count
        let due: Int = lets.filter { $0.u.now?.st == "due" }.count
        let owed: [TenantsView.Let] = lets.filter { $0.u.now != nil }
        if late > 0 { return (String(late) + " late", RentInk.lateDeep) }
        if due > 0 { return (String(due) + " due", RentInk.dueDeep) }
        if !owed.isEmpty && owed.allSatisfy({ $0.u.now?.st == "booked" }) { return ("All in", RentInk.goodDeep) }
        return ("Nothing due", RentInk.grey)
    }
    /// the same as a light on the dusk tile: red with a late rent, amber with one due, gold when every rent is in
    static func dot(_ lets: [TenantsView.Let]) -> Color {
        let owed: [TenantsView.Let] = lets.filter { $0.u.now != nil }
        if owed.contains(where: { $0.u.now?.st == "late" }) { return Dusk.red }
        if owed.contains(where: { $0.u.now?.st == "due" }) { return Dusk.amber }
        if !owed.isEmpty && owed.allSatisfy({ $0.u.now?.st == "booked" }) { return Dusk.gold }
        return Color.white.opacity(0.45)
    }

    /// what VoiceOver says for a building: who's late, or how it stands
    static func say(_ h: StreetHouse) -> String {
        let late: [TenantsView.Let] = h.lets.filter { $0.u.now?.st == "late" }
        var s: String = name(h.p) + ": "
        if !late.isEmpty {
            s += late.map { l -> String in
                let who: String = NudgeWords.name(l.u)
                return (who.isEmpty ? l.u.label : who) + " late"
            }.joined(separator: ", ")
        } else if h.lets.isEmpty {
            s += "nothing let out"
        } else {
            s += status(h.lets).0.lowercased()
        }
        return s
    }

    // MARK: floors

    static let ordinals: [(String, Int)] = [("first", 1), ("second", 2), ("third", 3), ("fourth", 4), ("fifth", 5), ("sixth", 6),
                                            ("seventh", 7), ("eighth", 8), ("ninth", 9), ("tenth", 10)]
    /// which floor a unit is on: from its name ("Ground floor", "Shop 3, first floor", "2nd floor", "Flat 302"), else
    /// a shop on the ground and a home's floors in the order they were added
    static func level(_ label: String, index: Int, shop: Bool, flats: Bool) -> Int {
        let l: String = label.lowercased()
        if l.contains("ground") || l.contains("basement") || l.hasPrefix("gf") || l.contains(" gf") { return 0 }
        for (w, n) in ordinals where l.contains(w + " floor") || l.contains(w + " fl") || l == w { return n }
        if let r = l.range(of: "\\d+\\s*(st|nd|rd|th)?\\s*(floor|fl)", options: .regularExpression),
           let d = l[r].range(of: "\\d+", options: .regularExpression), let n = Int(l[r][d]) { return min(n, 40) }
        if let r = l.range(of: "floor\\s*\\d+", options: .regularExpression),
           let d = l[r].range(of: "\\d+", options: .regularExpression), let n = Int(l[r][d]) { return min(n, 40) }
        if flats, let r = l.range(of: "\\d{3,4}", options: .regularExpression), let n = Int(l[r]) { return min(n / 100, 40) }
        return shop ? 0 : max(0, index)
    }

    /// a shop rather than a home: by its name, or a shop complex's floor that isn't named as a floor
    static func isShop(_ p: Prop, _ u: PropUnit) -> Bool {
        let l: String = u.label.lowercased()
        if l.contains("shop") || l.contains("booth") || l.contains("showroom") || l.contains("kiosk") { return true }
        return BuildingArt.kind(p) == .shop && !l.contains("floor")
    }

    /// a unit's short name on a tag or a badge: a shop's number ("S3"), a flat's ("302"), else its floor ("G", "1F")
    static func badge(_ p: Prop, _ u: PropUnit) -> String {
        let i: Int = u.idx ?? p.units.firstIndex(where: { $0.id == u.id }) ?? 0
        if isShop(p, u) {
            if let r = u.label.range(of: #"\d+"#, options: .regularExpression) { return "S" + String(u.label[r]) }
            return "S" + String(i + 1)
        }
        if let r = u.label.range(of: #"\d{3,4}"#, options: .regularExpression) { return String(u.label[r]) }
        let lv: Int = level(u.label, index: i, shop: false, flats: BuildingArt.kind(p) == .flats)
        return lv == 0 ? "G" : String(lv) + "F"
    }

    static func build(_ p: Prop) -> StreetHouse {
        let kind: BuildingArt.Kind = BuildingArt.kind(p)
        var byLevel: [Int: [StreetHouse.Window]] = [:]
        var lets: [TenantsView.Let] = []
        for (i, u) in p.units.enumerated() {
            let shop: Bool = isShop(p, u)
            let lv: Int = level(u.label, index: u.idx ?? i, shop: shop, flats: kind == .flats)
            let t: TenantsView.Let? = use(u) == "let" ? TenantsView.Let(p: p, u: u) : nil
            if let t { lets.append(t) }
            byLevel[lv, default: []].append(StreetHouse.Window(id: id(p) + "|" + String(i), tenant: t, u: u, light: .of(u), shop: shop))
        }
        let top: Int = max(byLevel.keys.max() ?? 0, kind == .flats ? 3 : 0)
        var floors: [StreetHouse.Floor] = []
        for lv in stride(from: top, through: 0, by: -1) {
            var ws: [StreetHouse.Window] = byLevel[lv] ?? []
            // a block of flats: the neighbours' windows either side; a floor kosh knows nothing about: one dim window
            let need: Int = kind == .flats ? 2 : 1
            var k: Int = 0
            while ws.count < need {
                ws.insert(StreetHouse.Window(id: id(p) + "|n" + String(lv) + "-" + String(k), tenant: nil, u: nil, light: .neighbour, shop: false), at: 0)
                k += 1
            }
            floors.append(StreetHouse.Floor(level: lv, windows: ws))
        }
        let shown: Int = 6
        return StreetHouse(p: p, kind: kind, floors: Array(floors.suffix(shown)), more: max(0, floors.count - shown),
                           lets: lets.sorted(by: TenantsView.before))
    }

    /// "3 let · 1 empty · family lives here"
    static func meta(_ h: StreetHouse) -> String {
        let lets: Int = h.lets.count
        let empty: Int = h.empty.count
        let family: Bool = h.p.units.contains { use($0) == "self" }
        var bits: [String] = []
        if lets > 0 { bits.append(String(lets) + " let") }
        if empty > 0 { bits.append(String(empty) + " empty") }
        if family { bits.append("family lives here") }
        return bits.isEmpty ? h.p.type : bits.joined(separator: " · ")
    }
}

/// this month's rent over a set of tenants: what's owed, what's in, what's late and what's due
struct RentSums {
    var expected: Double = 0, received: Double = 0, inSum: Double = 0, lateSum: Double = 0, dueSum: Double = 0
    var paid: Int = 0, late: Int = 0, due: Int = 0

    init(_ lets: [TenantsView.Let]) {
        for l in lets {
            guard let n = l.u.now else { continue }
            expected += n.amt
            switch n.st {
            case "booked": received += Street.got(n); inSum += n.amt; paid += 1
            case "late": lateSum += n.amt; late += 1
            case "due": dueSum += n.amt; due += 1
            default: break
            }
        }
    }
    /// the bar's pieces: in, due, late
    var parts: [RentBar.Part] {
        [RentBar.Part(id: "in", ink: RentInk.lit, v: inSum, breathe: false),
         RentBar.Part(id: "due", ink: RentInk.due, v: dueSum, breathe: false),
         RentBar.Part(id: "late", ink: RentInk.late, v: lateSum, breathe: true),
         RentBar.Part(id: "rest", ink: Color.rule.opacity(0.14), v: max(0, expected - inSum - dueSum - lateSum), breathe: false)]
            .filter { $0.v > 0 }
    }
}

// MARK: - The top tile

/// the dusk sky with the street (or the islands) in it; above it, what you're looking at, or the way back out
struct StreetTile: View {
    let world: IsoWorld
    let tenants: Int
    let level: IsoLevel
    let isle: String?
    let house: String?
    let tags: Bool
    let still: Bool
    let pickIsle: (String) -> Void
    let pickHouse: (String) -> Void
    let back: () -> Void
    let open: (TenantsView.Let) -> Void
    let more: () -> Void

    /// the street's height: more rows of buildings, more room, up to a point; islands get a little more
    static func height(_ w: IsoWorld) -> CGFloat {
        let n: Int = w.isles.map { $0.houses.count }.max() ?? 1
        let base: CGFloat = IsoBlock.height(n) + (w.many ? 100 : 70)
        return max(240, min(340, base))
    }

    var body: some View {
        let h: CGFloat = Self.height(world)
        let here: IsoWorld.Isle? = world.many && level != .all ? world.isles.first(where: { $0.id == isle }) : nil
        ZStack(alignment: .topLeading) {
            LinearGradient(stops: Dusk.sky, startPoint: .top, endPoint: .bottom)
            Stars(still: still).accessibilityHidden(true)
            Moon()
                .padding(.top, 22).padding(.trailing, 24)
                .frame(maxWidth: .infinity, alignment: .topTrailing)
                .opacity(here == nil ? 1 : 0)
                .accessibilityHidden(true)
            IsoStreet(world: world, level: level, isle: isle, house: house, tags: tags, still: still,
                      pickIsle: pickIsle, pickHouse: pickHouse, open: open, more: more)
                .frame(height: h)
                .padding(.top, 58)
            if level == .all {
                head.padding(.leading, 20).padding(.top, 16).transition(.opacity)
            } else {
                pill.padding(.leading, 14).padding(.top, 14).transition(.opacity.combined(with: .offset(y: -6)))
            }
            if let here {
                HStack(spacing: 8) {
                    StatePlate(code: here.code, height: 20)
                    Text(here.name).font(.system(.subheadline, weight: .bold)).foregroundStyle(Color.white).lineLimit(1)
                }
                .padding(.top, 22).padding(.trailing, 16)
                .frame(maxWidth: .infinity, alignment: .topTrailing)
                .transition(.opacity)
                .accessibilityElement(children: .combine)
            }
        }
        .frame(height: 58 + h + 10)
        .frame(maxWidth: .infinity)
        .clipShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
    }

    /// "Your street · 4 properties · 6 tenants", or across states
    var head: some View {
        let props: Int = world.isles.reduce(0) { $0 + $1.houses.count }
        let line: String = world.many
            ? String(world.isles.count) + " states · " + Self.count(props, "property", "properties")
            : Self.count(props, "property", "properties") + " · " + Self.count(tenants, "tenant", "tenants")
        return VStack(alignment: .leading, spacing: 1) {
            Text(world.many ? "Your properties" : "Your street").font(.system(.footnote, weight: .semibold)).foregroundStyle(Dusk.peach)
            Text(line).font(.system(.subheadline)).foregroundStyle(Dusk.lilac)
        }
        .allowsHitTesting(false)
        .accessibilityElement(children: .combine)
    }
    static func count(_ n: Int, _ one: String, _ many: String) -> String { String(n) + " " + (n == 1 ? one : many) }

    /// back out one level: from a building to its state (or the street), from a state to all of them
    var pill: some View {
        let to: String = level == .house && world.many ? Street.stateName(isle ?? "") : (world.many ? "All states" : "All properties")
        return Button(action: back) {
            HStack(spacing: 5) {
                Image(systemName: "chevron.left").font(.system(.footnote, weight: .bold))
                Text(to).lineLimit(1)
            }
            .font(.system(.footnote, weight: .semibold))
            .foregroundStyle(Color.white)
            .padding(.leading, 10).padding(.trailing, 14)
            .frame(minHeight: 36)
            .glassEffect(.clear.interactive(), in: .capsule)
        }
        .buttonStyle(.press)
        .accessibilityLabel("Back to " + to.lowercased())
    }
}

/// a twinkle of stars over the street
struct Stars: View {
    let still: Bool
    /// where each sits, as a share of the tile, its size, and its place in the twinkle
    static let spots: [(CGFloat, CGFloat, CGFloat, Double)] = [
        (0.55, 0.06, 2, 0), (0.66, 0.15, 2, 0.5), (0.5, 0.2, 1.5, 1.1), (0.83, 0.17, 2, 0.3), (0.75, 0.26, 1.5, 0.8),
        (0.92, 0.32, 1.5, 1.4), (0.08, 0.36, 1.5, 0.6),
    ]
    var body: some View {
        GeometryReader { g in
            ForEach(Array(Self.spots.enumerated()), id: \.offset) { _, s in
                Star(size: s.2, delay: s.3, still: still)
                    .position(x: g.size.width * s.0, y: min(g.size.height, 260) * s.1)
            }
        }
    }
}

struct Star: View {
    let size: CGFloat
    let delay: Double
    let still: Bool
    var body: some View {
        let dot = Circle().fill(Color.white).frame(width: size, height: size)
        if still {
            dot.opacity(0.7)
        } else {
            dot.phaseAnimator([0.2, 1.0]) { v, o in v.opacity(o) } animation: { _ in .easeInOut(duration: 1.6).delay(delay) }
        }
    }
}

struct Moon: View {
    var body: some View {
        Circle().fill(Dusk.moon)
            .frame(width: 30, height: 30)
            .overlay(alignment: .topLeading) { Circle().fill(Color(hex: "#D6C496").opacity(0.45)).frame(width: 6, height: 6).offset(x: 9, y: 8) }
            .overlay(alignment: .topLeading) { Circle().fill(Color(hex: "#D6C496").opacity(0.4)).frame(width: 4, height: 4).offset(x: 16, y: 18) }
            .background(Circle().fill(Dusk.moon.opacity(0.07)).padding(-7))
            .shadow(color: Dusk.moon.opacity(0.45), radius: 15)
    }
}
