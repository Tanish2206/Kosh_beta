import SwiftUI
import UIKit
import Observation

// MARK: - The store: changes made on this phone: categories, names, charges shared or split, refunds, notes
// (split out of Store.swift, 30 Oct 2026; the stored state stays in the class there)

extension Store {
    // changes made on this phone

    /// a payment's sheet, opened at its category or its chapter (a swipe on its row)
    func openTx(_ id: String, at start: String? = nil) {
        txStart = start
        sheet = .tx(id)
    }

    /// the other payments to the same payee (by its UPI ID, or its name) that would follow a change to this one:
    /// not the parts of split charges, and not ones you set for themselves only
    func samePayee(_ id: String, field: String) -> [Txn] {
        guard let t = txn(id), let lk = t.lk, !lk.isEmpty else { return [] }
        return tx.filter { $0.id != id && $0.lk == lk && $0.partOf == nil && !(live?.overrides[$0.id]?.only ?? "").contains(field) }
    }
    static func with(_ only: String?, _ f: String) -> String? { let o = only ?? ""; return o.contains(f) ? o : o + f }
    static func without(_ only: String?, _ f: String) -> String? { let o = (only ?? "").replacingOccurrences(of: f, with: ""); return o.isEmpty ? nil : o }

    /// file a payment. With other payments to the same payee, it's filed for this one only until you say "all of
    /// them" (asked straight after); naming payments one after another (ask: false) files every one to the payee.
    func setCategory(_ id: String, _ c: String, _ s: String, ask: Bool = true) {
        guard let cur = txn(id) else { return }
        let sym: String = symbol(c)
        edit(id) { t in t.c = c; t.s = s; t.u = false; t.g = false; t.sym = sym }
        if let (parent, k) = Self.part(id) {
            live?.override(parent) { o in if var ps = o.parts, k < ps.count { ps[k].c = c; ps[k].s = s; o.parts = ps } }
        } else {
            let others: [Txn] = ask ? samePayee(id, field: "c") : []
            live?.override(id) { o in
                o.c = c; o.s = s; o.by = nil; o.only = others.isEmpty ? Self.without(o.only, "c") : Self.with(o.only, "c")
                // (filed as anything but rent, it is no tenant's rent any more)
                if c != "Rent received" { o.rent = nil }
            }
            if c != "Rent received" { edit(id) { $0.rt = nil; $0.rtl = nil } }
            if !others.isEmpty {
                // (details-3nov: kosh asks first. Only this payment is filed until you say "all"; the earlier and later
                // payments to the payee are never changed without asking)
                applyAsk = ApplyAsk(tx: id, field: "c", payee: cur.m, others: others.count, label: s.isEmpty ? c : c + " · " + s)
            }
        }
        // what counts as spending follows the new name
        live?.rebuildSoon()
    }

    /// name a payee the bank only gives a code or a masked UPI ID for ("UPI ••h89k"): the name shows on every payment to
    /// it at once, and the engine keeps it for every payment to come (LiveSession.payeeNames). An empty name gives the
    /// bank's back
    func setPayeeName(_ id: String, _ name: String) {
        guard let live, let t = txn(id), let lk = t.lk, !lk.isEmpty else { return }
        let n: String = String(name.trimmingCharacters(in: .whitespacesAndNewlines).prefix(40))
        live.setPayeeName(lk, n)
        guard !n.isEmpty else { return }
        edit(id) { $0.m = n }
        var rows: [Txn] = tx, changed = false
        for i in rows.indices where rows[i].lk == lk && rows[i].id != id { rows[i].m = n; changed = true }
        if changed { tx = rows }
    }
    /// a payee's name as you gave it, if you did
    func payeeName(_ t: Txn) -> String? { (t.lk ?? "").isEmpty ? nil : live?.payeeNames[t.lk ?? ""] }

    /// "all of them": every payment to the payee follows this one (the ones you set for themselves only keep
    /// theirs), with an Undo for a few seconds
    func applyToAll(_ a: ApplyAsk, quiet: Bool = false) {
        applyAsk = nil
        guard let live, let t = txn(a.tx), let lk = t.lk else { return }
        var saved: [String: Override?] = [a.tx: live.overrides[a.tx]]
        live.override(a.tx) { o in o.only = Self.without(o.only, a.field) }
        for x in tx where x.id != a.tx && x.lk == lk && x.partOf == nil {
            guard let o = live.overrides[x.id], !(o.only ?? "").contains(a.field) else { continue }
            if a.field == "c" ? o.c != nil : o.f != nil {
                saved[x.id] = o
                live.override(x.id) { y in if a.field == "c" { y.c = nil; y.s = nil; y.by = nil } else { y.f = nil } }
            }
        }
        live.rebuildSoon()
        let what: String = a.field == "c" ? "Filed all \(a.others + 1) payments to \(a.payee) as \(a.label)" : "All \(a.others + 1) payments to \(a.payee) marked for \(a.label)"
        if !quiet { undoNote = UndoNote(text: what) { [weak self] in self?.restore(saved) } }
    }

    /// put payments' changes back as they were
    func restore(_ saved: [String: Override?]) {
        guard let live else { return }
        for (id, o) in saved { live.setOverride(id, o); edits[id] = nil; editGen[id] = nil }
        // an Undo on an open sheet shows at once: build now
        live.rebuildSoon(force: true)
    }

    /// count it or not from a swipe, with an Undo
    func swipeCount(_ t: Txn, _ on: Bool) {
        let key: String = Self.part(t.id)?.0 ?? t.id
        let saved: [String: Override?] = [key: live?.overrides[key]]
        setCounted(t.id, on)
        undoNote = UndoNote(text: on ? "Counted in spending" : "Left out of spending") { [weak self] in self?.restore(saved) }
    }

    // MARK: adjusting one charge, the way the web app does: share it, split it, or stop it counting.
    // The card was charged the full amount, so the rows always add back up to it.

    /// "b#1" is the second part split out of charge "b"
    static func part(_ id: String) -> (String, Int)? {
        let bits = id.split(separator: "#")
        guard bits.count == 2, let k = Int(bits[1]) else { return nil }
        return (String(bits[0]), k)
    }

    /// others owe you some of it: their shares go to Owed to you, and leave your spending
    /// `typedBack`: money back you typed on the split sheet, kept as this payment's refund just before (the split
    /// already took it off, so the engine never splits it again)
    func shareCharge(_ id: String, shares: [(name: String, amount: Double)], title: String, typedBack: Double = 0) {
        guard let t = txn(id), Self.part(id) == nil else { return }
        let owed = shares.reduce(0) { $0 + $1.amount }
        guard owed > 0 else { return }
        // (before any refund, as the engine applies it: SplitWays.mine; shown less the refund until the rebuild lands)
        let back: Double = t.refunded ?? 0
        let mine = SplitWays.mine(net: t.a, refunded: back, owed: owed)
        let base = t.a + (t.shared ?? 0)
        for s in shares where s.amount > 0 {
            // dated the day the money went, so a friend's money that came the same evening still settles it (a charge
            // counted in the next month has a later d)
            userOwed.insert(OwedItem(id: UUID().uuidString, name: s.name, title: title, amount: s.amount, date: t.od ?? t.d, dir: "in", kind: "split",
                                     settled: false, note: "Share of \(Fmt.rupees(base)) at \(t.m)", tx: id), at: 0)
        }
        if let live {
            // (sb: the money back this split already saw; any that comes later splits the way this one did)
            live.override(id) { $0.mine = mine; $0.sb = max(back, typedBack) }
            edit(id) { x in x.full = x.full ?? x.a; x.shared = (x.shared ?? 0) + owed; x.a = max(0, mine - back) }
            live.rebuildSoon()
        } else if let i = tx.firstIndex(where: { $0.id == id }) {
            tx[i].full = t.full ?? t.a; tx[i].shared = (t.shared ?? 0) + owed; tx[i].a = max(0, mine - back)
        }
    }

    /// keep it in the ledger and on the card, but not in spending
    func excludeCharge(_ id: String, reason: String?) {
        if let (parent, k) = Self.part(id) {
            live?.override(parent) { o in if var ps = o.parts, k < ps.count { ps[k].ex = reason; o.parts = ps } }
        } else {
            live?.override(id) { $0.ex = reason }
        }
        if let i = tx.firstIndex(where: { $0.id == id }) { tx[i].ex = reason; tx[i].nc = reason == nil ? nil : "ex" }
        live?.rebuildSoon()
    }

    /// part of it was something else (or came back): a row of its own, the same card and day
    func splitOut(_ id: String, amount: Double, c: String?, s: String?, refunded: Bool) {
        guard let t = txn(id), Self.part(id) == nil, amount > 0, amount < t.a else { return }
        live?.override(id) { o in
            var ps = o.parts ?? []
            ps.append(Override.Part(a: amount, c: c, s: s, ex: refunded ? "Refunded" : nil))
            o.parts = ps
        }
        live?.rebuildSoon()
    }

    /// back to one charge as the bank sent it; shares not yet paid back are dropped
    func resetCharge(_ id: String) {
        if let (parent, k) = Self.part(id) {
            live?.override(parent) { o in if var ps = o.parts, k < ps.count { ps.remove(at: k); o.parts = ps.isEmpty ? nil : ps } }
        } else {
            // paid back by hand or seen coming in: those stay, and stay split off it (their money did come in)
            let paid = paidShares(id)
            // (the charge as the bank sent it, its parts back in it, less those shares)
            let mine: Double? = paid.sum > 0 ? txn(id).map { t in SplitBook.paisa(max(0, (t.full ?? (t.a + (t.shared ?? 0))) - paid.sum)) } : nil
            let seen: Double? = mine == nil ? nil : (txn(id)?.refunded ?? 0)
            live?.override(id) { $0.mine = mine; $0.sb = seen; $0.ex = nil; $0.parts = nil }
            userOwed.removeAll { $0.tx == id && !paid.ids.contains($0.id) }
        }
        live?.rebuildSoon()
    }

    /// the shares others owe on one charge
    func shares(of id: String) -> [OwedItem] { owed.filter { $0.tx == id } }
    /// every share of a split charge has come back
    func sharesBack(_ id: String) -> Bool {
        let s: [OwedItem] = shares(of: id)
        return !s.isEmpty && s.allSatisfy { $0.settled }
    }

    // MARK: how a row counts: in which month, and whether at all

    /// count it in another month's spending and cash flow (nil: its own)
    func setCountMonth(_ id: String, _ m: String?) {
        let key: String = Self.part(id)?.0 ?? id
        live?.override(key) { $0.cm = m }
        live?.rebuildSoon(force: true)
    }
    /// what a payment you left out says it is (saved as the override's ex; LiveSession.migrateWords maps the old words)
    static let leftOut: String = "Left out of spending"
    /// the same, as kosh saved it before 18 Oct 2026
    static let leftOutBefore: String = "Kept out of spending"
    /// keep it out of spending and cash flow, or count it again
    /// count it or not. Turning on a payment kosh left out by itself (unnamed, a top-up, a trip's) counts this one
    /// anyway; turning one off keeps it out, whatever kosh would do.
    func setCounted(_ id: String, _ on: Bool) {
        if Self.part(id) != nil { excludeCharge(id, reason: on ? nil : Self.leftOut); return }
        let reason: String = txn(id)?.nc ?? ""
        let auto: Bool = !reason.isEmpty && reason != "ex"
        edit(id) { t in t.ex = on ? nil : Self.leftOut; t.nc = on ? nil : "ex" }
        live?.override(id) { o in
            if on { o.ex = nil; o.cnt = auto ? true : nil } else { o.ex = Self.leftOut; o.cnt = nil }
        }
        live?.rebuildSoon()
    }

    // MARK: refunds you're waiting for

    func refund(_ id: String) -> RefundInfo? { snap.refunds?.first { $0.id == id } }
    var refundsWaiting: [RefundInfo] { figures.refundsWaiting(who) }
    func expectRefund(_ id: String, amount: Double, by: String?, note: String) {
        live?.override(id) { o in o.rf = amount; o.rfBy = by; o.rfNote = note.isEmpty ? nil : note; o.rfDone = nil }
        live?.rebuildSoon(force: true)
    }
    func stopRefund(_ id: String) {
        live?.override(id) { o in o.rf = nil; o.rfBy = nil; o.rfNote = nil; o.rfDone = nil }
        for t in tx where t.refOf == id { live?.override(t.id) { $0.rfOf = nil } }
        live?.rebuildSoon(force: true)
    }
    /// it came back without kosh seeing the credit (cash, a voucher, another account)
    func refundBack(_ id: String, _ on: Bool) {
        live?.override(id) { $0.rfDone = on ? true : nil }
        live?.rebuildSoon(force: true)
    }
    /// this credit is the refund for that payment (nil: it isn't one)
    func linkRefund(credit: String, to payment: String?) {
        live?.override(credit) { $0.rfOf = payment ?? "none" }
        if let p = payment, let c = txn(credit), refund(p) == nil {
            // a payment you hadn't marked: what came back is what was owed
            live?.override(p) { o in if (o.rf ?? 0) <= 0 { o.rf = c.a } }
        }
        live?.rebuildSoon(force: true)
    }
    /// the payments a credit could be the refund for: waiting refunds first, then the same payee's, newest first
    func refundCandidates(for c: Txn) -> [Txn] {
        let waiting: Set<String> = Set(refundsWaiting.map(\.id))
        let name: String = String(c.m.lowercased().filter { $0.isLetter }.prefix(6))
        var out: [Txn] = []
        for t in tx where t.dr == "out" && t.partOf == nil && t.d <= c.d && (t.full ?? t.a) >= c.a - 1 {
            let same: Bool = name.count >= 4 && t.m.lowercased().filter { $0.isLetter }.contains(name)
            if waiting.contains(t.id) || same { out.append(t) }
        }
        out.sort { a, b in
            let wa: Bool = waiting.contains(a.id)
            let wb: Bool = waiting.contains(b.id)
            if wa != wb { return wa }
            return a.d > b.d
        }
        return Array(out.prefix(8))
    }
    func setFor(_ id: String, _ f: String, ask: Bool = true) {
        guard let cur = txn(id) else { return }
        edit(id) { t in t.f = f; t.fs = true }
        let others: [Txn] = ask ? samePayee(id, field: "f") : []
        live?.override(id) { o in o.f = f; o.only = others.isEmpty ? Self.without(o.only, "f") : Self.with(o.only, "f") }
        if !others.isEmpty {
            applyAsk = ApplyAsk(tx: id, field: "f", payee: cur.m, others: others.count, label: LearnedView.forName(f))
        }
        live?.rebuildSoon()
    }
    func setNote(_ id: String, _ n: String) {
        guard let cur = txn(id), cur.n != n else { return }
        edit(id) { t in t.n = n }
        live?.override(id) { $0.n = n }
        live?.rebuildSoon()
    }
    /// "14:05": the time a spend added by hand is filed at (made once, not on every add)
    static let clock: DateFormatter = {
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX"); f.dateFormat = "HH:mm"
        return f
    }()
    func addSpend(amount: Double, c: String, s: String, merchant: String, card: String) {
        if let live {
            // (in the ledger at once, and in the month's spending, before the build that lays it out lands: the row as
            // the engine makes one, ShownRules.manualRow; shown before the reading is added, so the build it starts
            // is known to have it)
            let id: String = "m-" + UUID().uuidString
            let time: String = Self.clock.string(from: Date())
            if let row = ShownRules.manualRow(snap.value, id: id, day: LiveSession.today, time: time, merchant: merchant, amount: amount, card: card, c: c, sub: s) {
                showNow("add|" + id, feel: false, rows: true, added: amount) { x in ShownRules.addRow(&x, row) }
            }
            live.addManual(amount: amount, c: c, s: s, merchant: merchant, card: card, id: id, time: time)
            return
        }
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX"); f.dateFormat = "HH:mm"
        let t = Txn(id: UUID().uuidString, d: snap.today, t: f.string(from: Date()), m: merchant, a: amount, card: card,
                    c: c, s: s, k: "out", o: "me", f: "me", fs: true, n: "", u: false, g: false, src: "manual",
                    sym: symbol(c), sp: true)
        tx.insert(t, at: 0)
        added += amount
    }
    /// one payment told twice (merge: the second is the first, listed and counted once), or two payments (never asked again)
    func resolveDup(_ d: Dup, merge: Bool) {
        dupsDone.insert(d.key)
        guard d.ids.count > 1 else { return }
        let keep = d.ids[0], other = d.ids[1]
        if merge { tx.removeAll { $0.id == other } }
        guard let live else { return }
        if merge { live.override(other) { $0.dup = keep } }
        else { live.override(keep) { o in if !(o.dupNot ?? []).contains(other) { o.dupNot = (o.dupNot ?? []) + [other] } } }
        live.rebuildSoon()
    }

    // naming payments: what this one most likely was
    func suggestions(for t: Txn) -> [Suggestion] {
        let words = t.m.lowercased().components(separatedBy: CharacterSet.letters.inverted)
            .filter { $0.count > 3 && !["paytm", "upi"].contains($0) }
        var tally: [String: Int] = [:]
        for x in tx where x.id != t.id && !x.u && x.k == "out" {
            let n = x.m.lowercased()
            var w = 0
            if words.contains(where: { n.contains($0) }) { w += 5 }
            if t.m.lowercased().hasPrefix("upi") && n.hasPrefix("upi") && x.a < 1500 { w += 1 }
            if w > 0 { tally[x.c + "|" + x.s, default: 0] += w }
        }
        var out: [Suggestion] = tally.sorted { $0.value > $1.value }.prefix(3).map { (kv: (key: String, value: Int)) -> Suggestion in
            let p = kv.key.components(separatedBy: "|")
            let c = p[0], s = p.count > 1 ? p[1] : ""
            return Suggestion(label: s.isEmpty || s == "Other" ? c : s, c: c, s: s, card: "", merchant: "", sym: symbol(c))
        }
        if out.isEmpty {
            out = [("Groceries", "Fruits & veggies"), ("Food & Drinks", "Snacks"), ("Medical", "Pharmacy")].map {
                Suggestion(label: $0.1, c: $0.0, s: $0.1, card: "", merchant: "", sym: symbol($0.0))
            }
        }
        return out
    }

    // quick add: the things you add by hand most
    var addSuggestions: [Suggestion] {
        var out: [Suggestion] = []
        if live == nil, let amex = tx.first(where: { $0.card.contains("3009") && $0.s == "Fuel" }) {
            out.append(Suggestion(label: "Fuel", c: "Transport", s: "Fuel", card: amex.card, merchant: "Fuel — HPCL (Amex)", sym: "fuelpump.fill"))
        }
        out.append(Suggestion(label: "Cash", c: "Miscellaneous", s: "Other", card: "Cash", merchant: "Cash", sym: "banknote.fill"))
        var seen = Set<String>()
        for t in tx where t.sp && !t.u && !t.m.lowercased().hasPrefix("upi") && t.m.count <= 22 {
            if seen.contains(t.m) || out.count >= 8 { continue }
            seen.insert(t.m)
            out.append(Suggestion(label: t.m, c: t.c, s: t.s, card: t.card, merchant: t.m, sym: t.sym))
        }
        return out
    }

    var spendCategories: [String] {
        let count: [String: Int] = catUse
        return snap.cats.filter { $0.value.kind == "spend" && $0.key != "Miscellaneous" }.map(\.key)
            .sorted { (count[$0] ?? 0) > (count[$1] ?? 0) }
    }
    /// every category of one kind (spend, prepaid, move, income), the ones you use most first
    func categories(kind: String) -> [String] {
        let count: [String: Int] = catUse
        return snap.cats.filter { $0.value.kind == kind && $0.key != "Miscellaneous" }.map(\.key)
            .sorted { (count[$0] ?? 0) == (count[$1] ?? 0) ? $0 < $1 : (count[$0] ?? 0) > (count[$1] ?? 0) }
    }
    /// how many payments each category has (counted once a change to the payments: catUseMemo)
    var catUse: [String: Int] {
        if catUseMemo.gen == txGen { return catUseMemo.counts }
        var count: [String: Int] = [:]
        for t in tx { count[t.c, default: 0] += 1 }
        catUseMemo = (txGen, count)
        return count
    }
}
