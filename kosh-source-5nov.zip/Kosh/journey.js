/* kosh journey: the money story the mail tells, joined up. Each mail the reader read (reader.js) carries its
   events (record.evs); one mail is one step, and the journey links the steps into threads:

     card     a card's statements, each with its minimum, due date and the payments that cleared it (on time,
              late, part, still open)
     bill     a biller's bills (and auto-debits coming up) and the payment that paid each, days before the due date
     order    a shop's order: placed, shipped, delivered, cancelled or returned, the charge that paid it, the
              refund it promised and the credit that brought it back
     policy   an insurance policy: issued, each premium paid, the next due (with the insurer's grace), renewed, lapsed
     deposit  a fixed deposit: opened (amount, rate, maturity), renewed, closed or matured, the money out and back
     ipo      an IPO: applied, money blocked, allotted or not, unblocked
     fund     a mutual fund scheme: each purchase, SIP and redemption, units and NAV
     stock    shares bought and sold, by security
     dividend a company's dividends
     sub      a subscription: started, renewing, charged, cancelled
     refund   a refund promised outside an order, and whether it came

   All of it is matching on what the mail said: amounts to the paisa, dates in windows, names that agree. Nothing
   is guessed; a step kosh couldn't link stays alone and says so (status "open", "waiting", "unmatched").

   Loaded after engine.js and reader.js; it hangs off build() (E.postBuild), so the app's snapshot gains
   snap.threads and snap.journey (counts and the few things worth saying). */

var KoshJourney = (function (E) {
  'use strict';
  var K = (typeof KoshKnowledge !== 'undefined' && KoshKnowledge) || (typeof require === 'function' ? (function () { try { return require('./knowledge.js'); } catch (e) { return {}; } })() : {});

  /* ------------------------------------------------------------ small things */
  function lc(s) { return String(s == null ? '' : s).toLowerCase(); }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function dayN(iso) { var p = String(iso || '').slice(0, 10).split('-'); return Date.UTC(+p[0], +p[1] - 1, +p[2]) / 864e5; }
  function isoN(n) { var d = new Date(n * 864e5); return d.getUTCFullYear() + '-' + pad(d.getUTCMonth() + 1) + '-' + pad(d.getUTCDate()); }
  function addDays(iso, n) { return isoN(dayN(iso) + n); }
  function between(a, b) { return Math.round(dayN(b) - dayN(a)); }
  function okDay(s) { return /^\d{4}-\d{2}-\d{2}$/.test(String(s || '')); }
  function money(n) { return Math.round((+n || 0) * 100) / 100; }
  function same(a, b) { return a > 0 && b > 0 && Math.abs(a - b) <= 1; }
  // the words a name is made of, without the ones every company has
  var FILLER = /^(?:the|and|of|for|ltd|limited|pvt|private|india|indian|co|company|inc|llp|bank|card|credit|debit|payment|payments|services|technologies|tech|online|retail|store|pay|upi|www|com|in)$/;
  var WORDS = {}, WORDS_N = 0;
  function words(s) {
    s = String(s == null ? '' : s);
    var w = WORDS[s];
    if (w) return w;
    w = lc(s).replace(/[^a-z0-9 ]+/g, ' ').split(/\s+/).filter(function (x) { return x.length >= 3 && !FILLER.test(x); });
    if (WORDS_N > 20000) { WORDS = {}; WORDS_N = 0; }
    WORDS[s] = w; WORDS_N++;
    return w;
  }
  function agree(a, b) {
    if (!a || !b) return false;
    var A = lc(a).replace(/[^a-z0-9]/g, ''), B = lc(b).replace(/[^a-z0-9]/g, '');
    if (A.length >= 4 && B.length >= 4 && (A.indexOf(B) >= 0 || B.indexOf(A) >= 0)) return true;
    var wa = words(a), wb = words(b);
    return wa.some(function (w) { return wb.indexOf(w) >= 0; });
  }
  // two names of one institution: every word of the shorter is in the longer ("HDFC Life" is not "HDFC ERGO")
  function sameName(a, b) {
    var wa = words(a), wb = words(b);
    if (!wa.length || !wb.length) return false;
    var s0 = wa.length <= wb.length ? wa : wb, l0 = s0 === wa ? wb : wa;
    return s0.every(function (w) { return l0.indexOf(w) >= 0; });
  }
  function keyOf(s) { return words(s).slice(0, 3).join(' ') || lc(s).replace(/[^a-z0-9]+/g, ' ').trim(); }
  function last4Of(v) { return v && v.last4 ? String(v.last4).slice(-4) : ''; }
  function sameLast(a, b) { return !!a && !!b && (a.slice(-4) === b.slice(-4) || a.slice(-2) === b.slice(-2) && (a.length < 4 || b.length < 4)); }

  /* ------------------------------------------------------------ names fit to be a thread's title
     A thread is named for the other side as a person would say it: "Example Person", not "EXAMPLE PERSON a/c XX4321";
     "United Breweries Limited", not "UNITED BREWERIES LIMITED"; never a word a template prints in that place
     ("registration", "TOTAL", "banking"): that is no name at all, and the sender's own brand stands in. */
  var GENERIC = /^(?:registration|(?:auto ?pay|autopay|auto ?debit|si|mandate|e-?mandate|standing instruction)(?: (?:registration|deactivation|activation|cancellation|request))?|deactivation|activation|total|grand total|banking|net ?banking|payment|payments|subscription|plan|mandate|nach|ecs|bill ?desk|billdesk|razorpay|payu|cashfree|connect|transfer|fund transfer|charges?|amount|details?|premium|renewal|emi|bill|bills|invoice|receipt|order|merchant|biller|others?|na|n\/a|unknown)$/i;
  var KEEP_CAPS = /^(?:HDFC|ICICI|IDFC|HSBC|NTPC|ONGC|BHEL|GAIL|IRCTC|IRFC|NHPC|NMDC|SJVN|RITES|IREDA|HUDCO|LIC|SBI|AU|RBL|YES|DBS|UCO|IDBI|PNB|BOB|UTI|AMC|ETF|NAV|IPO|SIP|NPS|PPF|EPF|FD|RD|UPI|GST|TDS|BSE|NSE|ITC|MRF|TVS|ABB|DLF|HUL|L&T|M&M|JSW|JK|KFC|BPCL|HPCL|IOCL|IOC|EV|USA|UK|UAE|PVR|INOX|ACKO|AIA|ERGO|PSU|II|III|IV)$/;
  var SMALL = /^(?:and|of|the|for|in|on|to|at|by|a|an|or|with|de|da)$/i;
  function tidyName(n) {
    n = String(n == null ? '' : n).replace(/\s+/g, ' ').trim();
    // what follows the name in a narration: its account ("a/c XX4321"), a reference, a code
    n = n.replace(/\s+(?:a\/c|acct|account|ac)\b.*$/i, '').replace(/\s+(?:ref|txn|utr|upi)\b.*$/i, '').replace(/[\s,:;|\-]+$/, '');
    var letters = n.replace(/[^A-Za-z]/g, ''), caps = n.replace(/[^A-Z]/g, '');
    if (letters.length >= 4 && caps.length / letters.length > 0.8) {
      n = n.split(' ').map(function (w, i) {
        var bare = w.replace(/[^A-Za-z&]/g, '');
        if (KEEP_CAPS.test(bare) || (bare.length <= 3 && !SMALL.test(bare) && !/[AEIOU]/.test(bare))) return w;
        if (i > 0 && SMALL.test(bare)) return w.toLowerCase();
        return w.charAt(0) + w.slice(1).toLowerCase();
      }).join(' ');
    }
    return n;
  }
  // the sender is the one a bill is owed to: a biller's own mail, a lender's or bank's own EMI
  function selfPayee(s, e) {
    var dom = lc(String(s.from || '').split('@')[1] || '');
    if ((K.billers || []).some(function (b) { return (b.domains || []).some(function (d) { return dom === d || dom.slice(-d.length - 1) === '.' + d; }); })) return true;
    if (e.what === 'emi' && (s.ik === 'bank' || s.ik === 'lender')) return true;
    return s.ik === 'biller' || s.ik === 'society';
  }
  // a biller's or shop's name as knowledge.js spells it ("UHBVN", not "Uhbvn"); each spelling looked up once a journey
  // (KNOWN, made afresh by journey(): every bill's and subscription's step lower-cased every name knowledge.js has)
  var KNOWN = null;
  function knownName(n) {
    var l = lc(n);
    if (!l) return n;
    var kb = KNOWN ? KNOWN[l] : undefined;
    if (kb === undefined) {
      kb = (K.billers || []).concat(K.shops || []).filter(function (x) { return lc(x.short) === l || lc(x.name) === l || (x.aliases || []).some(function (a) { return lc(a) === l; }); })[0] || null;
      if (KNOWN) KNOWN[l] = kb;
    }
    return kb ? (kb.short || kb.name) : n;
  }
  function genericName(n) { return !n || GENERIC.test(String(n).replace(/[^A-Za-z/ ]+/g, ' ').replace(/\s+/g, ' ').trim()); }
  // a sender's brand: the engine's name for it, else its domain's own word ("mail.examplesvc.com" → "Examplesvc")
  function brandOf(s) {
    var dom = lc(String(s.from || '').split('@')[1] || '');
    var inst = E && E.institution ? E.institution(s.from || '') : null;
    if (inst && inst.short) return inst.short;
    var kb = (K.shops || []).concat(K.billers || []).filter(function (x) { return (x.domains || []).some(function (d) { return dom === d || dom.slice(-d.length - 1) === '.' + d; }); })[0];
    if (kb) return kb.short || kb.name;
    var parts = lc(String(s.from || '').split('@')[1] || '').split('.').filter(function (x) { return x && !/^(?:mail|email|e|mailer|mailers|info|news|alerts?|notify|notifications?|noreply|no-reply|reply|em|t|m|go|send|bounce|comm|communication|engagement|service|services|support|accounts?|accts|billing|invoice|receipts?|updates?|order|orders|com|co|in|net|org|io|app|ai|bank|biz|gov|nic|me|us|uk)$/.test(x); });
    var w = parts[parts.length - 1] || '';
    return w ? w.charAt(0).toUpperCase() + w.slice(1) : '';
  }
  // a person, not a company: two to six words of letters, none a company's word ("EXAMPLE PERSON", "Example Person")
  var COMPANYISH = /\b(?:ltd|limited|pvt|private|llp|inc|corp|corporation|company|co|bank|insurance|assurance|life|general|finance|financial|finserv|capital|securities|services|service|technologies|technology|tech|solutions|ventures|enterprises|industries|industry|india|motors|foods|retail|store|stores|labs|media|digital|telecom|power|energy|electricity|gas|water|broadband|network|networks|communications|apple|google|netflix|spotify|amazon|microsoft|youtube|jio|airtel|vodafone|bsnl|tata|reliance|club|school|academy|education|university|college|hospital|clinic|society|trust|foundation|association|fund|funds|mutual|amc|nps|ppf|card|credit|loan|loans|emi|sip|invest|investment|investments|trading|exports|traders|agency|agencies|global|international|systems|software|cloud|online|mart|shop|market)\b/i;
  function personish(n) {
    var w = String(n || '').replace(/\s+(?:a\/c|acct|account)\b.*$/i, '').trim().split(/\s+/);
    return w.length >= 2 && w.length <= 6 && w.every(function (x) { return /^[A-Za-z][A-Za-z.']*$/.test(x); }) && !COMPANYISH.test(w.join(' '));
  }
  // two keys of one name, one of them misspelt ("sbi funds management" / "sbi funds managment"): the same first word
  // and at most two letters apart in the rest
  function closeKey(a, b) {
    a = String(a); b = String(b);
    if (a === b) return true;
    if (a.length < 10 || b.length < 10 || a.split(/[: ]/)[1] !== b.split(/[: ]/)[1] || Math.abs(a.length - b.length) > 2) return false;
    var prev = [], cur, i, j;
    for (j = 0; j <= b.length; j++) prev[j] = j;
    for (i = 1; i <= a.length; i++) {
      cur = [i];
      for (j = 1; j <= b.length; j++) cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a.charAt(i - 1) === b.charAt(j - 1) ? 0 : 1));
      prev = cur;
    }
    return prev[b.length] <= 2;
  }
  var INSURERISH = /\b(?:insurance|assurance|insurer|life insurance|general insurance|health insurance|\blic\b|life of india|prudential|ergo|lombard|allianz|bupa|star health|care health|acko|go ?digit|tata aia|max life|axis max|sbi life|hdfc life|icici pru|kotak life|bajaj life|bajaj allianz|aditya birla (?:sun ?life|health)|niva|manipal ?cigna|reliance general|new india assurance|united india|oriental insurance|national insurance|future generali|edelweiss (?:tokio|life)|canara hsbc|pnb metlife|aegon|aviva|exide life|indiafirst|shriram life|policybazaar|ditto)\b/i;
  /* what a recurring obligation is, so that it joins one thread and one only: a premium is its policy's, a card's
     bill is the card's, money sent on a schedule to a person is a standing instruction, an app's or a service's
     charge is a subscription, the rest (power, phone, broadband, a loan's EMI, a society's dues) is a bill */
  var SUBS = [];   // the services this mailbox has subscriptions with (journey() fills it first)
  function routeOf(e, s) {
    var who = String((e.type === 'due' ? e.payee : e.party) || '');
    var hay = who + ' ' + (s.subj || '');
    if (e.what === 'premium' || s.ik === 'insurer' || INSURERISH.test(who) || (/\bpremium\b/i.test(hay) && INSURERISH.test(hay + ' ' + s.from))) return 'policy';
    if (e.what === 'card' || /\bcredit ?card\b|\bcard (?:bill|dues?|outstanding)\b/i.test(who)) return 'card';
    if (e.what === 'emi' || /\b(?:loan|emi)\b/i.test(who)) return 'bill';
    // a service's own mail about its plan is a subscription; a person never writes to say they'll be paid, so a
    // mandate to a person is the bank's standing instruction
    var service = s.ik !== 'bank' && s.ik !== 'card' && s.ik !== 'gateway' && !!s.from && !/bank|billdesk|razorpay|payu|cashfree|npci/.test(lc(s.from));
    if (e.type === 'mandate' && service) return 'sub';
    if (e.type === 'mandate' && SUBS.some(function (n) { return sameName(n, who); })) return 'sub';
    if (e.type === 'mandate' && personish(who)) return 'standing';
    if (e.type === 'mandate' && (e.every || /subscription|membership|renew/i.test(hay))) return 'sub';
    return 'bill';
  }

  /* ------------------------------------------------------------ the steps: every event of every mail, dated */
  function stepsOf(records) {
    var out = [];
    records.forEach(function (r) {
      if (!r || !r.evs) return;
      if (r.use === 'claude' && r.claude && r.claude.kind === 'noise') return;
      var evs;
      try { evs = JSON.parse(r.evs); } catch (e) { return; }
      evs.forEach(function (e, i) {
        if (!e || e.type === 'noise') return;
        // what the reader wasn't sure of (reader.js › how sure) waits for a teacher before it joins a thread
        if (e.unsure) return;
        var d = e.date || e.stmtDate || '';
        if (!okDay(d)) d = r.sent || '';
        if (!okDay(d)) return;
        out.push({ e: e, d: d, n: dayN(d), id: r.id + (i ? '#' + i : ''), mail: r.id, from: r.from || '', inst: r.inst || '', subj: String(r.subject || '').slice(0, 90), acct: r.acct || '', ik: r.instKind || '' });
      });
    });
    out.sort(function (a, b) { return a.d < b.d ? -1 : a.d > b.d ? 1 : 0; });
    return out;
  }
  // the same movement told twice (the card's own alert and CRED's receipt, a bank alert and a shop's receipt)
  function dedupeMoves(moves) {
    var kept = [], at = {}, place = new Map();   // (where each kept move is in kept: one an echo replaced is gone from it)
    moves.forEach(function (m) {
      var e = m.e, r0 = Math.round(e.amt);
      var near = (at[r0 - 1] || []).concat(at[r0] || [], at[r0 + 1] || []);
      var twin = near.filter(function (k) {
        if (!place.has(k)) return false;
        var f = k.e;
        if (f.dir !== e.dir || !same(f.amt, e.amt) || Math.abs(k.n - m.n) > 2) return false;
        var la = last4Of(f.via), lb = last4Of(e.via);
        if (la && lb && !sameLast(la, lb) && f.via.kind === e.via.kind) return false;
        if (f.ref && e.ref && f.ref !== e.ref) return false;
        return true;
      })[0];
      if (!twin) { place.set(m, kept.length); kept.push(m); (at[r0] = at[r0] || []).push(m); return; }
      // the better-told one stays (digits, a payee, a reference), the other is its echo
      var score = function (x) { return (last4Of(x.e.via) ? 2 : 0) + (x.e.party ? 1 : 0) + (x.e.ref ? 1 : 0) + (x.e.via && x.e.via.kind !== 'other' ? 1 : 0); };
      (twin.echo = twin.echo || []).push(m.mail);
      if (score(m) > score(twin)) { m.echo = twin.echo.concat([twin.mail]); var i = place.get(twin); kept[i] = m; place.delete(twin); place.set(m, i); (at[r0] = at[r0] || []).push(m); }
    });
    return kept;
  }
  // movements of about this amount (to the rupee either side): every matcher looks here, not at all of them
  var NEAR = function () { return []; };
  function amtIndex(moves) {
    var at = {};
    moves.forEach(function (m) { var k = Math.round(m.e.amt); (at[k] = at[k] || []).push(m); });
    return function (amt) { var k = Math.round(+amt || 0); return (at[k - 1] || []).concat(at[k] || [], at[k + 1] || []); };
  }
  function step(s, t, extra) {
    var o = { d: s.d, t: t, mail: s.mail };
    for (var k in extra) if (extra[k] !== undefined && extra[k] !== '' && extra[k] !== null) o[k] = extra[k];
    return o;
  }
  function viaText(v) {
    if (!v) return '';
    var n = v.inst || '';
    if (v.kind === 'card') return (n ? n + ' ' : '') + (v.debit ? 'debit card' : 'card') + (v.last4 ? ' ••' + v.last4 : '');
    if (v.kind === 'account') return (n ? n + ' ' : '') + 'account' + (v.last4 ? ' ••' + v.last4 : '');
    if (v.kind === 'wallet') return n || 'wallet';
    if (v.kind === 'upi') return 'UPI';
    return n;
  }

  /* ------------------------------------------------------------ cards: statement → due → paid */
  function cardThreads(steps, moves, today, used) {
    var cards = {};
    function cardKey(inst, l4) { return lc(inst || '?') + '|' + (l4 || '').slice(-4); }
    function cardFor(inst, l4) {
      // a statement without digits joins the bank's one card; digits that end the same are the same card
      var keys = Object.keys(cards).filter(function (k) { var c = cards[k]; return lc(c.inst) === lc(inst || '?') && (!l4 || !c.last4 || sameLast(c.last4, l4)); });
      if (keys.length) { var c0 = cards[keys[0]]; if (l4 && !c0.last4) c0.last4 = l4; return c0; }
      var k = cardKey(inst, l4);
      return (cards[k] = cards[k] || { kind: 'card', id: 'card:' + k, inst: inst || '', last4: l4 || '', cycles: [], pays: [], reminders: [] });
    }
    steps.forEach(function (s) {
      var e = s.e;
      // (an account's, a broker's or a registrar's statement is not a card's: no card thread from it)
      // (a "statement is ready" notice with no figures makes no cycle: the statement's own figures will)
      if (e.type === 'statement' && !(e.via && e.via.kind && e.via.kind !== 'card') && (e.total != null || e.due)) {
        var c = cardFor((e.via && e.via.inst) || s.inst, last4Of(e.via));
        var sd = e.stmtDate || s.d;
        // the same statement mailed twice (or restated by a "balance update"): one cycle, with whatever each adds
        var twin = c.cycles.filter(function (x) { return (x.due && x.due === e.due && same(x.total, e.total)) || (same(x.total, e.total) && Math.abs(between(x.stmt, sd)) <= 10); })[0];
        if (twin) { if (!twin.due && e.due) twin.due = e.due; if (twin.min == null && e.min != null) twin.min = e.min; if (sd < twin.stmt) twin.stmt = sd; return; }
        c.cycles.push({ stmt: sd, total: e.total != null ? e.total : null, min: e.min != null ? e.min : null, due: e.due || '', mail: s.mail, pays: [] });
      } else if (e.type === 'due' && e.what === 'card') {
        cardFor((e.via && e.via.inst) || s.inst, last4Of(e.via)).reminders.push({ d: s.d, due: e.due || '', amt: e.amt || null, mail: s.mail });
      }
      // the issuer's count of what came in since its last statement (a balance update's "Recent credits ₹X since …")
      if ((e.type === 'balance' || e.type === 'due') && e.credits > 0 && e.stmtBal > 0) {
        var cc = cardFor((e.via && e.via.inst) || s.inst, last4Of(e.via));
        (cc.confirms = cc.confirms || []).push({ d: s.d, credits: e.credits, bal: e.stmtBal, closed: e.closed || '', mail: s.mail });
      }
    });
    // payments onto a card: the card's own "payment received" (in), or a bank's or app's debit towards a card
    moves.forEach(function (m) {
      var e = m.e;
      var onCard = e.dir === 'in' && e.via && e.via.kind === 'card' && !e.via.debit && /cardpay/.test(e.purpose || '');
      // (a bank's bill-pay debit that names the card it paid: "BIL/ONL/000123456/CREDIT CARD/XX9004")
      // (or a card's own UPI ID, "axiscc.8840@axisbank", or SBI's "-SBI CARD PAYMENT XXXX7710")
      var acctOut = e.dir === 'out' && e.via && e.via.kind === 'account';
      var named = acctOut ? /credit ?card\b[\s\/:\-]*(?:no\.?\s*|ending\s*(?:in\s*)?)?[x*•]*(\d{4})\b/i.exec(String(e.q || '') + ' ' + String(e.party || '')) : null;
      var namedOwn = acctOut && !named ? /^[a-z]{0,14}(?:cc|card|creditcard)[._-]?[x*]*(\d{4})@[a-z]+$/i.exec(String(e.vpa || '').trim())
        || (/cardpay/.test(e.purpose || '') ? /\bcard ?payment\b[\s\/:\-]*[x*•]*(\d{4})\b/i.exec(String(e.q || '')) : null) : null;
      named = named || namedOwn;
      var namedCard = named ? Object.keys(cards).map(function (k) { return cards[k]; }).filter(function (c) { return c.last4 && c.last4.slice(-4) === named[1]; }) : [];
      var toCard = e.dir === 'out' && (/cardpay/.test(e.purpose || '') || namedCard.length === 1);
      if (!onCard && !toCard) return;
      var target = null;
      if (onCard) target = cardFor(e.via.inst || m.inst, last4Of(e.via));
      else if (namedCard.length === 1) target = namedCard[0];
      // (a payment that names another card's digits is that card's, never this one's by the sum)
      else if (namedOwn) return;
      else {
        // which card a bank's debit paid: the statement it equals, else the card the payee names
        Object.keys(cards).forEach(function (k) {
          if (target) return;
          if (cards[k].cycles.some(function (cy) { return same(cy.total, e.amt) && between(cy.stmt, m.d) >= -2 && between(m.d, cy.due || addDays(cy.stmt, 25)) >= -20; })) target = cards[k];
        });
        if (!target) Object.keys(cards).forEach(function (k) { if (!target && cards[k].inst && agree(cards[k].inst, e.party || '')) target = cards[k]; });
      }
      if (!target) return;
      // the card's own word and the bank's echo of it are one payment
      if (target.pays.some(function (p) { return same(p.amt, e.amt) && Math.abs(between(p.d, m.d)) <= 3; })) { used[m.mail] = 1; return; }
      target.pays.push({ d: m.d, amt: e.amt, mail: m.mail, how: onCard ? '' : viaText(e.via) });
      used[m.mail] = 1;
    });
    var out = [];
    Object.keys(cards).forEach(function (k) {
      var c = cards[k];
      c.cycles.sort(function (a, b) { return a.stmt < b.stmt ? -1 : 1; });
      c.pays.sort(function (a, b) { return a.d < b.d ? -1 : 1; });
      // each payment clears the oldest statement still owing that came before it
      c.pays.forEach(function (p) {
        var cy = null;
        for (var i = c.cycles.length - 1; i >= 0; i--) if (c.cycles[i].stmt <= p.d) { cy = c.cycles[i]; break; }
        if (!cy) return;
        // a payment just before the next statement's date still belongs to the one it pays
        cy.pays.push(p);
      });
      var onTime = 0, late = 0, cycles = [];
      c.cycles.forEach(function (cy, i) {
        var paid = money(cy.pays.reduce(function (n, p) { return n + p.amt; }, 0));
        var due = cy.due || '';
        var byDue = money(cy.pays.filter(function (p) { return !due || p.d <= due; }).reduce(function (n, p) { return n + p.amt; }, 0));
        var full = cy.total != null ? cy.total : 0;
        /* GUARDRAIL the issuer's own count of what came in since this statement (a balance update after it: its statement
           closed within the five weeks before this due day, or, with no closing day, its balance is this total) settles
           it as far as it goes, as the card's row does (engine 18 settleBill): never a payment of its own, never added to
           the payments seen (the larger stands). When it was paid isn't known, so it is never counted on time or late */
        var cf = (c.confirms || []).filter(function (x) {
          if (x.d < cy.stmt || (c.cycles[i + 1] && x.d >= c.cycles[i + 1].stmt)) return false;
          return x.closed ? (!due || (x.closed <= due && between(x.closed, due) <= 35)) : same(x.bal, cy.total);
        }).pop();
        var byIssuer = !!(cf && cf.credits > paid + 0.5);
        if (byIssuer) paid = money(cf.credits);
        var status;
        if (full <= 1) status = 'nothing due';
        else if (byIssuer && paid >= full - 1) status = 'paid';
        else if (byIssuer) status = due && today > due ? 'part paid late' : 'part paid';
        else if (byDue >= full - 1) status = 'paid';
        else if (paid >= full - 1) status = 'paid late';
        else if (due && today <= due) status = paid > 0 ? 'part paid' : 'open';
        else if (byDue >= (cy.min || 0) - 1 && byDue > 0) status = 'minimum paid';
        else status = paid > 0 ? 'part paid late' : (due ? 'overdue' : 'unmatched');
        if (byIssuer) { /* when it was paid isn't known */ } else if (status === 'paid') onTime++; else if (/late|overdue/.test(status)) late++;
        var lastPay = cy.pays.length ? cy.pays[cy.pays.length - 1].d : '';
        var st = [{ d: cy.stmt, t: 'statement', amt: cy.total, min: cy.min, due: due || undefined, mail: cy.mail }];
        c.reminders.filter(function (r) { return (r.due && r.due === due) || (!r.due && r.d >= cy.stmt && (!c.cycles[i + 1] || r.d < c.cycles[i + 1].stmt)); }).forEach(function (r) { st.push({ d: r.d, t: 'reminder', amt: r.amt || undefined, mail: r.mail }); });
        cy.pays.forEach(function (p) { st.push({ d: p.d, t: 'paid', amt: p.amt, how: p.how || undefined, mail: p.mail }); });
        if (byIssuer) st.push({ d: cf.d, t: 'confirmed', amt: cf.credits, mail: cf.mail });
        st.sort(function (a, b) { return a.d < b.d ? -1 : 1; });
        cycles.push({ stmt: cy.stmt, total: cy.total, min: cy.min, due: due, paid: paid, status: status, early: lastPay && due ? between(lastPay, due) : undefined, steps: st });
      });
      var openC = cycles.filter(function (x) { return /open|overdue|part/.test(x.status); });
      out.push({ kind: 'card', id: c.id, title: (c.inst || 'Card') + (c.last4 ? ' ••' + c.last4 : ''), inst: c.inst, last4: c.last4,
        status: openC.length ? openC[openC.length - 1].status : cycles.length ? cycles[cycles.length - 1].status : 'unmatched',
        next: openC.length ? { d: openC[openC.length - 1].due, amt: openC[openC.length - 1].total - openC[openC.length - 1].paid, what: 'due' } : undefined,
        last: (cycles.length ? cycles[cycles.length - 1].stmt : '') || (c.pays.length ? c.pays[c.pays.length - 1].d : ''),
        onTime: onTime, late: late, cycles: cycles.reverse(),
        loose: c.pays.filter(function (p) { return !c.cycles.some(function (cy) { return cy.pays.indexOf(p) >= 0; }); }).map(function (p) { return { d: p.d, t: 'paid', amt: p.amt, mail: p.mail }; }) });
    });
    return out;
  }

  /* ------------------------------------------------------------ bills: due → paid (and auto-debits coming up) */
  function billThreads(steps, moves, today, used) {
    var by = {};
    steps.forEach(function (s) {
      var e = s.e;
      var isDue = e.type === 'due' && e.what !== 'card';
      var isUp = e.type === 'mandate' && (e.action === 'upcoming' || e.action === 'done');
      if (!isDue && !isUp) return;
      if (routeOf(e, s) !== 'bill') return;
      var who = (isDue ? e.payee : e.party) || '';
      // no name for whom it pays: the sender, when it is the one to be paid (a biller's own bill, a lender's EMI);
      // an app's or a bank's reminder for someone it doesn't name is no thread (who would it be?)
      if (genericName(who)) who = selfPayee(s, e) ? brandOf(s) + (e.what === 'emi' ? ' loan' : '') : '';
      who = knownName(tidyName(who));
      if (genericName(who)) return;
      var k = 'bill:' + keyOf(who);
      var b = by[k] = by[k] || { kind: 'bill', id: k, title: who, what: isDue ? e.what : 'auto-debit', items: [] };
      if (isDue) b.items.push({ d: s.d, due: e.due || '', amt: e.amt || null, mail: s.mail, what: e.what });
      else if (e.action === 'upcoming') b.items.push({ d: s.d, due: e.date || '', amt: e.amt || null, mail: s.mail, auto: true });
      else b.done = (b.done || []).concat([{ d: e.date || s.d, amt: e.amt, mail: s.mail }]);
    });
    var out = [];
    Object.keys(by).forEach(function (k) {
      var b = by[k];
      // the same bill reminded twice is one bill
      var items = [];
      b.items.sort(function (x, y) { return x.d < y.d ? -1 : 1; }).forEach(function (it) {
        var twin = items.filter(function (x) { return (x.due && x.due === it.due) || (!x.due && !it.due && same(x.amt, it.amt) && Math.abs(between(x.d, it.d)) <= 10); })[0];
        if (twin) { twin.reminders = (twin.reminders || 1) + 1; if (!twin.amt && it.amt) twin.amt = it.amt; return; }
        items.push(it);
      });
      var early = [];
      items.forEach(function (it) {
        // paid after the bill came (a few days' slack for a mail that arrives late), up to a few weeks past the due date
        var lo = addDays(it.d, -3), hi = it.due ? addDays(it.due, 20) : addDays(it.d, 30);
        if (it.due && addDays(it.due, -35) > lo) lo = addDays(it.due, -35);
        // what paid it: the debit the auto-debit mail confirms, or a payment out of this amount to this payee
        var cand = (it.amt ? NEAR(it.amt) : moves).filter(function (m) {
          var e = m.e;
          if (e.dir !== 'out' || m.d < lo || m.d > hi || used[m.mail] === 'bill') return false;
          if (it.amt && !same(e.amt, it.amt)) return false;
          var named = agree(b.title, e.party || '') || agree(b.title, m.from);
          // without the bill's amount only a payment that names the biller will do
          if (!it.amt) return named;
          return named || /billpay|emi|premium/.test(e.purpose || '') || (it.auto && e.mode === 'NACH');
        });
        var hit = cand[0];
        if (!hit && b.done) { var dn = b.done.filter(function (x) { return same(x.amt, it.amt) && x.d >= lo && x.d <= hi; })[0]; if (dn) hit = { d: dn.d, e: { amt: dn.amt }, mail: dn.mail }; }
        var st = [{ d: it.d, t: it.auto ? 'auto-debit set' : 'bill', amt: it.amt || undefined, due: it.due || undefined, mail: it.mail }];
        if (hit) { used[hit.mail] = 'bill'; st.push({ d: hit.d, t: 'paid', amt: hit.e.amt, how: viaText(hit.e.via) || undefined, mail: hit.mail }); if (it.due) early.push(between(hit.d, it.due)); }
        it.steps = st;
        it.status = hit ? (it.due && hit.d > it.due ? 'paid late' : 'paid') : it.due ? (it.due < today ? (it.auto ? 'not seen' : 'unpaid') : 'open') : (addDays(it.d, 30) >= today ? 'open' : 'not seen');
      });
      if (!items.length) return;
      items.sort(function (x, y) { return (x.due || x.d) < (y.due || y.d) ? 1 : -1; });
      var openI = items.filter(function (x) { return x.status === 'open'; });
      out.push({ kind: 'bill', id: b.id, title: b.title, what: b.what, status: openI.length ? 'open' : items[0].status, last: items[0].d,
        next: openI.length ? { d: openI[0].due || openI[0].d, amt: openI[0].amt || undefined, what: openI[0].auto ? 'auto-debit' : 'due' } : undefined,
        usualEarly: early.length ? early.sort(function (x, y) { return x - y; })[Math.floor(early.length / 2)] : undefined,
        items: items.map(function (x) { return { due: x.due, amt: x.amt, status: x.status, steps: x.steps }; }) });
    });
    return out;
  }

  /* ------------------------------------------------------------ a promised refund's money
     The build's refunds (engine/21b: snap.refunds and snap.refundPromises, each listing the mails that promised it) are
     the one place a promise meets its credit, so a refund is one figure on every screen. Each credit set against it is a
     step once: the bank's credit or a statement's line under `word` ("refunded", "came"), the shop's word alone that it
     sent it as "refund started". Without the build's word (journey() called on its own) a promise stays open: nothing
     here matches a credit to it by its sum. */
  var BACK = {};
  function refundSteps(steps, p, used, tag, word) {
    var row = BACK[p.mail] || null;
    p.row = row;
    p.open = !row || row.state !== 'back';
    p.late = !!row && row.state === 'late';
    p.left = row ? money(Math.max(0, row.exp - row.back)) : p.amt;
    if (row && row.by) p.by = row.by;
    if (!row) return;
    (row.credits || []).forEach(function (c) {
      var t = c.shop ? 'refund started' : word;
      if (steps.some(function (x) { return x.mail === c.id && x.t === t; })) return;
      var mv = c.shop ? null : NEAR(c.a).filter(function (m) { return m.mail === c.id; })[0];
      if (!c.shop) used[c.id] = tag;
      steps.push({ d: c.d, t: t, amt: c.a, how: mv ? viaText(mv.e.via) || undefined : undefined, mail: c.id });
    });
  }

  /* ------------------------------------------------------------ orders: placed → shipped → delivered, charged, refunded */
  /* a parcel's steps (the reader's parcel events, a shop's and a courier's own mail): the order's, by its number, else
     by its tracking number (a shop's dispatch mail carries both, so a courier's later mail with the tracking number alone
     joins the order). On the way: in transit is "shipped", then "out"; a missed delivery, a new day, held for collection
     sit beside "out" (the latest of them is where it stands); delivered closes it. A return: its pickup booked, missed or
     moved, then picked up. An order's status only moves forward: a late "in transit" after "delivered" changes nothing */
  var PARCEL_T = { transit: 'shipped', out: 'out', attempted: 'attempted', rescheduled: 'rescheduled', held: 'held', delivered: 'delivered' };
  var RETURN_T = { 'pickup-booked': 'pickup booked', attempted: 'pickup missed', rescheduled: 'pickup moved', 'picked-up': 'picked up' };
  var ORDER_RANK = { placed: 1, declined: 1, shipped: 2, out: 3, attempted: 3, rescheduled: 3, held: 3, delivered: 4, 'pickup booked': 4.5, 'pickup missed': 4.5, 'pickup moved': 4.5, 'picked up': 4.8,
    cancelled: 5, returned: 5, 'refund promised': 6, 'refund started': 6, refunded: 7 };
  var LATEST_WINS = { out: 1, attempted: 1, rescheduled: 1, held: 1, 'pickup booked': 1, 'pickup missed': 1, 'pickup moved': 1 };
  function parcelKey(s) { return String(s || '').replace(/[^A-Za-z0-9]/g, '').toUpperCase(); }
  function orderThreads(steps, moves, today, used) {
    var by = {};
    // a tracking number the shop's mail gave beside the order's: that order's
    var awbOrder = {};
    steps.forEach(function (s) { var e = s.e; if (e.type === 'parcel' && e.order && e.awb && parcelKey(e.awb) && !awbOrder[parcelKey(e.awb)]) awbOrder[parcelKey(e.awb)] = String(e.order); });
    // (a status mail without its order's number takes the shop's latest order with one of its items: it looks only at the
    // orders made for a shop whose name agrees with its own, newest first, each two names compared once. Every order, for
    // every such mail, grew with the square of the orders)
    var made = 0, rank = {}, keysOf = new Map(), agreed = new Map();
    function priorOf(e, shop) {
      var best, bestAt = -1;
      keysOf.forEach(function (ks, s0) {
        var two = s0 + '\u0000' + shop, ok = agreed.get(two);
        if (ok === undefined) { ok = agree(s0, shop); agreed.set(two, ok); }
        if (!ok) return;
        for (var j = ks.length - 1; j >= 0 && rank[ks[j]] > bestAt; j--) {
          var o = by[ks[j]];
          if (o.items.length && (e.items || []).some(function (it) { return o.items.some(function (oi) { return agree(oi, it); }); })) { best = ks[j]; bestAt = rank[best]; break; }
        }
      });
      return best;
    }
    steps.forEach(function (s) {
      var e = s.e;
      if (e.type === 'parcel') { parcelStep(s, e); return; }
      if (e.type !== 'order' && !(e.type === 'expect' && e.what === 'refund' && e.order)) return;
      var shop = e.shop || e.party || s.inst || '';
      var oid = e.order || '';
      // a status mail without the order's number joins the shop's latest order with the same items, else stands alone
      var k = oid ? 'order:' + String(oid).replace(/[^A-Za-z0-9]/g, '').toUpperCase() : 'order:' + keyOf(shop) + ':' + s.d;
      // (no items, or none yet: no order can be it)
      if (!oid && !(Array.isArray(e.items) && !e.items.length) && e.items) {
        var prior = priorOf(e, shop);
        if (prior) k = prior;
      }
      if (!by[k]) {
        rank[k] = made++;
        if (!keysOf.has(shop)) keysOf.set(shop, []);
        keysOf.get(shop).push(k);
      }
      var o = by[k] = by[k] || { kind: 'order', id: k, shop: shop, order: oid, steps: [], items: [], total: null, promised: [] };
      if (e.type === 'order') {
        if (e.total > 0 && o.total == null) o.total = e.total;
        (e.items || []).forEach(function (it) { if (o.items.indexOf(it) < 0) o.items.push(it); });
        var t0 = e.status === 'refunded' ? 'refund started' : e.status;   // the shop's word; the money is the credit
        if (!o.steps.some(function (x) { return x.t === t0 && x.d === s.d; })) o.steps.push(step(s, t0, { amt: e.status === 'placed' ? e.total : undefined }));
      } else {
        o.promised.push({ d: s.d, amt: e.amt, by: e.by || '', mail: s.mail });
        o.steps.push(step(s, 'refund promised', { amt: e.amt, by: e.by }));
      }
    });
    function parcelStep(s, e) {
      var t = e.ret ? RETURN_T[e.step] : PARCEL_T[e.step];
      var oid = e.order ? String(e.order) : e.awb && awbOrder[parcelKey(e.awb)] ? awbOrder[parcelKey(e.awb)] : '';
      var key = oid ? parcelKey(oid) : parcelKey(e.awb);
      if (!t || !key) return;
      var k = 'order:' + key;
      if (!by[k]) {
        rank[k] = made++;
        var sh = e.shop || e.courier || s.inst || '';
        if (!keysOf.has(sh)) keysOf.set(sh, []);
        keysOf.get(sh).push(k);
      }
      var o = by[k] = by[k] || { kind: 'order', id: k, shop: e.shop || e.courier || s.inst || '', order: oid, steps: [], items: [], total: null, promised: [] };
      if (e.shop && (!o.shop || o.shop === e.courier)) o.shop = e.shop;
      if (e.awb && !o.awb) o.awb = String(e.awb);
      // (one step told by the shop and by the courier the same day is one: what either printed fills the other)
      var twin = o.steps.filter(function (x) { return x.t === t && x.d === s.d; })[0];
      var extra = { on: e.on, by: e.by, win: e.win && (e.win.from || e.win.to) ? e.win : undefined, cod: +e.cod > 0 ? +e.cod : undefined, next: e.next, until: e.holdUntil, courier: e.courier, parcel: true };
      if (twin) { for (var f in extra) if (extra[f] !== undefined && extra[f] !== '' && twin[f] === undefined) twin[f] = extra[f]; return; }
      o.steps.push(step(s, t, extra));
    }
    var out = [];
    Object.keys(by).forEach(function (k) {
      var o = by[k];
      o.steps.sort(function (a, b) { return a.d < b.d ? -1 : a.d > b.d ? 1 : (ORDER_RANK[a.t] || 9) - (ORDER_RANK[b.t] || 9); });
      var first = o.steps.length ? o.steps[0].d : '';
      // the charge: a payment out of the order's total, a few days around when it was placed, to this shop or unnamed
      if (o.total > 0 && first) {
        var ch = NEAR(o.total).filter(function (m) { return m.e.dir === 'out' && same(m.e.amt, o.total) && m.d >= addDays(first, -2) && m.d <= addDays(first, 4) && !used[m.mail] && (!m.e.party || agree(m.e.party, o.shop) || agree(m.from, o.shop)); })[0];
        if (ch) { used[ch.mail] = 'order'; o.steps.push({ d: ch.d, t: 'charged', amt: ch.e.amt, how: viaText(ch.e.via) || undefined, mail: ch.mail }); }
      }
      // the refund: what the build's refunds (engine/21b) set against it, the one place a refund meets its credit: the
      // bank's credit (or a statement's line) is "refunded", the shop's word alone that it sent it "refund started"
      o.promised.forEach(function (p) { refundSteps(o.steps, p, used, 'order', 'refunded'); });
      o.steps.sort(function (a, b) { return a.d < b.d ? -1 : a.d > b.d ? 1 : (ORDER_RANK[a.t] || 9) - (ORDER_RANK[b.t] || 9); });
      // (where a parcel stands among out, missed, moved and held is the latest of them; it never goes back past them)
      var top = o.steps.reduce(function (best, x) { var a = ORDER_RANK[x.t] || 0, b = ORDER_RANK[best] || 0; return a > b || (a === b && LATEST_WINS[x.t] && LATEST_WINS[best]) ? x.t : best; }, 'placed');
      // (one refund told by two mails is one: its row once)
      var waiting = o.promised.filter(function (p, i) { return p.open && !o.promised.slice(0, i).some(function (q) { return q.open && q.row && q.row === p.row; }); });
      var status = waiting.length ? (waiting.some(function (p) { return p.late; }) ? 'refund late' : 'refund waiting') : top;
      out.push({ kind: 'order', id: o.id, title: o.shop + (o.items.length ? ' · ' + o.items[0] : ''), shop: o.shop, order: o.order || undefined, awb: o.awb || undefined, total: o.total || undefined,
        items: o.items.length ? o.items.slice(0, 6) : undefined, status: status, last: o.steps.length ? o.steps[o.steps.length - 1].d : '',
        next: waiting.length ? { d: waiting[0].by || '', amt: waiting[0].left, what: 'refund' } : undefined, steps: o.steps });
    });
    return out;
  }

  /* ------------------------------------------------------------ policies: issued → premiums → next due, grace, renewed, lapsed */
  function policyThreads(steps, moves, today, used) {
    var by = {};
    steps.forEach(function (s) {
      var e = s.e;
      // a premium told as a bill or an auto-debit (a bank's "NACH for HDFC Life", an insurer's "premium is due") is a
      // step of the policy it pays, not a bill or a subscription of its own
      if ((e.type === 'due' || e.type === 'mandate') && routeOf(e, s) === 'policy') {
        var who = s.ik === 'insurer' ? s.inst : tidyName((e.type === 'due' ? e.payee : e.party) || '');
        if (genericName(who) || !(e.amt > 0)) return;
        var act = e.type === 'mandate' && e.action === 'done' ? 'paid' : e.type === 'mandate' && e.action === 'cancelled' ? 'autopay stopped' : 'due';
        e = { type: 'policy', action: act, insurer: who, premium: e.amt, due: act === 'due' ? (e.due || e.date || '') : '' };
      }
      if (e.type !== 'policy') return;
      var ins = e.insurer || s.inst || 'Insurer';
      var k = 'policy:' + (e.policyNo ? String(e.policyNo).toUpperCase() : keyOf(ins) + ':' + keyOf(e.plan || ''));
      // a mail naming only the insurer joins that insurer's policy of the same premium, else its one policy
      if (!e.policyNo) {
        var mine = Object.keys(by).filter(function (x) { return sameName(by[x].insurer, ins); });
        var priced = e.premium > 0 ? mine.filter(function (x) { return same(by[x].premium, e.premium); }) : [];
        if (priced.length === 1) k = priced[0]; else if (mine.length === 1) k = mine[0];
      }
      else if (!by[k]) { var loose = Object.keys(by).filter(function (x) { return !by[x].no && sameName(by[x].insurer, ins); })[0]; if (loose) { by[k] = by[loose]; by[k].id = k; delete by[loose]; } }
      var p = by[k] = by[k] || { kind: 'policy', id: k, insurer: ins, no: '', plan: '', steps: [], premium: null, cover: null, dues: [] };
      if (e.policyNo) p.no = e.policyNo;
      if (e.plan && !p.plan) p.plan = e.plan;
      if (e.premium > 0) p.premium = e.premium;
      if (e.cover > 0) p.cover = e.cover;
      if (e.due) p.dues.push(e.due);
      if (!p.steps.some(function (x) { return x.t === e.action && x.d === s.d; })) p.steps.push(step(s, e.action, { amt: e.premium, due: e.due }));
    });
    var out = [];
    Object.keys(by).forEach(function (k) {
      var p = by[k];
      // premiums paid by bank, card or app that the insurer's own mail didn't tell: payments to this insurer of the premium
      if (p.premium > 0) NEAR(p.premium).forEach(function (m) {
        var e = m.e;
        if (e.dir !== 'out' || used[m.mail] || !same(e.amt, p.premium)) return;
        if (!(sameName(e.party || '', p.insurer) || /premium/.test(e.purpose || ''))) return;
        if (p.steps.some(function (x) { return x.t === 'paid' && Math.abs(between(x.d, m.d)) <= 5; })) { used[m.mail] = 'policy'; return; }
        used[m.mail] = 'policy';
        p.steps.push({ d: m.d, t: 'paid', amt: e.amt, how: viaText(e.via) || undefined, mail: m.mail });
      });
      p.steps.sort(function (a, b) { return a.d < b.d ? -1 : 1; });
      var paid = p.steps.filter(function (x) { return x.t === 'paid' || x.t === 'renewed'; });
      var lastPaid = paid.length ? paid[paid.length - 1].d : '';
      var life = /life|lic\b|term/i.test(p.insurer + ' ' + p.plan);
      var grace = (K.grace && (life ? K.grace.life : K.grace.health) || {})[12] || 30;
      // a due date is settled by a premium paid from two months before it to the end of its grace
      var dues = p.dues.filter(function (d) { return !paid.some(function (x) { return x.d >= addDays(d, -62) && x.d <= addDays(d, grace); }); }).sort();
      // a renewal sets the next due itself ("Next due date 22-02-2027"): the latest due a paid premium points to
      var renewedTo = p.steps.filter(function (x) { return x.t === 'renewed' && x.due && x.due > x.d; }).map(function (x) { return x.due; }).sort().pop() || '';
      var due = dues.pop() || renewedTo || '';
      var estimated = false;
      // a year after the last premium, until a mail says otherwise (not for a single trip's travel cover)
      if (!due && lastPaid && !/travel|trip/i.test(p.plan + ' ' + p.insurer)) { due = addDays(lastPaid, 365); estimated = true; }
      var lapsedStep = p.steps.filter(function (x) { return x.t === 'lapsed'; }).pop();
      var status = lapsedStep && (!lastPaid || lastPaid < lapsedStep.d) ? 'lapsed'
        : due && due < today ? (addDays(due, grace) >= today ? 'in grace' : (estimated ? 'renewal not seen' : 'overdue'))
        : due ? 'active' : p.steps.some(function (x) { return x.t === 'issued'; }) ? 'active' : 'seen';
      out.push({ kind: 'policy', id: p.id, title: p.insurer + (p.plan ? ' · ' + p.plan : ''), insurer: p.insurer, no: p.no || undefined, plan: p.plan || undefined,
        premium: p.premium || undefined, cover: p.cover || undefined, status: status, last: p.steps.length ? p.steps[p.steps.length - 1].d : '',
        next: due ? { d: due, amt: p.premium || undefined, what: estimated ? 'renewal (expected)' : 'premium', grace: grace } : undefined, steps: p.steps });
    });
    return out;
  }

  /* ------------------------------------------------------------ deposits: opened → renewed → matured or closed */
  function depositThreads(steps, moves, today, used) {
    var by = {};
    steps.forEach(function (s) {
      var e = s.e;
      if (e.type !== 'deposit') return;
      var inst = e.inst || s.inst || 'Bank';
      var k = 'deposit:' + lc(inst) + ':' + (e.no || (e.amt ? String(e.amt) : s.d));
      var dp = by[k] = by[k] || { kind: 'deposit', id: k, inst: inst, no: e.no || '', steps: [], amt: null, rate: null, mat: '', matAmt: null };
      ['amt', 'rate', 'matAmt'].forEach(function (f) { if (e[f] > 0) dp[f] = e[f]; });
      if (e.mat) dp.mat = e.mat;
      // the same step told twice (two alerts for one debit) is one
      if (dp.steps.some(function (x) { return x.t === e.action && x.d === s.d && (x.amt || 0) === (e.amt || 0); })) return;
      dp.steps.push(step(s, e.action, { amt: e.amt, rate: e.rate, mat: e.mat }));
    });
    // the advice's mail names no number ("Your fixed deposit e-advice is here"): it is the deposit the same bank booked
    // within a few days, told twice
    Object.keys(by).forEach(function (k) {
      var dp = by[k];
      if (dp.no || !by[k]) return;
      var d0 = dp.steps[0] && dp.steps[0].d;
      var twin = Object.keys(by).map(function (k2) { return by[k2]; }).filter(function (o) {
        return o !== dp && o.no && lc(o.inst) === lc(dp.inst) && o.steps.some(function (x) { return (x.t === 'open' || x.t === 'renew') && d0 && Math.abs(between(x.d, d0)) <= 5; });
      })[0];
      if (!twin) return;
      dp.steps.forEach(function (x) { if (x.t === 'open' && twin.steps.some(function (y) { return y.t === 'open'; })) x.t = 'advice'; twin.steps.push(x); });
      ['amt', 'rate', 'matAmt'].forEach(function (f) { if (!(twin[f] > 0) && dp[f] > 0) twin[f] = dp[f]; });
      if (!twin.mat && dp.mat) twin.mat = dp.mat;
      delete by[k];
    });
    var out = [];
    Object.keys(by).forEach(function (k) {
      var dp = by[k];
      var opened = dp.steps.filter(function (x) { return x.t === 'open' || x.t === 'renew'; })[0] || dp.steps.filter(function (x) { return x.t === 'advice'; })[0];
      if (dp.amt > 0 && opened) {
        var put = NEAR(dp.amt).filter(function (m) { return m.e.dir === 'out' && same(m.e.amt, dp.amt) && Math.abs(between(m.d, opened.d)) <= 3 && !used[m.mail]; })[0];
        if (put) { used[put.mail] = 'deposit'; dp.steps.push({ d: put.d, t: 'money in', amt: put.e.amt, how: viaText(put.e.via) || undefined, mail: put.mail }); }
      }
      // paid out: a credit of its maturity amount around its maturity day (any credit those days is not its payout, and
      // one on auto-renewal pays nothing out)
      var renews = dp.steps.some(function (x) { return x.t === 'renew'; });
      if (dp.mat && dp.matAmt && !renews) {
        var back = NEAR(dp.matAmt).filter(function (m) { return m.e.dir === 'in' && m.d >= addDays(dp.mat, -2) && m.d <= addDays(dp.mat, 7) && same(m.e.amt, dp.matAmt) && !used[m.mail]; })[0];
        if (back) { used[back.mail] = 'deposit'; dp.steps.push({ d: back.d, t: 'paid out', amt: back.e.amt, how: viaText(back.e.via) || undefined, mail: back.mail }); }
      }
      dp.steps.sort(function (a, b) { return a.d < b.d ? -1 : 1; });
      var ended = dp.steps.some(function (x) { return /close|mature|paid out/.test(x.t); });
      out.push({ kind: 'deposit', id: dp.id, title: dp.inst + ' FD' + (dp.no ? ' ••' + String(dp.no).slice(-4) : ''), inst: dp.inst, no: dp.no || undefined,
        amt: dp.amt || undefined, rate: dp.rate || undefined, mat: dp.mat || undefined, matAmt: dp.matAmt || undefined,
        status: ended ? 'closed' : dp.mat && dp.mat < today ? (renews ? 'renewed' : 'matured') : 'running', last: dp.steps.length ? dp.steps[dp.steps.length - 1].d : '',
        next: !ended && dp.mat && dp.mat >= today ? { d: dp.mat, amt: dp.matAmt || undefined, what: 'maturity' } : undefined, steps: dp.steps });
    });
    return out;
  }

  /* ------------------------------------------------------------ investments */
  function investThreads(steps, moves, today, used) {
    var ipo = {}, fund = {}, stock = {}, div = {};
    steps.forEach(function (s) {
      var e = s.e;
      if (e.type === 'ipo') {
        var k = 'ipo:' + keyOf(e.company || s.subj);
        if (!ipo[k]) { var typo = Object.keys(ipo).filter(function (x) { return closeKey(x, k); })[0]; if (typo) k = typo; }
        var t = ipo[k] = ipo[k] || { kind: 'ipo', id: k, title: e.company || 'IPO', steps: [] };
        t.steps.push(step(s, e.action, { amt: e.amt, shares: e.shares }));
      } else if (e.type === 'expect' && e.what === 'unblock') {
        var k2 = 'ipo:' + keyOf(e.party || s.subj);
        if (!ipo[k2]) { var typo2 = Object.keys(ipo).filter(function (x) { return closeKey(x, k2); })[0]; if (typo2) k2 = typo2; }
        var t2 = ipo[k2] = ipo[k2] || { kind: 'ipo', id: k2, title: e.party || 'IPO', steps: [] };
        t2.steps.push(step(s, 'unblock due', { amt: e.amt, by: e.on }));
      } else if (e.type === 'expect' && (e.what === 'sip' || e.what === 'buy') && e.party && /fund|plan|etf|growth/i.test(e.party)) {
        // an order placed at a platform: a step of the fund's thread, not money in it until the fund allots units
        var ko = 'fund:' + keyOf(e.party);
        var fo0 = fund[ko] = fund[ko] || { kind: 'fund', id: ko, title: e.party, folio: '', steps: [] };
        if (!fo0.steps.some(function (x) { return x.d === (e.on || s.d) && same(x.amt, e.amt) && x.t === 'ordered'; })) fo0.steps.push({ d: e.on || s.d, t: 'ordered', amt: e.amt, mail: s.mail });
      } else if (e.type === 'fund') {
        var kf = 'fund:' + keyOf(e.scheme || '');
        var f = fund[kf] = fund[kf] || { kind: 'fund', id: kf, title: e.scheme || 'Fund', folio: '', steps: [] };
        if (e.folio) f.folio = e.folio;
        if (!f.steps.some(function (x) { return x.d === (e.date || s.d) && same(x.amt, e.amt) && x.t === e.action; })) f.steps.push({ d: e.date || s.d, t: e.action, amt: e.amt, units: e.units, nav: e.nav, mail: s.mail });
      } else if (e.type === 'trade' && (e.side === 'buy' || e.side === 'sell') && +e.qty > 0) {
        var ks = 'stock:' + (e.isin || keyOf(e.name || ''));
        var st = stock[ks] = stock[ks] || { kind: 'stock', id: ks, title: e.name || e.isin || 'Shares', isin: e.isin || '', steps: [] };
        st.steps.push({ d: e.date || s.d, t: e.side, qty: e.qty, price: e.price, amt: e.value, mail: s.mail });
      } else if (e.type === 'dividend') {
        var kd = 'dividend:' + keyOf(e.company || '');
        var dv = div[kd] = div[kd] || { kind: 'dividend', id: kd, title: e.company || 'Dividend', steps: [] };
        if (!dv.steps.some(function (x) { return x.d === (e.date || s.d) && same(x.amt, e.amt); })) dv.steps.push({ d: e.date || s.d, t: 'dividend', amt: e.amt, mail: s.mail });
      }
    });
    var out = [];
    Object.keys(ipo).forEach(function (k) {
      var t = ipo[k];
      t.steps.sort(function (a, b) { return a.d < b.d ? -1 : 1; });
      var allot = t.steps.filter(function (x) { return x.t === 'allotted'; }).pop(), no = t.steps.some(function (x) { return x.t === 'not-allotted'; });
      var unb = t.steps.filter(function (x) { return x.t === 'unblock due'; })[0];
      if (unb && t.steps.some(function (x) { return x.t === 'unblocked'; })) unb.t = 'unblock promised';
      out.push({ kind: 'ipo', id: t.id, title: t.title, status: allot ? 'allotted' : no ? 'not allotted' : t.steps.some(function (x) { return x.t === 'blocked'; }) ? 'money blocked' : 'applied',
        shares: allot ? allot.shares : undefined, amt: allot ? allot.amt : undefined, last: t.steps[t.steps.length - 1].d, steps: t.steps,
        next: unb && unb.t === 'unblock due' && unb.by && unb.by >= today ? { d: unb.by, amt: unb.amt, what: 'unblock' } : undefined });
    });
    Object.keys(fund).forEach(function (k) {
      var f = fund[k];
      f.steps.sort(function (a, b) { return a.d < b.d ? -1 : 1; });
      var put = 0, took = 0, units = 0;
      f.steps.forEach(function (x) { if (x.t === 'redeem') { took += +x.amt || 0; units -= +x.units || 0; } else if (x.t !== 'switch' && x.t !== 'ordered') { put += +x.amt || 0; units += +x.units || 0; } });
      var sips = f.steps.filter(function (x) { return x.t === 'sip'; });
      var orders = f.steps.filter(function (x) { return x.t === 'ordered'; });
      out.push({ kind: 'fund', id: f.id, title: f.title, folio: f.folio || undefined, invested: money(put), redeemed: money(took) || undefined, units: units ? Math.round(units * 1000) / 1000 : undefined,
        status: sips.length >= 2 || (sips.length && orders.length) || orders.length >= 2 ? 'SIP running' : took > 0 && took >= put ? 'redeemed' : put > 0 ? 'held' : 'ordered', last: f.steps[f.steps.length - 1].d, steps: f.steps });
    });
    Object.keys(stock).forEach(function (k) {
      var s = stock[k];
      s.steps.sort(function (a, b) { return a.d < b.d ? -1 : 1; });
      var qty = s.steps.reduce(function (n, x) { return n + (x.t === 'sell' ? -1 : 1) * (+x.qty || 0); }, 0);
      out.push({ kind: 'stock', id: s.id, title: s.title, isin: s.isin || undefined, qty: qty, status: qty > 0 ? 'held' : 'sold', last: s.steps[s.steps.length - 1].d, steps: s.steps });
    });
    Object.keys(div).forEach(function (k) {
      var d = div[k];
      d.steps.sort(function (a, b) { return a.d < b.d ? -1 : 1; });
      out.push({ kind: 'dividend', id: d.id, title: d.title, total: money(d.steps.reduce(function (n, x) { return n + (+x.amt || 0); }, 0)), status: 'paid', last: d.steps[d.steps.length - 1].d, steps: d.steps });
    });
    return out;
  }

  /* ------------------------------------------------------------ subscriptions */
  function subThreads(steps, moves, today, used) {
    var by = {};
    steps.forEach(function (s) {
      var e = s.e;
      if (e.type !== 'mandate' || !/created|upcoming|cancelled/.test(e.action)) return;
      var route = routeOf(e, s);
      if (route !== 'sub' && route !== 'standing') return;
      var bankish = /bank|card/.test(lc(s.from)) && !/apple|google|anthropic|netflix|spotify|patreon/.test(lc(s.from));
      // a service's own mail is named for the service ("Your Pro subscription is confirmed" is the service's); a bank's
      // for whom it pays
      var who = bankish || route === 'standing' ? (e.party || '') : (brandOf(s) || e.party || '');
      if (genericName(who)) who = bankish ? '' : brandOf(s);
      who = knownName(tidyName(who));
      if (genericName(who)) return;
      var k = (route === 'standing' ? 'standing:' : 'sub:') + keyOf(who);
      var t = by[k] = by[k] || { kind: route === 'standing' ? 'standing' : 'sub', id: k, title: who, bank: bankish, steps: [], price: null, every: '' };
      if (e.amt > 0) t.price = e.amt;
      if (e.every) t.every = e.every;
      t.steps.push(step(s, e.action === 'created' ? 'started' : e.action === 'upcoming' ? 'renewing' : 'cancelled', { amt: e.amt, on: e.date }));
    });
    var out = [];
    Object.keys(by).forEach(function (k) {
      var t = by[k];
      // its charges: payments out to the same name, at its price when it has one
      (t.price ? NEAR(t.price) : moves).forEach(function (m) {
        var e = m.e;
        if (e.dir !== 'out' || used[m.mail]) return;
        if (!(agree(e.party || '', t.title) || agree(m.from, t.title))) return;
        if (t.price && !same(e.amt, t.price)) return;
        used[m.mail] = 'sub';
        t.steps.push({ d: m.d, t: 'charged', amt: e.amt, how: viaText(e.via) || undefined, mail: m.mail });
      });
      t.steps.sort(function (a, b) { return a.d < b.d ? -1 : 1; });
      var last = t.steps[t.steps.length - 1];
      var cancelled = t.steps.filter(function (x) { return x.t === 'cancelled'; }).pop();
      var renew = t.steps.filter(function (x) { return x.t === 'renewing' || x.t === 'started'; }).map(function (x) { return x.on; }).filter(Boolean).sort().pop();
      out.push({ kind: t.kind, id: t.id, title: t.title, price: t.price || undefined, every: t.every || undefined,
        status: cancelled && cancelled.d >= (renew || '') ? 'cancelled' : 'active', last: last.d,
        next: !cancelled && renew && renew >= today ? { d: renew, amt: t.price || undefined, what: 'renews' } : undefined, steps: t.steps });
    });
    return out;
  }

  /* ------------------------------------------------------------ refunds promised outside an order */
  function refundThreads(steps, moves, today, used) {
    var out = [], byRow = [];
    steps.forEach(function (s) {
      var e = s.e;
      if (e.type !== 'expect' || e.dir !== 'in' || e.order || e.what === 'unblock') return;
      // a refund: its money is the build's (refundSteps); two mails promising one refund are one thread
      if (e.what === 'refund') {
        var p = { mail: s.mail, amt: e.amt, by: e.by || e.on || '' };
        var said = step(s, 'refund promised', { amt: e.amt, by: e.by || e.on });
        var mine = p.mail && BACK[p.mail] ? byRow.filter(function (x) { return x.row === BACK[p.mail]; })[0] : null;
        if (mine) { mine.t.steps.push(said); mine.t.steps.sort(function (a, b) { return a.d < b.d ? -1 : a.d > b.d ? 1 : 0; }); mine.t.last = mine.t.steps[mine.t.steps.length - 1].d; return; }
        var st0 = [said];
        refundSteps(st0, p, used, 'refund', 'came');
        st0.sort(function (a, b) { return a.d < b.d ? -1 : a.d > b.d ? 1 : 0; });
        var th = { kind: 'refund', id: 'refund:' + s.mail, title: (e.party || s.inst || 'Refund') + ' refund',
          status: !p.open ? (p.row && p.row.stage !== 'back' ? 'sent' : 'came') : p.late ? 'late' : 'waiting',
          last: st0[st0.length - 1].d, next: p.open ? { d: p.by, amt: p.left, what: e.what } : undefined, steps: st0 };
        if (p.row) byRow.push({ row: p.row, t: th });
        out.push(th);
        return;
      }
      var hi = e.by ? addDays(e.by, 10) : e.on ? addDays(e.on, 7) : addDays(s.d, 30);
      var rf = NEAR(e.amt).filter(function (m) { return m.e.dir === 'in' && same(m.e.amt, e.amt) && m.d >= addDays(s.d, -1) && m.d <= hi && !used[m.mail]; })[0];
      if (rf) used[rf.mail] = 'refund';
      var st = [step(s, e.what === 'refund' ? 'refund promised' : 'money promised', { amt: e.amt, by: e.by || e.on })];
      if (rf) st.push({ d: rf.d, t: 'came', amt: rf.e.amt, how: viaText(rf.e.via) || undefined, mail: rf.mail });
      var by = e.by || e.on || '';
      out.push({ kind: 'refund', id: 'refund:' + s.mail, title: (e.party || s.inst || 'Refund') + ' ' + (e.what === 'refund' ? 'refund' : e.what || ''), status: rf ? 'came' : by && by < today ? 'late' : 'waiting',
        last: st[st.length - 1].d, next: rf ? undefined : { d: by, amt: e.amt, what: e.what }, steps: st });
    });
    return out;
  }

  /* ------------------------------------------------------------ the second witness
     What one mail says, checked against what another says:
       balances  an account's alerts carry the balance after each payment; between two of them, the payments kosh
                 saw must add up (balance + money in − money out = the next balance). Where they do, every payment
                 in between is confirmed by the bank's own arithmetic; where they don't, the gap is money that moved
                 with no mail saying so (or an amount misread), and it is said, with the days it fell between. A gap
                 one payment kosh couldn't put on an account explains (a debit card's, a UPI app's) is that payment.
       echoes    the same payment told by two senders (the bank's alert and the shop's receipt, CRED's)
       linked    a payment a thread took: the statement it cleared, the order it paid, the premium
       disagree  two mails with one reference and different amounts; a reading the sender's own template doubts
     A payment none of these touch stands on one mail alone, and is counted as such. */
  function timeKey(d, t) { return d + 'T' + (t ? String(t).slice(0, 5) : ''); }
  function checksOf(steps, moves, used) {
    var accts = [], byMail = {};
    moves.forEach(function (m) { (byMail[m.mail] = byMail[m.mail] || []).push(m); (m.echo || []).forEach(function (x) { (byMail[x] = byMail[x] || []).push(m); }); });
    function acctFor(v, make) {
      if (!v || (v.kind !== 'account' && v.kind !== 'wallet') || v.debit) return null;
      var l4 = last4Of(v), inst = lc(v.inst || '');
      if (!l4 && !inst) return null;
      var a = accts.filter(function (x) { return x.kind === v.kind && (x.inst === inst || !x.inst || !inst) && (l4 ? sameLast(x.last4, l4) : !x.last4); })[0];
      if (!a && make) { a = { kind: v.kind, inst: inst, name: v.inst || '', last4: l4, moves: [], points: [] }; accts.push(a); }
      if (a && !a.name && v.inst) { a.name = v.inst; a.inst = inst; }
      return a;
    }
    // a balance, and the payment it came after (the same mail's); then every payment on an account that has one
    steps.forEach(function (s) {
      if (s.e.type !== 'balance' || !(s.e.amt >= 0) && !(s.e.amt < 0)) return;
      var anchor = (byMail[s.mail] || []).filter(function (m) { var v = m.e.via; return v && (v.kind === 'account' || v.kind === 'wallet') && !v.debit; })[0] || null;
      var a = acctFor(s.e.via || (anchor && anchor.e.via), true) || (anchor && acctFor(anchor.e.via, true));
      if (!a) return;
      if (anchor && a.moves.indexOf(anchor) < 0) a.moves.push(anchor);
      var d = anchor ? anchor.d : s.d, t = anchor ? anchor.e.time : s.e.time;
      if (a.points.some(function (p) { return p.mail === s.mail; })) return;
      a.points.push({ d: d, k: timeKey(d, t), timed: !!t, bal: +s.e.amt, mail: s.mail, anchor: anchor });
    });
    moves.forEach(function (m) { var a = acctFor(m.e.via, false); if (a && a.moves.indexOf(m) < 0) a.moves.push(m); });
    var out = { accounts: [], links: 0, held: 0, unclear: 0, breaks: [], witnessed: 0, alone: 0, contradictions: [] };
    var confirmed = {};
    // payments kosh couldn't put on an account: what a gap might be
    var loose = moves.filter(function (m) { var v = m.e.via || {}; return !acctFor(v, false) && (v.kind === 'upi' || v.kind === 'other' || v.debit || (v.kind === 'account' && !last4Of(v))); });
    accts.forEach(function (a) {
      if (!a.points.length) return;
      a.points.sort(function (x, y) { return x.k < y.k ? -1 : x.k > y.k ? 1 : 0; });
      a.moves.sort(function (x, y) { var kx = timeKey(x.d, x.e.time), ky = timeKey(y.d, y.e.time); return kx < ky ? -1 : kx > ky ? 1 : 0; });
      var acc = { title: viaText({ kind: a.kind, inst: a.name, last4: a.last4 }), kind: a.kind, inst: a.name, last4: a.last4, links: 0, held: 0, bal: a.points[a.points.length - 1].bal, d: a.points[a.points.length - 1].d };
      for (var i = 1; i < a.points.length; i++) {
        var P = a.points[i - 1], Q = a.points[i];
        if (dayN(Q.d) - dayN(P.d) > 45) continue;   // too far apart to say anything
        out.links++; acc.links++;
        // the payments between them: after P's, up to and including Q's. A payment on either day with no time
        // could fall on either side: then the link can't be checked
        var unclear = false, inn = [];
        a.moves.forEach(function (m) {
          if (m === P.anchor) return;
          var k = timeKey(m.d, m.e.time);
          if (m === Q.anchor) { inn.push(m); return; }
          if (m.d < P.d || m.d > Q.d) return;
          if ((m.d === P.d && (!m.e.time || !P.timed)) || (m.d === Q.d && (!m.e.time || !Q.timed))) { unclear = true; return; }
          if (k > P.k && k <= Q.k) inn.push(m);
        });
        if (unclear) { out.unclear++; continue; }
        var expect = money(P.bal + inn.reduce(function (n, m) { return n + (m.e.dir === 'in' ? 1 : -1) * m.e.amt; }, 0));
        var gap = money(Q.bal - expect);
        if (Math.abs(gap) <= 1) {
          out.held++; acc.held++;
          inn.concat(P.anchor ? [P.anchor] : []).forEach(function (m) { confirmed[m.id] = 1; });
          continue;
        }
        var br = { acct: acc.title, from: P.d, to: Q.d, gap: gap, dir: gap > 0 ? 'in' : 'out', amt: Math.abs(gap), mails: [P.mail, Q.mail] };
        var by = loose.filter(function (m) { return m.d >= P.d && m.d <= Q.d && same(m.e.amt, Math.abs(gap)) && m.e.dir === br.dir && (!a.name || !m.e.via.inst || lc(m.e.via.inst) === a.inst); })[0];
        if (by) { br.by = by.mail; br.byText = viaText(by.e.via) || by.e.party || ''; confirmed[by.id] = 1; out.held++; acc.held++; }
        out.breaks.push(br);
      }
      out.accounts.push(acc);
    });
    out.breaks.sort(function (x, y) { return x.to < y.to ? 1 : -1; });
    // payments with a second witness, and those on one mail alone
    moves.forEach(function (m) { if (confirmed[m.id] || (m.echo && m.echo.length) || used[m.mail]) out.witnessed++; else out.alone++; });
    // mails that disagree: one reference, two amounts
    var byRef = {};
    steps.forEach(function (s) { var r = s.e.type === 'move' && s.e.ref && String(s.e.ref).length >= 6 ? String(s.e.ref) : ''; if (r) (byRef[r] = byRef[r] || []).push(s); });
    Object.keys(byRef).forEach(function (r) {
      var l = byRef[r], amts = [];
      l.forEach(function (s) { if (!amts.some(function (x) { return Math.abs(x - s.e.amt) <= 1; })) amts.push(s.e.amt); });
      if (amts.length > 1) out.contradictions.push({ d: l[0].d, what: 'amount', ref: r, amts: amts, mails: l.map(function (s) { return s.mail; }) });
    });
    // a reading the sender's own template has never seen (reader.js: the book doubts it)
    steps.forEach(function (s) { if (s.e.doubt && s.e.doubt.length) out.contradictions.push({ d: s.d, what: 'template', fields: s.e.doubt, amt: s.e.amt || s.e.total || undefined, mails: [s.mail] }); });
    out.contradictions.sort(function (x, y) { return x.d < y.d ? 1 : -1; });
    out.breaks = out.breaks.slice(0, 60);
    out.contradictions = out.contradictions.slice(0, 40);
    return out;
  }

  /* ------------------------------------------------------------ the threads as the person sees them
     The last look before they are shown: a thread says something (a card with no statement is only payments, which
     the ledger already has; a deposit with no number, amount or maturity is no deposit kosh can follow), a name
     reads as a name, and only what is recent asks for attention: a bill unpaid two years ago, a renewal never seen
     last year, is the thread's history, not something to act on now ("no news" since its last step). */
  var ALARM = /overdue|late|unpaid|lapsed|in grace|not seen|^open$|part paid|minimum paid|money blocked|waiting/;
  function tidyThreads(threads, today) {
    var lately = addDays(today, -45);
    return threads.filter(function (t) {
      if (t.kind === 'card' && !(t.cycles && t.cycles.length)) return false;
      if (t.kind === 'deposit' && !t.no && !(t.amt > 0) && !t.mat) return false;
      if (/^(?:sub|standing|bill)$/.test(t.kind) && genericName(t.title)) return false;
      if (t.kind === 'policy') t.title = t.insurer + (t.plan ? ' · ' + tidyName(t.plan) : '');
      else if (t.kind !== 'order' && t.kind !== 'card' && t.kind !== 'deposit' && t.kind !== 'refund') t.title = knownName(tidyName(t.title));
      if (t.next && t.next.d && t.next.d < today && !/maturity/.test(t.next.what || '')) {
        // a date gone by is no longer what's next; if it is long gone, the alarm is history
        if (t.next.d < lately) delete t.next;
      }
      var when = (t.next && t.next.d) || t.last || '';
      if (ALARM.test(t.status || '') && when && when < lately) t.status = 'no news';
      return true;
    });
  }

  /* ------------------------------------------------------------ the whole journey */
  // refunds: the build's refunds (refundBook), so a promise's credit is the one the build set against it
  function journey(records, prof, refunds) {
    prof = prof || {};
    var today = prof.today || isoN(Math.floor(Date.now() / 864e5));
    BACK = refunds || {};
    KNOWN = Object.create(null);
    var steps = stepsOf(records || []);
    // a deposit's advice opened on the phone (docread.js): its terms are a step in the deposit's thread
    (prof.deposits || []).forEach(function (d, i) {
      if (!d || !(d.amt > 0) || !okDay(d.start)) return;
      steps.push({ e: { type: 'deposit', action: 'advice', inst: d.inst, no: String(d.depNo || '').slice(-4), amt: +d.amt, rate: +d.rate || undefined, mat: d.mat || undefined, matAmt: +d.matAmt || undefined },
        d: d.start, n: dayN(d.start), id: 'advice:' + i, mail: d.src || ('advice:' + i), from: '', inst: d.inst || '', subj: 'Deposit advice', acct: '' });
    });
    steps.sort(function (a, b) { return a.d < b.d ? -1 : a.d > b.d ? 1 : 0; });
    // the services that write about their own plans: a bank's auto-debit for one of them is that subscription
    SUBS = [];
    steps.forEach(function (s) {
      var e = s.e;
      if (e.type !== 'mandate' || /bank|billdesk|razorpay|payu|cashfree|npci/.test(lc(s.from)) || s.ik === 'bank' || s.ik === 'card' || s.ik === 'gateway') return;
      var b = brandOf(s);
      if (b && SUBS.indexOf(b) < 0) SUBS.push(b);
    });
    var moves = dedupeMoves(steps.filter(function (s) { return s.e.type === 'move' && s.e.amt > 0 && (!s.e.cur || s.e.cur === 'INR'); }));
    var used = {};
    NEAR = amtIndex(moves);
    var threads = []
      .concat(cardThreads(steps, moves, today, used))
      .concat(policyThreads(steps, moves, today, used))
      .concat(depositThreads(steps, moves, today, used))
      .concat(billThreads(steps, moves, today, used))
      .concat(subThreads(steps, moves, today, used))
      .concat(orderThreads(steps, moves, today, used))
      .concat(investThreads(steps, moves, today, used))
      .concat(refundThreads(steps, moves, today, used));
    threads = tidyThreads(threads, today);
    // each step says the words it was read from (reader.js › quoteOf): the mail's line holding its figure
    var QUOTES = {};
    steps.forEach(function (s) { if (s.e.q) (QUOTES[s.mail] = QUOTES[s.mail] || []).push({ amt: s.e.amt != null ? s.e.amt : s.e.total != null ? s.e.total : s.e.premium, q: s.e.q }); });
    function quote(st) {
      if (!st || st.q || !st.mail || !QUOTES[st.mail]) return;
      var qs = QUOTES[st.mail], hit = st.amt != null ? qs.filter(function (x) { return x.amt != null && Math.abs(x.amt - st.amt) <= 1; })[0] : null;
      st.q = (hit || qs[0]).q;
    }
    threads.forEach(function (t) {
      (t.steps || []).forEach(quote); (t.loose || []).forEach(quote);
      (t.items || []).forEach(function (it) { (it.steps || []).forEach(quote); });
      (t.cycles || []).forEach(function (cy) { (cy.steps || []).forEach(quote); });
    });
    threads.sort(function (a, b) { return (b.last || '').localeCompare(a.last || ''); });
    // what's coming in the next two months, nearest first; what fell late in the last six weeks (an old miss is the
    // thread's history, not something to act on now)
    var soon = addDays(today, 60), lately = addDays(today, -45);
    var coming = threads.filter(function (t) { return t.next && t.next.d && t.next.d >= today && t.next.d <= soon; }).map(function (t) { return { id: t.id, kind: t.kind, title: t.title, d: t.next.d, amt: t.next.amt, what: t.next.what }; })
      .sort(function (a, b) { return a.d < b.d ? -1 : 1; }).slice(0, 30);
    var late = threads.filter(function (t) { return /overdue|late|unpaid|lapsed|in grace|not seen/.test(t.status || ''); }).map(function (t) { return { id: t.id, kind: t.kind, title: t.title, status: t.status, d: t.next ? t.next.d : t.last }; })
      .filter(function (x) { return x.d && x.d >= lately && x.d <= today; });
    var cards = threads.filter(function (t) { return t.kind === 'card'; });
    var counts = {};
    threads.forEach(function (t) { counts[t.kind] = (counts[t.kind] || 0) + 1; });
    var stats = {
      steps: steps.length, moves: moves.length, linked: Object.keys(used).length, threads: threads.length, counts: counts,
      cardsOnTime: cards.reduce(function (n, c) { return n + c.onTime; }, 0), cardsLate: cards.reduce(function (n, c) { return n + c.late; }, 0),
      refundsWaiting: threads.filter(function (t) { return /refund (?:waiting|late)|^waiting$|^late$/.test(t.status) && (t.kind === 'order' || t.kind === 'refund'); }).length,
    };
    var checks = checksOf(steps, moves, used);
    stats.witnessed = checks.witnessed; stats.alone = checks.alone;
    return { threads: threads, coming: coming, late: late, stats: stats, checks: checks };
  }

  // the journey only changes when the mail (what each mail was read as) or a deposit's terms do: a build that changes
  // nothing else (an edit, a category) reuses it. The key is every reading's whole content, hashed, not its length
  // (a deposit's rate edited from 7.1 to 7.5 is the same length)
  var MEMO = { sig: '', out: null };
  function fnv(h, s) { for (var j = 0; j < s.length; j++) { h ^= s.charCodeAt(j); h = Math.imul(h, 16777619); } return h; }
  function sigOf(records, today) {
    var h = fnv(2166136261, today + '|' + records.length);
    // each reading by its length, its ends and a sample through it: a changed figure changes these, and the key stays cheap
    // (hashing every reading whole, on every build, cost seconds on the phone)
    for (var i = 0; i < records.length; i++) {
      var r = records[i], e = typeof r.evs === 'string' ? r.evs : r.evs ? JSON.stringify(r.evs) : '', smp = '';
      for (var p = 0; p < e.length; p += 37) smp += e.charAt(p);
      h = fnv(h, '|' + r.id + ':' + (r.use === 'claude' ? 'c' : '') + ':' + e.length + ':' + e.slice(0, 24) + e.slice(-24) + smp);
    }
    return (h >>> 0).toString(36) + ':' + records.length;
  }
  /* the build's refunds by each mail that promised one (engine/21b), and a key that changes when any of them does */
  function refundBook(snap) {
    var by = {}, sig = 2166136261;
    (snap.refunds || []).concat(snap.refundPromises || []).forEach(function (r) {
      if (!r || !r.mails || !r.mails.length) return;
      var row = { exp: +r.exp || 0, back: +r.back || 0, state: r.state || '', stage: r.stage || '', by: r.by || '', credits: (r.credits || []).map(function (c) { return { id: c.id, d: c.d, a: +c.a || 0, shop: !!c.shop }; }) };
      r.mails.forEach(function (m) { if (m && m.id && !by[m.id]) by[m.id] = row; });
      sig = fnv(sig, '|' + r.id + ':' + r.mails.map(function (m) { return m.id; }).join(',') + ':' + row.exp + ':' + row.back + ':' + row.state + ':' + row.stage + ':' + row.by + ':' + row.credits.map(function (c) { return c.id + (c.shop ? '*' : ''); }).join(','));
    });
    return { by: by, sig: (sig >>> 0).toString(36) };
  }
  function journeyOnce(records, prof, rb) {
    rb = rb || { by: {}, sig: '' };
    var today = (prof && prof.today) || '';
    // inside buildJSON the records are known exactly by their generation; the one profile setting build() changes the
    // readings by (withRejected) joins it. A build() called directly keeps the sampled key
    var gen = E && E.recordsGen ? E.recordsGen() : 0;
    var rsig = gen ? 'g' + gen + ':' + (records || []).length + '|' + today + '|' + (fnv(2166136261, JSON.stringify((prof && prof.rejected) || null)) >>> 0).toString(36) : sigOf(records || [], today);
    var sig = rsig + '|' + (fnv(2166136261, JSON.stringify((prof && prof.deposits) || [])) >>> 0).toString(36) + '|' + rb.sig;
    if (MEMO.sig === sig && MEMO.out) return MEMO.out;
    var out = journey(records, prof, rb.by);
    MEMO = { sig: sig, out: out };
    return out;
  }

  var api = { journey: journey, stepsOf: stepsOf, agree: agree, checksOf: checksOf, refundBook: refundBook };
  if (E && E.postBuild) E.postBuild.push(function (snap, prof, records) {
    var j = journeyOnce(records, prof, refundBook(snap));
    // the screens get the 600 most recent threads (what's coming and what's late are counted over all of them)
    var shown = j.threads.length > 600 ? j.threads.slice(0, 600) : j.threads;
    if (shown !== j.threads) {
      var want = {};
      j.coming.concat(j.late).forEach(function (x) { want[x.id] = 1; });
      shown.forEach(function (t) { delete want[t.id]; });
      j.threads.forEach(function (t) { if (want[t.id]) shown.push(t); });
    }
    snap.threads = shown;
    snap.journey = { coming: j.coming, late: j.late, stats: j.stats, checks: j.checks };
  });
  if (E) E.journey = api;
  return api;
})(typeof KoshEngine !== 'undefined' ? KoshEngine : require('./engine.js'));
if (typeof module !== 'undefined' && module.exports) module.exports = KoshJourney;
