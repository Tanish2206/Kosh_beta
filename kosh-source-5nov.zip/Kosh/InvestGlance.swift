import SwiftUI

// MARK: - Investments, summed up
//
// What you hold, said in a few lines: the total and its mix, each kind's own figures, what stands
// out (one share or fund being most of it, Regular plans where Direct ones exist, deposits about to
// mature, small positions), and only the biggest holdings of each kind, with the full list one tap
// away for a deep dive. Everything is worked out from the holdings themselves, for any portfolio.

enum HoldingName {
    /// "RADICO KHAITAN LIMITED" → "Radico Khaitan"; "XYZ MID CAP FUND-DIRECT-GROWTH" → "XYZ Mid Cap Fund · Direct · Growth"
    static func pretty(_ raw: String) -> String {
        var s = raw.trimmingCharacters(in: .whitespaces)
        let letters = s.filter(\.isLetter)
        if !letters.isEmpty && letters == letters.uppercased() {
            s = s.lowercased().split(separator: " ").map { w -> String in
                let word = String(w)
                // short all-letter words in capitals stay so (AMC, HDFC, ICICI, ETF, SBI)
                if word.count <= 4 && ["amc", "etf", "sbi", "hdfc", "icici", "uti", "lic", "dsp", "itc", "nse", "bse", "abb", "acc", "tvs", "mrf", "bel", "hal", "ntpc", "ongc", "gail", "irctc", "pnb", "idfc", "axis", "nps"].contains(word) { return word.uppercased() }
                return word.prefix(1).uppercased() + word.dropFirst()
            }.joined(separator: " ")
        }
        s = s.replacingOccurrences(of: #"\s*-\s*"#, with: " · ", options: .regularExpression)
        s = s.replacingOccurrences(of: #"\s+(Limited|Ltd\.?)$"#, with: "", options: [.regularExpression, .caseInsensitive])
        return s
    }
}

/// what kind of fund a fund is, from its name
enum FundKind: String, CaseIterable {
    case equity = "Equity", index = "Index", debt = "Debt", hybrid = "Hybrid", gold = "Gold", other = "Other"
    static func of(_ name: String) -> FundKind {
        let n = name.lowercased()
        if n.contains("gold") || n.contains("silver") { return .gold }
        // (a debt index fund or ETF is debt: "Nifty SDL Apr 2027 Index Fund", "CRISIL IBX Gilt", "Bharat Bond ETF")
        if n.range(of: #"\bsdl\b|\bgilt\b|\bg ?sec\b|\bbonds?\b|crisil ibx|\bibx\b|target maturity|\bliquid\b|overnight|money market|\btreasury\b|\bt-?bill"#, options: .regularExpression) != nil { return .debt }
        if n.range(of: #"index|nifty|sensex|etf|\bnext 50\b"#, options: .regularExpression) != nil { return .index }
        if n.range(of: #"hybrid|balanced|asset allocation|arbitrage|equity savings|multi asset|dynamic asset"#, options: .regularExpression) != nil { return .hybrid }
        if n.range(of: #"debt|liquid|gilt|bond|overnight|money market|short (?:term|duration)|corporate|banking (?:&|and) psu|credit risk|duration|income fund|treasury|floater"#, options: .regularExpression) != nil { return .debt }
        if n.range(of: #"equity|flexi|large|mid|small|multi ?cap|elss|tax saver|focused|value|contra|dividend yield|thematic|sector|infra|pharma|tech|bluechip|opportunit|growth fund|consumption|manufactur"#, options: .regularExpression) != nil { return .equity }
        return .other
    }
    var color: Color {
        switch self {
        case .equity: return Color(hex: "#30B0C7")
        case .index: return Color(hex: "#5AC8FA")
        case .debt: return Color(hex: "#007AFF")
        case .hybrid: return Color(hex: "#A2845E")
        case .gold: return Color(hex: "#FFCC00")
        case .other: return Color.gray
        }
    }
}

struct InvestHero: View {
    @Environment(Store.self) private var store
    @State private var grown = false
    var body: some View {
        let p = store.who
        let classes = store.classes(p)
        let total = classes.reduce(0) { $0 + $1.v }
        let n = store.holdings(p).count
        VStack(alignment: .leading, spacing: 16) {
            VStack(alignment: .leading, spacing: 4) {
                Text(p.possessive("investments", family: "The family’s investments")).font(.subheadline.weight(.medium)).foregroundStyle(.secondary)
                Text(Fmt.words(total))
                    .scaledFont(size: 42, weight: .bold, design: .rounded, relativeTo: .largeTitle)
                    .minimumScaleFactor(0.6).lineLimit(1)
                    .privacySensitive()
                Text("\(n) holding\(n == 1 ? "" : "s") across \(classes.count) kind\(classes.count == 1 ? "" : "s")").font(.subheadline).foregroundStyle(.secondary)
                GainLine(g: Gains(store.holdings(p)), ret: store.yearly(p, "all"))
            }
            if total > 0 {
                GeometryReader { g in
                    let gaps = CGFloat(max(0, classes.count - 1)) * 3
                    HStack(spacing: 3) {
                        ForEach(classes) { c in
                            RoundedRectangle(cornerRadius: 6, style: .continuous).fill(c.kindColor.gradient)
                                .frame(width: max(6, (g.size.width - gaps) * CGFloat(c.v / total) * (grown ? 1 : 0.02)))
                        }
                    }
                }
                .frame(height: 14)
                VStack(spacing: 9) {
                    ForEach(classes) { c in
                        HStack(spacing: 10) {
                            Circle().fill(c.kindColor).frame(width: 9, height: 9)
                            Text(c.title).font(.subheadline)
                            Spacer()
                            Text(Fmt.words(c.v)).font(.subheadline.weight(.semibold)).monospacedDigit().privacySensitive()
                            Text(Fmt.pct(c.v / total)).font(.caption).foregroundStyle(.secondary).frame(width: 38, alignment: .trailing)
                        }
                    }
                }
            }
        }
        .padding(20)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(CardFill(), in: RoundedRectangle(cornerRadius: 28, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 28, style: .continuous).strokeBorder(CardEdge(), lineWidth: 1))
        .onAppear { withAnimation(Motion.reveal) { grown = true } }
    }
}

/// each kind's own figures, side by side
struct InvestTiles: View {
    @Environment(Store.self) private var store
    var body: some View {
        let p = store.who
        let hs = store.holdings(p)
        let stocks = hs.filter { $0.cls == "stk" }.sorted { $0.amt > $1.amt }
        let funds = hs.filter { $0.cls == "mf" }.sorted { $0.amt > $1.amt }
        let deps = hs.filter { $0.cls == "dep" }
        let sips = store.snap.recurring.filter { $0.kind == "sip" && ($0.lapsed ?? "").isEmpty }
        LazyVGrid(columns: [GridItem(.flexible(), spacing: 10), GridItem(.flexible(), spacing: 10)], spacing: 10) {
            if !stocks.isEmpty {
                let v = stocks.reduce(0) { $0 + $1.amt }
                GlanceTile(sym: "chart.line.uptrend.xyaxis", color: WealthKind.color("stk"), label: "Stocks · \(stocks.count)",
                           value: Fmt.words(v), sub: "Biggest: \(HoldingName.pretty(stocks[0].bank)), \(Fmt.pct(stocks[0].amt / max(1, v)))")
            }
            if !funds.isEmpty {
                let v = funds.reduce(0) { $0 + $1.amt }
                let eq = funds.filter { [.equity, .index].contains(FundKind.of($0.bank)) }.reduce(0) { $0 + $1.amt }
                GlanceTile(sym: "chart.pie.fill", color: WealthKind.color("mf"), label: "Mutual funds · \(funds.count)",
                           value: Fmt.words(v), sub: "\(Fmt.pct(eq / max(1, v))) in equity and index funds")
            }
            if !deps.isEmpty {
                let v = deps.reduce(0) { $0 + $1.amt }
                let next = deps.compactMap(\.mat).filter { $0 >= store.snap.cm }.min()
                GlanceTile(sym: "building.columns.fill", color: WealthKind.color("dep"), label: "Deposits · \(deps.count)",
                           value: Fmt.words(v), sub: next.map { "Next matures " + Day.fmt($0 + "-01", "MMM yyyy") } ?? "None maturing soon")
            }
            if !sips.isEmpty {
                GlanceTile(sym: "arrow.triangle.2.circlepath", color: WealthKind.color("mf"), label: "SIPs · \(sips.count)",
                           value: Fmt.rupees(sips.reduce(0) { $0 + $1.amount }), sub: "a month, from your payments")
            }
        }
    }
}

/// the mix of funds by kind
struct FundMix: View {
    let funds: [Holding]
    var body: some View {
        let total = max(1, funds.reduce(0) { $0 + $1.amt })
        let kinds: [(FundKind, Double)] = FundKind.allCases.map { k in (k, funds.filter { FundKind.of($0.bank) == k }.reduce(0) { $0 + $1.amt }) }.filter { $0.1 > 0 }
        VStack(alignment: .leading, spacing: 10) {
            GeometryReader { g in
                HStack(spacing: 2) {
                    ForEach(kinds, id: \.0) { k in
                        Capsule().fill(k.0.color.gradient).frame(width: shareWidth(g.size.width, gaps: kinds.count - 1, gap: 2, part: k.1, of: total, least: 4))
                    }
                }
            }
            .frame(height: 9)
            HStack(spacing: 12) {
                ForEach(kinds, id: \.0) { k in
                    HStack(spacing: 4) {
                        Circle().fill(k.0.color).frame(width: 7, height: 7)
                        Text("\(k.0.rawValue) \(Fmt.pct(k.1 / total))").font(.caption).foregroundStyle(.secondary)
                    }
                }
            }
        }
        .padding(.vertical, 4)
    }
}

enum InvestNotes {
    static func make(_ store: Store) -> [SmartNote] {
        let p = store.who
        let hs = store.holdings(p)
        let total = hs.reduce(0) { $0 + $1.amt }
        guard total > 0 else { return [] }
        var out: [SmartNote] = []
        let stocks = hs.filter { $0.cls == "stk" }.sorted { $0.amt > $1.amt }
        let funds = hs.filter { $0.cls == "mf" }
        let sv = stocks.reduce(0) { $0 + $1.amt }
        if stocks.count >= 8 {
            let top5 = stocks.prefix(5).reduce(0) { $0 + $1.amt }
            out.append(SmartNote(id: "top5", sym: "chart.bar.fill", color: Color(hex: "#34C759"),
                                 text: "Your five biggest stocks are \(Fmt.pct(top5 / max(1, sv))) of the \(Fmt.words(sv)) in shares; the other \(stocks.count - 5) make up the rest."))
            let tiny = stocks.filter { $0.amt < sv * 0.01 }
            if tiny.count >= 5 {
                out.append(SmartNote(id: "tiny", sym: "square.grid.3x3.fill", color: Color.orange,
                                     text: "\(tiny.count) stocks are each under 1% of your shares, \(Fmt.words(tiny.reduce(0) { $0 + $1.amt })) together. Positions that small barely move the total either way."))
            }
        }
        if let top = hs.max(by: { $0.amt < $1.amt }), hs.count > 3, top.amt / total > 0.2 {
            out.append(SmartNote(id: "big", sym: "exclamationmark.circle.fill", color: Color.orange,
                                 text: "\(HoldingName.pretty(top.bank)) alone is \(Fmt.pct(top.amt / total)) of everything invested."))
        }
        // a Regular plan says so, and isn't a Direct plan of a fund named "… Regular Savings …"
        let regular = funds.filter { FundFees.isRegular($0.bank) }
        if !regular.isEmpty {
            let says: String = "\(regular.count) fund\(regular.count == 1 ? " is a" : "s are") Regular plan\(regular.count == 1 ? "" : "s") (\(Fmt.words(regular.reduce(0) { $0 + $1.amt }))). Regular plans pay a distributor's commission out of the fund each year; the Direct plan of the same fund doesn't."
            out.append(SmartNote(id: "regular", sym: "percent", color: Color.sky, text: says + FundFeeWords.cost(store, p)))
        }
        let fv = funds.reduce(0) { $0 + $1.amt }
        if fv > 0 {
            let debt = funds.filter { FundKind.of($0.bank) == .debt }.reduce(0) { $0 + $1.amt }
            let eq = sv + funds.filter { [.equity, .index].contains(FundKind.of($0.bank)) }.reduce(0) { $0 + $1.amt }
            out.append(SmartNote(id: "mix", sym: "chart.pie.fill", color: Color.kosh,
                                 text: "\(Fmt.pct(eq / total)) of your investments move with the share market (stocks and equity funds)\(debt > 0 ? "; \(Fmt.pct(debt / total)) is in debt funds" : "")."))
        }
        let soon = hs.filter { $0.cls == "dep" && ($0.mat ?? "") >= store.snap.cm && ($0.mat ?? "") <= MonthsAround.key(store.snap.today, 3) }
        if !soon.isEmpty {
            out.append(SmartNote(id: "fd", sym: "lock.open.fill", color: Color(hex: "#007AFF"),
                                 text: "\(soon.count) deposit\(soon.count == 1 ? "" : "s") worth \(Fmt.words(soon.reduce(0) { $0 + $1.amt })) mature\(soon.count == 1 ? "s" : "") in the next three months."))
        }
        return out
    }
}

/// statements, as one quiet line once they're read
struct StatementsLine: View {
    @Environment(Store.self) private var store
    let kinds: Set<String>
    var body: some View {
        if let live = store.live {
            let items = live.docItems(kinds: kinds)
            let locked = items.filter { $0.state == "locked" }.count
            let read = items.filter { $0.state == "read" }.count
            let senders = Set(items.map(\.sender)).sorted()
            Button { store.betaSheet = .documents } label: {
                HStack(spacing: 12) {
                    IconTile(symbol: locked > 0 ? "lock.doc.fill" : "doc.text.fill", color: locked > 0 ? Color.orange : Color.gray, size: 30)
                    VStack(alignment: .leading, spacing: 1) {
                        Text(items.isEmpty ? "No statements yet" : "Statements · \(read) read" + (locked > 0 ? ", \(locked) locked" : ""))
                            .font(.subheadline.weight(.medium)).foregroundStyle(Color.primary)
                        if !senders.isEmpty {
                            Text(senders.prefix(4).joined(separator: ", ")).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                        }
                    }
                    Spacer()
                    Image(systemName: "chevron.right").font(.footnote.weight(.semibold)).foregroundStyle(.tertiary)
                }
            }
        }
    }
}

// MARK: - One instrument at a time

/// all of it, or one instrument: chips you swipe across
struct InstrumentChips: View {
    let options: [(String, String)]
    @Binding var selection: String
    var body: some View {
        // (Wealth's outlined pills, as on its Overview: only Wealth's pages use these)
        ScrollView(.horizontal) {
            WealthPills(options: pills, selection: $selection)
                .padding(.horizontal, 2)
        }
        .scrollIndicators(.hidden)
    }
    var pills: [(id: String, label: String)] { options.map { (o: (String, String)) -> (id: String, label: String) in (id: o.0, label: o.1) } }
}

/// one instrument on its own: what it adds up to, what stands out, every holding, and how to add more
struct InstrumentPage: View {
    @Environment(Store.self) private var store
    let c: ClassSum
    @State private var query = ""

    var body: some View {
        let p = store.who
        let all = store.holdings(p).filter { $0.cls == c.key }.sorted { $0.amt > $1.amt }
        let invested = store.classes(p).reduce(0) { $0 + $1.v }
        let q = query.trimmingCharacters(in: .whitespaces).lowercased()
        let items = q.isEmpty ? all : all.filter { $0.bank.lowercased().contains(q) }
        Section {
            VStack(alignment: .leading, spacing: 6) {
                HStack(spacing: 10) {
                    IconTile(symbol: c.sym, color: c.kindColor, size: 34)
                    Text(c.title).font(.headline)
                }
                Text(Fmt.words(c.v))
                    .font(.system(size: 40, weight: .bold, design: .rounded))
                    .privacySensitive()
                Text("\(all.count) holding\(all.count == 1 ? "" : "s") · \(Fmt.pct(c.v / max(1, invested))) of what you've invested")
                    .font(.subheadline).foregroundStyle(.secondary)
                GainLine(g: Gains(all), ret: store.yearly(p, c.key), cls: c.key)
                if let u = store.classUpdated(c.key, p) {
                    Label(u.line, systemImage: u.stale ? "exclamationmark.circle" : "clock")
                        .font(.footnote).foregroundStyle(u.stale ? Color.orange : Color.secondary)
                }
            }
            .padding(.vertical, 6)
            .listRowBackground(Color.clear)
            if c.key == "mf" && all.count > 1 { FundMix(funds: all) }
        }
        // EPF, PPF and NPS held together, EPF first (RetirementView.swift); the passbook's own path is in there too
        if c.key == "ret" {
            RetirementSections(person: p)
        }
        if c.key == "mf", let f = store.snap.brief?.fees, f.rows.contains(where: { p.owns($0.person) }) || f.unknown.contains(where: { p.owns($0.person) }) {
            Section {
                NavigationLink { FundFeesList() } label: {
                    HStack(spacing: 12) {
                        IconTile(symbol: "percent", color: Color.sky, size: 30)
                        VStack(alignment: .leading, spacing: 1) {
                            Text("What Regular plans cost").font(.subheadline.weight(.semibold))
                            Text(FundFeeWords.line(store, p)).font(.footnote).foregroundStyle(.secondary).privacySensitive()
                        }
                    }
                }
            }
        }
        let found = self.notes(all)
        if !found.isEmpty {
            Section("What stands out") {
                ForEach(found) { n in
                    HStack(alignment: .top, spacing: 12) {
                        Image(systemName: n.sym).font(.system(size: 14, weight: .semibold)).foregroundStyle(n.color)
                            .frame(width: 26, height: 26).background(n.color.opacity(0.13), in: Circle())
                        Text(n.text).font(.subheadline).fixedSize(horizontal: false, vertical: true).privacySensitive()
                    }
                    .padding(.vertical, 2)
                }
            }
        }
        // what the shares have paid out, by year and company (PortfolioViews.swift)
        if c.key == "stk" && store.dividends(p) != nil {
            Section { DividendsLink() }
        }
        if c.key == "dep" && store.snap.deposits != nil {
            // Live, Needs a look, Closed: each deposit opening to its journey (Deposits.swift)
            DepositSections(person: p)
        } else {
        Section {
            if all.count > 8 {
                HStack {
                    Image(systemName: "magnifyingglass").foregroundStyle(.secondary)
                    TextField("Find in \(c.title.lowercased())", text: $query).autocorrectionDisabled()
                }
            }
            ForEach(items) { h in
                if let live = store.live, let mine = live.typedHolding(h) {
                    Button { store.betaSheet = .holding(mine.id) } label: { HoldingRow(h: h, sym: c.sym, color: c.kindColor, showWho: p == .family, total: c.v).foregroundStyle(Color.primary) }
                } else if store.live != nil, let src = h.src, !src.isEmpty {
                    Button { store.betaSheet = .source(SourceRef(title: h.bank, mails: src, type: "deposit")) } label: { HoldingRow(h: h, sym: c.sym, color: c.kindColor, showWho: p == .family, total: c.v).foregroundStyle(Color.primary) }
                } else {
                    HoldingRow(h: h, sym: c.sym, color: c.kindColor, showWho: p == .family, total: c.v)
                }
            }
        } header: {
            Text("Every holding")
        }
        }
        if store.live != nil {
            Section {
                switch c.key {
                case "dep":
                    Button { store.betaSheet = .holding("new:FD") } label: { Label("Add a fixed deposit", systemImage: "plus.circle.fill") }
                case "ret":
                    Button { store.betaSheet = .epf } label: { Label("Read EPF from the EPFO passbook", systemImage: "briefcase.fill") }
                    Button { store.betaSheet = .holding("new:PPF") } label: { Label("Add PPF or NPS", systemImage: "plus.circle") }
                case "gold":
                    Button { store.betaSheet = .holding("new:gold") } label: { Label("Add physical gold", systemImage: "plus.circle.fill") }
                default:
                    Button { store.betaSheet = .holding(nil) } label: { Label("Add a holding", systemImage: "plus.circle") }
                }
            } footer: {
                switch c.key {
                case "dep": Text("Deposits your bank emails about (booked, renewed, closed) appear on their own; add the rest here.")
                case "ret": Text("EPF comes from the EPFO passbook: you log in there yourself and kosh reads the balances.")
                case "gold": Text("Valued every day at the India Bullion and Jewellers Association's rate for its purity, without GST and making charges.")
                default: Text("Your CAS brings in shares and funds every month; their prices come from AMFI and NSE each day.")
                }
            }
        }
    }

    func notes(_ hs: [Holding]) -> [SmartNote] {
        var out: [SmartNote] = []
        let v = hs.reduce(0) { $0 + $1.amt }
        guard v > 0 else { return out }
        switch c.key {
        case "stk":
            if hs.count >= 6 {
                let top5 = hs.prefix(5).reduce(0) { $0 + $1.amt }
                out.append(SmartNote(id: "t5", sym: "chart.bar.fill", color: c.kindColor, text: "The five biggest are \(Fmt.pct(top5 / v)); the other \(hs.count - 5) share the rest."))
            }
            let tiny = hs.filter { $0.amt < v * 0.01 }
            if tiny.count >= 5 { out.append(SmartNote(id: "tiny", sym: "square.grid.3x3.fill", color: Color.orange, text: "\(tiny.count) are under 1% each, \(Fmt.words(tiny.reduce(0) { $0 + $1.amt })) together.")) }
        case "mf":
            let reg = hs.filter { FundFees.isRegular($0.bank) }
            if !reg.isEmpty {
                let says: String = "\(reg.count) Regular plan\(reg.count == 1 ? "" : "s"): these pay a distributor's commission out of the fund each year; Direct plans don't."
                out.append(SmartNote(id: "reg", sym: "percent", color: Color.sky, text: says + FundFeeWords.cost(store, store.who)))
            }
            let idx = hs.filter { FundKind.of($0.bank) == .index }
            if !idx.isEmpty { out.append(SmartNote(id: "idx", sym: "chart.line.flattrend.xyaxis", color: FundKind.index.color, text: "\(Fmt.pct(idx.reduce(0) { $0 + $1.amt } / v)) is in index funds, which follow the market at low cost.")) }
        case "dep":
            let next = hs.filter { ($0.mat ?? "") >= store.snap.cm }.sorted { ($0.mat ?? "") < ($1.mat ?? "") }.first
            if let n = next, let m = n.mat { out.append(SmartNote(id: "next", sym: "calendar", color: c.kindColor, text: "Next to mature: \(HoldingName.pretty(n.bank)), \(Day.fmt(m + "-01", "MMMM yyyy")).")) }
            let rated = hs.filter { $0.rate > 0 }
            if !rated.isEmpty {
                let avg = rated.reduce(0) { $0 + $1.rate * $1.amt } / max(1, rated.reduce(0) { $0 + $1.amt })
                out.append(SmartNote(id: "rate", sym: "percent", color: Color.green, text: "They earn \(Fmt.trim(avg, 2))% on average, weighted by amount."))
            }
        default: break
        }
        return out
    }
}


/// up or down against what went in, once that's known for most of the money (a share's cost isn't in its
/// statement, so a gain over a few of them would speak for the rest); and under it what that comes to a year,
/// over the holdings whose dated money kosh has. Neither: nothing.
struct GainLine: View {
    let g: Gains
    /// the yearly return over these holdings, and their kind ("mf", "dep"… or "all"), for its wording
    var ret: HoldReturn? = nil
    var cls: String = "all"
    var body: some View {
        let gain: Bool = g.covered && g.cost > 0
        if gain || ret != nil {
            VStack(alignment: .leading, spacing: 2) {
                if gain {
                    HStack(spacing: 6) {
                        Image(systemName: g.gain >= 0 ? "arrow.up.right" : "arrow.down.right").font(.caption.weight(.bold))
                        Text(Gains.line(g.gain, g.pct)).font(.subheadline.weight(.semibold)).monospacedDigit()
                    }
                    .foregroundStyle(g.gain >= 0 ? Color.green : Color.red)
                    .privacySensitive()
                }
                if let ret {
                    Text(Gains.yearly(ret, cls)).font(.caption).foregroundStyle(.secondary).monospacedDigit()
                        .fixedSize(horizontal: false, vertical: true)
                        .privacySensitive()
                }
            }
            .padding(.top, 2)
        }
    }
}

/// what Regular plans cost against Direct, in a sentence, for whoever is being looked at (brief.js's fund fees)
enum FundFeeWords {
    /// the plans kosh worked out, and those it couldn't, for whoever is being looked at
    static func rows(_ store: Store, _ p: Person) -> [FundFeesInfo.Row] { (store.snap.brief?.fees?.rows ?? []).filter { p.owns($0.person) } }
    static func unknown(_ store: Store, _ p: Person) -> [FundFeesInfo.Unknown] { (store.snap.brief?.fees?.unknown ?? []).filter { p.owns($0.person) } }
    static func year(_ store: Store, _ p: Person) -> Double { rows(store, p).reduce(0) { $0 + $1.year } }
    /// " Together they cost about ₹6,600 a year more than the Direct plans would." When AMFI's list doesn't give
    /// them all, it says the figure is for the ones it gives. Empty when nothing is known.
    static func cost(_ store: Store, _ p: Person) -> String {
        let y: Double = year(store, p)
        guard y >= 1 else { return "" }
        let figure: String = Fmt.rupees(Fmt.roundish(y))
        if unknown(store, p).isEmpty { return " Together they cost about " + figure + " a year more than the Direct plans would." }
        let n: Int = rows(store, p).count
        return n == 1 ? " The one in AMFI’s fee list costs about " + figure + " a year more than its Direct plan would."
                      : " The " + Words.number(n) + " in AMFI’s fee list cost about " + figure + " a year more than their Direct plans would."
    }
    /// the row's second line: the cost a year (for the plans AMFI's list gives), no extra fee, or why it isn't known
    static func line(_ store: Store, _ p: Person) -> String {
        let y: Double = year(store, p)
        let missing: [FundFeesInfo.Unknown] = unknown(store, p)
        if y >= 1 { return "About " + Fmt.rupees(Fmt.roundish(y)) + " a year more than Direct" + (missing.isEmpty ? "" : ", for those in AMFI’s list") }
        guard store.snap.brief?.fees?.fetched == true else { return "AMFI’s fee list arrives once kosh is online" }
        if !rows(store, p).isEmpty { return missing.isEmpty ? "No extra fee against Direct" : "No extra fee for those in AMFI’s list" }
        return missing.contains { $0.why == "two" || $0.why == "nodirect" } ? "AMFI’s list doesn’t say for certain" : "Not in AMFI’s fee list yet"
    }
}
