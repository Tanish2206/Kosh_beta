import Foundation

/// One mail must never hang kosh. Reading a mail holds the engine's lock, and the reading starts again on every launch,
/// so a mail the engine can't finish would stop the app every time it opens. Three guards, beside the engine's own
/// (engine-test/adversarial.js keeps its patterns and scans from going the long way on any shape of mail):
/// 1. the mail being read is noted before the engine starts on it (`begin`) and forgotten when it finishes (`end`):
///    if kosh stopped part-way through one (iOS ended it, or you did, while it hung), the next launch finds the note
///    and that mail is kept as "Couldn't read: too long" instead of being read again (`skip`, `unreadable`);
/// 2. a per-mail engine call is waited for at most `limit` seconds (a watchdog in `Engine.call`, public API only: the
///    engine runs on its own serial queue): past it that engine is abandoned, never touched again, a fresh one is
///    loaded from the bundled scripts for the next mail, and the mail is kept the same way (a loop or one regular
///    expression running long alike; Engine.maxStuck caps how many abandoned engines may still be running);
/// 3. both are forgotten when the reading code changes (ReadingPrint.mail): the mail is tried once more then.
enum ParseGuard {
    static let parsingKey = "kosh.parsing"
    static let tooLongKey = "kosh.tooLong"
    /// seconds one mail may take in the engine (a mail takes milliseconds; the slowest invented ones well under one)
    static let limit: Double = 5
    /// the reason an unreadable mail carries (Settings › Parser check lists it)
    static let reason = "Couldn’t read — too long"
    private static let lock = NSLock()
    private static var settled = false
    private static var tooLong: [String: String] = [:]

    /// once a launch: the note left by a reading that never finished becomes a mail to skip
    private static func settle() {
        guard !settled else { return }
        settled = true
        let ud = UserDefaults.standard
        tooLong = (ud.dictionary(forKey: tooLongKey) as? [String: String]) ?? [:]
        // (the mails the readers were on, one each: Readers)
        let was: [String] = (ud.stringArray(forKey: parsingKey) ?? ud.string(forKey: parsingKey).map { [$0] } ?? []).filter { !$0.isEmpty }
        if !was.isEmpty {
            ud.removeObject(forKey: parsingKey)
            for id in was { remember(id) }
        }
    }
    private static func remember(_ id: String) {
        tooLong[id] = ReadingPrint.mail
        // (a handful at most in practice; never more than 200 kept)
        if tooLong.count > 200 {
            let keep = Array(tooLong.keys.sorted().suffix(200))
            var next: [String: String] = [:]
            for k in keep { next[k] = tooLong[k] }
            tooLong = next
        }
        UserDefaults.standard.set(tooLong, forKey: tooLongKey)
    }

    /// the mail kosh couldn't finish reading, by this code: not read again
    static func skip(_ id: String) -> Bool {
        lock.lock(); defer { lock.unlock() }
        settle()
        return tooLong[id] == ReadingPrint.mail
    }
    /// the engine is past its time limit on this mail: kept as too long
    static func gaveUp(_ id: String) {
        lock.lock(); defer { lock.unlock() }
        settle()
        remember(id)
    }
    /// the note before an engine starts on a mail, and its end (the readers work side by side: a note each)
    private static var parsing: [String] = []
    static func begin(_ id: String) {
        lock.lock(); defer { lock.unlock() }
        settle()
        parsing.append(id)
        UserDefaults.standard.set(parsing, forKey: parsingKey)
    }
    static func end(_ id: String) {
        lock.lock(); defer { lock.unlock() }
        if let i = parsing.firstIndex(of: id) { parsing.remove(at: i) }
        if parsing.isEmpty { UserDefaults.standard.removeObject(forKey: parsingKey) } else { UserDefaults.standard.set(parsing, forKey: parsingKey) }
    }

    /// the engine's reading of one mail, the mail noted while it works (guard 1) under its time limit (guard 2); past
    /// the limit the mail is kept as too long and this throws
    static func parse(_ m: MailMsg, id: String, engine: Engine) throws -> String {
        do {
            return try engine.call("parseJSON", [JSONText.encode(m)], mark: id)
        } catch {
            if case LiveError.engine(let why) = error, why == Engine.tooLongMessage { gaveUp(id) }
            throw error
        }
    }

    /// the mail as kosh keeps one it couldn't read: who sent it, when, its subject, and why (never its words: nothing
    /// reads it again until the reading code changes)
    static func unreadable(_ m: MailMsg, id: String, acct: String) -> Reading? {
        let addr: String = {
            guard let a = m.from.firstIndex(of: "<"), let b = m.from[a...].firstIndex(of: ">") else { return m.from.lowercased() }
            let inner = m.from[m.from.index(after: a)..<b]
            return inner.trimmingCharacters(in: .whitespaces).lowercased()
        }()
        var d: [String: Any] = [:]
        d["id"] = id
        d["kind"] = "unknown"
        d["rule"] = "too-long"
        d["reason"] = reason
        d["sent"] = String(m.date.prefix(10))
        d["from"] = addr
        d["subject"] = String(m.subject.prefix(300))
        guard var r = Reading.fromEngine(JSONText.object(d)) else { return nil }
        if !acct.isEmpty { r.acct = acct }
        r.rp = ReadingPrint.mail
        return r
    }
}
