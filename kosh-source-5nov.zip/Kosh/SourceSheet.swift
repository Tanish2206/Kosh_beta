import SwiftUI

// MARK: - Where it came from
//
// Anything kosh found on its own (a deposit, a thread's step, a payment) can say which mail it was read from: who
// sent it, when, and the line kosh took the figure from. And the person can say it's wrong: "Not a deposit" leaves
// that mail's reading of that kind out of every screen and total, and teaches the mail's template, so the next mail
// of the same shape isn't read that way either. "Undo" takes it back.

/// a figure's source: the mails behind it and the kind of reading it stands on ("deposit", "move", "policy"...)
struct SourceRef: Hashable, Identifiable {
    let title: String
    let mails: [String]
    let type: String
    /// opened from a black page (Insurance, Wealth): the sheet is drawn in that look, in the page's colour
    var tint: Color? = nil
    var id: String { type + ":" + mails.joined(separator: ",") }
}

struct SourceSheet: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    let ref: SourceRef
    @State private var left: Bool = false

    var body: some View {
        // one design everywhere (1 Nov): the black sheet, in the page's colour or kosh's own
        ObsidianSourceSheet(ref: ref, tint: ref.tint ?? Obsidian.motor, left: $left)
            .onAppear { left = Self.isLeft(store, ref) }
    }
    static func isLeft(_ store: Store, _ ref: SourceRef) -> Bool {
        !ref.mails.isEmpty && ref.mails.allSatisfy { (store.live?.rejected[$0] ?? []).contains(ref.type) }
    }

    var plain: some View {
        NavigationStack {
            ObsidianList {
                Section {
                    ForEach(ref.mails, id: \.self) { id in
                        if let r = store.live?.records.first(where: { $0.id == id }) {
                            MailSourceRow(r: r, type: ref.type)
                        } else {
                            Text("A mail kosh no longer keeps").foregroundStyle(.secondary)
                        }
                    }
                } header: {
                    Text(ref.mails.count == 1 ? "Read from this mail" : "Read from these mails")
                }
                if store.live != nil && !ref.mails.isEmpty {
                    Section {
                        if left {
                            Label("Left out. Mail like this won’t be read as " + Self.noun(ref.type) + " again.", systemImage: "checkmark.circle.fill")
                                .foregroundStyle(Color.green)
                            Button("Undo") {
                                store.live?.unreject(mails: ref.mails, type: ref.type)
                                left = false
                            }
                        } else {
                            Button(role: .destructive) {
                                store.live?.reject(mails: ref.mails, type: ref.type)
                                left = true
                            } label: {
                                Label("Not " + Self.noun(ref.type) + ": leave it out", systemImage: "xmark.circle")
                            }
                        }
                    } footer: {
                        Text("kosh leaves this mail’s reading out of every screen and total, and learns its layout so the next mail like it isn’t read that way. Nothing in your inbox changes.")
                    }
                }
            }
            .navigationTitle(ref.title)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } }
            }
            .onAppear { left = Self.isLeft(store, ref) }
        }
    }

    static func noun(_ type: String) -> String {
        switch type {
        case "deposit": return "a deposit"
        case "move": return "a payment"
        case "policy": return "a policy"
        case "order": return "an order"
        case "due": return "a bill"
        case "mandate": return "an auto-debit"
        case "statement": return "a statement"
        case "expect": return "money promised"
        case "fund", "ipo", "trade", "dividend": return "an investment"
        default: return "this"
        }
    }
}

/// one mail behind a figure: its subject, who sent it and when, the words kosh read, and a way to open it
struct MailSourceRow: View {
    let r: Reading
    let type: String
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(r.subject ?? "A mail").font(.subheadline.weight(.medium)).lineLimit(2)
            Text(Self.byline(r)).font(.caption).foregroundStyle(.secondary)
            ForEach(Self.quotes(r, type: type), id: \.self) { q in
                Text("“" + q + "”").font(.footnote).foregroundStyle(.secondary).padding(.top, 2)
            }
            if let u = URL(string: "https://mail.google.com/mail/u/0/#all/" + r.id) {
                Link("Open in Gmail", destination: u).font(.footnote)
            }
        }
        .padding(.vertical, 2)
        .privacySensitive()
    }
    static func byline(_ r: Reading) -> String {
        var parts: [String] = []
        let who: String = (r.inst ?? "").isEmpty ? (r.from ?? "") : (r.inst ?? "")
        if !who.isEmpty { parts.append(who) }
        if let d = r.sent, !d.isEmpty { parts.append(Day.fmt(d, "d MMM yyyy")) }
        // who read it: Claude (checked against the mail on this phone), or kosh's own rules
        if r.by == "claude" { parts.append("read by kosh’s smart reading") }
        return parts.joined(separator: " · ")
    }
    /// the lines kosh read the figure from (reader.js › quoteOf), of this kind first
    static func quotes(_ r: Reading, type: String) -> [String] {
        guard let s = r.evs, let d = s.data(using: .utf8), let evs = try? JSONSerialization.jsonObject(with: d) as? [[String: Any]] else { return [] }
        let mine: [String] = evs.filter { ($0["type"] as? String) == type }.compactMap { $0["q"] as? String }
        let any: [String] = evs.compactMap { $0["q"] as? String }
        var out: [String] = []
        for q in (mine.isEmpty ? any : mine) where !q.isEmpty && !out.contains(q) { out.append(q) }
        return Array(out.prefix(3))
    }
}

// MARK: - The same sheet in the black look

/// Where it came from, opened from an Obsidian page (1 Nov: the grey system sheet over the black policy page read as a
/// different app). Black, the mail as a card with the line kosh read set off by the page's colour, Gmail one tap away,
/// and "not a policy" as a quiet row of its own rather than a red button
struct ObsidianSourceSheet: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    @Environment(\.accessibilityReduceMotion) private var still
    let ref: SourceRef
    let tint: Color
    @Binding var left: Bool
    static let warn: Color = Color(hex: "#FF7A70")

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 0) {
                HStack(alignment: .top, spacing: 12) {
                    VStack(alignment: .leading, spacing: 7) {
                        Text(ref.mails.count == 1 ? "Read from this mail" : "Read from these mails").caption(tint)
                        Text(ref.title).font(.system(size: 21, weight: .semibold)).foregroundStyle(Obsidian.ink)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                    Spacer(minLength: 8)
                    Button { dismiss() } label: {
                        Image(systemName: "xmark").font(.system(size: 13, weight: .bold)).foregroundStyle(Obsidian.ink2)
                            .frame(width: 34, height: 34).background(Color.white.opacity(0.08), in: Circle())
                    }
                    .buttonStyle(.press)
                    .accessibilityLabel("Done")
                }
                .padding(.top, 26)
                VStack(spacing: 10) {
                    ForEach(ref.mails, id: \.self) { id in
                        if let r = store.live?.records.first(where: { $0.id == id }) {
                            ObsidianMailCard(r: r, type: ref.type, tint: tint)
                        } else {
                            Text("A mail kosh no longer keeps").font(.system(size: 14)).foregroundStyle(Obsidian.ink3)
                                .frame(maxWidth: .infinity, alignment: .leading).obsidianCard(20, padding: 16)
                        }
                    }
                }
                .padding(.top, 20)
                if store.live != nil && !ref.mails.isEmpty { leaveOut.padding(.top, 22) }
            }
            .padding(.horizontal, 20)
            .padding(.bottom, 30)
        }
        .scrollIndicators(.hidden)
        .background(alignment: .top) {
            RadialGradient(colors: [tint.opacity(0.22), .clear], center: .center, startRadius: 0, endRadius: 260)
                .frame(width: 520, height: 420).offset(x: -90, y: -170).allowsHitTesting(false).accessibilityHidden(true)
        }
        .environment(\.colorScheme, .dark)
        .presentationBackground(Obsidian.bg)
        .presentationCornerRadius(34)
        .presentationDragIndicator(.visible)
        .sensoryFeedback(.success, trigger: left) { _, now in now }
    }

    @ViewBuilder var leaveOut: some View {
        VStack(alignment: .leading, spacing: 10) {
            if left {
                HStack(spacing: 12) {
                    Image(systemName: "checkmark.circle.fill").font(.system(size: 19)).foregroundStyle(Obsidian.health)
                    Text("Left out. Mail like this won’t be read as " + SourceSheet.noun(ref.type) + " again.")
                        .font(.system(size: 14.5, weight: .medium)).foregroundStyle(Obsidian.ink)
                        .fixedSize(horizontal: false, vertical: true)
                    Spacer(minLength: 6)
                    Button("Undo") {
                        store.live?.unreject(mails: ref.mails, type: ref.type)
                        withAnimation(still ? nil : Motion.base) { left = false }
                    }
                    .font(.system(size: 14, weight: .semibold)).foregroundStyle(tint)
                }
                .obsidianCard(20, padding: 16)
                .transition(.opacity)
            } else {
                Button {
                    store.live?.reject(mails: ref.mails, type: ref.type)
                    withAnimation(still ? nil : Motion.base) { left = true }
                } label: {
                    HStack(spacing: 12) {
                        Image(systemName: "xmark").font(.system(size: 12, weight: .bold)).foregroundStyle(Self.warn)
                            .frame(width: 30, height: 30).background(Self.warn.opacity(0.14), in: Circle())
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Not " + SourceSheet.noun(ref.type)).font(.system(size: 15, weight: .medium)).foregroundStyle(Obsidian.ink)
                            Text("Leave this mail’s reading out").font(.system(size: 12.5)).foregroundStyle(Obsidian.ink3)
                        }
                        Spacer(minLength: 6)
                        Image(systemName: "chevron.right").font(.system(size: 12, weight: .semibold)).foregroundStyle(Obsidian.ink3)
                    }
                    .contentShape(Rectangle())
                    .obsidianCard(20, padding: 14)
                }
                .buttonStyle(.press)
                .transition(.opacity)
            }
            Text("kosh drops it from every screen and total, and learns the layout so the next mail like it isn’t read that way. Nothing in your inbox changes.")
                .font(.system(size: 12)).foregroundStyle(Obsidian.ink3).fixedSize(horizontal: false, vertical: true)
                .padding(.horizontal, 4)
        }
    }
}

/// one mail, in the black look: who sent it and when, its subject, the line kosh read, and Gmail
struct ObsidianMailCard: View {
    let r: Reading
    let type: String
    let tint: Color
    var body: some View {
        let who: String = (r.inst ?? "").isEmpty ? (r.from ?? "") : (r.inst ?? "")
        let when: String = (r.sent ?? "").isEmpty ? "" : Day.fmt(r.sent ?? "", "d MMM yyyy")
        let meta: String = [when, r.by == "claude" ? "smart reading" : ""].filter { !$0.isEmpty }.joined(separator: " · ")
        VStack(alignment: .leading, spacing: 14) {
            HStack(spacing: 10) {
                Text(String(who.prefix(1)).uppercased()).font(.system(size: 14, weight: .semibold)).foregroundStyle(tint)
                    .frame(width: 32, height: 32).background(tint.opacity(0.14), in: Circle())
                VStack(alignment: .leading, spacing: 2) {
                    Text(who.isEmpty ? "A mail" : who).font(.system(size: 13.5, weight: .medium)).foregroundStyle(Obsidian.ink).lineLimit(1)
                    Text(meta).font(.system(size: 10.5, design: .monospaced)).foregroundStyle(Obsidian.ink3)
                }
            }
            Text(r.subject ?? "A mail").font(.system(size: 16, weight: .semibold)).foregroundStyle(Obsidian.ink)
                .fixedSize(horizontal: false, vertical: true)
            ForEach(MailSourceRow.quotes(r, type: type), id: \.self) { q in
                HStack(alignment: .top, spacing: 12) {
                    Capsule().fill(tint).frame(width: 2.5)
                    Text(q).font(.system(size: 14)).foregroundStyle(Obsidian.ink2).fixedSize(horizontal: false, vertical: true)
                }
                .fixedSize(horizontal: false, vertical: true)
            }
            if let u = URL(string: "https://mail.google.com/mail/u/0/#all/" + r.id) {
                Link(destination: u) {
                    HStack(spacing: 6) {
                        Text("Open in Gmail")
                        Image(systemName: "arrow.up.right").font(.system(size: 11, weight: .bold))
                    }
                    .font(.system(size: 13.5, weight: .semibold)).foregroundStyle(Obsidian.ink)
                    .padding(.horizontal, 14).frame(minHeight: 36)
                    .background(Color.white.opacity(0.08), in: Capsule())
                    .overlay(Capsule().strokeBorder(Color.white.opacity(0.08), lineWidth: 1))
                }
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .obsidianCard(24, padding: 18)
        .privacySensitive()
        .accessibilityElement(children: .contain)
    }
}
