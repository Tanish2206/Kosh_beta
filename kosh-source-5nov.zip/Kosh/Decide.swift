import SwiftUI
import Charts

// MARK: - Should I…? and where it's heading (decide.js)
//
// Ask kosh weighs a money decision on the household's own numbers (prepay a loan or invest, a car in cash or on a
// loan, can we afford something, break an FD, is the emergency fund enough, the card in full or the minimum) and
// shows its working: the answer in a sentence, the figures that decide it, every step with how it was worked out,
// what it assumed (change it and it works it out again), and what would turn the answer. A decision can be saved on
// this phone and opened later on that day's numbers: "since you saved this, the loan's rate went from 8.5% to
// 8.75%". "Where this is heading" draws net worth five years on at today's pace and, dashed beside it, a change:
// more into SIPs, a prepayment, a big purchase, income up or down; its growth rates are shown and can be changed.
// decide.js does every sum; this only draws what it hands back.

// MARK: what decide.js hands back

/// one numbered step of the working: what, the figure, and how it was worked out
struct DecisionStep: Codable, Hashable, Identifiable {
    let n: Int
    let label: String
    let value: String
    let how: String
    var id: Int { n }
}

/// an assumption the answer rests on, with its unit ("%", "₹", "months", "years"); one with a range can be changed
struct DecisionKnob: Codable, Hashable, Identifiable {
    let key: String
    let label: String
    var value: Double
    let unit: String
    var min: Double? = nil
    var max: Double? = nil
    var step: Double? = nil
    var note: String? = nil
    var id: String { key }
    var editable: Bool { min != nil && max != nil }

    /// "8.5%", "₹3,00,000", "6 months", "1 year"
    static func shown(_ v: Double, _ unit: String) -> String {
        switch unit {
        case "%": return Fmt.trim(v, 2) + "%"
        case "₹": return (v < -0.5 ? "−" : "") + Fmt.rupees(v)
        case "months": return Fmt.trim(v, 2) + (v == 1 ? " month" : " months")
        case "years": return Fmt.trim(v, 2) + (v == 1 ? " year" : " years")
        default: return Fmt.trim(v, 2) + " " + unit
        }
    }
}

/// one of the household's own figures a decision used, saved with it so working it out again can say what moved
struct DecisionFact: Codable, Hashable {
    let key: String
    let label: String
    let value: Double
    let unit: String
}

/// a decision carried into the five years ahead: a prepayment, or a purchase (part of it on a new loan)
struct DecisionScenario: Codable, Hashable {
    struct Prepay: Codable, Hashable { var amount: Double; var loan: String? = nil }
    struct Borrow: Codable, Hashable { var amount: Double; var rate: Double; var months: Int }
    struct Purchase: Codable, Hashable { var amount: Double; var year: Int; var loan: Borrow? = nil }
    var prepay: Prepay? = nil
    var purchase: Purchase? = nil
    var sip: Double? = nil
    var income: Double? = nil
}

struct Decision: Codable, Hashable, Identifiable {
    var id: String
    let kind: String
    let title: String
    let verdict: String
    let lean: String
    let steps: [DecisionStep]
    /// the steps that decide it, shown under the answer
    var key: [Int]? = nil
    let assumptions: [DecisionKnob]
    let changes: [String]
    let note: String
    /// what kosh needs to weigh it, when it can't yet
    let missing: [String]
    let facts: [DecisionFact]
    /// what was asked, as JSON: worked out again from it (with whatever was changed)
    let args: String
    let asOf: String
    var scenario: DecisionScenario? = nil
    /// worked out again: what moved since it was saved
    var since: [String]? = nil
    var savedOn: String? = nil
    /// the question as it was asked, for the saved list
    var question: String? = nil

    var complete: Bool { missing.isEmpty && lean != "unknown" }
    var keySteps: [DecisionStep] {
        let k: Set<Int> = Set(key ?? [])
        return steps.filter { k.contains($0.n) }
    }
    var sym: String {
        switch kind {
        case "prepay": return "building.columns.fill"
        case "car": return "car.fill"
        case "afford": return "cart.fill"
        case "fd": return "banknote.fill"
        case "emergency": return "cross.case.fill"
        case "card": return "creditcard.fill"
        default: return "scalemass.fill"
        }
    }
    /// the answer in a word or two, no figures: which way it leans
    var answer: String? {
        switch kind + "." + lean {
        case "prepay.invest": return "Leans invest"
        case "prepay.prepay": return "Leans prepay"
        case "prepay.close": return "Close call"
        case "car.loan": return "Leans loan"
        case "car.cash": return "Leans cash"
        case "afford.yes": return "Yes"
        case "afford.stretch": return "A stretch"
        case "afford.no": return "Not yet"
        case "fd.keep": return "Leave it"
        case "fd.borrow": return "Leans borrowing"
        case "fd.break": return "Leans breaking it"
        case "fd.even": return "About even"
        case "emergency.yes": return "Enough"
        case "emergency.fd": return "With your FDs"
        case "emergency.no": return "Not yet"
        case "card.full": return "Pay in full"
        case "card.most": return "Pay what you can"
        default: return nil
        }
    }
}

struct OutlookParts: Codable, Hashable {
    let cash: Double
    let invest: Double
    let safe: Double
    let other: Double
    let loans: Double
}

/// net worth at a year's end (0 is today)
struct OutlookPoint: Codable, Hashable, Identifiable {
    let y: Int
    let date: String
    let worth: Double
    let parts: OutlookParts
    var id: Int { y }
}

/// the months behind it: what's left before investing (the middle of them, and their range), and what's invested
struct OutlookFlow: Codable, Hashable {
    let before: Double
    let invest: Double
    let income: Double
    let lo: Double
    let hi: Double
    let months: Int
    let sip: Double
    /// kosh sees the spending but not the income (a salary in an account that sends no mail): the line holds the bank
    /// where it is rather than invent a fall, and asks for the take-home
    var blind: Bool = false
    enum CodingKeys: String, CodingKey { case before, invest, income, lo, hi, months, sip, blind }
    init(from d: Decoder) throws {
        let c = try d.container(keyedBy: CodingKeys.self)
        before = try c.decode(Double.self, forKey: .before); invest = try c.decode(Double.self, forKey: .invest)
        income = try c.decode(Double.self, forKey: .income); lo = try c.decode(Double.self, forKey: .lo)
        hi = try c.decode(Double.self, forKey: .hi); months = try c.decode(Int.self, forKey: .months)
        sip = try c.decode(Double.self, forKey: .sip); blind = (try? c.decodeIfPresent(Bool.self, forKey: .blind)) ?? false
    }
}

struct OutlookEvent: Codable, Hashable {
    let y: Int
    let date: String
    let text: String
}

/// five years ahead at today's pace, and a change beside it
struct WorthOutlook: Codable, Hashable {
    let today: String
    let years: Int
    let start: OutlookPoint
    let base: [OutlookPoint]
    let scen: [OutlookPoint]
    let flow: OutlookFlow
    let assumptions: [DecisionKnob]
    let events: [OutlookEvent]
    let notes: [String]
    let headline: String
    let scenarioLine: String
    /// the end figure in today's money
    let real: Double
    /// the month the bank would run short, at this pace and with the change ("" when it doesn't)
    let dry: String
    let dryAlt: String
}

// MARK: the engine, off the main thread (a build may be holding it)

enum DecideEngine {
    static func call(_ fn: String, _ args: [String]) -> String? {
        guard let out = try? Engine.shared.call(fn, args), !out.isEmpty, out != "null" else { return nil }
        return out
    }
    static func decide(_ kind: String, args: String, ctx: String) async -> Decision? {
        let out: String? = await Task.detached(priority: .userInitiated) { DecideEngine.call("decideJSON", [kind, args, ctx]) }.value
        return out.flatMap { try? JSONText.decode(Decision.self, $0) }
    }
    static func rerun(_ saved: Decision, ctx: String) async -> Decision? {
        let json: String = JSONText.encode(saved)
        let out: String? = await Task.detached(priority: .userInitiated) { DecideEngine.call("decideRerunJSON", [json, ctx]) }.value
        return out.flatMap { try? JSONText.decode(Decision.self, $0) }
    }
    static func project(ctx: String, opts: String) async -> WorthOutlook? {
        let out: String? = await Task.detached(priority: .userInitiated) { DecideEngine.call("projectJSON", [ctx, opts]) }.value
        return out.flatMap { try? JSONText.decode(WorthOutlook.self, $0) }
    }

    /// what decide.js reads: balances, cards, what's due, repeats, holdings, the months behind, the loans. With
    /// `start`, what the five years start from, the family's as the phone shows them (cash in hand, what you said a
    /// loan stands at), so the line opens on the net worth on Home
    @MainActor static func context(_ store: Store, start: Bool = false) -> String {
        let s: Snapshot = store.snap.whole
        var d: [String: Any] = ["today": s.today]
        d["accounts"] = s.accounts.map { a -> [String: Any] in
            var x: [String: Any] = ["name": a.name, "bank": a.bank, "last": a.last, "asOf": a.asOf]
            if let b = a.balance { x["balance"] = b }
            return x
        }
        d["cards"] = s.cards.map { c -> [String: Any] in
            var x: [String: Any] = ["name": c.name, "bank": c.bank, "last": c.last]
            if let v = c.due { x["due"] = v }
            if let v = c.minDue { x["minDue"] = v }
            if let v = c.dueDate { x["dueDate"] = v }
            if let v = c.stmtOn { x["stmtOn"] = v }
            if let v = c.paid { x["paid"] = v }
            if let v = c.paidOn { x["paidOn"] = v }
            return x
        }
        d["agenda"] = s.agenda.compactMap { a -> [String: Any]? in
            guard let date = a.date else { return nil }
            return ["date": date, "name": a.name, "amt": a.amt, "sub": a.sub, "kind": a.kind, "booked": a.booked]
        }
        d["recurring"] = s.recurring.map { r -> [String: Any] in
            var x: [String: Any] = ["name": r.name, "amount": r.amount, "kind": r.kind, "per": r.per ?? 1]
            if let g = r.gone { x["gone"] = g }
            if let l = r.lapsed { x["lapsed"] = l }
            return x
        }
        let hold: [[String: Any]] = store.holdings(.family).map { h -> [String: Any] in
            var x: [String: Any] = ["bank": h.bank, "type": h.type, "cls": h.cls, "amt": h.amt, "rate": h.rate]
            if let m = h.mat { x["mat"] = m }
            return x
        }
        d["hold"] = hold
        d["fc"] = ["usual": s.fc.usual]
        d["cashflow"] = (s.cashflow ?? []).map { c -> [String: Any] in
            var x: [String: Any] = ["m": c.m, "inn": c.inn, "out": c.out, "inv": c.inv, "kept": c.kept, "live": c.live]
            if let ev = c.ev { x["ev"] = ev }
            if c.noPay == true { x["noPay"] = true }
            return x
        }
        let loans: [[String: Any]] = loansJSON(store)
        d["loans"] = loans
        if start {
            d["start"] = ["bank": store.bankBalance(.family), "cash": store.cashInHand, "prop": store.propertyWorth(.family), "hold": hold, "loans": loans] as [String: Any]
        }
        return JSONText.object(d)
    }

    /// the loans running, at what you said they stand at (Portfolio › Debts), else what the bank said
    @MainActor static func loansJSON(_ store: Store) -> [[String: Any]] {
        store.snap.loans.filter { $0.active }.map { l -> [String: Any] in
            var x: [String: Any] = ["name": l.name, "bank": l.bank, "emi": l.emi, "active": true]
            if let b = store.loanBalance(l) { x["outstanding"] = b }
            if let r = l.rate, r > 0 { x["rate"] = r }
            if l.est == true { x["est"] = true }
            if let d = l.due, !d.isEmpty { x["due"] = d }
            if let n = l.n, n > 0, let left = l.left { x["n"] = n; x["left"] = left }
            // the day of the month its EMI goes, for Ask kosh's "when is the next EMI" when the calendar hasn't learnt it
            if l.day >= 1 && l.day <= 31 { x["day"] = l.day }
            return x
        }
    }
}

// MARK: the decisions you saved, on this phone

/// decisions.json beside the records, encrypted like them; newest first
@MainActor @Observable
final class DecisionBook {
    static let shared = DecisionBook()
    private(set) var items: [Decision] = []
    /// read from the file (or there was none): until then nothing is written over it, so a start before the phone's
    /// first unlock (when the file can't be read yet) never loses what was saved
    @ObservationIgnored private var loaded = false
    private var url: URL { LiveSession.folder.appendingPathComponent("decisions.json") }
    /// one write after another, in the order they were made (a save then a delete never lands the other way round)
    private static let queue = DispatchQueue(label: "kosh.decisions", qos: .utility)

    private init() { load() }

    func load() {
        guard !loaded else { return }
        let u: URL = url
        guard FileManager.default.fileExists(atPath: u.path) else { loaded = true; return }
        guard let d = try? Data(contentsOf: u) else { return }
        // one by one: a decision this version can't read is left out, never the rest with it
        // (in whatever shape a kosh wrote it: SavedFormat)
        if let list = try? SavedFormat.decode(LiveSession.LossyList<Decision>.self, d, .decisions).value {
            items = list.items
        } else {
            // not a list at all: the file is set aside (dated), not written over
            let aside: URL = u.deletingPathExtension().appendingPathExtension("unread-" + Day.iso(Date()) + ".json")
            if !FileManager.default.fileExists(atPath: aside.path) { try? FileManager.default.copyItem(at: u, to: aside) }
            items = []
        }
        loaded = true
    }
    private func write() {
        load()
        guard loaded else { return }
        let all: [Decision] = items
        let u: URL = url
        Self.queue.async {
            if let d = try? JSONEncoder().encode(all) { try? SavedFormat.write(d, .decisions, to: u, options: [.atomic, LiveSession.protection]) }
        }
    }
    /// Erase: every saved decision goes, from the screen and the disk
    func clear() {
        items = []
        loaded = true
        let u: URL = url
        Self.queue.async { try? FileManager.default.removeItem(at: u) }
    }
    /// saved under its own id, with the day and the question as asked
    @discardableResult
    func save(_ d: Decision, question: String, today: String) -> Decision {
        load()
        var x: Decision = d
        x.id = UUID().uuidString
        x.savedOn = today
        x.question = question.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? d.title : question
        x.since = nil
        items.insert(x, at: 0)
        write()
        return x
    }
    /// a saved one worked out again, saved as it now stands (its question and place in the list stay)
    func replace(_ id: String, with d: Decision, today: String) {
        load()
        guard let i = items.firstIndex(where: { $0.id == id }) else { return }
        var x: Decision = d
        x.id = id
        x.savedOn = today
        x.question = items[i].question
        x.since = nil
        items[i] = x
        write()
    }
    func remove(_ id: String) {
        load()
        items.removeAll { $0.id == id }
        write()
    }
    func isSaved(_ d: Decision) -> Bool { items.contains { $0.kind == d.kind && $0.args == d.args && $0.asOf == d.asOf && $0.verdict == d.verdict } }
}

// MARK: a decision, as Ask kosh shows it

/// a decision carried into "Where this is heading"
struct OutlookStart: Identifiable {
    let id = UUID()
    let scenario: DecisionScenario
}

struct DecisionCard: View {
    @Environment(Store.self) private var store
    let question: String
    /// Claude wrote the answer above it: the card is its working, without the answer again
    var compact: Bool = false
    /// Save is offered (not on a saved one, opened from the list)
    var saving: Bool = true
    /// what it assumed can be changed (not on a saved one as it was: changing it would mix that day's numbers with today's)
    var editable: Bool = true
    /// told each time it's worked out again, so a saved one opened from the list saves the version on screen
    var onChange: ((Decision) -> Void)? = nil
    @State private var d: Decision
    @State private var edits: [String: Double] = [:]
    @State private var working = false
    @State private var showSteps = false
    @State private var showKnobs = false
    @State private var outlook: OutlookStart?
    @State private var savedNow = false

    init(decision: Decision, question: String, compact: Bool = false, saving: Bool = true, editable: Bool = true, onChange: ((Decision) -> Void)? = nil) {
        self.question = question
        self.compact = compact
        self.saving = saving
        self.editable = editable
        self.onChange = onChange
        _d = State(initialValue: decision)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            head
            if !compact {
                Text(AskSheet.rich(d.verdict))
                    .font(.body)
                    .fixedSize(horizontal: false, vertical: true)
                    .privacySensitive()
                if d.complete && !d.keySteps.isEmpty { DecisionKeyFigures(steps: d.keySteps) }
            }
            if d.complete {
                workingGroup
                if !d.assumptions.isEmpty { knobsGroup }
                if !d.changes.isEmpty { DecisionChanges(lines: d.changes) }
            }
            if !d.note.isEmpty {
                Text(d.note).font(.caption).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            }
            if d.complete && (saving || usable != nil) { actions }
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.surface, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        .sheet(item: $outlook) { o in
            OutlookView(start: o.scenario)
                .environment(store)
                .tint(Color.kosh)
                .redacted(reason: store.hidden ? .privacy : [])
        }
    }

    var head: some View {
        HStack(alignment: .center, spacing: 10) {
            IconTile(symbol: d.sym, color: Color.kosh, size: 30)
            Text(d.title).font(.subheadline.weight(.semibold)).fixedSize(horizontal: false, vertical: true)
            Spacer(minLength: 6)
            if let a = d.answer {
                Text(a)
                    .font(.caption.weight(.bold))
                    .foregroundStyle(Color.kosh)
                    .padding(.horizontal, 9)
                    .padding(.vertical, 4)
                    .background(Color.kosh.opacity(0.12), in: Capsule())
                    .fixedSize()
            }
        }
    }

    var workingGroup: some View {
        DisclosureGroup(isExpanded: $showSteps) {
            DecisionWorking(steps: d.steps, key: Set(d.key ?? [])).padding(.top, 12)
        } label: {
            Label("Show the working", systemImage: "list.number").font(.subheadline.weight(.semibold))
        }
        .tint(Color.primary)
    }

    var knobsGroup: some View {
        DisclosureGroup(isExpanded: $showKnobs) {
            VStack(alignment: .leading, spacing: 14) {
                ForEach(d.assumptions) { k in
                    if editable && k.editable {
                        DecisionKnobRow(knob: k, value: binding(k))
                    } else {
                        HStack(alignment: .firstTextBaseline) {
                            Text(k.label).font(.subheadline)
                            Spacer(minLength: 6)
                            Text(DecisionKnob.shown(k.value, k.unit)).font(.subheadline.weight(.semibold)).monospacedDigit().privacySensitive()
                        }
                    }
                }
                if editable {
                    Button { rework() } label: {
                        HStack(spacing: 6) {
                            if working { ProgressView().controlSize(.small) }
                            Text("Work it out again")
                        }
                    }
                    .buttonStyle(.glassProminent).koshFilled()
                    .font(.subheadline.weight(.semibold))
                    .disabled(!changed || working)
                }
            }
            .padding(.top, 12)
        } label: {
            Label(editable ? "Change what it assumed" : "What it assumed", systemImage: "slider.horizontal.3").font(.subheadline.weight(.semibold))
        }
        .tint(Color.primary)
    }

    @ViewBuilder var actions: some View {
        let saved: Bool = savedNow || DecisionBook.shared.isSaved(d)
        HStack(spacing: 10) {
            if saving {
                Button { save() } label: {
                    Label(saved ? "Saved" : "Save", systemImage: saved ? "bookmark.fill" : "bookmark")
                }
                .buttonStyle(.glass)
                .disabled(saved)
            }
            if let s = usable {
                Button { outlook = OutlookStart(scenario: s) } label: {
                    Label("See five years ahead", systemImage: "chart.line.uptrend.xyaxis")
                }
                .buttonStyle(.glass)
            }
        }
        .font(.subheadline.weight(.semibold))
        // (only on saving: working it out again clears savedNow, and that's no success)
        .sensoryFeedback(.success, trigger: savedNow) { _, new in new }
    }

    /// its five years ahead, when the phone has what they need (a prepayment needs the loan added in Debts)
    var usable: DecisionScenario? {
        guard let s = d.scenario else { return nil }
        if let pp = s.prepay {
            let names: [String] = store.snap.loans.filter { $0.active && (store.loanBalance($0) ?? 0) > 0 }.map(\.name)
            guard let l = pp.loan, names.contains(l) else { return nil }
        }
        return s
    }

    func binding(_ k: DecisionKnob) -> Binding<Double> {
        Binding(get: { edits[k.key] ?? k.value }, set: { edits[k.key] = $0 })
    }
    var changed: Bool {
        for k in d.assumptions {
            if let v = edits[k.key], abs(v - k.value) > 0.0001 { return true }
        }
        return false
    }

    /// saved under the question that started it (a follow-up's carries the first one), with any change of what it
    /// assumed worked in first
    func save() {
        if changed {
            rework { fresh in keep(fresh) }
        } else {
            keep(d)
        }
    }
    private func keep(_ x: Decision) {
        let asked: String = (x.question ?? "").isEmpty ? question : (x.question ?? question)
        DecisionBook.shared.save(x, question: asked, today: store.snap.today)
        withAnimation(Motion.base) { savedNow = true }
    }

    /// the same question with what was changed, on the numbers as they are
    func rework(then: ((Decision) -> Void)? = nil) {
        var args: [String: Any] = ((try? JSONSerialization.jsonObject(with: Data(d.args.utf8))) as? [String: Any]) ?? [:]
        for (k, v) in edits { args[k] = v }
        // an amount you set is yours, no longer kosh's example
        if edits["amount"] != nil { args.removeValue(forKey: "example") }
        let kind: String = d.kind
        let json: String = JSONText.object(args)
        let ctx: String = DecideEngine.context(store)
        let asked: String? = d.question
        working = true
        Task { @MainActor in
            let got: Decision? = await DecideEngine.decide(kind, args: json, ctx: ctx)
            working = false
            guard var fresh = got else { return }
            fresh.question = asked
            withAnimation(Motion.open) {
                d = fresh
                edits = [:]
                savedNow = false
            }
            onChange?(fresh)
            then?(fresh)
        }
    }
}

/// the figures that decide it, under the answer
struct DecisionKeyFigures: View {
    let steps: [DecisionStep]
    var body: some View {
        VStack(spacing: 0) {
            ForEach(Array(steps.enumerated()), id: \.element.id) { i, s in
                if i > 0 { Divider() }
                ViewThatFits(in: .horizontal) {
                    HStack(alignment: .firstTextBaseline, spacing: 10) {
                        Text(s.label).font(.subheadline).foregroundStyle(.secondary).lineLimit(1)
                        Spacer(minLength: 8)
                        Text(s.value).font(.subheadline.weight(.semibold)).monospacedDigit().lineLimit(1)
                    }
                    VStack(alignment: .leading, spacing: 2) {
                        Text(s.label).font(.subheadline).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                        Text(s.value).font(.subheadline.weight(.semibold)).monospacedDigit().fixedSize(horizontal: false, vertical: true)
                    }
                }
                .padding(.vertical, 8)
                .privacySensitive()
                .accessibilityElement(children: .combine)
            }
        }
    }
}

/// the working: numbered, the steps that decide it marked, each with its figure and how it was worked out
struct DecisionWorking: View {
    let steps: [DecisionStep]
    let key: Set<Int>
    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            ForEach(steps) { s in DecisionStepRow(step: s, key: key.contains(s.n)) }
        }
    }
}

struct DecisionStepRow: View {
    let step: DecisionStep
    let key: Bool
    /// the number's circle, sized with the text
    @ScaledMetric(relativeTo: .caption2) private var dot: CGFloat = 20
    var body: some View {
        HStack(alignment: .firstTextBaseline, spacing: 10) {
            Text("\(step.n)")
                .font(.caption2.weight(.bold)).monospacedDigit()
                .foregroundStyle(key ? Color.onKosh : Color.secondary)
                .frame(width: dot, height: dot)
                .background(key ? Color.koshFill : Color.primary.opacity(0.08), in: Circle())
            VStack(alignment: .leading, spacing: 3) {
                Text(step.label).font(.subheadline.weight(.medium)).fixedSize(horizontal: false, vertical: true)
                Text(step.value)
                    .font(.subheadline.weight(.semibold)).monospacedDigit()
                    .foregroundStyle(key ? Color.kosh : Color.primary)
                    .fixedSize(horizontal: false, vertical: true)
                if !step.how.isEmpty {
                    Text(step.how).font(.caption).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                }
            }
            .privacySensitive()
        }
        .accessibilityElement(children: .combine)
    }
}

struct DecisionChanges: View {
    let lines: [String]
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("What would change the answer").font(.caption.weight(.semibold)).foregroundStyle(.secondary)
            ForEach(lines, id: \.self) { c in
                HStack(alignment: .firstTextBaseline, spacing: 7) {
                    Text("•").foregroundStyle(.secondary)
                    Text(c).fixedSize(horizontal: false, vertical: true).privacySensitive()
                }
                .font(.footnote)
            }
        }
    }
}

/// one assumption with a stepper: a rate, an amount, months or years
struct DecisionKnobRow: View {
    let knob: DecisionKnob
    @Binding var value: Double
    var body: some View {
        let lo: Double = knob.min ?? 0
        let hi: Double = Swift.max(lo, knob.max ?? lo)
        let small: Double = knob.step ?? (knob.unit == "₹" ? 1000 : 1)
        let by: Double = knob.unit == "₹" ? Swift.max(small, OutlookKit.step(abs(value), small: small)) : small
        VStack(alignment: .leading, spacing: 3) {
            Stepper(value: $value, in: lo...hi, step: by) {
                VStack(alignment: .leading, spacing: 1) {
                    Text(knob.label).font(.subheadline)
                    Text(DecisionKnob.shown(value, knob.unit))
                        .font(.subheadline.weight(.semibold)).monospacedDigit()
                        .foregroundStyle(Color.kosh)
                        .contentTransition(.numericText(value: value))
                        .privacySensitive()
                }
            }
            if let n = knob.note, !n.isEmpty {
                Text(n).font(.caption).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true).privacySensitive()
            }
        }
    }
}

// MARK: the decisions you saved

struct DecisionsList: View {
    @Environment(Store.self) private var store
    var body: some View {
        let book: DecisionBook = DecisionBook.shared
        List {
            if book.items.isEmpty {
                ContentUnavailableView("Nothing saved yet", systemImage: "bookmark",
                                       description: Text("Save a decision from Ask kosh, and open it later to see it on that day’s numbers."))
            } else {
                Section {
                    ForEach(book.items) { d in
                        NavigationLink {
                            DecisionDetail(saved: d)
                        } label: {
                            DecisionListRow(d: d, hidden: store.hidden)
                        }
                    }
                    .onDelete { at in
                        let ids: [String] = at.map { book.items[$0].id }
                        withAnimation(Motion.open) { for id in ids { book.remove(id) } }
                    }
                } footer: {
                    Text("Saved on this phone. Open one to see it worked out on today’s numbers, and what moved.")
                }
            }
        }
        .listStyle(.insetGrouped)
        .navigationTitle("Saved decisions")
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct DecisionListRow: View {
    let d: Decision
    let hidden: Bool
    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            IconTile(symbol: d.sym, color: Color.kosh, size: 34)
            VStack(alignment: .leading, spacing: 3) {
                // the question can carry amounts: with amounts hidden, the decision's own title
                Text(hidden ? d.title : (d.question ?? d.title)).font(.body.weight(.medium)).lineLimit(2)
                if let a = d.answer { Text(a).font(.subheadline).foregroundStyle(Color.kosh) }
                if let on = d.savedOn, !on.isEmpty {
                    Text("Saved " + Day.fmt(on, "d MMM yyyy")).font(.caption).foregroundStyle(.secondary)
                }
            }
        }
        .padding(.vertical, 2)
    }
}

/// a saved decision, worked out again on today's numbers as it opens: what moved, today's answer, and how it was
struct DecisionDetail: View {
    @Environment(Store.self) private var store
    let saved: Decision
    @State private var fresh: Decision?
    /// the version on screen: today's, or what you changed it to since
    @State private var latest: Decision?
    @State private var tried = false
    @State private var resaved = false

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                VStack(alignment: .leading, spacing: 4) {
                    Text(store.hidden ? saved.title : (saved.question ?? saved.title))
                        .font(.title3.weight(.bold))
                        .fixedSize(horizontal: false, vertical: true)
                    if let on = saved.savedOn, !on.isEmpty {
                        Text("Saved " + Day.fmt(on, "d MMMM yyyy")).font(.subheadline).foregroundStyle(.secondary)
                    }
                }
                if let f = fresh {
                    let shown: Decision = latest ?? f
                    DecisionSince(lines: f.since ?? [], canSave: shown.verdict != saved.verdict || shown.args != saved.args, resaved: resaved) {
                        DecisionBook.shared.replace(saved.id, with: shown, today: store.snap.today)
                        withAnimation(Motion.base) { resaved = true }
                    }
                    DecisionCard(decision: f, question: saved.question ?? "", saving: false) { changed in
                        latest = changed
                        resaved = false
                    }
                    .id(f.asOf + f.args)
                    if f.verdict != saved.verdict {
                        DisclosureGroup {
                            Text(AskSheet.rich(saved.verdict))
                                .font(.subheadline).foregroundStyle(.secondary)
                                .fixedSize(horizontal: false, vertical: true)
                                .privacySensitive()
                                .padding(.top, 6)
                        } label: {
                            Text("As it was on " + Day.fmt(saved.savedOn ?? saved.asOf, "d MMM")).font(.subheadline.weight(.semibold))
                        }
                        .tint(Color.primary)
                        .padding(.horizontal, 4)
                    }
                } else if tried {
                    DecisionCard(decision: saved, question: saved.question ?? "", saving: false, editable: false)
                } else {
                    HStack(spacing: 8) {
                        ProgressView()
                        Text("Working it out on today’s numbers…").foregroundStyle(.secondary)
                    }
                    .frame(maxWidth: .infinity, minHeight: 120)
                }
            }
            .padding(20)
        }
        .navigationTitle("Saved decision")
        .navigationBarTitleDisplayMode(.inline)
        .task { await rerun() }
    }

    func rerun() async {
        guard fresh == nil else { return }
        let ctx: String = DecideEngine.context(store)
        let f: Decision? = await DecideEngine.rerun(saved, ctx: ctx)
        tried = true
        withAnimation(Motion.open) { fresh = f }
    }
}

/// what moved since it was saved
struct DecisionSince: View {
    let lines: [String]
    let canSave: Bool
    let resaved: Bool
    let save: () -> Void
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Label("Since you saved this", systemImage: "clock.arrow.circlepath").font(.subheadline.weight(.semibold))
            ForEach(lines, id: \.self) { l in
                HStack(alignment: .firstTextBaseline, spacing: 7) {
                    Text("•").foregroundStyle(.secondary)
                    Text(l).fixedSize(horizontal: false, vertical: true).privacySensitive()
                }
                .font(.subheadline)
            }
            if canSave {
                Button(action: save) {
                    Label(resaved ? "Saved" : "Save this version", systemImage: resaved ? "checkmark" : "bookmark")
                }
                .buttonStyle(.glass)
                .font(.subheadline.weight(.semibold))
                .disabled(resaved)
                .padding(.top, 2)
            }
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.kosh.opacity(0.08), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
    }
}

// MARK: where it's heading: five years at today's pace, and a change beside it

/// on the net worth card and in Portfolio: a row that opens the five years ahead
struct OutlookLink: View {
    @Environment(Store.self) private var store
    @State private var show = false
    @State private var line = ""
    static let plain = "Five years at today’s pace, and what a change would do"

    var body: some View {
        Button { show = true } label: {
            HStack(spacing: 12) {
                IconTile(symbol: "chart.line.uptrend.xyaxis", color: Color.kosh, size: 36)
                VStack(alignment: .leading, spacing: 2) {
                    Text("Where this is heading").font(.body.weight(.medium)).foregroundStyle(Color.primary)
                    // with amounts hidden, the words without the figure
                    Text(store.hidden || line.isEmpty ? Self.plain : line)
                        .font(.subheadline).foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                }
                Spacer(minLength: 4)
                Image(systemName: "chevron.right").font(.footnote.weight(.semibold)).foregroundStyle(.tertiary)
            }
            .contentShape(Rectangle())
        }
        .buttonStyle(.press)
        .sheet(isPresented: $show) {
            OutlookView(start: nil)
                .environment(store)
                .tint(Color.kosh)
                .redacted(reason: store.hidden ? .privacy : [])
        }
        .task(id: store.snap.generated) { await teaser() }
    }

    func teaser() async {
        let ctx: String = DecideEngine.context(store, start: true)
        let opts: String = JSONText.object(["assume": OutlookKit.savedRates()])
        guard let p = await DecideEngine.project(ctx: ctx, opts: opts), let end = p.base.last, p.flow.months > 0 || abs(p.start.worth) > 0.5 else {
            line = ""
            return
        }
        if p.flow.blind {
            line = "kosh can’t see your income yet: add your take-home"
        } else {
            line = "About " + OutlookKit.signed(end.worth) + " by " + Day.fmt(end.date, "MMM yyyy") + ", at this pace"
        }
    }
}

/// the five years' small helpers: the growth rates you set, amounts in words, a stepper's step
enum OutlookKit {
    /// the growth rates you set, saved for next time (the monthly figures are your own months', so they aren't)
    static let ratesKey = "decide.rates"
    static let rateKeys: Set<String> = ["equity", "debt", "savings", "ret", "gold", "ins", "prop", "inflation"]
    static func savedRates() -> [String: Double] { (UserDefaults.standard.dictionary(forKey: ratesKey) as? [String: Double]) ?? [:] }
    /// ₹12L, −₹3.4L
    static func signed(_ v: Double) -> String { (v < -0.5 ? "−" : "") + Fmt.words(v) }
    /// a stepper's step for an amount: fine near nothing, coarser as it grows
    static func step(_ v: Double, small: Double) -> Double {
        if v >= 1e7 { return Swift.max(small, 500000) }
        if v >= 1e6 { return Swift.max(small, 100000) }
        if v >= 1e5 { return Swift.max(small, 10000) }
        return small
    }
    /// "5 years", "1 year", "18 months"
    static func months(_ n: Int) -> String { n % 12 == 0 ? "\(n / 12) year" + (n == 12 ? "" : "s") : "\(n) months" }
    /// "Shares 10% · Bonds 7% · Savings 3% · EPF 7.5% · Gold 6% · Property 5% · Prices 5%"
    static func rateLine(_ ks: [DecisionKnob]) -> String {
        let short: [String: String] = ["equity": "Shares", "debt": "Bonds", "savings": "Savings", "ret": "EPF", "gold": "Gold", "prop": "Property", "inflation": "Prices"]
        return ks.filter { $0.unit == "%" && short[$0.key] != nil }.map { (short[$0.key] ?? $0.key) + " " + Fmt.trim($0.value, 2) + "%" }.joined(separator: " · ")
    }
}

/// everything the line depends on: a change in any of it works the five years out again
struct OutlookInputs: Equatable {
    var sip: Double
    var prepayLoan: String
    var prepay: Double
    var buy: Double
    var buyYear: Int
    var borrow: DecisionScenario.Borrow?
    var onLoan: Bool
    var income: Double
    var assume: [String: Double]
    var built: String
}

struct OutlookView: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    @State private var p: WorthOutlook?
    @State private var sip: Double
    @State private var prepayLoan: String
    @State private var prepay: Double
    @State private var buy: Double
    @State private var buyYear: Int
    @State private var borrow: DecisionScenario.Borrow?
    @State private var onLoan: Bool
    @State private var income: Double
    @State private var assume: [String: Double] = OutlookKit.savedRates()
    @State private var showAssume = false
    @State private var picked: Double?
    /// the "on the way" dates, sized with the text
    @ScaledMetric(relativeTo: .footnote) private var dateColumn: CGFloat = 76

    /// a decision's change to start from ("See five years ahead"); nil for today's pace alone
    init(start: DecisionScenario?) {
        _sip = State(initialValue: start?.sip ?? 0)
        _prepayLoan = State(initialValue: start?.prepay?.loan ?? "")
        _prepay = State(initialValue: start?.prepay?.amount ?? 0)
        _buy = State(initialValue: start?.purchase?.amount ?? 0)
        _buyYear = State(initialValue: Swift.min(5, Swift.max(1, start?.purchase?.year ?? 1)))
        _borrow = State(initialValue: start?.purchase?.loan)
        _onLoan = State(initialValue: start?.purchase?.loan != nil)
        _income = State(initialValue: start?.income ?? 0)
    }

    var loans: [Loan] { store.snap.loans.filter { $0.active && (store.loanBalance($0) ?? 0) > 0 } }
    var inputs: OutlookInputs {
        OutlookInputs(sip: sip, prepayLoan: prepayLoan, prepay: prepay, buy: buy, buyYear: buyYear, borrow: borrow, onLoan: onLoan, income: income, assume: assume, built: store.snap.generated)
    }
    var changing: Bool { sip > 0 || prepay > 0 || buy > 0 || income != 0 }

    var body: some View {
        NavigationStack {
            List {
                Section { top }
                whatIf
                if let p {
                    assumptionsSection(p)
                    eventsSection(p)
                }
            }
            .listStyle(.insetGrouped)
            .navigationTitle("Where this is heading")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } } }
            .sheet(isPresented: $showAssume) {
                OutlookAssumptions(knobs: p?.assumptions ?? [], assume: $assume)
                    .environment(store)
                    .tint(Color.kosh)
                    .redacted(reason: store.hidden ? .privacy : [])
            }
            .onAppear {
                // a loan named by a decision, else the biggest
                if !loans.contains(where: { $0.name == prepayLoan }) {
                    prepayLoan = loans.max(by: { (store.loanBalance($0) ?? 0) < (store.loanBalance($1) ?? 0) })?.name ?? ""
                }
            }
            .task(id: inputs) { await recompute() }
            .onChange(of: assume) { _, v in
                UserDefaults.standard.set(v.filter { OutlookKit.rateKeys.contains($0.key) }, forKey: OutlookKit.ratesKey)
            }
        }
    }

    // the figure five years on, the line, and a year read off it

    @ViewBuilder var top: some View {
        if let p, let end = p.base.last {
            VStack(alignment: .leading, spacing: 16) {
                OutlookHead(p: p, end: end)
                OutlookChart(p: p, picked: $picked, hidden: store.hidden)
                    .frame(height: 210)
                if !p.scen.isEmpty { OutlookKey() }
                OutlookYear(pt: point(p), alt: p.scen.first(where: { $0.y == year(p) }))
            }
            .padding(.vertical, 6)
        } else {
            HStack(spacing: 8) {
                ProgressView()
                Text("Working it out…").foregroundStyle(.secondary)
            }
            .frame(maxWidth: .infinity, minHeight: 240)
        }
    }
    func year(_ p: WorthOutlook) -> Int {
        guard let x = picked else { return p.years }
        return Swift.min(p.years, Swift.max(0, Int(x.rounded())))
    }
    func point(_ p: WorthOutlook) -> OutlookPoint { p.base.first(where: { $0.y == year(p) }) ?? p.base[p.base.count - 1] }

    // what if

    @ViewBuilder var whatIf: some View {
        Section {
            Stepper(value: $sip, in: 0...500000, step: OutlookKit.step(sip, small: 1000)) {
                OutlookAmountLabel(title: "More into SIPs, a month", value: sip, words: false)
            }
            if !loans.isEmpty {
                if loans.count > 1 {
                    Picker("Prepay", selection: $prepayLoan) {
                        ForEach(loans) { l in Text(l.name).tag(l.name) }
                    }
                }
                Stepper(value: $prepay, in: 0...maxPrepay, step: OutlookKit.step(prepay, small: 25000)) {
                    OutlookAmountLabel(title: loans.count == 1 ? "Prepay " + loans[0].name + " now" : "Prepay it now", value: prepay, words: true)
                }
            }
            Stepper(value: $buy, in: 0...50000000, step: OutlookKit.step(buy, small: 50000)) {
                OutlookAmountLabel(title: "A big purchase", value: buy, words: true)
            }
            if buy > 0 {
                Picker("When", selection: $buyYear) {
                    ForEach(1...5, id: \.self) { y in Text(y == 1 ? "In the next 12 months" : "In year \(y)").tag(y) }
                }
                if let b = borrow {
                    Toggle(isOn: $onLoan) {
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Part of it on a loan")
                            Text(Fmt.words(Swift.min(b.amount, buy)) + " at " + Fmt.trim(b.rate, 2) + "% over " + OutlookKit.months(b.months))
                                .font(.caption).foregroundStyle(.secondary).privacySensitive()
                        }
                    }
                }
            }
            VStack(alignment: .leading, spacing: 6) {
                HStack {
                    Text("Income")
                    Spacer(minLength: 6)
                    Text(income == 0 ? "As now" : (income > 0 ? "Up " : "Down ") + Fmt.trim(abs(income), 0) + "%")
                        .foregroundStyle(.secondary).monospacedDigit()
                }
                Slider(value: $income, in: -50...50, step: 5) { Text("Income") } minimumValueLabel: {
                    Text("−50%").font(.caption2).foregroundStyle(.secondary)
                } maximumValueLabel: {
                    Text("+50%").font(.caption2).foregroundStyle(.secondary)
                }
            }
            if changing {
                Button("Back to today’s pace", role: .destructive) {
                    withAnimation(Motion.open) { sip = 0; prepay = 0; buy = 0; income = 0 }
                }
            }
        } header: {
            Text("What if")
        } footer: {
            Text("The dashed line. More into SIPs, a prepayment or a purchase is paid from what’s left each month, then savings, then investments.")
        }
    }
    var maxPrepay: Double {
        let l: Loan? = loans.first(where: { $0.name == prepayLoan }) ?? loans.max(by: { (store.loanBalance($0) ?? 0) < (store.loanBalance($1) ?? 0) })
        let bal: Double = l.flatMap { store.loanBalance($0) } ?? 0
        return Swift.max(25000, (bal / 25000).rounded(.up) * 25000)
    }

    // what it assumes, and what happens on the way

    func assumptionsSection(_ p: WorthOutlook) -> some View {
        Section {
            Button { showAssume = true } label: {
                HStack {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Growth rates and monthly figures").foregroundStyle(Color.primary)
                        Text(OutlookKit.rateLine(p.assumptions)).font(.caption).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                    }
                    Spacer(minLength: 6)
                    Image(systemName: "chevron.right").font(.footnote.weight(.semibold)).foregroundStyle(.tertiary)
                }
            }
            ForEach(p.notes, id: \.self) { n in
                Text(n).font(.footnote).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true).privacySensitive()
            }
        } header: {
            Text("What it assumes")
        }
    }

    @ViewBuilder func eventsSection(_ p: WorthOutlook) -> some View {
        if !p.events.isEmpty {
            Section("On the way") {
                ForEach(Array(p.events.enumerated()), id: \.offset) { _, e in
                    HStack(alignment: .firstTextBaseline, spacing: 12) {
                        Text(Day.fmt(e.date, "MMM yyyy")).font(.footnote.weight(.semibold)).foregroundStyle(.secondary).frame(width: dateColumn, alignment: .leading)
                        Text(e.text).font(.footnote).fixedSize(horizontal: false, vertical: true).privacySensitive()
                    }
                }
            }
        }
    }

    // working it out

    func optsJSON() -> String {
        var s: [String: Any] = [:]
        if sip > 0 { s["sip"] = sip }
        if prepay > 0, !prepayLoan.isEmpty { s["prepay"] = ["amount": prepay, "loan": prepayLoan] as [String: Any] }
        if buy > 0 {
            var b: [String: Any] = ["amount": buy, "year": buyYear]
            if onLoan, let l = borrow { b["loan"] = ["amount": l.amount, "rate": l.rate, "months": l.months] as [String: Any] }
            s["purchase"] = b
        }
        if income != 0 { s["income"] = income }
        let opts: [String: Any] = ["scenario": s, "assume": assume]
        return JSONText.object(opts)
    }
    func recompute() async {
        // a stepper held down changes it many times a second: wait for it to settle (not for the first drawing)
        if p != nil {
            try? await Task.sleep(for: .milliseconds(160))
            if Task.isCancelled { return }
        }
        let ctx: String = DecideEngine.context(store, start: true)
        let opts: String = optsJSON()
        guard let fresh = await DecideEngine.project(ctx: ctx, opts: opts), !Task.isCancelled else { return }
        withAnimation(Motion.open) { p = fresh }
    }
}

/// a what-if row's words and amount
struct OutlookAmountLabel: View {
    let title: String
    let value: Double
    /// ₹2.5L rather than ₹2,50,000
    let words: Bool
    var body: some View {
        HStack {
            Text(title)
            Spacer(minLength: 6)
            Text(value > 0 ? (words ? Fmt.words(value) : Fmt.rupees(value)) : "None")
                .foregroundStyle(value > 0 ? Color.primary : Color.secondary)
                .monospacedDigit()
                .contentTransition(.numericText(value: value))
                .privacySensitive()
        }
    }
}

/// five years on, at this pace: the figure, in today's money, and with the change
struct OutlookHead: View {
    let p: WorthOutlook
    let end: OutlookPoint
    /// the big figure, sized with the text
    @ScaledMetric(relativeTo: .largeTitle) private var big: CGFloat = 40
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            let when: String = "By " + Day.fmt(end.date, "MMMM yyyy")
            Text(p.flow.blind ? when + ", from what you own today" : when + ", at this pace").font(.subheadline.weight(.medium)).foregroundStyle(.secondary)
            Text(OutlookKit.signed(end.worth))
                .font(.system(size: big, weight: .bold, design: .rounded))
                .minimumScaleFactor(0.6)
                .lineLimit(1)
                .contentTransition(.numericText(value: end.worth))
                .privacySensitive()
            Text("About " + OutlookKit.signed(p.real) + " in today’s money").font(.subheadline).foregroundStyle(.secondary).privacySensitive()
            if !p.scenarioLine.isEmpty {
                Text(p.scenarioLine)
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(Color.orange)
                    .fixedSize(horizontal: false, vertical: true)
                    .padding(.top, 4)
                    .privacySensitive()
            }
            if p.flow.blind {
                Label("kosh sees your spending but not your salary, so it can’t tell what’s left each month. Add your take-home under What it assumes.", systemImage: "info.circle.fill")
                    .font(.footnote.weight(.medium))
                    .foregroundStyle(Color.kosh)
                    .fixedSize(horizontal: false, vertical: true)
                    .padding(.top, 2)
            }
            if !p.dry.isEmpty || !p.dryAlt.isEmpty {
                Label(!p.dry.isEmpty ? "At this pace the bank runs short by " + Day.fmt(p.dry, "MMM yyyy") : "With the change the bank runs short by " + Day.fmt(p.dryAlt, "MMM yyyy"),
                      systemImage: "exclamationmark.triangle.fill")
                    .font(.footnote.weight(.medium))
                    .foregroundStyle(Color.orange)
                    .padding(.top, 2)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

/// the two lines' key
struct OutlookKey: View {
    var body: some View {
        HStack(spacing: 16) {
            HStack(spacing: 6) {
                Capsule().fill(Color.kosh).frame(width: 18, height: 3)
                Text("At this pace")
            }
            HStack(spacing: 6) {
                Path { path in
                    path.move(to: CGPoint(x: 0, y: 1.5))
                    path.addLine(to: CGPoint(x: 18, y: 1.5))
                }
                .stroke(Color.orange, style: StrokeStyle(lineWidth: 2.5, lineCap: .round, dash: [4, 4]))
                .frame(width: 18, height: 3)
                Text("What if")
            }
        }
        .font(.caption)
        .foregroundStyle(.secondary)
    }
}

/// today's pace, solid over its own shade; the change, dashed; drag along it to read a year
struct OutlookChart: View {
    let p: WorthOutlook
    @Binding var picked: Double?
    /// amounts hidden: the line keeps its shape, the scale goes
    let hidden: Bool
    var body: some View {
        let all: [OutlookPoint] = p.base + p.scen
        let lo: Double = Swift.min(0, all.map(\.worth).min() ?? 0)
        let last: Int = Swift.max(1, p.years)
        let ticks: [Double] = (0...last).map { Double($0) }
        let chosen: Int? = picked.map { Swift.min(p.years, Swift.max(0, Int($0.rounded()))) }
        Chart {
            ForEach(p.base) { pt in
                AreaMark(x: .value("Year", Double(pt.y)), yStart: .value("Floor", lo), yEnd: .value("Net worth", pt.worth))
                    .foregroundStyle(LinearGradient(colors: [Color.kosh.opacity(0.22), Color.kosh.opacity(0.02)], startPoint: .top, endPoint: .bottom))
                    .interpolationMethod(.monotone)
                LineMark(x: .value("Year", Double(pt.y)), y: .value("Net worth", pt.worth), series: .value("Line", "At this pace"))
                    .foregroundStyle(Color.kosh)
                    .lineStyle(StrokeStyle(lineWidth: 3, lineCap: .round, lineJoin: .round))
                    .interpolationMethod(.monotone)
            }
            ForEach(p.scen) { pt in
                LineMark(x: .value("Year", Double(pt.y)), y: .value("Net worth", pt.worth), series: .value("Line", "What if"))
                    .foregroundStyle(Color.orange)
                    .lineStyle(StrokeStyle(lineWidth: 2.5, lineCap: .round, lineJoin: .round, dash: [6, 5]))
                    .interpolationMethod(.monotone)
            }
            if let y = chosen {
                RuleMark(x: .value("Year", Double(y)))
                    .foregroundStyle(Color.secondary.opacity(0.35))
                if let b = p.base.first(where: { $0.y == y }) {
                    PointMark(x: .value("Year", Double(y)), y: .value("Net worth", b.worth))
                        .foregroundStyle(Color.kosh)
                        .symbolSize(60)
                }
                if let s = p.scen.first(where: { $0.y == y }) {
                    PointMark(x: .value("Year", Double(y)), y: .value("Net worth", s.worth))
                        .foregroundStyle(Color.orange)
                        .symbolSize(50)
                }
            }
        }
        .chartXScale(domain: 0...Double(last))
        .chartXAxis {
            AxisMarks(values: ticks) { v in
                AxisGridLine().foregroundStyle(Color.primary.opacity(0.06))
                AxisValueLabel {
                    if let x = v.as(Double.self) { Text(yearLabel(Int(x.rounded()))) }
                }
            }
        }
        .chartYAxis {
            AxisMarks(position: .trailing, values: .automatic(desiredCount: 4)) { v in
                AxisGridLine().foregroundStyle(Color.primary.opacity(0.06))
                AxisValueLabel {
                    if let w = v.as(Double.self) { Text(hidden ? " " : OutlookKit.signed(w)) }
                }
            }
        }
        .chartXSelection(value: $picked)
        .sensoryFeedback(.selection, trigger: chosen)
        // with amounts hidden VoiceOver reads no values off the line, only what it is; shown, where each line runs to
        .modifier(OutlookChartPrivacy(hidden: hidden, years: p.years, spoken: spoken))
    }
    /// what VoiceOver says of the lines while amounts show: where each runs to
    var spoken: String {
        let span: String = "Net worth over the next " + String(p.years) + (p.years == 1 ? " year" : " years")
        var parts: [String] = [span]
        if let b = p.base.last { parts.append(OutlookKit.signed(b.worth) + " at this pace") }
        if let s = p.scen.last { parts.append(OutlookKit.signed(s.worth) + " with the change") }
        return parts.joined(separator: ", ")
    }
    /// "Now", then "’27", "’28"…
    func yearLabel(_ y: Int) -> String {
        if y == 0 { return "Now" }
        guard let pt = p.base.first(where: { $0.y == y }) else { return "\(y)" }
        return "’" + String(pt.date.prefix(4).suffix(2))
    }
}

/// amounts hidden: the chart is one element that says what it shows, never its values
struct OutlookChartPrivacy: ViewModifier {
    let hidden: Bool
    let years: Int
    /// shown: the summary VoiceOver gives of the lines (OutlookChart.spoken)
    var spoken: String = ""
    @ViewBuilder func body(content: Content) -> some View {
        if hidden {
            content
                .accessibilityElement(children: .ignore)
                .accessibilityLabel("Net worth over the next \(years) years, at this pace and with the change. Amounts are hidden.")
        } else if !spoken.isEmpty {
            content
                .accessibilityElement(children: .ignore)
                .accessibilityLabel(spoken)
        } else {
            content
        }
    }
}

/// a year read off the line: what net worth is made of then
struct OutlookYear: View {
    let pt: OutlookPoint
    let alt: OutlookPoint?
    var body: some View {
        VStack(alignment: .leading, spacing: 7) {
            HStack(alignment: .firstTextBaseline) {
                Text(pt.y == 0 ? "Today" : Day.fmt(pt.date, "MMMM yyyy")).font(.subheadline.weight(.semibold))
                Spacer(minLength: 6)
                Text(OutlookKit.signed(pt.worth)).font(.subheadline.weight(.bold)).monospacedDigit().privacySensitive()
            }
            if let a = alt, pt.y > 0 {
                HStack(alignment: .firstTextBaseline) {
                    Text("What if").font(.footnote.weight(.medium)).foregroundStyle(Color.orange)
                    Spacer(minLength: 6)
                    Text(OutlookKit.signed(a.worth)).font(.footnote.weight(.semibold)).foregroundStyle(Color.orange).monospacedDigit().privacySensitive()
                }
            }
            part("In the bank and cash", pt.parts.cash)
            part("Shares and funds", pt.parts.invest)
            part("Deposits, bonds and retirement", pt.parts.safe)
            part("Gold, insurance savings, property", pt.parts.other)
            part("Loans", -pt.parts.loans)
        }
        .accessibilityElement(children: .combine)
    }
    @ViewBuilder func part(_ label: String, _ v: Double) -> some View {
        if abs(v) >= 0.5 {
            HStack(alignment: .firstTextBaseline) {
                Text(label).font(.footnote).foregroundStyle(.secondary)
                Spacer(minLength: 6)
                Text(OutlookKit.signed(v)).font(.footnote).monospacedDigit().foregroundStyle(.secondary).privacySensitive()
            }
        }
    }
}

/// the growth rates and the monthly figures, each with a stepper; kosh's own figures back in one tap
struct OutlookAssumptions: View {
    let knobs: [DecisionKnob]
    @Binding var assume: [String: Double]
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            List {
                Section {
                    ForEach(knobs.filter { $0.unit == "%" }) { k in DecisionKnobRow(knob: k, value: bind(k)) }
                } header: {
                    Text("Growth, a year")
                } footer: {
                    Text("Before tax. Each FD earns its own rate until it matures, then the rate for bonds and debt funds.")
                }
                Section {
                    ForEach(knobs.filter { $0.unit == "₹" }) { k in DecisionKnobRow(knob: k, value: bind(k)) }
                } header: {
                    Text("Each month")
                } footer: {
                    Text("From your own months. A change here lasts while this page is open; the growth rates stay as you set them.")
                }
                if !assume.isEmpty {
                    Section {
                        Button("Use kosh’s figures") { withAnimation(Motion.open) { assume = [:] } }
                    }
                }
            }
            .listStyle(.insetGrouped)
            .navigationTitle("What it assumes")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } } }
        }
    }
    func bind(_ k: DecisionKnob) -> Binding<Double> {
        Binding(get: { assume[k.key] ?? k.value }, set: { assume[k.key] = $0 })
    }
}
