import SwiftUI
import UIKit
import Observation

// MARK: - The store: the running month, the ledger, its payees to name, search and the month's chart
// (split out of Store.swift, 30 Oct 2026; the stored state stays in the class there)

extension Store {
    // the running month
    /// the figures every screen shows, worked out in one screen-free place (Figures.swift: engine-test/screens.js
    /// compiles it with the phone's own Snapshot types and ties each figure to the same money elsewhere). The month's
    /// payments are handed over only when a month has no engine figure, so a figure never watches the ledger it
    /// doesn't read
    var figures: Figures { Figures(snap: snap.reading(Self.figuresReads), tx: [], added: added, cashInHand: cashInHand, typedLoans: typedLoans) }
    /// the parts of the build Figures.swift reads (a screen showing a figure redraws when one of these changes, not on
    /// every build): keep in step with the `snap.` reads there
    static let figuresReads: [PartialKeyPath<Snapshot>] = [
        \Snapshot.accounts, \Snapshot.agenda, \Snapshot.cm, \Snapshot.fc, \Snapshot.hold, \Snapshot.loans, \Snapshot.months,
        \Snapshot.prop, \Snapshot.refunds, \Snapshot.today, \Snapshot.worth,
    ]
    /// a loan's balance you typed last, by the loan's id
    var typedLoans: [String: Double] {
        var out: [String: Double] = [:]
        for l in snap.loans { if let v = latest("loan:" + l.id)?.amount { out[l.id] = v } }
        return out
    }
    var spentNow: Double { figures.spentNow }
    var likelyNow: Double { figures.likelyNow }
    /// what's left of the month's budget after what's spent and what's still to go out
    var leftNow: Double { figures.leftNow }
    var current: MonthInfo? { snap.months.first { $0.live } }
    var monthName: String { current?.name ?? "This month" }
    /// what a month's spending comes to for whoever is chosen: the one figure every screen shows
    func total(of mo: MonthInfo) -> Double { figures.total(of: mo, who, rows: { self.txs(in: mo.m) }) }
    func spent(_ m: String) -> Double { figures.spent(m, who, rows: { self.txs(in: m) }) }
    /// one kind of a month's spending for one person (nil for the family, whose figures are the month's own)
    func spentCats(_ mo: MonthInfo) -> [MonthInfo.WhoCat]? { figures.spentCats(mo, who) }
    /// every kind of a month's spending for whoever is shown, with money back taken off as the month's own figure takes
    /// it (Figures.catsSpent)
    func catsSpent(_ mo: MonthInfo) -> [String: Double] { figures.catsSpent(mo, who, rows: { self.txs(in: mo.m) }) }
    func month(_ m: String) -> MonthInfo? { snap.months.first { $0.m == m } }

    // ledger
    /// a payment by its id: looked up in an index made once a build, not by going through every payment (a row on the
    /// screen asks this for its refund and its chapter, a hundred rows a redraw)
    func txn(_ id: String) -> Txn? {
        if let e = edits[id] { return e }
        if txIndexMemo.gen != txGen {
            var m: [String: Int] = [:]
            m.reserveCapacity(tx.count)
            for (i, t) in tx.enumerated() where m[t.id] == nil { m[t.id] = i }
            txIndexMemo = (txGen, m)
        }
        guard let i = txIndexMemo.map[id], i < tx.count, tx[i].id == id else { return tx.first { $0.id == id } }
        return tx[i]
    }
    var untagged: [Txn] { tx.filter { $0.u } }

    /// the payments that need a name, a payee at a time (by its UPI ID, or its name), the payees that cost the most
    /// first: name one and every payment to it is named
    var untaggedPayees: [PayeeGroup] {
        // (worked out once a build: Transactions asks for it more than once a redraw)
        if payeesMemo.gen == txGen { return payeesMemo.groups }
        let made: [PayeeGroup] = untaggedPayeesNow
        payeesMemo = (txGen, made)
        return made
    }
    private var untaggedPayeesNow: [PayeeGroup] {
        var by: [String: [Txn]] = [:]
        var order: [String] = []
        for t in tx where t.u && t.partOf == nil {
            let k: String = (t.lk ?? "").isEmpty ? "n:" + t.m.lowercased() : (t.lk ?? "")
            if by[k] == nil { order.append(k) }
            by[k, default: []].append(t)
        }
        return order.compactMap { k -> PayeeGroup? in
            guard let rows = by[k]?.sorted(by: { $0.d > $1.d }), let top = rows.first else { return nil }
            return PayeeGroup(id: k, name: top.m, rows: rows, total: rows.reduce(0) { $0 + $1.a },
                              first: rows.last?.d ?? top.d, vpa: rows.compactMap(\.vpa).first, person: PayeeGroup.looksLikePerson(top.m, vpa: rows.compactMap(\.vpa).first))
        }
        .sorted { $0.total > $1.total }
    }

    /// this week's few to name: of the payees kosh couldn't place, the five with the most money in the last 30 days
    /// (₹200 or more between them). Never the whole backlog: an old or small payee is never asked about and stays
    /// "not yet named"; one name files every payment to that payee, past and future.
    var weeklyToName: [PayeeGroup] {
        if weeklyMemo.gen == txGen && weeklyMemo.day == snap.today { return weeklyMemo.groups }
        let made: [PayeeGroup] = weeklyToNameNow
        weeklyMemo = (txGen, snap.today, made)
        return made
    }
    private var weeklyToNameNow: [PayeeGroup] {
        let since: String = Day.add(snap.today, -30)
        func recent(_ g: PayeeGroup) -> Double { g.rows.reduce(0) { $1.d >= since ? $0 + $1.a : $0 } }
        let fresh: [(PayeeGroup, Double)] = untaggedPayees.map { ($0, recent($0)) }.filter { $0.1 >= 200 }
        return Array(fresh.sorted { $0.1 > $1.1 }.prefix(5).map(\.0))
    }

    /// file every payment to a payee at once (one save, one rebuild); kosh learns the payee from them
    func fileGroup(_ g: PayeeGroup, _ c: String, _ s: String) {
        let ids: Set<String> = Set(g.rows.map(\.id))
        for i in tx.indices where ids.contains(tx[i].id) {
            tx[i].c = c; tx[i].s = s; tx[i].u = false; tx[i].g = false; tx[i].sym = symbol(c)
        }
        live?.overrideMany(Array(ids)) { o in o.c = c; o.s = s; o.by = nil; o.only = Self.without(o.only, "c") }
        live?.rebuildSoon()
    }

    /// what a payee's payments most likely were: what you filed similar names as, then what its shape says (the same
    /// sum to a person every month is help or rent; a person otherwise is family, a gift or your own account; a shop by
    /// how much it usually takes)
    func suggestions(for g: PayeeGroup) -> [Suggestion] {
        var out: [Suggestion] = g.person ? [] : suggestions(for: g.rows[0]).filter { !["Snacks", "Fruits & veggies", "Pharmacy"].contains($0.s) }
        func add(_ c: String, _ s: String, _ label: String? = nil) {
            if out.contains(where: { $0.c == c && $0.s == s }) || out.count >= 3 { return }
            out.append(Suggestion(label: label ?? (s.isEmpty ? c : s), c: c, s: s, card: "", merchant: "", sym: symbol(c)))
        }
        let amounts: [Double] = g.rows.map(\.a)
        let avg: Double = amounts.reduce(0, +) / Double(max(1, amounts.count))
        let months: Int = Set(g.rows.map { String($0.d.prefix(7)) }).count
        let steady: Bool = g.rows.count >= 2 && months >= 2 && amounts.allSatisfy { abs($0 - avg) <= avg * 0.2 }
        if g.person {
            if steady && avg >= 8000 { add("Home", "Rent") }
            if steady && avg < 25000 { add("Home", "Domestic help") }
            add("Family Support", "Relatives", "Family")
            add("People", "Friends", "A friend")
            add("Gift", "", "A gift")
            add("Self Transfer", "", "My own account")
        } else if avg < 300 {
            add("Food & Drinks", "Tea & coffee"); add("Groceries", "Kirana"); add("Transport", "Auto")
        } else if avg < 2500 {
            add("Groceries", "Kirana"); add("Food & Drinks", "Restaurants"); add("Medical", "Pharmacy")
        } else {
            add("Shopping", "Online"); add("Home", "Repairs"); add("Services", "Professional fees")
        }
        return out
    }
    /// a month's payments for whoever is picked: each month's list made once a build (the month tiles ask for every month)
    func txs(in m: String) -> [Txn] {
        let w: String = who.id
        if monthMemo.gen != txGen || monthMemo.who != w {
            var by: [String: [Txn]] = [:]
            for t in tx where who.owns(t.o) { by[String(t.d.prefix(7)), default: []].append(t) }
            monthMemo = (txGen, w, by)
        }
        if m.count == 7 { return monthMemo.byMonth[m] ?? [] }
        return tx.filter { $0.d.hasPrefix(m) && who.owns($0.o) }
    }
    func spendCount(_ m: String) -> Int { txs(in: m).filter { $0.sp }.count }
    /// the spending payments of some months for whoever is shown, read month by month from the lists above rather
    /// than by going through every payment kosh has (a screen asks this on each redraw)
    func spends<S: Sequence>(in months: S) -> [Txn] where S.Element == String {
        var out: [Txn] = []
        for m in months { for t in txs(in: m) where t.sp { out.append(t) } }
        return out
    }
    func isMove(_ t: Txn) -> Bool { t.k == "move" || t.k == "cardpay" || t.k == "invest" }

    func catColor(_ c: String) -> Color { Color(hex: snap.cats[c]?.color ?? "#8E8E93") }
    func color(for t: Txn) -> Color {
        if t.u { return .orange }
        if isMove(t) { return Color(white: 0.62) }
        return catColor(t.c)
    }
    func catLine(_ t: Txn) -> String { t.s.isEmpty || t.s == "Other" ? t.c : t.c + " · " + t.s }
    func symbol(_ c: String) -> String { snap.cats[c]?.symbol ?? "square.grid.2x2.fill" }

    func groups(month m: String, filter: LedgerFilter, paid: String = "") -> [DayGroup] {
        let key: String = who.id + "|" + m + "|" + filter.rawValue + "|" + paid
        if groupsMemo.gen != txGen { groupsMemo = (txGen, [:]) }
        if let known = groupsMemo.by[key] { return known }
        let made: [DayGroup] = makeGroups(month: m, filter: filter, paid: paid)
        groupsMemo.by[key] = made
        return made
    }
    private func makeGroups(month m: String, filter: LedgerFilter, paid: String) -> [DayGroup] {
        let rows = txs(in: m).filter { t in
            if !PaidWith.matches(t, paid) { return false }
            switch filter {
            case .all: return true
            case .moneyIn: return t.k == "in"
            case .moves: return isMove(t)
            case .me: return t.k == "out" && t.f == "me"
            case .mom: return t.k == "out" && t.f == "mom"
            case .home: return t.k == "out" && t.f == "home"
            case .work: return t.k == "out" && t.f == "work"
            case .chapters: return trip(t.tr) != nil
            }
        }
        var order: [String] = []
        var byDay: [String: [Txn]] = [:]
        for t in rows {
            if byDay[t.d] == nil { order.append(t.d) }
            byDay[t.d, default: []].append(t)
        }
        return order.sorted(by: >).map { (d: String) -> DayGroup in
            let items = byDay[d] ?? []
            return DayGroup(day: d, items: items.filter { $0.wf == nil }, total: items.filter { $0.sp }.reduce(0) { $0 + $1.a })
        }
    }

    func moneyIn(_ m: String) -> Double { Figures.moneyIn(txs(in: m)) }

    /// every word found in the payment: its payee, category, the card or account, your note, and how it was paid
    /// ("zomato money", "wallet", "upi hdfc", "card 1234")
    /// every payment whose words have all of what's typed: a shop, a person, a note, a card, a wallet, a UPI ID; or
    /// an amount ("22476", "22,476", "₹22,476"), a range ("5000-10000") or a bound (">5000", "<500")
    func search(_ q: String) -> [Txn] {
        let toks = q.lowercased().replacingOccurrences(of: "₹", with: " ").replacingOccurrences(of: "rs.", with: " ")
            .split(separator: " ").map(String.init).filter { !$0.isEmpty }
        if toks.isEmpty { return [] }
        return tx.filter { t in
            let way = PayWay.word(t.md ?? "") + " " + (t.bk ?? "") + " " + (t.l4 ?? "")
            let hay = (t.m + " " + t.c + " " + t.s + " " + t.card + " " + t.n + " " + way + " " + (t.vpa ?? "")).lowercased()
            return toks.allSatisfy { tok in hay.contains(tok) || Self.amountFits(tok, t) }
        }
    }
    /// "22476", "22,476", "22476.50": that amount (as charged, or your share); "5000-10000", ">5000", "<500"
    static func amountFits(_ tok: String, _ t: Txn) -> Bool {
        let s = tok.replacingOccurrences(of: ",", with: "")
        let amounts: [Double] = [t.a, t.full ?? t.a]
        if s.hasPrefix(">"), let v = Double(s.dropFirst()) { return amounts.contains { $0 > v } }
        if s.hasPrefix("<"), let v = Double(s.dropFirst()) { return amounts.contains { $0 < v } }
        let parts = s.split(separator: "-")
        if parts.count == 2, let lo = Double(parts[0]), let hi = Double(parts[1]), lo <= hi { return amounts.contains { $0 >= lo && $0 <= hi } }
        guard let v = Double(s), v >= 1 else { return false }
        return amounts.contains { abs($0 - v) < 1 }
    }

    /// the wallets and app balances payments were made from, the most used first ("Zomato Money", "Amazon Pay")
    var walletsUsed: [String] {
        // (once a change to the payments, for whoever is shown: walletsMemo)
        if walletsMemo.gen == txGen && walletsMemo.who == who.id { return walletsMemo.names }
        let made: [String] = walletsUsedNow
        walletsMemo = (txGen, who.id, made)
        return made
    }
    private var walletsUsedNow: [String] {
        var count: [String: Int] = [:], shown: [String: String] = [:]
        for t in tx where PaidWith.key(t) == "wallet" && who.owns(t.o) {
            let name = PaidWith.walletName(t), k = PaidWith.walletKey(name)
            if k.isEmpty { continue }
            count[k, default: 0] += 1
            if shown[k] == nil || name.count < shown[k]!.count { shown[k] = name }
        }
        return count.sorted { $0.value != $1.value ? $0.value > $1.value : $0.key < $1.key }.compactMap { shown[$0.key] }
    }

    // the month line
    func actualPoints(_ mo: MonthInfo) -> [DayV] {
        let arr = mo.live ? snap.fc.actual : mo.cum
        return arr.enumerated().map { i, v in DayV(day: i + 1, v: v + (mo.live && i == arr.count - 1 ? added : 0)) }
    }
    func prevPoints(_ mo: MonthInfo) -> [DayV] {
        guard let p = mo.prev, let pm = month(p) else { return [] }
        return pm.cum.prefix(mo.days).enumerated().map { DayV(day: $0.offset + 1, v: $0.element) }
    }
    /// a month's day-by-day line for whoever is shown: the household's (`actualPoints`) for Family, else the person's own
    /// from the engine (their spending, less the money back taken off theirs, so it ends on their month); a person who
    /// spent nothing that month is a flat line at nothing. nil: a build from before the engine drew people's lines, so
    /// there is no line of theirs to draw (never the household's in their name)
    func linePoints(_ mo: MonthInfo) -> [DayV]? {
        if who == .family { return actualPoints(mo) }
        guard let w = mo.who else { return nil }
        let n: Int = mo.live ? snap.fc.d : mo.days
        guard let mine = w.first(where: { $0.o == who.id }) else { return (0..<max(0, n)).map { DayV(day: $0 + 1, v: 0) } }
        guard let cum = mine.cum else { return nil }
        return cum.enumerated().map { DayV(day: $0.offset + 1, v: $0.element) }
    }
    /// last month's line beside a month's, for whoever is shown (`prevPoints` for Family)
    func prevLinePoints(_ mo: MonthInfo) -> [DayV] {
        if who == .family { return prevPoints(mo) }
        guard let p = mo.prev, let pm = month(p) else { return [] }
        return Array((linePoints(pm) ?? []).prefix(mo.days))
    }
    func forecastPoints() -> [DayV] {
        let F = snap.fc
        var out: [DayV] = []
        for i in 0..<F.forecast.count where i + 1 >= F.d {
            if let v = F.forecast[i] { out.append(DayV(day: i + 1, v: v + added)) }
        }
        return out
    }
    func bandPoints() -> [DayBand] {
        let F = snap.fc
        var out: [DayBand] = []
        for i in 0..<min(F.lo.count, F.hi.count) where i + 1 >= F.d {
            if let lo = F.lo[i], let hi = F.hi[i] { out.append(DayBand(day: i + 1, lo: lo + added, hi: hi + added)) }
        }
        return out
    }
    func value(_ mo: MonthInfo, _ day: Int) -> Double {
        let act = actualPoints(mo)
        if day <= act.count, day >= 1 { return act[day - 1].v }
        if mo.live, let f = forecastPoints().first(where: { $0.day == day }) { return f.v }
        return act.last?.v ?? 0
    }
    func chartMax(_ mo: MonthInfo) -> Double {
        var m = actualPoints(mo).map(\.v).max() ?? 1
        m = max(m, prevPoints(mo).map(\.v).max() ?? 0)
        if mo.live {
            m = max(m, bandPoints().map(\.hi).max() ?? 0, snap.fc.budget)
        }
        return max(1, m * 1.12)
    }
}
