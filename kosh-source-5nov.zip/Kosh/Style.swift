import SwiftUI

// MARK: - Colour

extension Color {
    // Color(hex:) lives in Shared/KoshLook.swift, one for the app and the widgets
    /// kosh blue (or the accent picked in Settings › Appearance): what you can touch, and what kosh predicts.
    /// Words, icons and lines: deep enough on white, lifted by night. Read from Look, so views redraw when it changes.
    static var kosh: Color { Look.shared.accent.ink }
    /// the accent as a fill under words (a button, the selected pill, an avatar); write on it in onKosh
    static var koshFill: Color { Look.shared.accent.fill }
    /// words on koshFill: white, or black on Graphite's light grey by night
    static var onKosh: Color { Look.shared.accent.onFill }
    /// the second accent, the colour kosh's gradients run into: a clear sky blue for kosh blue (no purples: they read as loud)
    static var sky: Color { Look.shared.accent.sky }
    /// Apple's light grey surface on a white page (#1C1C1E on black by night)
    static let surface = Color(uiColor: .secondarySystemBackground)
    static let hairline = Color(light: Color.black.opacity(0.08), dark: Color.white.opacity(0.12))
    /// Apple's grey for rules, quiet fills and outlines (#3C3C43 by day), and its light twin by night; used with an opacity
    static let rule = Color(light: "#3C3C43", dark: "#EBEBF5")
    /// white laid over a coloured wash (a chip, a tile on a hero card); by night a faint lift of white instead
    static func lift(_ o: Double) -> Color { Color(light: Color.white.opacity(o), dark: Color.white.opacity(min(0.14, o * 0.14))) }
    /// a tile that sits inside a grey card: white by day, a step up from the card by night
    static let raised = Color(uiColor: .tertiarySystemBackground)
}

// MARK: - Numbers, the way the family reads them

enum Fmt {
    static let grouping: NumberFormatter = {
        let f = NumberFormatter()
        f.locale = Locale(identifier: "en_IN")
        f.numberStyle = .decimal
        f.maximumFractionDigits = 0
        return f
    }()
    static func inr(_ v: Double) -> String { grouping.string(from: NSNumber(value: abs(v).rounded())) ?? "0" }
    static func rupees(_ v: Double) -> String { "₹" + inr(v) }
    static func trim(_ x: Double, _ dp: Int) -> String {
        var s = String(format: "%.\(dp)f", x)
        while s.contains(".") && (s.hasSuffix("0") || s.hasSuffix(".")) { s.removeLast() }
        return s
    }
    /// lakh as L and crore as CR, straight after the figure as k is: ₹44.9L, ₹1.58CR
    static func words(_ v: Double) -> String {
        let a = abs(v)
        // no space, as with k: ₹12L, ₹1.05CR. A figure that rounds up into the next step is written in it: ₹99,99,999
        // is ₹1CR, never "₹100L"; ₹99,999.60 is ₹1L (engine-test/screens.js)
        if a >= 1e7 || (a >= 1e6 && (a / 1e4).rounded() >= 1000) { return "₹" + trim(a / 1e7, 2) + "CR" }
        if a >= 1e5 || a.rounded() >= 1e5 { return "₹" + trim(a / 1e5, a >= 1e6 ? 1 : 2) + "L" }
        return rupees(a)
    }
    /// a figure that can be below nothing, said so: net worth when the loans are more than what's owned is "−₹18.5L",
    /// never "₹18.5L" (words, short and rupees give the size alone; their callers add "+" or "−" where it means a way)
    static func signedWords(_ v: Double) -> String { (v <= -0.5 ? "−" : "") + words(v) }
    static func short(_ v: Double) -> String {
        let a = abs(v)
        // (₹99,960 is never "₹100k": a figure that rounds to a hundred thousands is written whole)
        if a >= 1e5 || (a / 100).rounded() >= 1000 { return words(a) }
        if a >= 1000 { return "₹" + trim(a / 1000, 1) + "k" }
        return rupees(a)
    }
    static func roundish(_ v: Double) -> Double {
        let a = abs(v)
        if a >= 1e5 { return a }
        if a >= 2e4 { return (a / 1000).rounded() * 1000 }
        if a >= 2000 { return (a / 100).rounded() * 100 }
        return (a / 10).rounded() * 10
    }
    static func pct(_ x: Double) -> String { String(Int(safe: (x * 100).rounded())) + "%" }
}

/// one piece of a strip split by share: its part of the room left once the gaps are taken, never thinner than `least`;
/// `grown` false draws it nearly nothing, for the strip to grow from
func shareWidth(_ room: CGFloat, gaps: Int, gap: CGFloat, part: Double, of whole: Double, least: CGFloat, grown: Bool = true) -> CGFloat {
    let free: CGFloat = room - CGFloat(gaps) * gap
    let share: CGFloat = CGFloat(part / whole)
    let scale: CGFloat = grown ? 1 : 0.02
    return max(least, free * share * scale)
}

/// "1st", "2nd", "11th", "23rd": a day of the month as it is said
func ordinal(_ n: Int) -> String {
    let tens = n % 100
    if tens >= 11 && tens <= 13 { return "\(n)th" }
    switch n % 10 {
    case 1: return "\(n)st"
    case 2: return "\(n)nd"
    case 3: return "\(n)rd"
    default: return "\(n)th"
    }
}

enum Words {
    static let small = ["no", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve"]
    static func number(_ n: Int) -> String { n >= 0 && n < small.count ? small[n] : String(n) }
    static func cap(_ s: String) -> String { s.prefix(1).uppercased() + s.dropFirst() }
    /// "a", "a and b", "a, b and c"
    static func list(_ items: [String]) -> String {
        guard items.count > 1 else { return items.first ?? "" }
        return items.dropLast().joined(separator: ", ") + " and " + (items.last ?? "")
    }
}

// MARK: - Days (kosh dates are yyyy-MM-dd, India time)

enum Day {
    static let zone = TimeZone(identifier: "Asia/Kolkata") ?? .current
    static let parser: DateFormatter = {
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX")
        f.timeZone = zone
        f.dateFormat = "yyyy-MM-dd"
        return f
    }()
    static let cal: Calendar = {
        var c = Calendar(identifier: .gregorian)
        c.timeZone = zone
        return c
    }()
    /* (24 Oct 2026) The screens ask for dates thousands of times a redraw: what day is a yyyy-MM-dd, the day after,
       how many days between, which weekday. A DateFormatter answered each one, and a tab switch spent much of its time
       there. India keeps one offset all year (+5:30), so a date is whole days counted from 1 Jan 1970 and these are
       plain arithmetic; a string that isn't a real yyyy-MM-dd still goes to the formatter, as before */
    static let offset: Double = 19_800
    /// a yyyy-MM-dd as whole days since 1 Jan 1970, nil when it isn't a real date
    static func index(_ s: String) -> Int? {
        let u: [UInt8] = Array(s.utf8.prefix(10))
        guard u.count == 10, u[4] == 45, u[7] == 45 else { return nil }
        var y: Int = 0, m: Int = 0, d: Int = 0
        for i in 0..<4 { let c: Int = Int(u[i]) - 48; guard c >= 0 && c <= 9 else { return nil }; y = y * 10 + c }
        for i in 5..<7 { let c: Int = Int(u[i]) - 48; guard c >= 0 && c <= 9 else { return nil }; m = m * 10 + c }
        for i in 8..<10 { let c: Int = Int(u[i]) - 48; guard c >= 0 && c <= 9 else { return nil }; d = d * 10 + c }
        guard m >= 1 && m <= 12 && d >= 1 && d <= monthLength(y, m) else { return nil }
        // (days from the civil date: H. Hinnant's algorithm)
        let yy: Int = m <= 2 ? y - 1 : y
        let era: Int = (yy >= 0 ? yy : yy - 399) / 400
        let yoe: Int = yy - era * 400
        let mp: Int = (m + 9) % 12
        let doy: Int = (153 * mp + 2) / 5 + d - 1
        let doe: Int = yoe * 365 + yoe / 4 - yoe / 100 + doy
        return era * 146_097 + doe - 719_468
    }
    /// whole days since 1 Jan 1970 as a yyyy-MM-dd
    static func iso(index z0: Int) -> String {
        let z: Int = z0 + 719_468
        let era: Int = (z >= 0 ? z : z - 146_096) / 146_097
        let doe: Int = z - era * 146_097
        let yoe: Int = (doe - doe / 1460 + doe / 36_524 - doe / 146_096) / 365
        let doy: Int = doe - (365 * yoe + yoe / 4 - yoe / 100)
        let mp: Int = (5 * doy + 2) / 153
        let d: Int = doy - (153 * mp + 2) / 5 + 1
        let m: Int = mp < 10 ? mp + 3 : mp - 9
        let y: Int = yoe + era * 400 + (m <= 2 ? 1 : 0)
        return String(format: "%04d-%02d-%02d", y, m, d)
    }
    static func monthLength(_ y: Int, _ m: Int) -> Int {
        switch m {
        case 2: return (y % 4 == 0 && y % 100 != 0) || y % 400 == 0 ? 29 : 28
        case 4, 6, 9, 11: return 30
        default: return 31
        }
    }
    static func date(_ s: String) -> Date {
        if let z = index(s) { return Date(timeIntervalSince1970: Double(z) * 86_400 - offset) }
        return parser.date(from: String(s.prefix(10))) ?? Date()
    }
    static func iso(_ d: Date) -> String {
        let t: Double = d.timeIntervalSince1970 + offset
        guard t.isFinite else { return parser.string(from: d) }
        return iso(index: Int(safe: (t / 86_400).rounded(.down)))
    }
    /// one formatter per pattern: making them is slow, reusing them is not; and each answer kept, since the same few
    /// dates are written again on every redraw
    nonisolated(unsafe) private static var formatters: [String: DateFormatter] = [:]
    nonisolated(unsafe) private static var written: [String: String] = [:]
    private static let writing = NSLock()
    static func fmt(_ s: String, _ format: String) -> String {
        let key: String = format + "|" + s
        writing.lock(); defer { writing.unlock() }
        if let w = written[key] { return w }
        let f: DateFormatter
        if let known = formatters[format] { f = known } else {
            f = DateFormatter()
            f.locale = Locale(identifier: "en_GB")
            f.timeZone = zone
            f.dateFormat = format
            formatters[format] = f
        }
        let out: String = f.string(from: date(s))
        if written.count > 20_000 { written.removeAll(keepingCapacity: true) }
        written[key] = out
        return out
    }
    /// whole days from one yyyy-MM-dd to another (negative when b comes first)
    static func between(_ a: String, _ b: String) -> Int {
        if let x = index(a), let y = index(b) { return y - x }
        return cal.dateComponents([.day], from: date(a), to: date(b)).day ?? 0
    }
    static func add(_ s: String, _ n: Int) -> String {
        if let z = index(s) { return iso(index: z + n) }
        return parser.string(from: cal.date(byAdding: .day, value: n, to: date(s)) ?? date(s))
    }
    /// how many days a month ("2026-10") has
    static func daysIn(_ m: String) -> Int {
        if let z = index(String(m.prefix(7)) + "-01") {
            let p: String = iso(index: z)
            return monthLength(Int(p.prefix(4)) ?? 2000, Int(p.dropFirst(5).prefix(2)) ?? 1)
        }
        return 30
    }
    static func short(_ s: String) -> String { fmt(s, "EEE d MMM") }
    static func long(_ s: String) -> String { fmt(s, "EEEE, d MMMM") }
    static func dayNumber(_ s: String) -> Int {
        if index(s) != nil, let d = Int(String(s.dropFirst(8).prefix(2))) { return d }
        return cal.component(.day, from: date(s))
    }
    /// 1 Sunday … 7 Saturday (1 Jan 1970 was a Thursday)
    static func weekday(_ s: String) -> Int {
        if let z = index(s) { return ((z % 7) + 7 + 4) % 7 + 1 }
        return cal.component(.weekday, from: date(s))
    }
    static func label(_ s: String, today: String) -> String {
        if s == today { return "Today" }
        if s == add(today, -1) { return "Yesterday" }
        if s == add(today, 1) { return "Tomorrow" }
        // (a day of another year says its year: "Tue 19 Nov 2024", never a November that reads as this one)
        if s.count >= 10 && s.prefix(4) != today.prefix(4) { return short(s) + " " + String(s.prefix(4)) }
        return short(s)
    }
    static func time12(_ t: String) -> String {
        let p = t.split(separator: ":").compactMap { Int($0) }
        guard p.count == 2 else { return "" }
        let h = p[0] % 12 == 0 ? 12 : p[0] % 12
        return "\(h):" + String(format: "%02d", p[1]) + (p[0] >= 12 ? " pm" : " am")
    }
    static func monthName(_ m: String) -> String { fmt(m + "-01", "MMMM") }
    /// "today", "yesterday", or the date as written, for the middle of a sentence
    static func when(_ s: String, today: String) -> String {
        let l = label(s, today: today)
        return l == "Today" || l == "Yesterday" || l == "Tomorrow" ? l.lowercased() : l
    }
    static func monthShort(_ m: String) -> String { fmt(m + "-01", "MMM") }
    /// a yyyy-MM month's last day, yyyy-MM-dd
    static func monthEnd(_ m: String) -> String { add(addMonths(String(m.prefix(7)), 1) + "-01", -1) }
    /// a yyyy-MM month moved by n months
    static func addMonths(_ m: String, _ n: Int) -> String {
        let d = cal.date(byAdding: .month, value: n, to: date(String(m.prefix(7)) + "-01")) ?? date(m + "-01")
        return String(parser.string(from: d).prefix(7))
    }
}

// MARK: - Motion: one scale for everything that moves
//
// His recorded standard (transitions.dev): one ease, smooth-out cubic-bezier(0.22, 1, 0.36, 1); five durations,
// 150, 250, 350, 400 and 500 ms; closing faster than opening; a 40 ms stagger; and no bounce where a rupee is on
// screen (a figure that overshoots reads, for a frame, as a different figure). Every animation in kosh picks a step
// from here instead of writing its own; the only spring with any give is `pop`, for a glyph landing with no money
// near it. Ambient loops (a breathing dot, a shimmer, an error shake) are not transitions and keep their own pace.

enum Motion {
    /// the one ease, at a duration on the scale
    static func out(_ seconds: Double) -> Animation { .timingCurve(0.22, 1, 0.36, 1, duration: seconds) }
    /// 150 ms: a press, a tick, a chip lighting, anything going away
    static let quick: Animation = out(0.15)
    /// 250 ms: a selection, a toggle, a row's state; and closing what `open` opened
    static let base: Animation = out(0.25)
    /// 350 ms: a panel or a sub-tab coming in, a list growing, a scroll to a place
    static let open: Animation = out(0.35)
    /// 400 ms: something large moving across the screen
    static let large: Animation = out(0.4)
    /// 500 ms: a chart growing in, a figure counting up, the first look at a screen
    static let reveal: Animation = out(0.5)
    /// closing is quicker than opening: open with `open`, close with `close`
    static let close: Animation = base
    /// the one step between items that arrive in turn
    static let step: Double = 0.04
    /// the delay before item `i` of a run that starts after `after` seconds (items past the eighth arrive with it,
    /// so a long list never waits on itself)
    static func stagger(_ i: Int, after: Double = 0) -> Double { after + Double(min(max(i, 0), 8)) * step }
    /// opening or closing by which way a flag is going
    static func fold(_ opening: Bool) -> Animation { opening ? open : close }
    /// a finger let go (a drag springs back, a card is thrown): a spring keeps the finger's speed, with no overshoot
    static let settle: Animation = .spring(duration: 0.35, bounce: 0)
    /// a small glyph landing (a tick, a photo dropping into a stack), never where a rupee is on screen
    static let pop: Animation = .spring(duration: 0.35, bounce: 0.15)
    /// `pop` as a keyframe's spring (ChapterStage's stamp landing)
    static let popSpring: Spring = Spring(duration: 0.35, bounce: 0.15)
}

/// every plain button's pressed state: it gives a little under the finger and lets go quicker than it went in,
/// so a tap never feels dead. Otherwise it is the plain style: no tint, no padding, and a disabled one looks as the
/// screen drew it (some screens dim their own).
struct PressStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.98 : 1)
            .opacity(configuration.isPressed ? 0.8 : 1)
            .animation(configuration.isPressed ? Motion.quick : Motion.base, value: configuration.isPressed)
    }
}

extension ButtonStyle where Self == PressStyle {
    /// `.buttonStyle(.press)`: the plain look, with a pressed state
    static var press: PressStyle { PressStyle() }
}

// MARK: - Building blocks

/// A glyph drawn in its colour's ink on a pale wash of it, the way Chapters draws its tiles: the outline of the
/// symbol when it has one, so a row of them reads as line drawings rather than filled badges
struct IconTile: View {
    let symbol: String
    let color: Color
    var size: CGFloat = 36
    @Environment(\.colorScheme) private var scheme

    nonisolated(unsafe) private static var outlines: [String: String] = [:]
    /// "house.fill" → "house", when the outline exists; otherwise the symbol as it is
    static func outline(_ s: String) -> String {
        if let known = outlines[s] { return known }
        var out: String = s
        if s.hasSuffix(".fill") {
            let o: String = String(s.dropLast(5))
            if UIImage(systemName: o) != nil { out = o }
        }
        outlines[s] = out
        return out
    }

    var body: some View {
        let ink: Color = scheme == .dark ? color.mix(with: .white, by: 0.3) : color.mix(with: .black, by: 0.2)
        let wash: Color = scheme == .dark ? color.opacity(0.24) : color.mix(with: .white, by: 0.86)
        Image(systemName: Self.outline(symbol))
            .font(.system(size: size * 0.44, weight: .regular))
            .foregroundStyle(ink)
            .frame(width: size, height: size)
            .background(wash, in: RoundedRectangle(cornerRadius: size * 0.28, style: .continuous))
    }
}

/// small capitals over a title: what kind of thing, which month, how many
// MARK: Dynamic Type

/// a figure drawn at its own design size that still grows and shrinks with the reader's text size (hero figures,
/// which already shrink to fit their width): the size is scaled as `relativeTo` is
struct ScaledSystemFont: ViewModifier {
    @ScaledMetric private var size: CGFloat
    let weight: Font.Weight
    let design: Font.Design
    init(size: CGFloat, weight: Font.Weight, design: Font.Design, relativeTo style: Font.TextStyle) {
        _size = ScaledMetric(wrappedValue: size, relativeTo: style)
        self.weight = weight
        self.design = design
    }
    func body(content: Content) -> some View {
        content.font(.system(size: size, weight: weight, design: design))
    }
}

/// one line, as the design has it; two at the accessibility text sizes, where one line would cut a name to a few letters
struct OneLineUnlessLarge: ViewModifier {
    @Environment(\.dynamicTypeSize) private var typeSize
    func body(content: Content) -> some View {
        content.lineLimit(typeSize.isAccessibilitySize ? 2 : 1)
    }
}

extension View {
    func scaledFont(size: CGFloat, weight: Font.Weight = .regular, design: Font.Design = .default, relativeTo style: Font.TextStyle) -> some View {
        modifier(ScaledSystemFont(size: size, weight: weight, design: design, relativeTo: style))
    }
    func oneLineUnlessLarge() -> some View { modifier(OneLineUnlessLarge()) }
}

struct Eyebrow: View {
    let text: String
    var color: Color = Color.secondary
    var body: some View {
        Text(text)
            .font(.system(.caption2, weight: .semibold))
            .tracking(1.2)
            .textCase(.uppercase)
            .foregroundStyle(color)
    }
}

struct SectionHeader: View {
    let title: String
    var detail: String? = nil
    var action: String? = nil
    /// when set, the title folds the section away and back
    var folded: Binding<Bool>? = nil
    /// a part's number on a page told in parts, as a chapter's page numbers its own
    var n: Int? = nil
    var onAction: (() -> Void)? = nil
    @Environment(\.obsidian) private var obsidian
    /// the title: a bold heading, or on the black screens the spaced capital caption Wealth and Insurance title theirs with
    @ViewBuilder var heading: some View {
        if obsidian { Text(title).caption() } else { Text(title).font(.title2.weight(.bold)) }
    }
    var body: some View {
        if let folded {
            // the whole row folds it: the title, the chevron and the room either side of them (the action button
            // beside it still does its own thing, a button inside wins the tap)
            row
                .padding(.vertical, 8)
                .contentShape(Rectangle())
                .onTapGesture { withAnimation(Fold.motion(opening: folded.wrappedValue)) { folded.wrappedValue.toggle() } }
                .padding(.vertical, -8)
        } else {
            row
        }
    }

    var row: some View {
        HStack(alignment: .firstTextBaseline, spacing: 10) {
            if let n {
                Text(String(format: "%02d", n))
                    .font(.system(.footnote, design: .monospaced, weight: .semibold))
                    .foregroundStyle(.secondary)
            }
            if let folded {
                Button {
                    withAnimation(Fold.motion(opening: folded.wrappedValue)) { folded.wrappedValue.toggle() }
                } label: {
                    HStack(alignment: .firstTextBaseline, spacing: 8) {
                        heading.foregroundStyle(Color.primary)
                        Image(systemName: "chevron.down")
                            .font(.footnote.weight(.bold))
                            .foregroundStyle(.tertiary)
                            .rotationEffect(.degrees(folded.wrappedValue ? -90 : 0))
                            .animation(Fold.turn, value: folded.wrappedValue)
                    }
                    .contentShape(Rectangle())
                }
                .buttonStyle(.press)
                .accessibilityHint(folded.wrappedValue ? "Shows this section" : "Folds this section away")
            } else {
                heading
            }
            Spacer()
            if let action, let onAction, folded?.wrappedValue != true {
                Button(action, action: onAction).font(.subheadline.weight(.medium))
            } else if let detail, folded?.wrappedValue != true {
                Text(detail).font(.subheadline).foregroundStyle(.secondary)
            }
        }
    }
}

struct CardStyle: ViewModifier {
    var padding: CGFloat
    func body(content: Content) -> some View {
        content
            .padding(padding)
            .frame(maxWidth: .infinity, alignment: .leading)
            // (near-black with its hairline on Wealth's and Insurance's pages: ObsidianKit.swift)
            .background(CardFill(), in: RoundedRectangle(cornerRadius: 26, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 26, style: .continuous).strokeBorder(CardEdge(), lineWidth: 0.5))
    }
}

extension View {
    func card(_ padding: CGFloat = 16) -> some View { modifier(CardStyle(padding: padding)) }
    /// a date picker in India's days, as every kosh date is (Day): picked on a phone east or west of India, the day
    /// shown is the day saved
    func indiaDates() -> some View { environment(\.timeZone, Day.zone).environment(\.calendar, Day.cal) }
    /// a VoiceOver label that names figures: while amounts are hidden, the words without them (VoiceOver would read
    /// the custom label aloud even where the figures on screen are hidden)
    func spokenFigures(_ full: String, hidden plain: String) -> some View { modifier(SpokenFigures(full: full, plain: plain)) }
}

/// what VoiceOver says of a view that shows figures: the figures, unless amounts are hidden (the privacy redaction
/// reaches every view under it)
struct SpokenFigures: ViewModifier {
    let full: String
    let plain: String
    @Environment(\.redactionReasons) private var redaction
    func body(content: Content) -> some View {
        let said: String = redaction.contains(.privacy) ? plain : full
        return content.accessibilityLabel(Text(said))
    }
}

/// the words charts are summed up in for VoiceOver
enum SpokenWords {
    /// "3 months", "1 day"
    static func count(_ n: Int, _ one: String, _ many: String) -> String { String(n) + " " + (n == 1 ? one : many) }
    /// "from ₹1,200 to ₹1,450", or "each ₹999" when they're all one
    static func range(_ values: [Double]) -> String {
        let lo: Double = values.min() ?? 0
        let hi: Double = values.max() ?? 0
        if lo == hi { return "each " + Fmt.rupees(hi) }
        return "from " + Fmt.rupees(lo) + " to " + Fmt.rupees(hi)
    }
    /// "highest ₹4,200 in March", for figures by month ("yyyy-MM")
    static func highest(_ items: [(m: String, v: Double)]) -> String {
        guard let top = items.max(by: { $0.v < $1.v }), top.v > 0 else { return "nothing yet" }
        return "highest " + Fmt.rupees(top.v) + " in " + Day.monthName(top.m)
    }
}

struct ForPill: View {
    @Environment(Store.self) private var store
    let f: String
    var color: Color {
        switch f {
        case "me": return Color(hex: "#007AFF")
        case "mom": return Color(hex: "#FF2D55")
        case "home": return Color(hex: "#FF9500")
        default: return Color(hex: "#30B0C7")
        }
    }
    var label: String {
        switch f {
        case "me": return "Me"
        case "mom": return store.live != nil ? "Family" : "Mom"
        case "home": return "Home"
        default: return "Work"
        }
    }
    var body: some View {
        HStack(spacing: 4) {
            Circle().fill(color).frame(width: 6, height: 6)
            Text(label)
        }
        .font(.caption.weight(.semibold))
        .foregroundStyle(color)
    }
}

/// the small lines under a row: a refund still to come or come back, the payment a credit refunds,
/// a payment counted in another month
struct TxHint: Identifiable {
    let sym: String
    let text: String
    let tint: Color
    var id: String { sym + text }
    @MainActor static func of(_ t: Txn, store: Store, trip showTrip: Bool = true) -> [TxHint] {
        var out: [TxHint] = []
        if showTrip, let trip = store.trip(t.tr) {
            out.append(TxHint(sym: trip.sym, text: trip.name, tint: trip.tint))
        }
        let left: Double = t.rx ?? 0
        let back: Double = t.refunded ?? 0
        if left > 0.5 {
            out.append(TxHint(sym: "arrow.uturn.backward", text: Fmt.rupees(left) + " refund to come", tint: Color.kosh))
        } else if back > 0.5 {
            out.append(TxHint(sym: "checkmark.circle", text: Fmt.rupees(back) + " came back", tint: Color.green))
        }
        if let of = t.refOf {
            let name: String = store.txn(of)?.m ?? "a payment"
            out.append(TxHint(sym: "arrow.uturn.backward", text: "Refund for " + name, tint: Color.secondary))
        } else if let kind = t.nt {
            // a refund kosh couldn't match to a payment: money back, off that kind of spending (as far as there was some)
            let off: Double = t.nta ?? 0
            let text: String = off > 0.5 ? "Refund · " + Fmt.rupees(off) + " off " + kind + " spending" : "Refund · not counted as money in"
            out.append(TxHint(sym: "arrow.uturn.backward", text: text, tint: Color.secondary))
        }
        // money someone paid back: whose share of what (the engine's words), not income
        if !(t.paysBack ?? []).isEmpty, let why = t.ex, !why.isEmpty {
            out.append(TxHint(sym: "person.2.fill", text: why, tint: Color.green))
        }
        if let od = t.od {
            let text: String = "Paid " + Day.fmt(od, "d MMM") + ", counted in " + Day.monthName(String(t.d.prefix(7)))
            out.append(TxHint(sym: "calendar", text: text, tint: Color.secondary))
        }
        if let why = Self.notCounted(t) {
            out.append(TxHint(sym: "eye.slash", text: why, tint: t.nc == "unnamed" ? Color.orange : Color.secondary))
        }
        // through an app whose receipt never names your bank: kosh works the account out (alerts, daily balances, its
        // earlier payments); until it has, the row says so
        if store.live != nil, (t.dr ?? "out") == "out", let app = store.railOf(t) {
            if !store.paidFromKnown(t) {
                out.append(TxHint(sym: "building.columns", text: app + " is the app; kosh is finding the account", tint: Color.secondary))
            } else if t.fg == true {
                out.append(TxHint(sym: "building.columns", text: "Likely account, from your past " + app + " payments", tint: Color.secondary))
            }
        }
        return out
    }
    /// a payment that looks like spending but isn't counted, in a few words: the row and its sheet say the same
    static func notCounted(_ t: Txn) -> String? {
        switch t.nc ?? "" {
        case "ex": return "Not counted · you left it out"
        case "unnamed": return "Not counted · big and unnamed, name it to count it"
        case "parked": return "Not counted yet · counts when it's spent"
        case "wallet": return "Not counted · counted when the wallet was loaded"
        case "chapter": return "Not counted · trips are left out of monthly spending"
        case "tax": return "Not counted · a tax, not spending"
        default: return nil
        }
    }
}

struct TxRow: View {
    @Environment(Store.self) private var store
    let t: Txn
    var when: String
    /// the share of the month's spending gone out by this payment (the newest is 100%); nil to leave it off
    var cum: Double? = nil
    /// how it was paid and from which bank, under the category (left off where the page is one account or card)
    var showWay: Bool = true
    /// the trip it's in, under the name (left off on the trip's own page)
    var showTrip: Bool = true
    /// words to light in the name (Find: what you typed)
    var mark: [String] = []
    var body: some View {
        let move = store.isMove(t)
        let way: String? = showWay ? PayWay.line(t) : nil
        let excluded: Bool = (t.ex != nil || !(t.nc ?? "").isEmpty) && t.refOf == nil && t.nt == nil && t.paysBack == nil
        let hints: [TxHint] = TxHint.of(t, store: store, trip: showTrip)
        // a split whose shares have all come back
        let back: Bool = (t.shared ?? 0) > 0 && store.sharesBack(t.id)
        Button {
            store.sheet = .tx(t.id)
        } label: {
            VStack(alignment: .leading, spacing: 4) {
                HStack(spacing: 12) {
                    IconTile(symbol: t.u ? "questionmark" : t.sym, color: store.color(for: t))
                    VStack(alignment: .leading, spacing: 2) {
                        // (smooth-5nov) a plain Text unless Find has words to light: no AttributedString per row
                        (mark.isEmpty ? Text(t.m) : Text(TxMark.lit(t.m, mark)))
                            .font(.body.weight(.medium))
                            .foregroundStyle(move ? Color.secondary : Color.primary)
                            .oneLineUnlessLarge()
                        HStack(spacing: 6) {
                            if t.u {
                                Text("Needs a name").foregroundStyle(Color.orange)
                            } else {
                                Text(store.catLine(t))
                            }
                            if t.k == "out", !t.f.isEmpty { ForPill(f: t.f) }
                            if excluded { Image(systemName: "eye.slash").foregroundStyle(.tertiary).accessibilityLabel(Self.leftOut) }
                        }
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .oneLineUnlessLarge()
                        if let way { WayPill(text: way, md: t.md ?? "").padding(.top, 2) }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    VStack(alignment: .trailing, spacing: 2) {
                        Text((t.k == "in" ? "+" : "") + (t.est == true ? "≈ " : "") + Fmt.rupees((t.wu?.isEmpty == false ? t.ot : nil) ?? t.a))
                            .font(.body.weight(.semibold))
                            .monospacedDigit()
                            .strikethrough(excluded, color: .secondary)
                            .foregroundStyle(t.k == "in" ? Color.green : (move || excluded ? Color.secondary : Color.primary))
                            .lineLimit(1)
                            .privacySensitive()
                        if let fx = t.fx { Text(fx).font(.caption).foregroundStyle(.secondary).monospacedDigit().lineLimit(1).privacySensitive() }
                        if let full = t.full ?? t.partOf.flatMap({ store.txn($0) }).flatMap({ $0.full }), full > t.a + 0.5 {
                            Text("of \(Fmt.rupees(full))").font(.caption).foregroundStyle(.secondary).monospacedDigit().lineLimit(1).privacySensitive()
                        }
                        if !when.isEmpty { Text(when).font(.caption).foregroundStyle(.secondary).lineLimit(1) }
                    }
                    .layoutPriority(1)   // the amount keeps its width; the name gives way
                }
                // a split: what others owe on it, on a line of its own under the name, the full row wide
                if let sh = t.shared, sh > 0 {
                    Label(Fmt.rupees(sh) + (back ? " paid back" : " to get back"), systemImage: back ? "checkmark.circle.fill" : "person.2.fill")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(Color.green)
                        .lineLimit(1)
                        .padding(.leading, 48)
                        .privacySensitive()
                } else if let part = t.partOf, !part.isEmpty {
                    HintLine(sym: "scissors", text: SplitWords.part(t, store))
                        .font(.caption).foregroundStyle(.secondary)
                        .padding(.leading, 48)
                        .privacySensitive()
                } else if let paid = SplitWords.paidHow(t, store) {
                    HintLine(sym: "creditcard.and.123", text: paid)
                        .font(.caption).foregroundStyle(.secondary)
                        .padding(.leading, 48)
                        .privacySensitive()
                } else if let bh = t.bh, !bh.isEmpty {
                    HintLine(sym: "house", text: bh)
                        .font(.caption).foregroundStyle(.secondary)
                        .padding(.leading, 48)
                        .privacySensitive()
                } else if let gw = t.gw, let nm = gw.split(separator: "|").first, !nm.isEmpty {
                    HintLine(sym: "link", text: "Goes with your " + String(nm) + (gw.split(separator: "|").count > 1 ? " · " + GoesWithWords.when(String(gw.split(separator: "|")[1])) : ""))
                        .font(.caption).foregroundStyle(.secondary)
                        .padding(.leading, 48)
                        .privacySensitive()
                } else if let gone = SplitWords.returned(t, store) {
                    HintLine(sym: "arrow.uturn.backward", text: gone)
                        .font(.caption).foregroundStyle(Color.green)
                        .padding(.leading, 48)
                        .privacySensitive()
                } else if t.full != nil, let rest = SplitWords.rest(t, store) {
                    HintLine(sym: "shippingbox", text: rest)
                        .font(.caption).foregroundStyle(.secondary)
                        .padding(.leading, 48)
                        .privacySensitive()
                }
                ForEach(hints) { h in
                    HintLine(sym: h.sym, text: h.text)
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(h.tint)
                        .padding(.leading, 48)
                        .privacySensitive()
                }
                // left out with no reason line of its own: said in words too, not by the struck-through amount alone
                if excluded && TxHint.notCounted(t) == nil {
                    HintLine(sym: "eye.slash", text: Self.leftOut)
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.secondary)
                        .padding(.leading, 48)
                }
                if let cum { MonthShare(f: cum).padding(.leading, 48) }
            }
            .contentShape(Rectangle())
        }
        .buttonStyle(.press)
    }
    static let leftOut: String = "Left out of totals"
}

/// a small line under a payment: its icon right beside its words (a Label in a list row sets the words a whole
/// icon column away)
struct HintLine: View {
    let sym: String
    let text: String
    var body: some View {
        HStack(spacing: 5) {
            Image(systemName: sym).imageScale(.small)
            Text(text).lineLimit(1)
        }
        .accessibilityElement(children: .combine)
    }
}

/// how a payment was made and from which bank, as a quiet pill under its category
struct WayPill: View {
    let text: String
    let md: String
    var body: some View {
        HStack(spacing: 4) {
            Image(systemName: PayWay.symbol(md)).font(.system(size: 9, weight: .bold))
            Text(text).lineLimit(1)
        }
        .font(.caption)
        .foregroundStyle(.secondary)
        .padding(.horizontal, 6).padding(.vertical, 2)
        .background(Color.primary.opacity(0.05), in: Capsule())
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(Text(verbatim: "Paid by " + text))
    }
}

/// a hairline under a payment: how much of the month's spending had gone out by then
struct MonthShare: View {
    let f: Double
    var body: some View {
        let pct: Int = Int(safe: (f * 100).rounded())
        HStack(spacing: 8) {
            GeometryReader { geo in
                ZStack(alignment: .leading) {
                    Capsule().fill(Color.primary.opacity(0.06))
                    Capsule().fill(Color.kosh.opacity(f >= 0.999 ? 0.8 : 0.45)).frame(width: max(2, geo.size.width * f))
                }
            }
            .frame(height: 3)
            Text(String(pct) + "%")
                .font(.caption2.weight(.medium)).monospacedDigit().foregroundStyle(.tertiary)
                .frame(width: 34, alignment: .trailing)
        }
        .padding(.top, 1)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(String(pct) + " percent of the month's spending so far had gone out by this payment")
    }
}

/// Calendar's own page: the month in red, the day in black
struct DateBadge: View {
    let date: String
    var today: Bool = false
    var body: some View {
        VStack(spacing: 0) {
            Text(Day.fmt(date, "MMM").uppercased())
                .font(.system(size: 10, weight: .bold))
                .foregroundStyle(today ? Color.kosh : Color.red)
            Text("\(Day.dayNumber(date))")
                .font(.system(size: 19, weight: .semibold, design: .rounded))
        }
        .frame(width: 42, height: 44)
        .background(CardFill(raised: true), in: RoundedRectangle(cornerRadius: 11, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 11, style: .continuous).stroke(Color.hairline, lineWidth: 1))
    }
}

/// A committee as a ring of months: filled once paid, blue on the month you take the pool
struct RingView: View {
    let c: Committee?
    var count: Int = 0
    var size: CGFloat = 44
    @State private var shown = false

    var n: Int {
        guard let c else { return max(count, 1) }
        return c.members > 0 ? c.members : max(12, c.paid + 6)
    }
    var label: String {
        guard let c else { return "\(count)" }
        if let d = c.draw { return Day.monthShort(d) }
        return "\(c.paid)"
    }
    func color(_ i: Int) -> Color {
        guard let c else { return Color.primary }
        if i == c.drawIndex { return c.done ? Color.green : Color.kosh }
        if i < c.paid { return Color.primary }
        return Color.clear
    }
    var body: some View {
        let r = size / 2 - 4
        let dot = max(3, min(6, (2 * .pi * r / CGFloat(n)) * 0.5))
        ZStack {
            ForEach(0..<n, id: \.self) { i in
                let a = -Double.pi / 2 + Double(i) * 2 * Double.pi / Double(n)
                let isDraw = c != nil && i == c!.drawIndex
                Circle()
                    .fill(color(i))
                    .overlay(Circle().stroke(Color.secondary.opacity(color(i) == Color.clear ? 0.6 : 0), lineWidth: 1))
                    .frame(width: isDraw ? dot * 1.5 : dot, height: isDraw ? dot * 1.5 : dot)
                    .offset(x: CGFloat(cos(a)) * r, y: CGFloat(sin(a)) * r)
                    .scaleEffect(shown ? 1 : 0.2)
                    .opacity(shown ? 1 : 0)
                    .animation(Motion.reveal.delay(Motion.stagger(i)), value: shown)
            }
            Text(label)
                .font(.system(size: max(10, size * 0.23), weight: .semibold, design: .rounded))
        }
        .frame(width: size, height: size)
        .onAppear { shown = true }
    }
}

struct AgendaRow: View {
    @Environment(Store.self) private var store
    let a: AgendaItem
    var body: some View {
        HStack(spacing: 12) {
            if let d = a.date {
                DateBadge(date: d, today: d == store.snap.today)
            } else if a.cat == "committee" {
                RingView(c: store.committee(a.comm), size: 42)
            } else {
                IconTile(symbol: a.sym, color: a.kind == "in" ? Color.green : store.catColor(a.cat), size: 42)
            }
            VStack(alignment: .leading, spacing: 2) {
                Text(a.name).font(.body.weight(.medium)).lineLimit(1)
                Text(a.sub).font(.subheadline).foregroundStyle(a.lock ? Color.orange : Color.secondary).lineLimit(1)
            }
            Spacer(minLength: 8)
            Text((a.kind == "in" ? "+" : "") + Fmt.words(a.amt))
                .font(.body.weight(.semibold))
                .monospacedDigit()
                .foregroundStyle(a.lock ? Color.secondary : (a.kind == "in" ? Color.green : Color.primary))
                .privacySensitive()
        }
        .contentShape(Rectangle())
        .contextMenu {
            // paid before the bank's mail shows it: hold the row (its reminder has the same button). A committee's
            // month is recorded in its book instead.
            if store.live != nil && a.kind != "in" && a.cat != "committee" && a.date != nil && !a.booked {
                Button { store.markPaid(a.id, undo: true) } label: { Label("Mark as paid", systemImage: "checkmark.circle") }
            }
        }
    }
}

/// Rows inside one rounded card, with inset dividers
struct RowsCard<Item: Identifiable, Row: View>: View {
    let items: [Item]
    var inset: CGFloat = 58
    @ViewBuilder let row: (Item) -> Row
    var body: some View {
        VStack(spacing: 0) {
            ForEach(Array(items.enumerated()), id: \.element.id) { i, item in
                if i > 0 { Divider().padding(.leading, inset) }
                row(item).padding(.vertical, 11).padding(.horizontal, 14)
            }
        }
        .background(CardFill(), in: RoundedRectangle(cornerRadius: 26, style: .continuous))
    }
}

// MARK: - Sub-tabs, whose-money menu, badges

/// The glass row of sub-tabs under a tab's title
struct SubTabBar<T: SubTab>: View {
    @Environment(Store.self) private var store
    @Binding var selection: T
    /// the tab whose page can be arranged: a sliders circle at the row's end opens "Arrange this tab" (only on a
    /// page that has sections to arrange)
    var arrange: AppTab? = nil
    /// a magnifying glass at the row's end instead, that opens Find
    var find: (() -> Void)? = nil
    /// a bell at the row's end, with how many things are waiting for a look (Home's heads-up)
    var bell: BellInfo? = nil
    @Namespace private var glass
    @Environment(\.obsidian) private var obsidian

    var body: some View {
        HStack(spacing: 0) {
            pills
            if let bell {
                BellButton(info: bell)
                    .padding(.trailing, 16)
                    .padding(.leading, 4)
            }
            if let find {
                Button(action: find) { HeaderCircle(symbol: "magnifyingglass") }
                    .buttonStyle(.press)
                    .accessibilityLabel("Find payments")
                    .accessibilityHint("Search by name and filter by category, who it was for, how it was paid and more")
                    .padding(.trailing, 16)
                    .padding(.leading, 4)
                    .transition(.opacity.combined(with: .scale(scale: 0.8)))
            } else if let tab = arrange, PlanPage.showing(tab, store) != nil {
                ArrangeButton(tab: tab)
                    .padding(.trailing, 16)
                    .padding(.leading, 4)
                    .transition(.opacity.combined(with: .scale(scale: 0.8)))
            }
        }
        .animation(Motion.base, value: selection)
    }

    /// the chosen pill: kosh's colour, or white with black words on the black screens (Wealth, Insurance)
    var fill: Color { obsidian ? Obsidian.ink : Color.koshFill }
    func ink(_ on: Bool) -> Color {
        if obsidian { return on ? Color.black : Obsidian.ink2 }
        return on ? Color.onKosh : Color.primary
    }

    var pills: some View {
        ScrollViewReader { proxy in
        ScrollView(.horizontal) {
            GlassEffectContainer(spacing: 8) {
                HStack(spacing: 6) {
                    ForEach(T.allCases) { t in
                        let on = t == selection
                        Button {
                            withAnimation(Motion.open) { selection = t }
                        } label: {
                            Text(t.title)
                                .font(.subheadline.weight(.semibold))
                                .foregroundStyle(ink(on))
                                .padding(.horizontal, 15)
                                .padding(.vertical, 8)
                        }
                        .buttonStyle(.plain)
                        .glassEffect(on ? Glass.regular.tint(fill).interactive() : Glass.regular.interactive(), in: .capsule)
                        .glassEffectID(t.title, in: glass)
                        .id(t.id)
                    }
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 6)
            }
        }
        .scrollIndicators(.hidden)
        .sensoryFeedback(.selection, trigger: selection)
        .onAppear { proxy.scrollTo(selection.id, anchor: .center) }
        .onChange(of: selection) { _, s in withAnimation(Motion.open) { proxy.scrollTo(s.id, anchor: .center) } }
        }
    }
}

// MARK: - A main tab's top row

/// what a tab's + does: one action, or each of these in its menu
struct HeaderAction: Identifiable {
    let title: String
    let symbol: String
    /// a divider above it in the menu
    var newGroup: Bool = false
    let run: () -> Void
    var id: String { title }
}

private struct PushedModuleKey: EnvironmentKey { static let defaultValue: Bool = false }
extension EnvironmentValues {
    /// a module's page pushed from Home rather than shown as its own tab: its title goes under the back button
    var pushedModule: Bool {
        get { self[PushedModuleKey.self] }
        set { self[PushedModuleKey.self] = newValue }
    }
}

/// Every main tab's top row: the title, large, from the top of the screen on the left (it shrinks into the bar as the
/// page scrolls, as iOS does), and on the right a few small glass circles: whose money it is (its menu also hides the
/// amounts and opens Settings), Ask kosh, the tab's own button if it has one, and add. Sub-tab pills sit right under.
struct TabHeader: ViewModifier {
    @Environment(\.pushedModule) private var pushed
    let title: String
    var add: [HeaderAction] = []
    var addLabel: String = "Add"
    var extra: HeaderAction? = nil
    /// a tab whose sub-tabs swap one scrolling page for another under the top row (Portfolio): the bar's large title
    /// stayed up over the new page while its small one came in too ("Portfolio Portfolio"), so kosh draws the large
    /// title itself and the bar draws none. The title is still the page's, for the back button and VoiceOver.
    var own: Bool = false
    @ViewBuilder func body(content: Content) -> some View {
        if own && !pushed {
            content
                .navigationTitle(title)
                .toolbarTitleDisplayMode(.inline)
                .toolbar(removing: .title)
                .toolbar {
                    ToolbarItem(placement: .topBarLeading) {
                        Text(title).font(.largeTitle.bold()).lineLimit(1)
                            .fixedSize(horizontal: true, vertical: false)
                            .accessibilityAddTraits(.isHeader)
                    }
                    .sharedBackgroundVisibility(.hidden)
                    ToolbarItem(placement: .topBarTrailing) {
                        HeaderButtons(add: add, addLabel: addLabel, extra: extra)
                    }
                    .sharedBackgroundVisibility(.hidden)
                }
        } else {
            content
                .navigationTitle(title)
                .toolbarTitleDisplayMode(pushed ? .large : .inlineLarge)
                .toolbar {
                    ToolbarItem(placement: .topBarTrailing) {
                        HeaderButtons(add: add, addLabel: addLabel, extra: extra)
                    }
                    .sharedBackgroundVisibility(.hidden)
                }
        }
    }
}

extension View {
    /// a main tab's title and its row of buttons (TabHeader); `ownTitle`: kosh draws the title (see TabHeader.own)
    func tabHeader(_ title: String, add: [HeaderAction] = [], addLabel: String = "Add", extra: HeaderAction? = nil, ownTitle: Bool = false) -> some View {
        modifier(TabHeader(title: title, add: add, addLabel: addLabel, extra: extra, own: ownTitle))
    }
}

/// the top row's circles, in one glass group: the tab's own, whose money, Ask kosh, add
struct HeaderButtons: View {
    @Environment(Store.self) private var store
    let add: [HeaderAction]
    var addLabel: String = "Add"
    var extra: HeaderAction? = nil
    /// each circle: small enough that three or four leave the title its room, big enough to tap
    static let size: CGFloat = 38

    var body: some View {
        GlassEffectContainer(spacing: 6) {
            HStack(spacing: 6) {
                if let e = extra {
                    Button(action: e.run) { HeaderCircle(symbol: e.symbol) }
                        .buttonStyle(.press)
                        .accessibilityLabel(e.title)
                }
                PersonToggle()
                Button { store.sheet = .ask } label: { HeaderCircle(symbol: "sparkles") }
                    .buttonStyle(.press)
                    .accessibilityLabel("Ask kosh")
                plus
            }
        }
    }

    @ViewBuilder var plus: some View {
        if add.count == 1, let a = add.first {
            Button(action: a.run) { HeaderCircle(symbol: "plus", filled: true) }
                .buttonStyle(.press)
                .accessibilityLabel(a.title)
        } else if add.count > 1 {
            Menu {
                ForEach(add) { a in
                    if a.newGroup { Divider() }
                    Button(action: a.run) { Label(a.title, systemImage: a.symbol) }
                }
            } label: {
                HeaderCircle(symbol: "plus", filled: true)
            }
            .menuStyle(.button)
            .buttonStyle(.press)
            .accessibilityLabel(addLabel)
        }
    }
}

/// one circle of the top row: a symbol, or a person's initials; add is filled with the accent
struct HeaderCircle: View {
    var symbol: String = ""
    var initials: String = ""
    var filled: Bool = false
    /// a person's colour, faintly, behind their initials
    var tint: Color? = nil
    var body: some View {
        let glass: Glass = filled ? Glass.regular.tint(Color.koshFill).interactive()
            : (tint.map { Glass.regular.tint($0.opacity(0.28)).interactive() } ?? Glass.regular.interactive())
        Group {
            if initials.isEmpty {
                Image(systemName: symbol).font(.system(size: 15, weight: .semibold))
            } else {
                Text(initials).font(.system(size: 13.5, weight: .bold, design: .rounded)).lineLimit(1).minimumScaleFactor(0.7)
            }
        }
        .foregroundStyle(filled ? Color.onKosh : Color.primary)
        .frame(width: HeaderButtons.size, height: HeaderButtons.size)
        .contentShape(Circle())
        .glassEffect(glass, in: .circle)
    }
}

extension View {
    /// a tab that follows the picker by whose each thing is: while one person is picked, one line under its bar says
    /// what it shows and how many are the household's alone (nil: nothing to say)
    func whoseScope(_ line: String?) -> some View { modifier(WhoseScope(line: line)) }
    /// a tab whose figures kosh keeps for the household, with no owner on them: said so while one person is picked,
    /// so the picker never reads as having filtered it (and nothing is guessed from a name to split it)
    func householdOnly(_ line: String) -> some View { modifier(HouseholdOnly(line: line)) }
}

struct WhoseScope: ViewModifier {
    @Environment(Store.self) private var store
    let line: String?
    func body(content: Content) -> some View {
        content.safeAreaInset(edge: .top, spacing: 0) {
            if store.who != .family, let line {
                Label(line, systemImage: "person.crop.circle").font(.footnote).foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal, 16).padding(.vertical, 8)
                    .background(.bar)
            }
        }
    }
}

struct HouseholdOnly: ViewModifier {
    @Environment(Store.self) private var store
    let line: String
    func body(content: Content) -> some View {
        content.safeAreaInset(edge: .top, spacing: 0) {
            if store.who != .family {
                Label(line, systemImage: "person.2").font(.footnote).foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal, 16).padding(.vertical, 8)
                    .background(.bar)
            }
        }
    }
}

/// whose money every tab shows: two people for the family, else the person's initials on a wash of their colour. Its
/// menu picks the person, hides the amounts (the old eye) and opens Settings (the old avatar).
struct PersonToggle: View {
    @Environment(Store.self) private var store
    var body: some View {
        @Bindable var store = store
        let who: Person = store.who
        let info: PersonInfo? = who == .family ? nil : store.person(who.id)
        let marks: String = info.map { PersonToggle.initials($0.full.isEmpty ? $0.name : $0.full) } ?? ""
        Menu {
            Picker("Whose money", selection: $store.who) {
                ForEach(store.whoOptions) { p in
                    Label(p.title, systemImage: p == .family ? "person.2" : "person").tag(p)
                }
            }
            Section {
                Toggle(isOn: Binding(get: { store.hidden }, set: { v in withAnimation(Motion.open) { store.hidden = v } })) {
                    Label("Hide amounts", systemImage: "eye.slash")
                }
                Button { store.push(.details(who == .family ? "" : who.id)) } label: { Label("Your details", systemImage: "person.text.rectangle") }
                Button { store.sheet = .settings } label: { Label("Settings", systemImage: "gearshape") }
            }
        } label: {
            HeaderCircle(symbol: who == .family ? "person.2.fill" : "person.fill", initials: marks,
                         tint: info.map { Color(hex: $0.color) })
        }
        .menuStyle(.button)
        .buttonStyle(.press)
        .accessibilityLabel("Whose money: " + who.title)
        .accessibilityHint("Also hides amounts and opens Settings")
    }
    /// "Test User" → "TU"; nothing for a placeholder name like "You", which keeps the person mark
    static func initials(_ name: String) -> String {
        let trimmed: String = name.trimmingCharacters(in: .whitespaces)
        if trimmed.isEmpty || trimmed == "You" { return "" }
        let parts = trimmed.split(separator: " ").prefix(2)
        return parts.compactMap { $0.first }.map { String($0) }.joined().uppercased()
    }
}

/// A person's initials on their colour
struct Avatar: View {
    let name: String
    var color: Color = Color.koshFill
    var size: CGFloat = 36
    /// the initials' colour: white on a person's colour; Color.onKosh on the accent's fill
    var ink: Color = Color.white
    var initials: String {
        let parts = name.split(separator: " ").prefix(2)
        let s = parts.compactMap { $0.first }.map { String($0) }.joined().uppercased()
        return s.isEmpty ? "?" : s
    }
    var body: some View {
        Text(initials)
            .font(.system(size: size * 0.38, weight: .semibold, design: .rounded))
            .foregroundStyle(ink)
            .frame(width: size, height: size)
            .background(color.gradient, in: Circle())
    }
}

/// A bank's mark on its own colour, the way a card shows its issuer
struct BankBadge: View {
    let bank: String
    let color: Color
    var size: CGFloat = 36
    var mark: String {
        if bank.count <= 4 && bank == bank.uppercased() { return bank }
        let caps = bank.filter { $0.isUppercase }
        if caps.count >= 2 { return String(caps.prefix(3)) }
        return String(bank.prefix(2)).uppercased()
    }
    var body: some View {
        Text(mark)
            .font(.system(size: size * (mark.count > 3 ? 0.25 : 0.32), weight: .heavy, design: .rounded))
            .foregroundStyle(.white)
            .frame(width: size, height: size)
            .background(color.gradient, in: RoundedRectangle(cornerRadius: size * 0.28, style: .continuous))
    }
}

/// A count with a label, for the household page
struct CountTile: View {
    let value: String
    let label: String
    let sym: String
    let color: Color
    var fill: Color = Color.surface
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Image(systemName: sym).font(.title3).foregroundStyle(color)
            Text(value)
                .font(.system(.title, design: .rounded, weight: .bold))
                .foregroundStyle(Color.primary)
                .contentTransition(.numericText())
            Text(label).font(.subheadline).foregroundStyle(.secondary).lineLimit(1)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(14)
        .background(fill, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
    }
}

/// A small coloured label
struct Chip: View {
    let text: String
    var color: Color = Color.kosh
    var body: some View {
        Text(text)
            .font(.caption.weight(.semibold))
            .padding(.horizontal, 8)
            .padding(.vertical, 3)
            .background(color.opacity(0.14), in: Capsule())
            .foregroundStyle(color)
    }
}

/// The big figure at the top of a page, with its line underneath
struct PageHead: View {
    let label: String
    let value: String
    var note: String = ""
    var color: Color = Color.primary
    var body: some View {
        VStack(alignment: .leading, spacing: 3) {
            Text(label).font(.subheadline.weight(.medium)).foregroundStyle(.secondary)
            Text(value)
                .scaledFont(size: 44, weight: .bold, design: .rounded, relativeTo: .largeTitle)
                .foregroundStyle(color)
                .minimumScaleFactor(0.6)
                .lineLimit(1)
                .privacySensitive()
            if !note.isEmpty {
                // (a note can carry a figure: "₹2,40,000 of it in your name"; hidden with the amounts)
                Text(note).font(.subheadline).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true).privacySensitive()
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}


/// What a tab is for, the first time someone opens it. × puts it away for good on this phone.
struct TabIntro: View {
    let sym: String
    let title: String
    let text: String
    @AppStorage private var gone: Bool
    init(id: String, sym: String, title: String, text: String) {
        self.sym = sym; self.title = title; self.text = text
        _gone = AppStorage(wrappedValue: false, "intro." + id)
    }
    var body: some View {
        if !gone {
            HStack(alignment: .top, spacing: 12) {
                Image(systemName: sym).font(.title3).foregroundStyle(Color.kosh).frame(width: 28).padding(.top, 2)
                VStack(alignment: .leading, spacing: 4) {
                    Text(title).font(.subheadline.weight(.semibold))
                    Text(text).font(.subheadline).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                }
                Spacer(minLength: 0)
                Button { withAnimation(Motion.open) { gone = true } } label: {
                    Image(systemName: "xmark").font(.caption.weight(.bold)).foregroundStyle(.secondary)
                        .frame(width: 28, height: 28).background(Color.primary.opacity(0.06), in: Circle())
                }
                .buttonStyle(.press)
                .accessibilityLabel("Don't show this again")
            }
            .padding(14)
            .background(Color.kosh.opacity(0.07), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            .transition(.opacity.combined(with: .move(edge: .top)))
        }
    }
}

/// each tab's first-time line, in one place
enum Intro {
    static func home() -> TabIntro { TabIntro(id: "home", sym: "house.fill", title: "Your money at a glance",
        text: "What's coming up, what needs you and what kosh noticed, all from your own mail. Tap a section's title to fold it away.") }
    static func transactions() -> TabIntro { TabIntro(id: "transactions", sym: "list.bullet.rectangle.fill", title: "Every payment, from your bank and card mail",
        text: "Tap one to change its category, split it with someone or say who it was for; kosh tags the next one like it. The line under each day is the month so far.") }
    static func property() -> TabIntro { TabIntro(id: "property", sym: "building.2.fill", title: "Your properties, rent and tax",
        text: "Add a property and its floors, mark rent as it comes in, and bring tax dues in from your state's portal with the building button at the top.") }
    static func committees() -> TabIntro { TabIntro(id: "committees", sym: "circle.dotted.circle", title: "Committees you're part of",
        text: "Add each one once: the monthly amount, how many members, when it started and your month. kosh puts each instalment on your calendar and works out what it has earned you.") }
    static func insurance() -> TabIntro { TabIntro(id: "insurance", sym: "shield.lefthalf.filled", title: "Every policy, read from your mail",
        text: "Nothing to upload: the schedule the insurer sent, each premium receipt, renewal notices and unit statements are read and matched to what you paid. Tap a policy for its story and one word on what to do with it.") }
    static func people() -> TabIntro { TabIntro(id: "people", sym: "person.2.fill", title: "Money between you and others",
        text: "Split a payment and kosh keeps track of who owes you. When their money arrives, mark it received; send a reminder with your UPI ID in one tap.") }
}

// MARK: - Analytics cards: their usual surface, or glass under Analytics testing

private struct LabGlassKey: EnvironmentKey { static var defaultValue: Color? { nil } }
extension EnvironmentValues {
    /// set: the analytics views' cards are glass tinted this colour (Analytics testing); nil: their usual surface
    var labGlass: Color? {
        get { self[LabGlassKey.self] }
        set { self[LabGlassKey.self] = newValue }
    }
}

/// an analytics card's surface: its usual one, or under Analytics testing, glass: a faint light-to-colour fill the
/// wash shows through and a hairline lit from above. No blur (the wash behind is smooth, a blur would change nothing
/// and cost every scroll frame)
struct InsightCardSurface: ViewModifier {
    @Environment(\.labGlass) private var tint
    let radius: CGFloat
    func body(content: Content) -> some View {
        let shape = RoundedRectangle(cornerRadius: radius, style: .continuous)
        if let tint {
            content
                .background(LinearGradient(stops: [.init(color: Color.white.opacity(0.085), location: 0),
                                                   .init(color: tint.opacity(0.07), location: 0.55),
                                                   .init(color: Color.white.opacity(0.03), location: 1)],
                                           startPoint: .topLeading, endPoint: .bottomTrailing), in: shape)
                .overlay(shape.strokeBorder(LinearGradient(colors: [Color.white.opacity(0.24), Color.white.opacity(0.05), tint.opacity(0.2)],
                                                           startPoint: .top, endPoint: .bottom), lineWidth: 0.75))
        } else {
            content.background(Color.surface, in: shape)
        }
    }
}

extension View {
    func insightCard(_ radius: CGFloat) -> some View { modifier(InsightCardSurface(radius: radius)) }
}
