import SwiftUI

// MARK: - When no fund statement comes: one card on Portfolio, and the request page inside kosh
//
// The engine notices a person whose fund statement (CAS) is missing, behind or old (snap.casGap). The card says so once
// and, with one tap, opens a registrar's free request page in an in-app Safari sheet, the person's own email shown to
// copy. The person fills and sends the form themselves: kosh never types into it, reads it or sends it (Portals are GET
// only). The statement that comes back is read like any other; a locked one opens with the password they chose, typed
// once in Holdings › Statements. What they said ("I asked", "not now") is kept by the gap's id (CASAsk.swift), so the
// same gap never asks twice. CAS-FAILSAFE.md has the pages, how they were found, and what comes next.

/// a person's missing, late or old fund statement, as the engine found it (engine/21n-build-cas-gap.js)
struct CASGap: Decodable, Hashable, Identifiable {
    struct Signal: Decodable, Hashable { let d: String; let what: String }
    /// "cas|<who>|<newest statement's day or none>", or "cas|<who>|locked|<its mail>"
    let id: String
    let who: String
    /// never · stale · old · locked
    let kind: String
    let title: String
    let why: String
    /// true: a statement is to be asked for; false: one came locked and waits on its password
    let ask: Bool
    /// the newest statement read (the day it came), and the day it covers
    var last: String? = nil
    var covered: String? = nil
    /// the newest sign of funds that set it off
    var signal: Signal? = nil
    /// the inbox their fund mail comes to
    var to: String? = nil
    /// a locked one: who sent it, and when
    var sender: String? = nil
    var on: String? = nil
}

/// Portfolio's card, in the statements banner's place: a person's gap when one shows, else what the page had before
/// (`fallback`), so the two never stand side by side
struct CASGapCard<Fallback: View>: View {
    @Environment(Store.self) private var store
    /// what the person said of each gap, by its id (CASAsk.Said), on this phone only
    @AppStorage(CASAsk.storeKey) private var saidJSON: String = ""
    @State private var asking: CASGap?
    let fallback: () -> Fallback
    init(@ViewBuilder fallback: @escaping () -> Fallback) { self.fallback = fallback }

    var said: [String: CASAsk.Said] { CASAsk.decode(saidJSON) }

    func tell(_ id: String, _ change: (inout CASAsk.Said) -> Void) {
        var all = said
        var s = all[id] ?? CASAsk.Said()
        change(&s)
        all[id] = s
        saidJSON = CASAsk.encode(all)
    }

    var body: some View {
        let today = store.snap.today
        let mine: [CASGap] = (store.snap.casGap ?? []).filter { store.who.id == "family" || $0.who == store.who.id }
        let now = said
        let shown: [(CASGap, CASAsk.Show)] = mine.compactMap { g in
            let s = CASAsk.show(kind: g.kind, said: now[g.id], today: today)
            return s == .hidden ? nil : (g, s)
        }
        if shown.isEmpty {
            fallback()
        } else {
            VStack(spacing: 10) {
                ForEach(shown, id: \.0.id) { pair in row(pair.0, pair.1) }
            }
            .sheet(item: $asking) { g in
                CASRequestSheet(gap: g, email: (g.to?.isEmpty == false ? g.to : nil) ?? store.live?.email ?? "") {
                    withAnimation(Motion.open) { tell(g.id) { $0.asked = store.snap.today } }
                }
            }
        }
    }

    @ViewBuilder func row(_ g: CASGap, _ show: CASAsk.Show) -> some View {
        let quiet: Bool = { if case .waiting = show { return true } else { return false } }()
        let to = g.to ?? store.live?.email ?? ""
        VStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .top, spacing: 12) {
                IconTile(symbol: show == .unlock ? "lock.doc.fill" : quiet ? "hourglass" : "doc.text.magnifyingglass",
                         color: show == .unlock ? Color.orange : Color.kosh)
                VStack(alignment: .leading, spacing: 3) {
                    Text(quiet ? "Your statement is on its way" : g.title)
                        .font(.body.weight(.semibold))
                    Text(CASAsk.line(show, why: g.why, to: to))
                        .font(.subheadline).foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                    if store.who.id == "family", g.who != "me", let n = store.snap.people.first(where: { $0.id == g.who })?.name {
                        Text(n).font(.caption.weight(.semibold)).foregroundStyle(.secondary)
                    }
                }
                Spacer(minLength: 0)
            }
            HStack(spacing: 10) {
                switch show {
                case .unlock:
                    Button { withAnimation(Motion.open) { store.portSub = .investments } } label: {
                        Label("Type its password", systemImage: "key.fill").font(.subheadline.weight(.semibold))
                    }
                    .buttonStyle(.borderedProminent).tint(Color.kosh)
                case .waiting:
                    Button { asking = g } label: { Text("Open the page again").font(.subheadline) }
                        .buttonStyle(.press)
                default:
                    Button { asking = g } label: {
                        Label(show == .ask ? "Ask for it" : "Ask again", systemImage: "envelope.arrow.triangle.branch").font(.subheadline.weight(.semibold))
                    }
                    .buttonStyle(.borderedProminent).tint(Color.kosh)
                }
                Spacer(minLength: 0)
                Button {
                    withAnimation(Motion.close) { tell(g.id) { $0.notNow = true } }
                } label: { Text(quiet ? "Hide" : "Not now").font(.subheadline).foregroundStyle(.secondary) }
                .buttonStyle(.press)
            }
        }
        .padding(14)
        .background(Color.surface, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        .transition(.opacity)
    }
}

/// the request page, inside kosh: which registrar, the person's email to copy, what the form asks, then the page itself
struct CASRequestSheet: View {
    @Environment(\.dismiss) private var dismiss
    let gap: CASGap
    let email: String
    let asked: () -> Void
    @State private var pick = CASRequest.pages.first?.id ?? ""
    @State private var open: CASOpenPage?
    @State private var copied = false

    var page: CASRequest.Page? { CASRequest.page(pick) }

    var body: some View {
        NavigationStack {
            List {
                Section {
                    Picker("Where", selection: $pick) {
                        ForEach(CASRequest.pages) { p in Text(p.name).tag(p.id) }
                    }
                    .pickerStyle(.segmented)
                    if let page { Text(page.covers).font(.subheadline).foregroundStyle(.secondary) }
                } footer: {
                    Text("Free, from the registrars that keep India’s mutual fund records. Any one of them is enough.")
                }
                if !email.isEmpty {
                    Section("Your email, as your funds have it") {
                        HStack {
                            Text(email).font(.body.monospaced()).lineLimit(1).truncationMode(.middle)
                            Spacer(minLength: 8)
                            Button {
                                Details.copy(email)
                                withAnimation(Motion.quick) { copied = true }
                            } label: {
                                Label(copied ? "Copied" : "Copy", systemImage: copied ? "checkmark" : "doc.on.doc").font(.subheadline)
                            }
                            .buttonStyle(.press)
                        }
                    }
                }
                if let page {
                    Section("On \(page.name)’s page") {
                        ForEach(Array(page.steps.enumerated()), id: \.offset) { i, s in
                            HStack(alignment: .firstTextBaseline, spacing: 10) {
                                Text("\(i + 1)").font(.subheadline.monospacedDigit().weight(.semibold)).foregroundStyle(Color.kosh)
                                Text(s).font(.subheadline).fixedSize(horizontal: false, vertical: true)
                            }
                        }
                    }
                    Section {
                        Button {
                            open = URL(string: page.url).map(CASOpenPage.init(url:))
                        } label: {
                            Label("Open \(page.name)’s page", systemImage: "safari").font(.body.weight(.semibold))
                        }
                        .buttonStyle(.press)
                        Button {
                            asked()
                            dismiss()
                        } label: {
                            Label("I’ve sent it", systemImage: "checkmark.circle").font(.body)
                        }
                        .buttonStyle(.press)
                    } footer: {
                        Text("You fill in and send the form yourself; kosh doesn’t see or keep what you type there. The statement comes to your mail, usually within a day, and kosh reads it. When it’s locked, kosh asks once for the password you chose.")
                    }
                }
            }
            .navigationTitle("Ask for your statement")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Close") { dismiss() } } }
            .sheet(item: $open) { p in SafariSheet(url: p.url).ignoresSafeArea() }
        }
    }
}

/// a page to open in the Safari sheet (a URL isn't Identifiable, and making it so for the whole app is not this file's call)
struct CASOpenPage: Identifiable { let url: URL; var id: String { url.absoluteString } }
