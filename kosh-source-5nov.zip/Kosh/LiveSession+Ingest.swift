import Foundation
import Observation
import UIKit
import Network

// MARK: - LiveSession: ingesting: one email read into a Reading, and a batch read side by side
// (split out of LiveSession+Reading.swift, 30 Oct 2026; its stored state stays in the class in LiveSession.swift)

extension LiveSession {
    func ingest(_ m: MailMsg, acct: String = "", tag: String = "") {
        guard let r = reading(m, acct: acct, tag: tag) else { return }
        // sealed on this phone, so new rules read it again without asking the inbox (MailVault)
        MailVault.put(m, id: r.id)
        // two reads running at once may both have listed it: kept once
        if records.last(where: { $0.id == r.id }) != nil { return }
        records.append(r)
    }

    /// A chunk of mail read off the main thread (the engine's calls take its own lock, one at a time), then filed
    /// here: the screens stay smooth through a year's mail, and the check for a mail read twice is one set per
    /// chunk rather than a look through every record per mail
    @MainActor

    func ingestAll(_ msgs: [MailMsg], acct: String, tag: String) async {
        guard !msgs.isEmpty else { return }
        let me = email, mode = checkMode
        await Interaction.yield(upTo: 3)
        let read: [(MailMsg, Reading)] = await Task.detached(priority: .utility) {
            LiveSession.readingsOf(msgs, acct: acct, tag: tag, me: me, checkMode: mode).compactMap { m, r in r.map { (m, $0) } }
        }.value
        var have: Set<String> = knownIDs
        for (m, r) in read {
            // sealed on this phone, so new rules read it again without asking the inbox (MailVault)
            MailVault.put(m, id: r.id)
            // two reads running at once may both have listed it: kept once
            guard have.insert(r.id).inserted else { continue }
            records.append(r)
        }
    }

    /// one mail as kosh files it: the rules' reading, and the attachment worth opening if any
    func reading(_ m: MailMsg, acct: String, tag: String) -> Reading? {
        Self.readingOf(m, acct: acct, tag: tag, me: email, checkMode: checkMode)
    }

    /// (every field the engine wrote is kept, in its place or whole in xtra: Reading.fromEngine; a mail kosh couldn't
    /// finish reading, stopped part-way or out of time, is kept as too long and not read again: ParseGuard)
    /// many mails read side by side, one reader each sender (Readers), in the order given
    static func readingsOf(_ msgs: [MailMsg], acct: String, tag: String, me: String, checkMode: String) -> [(MailMsg, Reading?)] {
        let n: Int = Readers.count
        var byReader: [[Int]] = Array(repeating: [], count: n)
        for (j, m) in msgs.enumerated() { byReader[Readers.index(from: m.from)].append(j) }
        let groups: [[Int]] = byReader
        let out = ReadingsBox(msgs.count)
        DispatchQueue.concurrentPerform(iterations: n) { i in
            var mine: [(Int, Reading?)] = []
            for j in groups[i] { mine.append((j, readingOf(msgs[j], acct: acct, tag: tag, me: me, checkMode: checkMode))) }
            out.put(mine)
        }
        let got: [Reading?] = out.all
        return msgs.enumerated().map { ($0.element, got[$0.offset]) }
    }

    static func readingOf(_ m: MailMsg, acct: String, tag: String, me email: String, checkMode: String) -> Reading? {
        let key: String = tag + m.id
        if ParseGuard.skip(key) { return ParseGuard.unreadable(m, id: key, acct: acct) }
        let engine: Engine = Readers.engine(for: m.from)   // (this sender's reader: Readers)
        guard let out = try? ParseGuard.parse(m, id: key, engine: engine), var r = Reading.fromEngine(out) else {
            return ParseGuard.skip(key) ? ParseGuard.unreadable(m, id: key, acct: acct) : nil
        }
        r.rp = ReadingPrint.mail   // read by today's code: not read again until that code changes (ReadingPrint)
        if !tag.isEmpty { r.id = tag + r.id }
        if !acct.isEmpty { r.acct = acct }
        // Claude's reading stays with the mail, so new rules read it again without asking Claude
        if let cl = m.cl { r.cl = cl; r.clv = ClaudeReads.version }
        // a statement attachment worth opening later: remember where to find it
        if let out = try? engine.call("docWantedJSON", [JSONText.encode(m)]),
           let want = try? JSONText.decode(DocWant.self, out), !want.kind.isEmpty,
           let att = want.file == "(mail)" ? Attach(id: "body", filename: "(mail)", mime: "text/html") : (m.attachments.first(where: { $0.filename == want.file }) ?? m.attachments.first(where: { $0.filename.lowercased().hasSuffix(".pdf") })) {
            r.doc = DocRef(kind: want.kind, msg: m.id, att: att.id, file: att.filename, acct: acct.isEmpty ? email : acct, from: m.from, hint: DocUnlock.hint(text: m.text, html: m.html), hinted: 2)
            // a shop's order whose amount is only in its invoices: every invoice in the mail is opened
            if want.kind == "order", let names = want.files {
                let more = m.attachments.filter { names.contains($0.filename) && $0.id != att.id }.map(\.id)
                if !more.isEmpty { r.doc?.more = more }
            }
        }
        // a mail Claude has read keeps nothing more: there is nothing left to check
        if m.cl != nil { return r }
        let keepHTML = m.text.trimmingCharacters(in: .whitespacesAndNewlines).count < 200
        // a reading the reader isn't sure of keeps the mail's words, for Claude to check
        let unsure = (r.evs ?? "").contains("\"unsure\":true")
        switch r.kind {
        case "noise":
            if unsure {
                r.text = String(m.text.prefix(6000))
                if keepHTML { r.html = String(m.html.prefix(40000)) }
            }
        case "unknown":
            r.text = String(m.text.prefix(6000))
            if keepHTML { r.html = String(m.html.prefix(40000)) }
        default:
            if checkMode != "off" {
                r.text = String(m.text.prefix(6000))
                if keepHTML { r.html = String(m.html.prefix(40000)) }
                r.check = Check(status: "pending", fields: [])
            }
        }
        return r
    }
}
