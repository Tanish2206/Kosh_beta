import SwiftUI
import UIKit
import Observation

// MARK: - The snapshot: what the engine builds for the screens (engine.js build → buildJSON), decoded as it comes

struct VoiceBit: Decodable, Hashable { let k: String; let t: String }

struct FcCat: Decodable, Hashable {
    let cat: String; let sofar: Double; let likely: Double; let usual: Double; let sym: String; let color: String
    /// a budget you set for it (0 when none), and what's still to go out of it this month
    var limit: Double? = nil; var committed: Double? = nil
}
/// something still to go out this month that will count as spending
struct Commitment: Decodable, Hashable, Identifiable { let name: String; let amt: Double; let date: String; var id: String { name + date } }

struct Forecast: Decodable, Equatable {
    let d: Int; let dim: Int; let left: Int
    let spent: Double; let likely: Double; let low: Double; let high: Double; let usual: Double; let budget: Double
    let actual: [Double]; let forecast: [Double?]; let lo: [Double?]; let hi: [Double?]
    let cats: [FcCat]
    /// left to spend: the budget (yours when own is true, else the usual month) less spent and committed (live mode)
    var own: Bool? = nil; var committed: Double? = nil; var remaining: Double? = nil; var commitments: [Commitment]? = nil
    /// how the forecast is made: everyday spending a day (payments up to everydayCap), and the bigger bills still due
    var daily: Double? = nil; var ahead: Double? = nil; var everydayCap: Double? = nil
}

struct MonthCat: Decodable, Hashable {
    let cat: String; let v: Double; let prev: Double; let sym: String; let color: String
}

struct MonthInfo: Decodable, Identifiable, Hashable {
    let m: String; let name: String; let short: String; let year: Int; let days: Int; let live: Bool
    let total: Double; let payments: Int; let cum: [Double]; let prev: String?; let prevTotal: Double
    let change: Double?; let lead: String; let cats: [MonthCat]
    /// what trips and events took this month (in the total, or left out of it when Everyday is on), by trip
    var trip: Double? = nil; var trips: [MonthTrip]? = nil
    /// each person's part of the month by the month's own rule (money back taken off), and of each kind of spending;
    /// cum: their own day-by-day line, as the month's cum is the household's (nil from a build before 30 Oct)
    struct Who: Decodable, Hashable { let o: String; let v: Double; let cats: [WhoCat]; var cum: [Double]? = nil }
    struct WhoCat: Decodable, Hashable { let cat: String; let v: Double }
    var who: [Who]? = nil
    /// the month the mail starts in, read from a day past the 1st (since: that day): shown, never a usual month
    var partial: Bool? = nil; var since: String? = nil
    var id: String { m }
}
struct MonthTrip: Decodable, Identifiable, Hashable { let id: String; let name: String; let v: Double }

/// a trip or event: what it cost, by kind of spend, by day, by month and by person; travel booked before it to offer
struct TripInfo: Decodable, Identifiable, Hashable {
    struct Cat: Decodable, Hashable, Identifiable { let cat: String; let v: Double; let sym: String; let color: String; var id: String { cat } }
    struct DayV: Decodable, Hashable, Identifiable { let d: String; let v: Double; var id: String { d } }
    struct MonthV: Decodable, Hashable, Identifiable { let m: String; let v: Double; var id: String { m } }
    struct WhoV: Decodable, Hashable, Identifiable { let o: String; let v: Double; var id: String { o } }
    let id: String; let name: String; let kind: String; let from: String; let to: String; let budget: Double
    let sym: String; let color: String; let auto: Bool; let who: [String]; let note: String
    /// now, soon, done, or open (no dates)
    let state: String; let days: Int
    let total: Double; let n: Int; let guesses: Int; let before: Double; let rx: Double
    let cats: [Cat]; let byDay: [DayV]; let months: [MonthV]; let people: [WhoV]; let maybe: [String]
    var tint: Color { Color(hex: color) }
    var isEvent: Bool { kind == "event" }
}

struct CatInfo: Decodable, Equatable { let color: String; let symbol: String; let kind: String; let subs: [String] }

/// one payee kosh files a certain way because you (or Claude) said so once
struct LearnedPayee: Decodable, Identifiable, Hashable {
    let key: String; let name: String; let c: String; let s: String; let n: String; let f: String; let by: String
    let ids: [String]; let count: Int; let d: String
    var id: String { key }
}

struct Txn: Decodable, Identifiable, Hashable {
    let id: String; let d: String; let t: String; var m: String; var a: Double; let card: String
    var c: String; var s: String; let k: String; let o: String; var f: String; var fs: Bool
    var n: String; var u: Bool; var g: Bool; let src: String; var sym: String; let sp: Bool
    /// what the card was charged, when this row is only part of it
    var full: Double? = nil
    /// a charge in another currency ("USD 20.00"); est: its rupee figure is kosh's estimate until the bank's or the statement's
    var fx: String? = nil; var est: Bool? = nil
    /// the app or store it went to ("Blinkit", "Amazon", "MakeMyTrip"), for Where you shop
    var pf: String? = nil
    /// a shopping payment's kind, what was bought (engine.js › whatWasBought): Clothing, Footwear, Accessories…; nil when
    /// nothing says. wkb: what said it (items, you, sub, shop)
    var wk: String? = nil; var wkb: String? = nil
    /// how much of it others owe you
    var shared: Double? = nil
    /// kept, but not counted as spending: why
    var ex: String? = nil
    /// looks like spending but isn't counted, and why: ex (you kept it out), unnamed, parked (a top-up, counted when
    /// spent), wallet (paid from a wallet, counted when it was loaded), chapter (a trip left out of monthly spending)
    var nc: String? = nil
    /// the charge this part was split out of
    var partOf: String? = nil
    /// what part of an order was something else (engine › whatWasBought): its share, where it goes, what it was
    /// an order paid partly from a wallet or a shop's credit: the wallets and their shares, the order's whole; on the
    /// wallet's own row, the card payment it went with
    struct WalletUse: Decodable, Hashable { let w: String; let a: Double }
    var wu: [WalletUse]? = nil; var ot: Double? = nil; var wf: String? = nil
    /// what this buy goes with: an earlier big purchase it names or is its maker's accessory for ("iPhone 16 Pro|2026-09-20")
    var gw: String? = nil
    /// a bill's connection and home, from its mail's own identifier ("UHBVN · Subscriber Id 6223430000 · Ambala")
    var bh: String? = nil
    struct Mix: Decodable, Hashable { let c: String; let g: Double; var s: String? = nil; var n: [String]? = nil; var all: Bool? = nil }
    var mix: Mix? = nil
    /// tagged like the payments to the same payee you tagged yourself
    var lr: Bool? = nil
    /// its kind is one you set (on it, or on a payee you tagged), not kosh's guess: what a payment fact says came from you
    /// (engine/21a-build-records.js, 21o-build-payfacts.js)
    var uc: Bool? = nil
    /// a tenant's rent: the floor's key ("<property id>|<floor's place>"); rtl, kosh's proposal from a credit you tagged
    /// from the same payer at about this sum (engine/21q-build-rent-tags.js)
    var rt: String? = nil; var rtl: Bool? = nil
    /// how it was paid (card, upi, transfer, auto, atm, wallet, bank, cash), and from which bank and account
    var md: String? = nil; var bk: String? = nil; var l4: String? = nil
    /// which way the money went through the account or card: in or out
    var dr: String? = nil
    /// money put into an investment (a SIP, a buy, a deposit booked): what the cash flow counts as invested, the engine's
    /// rule (21g). A redemption is k "invest" too, but money coming back, so it is never counted as put in
    var investedOut: Bool { k == "invest" && ex == nil && !sp && dr != "in" }
    /// the app it went through (CRED, a gateway): never the account itself. While bk is the app too, the account it
    /// left isn't known yet; fg, kosh's likely one (most of that app's earlier payments left it); pl4, the card it paid
    var via: String? = nil; var fg: Bool? = nil; var pl4: String? = nil
    /// (story-5nov) every other mail or SMS that told this payment (its twins, its receipt), the shop's own receipt (rc),
    /// and the statement mails whose lines answered for it (sm)
    var told: [String]? = nil; var rc: String? = nil; var sm: [String]? = nil
    /// the account it left, worked out from that bank's daily balance mails (its balance fell by exactly this)
    var fb: Bool? = nil
    /// counted in another month: the day it really happened
    var od: String? = nil
    /// a refund still to come back, and what has come back; on a credit, the payment it refunds
    var rx: Double? = nil; var refunded: Double? = nil; var refOf: String? = nil
    /// on a refund kosh couldn't match to a payment: the kind of spending it comes off, in the month it landed, and how
    /// much it took off (never more than that kind came to that month)
    var nt: String? = nil; var nta: Double? = nil
    /// the trip or event it's in, whether kosh put it there by its day, and that Everyday leaves it out of spending
    var tr: String? = nil; var trg: Bool? = nil; var ev: Bool? = nil
    /// a card's bill paid: the other side of the same money (the bank's debit for the card's "payment received")
    var pair: String? = nil
    /// the card's own side of a bill paid (its "payment received"): the same money as its pair, so it is listed once,
    /// as the payment, and kept for the card's page (Store.mirrors)
    var mr: Bool? = nil
    /// the UPI ID it went to or came from, and the payee it's learnt under (its UPI ID or its name): what makes
    /// "every payment to X" the same X
    var vpa: String? = nil; var lk: String? = nil
    /// on a credit: the shares owed to you it paid back (its ex says whose, and it isn't counted as income)
    var paysBack: [String]? = nil
    /// a bill paid: what it paid (engine billLoopBook, 3 Nov): biller, connection number and what it's called, the
    /// Bharat Connect and operator's references, the app's order, the UTR, the fee, the days it covers, the units used
    struct BillLine: Decodable, Hashable {
        var k: String? = nil; var bn: String? = nil; var no: String? = nil; var nol: String? = nil
        var ref: String? = nil; var oref: String? = nil; var ord: String? = nil; var utr: String? = nil; var fee: Double? = nil
        var from: String? = nil; var to: String? = nil; var units: Double? = nil; var unit: String? = nil
    }
    var bl: BillLine? = nil
    /// a bill paid, its loop: the app it went through, the card (its row in the stack, and last four) or biller it paid,
    /// the money it left, and whether the bank said so: st done (on, by; cid the bank's own line), wait (within two
    /// days), open (past two days, nothing yet), old (older, nothing in the mail); the app's order, UTR, ref, the day
    /// the app says the card was credited
    struct PayLoop: Decodable, Hashable {
        var pt: String? = nil; var card: String? = nil; var l4: String? = nil; var src: String? = nil
        var st: String = "old"; var on: String? = nil; var by: String? = nil; var cid: String? = nil
        var ord: String? = nil; var utr: String? = nil; var ref: String? = nil; var cr: String? = nil
    }
    var lp: PayLoop? = nil
    /// filed like the payment to the same payee you filed "just this one" (about the same sum): that payment's day
    var ls: String? = nil
}

/// a payee whose payments need a name: its payments (newest first), what they add up to, since when, its UPI ID, and
/// whether it looks like a person rather than a shop
struct PayeeGroup: Identifiable {
    let id: String
    let name: String
    let rows: [Txn]
    let total: Double
    let first: String
    let vpa: String?
    let person: Bool

    static let business = ["store", "stores", "mart", "traders", "trading", "enterprise", "enterprises", "pvt", "ltd", "limited", "llp", "shop", "foods", "food",
                           "medical", "medicals", "pharma", "pharmacy", "chemist", "kirana", "general", "agency", "agencies", "services", "service", "cafe", "restaurant",
                           "petroleum", "fuel", "filling", "hotel", "bakery", "sweets", "dairy", "electronics", "garments", "collection", "centre", "center",
                           "hospital", "clinic", "diagnostics", "india", "solutions", "industries", "associates", "brothers", "bros", "co", "company", "corp",
                           "and", "&", "mall", "bazaar", "bazar", "super", "fresh", "kitchen", "dhaba", "juice", "salon", "studio", "motors", "auto", "telecom"]

    /// two to four plain words with no shop word in them, or a UPI ID that's a phone number: a person
    static func looksLikePerson(_ name: String, vpa: String?) -> Bool {
        let v: String = (vpa ?? "").lowercased()
        if v.hasPrefix("paytmqr") || v.hasPrefix("q") && v.dropFirst().prefix(6).allSatisfy(\.isNumber) || v.contains("bharatpe") || v.contains(".rzp") || v.contains("@pos") { return false }
        let words: [String] = name.lowercased().split(whereSeparator: { !$0.isLetter && $0 != "&" }).map(String.init)
        if words.isEmpty || words.count > 4 { return false }
        if words.contains(where: { business.contains($0) }) { return false }
        if words.count >= 2 { return true }
        return v.split(separator: "@").first.map { $0.count == 10 && $0.allSatisfy(\.isNumber) } ?? false
    }
}

/// a change made to one payment that could go to every payment to its payee: its category ("c") or whom it's for
/// ("f"), the payee, how many other payments it has, and what the change was, in words
struct ApplyAsk: Identifiable, Equatable {
    let id = UUID()
    let tx: String; let field: String; let payee: String; let others: Int; let label: String
}
/// a change that can be taken back for a few seconds
struct UndoNote: Identifiable {
    let id = UUID()
    let text: String
    let undo: () -> Void
}

/// a refund you're waiting for, and how it stands: waiting, part (some back), late (past the day), back
struct RefundInfo: Decodable, Identifiable, Hashable {
    struct Credit: Decodable, Hashable {
        let id: String; let d: String; let a: Double; let m: String
        /// only the shop's word that it sent it, booked on the card when the bank said nothing (engine/21a)
        var shop: Bool? = nil
    }
    /// a mail that promised it (the reader's expect refund): when, how much, by when, for which order, the line read
    struct PromiseMail: Decodable, Hashable {
        let id: String; let d: String; let a: Double
        var by: String? = nil; var order: String? = nil; var q: String? = nil; var sent: Bool? = nil
    }
    /// the statement that covers the promised day and lacks the money (lateWhy "statement")
    struct LateStatement: Decodable, Hashable { let inst: String; let last4: String; let to: String }
    let id: String; let m: String; let d: String; let a: Double; let exp: Double; let back: Double
    let by: String; let note: String; let state: String; let credits: [Credit]; let o: String; let sym: String; let c: String; let manual: Bool
    /// who said it's owed: "you" (your mark), "mail" (the shop's promise), "credit" (a refund kosh set against it)
    var src: String? = nil
    /// how sure: "promised" (the shop says it will), "sent" (the shop says it sent it), "back" (the bank or a statement)
    var stage: String? = nil
    /// why it's late: "date" (your own day passed), "statement" (a statement covering the promised day lacks it)
    var lateWhy: String? = nil
    var stmt: LateStatement? = nil
    var mails: [PromiseMail]? = nil
    var order: String? = nil
    var left: Double { max(0, exp - back) }
}

/// one thing the household has to do, or that kosh is watching for it (assist.js, ASSISTANT.md §3): one per real-world
/// thing however many mails tell it, closed by itself when the evidence says it's done. No screen reads it yet.
struct ActionInfo: Decodable, Identifiable, Hashable {
    /// a mail (or a statement) it stands on: its day, the mail, who sent it, the step it told, the line read
    struct Ev: Decodable, Hashable {
        let d: String; let from: String; let step: String
        var mail: String? = nil; var q: String? = nil
    }
    /// what closed it, and when
    struct Closed: Decodable, Hashable { let what: String; var d: String? = nil; var mail: String? = nil }
    /// "refund|order:…", "due|month|day|name": the person's done, snoozed, dismissed are kept by it
    let id: String
    /// refund · due
    let kind: String
    let title: String; let why: String
    /// the day it is for
    let due: String
    /// now · soon · watch
    let ink: String
    /// open · closed · done · snoozed · dismissed
    let state: String
    let ev: [Ev]
    /// what one tap can do: got, paid, done, snooze, wrong
    let can: [String]
    /// the money at stake, the figure its own module shows (the refund's row, the calendar's item)
    var amt: Double? = nil
    /// that module's own id for it: the refund's row id, the calendar item's id
    var ref: String? = nil
    var closed: Closed? = nil
    /// snoozed until
    var until: String? = nil
    /// the money thread it belongs to (Threads.swift)
    var thread: String? = nil
    /// whose it is
    var owner: String? = nil
    /// a dispute's plain complaint note for the bank (never sent by kosh: the person sends it from their mail app)
    var note: String? = nil
}

/// The year's fees, from payments the ledger already counts once (engine/21m-build-savings.js): by kind and by account
/// or card, worst first, each row the payment (and its mail) it is.
struct FeeBook: Decodable, Hashable {
    struct Kind: Decodable, Hashable { let k: String; let label: String; let amt: Double; let n: Int }
    struct By: Decodable, Hashable { let acct: String; let amt: Double; let n: Int }
    struct Row: Decodable, Hashable {
        let id: String; let d: String; let a: Double
        /// gst · late · interest · forex · minbal · annual · bounce · convenience · other
        let k: String; let m: String; let acct: String
        var mail: String? = nil; var q: String? = nil; var o: String? = nil
    }
    /// a fee given back (reversed, waived, refunded)
    struct Back: Decodable, Hashable { let id: String; let d: String; let a: Double; let m: String; let acct: String }
    let from: String; let to: String; let total: Double; let n: Int
    let kinds: [Kind]; let by: [By]; let rows: [Row]
    var back: [Back]? = nil; var backTotal: Double? = nil
}

/// A card's annual fee as its mail printed it, the spend that waives it, spend in its fee year, and idle days.
struct CardFee: Decodable, Hashable {
    struct Said: Decodable, Hashable { let d: String; let mail: String; var q: String? = nil }
    struct Charged: Decodable, Hashable { let d: String; let a: Double; let id: String }
    let card: String; let bank: String; let last: String
    var owner: String? = nil
    /// the fee's day, only as a mail printed it
    var feeOn: String? = nil; var said: Said? = nil
    var fee: Double? = nil; var waive: Double? = nil
    var charged: Charged? = nil; var feeLast: Double? = nil
    var yearFrom: String? = nil; var spent: Double? = nil; var toWaive: Double? = nil
    var lastUsed: String? = nil; var idle: Int? = nil; var unused: Bool? = nil
}

/// One card charged the same sum by the same payee minutes apart, each by its own alert (never an echo of one payment).
struct DoubleCharge: Decodable, Hashable {
    struct Back: Decodable, Hashable { let d: String; let id: String }
    let id: String; let kind: String; let d: String; let a: Double; let m: String; let acct: String
    let ids: [String]; let times: [String]
    /// open · reversed
    let state: String
    let note: String
    var o: String? = nil; var back: Back? = nil
}

struct Need: Decodable, Identifiable, Hashable { let id: String; let title: String; let detail: String; let action: String; let sym: String }

struct FlowNode: Decodable, Identifiable, Hashable {
    let k: String; let l: String; let v: Double; let note: String; let color: String
    var id: String { k }
}

struct Flow: Decodable, Equatable { let ins: [FlowNode]; let outs: [FlowNode]; let insight: String; let warn: String; let tail: String; let blocked: String }

struct AgendaItem: Decodable, Identifiable, Hashable {
    let date: String?; let m: String; let kind: String; let name: String; let sub: String; let amt: Double
    let cat: String; let sym: String; var booked: Bool; let comm: String?; let lock: Bool
    /// paid because you said so (from its reminder, or a hold on its row), not because the bank's mail showed it
    var marked: Bool? = nil
    /// the bank account an auto-debit comes out of, when its mail or its last payment said (plan.js's low balance)
    var acct: String? = nil
    /// a free trial's reminder: the charge it turns into
    var trial: Bool? = nil
    /// a card bill paid in part: the statement's own figure and what went towards it (amt is what is still to pay)
    var bill: Double? = nil
    var part: Double? = nil
    /// the engine's own key for it (prof.paid is kept by this): month, day, name
    var id: String { m + "|" + (date ?? "any") + "|" + name }
}

struct SchedPoint: Decodable, Hashable { let m: String; let amt: Double }

struct Committee: Decodable, Identifiable, Hashable {
    let id: String; let name: String; let members: Int; let face: Double; let draw: String?; let net: Double; let pool: Double
    let paid: Int; let profit: Double; let pct: Double; let contributed: Double; let done: Bool; let now: Double; let drawIndex: Int
    let sched: [SchedPoint]; let outstanding: Double; let left: Int
    // the committee book (live mode): its kind, every month, and how it's paid
    var kind: String? = nil
    var rows: [CommRow]? = nil
    var commission: Double? = nil
    /// the day of the month it is paid (1–28)
    var day: Int? = nil
    var payeeName: String? = nil
    var linked: Bool? = nil
    var candidates: [CommCand]? = nil
    var taken: Bool? = nil
    var excluded: Bool? = nil
    /// whose it is (people of the household; none: the household's), and how kosh knows ("said", "paid", or "")
    var whose: [String]? = nil; var whoseWhy: String? = nil
    /// what you've taken out less what you've put in, so far; and how it should end
    var position: Double? = nil
    var endNet: Double? = nil
    var kindTitle: String { CommKind(rawValue: kind ?? "")?.title ?? "Committee" }
}

/// one month of a committee: what was (or will be) paid, against face value
struct CommRow: Decodable, Hashable, Identifiable {
    let m: String; let amt: Double; let face: Double
    /// paid (recorded, or a fixed instalment) · assumed (gone by, nothing recorded) · due (this month) · ahead
    let st: String
    let disc: Double; let pct: Double; let recv: Double
    /// who said what it cost: "you", "bank" (payments to the linked payee), or "" (not recorded)
    var src: String? = nil
    var id: String { m }
}
struct CommCand: Decodable, Hashable, Identifiable { let key: String; let name: String; let n: Int; let avg: Double; var id: String { key } }
/// all committees together in one month
struct CommMonth: Decodable, Hashable, Identifiable {
    let m: String; let out: Double; let recv: Double; let net: Double; let cum: Double
    let profit: Double; let pct: Double; let cumProfit: Double; let cumPct: Double; let ahead: Bool
    var id: String { m }
}

/// how a committee decides who takes the pool each month, which decides what each month costs
enum CommKind: String, CaseIterable, Identifiable {
    case auction, draw, fixed, custom
    var id: String { rawValue }
    var title: String {
        switch self {
        case .auction: return "Auction"
        case .draw: return "Lucky draw"
        case .fixed: return "Fixed turns"
        case .custom: return "Organiser's schedule"
        }
    }
    var line: String {
        switch self {
        case .auction: return "Members bid each month; the discount the winner gives up is shared, so everyone pays less than face value that month. What you save is what it earns you."
        case .draw: return "A draw picks who takes the pool. Everyone pays face value every month, so nothing is earned; it's saving, or an early loan if you're picked early."
        case .fixed: return "Turns are agreed in advance. Everyone pays face value every month."
        case .custom: return "The organiser sets what each month costs. Record each month's amount as you pay it."
        }
    }
}

struct Holding: Decodable, Identifiable, Hashable {
    let bank: String; let person: String; let type: String; let cls: String; let amt: Double; let rate: Double; let mat: String?; let rem: String
    /// the day it matures (yyyy-MM-dd), when its advice gives one; mat is the month alone (yyyy-MM)
    var matDay: String? = nil
    /// what was put in, when the statement says (0 when it doesn't)
    var cost: Double? = nil
    /// a security's ISIN, when its statement gave one
    var isin: String? = nil
    /// the day its figure is from (yyyy-MM-dd), and where it came from: cas, epf, manual…
    var asOf: String? = nil
    var via: String? = nil
    /// valued at the day's price: whose ("AMFI" or "NSE"), and what its statement said, and when
    var px: String? = nil
    var stAmt: Double? = nil
    var stAsOf: String? = nil
    /// what it has made a year, in percent (11.4), worked out from the dated money put in and taken out (a fixed
    /// deposit's: its rate, compounded quarterly); nil where kosh hasn't that money, or it spans under 30 days
    var xirr: Double? = nil
    /// a deposit kosh saw booked in the mail whose terms aren't read yet: "advice" (its advice hasn't come or isn't
    /// read), "locked" (its advice is a PDF that needs the holder's details to open)
    var pending: String? = nil
    /// the mails a holding kosh found on its own was read from (a deposit's debit, its advice), and its institution
    var src: [String]? = nil
    var inst: String? = nil
    /// moved since its statement by the trades and allotments mailed after it (engine.js rollForward): how many, the
    /// statement's day, the last move's; made: bought since the newest statement, a holding of the mail's alone
    struct Roll: Decodable, Hashable { var n: Int; var st: String; var last: String; var made: Bool? = nil }
    var roll: Roll? = nil
    /// units held now (a fund's or share's), when they moved since the statement
    var units: Double? = nil
    /// a deposit's place in snap.deposits (engine.js depositBook): its journey opens from the row
    var dep: String? = nil
    /// one you added: its id among your holdings (LiveSession.userHoldings), carried through the engine
    var uid: String? = nil
    /// (ppf-owner-4nov) a PPF's own key (inst|last4), the holder its paper names, and why it is whose it is:
    /// you (you said), named (its paper's holder), added (one you added), inbox (whose inbox it came to: a guess)
    var pk: String? = nil
    var holder: String? = nil
    var whoWhy: String? = nil
    /// how fresh its figure is (engine/21k-build-portfolio.js): read from (by: cas, statement, mail, advice, epf, you,
    /// bullion, insurer, interest) on day d; pd the day's price that values it now; ld the last trade mailed since its
    /// statement; old when read over 45 days ago (PortfolioViews.swift says it in words)
    struct Fresh: Decodable, Hashable {
        let by: String
        var d: String? = nil
        var pd: String? = nil
        var ld: String? = nil
        var old: Bool? = nil
    }
    var fresh: Fresh? = nil
    /// one row's own identity: yours by its id; the rest by what tells two apart at one bank for one person (the
    /// deposit's number is in its name, the rest in its note, ISIN, maturity and the mails it was read from)
    var id: String {
        if let uid { return "user|" + uid }
        let parts: [String] = [bank, person, type, rem, isin ?? "", mat ?? "", (src ?? []).joined(separator: ",")]
        return parts.joined(separator: "|")
    }
    var gain: Double? { (cost ?? 0) > 0 ? amt - cost! : nil }
}

/// when a kind's figures are from: d and lo the newest and oldest day of any; pd the newest price day and px whose
/// prices ("AMFI", "NSE", "NSE & AMFI"); n of `of` holdings at the day's price; st and sl the newest and oldest
/// statement day of the rest; via where they all came from (cas, epf…), when it's one place
struct KindAsOf: Decodable, Hashable {
    let d: String; let lo: String; let pd: String; let px: String; let n: Int; let of: Int; let st: String; let sl: String; let via: String
}
/// a yearly return over several holdings: the rate in percent, how many holdings' dated money it's from, and how many there are
struct HoldReturn: Decodable, Hashable { let r: Double; let n: Int; let of: Int }

/// what holdings are worth against what went into them, over the ones whose cost is known
struct Gains {
    let worth: Double; let cost: Double; let known: Int; let all: Int
    /// what all of them are worth, cost known or not
    let total: Double
    var gain: Double { worth - cost }
    var pct: Double { cost > 0 ? gain / cost : 0 }
    /// what was put in is known for most of the money (80% or more): only then is "put in" and "returns" the kind's own
    var covered: Bool { total > 0 && worth / total >= 0.8 }
    init(_ hs: [Holding]) {
        let k = hs.filter { ($0.cost ?? 0) > 0 }
        worth = k.reduce(0) { $0 + $1.amt }; cost = k.reduce(0) { $0 + ($1.cost ?? 0) }; known = k.count; all = hs.count
        total = hs.reduce(0) { $0 + $1.amt }
    }
    /// "+₹1.2 lakh · +14.2%"
    static func line(_ g: Double, _ pct: Double) -> String {
        (g >= 0 ? "+" : "−") + Fmt.words(abs(g)) + " · " + (pct >= 0 ? "+" : "−") + String(format: "%.1f%%", abs(pct) * 100)
    }
    /// "11.4% a year", "−2.3% a year", from a rate in percent
    static func yearly(_ pct: Double) -> String {
        (pct <= -0.05 ? "−" : "") + String(format: "%.1f%%", abs(pct)) + " a year"
    }
    /// "11.4% a year · over 3 of 11 funds", or just the rate when it's over all of them
    static func yearly(_ ret: HoldReturn, _ cls: String) -> String {
        if ret.n >= ret.of { return yearly(ret.r) }
        return yearly(ret.r) + " · over " + String(ret.n) + " of " + String(ret.of) + " " + noun(cls, ret.of)
    }
    /// what a kind's holdings are called, one or more
    static func noun(_ cls: String, _ n: Int) -> String {
        let one: Bool = n == 1
        switch cls {
        case "mf": return one ? "fund" : "funds"
        case "stk": return one ? "stock" : "stocks"
        case "dep": return one ? "deposit" : "deposits"
        case "ret": return one ? "account" : "accounts"
        default: return one ? "holding" : "holdings"
        }
    }
}

struct RollMonth: Decodable, Hashable, Identifiable {
    let m: String; let short: String; let amt: Double; var st: String
    var got: String? = nil; var due: String? = nil; var late: Int? = nil
    /// the credit kosh took for this month's rent: its id, who it came from, and how much
    var tx: String? = nil; var from: String? = nil; var fromAmt: Double? = nil
    /// rent you tagged on a payment's sheet: "yours" (you tagged it) or "learnt" (the same payer, about the sum you
    /// tagged), and the month's tagged credits; less than the rent: what came (part), on what day, and what's left
    var tag: String? = nil; var tags: [String]? = nil; var part: Double? = nil; var partOn: String? = nil; var left: Double? = nil
    var id: String { m }
}

struct PropUnit: Decodable, Identifiable, Hashable {
    let code: String; let label: String; let tenant: String; let rent: Double; let change: String; let renew: String
    let pays: String; let start: String; let months: Int; let end: String; let deposit: Double; let esc: String; let doc: String
    let registered: Bool; var roll: [RollMonth]
    var idx: Int? = nil; var status: String? = nil; var day: Int? = nil; var now: RollMonth? = nil
    /// the twelve months to this one (roll is this financial year's): what each property's rent log is made of
    var past: [RollMonth]? = nil
    /// the floor's key for a rent tag ("<property id>|<floor's place>"), its due day (0: none known) and how it's known
    /// ("agreed": the floor's own day; "usual": the middle day of the rents you tagged; ""), and how many credits are tagged
    var key: String? = nil; var dueDay: Int? = nil; var dueBy: String? = nil; var tagged: Int? = nil
    var id: String { code + label }
}

/// a payment on the ledger the Property tab points to: a property-tax receipt, or a credit called rent
struct PropPay: Decodable, Hashable, Identifiable { let id: String; let d: String; let a: Double; let m: String }

/// property tax paid in one financial year ("2026-27"): how much, in how many payments, and the last one's day
struct TaxYear: Decodable, Hashable, Identifiable {
    let fy: String; let paid: Double; let n: Int; let last: String
    var id: String { fy }
}

/// this financial year's property tax on one property. st: paid, part (some paid), due (the portal says so) or open
/// (nothing found yet); src: how it's known paid (mail, portal, marked). expect: the year's tax (from: set, the
/// figure on the portal or typed; last year, what was paid then). next and note: the day that matters while it isn't
/// paid (kind: rebate, the city's early-payment day; portal, its last day; year, the year's end)
struct TaxNow: Decodable, Hashable {
    let fy: String; let st: String; let src: String; let paid: Double; let n: Int; let expect: Double; let from: String
    let due: Double; let read: String; let next: String; let note: String; let kind: String; let last: String; let lastAmt: Double
}

/// one month of a property's rent: what was to come in, what came, and how it stands (in, part, late, due, none);
/// missed: how many of its floors' rents are late that month
struct RentLogMonth: Decodable, Hashable, Identifiable {
    let m: String; let short: String; let exp: Double; let got: Double; let st: String; let missed: Int
    var id: String { m }
}

/// a property's rent over the twelve months to this one: from and to (yyyy-MM) are the months with rent to collect
struct RentLog: Decodable, Hashable {
    let from: String; let to: String; let expected: Double; let received: Double; let missed: Int; let months: [RentLogMonth]
}

struct PropFlag: Decodable, Hashable { let level: String; let text: String }
struct PropTax: Decodable, Hashable { let property: Double; let fire: Double; let san: Double; let total: Double }

/// one reading of a property's dues off the state's portal
struct TaxSnap: Codable, Hashable { var d: String; var total: Double; var arrears: Double; var interest: Double; var demand: Double }

struct Prop: Decodable, Identifiable, Hashable {
    let pid: String; let name: String; let short: String; let type: String; let use: String
    var units: [PropUnit]; let older: Double; let demand: Double; let dev: Double; let flags: [PropFlag]
    let tax: PropTax; let note: String; let payableTill: String
    /// the property's own id in the beta (its PID can be empty or change)
    var uid: String?
    var photo: String?; var floors: Int?
    /// what the portal said was due, each day it was read
    var hist: [TaxSnap]?
    // set by the beta: the state's tax portal
    var state: String?; var city: String?; var portal: String?; var portalName: String?; var findBy: String?
    // read off the state's portal
    var owner: String?; var address: String?; var category: String?; var plotArea: String?; var covered: String?; var interest: Double?; var portalReadAt: String?
    var taxDue: Double?; var charge: String?
    /// what was last paid in tax, as you or the portal gave it
    var lastPaid: Double? = nil
    /// what the land is worth: the plot in sq yd at a rate per sq yd (yours, or one kosh looked up)
    var plotSqYd: Double? = nil; var landRate: Double? = nil; var landRateNote: String? = nil; var landRateAt: String? = nil; var worth: Double? = nil
    /// the property-tax payments placed on it (latest first), what was paid each year, and this year's
    var taxPays: [PropPay]? = nil; var taxYears: [TaxYear]? = nil; var taxNow: TaxNow? = nil
    /// its rent, month by month over the twelve months to this one
    var rentLog: RentLog? = nil
    /// whose it is (people of the household; none: the household's), and how kosh knows ("said", "portal", "rent", or "")
    var whose: [String]? = nil; var whoseWhy: String? = nil
    var id: String { pid }
}

struct PropEvent: Decodable, Identifiable, Hashable {
    let m: String; let when: String; let kind: String; let what: String; let detail: String; let place: String
    var id: String { m + what }
}

struct PropertyBook: Decodable, Equatable {
    let fy: String; let rent: Double; let tax: Double; let arrears: Double; let due: Double; var props: [Prop]; let events: [PropEvent]; var worth: Double? = nil
    /// property-tax payments that fit no property, and credits called rent that no floor took (the last twelve months)
    var taxLoose: [PropPay]? = nil; var rentLoose: [PropPay]? = nil
    /// each person's part of the book: the properties in their name, a joint one at an equal share
    var byWho: [String: PropShare]? = nil
}

/// one person's part of the property book (a joint property at an equal share)
struct PropShare: Decodable, Hashable { let rent: Double; let tax: Double; let arrears: Double; let worth: Double; let n: Int }

struct Lent: Decodable, Identifiable, Hashable { let amount: Double; let date: String; let note: String; var id: String { date + note } }

struct Dup: Decodable, Hashable {
    let ids: [String]; let amount: Double; let name: String
    var key: String { ids.joined(separator: "|") }
}

/// one thing kosh noticed (agent.js watch): found by rules on the ledger, never by a model
struct WatchItem: Decodable, Identifiable, Hashable {
    let id: String; let kind: String
    /// 3 act now, 2 worth a look, 1 good to know
    let sev: Int
    let title: String; let detail: String
    var amt: Double = 0; var date: String = ""
    /// the payments behind it
    var rows: [String] = []
    var sym: String = "sparkles"
    /// a question that takes it further, for Ask kosh
    var ask: String = ""
    /// the subscriptions or trials behind it, each with how to cancel it (plan.js; Plan.swift)
    var reps: [String] = []
    enum CodingKeys: String, CodingKey { case id, kind, sev, title, detail, amt, date, rows, sym, ask, reps }
    init(from d: Decoder) throws {
        let c = try d.container(keyedBy: CodingKeys.self)
        id = try c.decode(String.self, forKey: .id); kind = try c.decode(String.self, forKey: .kind)
        sev = (try? c.decode(Int.self, forKey: .sev)) ?? 1
        title = try c.decode(String.self, forKey: .title); detail = (try? c.decode(String.self, forKey: .detail)) ?? ""
        amt = (try? c.decode(Double.self, forKey: .amt)) ?? 0; date = (try? c.decode(String.self, forKey: .date)) ?? ""
        rows = (try? c.decode([String].self, forKey: .rows)) ?? []; sym = (try? c.decode(String.self, forKey: .sym)) ?? "sparkles"
        ask = (try? c.decode(String.self, forKey: .ask)) ?? ""
        reps = (try? c.decode([String].self, forKey: .reps)) ?? []
    }
}

/// Retirement: EPF, PPF and NPS as one build works them out (engine/21l-build-retirement.js). Every figure here is
/// one a paper or a page stated, with the day it was stated on. The one sum kosh makes itself — the interest accrued
/// since the EPFO last credited any (`epf.accrued`, `mine: true`) — is in no total and in no net worth.
struct RetirementBook: Decodable, Hashable {
    let today: String
    /// what the three come to, as the papers and pages say them (the same money net worth counts)
    let total: Double
    var epf: EPF? = nil
    var ppf: PPF? = nil
    var nps: NPS? = nil
    var other: Other? = nil
    struct Other: Decodable, Hashable { let total: Double; let n: Int }

    struct EPF: Decodable, Hashable {
        let total: Double
        /// the sentence that says why a passbook months old is the newest there is
        let why: String
        var uan: String? = nil
        /// the newest day any job's passbook closes on, and how many days ago that is
        var asOf: String? = nil; var days: Int? = nil; var old: Bool? = nil
        /// the pension (EPS) share across the jobs that count: beside the money, never inside it
        var pension: Double = 0
        var lastMonth: String? = nil
        var jobs: [Job] = []
        /// the member IDs of accounts left behind that still hold money
        var left: [String] = []
        var since: Since? = nil
        var missing: [Missing]? = nil
        var years: [Year]? = nil
        var accrued: Accrued? = nil
        /// what went in each wage month off the passbook, your share and your employer's, and the year's interest on
        /// its March (engine/21u-build-epf-months.js): a month with no row is absent, never a zero kosh filled in
        var months: [Month]? = nil
        struct Month: Decodable, Hashable, Identifiable { let m: String; let ee: Double; let er: Double; var int: Double? = nil; var id: String { m } }
        /// some jobs under the UAN have no figure yet: the total is `read` jobs of `of`, never the whole
        struct Partial: Decodable, Hashable { let read: Int; let of: Int }
        var partial: Partial? = nil

        /// one job under the UAN. `counted`: its figure is in the total (an account whose money has moved into a
        /// newer one keeps its row and counts nothing); `unread`: kosh has no figure for it yet.
        struct Job: Decodable, Hashable, Identifiable {
            let id: String
            let name: String
            let amt: Double; let employee: Double; let employer: Double; let pension: Double
            let months: Int
            var book: Bool? = nil
            var joined: String? = nil; var left: String? = nil
            var lastMonth: String? = nil; var firstMonth: String? = nil
            var asOf: String? = nil; var days: Int? = nil; var old: Bool? = nil
            var movedTo: String? = nil
            var counted: Bool = false
            var unread: Bool? = nil
        }
        /// what has gone in since the passbook's last row, off the payslips: your own share, the only share a
        /// payslip states (`mine` is false — these are figures a paper printed, not kosh's sum)
        struct Since: Decodable, Hashable { let months: Int; let from: String; let to: String; let employee: Double; let mine: Bool }
        /// a month a payslip says PF left your pay with no row for it in the passbook that covers that month
        struct Missing: Decodable, Hashable { let month: String; let employee: Double; let employer: String }
        struct Year: Decodable, Hashable, Identifiable { let fy: String; let saved: Double; let interest: Double; let months: Int; var id: String { fy } }
        /// kosh's own sum: the balance at the EPFO's declared rate for the days since it last credited any
        struct Accrued: Decodable, Hashable {
            let mine: Bool; let amt: Double; let rate: Double; let from: String; let days: Int
            let fy: String; let of: Double; let note: String
        }
    }

    struct PPF: Decodable, Hashable {
        let total: Double; let accounts: Int
        var asOf: String? = nil; var days: Int? = nil; var old: Bool? = nil
        let year: Year
        /// (ppf-owner-4nov) each account on its own, and the ones closed or paid out (in no total)
        var rows: [Row]? = nil
        var closed: [Shut]? = nil
        struct Row: Decodable, Hashable, Identifiable {
            let id: String; let bank: String; let owner: String; let why: String; let amt: Double; let year: Mine
            var holder: String? = nil; var asOf: String? = nil; var rate: Double? = nil; var mat: String? = nil
            var rem: String? = nil; var via: String? = nil; var uid: String? = nil; var pays: [String]? = nil
        }
        struct Mine: Decodable, Hashable { let paid: Double; let n: Int; let cap: Double; let left: Double; let over: Bool }
        struct Shut: Decodable, Hashable, Identifiable {
            let id: String; let bank: String; let owner: String; let amt: Double; let by: String
            var holder: String? = nil; var asOf: String? = nil; var on: String? = nil
        }
        /// this financial year against the ₹1.5L one account may take, from the payments already filed
        struct Year: Decodable, Hashable { let fy: String; let from: String; let to: String; let paid: Double; let n: Int; let cap: Double; let left: Double; let over: Bool }
    }

    struct NPS: Decodable, Hashable {
        let total: Double
        var tier1: Tier? = nil; var tier2: Tier? = nil
        /// a statement that named no tier: its figure, said as one account rather than put in either
        var untiered: Double? = nil
        struct Tier: Decodable, Hashable { let amt: Double; let cost: Double; var navAsOf: String? = nil; var days: Int? = nil; var old: Bool? = nil }
    }
}

/// one person's details with one institution, in one category (bank, card, invest, insurance, loan, tax, identity,
/// contact): each detail with how many mails printed it, the first and last of them, and those mails (src)
struct FactGroup: Decodable, Hashable {
    let who: String
    let inst: String
    let cat: String
    let items: [FactItem]
}
struct FactItem: Decodable, Hashable {
    let k: String
    let label: String
    let v: String
    var masked: Bool? = nil
    /// the instrument it belongs to, by its own last four: the account for an account number, the card for a card
    /// number, the account an IFSC, MICR or branch was printed for (only where the bank has one account)
    var last4: String? = nil
    /// the kind of account the bank printed beside its number ("savings", "current", "deposit"…), absent when it
    /// printed none: never guessed
    var sub: String? = nil
    /// false on an account or card number kosh has no such account for at that bank, or whose digits fit several of
    /// them: printed, but it can't say which account it is
    var ok: Bool? = nil
    var first: String? = nil
    var last: String? = nil
    var n: Int? = nil
    var src: [String]? = nil
}

struct PersonInfo: Codable, Identifiable, Hashable { let id: String; let name: String; let full: String; let rel: String; let color: String }

struct Account: Decodable, Identifiable, Hashable {
    let id: String; let bank: String; let name: String; let last: String; let kind: String
    let balance: Double?; let asOf: String; let count: Int; let month: Double; let last30: Double; let lastUsed: String
    let owner: String; let color: String
    /// how the balance was worked out: the last one kosh was told (v, when, from an alert, a statement or
    /// you), and the payments in and out since (n of them, net) that carry it to now
    var bal: BalInfo? = nil
    /// every row this account's payments are filed under (an alert that printed fewer digits joins it)
    var keys: [String]? = nil
    /// a wallet: the Gmail its mail comes to (the login it belongs to), and what it's mostly used for
    var inbox: String? = nil; var top: String? = nil
    /// where the mail showed this account (alerts, balance, statement, bill, mail) and when it last did
    var seen: String? = nil; var lastSeen: String? = nil
    /// money held in it for an IPO application (ASBA), still yours and counted in net worth beside the balance the bank
    /// calls available, and what for: each application's name, amount and the day it was held
    struct Held: Decodable, Hashable { let name: String; let amt: Double; let on: String }
    var held: Double? = nil; var heldFor: [Held]? = nil
    /// the account's debit cards, by their last four (a debit card is the account's card, never a credit card row)
    var debit: [String]? = nil
    /// (dcard-4nov) the debit cards placed on this account as kosh's best guess (its bank has several of your accounts)
    var debitGuess: [String]? = nil
    /// "debit card ••1234", or "" when the mail named none
    var debitWords: String {
        let d: [String] = debit ?? []
        if d.isEmpty { return "" }
        return (d.count == 1 ? "debit card ••" : "debit cards ••") + d.joined(separator: ", ••")
    }
    /// the other ways its mail printed it ("821" for ••4821); whose half of a split account this is; the holders
    /// of a joint account (owner "family"); the name you gave it
    var alias: [String]? = nil; var tag: String? = nil; var joint: [String]? = nil; var nick: String? = nil
    /// the kind of account the bank itself printed beside its number ("savings", "current", "salary", "nre", "nro",
    /// "deposit", "od", "cc"), nil when no mail ever printed one: never guessed from the bank's name
    var atype: String? = nil
    /// a debit card whose account kosh can't tell yet: the row is the card's (debit has its digits)
    var dcard: Bool? = nil
    /// (quiet-4nov) no money has moved through it in six months: the day it last did ("long ago" when never seen)
    var quiet: String? = nil
    /// (sweep-5nov) money over a limit moves from it into a linked deposit and back (its statements show the sweeps)
    var sweep: Bool? = nil
    /// an account its bank's own mail proves (it was opened, a debit card of it activated) whose number no mail has
    /// printed yet: the row stands for the bank's account until a statement, alert or balance prints the digits
    var pending: Bool? = nil
    /// where its balances didn't square with its payments: between two balances, the money no payment explains
    var gaps: [BalGap]? = nil
    /// an account with a bank abroad: its currency ("AED"), and what it last held in it, as of when (its own alerts);
    /// it has no rupee balance, so no rupee total counts it
    var ccy: String? = nil; var fbal: Double? = nil; var fasOf: String? = nil
    var isDebitCardOnly: Bool { dcard == true }
    /// an account a family business holds (its current account): its money is the business's, not household savings
    var biz: Bool? = nil
    /// "AED 1,67,393", or nil for a rupee account
    var foreignFigure: String? { guard let c = ccy, let v = fbal else { return nil }; return c + " " + Fmt.inr(v) }
}
/// how a balance is known: the last one told (v, when, from an alert, a daily note, a statement or you), the payments
/// since that carry it to now (n, net); and the check of every balance against the payments between: check is "ok"
/// (the latest pair adds up), "gap" (it doesn't: shown as told, not carried), "one" (nothing yet to check it against);
/// ok and bad count the pairs that add up and those that don't; stale: too old to carry forward; month: the statement's
struct BalInfo: Decodable, Hashable {
    let v: Double; let at: String; let src: String; let n: Int; let net: Double
    var check: String? = nil; var ok: Int? = nil; var bad: Int? = nil; var stale: Bool? = nil; var month: String? = nil
    /// the account's newest statement came after this balance, and kosh couldn't read its closing balance: that
    /// statement's month ("2026-10") and the day it came
    var behind: String? = nil; var behindSent: String? = nil
}
/// between two of an account's balances (from, to), what no payment kosh has explains (amt: + more came in, − more left)
struct BalGap: Decodable, Hashable { let from: String; let to: String; let amt: Double }
/// a bank account only someone else's mail names (a shop, a payment app): yours? (n payments filed under it)
struct AcctMaybe: Decodable, Hashable, Identifiable { let key: String; let bank: String; let last: String; let n: Int; let why: String; var lastUsed: String? = nil; var id: String { key } }
/// payments at a bank whose account kosh can't tell (the digits fit two of its accounts, or none)
/// payments (or statements) kosh couldn't put under one account at a bank: why ("digits" fit several accounts, "none"
/// printed, a "statement" without digits), the bank's accounts to choose from, and the mails (ids) or statements (srcs)
struct AcctUnplaced: Decodable, Hashable {
    let bank: String; let n: Int
    var why: String? = nil
    var options: [String]? = nil
    var ids: [String]? = nil
    var srcs: [String]? = nil
}
/// a name the household's mail is written to that is no one in the household yet, and what's filed as theirs meanwhile
struct NameGroup: Codable, Hashable { let id: String; let full: String }
struct PersonToConfirm: Decodable, Hashable, Identifiable { let id: String; let name: String; let full: String; let mails: Int; let accounts: Int; let cards: Int; let wallets: Int }

/// a bank's or card's newest statement in the mail, and where it stands
struct StmtStatus: Decodable, Identifiable, Hashable {
    struct Part: Decodable, Hashable { let k: String; let label: String; let note: String }
    struct Close: Decodable, Hashable { let last4: String; let v: Double; let d: String }
    let id: String; let kind: String; let inst: String; let name: String; let sent: String
    let state: String; let note: String; let hint: String; let parts: [Part]; let example: String
    let domain: String; let subject: String; let owner: String; let closes: [Close]
    /// its mail printed nothing to pay (total due ₹0): locked, it waits quietly (no nag, last in the list)
    var nothingDue: Bool? = nil
    /// (where-3nov) where this institution prints the detail its password needs ("in the HSBC India app › Statements")
    var findAt: String? = nil
}

struct CardInfo: Decodable, Identifiable, Hashable {
    let id: String; let bank: String; let name: String; let last: String; let top: String
    let count: Int; let month: Double; let last30: Double; let lastUsed: String; let owner: String; let color: String
    /// the card's own name (Regalia, Magnus…) and network, when its mail says them
    var product: String? = nil; var network: String? = nil
    /// where the mail showed this card: its strongest source (alerts, statement, bill, payment, mail), all of them,
    /// and when it last did. A card known only from its statement or a CRED bill has a row with no spends
    var seen: String? = nil; var sources: [String]? = nil; var lastSeen: String? = nil
    /// its latest statement: total due, minimum due, due date, and the day it came
    var due: Double? = nil; var minDue: Double? = nil; var dueDate: String? = nil; var stmtOn: String? = nil
    /// what went towards its latest bill since the statement (every payment and credit, once each; without a
    /// statement, the latest payment), and the day of the last of them
    var paid: Double? = nil; var paidOn: String? = nil
    /// who says its bill is paid when no payment kosh saw does: "issuer" (its balance update counted the credits since the
    /// statement, as of paidOn) or "you" (you marked it); billMark: the bill's own key, the same as its calendar line's
    /// (prof.paid holds a mark by it, so Mark paid works on a late bill whose line has gone)
    var paidSaid: String? = nil; var billMark: String? = nil
    /// nothing has come from it in 90 days (no mail of any kind, no spend): the day of the last of it. Shown folded away
    /// under Old cards; nothing counted from it changes
    var old: String? = nil
    /// in credit on its latest statement ("Total Amount Due 1,250.00 Cr"), or by its issuer's own mail ("excess balance
    /// of ₹X", creditSaid "mail"): what the card owes you, and as of which day
    var credit: Double? = nil; var creditOn: String? = nil; var creditSaid: String? = nil
    /// its bill comes with another number of the same card (reissued, or an add-on): that card's last four, whose row
    /// carries the bill
    var sharesBill: String? = nil
    /// a card with a bank abroad: its currency ("AED"); its spends are in that currency, never in rupee totals
    var ccy: String? = nil
    /// its credit limit (limitSaid: "alert", "statement" or "you") and what was left of it on availOn, as the latest
    /// alert or statement printed it; limitAll: the issuer's figures are for all your cards with it together
    var limit: Double? = nil; var limitOn: String? = nil; var limitSaid: String? = nil
    var avail: Double? = nil; var availOn: String? = nil; var limitAll: Bool? = nil
    /// its latest bill payments, newest first, and whether the bank confirmed each (Txn.PayLoop's st, on)
    struct Pay: Decodable, Hashable { let id: String; let d: String; let a: Double; let st: String; var pt: String? = nil; var src: String? = nil; var on: String? = nil }
    var pays: [Pay]? = nil
}

struct CashInfo: Decodable, Equatable { let month: Double; let last30: Double; let count: Int; let lastUsed: String }

struct Loan: Decodable, Identifiable, Hashable {
    let id: String; let name: String; let bank: String; let emi: Double; let day: Int; let paidMonths: Int
    let lastPaid: String; let from: String; let outstanding: Double?; let rate: Double?; let active: Bool; let note: String
    /// what's owed is kosh's estimate (its mail tells only the EMI); the day a loan falls due in one go (a gold loan's term)
    var est: Bool? = nil; var due: String? = nil
    /// a card purchase on EMIs: how many in all, and how many are still to be billed
    var n: Int? = nil; var left: Int? = nil
    /// whose loan: the one person its mail names, else whose inbox it came to (one you added is yours)
    var owner: String? = nil
}

struct Policy: Decodable, Identifiable, Hashable {
    var model: String? = nil   // a motor policy's vehicle, as its mail names it (fb 1 Nov)
    let id: String; let insurer: String; let type: String; let premium: Double; let lastPaid: String; let nextDue: String
    let via: String; let owner: String; let source: String; let missing: [String]; let note: String
    // read off the policy schedule, when there was one
    var cover: Double?; var policyNo: String?; var plan: String?; var holder: String?; var insured: String?; var nominee: String?
    var frequency: String?; var start: String?; var end: String?; var term: Int?; var ppt: Int?
    /// what "not mine" remembers it by: the policy number, or the insurer and type
    var key: String?
    /// its course: premiums paid and left, what's in, when paying ends and when it ends, what it earns, one word on it
    var maturity: Double? = nil; var fundValue: Double? = nil; var fundAsOf: String? = nil
    var paidN: Int? = nil; var totalN: Int? = nil; var leftN: Int? = nil; var paidIn: Double? = nil
    var payEnd: String? = nil; var endDate: String? = nil; var xirr: Double? = nil; var verdict: String? = nil; var verdictWhy: String? = nil
    /// the kind of cover: Health, Top-up, Term, ULIP, Endowment, Savings, Money back, Pension, Whole life, Life, Car, Two-wheeler, Vehicle, Home, Travel, Accident, Other
    var kind: String?
    /// where it stands today: active, due, overdue (past due, in its grace period), paidup, lapsed, expired, renewed,
    /// matured, ended (you said so); why, in a sentence; ended: it no longer runs (the archive)
    var status: String? = nil
    var statusWhy: String? = nil
    var ended: Bool? = nil
    /// IRDAI's product code, and whether it says unit-linked; the bonus accrued, for a traditional plan
    var uin: String? = nil
    var linked: Bool? = nil
    var bonus: Double? = nil
    /// its claims, each at its latest word: registered, query, approved, settled, rejected
    struct Claim: Decodable, Hashable { var no: String; var status: String; var amt: Double; var on: String; var from: String }
    var claims: [Claim]? = nil
    /// the premium is each instalment; perYear is the year of them (nothing a year after a single premium). covers: whom
    /// it insures, each by their id or, for someone kosh doesn't know yet, by name; ownerNew: its owner is such a someone
    var perYear: Double? = nil
    var covers: [String]? = nil
    var ownerNew: Bool? = nil
    /// what it's missing (premium, cover, due date) and where that would be: not in its mail, in its PDF that came
    /// locked, in a PDF not opened yet (checks.js)
    struct Gap: Decodable, Hashable { var what: String; var at: String }
    var gaps: [Gap]? = nil
    /// what you typed for it, filled in where its mail and papers said nothing (cover, premium, frequency, nominee, policyNo)
    var filled: [String]? = nil
    /// a motor policy's vehicle by its registration ("MH01AB1234"), its cover (Comprehensive, Third party) and the
    /// add-ons its plan or paper names; years: cover bought for two or three years at once
    var vehicle: String? = nil
    var coverType: String? = nil
    var addOns: [String]? = nil
    var years: Int? = nil
    /// its missing cover or premium is in its policy paper, which came locked (engine.js › insuranceBook): what the
    /// mail told shows, and the rest once the paper opens
    var paperLocked: Bool? = nil
    /// for its page (engine/21f): the latest premium paid from an account or card kosh can name (its bank, last four,
    /// whose, the day) and whether that payment was an auto-debit; the same premiums in a fixed deposit at a stated
    /// rate, to the day it matures; the mails and papers that told of it, newest first (k: paper, paper-locked, issued,
    /// receipt, notice, statement, claim, lapsed, matured, debitfailed, mail)
    struct PayFrom: Decodable, Hashable { var bk: String; var l4: String? = nil; var o: String? = nil; var on: String }
    var payFrom: PayFrom? = nil
    var auto: Bool? = nil
    struct FD: Decodable, Hashable { var rate: Double; var v: Double }
    var fd: FD? = nil
    struct Mail: Decodable, Hashable { var id: String; var on: String; var k: String; var pdf: Bool? = nil }
    /// what its latest receipt says left the account, tax and all, when that is more than the premium
    var gross: Double? = nil
    var mails: [Mail]? = nil
    var isEnded: Bool { ended == true }
    /// what it costs a year
    var yearly: Double {
        if let y = perYear { return y }
        let step = PremiumPlan.step(self)
        return step == 0 ? 0 : premium * 12 / Double(step)
    }
    /// how often its premium comes, after the amount: "a month", "a quarter", "every six months", "once", "a year"
    var premiumEvery: String {
        switch PremiumPlan.step(self) {
        case 1: return "a month"
        case 3: return "a quarter"
        case 6: return "every six months"
        case 0: return "once"
        default: return "a year"
        }
    }
}

/// one vehicle and its motor cover (engine.js › insuranceBook): its registration ("" while kosh can't name it), Car,
/// Two-wheeler or Vehicle, the current policy and the earlier ones (newest first), and where it stands: covered, due
/// (renews within 30 days), lapsed (its cover has ended: motor has no grace period)
struct VehicleInfo: Decodable, Identifiable, Hashable {
    let id: String; let reg: String; let kind: String; let insurer: String; let owner: String
    let policy: String; let history: [String]; let status: String
    var idv: Double? = nil; var premium: Double? = nil; var renews: String? = nil; var days: Int? = nil
    var why: String? = nil; var coverType: String? = nil; var addOns: [String]? = nil
    /// its make and model, as its policy's mail names it ("Triumph Scrambler 400 X")
    var model: String? = nil
}
/// one person's health cover: the sum insured of every running health policy that covers them (a floater's whole sum
/// for each member), which policies, how many of them are shared (floaters) and how many have no cover known yet.
/// name: someone only a policy names, not yet in the household
struct HealthPerson: Decodable, Identifiable, Hashable {
    let id: String; let cover: Double; let policies: [String]
    var name: String? = nil; var shared: Int? = nil; var unknown: Int? = nil
    /// no policy kosh can see, and you said their cover is held where kosh can't see it (an employer's group cover)
    var elsewhere: Bool? = nil
}
/// one premium or renewal in the next twelve months (engine.js › insuranceBook › premAhead): its policy, its day, how
/// much, whose, and for one of ₹25,000 or more, what to put aside each month from now so it's there on the day
struct PremAhead: Decodable, Identifiable, Hashable {
    let policy: String; let insurer: String; let name: String; let kind: String; let date: String; let amt: Double; let owner: String
    var perMonth: Double? = nil
    /// its day is known and its premium isn't (amt is 0): "locked", in its locked paper; "missing", in no mail or paper
    var noAmt: String? = nil
    var id: String { policy + "|" + date }
}
/// what kosh found and can't fill in, with the one thing that would fill it. why: locked (a paper that a password
/// opens), payments (paid to an insurer, no policy mail), missing (not in its mail), unreadable, unread
struct LookItem: Decodable, Identifiable, Hashable {
    let id: String; let why: String; let text: String
    var insurer: String? = nil; var policy: String? = nil; var key: String? = nil; var owner: String? = nil
    var kind: String? = nil; var what: [String]? = nil; var amt: Double? = nil; var n: Int? = nil
}

struct Recurring: Decodable, Identifiable, Hashable {
    let id: String; let name: String; let cat: String; let sym: String; let amount: Double; let date: String; let cadence: String; let kind: String
    /// it costs more than its first charge (by this much, from that); it hasn't come for two months (last seen)
    var rise: Double? = nil; var riseFrom: Double? = nil; var lapsed: String? = nil
    /// its sub-category, when it last went, how it was paid then, and how many times it has come
    var sub: String? = nil; var last: String? = nil; var via: String? = nil; var seen: Int? = nil
    /// its cycle in months (1, 3, 6 or 12), whose money it is, every payment it's made of, and the day you said you
    /// cancelled it
    var per: Int? = nil; var o: String? = nil; var ids: [String]? = nil; var gone: String? = nil
    /// what it comes to in a month: a yearly ₹1,200 is ₹100
    var monthly: Double { amount / Double(max(1, per ?? 1)) }
}
/// a repeat you said isn't one
struct RepeatOff: Decodable, Identifiable, Hashable { let id: String; let name: String; let why: String }
/// one statement against the alerts: lines read, matched to an alert, names filled in, added (the alerts missed them),
/// and payments to the card left out (the bank side has them)
struct Recon: Decodable, Identifiable, Hashable {
    let src: String; let inst: String; let instr: String; let last4: String
    var from: String? = nil; var to: String? = nil; var sent: String? = nil
    let lines: Int; let matched: Int; let filled: Int; let added: Int; let skipped: Int
    var owner: String? = nil
    /// whether its lines added up to its own balances or summary, and the lines kept out because they didn't
    var ok: Bool? = nil; var note: String? = nil; var held: Int? = nil
    /// the other way round: payments kosh counts on this card or account in the statement's period that it doesn't have
    var extra: Int? = nil; var extras: [ReconExtra]? = nil
    var id: String { src }
}
struct Health: Decodable, Hashable {
    struct Held: Decodable, Hashable { let what: String; let title: String; var amt: Double? = nil; let why: String }
    let held: [Held]; let n: Int
}
/// a payment kosh counts that the statement doesn't have: "twice" (another payment of the amount matched a line) or "absent"
struct ReconExtra: Decodable, Identifiable, Hashable {
    let id: String; let d: String; let a: Double; let dir: String; let m: String; let why: String
}
/// one month's cash flow: in, spent, invested, kept (and kept as a share of in)
struct CashMonth: Decodable, Identifiable, Hashable {
    let m: String; let inn: Double; let out: Double; let inv: Double; let kept: Double; let rate: Int?; let live: Bool
    /// trips and events left out of spending (Everyday), which still left the accounts
    var ev: Double? = nil
    /// taxes paid (income tax, advance tax, GST): out of spending, still money that left the month
    var tax: Double? = nil
    /// a finished month with no salary in the mail, once a salary has been seen three months: its pay mail never came
    var noPay: Bool? = nil
    /// the month the mail starts in, read from a day past the 1st (since: that day): what came in and went out from then only
    var partial: Bool? = nil; var since: String? = nil
    var id: String { m }
}

/// Money between people: splits, loans to friends, refunds. dir "in" = owed to you, "out" = you owe.
struct OwedItem: Codable, Identifiable, Hashable {
    var id: String; var name: String; var title: String; var amount: Double; var date: String
    var dir: String; var kind: String; var settled: Bool; var note: String
    /// the payment it was split from, if any
    var tx: String? = nil
    /// the credit that paid it back, when kosh saw it come in (filled from each build, never saved)
    var settledBy: String? = nil
    /// credits kosh took as this paid back and you said weren't (Undo): they settle nothing again
    var notBy: [String]? = nil
}

/// a share owed to you that a credit paid back (engine settleShares): the share, the credit, its day, amount and
/// name, and how kosh knew whom it came from: name, first (a first name or an initial alone), upi (a UPI ID that
/// carried the person's name before)
struct PaidBack: Decodable, Hashable {
    let id: String; let by: String; let d: String; let a: Double; let m: String; let how: String
}

/// a share of a split payment after money came back on it (engine 21b shareNow): the share now, and what came off
struct ShareNow: Decodable, Hashable {
    let id: String; let tx: String; let a: Double; let cut: Double
}

struct ForWhom: Decodable, Identifiable, Equatable { let m: String; let short: String; let me: Double; let mom: Double; let home: Double; let work: Double; let none: Double; var id: String { m } }
struct TrendPoint: Decodable, Identifiable, Hashable { let m: String; let short: String; let v: Double; var id: String { m } }
struct Trend: Decodable, Identifiable, Equatable { let cat: String; let color: String; let sym: String; let values: [TrendPoint]; var id: String { cat } }
/// something kosh noticed in how the money moves: a habit, a category moving, repeats, a big one-off
struct Pattern: Decodable, Identifiable, Hashable { let id: String; let kind: String; let title: String; let detail: String; let amount: Double; let sym: String; let color: String; let tone: String }
struct Insights: Decodable, Equatable { let forWhom: [ForWhom]; let trend: [Trend]; var patterns: [Pattern]? = nil }

struct ScanItem: Decodable, Identifiable, Hashable { let id: String; let kind: String; let title: String; let detail: String; let count: Int; let sym: String; let color: String }
struct ScanStats: Decodable, Equatable { let emails: Int; let from: String; let months: Int }

/// a gift voucher a store's mail delivered: what it's for, its value, when it runs out, how it came (bought or
/// paid with points) and the mail it's in. kosh keeps no code or PIN; the mail has them.
struct Voucher: Decodable, Identifiable, Hashable {
    let id: String; let brand: String; let value: Double; let until: String; let d: String
    let store: String; let how: String; let via: String
    /// open, used (its app's balance took it) or expired
    let status: String; let usedOn: String
    let mail: String; let acct: String; let owner: String
}

/// Equatable so Store.SnapBox can tell which parts a build changed (every part is: a new one must be too)
struct Snapshot: Decodable, Equatable {
    let generated: String; let today: String; let cm: String; let name: String
    let voice: [VoiceBit]; let wealthVoice: String
    let fc: Forecast; let months: [MonthInfo]; let cats: [String: CatInfo]
    var tx: [Txn]; let needs: [Need]; let flow: Flow; var agenda: [AgendaItem]
    let comm: [Committee]; let hold: [Holding]; var prop: PropertyBook
    let lent: [Lent]; let dups: [Dup]
    let people: [PersonInfo]; let accounts: [Account]; var cards: [CardInfo]; let wallets: [Account]; let cash: CashInfo
    let loans: [Loan]; var policies: [Policy]; var recurring: [Recurring]; let owed: [OwedItem]
    let insights: Insights; let scan: [ScanItem]; let scanStats: ScanStats; let fy: String
    /// yearly returns by "person|kind" ("family|all", "me|mf"), where some holdings have the dated money for one
    var rets: [String: HoldReturn]? = nil
    /// the committees together, month by month (live mode)
    var commMonths: [CommMonth]? = nil
    /// the same, for each person: their committees, a joint one at their share (by person id)
    var commWho: [String: [CommMonth]]? = nil
    /// what was owned at each month's end, by person and class, from what's dated (live mode)
    var worth: [WorthRow]? = nil
    /// the tax deducted at source the mail tells (a client's payment advice, the Form 26AS mail), as the papers' facts
    /// are: for Ask's papers tool (engine.js taxFacts)
    var taxFacts: [DocFact]? = nil
    var cashflow: [CashMonth]? = nil
    /// how each card or bank statement squared with the alerts; where the ledger starts
    var recon: [Recon]? = nil
    /// what kosh's last check held back from every screen and total (a payment with no figure or a misread year,
    /// a holding with no name, a policy told twice), and why
    var health: Health? = nil
    /// each bank's and card's newest statement, and where it stands
    var stmts: [StmtStatus]? = nil
    /// gift vouchers from the stores' mail, open ones first
    var vouchers: [Voucher]? = nil
    /// trips the bookings in the mail make, offered as chapters (trips.js)
    var tripDrafts: [TripDraft]? = nil
    /// refunds you're waiting for, and those that came back
    var refunds: [RefundInfo]? = nil
    /// refunds a shop's mail promised for a payment kosh never saw (id "promise|…", a: 0): kept apart from refunds until
    /// the Refunds page can show a row with no payment to open
    var refundPromises: [RefundInfo]? = nil
    /// the year's fees, each card's annual fee, a card charged twice (engine/21m-build-savings.js)
    var fees: FeeBook? = nil
    var cardFees: [CardFee]? = nil
    var doubles: [DoubleCharge]? = nil
    /// where each payment was made, what it bought, how often (engine/21o-build-payfacts.js; PayFacts.swift)
    var payFacts: PayFacts? = nil
    /// how you shop: each kind of thing bought over the last nine months (engine.js › buyPatterns)
    var buys: [BuyPattern]? = nil
    /// what each order was (its mails, its bill, what was bought, its tags) and the month in review
    /// (engine/21r-build-orders.js; Orders.swift)
    var orders: OrdersBook? = nil
    /// each home's bills, spread over the days each covers, by the home they belong to (engine/21s-build-homes.js; Homes.swift)
    var homes: HomesBook? = nil
    /// what the mail says about your life: events, trips, whom you spend on, habits (engine/21t-build-persona.js; Persona.swift)
    var persona: Persona? = nil
    /// what needs doing and what kosh is watching (assist.js): refunds on their way or late, bills due this week
    var actions: [ActionInfo]? = nil
    /// a person whose fund statement is missing, behind, old or came locked (engine/21n-build-cas-gap.js; CASFailsafe.swift)
    var casGap: [CASGap]? = nil
    /// each tab's one line, what matters today (engine/21p-build-tab-smarts.js; TabSmarts.swift)
    var smarts: TabSmarts? = nil
    /// when each kind of holding's figures are from, for "family" and for each person, by class (mf, stk…)
    var holdAsOf: [String: [String: KindAsOf]]? = nil
    /// what the mail since the statements couldn't place yet (a purchase without its units), and what's been sold out
    struct HoldRoll: Decodable, Hashable {
        struct Sold: Decodable, Hashable { var bank: String; var owner: String; var isin: String? = nil; var on: String; var n: Int }
        var waiting: Int; var sold: [Sold]
    }
    var holdRoll: HoldRoll? = nil
    /// shares owed to you that kosh saw come back (live mode)
    var paidBack: [PaidBack]? = nil
    /// a change saved on a payment's twin that the build dropped (the SMS, once the mail told it too), carried to the
    /// row it kept: dropped id → kept id (engine 21a carryChanges). Store.carryTwins moves the change, and the shares
    /// split off it, onto the kept row for good
    var carried: [String: String]? = nil
    /// each share split off a payment money later came back on, as it is now: the others' part of the money back taken
    /// off in proportion (engine 21b shareNow). `a` is the share now, `cut` what came off it
    var shareNow: [ShareNow]? = nil
    /// trips and events, and whether spending leaves them out (Everyday)
    var trips: [TripInfo]? = nil
    /// every detail the mail printed about each person, by institution and category (Your details)
    var facts: [FactGroup]? = nil
    var everyday: Bool? = nil
    var showFrom: String? = nil
    /// what kosh noticed on its own (agent.js): fees, a charge twice, a big spend, a price rise, what's due and
    /// whether the money is there, deposits maturing, late rent, the month's pace; most pressing first
    var watch: [WatchItem]? = nil
    /// what kosh learned from your changes (and Claude's), payee by payee: What kosh has learned
    var learned: [LearnedPayee]? = nil
    /// repeats you said aren't repeats
    var recurringOff: [RepeatOff]? = nil
    /// the money threads the mail tells (journey.js): a statement and what cleared it, an order from placed to refunded,
    /// a policy's premiums; and across them, what's coming and what needs a look (Threads.swift)
    var threads: [MoneyThread]? = nil
    var journey: JourneyInfo? = nil
    /// every travel payment and the mail that proves it, with kosh's guess at what's work (packs.js): what a claim
    /// is made from
    var docs: [ClaimDoc]? = nil
    /// what kosh is following up for you: a claim to make or send, one waiting for its money, one paid (packs.js)
    var cases: [CaseItem]? = nil
    /// goals, the salary split, a low balance before an auto-debit, subscriptions (plan.js; Plan.swift)
    var plan: PlanInfo? = nil
    /// the Sunday digest, the morning briefing, the projection, fund fees (brief.js; Brief.swift)
    var brief: BriefInfo? = nil
    /// the accounts kosh asks about (named only by others' mail), payments it can't place, and names on the mail that
    /// are no one in the household yet (engine.js › acctRegistry, personFor)
    var acctMaybe: [AcctMaybe]? = nil
    var acctUnplaced: [AcctUnplaced]? = nil
    var peopleToConfirm: [PersonToConfirm]? = nil
    /// the names the mail greets that are no one in the household yet (whose a locked statement may be: pwWho)
    var nameGroups: [NameGroup]? = nil
    /// every deposit kosh has seen, where it stands and why, and the booking requests that aren't deposits
    /// (engine.js depositBook; Deposits.swift)
    var deposits: DepositBook? = nil
    /// dividends by financial year and company, for "family" and each person; deposits maturing in the next twelve
    /// months and closed in the last six (engine/21k-build-portfolio.js; PortfolioViews.swift)
    var dividends: [String: DividendBook]? = nil
    var depDates: DepDates? = nil
    /// EPF, PPF and NPS on one screen (engine/21l-build-retirement.js; RetirementView.swift)
    var retirement: RetirementBook? = nil
    /// the Insurance tab, arranged (engine.js › insuranceBook): each vehicle with its history, each person's health
    /// cover, and what needs a look (nil from a build before them)
    var vehicles: [VehicleInfo]? = nil
    var healthBy: [HealthPerson]? = nil
    var needsLook: [LookItem]? = nil
    /// every running policy's premiums in the next twelve months, by day; a big one says what to put aside each month
    var premAhead: [PremAhead]? = nil
    /// a person's name for screens: the household's, else a name the mail is written to that is still to confirm
    func personName(_ id: String) -> String? {
        if let p = people.first(where: { $0.id == id }) { return p.rel.isEmpty ? p.name : p.rel }
        return peopleToConfirm?.first(where: { $0.id == id })?.full
    }

    /// "kosh" is the family's own snapshot; "demo" is the made-up household for showing kosh to people
    static func load(_ name: String = "kosh") -> Snapshot {
        guard let url = Bundle.main.url(forResource: name, withExtension: "json"),
              let data = try? Data(contentsOf: url) else { fatalError("\(name).json is missing from the app bundle") }
        do { return try JSONDecoder().decode(Snapshot.self, from: data) }
        catch { fatalError("\(name).json could not be read: \(error)") }
    }
    static var hasDemo: Bool { Bundle.main.url(forResource: "demo", withExtension: "json") != nil }
    /// the beta ships without a snapshot: it reads your own Gmail instead
    static var isLive: Bool { Bundle.main.url(forResource: "kosh", withExtension: "json") == nil }
}

/// a trip the bookings in the mail make, offered as a chapter: where, when, what booked it and what it cost
struct TripDraft: Decodable, Identifiable, Hashable {
    let id: String; let name: String; let place: String; let from: String; let to: String
    var home: String? = nil
    let legs: Int
    var kinds: [String: Int]? = nil
    let paid: Double
    let pay: [String]
    /// what was spent around it that looks like the trip's (its days, forex the month before), offered with it, and
    /// what that came to; the days all its payments run over
    var near: [String]? = nil
    var nearPaid: Double? = nil
    var payFrom: String? = nil
    var payTo: String? = nil
    /// your word on it: a name you gave it, two drafts you joined into one (trips.js: prof.tripNames, prof.tripJoin)
    var named: Bool? = nil
    var joined: Bool? = nil
}

