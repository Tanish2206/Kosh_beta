import Foundation

// MARK: - The store: bills by home (Homes.swift; engine/21s-build-homes.js)
// Read-only lookups into the snapshot, and your word on which home a connection is (learnt for good: every bill of
// that connection, past and future, goes with it). Nothing here is worked out again.

extension Store {
    /// every home with bills, the dearest a month first
    var homes: [HomesBook.Home] { snap.homes?.homes ?? [] }
    func home(_ id: String) -> HomesBook.Home? { homes.first { $0.id == id } }
    /// a home's connections, and the ones kosh couldn't place
    func homeAccts(_ id: String) -> [HomesBook.Acct] { (snap.homes?.accts ?? []).filter { ($0.home ?? "") == id } }
    var unplacedAccts: [HomesBook.Acct] {
        let ids: Set<String> = Set(snap.homes?.unplaced ?? [])
        return (snap.homes?.accts ?? []).filter { ids.contains($0.id) }
    }
    /// a home's bills, newest first; a connection's
    func homeBills(_ id: String) -> [HomesBook.Bill] { (snap.homes?.bills ?? []).filter { ($0.home ?? "") == id } }
    func acctBills(_ id: String) -> [HomesBook.Bill] { (snap.homes?.bills ?? []).filter { $0.acct == id } }

    /// put a connection in a home (a home's id; "none" when its bills are no home's), for good
    func placeConnection(_ acct: String, in home: String) {
        guard let live else { return }
        live.placeConnection(acct, in: home)
    }
    /// a home you name, with this connection in it
    func newHome(_ name: String, with acct: String) {
        guard let live else { return }
        let n: String = String(name.trimmingCharacters(in: .whitespacesAndNewlines).prefix(40))
        guard !n.isEmpty else { return }
        let id: String = live.nameHome(n)
        live.placeConnection(acct, in: id)
    }
}

extension LiveSession {
    static let homeOfKey: String = "beta.homeOf"
    static let homesNamedKey: String = "beta.homesNamed"
    /// which home each connection is, as you said (engine/21s: prof.homeOf)
    var homeOf: [String: String] { (ud.dictionary(forKey: Self.homeOfKey) as? [String: String]) ?? [:] }
    /// the homes you named: [{ id, name }] (engine/21s: prof.homes)
    var homesNamed: [[String: String]] { (ud.array(forKey: Self.homesNamedKey) as? [[String: String]]) ?? [] }

    func placeConnection(_ acct: String, in home: String) {
        var m: [String: String] = homeOf
        if home.isEmpty { m.removeValue(forKey: acct) } else { m[acct] = home }
        ud.set(m, forKey: Self.homeOfKey)
        rebuildSoon(force: true)
    }
    /// a home of your own naming; its id, kept with its name
    func nameHome(_ name: String) -> String {
        var list: [[String: String]] = homesNamed
        if let had = list.first(where: { ($0["name"] ?? "").lowercased() == name.lowercased() }), let id = had["id"] { return id }
        let id: String = "u:" + String(list.count + 1) + "-" + String(Int(Date().timeIntervalSince1970) % 100000)
        list.append(["id": id, "name": name])
        ud.set(list, forKey: Self.homesNamedKey)
        return id
    }
}
