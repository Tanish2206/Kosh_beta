/* kosh mailwire: mail from inboxes that aren't Gmail (Outlook through Microsoft's Graph; Yahoo, iCloud, AOL, Zoho
   and any other mail server through IMAP), turned into the same email shape the engine reads from Gmail.
   No network, no storage, like the engine: Swift moves the bytes, this reads them.

   IMAP text arrives as a "binary" string, one character per byte (Latin-1), so byte counts, base64 and the
   attachments' bytes survive the trip; the readable parts are decoded from their own charset here.

   Loaded after engine.js; its functions are added to KoshEngine, so Swift calls them like any other. */

var KoshMail = (function (E) {
  'use strict';

  /* ------------------------------------------------------------ bytes and charsets */
  var B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
  var B64I = {};
  for (var bi = 0; bi < 64; bi++) B64I[B64.charAt(bi)] = bi;
  B64I['-'] = 62; B64I['_'] = 63;

  // char codes → string, in slices (one big apply overflows the stack)
  function fromCodes(codes) {
    var out = '';
    for (var i = 0; i < codes.length; i += 8192) out += String.fromCharCode.apply(null, codes.slice(i, i + 8192));
    return out;
  }
  // base64 → binary string; anything that isn't base64 (line breaks, padding) is skipped
  function b64decode(s) {
    var codes = [], buf = 0, bits = 0;
    for (var i = 0; i < s.length; i++) {
      var v = B64I[s.charAt(i)];
      if (v === undefined) continue;
      buf = ((buf << 6) | v) & 0xffffff;
      bits += 6;
      if (bits >= 8) { bits -= 8; codes.push((buf >> bits) & 255); }
    }
    return fromCodes(codes);
  }
  function b64encode(bin) {
    var out = [], i = 0;
    for (; i + 2 < bin.length; i += 3) {
      var n = (bin.charCodeAt(i) << 16) | (bin.charCodeAt(i + 1) << 8) | bin.charCodeAt(i + 2);
      out.push(B64.charAt(n >> 18 & 63) + B64.charAt(n >> 12 & 63) + B64.charAt(n >> 6 & 63) + B64.charAt(n & 63));
    }
    var rest = bin.length - i;
    if (rest === 1) { var a = bin.charCodeAt(i) << 16; out.push(B64.charAt(a >> 18 & 63) + B64.charAt(a >> 12 & 63) + '=='); }
    else if (rest === 2) { var b = (bin.charCodeAt(i) << 16) | (bin.charCodeAt(i + 1) << 8); out.push(B64.charAt(b >> 18 & 63) + B64.charAt(b >> 12 & 63) + B64.charAt(b >> 6 & 63) + '='); }
    return out.join('');
  }
  // quoted-printable → binary string (soft line breaks joined)
  function qpdecode(s) {
    return s.replace(/=\r?\n/g, '').replace(/=([0-9A-Fa-f]{2})/g, function (m, h) { return String.fromCharCode(parseInt(h, 16)); });
  }
  // UTF-8 bytes → text; null if the bytes aren't UTF-8 (then they're read as Latin-1 / Windows-1252)
  function utf8(bin) {
    var codes = [], i = 0, n = bin.length;
    function cont(k) { var c = bin.charCodeAt(k); return c >= 0x80 && c < 0xc0 ? c & 63 : -1; }
    while (i < n) {
      var c = bin.charCodeAt(i);
      if (c > 0xff) return null;
      if (c < 0x80) { codes.push(c); i++; continue; }
      var a, b2, c3;
      if (c >= 0xc2 && c < 0xe0) {
        a = cont(i + 1); if (a < 0) return null;
        codes.push(((c & 31) << 6) | a); i += 2;
      } else if (c >= 0xe0 && c < 0xf0) {
        a = cont(i + 1); b2 = cont(i + 2); if (a < 0 || b2 < 0) return null;
        codes.push(((c & 15) << 12) | (a << 6) | b2); i += 3;
      } else if (c >= 0xf0 && c < 0xf5) {
        a = cont(i + 1); b2 = cont(i + 2); c3 = cont(i + 3); if (a < 0 || b2 < 0 || c3 < 0) return null;
        var cp = (((c & 7) << 18) | (a << 12) | (b2 << 6) | c3) - 0x10000;
        codes.push(0xd800 + (cp >> 10), 0xdc00 + (cp & 1023)); i += 4;
      } else return null;
    }
    return fromCodes(codes);
  }
  // the few Windows-1252 characters bank mail uses where Latin-1 has control codes
  var CP1252 = { 0x80: 0x20ac, 0x82: 0x201a, 0x84: 0x201e, 0x85: 0x2026, 0x91: 0x2018, 0x92: 0x2019, 0x93: 0x201c, 0x94: 0x201d, 0x95: 0x2022, 0x96: 0x2013, 0x97: 0x2014, 0x99: 0x2122 };
  function latin(bin) { return bin.replace(/[\x80-\x9f]/g, function (ch) { var m = CP1252[ch.charCodeAt(0)]; return m ? String.fromCharCode(m) : ' '; }); }
  function decodeText(bin, charset) {
    var cs = String(charset || '').toLowerCase().replace(/["']/g, '');
    if (!cs || cs === 'utf-8' || cs === 'utf8' || cs === 'us-ascii' || cs === 'ascii') {
      var u = utf8(bin);
      return u === null ? latin(bin) : u;
    }
    if (cs === 'utf-16' || cs === 'utf-16le' || cs === 'utf-16be') {
      var le = cs !== 'utf-16be', codes = [];
      for (var i = 0; i + 1 < bin.length; i += 2) codes.push(le ? bin.charCodeAt(i) | (bin.charCodeAt(i + 1) << 8) : (bin.charCodeAt(i) << 8) | bin.charCodeAt(i + 1));
      return fromCodes(codes).replace(/^﻿/, '');
    }
    // Latin-1, Windows-1252 and the rest: as Latin-1, unless the bytes are plainly UTF-8 under a wrong label
    var t = utf8(bin);
    return t !== null && /[Ā-￿]/.test(t) ? t : latin(bin);
  }
  // "=?UTF-8?B?4oK5IDUwMA==?= paid" → "₹ 500 paid"; words next to each other join without the space between
  function headerText(s) {
    s = String(s || '');
    if (s.indexOf('=?') < 0) { var u = utf8(s); return u === null ? latin(s) : u; }
    return s.replace(/(=\?[^?\s]+\?[BbQq]\?[^?\s]*\?=)\s+(?==\?)/g, '$1').replace(/=\?([^?\s]+)\?([BbQq])\?([^?\s]*)\?=/g, function (m, cs, enc, txt) {
      var bin = /b/i.test(enc) ? b64decode(txt) : qpdecode(txt.replace(/_/g, ' '));
      return decodeText(bin, cs.replace(/\*.*$/, ''));
    });
  }

  /* ------------------------------------------------------------ one message: headers and MIME parts */
  function splitHead(raw) {
    var m = /\r?\n\r?\n/.exec(raw);
    return m ? { head: raw.slice(0, m.index), body: raw.slice(m.index + m[0].length) } : { head: raw, body: '' };
  }
  function headers(head) {
    var out = {};
    head.replace(/\r?\n[ \t]+/g, ' ').split(/\r?\n/).forEach(function (line) {
      var k = line.indexOf(':');
      if (k <= 0) return;
      var name = line.slice(0, k).trim().toLowerCase();
      if (out[name] === undefined) out[name] = line.slice(k + 1).trim();
    });
    return out;
  }
  // "text/html; charset=\"utf-8\"; name*=UTF-8''%E2%82%B9.pdf" → { value: 'text/html', charset: 'utf-8', name: '₹.pdf' }
  function params(v) {
    var parts = [], cur = '', q = false;
    String(v || '').split('').forEach(function (ch) {
      if (ch === '"') q = !q;
      if (ch === ';' && !q) { parts.push(cur); cur = ''; } else cur += ch;
    });
    parts.push(cur);
    var out = { value: parts.shift().trim().toLowerCase() }, cont = {};
    parts.forEach(function (p) {
      var k = p.indexOf('=');
      if (k < 0) return;
      var key = p.slice(0, k).trim().toLowerCase(), val = p.slice(k + 1).trim().replace(/^"(.*)"$/, '$1').replace(/\\(.)/g, '$1');
      var c = /^([^*]+)\*(\d+)?(\*)?$/.exec(key);
      if (c) { (cont[c[1]] = cont[c[1]] || []).push({ n: +(c[2] || 0), enc: !!c[3] || (!c[2] && /\*$/.test(key)), v: val }); return; }
      out[key] = val;
    });
    Object.keys(cont).forEach(function (key) {
      var segs = cont[key].sort(function (a, b) { return a.n - b.n; }), cs = '';
      var bin = segs.map(function (s, i) {
        var v = s.v;
        if (s.enc && i === 0) { var m = /^([^']*)'[^']*'(.*)$/.exec(v); if (m) { cs = m[1]; v = m[2]; } }
        return s.enc ? v.replace(/%([0-9A-Fa-f]{2})/g, function (x, h) { return String.fromCharCode(parseInt(h, 16)); }) : v;
      }).join('');
      out[key] = decodeText(bin, cs || 'utf-8');
    });
    return out;
  }
  function transferDecode(body, enc) {
    enc = String(enc || '').toLowerCase().trim();
    if (enc === 'base64') return b64decode(body);
    if (enc === 'quoted-printable') return qpdecode(body);
    return body;
  }
  /* every part of a message, in order: its number ("1", "2.1"), type, charset, file name and decoded bytes.
     The numbers are kosh's own walk of the message, the same each time it's read, which is how an attachment is
     found again later. */
  function walk(raw, path, out, depth) {
    var sh = splitHead(raw), h = headers(sh.head);
    var ct = params(h['content-type'] || 'text/plain'), cd = params(h['content-disposition'] || '');
    var type = ct.value || 'text/plain';
    if (/^multipart\//.test(type) && ct.boundary && depth < 12) {
      var b = '--' + ct.boundary, chunks = sh.body.split(new RegExp('(?:^|\\r?\\n)' + b.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '(--)?[ \\t]*(?=\\r?\\n|$)'));
      // [preamble, '--'?, part, '--'?, part, …]: every other item is the closing marker's capture
      var n = 0;
      for (var i = 2; i < chunks.length; i += 2) {
        if (chunks[i - 1] === '--') break;
        var c = chunks[i];
        if (c === undefined) break;
        n++;
        walk(c.replace(/^\r?\n/, ''), path ? path + '.' + n : String(n), out, depth + 1);
      }
      return;
    }
    if (type === 'message/rfc822' && depth < 12) { walk(transferDecode(sh.body, h['content-transfer-encoding']), path ? path + '.1' : '1', out, depth + 1); return; }
    var name = cd.filename || ct.name || '';
    out.push({ path: path || '1', type: type, charset: ct.charset || '', filename: headerText(name), disposition: cd.value || '',
      bytes: transferDecode(sh.body, h['content-transfer-encoding']) });
  }
  var MONTHN = { jan: 0, feb: 1, mar: 2, apr: 3, may: 4, jun: 5, jul: 6, aug: 7, sep: 8, oct: 9, nov: 10, dec: 11 };
  var ZONES = { ut: 0, utc: 0, gmt: 0, z: 0, est: -300, edt: -240, cst: -360, cdt: -300, mst: -420, mdt: -360, pst: -480, pdt: -420, ist: 330 };
  // "Sat, 10 Oct 2026 14:37:13 +0530 (IST)" or IMAP's "10-Oct-2026 14:37:13 +0530" → "2026-10-10T09:07:13Z"
  function isoOf(s) {
    var m = /(\d{1,2})[\s-]+([A-Za-z]{3})[a-z]*[\s-]+(\d{2,4})\s+(\d{1,2}):(\d{2})(?::(\d{2}))?\s*([+-]\d{4}|[A-Za-z]{1,5})?/.exec(String(s || ''));
    if (!m || MONTHN[m[2].toLowerCase()] === undefined) return '';
    var y = +m[3]; if (y < 100) y += y < 70 ? 2000 : 1900;
    var off = 0, z = m[7] || '';
    if (/^[+-]\d{4}$/.test(z)) off = (z.charAt(0) === '-' ? -1 : 1) * (+z.slice(1, 3) * 60 + +z.slice(3, 5));
    else if (ZONES[z.toLowerCase()] !== undefined) off = ZONES[z.toLowerCase()];
    var t = Date.UTC(y, MONTHN[m[2].toLowerCase()], +m[1], +m[4], +m[5], +(m[6] || 0)) - off * 60000;
    return isNaN(t) ? '' : new Date(t).toISOString().replace(/\.\d{3}Z$/, 'Z');
  }
  /* one whole message (RFC 822 as the server keeps it) → the email kosh reads: who it's from, when, the subject,
     its text and HTML, and its attachments by part number. Long parts are cut the way Gmail's are. */
  function message(raw, id, fallbackDate) {
    var sh = splitHead(raw), h = headers(sh.head), parts = [];
    walk(raw, '', parts, 0);
    var text = '', html = '', att = [];
    parts.forEach(function (p) {
      var isFile = p.disposition === 'attachment' || (p.filename && !/^text\/(?:plain|html)$/.test(p.type)) || (p.filename && p.disposition !== 'inline');
      if (isFile) { att.push({ id: p.path, filename: p.filename || ('part-' + p.path), mime: p.type }); return; }
      if (p.type === 'text/plain') text += decodeText(p.bytes, p.charset) + '\n';
      else if (p.type === 'text/html') html += decodeText(p.bytes, p.charset) + '\n';
    });
    return { id: String(id || ''), from: headerText(h.from || ''), date: isoOf(h.date) || isoOf(fallbackDate) || new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'),
      subject: headerText(h.subject || ''), text: text.slice(0, 12000), html: html.slice(0, 60000), attachments: att };
  }
  // one part's bytes (an attachment), as a binary string; '' if the message has no such part
  function part(raw, path) {
    var parts = [];
    walk(raw, '', parts, 0);
    for (var i = 0; i < parts.length; i++) if (parts[i].path === path) return parts[i].bytes;
    return '';
  }

  /* ------------------------------------------------------------ IMAP: reading what the server says
     A response is lines, any of which may carry literals ("{1234}" then exactly that many bytes). Swift collects
     a whole response (up to the tagged OK) and hands it over as one binary string. */
  function Reader(s) { this.s = s; this.i = 0; }
  Reader.prototype.ws = function () { while (this.s.charAt(this.i) === ' ') this.i++; };
  Reader.prototype.peek = function () { return this.s.charAt(this.i); };
  Reader.prototype.value = function () {
    this.ws();
    var c = this.peek(), s = this.s;
    if (c === '(') {
      this.i++;
      var list = [];
      while (this.i < s.length) {
        this.ws();
        if (this.peek() === ')') { this.i++; break; }
        if (this.peek() === '\r' || this.peek() === '\n') { this.i++; continue; }
        list.push(this.value());
      }
      return list;
    }
    if (c === '"') {
      var out = '';
      this.i++;
      while (this.i < s.length) {
        var ch = s.charAt(this.i++);
        if (ch === '\\') { out += s.charAt(this.i++); continue; }
        if (ch === '"') break;
        out += ch;
      }
      return out;
    }
    if (c === '{') {
      var close = s.indexOf('}', this.i), n = +s.slice(this.i + 1, close).replace('+', '');
      var at = s.indexOf('\n', close) + 1;
      this.i = at + n;
      return s.substr(at, n);
    }
    // an atom; a section ("BODY[HEADER.FIELDS (FROM SUBJECT)]<0>") is one, brackets and all
    var start = this.i, depth = 0;
    while (this.i < s.length) {
      var d = s.charAt(this.i);
      if (d === '[') depth++;
      else if (d === ']') depth--;
      else if (depth <= 0 && (d === ' ' || d === ')' || d === '(' || d === '\r' || d === '\n')) break;
      this.i++;
    }
    var atom = s.slice(start, this.i);
    return atom === 'NIL' ? null : atom;
  }
  // every "* n FETCH (…)" in a response, as { UID, INTERNALDATE, RFC822.SIZE, BODY[...]: … }
  function fetches(resp) {
    var out = [], s = String(resp || ''), re = /\* \d+ FETCH \(/g, m;
    while ((m = re.exec(s))) {
      var r = new Reader(s);
      r.i = m.index + m[0].length - 1;
      var list = r.value(), item = {};
      for (var k = 0; k + 1 < (list || []).length; k += 2) {
        var key = String(list[k]).toUpperCase().replace(/^BODY\.PEEK/, 'BODY');
        // BODY[HEADER.FIELDS (FROM SUBJECT DATE)] and BODY[] are told apart by what's in the brackets
        item[/^BODY\[HEADER/.test(key) ? 'HEADER' : /^BODY\[\]/.test(key) ? 'BODY' : /^BODY\[/.test(key) ? 'PART' : key] = list[k + 1];
      }
      out.push(item);
      re.lastIndex = Math.max(re.lastIndex, r.i);
    }
    return out;
  }
  function search(resp) {
    var out = [];
    String(resp || '').split(/\r?\n/).forEach(function (l) {
      var m = /^\* (?:E?SEARCH)\b(.*)$/i.exec(l);
      if (m) m[1].trim().split(/\s+/).forEach(function (x) { if (/^\d+$/.test(x)) out.push(+x); });
    });
    return out;
  }
  // folders kosh reads: the inbox and the user's own folders; never Sent, Drafts, Trash, Spam or the like
  var SKIP_ATTR = /\\(?:noselect|nonexistent|sent|drafts|trash|junk|spam|all|flagged|important)\b/i;
  var SKIP_NAME = /^(?:sent|sent items|sent messages|sent mail|outbox|drafts?|trash|bin|deleted|deleted items|deleted messages|junk|junk e-?mail|spam|bulk|bulk mail|notes|templates|scheduled|chats|conversation history|sync issues.*|rss feeds|calendar|contacts|tasks|journal)$/i;
  function folders(resp) {
    var out = [], s = String(resp || '');
    var re = /^\* (?:LIST|XLIST) /gim, m;
    while ((m = re.exec(s))) {
      var r = new Reader(s);
      r.i = m.index + m[0].length;
      var attrs = r.value(), delim = r.value(), name = r.value();
      if (name === null || name === undefined) continue;
      var flags = (attrs || []).join(' ');
      var leaf = delim ? String(name).split(delim).pop() : String(name);
      if (SKIP_ATTR.test(flags) || SKIP_NAME.test(leaf.trim()) || /^\[gmail\]$/i.test(name)) continue;
      out.push({ name: String(name), inbox: /^inbox$/i.test(name) });
    }
    out.sort(function (a, b) { return (b.inbox ? 1 : 0) - (a.inbox ? 1 : 0); });
    return out.slice(0, 60).map(function (f) { return f.name; });
  }
  function uidValidity(resp) { var m = /\[UIDVALIDITY (\d+)\]/i.exec(String(resp || '')); return m ? m[1] : '0'; }
  function quote(s) { return '"' + String(s).replace(/\\/g, '\\\\').replace(/"/g, '\\"') + '"'; }
  var MON3 = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  function imapDay(isoDay) { var p = String(isoDay).split('-'); return +p[2] + '-' + MON3[+p[1] - 1] + '-' + p[0]; }
  // "UID SEARCH SINCE 1-Jan-2026 BEFORE 1-Feb-2026"
  function searchCommand(after, before) { return 'UID SEARCH SINCE ' + imapDay(after) + (before ? ' BEFORE ' + imapDay(before) : ''); }
  // an IMAP message's id in kosh: "<uidvalidity>.<uid>@<folder>", the same each time the folder is read
  function imapID(validity, uid, folder) { return validity + '.' + uid + '@' + folder; }
  function imapRef(id) {
    var m = /^(\d+)\.(\d+)@([\s\S]*)$/.exec(String(id || ''));
    return m ? { validity: m[1], uid: +m[2], folder: m[3] } : null;
  }

  /* ------------------------------------------------------------ which mail is worth fetching
     Gmail is searched server-side (engine.gmailQueries). Elsewhere kosh lists every message's sender and subject
     in the window and keeps the ones those searches would find: every address of a money sender kosh knows, less
     marketing desks and one-time passwords; a shop's receipts; and money words in the subject from anyone, less
     newsletters. */
  // the words of an address the Gmail searches leave out (-from:(offers OR … OR mktcomm)), matched as whole words
  // the way Gmail's from: matches them, so mailers.hdfcbank.bank.in is out and mailer.zerodha.com is not
  var MARKETING_WORDS = { offers: 1, offer: 1, promotions: 1, promo: 1, marketing: 1, newsletter: 1, newsletters: 1, mailers: 1, campaign: 1, mktcomm: 1 };
  // from a sender kosh doesn't know, a few more that only ever send marketing
  var MARKETING_MORE = { deals: 1, digest: 1, events: 1, webinar: 1, news: 1, promotion: 1, campaigns: 1 };
  function marketing(addr, more) {
    return String(addr).split(/[^a-z0-9]+/).some(function (w) { return MARKETING_WORDS[w] || (more && MARKETING_MORE[w]); }) ||
      /^updates\.fold|updates\.wintwealth\.com$/.test(String(addr).split('@')[1] || '');
  }
  var NEWSLETTER_DOM = /(?:^|\.)(?:substack\.com|beehiiv\.com|redditmail\.com|medium\.com|linkedin\.com|quora\.com|facebookmail\.com|twitter\.com|x\.com|youtube\.com|instagram\.com)$/i;
  var NOT_SUBJ = /\b(?:otp|one[- ]time password|verification code|passcode|logged in|log ?in|login|webinar|newsletter|survey)\b/i;
  var VOCAB_SUBJ = /\b(?:debited|credited|spent|withdrawn|was used|has been used|payment|paid|refund(?:ed)?|reversed|cash ?back|money added|added to your|upi|imps|neft|rtgs|nach|e-?mandate|auto ?-?pay|auto[- ]debit|standing instruction|emi|top-?up|wallet|statement|e-?statement|bill|amount due|due date|premium|policy|invoice|receipt|order|booking|sip|allot(?:ment|ted)|redemption|dividend|interest|contract note|demat|deposit|fixed deposit|ppf|nps|provident|epf|gold|consolidated account|cas\b|transaction|txn|alert|purchase|spend|charged|instalment|installment|loan|repayment|maintenance|rent|tax|tds|salary|credit card|debit card|e-?voucher|gift card|gift voucher|ipo|units)\b/i;
  function emailOf(from) { var m = /<([^>]+)>/.exec(from || ''); return (m ? m[1] : (from || '')).trim().toLowerCase(); }
  function wantHeader(h) {
    var from = String(h.from || ''), subj = String(h.subject || ''), addr = emailOf(from), dom = addr.split('@')[1] || '';
    if (!addr || NOT_SUBJ.test(subj)) return false;
    // a travel site's receipt, ticket or booking: what an expense claim is made of
    if (E.travel && E.travel.senderOf(from) && E.travel.SUBJ.test(subj)) return true;
    var ins = E.institution(from);
    if (ins && ins.kind === 'merchant') {
      var words = ((ins.merchant || {}).subjects || []);
      return words.some(function (w) { return subj.toLowerCase().indexOf(String(w).toLowerCase()) >= 0; });
    }
    if (marketing(addr, !ins)) return false;
    if (ins) return true;
    if (NEWSLETTER_DOM.test(dom)) return false;
    return VOCAB_SUBJ.test(subj);
  }

  /* ------------------------------------------------------------ Microsoft Graph */
  // one message as Graph sends it (with its file attachments, if listed) → the email kosh reads
  function graphMessage(m, atts) {
    m = m || {};
    var f = (m.from || m.sender || {}).emailAddress || {};
    var body = m.body || {}, isHtml = String(body.contentType || '').toLowerCase() === 'html';
    var list = ((atts && atts.value) || []).filter(function (a) { return !a['@odata.type'] || /fileAttachment$/i.test(a['@odata.type']); })
      .filter(function (a) { return !a.isInline || /\.pdf$/i.test(a.name || ''); })
      .map(function (a) { return { id: a.id, filename: a.name || 'attachment', mime: a.contentType || '' }; });
    return { id: String(m.id || ''), from: (f.name ? f.name + ' <' + (f.address || '') + '>' : (f.address || '')), date: String(m.receivedDateTime || '').replace(/\.\d+Z$/, 'Z'),
      subject: m.subject || '', text: isHtml ? '' : String(body.content || '').slice(0, 12000), html: isHtml ? String(body.content || '').slice(0, 60000) : '', attachments: list };
  }
  // one page of a Graph listing → the ids worth fetching (money senders and subjects, never Sent or Deleted) and the next page
  function graphPage(page, skipFolders) {
    var skip = {};
    (skipFolders || []).forEach(function (f) { if (f) skip[f] = 1; });
    var ids = [], seen = 0;
    ((page && page.value) || []).forEach(function (m) {
      seen++;
      if (skip[m.parentFolderId]) return;
      var f = (m.from || m.sender || {}).emailAddress || {};
      if (wantHeader({ from: (f.name || '') + ' <' + (f.address || '') + '>', subject: m.subject || '' })) ids.push(m.id);
    });
    return { ids: ids, seen: seen, next: (page && page['@odata.nextLink']) || '' };
  }
  // Graph's filter for a window of days: "receivedDateTime ge 2026-01-01T00:00:00Z and receivedDateTime lt …"
  function graphFilter(after, before) {
    return 'receivedDateTime ge ' + after + 'T00:00:00Z' + (before ? ' and receivedDateTime lt ' + before + 'T00:00:00Z' : '');
  }

  /* ------------------------------------------------------------ providers: who's who, and where their mail lives */
  var PROVIDERS = [
    { id: 'gmail', name: 'Gmail', sub: 'Google, including Workspace', kind: 'google', color: '#EA4335',
      domains: ['gmail.com', 'googlemail.com'] },
    { id: 'microsoft', name: 'Outlook', sub: 'Outlook, Hotmail, Live, MSN and Microsoft 365', kind: 'microsoft', color: '#0078D4',
      domains: ['outlook.com', 'outlook.in', 'hotmail.com', 'hotmail.co.in', 'hotmail.co.uk', 'live.com', 'live.in', 'live.co.uk', 'msn.com', 'passport.com', 'windowslive.com'] },
    { id: 'yahoo', name: 'Yahoo Mail', sub: 'yahoo.com, yahoo.co.in, ymail, rocketmail', kind: 'imap', color: '#6001D2',
      domains: ['yahoo.com', 'yahoo.co.in', 'yahoo.in', 'yahoo.co.uk', 'ymail.com', 'rocketmail.com'],
      servers: [{ host: 'imap.mail.yahoo.com', port: 993, user: 'email' }],
      passwordURL: 'https://login.yahoo.com/account/security/app-passwords', password: 'app',
      steps: ['Open Yahoo’s account security page (the button below) and sign in.', 'Tap Generate app password, name it kosh, and copy the 16 letters.', 'Paste them here. Your Yahoo password itself is never asked for.'] },
    { id: 'icloud', name: 'iCloud Mail', sub: 'icloud.com, me.com, mac.com', kind: 'imap', color: '#1C8CF8',
      domains: ['icloud.com', 'me.com', 'mac.com'],
      servers: [{ host: 'imap.mail.me.com', port: 993, user: 'local' }, { host: 'imap.mail.me.com', port: 993, user: 'email' }],
      passwordURL: 'https://account.apple.com/account/manage', password: 'app',
      steps: ['Open your Apple Account page (the button below) and sign in.', 'Go to Sign-In and Security › App-Specific Passwords, add one named kosh.', 'Paste it here (it looks like abcd-efgh-ijkl-mnop).'] },
    { id: 'aol', name: 'AOL Mail', sub: 'aol.com, aim.com', kind: 'imap', color: '#3D59AB',
      domains: ['aol.com', 'aol.in', 'aim.com'],
      servers: [{ host: 'imap.aol.com', port: 993, user: 'email' }],
      passwordURL: 'https://login.aol.com/account/security/app-passwords', password: 'app',
      steps: ['Open AOL’s account security page (the button below) and sign in.', 'Tap Generate app password, name it kosh, and copy it.', 'Paste it here.'] },
    { id: 'zoho', name: 'Zoho Mail', sub: 'zoho.com, zohomail, zoho.in', kind: 'imap', color: '#E42527',
      domains: ['zoho.com', 'zohomail.com', 'zoho.in', 'zohomail.in'],
      servers: [{ host: 'imap.zoho.in', port: 993, user: 'email' }, { host: 'imap.zoho.com', port: 993, user: 'email' }, { host: 'imappro.zoho.in', port: 993, user: 'email' }, { host: 'imappro.zoho.com', port: 993, user: 'email' }],
      passwordURL: 'https://accounts.zoho.in/home#security/app_password', password: 'app',
      steps: ['In Zoho Mail, open Settings › Mail Accounts and turn on IMAP access.', 'Open Zoho Accounts › Security › App Passwords (the button below) and create one named kosh.', 'Paste it here.'] },
    { id: 'rediff', name: 'Rediffmail', sub: 'rediffmail.com', kind: 'imap', color: '#E2231A',
      domains: ['rediffmail.com', 'rediff.com'],
      servers: [{ host: 'imap.rediffmail.com', port: 993, user: 'email' }, { host: 'imap.rediffmailpro.com', port: 993, user: 'email' }],
      password: 'own',
      steps: ['Use your Rediffmail password.', 'Rediff may not let other apps read free accounts. If it refuses, set Rediffmail to forward mail to an inbox kosh reads.'] },
    { id: 'imap', name: 'Another email', sub: 'Work, your own domain, any mail with IMAP', kind: 'imap', color: '#8E8E93',
      domains: [], servers: [], password: 'own',
      steps: ['Use your email password, or an app password if your provider has two-step sign-in.', 'kosh finds the mail server for most addresses; type it in if it doesn’t.'] },
  ];
  function providerFor(email) {
    var dom = String(email || '').toLowerCase().split('@')[1] || '';
    for (var i = 0; i < PROVIDERS.length; i++) if (PROVIDERS[i].domains.indexOf(dom) >= 0) return PROVIDERS[i];
    return null;
  }
  // the IMAP servers to try for an address, in order: its provider's, then what the address's own domain suggests
  function serversFor(email, providerId) {
    var dom = String(email || '').toLowerCase().split('@')[1] || '';
    // "Another email" with a Yahoo or iCloud address still goes to Yahoo's or iCloud's servers
    var p = (providerId && providerId !== 'imap' ? PROVIDERS.filter(function (x) { return x.id === providerId; })[0] : null) || providerFor(email) ||
      PROVIDERS.filter(function (x) { return x.id === 'imap'; })[0];
    var out = (p && p.servers ? p.servers.slice() : []);
    if (dom && (!p || p.id === 'imap')) {
      out.push({ host: 'imap.' + dom, port: 993, user: 'email' });
      out.push({ host: 'mail.' + dom, port: 993, user: 'email' });
    }
    return out;
  }
  // Thunderbird's directory of mail servers (autoconfig XML) → its IMAP servers over TLS
  function ispdb(xml) {
    var out = [], re = /<incomingServer\s+type="imap"[^>]*>([\s\S]*?)<\/incomingServer>/gi, m;
    while ((m = re.exec(String(xml || '')))) {
      var b = m[1];
      function tag(t) { var x = new RegExp('<' + t + '>\\s*([^<]*?)\\s*</' + t + '>', 'i').exec(b); return x ? x[1] : ''; }
      var sock = tag('socketType').toUpperCase(), port = +tag('port') || 993;
      if (sock !== 'SSL' && port !== 993) continue;   // kosh talks to mail servers over TLS only
      var u = tag('username');
      out.push({ host: tag('hostname'), port: port, user: /%EMAILLOCALPART%/.test(u) ? 'local' : 'email' });
    }
    return out;
  }
  function loginFor(email, user) { return user === 'local' ? String(email).split('@')[0] : String(email); }

  var api = {
    b64decode: b64decode, b64encode: b64encode, qpdecode: qpdecode, utf8: utf8, decodeText: decodeText, headerText: headerText,
    message: message, part: part, isoOf: isoOf, fetches: fetches, search: search, folders: folders, uidValidity: uidValidity,
    quote: quote, imapDay: imapDay, searchCommand: searchCommand, imapID: imapID, imapRef: imapRef, wantHeader: wantHeader,
    graphMessage: graphMessage, graphPage: graphPage, graphFilter: graphFilter, PROVIDERS: PROVIDERS, providerOf: providerFor,
    serversFor: serversFor, ispdb: ispdb, loginFor: loginFor,

    // the bridge Swift calls (strings in, strings out)
    // a FETCH of headers (UID INTERNALDATE BODY.PEEK[HEADER.FIELDS (FROM SUBJECT DATE)]) → ids worth fetching in full
    imapWantedJSON: function (resp, validity, folder) {
      var ids = [], seen = 0;
      fetches(resp).forEach(function (f) {
        if (!f.UID) return;
        seen++;
        var h = headers(String(f.HEADER || ''));
        if (wantHeader({ from: headerText(h.from || ''), subject: headerText(h.subject || '') })) ids.push(imapID(validity, f.UID, folder));
      });
      return JSON.stringify({ ids: ids, seen: seen });
    },
    // a FETCH of whole messages (UID INTERNALDATE BODY.PEEK[]) → the emails, ids as kosh keeps them
    imapMessagesJSON: function (resp, validity, folder) {
      return JSON.stringify(fetches(resp).filter(function (f) { return f.UID && typeof f.BODY === 'string'; })
        .map(function (f) { return message(f.BODY, imapID(validity, f.UID, folder), f.INTERNALDATE); }));
    },
    // one attachment out of a FETCH of its whole message, as a binary string ('' if it isn't there)
    imapPart: function (resp, path) {
      var f = fetches(resp).filter(function (x) { return typeof x.BODY === 'string'; })[0];
      return f ? part(f.BODY, path) : '';
    },
    imapSearchJSON: function (resp) { return JSON.stringify(search(resp)); },
    imapFoldersJSON: function (resp) { return JSON.stringify(folders(resp)); },
    imapUIDValidity: function (resp) { return uidValidity(resp); },
    imapSearchCommand: function (after, before) { return searchCommand(after, before || ''); },
    imapQuote: function (s) { return quote(s); },
    imapRefJSON: function (id) { return JSON.stringify(imapRef(id) || {}); },
    graphMessageJSON: function (m, atts) { return JSON.stringify(graphMessage(JSON.parse(m || '{}'), atts ? JSON.parse(atts) : null)); },
    graphPageJSON: function (page, skip) { return JSON.stringify(graphPage(JSON.parse(page || '{}'), JSON.parse(skip || '[]'))); },
    graphFilter: function (after, before) { return graphFilter(after, before || ''); },
    providersJSON: function () { return JSON.stringify(PROVIDERS); },
    providerFor: function (email) { var p = providerFor(email); return p ? p.id : ''; },
    serversForJSON: function (email, pid, xml) {
      var list = ispdb(xml || '').concat(serversFor(email, pid || '')), seen = {}, out = [];
      list.forEach(function (s) { var k = s.host + ':' + s.port + ':' + s.user; if (s.host && !seen[k]) { seen[k] = 1; out.push({ host: s.host, port: s.port, login: loginFor(email, s.user) }); } });
      return JSON.stringify(out);
    },
    wantHeaderJSON: function (h) { return wantHeader(JSON.parse(h)) ? 'yes' : ''; },
  };
  // Swift calls everything through KoshEngine
  for (var k in api) if (Object.prototype.hasOwnProperty.call(api, k) && /JSON$|^imap|^graph|^provider|^serversFor|^wantHeader/.test(k)) E[k] = api[k];
  return api;
})(typeof KoshEngine !== 'undefined' ? KoshEngine : require('./engine.js'));
if (typeof module !== 'undefined' && module.exports) module.exports = KoshMail;
