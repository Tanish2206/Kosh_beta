import Foundation
import UIKit

// MARK: - Mail read while the phone is locked: a background download session
//
// iOS gives an app about half a minute once it leaves the screen. A background URLSession isn't bound by that: iOS
// itself downloads what it was handed, with kosh suspended (or closed by the system), and wakes kosh when the
// downloads are done so it can read them in. So when kosh leaves the screen with mail listed but not yet read (a
// read's plan, reading.json), the next few hundred emails go to the session as plain Gmail requests, each carrying
// its inbox's access token. Each email that comes back is read exactly as one read on screen (the same decoding,
// Gmail.decode, the same rules) and struck off the plan only once it's in the records (LiveSession.takeDelivered);
// the records are saved before the plan. Then the next batch goes, with a fresh token, until the plans are read.
//
// An email that doesn't come back (its token ran out, Gmail was busy, the phone lost the internet) is simply still
// on the list for the next run. A read on the phone works from the front of each list and the downloads from the
// back, so the two rarely meet; when they do, neither reads an email twice. Back on screen, whatever is still on its
// way is cancelled, what already came is read in, and the read on screen carries on from the plan.
//
// The first batch goes out in the moment kosh starts to leave the screen, while iOS still starts downloads at once;
// iOS starts a batch handed over with kosh in the background when it sees fit (often soon, on Wi-Fi). The tokens
// are kept fresh while kosh reads on screen, so that first hand-over needs no network.

/// One email handed to the background downloads, and where it goes when it comes back: its read (the plan's job),
/// the window of mail it was listed in (LiveSession.windowTag), the inbox, and Gmail's id. Carried in the task's
/// description, so it survives kosh being closed and opened again by iOS.
struct MailTicket: Codable, Hashable {
    var job: String
    var key: String
    var acct: String
    var id: String

    /// "inbox/id": one email, whatever read it was listed for
    var slot: String { acct + "/" + id }

    var text: String? {
        guard let d = try? JSONEncoder().encode(self) else { return nil }
        return String(data: d, encoding: .utf8)
    }
    static func of(_ text: String?) -> MailTicket? {
        guard let text, let d = text.data(using: .utf8) else { return nil }
        return try? JSONDecoder().decode(MailTicket.self, from: d)
    }
}

@MainActor
final class BackgroundMail {
    static let shared = BackgroundMail()
    nonisolated static var identifier: String { (Bundle.main.bundleIdentifier ?? "app.kosh") + ".mail" }

    /// emails on their way at most: under a minute of one inbox's Gmail allowance (a whole email costs 60 of its 6,000
    /// units a minute: about 85 emails at kosh's ceiling, QuotaGate), so the downloads, which iOS runs at its own pace and
    /// no bucket can slow, don't run into "too many"; and few enough to be read in within the time iOS gives kosh when it
    /// wakes it. (An email Google turns away anyway stays on the list for the next batch: arrived(_:_:status:).)
    static var batch: Int { Swift.max(20, Int(QuotaGate.ceiling / QuotaPace.fullMail)) }
    /// a token is handed over only if it lasts this many minutes more; below it, a fresh one is fetched first
    static let lasting: Double = 40

    private let delegate = MailDelegate()
    private var session: URLSession?
    /// what iOS gave kosh to call once it has read in what the downloads brought back (it woke kosh for them)
    private var wake: (() -> Void)?
    private var wakeGrace: UIBackgroundTaskIdentifier = .invalid
    /// emails on their way ("inbox/id")
    private(set) var onTheWay: Set<String> = []
    /// emails back and not yet read in (kosh's files still locked away, or a read-in under way)
    private var waiting: [(MailTicket, MailMsg)] = []
    private var draining: Task<Void, Never>?
    /// kosh is off screen and the downloads are carrying its reading
    private(set) var away = false
    /// emails read in from the downloads since kosh left the screen
    private(set) var readAway = 0
    /// inboxes whose token ran out before their emails came (401): the next batch takes a fresh one
    private var expired: Set<String> = []
    private var handing = false
    private var warming = false
    private var warmedAt = Date.distantPast

    var inFlight: Int { onTheWay.count }
    /// handing a batch over, or reading in what came: more is on its way in a moment
    var busy: Bool { handing || draining != nil || !waiting.isEmpty }

    /// Once, as kosh launches (in front, or woken by iOS for these very downloads): the session is made again under
    /// its name, so what it brought back while kosh wasn't running is handed over.
    func start() {
        guard session == nil else { return }
        let c = URLSessionConfiguration.background(withIdentifier: Self.identifier)
        c.sessionSendsLaunchEvents = true
        c.isDiscretionary = false
        c.httpMaximumConnectionsPerHost = 6
        c.timeoutIntervalForRequest = 60
        // an email still not here after most of an hour won't be: its token has run out (it stays on the list)
        c.timeoutIntervalForResource = 55 * 60
        c.allowsCellularAccess = true
        session = URLSession(configuration: c, delegate: delegate, delegateQueue: delegate.queue)
        Task { await self.recount() }
        // kosh woken while the phone was still locked from a restart: what came back is read in once it's unlocked
        NotificationCenter.default.addObserver(forName: UIApplication.protectedDataDidBecomeAvailableNotification, object: nil, queue: .main) { _ in
            MainActor.assumeIsolated { BackgroundMail.shared.drainSoon() }
        }
    }

    /// iOS launched or woke kosh for what the downloads brought back: `done` is called once it's all read in
    func relaunched(_ done: @escaping () -> Void) {
        start()
        wake?()
        wake = done
        // the time to read it in, if iOS is slow to say it has handed everything over
        if wakeGrace == .invalid {
            wakeGrace = UIApplication.shared.beginBackgroundTask(withName: "kosh mail") {
                MainActor.assumeIsolated { BackgroundMail.shared.wokeOver() }
            }
        }
    }

    // MARK: handing the reading over

    /// kosh is leaving the screen: the mail still to read goes to the downloads now, while iOS still starts them at
    /// once (kosh is on its way out, not yet in the background). Without a token in hand that lasts, a fresh one is
    /// fetched and the batch goes a moment later.
    func leaving() {
        guard !away else { return }
        away = true
        readAway = 0
        expired = []
        handOffNow()
        // an inbox without a token in hand (or room left in the batch): its share goes once a fresh token is here
        if (LiveSession.current?.leftToDownload ?? 0) > onTheWay.count {
            Task { await self.handOff() }
        }
    }

    /// The next batch, with the tokens in hand (no network: for the moment kosh leaves, or as its time runs out);
    /// returns how many went.
    @discardableResult
    func handOffNow() -> Int {
        guard let live = LiveSession.current, live.loadedFromDisk, live.signedIn else { return 0 }
        live.strikeRead()
        let picks: [MailTicket] = live.downloadPicks(limit: Self.batch - onTheWay.count, skipping: onTheWay)
        guard !picks.isEmpty else { return 0 }
        var tokens: [String: String] = [:]
        for acct in Set(picks.map(\.acct)) where !expired.contains(acct) {
            if let t = live.heldToken(acct, minutes: Self.lasting - 15) { tokens[acct] = t }
        }
        return send(picks, tokens)
    }

    /// The next batch, with a token for each inbox that lasts (fetched if need be): when iOS has woken kosh, or
    /// gives it time to catch up.
    func handOff() async {
        guard !handing, let live = LiveSession.current else { return }
        handing = true
        defer { handing = false }
        live.reloadIfNeeded()
        guard live.loadedFromDisk, live.signedIn else { return }
        live.strikeRead()
        let picks: [MailTicket] = live.downloadPicks(limit: Self.batch - onTheWay.count, skipping: onTheWay)
        guard !picks.isEmpty else { return }
        var tokens: [String: String] = [:]
        for acct in Set(picks.map(\.acct)) {
            if let t = try? await live.lastingToken(acct, minutes: Self.lasting) { tokens[acct] = t }
        }
        expired.subtract(tokens.keys)
        // (anything picked that a read on screen got to while the tokens came is simply not read twice)
        send(picks.filter { !onTheWay.contains($0.slot) }, tokens)
    }

    /// each email as a GET of the whole message, with its inbox's token; an inbox without one waits for the next run
    @discardableResult
    private func send(_ picks: [MailTicket], _ tokens: [String: String]) -> Int {
        if session == nil { start() }
        guard let s = session, !picks.isEmpty else { return 0 }
        var n = 0
        var sent: [String: Int] = [:]
        for t in picks {
            guard let tok = tokens[t.acct], let url = Gmail.messageURL(t.id), let desc = t.text else { continue }
            var req = URLRequest(url: url)
            req.setValue("Bearer " + tok, forHTTPHeaderField: "Authorization")
            req.setValue("application/json", forHTTPHeaderField: "Accept")
            let task = s.downloadTask(with: req)
            task.taskDescription = desc
            // about what one email weighs, so iOS can plan the transfers
            task.countOfBytesClientExpectsToSend = 1024
            task.countOfBytesClientExpectsToReceive = 48 * 1024
            task.resume()
            onTheWay.insert(t.slot)
            n += 1
            sent[t.acct, default: 0] += 1
        }
        // what these cost comes out of each inbox's allowance, so a read on screen waits its turn behind them
        // (a whole email, format=full: Gmail.messageURL)
        for (acct, k) in sent { Task { await QuotaGate.shared.spend(acct, Double(k) * QuotaPace.fullMail) } }
        if n > 0 { ReadingLive.shared.refresh() }
        return n
    }

    // MARK: what comes back

    /// one download back, in the order they came: an email to read in; one Gmail no longer has (deleted since it was
    /// listed), struck off as a read on screen would; or (its token ran out, Gmail was busy) one left on the list for
    /// the next run
    func arrived(_ t: MailTicket, _ m: MailMsg?, status: Int) {
        onTheWay.remove(t.slot)
        guard let m else {
            if status == 401 {
                expired.insert(t.acct)
                LiveSession.current?.forgetToken(t.acct)
            } else if status == 404 || status == 400 || status == 410 || status == 200 {
                // (a 200 that couldn't be read as a message is passed over too, as on screen)
                LiveSession.current?.takeGone(t)
            }
            return
        }
        waiting.append((t, m))
        drainSoon()
    }

    /// a download is over, whether it came back or not
    func finished(_ t: MailTicket?) {
        if let t { onTheWay.remove(t.slot) }
    }

    /// iOS has handed over everything the downloads brought back: read it in, save, send the next batch (with a fresh
    /// token) if there's more to read, tell the Lock Screen, and only then let iOS suspend kosh again
    func eventsDone() {
        Task { @MainActor in
            await self.draining?.value
            _ = await self.drain()
            await self.recount()
            if let live = LiveSession.current, live.loadedFromDisk {
                live.strikeRead()
                live.deliveredSaved(0, force: true)
                // back in front meanwhile: the read on screen has it from here
                if UIApplication.shared.applicationState != .active { await self.handOff() }
            }
            ReadingLive.shared.settle()
            // the reminders and the widgets follow what came in, before iOS suspends kosh again
            if let live = LiveSession.current, UIApplication.shared.applicationState != .active { await BackgroundReading.settle(live) }
            self.wokeOver()
        }
    }

    /// iOS is told kosh is done with what it was woken for
    private func wokeOver() {
        let done = wake
        wake = nil
        done?()
        if wakeGrace != .invalid {
            UIApplication.shared.endBackgroundTask(wakeGrace)
            wakeGrace = .invalid
        }
    }

    func drainSoon() {
        guard draining == nil, !waiting.isEmpty else { return }
        draining = Task { @MainActor in
            let readable: Bool = await self.drain()
            self.draining = nil
            // more came while the last was read in
            if readable && !self.waiting.isEmpty { self.drainSoon() }
        }
    }

    /// What came back, read in fifteen at a time, with a breath between (the screen never stalls if kosh is in front);
    /// saved as it goes (records first, then the plan). False if it can't be read in yet: kosh's files are still
    /// locked away after a restart, and it's kept until they open.
    private func drain() async -> Bool {
        guard !waiting.isEmpty else { return true }
        guard let live = LiveSession.current else { return false }
        live.reloadIfNeeded()
        guard live.loadedFromDisk else { return false }
        while !waiting.isEmpty {
            let n: Int = min(15, waiting.count)
            let some = Array(waiting.prefix(n))
            waiting.removeFirst(n)
            var read = 0
            for (t, m) in some {
                if live.takeDelivered(m, t) { read += 1 }
            }
            readAway += read
            live.deliveredSaved(read)
            ReadingLive.shared.refresh()
            try? await Task.sleep(for: .milliseconds(UIApplication.shared.applicationState == .active ? 40 : 2))
        }
        return true
    }

    /// what's still on its way, as the session itself has it
    private func recount() async {
        guard let s = session else { onTheWay = []; return }
        let tasks: [URLSessionTask] = await withCheckedContinuation { (c: CheckedContinuation<[URLSessionTask], Never>) in
            s.getAllTasks { c.resume(returning: $0) }
        }
        onTheWay = Set(tasks.filter { $0.state == .running || $0.state == .suspended }.compactMap { MailTicket.of($0.taskDescription)?.slot })
    }

    // MARK: kosh in front again, and the tokens

    /// kosh is on screen again: whatever is still on its way is cancelled (the read on screen carries on from the
    /// plan), and what already came is read in
    func backInFront() {
        away = false
        expired = []
        session?.getAllTasks { tasks in tasks.forEach { $0.cancel() } }
        onTheWay = []
        drainSoon()
    }

    /// everything stops and nothing that comes back is read in (kosh's data erased)
    func cancelAll() {
        session?.getAllTasks { tasks in tasks.forEach { $0.cancel() } }
        onTheWay = []
        waiting = []
    }

    /// each second while kosh reads (KeepGoing's tick): once a minute, on screen, every inbox with mail still to read
    /// gets a token that lasts, so handing the reading over as kosh leaves needs no network
    func tick() {
        guard !warming, Date().timeIntervalSince(warmedAt) > 60, UIApplication.shared.applicationState == .active,
              let live = LiveSession.current, live.loadedFromDisk, live.signedIn else { return }
        warmedAt = Date()
        let accts: [String] = live.inboxesToDownload.filter { live.tokenMinutes($0) < Self.lasting + 5 }
        guard !accts.isEmpty else { return }
        warming = true
        Task { @MainActor in
            for a in accts { _ = try? await live.lastingToken(a, minutes: Self.lasting + 5) }
            self.warming = false
        }
    }
}

// MARK: - The session's events, on its own queue

/// Each download is read before iOS deletes its file (it goes as soon as the call returns), decoded here, off the
/// main thread, and handed to BackgroundMail on the main actor, in the order they came.
final class MailDelegate: NSObject, URLSessionDownloadDelegate, @unchecked Sendable {
    let queue: OperationQueue = {
        let q = OperationQueue()
        q.name = "kosh.mail"
        q.maxConcurrentOperationCount = 1
        q.qualityOfService = .utility
        return q
    }()

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
        guard let t = MailTicket.of(downloadTask.taskDescription) else { return }
        var status: Int = (downloadTask.response as? HTTPURLResponse)?.statusCode ?? 0
        var msg: MailMsg? = nil
        if status == 200 {
            if let data = try? Data(contentsOf: location) {
                msg = try? Gmail.decode(data)
            } else {
                // the file couldn't be opened here: not the email's fault, so it stays on the list
                status = 0
            }
        }
        let m: MailMsg? = msg
        let code: Int = status
        DispatchQueue.main.async {
            MainActor.assumeIsolated { BackgroundMail.shared.arrived(t, m, status: code) }
        }
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        let t: MailTicket? = MailTicket.of(task.taskDescription)
        DispatchQueue.main.async {
            MainActor.assumeIsolated { BackgroundMail.shared.finished(t) }
        }
    }

    func urlSessionDidFinishEvents(forBackgroundURLSession session: URLSession) {
        DispatchQueue.main.async {
            MainActor.assumeIsolated { BackgroundMail.shared.eventsDone() }
        }
    }
}
