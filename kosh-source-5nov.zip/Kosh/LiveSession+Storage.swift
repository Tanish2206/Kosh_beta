import Foundation
import Observation
import UIKit
import Network
import SQLite3

// MARK: - LiveSession: the files kosh keeps on this phone: loading, saving (one queue), checkpoints and reading plans
// (split out of LiveSession.swift, 17 Oct 2026; its stored state stays in the class there)

extension LiveSession {
    // MARK: files on this phone (encrypted while the phone is locked)

    struct Profile: Codable {
        var people: [PersonInfo]; var owners: [String: String]; var hidden: [String]; var overrides: [String: Override]
        var accounts: [MailAccount]?; var userPolicies: [UserPolicy]?; var userLoans: [UserLoan]?
        var userHoldings: [UserHolding]?; var docHoldings: [UserHolding]?; var properties: [UserProperty]?
        var localDocs: [LocalDoc]?
        var hiddenPolicies: [String]?
        var rejected: [String: [String]]?
        var epfJobs: [EPFJob]?
        var committees: [UserCommittee]?
        var readings: [WorthReading]?
        var statements: [StmtDoc]?
        var balances: [String: TypedBalance]?
        var trips: [UserTrip]?
        var facts: [DocFact]?
        var deposits: [DocDeposit]?
        var trades: [Trade]?
        /// what you said about repeats, by id: "no" (not a repeat), "gone:yyyy-MM-dd" (cancelled that day)
        var repeats: [String: String]?
        /// bills you marked paid, by the calendar item's id: the day you marked it
        var paid: [String: String]?
        var fundSegs: [FundSeg]?
        /// what you said about a policy, by its key: "active" (still running), "ended" (no longer running)
        var policyMarks: [String: String]? = nil
        /// budgets, the plan, the briefings, money owed, what you added, your UPI ID, Claude's brief (nil: an older file)
        var money: MoneyBits? = nil
        /// what you said about your deposits (Deposits.swift › DepFix)
        var depFix: DepFix? = nil
        /// what you typed for a policy where its mail says nothing, by its key; whose health cover is held elsewhere
        var policyFill: [String: [String: String]]? = nil
        var healthElsewhere: [String: String]? = nil
        /// the credit limits you typed, by card id
        var cardLimit: [String: Double]? = nil
        /// the names you gave payees, by payee key
        var payeeNames: [String: String]? = nil
        enum CodingKeys: String, CodingKey {
            case people, owners, hidden, overrides, accounts, userPolicies, userLoans, userHoldings, docHoldings, properties, localDocs,
                 hiddenPolicies, rejected, epfJobs, committees, readings, statements, balances, trips, facts, deposits, trades, repeats, paid, fundSegs, policyMarks,
                 money
            case depFix
            case policyFill, healthElsewhere
            case cardLimit
            case payeeNames
        }
    }

    /// The money you set or added that lived in plain UserDefaults until 18 Oct 2026, now in the protected profile:
    /// the month's budget and each category's, the plan (goals, the salary split) and the briefings as the engine's JSON,
    /// money owed to you and the shares settled, what you added by hand or from a photo, your UPI ID, and the day's
    /// brief from Claude ("d": its day, "t": its words). Read part by part, like the rest of the profile.
    struct MoneyBits: Codable {
        var budget: Double = 0
        var budgets: [String: Double] = [:]
        var plan: String = ""
        var brief: String = ""
        var owed: [OwedItem] = []
        var settled: [String] = []
        var captures: [Capture] = []
        var upi: String = ""
        var agentBrief: [String: String] = [:]
        // the second move (18 Oct 2026, later the same day): the account payments through an app (CRED, a gateway)
        // leave, what you said about your bank accounts (the engine's acctFix JSON), the payees Claude was asked about
        // and when, what kosh noticed that you marked done or snoozed, when each heads-up was set to ring, and the
        // bills you snoozed. Times are seconds since 1970.
        var railFrom: [String: String] = [:]
        var acctFix: String = ""
        var askedPayees: [String: Double] = [:]
        var hushed: [String: Double] = [:]
        var noticedAt: [String: Double] = [:]
        var snoozed: [String: Double] = [:]
        /// the live views pinned to Home (LiveViewCore.swift): each a plan, the question asked again on each build
        var liveViews: [LivePin] = []
        enum CodingKeys: String, CodingKey {
            case budget, budgets, plan, brief, owed, settled, captures, upi, agentBrief
            case railFrom, acctFix, askedPayees, hushed, noticedAt, snoozed
            case liveViews
        }
        init() {}
        init(from decoder: Decoder) throws {
            let c = try decoder.container(keyedBy: CodingKeys.self)
            typealias L = LiveSession
            budget = L.lossyValue(c, .budget, Double.self) ?? 0
            budgets = L.lossyMap(c, .budgets, Double.self) ?? [:]
            plan = L.lossyValue(c, .plan, String.self) ?? ""
            brief = L.lossyValue(c, .brief, String.self) ?? ""
            owed = L.lossyList(c, .owed, OwedItem.self) ?? []
            settled = L.lossyList(c, .settled, String.self) ?? []
            captures = L.lossyList(c, .captures, Capture.self) ?? []
            upi = L.lossyValue(c, .upi, String.self) ?? ""
            agentBrief = L.lossyValue(c, .agentBrief, [String: String].self) ?? [:]
            railFrom = L.lossyMap(c, .railFrom, String.self) ?? [:]
            acctFix = L.lossyValue(c, .acctFix, String.self) ?? ""
            askedPayees = L.lossyMap(c, .askedPayees, Double.self) ?? [:]
            hushed = L.lossyMap(c, .hushed, Double.self) ?? [:]
            noticedAt = L.lossyMap(c, .noticedAt, Double.self) ?? [:]
            snoozed = L.lossyMap(c, .snoozed, Double.self) ?? [:]
            liveViews = L.lossyList(c, .liveViews, LivePin.self) ?? []
        }

        /// where they lived before, read once to carry them over (Store kept its own per household: "kosh." is yours)
        static let oldKeys: [String] = ["beta.budget", "beta.budgets", "beta.plan", "beta.brief",
                                        "kosh.owed", "kosh.settled", "kosh.captures", "kosh.upi", "agent.brief"]
        static func fromDefaults(_ ud: UserDefaults) -> MoneyBits {
            var m = MoneyBits()
            m.budget = ud.double(forKey: "beta.budget")
            m.budgets = (ud.dictionary(forKey: "beta.budgets") as? [String: Double]) ?? [:]
            m.plan = ud.string(forKey: "beta.plan") ?? ""
            m.brief = ud.string(forKey: "beta.brief") ?? ""
            m.owed = Saved.load("kosh.owed", [OwedItem]())
            m.settled = Saved.load("kosh.settled", [String]())
            m.captures = Saved.load("kosh.captures", [Capture]())
            m.upi = ud.string(forKey: "kosh.upi") ?? ""
            m.agentBrief = (ud.dictionary(forKey: "agent.brief") as? [String: String]) ?? [:]
            m.takeLater(ud)
            return m
        }
        /// the second move's keys. Carried in whenever the phone's defaults hold them: a profile written before they
        /// moved, or a snooze or a heads-up set while the profile couldn't be read yet (OwnTimes). Dropped like the first.
        static let laterKeys: [String] = ["beta.railFrom", "beta.acctFix", "agent.askedPayees", "watch.hushed", "kosh.noticedAt", "kosh.snoozed"]
        static func laterInDefaults(_ ud: UserDefaults) -> Bool { laterKeys.contains { ud.object(forKey: $0) != nil } }
        /// what the defaults hold of the second move's keys, laid over these: what you set in the profile wins for the
        /// accounts (only an older phone has them in the defaults), the later time wins for the rest
        mutating func takeLater(_ ud: UserDefaults) {
            if let d = ud.dictionary(forKey: "beta.railFrom") as? [String: String] { railFrom.merge(d) { mine, _ in mine } }
            if acctFix.isEmpty, let s = ud.string(forKey: "beta.acctFix") { acctFix = s }
            func times(_ k: String) -> [String: Double] { (ud.dictionary(forKey: k) as? [String: Double]) ?? [:] }
            askedPayees.merge(times("agent.askedPayees")) { a, b in max(a, b) }
            hushed.merge(times("watch.hushed")) { a, b in max(a, b) }
            noticedAt.merge(times("kosh.noticedAt")) { a, b in max(a, b) }
            snoozed.merge(times("kosh.snoozed")) { a, b in max(a, b) }
        }
        static func inDefaults(_ ud: UserDefaults) -> Bool { oldKeys.contains { ud.object(forKey: $0) != nil } || laterInDefaults(ud) }
        /// the old keys go, once the profile holding what they held is on the disk
        static func dropDefaults(_ ud: UserDefaults) { for k in oldKeys + laterKeys { ud.removeObject(forKey: k) } }
    }

    /// kosh.noticedAt, kosh.snoozed and agent.askedPayees wherever they live now: in the protected profile once it
    /// has been read (MoneyBits), in the phone's defaults before that and in the bundled builds (the profile takes
    /// them in when it's read: MoneyBits.takeLater). From the main thread, like every other change to the profile.
    enum OwnTimes {
        case noticedAt, snoozed, askedPayees
        var key: String {
            switch self {
            case .noticedAt: return "kosh.noticedAt"
            case .snoozed: return "kosh.snoozed"
            case .askedPayees: return "agent.askedPayees"
            }
        }
        var path: WritableKeyPath<MoneyBits, [String: Double]> {
            switch self {
            case .noticedAt: return \.noticedAt
            case .snoozed: return \.snoozed
            case .askedPayees: return \.askedPayees
            }
        }
    }
    static func times(_ t: OwnTimes) -> [String: Double] {
        if let l = current, l.loadedFromDisk { return l.own[keyPath: t.path] }
        return (UserDefaults.standard.dictionary(forKey: t.key) as? [String: Double]) ?? [:]
    }
    static func setTimes(_ t: OwnTimes, _ v: [String: Double]) {
        if let l = current, l.loadedFromDisk {
            guard l.own[keyPath: t.path] != v else { return }
            l.own[keyPath: t.path] = v
            l.save()
            return
        }
        UserDefaults.standard.set(v, forKey: t.key)
    }

    /// the money bits as the profile is read in: its own, or (an older file) the old UserDefaults keys, carried over
    func takeMoney(_ saved: MoneyBits?) {
        var m: MoneyBits
        if let saved {
            m = saved
            if MoneyBits.laterInDefaults(ud) {
                // a profile from before the second move (or a snooze set before it could be read): what the defaults
                // hold comes in, and the keys go once the profile holding it is written
                m.takeLater(ud)
                moneyFromDefaults = true
            } else {
                moneyFromDefaults = false
                // carried over before, and the profile holding them read back: anything left behind goes
                if MoneyBits.inDefaults(ud) { MoneyBits.dropDefaults(ud) }
            }
        } else {
            m = MoneyBits.fromDefaults(ud)
            moneyFromDefaults = MoneyBits.inDefaults(ud)
        }
        loadingProfile = true
        budget = m.budget; budgets = m.budgets; planJSON = m.plan; briefJSON = m.brief
        railFrom = m.railFrom; acctFixJSON = m.acctFix
        own = m
        loadingProfile = false
    }

    /// the money bits as they are now, for the profile
    var moneyNow: MoneyBits {
        var m: MoneyBits = own
        m.budget = budget; m.budgets = budgets; m.plan = planJSON; m.brief = briefJSON
        m.railFrom = railFrom; m.acctFix = acctFixJSON
        return m
    }

    /// a balance you typed for an account (read off your bank's app), and when: kosh carries it
    /// forward with every payment after that moment
    struct TypedBalance: Codable, Hashable { var v: Double; var at: String }

    /// GUARDRAIL a saved file is read part by part and item by item: an item this version can't read (a field it
    /// now needs, a value it no longer knows) is left out and counted, never the whole file. Before this, one new
    /// field in one policy made the whole profile unreadable, and the next save wrote an empty one over it.
    struct Lossy<T: Decodable>: Decodable {
        let v: T?
        init(from decoder: Decoder) throws { v = try? T(from: decoder) }
    }

    struct LossyList<T: Decodable>: Decodable {
        var items: [T] = []
        var dropped = 0
        init(from decoder: Decoder) throws {
            var c = try decoder.unkeyedContainer()
            while !c.isAtEnd {
                guard let x = try? c.decode(Lossy<T>.self) else { dropped += 1; break }
                if let v = x.v { items.append(v) } else { dropped += 1 }
            }
        }
    }

    struct LossyMap<T: Decodable>: Decodable {
        var items: [String: T] = [:]
        var dropped = 0
        init(from decoder: Decoder) throws {
            let raw = try [String: Lossy<T>](from: decoder)
            for (k, x) in raw { if let v = x.v { items[k] = v } else { dropped += 1 } }
        }
    }

    /// what reading the files left out, said on Home (reset at each load)
    nonisolated(unsafe) static var droppedOnLoad = 0

    /// the records as read off the main thread at launch: unreadable (the phone not unlocked since it started); the
    /// database's rows (RecordStore), with how many this version couldn't read and how many a newer kosh wrote; the
    /// database damaged and set aside, with the copy that stands in (nil: none could be read); or records.json's bytes
    /// and what they decoded to (nil: the file is damaged), when there is no database yet (and its readings were moved
    /// into one, if they could be: RecordStore.importAll) or it couldn't be made
    enum RecordsRead {
        case unreadable
        case read(Data, (value: LossyList<Reading>, found: Int)?)
        case db(items: [Reading], dropped: Int, newer: Int)
        case dbDamaged([Reading]?)
    }
    /// (screen-free; it touches nothing shared but RecordStore, behind its lock: the records' decoding counts nothing in
    /// droppedOnLoad, the profile's does)
    static func readRecords(_ url: URL) -> RecordsRead {
        switch RecordStore.shared.load() {
        case .rows(let items, let dropped, let newer):
            return .db(items: items, dropped: dropped, newer: newer)
        case .unreadable:
            return .unreadable
        case .damaged:
            // the last good copy (exported from the database, a day old at most) first, then records.json as it was at the move
            for u in [lastGood(url), url] {
                if let d = try? Data(contentsOf: u), let l = try? SavedFormat.decode(LossyList<Reading>.self, d, .records).value { return .dbDamaged(l.items) }
            }
            return .dbDamaged(nil)
        case .absent:
            break
        }
        // no database yet: records.json as before, its readings then moved into a new one (records.json is kept as it is)
        guard FileManager.default.fileExists(atPath: url.path) else { return .db(items: [], dropped: 0, newer: 0) }
        let t0: CFAbsoluteTime = CFAbsoluteTimeGetCurrent()
        guard let d = try? Data(contentsOf: url) else { return .unreadable }
        let t1: CFAbsoluteTime = CFAbsoluteTimeGetCurrent()
        let o: (value: LossyList<Reading>, found: Int)? = try? SavedFormat.decode(LossyList<Reading>.self, d, .records)
        Perf.shared.record("startup · records read, off screen", ms: (t1 - t0) * 1000)
        Perf.shared.record("startup · records decoded, off screen", ms: (CFAbsoluteTimeGetCurrent() - t1) * 1000)
        // (a damaged file isn't moved: load() reads the last good copy as before, and this launch saves records.json)
        if let o { _ = RecordStore.shared.importAll(o.value.items) } else { RecordStore.shared.useJSON() }
        return .read(d, o)
    }

    static func lossyList<T: Decodable, K: CodingKey>(_ c: KeyedDecodingContainer<K>, _ k: K, _ t: T.Type) -> [T]? {
        guard c.contains(k), (try? c.decodeNil(forKey: k)) != true else { return nil }
        guard let l = try? c.decode(LossyList<T>.self, forKey: k) else { droppedOnLoad += 1; return nil }
        droppedOnLoad += l.dropped
        return l.items
    }

    static func lossyMap<T: Decodable, K: CodingKey>(_ c: KeyedDecodingContainer<K>, _ k: K, _ t: T.Type) -> [String: T]? {
        guard c.contains(k), (try? c.decodeNil(forKey: k)) != true else { return nil }
        guard let m = try? c.decode(LossyMap<T>.self, forKey: k) else { droppedOnLoad += 1; return nil }
        droppedOnLoad += m.dropped
        return m.items
    }

    static func lossyValue<T: Decodable, K: CodingKey>(_ c: KeyedDecodingContainer<K>, _ k: K, _ t: T.Type) -> T? {
        guard c.contains(k), (try? c.decodeNil(forKey: k)) != true else { return nil }
        guard let v = try? c.decode(T.self, forKey: k) else { droppedOnLoad += 1; return nil }
        return v
    }

    @MainActor

    func setBalance(_ accountID: String, _ v: Double?) {
        if let v {
            let f = DateFormatter()
            f.locale = Locale(identifier: "en_US_POSIX"); f.timeZone = TimeZone(identifier: "Asia/Kolkata"); f.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
            typedBalances[accountID] = TypedBalance(v: v, at: f.string(from: Date()))
        } else {
            typedBalances[accountID] = nil
        }
        save(); rebuild()
    }

    /// what a statement or a page said holdings were worth on a day (by class), kept so net worth can be
    /// drawn over time from what's dated rather than guessed
    struct WorthReading: Codable, Hashable { var src: String; var d: String; var o: String; var v: [String: Double] }

    func noteReading(src: String, date: String, owner: String, values: [String: Double]) {
        let d = String(date.prefix(10))
        guard !src.isEmpty, d.range(of: #"^\d{4}-\d{2}-\d{2}$"#, options: .regularExpression) != nil else { return }
        let r = WorthReading(src: src, d: d, o: owner, v: values.filter { $0.value > 0 })
        readings.removeAll { $0.src == src && $0.d == d }
        readings.append(r)
        // a few years of monthly statements from a handful of places is a few hundred; keep the newest
        if readings.count > 3000 { readings = Array(readings.sorted { $0.d < $1.d }.suffix(3000)) }
    }

    /// kosh's own folder: made the first time it is asked for, then the same URL without touching the disk (every
    /// records, profile and snapshot path asks for it, a few times a mail during a re-read). Erase calls folderGone().
    static var folder: URL {
        folderLock.lock(); defer { folderLock.unlock() }
        if !folderMade {
            try? FileManager.default.createDirectory(at: folderBase, withIntermediateDirectories: true)
            folderMade = true
        }
        return folderBase
    }
    private static let folderBase: URL = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("kosh-beta", isDirectory: true)
    private static let folderLock = NSLock()
    nonisolated(unsafe) private static var folderMade = false
    /// the folder is gone (Erase removed it): the next look makes it again
    static func folderGone() { folderLock.lock(); folderMade = false; folderLock.unlock() }

    var recordsURL: URL { Self.folder.appendingPathComponent("records.json") }

    var profileURL: URL { Self.folder.appendingPathComponent("profile.json") }

    var plansURL: URL { Self.folder.appendingPathComponent("reading.json") }

    /// kosh's files stay encrypted until the phone is first unlocked after it starts; after that they can be
    /// read and written while it's locked, so reading carries on with the screen off. (With complete protection
    /// nothing could be saved about ten seconds after locking, and what was read while locked was lost.)
    static let protection: Data.WritingOptions = .completeFileProtectionUntilFirstUserAuthentication

    /// the same for files written before: records, profile, statements and photos
    func relaxProtection() {
        // once a launch, and off the main thread: the walk over every sealed mail took a moment of the opening
        guard !Self.relaxedThisLaunch else { return }
        Self.relaxedThisLaunch = true
        let base = Self.folder
        DispatchQueue.global(qos: .utility).async {
            let fm = FileManager.default
            let attrs: [FileAttributeKey: Any] = [.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication]
            try? fm.setAttributes(attrs, ofItemAtPath: base.path)
            guard let walk = fm.enumerator(at: base, includingPropertiesForKeys: [.fileProtectionKey]) else { return }
            for case let u as URL in walk {
                if (try? u.resourceValues(forKeys: [.fileProtectionKey]).fileProtection) == .completeUntilFirstUserAuthentication { continue }
                try? fm.setAttributes(attrs, ofItemAtPath: u.path)
            }
        }
    }
    /// set by the first load of this launch (on the main thread)
    static var relaxedThisLaunch: Bool = false

    func load() {
        let fm = FileManager.default
        var okRecords = true, okProfile = true
        var profileRead = false
        var wordsMoved = false
        var said: [String] = []
        Self.droppedOnLoad = 0
        /* the records (every email's reading, the biggest file: half a second to decode at 5,000 on a phone) are read
           and decoded off the main thread while the settings are read on it; the main thread waits only for what is
           left of them. Nothing looks at `records` before they're in (the settings need them only after, below) */
        let recURL: URL = recordsURL
        // (always: the database, records.json to move into it, or neither, which sets RecordStore up empty)
        let recordsSoon: Prefetch<RecordsRead>? = Prefetch { Self.readRecords(recURL) }
        // (the settings' file read here, meanwhile; what it says is taken in after the records, as before)
        var profileData: Data? = nil
        var profileUnreadable = false
        if fm.fileExists(atPath: profileURL.path) {
            do { profileData = try Data(contentsOf: profileURL) } catch { profileUnreadable = true }
        }
        Self.droppedOnLoad = 0
        // (in whatever shape a kosh wrote it: SavedFormat)
        let profileOpened: (value: Profile, found: Int)? = profileData.flatMap { d in
            Perf.shared.measure("startup · profile decoded") { try? SavedFormat.decode(Profile.self, d, .profile) }
        }
        if let recordsSoon {
            switch Perf.shared.measure("startup · records waited", { recordsSoon.wait() }) ?? .unreadable {
            case .unreadable:
                okRecords = false
            case .db(let items, let dropped, let newer):
                // the database's rows, each on its own: a row this version can't read is left out (and left in the
                // database, for a kosh that can), with a copy of the database set aside (RecordStore.load)
                records = items
                if dropped > 0 { said.append("\(dropped) saved emails couldn’t be read by this version and were left out (a copy of the file was saved)") }
                if newer > 0 { said.append(Self.newerWords("saved emails")) }
            case .dbDamaged(let back):
                // the database was damaged and moved aside whole (RecordStore): yesterday's copy, or records.json as it
                // was at the move, stands in; this launch saves records.json, and the next moves it into a new database
                if let back {
                    records = back
                    said.append("your saved emails were damaged, so kosh went back to an earlier copy (the damaged file was set aside)")
                } else {
                    keepAside(recordsURL)
                    said.append("your saved emails couldn’t be read; a copy of the file was saved")
                }
            case .read(_, let o?):
                // each email's reading on its own: one this version can't read is left out, not all of them. The file
                // in whatever shape a kosh wrote it (SavedFormat), brought up to today's
                let l: LossyList<Reading> = o.value
                records = l.items
                if l.dropped > 0 { keepAside(recordsURL); said.append("\(l.dropped) saved emails couldn’t be read by this version and were left out (a copy of the file was saved)") }
                if o.found > SavedFormat.File.records.version { keepAside(recordsURL); said.append(Self.newerWords("saved emails")) }
            case .read(_, nil):
                if let back = try? Data(contentsOf: Self.lastGood(recordsURL)), let l = try? SavedFormat.decode(LossyList<Reading>.self, back, .records).value {
                    // the file itself is damaged: the last good copy (a day old at most) stands in
                    keepAside(recordsURL)
                    records = l.items
                    said.append("your saved emails were damaged, so kosh went back to yesterday’s copy (the damaged file was set aside)")
                } else {
                    keepAside(recordsURL)
                    said.append("your saved emails couldn’t be read; a copy of the file was saved")
                }
            }
        }
        if profileUnreadable { okProfile = false }
        if profileData != nil {
            do {
                let o0: (value: Profile, found: Int)? = profileOpened
                var p0: Profile? = o0?.value
                if let o0, o0.found > SavedFormat.File.profile.version { keepAside(profileURL); said.append(Self.newerWords("settings")) }
                // an older shape: kept as it was, once, before the first save writes today's
                if let o0, o0.found < SavedFormat.File.profile.version { SavedFormat.keepBefore(profileURL, version: o0.found) }
                if p0 == nil, let back = try? Data(contentsOf: Self.lastGood(profileURL)), let p1 = try? SavedFormat.decode(Profile.self, back, .profile).value {
                    keepAside(profileURL)
                    said.append("your settings file was damaged, so kosh went back to yesterday’s copy (the damaged file was set aside)")
                    p0 = p1
                }
                if Self.droppedOnLoad > 0, p0 != nil {
                    keepAside(profileURL)
                    said.append("\(Self.droppedOnLoad) saved items couldn’t be read by this version and were left out (a copy of the file was saved)")
                }
                do {
                    guard let p = p0 else { throw LiveError.engine("profile") }
                    people = p.people; owners = p.owners; hidden = Set(p.hidden); overrides = p.overrides
                    accounts = p.accounts ?? []; userPolicies = p.userPolicies ?? []; userLoans = p.userLoans ?? []
                    userHoldings = p.userHoldings ?? []; docHoldings = p.docHoldings ?? []; properties = p.properties ?? []
                    localDocs = p.localDocs ?? []
                    hiddenPolicies = p.hiddenPolicies ?? []
                    rejected = p.rejected ?? [:]
                    epfJobs = p.epfJobs ?? []
                    userCommittees = p.committees ?? []
                    readings = p.readings ?? []
                    statements = p.statements ?? []
                    typedBalances = p.balances ?? [:]
                    userTrips = p.trips ?? []
                    docFacts = p.facts ?? []
                    docDeposits = p.deposits ?? []
                    trades = p.trades ?? []
                    repeatMarks = p.repeats ?? [:]
                    paidMarks = p.paid ?? [:]
                    fundSegs = p.fundSegs ?? []
                    policyMarks = p.policyMarks ?? [:]
                    policyFill = p.policyFill ?? [:]
                    healthElsewhere = p.healthElsewhere ?? [:]
                    cardLimit = p.cardLimit ?? [:]
                    payeeNames = p.payeeNames ?? [:]
                    depFix = p.depFix ?? DepFix()
                    takeMoney(p.money)
                    if migrateWords() { wordsMoved = true }
                    // every other inbox's lasting tag, given once (the records are read in above)
                    if tagInboxes() { wordsMoved = true }
                    profileRead = true
                } catch { keepAside(profileURL); said.append("your settings couldn’t be read; a copy was saved") }
            }
        }
        if !said.isEmpty { loadProblem = "kosh opened with a problem: " + said.joined(separator: "; ") + "." }
        loadedFromDisk = okRecords && okProfile
        if loadedFromDisk && loadProblem?.hasPrefix("kosh started while") == true { loadProblem = nil }
        if !loadedFromDisk { loadProblem = "kosh started while your phone was locked. Your data is safe; it opens as soon as you unlock." }
        if loadedFromDisk {
            // no profile yet (or none that could be read): what the old UserDefaults keys hold comes over
            if !profileRead { takeMoney(nil) }
            relaxProtection()
            Perf.shared.measure("startup · plans") { loadPlans() }
            Perf.shared.measure("startup · CAS parts") { redoCASParts() }
            if !trades.isEmpty { Perf.shared.measure("startup · gains") { recomputeGains() } }
            Perf.shared.measure("startup · learned rules") { LearnedRules.install() }
            Perf.shared.measure("startup · layout book") { LayoutBook.install() }
            tripLegs = Perf.shared.measure("startup · trip legs") { Self.loadTripLegs() }
            // carried over from the old keys: into the protected file now (the keys go once it's written); the same for
            // words saved as they used to be said
            if moneyFromDefaults || wordsMoved { save() }
        }
    }

    /// what kosh saved in words it no longer says, said the new way (the profile is read back into these on every
    /// launch, so an older one keeps working): "Kept out of spending" is now "Left out of spending". True when any
    /// changed, to be saved.
    func migrateWords() -> Bool {
        let old: String = Store.leftOutBefore, now: String = Store.leftOut
        var changed = false
        for (k, o) in overrides {
            var x: Override = o
            if x.ex == old { x.ex = now }
            if var ps = x.parts {
                for i in ps.indices where ps[i].ex == old { ps[i].ex = now }
                x.parts = ps
            }
            if x != o { overrides[k] = x; changed = true }
        }
        return changed
    }

    /// where the long reads had got to when kosh last saved; a plan over three days old is dropped
    func loadPlans() {
        guard let d = try? Data(contentsOf: plansURL), let f = try? SavedFormat.decode(ReadingFile.self, d, .plans).value else { plans = [:]; return }
        plans = f.plans.filter { !$0.value.stale }
        interrupted = Set(plans.keys)
        if plans.count != f.plans.count { writePlans() }
    }

    func writePlans() {
        guard loadedFromDisk else { return }
        // the records first: a plan never says more was read than is saved. Both go through the one save queue, in
        // order, so reading.json can't reach the disk before the records it describes (a kill between the two
        // writes left emails marked read that were never stored)
        unsaved = 0; lastCheckpoint = Date(); save()
        let url = plansURL
        // (turned into JSON on the save queue: a re-read's plan lists thousands of emails)
        let file: ReadingFile? = plans.isEmpty ? nil : ReadingFile(plans: plans)
        Self.saveQueue.async {
            if let file, let data = try? JSONEncoder().encode(file) { try? SavedFormat.write(data, .plans, to: url, options: [.atomic, Self.protection]) } else { try? FileManager.default.removeItem(at: url) }
        }
    }

    /// The records and where the reading had got to, saved together (the records first, so reading.json never
    /// says more was read than is saved). Often enough that little is lost if kosh is stopped: every ~10 s or ~300
    /// emails, and whenever kosh is asked to stop. (Only the readings that changed are written: RecordStore)
    func checkpoint(_ read: Int = 0, force: Bool = false) {
        unsaved += read
        guard force || unsaved >= 300 || Date().timeIntervalSince(lastCheckpoint) >= 10 else { return }
        lastCheckpoint = Date()
        unsaved = 0
        Perf.shared.measure("checkpoint") {
            Perf.shared.measure("save") { save() }
            Perf.shared.measure("write plans") { writePlans() }
            Perf.shared.measure("layout book") { LayoutBook.save() }
        }
    }

    /// kosh is going to the background: what's been read is saved now, with what's still to read
    func checkpointIfReading() {
        if hasPlans || unsaved > 0 { checkpoint(force: true) }
    }

    /// a usable plan for a job: not stale, and over the same inboxes (otherwise it's dropped and listed afresh)
    func plan(_ job: String) -> ReadingPlan? {
        guard let p = plans[job] else { return nil }
        if p.stale || p.accounts != allAccounts { plans[job] = nil; return nil }
        return p
    }

    /// a job carrying on from a plan: if it was cut short, the bar says so for a few seconds
    @MainActor

    func pickUp(_ job: String) {
        guard interrupted.remove(job) != nil else { return }
        pickingUp = true
        let mark = Date()
        pickUpMark = mark
        Task { [weak self] in
            try? await Task.sleep(for: .seconds(3))
            if self?.pickUpMark == mark { self?.pickingUp = false }
        }
    }

    /// a job stopped before the end (its time ran out): its plan stays, and carrying it on says so
    @MainActor

    func cutShort(_ job: String) {
        note(job + ": cut short (" + (halted ? "kosh stopped" : "no internet") + ")")
        interrupted.insert(job)
        checkpoint(force: true)
    }

    /// the file's last good copy, kept beside it once a day (LiveSession.save): what a damaged file is read from
    nonisolated static func lastGood(_ url: URL) -> URL { url.deletingPathExtension().appendingPathExtension("lastgood.json") }

    /// before a file is written over: if its last good copy is a day old, the file as it is becomes the new one (if it
    /// is whole: a damaged file never replaces a good copy)
    nonisolated static func offBackups(_ url: URL) {
        var u = url
        var v = URLResourceValues(); v.isExcludedFromBackup = true
        try? u.setResourceValues(v)
    }

    nonisolated static func keepLastGood(_ url: URL) {
        let fm = FileManager.default
        let back = lastGood(url)
        let age = ((try? fm.attributesOfItem(atPath: back.path))?[.modificationDate] as? Date).map { Date().timeIntervalSince($0) } ?? .infinity
        guard age > 86400, let d = try? Data(contentsOf: url), (try? JSONSerialization.jsonObject(with: d)) != nil else { return }
        try? d.write(to: back, options: [.atomic, LiveSession.protection])
    }

    /// what Home says when a file was written by a newer kosh than this one (a build put back): read as well as this
    /// one can, and the file as it was kept beside it
    static func newerWords(_ what: String) -> String {
        "your " + what + " were saved by a newer kosh; this one read what it could (a copy of the file was saved)"
    }

    /// a file this version can't read is kept beside it (dated), never overwritten
    func keepAside(_ url: URL) {
        let stamp = Self.iso(Date()).replacingOccurrences(of: "-", with: "")
        let copy = url.deletingPathExtension().appendingPathExtension("unread-" + stamp + ".json")
        if !FileManager.default.fileExists(atPath: copy.path) { try? FileManager.default.copyItem(at: url, to: copy) }
    }

    /// read the files in once the phone is unlocked, if they couldn't be read at start; then catch up
    @MainActor

    func reloadIfNeeded() {
        recheckSignIn()
        guard !loadedFromDisk else { return }
        load()
        guard loadedFromDisk else { return }
        // the Keychain was locked away too if kosh started before the phone was first unlocked
        recheckSignIn()
        rereadDocumentsIfReaderChanged()
        rebuild()
    }

    /// writes happen here, one after another, off the main thread: a tap that changes a row never waits on the disk
    static let saveQueue = DispatchQueue(label: "kosh.save", qos: .utility)

    /// the newest save handed over (read on the save queue, so behind a lock, never a hop to the main thread)
    static let saveLock = NSLock()

    nonisolated(unsafe) static var saveGen: Int = 0
    /// the saves that carry the records, numbered: only the newest one waiting writes them (under saveLock)
    nonisolated(unsafe) static var recordsGen: Int = 0

    /// wait for the writes already handed over (before kosh goes to the background, or a backup reads the files)
    func flushSaves() { Self.saveQueue.sync {} }

    func save() {
        guard loadedFromDisk else { return }
        // what to write is taken now (copies of values, cheap); turning it into JSON and onto the disk happens on the
        // save queue. A newer save supersedes a waiting one, so a burst of taps writes once.
        // the records (every email's reading, the biggest file) are written again only when reading changed them: a
        // change to a setting or a row writes the small profile alone. In the database (RecordStore, the norm) only the
        // readings that changed are written; in records.json (this launch couldn't use the database) all of them
        let inDB: Bool = RecordStore.shared.mode == .db
        let recordsAt: URL = inDB ? RecordStore.url : recordsURL
        let recs: [Reading]? = (recordsVersion != savedRecordsVersion || !FileManager.default.fileExists(atPath: recordsAt.path)) ? records : nil
        /* (each save that carries the records takes a number: one still waiting when a later one with newer records is
           queued skips the records, since the later one writes them whole. Through a re-read of thousands of mails the
           records were otherwise encoded and written, and the last good copy made, once for every save on the way, each
           time the whole file: the disk work grew with the square of the mailbox) */
        Self.saveLock.lock(); Self.saveGen &+= 1; let gen: Int = Self.saveGen
        if recs != nil { Self.recordsGen &+= 1 }
        let rgen: Int = Self.recordsGen; Self.saveLock.unlock()
        let version: Int = recordsVersion
        let recordsURL: URL = self.recordsURL, profileURL: URL = self.profileURL
        let p = Profile(people: people, owners: owners, hidden: Array(hidden), overrides: overrides,
                        accounts: accounts, userPolicies: userPolicies, userLoans: userLoans,
                        userHoldings: userHoldings, docHoldings: docHoldings, properties: properties, localDocs: localDocs,
                        hiddenPolicies: hiddenPolicies, rejected: rejected, epfJobs: epfJobs, committees: userCommittees, readings: readings, statements: statements,
                        balances: typedBalances, trips: userTrips, facts: docFacts, deposits: docDeposits, trades: trades, repeats: repeatMarks,
                        paid: paidMarks, fundSegs: fundSegs, policyMarks: policyMarks, money: moneyNow, depFix: depFix.isEmpty ? nil : depFix,
                        policyFill: policyFill.isEmpty ? nil : policyFill, healthElsewhere: healthElsewhere.isEmpty ? nil : healthElsewhere,
                        cardLimit: cardLimit.isEmpty ? nil : cardLimit, payeeNames: payeeNames.isEmpty ? nil : payeeNames)
        // what came over from the old UserDefaults keys: they go once this file is written
        let dropOld: Bool = moneyFromDefaults
        if recs != nil { savedRecordsVersion = version }
        Self.saveQueue.async { [weak self] in
            Self.saveLock.lock(); let newerRecords: Bool = Self.recordsGen != rgen; Self.saveLock.unlock()
            if let recs, !newerRecords, inDB {
                // the readings that changed, in one transaction; then the last good copy, if it's a day old, from them
                if RecordStore.shared.save(recs) {
                    RecordStore.keepLastGood(recs, to: Self.lastGood(recordsURL))
                } else {
                    DispatchQueue.main.async { self?.savedRecordsVersion = -1 }
                }
            } else if let recs, !newerRecords, let body = try? JSONEncoder().encode(recs) {
                Self.keepLastGood(recordsURL)
                if (try? SavedFormat.write(body, .records, to: recordsURL, options: [.atomic, Self.protection])) == nil {
                    DispatchQueue.main.async { self?.savedRecordsVersion = -1 }
                } else {
                    // every email's reading (and the text of the ones kosh wasn't sure of) can be read again from the
                    // inbox: it stays off backups. What you set (profile.json) is backed up with the phone
                    Self.offBackups(recordsURL); Self.offBackups(Self.lastGood(recordsURL))
                }
            }
            // a newer profile is already on its way: skip this one
            Self.saveLock.lock(); let latest: Bool = Self.saveGen == gen; Self.saveLock.unlock()
            guard latest || recs != nil else { return }
            if let body = try? JSONEncoder().encode(p) {
                Self.keepLastGood(profileURL)
                let wrote: Bool = (try? SavedFormat.write(body, .profile, to: profileURL, options: [.atomic, Self.protection])) != nil
                if wrote && dropOld {
                    MoneyBits.dropDefaults(UserDefaults.standard)
                    DispatchQueue.main.async { self?.moneyFromDefaults = false }
                }
            }
        }
        ud.set(email, forKey: "beta.email")
        ud.set(name, forKey: "beta.name")
        ud.set(scanFrom, forKey: "beta.scanFrom")
        ud.set(lastScan, forKey: "beta.lastScan")
    }

    func setClientID(_ s: String) {
        let v = s.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !v.isEmpty else { return }
        clientID = v
        ud.set(v, forKey: "beta.clientID")
    }

    func setClaudeKey(_ k: String?) {
        Keychain.set(k?.trimmingCharacters(in: .whitespacesAndNewlines), for: "claude.key")
        claudeReady = !(Keychain.get("claude.key") ?? "").isEmpty
    }
}

// MARK: - the profile, read part by part (LiveSession › Lossy)

extension LiveSession.Profile {
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        typealias L = LiveSession
        people = L.lossyList(c, .people, PersonInfo.self) ?? []
        owners = L.lossyValue(c, .owners, [String: String].self) ?? [:]
        hidden = L.lossyList(c, .hidden, String.self) ?? []
        overrides = L.lossyMap(c, .overrides, Override.self) ?? [:]
        accounts = L.lossyList(c, .accounts, MailAccount.self)
        userPolicies = L.lossyList(c, .userPolicies, UserPolicy.self)
        userLoans = L.lossyList(c, .userLoans, UserLoan.self)
        userHoldings = L.lossyList(c, .userHoldings, UserHolding.self)
        docHoldings = L.lossyList(c, .docHoldings, UserHolding.self)
        properties = L.lossyList(c, .properties, UserProperty.self)
        localDocs = L.lossyList(c, .localDocs, LocalDoc.self)
        hiddenPolicies = L.lossyList(c, .hiddenPolicies, String.self)
        rejected = L.lossyValue(c, .rejected, [String: [String]].self)
        epfJobs = L.lossyList(c, .epfJobs, LiveSession.EPFJob.self)
        committees = L.lossyList(c, .committees, UserCommittee.self)
        readings = L.lossyList(c, .readings, LiveSession.WorthReading.self)
        statements = L.lossyList(c, .statements, LiveSession.StmtDoc.self)
        balances = L.lossyMap(c, .balances, LiveSession.TypedBalance.self)
        trips = L.lossyList(c, .trips, UserTrip.self)
        facts = L.lossyList(c, .facts, DocFact.self)
        deposits = L.lossyList(c, .deposits, DocDeposit.self)
        trades = L.lossyList(c, .trades, Trade.self)
        repeats = L.lossyValue(c, .repeats, [String: String].self)
        paid = L.lossyValue(c, .paid, [String: String].self)
        fundSegs = L.lossyList(c, .fundSegs, FundSeg.self)
        policyMarks = L.lossyValue(c, .policyMarks, [String: String].self)
        policyFill = L.lossyValue(c, .policyFill, [String: [String: String]].self)
        healthElsewhere = L.lossyValue(c, .healthElsewhere, [String: String].self)
        cardLimit = L.lossyValue(c, .cardLimit, [String: Double].self)
        payeeNames = L.lossyValue(c, .payeeNames, [String: String].self)
        money = L.lossyValue(c, .money, LiveSession.MoneyBits.self)
        depFix = L.lossyValue(c, .depFix, DepFix.self)
    }
}

/// One piece of work started now on another thread, its answer taken later (waiting then only for what is left of it):
/// how a launch reads its biggest files side by side instead of one after another on the main thread. The answer can
/// be taken more than once
final class Prefetch<T>: @unchecked Sendable {
    private let done = DispatchSemaphore(value: 0)
    private let lock = NSLock()
    private var value: T?
    private var landed = false
    init(qos: DispatchQoS.QoSClass = .userInitiated, _ work: @escaping () -> T?) {
        DispatchQueue.global(qos: qos).async { [self] in
            let v: T? = work()
            lock.lock(); value = v; landed = true; lock.unlock()
            done.signal()
        }
    }
    /// the answer, waited for if it hasn't come yet
    func wait() -> T? {
        lock.lock()
        if landed { let v: T? = value; lock.unlock(); return v }
        lock.unlock()
        done.wait()
        // (and on to anyone else waiting)
        done.signal()
        lock.lock(); defer { lock.unlock() }
        return value
    }
}

// MARK: - the records in a database (records.sqlite), saved row by row
//
// Until 5 Nov 2026 every checkpoint (every ~10 s or ~300 emails of a read) encoded every email's reading again and wrote
// the whole of records.json: the disk work of one save grew with the mailbox, and a year's re-read wrote the file
// hundreds of times. The records now live in a SQLite database beside it (the system's own SQLite, `import SQLite3`):
//
//     records(k TEXT PRIMARY KEY, seq INTEGER, v INTEGER, updated REAL, body BLOB)    one row a reading
//     meta(k TEXT PRIMARY KEY, v TEXT)                                                 "imported": when it was made
//
// k is the reading's id (a second reading with the same id, which ingest never makes but an old file may hold, gets
// "id\u{1F}2"); seq its place in `records`, so the order comes back as it was; v the row's shape (RecordStore.schema,
// also PRAGMA user_version); body the reading's own JSON (Codable), as records.json held it. A save hands the queue
// the whole list (a copy, cheap); on the save queue each reading's hash is compared with the one kept in memory for
// what's in the database, and only the readings that changed are encoded and written, the ones that only moved get a
// new seq, and the ones gone are deleted: all in one transaction, so a save is whole or not at all. WAL with
// synchronous FULL: a save is on the disk before the reading plan that follows it on the same queue (records first).
//
// What stays as it was: the one save queue, its order and its superseding; the files' protection (sqlite opens the
// database, -wal and -shm with completeUntilFirstUserAuthentication, and they're set so again after each save) and their
// staying off backups, like records.json; reading item by item (a row this version can't read is left out, counted,
// said on Home, and kept in the database for a kosh that can, with a copy set aside); a database a newer kosh wrote
// is read as well as this one can, with a copy kept first; the last good copy, a day old at most, now exported from
// the database in records.json's own shape (records.lastgood.json), so everything that reads it still does.
//
// The move: the first launch with this code finds records.json and no database (or one with no rows that was never
// filled), reads the file as before, imports every reading in one transaction and checks the count. records.json is
// left as it was, a fallback; from then on the database is the book. If the import fails, its database goes (records.json
// has all of it) and this launch saves records.json as before (Mode.json); the next launch tries again.
//
// When it can't be read: a database whose bytes can't be opened is the phone not unlocked since it started, the same
// as records.json: nothing is saved (loadedFromDisk) and it's read again on unlock. Any other failure that isn't damage
// is treated the same way, never as empty. A damaged one (SQLITE_CORRUPT, SQLITE_NOTADB) is moved aside whole (renamed,
// with its -wal and -shm), yesterday's copy (else records.json) stands in, this launch saves records.json, and the
// next imports it again. Erase closes it and deletes the database, -wal and -shm.
//
// One connection (FULLMUTEX), used behind `lock`: loading (off the main thread at launch, before any save can be
// handed over) and the saves (on the save queue). Mode and the counts for the diagnostics sit behind their own small
// lock, so the main thread never waits on the disk to read them.

/// sqlite copies what's bound (the key and the reading's bytes) before the bind returns
private let SQLITE_TRANSIENT = unsafeBitCast(-1, to: sqlite3_destructor_type.self)

final class RecordStore: @unchecked Sendable {
    static let shared = RecordStore()

    /// the shape of a row today (each row's v, and the database's user_version)
    static let schema: Int = 1
    /// SQLITE_OPEN_FILEPROTECTION_COMPLETEUNTILFIRSTUSERAUTHENTICATION (Apple's sqlite3.h): the files sqlite makes for the
    /// database (-wal, -shm) get the class LiveSession.protection gives records.json
    private static let protectionFlag: Int32 = 0x00300000
    /// between an id and the count of a second reading with that id (never in an id kosh makes)
    private static let dupMark: String = "\u{1F}"

    static var url: URL { LiveSession.folder.appendingPathComponent("records.sqlite") }
    /// the database and the two files sqlite keeps beside it in WAL mode
    static var files: [URL] {
        let p: String = url.path
        return [URL(fileURLWithPath: p), URL(fileURLWithPath: p + "-wal"), URL(fileURLWithPath: p + "-shm")]
    }

    /// where the records are saved this launch: the database, or records.json as before (the database couldn't be
    /// made, or was damaged: the next launch imports again)
    enum Mode { case db, json }

    /// what loading found
    enum Loaded {
        /// the database's readings in order; rows this version couldn't read, and rows a newer kosh wrote
        case rows(items: [Reading], dropped: Int, newer: Int)
        /// not readable now (the phone not unlocked since it started, or a failure that isn't damage): nothing is saved
        case unreadable
        /// damaged, and moved aside: records.json's path stands in this launch
        case damaged
        /// no database yet (or one never filled): import records.json, or start empty
        case absent
    }

    private struct Entry { var h: Int; var seq: Int }

    /// the connection and what's in the database, by key (hash, seq): behind `lock`
    private let lock = NSLock()
    private var db: OpaquePointer?
    private var saved: [String: Entry] = [:]

    /// the mode and the counts for the diagnostics: behind `small`
    private let small = NSLock()
    private var modeNow: Mode = .db
    private var stats: [String: Any] = [:]

    var mode: Mode { small.lock(); defer { small.unlock() }; return modeNow }
    private func setMode(_ m: Mode) { small.lock(); modeNow = m; stats["mode"] = m == .db ? "sqlite" : "json"; small.unlock() }
    private func note(_ k: String, _ v: Any) { small.lock(); stats[k] = v; small.unlock() }

    /// for the diagnostics: where the records are saved and what the last save wrote (no figures, no names)
    func summary() -> [String: Any] {
        small.lock(); defer { small.unlock() }
        var s: [String: Any] = stats
        s["mode"] = modeNow == .db ? "sqlite" : "json"
        return s
    }

    // MARK: loading

    /// the readings in the database, read row by row (a row this version can't read is counted and left in place)
    func load() -> Loaded {
        lock.lock(); defer { lock.unlock() }
        closeLocked()
        saved = [:]
        setMode(.db)
        let fm = FileManager.default
        let path: String = Self.url.path
        guard fm.fileExists(atPath: path) else { return .absent }
        // bytes that can't be read at all: still sealed (the phone not unlocked since it started). Read again on unlock
        guard let fh = FileHandle(forReadingAtPath: path) else { note("error", "sealed"); return .unreadable }
        do { _ = try fh.read(upToCount: 16) } catch { try? fh.close(); note("error", "sealed"); return .unreadable }
        try? fh.close()
        let t0: CFAbsoluteTime = CFAbsoluteTimeGetCurrent()
        let rc: Int32 = openLocked(create: false)
        guard rc == SQLITE_OK else { return failLocked(rc) }
        guard let shape = intLocked("PRAGMA user_version"), let count = intLocked("SELECT COUNT(*) FROM records"),
              let marked = intLocked("SELECT COUNT(*) FROM meta WHERE k = 'imported'") else { return failLocked(lastRC) }
        // never filled (an import cut short before its commit): as if there were none
        if count == 0 && marked == 0 { return .absent }
        guard let db else { return failLocked(SQLITE_MISUSE) }
        var st: OpaquePointer?
        var step: Int32 = sqlite3_prepare_v2(db, "SELECT k, seq, v, body FROM records ORDER BY seq", -1, &st, nil)
        guard step == SQLITE_OK, let st else { sqlite3_finalize(st); return failLocked(step) }
        let dec = JSONDecoder()
        var items: [Reading] = []
        items.reserveCapacity(count)
        var map: [String: Entry] = [:]
        map.reserveCapacity(count)
        var dropped = 0, newer = 0
        while true {
            step = sqlite3_step(st)
            guard step == SQLITE_ROW else { break }
            guard let kp = sqlite3_column_text(st, 0) else { dropped += 1; continue }
            let k: String = String(cString: kp)
            let seq: Int = Int(sqlite3_column_int64(st, 1))
            let v: Int = Int(sqlite3_column_int64(st, 2))
            // (the blob first, then its length, as sqlite asks; the bytes are copied before the next step)
            let bp: UnsafeRawPointer? = sqlite3_column_blob(st, 3)
            let n: Int = Int(sqlite3_column_bytes(st, 3))
            guard let bp, n > 0, let r = try? dec.decode(Reading.self, from: Data(bytes: bp, count: n)) else { dropped += 1; continue }
            if v > Self.schema { newer += 1 }
            items.append(r)
            map[k] = Entry(h: Self.hash(r), seq: seq)
        }
        sqlite3_finalize(st)
        guard step == SQLITE_DONE else { return failLocked(step) }
        if shape > Self.schema && newer == 0 { newer = 1 }
        // a copy kept first, as for records.json: of a database a newer kosh wrote (once a version), and of one holding
        // rows this version couldn't read (once a day; the rows themselves stay, for a kosh that can)
        if newer > 0 { copyAsideLocked("v" + String(max(shape, Self.schema + 1))) }
        if dropped > 0 { copyAsideLocked("unread-" + Self.stamp(time: false)) }
        saved = map
        sealFiles()
        note("loaded", items.count); note("unreadRows", dropped); note("newerRows", newer)
        Perf.shared.record("startup · records read from the database, off screen", ms: (CFAbsoluteTimeGetCurrent() - t0) * 1000)
        return .rows(items: items, dropped: dropped, newer: newer)
    }

    /// The move from records.json: every reading in one transaction, the rows counted back. False (and the database
    /// that was being made gone: records.json holds all of it): this launch saves records.json as before
    func importAll(_ items: [Reading]) -> Bool {
        lock.lock(); defer { lock.unlock() }
        closeLocked()
        saved = [:]
        let t0: CFAbsoluteTime = CFAbsoluteTimeGetCurrent()
        var ok: Bool = openLocked(create: true) == SQLITE_OK && writeLocked(items)
        if ok { ok = intLocked("SELECT COUNT(*) FROM records") == items.count && saved.count == items.count }
        guard ok else {
            note("error", "import failed: " + errLocked())
            closeLocked()
            saved = [:]
            for u in Self.files { try? FileManager.default.removeItem(at: u) }
            setMode(.json)
            return false
        }
        setMode(.db)
        note("imported", items.count)
        Perf.shared.record("startup · records moved into the database", ms: (CFAbsoluteTimeGetCurrent() - t0) * 1000)
        return true
    }

    /// records.json couldn't be read whole (damaged): this launch saves it as before, and the next moves it in
    func useJSON() {
        lock.lock(); defer { lock.unlock() }
        closeLocked()
        saved = [:]
        setMode(.json)
    }

    // MARK: saving (on the save queue)

    /// the readings that changed since the last save written, in one transaction. False: nothing was written (the
    /// caller asks for the records again next save)
    func save(_ recs: [Reading]) -> Bool {
        lock.lock(); defer { lock.unlock() }
        guard mode == .db else { return false }
        return writeLocked(recs)
    }

    /// Erase: the connection closed, and the database, -wal and -shm gone
    func erase() {
        lock.lock(); defer { lock.unlock() }
        closeLocked()
        saved = [:]
        for u in Self.files { try? FileManager.default.removeItem(at: u) }
        small.lock(); stats = [:]; small.unlock()
        setMode(.db)
    }

    /// the last good copy, a day old at most, in records.json's own shape (what a damaged file is read from): exported
    /// from the readings just saved
    static func keepLastGood(_ recs: [Reading], to back: URL) {
        let fm = FileManager.default
        let age: TimeInterval = ((try? fm.attributesOfItem(atPath: back.path))?[.modificationDate] as? Date).map { Date().timeIntervalSince($0) } ?? .infinity
        guard age > 86400, let body = try? JSONEncoder().encode(recs) else { return }
        if (try? SavedFormat.seal(body, .records).write(to: back, options: [.atomic, LiveSession.protection])) != nil {
            LiveSession.offBackups(back)
        }
    }

    // MARK: inside (behind `lock`)

    private var lastRC: Int32 = SQLITE_OK

    private func writeLocked(_ recs: [Reading]) -> Bool {
        let t0: CFAbsoluteTime = CFAbsoluteTimeGetCurrent()
        guard openLocked(create: true) == SQLITE_OK, let db else { note("error", "open: " + errLocked()); return false }
        var next: [String: Entry] = [:]
        next.reserveCapacity(recs.count)
        var changed: [(k: String, seq: Int, r: Reading)] = []
        var moved: [(k: String, seq: Int)] = []
        for (i, r) in recs.enumerated() {
            var k: String = r.id
            if next[k] != nil {
                var n = 2
                while next[r.id + Self.dupMark + String(n)] != nil { n += 1 }
                k = r.id + Self.dupMark + String(n)
            }
            let e = Entry(h: Self.hash(r), seq: i)
            next[k] = e
            if let was = saved[k], was.h == e.h {
                if was.seq != i { moved.append((k: k, seq: i)) }
            } else {
                changed.append((k: k, seq: i, r: r))
            }
        }
        let gone: [String] = saved.keys.filter { next[$0] == nil }
        if changed.isEmpty && moved.isEmpty && gone.isEmpty { return true }

        guard exec("BEGIN IMMEDIATE") == SQLITE_OK else { note("error", "begin: " + errLocked()); return false }
        var put: OpaquePointer?, mv: OpaquePointer?, del: OpaquePointer?
        // (all three finalized below, whatever happens)
        var ok: Bool = sqlite3_prepare_v2(db, "INSERT OR REPLACE INTO records(k, seq, v, updated, body) VALUES(?, ?, ?, ?, ?)", -1, &put, nil) == SQLITE_OK
        if ok { ok = sqlite3_prepare_v2(db, "UPDATE records SET seq = ? WHERE k = ?", -1, &mv, nil) == SQLITE_OK }
        if ok { ok = sqlite3_prepare_v2(db, "DELETE FROM records WHERE k = ?", -1, &del, nil) == SQLITE_OK }
        let enc = JSONEncoder()
        let now: Double = Date().timeIntervalSince1970
        var wrote = 0, skipped = 0
        if ok {
            for c in changed {
                // a reading that can't be encoded (a figure that isn't a number) keeps its old row, and is tried again next save
                guard let body = try? enc.encode(c.r), !body.isEmpty else { skipped += 1; next[c.k] = saved[c.k]; continue }
                sqlite3_reset(put); sqlite3_clear_bindings(put)
                sqlite3_bind_text(put, 1, c.k, -1, SQLITE_TRANSIENT)
                sqlite3_bind_int64(put, 2, sqlite3_int64(c.seq))
                sqlite3_bind_int64(put, 3, sqlite3_int64(Self.schema))
                sqlite3_bind_double(put, 4, now)
                let bound: Int32 = body.withUnsafeBytes { (b: UnsafeRawBufferPointer) -> Int32 in
                    sqlite3_bind_blob(put, 5, b.baseAddress, Int32(b.count), SQLITE_TRANSIENT)
                }
                guard bound == SQLITE_OK, sqlite3_step(put) == SQLITE_DONE else { ok = false; break }
                wrote += 1
            }
        }
        if ok {
            for m in moved {
                sqlite3_reset(mv); sqlite3_clear_bindings(mv)
                sqlite3_bind_int64(mv, 1, sqlite3_int64(m.seq))
                sqlite3_bind_text(mv, 2, m.k, -1, SQLITE_TRANSIENT)
                guard sqlite3_step(mv) == SQLITE_DONE else { ok = false; break }
            }
        }
        if ok {
            for k in gone {
                sqlite3_reset(del); sqlite3_clear_bindings(del)
                sqlite3_bind_text(del, 1, k, -1, SQLITE_TRANSIENT)
                guard sqlite3_step(del) == SQLITE_DONE else { ok = false; break }
            }
        }
        if ok { ok = exec("INSERT OR IGNORE INTO meta(k, v) VALUES('imported', datetime('now'))") == SQLITE_OK }
        let why: String = ok ? "" : errLocked()
        sqlite3_finalize(put); sqlite3_finalize(mv); sqlite3_finalize(del)
        if ok { ok = exec("COMMIT") == SQLITE_OK }
        guard ok else {
            note("error", "save: " + (why.isEmpty ? errLocked() : why))
            _ = exec("ROLLBACK")
            return false
        }
        saved = next
        sealFiles()
        small.lock()
        stats["rows"] = next.count; stats["lastWrote"] = wrote; stats["lastMoved"] = moved.count; stats["lastDeleted"] = gone.count
        stats["unencodable"] = skipped; stats["lastMs"] = Int((CFAbsoluteTimeGetCurrent() - t0) * 1000)
        small.unlock()
        return true
    }

    /// the connection, opened once (and the tables made if they aren't there). The result code of what failed
    private func openLocked(create: Bool) -> Int32 {
        if db != nil { return SQLITE_OK }
        var h: OpaquePointer?
        var flags: Int32 = SQLITE_OPEN_READWRITE | SQLITE_OPEN_FULLMUTEX | Self.protectionFlag
        if create { flags |= SQLITE_OPEN_CREATE }
        let rc: Int32 = sqlite3_open_v2(Self.url.path, &h, flags, nil)
        guard rc == SQLITE_OK, let h else {
            if let h { lastRC = rc; note("error", "open: " + String(cString: sqlite3_errmsg(h))); sqlite3_close_v2(h) }
            return rc == SQLITE_OK ? SQLITE_CANTOPEN : rc
        }
        db = h
        sqlite3_busy_timeout(h, 3000)
        // (sqlite reads the file only now: a damaged one says so here)
        let setup: [String] = [
            "PRAGMA journal_mode=WAL",
            "PRAGMA synchronous=FULL",
            "CREATE TABLE IF NOT EXISTS records(k TEXT PRIMARY KEY NOT NULL, seq INTEGER NOT NULL, v INTEGER NOT NULL, updated REAL NOT NULL, body BLOB NOT NULL)",
            "CREATE TABLE IF NOT EXISTS meta(k TEXT PRIMARY KEY NOT NULL, v TEXT NOT NULL)",
        ]
        for sql in setup {
            let r: Int32 = exec(sql)
            if r != SQLITE_OK { note("error", "setup: " + errLocked()); closeLocked(); return r }
        }
        // a new database takes today's shape; a newer kosh's keeps its own
        if (intLocked("PRAGMA user_version") ?? 0) == 0 { _ = exec("PRAGMA user_version=" + String(Self.schema)) }
        sealFiles()
        return SQLITE_OK
    }

    private func closeLocked() {
        guard let h = db else { return }
        db = nil
        sqlite3_close_v2(h)
    }

    /// a failure while reading: damage moves the database aside (renamed, never deleted) and records.json's path
    /// stands in; anything else is "not now", and nothing is saved over it
    private func failLocked(_ rc: Int32) -> Loaded {
        note("error", "read: " + errLocked())
        closeLocked()
        saved = [:]
        let primary: Int32 = rc & 0xFF
        guard primary == SQLITE_CORRUPT || primary == SQLITE_NOTADB else { return .unreadable }
        let fm = FileManager.default
        let stamp: String = Self.stamp(time: true)
        let base: String = Self.url.deletingPathExtension().path + ".unread-" + stamp + ".sqlite"
        let ends: [String] = ["", "-wal", "-shm"]
        for (u, end) in zip(Self.files, ends) where fm.fileExists(atPath: u.path) {
            try? fm.moveItem(at: u, to: URL(fileURLWithPath: base + end))
        }
        setMode(.json)
        return .damaged
    }

    /// a whole copy of the database beside it ("records.v2.sqlite", "records.unread-20261105.sqlite"), once
    private func copyAsideLocked(_ tag: String) {
        let copy: URL = Self.url.deletingPathExtension().appendingPathExtension(tag + ".sqlite")
        let fm = FileManager.default
        guard !fm.fileExists(atPath: copy.path) else { return }
        // (VACUUM INTO: one consistent file, what's in the -wal included)
        if exec("VACUUM INTO '" + copy.path.replacingOccurrences(of: "'", with: "''") + "'") == SQLITE_OK {
            try? fm.setAttributes([.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication], ofItemAtPath: copy.path)
            LiveSession.offBackups(copy)
        }
    }

    /// the database, -wal and -shm: the protection records.json has, and off backups like it
    private func sealFiles() {
        let fm = FileManager.default
        let attrs: [FileAttributeKey: Any] = [.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication]
        for u in Self.files where fm.fileExists(atPath: u.path) {
            try? fm.setAttributes(attrs, ofItemAtPath: u.path)
            LiveSession.offBackups(u)
        }
    }

    private func exec(_ sql: String) -> Int32 {
        guard let db else { lastRC = SQLITE_MISUSE; return SQLITE_MISUSE }
        let rc: Int32 = sqlite3_exec(db, sql, nil, nil, nil)
        lastRC = rc
        return rc
    }

    /// one number from a query (nil: it failed, lastRC says how)
    private func intLocked(_ sql: String) -> Int? {
        guard let db else { lastRC = SQLITE_MISUSE; return nil }
        var st: OpaquePointer?
        let rc: Int32 = sqlite3_prepare_v2(db, sql, -1, &st, nil)
        guard rc == SQLITE_OK, let st else { lastRC = rc; sqlite3_finalize(st); return nil }
        defer { sqlite3_finalize(st) }
        let s: Int32 = sqlite3_step(st)
        guard s == SQLITE_ROW else { lastRC = s; return nil }
        lastRC = SQLITE_OK
        return Int(sqlite3_column_int64(st, 0))
    }

    private func errLocked() -> String {
        guard let db, let m = sqlite3_errmsg(db) else { return "rc " + String(lastRC) }
        return String(cString: m)
    }

    /// a reading's hash for this run of the app (Hasher is seeded per launch: never saved)
    static func hash(_ r: Reading) -> Int {
        var h = Hasher()
        r.hash(into: &h)
        return h.finalize()
    }

    static func stamp(time: Bool) -> String {
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX"); f.timeZone = TimeZone(identifier: "Asia/Kolkata")
        f.dateFormat = time ? "yyyyMMdd-HHmmss" : "yyyyMMdd"
        return f.string(from: Date())
    }
}
