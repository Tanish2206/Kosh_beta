import SwiftUI

// MARK: - Ask kosh: questions about your money, worked out step by step
//
// The assistant (KoshAgent) looks things up with kosh's own tools as many times as a question needs, and
// every figure it gives has to be one those tools found. Each answer shows what it looked up, the payments
// behind it, and anything it suggests doing, as a card you confirm.

struct AskMessage: Identifiable, Hashable {
    let id = UUID()
    let mine: Bool
    let text: String
    var steps: [AgentStep] = []
    var rows: [String] = []
    var proposals: [AgentProposal] = []
    var checked = true
    var brain = ""
    /// questions to tap next, under the newest answer
    var suggest: [String] = []
    /// what the phone took the question to be, for the next one to carry on from
    var frame: String? = nil
    /// a decision weighed with its working (decide.js), and the question that asked it, for saving
    var decisions: [Decision] = []
    var asked: String = ""
    /// how it was answered, when that needs saying (Claude out of reach)
    var notice: String? = nil
}

struct AskSheet: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    /// the conversation stays with kosh while it's open, so closing the sheet doesn't lose it
    private var messages: [AskMessage] { store.askThread }
    @State private var task: Task<Void, Never>?
    @State private var question = ""
    @State private var thinking = false
    @State private var live: [AgentStep] = []
    @State private var mode = KoshAgent.mode
    @State private var done: Set<String> = []
    @State private var said: [String: String] = [:]
    @State private var showing: AskRows?
    /// the question drawn as a live view (LiveView.swift)
    @State private var drawing = false
    @FocusState private var focused: Bool

    struct AskRows: Identifiable { let id = UUID(); let ids: [String] }

    /// with Claude: anything, decisions included
    static let starters = [
        "Brief me: what needs me today?",
        "Can I cover what’s due this week?",
        "What changed in my spending this month?",
        "Which repeats could I cut, and what would I save?",
        "Should I prepay my home loan or invest the money?",
        "How much did I spend on food last month?",
    ]
    /// on the phone alone: what kosh works out by itself
    static let phoneStarters = [
        "Who did I pay the most this month?",
        "How much have I spent this month?",
        "What changed in my spending this month?",
        "Can I cover what’s due this week?",
        "What were my biggest payments last month?",
        "Is my emergency fund enough?",
    ]

    var body: some View {
        NavigationStack {
            Group {
                chat
            }
            .sheet(isPresented: $drawing) {
                LiveViewScreen(seed: messages.last(where: { $0.mine })?.text)
                    .environment(store)
                    .presentationDetents([.large])
                    .redacted(reason: store.hidden ? .privacy : [])
            }
            .navigationTitle("Ask kosh")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } }
                // the last question (or a new one) drawn as a live view
                ToolbarItem(placement: .topBarTrailing) {
                    Button { drawing = true } label: { Image(systemName: "chart.bar.xaxis") }
                        .accessibilityLabel("Draw it")
                }
                // the decisions you saved, to see again on today's numbers
                if !DecisionBook.shared.items.isEmpty {
                    ToolbarItem(placement: .topBarTrailing) {
                        NavigationLink { DecisionsList() } label: { Image(systemName: "bookmark") }
                            .accessibilityLabel("Saved decisions")
                    }
                }
                if !messages.isEmpty && !thinking {
                    ToolbarItem(placement: .topBarLeading) {
                        Button { withAnimation(Motion.open) { store.askThread = [] } } label: { Image(systemName: "square.and.pencil") }
                            .accessibilityLabel("New conversation")
                    }
                }
                if KoshAgent.cloudReady && KoshAgent.phoneReady {
                    ToolbarItem(placement: .topBarLeading) {
                        Menu {
                            Picker("Who answers", selection: $mode) {
                                Text("Smart answers (sharper)").tag("auto")
                                Text("Only this phone").tag("phone")
                            }
                        } label: { Image(systemName: mode == "phone" ? "iphone" : "cloud") }
                        .onChange(of: mode) { _, v in KoshAgent.mode = v }
                    }
                }
            }
            .sheet(item: $showing) { r in
                AskRowsSheet(ids: r.ids)
                    .environment(store)
                    .redacted(reason: store.hidden ? .privacy : [])
            }
        }
        .onAppear {
            if let seed = store.askSeed { store.askSeed = nil; ask(seed) }
        }
    }

    var who: String {
        if KoshAgent.useCloud { return "Worked out by kosh’s smart answers, an AI that sees only the figures and payee names kosh looks up for it, never your mail." }
        return AppleBrain.available ? "Worked out on this phone by Apple Intelligence. Nothing is sent anywhere." : "Worked out on this phone from your ledger. Nothing is sent anywhere."
    }

    /// on the phone alone: the way to make it smart, said once at the top
    @ViewBuilder var smarter: some View {
        if !KoshAgent.useCloud {
            NavigationLink {
                AgentSettings()
            } label: {
                HStack(spacing: 12) {
                    Image(systemName: "brain.head.profile").font(.title3).foregroundStyle(Color.kosh)
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Make Ask kosh smart").font(.subheadline.weight(.semibold))
                        Text("Add an AI key: any question, worked out step by step, every figure checked.").font(.footnote).foregroundStyle(.secondary)
                    }
                    Spacer(minLength: 4)
                    Image(systemName: "chevron.right").font(.footnote.weight(.semibold)).foregroundStyle(.tertiary)
                }
                .padding(14)
                .background(Color.surface, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            }
            .buttonStyle(.press)
        }
    }

    /// before the first question: the decisions saved, when there are some
    @ViewBuilder var savedDecisions: some View {
        let n: Int = DecisionBook.shared.items.count
        if n > 0 {
            NavigationLink {
                DecisionsList()
            } label: {
                HStack(spacing: 12) {
                    Image(systemName: "bookmark.fill").font(.title3).foregroundStyle(Color.kosh)
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Saved decisions").font(.subheadline.weight(.semibold))
                        Text(Words.cap(Words.number(n)) + (n == 1 ? " decision" : " decisions") + ", to see again on today’s numbers").font(.footnote).foregroundStyle(.secondary)
                    }
                    Spacer(minLength: 4)
                    Image(systemName: "chevron.right").font(.footnote.weight(.semibold)).foregroundStyle(.tertiary)
                }
                .padding(14)
                .background(Color.surface, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            }
            .buttonStyle(.press)
            .padding(.top, 4)
        }
    }

    var chat: some View {
        VStack(spacing: 0) {
            ScrollViewReader { proxy in
                ScrollView {
                    VStack(alignment: .leading, spacing: 14) {
                        if messages.isEmpty {
                            VStack(alignment: .leading, spacing: 10) {
                                Image(systemName: "sparkles")
                                    .font(.system(.largeTitle, weight: .semibold))
                                    .foregroundStyle(LinearGradient(colors: [Color.kosh, Color.sky], startPoint: .topLeading, endPoint: .bottomTrailing))
                                Text("Ask about your money").font(.title2.weight(.bold))
                                Text(who).font(.subheadline).foregroundStyle(.secondary)
                            }
                            .padding(.bottom, 8)
                            smarter
                            ForEach(KoshAgent.useCloud ? Self.starters : Self.phoneStarters, id: \.self) { s in
                                Button { ask(s) } label: {
                                    HStack {
                                        Text(s).multilineTextAlignment(.leading)
                                        Spacer(minLength: 6)
                                        Image(systemName: "arrow.up.circle.fill").foregroundStyle(Color.kosh)
                                    }
                                    .font(.subheadline.weight(.medium))
                                    .padding(14)
                                    .background(Color.surface, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                                }
                                .buttonStyle(.press)
                            }
                            savedDecisions
                        }
                        ForEach(messages) { m in
                            Group {
                                if m.mine { Mine(text: m.text) } else { answer(m) }
                            }
                            .id(m.id)
                            .transition(.move(edge: .bottom).combined(with: .opacity))
                        }
                        if thinking { Working(steps: live).id("thinking") }
                    }
                    .padding(20)
                    .animation(Motion.large, value: messages)
                    .animation(Motion.open, value: live)
                }
                .onChange(of: messages.count) { _, _ in
                    withAnimation(Motion.open) { proxy.scrollTo(messages.last.map { AnyHashable($0.id) } ?? AnyHashable("thinking"), anchor: .bottom) }
                }
                .onChange(of: thinking) { _, on in if on { withAnimation(Motion.open) { proxy.scrollTo("thinking", anchor: .bottom) } } }
            }
            HStack(spacing: 10) {
                TextField("Ask about spending, bills, savings…", text: $question, axis: .vertical)
                    .lineLimit(1...4)
                    .focused($focused)
                    .padding(.horizontal, 14)
                    .padding(.vertical, 10)
                    .background(Color.surface, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
                    .onSubmit { ask(question) }
                Button { if thinking { stop() } else { ask(question) } } label: {
                    Image(systemName: thinking ? "stop.fill" : "arrow.up").font(.body.weight(.bold))
                }
                .accessibilityLabel(thinking ? "Stop" : "Ask")
                .buttonStyle(.glassProminent).koshFilled()
                .buttonBorderShape(.circle)
                .disabled(question.trimmingCharacters(in: .whitespaces).isEmpty && !thinking)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 10)
        }
    }

    /// an answer: what it looked up, what it says, the payments behind it, and what it suggests. A decision kosh
    /// weighed on the phone is its card alone (the answer, the figures, the working); one Claude weighed is the
    /// working under Claude's own words
    @ViewBuilder func answer(_ m: AskMessage) -> some View {
        let byPhone: Bool = !m.decisions.isEmpty && m.brain == "kosh"
        let cards: [Decision] = byPhone ? m.decisions : m.decisions.filter { $0.complete }
        // the decision's working is on its card: not again under "How kosh worked it out"
        let worked: [AgentStep] = m.steps.filter { !$0.result.isEmpty && !(!m.decisions.isEmpty && $0.tool == "decide") }
        VStack(alignment: .leading, spacing: 10) {
            if !m.steps.isEmpty && !byPhone { StepsLine(steps: m.steps) }
            if !byPhone {
                Text(Self.rich(m.text))
                    .font(.body)
                    .textSelection(.enabled)
                    .privacySensitive()
                    .padding(.horizontal, 14)
                    .padding(.vertical, 10)
                    .background(Color.surface, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
            }
            ForEach(cards) { d in DecisionCard(decision: d, question: m.asked, compact: !byPhone) }
            // (the words carry the note; a decision's card stands in for them, so it's said here)
            if byPhone, let n = m.notice, !n.isEmpty {
                Label(n, systemImage: "icloud.slash").font(.caption).foregroundStyle(.secondary).padding(.horizontal, 4)
            }
            HStack(spacing: 12) {
                if !m.rows.isEmpty {
                    Button { showing = AskRows(ids: m.rows) } label: {
                        Label("Based on \(m.rows.count) payment\(m.rows.count == 1 ? "" : "s")", systemImage: "list.bullet.rectangle")
                    }
                }
                if !m.steps.isEmpty {
                    if m.checked {
                        Label("Figures checked", systemImage: "checkmark.shield").foregroundStyle(.secondary)
                    } else {
                        Label("Some figures not checked", systemImage: "exclamationmark.shield").foregroundStyle(Color.orange)
                    }
                }
                Spacer(minLength: 0)
                if !m.brain.isEmpty { Text(m.brain).foregroundStyle(.tertiary) }
            }
            .font(.caption.weight(.medium))
            .padding(.horizontal, 4)
            if !worked.isEmpty {
                DisclosureGroup {
                    VStack(alignment: .leading, spacing: 10) {
                        ForEach(worked) { s in
                            VStack(alignment: .leading, spacing: 3) {
                                Text(s.label).font(.caption.weight(.semibold))
                                Text(s.result).font(.caption).foregroundStyle(.secondary).textSelection(.enabled).privacySensitive()
                            }
                        }
                    }
                    .padding(.top, 6)
                } label: {
                    Text("How kosh worked it out").font(.caption.weight(.semibold))
                }
                .tint(Color.secondary)
                .padding(.horizontal, 4)
            }
            ForEach(m.proposals) { p in proposalCard(p) }
            // what to ask next, under the newest answer only
            if !m.suggest.isEmpty && m.id == messages.last?.id && !thinking {
                VStack(alignment: .leading, spacing: 8) {
                    ForEach(m.suggest, id: \.self) { s in
                        Button { ask(s) } label: {
                            HStack(spacing: 6) {
                                Image(systemName: "arrow.turn.down.right").font(.caption.weight(.bold))
                                // Claude's next questions can carry figures ("…if I cut ₹2,000?")
                                Text(s).multilineTextAlignment(.leading).fixedSize(horizontal: false, vertical: true)
                                    .privacySensitive()
                            }
                            .font(.subheadline.weight(.medium))
                            .foregroundStyle(Color.kosh)
                            .padding(.horizontal, 12)
                            .padding(.vertical, 8)
                            .background(Color.kosh.opacity(0.1), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                        }
                        .buttonStyle(.press)
                    }
                }
                .padding(.top, 2)
                .transition(.opacity)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    func proposalCard(_ p: AgentProposal) -> some View {
        let isDone = done.contains(p.id)
        return VStack(alignment: .leading, spacing: 8) {
            // what it proposes, why, and what doing it did can all carry figures ("Budget set: ₹8,000 a month")
            Label(p.title, systemImage: Self.sym(p.action)).font(.subheadline.weight(.semibold))
                .privacySensitive()
            if let w = p.why, !w.isEmpty { Text(w).font(.footnote).foregroundStyle(.secondary).privacySensitive() }
            if isDone {
                Label(said[p.id] ?? "Done", systemImage: "checkmark.circle.fill").font(.footnote.weight(.semibold)).foregroundStyle(Color.green)
                    .privacySensitive()
            } else {
                HStack {
                    Button("Do it") {
                        Task { @MainActor in
                            let line = await KoshAgent.perform(p, store: store)
                            said[p.id] = line
                            withAnimation(Motion.base) { _ = done.insert(p.id) }
                        }
                    }
                    .buttonStyle(.glassProminent).koshFilled()
                    Button("Not now") { withAnimation(Motion.base) { said[p.id] = "Left as it is"; _ = done.insert(p.id) } }
                        .buttonStyle(.glass)
                }
                .font(.subheadline.weight(.semibold))
            }
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.kosh.opacity(0.08), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(Color.kosh.opacity(0.25), lineWidth: 1))
    }

    static func sym(_ action: String) -> String {
        switch action {
        case "budget": return "gauge.with.dots.needle.50percent"
        case "recategorize": return "tag.fill"
        case "remind": return "bell.fill"
        case "chapter": return "book.pages.fill"
        case "pack": return "doc.badge.plus"
        default: return "sparkles"
        }
    }

    /// the answer's light Markdown (bold, bullets) as the phone draws it
    static func rich(_ s: String) -> AttributedString {
        (try? AttributedString(markdown: s, options: .init(interpretedSyntax: .inlineOnlyPreservingWhitespace))) ?? AttributedString(s)
    }

    func ask(_ q: String) {
        let text = q.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty, !thinking else { return }
        question = ""
        focused = false
        var history: [(q: String, a: String)] = []
        var pending: String?
        for m in messages {
            if m.mine { pending = m.text } else if let p = pending { history.append((p, m.text)); pending = nil }
        }
        // what the last answer was about, for "and last month?", "show them", "why?"
        let prev: String? = messages.last(where: { !$0.mine })?.frame
        // the answer before, for a short follow-up to a decision ("and at 12%?") to be saved under the question it carries on from
        let before: AskMessage? = messages.last(where: { !$0.mine })
        store.askThread.append(AskMessage(mine: true, text: text))
        thinking = true
        live = []
        task = Task { @MainActor in
            let r = await KoshAgent.ask(text, history: history, prev: prev, store: store) { step in
                Task { @MainActor in live.append(step) }
            }
            guard !Task.isCancelled else { return }
            thinking = false
            var asked: String = text
            if let b = before, !b.decisions.isEmpty, text.split(separator: " ").count <= 8,
               r.decisions.contains(where: { d in b.decisions.contains { $0.kind == d.kind } }) { asked = b.asked }
            store.askThread.append(AskMessage(mine: false, text: r.text, steps: r.steps, rows: r.rows, proposals: r.proposals, checked: r.checked, brain: r.brain, suggest: r.suggest, frame: r.frame,
                                              decisions: r.decisions, asked: asked, notice: r.notice))
        }
    }

    /// stop working on it: whatever Claude was doing is dropped
    func stop() {
        task?.cancel()
        task = nil
        thinking = false
        store.askThread.append(AskMessage(mine: false, text: "Stopped.", checked: true, brain: ""))
    }

    struct Mine: View {
        let text: String
        var body: some View {
            HStack {
                Spacer(minLength: 40)
                // a question can carry figures ("Can I spend ₹40,000 on a phone?")
                Text(text)
                    .font(.body)
                    .foregroundStyle(Color.onKosh)
                    .privacySensitive()
                    .padding(.horizontal, 14)
                    .padding(.vertical, 10)
                    .background(Color.koshFill, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
            }
        }
    }

    /// what it looked up, as small chips
    struct StepsLine: View {
        let steps: [AgentStep]
        var body: some View {
            let labels = steps.map(\.label).reduce(into: [String]()) { if !$0.contains($1) { $0.append($1) } }
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 6) {
                    Image(systemName: "magnifyingglass").font(.caption2.weight(.bold)).foregroundStyle(.secondary)
                    ForEach(labels, id: \.self) { l in
                        Text(l).font(.caption.weight(.medium))
                            .padding(.horizontal, 9).padding(.vertical, 4)
                            .background(Color.primary.opacity(0.06), in: Capsule())
                    }
                }
            }
        }
    }

    /// while it works: what it's looking up now
    struct Working: View {
        let steps: [AgentStep]
        var body: some View {
            VStack(alignment: .leading, spacing: 8) {
                if !steps.isEmpty { StepsLine(steps: steps) }
                HStack(spacing: 6) {
                    ForEach(0..<3, id: \.self) { i in
                        Circle().fill(Color.secondary).frame(width: 7, height: 7)
                            .phaseAnimator([0.3, 1.0]) { v, p in v.opacity(p) } animation: { _ in .easeInOut(duration: 0.5).delay(Double(i) * 0.15) }
                    }
                    Text(steps.last.map { "Looking at " + $0.label.lowercased() + "…" } ?? "Thinking…").font(.footnote).foregroundStyle(.secondary)
                }
                .padding(14)
                .background(Color.surface, in: Capsule())
            }
        }
    }
}

/// the payments behind an answer
struct AskRowsSheet: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    let ids: [String]
    var body: some View {
        let set = Set(ids)
        let rows = store.tx.filter { set.contains($0.id) }.sorted { ($0.d + $0.t) > ($1.d + $1.t) }
        NavigationStack {
            List {
                Section {
                    // shown, not opened: opening one here would close the conversation
                    ForEach(rows) { t in TxRow(t: t, when: Day.short(t.d)).allowsHitTesting(false) }
                } footer: {
                    let total: Double = rows.reduce(0) { $0 + $1.a }
                    let count: String = "\(rows.count) payment\(rows.count == 1 ? "" : "s")"
                    Text(count + ", " + Fmt.rupees(total) + " in all.")
                        .privacySensitive()
                }
            }
            .listStyle(.insetGrouped)
            .navigationTitle("Behind the answer")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } } }
        }
    }
}
