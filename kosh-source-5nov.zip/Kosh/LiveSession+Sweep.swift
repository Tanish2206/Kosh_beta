import Foundation
import Observation
import UIKit
import Network

// MARK: - LiveSession: the sweep through each inbox: inbox tags, one window of mail listed and read, every inbox side by side
// (split out of LiveSession+Reading.swift, 30 Oct 2026; its stored state stays in the class in LiveSession.swift)

extension LiveSession {
    /// how an inbox's records are told apart: nothing for yours, its own lasting "a1-" and so on for the others (the
    /// place in the list stands in only for an inbox not yet given one: tagInboxes gives each its own)
    func inboxTag(_ acct: String) -> String {
        if acct == email { return "" }
        if let t = accounts.first(where: { $0.id == acct })?.tag, !t.isEmpty { return t }
        return "a\(allAccounts.firstIndex(of: acct) ?? 0)-"
    }

    /// the "a<n>-" a record's id starts with, if it has one (the records of the inbox you signed in with have none)
    static func inboxPrefix(_ id: String) -> String? {
        guard id.hasPrefix("a") else { return nil }
        let rest: Substring = id.dropFirst()
        let digits: String = String(rest.prefix { $0.isASCII && $0.isNumber })
        guard !digits.isEmpty, rest.dropFirst(digits.count).first == "-" else { return nil }
        return "a" + digits + "-"
    }

    /// a tag no inbox has had: past every one given and every one a record still carries
    func freshInboxTag() -> String {
        var top = 0
        let given: [String] = accounts.compactMap(\.tag) + records.compactMap { Self.inboxPrefix($0.id) }
        for t in given { top = max(top, Int(t.dropFirst().dropLast()) ?? 0) }
        return "a" + String(top + 1) + "-"
    }

    /// Once, as the profile is read: every inbox without a lasting tag is given the one its records already carry
    /// (the most of them, if a removal shifted some), else its place in the list as it was, else a fresh one. No
    /// record's id changes; a record under an older tag is still known (knownIDs) and read again under its own id.
    /// True when any inbox was given one (the profile is saved).
    func tagInboxes() -> Bool {
        guard accounts.contains(where: { ($0.tag ?? "").isEmpty }) else { return false }
        // for each inbox, how many of its records carry each tag
        var counts: [String: [String: Int]] = [:]
        for r in records {
            guard let a = r.acct, !a.isEmpty, a != email, let p = Self.inboxPrefix(r.id) else { continue }
            counts[a, default: [:]][p, default: 0] += 1
        }
        var taken: Set<String> = Set(accounts.compactMap(\.tag).filter { !$0.isEmpty })
        let places: [String] = allAccounts
        for i in accounts.indices where (accounts[i].tag ?? "").isEmpty {
            let id: String = accounts[i].id
            let carried: [String] = (counts[id] ?? [:]).sorted { $0.value != $1.value ? $0.value > $1.value : $0.key < $1.key }.map(\.key)
            let place: String? = places.firstIndex(of: id).map { "a" + String($0) + "-" }
            let pick: String? = (carried + [place].compactMap { $0 }).first { !taken.contains($0) }
            let tag: String = pick ?? freshInboxTag()
            accounts[i].tag = tag
            taken.insert(tag)
        }
        return true
    }

    /// every record's id, and for a record stored under its inbox's earlier tag, the id it would have now: a mail
    /// already read is never read again as new
    var knownIDs: Set<String> {
        var out: Set<String> = Set(records.map(\.id))
        var now: [String: String] = [:]
        for a in accounts { if let t = a.tag, !t.isEmpty { now[a.id] = t } }
        for r in records {
            guard let a = r.acct, a != email, let t = now[a], !r.id.hasPrefix(t), let old = Self.inboxPrefix(r.id) else { continue }
            out.insert(t + String(r.id.dropFirst(old.count)))
        }
        return out
    }

    /// a dropped connection, a timeout or a busy server, not a refusal: worth trying again in a moment
    static func transient(_ error: Error) -> Bool {
        if error is URLError || error is NWError { return true }
        if let m = error as? MailError {
            switch m {
            case .login, .refused, .tooBig: return false
            default: return true
            }
        }
        if let e = error as? LiveError {
            switch e {
            case .busy: return true
            case .http(let code, _): return code >= 500 || code == 429
            default: return false
            }
        }
        return false
    }

    /// One window of mail, across every inbox: listed first (and kept in reading.json, so a read that's cut
    /// short is never listed again), then read 15 at a time, every inbox side by side, each inside its own
    /// allowance with Google (QuotaGate). Without the internet it waits; if kosh's time runs out it stops,
    /// saving what it read with what's left. False if it failed or was stopped before the end.
    @MainActor

    func sweep(after: String, before: String?, quiet: Bool = false, only: String? = nil, queries: [String]? = nil, job: String, since: [String: String] = [:]) async -> Bool {
        let key = MailWindow.key(after: after, before: before, queries: queries, only: only)
        stretchSeen = true
        // while this runs, the plan is this read's to keep: what the background downloads bring back meanwhile
        // is read, and struck off here when the read gets to it
        sweeping.insert(job)
        defer { sweeping.remove(job) }
        var win: MailWindow
        if let w = plan(job)?.windows.first(where: { $0.key == key }) {
            // listed before and cut short: on from the same email, nothing listed again
            win = w
            pickUp(job)
            if !quiet { message = nil; found = w.total }
        } else {
            if !quiet { phase = .listing; message = nil; found = 0; fetched = 0; total = 0 } else { bgListing = true; bgFetched = 0; bgTotal = 0 }
            let listed = await listWindow(after: after, before: before, only: only, queries: queries, known: knownIDs, since: since,
                                          counting: { n in if quiet { self.bgTotal += n } else { self.found += n } })
            bgListing = false
            guard let listed else {
                // stopped while listing: nothing read yet, nothing to carry on
                if !quiet { phase = .idle }
                return false
            }
            win = listed
            // from here on what's left is kept, so it's never listed again
            var p = (job == "backfill" ? plan(job) : nil) ?? ReadingPlan(job: job, accounts: allAccounts)
            p.windows.removeAll { $0.key == key }
            p.windows.insert(win, at: 0)
            p.total += win.total
            plans[job] = p
            writePlans()
        }
        if !quiet {
            phase = .reading; fetched = win.done; total = win.total
            rateBase = win.done; scanStarted = Date()
        } else {
            bgFetched = win.done; bgTotal = win.total
        }
        if job == "backfill", let p = plans[job] { yearDone = p.done; yearTotal = p.total }
        // each inbox has its own allowance with Google, so the inboxes are read side by side, each as fast as its
        // own allowance lets it (QuotaGate paces every request); they share the window's progress
        let run = SweepRun(win)
        let known = knownIDs
        let inboxes = allAccounts.filter { win.left[$0] != nil }
        await withTaskGroup(of: Void.self) { g in
            for acct in inboxes {
                g.addTask { @MainActor in await self.sweepInbox(acct, run: run, job: job, quiet: quiet, known: known) }
            }
        }
        win = run.win
        let anyFail = run.anyFail
        let stopped = run.stopped
        // an inbox that couldn't be read to the end keeps what's left in the plan, like a stop
        let leftover = win.left.values.contains { !$0.isEmpty }
        if stopped || (anyFail != nil && leftover) {
            // what was read is saved with what's left; the next run carries on from here
            cutShort(job)
            if !stopped, let anyFail, !quiet { phase = .failed; message = anyFail; lastRebuild = Date(); rebuildSoon(); return false }
            if !quiet { phase = .idle }
            lastRebuild = Date(); rebuildSoon()
            return false
        }
        // the window is read: it leaves reading.json (the year's plan keeps its other months, and is saved by backfill)
        if job == "backfill" { plans[job]?.windows.removeAll { $0.key == key } } else { plans[job] = nil }
        if only == nil && !quiet && anyFail == nil {
            if scanFrom.isEmpty || after < scanFrom { scanFrom = after }
            // the next read starts from when this one was listed, so mail that came in while it read isn't missed
            lastScan = ISO8601DateFormatter().string(from: win.listedAt)
        }
        if job != "backfill" { save(); writePlans() }
        lastRebuild = Date(); rebuildSoon()
        if let anyFail, !quiet { phase = .failed; message = anyFail; return false }
        if anyFail != nil && quiet { return false }
        return true
    }

    /// what the inboxes' readers share while they read one window side by side
    @MainActor

    final class SweepRun {
        var win: MailWindow
        var anyFail: String?
        var stopped = false
        init(_ w: MailWindow) { win = w; anyFail = w.failed }
    }

    /// One inbox's part of a window: fetched 15 at a time, as fast as its allowance lets it. Without the internet
    /// it waits; a passing failure is tried again; a stop or a failure leaves what's left in the plan.
    @MainActor

    func sweepInbox(_ acct: String, run: SweepRun, job: String, quiet: Bool, known: Set<String>) async {
        let tag = inboxTag(acct)
        var todo = run.win.left[acct] ?? []
        // read before the last save but not struck off yet: counted, not read twice
        let had = todo.count
        todo.removeAll { known.contains(tag + $0) }
        if had != todo.count {
            run.win.left[acct] = todo.isEmpty ? nil : todo
            advance(&run.win, by: had - todo.count, job: job, quiet: quiet)
        }
        var tries = 0
        // what didn't come yet, by id, and how often it has been asked for in this run; what was asked for five times
        // stays in the plan for the next run (a busy minute never strikes an email off unread)
        var asked: [String: Int] = [:]
        var stuck: [String] = []
        while !todo.isEmpty {
            if halted || run.stopped { run.stopped = true; return }
            if !Net.shared.online {
                // paused, not lost: it carries on by itself once the phone is back online
                guard await Net.shared.waitOnline() else { run.stopped = true; return }
            }
            let chunk = Array(todo.prefix(15))
            // read meanwhile by the background downloads (kosh was off screen a moment ago): counted, not fetched again
            let fresh = readInBackground.isEmpty ? chunk : chunk.filter { !readInBackground.contains(tag + $0) }
            var msgs: [MailMsg] = []
            var later: [String] = []
            if !fresh.isEmpty {
                do {
                    let some = try await fetchSome(fresh, acct: acct)
                    msgs = some.got
                    later = some.later
                } catch {
                    if Self.transient(error) && tries < 4 { tries += 1; try? await Task.sleep(for: .seconds(Double(1 << tries))); continue }
                    run.anyFail = error.localizedDescription
                    let keep: [String] = todo + stuck
                    run.win.left[acct] = keep.isEmpty ? nil : keep
                    return
                }
            }
            // nothing came, and some may yet: the connection or the allowance rather than the mail. Again in a moment;
            // after a few tries the chunk stays in the plan (never struck off unread) and the next run carries on from it.
            // (what the inbox answered without, moved or deleted since it was listed, is gone, not a failure)
            if msgs.isEmpty && !later.isEmpty {
                if tries < 4 {
                    tries += 1
                    try? await Task.sleep(for: .seconds(Double(1 << tries)))
                    continue
                }
                run.anyFail = "The inbox didn’t answer. kosh carries on from here next time."
                let keep: [String] = todo + stuck
                run.win.left[acct] = keep.isEmpty ? nil : keep
                return
            }
            tries = 0
            await ingestAll(msgs, acct: acct, tag: tag)
            todo.removeFirst(chunk.count)
            // what came and what's gone are struck off; what didn't come yet goes to the back of the list, asked for again
            // before this window is done
            for id in later {
                let n: Int = (asked[id] ?? 0) + 1
                asked[id] = n
                if n < 5 { todo.append(id) } else { stuck.append(id) }
            }
            let left: [String] = todo + stuck
            run.win.left[acct] = left.isEmpty ? nil : left
            advance(&run.win, by: chunk.count - later.count, job: job, quiet: quiet)
            stretchRead += msgs.count + chunk.count - fresh.count
            checkpoint(chunk.count)
            // laying the screens out again is the slow part on the phone: every 2.5 s while you
            // watch, every 20 s in the background; never sooner than twice the last build's time
            let every: Double = quiet ? 20 : 5
            if readingBuildDue(every: every) { lastRebuild = Date(); rebuildSoon() }
        }
        // asked for five times and still not here: kept in the plan (set above), and the window isn't done until they
        // come, so the next run asks again. Said as a failure, or the window would be taken as read and these lost
        if !stuck.isEmpty && run.anyFail == nil {
            run.anyFail = "Some emails didn’t come from the inbox. kosh asks for them again next time."
        }
    }

    /// a window's progress, kept in its plan and shown on the bar
    @MainActor

    func advance(_ win: inout MailWindow, by n: Int, job: String, quiet: Bool) {
        win.done += n
        if var p = plans[job] {
            let key = win.key
            if let i = p.windows.firstIndex(where: { $0.key == key }) { p.windows[i] = win }
            p.done += n
            plans[job] = p
            if job == "backfill" { yearDone = p.done; yearTotal = p.total }
        }
        if quiet { bgFetched = win.done } else { fetched = win.done }
    }

    /// Every new email in a window, in each inbox: Gmail's ids, less the ones already read. Nil if kosh was
    /// stopped meanwhile; an inbox that couldn't be listed is noted in `failed` and the others go on.
    @MainActor

    func listWindow(after: String, before: String?, only: String?, queries: [String]?, known: Set<String>, since: [String: String] = [:], counting: ((Int) -> Void)? = nil) async -> MailWindow? {
        var win = MailWindow(after: after, before: before, queries: queries, only: only)
        byChangeLogFellBack = false
        for acct in allAccounts where only == nil || acct == only {
            let tag = inboxTag(acct)
            let gmail = isGmail(acct)
            // a job's own Gmail searches (statements, wallets, a named bank) are Gmail's: other inboxes are listed whole
            if !gmail && queries != nil { continue }
            var tries = 0
            while true {
                if halted { return nil }
                if !Net.shared.online { guard await Net.shared.waitOnline() else { return nil } }
                do {
                    let ids: [String]
                    var viaLog: [String]? = nil
                    if gmail, queries == nil, let mark = since[acct] { viaLog = try await changeLogIDs(acct, since: mark, known: known) }
                    if let found = viaLog {
                        ids = found
                        counting?(found.count)
                    } else if gmail {
                        if since[acct] != nil { byChangeLogFellBack = true }
                        let qs = try (queries ?? JSONText.decode([String].self, try Engine.shared.call("queriesJSON", [after])))
                            .map { before == nil ? $0 : $0 + " before:" + before!.replacingOccurrences(of: "-", with: "/") }
                        ids = try await listIDs(qs, acct: acct, counting: counting)
                    } else {
                        ids = try await listOther(acct, after: after, before: before, counting: counting)
                    }
                    let todo = ids.filter { !known.contains(tag + $0) }
                    if !todo.isEmpty { win.left[acct] = todo }
                    win.total += todo.count
                    break
                } catch {
                    if Self.transient(error) && tries < 3 { tries += 1; try? await Task.sleep(for: .seconds(Double(2 << tries))); continue }
                    win.failed = error.localizedDescription
                    break
                }
            }
        }
        return win
    }

    static let notMoneyLabels: Set<String> = ["SPAM", "TRASH", "DRAFT", "SENT", "CATEGORY_SOCIAL", "CATEGORY_FORUMS", "CATEGORY_PROMOTIONS", "CHAT"]

    @MainActor

    func changeLogIDs(_ acct: String, since mark: String, known: Set<String>) async throws -> [String]? {
        let tag = inboxTag(acct)
        var ids: [String] = []
        var seen = Set<String>()
        var page: String? = nil
        repeat {
            let tok = try await token(acct)
            let pg = page
            guard let got = try await QuotaGate.$inbox.withValue(acct, operation: { try await Gmail.added(since: mark, token: tok, page: pg) }) else { return nil }
            for m in got.msgs where seen.insert(m.id).inserted && !known.contains(tag + m.id) && !m.labels.contains(where: { Self.notMoneyLabels.contains($0) }) {
                ids.append(m.id)
            }
            page = got.next
            if ids.count > 300 { return nil }
        } while page != nil
        guard !ids.isEmpty else { return [] }
        // who sent each and what it's about: fifteen at a time, within the inbox's allowance
        var wanted: [String] = []
        var at = 0
        while at < ids.count {
            let chunk = Array(ids[at..<min(at + 15, ids.count)])
            at += chunk.count
            let tok = try await token(acct)
            let heads: [(String, String, String)] = await withTaskGroup(of: (String, String, String)?.self) { g in
                for id in chunk {
                    g.addTask {
                        guard let h = try? await QuotaGate.$inbox.withValue(acct, operation: { try await Gmail.headers(id, token: tok) }) else { return (id, "", "") }
                        return (id, h.from, h.subject)
                    }
                }
                var out: [(String, String, String)] = []
                for await r in g { if let r { out.append(r) } }
                return out
            }
            for (id, from, subject) in heads {
                // a mail whose headers didn't come is read anyway: never left out for a passing failure
                if from.isEmpty || (try? Engine.shared.call("mailWantedJSON", [from, subject])) == "true" { wanted.append(id) }
            }
        }
        // in the order Gmail added them
        let keep = Set(wanted)
        return ids.filter { keep.contains($0) }
    }

    /// every id a set of searches finds in one inbox, in order, without repeats
    @MainActor

    func listIDs(_ qs: [String], acct: String, counting: ((Int) -> Void)?) async throws -> [String] {
        var ids: [String] = []
        var seen = Set<String>()
        for q in qs {
            var page: String? = nil
            repeat {
                let tok = try await token(acct)
                let pg = page
                let (got, next) = try await QuotaGate.$inbox.withValue(acct) { try await Self.retrying { try await Gmail.list(query: q, token: tok, page: pg) } }
                for id in got where seen.insert(id).inserted { ids.append(id) }
                counting?(got.count)
                page = next
            } while page != nil
        }
        return ids
    }

    /// a few emails at once, in the order asked; any that didn't come are left out
    /// A few Gmail emails at once, each inside the inbox's allowance (QuotaGate), each tried again while Google is busy
    /// (LiveSession.retrying). What came, in the order asked; and what didn't come but may yet (still "too many" after
    /// every try, a dropped connection, a server error, an expired token), said in `later` so it is asked again and never
    /// struck off unread. Only an email Gmail no longer has (404: deleted since it was listed) is in neither.
    static func fetchSome(_ ids: [String], token: String) async -> (got: [MailMsg], later: [String]) {
        let res: ([String: MailMsg], Set<String>) = await withTaskGroup(of: (String, MailMsg?, Bool).self) { g in
            for id in ids {
                g.addTask {
                    do {
                        let m: MailMsg = try await LiveSession.retrying { try await Gmail.message(id, token: token) }
                        return (id, m, false)
                    } catch {
                        return (id, nil, !LiveSession.gone(error))
                    }
                }
            }
            var out: [String: MailMsg] = [:]
            var later: Set<String> = []
            for await r in g {
                if let m = r.1 { out[r.0] = m } else if r.2 { later.insert(r.0) }
            }
            return (out, later)
        }
        return (ids.compactMap { res.0[$0] }, ids.filter { res.1.contains($0) })
    }
}
