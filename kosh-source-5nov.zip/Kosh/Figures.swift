import Foundation

/* The money figures the screens show, worked out from the build and the little this phone adds to it (spending typed
   since the last build, the cash at home you said, a loan's balance you typed). Store's figure functions are these:
   Home's net worth and its tiles, Portfolio's, a month's spending on Home, Transactions, Insights and Month detail,
   each person's part under the whose-money picker, money in, what's still to go out this month, the refunds waiting.

   Screen-free on purpose (Foundation only, nothing draws): engine-test/screens.js compiles this file with swiftc
   beside the phone's own Snapshot types (cut out of the app by tools/swiftslice.js) and the golden and blind-QA
   households' builds, and checks every figure here against the same money on the other screens and in Ask kosh.
   A figure a screen shows is worked out here once; a screen that adds figures up itself is a bug to move here. */
struct Figures {
    /// (each part read here is listed in Store.figuresReads, Store+Ledger.swift, so screens redraw when it changes)
    let snap: Snapshot
    /// the payments as the phone holds them (the build's, with your edits)
    let tx: [Txn]
    /// spending typed on the phone this month, before the next build counts it
    var added: Double = 0
    /// the cash at home you last said
    var cashInHand: Double = 0
    /// a loan's balance you last typed, by the loan's id
    var typedLoans: [String: Double] = [:]

    // MARK: the running month

    var spentNow: Double { snap.fc.spent + added }
    var likelyNow: Double { snap.fc.likely + added }
    /// what's left of the month's budget after what's spent and what's still to go out
    var leftNow: Double { (snap.fc.remaining ?? (snap.fc.budget - snap.fc.spent)) - added }
    func month(_ m: String) -> MonthInfo? { snap.months.first { $0.m == m } }

    // MARK: a month's spending, for whoever is picked

    /// a month's payments for one person (or everyone): the ledger's own rows
    func txs(in m: String, _ who: Person) -> [Txn] { tx.filter { $0.d.hasPrefix(m) && who.owns($0.o) } }
    /// what a month's spending comes to for whoever is chosen: the one figure every screen shows
    /// (`rows`: the month's payments for whoever is picked, asked for only when the month has no engine figure for them;
    /// Store keeps them by month)
    func total(of mo: MonthInfo, _ who: Person, rows: (() -> [Txn])? = nil) -> Double {
        if who == .family { return mo.live ? spentNow : mo.total }
        return spent(mo.m, who, rows: rows)
    }
    func spent(_ m: String, _ who: Person, rows: (() -> [Txn])? = nil) -> Double {
        if who == .family, let mo = month(m) { return mo.live ? spentNow : mo.total }
        // one person's: the engine's, worked out as the household's is, so the people's months come to the family's
        if let w = month(m)?.who { return w.first { $0.o == who.id }?.v ?? 0 }
        return (rows?() ?? txs(in: m, who)).filter { $0.sp }.reduce(0) { $0 + $1.a }
    }
    /// one kind of a month's spending for one person (nil for the family, whose figures are the month's own)
    func spentCats(_ mo: MonthInfo, _ who: Person) -> [MonthInfo.WhoCat]? {
        guard who != .family, let w = mo.who else { return nil }
        return w.first { $0.o == who.id }?.cats ?? []
    }
    /// every kind of a month's spending for whoever is shown, with money back taken off as the month's own figure takes
    /// it: the engine's (each person's kinds, added up for the family), so a kind's figure is the same on every screen.
    /// Only a month built before the engine gave them falls back to the payments themselves.
    func catsSpent(_ mo: MonthInfo, _ who: Person, rows: (() -> [Txn])? = nil) -> [String: Double] {
        var out: [String: Double] = [:]
        if let w = mo.who {
            for p in w where who.owns(p.o) {
                for c in p.cats { out[c.cat.isEmpty ? "Other" : c.cat, default: 0] += c.v }
            }
            return out
        }
        for t in rows?() ?? txs(in: mo.m, who) where t.sp { out[t.c.isEmpty ? "Other" : t.c, default: 0] += t.a }
        return out
    }
    /// money that came in (a month's payments in, less your own transfers and money back on a payment)
    static func moneyIn(_ rows: [Txn]) -> Double {
        rows.filter { $0.k == "in" && $0.c != "Self Transfer" && $0.c != "Transfer in" && ($0.ex ?? "").isEmpty }.reduce(0) { $0 + $1.a }
    }

    // MARK: what's ahead

    /// the dated lines of the next six weeks not yet paid (Home's week and bills ahead, the calendar)
    var datedAhead: [AgendaItem] {
        let end = Day.add(snap.today, 41)
        return snap.agenda.filter { a in
            guard let d = a.date else { return false }
            return d >= snap.today && d <= end && !a.booked
        }.sorted { ($0.date ?? "") < ($1.date ?? "") }
    }
    /// what's still to go out this month: the month's lines not yet paid, from today on (or with no day yet)
    var stillOut: Double {
        snap.agenda.filter { $0.m == snap.cm && $0.kind == "out" && !$0.booked && ($0.date == nil || ($0.date ?? "") >= snap.today) }.reduce(0) { $0 + $1.amt }
    }
    var stillIn: Double {
        snap.agenda.filter { $0.m == snap.cm && $0.kind == "in" && !$0.lock }.reduce(0) { $0 + $1.amt }
    }
    /// the Refunds list: payments with money still owed back on them, for whoever is picked
    func refundsWaiting(_ who: Person) -> [RefundInfo] { (snap.refunds ?? []).filter { $0.state != "back" && who.owns($0.o) } }

    // MARK: what you own and owe

    func holdings(_ p: Person) -> [Holding] { p == .family ? snap.hold : snap.hold.filter { $0.person == p.rawValue } }
    /// what the banks last said is in your accounts
    /// (with what is held in them for an IPO: still the account's money, out of what the bank calls available)
    func bankBalance(_ p: Person) -> Double { snap.accounts.filter { p.owns($0.owner) }.reduce(0) { $0 + ($1.balance ?? 0) + ($1.balance == nil ? 0 : ($1.held ?? 0)) } }
    /// the land under the properties, at the rates set: the household's all of it, a person's what's in their name
    /// (a joint one at their share). A property no one is named on counts only for the household
    func propertyWorth(_ p: Person) -> Double { p == .family ? (snap.prop.worth ?? 0) : (snap.prop.byWho?[p.id]?.worth ?? 0) }
    /// a loan's balance: the one you typed last, else the engine's
    func loanBalance(_ l: Loan) -> Double? { typedLoans[l.id] ?? l.outstanding }
    func assets(_ p: Person) -> Double { holdings(p).reduce(0) { $0 + $1.amt } + bankBalance(p) + (p == .family || p == .me ? cashInHand : 0) + propertyWorth(p) }
    func debts(_ p: Person) -> Double {
        snap.loans.filter { $0.active && p.owns($0.owner ?? "me") }.reduce(0) { $0 + (loanBalance($1) ?? 0) }
    }
    func netWorth(_ p: Person) -> Double { assets(p) - debts(p) }
    /// net worth month by month: what was held at each month's end (from the engine's dated record), with
    /// cash, the land at the rate you set and today's loans as they are now (kosh has no past figure for them); this
    /// month is today's figure, so the line ends where the headline is
    func worthSeries(_ p: Person) -> [NWPoint] {
        var by: [String: Double] = [:]
        // (a loan's dated figure, "loan", is the engine's; the line takes today's loans off below, so it is left out here)
        for w in snap.worth ?? [] where p.owns(w.o) { by[w.m, default: 0] += w.v.filter { $0.key != "loan" }.values.reduce(0, +) }
        guard !by.isEmpty else { return [] }
        let extra: Double = (p == .family || p == .me ? cashInHand : 0) + propertyWorth(p) - debts(p)
        var out = by.keys.sorted().map { NWPoint(m: $0, v: (by[$0] ?? 0) + extra) }
        out.removeAll { $0.m == snap.cm }
        out.append(NWPoint(m: snap.cm, v: netWorth(p), day: snap.today))
        return out
    }
}
