import Foundation
import Observation
import UIKit
import Network

// MARK: - LiveSession: the inboxes: Google sign-in, more Gmail accounts, Outlook (Microsoft) and mail servers (IMAP)
// (split out of LiveSession.swift, 17 Oct 2026; its stored state stays in the class there)

extension LiveSession {
    // MARK: Google sign-in

    func signInRequest() throws -> (url: URL, scheme: String) {
        guard !clientID.isEmpty else { throw LiveError.noClientID }
        let p = GoogleOAuth.pkce()
        verifier = p.verifier
        oauthState = UUID().uuidString
        // when adding a second account, don't pre-fill the one already signed in
        return (GoogleOAuth.authURL(clientID: clientID, challenge: p.challenge, state: oauthState, hint: addingAccount ? nil : email, pick: addingAccount), GoogleOAuth.scheme(clientID))
    }

    @MainActor

    func finishSignIn(_ callback: URL) async throws {
        let t = try await GoogleOAuth.finish(callback: callback, clientID: clientID, verifier: verifier, state: oauthState)
        if let r = t.refresh { Keychain.set(r, for: "google.refresh") }
        access[email] = (t.access, t.expires)
        if !t.email.isEmpty { email = t.email }
        ud.set("gmail", forKey: "beta.provider")
        if !t.name.isEmpty { name = t.name }
        signedIn = true
        if people.isEmpty {
            people = [PersonInfo(id: "me", name: firstName, full: name.isEmpty ? "You" : name, rel: "You", color: Self.palette[0])]
        }
        save()
    }

    /// the first inbox's own key, as kosh keeps it for its provider
    var primaryKey: String { Self.credentialKey(ud.string(forKey: "beta.provider") ?? "gmail", email, primary: true) }
    /// an inbox's key is on this phone (one the phone can't read until it's unlocked counts: it is still there)
    func keyKept(_ acct: String) -> Bool {
        if acct.isEmpty || acct == email { return !email.isEmpty && !Keychain.missing(primaryKey) }
        return !Keychain.missing(Self.credentialKey(config(acct).provider, acct, primary: false))
    }
    /// signed in again once the first inbox's key can be read: a read that failed while the phone was locked (a
    /// background start before the first unlock) marked it signed out, and nothing else turned it back on
    @MainActor
    func recheckSignIn() {
        guard !signedIn, !email.isEmpty, Keychain.get(primaryKey) != nil else { return }
        signedIn = true
    }

    func signOut() {
        Keychain.set(nil, for: "google.refresh")
        Keychain.set(nil, for: Self.credentialKey(config(email).provider, email, primary: true))
        access.removeAll()
        signedIn = false
    }

    /// an access token for one inbox, refreshed if it has less than `lasting` seconds left (a minute for a read on
    /// screen; most of an hour for the background downloads, which carry it until they're done)
    func token(_ acct: String? = nil, lasting: TimeInterval = 60) async throws -> String {
        let a = acct ?? email
        if let c = access[a], c.until > Date().addingTimeInterval(lasting) { return c.token }
        guard let r = Keychain.get(refreshKey(a)) else {
            // (signed out only when the key is gone: one the phone can't read just now, before its first unlock, is
            // still there, and calling that signed out hid every inbox on Settings › Mail until kosh restarted)
            if a == email && Keychain.missing(refreshKey(a)) { await MainActor.run { self.signedIn = false } }
            throw LiveError.signIn("Sign in to Google again.")
        }
        do {
            // (two reads asking at once, the sweep and the downloads, share one refresh instead of racing for it)
            let id = clientID
            let got = try await access.refresh(a) {
                let (t, until) = try await GoogleOAuth.refresh(r, clientID: id)
                return (t, until)
            }
            return got.token
        } catch {
            if "\(error)".contains("invalid_grant") {
                Keychain.set(nil, for: refreshKey(a))
                if a == email { await MainActor.run { self.signedIn = false } }
                throw LiveError.signIn("Google ended kosh’s sign-in for \(a), as it does every 7 days for an app still in testing. Tap Reconnect Gmail to carry on; nothing read so far is lost.")
            }
            throw error
        }
    }

    static func retrying<T>(_ times: Int = 5, _ f: () async throws -> T) async throws -> T {
        var wait = 1.5
        var attempt = 0
        while true {
            do { return try await f() }
            catch LiveError.busy(let s) {
                attempt += 1
                if attempt >= times { throw LiveError.busy(s) }
                try await Task.sleep(for: .seconds(max(s, wait)))
                wait *= 2
            }
        }
    }

    func beginAddAccount(for person: String? = nil) { addingAccount = true; addingFor = person }

    func cancelAddAccount() { addingAccount = false; addingFor = nil }

    /// whose an inbox is: the one you signed in with is yours; a family member's is theirs
    func ownerOf(inbox acct: String) -> String {
        if acct.isEmpty || acct == email { return "me" }
        return accounts.first { $0.id == acct }?.person ?? "me"
    }

    /// the Gmail connected for one person, if any
    func inbox(of person: String) -> MailAccount? { accounts.first { $0.person == person } }

    /// give an inbox to someone (or back to you); what came from it follows
    func setInboxOwner(_ acct: String, _ person: String?) {
        guard let i = accounts.firstIndex(where: { $0.id == acct }) else { return }
        accounts[i].person = person == "me" ? nil : person
        save(); rebuild()
    }

    @MainActor

    func finishAddAccount(_ callback: URL) async throws {
        let t = try await GoogleOAuth.finish(callback: callback, clientID: clientID, verifier: verifier, state: oauthState)
        addingAccount = false
        let forWhom = addingFor
        addingFor = nil
        let addr = t.email
        if addr == email { throw LiveError.signIn("That’s the account you’re already signed in with.") }
        guard !addr.isEmpty else { return }
        if let r = t.refresh { Keychain.set(r, for: refreshKey(addr)) }
        access[addr] = (t.access, t.expires)
        if let i = accounts.firstIndex(where: { $0.id == addr }) {
            if let forWhom { accounts[i].person = forWhom == "me" ? nil : forWhom }
        } else {
            // one Gmail per person: connecting a new one for someone replaces theirs
            if let forWhom, forWhom != "me", let old = accounts.firstIndex(where: { $0.person == forWhom }) { accounts[old].person = nil }
            var a = MailAccount(id: addr, name: t.name.isEmpty ? addr : t.name, color: Self.palette[(accounts.count + 1) % Self.palette.count],
                                person: forWhom == "me" ? nil : forWhom)
            a.tag = freshInboxTag()
            accounts.append(a)
        }
        save()
        // read the new inbox from as far back as the rest, in the background
        if !scanFrom.isEmpty { Task { await self.readInbox(addr) } }
    }

    /// one inbox, from the date the others go back to: used when an inbox is added after the first read
    @MainActor

    func readInbox(_ addr: String) async {
        let job = "inbox:" + addr
        guard !inboxesReading.contains(addr) else { return }
        // a read that was cut short carries on with the same window
        let from = plan(job)?.windows.first?.after ?? (scanFrom.isEmpty ? Self.daysAgo(scanDays) : scanFrom)
        KeepGoing.shared.begin("Reading the new inbox")
        defer { KeepGoing.shared.end() }
        inboxesReading.insert(addr)
        readingInbox = true
        let ok = await sweep(after: from, before: nil, quiet: true, only: addr, job: job)
        inboxesReading.remove(addr)
        readingInbox = !inboxesReading.isEmpty
        if !ok && halted { return }
        await readDocuments()
        if aiReady && !running && !halted { await aiPass() }
    }

    func removeAccount(_ addr: String) {
        Keychain.set(nil, for: refreshKey(addr))
        Keychain.set(nil, for: Self.credentialKey(config(addr).provider, addr, primary: false))
        access[addr] = nil
        // its tag, taken before it goes (the other inboxes keep theirs: nothing shifts)
        let tag: String = inboxTag(addr)
        accounts.removeAll { $0.id == addr }
        plans["inbox:" + addr] = nil
        // drop what that account contributed: its records by their inbox, and one without an inbox by its tag
        records.removeAll { r in
            if let a = r.acct, !a.isEmpty { return a == addr }
            return !tag.isEmpty && r.id.hasPrefix(tag)
        }
        save(); rebuild()
    }

    // MARK: Inboxes beyond Gmail: Outlook (Microsoft) and mail servers (IMAP)

    /// how an inbox is reached: the one you signed in with (Gmail, unless you started with another), then the rest
    func config(_ acct: String) -> MailConfig {
        if acct.isEmpty || acct == email {
            let port = ud.integer(forKey: "beta.imapPort")
            return MailConfig(provider: ud.string(forKey: "beta.provider") ?? "gmail", host: ud.string(forKey: "beta.imapHost") ?? "",
                              port: port > 0 ? port : 993, login: ud.string(forKey: "beta.imapLogin") ?? email)
        }
        if let a = accounts.first(where: { $0.id == acct }) {
            return MailConfig(provider: a.provider ?? "gmail", host: a.host ?? "", port: a.port ?? 993, login: a.login ?? a.id)
        }
        return MailConfig(provider: "gmail")
    }

    func isGmail(_ acct: String) -> Bool { config(acct).isGmail }

    /// which provider an inbox is with, by name ("Gmail", "Outlook", "Yahoo Mail"…), for the screens
    func providerName(_ acct: String) -> String {
        let c = config(acct)
        if c.provider == "imap" {
            let id = (try? Engine.shared.call("providerFor", [acct])) ?? ""
            return MailProviderInfo.of(id.isEmpty ? "imap" : id)?.name ?? "Email"
        }
        return c.provider == "microsoft" ? "Outlook" : "Gmail"
    }

    /// where an inbox's key lives in the Keychain: Google's refresh token, Microsoft's, or the mail server's password
    static func credentialKey(_ provider: String, _ acct: String, primary: Bool) -> String {
        switch provider {
        case "microsoft": return "ms.refresh." + acct
        case "imap": return "imap.pass." + acct
        default: return primary ? "google.refresh" : "google.refresh." + acct
        }
    }

    func setMSClientID(_ s: String) {
        let v = s.trimmingCharacters(in: .whitespacesAndNewlines)
        msClientID = v
        ud.set(v, forKey: "beta.msClientID")
    }

    /// a Microsoft access token for one inbox; each refresh brings a new refresh token, kept in place of the old
    func msToken(_ acct: String, lasting: TimeInterval = 60) async throws -> String {
        if let c = access[acct], c.until > Date().addingTimeInterval(lasting) { return c.token }
        let key = Self.credentialKey("microsoft", acct, primary: acct == email)
        guard let r = Keychain.get(key) else {
            if acct == email && Keychain.missing(key) { await MainActor.run { self.signedIn = false } }
            throw LiveError.signIn("Sign in to Microsoft again for \(acct).")
        }
        guard !msClientID.isEmpty else { throw LiveError.signIn("kosh’s Microsoft app ID isn’t set.") }
        do {
            // (one refresh at a time: Microsoft's refresh token changes with each, so a second one at once would use a spent one)
            let id = msClientID
            let got = try await access.refresh(acct) {
                let (t, until, fresh) = try await MicrosoftOAuth.refresh(r, clientID: id)
                if let fresh, !fresh.isEmpty { Keychain.set(fresh, for: key) }
                return (t, until)
            }
            return got.token
        } catch {
            if "\(error)".contains("invalid_grant") {
                Keychain.set(nil, for: key)
                if acct == email { await MainActor.run { self.signedIn = false } }
                throw LiveError.signIn("Microsoft ended the sign-in for \(acct). Connect it again in Settings.")
            }
            throw error
        }
    }

    /// a mail server inbox: where it is and its password (kept in the Keychain)
    func imapAccount(_ acct: String) throws -> IMAPAccount {
        let c = config(acct)
        guard let pass = Keychain.get(Self.credentialKey("imap", acct, primary: acct == email)), !c.host.isEmpty else {
            throw LiveError.signIn("kosh needs the password for \(acct) again. Connect it in Settings.")
        }
        return IMAPAccount(host: c.host, port: c.port, login: c.login.isEmpty ? acct : c.login, password: pass)
    }

    /// a few emails from one inbox, whichever provider it's with; any that didn't come are left out
    func fetchMessages(_ ids: [String], acct: String) async throws -> [MailMsg] {
        try await fetchSome(ids, acct: acct).got
    }

    /// A few emails from one inbox, whichever provider it's with: what came, and what didn't come but may yet (the
    /// inbox's allowance used up after every try, a dropped connection, a server error), to be asked again and never
    /// struck off unread. What the inbox no longer has (deleted since it was listed) is in neither.
    func fetchSome(_ ids: [String], acct: String) async throws -> (got: [MailMsg], later: [String]) {
        switch config(acct).provider {
        case "microsoft":
            let tok = try await msToken(acct)
            return try await Self.fetchGraph(ids, token: tok)
        case "imap":
            // (a mail server's email that didn't come was moved since it was listed: its folder was rebuilt)
            let got: [MailMsg] = try await IMAPMail.fetch(try imapAccount(acct), ids: ids)
            return (got, [String]())
        default:
            let tok = try await token(acct)
            return await QuotaGate.$inbox.withValue(acct) { await Self.fetchSome(ids, token: tok) }
        }
    }

    /// a few Outlook emails at once; one deleted since it was listed is left out, one that didn't come yet is in
    /// `later`, a connection that failed for all throws
    static func fetchGraph(_ ids: [String], token: String) async throws -> (got: [MailMsg], later: [String]) {
        let result: ([MailMsg], [String], Error?) = await withTaskGroup(of: (Int, MailMsg?, Error?).self) { g in
            for (i, id) in ids.enumerated() {
                g.addTask {
                    do {
                        let m = try await LiveSession.retrying { try await Graph.message(id, token: token) }
                        return (i, m, nil)
                    } catch {
                        return (i, nil, error)
                    }
                }
            }
            var got: [(Int, MailMsg)] = []
            var later: [Int] = []
            var failure: Error? = nil
            for await r in g {
                if let m = r.1 { got.append((r.0, m)) } else if let e = r.2, !LiveSession.gone(e) { failure = e; later.append(r.0) }
            }
            let sorted: [MailMsg] = got.sorted { $0.0 < $1.0 }.map { $0.1 }
            return (sorted, later.sorted().map { ids[$0] }, failure)
        }
        if result.0.isEmpty, let failure = result.2 { throw failure }
        return (result.0, result.1)
    }

    /// an email the server no longer has
    static func gone(_ e: Error) -> Bool {
        if let l = e as? LiveError, case .http(let code, _) = l { return code == 404 }
        return false
    }

    /// one email again (a statement's password hint, a re-read with new rules)
    func fetchOne(_ id: String, acct: String) async throws -> MailMsg {
        switch config(acct).provider {
        case "microsoft":
            let tok = try await msToken(acct)
            return try await Self.retrying { try await Graph.message(id, token: tok) }
        case "imap":
            guard let m = try await IMAPMail.fetch(try imapAccount(acct), ids: [id]).first else { throw LiveError.http(404, "That email is no longer in the inbox.") }
            return m
        default:
            let tok = try await token(acct)
            return try await QuotaGate.$inbox.withValue(acct) { try await Self.retrying { try await Gmail.message(id, token: tok) } }
        }
    }

    /// an attachment's bytes (a statement, an invoice), from whichever inbox it came to
    func attachmentBytes(acct: String, msg: String, att: String) async throws -> Data {
        switch config(acct).provider {
        case "microsoft":
            let tok = try await msToken(acct)
            return try await Self.retrying { try await Graph.attachment(message: msg, attachment: att, token: tok) }
        case "imap":
            return try await IMAPMail.attachment(try imapAccount(acct), id: msg, part: att)
        default:
            let tok = try await token(acct)
            return try await QuotaGate.$inbox.withValue(acct) { try await Self.retrying { try await Gmail.attachment(message: msg, attachment: att, token: tok) } }
        }
    }

    /// A statement's bytes: by the attachment id kept when its mail was read, else by the mail fetched afresh. Gmail
    /// hands out a new attachment id each time a mail is fetched, and one kept for months can stop working: the
    /// attachment with the same file name (or the mail's only one) is fetched by its id of today, and kept on the paper.
    /// A busy inbox is busy, not a stale id: that waits for the next try.
    func docBytes(_ d: inout DocRef) async throws -> Data {
        do { return try await attachmentBytes(acct: d.acct, msg: d.msg, att: d.att) }
        catch LiveError.busy(let s) { throw LiveError.busy(s) }
        catch {
            if Self.gone(error) || config(d.acct).provider == "imap" { throw error }
            let m: MailMsg = try await fetchOne(d.msg, acct: d.acct)
            let file: String = d.file, old: String = d.att
            guard let a = m.attachments.first(where: { $0.filename == file }) ?? (m.attachments.count == 1 ? m.attachments.first : nil), a.id != old else { throw error }
            let bytes: Data = try await attachmentBytes(acct: d.acct, msg: d.msg, att: a.id)
            d.att = a.id
            return bytes
        }
    }

    /// What a window holds in an inbox that isn't Gmail: every sender and subject in it, and the money mail among them
    /// (the mail kosh's Gmail searches would have found), never Sent, Spam or Trash.
    @MainActor

    func listOther(_ acct: String, after: String, before: String?, counting: ((Int) -> Void)?) async throws -> [String] {
        let tell: (@MainActor (Int) -> Void)? = counting.map { f in { n in f(n) } }
        switch config(acct).provider {
        case "microsoft":
            return try await Graph.list(after: after, before: before, token: { [weak self] in
                guard let self else { throw LiveError.signIn("kosh closed") }
                return try await self.msToken(acct)
            }, counting: tell)
        default:
            return try await IMAPMail.list(try imapAccount(acct), after: after, before: before, counting: tell)
        }
    }

    /// Microsoft's sign-in page for Outlook, Hotmail, Live or Microsoft 365
    func microsoftRequest(hint: String? = nil) throws -> (url: URL, scheme: String) {
        guard !msClientID.isEmpty else { throw LiveError.signIn("Outlook needs kosh’s Microsoft app ID first (Settings › Beta).") }
        let p = GoogleOAuth.pkce()
        msVerifier = p.verifier
        msState = UUID().uuidString
        return (MicrosoftOAuth.authURL(clientID: msClientID, challenge: p.challenge, state: msState, hint: hint), MicrosoftOAuth.scheme)
    }

    /// back from Microsoft: the inbox is kosh's first, or added (someone's, if you said)
    @MainActor

    func finishMicrosoft(_ callback: URL, for person: String?) async throws {
        let t = try await MicrosoftOAuth.finish(callback: callback, clientID: msClientID, verifier: msVerifier, state: msState)
        guard !t.email.isEmpty else { throw LiveError.signIn("Microsoft didn’t say which address signed in.") }
        guard let r = t.refresh, !r.isEmpty else { throw LiveError.signIn("Microsoft didn’t let kosh keep reading. Try again and accept.") }
        access[t.email] = (t.access, t.expires)
        try addInbox(addr: t.email, name: t.name, config: MailConfig(provider: "microsoft"), secret: r, for: person)
    }

    /// An inbox on a mail server (Yahoo, iCloud, AOL, Zoho, a work address): its servers are tried in turn until one
    /// signs in and lists its folders, then it's saved and read. Throws why not, when none would.
    @MainActor

    func connectIMAP(email typed: String, password typedPassword: String, provider: String, host: String?, port: Int?, for person: String?) async throws {
        let addr = typed.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard addr.contains("@"), addr.split(separator: "@").last?.contains(".") == true else { throw LiveError.signIn("That doesn’t look like an email address.") }
        // an app password is letters (and dashes); the spaces a page shows it with aren't part of it
        let appPassword = MailProviderInfo.of(provider)?.password == "app"
        let password = appPassword ? typedPassword.filter { !$0.isWhitespace } : typedPassword
        guard !password.isEmpty else { throw LiveError.signIn("Paste the password first.") }
        if (signedIn && addr == email) || accounts.contains(where: { $0.id == addr }) { throw LiveError.signIn("kosh already reads \(addr).") }
        struct Server: Decodable { let host: String; let port: Int; let login: String }
        var servers: [Server] = []
        if let host, !host.trimmingCharacters(in: .whitespaces).isEmpty {
            let h = host.trimmingCharacters(in: .whitespaces).lowercased()
            servers = [Server(host: h, port: port ?? 993, login: addr), Server(host: h, port: port ?? 993, login: String(addr.split(separator: "@").first ?? ""))]
        } else {
            let xml = await Self.serverDirectory(for: addr, provider: provider)
            servers = (try? JSONText.decode([Server].self, try Engine.shared.call("serversForJSON", [addr, provider, xml]))) ?? []
        }
        guard !servers.isEmpty else { throw MailError.noServer("kosh couldn’t find the mail server for \(addr). Type it in: it usually starts with imap.") }
        var why: Error = MailError.noServer("kosh couldn’t reach a mail server for \(addr).")
        var signInRefused = false
        for s in servers {
            do {
                _ = try await IMAPMail.verify(IMAPAccount(host: s.host, port: s.port, login: s.login, password: password))
                try addInbox(addr: addr, name: addr, config: MailConfig(provider: "imap", host: s.host, port: s.port, login: s.login), secret: password, for: person)
                return
            } catch MailError.login(let m) {
                // the server is there and said no: a wrong password, or a different sign-in name on the next try
                signInRefused = true
                why = MailError.login(m)
            } catch {
                if !signInRefused { why = error }
            }
        }
        if signInRefused {
            let name = MailProviderInfo.of(provider)?.name ?? "The mail server"
            throw MailError.login(appPassword ? "\(name) didn’t accept that app password. Make a new one and paste it exactly." : "\(name) didn’t accept that password.")
        }
        throw why
    }

    /// Thunderbird's public directory of mail servers, for an address kosh has no preset for: only its domain is sent
    static func serverDirectory(for addr: String, provider: String) async -> String {
        guard provider == "imap", let dom = addr.split(separator: "@").last, let url = URL(string: "https://autoconfig.thunderbird.net/v1.1/" + dom) else { return "" }
        var req = URLRequest(url: url)
        req.timeoutInterval = 8
        guard let got = try? await URLSession.shared.data(for: req), (got.1 as? HTTPURLResponse)?.statusCode == 200 else { return "" }
        return String(decoding: got.0, as: UTF8.self)
    }

    /// a connected inbox: the first becomes the one you signed in with; any other is added (someone's, if you said)
    @MainActor

    func addInbox(addr: String, name: String, config c: MailConfig, secret: String, for person: String?) throws {
        if !signedIn {
            Keychain.set(secret, for: Self.credentialKey(c.provider, addr, primary: true))
            email = addr
            if !name.isEmpty && name != addr { self.name = name }
            ud.set(c.provider, forKey: "beta.provider")
            ud.set(c.host, forKey: "beta.imapHost")
            ud.set(c.port, forKey: "beta.imapPort")
            ud.set(c.login, forKey: "beta.imapLogin")
            signedIn = true
            if people.isEmpty {
                people = [PersonInfo(id: "me", name: firstName, full: self.name.isEmpty ? "You" : self.name, rel: "You", color: Self.palette[0])]
            }
            save()
            return
        }
        if addr == email { throw LiveError.signIn("That’s the inbox kosh already reads.") }
        Keychain.set(secret, for: Self.credentialKey(c.provider, addr, primary: false))
        var a = accounts.first(where: { $0.id == addr }) ?? MailAccount(id: addr, name: name.isEmpty ? addr : name, color: Self.palette[(accounts.count + 1) % Self.palette.count])
        a.provider = c.isGmail ? nil : c.provider
        a.host = c.provider == "imap" ? c.host : nil
        a.port = c.provider == "imap" ? c.port : nil
        a.login = c.provider == "imap" ? c.login : nil
        if let person { a.person = person == "me" ? nil : person }
        if (a.tag ?? "").isEmpty { a.tag = freshInboxTag() }
        if let i = accounts.firstIndex(where: { $0.id == addr }) { accounts[i] = a } else { accounts.append(a) }
        save()
        // read the new inbox from as far back as the rest, in the background
        if !scanFrom.isEmpty { Task { await self.readInbox(addr) } }
    }
}

/// the inboxes' access tokens, safe to read and write from any thread: the sweep and the downloads ask at the same
/// time. A refresh already on its way is shared, so two callers never refresh one inbox at once.
final class TokenCache: @unchecked Sendable {
    typealias Entry = (token: String, until: Date)
    private let lock = NSLock()
    private var map: [String: Entry] = [:]
    private var flying: [String: Task<Entry, Error>] = [:]

    subscript(acct: String) -> Entry? {
        get { lock.withLock { map[acct] } }
        set { lock.withLock { map[acct] = newValue } }
    }

    func removeAll() { lock.withLock { map.removeAll(); flying.removeAll() } }

    /// a fresh token for one inbox: joins the refresh already on its way, or starts one; what it gets is kept
    func refresh(_ acct: String, _ fetch: @escaping @Sendable () async throws -> Entry) async throws -> Entry {
        let task: Task<Entry, Error> = lock.withLock {
            if let going = flying[acct] { return going }
            let t = Task<Entry, Error> { try await fetch() }
            flying[acct] = t
            return t
        }
        do {
            let e = try await task.value
            lock.withLock {
                if flying[acct] == task { flying[acct] = nil }
                map[acct] = e
            }
            return e
        } catch {
            lock.withLock { if flying[acct] == task { flying[acct] = nil } }
            throw error
        }
    }
}
