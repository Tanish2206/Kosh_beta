import SwiftUI

// MARK: - Insurance, part by part
//
// The pages behind the Insurance home's parts (Route.cover): Health (people first, then each policy), Life (every
// policy, what each earns and when money comes back), Motor (one card per vehicle, its renewals as history), Other,
// everything that needs a look, the renewal calendar (InsuranceCalendar.swift) and the payments timeline
// (InsurancePayments.swift). The engine arranges them
// (engine.js › insuranceBook: vehicles, healthBy, needsLook, premAhead); a figure kosh doesn't know says what's
// missing and where, never ₹0.

struct InsurancePart: View {
    let part: String
    /// the page's light: its kind's colour, the warm gold elsewhere
    static func aura(_ part: String) -> Color {
        switch part {
        case "Health": return Obsidian.health
        case "Motor": return Obsidian.motor
        case "Life", "Life:term": return Obsidian.term
        case "Life:ulip": return Obsidian.ulip
        default: return Obsidian.savings
        }
    }
    var body: some View {
        // (the payments timeline draws its own page; the rest are drawn in the same black look as the home)
        if part == "Payments" {
            InsPaymentsPage()
        } else {
            Group {
                switch part {
                case "Health": HealthPage().navigationTitle("Health")
                case "Motor": MotorPage().navigationTitle("Motor")
                case "Life": LifePage().navigationTitle("Life")
                case "Life:term": LifePage(only: .term).navigationTitle("Term life")
                case "Life:savings": LifePage(only: .savings).navigationTitle("Savings plans")
                case "Life:ulip": LifePage(only: .ulip).navigationTitle("ULIP")
                case "Look": LookPage().navigationTitle("Needs a look")
                case "Calendar": RenewalCalendarPage().navigationTitle("Renewal calendar")
                default: OtherPage().navigationTitle("Other cover")
                }
            }
            .obsidianPage(aura: InsurancePart.aura(part))
        }
    }
}

/// one fact on a policy's or a vehicle's card: its label, and its value or what's missing
struct InsFact: View {
    let label: String
    let value: String
    var known: Bool = true
    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(label).font(.caption).foregroundStyle(.secondary)
            Text(value)
                .font(known ? Font.subheadline.weight(.semibold) : Font.caption)
                .foregroundStyle(known ? Color.primary : Color.secondary)
                .fixedSize(horizontal: false, vertical: true)
                .privacySensitive()
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .accessibilityElement(children: .combine)
    }
}

/// facts two to a row, one to a row at the largest text sizes
enum InsGrid {
    static func columns(_ type: DynamicTypeSize) -> [GridItem] {
        type.isAccessibilitySize ? [GridItem(.flexible())] : [GridItem(.flexible(), spacing: 12), GridItem(.flexible(), spacing: 12)]
    }
}

// MARK: Health

struct HealthPage: View {
    @Environment(Store.self) private var store
    var body: some View {
        let pols: [Policy] = InsBook.rows(store.policies, "Health")
        let people: [HealthPerson] = InsBook.health(store)
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                KindHead(part: "Health", pols: pols)
                if !people.isEmpty {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("People").font(.title3.weight(.bold)).accessibilityAddTraits(.isHeader)
                        VStack(spacing: 0) {
                            ForEach(Array(people.enumerated()), id: \.element.id) { i, h in
                                if i > 0 { Divider().padding(.leading, 14) }
                                HealthPersonRow(h: h).padding(.horizontal, 14).padding(.vertical, 12)
                            }
                        }
                        .background(CardFill(), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
                    }
                }
                VStack(alignment: .leading, spacing: 10) {
                    Text("Policies").font(.title3.weight(.bold)).accessibilityAddTraits(.isHeader)
                    if pols.isEmpty {
                        InsNone(text: "No health policy in your mail yet. Its schedule, a premium receipt or a renewal notice brings it here.", add: true)
                    }
                    ForEach(pols) { p in
                        Button { store.push(.policy(p.id)) } label: { HealthPolicyCard(p: p) }.buttonStyle(.press)
                    }
                }
                CoverCheck(pols: store.policies, only: "Health")
                let look: [LookItem] = InsBook.look(store).filter { ($0.kind ?? "") == "Health" || ($0.kind ?? "") == "Top-up" }
                if !look.isEmpty { LookSection(items: look) }
            }
            .padding(.horizontal, 20)
            .padding(.top, 8)
            .padding(.bottom, 30)
        }
        .animation(Motion.base, value: store.who)
    }
}

/// one person's health cover: the total and the policies giving it, each with its sum insured and renewal day, or
/// plainly that kosh found none, and the gentle next step
struct HealthPersonRow: View {
    @Environment(Store.self) private var store
    let h: HealthPerson
    var body: some View {
        let name: String = Words.cap(InsBook.who(h.id, store.snap))
        let color: Color = Color(hex: store.person(h.id)?.color ?? (h.id == "me" ? "#007AFF" : "#8E8E93"))
        let mine: [Policy] = h.policies.compactMap { (id: String) -> Policy? in InsBook.policy(store, id) }
        let own: String = h.id == "me" ? "your own" : "their own"
        VStack(alignment: .leading, spacing: 6) {
            HStack(alignment: .firstTextBaseline, spacing: 8) {
                Circle().fill(color).frame(width: 8, height: 8).accessibilityHidden(true)
                Text(name).font(.body.weight(.semibold))
                Spacer(minLength: 8)
                if h.cover > 0 {
                    Text(Fmt.words(h.cover)).font(.body.weight(.bold)).monospacedDigit().privacySensitive()
                } else if !h.policies.isEmpty {
                    Text(mine.contains(where: { InsBook.locked($0) }) ? "Paper locked" : "Cover not read yet").font(.caption).foregroundStyle(.secondary)
                }
            }
            .accessibilityElement(children: .combine)
            if h.policies.isEmpty && h.elsewhere == true {
                // (you said it's held where kosh can't see it: an employer's group cover, a policy in another inbox)
                HStack(spacing: 12) {
                    Text("Covered elsewhere, you said").font(.subheadline).foregroundStyle(.secondary)
                    if let live = store.live {
                        Button("Undo") { live.markHealthElsewhere(h.id, false) }.font(.subheadline.weight(.semibold)).buttonStyle(.borderless)
                    }
                }
            } else if h.policies.isEmpty {
                Text("No health cover found").font(.subheadline.weight(.medium)).foregroundStyle(Color.orange)
                Text("A policy of " + own + ", or a place on a family floater, pays hospital bills. Its schedule or a premium receipt in your mail brings it here; cover from work or in another inbox counts too.")
                    .font(.caption).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                if let live = store.live {
                    HStack(spacing: 16) {
                        Button { store.betaSheet = .policy(nil) } label: { Label("Add", systemImage: "plus.circle").font(.subheadline.weight(.semibold)) }
                            .accessibilityLabel("Add a health policy for " + name)
                        Button { live.markHealthElsewhere(h.id, true) } label: { Text("Covered elsewhere").font(.subheadline.weight(.semibold)) }
                            .accessibilityLabel(name + " is covered somewhere kosh can't see, like an employer's cover")
                    }
                    .buttonStyle(.borderless)
                }
            } else {
                // each policy that covers them: its sum insured and the day it renews (the sum is for the year to then)
                VStack(alignment: .leading, spacing: 3) {
                    ForEach(mine) { (p: Policy) in
                        Text(InsBook.healthLine(p)).font(.caption).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true).privacySensitive()
                    }
                }
            }
        }
    }
}

/// a health policy, whole: sum insured, premium, term, renewal, its number, whom it covers and who holds it
struct HealthPolicyCard: View {
    @Environment(Store.self) private var store
    @Environment(\.dynamicTypeSize) private var type
    let p: Policy
    var body: some View {
        let cover: Double = p.cover ?? 0
        let term: String = (p.years ?? 0) >= 2 ? "\(p.years ?? 0) years, bought at once" : "1 year, renewed yearly"
        let no: String = p.policyNo ?? ""
        let locked: Bool = InsBook.locked(p)
        VStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .top, spacing: 12) {
                PolicyBadge(p: p, size: 40)
                VStack(alignment: .leading, spacing: 2) {
                    Text(InsBook.name(p)).font(.body.weight(.semibold)).fixedSize(horizontal: false, vertical: true)
                    Text(p.insurer + " · " + InsBook.covers(p, store.snap)).font(.caption).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                }
                Spacer(minLength: 4)
                if let st = PolicyStatus.chip(p) { Chip(text: st.0, color: st.1) }
            }
            LazyVGrid(columns: InsGrid.columns(type), alignment: .leading, spacing: 12) {
                InsFact(label: "Sum insured", value: cover > 0 ? Fmt.words(cover) : locked ? "Paper locked" : "Not in mail yet · " + InsBook.whereIs(p, "Cover"), known: cover > 0)
                InsFact(label: "Premium", value: p.premium > 0 ? InsBook.premiumLine(p) : locked ? "Paper locked" : "Not in mail yet · " + InsBook.whereIs(p, "Premium"), known: p.premium > 0)
                InsFact(label: "Term", value: term)
                InsFact(label: "Renews", value: p.nextDue.isEmpty ? "Not in mail yet" : Day.fmt(p.nextDue, "d MMM yyyy"), known: !p.nextDue.isEmpty)
                if !no.isEmpty { InsFact(label: "Policy number", value: no.count > 4 ? "••" + String(no.suffix(4)) : no) }
                if let hd = p.holder, !hd.isEmpty { InsFact(label: "Held by", value: hd) }
                if PolicyKinds.of(p) == "Top-up" { InsFact(label: "Pays", value: "Above its deductible") }
                if let a = p.addOns, !a.isEmpty { InsFact(label: "Add-ons", value: a.joined(separator: ", ")) }
            }
            // (the card is a button to the policy, whose page has the way to the details that open its paper)
            if locked { LockedPaperNote(p: p, button: false) }
        }
        .padding(14)
        .background(CardFill(), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        .contentShape(Rectangle())
    }
}

// MARK: Motor

struct MotorPage: View {
    @Environment(Store.self) private var store
    var body: some View {
        let vehicles: [VehicleInfo] = InsBook.vehicles(store)
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                KindHead(part: "Motor", pols: [], vehicles: vehicles.count)
                if vehicles.isEmpty {
                    InsNone(text: "No car or two-wheeler policy in your mail yet. Its policy mail or renewal notice brings it here.", add: true)
                }
                ForEach(vehicles) { v in VehicleCard(v: v, named: vehicles.filter { !$0.reg.isEmpty && $0.id != v.id }) }
            }
            .padding(.horizontal, 20)
            .padding(.top, 8)
            .padding(.bottom, 30)
        }
        .animation(Motion.base, value: store.who)
    }
}

/// one vehicle: its registration, what it is, its cover now (IDV, premium, renewal, comprehensive or third party and
/// its add-ons), where it stands, and its earlier policies. One kosh can't name gets a way to name it
struct VehicleCard: View {
    @Environment(Store.self) private var store
    @Environment(\.dynamicTypeSize) private var type
    let v: VehicleInfo
    /// the vehicles it could be put with
    let named: [VehicleInfo]
    @State private var reg: String = ""
    var body: some View {
        let pill: (String, Color) = VehicleStatus.pill(v)
        let cur: Policy? = InsBook.policy(store, v.policy)
        let history: [Policy] = v.history.compactMap { InsBook.policy(store, $0) }
        let cover: String = VehicleStatus.coverLine(v)
        let warn: String = VehicleStatus.warning(v)
        let thisYear: String = VehicleStatus.thisYear(cur)
        // (its IDV or premium is in this year's policy paper, which came locked)
        let locked: Bool = cur.map { InsBook.locked($0) } ?? false
        VStack(alignment: .leading, spacing: 14) {
            HStack(alignment: .top, spacing: 10) {
                Image(systemName: VehicleStatus.sym(v)).font(.title3).foregroundStyle(PolicyLook.color("Motor")).accessibilityHidden(true)
                VStack(alignment: .leading, spacing: 2) {
                    if v.reg.isEmpty, let model = v.model, !model.isEmpty {
                        Text(model).font(.title3.weight(.bold)).fixedSize(horizontal: false, vertical: true)
                    } else if v.reg.isEmpty {
                        Text("A vehicle kosh can't name yet").font(.title3.weight(.bold)).fixedSize(horizontal: false, vertical: true)
                    } else {
                        Text(v.reg).font(.system(.title2, design: .monospaced, weight: .bold)).lineLimit(1).minimumScaleFactor(0.7)
                    }
                    Text(VehicleStatus.kindWord(v) + " · " + v.insurer + " · " + store.ownerName(v.owner)).font(.caption).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                }
                Spacer(minLength: 4)
                Chip(text: pill.0, color: pill.1)
            }
            LazyVGrid(columns: InsGrid.columns(type), alignment: .leading, spacing: 12) {
                InsFact(label: "IDV", value: (v.idv ?? 0) > 0 ? Fmt.rupees(v.idv ?? 0) : locked ? "Paper locked" : "Not in mail yet", known: (v.idv ?? 0) > 0)
                InsFact(label: "Premium", value: (v.premium ?? 0) > 0 ? Fmt.rupees(v.premium ?? 0) + " a year" : locked ? "Paper locked" : "Not in mail yet", known: (v.premium ?? 0) > 0)
                InsFact(label: v.status == "lapsed" ? "Ended" : "Renews", value: (v.renews ?? "").isEmpty ? "Not in mail yet" : Day.fmt(v.renews ?? "", "d MMM yyyy"), known: !(v.renews ?? "").isEmpty)
                InsFact(label: "Cover", value: cover, known: !(v.coverType ?? "").isEmpty)
            }
            if !warn.isEmpty {
                Label(warn, systemImage: "exclamationmark.triangle.fill")
                    .font(.footnote).foregroundStyle(pill.1).fixedSize(horizontal: false, vertical: true)
            }
            if let c = cur, locked { LockedPaperNote(p: c) }
            if v.reg.isEmpty { nameIt(cur: cur, history: history) }
            if let c = cur {
                Button { store.push(.policy(c.id)) } label: {
                    HStack {
                        Text(thisYear).font(.subheadline.weight(.semibold))
                        Spacer()
                        Image(systemName: "chevron.right").font(.footnote.weight(.semibold)).foregroundStyle(.tertiary)
                    }
                    .contentShape(Rectangle())
                }
                .buttonStyle(.press)
            }
            if !history.isEmpty {
                VStack(alignment: .leading, spacing: 8) {
                    Text("History").font(.subheadline.weight(.semibold)).foregroundStyle(.secondary).accessibilityAddTraits(.isHeader)
                    ForEach(history) { p in
                        Button { store.push(.policy(p.id)) } label: { VehicleHistoryRow(p: p) }.buttonStyle(.press)
                    }
                }
            }
        }
        .padding(16)
        .background(CardFill(), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
    }

    /// a registration to give it, or a vehicle to put it with
    @ViewBuilder func nameIt(cur: Policy?, history: [Policy]) -> some View {
        let keys: [String] = ([cur].compactMap { $0 } + history).compactMap { $0.key }.filter { !$0.isEmpty }
        let clean: String = reg.uppercased().filter { $0.isLetter || $0.isNumber }
        let ok: Bool = clean.range(of: "^[A-Z]{2}[0-9]{1,2}[A-Z]{1,3}[0-9]{4}$", options: .regularExpression) != nil
        VStack(alignment: .leading, spacing: 8) {
            Text("Its mail printed no registration. Give it one, or put it with a vehicle kosh knows.").font(.footnote).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            if let live = store.live, !keys.isEmpty {
                HStack(spacing: 10) {
                    TextField("Registration, like MH01AB1234", text: $reg)
                        .textInputAutocapitalization(.characters)
                        .autocorrectionDisabled()
                        .font(.body.monospaced())
                        .padding(.horizontal, 12).padding(.vertical, 8)
                        .background(Color.primary.opacity(0.05), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                    Button("Save") { for k in keys { live.markPolicy("reg|" + k, clean) } }
                        .font(.subheadline.weight(.semibold))
                        .disabled(!ok)
                }
                if !named.isEmpty {
                    Menu {
                        ForEach(named) { o in
                            Button(o.reg + " · " + VehicleStatus.kindWord(o)) { for k in keys { live.markPolicy("reg|" + k, o.reg) } }
                        }
                    } label: { Label("Put it with a vehicle", systemImage: "arrow.triangle.merge").font(.subheadline.weight(.semibold)) }
                }
            }
        }
    }
}

/// an earlier policy of a vehicle: its insurer, the year it ran, its premium
struct VehicleHistoryRow: View {
    let p: Policy
    var body: some View {
        let from: String = (p.start ?? "").isEmpty ? p.lastPaid : (p.start ?? "")
        let span: String = from.isEmpty ? "Dates not in mail" : Day.fmt(from, "MMM yyyy") + ((p.end ?? "").isEmpty ? "" : " to " + Day.fmt(p.end ?? "", "MMM yyyy"))
        HStack(alignment: .firstTextBaseline, spacing: 8) {
            VStack(alignment: .leading, spacing: 1) {
                Text(p.insurer).font(.subheadline)
                Text(span).font(.caption).foregroundStyle(.secondary)
            }
            Spacer(minLength: 8)
            if p.premium > 0 { Text(Fmt.rupees(p.premium)).font(.subheadline).monospacedDigit().foregroundStyle(.secondary).privacySensitive() }
            Image(systemName: "chevron.right").font(.caption.weight(.semibold)).foregroundStyle(.tertiary).accessibilityHidden(true)
        }
        .contentShape(Rectangle())
        .accessibilityElement(children: .combine)
    }
}

// MARK: Life, Other, Needs a look

struct LifePage: View {
    @Environment(Store.self) private var store
    /// one kind of life cover only (a tile of By kind): term, savings or ULIP
    var only: InsKind? = nil
    var body: some View {
        let all: [Policy] = InsBook.rows(store.policies, "Life")
        let pols: [Policy] = only.map { k in all.filter { InsKind.of($0) == k } } ?? all
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                KindHead(part: "Life", pols: pols)
                if pols.isEmpty {
                    InsNone(text: "No life cover in your mail yet. A term plan's or a savings plan's schedule or receipt brings it here.", add: true)
                } else {
                    InsRows(pols: pols)
                }
                CoverCheck(pols: store.policies, only: "Life")
                WhatItEarns(pols: pols)
                MoneyBack(pols: pols)
                PolicyTimeline(pols: pols)
            }
            .padding(.horizontal, 20)
            .padding(.top, 8)
            .padding(.bottom, 30)
        }
        .animation(Motion.base, value: store.who)
    }
}

struct OtherPage: View {
    @Environment(Store.self) private var store
    var body: some View {
        let pols: [Policy] = InsBook.rows(store.policies, "Other")
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                KindHead(part: "Other", pols: pols)
                if pols.isEmpty {
                    InsNone(text: "No travel, home or accident cover in your mail.", add: true)
                } else {
                    InsRows(pols: pols)
                }
            }
            .padding(.horizontal, 20)
            .padding(.top, 8)
            .padding(.bottom, 30)
        }
    }
}

struct LookPage: View {
    @Environment(Store.self) private var store
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 28) {
                CoverGapsCard(notes: InsBook.coverNotes(store))
                LookSection(items: InsBook.look(store))
            }
            .padding(.horizontal, 20)
            .padding(.top, 8)
            .padding(.bottom, 30)
        }
    }
}

/// who has no health or life cover kosh can see, and a vehicle whose cover ended (the household's, from the build)
struct CoverGapsCard: View {
    let notes: [String]
    var body: some View {
        if !notes.isEmpty {
            VStack(alignment: .leading, spacing: 12) {
                Text("Cover kosh can’t see").caption()
                VStack(alignment: .leading, spacing: 14) {
                    ForEach(notes, id: \.self) { (n: String) in row(n) }
                }
                .obsidianCard(20, padding: 16)
            }
        }
    }
    func row(_ n: String) -> some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: "shield.slash").font(.system(size: 14, weight: .semibold)).foregroundStyle(Obsidian.savings)
                .frame(width: 28, height: 28).background(Obsidian.savings.opacity(0.13), in: Circle())
                .accessibilityHidden(true)
            Text(n).font(.system(size: 14.5)).foregroundStyle(Obsidian.ink).fixedSize(horizontal: false, vertical: true)
                .privacySensitive()
        }
    }
}
