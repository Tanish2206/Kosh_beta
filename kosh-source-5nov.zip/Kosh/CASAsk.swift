import Foundation

// MARK: - Asking for a fund statement when none comes (screen-free; engine-test/cas-ask.js compiles it with swiftc)
//
// The engine says a person's fund statement is missing, behind or old (snap.casGap, engine/21n-build-cas-gap.js). kosh
// can't fetch one: MF Central's statement API is sold only to registered distributors and advisers, and an Account
// Aggregator needs a partner (CAS-FAILSAFE.md). So the person asks for it themselves on a registrar's free page, inside
// kosh, and kosh reads what comes back. This file holds the pages (one place) and what the card says at each step;
// what the person said ("I asked", "not now") is kept by the gap's own id, so the same gap never asks twice.

/// The official, free pages where an investor asks for their consolidated account statement. Found and checked on the
/// day below (CAS-FAILSAFE.md says where, and how to check them again). kosh only opens them: the person types and
/// sends the form; kosh never fills, reads or submits it.
enum CASRequest {
    struct Page: Hashable, Identifiable {
        let id: String
        let name: String
        let url: String
        /// what the statement it sends covers
        let covers: String
        /// what the form asks, in the order it asks
        let steps: [String]
    }
    /// the day these addresses were last checked against AMFI's own list and the pages themselves
    static let checked = "2026-10-30"
    static let pages: [Page] = [
        Page(id: "kfintech", name: "KFintech", url: "https://mfs.kfintech.com/investor/General/ConsolidatedAccountStatement",
             covers: "Every mutual fund you hold under your PAN, whichever registrar serves it.",
             steps: ["Statement type: Detailed.", "Period: Current financial year (or a specific period up to today).",
                     "Email: the one your funds have, shown above.", "PAN: optional.",
                     "Password: choose one you’ll remember (8 or more, with a capital, a small letter, a number and a sign). kosh asks for it once, when the statement comes.",
                     "Type the security check and send it."]),
        Page(id: "cams", name: "CAMS", url: "https://www.camsonline.com/Investors/Statements/Consolidated-Account-Statement",
             covers: "Every mutual fund you hold under your PAN, whichever registrar serves it.",
             steps: ["Choose the consolidated statement, Detailed.", "Period: the one that reaches today.",
                     "Email: the one your funds have, shown above.",
                     "Password: choose one you’ll remember. kosh asks for it once, when the statement comes.",
                     "Send it."]),
        Page(id: "mfcentral", name: "MF Central", url: "https://www.mfcentral.com/",
             covers: "Every mutual fund under your PAN, from both registrars’ own service.",
             steps: ["Sign in with your PAN and the OTP sent to your mobile (once: sign up the first time).",
                     "Open the statement (CAS) page and choose Detailed, with a period up to today.",
                     "Have it emailed, or download it and add it in Wealth › Holdings › Statements."]),
    ]
    static func page(_ id: String) -> Page? { pages.first { $0.id == id } }
}

enum CASAsk {
    /// what the person said of one gap, kept by its id
    struct Said: Codable, Equatable {
        /// the day they said they asked for a statement
        var asked: String? = nil
        /// "not now": this gap is never shown again (a new statement makes a new gap)
        var notNow: Bool? = nil
    }
    /// what the card shows for a gap
    enum Show: Equatable {
        case ask
        /// they asked on that day; kosh waits quietly
        case waiting(since: String)
        /// they asked that long ago and nothing came: once more, in other words
        case again(since: String)
        /// the statement came locked: its password opens it
        case unlock
        case hidden
    }
    /// a statement asked for comes within a day or two; after this many days, the card says nothing came
    static let waitDays = 14

    /// where the person's word on every gap is kept (one JSON map, by gap id), on this phone only
    static let storeKey = "cas.said"
    static func decode(_ json: String) -> [String: Said] {
        guard let d = json.data(using: .utf8), !json.isEmpty else { return [:] }
        return (try? JSONDecoder().decode([String: Said].self, from: d)) ?? [:]
    }
    static func encode(_ all: [String: Said]) -> String {
        let e = JSONEncoder()
        e.outputFormatting = .sortedKeys
        return (try? e.encode(all)).flatMap { String(data: $0, encoding: .utf8) } ?? ""
    }

    static func show(kind: String, said: Said?, today: String) -> Show {
        if said?.notNow == true { return .hidden }
        if kind == "locked" { return .unlock }
        if let a = said?.asked, let n = days(from: a, to: today) {
            return n < waitDays ? .waiting(since: a) : .again(since: a)
        }
        return .ask
    }

    /// the line under a gap's title for each step (the engine's own why for a fresh one)
    static func line(_ show: Show, why: String, to: String) -> String {
        switch show {
        case .ask, .unlock, .hidden: return why
        case .waiting(let since):
            return "You asked on " + short(since) + ". It usually comes within a day" + (to.isEmpty ? "" : " to " + to) + "; kosh reads it when it lands."
        case .again(let since):
            return "You asked on " + short(since) + " and nothing has come. It goes to the email your funds have on file: if that’s another inbox, add it in Settings › Mail, or ask again."
        }
    }

    /// "2 Nov" (this year) or "2 Nov 2025"
    static func short(_ iso: String, today: String = "") -> String {
        let p = iso.prefix(10).split(separator: "-").compactMap { Int($0) }
        guard p.count == 3, (1...12).contains(p[1]) else { return iso }
        let mon = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"][p[1] - 1]
        let sameYear = today.count >= 4 && today.prefix(4) == iso.prefix(4)
        return "\(p[2]) \(mon)" + (sameYear || today.isEmpty ? "" : " \(p[0])")
    }

    /// whole days from one ISO day to another (nil when either isn't a day)
    static func days(from a: String, to b: String) -> Int? {
        guard let x = dayNumber(a), let y = dayNumber(b) else { return nil }
        return y - x
    }
    static func dayNumber(_ iso: String) -> Int? {
        let p = iso.prefix(10).split(separator: "-").compactMap { Int($0) }
        guard p.count == 3, (1...12).contains(p[1]), (1...31).contains(p[2]) else { return nil }
        var c = DateComponents(); c.year = p[0]; c.month = p[1]; c.day = p[2]
        var cal = Calendar(identifier: .gregorian)
        cal.timeZone = TimeZone(identifier: "UTC") ?? .current
        guard let d = cal.date(from: c), cal.component(.day, from: d) == p[2] else { return nil }
        return Int((d.timeIntervalSince1970 / 86_400).rounded(.down))
    }
}
