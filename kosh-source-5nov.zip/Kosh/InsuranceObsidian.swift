import SwiftUI
import UserNotifications

// MARK: - Insurance in the black look (his pick, 1 Nov: "kosh · Insurance (Obsidian)")
//
// Three screens. The home: a ring of what the premiums come to a year by kind, the cover it buys, what's due next, each
// kind as a tile, the kinds kosh found no policy of, whose name the policies are in, and every policy. Payments (from
// "Up next › Timeline"): what falls due in a range, month by month. A policy's page: its premiums paid and left, the next
// one, its life from start to maturity, what goes in and what comes back, the people on it, every premium, the fine print
// and the mails it came from. What the figures are is worked out once a build (InsuranceModel.swift, Store.insuranceHome);
// a figure kosh doesn't have leaves its row out, never ₹0 or a guess.

extension Store {
    /// the home's figures for whoever's money is showing, worked out again only when the policies or premiums change
    var insuranceHome: InsHome {
        let pols: [Policy] = policies
        let ahead: [PremAhead] = (snap.premAhead ?? []).filter { who.owns($0.owner) }
        var h: Hasher = Hasher()
        h.combine(who.id); h.combine(snap.today); h.combine(pols); h.combine(ahead)
        let key: Int = h.finalize()
        if let home = insMemo.home, insMemo.key == key { return home }
        let home: InsHome = InsHome.make(pols, ahead: ahead, today: snap.today)
        insMemo = (key, home)
        return home
    }
}

/// a kind's colour, its wash, and its drawing
enum InsLook {
    static func color(_ k: InsKind) -> Color {
        switch k {
        case .health: return Obsidian.health
        case .term: return Obsidian.term
        case .savings: return Obsidian.savings
        case .ulip: return Obsidian.ulip
        case .motor: return Obsidian.motor
        case .property: return Obsidian.property
        case .other: return Obsidian.ink2
        }
    }
    static func wash(_ k: InsKind) -> Color { color(k).opacity(0.14) }
    static func sym(_ k: InsKind) -> String {
        switch k {
        case .health: return "cross.case"
        case .term: return "umbrella"
        case .savings: return "leaf"
        case .ulip: return "chart.line.uptrend.xyaxis"
        case .motor: return "car"
        case .property: return "house"
        case .other: return "shield"
        }
    }
    /// the part of Insurance a kind's tile opens
    static func part(_ k: InsKind) -> String {
        switch k {
        case .health: return "Health"
        case .term, .savings, .ulip: return "Life"
        case .motor: return "Motor"
        default: return "Other"
        }
    }
    /// "₹3.04L" as "₹3.04" and "L", the unit drawn smaller
    static func split(_ s: String) -> (String, String) {
        if s.hasSuffix("CR") { return (String(s.dropLast(2)), "CR") }
        if s.hasSuffix("L") || s.hasSuffix("k") { return (String(s.dropLast()), String(s.suffix(1))) }
        return (s, "")
    }
    /// "in 5 days", "tomorrow", "today", "3 days late"
    static func when(_ d: Int) -> String {
        if d < 0 { return "\(-d) day" + (d == -1 ? "" : "s") + " late" }
        if d == 0 { return "today" }
        if d == 1 { return "tomorrow" }
        return "in \(d) days"
    }
    static func whenColor(_ d: Int) -> Color { d < 0 ? Color(hex: "#FF6B6B") : d <= 7 ? Obsidian.savings : Obsidian.ink3 }
    static func person(_ store: Store, _ id: String) -> String { Words.cap(InsBook.who(id, store.snap)) }
}

/// a figure with its lakh or crore drawn smaller, as the design writes ₹3.04 L
struct InsFigure: View {
    let text: String
    var size: CGFloat = 44
    var color: Color = Obsidian.ink
    var body: some View {
        let parts: (String, String) = InsLook.split(text)
        HStack(alignment: .firstTextBaseline, spacing: 2) {
            Text(parts.0).font(.system(size: size, weight: .semibold)).foregroundStyle(color)
            if !parts.1.isEmpty {
                Text(parts.1).font(.system(size: size * 0.5, weight: .medium)).foregroundStyle(Obsidian.ink2)
            }
        }
        .monospacedDigit()
        .tracking(-size * 0.03)
        .lineLimit(1).minimumScaleFactor(0.6)
        .privacySensitive()
    }
}

/// a section's heading in the black look, with its quiet word or link on the right
struct InsHead: View {
    let title: String
    var note: String = ""
    var link: String = ""
    var action: (() -> Void)? = nil
    var body: some View {
        HStack(alignment: .firstTextBaseline) {
            Text(title).font(.system(size: 20, weight: .semibold)).tracking(-0.3).foregroundStyle(Obsidian.ink).accessibilityAddTraits(.isHeader)
            Spacer(minLength: 8)
            if let action, !link.isEmpty {
                Button(action: action) {
                    HStack(spacing: 3) {
                        Text(link).font(.system(size: 13))
                        Image(systemName: "chevron.right").font(.system(size: 11, weight: .semibold))
                    }
                    .foregroundStyle(Obsidian.ink2)
                    .frame(minHeight: 44)
                    .contentShape(Rectangle())
                }
                .buttonStyle(.press)
            } else if !note.isEmpty {
                Text(note).caption()
            }
        }
    }
}

/// a ring of arcs: each a share of the whole, in its colour, a small gap between
struct InsRing: View {
    struct Arc: Identifiable { let id: Int; let from: Double; let to: Double; let color: Color }
    let arcs: [Arc]
    var width: CGFloat = 18
    var track: Color = Color(hex: "#141419")
    @State private var grown: Bool = false
    /// arcs from shares (0…1, adding up to 1), a gap of `gap` (a share) between them
    static func arcs(_ parts: [(Double, Color)], gap: Double) -> [Arc] {
        var out: [Arc] = []
        var at: Double = 0
        for (i, p) in parts.enumerated() {
            let end: Double = at + p.0
            let g: Double = parts.count > 1 ? min(gap, p.0 * 0.4) : 0
            out.append(Arc(id: i, from: at, to: max(at + 0.002, end - g), color: p.1))
            at = end
        }
        return out
    }
    var body: some View {
        ZStack {
            Circle().stroke(track, lineWidth: width)
            ForEach(arcs) { (a: Arc) in
                Circle()
                    .trim(from: CGFloat(a.from), to: CGFloat(grown ? a.to : a.from))
                    .stroke(a.color, style: StrokeStyle(lineWidth: width, lineCap: .butt))
                    .rotationEffect(.degrees(-90))
            }
        }
        .onAppear { withAnimation(Motion.reveal) { grown = true } }
        .accessibilityHidden(true)
    }
}

// MARK: The home

/// the Insurance home, for the tab and for the page pushed from Portfolio or Home
struct InsuranceHome: View {
    @Environment(Store.self) private var store
    var body: some View {
        let home: InsHome = store.insuranceHome
        let look: [LookItem] = InsBook.look(store)
        // (the tab line that sat at the top is gone, his ask: its cover gaps count under Needs a look)
        let looks: Int = look.count + InsBook.coverNotes(store).count
        VStack(alignment: .leading, spacing: 0) {
            if store.live != nil { Intro.insurance().padding(.bottom, 16) }
            Text("kosh · cover · as of " + Day.fmt(store.snap.today, "d MMM")).caption().padding(.bottom, 6)
            if home.n == 0 && look.isEmpty {
                InsEmpty()
            } else {
                if home.n > 0 {
                    InsPremiumRing(home: home).padding(.top, 20)
                    InsCoverStats(home: home).padding(.top, 8)
                }
                if !home.next.isEmpty { InsUpNext(dues: home.next).padding(.top, 36) }
                if !home.parts.isEmpty { InsKindGrid(parts: home.parts).padding(.top, 40) }
                if home.n > 0 && !home.gaps.isEmpty { InsGaps(gaps: home.gaps).padding(.top, 36) }
                if home.whose.count > 1 || (home.whose.count == 1 && store.who == .family && home.whose[0].id != "me") {
                    InsWhoseRow(whose: home.whose).padding(.top, 40)
                }
                if !home.rows.isEmpty { InsAllPolicies(rows: home.rows).padding(.top, 40) }
                if looks > 0 { InsLookLink(n: looks).padding(.top, 24) }
                PolicyArchive(pols: store.endedPolicies).padding(.top, 24)
            }
        }
    }
}

/// nothing yet: what brings policies here, and the way to add one
struct InsEmpty: View {
    @Environment(Store.self) private var store
    var body: some View {
        VStack(alignment: .leading, spacing: 18) {
            if store.live != nil { MailFirstCard(found: 0) }
            PolicyArchive(pols: store.endedPolicies)
            BetaEmpty(sym: "shield.lefthalf.filled", title: "No policies yet",
                      text: "Every policy kosh knows about comes from your mail: the schedule the insurer sent, premium receipts and renewal notices. Read your mail once, or add one by hand.",
                      add: "Add a policy") { store.betaSheet = .policy(nil) }
        }
        .padding(.top, 16)
    }
}

/// the ring: premiums a year by kind, biggest first, the sum in its middle
struct InsPremiumRing: View {
    @Environment(Store.self) private var store
    let home: InsHome
    var body: some View {
        let parts: [InsKindPart] = home.parts.filter { $0.yearly > 0 }
        let people: String = home.people == 1 ? "1 person" : "\(home.people) people"
        let pols: String = home.n == 1 ? "1 policy" : "\(home.n) policies"
        let shares: [(Double, Color)] = parts.map { (p: InsKindPart) -> (Double, Color) in (p.share, InsLook.color(p.kind)) }
        let arcs: [InsRing.Arc] = InsRing.arcs(shares, gap: 0.008)
        let kinds: String = parts.map { (p: InsKindPart) -> String in p.kind.title + " " + Fmt.pct(p.share) }.joined(separator: ", ")
        let said: String = "Premiums a year " + Fmt.words(home.yearly) + ", " + pols + ", " + people + ". " + kinds
        ZStack {
            RadialGradient(colors: [Obsidian.savings.opacity(0.22), Obsidian.ulip.opacity(0.08), Color.clear], center: .center, startRadius: 0, endRadius: 170)
                .frame(width: 340, height: 300)
                .accessibilityHidden(true)
            Circle().stroke(Color.white.opacity(0.06), style: StrokeStyle(lineWidth: 1, dash: [1, 5])).frame(width: 244, height: 244).accessibilityHidden(true)
            InsRing(arcs: arcs, width: 18).frame(width: 208, height: 208)
            VStack(spacing: 6) {
                Text("Premiums a year").caption()
                if home.yearly > 0 { InsFigure(text: Fmt.words(home.yearly), size: 44) } else { Text("Not known yet").font(.system(size: 17, weight: .medium)).foregroundStyle(Obsidian.ink2) }
                Text(pols + " · " + people).font(.system(size: 12.5)).foregroundStyle(Obsidian.ink2)
            }
            .frame(width: 170)
        }
        .frame(maxWidth: .infinity)
        .frame(height: 268)
        .accessibilityElement(children: .ignore)
        .spokenFigures(said, hidden: pols + ", " + people)
    }
}

/// life cover, health cover and what's insured of things, each only when kosh knows it
struct InsCoverStats: View {
    let home: InsHome
    var body: some View {
        let stats: [(Double, String)] = [(home.life, "life cover"), (home.health, "health cover"), (home.assets, "things insured")].filter { $0.0 > 0 }
        if !stats.isEmpty {
            HStack(spacing: 0) {
                ForEach(Array(stats.enumerated()), id: \.offset) { pair in
                    InsStat(value: pair.element.0, label: pair.element.1, first: pair.offset == 0)
                }
            }
            .overlay(alignment: .top) { Rectangle().fill(Color.white.opacity(0.08)).frame(height: 1) }
            .overlay(alignment: .bottom) { Rectangle().fill(Color.white.opacity(0.08)).frame(height: 1) }
        }
    }
}

struct InsStat: View {
    let value: Double
    let label: String
    let first: Bool
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(Fmt.words(value)).font(.system(size: 19, weight: .semibold)).monospacedDigit().foregroundStyle(Obsidian.ink).lineLimit(1).minimumScaleFactor(0.7).privacySensitive()
            Text(label).font(.system(size: 12)).foregroundStyle(Obsidian.ink3)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.vertical, 16)
        .padding(.leading, first ? 2 : 14)
        .overlay(alignment: .leading) { if !first { Rectangle().fill(Color.white.opacity(0.08)).frame(width: 1) } }
        .accessibilityElement(children: .combine)
    }
}

/// what's due next, one card each, and the way to the timeline
struct InsUpNext: View {
    @Environment(Store.self) private var store
    let dues: [InsDue]
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            InsHead(title: "Up next", link: "Timeline") { store.push(.cover("Payments")) }
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 10) {
                    ForEach(Array(dues.prefix(8))) { (d: InsDue) in
                        Button { store.push(.policy(d.a.policy)) } label: { InsDueCard(d: d) }.buttonStyle(.press)
                    }
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 4)
            }
            .padding(.horizontal, -20)
            .scrollClipDisabled()
        }
    }
}

struct InsDueCard: View {
    @Environment(Store.self) private var store
    let d: InsDue
    var body: some View {
        let p: Policy? = InsBook.policy(store, d.a.policy)
        let name: String = p.map { InsBook.name($0) } ?? (d.a.name.isEmpty ? d.a.insurer : d.a.name)
        let sub: String = [InsLook.person(store, d.a.owner), d.every].filter { !$0.isEmpty }.joined(separator: " · ")
        let tint: Color = InsLook.color(d.kind)
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                Text(InsLook.when(d.days)).caption(d.days < 0 ? InsLook.whenColor(d.days) : tint)
                Spacer(minLength: 4)
                Text(Day.fmt(d.a.date, "d MMM")).font(.system(size: 11, design: .monospaced)).foregroundStyle(Obsidian.ink3)
            }
            VStack(alignment: .leading, spacing: 4) {
                Text(name).font(.system(size: 14.5, weight: .medium)).foregroundStyle(Obsidian.ink).lineLimit(2).multilineTextAlignment(.leading)
                Text(sub).font(.system(size: 12)).foregroundStyle(Obsidian.ink3).lineLimit(1)
            }
            Spacer(minLength: 0)
            HStack(alignment: .firstTextBaseline) {
                if d.known {
                    Text(Fmt.rupees(d.a.amt)).font(.system(size: 22, weight: .semibold)).monospacedDigit().tracking(-0.4).foregroundStyle(Obsidian.ink).lineLimit(1).minimumScaleFactor(0.7).privacySensitive()
                } else {
                    Text(d.a.noAmt == "locked" ? "Paper locked" : "Premium not known").font(.system(size: 13)).foregroundStyle(Obsidian.ink3)
                }
                Spacer(minLength: 0)
                if d.auto { InsAutoTag() }
            }
        }
        .frame(width: 136, height: 150, alignment: .topLeading)
        .padding(16)
        .background {
            ZStack(alignment: .topTrailing) {
                Obsidian.card
                RadialGradient(colors: [tint.opacity(ObsidianAura.card), Color.clear], center: .center, startRadius: 0, endRadius: 65)
                    .frame(width: 130, height: 130).offset(x: 50, y: -50)
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous).strokeBorder(Obsidian.cardBorder, lineWidth: 1))
        .accessibilityElement(children: .combine)
    }
}

/// "AUTOPAY": the last premium went by auto-debit
struct InsAutoTag: View {
    var body: some View {
        Text("Autopay").font(.system(size: 10, design: .monospaced)).textCase(.uppercase)
            .foregroundStyle(Obsidian.ink2)
            .padding(.horizontal, 6).padding(.vertical, 2)
            .background(Color(hex: "#1B1B22"), in: RoundedRectangle(cornerRadius: 6, style: .continuous))
            .accessibilityLabel("Paid by auto-debit last time")
    }
}

/// each kind as a tile: its share of the premiums, its headline, its policies and what they cost a year
struct InsKindGrid: View {
    let parts: [InsKindPart]
    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            InsHead(title: "By kind", note: "share of premium")
            LazyVGrid(columns: [GridItem(.flexible(), spacing: 12), GridItem(.flexible(), spacing: 12)], spacing: 12) {
                ForEach(parts) { (k: InsKindPart) in InsKindTile(k: k) }
            }
        }
    }
}

struct InsKindTile: View {
    @Environment(Store.self) private var store
    let k: InsKindPart
    static func figLabel(_ k: InsKindPart) -> String {
        switch k.figIs {
        case "sum": return k.members > 1 ? "floater cover" : "sum insured"
        case "maturity": return "back at maturity"
        case "fund": return "fund value" + (k.figOn.isEmpty ? "" : " · " + Day.fmt(k.figOn, "d MMM"))
        case "idv": return "insured value (IDV)"
        case "property": return "property insured"
        default: return k.kind.life ? "life cover" : "cover"
        }
    }
    var body: some View {
        let tint: Color = InsLook.color(k.kind)
        let count: String = k.members > 1 ? "Floater · \(k.members)" : k.n == 1 ? "1 policy" : "\(k.n) policies"
        Button { store.push(.cover(InsLook.part(k.kind) == "Life" ? "Life:" + k.kind.rawValue : InsLook.part(k.kind))) } label: {
            VStack(alignment: .leading, spacing: 0) {
                HStack(alignment: .top) {
                    Image(systemName: InsLook.sym(k.kind)).font(.system(size: 18, weight: .medium)).foregroundStyle(tint)
                        .frame(width: 40, height: 40).background(InsLook.wash(k.kind), in: RoundedRectangle(cornerRadius: 13, style: .continuous))
                    Spacer(minLength: 4)
                    if k.yearly > 0 { Text(Fmt.pct(k.share)).font(.system(size: 12, design: .monospaced)).monospacedDigit().foregroundStyle(tint) }
                }
                Spacer(minLength: 22)
                Text(k.kind.title).font(.system(size: 13)).foregroundStyle(Obsidian.ink2)
                if let f = k.fig {
                    Text(Fmt.words(f)).font(.system(size: 25, weight: .semibold)).monospacedDigit().tracking(-0.7).foregroundStyle(Obsidian.ink)
                        .lineLimit(1).minimumScaleFactor(0.6).padding(.top, 6).privacySensitive()
                    Text(Self.figLabel(k)).font(.system(size: 11.5)).foregroundStyle(Obsidian.ink3).padding(.top, 5).lineLimit(1)
                } else {
                    Text("Cover not read yet").font(.system(size: 13)).foregroundStyle(Obsidian.ink3).padding(.top, 6)
                }
                HStack {
                    Text(count)
                    Spacer(minLength: 4)
                    if k.yearly > 0 { Text(Fmt.short(k.yearly) + "/yr").monospacedDigit().privacySensitive() }
                }
                .font(.system(size: 11, design: .monospaced)).foregroundStyle(Obsidian.ink2)
                .padding(.top, 12)
                .overlay(alignment: .top) { Rectangle().fill(Obsidian.cardBorder).frame(height: 1) }
                .padding(.top, 12)
            }
            .frame(maxWidth: .infinity, minHeight: 180, alignment: .topLeading)
            .padding(16)
            .background {
                ZStack(alignment: .bottomTrailing) {
                    Obsidian.card
                    RadialGradient(colors: [InsLook.color(k.kind).opacity(0.26), Color.clear], center: .center, startRadius: 0, endRadius: 85)
                        .frame(width: 170, height: 170).offset(x: 50, y: 70)
                }
            }
            .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 24, style: .continuous).strokeBorder(Obsidian.cardBorder, lineWidth: 1))
        }
        .buttonStyle(.press)
        .accessibilityElement(children: .combine)
    }
}

/// the kinds of cover with no policy in the mail, each a way to add one
struct InsGaps: View {
    @Environment(Store.self) private var store
    let gaps: [String]
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            Text("No cover found yet").font(.system(size: 16, weight: .semibold)).foregroundStyle(Obsidian.ink).accessibilityAddTraits(.isHeader)
            Text("kosh found no policy of these kinds in your mail. The day one lands, it files itself here.")
                .font(.system(size: 13)).foregroundStyle(Obsidian.ink3).fixedSize(horizontal: false, vertical: true)
                .padding(.top, 4).padding(.bottom, 14)
            InsChips(items: gaps.map { $0 == "Term" ? "Term life" : PolicyKinds.title($0) }) { _ in if store.live != nil { store.betaSheet = .policy(nil) } }
        }
    }
}

/// chips that wrap to the next line
struct InsChips: View {
    let items: [String]
    let tap: (String) -> Void
    var body: some View {
        ViewThatFits(in: .horizontal) {
            HStack(spacing: 8) { ForEach(items, id: \.self) { chip($0) } }
            VStack(alignment: .leading, spacing: 8) {
                ForEach(Array(stride(from: 0, to: items.count, by: 3)), id: \.self) { (i: Int) in
                    HStack(spacing: 8) { ForEach(Array(items[i..<min(i + 3, items.count)]), id: \.self) { chip($0) } }
                }
            }
        }
    }
    func chip(_ s: String) -> some View {
        Button { tap(s) } label: {
            HStack(spacing: 6) {
                Image(systemName: "plus").font(.system(size: 11, weight: .semibold))
                Text(s).font(.system(size: 13))
            }
            .foregroundStyle(Obsidian.ink2)
            .padding(.horizontal, 14).frame(minHeight: 40)
            .overlay(Capsule().strokeBorder(Color.white.opacity(0.18), style: StrokeStyle(lineWidth: 1, dash: [3, 3])))
            .contentShape(Capsule())
        }
        .buttonStyle(.press)
        .accessibilityLabel("Add a " + s.lowercased() + " policy")
    }
}

/// whose name the policies are in: a circle each, how many and what they cost a year
struct InsWhoseRow: View {
    @Environment(Store.self) private var store
    let whose: [InsWhose]
    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            InsHead(title: "Whose name")
            LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 10), count: min(3, max(1, whose.count))), spacing: 10) {
                ForEach(whose) { (w: InsWhose) in InsPersonTile(w: w) }
            }
        }
    }
}

struct InsPersonTile: View {
    @Environment(Store.self) private var store
    let w: InsWhose
    var body: some View {
        let name: String = InsLook.person(store, w.id)
        VStack(spacing: 0) {
            Text(String(name.prefix(1))).font(.system(size: 15, weight: .semibold)).foregroundStyle(Obsidian.ink)
                .frame(width: 48, height: 48)
                .background(Color(hex: "#1B1B22"), in: Circle())
                .overlay(Circle().strokeBorder(Color.white.opacity(0.12), lineWidth: 1))
            Text(name).font(.system(size: 14, weight: .medium)).foregroundStyle(Obsidian.ink).lineLimit(1).padding(.top, 10)
            Text(w.n == 1 ? "1 policy" : "\(w.n) policies").font(.system(size: 12)).foregroundStyle(Obsidian.ink3).padding(.top, 3)
            if w.yearly > 0 {
                Text(Fmt.short(w.yearly) + "/yr").font(.system(size: 12, design: .monospaced)).monospacedDigit().foregroundStyle(Obsidian.ink2).padding(.top, 10).privacySensitive()
            }
        }
        .frame(maxWidth: .infinity)
        .obsidianCard(22, padding: 14)
        .accessibilityElement(children: .combine)
    }
}

/// every running policy: its kind's colour, name, insurer and whose, its premium and when it's next due
struct InsAllPolicies: View {
    @Environment(Store.self) private var store
    let rows: [Policy]
    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            InsHead(title: "All policies", note: "next due")
            VStack(spacing: 0) {
                ForEach(Array(rows.enumerated()), id: \.element.id) { pair in
                    Button { store.push(.policy(pair.element.id)) } label: { InsPolicyLine(p: pair.element) }
                        .buttonStyle(.press)
                        .overlay(alignment: .top) { if pair.offset > 0 { Rectangle().fill(Color.white.opacity(0.06)).frame(height: 1) } }
                }
            }
            .background(Obsidian.card, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 24, style: .continuous).strokeBorder(Obsidian.cardBorder, lineWidth: 1))
        }
    }
}

struct InsPolicyLine: View {
    @Environment(Store.self) private var store
    let p: Policy
    var body: some View {
        let k: InsKind = InsKind.of(p)
        let every: String = InsHome.freq(p)
        let due: String = p.nextDue.isEmpty ? (PolicyStatus.chip(p)?.0 ?? "") : Day.fmt(p.nextDue, "d MMM") + (every.isEmpty || every == "renewal" ? "" : " · " + every)
        let late: Bool = !p.nextDue.isEmpty && p.nextDue < store.snap.today
        HStack(spacing: 12) {
            Image(systemName: InsLook.sym(k)).font(.system(size: 16, weight: .medium)).foregroundStyle(InsLook.color(k))
                .frame(width: 36, height: 36).background(InsLook.wash(k), in: RoundedRectangle(cornerRadius: 11, style: .continuous))
            VStack(alignment: .leading, spacing: 3) {
                Text(InsBook.name(p)).font(.system(size: 14.5, weight: .medium)).foregroundStyle(Obsidian.ink).lineLimit(1)
                Text(p.insurer + " · " + InsLook.person(store, p.owner)).font(.system(size: 12)).foregroundStyle(Obsidian.ink3).lineLimit(1)
            }
            Spacer(minLength: 8)
            VStack(alignment: .trailing, spacing: 3) {
                if p.premium > 0 {
                    Text(Fmt.rupees(p.premium)).font(.system(size: 14, weight: .medium)).monospacedDigit().foregroundStyle(Obsidian.ink).privacySensitive()
                } else {
                    Text(InsBook.locked(p) ? "Paper locked" : "Premium not known").font(.system(size: 12)).foregroundStyle(Obsidian.ink3)
                }
                if !due.isEmpty { Text(due).font(.system(size: 11, design: .monospaced)).foregroundStyle(late ? Color(hex: "#FF6B6B") : Obsidian.ink3) }
            }
        }
        .padding(.horizontal, 16).padding(.vertical, 14)
        .contentShape(Rectangle())
        .accessibilityElement(children: .combine)
    }
}

/// what kosh found but can't fill in, a tap away
struct InsLookLink: View {
    @Environment(Store.self) private var store
    let n: Int
    var body: some View {
        Button { store.push(.cover("Look")) } label: {
            HStack(spacing: 12) {
                Image(systemName: "exclamationmark.magnifyingglass").font(.system(size: 15, weight: .semibold)).foregroundStyle(Obsidian.savings)
                    .frame(width: 32, height: 32).background(Obsidian.savings.opacity(0.13), in: Circle())
                VStack(alignment: .leading, spacing: 2) {
                    Text(n == 1 ? "One thing needs a look" : Words.cap(Words.number(n)) + " things need a look").font(.system(size: 14.5, weight: .medium)).foregroundStyle(Obsidian.ink)
                    Text("What kosh found but can’t fill in, and the one thing that would.").font(.system(size: 12)).foregroundStyle(Obsidian.ink3).fixedSize(horizontal: false, vertical: true)
                }
                Spacer(minLength: 4)
                Image(systemName: "chevron.right").font(.system(size: 12, weight: .semibold)).foregroundStyle(Obsidian.ink3)
            }
            .obsidianCard(20, padding: 14)
        }
        .buttonStyle(.press)
    }
}
