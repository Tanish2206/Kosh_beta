import Foundation

/// What kosh knows about each payment (engine/21o-build-payfacts.js, `snap.payFacts`): where it was made, what it bought,
/// and how often. Every fact is what the payment's own mails printed (or its shop's order mail, named in `src`), never a
/// guess; a fact kosh is less sure of is named in `cf`. Screen-free: the screens and Ask kosh read it through `Store`.
struct PayFacts: Decodable, Hashable {
    /// one line of an order or invoice, as printed: the item, how many, the line's figure, or each one's price
    struct Item: Decodable, Hashable {
        let n: String
        var q: Int? = nil
        var amt: Double? = nil
        var unit: Double? = nil
        /// the order it was in, the day a shop said it went back, and what its mail said came back
        var o: String? = nil
        var ret: String? = nil
        var back: Double? = nil
    }
    /// one payment's facts (by the payment's id in `pay`)
    struct Fact: Decodable, Hashable {
        /// the shop's key in `shops`, and the shop as a person says it (a card's city and country taken off)
        var sh: String? = nil
        var at: String? = nil
        /// the restaurant a food delivery app's order came from
        var outlet: String? = nil
        /// online · shop
        var on: String? = nil
        /// the city a card's charge printed after the shop's name (never for a payment made online)
        var city: String? = nil
        /// upi · card · wallet · netbanking · transfer · auto · atm · cash
        var ch: String? = nil
        /// credit · debit
        var card: String? = nil
        var emi: Bool? = nil
        var auto: Bool? = nil
        /// the app it went through (CRED, a gateway)
        var via: String? = nil
        var items: [Item]? = nil
        /// its shop's rhythm (a key in `rhythms`)
        var rh: String? = nil
        /// the mail a fact came from when it isn't the payment's own: fact name → mail id
        var src: [String: String]? = nil
        /// a fact kosh is less sure of: fact name → "medium"
        var cf: [String: String]? = nil
    }
    /// a shop, one however the bank, the UPI ID and the receipt name it
    struct Shop: Decodable, Hashable, Identifiable {
        let id: String
        let name: String
        let n: Int
        let total: Double
        let first: String
        let last: String
        var brand: String? = nil
        var kind: String? = nil
        var cat: String? = nil
        /// how many of its payments were online, and how many in the shop
        var online: Int? = nil
        var inShop: Int? = nil
        var cities: [String]? = nil
        /// its payments by the way paid
        var ch: [String: Int]? = nil
        var rh: String? = nil
    }
    /// how often a shop is paid or an item bought: from its repeat (by "repeat", ref its id) or from its visits
    struct Rhythm: Decodable, Hashable, Identifiable {
        let id: String
        /// shop · item
        let of: String
        let name: String
        /// twice a week · week · fortnight · month · two months · quarter · half year · year · days
        let every: String
        let days: Int
        let n: Int
        var sh: String? = nil
        var usual: Double? = nil
        var lo: Double? = nil
        var hi: Double? = nil
        var first: String? = nil
        let last: String
        /// the next day it's due on its beat; none when it has gone quiet
        var next: String? = nil
        var quiet: Bool? = nil
        let by: String
        var ref: String? = nil
        /// high · medium
        let conf: String
        let ids: [String]
    }
    /// how many payments carry each fact
    struct Cover: Decodable, Hashable {
        let pay: Int
        let at: Int
        let brand: Int
        let kind: Int
        let on: Int
        let city: Int
        let ch: Int
        let items: Int
        let rh: Int
    }
    let v: Int
    let pay: [String: Fact]
    let shops: [Shop]
    let rhythms: [Rhythm]
    let cover: Cover

    func shop(_ key: String?) -> Shop? { key.flatMap { k in shops.first { $0.id == k } } }
    func rhythm(_ key: String?) -> Rhythm? { key.flatMap { k in rhythms.first { $0.id == k } } }
    /// the items bought on a beat (milk every week), most often first
    var itemRhythms: [Rhythm] { rhythms.filter { $0.of == "item" && $0.quiet != true } }

    /// "Every week", "About every 10 days": a rhythm in words
    static func everyWords(_ r: Rhythm) -> String {
        switch r.every {
        case "twice a week": return "Twice a week"
        case "week": return "Every week"
        case "fortnight": return "Every two weeks"
        case "month": return "Every month"
        case "two months": return "Every two months"
        case "quarter": return "Every three months"
        case "half year": return "Every six months"
        case "year": return "Every year"
        default: return "About every \(r.days) days"
        }
    }
    /// "UPI", "Credit card", "Net banking": the way paid in words, with EMI and autopay said
    static func wayWords(_ f: Fact) -> String? {
        var w: String
        switch f.ch {
        case "upi": w = f.card == "credit" ? "UPI on a credit card" : "UPI"
        case "card": w = f.card == "debit" ? "Debit card" : f.card == "credit" ? "Credit card" : "Card"
        case "wallet": w = "Wallet"
        case "netbanking": w = "Net banking"
        case "transfer": w = "Bank transfer"
        case "auto": w = "Autopay"
        case "atm": w = "ATM"
        case "cash": w = "Cash"
        default: return nil
        }
        if f.emi == true { w += ", on EMI" }
        if f.auto == true && f.ch != "auto" { w += ", autopay" }
        return w
    }
}
