import SwiftUI
import UserNotifications

// MARK: - One policy, opened (Route.policy), in the black look
//
// Its kind and name; its premiums paid and left on a ring (a life policy whose schedule is known); the next premium and
// a reminder for it; its life from start to maturity; what goes in and what comes back (with the same premiums in an FD
// at a stated rate, beside it, where the build worked one out); the people on it; every premium by year; the fine print;
// and the mails and papers it was read from. Each part only when kosh knows what it says (InsPolicyPage,
// InsuranceModel.swift). What you can say about it (where it stands, what's missing, not mine) is a tap away, on the
// policy's details (PolicyDetail, the page it had before).

struct InsPolicyScreen: View {
    @Environment(Store.self) private var store
    let id: String
    @State private var details: Bool = false
    var body: some View {
        if let p = store.snap.policies.first(where: { $0.id == id }) {
            let page: InsPolicyPage = InsPolicyPage.make(p, today: store.snap.today)
            let tint: Color = InsLook.color(page.kind)
            ScrollView {
                VStack(alignment: .leading, spacing: 0) {
                    InsPolicyTitle(p: p, kind: page.kind)
                    if !page.ring.isEmpty { InsPolicyRing(page: page).padding(.top, 26) } else { InsPolicyCoverHero(p: p).padding(.top, 22) }
                    if InsBook.locked(p) { LockedPaperNote(p: p).obsidianCard(20, padding: 14).padding(.top, 20) }
                    if page.nextDays != nil { InsNextPremium(p: p, page: page).padding(.top, 26) }
                    if !page.lifeFrom.isEmpty { InsPolicyLife(p: p, page: page).padding(.top, 36) }
                    if page.putIn != nil || page.back != nil || p.xirr != nil || (p.fundValue ?? 0) > 0 { InsInAndBack(p: p, page: page).padding(.top, 36) }
                    InsPeopleOn(p: p, ask: { details = true }).padding(.top, 36)
                    if !page.years.isEmpty { InsEveryPremium(p: p, page: page).padding(.top, 36) }
                    InsFinePrint(p: p).padding(.top, 36)
                    if !(p.claims ?? []).isEmpty { InsClaims(p: p).padding(.top, 36) }
                    if !(p.mails ?? []).isEmpty { InsFoundIn(p: p).padding(.top, 36) }
                    Button { details = true } label: {
                        HStack {
                            Text("Where it stands, what’s missing, and corrections").font(.system(size: 14, weight: .medium)).foregroundStyle(Obsidian.ink)
                            Spacer(minLength: 8)
                            Image(systemName: "chevron.right").font(.system(size: 12, weight: .semibold)).foregroundStyle(Obsidian.ink3)
                        }
                        .obsidianCard(20, padding: 16)
                    }
                    .buttonStyle(.press)
                    .padding(.top, 36)
                }
                .padding(.horizontal, 20)
                .padding(.top, 8)
                .padding(.bottom, 40)
            }
            .navigationTitle("")
            .navigationBarTitleDisplayMode(.inline)
            .obsidianPage(aura: tint)
            .sheet(isPresented: $details) {
                NavigationStack {
                    PolicyDetail(id: p.id)
                        .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { details = false } } }
                        .obsidianPage()
                }
                .obsidianSheet()
            }
        } else {
            ContentUnavailableView("No such policy", systemImage: "shield").obsidianPage()
        }
    }
}

/// the kind as a tag, the policy's name, its number and when it was bought
struct InsPolicyTitle: View {
    let p: Policy
    let kind: InsKind
    static func bits(_ p: Policy) -> [String] {
        let no: String = p.policyNo ?? ""
        let start: String = p.start ?? ""
        var bits: [String] = [p.insurer]
        if no.count > 4 { bits.append("Policy ••" + String(no.suffix(4))) } else if !no.isEmpty { bits.append("Policy " + no) }
        if !start.isEmpty { bits.append("bought " + Day.fmt(start, "d MMM yyyy")) }
        return bits
    }
    var body: some View {
        let tint: Color = InsLook.color(kind)
        let k: String = PolicyKinds.title(PolicyKinds.of(p)) + ((p.linked ?? false) && kind != .ulip ? " · unit-linked" : "")
        let bits: [String] = Self.bits(p)
        VStack(alignment: .leading, spacing: 0) {
            HStack(spacing: 6) {
                Image(systemName: InsLook.sym(kind)).font(.system(size: 11, weight: .semibold))
                Text(k).font(.system(size: 11, design: .monospaced)).textCase(.uppercase).tracking(0.7)
            }
            .foregroundStyle(tint)
            .padding(.horizontal, 10).padding(.vertical, 5)
            .background(tint.opacity(0.12), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
            Text(InsBook.name(p)).font(.system(size: 32, weight: .semibold)).tracking(-1).foregroundStyle(Obsidian.ink)
                .fixedSize(horizontal: false, vertical: true).padding(.top, 14)
            Text(bits.joined(separator: " · ")).font(.system(size: 12, design: .monospaced)).foregroundStyle(Obsidian.ink3).padding(.top, 10)
        }
    }
}

/// a policy with no schedule to draw (cover bought a year at a time, or one whose terms aren't known): what it covers
struct InsPolicyCoverHero: View {
    @Environment(Store.self) private var store
    let p: Policy
    var body: some View {
        let part: String = PolicyKinds.part(p)
        let word: String = part == "Health" ? "sum insured" : part == "Motor" ? "insured value (IDV)" : part == "Life" ? "life cover" : "cover"
        VStack(alignment: .leading, spacing: 6) {
            if let c = p.cover, c > 0 {
                InsFigure(text: Fmt.words(c), size: 52)
                Text(word + (part == "Health" ? " · " + InsBook.covers(p, store.snap) : "")).font(.system(size: 13)).foregroundStyle(Obsidian.ink2)
            } else {
                Text(Words.cap(InsBook.unknown(p, "Cover", word))).font(.system(size: 15, weight: .medium)).foregroundStyle(Obsidian.ink2)
            }
            if p.yearly > 0 {
                Text(Fmt.rupees(p.yearly) + " a year").font(.system(size: 12, design: .monospaced)).monospacedDigit().foregroundStyle(Obsidian.ink3).privacySensitive()
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

/// the premiums: one arc each (or each year of them), paid in the kind's colour, the next one faint, the rest dark
struct InsPolicyRing: View {
    let page: InsPolicyPage
    var body: some View {
        let tint: Color = InsLook.color(page.kind)
        let n: Double = Double(max(1, page.ring.count))
        let parts: [(Double, Color)] = page.ring.map { (s: InsStep) -> (Double, Color) in
            (1 / n, s == .paid ? tint : s == .next ? tint.opacity(0.38) : Color(hex: "#1B1B22"))
        }
        let last: String = (page.p.payEnd ?? "").isEmpty ? "" : " · last one in " + Day.fmt(page.p.payEnd ?? "", "MMMM yyyy")
        VStack(spacing: 14) {
            ZStack {
                InsRing(arcs: InsRing.arcs(parts, gap: min(0.02, 0.3 / n)), width: 14, track: Color.clear).frame(width: 192, height: 192)
                VStack(spacing: 0) {
                    if page.left > 0 {
                        Text("\(page.left)").font(.system(size: 64, weight: .semibold)).monospacedDigit().tracking(-3).foregroundStyle(Obsidian.ink)
                        Text(page.left == 1 ? "premium left" : "premiums left").font(.system(size: 13)).foregroundStyle(Obsidian.ink2).padding(.top, 4)
                        Text(Fmt.rupees(page.toGo) + " to go").font(.system(size: 11.5, design: .monospaced)).monospacedDigit().foregroundStyle(tint).padding(.top, 6).privacySensitive()
                    } else {
                        Text("Paid up").font(.system(size: 30, weight: .semibold)).foregroundStyle(Obsidian.ink)
                        Text("nothing more to pay").font(.system(size: 13)).foregroundStyle(Obsidian.ink2).padding(.top, 4)
                    }
                }
            }
            .frame(width: 236, height: 236)
            Text("\(page.paid) of \(page.total) paid" + last).font(.system(size: 12.5)).foregroundStyle(Obsidian.ink3)
        }
        .frame(maxWidth: .infinity)
        .accessibilityElement(children: .combine)
    }
}

/// the next premium: how much, when, which one it is, the days to it, and a reminder
struct InsNextPremium: View {
    @Environment(Store.self) private var store
    let p: Policy
    let page: InsPolicyPage
    @State private var reminded: Bool = false
    @State private var refused: Bool = false
    var body: some View {
        let tint: Color = InsLook.color(page.kind)
        let d: Int = page.nextDays ?? 0
        let every: String = InsHome.freq(p)
        let which: String = page.nextIndex > 0 ? " · premium \(page.nextIndex) of \(page.total)" : (every.isEmpty ? "" : " · " + every)
        let setFor: String = Day.fmt(PremiumReminder.day(p.nextDue, today: store.snap.today), "d MMM")
        let word: String = reminded ? "Reminder set for " + setFor : (refused ? "Notifications are off for kosh" : "Remind me")
        let quietButton: Bool = reminded || refused
        let rid: String = PremiumReminder.id(p.id, p.nextDue)
        let count: Color = d < 0 ? Color(hex: "#FF6B6B") : d <= 7 ? Obsidian.savings : tint
        VStack(alignment: .leading, spacing: 16) {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 0) {
                    Text(d < 0 ? "Premium past due" : "Next premium").caption()
                    if p.premium > 0 {
                        Text(Fmt.rupees(p.premium)).font(.system(size: 30, weight: .semibold)).monospacedDigit().tracking(-0.9).foregroundStyle(Obsidian.ink).padding(.top, 8).privacySensitive()
                    } else {
                        Text(InsBook.locked(p) ? "In its locked paper" : "Not in its mail yet").font(.system(size: 17, weight: .medium)).foregroundStyle(Obsidian.ink2).padding(.top, 8)
                    }
                    Text(Day.fmt(p.nextDue, "d MMMM yyyy") + which).font(.system(size: 13)).foregroundStyle(Obsidian.ink2).padding(.top, 4)
                    if p.auto == true, let f = p.payFrom {
                        HStack(spacing: 6) {
                            InsAutoTag()
                            Text("last from " + f.bk + ((f.l4 ?? "").isEmpty ? "" : " ••" + (f.l4 ?? ""))).font(.system(size: 12)).foregroundStyle(Obsidian.ink3)
                        }
                        .padding(.top, 8)
                    }
                }
                Spacer(minLength: 8)
                VStack(spacing: 4) {
                    Text("\(abs(d))").font(.system(size: 24, weight: .semibold)).monospacedDigit().foregroundStyle(count)
                    Text(d < 0 ? "DAYS LATE" : d == 1 ? "DAY" : "DAYS").font(.system(size: 10, design: .monospaced)).foregroundStyle(count)
                }
                .padding(.horizontal, 12).padding(.vertical, 10)
                .background(tint.opacity(0.10), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                .accessibilityElement(children: .combine)
            }
            // (no insurer's pay link is known to kosh, so there is no "Pay early"; a reminder rings on this phone)
            if d >= 1 {
                Button {
                    Task {
                        let ok: Bool = await PremiumReminder.set(p, name: InsBook.name(p), quiet: Reminders.quiet(store))
                        reminded = ok; refused = !ok
                    }
                } label: {
                    Text(word)
                        .font(.system(size: 14, weight: quietButton ? .medium : .semibold))
                        .foregroundStyle(quietButton ? Obsidian.ink : Color.black)
                        .frame(maxWidth: .infinity, minHeight: 46)
                        .background(quietButton ? Color.clear : Obsidian.ink, in: Capsule())
                        .overlay(Capsule().strokeBorder(Color.white.opacity(quietButton ? 0.12 : 0), lineWidth: 1))
                        .contentShape(Capsule())
                }
                .buttonStyle(.press)
                .disabled(reminded)
                .task { reminded = await PremiumReminder.isSet(rid) }
            }
        }
        .padding(18)
        .background(Obsidian.card, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 24, style: .continuous).strokeBorder(tint.opacity(0.22), lineWidth: 1))
    }
}

/// a premium's reminder on this phone: the morning before it's due (or the morning of, when that's already gone).
/// Its own name ("prem|…"), so the reminders kosh makes again after every build leave it be (Reminders.ownedElsewhere)
enum PremiumReminder {
    static func id(_ policy: String, _ due: String) -> String { "prem|" + policy + "|" + due }
    static func day(_ due: String, today: String) -> String {
        let eve: String = Day.add(due, -1)
        return eve > today ? eve : due
    }
    static func isSet(_ id: String) async -> Bool {
        let pending: [UNNotificationRequest] = await UNUserNotificationCenter.current().pendingNotificationRequests()
        return pending.contains { $0.identifier == id }
    }
    /// asks the phone once (Reminders.enable); false when notifications are refused
    @MainActor static func set(_ p: Policy, name: String, quiet: Bool) async -> Bool {
        guard await Reminders.enable() else { return false }
        let today: String = Day.iso(Date())
        let on: String = day(p.nextDue, today: today)
        guard on >= today, let d = Day.parser.date(from: on) else { return false }
        var comps: DateComponents = Day.cal.dateComponents([.year, .month, .day], from: d)
        comps.hour = 9; comps.minute = 0
        let c: UNMutableNotificationContent = UNMutableNotificationContent()
        let when: String = on == p.nextDue ? "today" : "tomorrow"
        c.title = quiet ? "" : name + " is due " + when
        c.body = quiet ? "A premium is due " + when + "." : (p.premium > 0 ? Fmt.rupees(p.premium) + " · " : "") + p.insurer
        c.sound = .default
        c.threadIdentifier = "kosh"
        c.userInfo = ["quiet": quiet]
        let req: UNNotificationRequest = UNNotificationRequest(identifier: id(p.id, p.nextDue), content: c, trigger: UNCalendarNotificationTrigger(dateMatching: comps, repeats: false))
        do { try await UNUserNotificationCenter.current().add(req) } catch { return false }
        return true
    }
}

/// the policy's life: a bar from its start to its end, today on it, the last premium where paying stops; how long it has
/// run and how long it has left
struct InsPolicyLife: View {
    let p: Policy
    let page: InsPolicyPage
    var body: some View {
        let tint: Color = InsLook.color(page.kind)
        let life: Bool = page.kind.life
        let sp = InsDay.span(page.lifeFrom, page.lifeTo.count >= 10 ? Day.add(page.lifeTo, 1) : page.lifeTo)
        let years: Int = sp.years + (sp.months >= 6 ? 1 : 0)
        VStack(alignment: .leading, spacing: 0) {
            InsHead(title: "Policy life", note: years > 0 ? "\(years) year" + (years == 1 ? "" : "s") : "")
            InsLifeBar(page: page, tint: tint).frame(height: 14).padding(.top, 30)
            ZStack(alignment: .topLeading) {
                Text(Day.fmt(page.lifeFrom, "MMM yyyy") + "\nstart").frame(maxWidth: .infinity, alignment: .leading)
                if let pe = page.payEndAt {
                    GeometryReader { geo in
                        Text(Day.fmt(p.payEnd ?? "", "MMM yyyy") + "\nlast premium").multilineTextAlignment(.center)
                            .fixedSize().position(x: geo.size.width * CGFloat(pe), y: 14)
                    }
                }
                Text(Day.fmt(page.lifeTo, "MMM yyyy") + "\n" + (life ? "matures" : "ends")).multilineTextAlignment(.trailing)
                    .foregroundStyle(tint).frame(maxWidth: .infinity, alignment: .trailing)
            }
            .font(.system(size: 10.5, design: .monospaced)).foregroundStyle(Obsidian.ink3)
            .frame(height: 34).padding(.top, 12)
            HStack(spacing: 10) {
                if let r = page.ran { InsTile(label: "Running for", value: InsYM.words(r.years, r.months)) }
                if let t = page.toRun { InsTile(label: life ? "Matures in" : "Ends in", value: InsYM.words(t.years, t.months), color: tint) }
            }
            .padding(.top, 22)
        }
    }
}

enum InsYM {
    static func words(_ y: Int, _ m: Int) -> String {
        if y == 0 && m == 0 { return "under a month" }
        if y == 0 { return "\(m) mo" }
        return "\(y) yr" + (m > 0 ? " \(m) mo" : "")
    }
}

struct InsLifeBar: View {
    let page: InsPolicyPage
    let tint: Color
    var body: some View {
        GeometryReader { geo in
            let w: CGFloat = geo.size.width
            let pay: CGFloat = CGFloat(page.payEndAt ?? 1)
            let now: CGFloat = CGFloat(page.todayAt ?? 0)
            ZStack(alignment: .leading) {
                // paying: solid up to today, faint to the last premium; then running on, hatched
                Capsule().fill(tint.opacity(0.10)).frame(width: w)
                Rectangle().fill(tint.opacity(0.38)).frame(width: w * pay)
                Rectangle().fill(tint).frame(width: w * min(now, pay))
                if pay < 1 {
                    InsHatch(color: tint).frame(width: w * (1 - pay) - 2).offset(x: w * pay + 2)
                }
                RoundedRectangle(cornerRadius: 1).fill(Obsidian.ink).frame(width: 2, height: 34)
                    .shadow(color: Color.white.opacity(0.6), radius: 6).offset(x: w * now - 1)
                Text("Today").font(.system(size: 10.5, design: .monospaced)).foregroundStyle(Obsidian.ink).fixedSize()
                    .position(x: min(max(w * now, 20), w - 20), y: -21)
                Circle().fill(tint).frame(width: 22, height: 22)
                    .overlay(Circle().stroke(Obsidian.bg, lineWidth: 4))
                    .shadow(color: tint.opacity(0.7), radius: 10)
                    .position(x: w, y: 7)
            }
        }
        .accessibilityHidden(true)
    }
}

/// diagonal stripes: the years a policy runs on after its last premium
struct InsHatch: View {
    let color: Color
    var body: some View {
        Canvas { ctx, size in
            ctx.fill(Path(CGRect(origin: .zero, size: size)), with: .color(color.opacity(0.06)))
            var x: CGFloat = -size.height
            while x < size.width {
                var path: Path = Path()
                path.move(to: CGPoint(x: x, y: size.height))
                path.addLine(to: CGPoint(x: x + size.height, y: 0))
                ctx.stroke(path, with: .color(color.opacity(0.22)), lineWidth: 2.5)
                x += 8
            }
        }
    }
}

/// a small tile: what it is and the figure
struct InsTile: View {
    let label: String
    let value: String
    var color: Color = Obsidian.ink
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(label).font(.system(size: 12)).foregroundStyle(Obsidian.ink3)
            Text(value).font(.system(size: 22, weight: .semibold)).monospacedDigit().tracking(-0.4).foregroundStyle(color).lineLimit(1).minimumScaleFactor(0.6)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .obsidianCard(20, padding: 16)
        .accessibilityElement(children: .combine)
    }
}

/// what goes in (every premium of its schedule, and what's paid so far), what comes back (the maturity figure, or the
/// fund's value), what that earns a year, and the same premiums in an FD at the rate stated, where the build has both
struct InsInAndBack: View {
    let p: Policy
    let page: InsPolicyPage
    var body: some View {
        let tint: Color = InsLook.color(page.kind)
        let paidIn: Double = p.paidIn ?? 0
        let endYear: String = page.lifeTo.isEmpty ? "" : " in " + Day.fmt(page.lifeTo, "yyyy")
        let payYears: Int = InsDay.span(p.start ?? "", p.payEnd ?? "").years + 1
        VStack(alignment: .leading, spacing: 0) {
            Text("What goes in, what comes back").font(.system(size: 17, weight: .semibold)).foregroundStyle(Obsidian.ink).accessibilityAddTraits(.isHeader)
            if let put = page.putIn, put > 0 {
                InsBarLine(label: "You put in" + (payYears > 1 ? ", over \(payYears) years" : ""), value: Fmt.rupees(put), fill: min(1, paidIn / put), back: put, tint: tint, valueColor: Obsidian.ink)
                    .padding(.top, 18)
                if paidIn > 0 { Text(Fmt.rupees(paidIn) + " paid so far").font(.system(size: 10.5, design: .monospaced)).foregroundStyle(Obsidian.ink3).padding(.top, 6).privacySensitive() }
            }
            if let b = page.back {
                InsBarLine(label: "You get back" + endYear, value: Fmt.rupees(b), fill: 1, back: b, tint: tint, valueColor: tint, glow: true).padding(.top, 16)
            } else if let fv = p.fundValue, fv > 0 {
                InsBarLine(label: "Worth today" + ((p.fundAsOf ?? "").isEmpty ? "" : " (" + Day.fmt(p.fundAsOf ?? "", "d MMM yyyy") + ")"), value: Fmt.rupees(fv), fill: 1, back: fv, tint: tint, valueColor: tint, glow: true).padding(.top, 16)
            }
            if p.xirr != nil || p.fd != nil {
                HStack(alignment: .top, spacing: 14) {
                    if let x = p.xirr {
                        Text(Fmt.trim(x, 1) + "%").font(.system(size: 26, weight: .semibold)).monospacedDigit().tracking(-0.8).foregroundStyle(Obsidian.ink)
                    }
                    Text(Self.line(p, page: page)).font(.system(size: 12.5)).foregroundStyle(Obsidian.ink2).fixedSize(horizontal: false, vertical: true)
                }
                .padding(.top, 16)
                .overlay(alignment: .top) { Rectangle().fill(Obsidian.cardBorder).frame(height: 1) }
                .padding(.top, 18)
            }
        }
        .obsidianCard(24, padding: 18)
        .privacySensitive()
    }
    /// "a year, on what's paid against the maturity figure. The same ₹1L a year in a 7% FD would reach about ₹20.7L by 2038."
    static func line(_ p: Policy, page: InsPolicyPage) -> String {
        var s: String = ""
        if p.xirr != nil {
            s = (p.fundValue ?? 0) > 0 && (p.maturity ?? 0) <= 0 ? "a year so far, its premiums against the fund's value." : "a year, its premiums against what it pays at the end."
        }
        if let fd = p.fd {
            let instalment: String = Fmt.words(p.premium) + " " + p.premiumEvery
            let rate: String = Fmt.trim(fd.rate, 1).appending("%")
            let till: String = page.lifeTo.isEmpty ? "" : " by " + Day.fmt(page.lifeTo, "yyyy")
            let fdLine: String = "The same " + instalment + " in a " + rate + " FD would reach about " + Fmt.words(fd.v) + till + "."
            s = s.isEmpty ? fdLine : s + " " + fdLine
        }
        return s
    }
}

struct InsBarLine: View {
    let label: String
    let value: String
    let fill: Double
    let back: Double
    let tint: Color
    let valueColor: Color
    var glow: Bool = false
    var body: some View {
        VStack(spacing: 8) {
            HStack {
                Text(label).foregroundStyle(Obsidian.ink2)
                Spacer(minLength: 8)
                Text(value).fontWeight(.semibold).monospacedDigit().foregroundStyle(valueColor)
            }
            .font(.system(size: 12.5))
            GeometryReader { geo in
                ZStack(alignment: .leading) {
                    Capsule().fill(Color(hex: "#1B1B22"))
                    Capsule().fill(tint.opacity(glow ? 1 : 0.35)).frame(width: geo.size.width)
                    Capsule().fill(tint).frame(width: geo.size.width * CGFloat(fill))
                }
            }
            .frame(height: 10)
            .shadow(color: glow ? tint.opacity(0.35) : Color.clear, radius: 9)
        }
    }
}

/// who's on it: its nominee, whose life it insures (or whom it covers), and who pays it, from which account
struct InsPeopleOn: View {
    @Environment(Store.self) private var store
    let p: Policy
    /// opens the policy's details, where what its papers didn't say is filled in once
    var ask: (() -> Void)? = nil
    var body: some View {
        let tint: Color = InsLook.color(InsKind.of(p))
        let nominee: String = p.nominee ?? ""
        let part: String = PolicyKinds.part(p)
        let insured: String = part == "Health" ? Words.cap(InsBook.covers(p, store.snap).replacingOccurrences(of: "covers ", with: "")) : (p.insured ?? "")
        let pays: String = Self.pays(store, p)
        VStack(alignment: .leading, spacing: 10) {
            InsHead(title: "People on this policy").padding(.bottom, 4)
            if !nominee.isEmpty {
                HStack(spacing: 16) {
                    Text(String(nominee.prefix(1)).uppercased()).font(.system(size: 19, weight: .semibold)).foregroundStyle(Obsidian.ink)
                        .frame(width: 50, height: 50).background(Color(hex: "#1B1B22"), in: Circle())
                        .padding(7).overlay(Circle().stroke(tint, lineWidth: 2.5))
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Nominee").caption(tint)
                        Text(nominee).font(.system(size: 18, weight: .semibold)).foregroundStyle(Obsidian.ink).lineLimit(2)
                        if let c = p.cover, c > 0, InsKind.of(p).life { Text("would get " + Fmt.words(c)).font(.system(size: 12.5)).foregroundStyle(Obsidian.ink3).privacySensitive() }
                    }
                    Spacer(minLength: 0)
                }
                .obsidianCard(24, padding: 18)
                .accessibilityElement(children: .combine)
            } else if InsKind.of(p).life, store.live != nil, let ask {
                // (a nominee its papers didn't print plainly: said so, and asked once, rather than a form's label shown)
                Button(action: ask) {
                    HStack(spacing: 16) {
                        Image(systemName: "person.badge.plus").font(.system(size: 18, weight: .medium)).foregroundStyle(tint)
                            .frame(width: 50, height: 50)
                            .overlay(Circle().strokeBorder(tint.opacity(0.55), style: StrokeStyle(lineWidth: 1.5, dash: [3, 4])))
                            .padding(7)
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Nominee").caption(tint)
                            Text("Not printed plainly in its papers").font(.system(size: 15.5, weight: .semibold)).foregroundStyle(Obsidian.ink)
                            Text("Add it once — kosh keeps it").font(.system(size: 12.5)).foregroundStyle(Obsidian.ink3)
                        }
                        Spacer(minLength: 0)
                        Image(systemName: "chevron.right").font(.system(size: 12, weight: .semibold)).foregroundStyle(Obsidian.ink3)
                    }
                    .obsidianCard(24, padding: 18)
                }
                .buttonStyle(.press)
            }
            LazyVGrid(columns: [GridItem(.flexible(), spacing: 10), GridItem(.flexible(), spacing: 10)], spacing: 10) {
                InsPersonFact(label: part == "Health" ? "Covers" : "Life assured", value: insured.isEmpty ? InsLook.person(store, p.owner) : insured)
                InsPersonFact(label: "Pays the premium", value: pays)
                if let h = p.holder, !h.isEmpty, h != p.insured { InsPersonFact(label: "Held by", value: h) }
            }
        }
    }
    /// "You · HDFC ••4821", from the payment that paid it last; else whose policy it is
    static func pays(_ store: Store, _ p: Policy) -> String {
        guard let f = p.payFrom else { return InsLook.person(store, p.owner) }
        let who: String = InsLook.person(store, f.o ?? p.owner)
        return who + " · " + f.bk + ((f.l4 ?? "").isEmpty ? "" : " ••" + (f.l4 ?? ""))
    }
}

struct InsPersonFact: View {
    let label: String
    let value: String
    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(label).font(.system(size: 12)).foregroundStyle(Obsidian.ink3)
            Text(value).font(.system(size: 15, weight: .medium)).foregroundStyle(Obsidian.ink).fixedSize(horizontal: false, vertical: true).privacySensitive()
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .obsidianCard(20, padding: 14)
        .accessibilityElement(children: .combine)
    }
}

/// every premium, a year a box: paid, the next, or still to come
struct InsEveryPremium: View {
    let p: Policy
    let page: InsPolicyPage
    var body: some View {
        let tint: Color = InsLook.color(page.kind)
        let step: Int = PremiumPlan.step(p)
        let note: String = Fmt.words(p.premium) + " each" + (step == 12 ? ", every " + Day.fmt(p.start ?? "", "MMMM") : step == 0 ? "" : ", " + InsHome.freq(p))
        VStack(alignment: .leading, spacing: 14) {
            InsHead(title: "Every premium", note: note)
            LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 8), count: 5), spacing: 8) {
                ForEach(page.years) { (y: InsYear) in
                    let on: Bool = y.state != .left
                    VStack(spacing: 5) {
                        Text("’" + String(String(y.year).suffix(2))).font(.system(size: 13, weight: .medium, design: .monospaced)).foregroundStyle(on ? Obsidian.ink : Obsidian.ink3)
                        Text(y.state == .paid ? "PAID" : y.state == .next ? "NEXT" : "—").font(.system(size: 9.5, design: .monospaced)).foregroundStyle(on ? tint : Obsidian.ink3)
                    }
                    .frame(maxWidth: .infinity).padding(.vertical, 11)
                    .background(y.state == .paid ? tint.opacity(0.12) : Obsidian.card, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous)
                        .strokeBorder(y.state == .next ? tint.opacity(0.6) : Obsidian.cardBorder, style: StrokeStyle(lineWidth: 1, dash: y.state == .next ? [4, 3] : [])))
                    .accessibilityElement(children: .ignore)
                    .accessibilityLabel(String(y.year) + ", " + (y.state == .paid ? "paid" : y.state == .next ? "next" : "to come"))
                }
            }
        }
    }
}

/// the policy's terms, plainly: each only when its mail or paper said it
struct InsFinePrint: View {
    @Environment(Store.self) private var store
    let p: Policy
    static func rows(_ p: Policy) -> [(String, String)] {
        let part: String = PolicyKinds.part(p)
        let coverWord: String = part == "Health" ? "Sum insured" : part == "Motor" ? "IDV" : part == "Life" ? "Sum assured" : "Cover"
        var r: [(String, String)] = []
        if let c = p.cover, c > 0 { r.append((coverWord, Fmt.rupees(c))) }
        if p.premium > 0 { r.append(("Premium", InsBook.premiumLine(p))) }
        if let g = p.gross, g > p.premium { r.append(("Last paid, with GST", Fmt.rupees(g))) }
        if let t = p.ppt, t > 0 { r.append(("Pay for", "\(t) years")) }
        if let y = p.years, y >= 2 { r.append(("Term", "\(y) years, bought at once")) } else if let t = p.term, t > 0 { r.append(("Policy term", "\(t) years")) }
        if PolicyKinds.part(p) == "Life", let c = p.cover, c > 0, let n = p.nominee, !n.isEmpty { r.append(("If something happens", Fmt.words(c) + " to " + n)) }
        if let b = p.bonus, b > 0 { r.append(("Bonus so far", Fmt.rupees(b))) }
        if let fv = p.fundValue, fv > 0 { r.append(("Fund value", Fmt.rupees(fv) + ((p.fundAsOf ?? "").isEmpty ? "" : " · " + Day.fmt(p.fundAsOf ?? "", "d MMM yyyy")))) }
        if let v = p.vehicle, !v.isEmpty { r.append(("Registration", v)) }
        if let c = p.coverType, !c.isEmpty { r.append(("Cover", c)) }
        if let a = p.addOns, !a.isEmpty { r.append(("Add-ons", a.joined(separator: ", "))) }
        if PolicyKinds.of(p) == "Top-up" { r.append(("Pays", "Above its deductible")) }
        if let v = p.plan, !v.isEmpty { r.append(("Plan", v)) }
        if let u = p.uin, !u.isEmpty { r.append(("Product code (UIN)", u)) }
        if let v = p.start, !v.isEmpty { r.append(("Started", Day.fmt(v, "d MMM yyyy"))) }
        if let v = p.end, !v.isEmpty { r.append((part == "Life" ? "Matures" : "Ends", Day.fmt(v, "d MMM yyyy"))) }
        if !p.lastPaid.isEmpty { r.append(("Last paid", Day.fmt(p.lastPaid, "d MMM yyyy"))) }
        if let w = p.statusWhy, !w.isEmpty { r.append(("Where it stands", w)) }
        return r
    }
    var body: some View {
        let rows: [(String, String)] = Self.rows(p)
        if !rows.isEmpty {
            VStack(alignment: .leading, spacing: 14) {
                InsHead(title: "The fine print, plainly")
                VStack(spacing: 0) {
                    ForEach(Array(rows.enumerated()), id: \.offset) { pair in
                        HStack(alignment: .firstTextBaseline, spacing: 12) {
                            Text(pair.element.0).foregroundStyle(Obsidian.ink2)
                            Spacer(minLength: 8)
                            Text(pair.element.1).fontWeight(.medium).monospacedDigit().foregroundStyle(Obsidian.ink).multilineTextAlignment(.trailing).privacySensitive()
                        }
                        .font(.system(size: 13.5))
                        .padding(.horizontal, 16).padding(.vertical, 14)
                        .overlay(alignment: .top) { if pair.offset > 0 { Rectangle().fill(Color.white.opacity(0.06)).frame(height: 1) } }
                        .accessibilityElement(children: .combine)
                    }
                }
                .background(Obsidian.card, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 24, style: .continuous).strokeBorder(Obsidian.cardBorder, lineWidth: 1))
            }
        }
    }
}

/// its claims, each at its latest word
struct InsClaims: View {
    let p: Policy
    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            InsHead(title: "Claims")
            VStack(spacing: 10) {
                ForEach(p.claims ?? [], id: \.self) { (c: Policy.Claim) in
                    let word: String = ["registered": "Registered", "query": "Waiting on documents", "approved": "Approved", "settled": "Settled", "rejected": "Rejected"][c.status] ?? c.status.capitalized
                    HStack {
                        VStack(alignment: .leading, spacing: 3) {
                            Text(word).font(.system(size: 14.5, weight: .medium)).foregroundStyle(Obsidian.ink)
                            Text((c.no.isEmpty ? "Claim" : "Claim " + c.no) + (c.on.count >= 10 ? " · " + Day.fmt(c.on, "d MMM yyyy") : "")).font(.system(size: 12)).foregroundStyle(Obsidian.ink3)
                        }
                        Spacer(minLength: 8)
                        if c.amt > 0 { Text(Fmt.rupees(c.amt)).font(.system(size: 14.5, weight: .semibold)).monospacedDigit().foregroundStyle(Obsidian.ink).privacySensitive() }
                    }
                    .obsidianCard(18, padding: 14)
                    .accessibilityElement(children: .combine)
                }
            }
        }
    }
}

/// the mails and papers it was read from: each opens the mail itself
struct InsFoundIn: View {
    @Environment(Store.self) private var store
    let p: Policy
    static func title(_ k: String) -> String {
        switch k {
        case "paper": return "Policy paper"
        case "paper-locked": return "Policy paper, locked"
        case "issued": return "Policy issued"
        case "receipt": return "Premium receipt"
        case "notice": return "Premium due notice"
        case "statement": return "Statement"
        case "claim": return "Claim update"
        case "lapsed": return "Lapse notice"
        case "matured": return "Maturity"
        case "debitfailed": return "Auto-debit failed"
        default: return "From the insurer"
        }
    }
    var body: some View {
        let mails: [Policy.Mail] = p.mails ?? []
        VStack(alignment: .leading, spacing: 14) {
            InsHead(title: "Found in your mail")
            LazyVGrid(columns: [GridItem(.flexible(), spacing: 10), GridItem(.flexible(), spacing: 10)], spacing: 10) {
                ForEach(mails, id: \.id) { (m: Policy.Mail) in
                    Button {
                        if store.live != nil { store.betaSheet = .source(SourceRef(title: InsBook.name(p), mails: [m.id], type: "policy", tint: InsLook.color(InsKind.of(p)))) }
                    } label: {
                        VStack(alignment: .leading, spacing: 14) {
                            Image(systemName: m.k.hasPrefix("paper") ? "doc.text" : m.pdf == true ? "doc.richtext" : "envelope").font(.system(size: 19)).foregroundStyle(Obsidian.ink2)
                            VStack(alignment: .leading, spacing: 4) {
                                Text(Self.title(m.k)).font(.system(size: 14, weight: .medium)).foregroundStyle(Obsidian.ink).lineLimit(2).multilineTextAlignment(.leading)
                                Text((m.k.hasPrefix("paper") || m.pdf == true ? "PDF" : "Mail") + (m.on.isEmpty ? "" : " · " + Day.fmt(m.on, "d MMM yyyy"))).font(.system(size: 10.5, design: .monospaced)).foregroundStyle(Obsidian.ink3)
                            }
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .obsidianCard(20, padding: 16)
                    }
                    .buttonStyle(.press)
                    .disabled(store.live == nil)
                }
            }
        }
    }
}
