import SwiftUI

// MARK: - The details banks lock statements with
//
// Banks, card issuers, fund houses, depositories, brokers, insurers and the tax department lock their PDFs with a
// password made of your details, and often say how in the email ("the first four letters of your name in capitals
// and your date of birth as DDMM"). Saved once here, in this phone's Keychain, kosh puts each sender's password
// together as its email says, then tries the formats Indian issuers commonly use, made from the same details. It's
// your own file, tried on the phone, once per statement; the password that opens it is kept for that sender, so
// its older statements open too. None of it leaves the phone.
//
// A family's papers are locked with each holder's own details (a parent's fixed deposit advice opens with the
// parent's name and date of birth), so kosh keeps a set of details for each person in the family, and tries the
// holder's first: the person whose inbox it came to, or who owns the sender's accounts.

/// one detail handed to the password formats with a person's details: what it is, its value, and where from
struct PwFact: Codable, Equatable, Hashable {
    var k: String
    var v: String
    var inst: String = ""
    var domain: String = ""
}

struct PasswordProfile: Codable, Equatable {
    var name = ""
    var dob = ""        // yyyy-MM-dd
    var pan = ""
    var mobile = ""
    var pin = ""
    /// a bank's customer ID or CRN, by the sender's domain
    var ids: [String: String] = [:]
    /// for someone under 18: the day you said you're their parent or guardian (India's data protection rules ask for a
    /// parent's consent before a child's details are used)
    var guardian: String? = nil
    /// (only while a locked statement is tried, never saved: whose details these are, and every detail kosh found
    /// for them with the statement's sender, a CRN, an account number, a folio, a policy number, for the engine's
    /// password formats to use)
    var who: String? = nil
    var facts: [PwFact]? = nil

    static let key = "pw.profile"
    /// yours
    static func load() -> PasswordProfile? {
        guard let s = Keychain.get(key), let p = try? JSONText.decode(PasswordProfile.self, s) else { return nil }
        return p
    }
    static func save(_ p: PasswordProfile?) {
        Keychain.set(p.map { JSONText.encode($0) }, for: key)
    }
    /// the family's, by person id ("me" is yours, kept where it always was)
    static let othersKey = "pw.profiles.family"
    static func others() -> [String: PasswordProfile] {
        guard let s = Keychain.get(othersKey), let d = try? JSONText.decode([String: PasswordProfile].self, s) else { return [:] }
        return d
    }
    static func load(for person: String) -> PasswordProfile? {
        person == "me" ? load() : others()[person]
    }
    static func save(_ p: PasswordProfile?, for person: String) {
        if person == "me" { save(p); return }
        var all = others()
        all[person] = (p?.isEmpty ?? true) ? nil : p
        Keychain.set(all.isEmpty ? nil : JSONText.encode(all), for: othersKey)
    }
    /// Facts kosh harvested on its own (no typing): the holder's name as banks write it, a Customer ID/CRN, PAN,
    /// date of birth or PIN code plainly printed in the mail. Kept apart from what the person typed, per person,
    /// so the person's own details always win and Erase clears both. Recomputed as kosh reads, never shown.
    static let harvestedKey = "pw.harvested"
    static func harvested() -> [String: PasswordProfile] {
        guard let s = Keychain.get(harvestedKey), let d = try? JSONText.decode([String: PasswordProfile].self, s) else { return [:] }
        return d
    }
    static func saveHarvested(_ d: [String: PasswordProfile]) {
        let kept = d.filter { !$0.value.isEmpty }
        Keychain.set(kept.isEmpty ? nil : JSONText.encode(kept), for: harvestedKey)
    }
    /// the person's typed details, with the harvested ones filling only the blanks (typed always wins)
    func filledWith(_ h: PasswordProfile) -> PasswordProfile {
        var x = self
        if x.name.isEmpty { x.name = h.name }
        // (a harvested date or PAN that can't be right fills nothing: one kept before kosh checked them stays out)
        if x.dob.isEmpty, PaperShelf.typed("dob", h.dob) != nil { x.dob = h.dob }
        if x.pan.isEmpty, PaperShelf.typed("pan", h.pan) != nil { x.pan = h.pan }
        if x.mobile.isEmpty { x.mobile = h.mobile }
        if x.pin.isEmpty { x.pin = h.pin }
        for (k, v) in h.ids where (x.ids[k] ?? "").isEmpty { x.ids[k] = v }
        return x
    }
    /// everyone's details, the given people first (a paper's likely holders), then you, then the rest; what the
    /// person typed, with the facts kosh harvested filling the blanks, and harvested-only people added
    static func ordered(first: [String]) -> [PasswordProfile] {
        var byPerson = others()
        if let mine = load() { byPerson["me"] = mine }
        for (id, h) in harvested() {
            if let typed = byPerson[id] { byPerson[id] = typed.filledWith(h) } else { byPerson[id] = h }
        }
        var order: [String] = []
        for p in first + ["me"] + byPerson.keys.sorted() where byPerson[p] != nil && !order.contains(p) { order.append(p) }
        return order.compactMap { (p: String) -> PasswordProfile? in
            guard var x = byPerson[p], !x.isEmpty else { return nil }
            x.who = p
            return x
        }
    }
    /// the person saved details themselves
    static var anySaved: Bool { load() != nil || !others().isEmpty }
    /// kosh has something to try on its own: the person's details, or facts it harvested
    static var anyUsable: Bool { anySaved || harvested().contains { !$0.value.isEmpty } }
    static func forgetAll() { save(nil); Keychain.set(nil, for: othersKey); Keychain.set(nil, for: harvestedKey) }
    var isEmpty: Bool { name.isEmpty && dob.isEmpty && pan.isEmpty && mobile.isEmpty && pin.isEmpty && ids.isEmpty }
}

struct PasswordProfileSheet: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    @State private var p = PasswordProfile()
    /// whose details are being edited: "me", or a family member's id
    @State private var who = "me"
    @State private var hasDOB = false
    @State private var dob = Calendar.current.date(byAdding: .year, value: -30, to: Date()) ?? Date()
    /// saved on this page: the background opening's word shows at the top
    @State private var saved = false
    /// the banks whose statements don't ask for a Customer ID, folded away until opened
    @State private var allBanks = false
    /// presented on its own (with Done), or pushed from Settings
    var inSheet = true
    /// one person's details, opened from the family list (nil: yours, with the rest of the household to pick from)
    var person: String? = nil
    var personName: String = ""
    /// false for someone the locked mail is written to who isn't in the household yet
    var inHousehold = true
    @State private var gone = false
    /// you're the parent or guardian of the person under 18 whose details these are
    @State private var guardianOK = false
    /// the person was set once; coming back to the page keeps whoever it became (after "Add to the family")
    @State private var started = false

    var body: some View {
        if inSheet { NavigationStack { form } } else { form }
    }

    var form: some View {
        let live: LiveSession? = store.live
        let banks: [IDSender] = live.map { idBanks($0) } ?? []
        let needed: [IDSender] = banks.filter(\.asks)
        let rest: [IDSender] = banks.filter { !$0.asks }
        let locked: [Reading] = live.map { lockedHere($0) } ?? []
        return Form {
            Section { header(locked) }
                .listRowBackground(Color.clear)
                .listRowInsets(EdgeInsets(top: 4, leading: 4, bottom: 4, trailing: 4))
            if person == nil, let people = live?.people, people.contains(where: { $0.id != "me" }) {
                Section { peopleStrip(people) }
                    .listRowBackground(Color.clear)
                    .listRowInsets(EdgeInsets(top: 0, leading: 0, bottom: 0, trailing: 0))
            }
            if saved, let live, !live.unlockNote.isEmpty {
                Section { status(live) }
            }
            Section {
                field("person", .blue, "Name") {
                    TextField(who == "me" ? "As on your bank account" : "As on their bank account", text: $p.name)
                        .textContentType(.name).autocorrectionDisabled()
                }
                dobRow
                if minor {
                    Toggle(isOn: $guardianOK) {
                        HStack(spacing: 12) {
                            IconTile(symbol: "figure.and.child.holdinghands", color: .mint, size: 30)
                            Text("I’m their parent or guardian")
                        }
                    }
                }
                field("creditcard", .indigo, "PAN") {
                    TextField("ABCDE1234F", text: $p.pan)
                        .textInputAutocapitalization(.characters).autocorrectionDisabled()
                        .onChange(of: p.pan) { _, v in p.pan = String(v.uppercased().filter { $0.isLetter || $0.isNumber }.prefix(10)) }
                }
                field("phone", .green, "Mobile") {
                    TextField("10 digits", text: $p.mobile).keyboardType(.phonePad).textContentType(.telephoneNumber)
                }
                // asked only when a locked statement's rule uses it (or it's already saved)
                if !p.pin.isEmpty || needsPIN {
                    field("mappin.and.ellipse", .orange, "PIN code") {
                        TextField("6 digits", text: $p.pin).keyboardType(.numberPad)
                            .onChange(of: p.pin) { _, v in p.pin = String(v.filter(\.isNumber).prefix(6)) }
                    }
                }
            } header: { Text(who == "me" ? "Your details" : "Their details") } footer: {
                if minor {
                    Text("They’re under 18, so a parent or guardian says yes before their details are used. Like everything here, they stay on this phone.")
                } else if who != "me" {
                    Text("Add someone only with their permission. Their details stay on this phone, used only to open their statements.")
                }
            }
            if !needed.isEmpty {
                Section {
                    ForEach(needed, id: \.key) { (s: IDSender) in bankRow(s, hint: true) }
                } header: { Text("Customer ID or CRN needed") } footer: {
                    Text("These banks lock statements with it. It’s on the cheque book, passbook, welcome letter or the bank’s app.")
                }
            }
            if !rest.isEmpty {
                Section {
                    DisclosureGroup(isExpanded: $allBanks.animation(Motion.base)) {
                        ForEach(rest, id: \.key) { (s: IDSender) in bankRow(s, hint: false) }
                    } label: {
                        HStack(spacing: 12) {
                            IconTile(symbol: "building.columns", color: .teal, size: 30)
                            VStack(alignment: .leading, spacing: 1) {
                                Text(needed.isEmpty ? "Customer IDs" : "Other banks").font(.body)
                                Text(Words.cap(Words.number(rest.count)) + " bank" + (rest.count == 1 ? "" : "s") + ", optional").font(.caption).foregroundStyle(.secondary)
                            }
                        }
                    }
                } footer: {
                    if needed.isEmpty { Text("Some banks lock statements with your Customer ID or CRN. Add it for the ones you know.") }
                }
            }
            if !inHousehold && !gone, let live {
                Section {
                    Button { if let nid = live.addUnlockPerson(who, full: personName, rel: "") { who = nid }; gone = true } label: {
                        Label("Add " + personName + " to the family", systemImage: "person.badge.plus")
                    }
                    Button(role: .destructive) { live.notFamily(who); gone = true; dismiss() } label: {
                        Label(personName + " isn’t family", systemImage: "person.badge.minus")
                    }
                } footer: {
                    Text("Locked mail is written to " + personName + ", who isn’t in your household yet. Their details are tried on those statements either way.")
                }
            }
            Section {
                Label("Kept in this phone’s Keychain. Never sent anywhere, never shown in kosh.", systemImage: "lock.shield")
                    .font(.footnote).foregroundStyle(.secondary)
                if PasswordProfile.load(for: who) != nil {
                    Button("Forget these details", role: .destructive) {
                        PasswordProfile.save(nil, for: who)
                        p = PasswordProfile(); hasDOB = false; saved = false
                    }
                    .font(.subheadline)
                }
            }
        }
        .navigationTitle(who == "me" ? "Your details" : "Their details")
        .navigationBarTitleDisplayMode(.inline)
        .safeAreaInset(edge: .bottom) { saveBar(locked.count) }
        .toolbar {
            if inSheet { ToolbarItem(placement: .cancellationAction) { Button("Done") { dismiss() } } }
        }
        .onChange(of: who) { _, w in load(w) }
        .onAppear {
            if !started, let person, who != person { who = person }
            if !started { load(who) }
            started = true
        }
    }

    // MARK: pieces

    var shownName: String {
        if who == "me" { let n: String = store.live?.name ?? ""; return n.isEmpty ? "You" : n }
        if let x = store.live?.people.first(where: { $0.id == who }) { return x.full.isEmpty ? x.name : x.full }
        return personName.isEmpty ? "Them" : personName
    }
    var shownColor: Color {
        if let x = store.live?.people.first(where: { $0.id == who }), !x.color.isEmpty { return Color(hex: x.color) }
        return Color.koshFill
    }

    /// whose details these are, and what's locked with them now
    func header(_ locked: [Reading]) -> some View {
        let names: [String] = Array(Set(locked.map { (r: Reading) -> String in (r.inst ?? "").isEmpty ? SenderPasswords.domain(r.doc?.from ?? "") : (r.inst ?? "") })).sorted()
        return VStack(alignment: .leading, spacing: 14) {
            HStack(spacing: 14) {
                Avatar(name: shownName, color: shownColor, size: 52)
                VStack(alignment: .leading, spacing: 3) {
                    Text(shownName).font(.title3.weight(.bold)).lineLimit(1)
                    Text(who == "me" ? "The details your bank statements are locked with" : "The details their statements are locked with")
                        .font(.subheadline).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                }
            }
            if !locked.isEmpty {
                HStack(spacing: 10) {
                    HStack(spacing: -8) {
                        ForEach(names.prefix(4), id: \.self) { (n: String) in
                            InstIcon(name: n, color: Color.kosh, size: 26, plain: true)
                                .overlay(RoundedRectangle(cornerRadius: 26 * 0.28, style: .continuous).stroke(Color(uiColor: .systemGroupedBackground), lineWidth: 2))
                        }
                    }
                    VStack(alignment: .leading, spacing: 1) {
                        Text(Words.cap(Words.number(locked.count)) + " statement" + (locked.count == 1 ? "" : "s") + " locked")
                            .font(.subheadline.weight(.semibold))
                        Text(Words.list(Array(names.prefix(3))) + (names.count > 3 ? " and more" : ""))
                            .font(.caption).foregroundStyle(.secondary).lineLimit(1)
                    }
                    Spacer(minLength: 0)
                    Image(systemName: "lock.fill").font(.footnote).foregroundStyle(Color.orange)
                }
                .padding(12)
                .background(Color.orange.opacity(0.09), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            }
        }
        .padding(.vertical, 6)
    }

    /// the household, to pick whose details
    func peopleStrip(_ people: [PersonInfo]) -> some View {
        let order: [PersonInfo] = people.filter { $0.id == "me" } + people.filter { $0.id != "me" }
        return ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(order) { (x: PersonInfo) in
                    let on: Bool = who == x.id
                    Button { withAnimation(Motion.base) { who = x.id } } label: {
                        HStack(spacing: 7) {
                            Avatar(name: x.full.isEmpty ? x.name : x.full, color: x.color.isEmpty ? Color.koshFill : Color(hex: x.color), size: 26)
                            Text(x.id == "me" ? "You" : x.name).font(.subheadline.weight(on ? .semibold : .regular)).foregroundStyle(Color.primary)
                        }
                        .padding(.leading, 4).padding(.trailing, 14).padding(.vertical, 4)
                        .background(on ? Color.kosh.opacity(0.14) : Color(uiColor: .secondarySystemGroupedBackground), in: Capsule())
                        .overlay(Capsule().strokeBorder(on ? Color.kosh.opacity(0.6) : Color.clear, lineWidth: 1))
                    }
                    .buttonStyle(.press)
                    .accessibilityAddTraits(on ? .isSelected : [])
                }
            }
            .padding(.horizontal, 20)
            .padding(.vertical, 2)
        }
    }

    /// saved, and the statements opening in the background (or what came of it)
    func status(_ live: LiveSession) -> some View {
        let opened: Bool = live.unlockNote.hasPrefix("Opened")
        return HStack(spacing: 12) {
            if live.unlocking { ProgressView().frame(width: 30) }
            else { Image(systemName: opened ? "checkmark.circle.fill" : "info.circle.fill").font(.title2).foregroundStyle(opened ? Color.green : Color.secondary).frame(width: 30) }
            VStack(alignment: .leading, spacing: 2) {
                Text(live.unlocking ? "Saved. Opening statements" : "Saved").font(.subheadline.weight(.semibold))
                Text(live.unlocking ? "This runs in the background. You can leave this page." : live.unlockNote)
                    .font(.footnote).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            }
        }
        .padding(.vertical, 2)
        .animation(Motion.open, value: live.unlocking)
    }

    /// one detail: its icon and name on the left, what's typed on the right
    func field<F: View>(_ sym: String, _ color: Color, _ title: String, @ViewBuilder _ input: () -> F) -> some View {
        HStack(spacing: 12) {
            IconTile(symbol: sym, color: color, size: 30)
            Text(title).fixedSize()
            Spacer(minLength: 12)
            input().multilineTextAlignment(.trailing)
        }
    }

    var dobRow: some View {
        HStack(spacing: 12) {
            IconTile(symbol: "gift", color: .pink, size: 30)
            Text("Date of birth").fixedSize()
            Spacer(minLength: 8)
            if hasDOB {
                DatePicker("Date of birth", selection: $dob, in: ...Date(), displayedComponents: .date)
                    .labelsHidden().indiaDates()
                Button { withAnimation(Motion.base) { hasDOB = false } } label: {
                    Image(systemName: "xmark.circle.fill").foregroundStyle(.tertiary)
                }
                .buttonStyle(.borderless)
                .accessibilityLabel("Clear date of birth")
            } else {
                Button("Add") { withAnimation(Motion.base) { hasDOB = true } }
                    .font(.subheadline.weight(.semibold))
                    .buttonStyle(.borderless)
            }
        }
    }

    /// a bank, and its Customer ID or CRN
    func bankRow(_ s: IDSender, hint: Bool) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(spacing: 12) {
                InstIcon(name: s.name, color: Color.kosh, size: 30, site: s.site, plain: true)
                VStack(alignment: .leading, spacing: 1) {
                    Text(s.name).lineLimit(1)
                    if s.locked && s.asks { Text("A statement waits on it").font(.caption).foregroundStyle(Color.orange) }
                }
                Spacer(minLength: 10)
                TextField("Customer ID", text: idBinding(s))
                    .multilineTextAlignment(.trailing)
                    .autocorrectionDisabled().textInputAutocapitalization(.characters)
                    .frame(maxWidth: 150)
            }
            if hint && !s.hint.isEmpty {
                Text(s.hint).italic()
                    .font(.footnote).foregroundStyle(.secondary)
                    .lineLimit(3).fixedSize(horizontal: false, vertical: true)
                    .padding(.leading, 42)
            }
        }
        .padding(.vertical, 2)
    }

    /// someone else, under 18 by the date of birth given
    var minor: Bool {
        guard who != "me", hasDOB, let y = Calendar.current.dateComponents([.year], from: dob, to: Date()).year else { return false }
        return y < 18
    }

    /// the one thing to do here
    func saveBar(_ locked: Int) -> some View {
        Button { save() } label: {
            Text(locked > 0 ? "Save and open statements" : "Save")
                .font(.headline)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 15)
                .foregroundStyle(Color.onKosh)
                .background(Color.koshFill, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        }
        .buttonStyle(.press)
        .disabled(minor && !guardianOK)
        .opacity(minor && !guardianOK ? 0.5 : 1)
        .padding(.horizontal, 20)
        .padding(.top, 10)
        .padding(.bottom, 6)
        .background(.bar)
    }

    func load(_ person: String) {
        saved = false
        if let s = PasswordProfile.load(for: person) { p = s } else {
            p = PasswordProfile()
            p.name = person == "me" ? (store.live?.name ?? "") : (store.live?.people.first { $0.id == person }?.full ?? personName)
        }
        hasDOB = false
        if let d = Day.parser.date(from: p.dob) { dob = d; hasDOB = true }
        guardianOK = p.guardian != nil
    }

    /// a bank whose Customer ID or CRN may lock this person's statements: every address its statements come from (one
    /// bank, several: hdfcbank.net and hdfcbank.bank.in), whether its password asks for one (its own words, when it
    /// does), and whether one of the person's statements from it is locked now. Their bank accounts are listed too, so
    /// the ID can be added before any statement comes.
    struct IDSender { let key: String; let name: String; let site: String?; let domains: [String]; let hint: String; let asks: Bool; let locked: Bool }

    /// the locked statements that are this person's (the likeliest holder of each)
    func lockedHere(_ live: LiveSession) -> [Reading] {
        live.lockedDocs.filter { (r: Reading) -> Bool in (live.likelyHolders(r).first ?? "me") == who }
    }

    func idBanks(_ live: LiveSession) -> [IDSender] {
        typealias Acc = (name: String, domains: Set<String>, hint: String, asks: Bool, locked: Bool)
        var by: [String: Acc] = [:]
        let idRule: String = #"(?i)customer\s*(?:id|number)|\bcrn\b|customer relationship|\bcif\b"#
        for r in live.records {
            guard let d = r.doc, d.kind == "stmt" || d.kind == "cardstmt" else { continue }
            let dom: String = SenderPasswords.domain(d.from.isEmpty ? (r.from ?? "") : d.from)
            guard !dom.isEmpty else { continue }
            let asks: Bool = d.hint.range(of: idRule, options: .regularExpression) != nil
            let holders: [String] = live.likelyHolders(r)
            // (a bank's statement that asks for a Customer ID shows for whoever's it is; any other only for its holder)
            guard holders.first == who || (asks && holders.contains(who)) else { continue }
            let name: String = (r.inst ?? "").isEmpty ? dom : (r.inst ?? dom)
            var x: Acc = by[name.lowercased()] ?? (name: name, domains: [], hint: "", asks: false, locked: false)
            x.domains.insert(dom)
            if asks { x.asks = true; if x.hint.isEmpty { x.hint = d.hint } }
            if d.state == "locked" { x.locked = true }
            by[name.lowercased()] = x
        }
        for a in store.snap.accounts where a.kind == "bank" && a.owner == who && !a.bank.isEmpty && by[a.bank.lowercased()] == nil {
            by[a.bank.lowercased()] = (name: a.bank, domains: [], hint: "", asks: false, locked: false)
        }
        // a Customer ID saved before for an address none of these send from stays editable
        let known: Set<String> = Set(by.values.flatMap { $0.domains })
        for key in p.ids.keys where !key.hasPrefix("bank:") && !known.contains(key) && by[key] == nil {
            by[key] = (name: key, domains: [key], hint: "", asks: false, locked: false)
        }
        // the ones whose rule asks for it first, the locked among them first; then the rest by name
        return by.values.map { (x: Acc) -> IDSender in
            let site: String? = x.name == x.domains.first ? x.name : nil
            return IDSender(key: x.name.lowercased(), name: x.name, site: site, domains: x.domains.sorted(), hint: x.hint, asks: x.asks, locked: x.locked)
        }
        .sorted { (a: IDSender, b: IDSender) -> Bool in a.asks != b.asks ? a.asks : a.locked != b.locked ? a.locked : a.name < b.name }
    }

    /// one bank's Customer ID or CRN: kept under the bank's name ("bank:hdfc bank") and every address its statements
    /// come from, so any of them finds it
    func idBinding(_ s: IDSender) -> Binding<String> {
        let keys: [String] = ["bank:" + s.key] + s.domains
        return Binding(get: { keys.compactMap { p.ids[$0] }.first { !$0.isEmpty } ?? "" },
                       set: { (v: String) in
                           let t: String = v.trimmingCharacters(in: .whitespaces)
                           for k in keys { p.ids[k] = t.isEmpty ? nil : t }
                       })
    }

    /// a locked statement's rule uses the PIN code
    var needsPIN: Bool {
        guard let live = store.live else { return false }
        return live.lockedDocs.contains { (r: Reading) -> Bool in
            (r.doc?.hint ?? "").range(of: #"(?i)pin ?code|\bpincode\b|postal code"#, options: .regularExpression) != nil
        }
    }

    /// saved to the Keychain at once; the statements are opened in the background, so nothing waits here
    @MainActor
    func save() {
        var x = p
        x.name = x.name.trimmingCharacters(in: .whitespaces)
        x.dob = hasDOB ? Day.parser.string(from: dob) : ""
        x.mobile = String(x.mobile.filter(\.isNumber).suffix(10))
        // a parent's or guardian's yes, with its day, for someone under 18 (kept from the first time it was given)
        x.guardian = minor && guardianOK ? (x.guardian ?? Day.iso(Date())) : nil
        PasswordProfile.save(x.isEmpty ? nil : x, for: who)
        p = x
        saved = true
        guard let live = store.live else { dismiss(); return }
        live.openLockedInBackground()
    }
}
