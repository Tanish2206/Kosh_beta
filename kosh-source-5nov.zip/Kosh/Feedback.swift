import SwiftUI
import UIKit

// MARK: - Feedback: shake the phone on any screen, say what you noticed, share them all later

struct FeedbackNote: Codable, Identifiable, Hashable {
    var id: String
    var date: Date
    var screen: String
    var mood: String
    var text: String
    var image: String?
}

extension Notification.Name { static let koshShake = Notification.Name("kosh.shake") }

extension UIWindow {
    open override func motionEnded(_ motion: UIEvent.EventSubtype, with event: UIEvent?) {
        if motion == .motionShake { NotificationCenter.default.post(name: .koshShake, object: nil) }
        super.motionEnded(motion, with: event)
    }
}

@Observable
final class FeedbackBook {
    static let shared = FeedbackBook()
    var notes: [FeedbackNote] = []

    /// the notes' folder: made the first time it is asked for, then the same URL without touching the disk (as
    /// LiveSession.folder and MailVault.folder are). Erase removes it and calls folderGone(): the next note makes it again
    static var folder: URL {
        folderLock.lock(); defer { folderLock.unlock() }
        if !folderMade {
            try? FileManager.default.createDirectory(at: folderBase, withIntermediateDirectories: true)
            folderMade = true
        }
        return folderBase
    }
    private static let folderBase: URL = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("kosh-feedback", isDirectory: true)
    private static let folderLock = NSLock()
    nonisolated(unsafe) private static var folderMade = false
    /// the folder is gone (Erase removed it): the next look makes it again
    static func folderGone() { folderLock.lock(); folderMade = false; folderLock.unlock() }
    private var file: URL { Self.folder.appendingPathComponent("notes.json") }

    init() {
        if let d = try? Data(contentsOf: file) {
            let dec = JSONDecoder()
            dec.dateDecodingStrategy = .iso8601
            notes = (try? dec.decode([FeedbackNote].self, from: d)) ?? []
        }
    }

    func save() {
        let enc = JSONEncoder()
        enc.dateEncodingStrategy = .iso8601
        enc.outputFormatting = .prettyPrinted
        if let d = try? enc.encode(notes) { try? d.write(to: file, options: .atomic) }
    }

    func add(screen: String, mood: String, text: String, image: UIImage?) {
        let id = UUID().uuidString
        var name: String?
        if let image, let png = image.jpegData(compressionQuality: 0.7) {
            name = "shot-\(notes.count + 1)-\(id.prefix(6)).jpg"
            try? png.write(to: Self.folder.appendingPathComponent(name!))
        }
        notes.append(FeedbackNote(id: id, date: Date(), screen: screen, mood: mood, text: text, image: name))
        save()
    }

    func remove(_ n: FeedbackNote) {
        if let i = n.image { try? FileManager.default.removeItem(at: Self.folder.appendingPathComponent(i)) }
        notes.removeAll { $0.id == n.id }
        save()
    }

    func removeAll() {
        for n in notes { if let i = n.image { try? FileManager.default.removeItem(at: Self.folder.appendingPathComponent(i)) } }
        notes = []
        save()
    }

    /// one markdown file plus the screenshots, ready to share
    func export(context: String) -> [URL] {
        let f = DateFormatter()
        f.dateFormat = "d MMM, h:mm a"
        var md = "# kosh beta feedback\n\n\(context)\n\n"
        for (i, n) in notes.enumerated() {
            md += "## \(i + 1). \(n.mood) · \(n.screen)\n_\(f.string(from: n.date))_\n\n\(n.text.isEmpty ? "(no words)" : n.text)\n"
            if let img = n.image { md += "\nScreenshot: \(img)\n" }
            md += "\n"
        }
        let out = FileManager.default.temporaryDirectory.appendingPathComponent("kosh-beta-feedback", isDirectory: true)
        try? FileManager.default.removeItem(at: out)
        try? FileManager.default.createDirectory(at: out, withIntermediateDirectories: true)
        let mdURL = out.appendingPathComponent("kosh-beta-feedback.md")
        try? md.write(to: mdURL, atomically: true, encoding: .utf8)
        var urls = [mdURL]
        for n in notes {
            guard let img = n.image else { continue }
            let src = Self.folder.appendingPathComponent(img), dst = out.appendingPathComponent(img)
            if (try? FileManager.default.copyItem(at: src, to: dst)) != nil { urls.append(dst) }
        }
        return urls
    }
}

/// The note card, shown in its own window so it works over any sheet
@MainActor
final class FeedbackPresenter {
    static let shared = FeedbackPresenter()
    private var window: UIWindow?

    var showing: Bool { window != nil }

    static func screenshot() -> UIImage? {
        let scenes = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }
        guard let w = scenes.flatMap(\.windows).first(where: { $0.isKeyWindow }) else { return nil }
        let r = UIGraphicsImageRenderer(bounds: w.bounds)
        return r.image { _ in w.drawHierarchy(in: w.bounds, afterScreenUpdates: false) }
    }

    func show(screen: String) {
        guard window == nil else { return }
        let shot = Self.screenshot()
        guard let scene = UIApplication.shared.connectedScenes.compactMap({ $0 as? UIWindowScene }).first(where: { $0.activationState == .foregroundActive })
                ?? UIApplication.shared.connectedScenes.compactMap({ $0 as? UIWindowScene }).first else { return }
        let w = UIWindow(windowScene: scene)
        w.windowLevel = .alert + 1
        w.overrideUserInterfaceStyle = Look.shared.scheme.style
        let host = UIHostingController(rootView: FeedbackCard(screen: screen, image: shot) { [weak self] in self?.hide() }.tint(Color.kosh))
        host.view.backgroundColor = .clear
        w.rootViewController = host
        w.makeKeyAndVisible()
        window = w
    }

    func hide() {
        window?.isHidden = true
        window = nil
    }
}

struct FeedbackCard: View {
    let screen: String
    let image: UIImage?
    let done: () -> Void
    @State private var mood = "Confusing"
    @State private var text = ""
    /// the screen goes with the note only when you say so (it shows your figures)
    @State private var attach = false
    @State private var shown = false
    @FocusState private var focused: Bool

    struct Mood: Identifiable { let id: String; let sym: String; let color: Color }
    let moods: [Mood] = [Mood(id: "Works well", sym: "hand.thumbsup.fill", color: Color.green), Mood(id: "Confusing", sym: "questionmark.circle.fill", color: Color.orange),
                         Mood(id: "Broken", sym: "exclamationmark.triangle.fill", color: Color.red), Mood(id: "Idea", sym: "lightbulb.fill", color: Color.sky)]

    var body: some View {
        ZStack(alignment: .bottom) {
            Color.black.opacity(shown ? 0.32 : 0).ignoresSafeArea()
                .onTapGesture { close() }
            VStack(alignment: .leading, spacing: 14) {
                HStack {
                    Label("Note for the beta", systemImage: "bubble.left.and.text.bubble.right.fill")
                        .font(.headline)
                    Spacer()
                    Button { close() } label: { Image(systemName: "xmark").font(.body.weight(.semibold)) }
                        .buttonStyle(.glass)
                        .buttonBorderShape(.circle)
                        .accessibilityLabel("Close")
                }
                Text(screen).font(.subheadline).foregroundStyle(.secondary)
                HStack(spacing: 8) {
                    ForEach(moods) { m in
                        Button {
                            withAnimation(Motion.base) { mood = m.id }
                        } label: {
                            VStack(spacing: 4) {
                                Image(systemName: m.sym).font(.title3)
                                Text(m.id).font(.caption2.weight(.semibold)).lineLimit(1).minimumScaleFactor(0.7)
                            }
                            .foregroundStyle(mood == m.id ? Color.white : m.color)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 10)
                            .background(mood == m.id ? m.color : m.color.opacity(0.12), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                        }
                        .buttonStyle(.press)
                    }
                }
                TextField("What did you notice? What did you expect?", text: $text, axis: .vertical)
                    .lineLimit(3...7)
                    .focused($focused)
                    .padding(12)
                    .background(Color.surface, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                if let image {
                    Toggle(isOn: $attach) {
                        HStack(spacing: 10) {
                            Image(uiImage: image).resizable().scaledToFill().frame(width: 34, height: 60).clipShape(RoundedRectangle(cornerRadius: 6))
                            Text("Attach this screen").font(.subheadline)
                        }
                    }
                }
                Button {
                    FeedbackBook.shared.add(screen: screen, mood: mood, text: text, image: attach ? image : nil)
                    close()
                } label: {
                    Text("Save note").font(.headline).frame(maxWidth: .infinity).padding(.vertical, 4)
                }
                .buttonStyle(.glassProminent).koshFilled()
                .controlSize(.large)
                Text("Notes stay on this phone. Share them all from Settings › Help and diagnostics.")
                    .font(.caption).foregroundStyle(.secondary)
            }
            .padding(20)
            .background(Color(uiColor: .systemBackground), in: RoundedRectangle(cornerRadius: 32, style: .continuous))
            .padding(10)
            .offset(y: shown ? 0 : 600)
        }
        .onAppear {
            withAnimation(Motion.large) { shown = true }
            focused = true
        }
    }

    func close() {
        focused = false
        withAnimation(Motion.base) { shown = false }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.27) { done() }
    }
}

/// Settings' list of notes
struct FeedbackListView: View {
    @Environment(Store.self) private var store
    @State private var book = FeedbackBook.shared
    @State private var files: [URL] = []

    var body: some View {
        List {
            Section {
                if book.notes.isEmpty {
                    Text("No notes yet. Shake the phone on any screen to write one.").foregroundStyle(.secondary)
                }
                ForEach(book.notes.reversed()) { n in
                    VStack(alignment: .leading, spacing: 4) {
                        HStack {
                            Text(n.mood).font(.subheadline.weight(.semibold))
                            Spacer()
                            Text(n.date, style: .relative).font(.caption).foregroundStyle(.secondary)
                        }
                        Text(n.screen).font(.caption).foregroundStyle(.secondary)
                        if !n.text.isEmpty { Text(n.text).font(.body) }
                        if n.image != nil { Label("Screenshot attached", systemImage: "photo").font(.caption).foregroundStyle(.secondary) }
                    }
                    .swipeActions { Button("Delete", role: .destructive) { book.remove(n) } }
                }
            } footer: {
                if !book.notes.isEmpty { Text("Swipe a note to delete it.") }
            }
        }
        .navigationTitle("Feedback")
        .toolbar {
            ToolbarItem(placement: .primaryAction) {
                if !book.notes.isEmpty {
                    ShareLink(items: files) { Image(systemName: "square.and.arrow.up") }
                        .disabled(files.isEmpty)
                        .accessibilityLabel("Share the notes")
                }
            }
        }
        .onAppear { files = book.export(context: store.betaContext) }
        .onChange(of: book.notes) { _, _ in files = book.export(context: store.betaContext) }
    }
}
