import SwiftUI
import PhotosUI
import AuthenticationServices

// MARK: - The beta's add/edit sheets: policy, loan, holding, property, key ring, accounts, documents

struct BetaSheetHost: View {
    let kind: BetaSheet
    var body: some View {
        switch kind {
        case .policy(let id): PolicyEditor(id: id).presentationDetents([.large])
        case .loan(let id): LoanEditor(id: id).presentationDetents([.medium, .large])
        case .holding(let id): HoldingEditor(id: id).presentationDetents([.medium, .large])
        case .property(let id): PropertyEditor(id: id).presentationDetents([.large])
        case .accounts: AccountsSheet().presentationDetents([.large])
        case .documents: DocumentsSheet().presentationDetents([.large])
        case .portal(let st): PortalSheet(state: st).presentationDetents([.large]).interactiveDismissDisabled()
        case .epf: EPFSheet().presentationDetents([.large]).interactiveDismissDisabled()
        case .committee(let id): CommitteeEditor(id: id).presentationDetents([.large])
        // every "locked statements" banner and card lands on the family's details: whose each one is, what's missing,
        // and from there what each sender needs
        case .passwords: FamilyUnlockView(inSheet: true).presentationDetents([.large])
        case .papers: PapersSheet().presentationDetents([.large])
        case .noticed(let id): NoticedSheet(open: id).presentationDetents([.medium, .large])
        case .headsUp: HeadsUpSheet().presentationDetents([.medium, .large]).presentationDragIndicator(.visible).presentationBackground(Color(uiColor: .systemBackground))
        case .digest: DigestSheet().presentationDetents([.large])
        case .alertsSetup: AlertsTurnOn().presentationDetents([.large])
        case .threads(let id): ThreadsSheet(open: id).presentationDetents([.large])
        case .source(let r): SourceSheet(ref: r).presentationDetents([.medium, .large])
        case .tutor(let d): ReaderTutorSheet(domain: d).presentationDetents([.large])
        case .pack(let p): PackSheet(period: p).presentationDetents([.large])
        case .claim(let c): ClaimSheet(id: c).presentationDetents([.medium, .large])
        }
    }
}

/// An empty-state card with a title, a line, and an add button — shown on the beta's tabs
struct BetaEmpty: View {
    let sym: String
    let title: String
    let text: String
    let add: String
    let action: () -> Void
    var body: some View {
        VStack(spacing: 12) {
            Image(systemName: sym).font(.system(.largeTitle, weight: .semibold)).foregroundStyle(Color.kosh.gradient)
            Text(title).font(.headline)
            Text(text).font(.subheadline).foregroundStyle(.secondary).multilineTextAlignment(.center).fixedSize(horizontal: false, vertical: true)
            Button(action: action) { Label(add, systemImage: "plus").font(.subheadline.weight(.semibold)) }
                .buttonStyle(.glassProminent).koshFilled()
                .padding(.top, 2)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 28)
        .padding(.horizontal, 20)
    }
}

// MARK: a small money field that reads rupees

struct RupeeField: View {
    let label: String
    @Binding var value: Double
    var body: some View {
        // up to ₹1,000 crore: twenty typed digits would otherwise reach every screen that shows it as a whole number
        let capped: Binding<Double> = Binding(get: { value }, set: { v in value = TypedAmount.cap(v) })
        HStack {
            Text(label)
            Spacer()
            TextField("0", value: capped, format: .number)
                .keyboardType(.numberPad)
                .multilineTextAlignment(.trailing)
                .frame(maxWidth: 160)
        }
    }
}

// MARK: Insurance — type by hand or read a photo of the policy

struct PolicyEditor: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    let id: String?
    @State private var p = UserPolicy()
    @State private var item: PhotosPickerItem?
    @State private var reading = false
    @State private var readNote: String?
    let types = ["Health", "Life", "Vehicle", "Home", "Travel", "Other"]

    var body: some View {
        NavigationStack {
            ObsidianForm {
                Section {
                    PhotosPicker(selection: $item, matching: .images) {
                        Label(reading ? "Reading the photo…" : "Read a photo of the policy", systemImage: "camera.viewfinder")
                    }
                    .disabled(reading)
                    if let readNote { Text(readNote).font(.footnote).foregroundStyle(.secondary) }
                } footer: {
                    Text("Snap the policy schedule. kosh reads it on this phone with Apple’s on-device text reader — nothing is sent anywhere — and fills in what it can. Check the details below.")
                }
                Section("Policy") {
                    TextField("Insurer (e.g. Star Health, LIC)", text: $p.insurer)
                    Picker("Type", selection: $p.type) { ForEach(types, id: \.self) { Text($0) } }
                    RupeeField(label: "Cover", value: $p.cover)
                    RupeeField(label: "Premium a year", value: $p.premium)
                    TextField("Policy number", text: $p.policyNo).autocorrectionDisabled()
                    DatePicker("Renews", selection: dueBinding, displayedComponents: .date).indiaDates()
                }
                if p.type == "Life" {
                    Section {
                        DatePicker("Started", selection: Binding(get: { Day.date(p.start ?? store.snap.today) }, set: { p.start = LiveSession.iso($0) }), displayedComponents: .date)
                            .indiaDates()
                        Stepper(value: Binding(get: { p.ppt ?? 0 }, set: { p.ppt = $0 > 0 ? $0 : nil }), in: 0...40) { LabeledContent("Paying for", value: (p.ppt ?? 0) > 0 ? "\(p.ppt ?? 0) years" : "not set") }
                        Stepper(value: Binding(get: { p.term ?? 0 }, set: { p.term = $0 > 0 ? $0 : nil }), in: 0...60) { LabeledContent("Runs for", value: (p.term ?? 0) > 0 ? "\(p.term ?? 0) years" : "not set") }
                        RupeeField(label: "Maturity figure (optional)", value: Binding(get: { p.maturity ?? 0 }, set: { p.maturity = $0 > 0 ? $0 : nil }))
                        RupeeField(label: "Fund value today (optional)", value: Binding(get: { p.fundValue ?? 0 }, set: { p.fundValue = $0 > 0 ? $0 : nil; p.fundAsOf = $0 > 0 ? store.snap.today : nil }))
                    } header: { Text("Its course") } footer: {
                        Text("With these kosh counts the premiums paid and left, and works out what the policy earns a year. The schedule and unit statements insurers email fill them in by themselves.")
                    }
                }
                if store.snap.people.count > 1 {
                    Section("Whose") {
                        Picker("Whose", selection: $p.owner) { ForEach(store.snap.people) { Text($0.id == "me" ? "You" : $0.full).tag($0.id) } }
                    }
                }
                if id != nil {
                    Section { Button("Remove this policy", role: .destructive) { store.live?.removePolicy(p.id); dismiss() } }
                }
            }
            .navigationTitle(id == nil ? "Add insurance" : "Edit policy")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) { Button("Save") { store.live?.upsertPolicy(p); dismiss() }.disabled(p.insurer.isEmpty) }
            }
            .onAppear { if let id, let e = store.live?.userPolicies.first(where: { $0.id == id }) { p = e } }
            .onChange(of: item) { _, v in if let v { Task { await read(v) } } }
        }
    }

    var dueBinding: Binding<Date> {
        Binding(get: { Day.date(p.nextDue) }, set: { p.nextDue = LiveSession.iso($0) })
    }

    @MainActor func read(_ pick: PhotosPickerItem) async {
        reading = true; readNote = nil
        defer { reading = false }
        guard let data = try? await pick.loadTransferable(type: Data.self) else { readNote = "Couldn’t open that photo."; return }
        let lines = await TextReader.lines(in: data)
        guard !lines.isEmpty else { readNote = "No text found. Try a clearer, flatter photo."; return }
        let joined = lines.joined(separator: "\n")
        if let out = try? Engine.shared.call("parseDocJSON", [joined, "policy", "", "policy schedule"]),
           let parsed = try? JSONText.decode(LiveSession.DocParsed.self, out), let d = parsed.policies.first {
            if let ins = d.insurer, !ins.isEmpty { p.insurer = ins }
            if let t = d.type, !t.isEmpty { p.type = t }
            if let c = d.cover, c > 0 { p.cover = c }
            if let pr = d.premium, pr > 0 { p.premium = pr }
            if let no = d.policyNo, !no.isEmpty { p.policyNo = no }
        }
        // insurer guess from the text if the parser missed it
        if p.insurer.isEmpty {
            for name in ["Star Health", "Niva Bupa", "Care", "HDFC Ergo", "ICICI Lombard", "Bajaj Allianz", "Tata AIG", "LIC", "HDFC Life", "ICICI Pru", "Max Life", "SBI Life", "Acko", "Digit"] {
                if joined.range(of: name, options: .caseInsensitive) != nil { p.insurer = name; break }
            }
        }
        let amts = TextReader.amounts(in: lines)
        if p.cover == 0, let big = amts.first { p.cover = big }
        readNote = "Read \(lines.count) lines. Check the details and fix anything."
    }
}

// MARK: Loans

struct LoanEditor: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    let id: String?
    @State private var l = UserLoan()
    var body: some View {
        NavigationStack {
            ObsidianForm {
                Section("Loan") {
                    TextField("Name (e.g. Home loan)", text: $l.name)
                    TextField("Bank", text: $l.bank)
                    RupeeField(label: "EMI a month", value: $l.emi)
                    RupeeField(label: "Outstanding", value: $l.outstanding)
                    HStack { Text("Rate %"); Spacer(); TextField("0", value: $l.rate, format: .number).keyboardType(.decimalPad).multilineTextAlignment(.trailing).frame(maxWidth: 100) }
                }
                if id != nil { Section { Button("Remove this loan", role: .destructive) { store.live?.removeLoan(l.id); dismiss() } } }
            }
            .navigationTitle(id == nil ? "Add a loan" : "Edit loan")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) { Button("Save") { store.live?.upsertLoan(l); dismiss() }.disabled(l.name.isEmpty) }
            }
            .onAppear { if let id, let e = store.live?.userLoans.first(where: { $0.id == id }) { l = e } }
        }
    }
}

// MARK: Holdings (what you own)

struct HoldingEditor: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    /// a holding's id to edit, nil for a new one, or "new:FD" (and the like) to start a new one of that kind
    let id: String?
    @State private var h = UserHolding()
    @State private var opened = Date()
    @State private var matures = Day.cal.date(byAdding: .year, value: 1, to: Date()) ?? Date()
    let kinds: [(String, String, String)] = [("dep", "FD", "Fixed deposit"), ("mf", "MF", "Mutual fund"), ("stk", "Equity", "Stocks"), ("ret", "NPS", "Retirement / NPS"), ("ret", "PPF", "PPF"), ("ret", "EPF", "EPF"), ("dep", "Gold", "Gold bonds (SGB)"), ("gold", "Gold", "Physical gold (coins, jewellery)"), ("dep", "RD", "Recurring deposit")]
    var isNew: Bool { id == nil || id!.hasPrefix("new:") }
    var isDeposit: Bool { h.type == "FD" || h.type == "RD" }
    var isGold: Bool { h.cls == "gold" }
    /// the rate as a year's return, grown quarterly as the bank does it (and as kosh values the deposit)
    var yearNote: String? {
        guard h.rate > 0 else { return nil }
        let pct: Double = (pow(1 + h.rate / 400, 4) - 1) * 100
        return Fmt.trim(h.rate, 2) + "% compounded quarterly comes to " + Gains.yearly(pct) + "."
    }
    /// what this gold is worth at the latest rate kosh has, if it has one
    var goldValue: (rate: Double, amt: Double, day: String)? {
        guard let p = store.live?.goldPrice, let g = h.grams, g > 0, let r = p.g[String(h.purity ?? 916)] else { return nil }
        return (r, (g * r).rounded(), p.d)
    }

    var body: some View {
        NavigationStack {
            ObsidianForm {
                Section {
                    Picker("Kind", selection: Binding(get: { h.cls + "|" + h.type }, set: { v in let p = v.split(separator: "|"); h.cls = String(p[0]); h.type = String(p.count > 1 ? p[1] : "") })) {
                        ForEach(kinds, id: \.2) { Text($0.2).tag($0.0 + "|" + $0.1) }
                    }
                }
                if isDeposit {
                    Section {
                        TextField("Bank (e.g. Kotak, SBI)", text: $h.bank)
                        RupeeField(label: "Amount deposited", value: $h.amt)
                        HStack {
                            Text("Interest rate")
                            Spacer()
                            TextField("7.0", value: $h.rate, format: .number).keyboardType(.decimalPad).multilineTextAlignment(.trailing).frame(maxWidth: 80)
                            Text("%").foregroundStyle(.secondary)
                        }
                        DatePicker("Opened on", selection: $opened, displayedComponents: .date).indiaDates()
                        DatePicker("Matures on", selection: $matures, in: opened..., displayedComponents: .date).indiaDates()
                        RupeeField(label: "At maturity (optional)", value: Binding(get: { h.matAmt ?? 0 }, set: { h.matAmt = $0 > 0 ? $0 : nil }))
                        TextField("Deposit number (last 4, optional)", text: $h.rem).keyboardType(.numberPad)
                    } header: {
                        Text("The deposit")
                    } footer: {
                        if let n = yearNote { Text(n) }
                    }
                } else if isGold {
                    Section {
                        TextField("What (e.g. coins, mother's bangles)", text: $h.bank)
                        HStack {
                            Text("Weight")
                            Spacer()
                            TextField("0", value: Binding(get: { h.grams ?? 0 }, set: { h.grams = $0 > 0 ? $0 : nil }), format: .number)
                                .keyboardType(.decimalPad).multilineTextAlignment(.trailing).frame(maxWidth: 100)
                            Text("grams").foregroundStyle(.secondary)
                        }
                        Picker("Purity", selection: Binding(get: { h.purity ?? 916 }, set: { h.purity = $0 })) {
                            ForEach(LiveSession.purities, id: \.0) { Text($0.1).tag($0.0) }
                        }
                        if let v = goldValue {
                            LabeledContent("Worth today", value: Fmt.rupees(v.amt))
                        }
                    } header: { Text("Physical gold") } footer: {
                        Text(goldValue.map { "At " + Fmt.rupees($0.rate) + " a gram on " + Day.fmt($0.day, "d MMM") + ": the India Bullion and Jewellers Association's rate, the one banks use, without GST and making charges. kosh updates it every day." }
                             ?? "kosh looks up today's rate when you save, and keeps it up to date every day: the India Bullion and Jewellers Association's rate, without GST and making charges.")
                    }
                } else {
                    Section("Holding") {
                        TextField("Where (e.g. Zerodha, HDFC MF)", text: $h.bank)
                        TextField("What (fund or scrip, optional)", text: $h.rem)
                        RupeeField(label: "Value now", value: $h.amt)
                    }
                }
                if store.snap.people.count > 1 {
                    Section("Whose") { Picker("Whose", selection: $h.owner) { ForEach(store.snap.people) { Text($0.id == "me" ? "You" : $0.full).tag($0.id) } } }
                }
                if !isNew { Section { Button("Remove", role: .destructive) { store.live?.removeHolding(h.id); dismiss() } } }
            }
            .navigationTitle(isNew ? (isDeposit ? "Add a fixed deposit" : "Add a holding") : "Edit holding")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) { Button("Save") { save(); dismiss() }.disabled(h.bank.isEmpty || (isGold ? (h.grams ?? 0) <= 0 : h.amt <= 0)) }
            }
            .onAppear {
                if let id, id.hasPrefix("new:") {
                    let t = String(id.dropFirst(4))
                    if t == "gold" { h.cls = "gold"; h.type = "Gold"; h.purity = 916 }
                    else if let k = kinds.first(where: { $0.1 == t }) { h.cls = k.0; h.type = k.1 }
                } else if let id, let e = store.live?.userHoldings.first(where: { $0.id == id }) {
                    h = e
                    if e.type == "FD" || e.type == "RD" { h.rem = "" }
                    if let s = e.start, let d = Self.day(s) { opened = d }
                    if let m = e.mat, let d = Self.day(m) { matures = d }
                }
            }
        }
    }

    func save() {
        if isGold {
            h.type = "Gold"; h.source = "gold|" + h.id
            if h.purity == nil { h.purity = 916 }
            if let v = goldValue { h.amt = v.amt }
        }
        if isDeposit {
            h.start = LiveSession.iso(opened); h.mat = LiveSession.iso(matures)
            let digits = h.rem.filter(\.isNumber)
            let name = h.bank.lowercased().contains(" fd") || h.bank.lowercased().hasSuffix("fd") ? h.bank : h.bank + " " + h.type
            h.bank = digits.count >= 4 ? name + " ••" + digits.suffix(4) : name
            h.rem = (h.matAmt ?? 0) > 0 ? Fmt.rupees(h.matAmt!) + " at maturity" : "opened " + Day.fmt(h.start!, "d MMM yyyy")
        }
        store.live?.upsertHolding(h)
    }
    /// a saved day (India's, as LiveSession.iso writes it) back into the picker: read in India's time too, or a phone
    /// east of India saved the day before each time
    static func day(_ s: String) -> Date? {
        (s.count > 7 ? Day.parser : FloorRows.monthFmt).date(from: s)
    }
}

/// One floor (or flat, or shop) of a property: who's in it, the rent, when it's due, the lease
/// One floor's rows in the property form: who uses it, and for a let floor the tenant, rent,
/// the day it's due and the lease
struct FloorRows: View {
    @Binding var u: UserUnit
    @State private var customLease = false
    var status: String { u.status ?? (u.tenant.isEmpty ? "vacant" : "let") }

    static let leases: [(String, Int)] = [("11 months", 11), ("1 year", 12), ("2 years", 24)]

    var body: some View {
        TextField("Floor name (Ground floor, Shop 2…)", text: $u.label)
            .onAppear { if status == "let" && u.months == 0 { u.months = 11 } }
        Picker("Who uses it", selection: Binding(get: { status }, set: { u.status = $0; if $0 == "let" && u.months == 0 { u.months = 11 } })) {
            Text("Let out").tag("let")
            Text("Empty").tag("vacant")
            Text("Family").tag("self")
        }
        .pickerStyle(.segmented)
        .listRowInsets(EdgeInsets(top: 12, leading: 16, bottom: 12, trailing: 16))
        if status == "let" {
            TextField("Tenant’s name (optional)", text: $u.tenant).textInputAutocapitalization(.words)
            RupeeField(label: "Rent a month", value: $u.rent)
            Picker("Rent due on", selection: Binding(get: { u.day ?? 5 }, set: { u.day = $0 })) {
                ForEach(1...28, id: \.self) { d in Text(ordinal(d) + " of the month").tag(d) }
            }
            .pickerStyle(.menu)
            RupeeField(label: "Deposit", value: $u.deposit)
            DatePicker("Lease from", selection: Binding(get: { Self.date(u.start) ?? Date() }, set: { u.start = Self.month($0) }), displayedComponents: .date)
                .indiaDates()
            VStack(alignment: .leading, spacing: 10) {
                Text("Lease length")
                Picker("Lease length", selection: Binding(get: { leaseChoice }, set: { pick($0) })) {
                    ForEach(Self.leases, id: \.1) { l in Text(l.0).tag(l.1) }
                    Text("Custom").tag(-1)
                }
                .pickerStyle(.segmented)
                .labelsHidden()
                if leaseChoice == -1 {
                    HStack {
                        Text("Months").foregroundStyle(.secondary)
                        Spacer()
                        TextField("e.g. 36", value: Binding(get: { u.months == 0 ? nil : u.months }, set: { u.months = max(0, min(240, $0 ?? 0)) }), format: .number)
                            .keyboardType(.numberPad)
                            .multilineTextAlignment(.trailing)
                            .frame(maxWidth: 100)
                    }
                    .padding(10)
                    .background(Color.primary.opacity(0.05), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
                }
            }
            .padding(.vertical, 6)
            Toggle("Agreement registered", isOn: $u.registered)
        }
    }

    /// which preset the lease matches, or custom
    var leaseChoice: Int {
        if customLease { return -1 }
        if Self.leases.contains(where: { $0.1 == u.months }) { return u.months }
        return u.months == 0 ? 11 : -1
    }
    func pick(_ v: Int) {
        if v == -1 { customLease = true; if Self.leases.contains(where: { $0.1 == u.months }) { u.months = 0 } }
        else { customLease = false; u.months = v }
    }

    static func date(_ ym: String) -> Date? {
        monthFmt.date(from: String(ym.prefix(7)))
    }
    static func month(_ d: Date) -> String {
        monthFmt.string(from: d)
    }
    /// yyyy-MM in India's time, made once (the pickers asked for a new formatter on every redraw of every floor)
    static let monthFmt: DateFormatter = {
        let f = DateFormatter(); f.locale = Locale(identifier: "en_US_POSIX"); f.timeZone = Day.zone; f.dateFormat = "yyyy-MM"
        return f
    }()
}

// MARK: Property — with the state's tax portal

struct PropertyEditor: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    let id: String?
    @State private var p = UserProperty()
    @State private var confirmRemove = false
    @State private var originalName = ""
    let types = ["House", "Flat", "Shop", "SCO", "Office", "Plot", "Other"]

    /// the city's own corporation's portal where kosh knows one, else the state's
    var portal: LiveSession.Portal? { LiveSession.portal(for: p.state, city: p.city) }
    /// this property as kosh last built it (whose it found it to be)
    var built: Prop? { id == nil ? nil : store.snap.prop.props.first { $0.uid == p.id } }

    var body: some View {
        NavigationStack {
            ObsidianForm {
                Section {
                    HStack(spacing: 16) {
                        BuildingArt(kind: kind, floors: p.units.map { $0.status ?? "vacant" }, width: 64)
                            .frame(width: 84, height: 110)
                        VStack(alignment: .leading, spacing: 4) {
                            Text(p.name.isEmpty ? "New property" : p.name).font(.headline).lineLimit(2)
                            Text(summary).font(.subheadline).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                        }
                    }
                    .padding(.vertical, 6)
                    .animation(Motion.open, value: p.units)
                }
                Section("Property") {
                    TextField("Name (e.g. Sector 10 house)", text: $p.name)
                    Picker("Type", selection: $p.type) { ForEach(types, id: \.self) { Text($0) } }
                }
                WhoseSection(whose: $p.whose, found: built?.whose ?? [], why: built?.whoseWhy ?? "", thing: "property")
                Section {
                    Picker("State", selection: $p.state) {
                        Text("Choose").tag("")
                        ForEach(LiveSession.states, id: \.self) { Text($0).tag($0) }
                    }
                    TextField("City / area", text: $p.city)
                } header: {
                    Text("Where")
                } footer: {
                    if let portal {
                        Text("Tax portal: \(portal.name). Find your property by \(portal.findBy.prefix(80)).")
                    } else if !p.state.isEmpty {
                        Text("No portal on file for \(p.state) yet. You can still track tax by hand.")
                    }
                }
                Section("Tax (optional)") {
                    TextField("Property ID on the portal", text: $p.pid).autocorrectionDisabled()
                    RupeeField(label: "Tax a year", value: $p.tax)
                }
                if id != nil { LandRateRows(p: $p) }
                Section {
                    Stepper(value: Binding(get: { max(1, p.units.count) }, set: { setFloors($0) }), in: 1...12) {
                        LabeledContent("Floors", value: "\(max(1, p.units.count))")
                    }
                } header: {
                    Text("Floors")
                } footer: {
                    Text("Each floor below: let out, empty, or used by the family. A let floor’s rent is matched to the money that comes in each month; if it hasn’t come by its due day, kosh shows it as late.")
                }
                ForEach(p.units.indices, id: \.self) { i in
                    Section(p.units[i].label.isEmpty ? Self.floorNames[min(i, Self.floorNames.count - 1)] : p.units[i].label) {
                        FloorRows(u: $p.units[i])
                    }
                }
                if id != nil {
                    Section {
                        Button("Remove this property", role: .destructive) { confirmRemove = true }
                            .frame(maxWidth: .infinity)
                    }
                }
            }
            .scrollDismissesKeyboard(.interactively)
            .navigationTitle(id == nil ? "Add property" : "Edit property")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) { Button("Save") { save(); dismiss() }.disabled(p.name.isEmpty) }
                ToolbarItemGroup(placement: .keyboard) {
                    Spacer()
                    Button("Done") { UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil) }
                }
            }
            .confirmationDialog("Remove \(p.short.isEmpty ? p.name : p.short)?", isPresented: $confirmRemove, titleVisibility: .visible) {
                Button("Remove property", role: .destructive) { store.live?.removeProperty(p.id); dismiss() }
                Button("Keep it", role: .cancel) {}
            } message: {
                Text("Its floors, tenants and rent tracking go with it. You can undo this from the Property tab straight after.")
            }
            .onAppear {
                // opened from a card: find it by its own id, or by its PID for older cards
                if let id, let e = store.live?.properties.first(where: { $0.id == id || (!$0.pid.isEmpty && $0.pid == id) }) { p = e; originalName = e.name }
                if p.units.isEmpty { setFloors(1) }
                for i in p.units.indices where p.units[i].label.isEmpty { p.units[i].label = Self.floorNames[min(i, Self.floorNames.count - 1)] }
            }
        }
    }

    var kind: BuildingArt.Kind {
        let t = p.type.lowercased()
        return t == "plot" ? .plot : t == "shop" || t == "sco" ? .shop : t == "flat" ? .flats : t == "office" ? .office : .house
    }
    var summary: String {
        let lets = p.units.filter { ($0.status ?? "") == "let" }
        let rent = lets.reduce(0) { $0 + $1.rent }
        var s = "\(p.type) · \(max(1, p.units.count)) floor\(p.units.count == 1 ? "" : "s")"
        if !lets.isEmpty { s += " · \(lets.count) let" + (rent > 0 ? ", \(Fmt.rupees(rent)) a month" : "") }
        return s
    }

    static let floorNames = ["Ground floor", "First floor", "Second floor", "Third floor", "Fourth floor", "Fifth floor", "Sixth floor", "Seventh floor", "Eighth floor", "Ninth floor", "Tenth floor", "Eleventh floor"]
    func setFloors(_ n: Int) {
        while p.units.count < n { var u = UserUnit(); u.label = Self.floorNames[min(p.units.count, Self.floorNames.count - 1)]; u.status = "vacant"; u.day = 5; p.units.append(u) }
        while p.units.count > n { p.units.removeLast() }
        p.floors = n
    }

    func save() {
        if p.units.isEmpty { setFloors(1) }
        // what the property is used for follows its floors
        let st = p.units.map { $0.status ?? ($0.tenant.isEmpty ? "vacant" : "let") }
        p.use = st.contains("let") ? "let" : st.contains("self") ? "own" : "vacant"
        if let portal { p.portalName = portal.name; p.portalUrl = portal.url; p.findBy = portal.findBy }
        // the name you type is the one the card shows
        if p.short.isEmpty || p.name != originalName { p.short = p.name }
        store.live?.upsertProperty(p)
    }
}

// MARK: More Gmail accounts

struct AccountsSheet: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            ObsidianList {
                if let live = store.live {
                    Section("Reading") {
                        HStack { Avatar(name: live.name.isEmpty ? live.email : live.name, color: Color.koshFill, size: 30, ink: Color.onKosh); Text(live.email.isEmpty ? "Primary" : live.email); Spacer(); Text("You").foregroundStyle(.secondary) }
                        ForEach(live.accounts) { a in
                            HStack {
                                Avatar(name: a.name, color: Color(hex: a.color), size: 30)
                                VStack(alignment: .leading, spacing: 0) {
                                    Text(a.id).lineLimit(1)
                                    Text(live.providerName(a.id)).font(.caption).foregroundStyle(.secondary)
                                }
                                Spacer()
                                Menu {
                                    ForEach(live.people.isEmpty ? [PersonInfo(id: "me", name: "You", full: "You", rel: "You", color: "#007AFF")] : live.people) { p in
                                        Button(p.id == "me" ? "Mine" : p.full) { live.setInboxOwner(a.id, p.id) }
                                    }
                                } label: {
                                    Text(a.person.flatMap { id in live.people.first { $0.id == id }?.name } ?? "Mine").font(.subheadline.weight(.semibold))
                                }
                                RemoveInboxButton(addr: a.id) { live.removeAccount(a.id) }
                            }
                        }
                    }
                    Section {
                        AddAccountButton { Task { await live.scan() } }
                    } footer: {
                        Text("Gmail, Outlook, Yahoo, iCloud, AOL, Zoho or any mail with IMAP. A Gmail must be on the beta’s test-user list first. Say whose each inbox is: the accounts and cards in it are filed under that person.")
                    }
                }
            }
            .navigationTitle("Inboxes")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } } }
        }
    }
}

struct AddAccountButton: View {
    var person: String? = nil
    var onDone: () -> Void
    @State private var showing = false
    var body: some View {
        Button { showing = true } label: {
            Label("Add another inbox", systemImage: "plus.circle")
        }
        .sheet(isPresented: $showing) {
            ConnectInboxSheet(person: person, onDone: onDone).presentationDetents([.large])
        }
    }
}

/// One inbox per family member (or more): connect theirs, and the accounts and cards in it are theirs
struct PersonGmailButton: View {
    @Environment(Store.self) private var store
    let person: PersonInfo
    @State private var showing = false
    var body: some View {
        let live = store.live!
        // every inbox that's theirs (yours: the ones added beside the one you signed in with); anyone can have more than one
        let mine = live.accounts.filter { $0.person == person.id || (person.id == "me" && ($0.person ?? "me") == "me") }
        VStack(alignment: .leading, spacing: 4) {
            ForEach(mine) { a in
                HStack(spacing: 6) {
                    Image(systemName: "envelope.fill").foregroundStyle(Color.green)
                    Text(a.id).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                    Text(live.providerName(a.id)).font(.caption2).foregroundStyle(.tertiary).lineLimit(1)
                    Spacer(minLength: 4)
                    RemoveInboxButton(addr: a.id, word: "Disconnect") { live.removeAccount(a.id) }
                }
            }
            Button {
                showing = true
            } label: {
                Label(mine.isEmpty && person.id != "me" ? "Connect \(person.name)’s email" : (person.id == "me" ? "Add another inbox of yours" : "Add another inbox of \(person.name)’s"), systemImage: "envelope.badge.plus")
                    .font(.caption.weight(.semibold))
            }
            .buttonStyle(.press)
            .foregroundStyle(Color.kosh)
        }
        .sheet(isPresented: $showing) {
            ConnectInboxSheet(person: person.id, onDone: { store.refreshPeople() }).presentationDetents([.large])
        }
    }
}

// MARK: Statements — open locked ones

struct DocumentsSheet: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            ObsidianList {
                CoverageSection()
                StatementCheckSection()
                HeldBackSection()
                StatementsSection(kinds: ["cas", "contract"], title: "Investments", empty: "No CAS statements found yet.")
                StatementsSection(kinds: ["policy"], title: "Insurance", empty: "No policy documents found yet.")
                StatementsSection(kinds: ["cardstmt", "stmt", "society"], title: "Bank and card statements", empty: "None found yet.")
                StatementsSection(kinds: ["payslip", "tax", "fd", "loan", "nps"], title: "Salary, tax, deposits and loans", empty: "None found yet.")
                UnreadPapersSection()
            }
            .navigationTitle("Statements")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } } }
        }
    }
}


/// Papers kosh opened but couldn't read, even with Claude's help: each with what went wrong, and a way to try again
struct UnreadPapersSection: View {
    @Environment(Store.self) private var store
    @State private var busy = false
    var body: some View {
        if let live = store.live {
            let items = live.unreadDocs
            if !items.isEmpty {
                Section {
                    ForEach(items) { it in
                        VStack(alignment: .leading, spacing: 3) {
                            Text(it.sender + " · " + it.file).font(.subheadline.weight(.semibold)).lineLimit(1)
                            Text(it.note.isEmpty ? "Opened, but not read" : it.note).font(.footnote).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                        }
                    }
                    Button {
                        busy = true
                        Task { @MainActor in await live.rereadUnread(); busy = false }
                    } label: {
                        Label(busy ? "Reading them again…" : "Read them again", systemImage: "arrow.clockwise")
                    }
                    .disabled(busy || live.readingDocs)
                } header: {
                    Text("Couldn’t read")
                } footer: {
                    Text(KoshAgent.useCloud || ClaudeReads.route() != nil
                         ? "kosh’s readers didn’t follow these, and smart reading didn’t add up against the pages, so nothing from them is counted. Shake the phone to send one in."
                         : "kosh’s readers didn’t follow these. With smart reading set up (Settings › Reading), an AI reads them, masked, and kosh counts only what checks out against the pages.")
                }
            }
        }
    }
}

// MARK: - A committee you're in

struct CommitteeEditor: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    let id: String?
    @State private var c = UserCommittee()
    @State private var start = Date()
    @State private var hasDraw = false
    @State private var draw = Date()
    @State private var paid = ""
    @State private var got = ""
    @State private var confirmRemove = false
    @State private var kind = CommKind.auction
    @State private var commission = ""
    @State private var inFlow = true

    static func month(_ d: Date) -> String { Day.iso(d).prefix(7).description }
    static func date(_ m: String) -> Date { Day.date(m + "-01") }
    /// this committee as kosh last built it (whose it found it to be)
    var built: Committee? { id == nil ? nil : store.committee(id) }

    var body: some View {
        NavigationStack {
            ObsidianForm {
                Section {
                    Picker("How the pool is given", selection: $kind.animation()) {
                        ForEach(CommKind.allCases) { Text($0.title).tag($0) }
                    }
                    if kind != .custom {
                        LabeledContent("Organiser's cut") {
                            HStack(spacing: 4) {
                                TextField("0", text: $commission).keyboardType(.decimalPad).multilineTextAlignment(.trailing)
                                Text("% of the pool").foregroundStyle(.secondary)
                            }
                        }
                    }
                } header: { Text("Kind") } footer: {
                    Text(kind.line + (kind == .custom ? "" : " A registered chit's organiser keeps up to 5–7% of the pool each month; an informal committee often keeps nothing."))
                }
                Section {
                    TextField("Organiser, or what you call it", text: $c.name).textInputAutocapitalization(.words)
                    LabeledContent("Monthly instalment") {
                        TextField("₹", value: Binding(get: { c.face }, set: { c.face = TypedAmount.cap($0) }), format: .number)
                            .keyboardType(.numberPad).multilineTextAlignment(.trailing)
                    }
                    Stepper(value: $c.members, in: 2...60) { LabeledContent("Members", value: "\(c.members) · \(c.members) months") }
                    DatePicker("First month", selection: $start, displayedComponents: .date).indiaDates()
                    Stepper(value: $c.day, in: 1...28) { LabeledContent("Paid on", value: ordinal(c.day) + " of the month") }
                } footer: {
                    Text(c.face > 0 ? "The pool is \(Fmt.words(c.face * Double(c.members))): \(c.members) of you, \(Fmt.rupees(c.face)) each, every month." : "One member takes the pool each month, so it runs as many months as it has members.")
                }
                WhoseSection(whose: $c.whose, found: built?.whose ?? [], why: built?.whoseWhy ?? "", thing: "committee")
                Section {
                    Toggle("I know my month", isOn: $hasDraw.animation())
                    if hasDraw {
                        DatePicker("I take the pool in", selection: $draw, displayedComponents: .date).indiaDates()
                        TextField("What I got (optional)", text: $got).keyboardType(.numberPad)
                    }
                } header: { Text("Your month") } footer: {
                    Text("The month you take the pool, by bid or by lot. Leave it off until it's decided.")
                }
                Section {
                    if kind == .auction {
                        TextField("Paid in so far (optional)", text: $paid).keyboardType(.numberPad)
                    }
                    Toggle("Count in the month-by-month cash flow", isOn: $inFlow)
                    Toggle("Finished", isOn: $c.done)
                } footer: {
                    Text(kind == .auction
                         ? "Record each month's instalment on the committee's page, or link the person you pay it to and kosh takes it from your bank. If you only know the total paid so far, put it here and kosh spreads it over the months not recorded."
                         : "Link the person you pay it to on the committee's page, and kosh takes each instalment from your bank.")
                }
                if id != nil {
                    Section {
                        Button("Remove this committee", role: .destructive) { confirmRemove = true }
                    }
                }
            }
            .navigationTitle(id == nil ? "Add a committee" : "Committee")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") { save() }.disabled(c.name.trimmingCharacters(in: .whitespaces).isEmpty || c.face <= 0)
                }
            }
            .confirmationDialog("Remove \(c.name.isEmpty ? "this committee" : c.name)?", isPresented: $confirmRemove, titleVisibility: .visible) {
                Button("Remove", role: .destructive) { store.live?.removeCommittee(c.id); dismiss() }
            }
            .onAppear(perform: load)
        }
    }

    func load() {
        guard let id, let found = store.live?.userCommittees.first(where: { $0.id == id }) else {
            c.start = Self.month(Date()); start = Date(); return
        }
        c = found
        start = Self.date(found.start.isEmpty ? Self.month(Date()) : found.start)
        if let d = found.draw, !d.isEmpty { hasDraw = true; draw = Self.date(d) }
        if let v = found.paidSoFar, v > 0 { paid = String(Int(safe: v)) }
        if let v = found.received, v > 0 { got = String(Int(safe: v)) }
        kind = CommKind(rawValue: found.kind ?? "") ?? .auction
        if let v = found.commission, v > 0 { commission = Fmt.trim(v, 2) }
        inFlow = found.excluded != true
    }

    func save() {
        c.name = c.name.trimmingCharacters(in: .whitespaces)
        c.start = Self.month(start)
        c.draw = hasDraw ? Self.month(draw) : nil
        c.paidSoFar = kind == .auction ? TypedAmount.whole(paid).flatMap { $0 > 0 ? $0 : nil } : nil
        c.received = hasDraw ? TypedAmount.whole(got).flatMap { $0 > 0 ? $0 : nil } : nil
        c.kind = kind.rawValue
        c.commission = kind == .custom ? nil : Double(commission.replacingOccurrences(of: ",", with: ".")).flatMap { $0 > 0 && $0 < 50 ? $0 : nil }
        c.excluded = inFlow ? nil : true
        store.live?.upsertCommittee(c)
        dismiss()
    }
}

/// Whose a property or committee is. Until you say, kosh's own answer stands, with how it knows (the owners on the
/// portal's record, whose account the rent reaches or pays the instalments). Two or more people make it joint, each
/// counted at an equal share; "The household's" keeps it out of every one person's figures on purpose. Nothing is
/// guessed from a name: what kosh can't tell stays the household's until you say.
struct WhoseSection: View {
    @Environment(Store.self) private var store
    @Binding var whose: [String]?
    /// kosh's answer from its last build, and how it knows ("portal", "rent", "paid", "said" or "")
    let found: [String]
    let why: String
    let thing: String
    var body: some View {
        let people: [PersonInfo] = store.snap.people
        Section {
            Button { whose = nil } label: { row("Let kosh work it out", sub: foundWords, on: WhoseSaid.isOpen(whose, people: people.map(\.id))) }
            ForEach(people) { p in
                Button { toggle(p.id) } label: { row(p.id == "me" ? "You" : p.full, sub: nil, on: (whose ?? []).contains(p.id)) }
            }
            Button { whose = ["family"] } label: { row("The household’s, no one person", sub: nil, on: whose == ["family"]) }
        } header: {
            Text("Whose is it")
        } footer: {
            Text("Pick two or more for a joint \(thing): each counts an equal share. A \(thing) shows under each person it’s in the name of, and the household’s shows only under Family.")
        }
    }
    /// what kosh found, in a few words
    var foundWords: String {
        guard why != "said" else { return "" }
        guard !found.isEmpty else { return "Not known yet, so it counts only under Family" }
        let how: String = why == "portal" ? "the owners on the portal’s record" : why == "rent" ? "the account its rent reaches" : why == "paid" ? "the account that pays it" : "its records"
        let names: [String] = found.map(name)
        let joined: String = names.count > 1 ? names.dropLast().joined(separator: ", ") + " and " + (names.last ?? "") : (names.first ?? "")
        return joined + ", by " + how
    }
    func name(_ id: String) -> String { id == "me" ? "You" : (store.snap.people.first { $0.id == id }?.name ?? id) }
    func toggle(_ id: String) {
        // (only people still in the household: an id left by someone who has gone ticks nothing and counts for no one)
        let here: Set<String> = Set(store.snap.people.map(\.id))
        var list: [String] = (whose ?? []).filter { $0 != "family" && here.contains($0) }
        if let i = list.firstIndex(of: id) { list.remove(at: i) } else { list.append(id) }
        whose = list.isEmpty ? nil : list.sorted()
    }
    func row(_ title: String, sub: String?, on: Bool) -> some View {
        HStack(spacing: 12) {
            VStack(alignment: .leading, spacing: 2) {
                Text(title).foregroundStyle(Color.primary)
                if let sub, !sub.isEmpty { Text(sub).font(.caption).foregroundStyle(.secondary) }
            }
            Spacer(minLength: 8)
            if on { Image(systemName: "checkmark").font(.body.weight(.semibold)).foregroundStyle(Color.kosh) }
        }
        .contentShape(Rectangle())
    }
}
