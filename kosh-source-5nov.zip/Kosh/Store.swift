import SwiftUI
import UIKit
import Observation

// MARK: - The store: the snapshot plus what changes on this phone
// Here: the state, loading a build, the sheets and the setup steps. The rest, split out 30 Oct 2026 as extensions:
// Store+Tabs (tabs, deep links), Store+Ledger (the month, the ledger, search, the chart), Store+Worth (ahead, and
// what each person owns and owes), Store+Owed (money between people), Store+Edits (changes made on this phone).

/// What the showcase replays from Settings
enum Showcase: String, Identifiable { case cards, setup, intro; var id: String { rawValue } }

/// The beta's add/edit sheets. The id carries the item being edited, or "" for a new one.
enum BetaSheet: Identifiable, Hashable {
    case policy(String?), loan(String?), holding(String?), property(String?), accounts, documents, portal(String), epf, committee(String?)
    /// the details banks lock statements with; policies, statements and property papers; what kosh noticed; teaching kosh a sender
    case passwords, papers, noticed(String?), tutor(String)
    /// the money threads, or one of them
    case threads(String?)
    /// where something kosh found was read from, and "that's not right"
    case source(SourceRef)
    /// a travel claim to make ("from|to"), and one already made (its id)
    case pack(String), claim(String)
    /// Home's bell: what kosh noticed and the money threads coming up, in one sheet
    case headsUp
    /// the week on one screen (Brief.swift)
    case digest
    /// Payments by SMS being turned on, carried on after iOS closed kosh mid-way (Alerts.swift)
    case alertsSetup
    var id: String {
        switch self {
        case .alertsSetup: return "alertsSetup"
        case .headsUp: return "headsUp"
        case .digest: return "digest"
        case .pack(let p): return "pack" + p
        case .claim(let c): return "claim" + c
        case .source(let r): return "src" + r.id
        case .passwords: return "passwords"
        case .papers: return "papers"
        case .noticed(let i): return "noticed" + (i ?? "")
        case .threads(let i): return "threads" + (i ?? "")
        case .tutor(let d): return "tutor" + d
        case .portal(let st): return "portal" + st
        case .policy(let i): return "pol" + (i ?? "")
        case .loan(let i): return "loan" + (i ?? "")
        case .holding(let i): return "hold" + (i ?? "")
        case .property(let i): return "prop" + (i ?? "")
        case .accounts: return "accounts"
        case .documents: return "documents"
        case .epf: return "epf"
        case .committee(let i): return "comm" + (i ?? "")
        }
    }
}

/// one part of the build that screens watch: bumped when a build changes that part (SnapBox)
@Observable
final class SnapCell {
    var n = 0
    func read() { _ = n }
    func bump() { n &+= 1 }
}

/* The build, watched part by part. `store.snap.cards` reads like the Snapshot it holds (dynamic member lookup), but a
   screen that reads it is redrawn only when a build changes `cards`, not on every build: a build replaces the whole
   Snapshot every few seconds while kosh reads mail, and each of the screens' 470-odd reads used to redraw them all.
   `whole` is the Snapshot for code that hands it on (it watches every part); `value` is the same, watched by nothing,
   for work done outside a screen's body. */
@dynamicMemberLookup
final class SnapBox {
    private(set) var value: Snapshot
    private let cells: [AnyKeyPath: SnapCell]
    /// bumped on any change: for `whole`, and for a part not in `parts`
    private let anyPart = SnapCell()

    init(_ s: Snapshot) {
        value = s
        var c: [AnyKeyPath: SnapCell] = [:]
        for p in Self.parts { c[p.key] = SnapCell() }
        cells = c
    }

    subscript<T>(dynamicMember kp: KeyPath<Snapshot, T>) -> T {
        if let c = cells[kp] { c.read() } else { anyPart.read() }
        return value[keyPath: kp]
    }

    /// the whole build, watching every part (a screen that hands it on redraws on any change, as before)
    var whole: Snapshot { anyPart.read(); return value }

    /// the build, watching only the parts named (for code that takes a Snapshot but reads only these: Figures)
    func reading(_ kps: [PartialKeyPath<Snapshot>]) -> Snapshot {
        for kp in kps { if let c = cells[kp] { c.read() } else { anyPart.read() } }
        return value
    }

    func personName(_ id: String) -> String? {
        // (the two parts Snapshot.personName reads, watched)
        _ = self[dynamicMember: \Snapshot.people]
        _ = self[dynamicMember: \Snapshot.peopleToConfirm]
        return value.personName(id)
    }

    /// a new build: only the parts that differ tell their screens
    func replace(with s: Snapshot) {
        let old: Snapshot = value
        value = s
        var changed = false
        for p in Self.parts where !p.same(old, s) {
            cells[p.key]?.bump()
            changed = true
        }
        // (a part missing from `parts` is still caught: the whole build is compared when no listed part moved)
        if changed || old != s { anyPart.bump() }
    }

    struct Part {
        let key: AnyKeyPath
        let same: (Snapshot, Snapshot) -> Bool
    }
    private static func part<T: Equatable>(_ kp: KeyPath<Snapshot, T>) -> Part {
        Part(key: kp, same: { (a: Snapshot, b: Snapshot) -> Bool in a[keyPath: kp] == b[keyPath: kp] })
    }
    /// every stored part of Snapshot (a new one belongs here too; until then its screens redraw on every change)
    static let parts: [Part] = [
        part(\.generated), part(\.today), part(\.cm), part(\.name), part(\.voice), part(\.wealthVoice),
        part(\.fc), part(\.months), part(\.cats), part(\.tx), part(\.needs), part(\.flow), part(\.agenda),
        part(\.comm), part(\.hold), part(\.prop), part(\.lent), part(\.dups),
        part(\.people), part(\.accounts), part(\.cards), part(\.wallets), part(\.cash),
        part(\.loans), part(\.policies), part(\.recurring), part(\.owed),
        part(\.insights), part(\.scan), part(\.scanStats), part(\.fy),
        part(\.rets), part(\.commMonths), part(\.commWho), part(\.worth), part(\.taxFacts), part(\.cashflow),
        part(\.recon), part(\.health), part(\.stmts), part(\.vouchers), part(\.tripDrafts), part(\.refunds),
        part(\.refundPromises), part(\.fees), part(\.cardFees), part(\.doubles), part(\.payFacts), part(\.buys),
        part(\.orders), part(\.homes), part(\.persona), part(\.actions), part(\.casGap), part(\.smarts),
        part(\.holdAsOf), part(\.holdRoll), part(\.paidBack), part(\.carried), part(\.shareNow), part(\.trips),
        part(\.facts), part(\.everyday), part(\.showFrom), part(\.watch), part(\.learned), part(\.recurringOff),
        part(\.threads), part(\.journey), part(\.docs), part(\.cases), part(\.plan), part(\.brief),
        part(\.acctMaybe), part(\.acctUnplaced), part(\.peopleToConfirm), part(\.nameGroups),
        part(\.deposits), part(\.dividends), part(\.depDates), part(\.retirement),
        part(\.vehicles), part(\.healthBy), part(\.needsLook), part(\.premAhead),
    ]
}

@Observable
final class Store {
    /// the build, watched part by part (SnapBox): assigned once, each build goes in through snap.replace(with:)
    let snap: SnapBox
    /* Your details, read once after each build and once after each correction, never from a view's body: the book is
       three Keychain reads and three JSON decodes, and a body pass that did them per person and per account page
       made the page redraw at the Keychain's pace */
    var details: [DetailEntry] = []
    func refreshDetails() {
        let d: [DetailEntry] = DetailsBook.entries(groups: snap.facts ?? [])
        if d != details { details = d }
    }
    var tx: [Txn] { didSet { txGen &+= 1 } }
    /// bumped whenever the payments change: what's worked out from them (below) is worked out again only then
    var txGen = 0
    // (not private: Store+Ledger.swift, an extension in its own file, reads and fills them)
    @ObservationIgnored var txIndexMemo: (gen: Int, map: [String: Int]) = (-1, [:])
    @ObservationIgnored var payeesMemo: (gen: Int, groups: [PayeeGroup]) = (-1, [])
    @ObservationIgnored var weeklyMemo: (gen: Int, day: String, groups: [PayeeGroup]) = (-1, "", [])
    @ObservationIgnored var monthMemo: (gen: Int, who: String, byMonth: [String: [Txn]]) = (-1, "", [:])
    /// (a month's days as the ledger lists them, and its chapters' share: each worked out once a build, since every
    /// redraw of Transactions asked for them again, a whole pass over the year each time)
    @ObservationIgnored var groupsMemo: (gen: Int, by: [String: [DayGroup]]) = (-1, [:])
    @ObservationIgnored var tripShareMemo: (gen: Int, by: [String: TripShare]) = (-1, [:])
    /// the payments filed to a chapter, picked out once a change (each month's share then looks at these only)
    @ObservationIgnored var tripTxMemo: (gen: Int, list: [Txn]) = (-1, [])
    /// the payments still in Miscellaneous, a payee at a time (Sort these, SortThese.swift): once a build, per person
    @ObservationIgnored var sortMemo: (gen: Int, who: String, queue: SortQueue) = (-1, "", SortQueue())
    /// payees passed over in Sort these while kosh is open: they wait at the end of the queue (never saved, since
    /// they're UPI IDs and names)
    @ObservationIgnored var sortSkipped: Set<String> = []
    /// what moved net worth over the range on screen, and the renewal calendar by month: each worked out once a build
    /// for whoever's money is showing (NetWorthMoves.swift, InsuranceCalendar.swift)
    @ObservationIgnored var worthMovesMemo: (gen: Int, key: String, out: WorthMoves?) = (-1, "", nil)
    @ObservationIgnored var renewalsMemo: (gen: Int, key: String, months: [RenewalMonth]) = (-1, "", [])
    /// the Insurance home's figures, kept by what they were worked out from (InsuranceObsidian.swift)
    @ObservationIgnored var insMemo: (key: Int, home: InsHome?) = (0, nil)
    /// how many payments each category has, and the wallets paid from for whoever is shown: once a change to the
    /// payments (the category pickers asked four times a redraw, and Find on every keystroke, each a pass over every
    /// payment; 31 Oct)
    @ObservationIgnored var catUseMemo: (gen: Int, counts: [String: Int]) = (-1, [:])
    @ObservationIgnored var walletsMemo: (gen: Int, who: String, names: [String]) = (-1, "", [])
    /// what went on each card in 30 days, a card's own payments, an account's money in and out, this month's cash flow
    /// by day, and Find's category chips: each worked out once a change to the payments (or to the cards' own side of
    /// bills paid), since Cards, Accounts, Home and Find asked for them on every redraw, each a pass over every payment
    @ObservationIgnored var cardSpendMemo: (gen: Int, key: String, out: [String: Double]) = (-1, "", [:])
    @ObservationIgnored var cardTxMemo: (gen: Int, mgen: Int, by: [String: [Txn]]) = (-1, -1, [:])
    @ObservationIgnored var flowMemo: (gen: Int, mgen: Int, by: [String: AccountFlow]) = (-1, -1, [:])
    @ObservationIgnored var cashDaysMemo: (gen: Int, key: String, inD: [Double], invD: [Double]) = (-1, "", [], [])
    @ObservationIgnored var findMemo: (gen: Int, who: String, unnamed: Int, cats: [String: Int], subs: [String: [String: Int]]) = (-1, "", 0, [:], [:])
    /// bumped whenever what's owed changes (a split, a share paid back): what's worked out from it is worked out again
    var owedGen = 0
    /// each chapter's split, worked out once a change to the payments or to what's owed (ChapterSplit.swift)
    @ObservationIgnored var splitMemo: (gen: Int, owed: Int, by: [String: ChapterSplit]) = (-1, -1, [:])
    /// each card's own side of a bill paid, out of every list (the payment says it once) and on the card's page only
    var mirrors: [Txn] = [] { didSet { mirrorsGen &+= 1 } }
    /// bumped whenever the cards' own sides change (as txGen is for the payments)
    var mirrorsGen = 0
    /// the beta's Gmail session; nil in the snapshot builds
    let live: LiveSession?
    /// a question to open Ask kosh with (from something kosh noticed)
    var askSeed: String? = nil
    /// the conversation with Ask kosh, kept while the app is open
    var askThread: [AskMessage] = []
    /// where a payment's sheet opens: its category ("cats") or its chapter ("trip"), from a swipe on its row
    var txStart: String? = nil
    /// what Find opens with, from a figure tapped elsewhere (a category's month on Insights)
    var findPreset: FindQuery? = nil
    /// the day the calendar opens on, and a card to open on Cards: from a reminder tapped; each taken once shown
    var calendarDay: String? = nil
    var cardJump: String? = nil
    /// a change to one payment that could go to every payment to its payee, asked once it's made
    var applyAsk: ApplyAsk? = nil
    /// the last change, to take back for a few seconds
    var undoNote: UndoNote? = nil
    /// what kosh noticed that you marked done or paid, or snoozed: its id → when it may show again (seconds since
    /// 1970); a done one waits four months, by when kosh has long stopped noticing it
    /// With kosh beta, in the protected profile (LiveSession.own.hushed, taken in by loadSaved); the bundled builds
    /// keep it in the phone's defaults.
    var hushed: [String: Double] = Snapshot.isLive ? [:] : Saved.ud.dictionary(forKey: "watch.hushed") as? [String: Double] ?? [:] {
        didSet {
            if let live { live.own.hushed = hushed; ownChanged(live) } else { Saved.ud.set(hushed, forKey: "watch.hushed") }
        }
    }
    var added: Double = 0
    /// Hide amounts: saved, so a relaunch, or a build woken in the background (a fresh Store), keeps the reminders and
    /// the Lock Screen free of figures
    var hidden: Bool = Saved.ud.bool(forKey: "kosh.hidden") { didSet { Saved.ud.set(hidden, forKey: "kosh.hidden") } }
    var tab: AppTab = .home
    var homePath: [Route] = []
    var txPath: [Route] = []
    var portPath: [Route] = []
    var propPath: [Route] = []
    var commPath: [Route] = []
    var peoplePath: [Route] = []
    var insPath: [Route] = []
    var loanPath: [Route] = []
    var chapPath: [Route] = []
    var homeSub: HomeSub = .overview
    var txSub: TxSub = .all
    var portSub: PortSub = .overview
    /// Wealth › Holdings' kind (dep, mf, ret, stk, gold, other); "" opens on the biggest (WealthHoldings.swift)
    var holdKind: String = ""
    var propSub: PropSub = .overview
    var commSub: CommSub = .active
    /// whose money is showing; kept across launches, so the picker opens where you left it
    var who: Person = .family { didSet { if who != oldValue { UserDefaults.standard.set(who.id, forKey: Self.whoKey) } } }
    static let whoKey = "beta.who"
    /// the saved choice is put back once, on the first build that has that person in it
    @ObservationIgnored private var whoRestored = false
    var sheet: SheetKind? { didSet { sheetChanged() } }
    /// changes made on an open payment's sheet, shown at once over `tx`; the build that follows the sheet's closing
    /// makes them real and they're dropped. Nothing else on screen redraws while you tap.
    var edits: [String: Txn] = [:]
    /// the build each change was made after (LiveSession.buildGen when you tapped): a build that had started before
    /// it knows nothing of it, so the change is laid over it again rather than undone until the next one lands
    @ObservationIgnored var editGen: [String: Int] = [:]
    /// rent months you just marked or unmarked received, shown before the build that confirms them (Store+RentMarks)
    @ObservationIgnored var rentMarks: [String: RentMark] = [:]
    /// the other changes you just made, shown before the build that confirms them (Store+Shown, ShownRules)
    @ObservationIgnored var shown: [Shown] = []
    /// one more each change shown at once: the light tap under your finger (ShownFeel)
    var felt: Int = 0
    var ledgerMonth: String
    /// pairs answered in "Counted twice?" this session (the next build drops them from the list)
    var dupsDone: Set<String> = []

    /// the privacy cards or the whole setup, replayed to show someone; not saved
    var showcase: Showcase?

    /// the beta's add/edit sheets (policy, loan, holding, property)
    var betaSheet: BetaSheet?

    // saved on the phone
    var onboarded: Bool = Saved.ud.bool(forKey: "kosh.onboarded.v2") { didSet { Saved.ud.set(onboarded, forKey: "kosh.onboarded.v2") } }
    /// the tab bar, in order: Home first, then the person's own choice, four to six in all
    var tabs: [AppTab] = Store.savedTabs() {
        didSet { Saved.save("kosh.tabs", tabs.map(\.rawValue)) }
    }
    /// the bar as icons alone; always so at six
    var iconsOnly: Bool = Saved.ud.bool(forKey: "kosh.tabs.icons") { didSet { Saved.ud.set(iconsOnly, forKey: "kosh.tabs.icons") } }
    /// the payments of one chapter, shown in Transactions in place of the month; not saved
    var ledgerChapter: String?
    /// Transactions' select mode: the payments ticked, to put in a chapter (or file) together
    var ledgerSelecting = false
    var ledgerSelected: Set<String> = []
    var faceID: Bool = Saved.ud.bool(forKey: "kosh.faceid") { didSet { Saved.ud.set(faceID, forKey: "kosh.faceid") } }
    /// the made-up household instead of the family's own figures
    var demo: Bool = Saved.ud.bool(forKey: "kosh.demo") { didSet { Saved.ud.set(demo, forKey: "kosh.demo") } }

    // saved per household, so what you add while showing kosh never mixes with your own. With kosh beta, in the
    // protected profile beside the ledger (LiveSession.own); the bundled builds keep theirs in the phone's defaults
    var userOwed: [OwedItem] = [] {
        didSet {
            if let live { live.own.owed = userOwed; ownChanged(live) } else { Saved.save(key("owed"), userOwed) }
            syncOwed()
            owedGen &+= 1
        }
    }
    var settledIDs: Set<String> = [] {
        didSet {
            if let live { live.own.settled = Array(settledIDs); ownChanged(live) } else { Saved.save(key("settled"), Array(settledIDs)) }
            syncOwed()
            owedGen &+= 1
        }
    }
    var captures: [Capture] = [] {
        didSet { if let live { live.own.captures = captures; ownChanged(live) } else { Saved.save(key("captures"), captures) } }
    }
    var upi: String = "" {
        didSet { if let live { live.own.upi = upi; ownChanged(live) } else { Saved.ud.set(upi, forKey: key("upi")) } }
    }
    /// with kosh beta: these were read from the profile (it can't be read before the phone's first unlock); until
    /// then nothing is written back over it
    @ObservationIgnored private var ownLoaded = false
    private func ownChanged(_ live: LiveSession) { if ownLoaded { live.save() } }

    func key(_ name: String) -> String { (demo ? "kosh.demo." : "kosh.") + name }
    var sourceNote: String { demo ? "the made-up household bundled with the app" : "the snapshot saved on this phone" }

    init() {
        if Snapshot.isLive {
            let l = LiveSession()
            // the first build already settles what came back: the shares saved on this phone go in with it
            let saved = Store.owedForEngine(l.own.owed, settled: Set(l.own.settled))
            l.owedOpen = saved.open
            l.owedDone = saved.done
            l.owedNot = saved.not
            // the screens as last laid out open at once, laid out afresh behind them; the first launch builds now
            let kept: Snapshot? = Perf.shared.measure("startup · kept screens") { l.savedSnapshot() }
            let s: Snapshot
            if let kept { s = kept } else if let first = Perf.shared.measure("startup · first build", { l.build() }) { s = first } else { s = LiveSession.blank }
            live = l
            snap = SnapBox(s)
            tx = s.tx.filter { $0.mr != true }; mirrors = s.tx.filter { $0.mr == true }
            ledgerMonth = s.cm
            demo = false
            loadSaved()
            refreshDetails()
            l.onBuild = { [weak self] s in self?.apply(s) }
            l.onShow = { [weak self] key, feel, change in self?.showNow(key, feel: feel, change) }
            if kept != nil { l.rebuildSoon(force: true) }
            return
        }
        live = nil
        let useDemo = Saved.ud.bool(forKey: "kosh.demo") && Snapshot.hasDemo
        let s = Snapshot.load(useDemo ? "demo" : "kosh")
        snap = SnapBox(s)
        tx = s.tx.filter { $0.mr != true }; mirrors = s.tx.filter { $0.mr == true }
        ledgerMonth = s.cm
        demo = useDemo
        loadSaved()
        refreshDetails()
    }

    /// a fresh build from the beta's records
    func apply(_ s: Snapshot) { Perf.shared.measure("apply build") { applyNow(s) } }
    private func applyNow(_ built: Snapshot) {
        // opened on the screens kept from before a new month began: the ledger moves on with the month
        // (rent you just marked received stays marked over a build that started before the tap)
        let s: Snapshot = keepShown(keepRentMarks(built))
        if ledgerMonth == snap.cm && s.cm != snap.cm { ledgerMonth = s.cm }
        // (only the parts this build changed redraw their screens: SnapBox)
        snap.replace(with: s)
        var fresh: [Txn] = s.tx.filter { $0.mr != true }
        let mirrored: [Txn] = s.tx.filter { $0.mr == true }
        if mirrored != mirrors { mirrors = mirrored }
        /* a change is real once a build started after it lands; a build that started before it (reading mail keeps
           one going) is laid out with the change over it, so a payment you just filed never flips back. Only the
           payments changed are touched */
        if !edits.isEmpty {
            let landed: Int = live?.buildGen ?? Int.max
            for (id, t) in edits {
                if landed > (editGen[id] ?? -1) {
                    if !editingTx { edits[id] = nil; editGen[id] = nil }
                } else if !editingTx, let i = fresh.firstIndex(where: { $0.id == id }) {
                    fresh[i] = t
                }
            }
        }
        // the same payments again (a build while reading that found nothing new): no redraw, and txGen stays, so
        // nothing worked out from them is worked out again
        if fresh != tx { tx = fresh }
        // (a spend you added counts until a build that has it lands: Store+Shown)
        let more: Double = shownAdded
        if more != added { added = more }
        refreshDetails()
        if month(ledgerMonth) == nil { ledgerMonth = s.cm }
        if !whoRestored, let saved = UserDefaults.standard.string(forKey: Self.whoKey), let p = whoOptions.first(where: { $0.id == saved }) {
            whoRestored = true
            who = p
        }
        if !whoOptions.contains(who) { who = .family }
        // opened before the phone's first unlock: what you added comes in with the first build after the profile is read
        if !ownLoaded, let live, live.loadedFromDisk { loadSaved() }
        // a change saved on a twin the build dropped moves onto the row it kept, with the shares split off it
        if ownLoaded { carryTwins(s.carried) }
        // the reminders and the widgets follow every build, in the background too: a bill the bank's mail shows paid
        // takes its own reminders away, rung ones included. While kosh reads, builds come every few seconds, so they
        // follow the last of a run (afterBuild), not each one
        afterBuild()
    }

    /// waiting to remake the reminders and the widgets after a build (a newer build waits again)
    @ObservationIgnored private var afterBuildWork: DispatchWorkItem? = nil
    /// when the reminders and widgets were last remade
    @ObservationIgnored private var afterBuildLast: Date = .distantPast

    /// remake the reminders and the widgets shortly, once the builds settle: soon in the background (iOS may stop kosh
    /// any moment; BackgroundReading.settle does it before handing back too), a moment later on screen, and a few
    /// seconds while reading, when the next build is on its way
    func afterBuild() {
        // builds coming steadily keep pushing the wait back: after ten seconds without, it happens now
        if afterBuildWork != nil && Date().timeIntervalSince(afterBuildLast) > 10 {
            MainActor.assumeIsolated { afterBuildNow() }
            return
        }
        afterBuildWork?.cancel()
        let w = DispatchWorkItem { [weak self] in
            MainActor.assumeIsolated { self?.afterBuildNow() }
        }
        afterBuildWork = w
        let delay: Double = MainActor.assumeIsolated { () -> Double in
            if UIApplication.shared.applicationState == .background { return 0.3 }
            return readingShown ? 4 : 0.6
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + delay, execute: w)
    }

    /// the reminders and the widgets from what kosh shows now (and nothing left waiting)
    @MainActor func afterBuildNow() { Perf.shared.measure("reminders and widgets") { afterBuildNowWork() } }
    @MainActor private func afterBuildNowWork() {
        afterBuildWork?.cancel()
        afterBuildWork = nil
        afterBuildLast = Date()
        Reminders.reschedule(self)
        AutoSplit.apply(self)
        AutoNote.apply(self)
        EventReminders.schedule(self)
        PlanNotes.reschedule(self)
        BriefNotes.reschedule(self)
        WidgetLink.publish(self)
    }

    /// a bill on the calendar marked paid by you (from its reminder, or a hold on its row), for when the bank's mail
    /// hasn't shown it: the engine counts it paid (prof.paid), and its reminders go now, not at the next build. Undo,
    /// when kosh is on screen. The bundled builds have nowhere to keep it: only the reminders go.
    func markPaid(_ item: String, _ on: Bool = true, undo: Bool = false) {
        // a snooze the bill had: Undo puts it back with the bill
        let snoozed: Double? = on && undo ? Reminders.snoozeOf(item) : nil
        // the mark first: any reminders made from here on leave the bill out, even before the build that says it's paid
        if let live {
            // always called on the main thread (a button, or the reminder's answer hopped to it)
            MainActor.assumeIsolated { live.reloadIfNeeded() }
            live.markPaid(item, on)
        }
        if on { Reminders.clear(item) }
        if on && undo && live != nil {
            undoNote = UndoNote(text: "Marked as paid") { [weak self] in
                // the snooze first, so the reminders the next build makes keep the bill quiet until it rings
                if let t = snoozed, t > Date().timeIntervalSince1970 { Reminders.restoreSnooze(item, until: t) }
                self?.markPaid(item, false)
            }
        }
    }
    func refreshPeople() { live?.rebuildSoon() }

    /// Erase (Settings › Beta): everything kosh beta read and everything you set or added goes, on the disk
    /// (LiveSession.eraseAll, KoshDefaults) and on screen (the conversation, what's owed, captures, saved decisions),
    /// and setup starts again
    func erase() {
        guard let live else { return }
        // what's on screen first, saved nowhere: eraseAll then wipes the profile and the defaults they lived in
        ownLoaded = false
        userOwed = []; settledIDs = []; captures = []; upi = ""
        askThread = []; askSeed = nil; edits = [:]; editGen = [:]; undoNote = nil; applyAsk = nil; dupsDone = []
        rentMarks = [:]; shown = []
        findPreset = nil; calendarDay = nil; cardJump = nil; txStart = nil; ledgerChapter = nil
        hushed = [:]
        live.eraseAll()
        ownLoaded = true
        // always from Settings' button, on the main thread
        MainActor.assumeIsolated { DecisionBook.shared.clear() }
        who = .family
        homePath = []; txPath = []; portPath = []; propPath = []; commPath = []; peoplePath = []; insPath = []; loanPath = []; chapPath = []
        onboarded = false
    }

    /// a payment's sheet is open
    var editingTx: Bool { if case .tx = sheet { return true }; return false }

    /// a payment's sheet holds the build while it's open; when it closes (and has finished closing), one build runs
    func sheetChanged() {
        guard let live else { return }
        if editingTx {
            live.holdBuilds = true
        } else if live.holdBuilds {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) { [weak self] in
                guard let self, !self.editingTx else { return }
                // what you changed on the sheet shows in the list at once, not when the build after it lands (a
                // build takes seconds while kosh reads the year of mail)
                if !self.edits.isEmpty {
                    var t: [Txn] = self.tx, changed = false
                    for (id, e) in self.edits { if let i = t.firstIndex(where: { $0.id == id }) { t[i] = e; changed = true } }
                    if changed { self.tx = t }
                }
                self.live?.holdBuilds = false
            }
        }
    }

    /// change one payment as you see it: on an open sheet only the sheet redraws (the change waits in `edits`);
    /// elsewhere the list changes at once
    func edit(_ id: String, _ change: (inout Txn) -> Void) {
        editGen[id] = live?.buildGen ?? 0
        if editingTx, var t = txn(id) {
            change(&t)
            edits[id] = t
        } else if let i = tx.firstIndex(where: { $0.id == id }) {
            change(&tx[i])
            edits[id] = tx[i]
        }
    }

    /// Family, then each person in the household
    var whoOptions: [Person] {
        [.family] + snap.people.map { Person(id: $0.id, title: $0.id == "me" ? "You" : $0.name) }
    }
    func personFor(_ id: String) -> Person { whoOptions.first { $0.id == id } ?? .family }

    /// where you are, for feedback notes
    var screenName: String {
        if !onboarded { return "Setup" }
        if let s = sheet {
            switch s {
            case .tx: return "Payment detail"
            case .add: return "Add a spend"
            case .tag: return "Name payments"
            case .sort: return "Sort these"
            case .dups: return "Doubles"
            case .split: return "Split a bill"
            case .lend: return "Lent or borrowed"
            case .settings: return "Settings"
            case .capture: return "Add a photo or number"
            case .parser: return "Reading check"
            case .ask: return "Ask kosh"
            case .tabs: return "Tab bar"
            case .arrange: return "Arrange this tab"
            }
        }
        var s = tab.title
        switch tab {
        case .home: s += " › " + homeSub.title
        case .transactions: s += " › " + txSub.title
        case .portfolio: s += " › " + portSub.title
        case .property: s += " › " + propSub.title
        case .committees: s += " › " + commSub.title
        default: break
        }
        let path: [Route] = {
            switch tab {
            case .home: return homePath
            case .transactions: return txPath
            case .portfolio: return portPath
            case .property: return propPath
            case .committees: return commPath
            case .people: return peoplePath
            case .insurance: return insPath
            case .loans: return loanPath
            case .chapters: return chapPath
            }
        }()
        if let last = path.last {
            switch last {
            case .month(let m): s += " › month " + m
            case .holdings: s += " › holdings"
            case .category(let c, _): s += " › " + c
            case .committee: s += " › a committee"
            case .policy: s += " › a policy"
            case .module(let t): s += " › " + t.title
            case .account: s += " › an account"
            case .refunds: s += " › refunds"
            case .repeats: s += " › repeats"
            case .trips: s += " › trips"
            case .trip: s += " › a trip"
            case .chapter: s += " › a chapter"
            case .chapterPayments: s += " › a chapter's payments"
            case .chapterGroup: s += " › a group pass"
            case .shop: s += " › a shop"
            case .find: s += " › find"
            case .platform(let n, _, _): s += n.isEmpty ? " › spending not through an app" : " › an app's payments"
            case .calendar: s += " › calendar"
            case .deposit: s += " › a deposit"
            case .ppf: s += " › a PPF account"
            case .cover(let part): s += " › insurance, " + part.lowercased()
            case .details: s += " › your details"
            case .dividends: s += " › dividends"
            case .maturities: s += " › maturities and closures"
            case .review: s += " › month in review"
            case .wealthFunds: s += " › mutual funds"
            case .wealthDeposits: s += " › deposits"
            case .persona: s += " › understanding you"
            case .lifeEvent: s += " › a life event"
            case .personaTrip: s += " › a trip kosh found"
            case .personaPerson: s += " › a person you spend on"
            case .personaHabit: s += " › a habit"
            case .payments(_, _, let ids): s += " › " + String(ids.count) + " payments"
            case .homes: s += " › bills by home"
            case .home: s += " › a home's bills"
            case .billKind(let k): s += " › " + k.lowercased() + " bills"
            }
        }
        return s
    }

    /// what goes at the top of shared feedback: counts only, no money
    var betaContext: String {
        guard let l = live else { return "kosh (snapshot build)" }
        let v = UIDevice.current.systemVersion
        return "iOS \(v) · \(l.readCount) emails read since \(l.scanFrom) · \(l.ruleCount) by rules · \(l.claudeRead) by smart reading · \(l.waitingCount) waiting · \(l.agreeCount) agree · \(l.differs.count) differ · \(snap.tx.count) payments · \(snap.accounts.count) accounts · \(snap.cards.count) cards"
    }

    private func loadSaved() {
        if let live {
            // from the profile, once it has been read (Store.apply takes them when it is)
            guard live.loadedFromDisk else { return }
            let own: LiveSession.MoneyBits = live.own
            ownLoaded = false
            userOwed = own.owed
            settledIDs = Set(own.settled)
            captures = own.captures
            upi = own.upi
            hushed = own.hushed
            ownLoaded = true
            return
        }
        userOwed = Saved.load(key("owed"), [OwedItem]())
        settledIDs = Set(Saved.load(key("settled"), [String]()))
        captures = Saved.load(key("captures"), [Capture]())
        upi = Saved.ud.string(forKey: key("upi")) ?? (demo ? "aarav.mehta@okaxis" : "")
    }

    /// swap between the family's figures and the made-up household
    func setDemo(_ on: Bool) {
        guard on != demo, !on || Snapshot.hasDemo else { return }
        demo = on
        let s = Snapshot.load(on ? "demo" : "kosh")
        snap.replace(with: s)
        tx = s.tx.filter { $0.mr != true }; mirrors = s.tx.filter { $0.mr == true }
        ledgerMonth = s.cm
        added = 0
        dupsDone = []
        who = .family
        homePath = []; txPath = []; portPath = []; propPath = []; commPath = []; peoplePath = []; insPath = []; loanPath = []; chapPath = []
        loadSaved()
        refreshDetails()
    }

    // setup progress, shown on Home until everything is in
    struct SetupStep: Identifiable { let id: String; let title: String; let done: Bool; let capture: String? }
    var setupSteps: [SetupStep] {
        let home = snap.loans.first { $0.active }
        return [
            SetupStep(id: "household", title: "Household", done: true, capture: nil),
            SetupStep(id: "banks", title: "Banks and cards", done: true, capture: nil),
            SetupStep(id: "mail", title: "Money mail", done: true, capture: nil),
            SetupStep(id: "review", title: "Review what kosh found", done: true, capture: nil),
            // (locked statements have their own card on Home: whose each one is, and the details still missing)
            SetupStep(id: "cash", title: "Cash in hand", done: latest("cash") != nil, capture: "cash"),
            SetupStep(id: "loan", title: "Home loan balance", done: home.map { loanBalance($0) != nil } ?? true, capture: home.map { "loan:" + $0.id }),
            SetupStep(id: "policies", title: "Policy details", done: captures.contains { $0.kind.hasPrefix("policy:") }, capture: "policy:" + (snap.policies.first { !$0.isEnded }?.id ?? "")),
            SetupStep(id: "gold", title: "Gold and other savings", done: latest("gold") != nil || live?.userHoldings.contains(where: { $0.cls == "gold" }) == true, capture: "gold"),
            // what setup no longer stops for: property from the state's portal
            SetupStep(id: "papers", title: "Property tax from your state’s portal", done: live.map { !$0.properties.isEmpty } ?? true, capture: "papers"),
        ]
    }
}
