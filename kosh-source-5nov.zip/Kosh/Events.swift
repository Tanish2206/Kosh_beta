import Foundation
import UserNotifications

/// an event booked, followed to its day (fb 2 Nov)
enum EventWords {
    static func today() -> String { Day.iso(Date()) }
    /// " · in 96 days", " · tomorrow", " · today"; "" once it has passed
    static func countdown(_ on: String) -> String {
        let n: Int = Day.between(today(), on)
        if n < 0 { return "" }
        if n == 0 { return " · today" }
        if n == 1 { return " · tomorrow" }
        return " · in " + String(n) + " days"
    }
    /// kosh's note for an event: name, day and time, tickets and tier, venue, booking
    static func note(_ s: OrdersBook.Show, booking: String?) -> String {
        var lines: [String] = [s.name + (s.city.map { " · " + $0 } ?? "")]
        if let on = s.on { lines.append(Day.fmt(on, "EEE d MMM yyyy") + (s.time.map { ", " + $0 } ?? "") + (s.till.map { " – " + $0 } ?? "")) }
        var t: [String] = []
        if let n = s.n, n > 0 { t.append(n == 1 ? "1 ticket" : String(n) + " tickets") }
        if let tier = s.tier, !tier.isEmpty { t.append(tier) }
        if !t.isEmpty { lines.append(t.joined(separator: " · ")) }
        if let v = s.venue, !v.isEmpty { lines.append(v) }
        if let b = booking, !b.isEmpty { lines.append("Booking " + b) }
        return lines.joined(separator: "\n")
    }
}

/// reminders for the events booked: a week before (10 am), the evening before (7 pm), the morning of (9 am)
@MainActor
enum EventReminders {
    static func schedule(_ store: Store) {
        let center = UNUserNotificationCenter.current()
        let today: String = EventWords.today()
        var wanted: [UNNotificationRequest] = []
        for t in store.snap.tx where t.k == "out" && t.partOf == nil {
            guard let o = store.order(t), let s = o.show, let on = s.on, on >= today else { continue }
            let when: String = Day.fmt(on, "EEE d MMM") + (s.time.map { ", " + $0 } ?? "")
            let tickets: String = s.n.map { $0 == 1 ? " · 1 ticket" : " · " + String($0) + " tickets" } ?? ""
            let plan: [(String, Int, Int, String)] = [("week", -7, 10, "In a week: " + s.name),
                                                      ("eve", -1, 19, "Tomorrow: " + s.name),
                                                      ("day", 0, 9, "Today: " + s.name)]
            for (k, back, hour, title) in plan {
                let d: String = Day.add(on, back)
                if d < today { continue }
                var dc = Calendar.current.dateComponents([.year, .month, .day], from: Day.date(d))
                dc.hour = hour; dc.minute = 0
                let c = UNMutableNotificationContent()
                c.title = title
                c.body = when + tickets + (s.venue.map { " · " + $0 } ?? "") + (o.o.map { " · booking " + $0 } ?? "")
                c.sound = .default
                wanted.append(UNNotificationRequest(identifier: "kosh.event." + t.id + "." + k + "." + on, content: c, trigger: UNCalendarNotificationTrigger(dateMatching: dc, repeats: false)))
            }
        }
        center.getPendingNotificationRequests { pending in
            let mine: [String] = pending.map(\.identifier).filter { $0.hasPrefix("kosh.event.") }
            let keep: Set<String> = Set(wanted.map(\.identifier))
            center.removePendingNotificationRequests(withIdentifiers: mine.filter { !keep.contains($0) })
            for r in wanted where !mine.contains(r.identifier) { center.add(r) }
        }
    }
}
