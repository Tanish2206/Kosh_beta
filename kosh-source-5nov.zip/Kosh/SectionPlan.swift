import SwiftUI

// MARK: - Plan your own tab
//
// Every page that's a stack of sections draws them through PlanStack, in the order you set, without the ones you
// hid. The sliders button at the end of a tab's sub-tab row (on the top row for a tab without sub-tabs) opens
// "Arrange this tab": the page's sections, a switch each to show or hide it, a handle to drag it up or down, and
// Reset. Each page's plan is kept on the phone as a little JSON ({"order": […], "hidden": […]}) under
// "plan.<page>"; with none saved, a page is in kosh's own order. A section kosh adds later slots in after the one
// it follows by default, so a saved plan never hides something new. What stays pinned and isn't in a plan: a
// page's intro, its empty state, a problem kosh hit reading, and prompts that go once they're done.

/// a section of a page, as the Arrange sheet lists it
struct PlanSection: Identifiable, Hashable {
    let id: String
    let title: String
    let sym: String
}

/// a page whose sections can be arranged
enum PlanPage: String, CaseIterable, Identifiable {
    case homeOverview = "home.overview"
    case homeCalendar = "home.calendar"
    case txInsights = "tx.insights"
    case txRepeats = "tx.repeats"
    case portDebts = "port.debts"
    case propOverview = "prop.overview"
    case propTenants = "prop.tenants"
    case propTax = "prop.tax"
    case commHome = "comm.home"
    case people = "people"
    case insurance = "insurance"

    var id: String { rawValue }

    /// what the Arrange sheet's picker calls it
    var title: String {
        switch self {
        case .homeOverview, .propOverview: return "Overview"
        case .homeCalendar: return "Calendar"
        case .txInsights: return "Insights"
        case .txRepeats: return "Repeats"
        case .portDebts: return "Debts"
        case .propTenants: return "Tenants"
        case .propTax: return "Property tax"
        case .commHome: return "Committees"
        case .people: return "People"
        case .insurance: return "Insurance"
        }
    }

    /// its sections, in kosh's own order
    var sections: [PlanSection] {
        switch self {
        // what kosh noticed and the money threads sit behind the bell beside the sub-tabs; what needs you and what
        // kosh is chasing, on Genie
        case .homeOverview: return [
            .init(id: "setup", title: "Setting up", sym: "checklist"),
            // (no "This morning" briefing on Home: his call, 31 Oct; the morning notification still comes)
            .init(id: "worth", title: "Net worth", sym: "chart.line.uptrend.xyaxis"),
            .init(id: "goals", title: "Goals", sym: "target"),
            .init(id: "expenses", title: "Spending", sym: "creditcard"),
            .init(id: "flow", title: "Cash flow", sym: "arrow.left.arrow.right"),
            .init(id: "week", title: "This week", sym: "calendar"),
            .init(id: "trip", title: "The chapter you're in", sym: "book.pages"),
            .init(id: "also", title: "Also in kosh", sym: "square.grid.2x2"),
        ]
        case .homeCalendar: return [
            .init(id: "tally", title: "Still to go out, still to come in", sym: "plusminus"),
            .init(id: "days", title: "The next six weeks", sym: "calendar.day.timeline.left"),
            .init(id: "committees", title: "Committees this month", sym: "circle.dotted.circle"),
            .init(id: "later", title: "Later", sym: "clock"),
            .init(id: "year", title: "Later this year", sym: "calendar.badge.clock"),
        ]
        case .txInsights: return [
            .init(id: "pace", title: "This month's pace", sym: "speedometer"),
            .init(id: "paid", title: "How you paid", sym: "creditcard"),
            .init(id: "shops", title: "Where you shop", sym: "bag"),
            .init(id: "review", title: "Month in review", sym: "sparkles.rectangle.stack"),
            .init(id: "you", title: "Understanding you", sym: "person.text.rectangle"),
            .init(id: "homes", title: "Bills by home", sym: "house"),
            .init(id: "where", title: "Where it goes", sym: "chart.pie"),
            .init(id: "repeats", title: "Repeats", sym: "arrow.triangle.2.circlepath"),
            .init(id: "grid", title: "Category by month", sym: "tablecells"),
            .init(id: "close", title: "Up close", sym: "magnifyingglass"),
            .init(id: "keep", title: "What you keep", sym: "banknote"),
            .init(id: "budgets", title: "Budgets", sym: "gauge.with.dots.needle.33percent"),
            .init(id: "look", title: "Worth a look", sym: "lightbulb"),
        ]
        case .txRepeats: return [
            .init(id: "hero", title: "On autopilot every month", sym: "arrow.triangle.2.circlepath"),
            .init(id: "days", title: "When they come", sym: "calendar"),
            .init(id: "next", title: "Coming next", sym: "forward"),
            .init(id: "usual", title: "The usual suspects", sym: "list.bullet"),
        ]
        case .portDebts: return [
            .init(id: "head", title: "EMIs a month", sym: "building.columns"),
            .init(id: "active", title: "Loans running", sym: "list.bullet.rectangle"),
            .init(id: "closed", title: "Closed", sym: "checkmark.circle"),
        ]
        case .propOverview: return [
            .init(id: "head", title: "Rent, tax and land", sym: "building.2"),
            .init(id: "alerts", title: "Late rent", sym: "exclamationmark.triangle"),
            .init(id: "props", title: "Each property", sym: "house"),
            .init(id: "events", title: "What changes when", sym: "calendar.badge.clock"),
        ]
        case .propTenants: return [
            .init(id: "street", title: "The street", sym: "moon.stars"),
            .init(id: "rent", title: "This month's rent, and each building's tenants", sym: "indianrupeesign.circle"),
        ]
        case .propTax: return [
            .init(id: "hero", title: "Tax due", sym: "building.columns"),
            .init(id: "tiles", title: "What it's made of", sym: "rectangle.grid.2x2"),
            .init(id: "each", title: "Each property", sym: "house"),
            .init(id: "trend", title: "Over the years", sym: "chart.bar"),
            .init(id: "table", title: "The table", sym: "tablecells"),
            .init(id: "notes", title: "Worth knowing", sym: "lightbulb"),
        ]
        case .commHome: return [
            .init(id: "month", title: "This month", sym: "circle.dotted.circle"),
            .init(id: "instalments", title: "This month's instalments", sym: "checklist"),
            .init(id: "ahead", title: "Cash a year ahead", sym: "chart.bar"),
            .init(id: "earned", title: "What they've earned", sym: "chart.line.uptrend.xyaxis"),
            .init(id: "book", title: "The book", sym: "book.closed"),
            .init(id: "done", title: "Finished", sym: "checkmark.circle"),
        ]
        case .people: return [
            .init(id: "tiles", title: "Owed and owing", sym: "plusminus"),
            .init(id: "actions", title: "Split a bill, lent or borrowed", sym: "person.2"),
            .init(id: "settle", title: "Settle up in one", sym: "equal.circle"),
            .init(id: "toYou", title: "Owed to you", sym: "arrow.down.left"),
            .init(id: "youOwe", title: "You owe", sym: "arrow.up.right"),
            .init(id: "settled", title: "Settled", sym: "checkmark.circle"),
        ]
        case .insurance: return [
            .init(id: "head", title: "Premiums a year", sym: "shield.lefthalf.filled"),
            .init(id: "papers", title: "Policy papers in your mail", sym: "doc.text"),
            .init(id: "policies", title: "Your policies, by kind", sym: "list.bullet.rectangle"),
        ]
        }
    }

    /// the pages a tab can arrange, in its sub-tabs' order
    static func pages(_ tab: AppTab) -> [PlanPage] {
        switch tab {
        case .home: return [.homeOverview, .homeCalendar]
        case .transactions: return [.txInsights, .txRepeats]
        // (Wealth's Overview is one drawing, WealthHome: nothing to arrange)
        case .portfolio: return [.portDebts]
        case .property: return [.propOverview, .propTenants, .propTax]
        case .committees: return [.commHome]
        case .people: return [.people]
        // (Insurance's parts keep their order, Health, Life, Motor, Needs a look: nothing to arrange)
        case .insurance: return []
        case .loans: return [.portDebts]
        case .chapters: return []
        }
    }

    /// the page a tab is showing, when it can be arranged
    @MainActor static func showing(_ tab: AppTab, _ store: Store) -> PlanPage? {
        switch tab {
        case .home: return store.homeSub == .overview ? .homeOverview : nil
        case .transactions:
            switch store.txSub {
            case .insights: return .txInsights
            default: return nil
            }
        case .portfolio:
            switch store.portSub {
            case .loans: return .portDebts
            default: return nil
            }
        case .property:
            switch store.propSub {
            case .overview: return .propOverview
            case .tenants: return .propTenants
            case .tax: return .propTax
            }
        case .committees: return .commHome
        case .people: return .people
        case .insurance: return nil
        case .loans: return .portDebts
        case .chapters: return nil
        }
    }
}

/// a page's plan: kept as JSON on the phone, merged with the page's sections as kosh has them now
enum SectionPlan {
    struct Saved: Codable, Equatable {
        var order: [String] = []
        var hidden: [String] = []
    }

    static func key(_ p: PlanPage) -> String { "plan." + p.rawValue }

    static func decode(_ raw: String) -> Saved {
        guard !raw.isEmpty, let d = raw.data(using: .utf8), let s = try? JSONDecoder().decode(Saved.self, from: d) else { return Saved() }
        return s
    }
    static func encode(_ s: Saved) -> String {
        guard let d = try? JSONEncoder().encode(s) else { return "" }
        return String(decoding: d, as: UTF8.self)
    }

    /// every section in plan order: the saved order, less what kosh no longer has, with anything new slotted in
    /// after the section it follows by default
    static func order(_ p: PlanPage, _ s: Saved) -> [String] {
        let all: [String] = p.sections.map(\.id)
        var out: [String] = []
        // what's saved, once each, and only what the page still has
        for id in s.order where all.contains(id) && !out.contains(id) { out.append(id) }
        for (i, id) in all.enumerated() where !out.contains(id) {
            let before: String? = all[..<i].last { out.contains($0) }
            if let b = before, let at = out.firstIndex(of: b) { out.insert(id, at: at + 1) } else { out.insert(id, at: 0) }
        }
        return out
    }

    /// the sections drawn: in plan order, the hidden ones left out
    static func shown(_ p: PlanPage, raw: String) -> [String] {
        let s: Saved = decode(raw)
        let hidden: Set<String> = Set(s.hidden)
        return order(p, s).filter { !hidden.contains($0) }
    }
}

// MARK: drawing a page by its plan

/// a page's sections, one under the next, in the order you set and without the ones you hid
struct PlanStack<Content: View>: View {
    let page: PlanPage
    let spacing: CGFloat
    let section: (String) -> Content
    @AppStorage private var raw: String

    init(_ page: PlanPage, spacing: CGFloat = 0, @ViewBuilder section: @escaping (String) -> Content) {
        self.page = page
        self.spacing = spacing
        self.section = section
        _raw = AppStorage(wrappedValue: "", SectionPlan.key(page))
    }

    var body: some View {
        VStack(alignment: .leading, spacing: spacing) {
            ForEach(SectionPlan.shown(page, raw: raw), id: \.self) { id in section(id) }
        }
    }
}

/// the same, for a page that's a List: each section becomes its List section(s), in plan order
struct PlanSections<Content: View>: View {
    let page: PlanPage
    let section: (String) -> Content
    @AppStorage private var raw: String

    init(_ page: PlanPage, @ViewBuilder section: @escaping (String) -> Content) {
        self.page = page
        self.section = section
        _raw = AppStorage(wrappedValue: "", SectionPlan.key(page))
    }

    var body: some View {
        ForEach(SectionPlan.shown(page, raw: raw), id: \.self) { id in section(id) }
    }
}

// MARK: the button

extension HeaderAction {
    /// the sliders circle on the top row of a tab with no sub-tabs
    static func arrange(_ tab: AppTab, run: @escaping () -> Void) -> HeaderAction {
        HeaderAction(title: "Arrange this tab", symbol: "slider.horizontal.3", run: run)
    }
}

/// the sliders circle that opens "Arrange this tab"
struct ArrangeButton: View {
    @Environment(Store.self) private var store
    let tab: AppTab
    var body: some View {
        Button { store.sheet = .arrange(tab) } label: { HeaderCircle(symbol: "slider.horizontal.3") }
            .buttonStyle(.press)
            .accessibilityLabel("Arrange this tab")
            .accessibilityHint("Show, hide and reorder this page’s sections")
    }
}

// MARK: - Arrange this tab

struct ArrangeSheet: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    let tab: AppTab
    @State private var page: PlanPage
    @State private var plan = SectionPlan.Saved()
    @State private var loaded = false

    init(tab: AppTab, page: PlanPage) {
        self.tab = tab
        _page = State(initialValue: page)
    }

    var body: some View {
        let pages: [PlanPage] = PlanPage.pages(tab)
        let order: [String] = SectionPlan.order(page, plan)
        let byID: [String: PlanSection] = Dictionary(uniqueKeysWithValues: page.sections.map { ($0.id, $0) })
        let shown: Int = order.filter { !plan.hidden.contains($0) }.count
        let head: String = page.title + " · " + String(shown) + " of " + String(order.count) + " shown"
        NavigationStack {
            ObsidianList {
                if pages.count > 1 {
                    Section {
                        Picker("Page", selection: $page) {
                            ForEach(pages) { p in Text(p.title).tag(p) }
                        }
                        .pickerStyle(.segmented)
                        .listRowBackground(Color.clear)
                        .listRowInsets(EdgeInsets(top: 4, leading: 0, bottom: 4, trailing: 0))
                    }
                }
                Section {
                    rows(order, byID: byID, last: shown == 1)
                } header: {
                    Text(head)
                } footer: {
                    Text("Drag a section up or down; switch one off to hide it. Hidden ones wait here until you want them back.")
                }
                Section {
                    Button("Back to kosh’s order", role: .destructive) { reset() }
                        .disabled(plan == SectionPlan.Saved())
                }
            }
            .environment(\.editMode, .constant(.active))
            .navigationTitle("Arrange this tab")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") { dismiss() }
                }
            }
            .onAppear { load() }
            .onChange(of: page) { _, _ in loaded = false; load() }
            .sensoryFeedback(.selection, trigger: plan)
        }
    }

    /// a row a section, in plan order, each with its switch; drag to reorder
    func rows(_ order: [String], byID: [String: PlanSection], last: Bool) -> some View {
        ForEach(order, id: \.self) { id in
            if let s = byID[id] {
                ArrangeRow(section: s, on: !plan.hidden.contains(id), last: last) { on in set(id, on: on) }
            }
        }
        .onMove { from, to in move(order, from: from, to: to) }
    }

    func load() {
        guard !loaded else { return }
        loaded = true
        plan = SectionPlan.decode(UserDefaults.standard.string(forKey: SectionPlan.key(page)) ?? "")
    }
    func save() {
        let raw: String = plan == SectionPlan.Saved() ? "" : SectionPlan.encode(plan)
        UserDefaults.standard.set(raw, forKey: SectionPlan.key(page))
    }
    func set(_ id: String, on: Bool) {
        withAnimation(Motion.open) {
            if on { plan.hidden.removeAll { $0 == id } } else if !plan.hidden.contains(id) { plan.hidden.append(id) }
        }
        save()
    }
    func move(_ order: [String], from: IndexSet, to: Int) {
        var o: [String] = order
        o.move(fromOffsets: from, toOffset: to)
        plan.order = o
        save()
    }
    func reset() {
        withAnimation(Motion.open) { plan = SectionPlan.Saved() }
        save()
    }
}

struct ArrangeRow: View {
    let section: PlanSection
    let on: Bool
    /// the only one still showing: it can't be switched off, or the page would be blank
    let last: Bool
    let set: (Bool) -> Void
    var body: some View {
        HStack(spacing: 12) {
            IconTile(symbol: section.sym, color: on ? Color.kosh : Color.gray, size: 30)
            Text(section.title)
                .foregroundStyle(on ? Color.primary : Color.secondary)
                .lineLimit(2)
            Spacer(minLength: 8)
            Toggle(section.title, isOn: Binding(get: { on }, set: { set($0) }))
                .labelsHidden()
                .disabled(on && last)
        }
        .accessibilityElement(children: .combine)
    }
}
