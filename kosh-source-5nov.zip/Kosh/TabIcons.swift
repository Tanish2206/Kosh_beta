import SwiftUI

// MARK: - kosh's own tab icons
//
// Drawn rather than SF Symbols: one shape per tab on a 24-point grid, outline while not chosen, solid once chosen.
// `on` runs 0…1, so the bar can fill an icon in as you swipe towards its page. Details (the receipt's lines, the
// windows, the tick, the book's spine) are lines on the outline and cut through the solid, so the glass shows
// through them. Chosen 5 Nov 2026 from the icon board: Home A arch door, Transactions A receipt, Wealth E sprout,
// Property A two blocks, Committees B circle of members, People A two people, Insurance A shield tick,
// Loans A bank, Chapters A open book. The paths are the board's SVG, converted point for point.

struct KoshGlyph: View {
    let tab: AppTab
    /// 0 outline … 1 solid
    var on: CGFloat = 0
    var size: CGFloat = 24

    var body: some View {
        let g: KoshGlyphs.Parts = KoshGlyphs.parts(tab)
        let st = StrokeStyle(lineWidth: 1.7 * size / 24, lineCap: .round, lineJoin: .round)
        // the fill arrives over the middle of a swipe rather than as a grey wash across all of it
        let solid: CGFloat = min(1, max(0, (on - 0.35) / 0.3))
        ZStack {
            GlyphShape(path: g.fill).fill(.foreground).opacity(solid)
            GlyphShape(path: g.fill).stroke(.foreground, style: st)
            GlyphShape(path: g.line).stroke(.foreground, style: st)
            GlyphShape(path: g.detail).stroke(.foreground, style: st).opacity(1 - solid)
            GlyphShape(path: g.detail).stroke(Color.black, style: st).opacity(solid).blendMode(.destinationOut)
        }
        .compositingGroup()
        .frame(width: size, height: size)
        .accessibilityHidden(true)
    }
}

/// a path drawn on the 24-point grid, scaled to whatever it's given
struct GlyphShape: Shape {
    let path: Path
    func path(in r: CGRect) -> Path {
        path.applying(CGAffineTransform(a: r.width / 24, b: 0, c: 0, d: r.height / 24, tx: r.minX, ty: r.minY))
    }
}

enum KoshGlyphs {
    struct Parts {
        /// the outline, filled once chosen
        var fill = Path()
        /// lines inside the shape: drawn on the outline, cut out of the solid
        var detail = Path()
        /// lines outside the shape, always lines
        var line = Path()
    }

    static func parts(_ t: AppTab) -> Parts { all[t] ?? Parts() }

    private static let all: [AppTab: Parts] = Dictionary(uniqueKeysWithValues: AppTab.allCases.map { ($0, make($0)) })

    private static func p(_ x: CGFloat, _ y: CGFloat) -> CGPoint { CGPoint(x: x, y: y) }
    private static func draw(_ build: (inout Path) -> Void) -> Path {
        var g = Path()
        build(&g)
        return g
    }

    private static func make(_ t: AppTab) -> Parts {
        var fill = Path()
        var detail = Path()
        var line = Path()
        switch t {
        case .home:
            fill = draw { g in g.move(to: p(4, 10.4)); g.addLine(to: p(12, 4)); g.addLine(to: p(20, 10.4)); g.addLine(to: p(20, 19)); g.addCurve(to: p(19.799, 19.75), control1: p(20, 19.263), control2: p(19.931, 19.522)); g.addCurve(to: p(19.25, 20.299), control1: p(19.667, 19.978), control2: p(19.478, 20.167)); g.addCurve(to: p(18.5, 20.5), control1: p(19.022, 20.431), control2: p(18.763, 20.5)); g.addLine(to: p(15, 20.5)); g.addLine(to: p(15, 15.9)); g.addCurve(to: p(14.598, 14.4), control1: p(15, 15.373), control2: p(14.861, 14.856)); g.addCurve(to: p(13.5, 13.302), control1: p(14.335, 13.944), control2: p(13.956, 13.565)); g.addCurve(to: p(12, 12.9), control1: p(13.044, 13.039), control2: p(12.527, 12.9)); g.addCurve(to: p(10.5, 13.302), control1: p(11.473, 12.9), control2: p(10.956, 13.039)); g.addCurve(to: p(9.402, 14.4), control1: p(10.044, 13.565), control2: p(9.665, 13.944)); g.addCurve(to: p(9, 15.9), control1: p(9.139, 14.856), control2: p(9, 15.373)); g.addLine(to: p(9, 20.5)); g.addLine(to: p(5.5, 20.5)); g.addCurve(to: p(4.75, 20.299), control1: p(5.237, 20.5), control2: p(4.978, 20.431)); g.addCurve(to: p(4.201, 19.75), control1: p(4.522, 20.167), control2: p(4.333, 19.978)); g.addCurve(to: p(4, 19), control1: p(4.069, 19.522), control2: p(4, 19.263)); g.closeSubpath() }
        case .transactions:
            fill = draw { g in g.move(to: p(6, 3.5)); g.addLine(to: p(18, 3.5)); g.addLine(to: p(18, 20.5)); g.addLine(to: p(16, 19.1)); g.addLine(to: p(14, 20.5)); g.addLine(to: p(12, 19.1)); g.addLine(to: p(10, 20.5)); g.addLine(to: p(8, 19.1)); g.addLine(to: p(6, 20.5)); g.closeSubpath() }
            detail = draw { g in g.move(to: p(9, 8.5)); g.addLine(to: p(15, 8.5)); g.move(to: p(9, 12)); g.addLine(to: p(15, 12)); g.move(to: p(9, 15.5)); g.addLine(to: p(12.5, 15.5)) }
        case .portfolio:
            fill = draw { g in g.move(to: p(12, 11)); g.addCurve(to: p(5, 4.5), control1: p(12, 7), control2: p(9.5, 4.5)); g.addCurve(to: p(12, 11), control1: p(5, 8.5), control2: p(7.5, 11)); g.closeSubpath(); g.move(to: p(12, 13.5)); g.addCurve(to: p(18.5, 7.7), control1: p(12, 10), control2: p(14.3, 7.7)); g.addCurve(to: p(12, 13.5), control1: p(18.5, 11.2), control2: p(16.2, 13.5)); g.closeSubpath() }
            line = draw { g in g.move(to: p(12, 20.5)); g.addLine(to: p(12, 11)) }
        case .property:
            fill = draw { g in g.move(to: p(4, 20.5)); g.addLine(to: p(4, 8.6)); g.addLine(to: p(10, 5.5)); g.addLine(to: p(10, 20.5)); g.closeSubpath(); g.move(to: p(10, 20.5)); g.addLine(to: p(10, 10.5)); g.addLine(to: p(20, 10.5)); g.addLine(to: p(20, 20.5)); g.closeSubpath() }
            detail = draw { g in g.move(to: p(13, 13.8)); g.addLine(to: p(14, 13.8)); g.move(to: p(16.5, 13.8)); g.addLine(to: p(17.5, 13.8)); g.move(to: p(13, 17)); g.addLine(to: p(14, 17)); g.move(to: p(16.5, 17)); g.addLine(to: p(17.5, 17)); g.move(to: p(6.6, 10.8)); g.addLine(to: p(7.6, 10.8)); g.move(to: p(6.6, 14)); g.addLine(to: p(7.6, 14)) }
        case .committees:
            fill = draw { g in g.move(to: p(9.4, 12)); g.addCurve(to: p(9.657, 13.128), control1: p(9.4, 12.391), control2: p(9.488, 12.776)); g.addCurve(to: p(10.379, 14.033), control1: p(9.827, 13.48), control2: p(10.074, 13.789)); g.addCurve(to: p(11.421, 14.535), control1: p(10.684, 14.276), control2: p(11.041, 14.448)); g.addCurve(to: p(12.579, 14.535), control1: p(11.802, 14.622), control2: p(12.198, 14.622)); g.addCurve(to: p(13.621, 14.033), control1: p(12.959, 14.448), control2: p(13.316, 14.276)); g.addCurve(to: p(14.343, 13.128), control1: p(13.926, 13.789), control2: p(14.173, 13.48)); g.addCurve(to: p(14.6, 12), control1: p(14.512, 12.776), control2: p(14.6, 12.391)); g.addCurve(to: p(14.343, 10.872), control1: p(14.6, 11.609), control2: p(14.512, 11.224)); g.addCurve(to: p(13.621, 9.967), control1: p(14.173, 10.52), control2: p(13.926, 10.211)); g.addCurve(to: p(12.579, 9.465), control1: p(13.316, 9.724), control2: p(12.959, 9.552)); g.addCurve(to: p(11.421, 9.465), control1: p(12.198, 9.378), control2: p(11.802, 9.378)); g.addCurve(to: p(10.379, 9.967), control1: p(11.041, 9.552), control2: p(10.684, 9.724)); g.addCurve(to: p(9.657, 10.872), control1: p(10.074, 10.211), control2: p(9.827, 10.52)); g.addCurve(to: p(9.4, 12), control1: p(9.488, 11.224), control2: p(9.4, 11.609)); g.closeSubpath(); g.move(to: p(17.3, 12)); g.addCurve(to: p(17.468, 12.738), control1: p(17.3, 12.255), control2: p(17.358, 12.508)); g.addCurve(to: p(17.94, 13.329), control1: p(17.579, 12.968), control2: p(17.74, 13.17)); g.addCurve(to: p(18.622, 13.657), control1: p(18.14, 13.488), control2: p(18.373, 13.601)); g.addCurve(to: p(19.378, 13.657), control1: p(18.871, 13.714), control2: p(19.129, 13.714)); g.addCurve(to: p(20.06, 13.329), control1: p(19.627, 13.601), control2: p(19.86, 13.488)); g.addCurve(to: p(20.532, 12.738), control1: p(20.26, 13.17), control2: p(20.421, 12.968)); g.addCurve(to: p(20.7, 12), control1: p(20.642, 12.508), control2: p(20.7, 12.255)); g.addCurve(to: p(20.532, 11.262), control1: p(20.7, 11.745), control2: p(20.642, 11.492)); g.addCurve(to: p(20.06, 10.671), control1: p(20.421, 11.032), control2: p(20.26, 10.83)); g.addCurve(to: p(19.378, 10.343), control1: p(19.86, 10.512), control2: p(19.627, 10.399)); g.addCurve(to: p(18.622, 10.343), control1: p(19.129, 10.286), control2: p(18.871, 10.286)); g.addCurve(to: p(17.94, 10.671), control1: p(18.373, 10.399), control2: p(18.14, 10.512)); g.addCurve(to: p(17.468, 11.262), control1: p(17.74, 10.83), control2: p(17.579, 11.032)); g.addCurve(to: p(17.3, 12), control1: p(17.358, 11.492), control2: p(17.3, 11.745)); g.closeSubpath(); g.move(to: p(13.8, 18.06)); g.addCurve(to: p(13.968, 18.798), control1: p(13.8, 18.315), control2: p(13.858, 18.568)); g.addCurve(to: p(14.44, 19.389), control1: p(14.079, 19.028), control2: p(14.24, 19.23)); g.addCurve(to: p(15.122, 19.717), control1: p(14.64, 19.548), control2: p(14.873, 19.661)); g.addCurve(to: p(15.878, 19.717), control1: p(15.371, 19.774), control2: p(15.629, 19.774)); g.addCurve(to: p(16.56, 19.389), control1: p(16.127, 19.661), control2: p(16.36, 19.548)); g.addCurve(to: p(17.032, 18.798), control1: p(16.76, 19.23), control2: p(16.921, 19.028)); g.addCurve(to: p(17.2, 18.06), control1: p(17.142, 18.568), control2: p(17.2, 18.315)); g.addCurve(to: p(17.032, 17.322), control1: p(17.2, 17.805), control2: p(17.142, 17.552)); g.addCurve(to: p(16.56, 16.731), control1: p(16.921, 17.092), control2: p(16.76, 16.89)); g.addCurve(to: p(15.878, 16.403), control1: p(16.36, 16.572), control2: p(16.127, 16.459)); g.addCurve(to: p(15.122, 16.403), control1: p(15.629, 16.346), control2: p(15.371, 16.346)); g.addCurve(to: p(14.44, 16.731), control1: p(14.873, 16.459), control2: p(14.64, 16.572)); g.addCurve(to: p(13.968, 17.322), control1: p(14.24, 16.89), control2: p(14.079, 17.092)); g.addCurve(to: p(13.8, 18.06), control1: p(13.858, 17.552), control2: p(13.8, 17.805)); g.closeSubpath(); g.move(to: p(6.8, 18.06)); g.addCurve(to: p(6.968, 18.798), control1: p(6.8, 18.315), control2: p(6.858, 18.568)); g.addCurve(to: p(7.44, 19.389), control1: p(7.079, 19.028), control2: p(7.24, 19.23)); g.addCurve(to: p(8.122, 19.717), control1: p(7.64, 19.548), control2: p(7.873, 19.661)); g.addCurve(to: p(8.878, 19.717), control1: p(8.371, 19.774), control2: p(8.629, 19.774)); g.addCurve(to: p(9.56, 19.389), control1: p(9.127, 19.661), control2: p(9.36, 19.548)); g.addCurve(to: p(10.032, 18.798), control1: p(9.76, 19.23), control2: p(9.921, 19.028)); g.addCurve(to: p(10.2, 18.06), control1: p(10.142, 18.568), control2: p(10.2, 18.315)); g.addCurve(to: p(10.032, 17.322), control1: p(10.2, 17.805), control2: p(10.142, 17.552)); g.addCurve(to: p(9.56, 16.731), control1: p(9.921, 17.092), control2: p(9.76, 16.89)); g.addCurve(to: p(8.878, 16.403), control1: p(9.36, 16.572), control2: p(9.127, 16.459)); g.addCurve(to: p(8.122, 16.403), control1: p(8.629, 16.346), control2: p(8.371, 16.346)); g.addCurve(to: p(7.44, 16.731), control1: p(7.873, 16.459), control2: p(7.64, 16.572)); g.addCurve(to: p(6.968, 17.322), control1: p(7.24, 16.89), control2: p(7.079, 17.092)); g.addCurve(to: p(6.8, 18.06), control1: p(6.858, 17.552), control2: p(6.8, 17.805)); g.closeSubpath(); g.move(to: p(3.3, 12)); g.addCurve(to: p(3.468, 12.738), control1: p(3.3, 12.255), control2: p(3.358, 12.508)); g.addCurve(to: p(3.94, 13.329), control1: p(3.579, 12.968), control2: p(3.74, 13.17)); g.addCurve(to: p(4.622, 13.657), control1: p(4.14, 13.488), control2: p(4.373, 13.601)); g.addCurve(to: p(5.378, 13.657), control1: p(4.871, 13.714), control2: p(5.129, 13.714)); g.addCurve(to: p(6.06, 13.329), control1: p(5.627, 13.601), control2: p(5.86, 13.488)); g.addCurve(to: p(6.532, 12.738), control1: p(6.26, 13.17), control2: p(6.421, 12.968)); g.addCurve(to: p(6.7, 12), control1: p(6.642, 12.508), control2: p(6.7, 12.255)); g.addCurve(to: p(6.472, 11.15), control1: p(6.7, 11.702), control2: p(6.621, 11.408)); g.addCurve(to: p(5.85, 10.528), control1: p(6.323, 10.892), control2: p(6.108, 10.677)); g.addCurve(to: p(5, 10.3), control1: p(5.592, 10.379), control2: p(5.298, 10.3)); g.addCurve(to: p(4.15, 10.528), control1: p(4.702, 10.3), control2: p(4.408, 10.379)); g.addCurve(to: p(3.528, 11.15), control1: p(3.892, 10.677), control2: p(3.677, 10.892)); g.addCurve(to: p(3.3, 12), control1: p(3.379, 11.408), control2: p(3.3, 11.702)); g.closeSubpath(); g.move(to: p(6.8, 5.94)); g.addCurve(to: p(6.968, 6.678), control1: p(6.8, 6.195), control2: p(6.858, 6.448)); g.addCurve(to: p(7.44, 7.269), control1: p(7.079, 6.908), control2: p(7.24, 7.11)); g.addCurve(to: p(8.122, 7.597), control1: p(7.64, 7.428), control2: p(7.873, 7.541)); g.addCurve(to: p(8.878, 7.597), control1: p(8.371, 7.654), control2: p(8.629, 7.654)); g.addCurve(to: p(9.56, 7.269), control1: p(9.127, 7.541), control2: p(9.36, 7.428)); g.addCurve(to: p(10.032, 6.678), control1: p(9.76, 7.11), control2: p(9.921, 6.908)); g.addCurve(to: p(10.2, 5.94), control1: p(10.142, 6.448), control2: p(10.2, 6.195)); g.addCurve(to: p(10.032, 5.202), control1: p(10.2, 5.685), control2: p(10.142, 5.432)); g.addCurve(to: p(9.56, 4.611), control1: p(9.921, 4.972), control2: p(9.76, 4.77)); g.addCurve(to: p(8.878, 4.283), control1: p(9.36, 4.452), control2: p(9.127, 4.339)); g.addCurve(to: p(8.122, 4.283), control1: p(8.629, 4.226), control2: p(8.371, 4.226)); g.addCurve(to: p(7.44, 4.611), control1: p(7.873, 4.339), control2: p(7.64, 4.452)); g.addCurve(to: p(6.968, 5.202), control1: p(7.24, 4.77), control2: p(7.079, 4.972)); g.addCurve(to: p(6.8, 5.94), control1: p(6.858, 5.432), control2: p(6.8, 5.685)); g.closeSubpath(); g.move(to: p(13.8, 5.94)); g.addCurve(to: p(13.968, 6.678), control1: p(13.8, 6.195), control2: p(13.858, 6.448)); g.addCurve(to: p(14.44, 7.269), control1: p(14.079, 6.908), control2: p(14.24, 7.11)); g.addCurve(to: p(15.122, 7.597), control1: p(14.64, 7.428), control2: p(14.873, 7.541)); g.addCurve(to: p(15.878, 7.597), control1: p(15.371, 7.654), control2: p(15.629, 7.654)); g.addCurve(to: p(16.56, 7.269), control1: p(16.127, 7.541), control2: p(16.36, 7.428)); g.addCurve(to: p(17.032, 6.678), control1: p(16.76, 7.11), control2: p(16.921, 6.908)); g.addCurve(to: p(17.2, 5.94), control1: p(17.142, 6.448), control2: p(17.2, 6.195)); g.addCurve(to: p(17.032, 5.202), control1: p(17.2, 5.685), control2: p(17.142, 5.432)); g.addCurve(to: p(16.56, 4.611), control1: p(16.921, 4.972), control2: p(16.76, 4.77)); g.addCurve(to: p(15.878, 4.283), control1: p(16.36, 4.452), control2: p(16.127, 4.339)); g.addCurve(to: p(15.122, 4.283), control1: p(15.629, 4.226), control2: p(15.371, 4.226)); g.addCurve(to: p(14.44, 4.611), control1: p(14.873, 4.339), control2: p(14.64, 4.452)); g.addCurve(to: p(13.968, 5.202), control1: p(14.24, 4.77), control2: p(14.079, 4.972)); g.addCurve(to: p(13.8, 5.94), control1: p(13.858, 5.432), control2: p(13.8, 5.685)); g.closeSubpath() }
        case .people:
            fill = draw { g in g.move(to: p(5.8, 8)); g.addCurve(to: p(6.117, 9.388), control1: p(5.8, 8.481), control2: p(5.908, 8.955)); g.addCurve(to: p(7.005, 10.502), control1: p(6.325, 9.822), control2: p(6.629, 10.202)); g.addCurve(to: p(8.288, 11.12), control1: p(7.381, 10.802), control2: p(7.819, 11.013)); g.addCurve(to: p(9.712, 11.12), control1: p(8.757, 11.227), control2: p(9.243, 11.227)); g.addCurve(to: p(10.995, 10.502), control1: p(10.181, 11.013), control2: p(10.619, 10.802)); g.addCurve(to: p(11.883, 9.388), control1: p(11.371, 10.202), control2: p(11.675, 9.822)); g.addCurve(to: p(12.2, 8), control1: p(12.092, 8.955), control2: p(12.2, 8.481)); g.addCurve(to: p(11.771, 6.4), control1: p(12.2, 7.438), control2: p(12.052, 6.886)); g.addCurve(to: p(10.6, 5.229), control1: p(11.49, 5.914), control2: p(11.086, 5.51)); g.addCurve(to: p(9, 4.8), control1: p(10.114, 4.948), control2: p(9.562, 4.8)); g.addCurve(to: p(7.4, 5.229), control1: p(8.438, 4.8), control2: p(7.886, 4.948)); g.addCurve(to: p(6.229, 6.4), control1: p(6.914, 5.51), control2: p(6.51, 5.914)); g.addCurve(to: p(5.8, 8), control1: p(5.948, 6.886), control2: p(5.8, 7.438)); g.closeSubpath(); g.move(to: p(3.5, 19.5)); g.addCurve(to: p(9, 14), control1: p(3.5, 16.2), control2: p(6, 14)); g.addCurve(to: p(14.5, 19.5), control1: p(12, 14), control2: p(14.5, 16.2)); g.closeSubpath() }
            line = draw { g in g.move(to: p(15.5, 4.9)); g.addCurve(to: p(16.745, 5.533), control1: p(15.957, 5.017), control2: p(16.382, 5.233)); g.addCurve(to: p(17.601, 6.637), control1: p(17.108, 5.834), control2: p(17.401, 6.21)); g.addCurve(to: p(17.906, 8), control1: p(17.802, 7.063), control2: p(17.906, 7.529)); g.addCurve(to: p(17.601, 9.363), control1: p(17.906, 8.471), control2: p(17.802, 8.937)); g.addCurve(to: p(16.745, 10.467), control1: p(17.401, 9.79), control2: p(17.108, 10.166)); g.addCurve(to: p(15.5, 11.1), control1: p(16.382, 10.767), control2: p(15.957, 10.983)); g.move(to: p(17, 14.3)); g.addCurve(to: p(20.5, 19.5), control1: p(19, 14.9), control2: p(20.5, 16.8)) }
        case .insurance:
            fill = draw { g in g.move(to: p(12, 3.5)); g.addLine(to: p(19, 6)); g.addLine(to: p(19, 11.4)); g.addCurve(to: p(12, 20.5), control1: p(19, 15.8), control2: p(16, 19.4)); g.addCurve(to: p(5, 11.4), control1: p(8, 19.4), control2: p(5, 15.8)); g.addLine(to: p(5, 6)); g.closeSubpath() }
            detail = draw { g in g.move(to: p(9, 12)); g.addLine(to: p(11.1, 14.1)); g.addLine(to: p(15.2, 10)) }
        case .loans:
            fill = draw { g in g.move(to: p(3.5, 9)); g.addLine(to: p(12, 4)); g.addLine(to: p(20.5, 9)); g.closeSubpath() }
            line = draw { g in g.move(to: p(5.8, 11.5)); g.addLine(to: p(5.8, 17.5)); g.move(to: p(10, 11.5)); g.addLine(to: p(10, 17.5)); g.move(to: p(14, 11.5)); g.addLine(to: p(14, 17.5)); g.move(to: p(18.2, 11.5)); g.addLine(to: p(18.2, 17.5)); g.move(to: p(3.5, 20.3)); g.addLine(to: p(20.5, 20.3)) }
        case .chapters:
            fill = draw { g in g.move(to: p(12, 6.5)); g.addCurve(to: p(4, 4.5), control1: p(10, 5), control2: p(7.5, 4.5)); g.addLine(to: p(4, 18.5)); g.addCurve(to: p(12, 20.5), control1: p(7.5, 18.5), control2: p(10, 19)); g.addCurve(to: p(20, 18.5), control1: p(14, 19), control2: p(16.5, 18.5)); g.addLine(to: p(20, 4.5)); g.addCurve(to: p(12, 6.5), control1: p(16.5, 4.5), control2: p(14, 5)); g.closeSubpath() }
            detail = draw { g in g.move(to: p(12, 6.5)); g.addLine(to: p(12, 20)) }
        }
        return Parts(fill: fill, detail: detail, line: line)
    }
}
