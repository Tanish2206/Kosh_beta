import SwiftUI

// MARK: - Teaching kosh a sender it can't read
//
// When a bank's alerts match none of kosh's rules, you can let Claude look at a few of them, with long numbers
// masked, and write a rule for that layout as data: the sender, the subject, and patterns for the amount, the
// digits, the payee, the date and which way the money went. The rule is kept only if it reads every one of the
// samples to an amount printed in the mail and never disagrees with how kosh already reads that sender's mail
// (agent.js ruleCheck). It's then used on this phone for that sender's mail the built-in rules can't read.

enum LearnedRules {
    static let key = "beta.learnedRules"

    static func all() -> [[String: Any]] {
        guard let s = UserDefaults.standard.string(forKey: key), let d = s.data(using: .utf8),
              let a = try? JSONSerialization.jsonObject(with: d) as? [[String: Any]] else { return [] }
        return a
    }
    private static func store(_ a: [[String: Any]]) {
        if let d = try? JSONSerialization.data(withJSONObject: a), let s = String(data: d, encoding: .utf8) { UserDefaults.standard.set(s, forKey: key) }
        install()
    }
    /// a rule for a sender and subject replaces the one before it
    static func add(_ rule: [String: Any]) {
        var a = all()
        a.removeAll { ($0["domain"] as? String) == (rule["domain"] as? String) && ($0["subject"] as? String ?? "") == (rule["subject"] as? String ?? "") }
        a.append(rule)
        store(a)
    }
    static func remove(_ id: String) { store(all().filter { ($0["id"] as? String) != id }) }
    static func clear() { UserDefaults.standard.removeObject(forKey: key); UserDefaults.standard.removeObject(forKey: sharedKey); install() }

    /// the rules kosh's service has reviewed and shares with everyone (patterns only), fetched once a day
    static let sharedKey = "beta.sharedRules"
    static func shared() -> [[String: Any]] {
        guard let s = UserDefaults.standard.string(forKey: sharedKey), let d = s.data(using: .utf8),
              let a = try? JSONSerialization.jsonObject(with: d) as? [[String: Any]] else { return [] }
        return a
    }
    static func refreshShared() async {
        guard let cfg = AgentCloud.config(), cfg.via == "kosh",
              LiveSession.daysSince(UserDefaults.standard.string(forKey: "beta.sharedRulesAt") ?? "") >= 1,
              let u = URL(string: cfg.url.absoluteString.replacingOccurrences(of: "/v1/messages", with: "/v1/rules")) else { return }
        guard let got = try? await URLSession.shared.data(from: u), (got.1 as? HTTPURLResponse)?.statusCode == 200,
              (try? JSONSerialization.jsonObject(with: got.0)) is [[String: Any]], let s = String(data: got.0, encoding: .utf8) else { return }
        UserDefaults.standard.set(s, forKey: sharedKey)
        UserDefaults.standard.set(LiveSession.today, forKey: "beta.sharedRulesAt")
        install()
    }

    /// both engines read with them: the one on the main thread and the one that lays the screens out. A rule
    /// learned on this phone comes before a shared one for the same sender.
    /// every rule, as the engines take them
    static var json: String { JSONText.object(all() + shared()) }
    static func install() {
        let json = self.json
        // (off the main thread: each engine takes them when it's free, and one may be in the middle of a build or a
        // batch of mail; handed over on the main thread, the screens froze until it was done)
        DispatchQueue.global(qos: .utility).async {
            _ = try? Engine.shared.call("setLearnedRulesJSON", [json])
            _ = try? Engine.builder.call("setLearnedRulesJSON", [json])
            if Engine.quickReady { _ = try? Engine.quick.call("setLearnedRulesJSON", [json]) }
            Readers.setRules(json)
        }
    }
}

/// The reader's book of templates (reader.js, "learning from old mail"): for each sender, the shapes its mail comes
/// in and where in each shape the amount, the date, the card and the payee sit, learnt as mail is read and taught by
/// Claude's readings of what the rules couldn't read. Kept on this phone beside the records (layouts.json, never
/// sent anywhere), handed to the engine that reads mail when the files are read in, and saved with the records.
enum LayoutBook {
    static var url: URL { LiveSession.folder.appendingPathComponent("layouts.json") }
    private static let queue = DispatchQueue(label: "kosh.layouts", qos: .utility)

    static func install() {
        /* off the main thread (31 Oct): the main engine's first call makes it, every script loaded, and the book is read
           off the disk; on a phone with 5,000 mails that held the opening for 378 ms. On the queue that saves the book,
           so a save asked meanwhile waits behind it and never writes out a book the engine wasn't handed. Mail is read
           by the readers (Readers), which take the book from layouts.json as they start, never by this engine */
        queue.async(qos: .userInitiated, flags: .enforceQoS) {
            let t0: CFAbsoluteTime = CFAbsoluteTimeGetCurrent()
            let s: String = stored()
            _ = try? Engine.shared.call("loadLayoutBookJSON", [s])
            Perf.shared.record("startup · layout book, off screen", ms: (CFAbsoluteTimeGetCurrent() - t0) * 1000)
            // (the readers that read mail keep the book as they read: Readers)
            Readers.loadBook(s)
            if Engine.quickReady { _ = try? Engine.quick.call("loadLayoutBookJSON", [s]) }
        }
    }
    /// the book as last saved ("" when there is none): also what a fresh engine is handed (Engine.live). In whatever
    /// shape a kosh wrote it (SavedFormat): the engine is handed the book itself
    static func stored() -> String {
        guard let d = try? Data(contentsOf: url), let o = SavedFormat.open(d, .layouts) else { return "" }
        return String(decoding: o.body, as: UTF8.self)
    }
    /// taken from the engine now, written off the main thread
    static func save() {
        // (off the main thread: the engine may be busy reading a mail, and the book can be large)
        let u = url
        queue.async {
            // (the readers' books as one; before any reader has read, the main engine's)
            guard let s = Readers.bookJSON() ?? (try? Engine.shared.call("layoutBookJSON", [])), !s.isEmpty else { return }
            try? SavedFormat.write(Data(s.utf8), .layouts, to: u, options: [.atomic, LiveSession.protection])
        }
    }
    /// a reading surer than the reader's own (Claude's, of mail the rules couldn't read) teaches the mail's template
    static func teach(_ m: MailMsg, _ r: Reading) {
        _ = try? Readers.engine(for: m.from).call("teachJSON", [JSONText.encode(m), JSONText.encode(r)])
    }
    /// you said a mail isn't what kosh read it as (teachNotJSON) or undid that (teachUndoJSON): its sender's reader learns it
    static func teach(_ call: String, _ m: MailMsg, type: String) {
        _ = try? Readers.engine(for: m.from).call(call, [JSONText.encode(m), type])
    }
    /// the same for each of some mails, then the book saved: off the main thread (31 Oct). Each mail is read back from
    /// its sealed copy and taught to its sender's reader, which may be in the middle of a batch of mail; "that's not
    /// right" on a figure waited for both before the sheet could close
    static func teachSoon(_ call: String, mails: [String], type: String) {
        queue.async {
            for id in mails where !id.isEmpty { if let m = MailVault.get(id) { teach(call, m, type: type) } }
            save()
        }
    }
    static func clear() {
        queue.sync {}
        try? FileManager.default.removeItem(at: url)
        _ = try? Engine.shared.call("loadLayoutBookJSON", [""])
        Readers.loadBook("")
        if Engine.quickReady { _ = try? Engine.quick.call("loadLayoutBookJSON", [""]) }
    }
}

struct ReaderTutorSheet: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    let domain: String
    @State private var working = false
    @State private var result: String?
    @State private var problems: [String] = []
    @State private var tries = 0
    /// off until you choose: the rule holds no mail, but it's yours to share
    @State private var share = false

    var body: some View {
        let samples = Self.samples(store.live, domain)
        NavigationStack {
            Form {
                Section {
                    Text("kosh couldn’t read \(Words.number(samples.count)) email\(samples.count == 1 ? "" : "s") from \(domain). Smart reading can look at \(samples.count == 1 ? "it" : "a few of them") and write a reading rule for that layout. kosh uses the rule only if it reads every one of them correctly.")
                        .font(.subheadline)
                }
                if let cfg = AgentCloud.config() {
                    Section {
                        DisclosureGroup("What the AI sees") {
                            Text(prompt(samples)).font(.caption.monospaced()).foregroundStyle(.secondary).textSelection(.enabled)
                        }
                        if cfg.via == "kosh" {
                            Toggle("Share the rule (never the emails) so kosh reads this bank for everyone", isOn: $share)
                        }
                    } footer: {
                        Text("Account and card numbers are cut to their last digits. Only these emails go, once; nothing else from your inbox.")
                    }
                    Section {
                        Button {
                            Task { await teach(samples, cfg) }
                        } label: {
                            HStack {
                                if working { ProgressView() }
                                Text(tries == 0 ? "Write a rule with AI" : "Try again")
                            }
                        }
                        .disabled(working || samples.isEmpty || tries >= 3)
                    }
                } else {
                    Section {
                        Text("This needs the kosh service or your own AI key (Settings › Ask kosh).").foregroundStyle(.secondary)
                    }
                }
                if let result {
                    Section { Label(result, systemImage: problems.isEmpty ? "checkmark.seal.fill" : "exclamationmark.triangle.fill").foregroundStyle(problems.isEmpty ? Color.green : Color.orange) }
                }
                if !problems.isEmpty {
                    Section("Why it wasn’t saved") { ForEach(problems, id: \.self) { Text($0).font(.footnote) } }
                }
                let rules = LearnedRules.all().filter { ($0["domain"] as? String) == domain }
                if !rules.isEmpty {
                    Section("Rules kosh learned for \(domain)") {
                        ForEach(rules.indices, id: \.self) { i in
                            let r = rules[i]
                            HStack {
                                Text((r["why"] as? String) ?? (r["subject"] as? String) ?? "A rule").font(.footnote)
                                Spacer()
                                Button("Forget", role: .destructive) { LearnedRules.remove(r["id"] as? String ?? ""); store.live?.rereadWithRules(domain: domain) }
                                    .font(.footnote)
                            }
                        }
                    }
                }
            }
            .navigationTitle("Teach kosh")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } } }
        }
    }

    /// the unread mail from the sender, as the reader sees it
    static func samples(_ live: LiveSession?, _ domain: String) -> [MailMsg] {
        guard let live else { return [] }
        return live.unread.filter { SenderPasswords.domain($0.from ?? "") == domain && !($0.text ?? "").isEmpty }.prefix(6).map {
            MailMsg(id: $0.id, from: $0.from ?? "", date: ($0.sent ?? "") + "T09:00:00Z", subject: $0.subject ?? "", text: $0.text ?? "", html: $0.html ?? "")
        }
    }

    func prompt(_ samples: [MailMsg]) -> String {
        (try? Engine.shared.call("rulePromptText", [JSONText.encode(Array(samples.prefix(4))), JSONText.object(["names": store.live?.claudeNames ?? []])])) ?? ""
    }

    @MainActor
    func teach(_ samples: [MailMsg], _ cfg: AgentCloud.Config) async {
        guard let live = store.live, !samples.isEmpty else { return }
        working = true
        defer { working = false }
        tries += 1
        let tool = (try? JSONSerialization.jsonObject(with: Data(((try? Engine.shared.call("ruleToolJSON", [])) ?? "{}").utf8))) as? [String: Any] ?? [:]
        var text = prompt(samples)
        if !problems.isEmpty { text += "\n\nA rule tried before wasn’t used: " + problems.joined(separator: "; ") + ". Write one that avoids that." }
        let body: [String: Any] = ["model": cfg.model, "max_tokens": 900, "tools": [tool], "tool_choice": ["type": "tool", "name": "propose_rule"],
                                   "messages": [["role": "user", "content": text]]]
        do {
            let resp = try await AgentCloud.send(body, cfg)
            guard let use = (resp["content"] as? [[String: Any]])?.first(where: { ($0["type"] as? String) == "tool_use" }), var rule = use["input"] as? [String: Any] else {
                result = "No rule came back from the AI."; problems = ["No rule came back"]; return
            }
            rule["id"] = "r" + String(Int(Date().timeIntervalSince1970))
            if (rule["domain"] as? String ?? "").isEmpty { rule["domain"] = domain }
            rule["by"] = "claude"; rule["made"] = LiveSession.today
            // checked against every unread mail from the sender, and against how kosh already reads its other mail
            let known: [[String: Any]] = live.records.filter { SenderPasswords.domain($0.from ?? "") == domain && $0.kind == "txn" }.prefix(8).compactMap { r in
                guard let m = MailVault.get(r.id), let md = try? JSONSerialization.jsonObject(with: Data(JSONText.encode(m).utf8)) else { return nil }
                return ["msg": md, "rec": ["kind": r.kind, "amt": r.amt ?? 0, "dir": r.dir ?? ""]]
            }
            struct Check: Decodable { let ok: Bool; let read: Int; let of: Int; let problems: [String] }
            let out = (try? Engine.shared.call("ruleCheckJSON", [JSONText.object(rule), JSONText.encode(samples), JSONText.object(known)])) ?? ""
            guard let c = try? JSONText.decode(Check.self, out) else { result = "kosh couldn’t check the rule."; problems = ["The check failed"]; return }
            if c.ok {
                LearnedRules.add(rule)
                let n = live.rereadWithRules(domain: domain)
                problems = []
                result = "Saved. It read \(c.read) of \(c.of), and \(n) email\(n == 1 ? " is" : "s are") now in your ledger."
                if share && cfg.via == "kosh" { let shared = rule; Task.detached { await AgentCloud.shareRule(shared, cfg) } }
            } else {
                problems = c.problems
                result = "Not saved: it read \(c.read) of \(c.of)."
            }
        } catch {
            result = "The AI couldn’t be reached: " + error.localizedDescription
            problems = []
        }
    }
}

extension AgentCloud {
    /// a rule kosh learned, sent to kosh's service so it can read that bank for everyone (the rule alone, never mail)
    static func shareRule(_ rule: [String: Any], _ cfg: Config) async {
        guard let u = URL(string: cfg.url.absoluteString.replacingOccurrences(of: "/v1/messages", with: "/v1/rules")) else { return }
        var req = URLRequest(url: u)
        req.httpMethod = "POST"
        for (k, v) in cfg.headers { req.setValue(v, forHTTPHeaderField: k) }
        req.httpBody = try? JSONSerialization.data(withJSONObject: rule)
        _ = try? await URLSession.shared.data(for: req)
    }
}

extension LiveSession {
    /// a sender's mail the rules couldn't read, read again with what kosh has learned (from what's kept on the
    /// record); how many it now reads
    @MainActor
    @discardableResult
    func rereadWithRules(domain: String) -> Int {
        var n = 0
        for i in records.indices {
            let r = records[i]
            guard SenderPasswords.domain(r.from ?? "") == domain, r.kind == "unknown" || r.src == "learned" else { continue }
            let acct = (r.acct ?? "").isEmpty ? email : (r.acct ?? email)
            let tag = inboxTag(acct)
            let id = tag.isEmpty || !r.id.hasPrefix(tag) ? r.id : String(r.id.dropFirst(tag.count))
            let m = MailVault.get(r.id) ?? MailMsg(id: id, from: r.from ?? "", date: (r.sent ?? "") + "T09:00:00Z", subject: r.subject ?? "", text: r.text ?? "", html: r.html ?? "")
            guard !m.text.isEmpty || !m.html.isEmpty, var fresh = reading(m, acct: acct, tag: tag) else { continue }
            // what the new reading doesn't carry stays from the old one: its statement and Claude's reading
            fresh.doc = fresh.doc ?? r.doc
            fresh.claude = fresh.claude ?? r.claude
            records[i] = fresh
            if fresh.kind == "txn" { n += 1 }
        }
        save(); rebuildSoon()
        return n
    }
}
