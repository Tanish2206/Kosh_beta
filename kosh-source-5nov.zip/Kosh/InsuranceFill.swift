import SwiftUI

// MARK: - Insurance: what's missing filled in once, premiums ahead, cover per rupee
//
// A policy's mail and papers don't always say everything: a ULIP's cover, a parent's premium, the nominee. The
// policy page asks once for each figure still missing (LiveSession.fillPolicy; the engine reads it as
// prof.policyFill, and what you typed stands). The premiums ahead are on the home's "Up next" and the payments timeline
// (InsuranceObsidian.swift, InsurancePayments.swift). A life policy says
// how much cover each ₹1,000 of premium a year buys: plain arithmetic on its own figures, never advice.

/// the policy page's ask: each figure its mail and papers don't say, typed once
struct PolicyFillSection: View {
    @Environment(Store.self) private var store
    let p: Policy
    @State private var cover = ""
    @State private var premium = ""
    @State private var freq = ""
    @State private var nominee = ""
    @State private var number = ""
    @State private var loaded = false
    @State private var saved = false

    static let freqs: [String] = ["Monthly", "Quarterly", "Half-yearly", "Yearly", "Single"]

    var body: some View {
        let key: String = p.key ?? ""
        let typed: [String: String] = store.live?.policyFill[key] ?? [:]
        let miss: Set<String> = Set((p.gaps ?? []).map(\.what))
        let askCover: Bool = miss.contains("Cover") || typed["cover"] != nil
        let askPremium: Bool = miss.contains("Premium") || typed["premium"] != nil
        let askFreq: Bool = miss.contains("How often") || typed["frequency"] != nil
        let askNominee: Bool = miss.contains("Nominee") || typed["nominee"] != nil
        let askNumber: Bool = miss.contains("Policy number") || typed["policyNo"] != nil
        let part: String = PolicyKinds.part(p)
        let coverWord: String = part == "Health" ? "Sum insured" : part == "Motor" ? "IDV" : part == "Life" ? "Life cover" : "Cover"
        if askCover || askPremium || askFreq || askNominee || askNumber {
            Section {
                if askCover { field(coverWord, "₹", $cover, .numberPad) }
                if askPremium { field("Premium", "₹ each time", $premium, .numberPad) }
                if askFreq || askPremium {
                    Picker("Paid", selection: $freq) {
                        Text("Not sure").tag("")
                        ForEach(Self.freqs, id: \.self) { (f: String) in Text(f).tag(f) }
                    }
                }
                if askNominee { field("Nominee", "Name", $nominee, .default) }
                if askNumber { field("Policy number", "As printed", $number, .asciiCapable) }
                Button {
                    store.live?.fillPolicy(key, ["cover": digits(cover), "premium": digits(premium), "frequency": freq, "nominee": nominee, "policyNo": number])
                    saved = true
                } label: {
                    Text(saved ? "Saved" : "Save").font(.body.weight(.semibold))
                }
                .disabled(key.isEmpty || !changed(typed))
            } header: {
                Text("Fill in what’s missing")
            } footer: {
                Text(footer(miss))
            }
            .onAppear {
                guard !loaded else { return }
                loaded = true
                cover = typed["cover"] ?? ""; premium = typed["premium"] ?? ""; freq = typed["frequency"] ?? (p.frequency ?? "")
                nominee = typed["nominee"] ?? ""; number = typed["policyNo"] ?? ""
                if !Self.freqs.contains(freq) { freq = "" }
            }
            .onChange(of: cover) { _, _ in saved = false }
            .onChange(of: premium) { _, _ in saved = false }
            .onChange(of: freq) { _, _ in saved = false }
            .onChange(of: nominee) { _, _ in saved = false }
            .onChange(of: number) { _, _ in saved = false }
        }
    }

    func field(_ label: String, _ hint: String, _ text: Binding<String>, _ kb: UIKeyboardType) -> some View {
        HStack(spacing: 12) {
            Text(label)
            Spacer(minLength: 12)
            TextField(hint, text: text)
                .multilineTextAlignment(.trailing)
                .keyboardType(kb)
                .autocorrectionDisabled()
                .textInputAutocapitalization(kb == .asciiCapable ? .characters : .words)
        }
    }

    func digits(_ s: String) -> String { String(s.filter { $0.isNumber || $0 == "." }) }

    func changed(_ typed: [String: String]) -> Bool {
        let now: [String: String] = ["cover": digits(cover), "premium": digits(premium), "frequency": freq, "nominee": nominee.trimmingCharacters(in: .whitespaces), "policyNo": number.trimmingCharacters(in: .whitespaces)]
        return now.contains { (k: String, v: String) -> Bool in v != (typed[k] ?? "") && !(v.isEmpty && typed[k] == nil) }
    }

    /// where kosh looked, in a sentence
    func footer(_ miss: Set<String>) -> String {
        let at: String = (p.gaps ?? []).first?.at ?? ""
        let whereW: String = at.contains("locked") ? "Its policy paper is locked; kosh opens it in the background once your details are saved."
            : at.contains("not opened") ? "Its policy paper hasn’t been opened yet."
            : at.contains("couldn") ? "kosh couldn’t read its policy paper."
            : "Its mail doesn’t say these."
        return whereW + " What you type here stands, whatever its papers say later."
    }
}

/// how much life cover each ₹1,000 of premium a year buys: plain arithmetic on the policy's own figures
enum CoverPerRupee {
    static func of(_ p: Policy) -> Double? {
        guard PolicyKinds.part(p) == "Life", let c = p.cover, c > 0 else { return nil }
        let y: Double = p.yearly
        guard y > 0 else { return nil }
        return c / y * 1000
    }
    /// "₹10.3L", "₹8,590"
    static func words(_ v: Double) -> String { v >= 1e5 ? Fmt.words(v) : Fmt.rupees(v) }
}

/// the life policies side by side: cover for each ₹1,000 a year, most first (two or more with both figures)
struct CoverPerRupeeLine: View {
    let pols: [Policy]
    var body: some View {
        let rows: [(Policy, Double)] = pols.compactMap { (p: Policy) -> (Policy, Double)? in CoverPerRupee.of(p).map { (p, $0) } }.sorted { $0.1 > $1.1 }
        if rows.count >= 2 {
            VStack(alignment: .leading, spacing: 6) {
                Text("Cover for each ₹1,000 of premium a year").font(.footnote.weight(.semibold)).foregroundStyle(.secondary)
                ForEach(rows, id: \.0.id) { (r: (Policy, Double)) in
                    HStack {
                        Text(InsBook.name(r.0)).font(.footnote).lineLimit(1)
                        Spacer(minLength: 8)
                        Text(CoverPerRupee.words(r.1)).font(.footnote.weight(.semibold)).monospacedDigit()
                    }
                }
            }
            .padding(14)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(CardFill(opacity: 0.7), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            .privacySensitive()
        }
    }
}
