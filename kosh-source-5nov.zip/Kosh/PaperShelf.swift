import Foundation

// MARK: - Settings › Statements & papers: which institution's shelf a paper sits on, and how a shelf is laid out
//
// Screen-free, so engine-test/paper-shelf.js compiles it with swiftc and checks it without Xcode. A paper sits under
// the institution the engine named for its sender (Reading.inst, from the directory), never under one guessed from
// an address: a sender the engine couldn't name goes under "Other". Two spellings of one name ("HDFC Bank",
// "hdfc bank ") are one shelf. A bank's locked papers come first, then the ones waiting to be opened, then the ones
// kosh couldn't read, then the opened ones by kind and month, newest first.

/// one paper, as the shelves see it
struct ShelfPaper: Hashable {
    let id: String
    /// the institution the engine named for its sender; "" when it named none
    let inst: String
    /// what a typed password is kept by (the sender's mail domain)
    let domain: String
    let kind: String
    /// read, locked, empty, older, "" (not opened yet)
    let state: String
    /// opened, but neither kosh's readers nor smart reading could read it
    let unread: Bool
    /// yyyy-MM-dd (or longer); "" when unknown
    let date: String
}

enum PaperShelf {
    static let other: String = "Other"

    /// where a paper's papers pile up on its institution's page
    enum Pile: String, CaseIterable {
        case locked, waiting, unread, opened, older
    }

    /// one institution with papers, as its chip in the strip says it
    struct Bank: Hashable, Identifiable {
        var name: String
        var total: Int = 0
        var locked: Int = 0
        var waiting: Int = 0
        var unread: Int = 0
        var older: Int = 0
        var newest: String = ""
        var id: String { name }
        /// what the chip's badge counts: papers still shut (locked, or not opened yet)
        var shut: Int { locked + waiting }
    }

    /// one kind of opened paper on a bank's page, by month
    struct KindShelf: Hashable, Identifiable {
        let kind: String
        let title: String
        /// (yyyy-MM, the papers' ids), newest month first; an undated paper's month is ""
        let months: [Month]
        var id: String { kind }
        var count: Int { months.reduce(0) { $0 + $1.ids.count } }
    }
    struct Month: Hashable, Identifiable {
        let ym: String
        let ids: [String]
        var id: String { ym }
    }

    static func key(_ s: String) -> String {
        s.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
    }

    /// the shelf a paper sits on: the engine's institution for its sender, or Other
    static func home(_ p: ShelfPaper) -> String {
        let i: String = p.inst.trimmingCharacters(in: .whitespacesAndNewlines)
        return i.isEmpty ? other : i
    }

    static func pile(_ p: ShelfPaper) -> Pile {
        switch p.state {
        case "locked": return .locked
        case "": return .waiting
        case "empty": return .unread
        case "older": return .older
        default: return p.unread ? .unread : .opened
        }
    }

    /// every institution with papers. The ones with something shut first, then the most papers, then by name; Other
    /// last. `extra` adds locked senders that have no paper among these (a passbook added from Files, say), by name.
    static func banks(_ papers: [ShelfPaper], extra: [(name: String, locked: Int)] = []) -> [Bank] {
        var by: [String: Bank] = [:]
        // a shelf is named the way most of its papers spell it (on a tie, the newest paper's way)
        var spelt: [String: [String: Int]] = [:]
        for p in papers.sorted(by: { $0.date > $1.date }) {
            let name: String = home(p)
            let k: String = key(name)
            spelt[k, default: [:]][name, default: 0] += 1
            var b: Bank = by[k] ?? Bank(name: name)
            b.total += 1
            switch pile(p) {
            case .locked: b.locked += 1
            case .waiting: b.waiting += 1
            case .unread: b.unread += 1
            case .older: b.older += 1
            case .opened: break
            }
            if p.date > b.newest { b.newest = p.date }
            by[k] = b
        }
        for (k, names) in spelt {
            // (papers were met newest first, and a later spelling replaces only on more papers)
            var best: (name: String, n: Int) = (by[k]?.name ?? "", names[by[k]?.name ?? ""] ?? 0)
            for (name, n) in names where n > best.n { best = (name, n) }
            by[k]?.name = best.name
        }
        for x in extra where x.locked > 0 {
            let name: String = x.name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? other : x.name
            let k: String = key(name)
            if by[k] == nil { by[k] = Bank(name: name, total: x.locked, locked: x.locked) }
        }
        return by.values.sorted { (a: Bank, b: Bank) -> Bool in
            let ao: Bool = key(a.name) == key(other), bo: Bool = key(b.name) == key(other)
            if ao != bo { return bo }
            if (a.shut > 0) != (b.shut > 0) { return a.shut > 0 }
            if a.total != b.total { return a.total > b.total }
            return a.name.localizedCaseInsensitiveCompare(b.name) == .orderedAscending
        }
    }

    /// the papers on one bank's shelf ("" is every bank)
    static func on(_ bank: String, _ papers: [ShelfPaper]) -> [ShelfPaper] {
        bank.isEmpty ? papers : papers.filter { key(home($0)) == key(bank) }
    }

    /// the shelf a locked sender's card sits on: the institution its papers sit on (the one most of them name),
    /// else the name the sender's mail was filed under, else Other. Never a name made up from the address.
    static func home(ofSender domain: String, named: String, _ papers: [ShelfPaper]) -> String {
        var count: [String: (name: String, n: Int)] = [:]
        for p in papers where p.domain == domain {
            let name: String = home(p)
            let k: String = key(name)
            count[k] = (count[k]?.name ?? name, (count[k]?.n ?? 0) + 1)
        }
        if let best = count.values.max(by: { $0.n != $1.n ? $0.n < $1.n : $0.name > $1.name }) { return best.name }
        let n: String = named.trimmingCharacters(in: .whitespacesAndNewlines)
        return n.isEmpty || key(n) == key(domain) ? other : n
    }

    /// the kinds in the order a person looks for them: money in the bank first, then what grows, then what protects
    static let kindOrder: [String] = ["stmt", "cardstmt", "cas", "contract", "nps", "fd", "loan", "policy", "payslip", "tax", "society"]

    static func kindTitle(_ k: String) -> String {
        switch k {
        case "stmt": return "Bank statements"
        case "cardstmt": return "Card statements"
        case "cas": return "Fund and demat statements"
        case "contract": return "Contract notes"
        case "nps": return "NPS statements"
        case "fd": return "Deposit advices"
        case "loan": return "Loan statements"
        case "policy": return "Policies"
        case "payslip": return "Payslips"
        case "tax": return "Tax forms"
        case "society": return "Society bills"
        default: return "Other papers"
        }
    }

    /// the opened papers among these, by kind (in kindOrder), each kind by month, newest first
    static func opened(_ papers: [ShelfPaper]) -> [KindShelf] {
        let open: [ShelfPaper] = papers.filter { pile($0) == .opened }
        let kinds: [String: [ShelfPaper]] = Dictionary(grouping: open, by: { $0.kind })
        let order: [String] = kinds.keys.sorted { (a: String, b: String) -> Bool in
            let ia: Int = kindOrder.firstIndex(of: a) ?? kindOrder.count, ib: Int = kindOrder.firstIndex(of: b) ?? kindOrder.count
            return ia != ib ? ia < ib : a < b
        }
        return order.map { (k: String) -> KindShelf in
            let ps: [ShelfPaper] = kinds[k] ?? []
            let byMonth: [String: [ShelfPaper]] = Dictionary(grouping: ps, by: { $0.date.count >= 7 ? String($0.date.prefix(7)) : "" })
            let months: [Month] = byMonth.keys.sorted(by: >).map { (ym: String) -> Month in
                Month(ym: ym, ids: (byMonth[ym] ?? []).sorted { $0.date != $1.date ? $0.date > $1.date : $0.id < $1.id }.map(\.id))
            }
            return KindShelf(kind: k, title: kindTitle(k), months: months)
        }
    }

    /// "2026-10" → "October 2026"; "" → "Undated"
    static func monthTitle(_ ym: String) -> String {
        let names: [String] = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
        guard ym.count == 7, let m = Int(ym.suffix(2)), (1...12).contains(m) else { return "Undated" }
        return names[m - 1] + " " + String(ym.prefix(4))
    }

    /// the line under the page's title for a shelf: what's shut, what's open, said plainly ("" when it holds nothing)
    static func line(_ b: Bank) -> String {
        var parts: [String] = []
        if b.locked > 0 { parts.append("\(b.locked) locked") }
        if b.waiting > 0 { parts.append("\(b.waiting) not opened yet") }
        if b.unread > 0 { parts.append("\(b.unread) couldn’t be read") }
        let open: Int = b.total - b.locked - b.waiting - b.unread - b.older
        if open > 0 { parts.append("\(open) opened") }
        return parts.joined(separator: " · ")
    }
}

// MARK: - The one field a locked sender's card asks for

extension PaperShelf {
    /// the one detail a locked sender's rule still needs, read from what kosh said it needs ("Needs your CRN."):
    /// crn, cid, dob, pan, mobile or pin; nil when it needs something only its own mail has (a card's digits, a
    /// policy number) or nothing kosh can name. The first named wins: one box at a time.
    static func field(forNeed need: String) -> String? {
        let n: String = need.lowercased()
        guard n.hasPrefix("needs ") else {
            // (kosh made the password from saved details and it didn't open: the ID is the likeliest culprit)
            return n.contains("crn") ? "crn" : n.contains("customer id") ? "cid" : nil
        }
        let order: [(String, String)] = [("your crn", "crn"), ("your customer id", "cid"), ("of birth", "dob"), ("your pan", "pan"),
                                         ("your mobile number", "mobile"), ("your pin code", "pin")]
        var best: (at: String.Index, f: String)? = nil
        for (words, f) in order {
            if let r = n.range(of: words), best == nil || r.lowerBound < best!.at { best = (r.lowerBound, f) }
        }
        return best?.f
    }

    /// what a locked sender needs, said of the person whose paper it is. kosh works it out from that person's details
    /// alone and says "your" ("Needs your date of birth."); on a parent's paper that reads as yours, so it is said with
    /// their name ("Needs Mohan’s date of birth."). Empty `whose` (your own paper) leaves it as it is. The box is still
    /// picked from the plain words (field(forNeed:)), never from these.
    static func need(_ need: String, whose: String) -> String {
        let name: String = whose.trimmingCharacters(in: .whitespaces)
        guard !name.isEmpty else { return need }
        return need.replacingOccurrences(of: "Your ", with: name + "’s ").replacingOccurrences(of: "your ", with: name + "’s ")
    }

    /// what the box is called, in the bank's own word
    static func fieldWord(_ f: String) -> String {
        switch f {
        case "crn": return "CRN"
        case "cid": return "Customer ID"
        case "dob": return "Date of birth"
        case "pan": return "PAN"
        case "mobile": return "Mobile number"
        case "pin": return "PIN code"
        default: return ""
        }
    }

    /// a typed value, made the way kosh keeps it, or nil when it isn't one: a date of birth as yyyy-MM-dd (typed
    /// DD/MM/YYYY, DD-MM-YYYY or DDMMYYYY, or kept already as yyyy-MM-dd; never a day that never was or is still to
    /// come), a PAN in capitals (never one printed masked: its fourth letter, the holder's kind, is never X), a mobile
    /// number's last ten digits, a PIN code's six; an ID as typed, with its spaces gone, at least four characters.
    /// The same test holds a detail kosh read from a mail (harvested) before it is kept or counted as known.
    static func typed(_ f: String, _ raw: String) -> String? {
        let s: String = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        let digits: String = s.filter(\.isNumber)
        switch f {
        case "dob":
            let parts: [Int] = s.split(whereSeparator: { "/-. ".contains($0) }).compactMap { Int($0) }
            var d: Int = 0, m: Int = 0, y: Int = 0
            if parts.count == 3 && s.range(of: #"^\d{4}-\d{2}-\d{2}$"#, options: .regularExpression) != nil { (y, m, d) = (parts[0], parts[1], parts[2]) }
            else if parts.count == 3 { (d, m, y) = (parts[0], parts[1], parts[2]) }
            else if parts.count == 1 && digits.count == 8 { d = Int(digits.prefix(2)) ?? 0; m = Int(digits.dropFirst(2).prefix(2)) ?? 0; y = Int(digits.suffix(4)) ?? 0 }
            guard (1...31).contains(d), (1...12).contains(m), (1900...2100).contains(y) else { return nil }
            let days: [Int] = [31, (y % 4 == 0 && (y % 100 != 0 || y % 400 == 0)) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
            guard d <= days[m - 1] else { return nil }
            let iso: String = String(format: "%04d-%02d-%02d", y, m, d)
            let now: DateComponents = Calendar(identifier: .gregorian).dateComponents([.year, .month, .day], from: Date())
            let today: String = String(format: "%04d-%02d-%02d", now.year ?? 2100, now.month ?? 12, now.day ?? 31)
            return iso <= today ? iso : nil
        case "pan":
            let p: String = s.uppercased().filter { !$0.isWhitespace }
            guard p.range(of: "^[A-Z]{5}[0-9]{4}[A-Z]$", options: .regularExpression) != nil, Array(p)[3] != "X" else { return nil }
            return p
        case "mobile":
            guard digits.count >= 10, digits.count <= 12 else { return nil }
            return String(digits.suffix(10))
        case "pin":
            return digits.count == 6 && digits.count == s.filter({ !$0.isWhitespace }).count ? digits : nil
        default:
            let id: String = s.filter { !$0.isWhitespace }
            return id.count >= 4 ? id : nil
        }
    }
}
