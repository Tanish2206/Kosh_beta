import SwiftUI
import UIKit

// MARK: - The intro: everywhere a household's money lives, untangled into kosh
//
// Five short beats on one Canvas, drawn as string art in the shape of a butterfly (Wings). Strings run from where
// money leaves (banks, cards, UPI apps: amber, on the wing's edge) into what it becomes (spending on the left wing,
// savings and investments on the right: rose) and on to the paper that records it (statements, CAS, policies, tax
// forms: blue, down the body).
//   1 where it leaves   bank/card/app → what it becomes; sparks run along them
//   2 what it becomes   spending and investments light up, sparks run on to the papers
//   3 what it leaves    one whole route at a time, named in a caption
//   4 all at once       everything lit and restless; the headline says "Countless", never a figure
//   5 kosh              the strings leave for a ring, the ring tightens into the coin's rim, the dark tile grows behind it,
//                       the coin fills, the glass walls rise, the lid drops on a spring, the ₹ draws itself and "kosh"
//                       rises beneath, letter by letter. A glint crosses the glass every few seconds.
// Anytime: tap a name to trace its routes; drag to send a ripple; tap the finished logo and the coin flips.
// The first run opens on beats 4 and 5; Settings › Play the intro shows all five.

/// The drawing the intro uses: Wings only (Lorenz and Loom were retired on 17 Oct 2026; the intro is redesigned later)
enum IntroLook: String {
    case wings
}

// MARK: - What the intro says: no figures anywhere

enum IntroTone {
    case app, wallet, gift, ink
    var color: Color {
        switch self {
        case .app: return IntroInk.appText
        case .wallet: return IntroInk.walletText
        case .gift: return IntroInk.giftText
        case .ink: return Color.primary
        }
    }
}

struct IntroLine {
    let key: String
    let tone: IntroTone
    let eyebrow: String
    let title: String
    var big: String? = nil
    var stats: [String] = []
    let text: String
    var foot: String? = nil
    let cta: String

    // one story, each beat leading into the next: money moves → it becomes something → it leaves a paper → nobody joins
    // the threads → kosh does. Every line fits two lines on a phone (the words box is 184 points, under the drawing).
    static let beats: [IntroLine] = [
        IntroLine(key: "b0", tone: .app, eyebrow: "Where it leaves", title: "Your money moves through many doors.",
                  text: "Banks, cards and UPI apps, each with its own alerts.", cta: "Next"),
        IntroLine(key: "b1", tone: .wallet, eyebrow: "What it becomes", title: "Some is spent. Some grows.",
                  text: "Food and bills on one side. Funds, stocks, deposits and gold on the other.", cta: "Next"),
        IntroLine(key: "b2", tone: .gift, eyebrow: "What it leaves behind", title: "Every rupee leaves a paper.",
                  text: "Receipts, statements, CAS, tax forms. All in your mail, most of it locked.", cta: "Next"),
        IntroLine(key: "b3", tone: .ink, eyebrow: "Put together", title: "threads to follow.", big: "Countless",
                  text: "Each bank, app and paper tells one part. Nobody joins them up.", cta: "Untangle it"),
        IntroLine(key: "b4", tone: .ink, eyebrow: "One place", title: "Every rupee, followed home.",
                  text: "kosh reads your mail and joins it all up: spending, savings, investments, loans.",
                  foot: "Read-only · encrypted on your phone", cta: "Get started"),
    ]

    /// the short intro's first beat: the tangle, said as the problem kosh solves
    static let opening: IntroLine = IntroLine(key: "o3", tone: .ink, eyebrow: "Your money today", title: "threads to follow.", big: "Countless",
        text: "Banks, apps, funds and papers each tell one part. Tap a name to follow it.", cta: "Untangle it")

    /// what a tapped name says about itself
    static func about(_ n: Int) -> IntroLine {
        let g: IntroGraph = IntroGraph.shared
        let node: IntroNode = g.nodes[n]
        var apps: Set<Int> = []
        var wallets: Set<Int> = []
        var portals: Set<Int> = []
        for ri in g.routesOf[n] {
            let r: IntroRoute = g.routes[ri]
            apps.insert(r.app)
            wallets.insert(r.wallet)
            portals.insert(r.portal)
        }
        let back: String = "Back to the story"
        switch node.tier {
        case .app:
            let only: Bool = wallets.count == 1
            return IntroLine(key: "f" + node.id, tone: .app, eyebrow: "Where it leaves", title: node.name,
                             stats: ["moves into " + g.names(wallets), "on paper in " + g.names(portals)],
                             text: only ? "One door, one kind of money." : "One account, more kinds of money than it lets on.", cta: back)
        case .wallet:
            return IntroLine(key: "f" + node.id, tone: .wallet, eyebrow: node.head ? "What it becomes · the busy one" : "What it becomes", title: node.name,
                             stats: ["paid from " + g.names(apps), "recorded in " + g.names(portals)],
                             text: apps.count == 1 ? "Money arrives here by exactly one door." : "Money arrives here from more places than you’d guess.", cta: back)
        case .portal:
            return IntroLine(key: "f" + node.id, tone: .gift, eyebrow: "The paper", title: node.name,
                             stats: ["records " + g.names(wallets), "from " + g.names(apps)],
                             text: "Somewhere in your mail, often locked. kosh finds it and reads it.", cta: back)
        }
    }
}

enum IntroCaption: Hashable {
    case hint
    case route(Int)
}

// MARK: - The screen

struct IntroView: View {
    /// replayed from Settings: the whole story, and the last button closes
    var showcase: Bool = false
    let done: () -> Void
    /// where the story starts: the whole story when replayed, and the last two beats (the tangle, then kosh) when
    /// it's the first thing someone sees, so the Gmail ask comes sooner
    let first: Int

    init(showcase: Bool = false, done: @escaping () -> Void) {
        self.showcase = showcase
        self.done = done
        self.first = showcase ? 0 : 3
        _beat = State(initialValue: showcase ? 0 : 3)
    }

    @Environment(\.accessibilityReduceMotion) private var still
    @Environment(\.colorScheme) private var scheme
    @State private var sim: IntroSim = IntroSim()
    @State private var beat: Int = 0
    @State private var focus: Int? = nil
    @State private var story: Int = -1
    @State private var caption: IntroCaption? = nil
    @State private var dragging: Bool = false
    @State private var lastRipple: CGPoint = .zero
    @State private var landed: Int = 0
    @State private var pokes: Int = 0
    @State private var hinted: Bool = false
    @State private var touched: Bool = false

    static let beatNames: [String] = ["Where it leaves", "What it becomes", "What it leaves behind", "Put together", "kosh"]

    struct BeatKey: Hashable {
        let beat: Int
        let paused: Bool
    }

    var look: IntroLook { .wings }
    var line: IntroLine { focus.map { (n: Int) -> IntroLine in IntroLine.about(n) } ?? (first == 3 && beat == 3 ? IntroLine.opening : IntroLine.beats[beat]) }
    var input: IntroInput { IntroInput(beat: beat, focus: focus, story: story, look: look, still: still, dragging: dragging) }

    var body: some View {
        VStack(spacing: 0) {
            topBar
            stage
            words
            StepButton(title: ctaTitle) { primary() }
                .padding(.top, 10)
        }
        .background(Color(uiColor: .systemBackground).ignoresSafeArea())
        .onAppear { if first > 0 { sim.begin(at: first) } }
        .task(id: BeatKey(beat: beat, paused: focus != nil)) { await run() }
        .sensoryFeedback(.impact(weight: .light), trigger: beat)
        .sensoryFeedback(.selection, trigger: focus)
        .sensoryFeedback(.impact(weight: .medium), trigger: landed)
        .sensoryFeedback(.impact(flexibility: .soft), trigger: pokes)
    }

    var ctaTitle: String {
        if beat == 4 && focus == nil && showcase { return "Done" }
        return line.cta
    }

    // MARK: Pieces

    var topBar: some View {
        HStack(spacing: 12) {
            IntroBars(beat: beat, first: first, sim: sim) { (i: Int) in
                touched = true
                go(i)
            }
            if showcase {
                Button(action: done) {
                    Image(systemName: "xmark").font(.body.weight(.semibold))
                }
                .buttonStyle(.glass)
                .buttonBorderShape(.circle)
                .accessibilityLabel("Close")
            } else {
                Button("Skip") {
                    touched = true
                    go(4)
                }
                .font(.subheadline.weight(.semibold))
                .buttonStyle(.glass)
                .opacity(beat < 4 ? 1 : 0)
                .disabled(beat >= 4)
            }
        }
        .padding(.horizontal, 16)
        .padding(.top, 4)
        .frame(height: 48)
    }

    var stage: some View {
        TimelineView(.animation) { tl in
            Canvas { ctx, size in
                sim.render(&ctx, size: size, time: tl.date.timeIntervalSinceReferenceDate, input: input, dark: scheme == .dark)
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .contentShape(Rectangle())
        .gesture(drag)
        .overlay(alignment: .bottom) {
            captionView
                .padding(.bottom, 6)
                .animation(.smooth(duration: 0.28), value: caption)
        }
        .accessibilityElement()
        .accessibilityLabel(beat == 4 ? "kosh" : "Strings run from banks, cards and payment apps, into what the money becomes, spending, savings and investments, and on to the papers that record it.")
        .accessibilityAddTraits(.isImage)
    }

    var words: some View {
        let l: IntroLine = line
        return ZStack(alignment: .topLeading) {
            IntroWords(line: l)
                .id(l.key)
                .transition(.opacity.combined(with: .offset(y: 8)))
        }
        .frame(maxWidth: .infinity, alignment: .topLeading)
        .frame(height: 184, alignment: .top)
        .padding(.horizontal, 28)
        .clipped()
        .animation(.smooth(duration: 0.3), value: l.key)
        .contentShape(Rectangle())
        .gesture(swipe)
    }

    @ViewBuilder var captionView: some View {
        if let c = caption {
            captionText(c)
                .font(.system(size: 11.5, weight: .medium, design: .monospaced))
                .lineLimit(1)
                .padding(.horizontal, 13)
                .padding(.vertical, 7)
                .glassEffect(.regular, in: .capsule)
                .padding(.horizontal, 16)
                .id(c)
                .transition(.opacity.combined(with: .offset(y: 6)))
                .allowsHitTesting(false)
        }
    }

    @ViewBuilder func captionText(_ c: IntroCaption) -> some View {
        switch c {
        case .hint:
            Text("Tap any name · drag across the strings")
        case .route(let ri):
            let r: IntroRoute = IntroGraph.shared.routes[ri]
            HStack(spacing: 5) {
                Text(IntroGraph.shared.nodes[r.app].name).fontWeight(.semibold).foregroundStyle(IntroInk.appText)
                Text("→").foregroundStyle(.secondary)
                Text(IntroGraph.shared.nodes[r.wallet].name).fontWeight(.semibold).foregroundStyle(IntroInk.walletText)
                Text("→").foregroundStyle(.secondary)
                Text(IntroGraph.shared.nodes[r.portal].name).fontWeight(.semibold).foregroundStyle(IntroInk.giftText)
            }
        }
    }

    var drag: some Gesture {
        DragGesture(minimumDistance: 0)
            .onChanged { (v: DragGesture.Value) in
                if !dragging {
                    dragging = true
                    touched = true
                    lastRipple = v.location
                    if caption == .hint { caption = nil }
                    sim.touch(v.location)
                } else if hypot(v.location.x - lastRipple.x, v.location.y - lastRipple.y) > 20 {
                    lastRipple = v.location
                    sim.touch(v.location)
                }
            }
            .onEnded { (v: DragGesture.Value) in
                dragging = false
                if hypot(v.translation.width, v.translation.height) < 10 { tap(v.location) }
            }
    }

    var swipe: some Gesture {
        DragGesture(minimumDistance: 24)
            .onEnded { (v: DragGesture.Value) in
                let dx: CGFloat = v.translation.width
                let dy: CGFloat = v.translation.height
                guard abs(dx) > 50, abs(dx) > abs(dy) * 1.5 else { return }
                touched = true
                go(beat + (dx < 0 ? 1 : -1))
            }
    }

    // MARK: Actions

    func tap(_ p: CGPoint) {
        if sim.onLogo(p) {
            if sim.pokeLogo() { pokes += 1 }
            return
        }
        guard beat < 4 else { return }
        if let n = sim.hit(p) {
            caption = nil
            focus = focus == n ? nil : n
        } else if focus != nil {
            focus = nil
        }
    }

    func go(_ b: Int) {
        let nb: Int = max(first, min(4, b))
        focus = nil
        story = -1
        caption = nil
        sim.enter(beat: nb)
        beat = nb
    }

    func primary() {
        touched = true
        if focus != nil {
            focus = nil
            return
        }
        if beat < 4 { go(beat + 1) } else { done() }
    }

    func show(_ c: IntroCaption, for seconds: Double) {
        caption = c
        Task { @MainActor in
            try? await Task.sleep(for: .seconds(seconds))
            if caption == c { caption = nil }
        }
    }

    /// keeps the beat moving while nobody holds it: the story's routes, the hint, then the next beat
    func run() async {
        guard focus == nil else { return }
        if beat == 4 {
            try? await Task.sleep(for: .seconds(still ? 0.4 : 3.05))
            if !Task.isCancelled { landed += 1 }
            return
        }
        let dur: Double = IntroSim.durations[beat]
        while !Task.isCancelled {
            try? await Task.sleep(for: .milliseconds(100))
            if Task.isCancelled { return }
            if beat == 0 && !hinted && !touched && sim.drawT > 2.4 {
                hinted = true
                show(.hint, for: 4.2)
            }
            if beat == 2 {
                let count: Int = max(1, IntroGraph.shared.story.count)
                let i: Int = Int(sim.beatElapsed / 1.3) % count
                if i != story, i < IntroGraph.shared.story.count {
                    story = i
                    caption = .route(IntroGraph.shared.story[i])
                }
            }
            if sim.beatElapsed >= dur {
                go(beat + 1)
                return
            }
        }
    }
}

/// the five story bars; tap one to jump there
struct IntroBars: View {
    let beat: Int
    var first: Int = 0
    let sim: IntroSim
    let jump: (Int) -> Void

    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 30)) { _ in
            HStack(spacing: 5) {
                ForEach(first..<5, id: \.self) { (i: Int) in
                    bar(i)
                }
            }
        }
    }

    func fill(_ i: Int) -> CGFloat {
        if i < beat || i == 4 && beat == 4 { return 1 }
        if i > beat { return 0 }
        return CGFloat(IntroMath.clamp(sim.beatElapsed / IntroSim.durations[i]))
    }

    func bar(_ i: Int) -> some View {
        let f: CGFloat = fill(i)
        return Button {
            jump(i)
        } label: {
            Capsule()
                .fill(Color.primary.opacity(0.1))
                .frame(height: 3)
                .overlay(alignment: .leading) {
                    GeometryReader { (geo: GeometryProxy) in
                        Capsule().fill(Color.primary).frame(width: geo.size.width * f)
                    }
                }
                .frame(height: 22)
                .contentShape(Rectangle())
        }
        .buttonStyle(.press)
        .accessibilityLabel(IntroView.beatNames[i])
    }
}

/// the words under the drawing
struct IntroWords: View {
    let line: IntroLine

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack(spacing: 8) {
                IntroToneMark(tone: line.tone)
                Text(line.eyebrow.uppercased())
                    .font(.system(size: 11, weight: .semibold, design: .monospaced))
                    .tracking(0.9)
            }
            .foregroundStyle(line.tone.color)
            if let big = line.big {
                Text(big)
                    .font(.system(size: 52, weight: .heavy, design: .rounded))
                    .tracking(-1.6)
                    .foregroundStyle(LinearGradient(colors: [IntroInk.app, IntroInk.wallet, IntroInk.gift], startPoint: .leading, endPoint: .trailing))
                    .lineLimit(1)
                    .minimumScaleFactor(0.7)
                    .padding(.top, 8)
            }
            Text(line.title)
                .font(.system(size: 30, weight: .bold, design: .rounded))
                .tracking(-0.4)
                .fixedSize(horizontal: false, vertical: true)
                .padding(.top, line.big == nil ? 11 : 0)
            if !line.stats.isEmpty {
                VStack(alignment: .leading, spacing: 3) {
                    ForEach(line.stats, id: \.self) { (s: String) in
                        Text(s).lineLimit(1).truncationMode(.tail)
                    }
                }
                .font(.system(size: 12, weight: .medium, design: .monospaced))
                .padding(.top, 9)
            }
            Text(line.text)
                .font(.body)
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
                .padding(.top, 10)
            if let foot = line.foot {
                Text(foot)
                    .font(.system(size: 11, weight: .medium, design: .monospaced))
                    .foregroundStyle(.secondary)
                    .padding(.top, 12)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .accessibilityElement(children: .combine)
    }
}

/// the small mark before each eyebrow: a dot for apps, a diamond for wallets, a pill for gift cards
struct IntroToneMark: View {
    let tone: IntroTone
    var body: some View {
        switch tone {
        case .wallet:
            Rectangle().frame(width: 6, height: 6).rotationEffect(.degrees(45))
        case .gift:
            Capsule().frame(width: 13, height: 7)
        default:
            Circle().frame(width: 7, height: 7)
        }
    }
}
