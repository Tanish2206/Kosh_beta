import SwiftUI

// MARK: - Chapters: the pieces its pages share
//
// Where a chapter page's links go, the notebook's inks (the postcards' words and the chapter pages use them), the
// "Start a new chapter" button, the sample chip, and the demo: a made-up household's year, to show kosh to anyone
// with nothing of yours in it. The page itself is ChaptersPostcards (ChapterIdeas.swift).

// MARK: where a chapter's links go

/// A chapter page's links (every payment, the group pass) go onto the tab's own stack; in the demo they go onto
/// the demo's, and every page reads the samples only.
struct ChapterRouter {
    var push: (Route) -> Void
    var samplesOnly: Bool = false
}

private struct ChapterRouterKey: EnvironmentKey {
    static var defaultValue: ChapterRouter? { nil }
}

extension EnvironmentValues {
    var chapterRouter: ChapterRouter? {
        get { self[ChapterRouterKey.self] }
        set { self[ChapterRouterKey.self] = newValue }
    }
}

// MARK: the notebook's colours, by day and by night

enum NotebookInk {
    static func dyn(_ light: UInt32, _ dark: UInt32, _ la: CGFloat = 1, _ da: CGFloat = 1) -> Color {
        Color(uiColor: UIColor { traits in
            traits.userInterfaceStyle == .dark ? NotebookInk.rgb(dark, da) : NotebookInk.rgb(light, la)
        })
    }

    static func rgb(_ v: UInt32, _ a: CGFloat) -> UIColor {
        UIColor(red: CGFloat((v >> 16) & 0xFF) / 255, green: CGFloat((v >> 8) & 0xFF) / 255, blue: CGFloat(v & 0xFF) / 255, alpha: a)
    }

    /// the page: cream by day, warm charcoal by night
    static let paper: Color = dyn(0xFFFDF8, 0x25211C)
    static let text: Color = dyn(0x1B1712, 0xF3EEE6)
    static let soft: Color = dyn(0x5C5346, 0xB9AF9F)
    static let faint: Color = dyn(0x6B5E4E, 0xA39684)
    static let rule: Color = dyn(0x4664A0, 0x93AEE6, 0.11, 0.12)
    static let margin: Color = dyn(0xC2412D, 0xE07A62, 0.24, 0.32)
    static let shadow: Color = dyn(0x46371E, 0x000000, 0.18, 0.55)
    static let thumb: Color = dyn(0xFFFFFF, 0xEDE7DC)
    static let chip: Color = dyn(0x4A443B, 0xC9C0B2)
}

extension NotebookChapter {
    /// its ink, lifted at night so it still reads; the blank page takes the accent
    @MainActor func color(_ scheme: ColorScheme) -> Color { isNext ? Color.kosh : Color(hex: ink).ink(scheme) }
}

// MARK: the button that never leaves

/// "Start a new chapter", pinned just over the tab bar, a soft light crossing it now and then. What's behind
/// fades out under it, so it never sits on top of a page's words.
struct StartChapterBar: View {
    /// what it fades into: the page behind it
    var fade: Color = Color(uiColor: .systemBackground)
    /// pinned over a sheet's foot (it fades the page behind it), or sitting on the page in line with the rest
    var floating: Bool = true
    let action: () -> Void
    @Environment(\.accessibilityReduceMotion) private var still
    @State private var sheen = false

    var body: some View {
        Button(action: action) {
            HStack(spacing: 8) {
                Image(systemName: "plus")
                    .font(.body.weight(.bold))
                    .accessibilityHidden(true)
                Text("Start a new chapter")
                    .font(.headline)
                    .lineLimit(2)
                    .multilineTextAlignment(.center)
            }
            .foregroundStyle(Color.white)
            .padding(.horizontal, 20)
            .padding(.vertical, 6)
            .frame(maxWidth: .infinity, minHeight: 54)
            .background {
                ZStack {
                    Capsule().fill(KoshGradient.fill)
                    if !still { band }
                }
                .clipShape(Capsule())
                .compositingGroup()
                .shadow(color: Color.kosh.opacity(0.3), radius: 12, x: 0, y: 10)
            }
            .contentShape(Capsule())
        }
        .buttonStyle(PulsePress())
        .accessibilityHint("Name a trip, a wedding, a move: anything with a beginning and an end.")
        .padding(.horizontal, floating ? 16 : 24)
        .padding(.top, 8)
        .padding(.bottom, 8)
        .background {
            if floating {
                LinearGradient(stops: [
                    .init(color: fade.opacity(0), location: 0),
                    .init(color: fade.opacity(0.92), location: 0.4),
                    .init(color: fade, location: 0.75)
                ], startPoint: .top, endPoint: .bottom)
                .padding(.top, -20)
                .ignoresSafeArea(edges: .bottom)
                .allowsHitTesting(false)
            }
        }
        .onAppear { if !still { sheen = true } }
    }

    /// the light crossing it: idle a while, then across
    private var band: some View {
        GeometryReader { g in
            LinearGradient(colors: [Color.white.opacity(0), Color.white.opacity(0.26), Color.white.opacity(0)], startPoint: .leading, endPoint: .trailing)
                .frame(width: g.size.width * 0.3)
                .offset(x: sheen ? g.size.width * 1.5 : -g.size.width * 0.4)
                .animation(.easeInOut(duration: 2.5).delay(4.5).repeatForever(autoreverses: false), value: sheen)
        }
        .allowsHitTesting(false)
    }
}

/// "Sample chapters", with a dashed ring: a label, not a button
struct SampleChip: View {
    var text: String = "Sample chapters"
    var body: some View {
        HStack(spacing: 6) {
            Circle()
                .strokeBorder(NotebookInk.chip, style: StrokeStyle(lineWidth: 1.4, dash: [2, 1.6]))
                .frame(width: 12, height: 12)
            Text(text)
                .font(.caption.weight(.semibold))
                .lineLimit(1)
                .minimumScaleFactor(0.85)
        }
        .foregroundStyle(NotebookInk.chip)
        .padding(.horizontal, 11)
        .frame(minHeight: 28)
        .background(Color.primary.opacity(0.07), in: Capsule())
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(text + ", made up to show how a chapter reads")
    }
}

// MARK: the demo

/// The full sample year, to show kosh to anyone: the timeline, the year's shelf, what's coming, each chapter's
/// page, its payments and its group pass, all from ChapterSamples on a stack of its own. Nothing of yours is read
/// and nothing is written; a strip at the foot of every page says so.
struct ChaptersDemo: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    /// from the demo's "Next chapter": the demo closes, and your own begins
    let startOwn: () -> Void
    @State private var path: [Route] = []
    @State private var month: String = ""
    @State private var back = false
    @State private var jump = 0
    @Namespace private var zoom

    var body: some View {
        NavigationStack(path: $path) {
            year
                .navigationDestination(for: Route.self) { route in
                    RouteDestination(route: route, zoom: zoom)
                }
        }
        .safeAreaInset(edge: .bottom, spacing: 0) {
            DemoStrip { dismiss() }
        }
        .environment(\.chapterRouter, ChapterRouter(push: { r in path.append(r) }, samplesOnly: true))
    }

    @ViewBuilder private var year: some View {
        let items: [Chapter] = ChapterSamples.chapters
        let today: String = store.snap.today
        let shown: String = month.isEmpty ? String(today.prefix(7)) : month
        ScrollView {
            VStack(alignment: .leading, spacing: 0) {
                DemoBanner()
                    .padding(.horizontal, 24)
                    .padding(.top, 8)
                MonthHeader(month: shown, today: today, back: back, inView: ChaptersHome.inView(shown, items, today)) { jump += 1 }
                    .padding(.horizontal, 24)
                    .padding(.top, 26)
                ChapterThread(items: items, today: today, zoom: zoom, month: $month, back: $back, jump: jump,
                              open: { c in path.append(.chapter(c.id)) }, start: startOwn)
                    .padding(.top, 10)
                ThreadKey().padding(.horizontal, 24).padding(.top, 2)
                Hairline().padding(.top, 22)
                MailNotice { path.append(.chapter("bali")) }
                    .padding(.horizontal, 24)
                    .padding(.top, 24)
                let shelf: ShelfData = ShelfData.make(items, today: today, store: store)
                if !shelf.books.isEmpty {
                    Hairline().padding(.top, 28)
                    YearShelf(data: shelf, numbers: ChaptersHome.numbers(items)) { c in path.append(.chapter(c.id)) }
                        .padding(.horizontal, 24)
                        .padding(.top, 26)
                }
                let next: [Chapter] = ChaptersHome.upcoming(items, today)
                if !next.isEmpty {
                    Hairline().padding(.top, 28)
                    ComingUpList(items: next, today: today) { c in path.append(.chapter(c.id)) }
                        .padding(.horizontal, 24)
                        .padding(.top, 26)
                }
                Color.clear.frame(height: 24)
            }
        }
        .scrollIndicators(.hidden)
        .background(Color(uiColor: .systemBackground))
        .navigationTitle("Sample chapters")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button("Done") { dismiss() }
            }
        }
    }
}

struct DemoBanner: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            SampleChip(text: "Sample chapters, nothing of yours")
            Text("A year, told in chapters")
                .font(.system(.title, design: .serif, weight: .semibold))
                .fixedSize(horizontal: false, vertical: true)
                .padding(.top, 14)
            Text("Meet a family kosh made up: a wedding in Jaipur, a road trip over Kunzum, a kitchen that ran over budget. Show it to anyone. No rupee of yours is in here, and nothing you tap changes a thing.")
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
                .padding(.top, 6)
        }
    }
}

/// at the foot of every page in the demo
struct DemoStrip: View {
    let close: () -> Void
    var body: some View {
        HStack(spacing: 10) {
            Circle()
                .strokeBorder(Color.secondary, style: StrokeStyle(lineWidth: 1.4, dash: [2, 1.6]))
                .frame(width: 14, height: 14)
                .accessibilityHidden(true)
            Text("Sample chapters, nothing of yours")
                .font(.subheadline.weight(.semibold))
                .lineLimit(2)
                .minimumScaleFactor(0.85)
            Spacer(minLength: 8)
            Button(action: close) {
                Text("Close demo")
                    .font(.subheadline.weight(.semibold))
                    .padding(.horizontal, 14)
                    .frame(minHeight: 36)
                    .background(Color.primary.opacity(0.08), in: Capsule())
            }
            .buttonStyle(.press)
        }
        .foregroundStyle(Color.primary)
        .padding(.leading, 16)
        .padding(.trailing, 6)
        .padding(.vertical, 6)
        .glassEffect(.regular, in: .capsule)
        .padding(.horizontal, 16)
        .padding(.bottom, 6)
    }
}
