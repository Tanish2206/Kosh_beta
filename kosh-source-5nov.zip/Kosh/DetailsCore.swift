import Foundation

// MARK: - Your details: which account each number belongs to
//
// The part of Your details that decides what a number is a number *about*: whose it is, at which institution, and
// which of that institution's accounts or cards. It holds no screens, so it is checked without Xcode
// (engine-test/details.js compiles this file alone, the way engine-test/split-ways.js compiles Kosh/SplitWays.swift).
// The rules it keeps:
//   • an institution is matched by its whole name, never a part of it: "SBI" is not "SBI Card", "Axis" is not
//     "Axis Max Life", "IDFC" is not "IDFC First"
//   • a number is one account's only when it was printed for that account's digits (or one of the other ways its
//     mail wrote them); the institution's own numbers (a Customer ID, a CRN) sit under the institution, not an account
//   • a number the engine couldn't place at a bank (ok false) belongs to no account at all
//   • nothing is ever filled in: an account the bank never printed a type for says so, in words

/// one detail as the screens show it: whose, with which institution, what it's for (cat), what it is (k) in the
/// institution's own word (label), its value, and where it was found
struct DetailEntry: Identifiable, Hashable {
    let key: String
    let who: String
    let inst: String
    let cat: String
    let k: String
    let label: String
    let v: String
    /// only part of it was ever printed ("XXXX1234"): shown as it is
    let masked: Bool
    let last4: String
    /// how many mails printed it, the last day one did, and those mails
    let n: Int
    let last: String
    let src: [String]
    /// the statement sender it came with (a paper opened on the phone), for the password tries
    let domain: String
    /// you added or corrected it
    let typed: Bool
    /// a statement printed it too
    let fromDoc: Bool
    /// the kind of account the bank printed beside its number ("savings", "current", "deposit"…), "" when it printed
    /// none (engine/21j-build-facts.js › sub)
    var sub: String = ""
    /// kosh can say which account or card this number is: false when it has no such account at that bank, or the
    /// digits fit several (engine/21j-build-facts.js › ok)
    var ok: Bool = true
    var id: String { key }

    /// the same detail found again: counted, its newest day and mails kept, the fullest value kept
    func merged(with o: DetailEntry) -> DetailEntry {
        let fuller: Bool = masked && !o.masked
        var mails: [String] = src
        for m in o.src where !mails.contains(m) { mails.append(m) }
        // (the same number filed two ways — a CRN in a bank's mail and in its card's — takes the more primary of the
        // two categories, so which mail came first never decides where it is shown)
        let keptCat: String = cat.isEmpty ? o.cat : o.cat.isEmpty ? cat
            : (Details.catRank(cat) <= Details.catRank(o.cat) ? cat : o.cat)
        return DetailEntry(key: key, who: who, inst: inst.isEmpty ? o.inst : inst, cat: keptCat, k: k,
                           label: label.isEmpty ? o.label : label, v: fuller ? o.v : v, masked: masked && o.masked,
                           last4: last4.isEmpty ? o.last4 : last4, n: n + o.n, last: max(last, o.last), src: Array(mails.prefix(12)),
                           domain: domain.isEmpty ? o.domain : domain, typed: typed || o.typed, fromDoc: fromDoc || o.fromDoc,
                           sub: sub.isEmpty ? o.sub : sub, ok: ok && o.ok)
    }
}

/// an account, card or loan as Your details needs it: where it is, what the bank called it, the last four kosh has,
/// the other ways its mail wrote them, and whose it is. Built from the accounts, cards and loans already on screen.
struct DetailHolder: Identifiable, Hashable {
    /// which group it is shown under: savings · current · deposit · account · card · loan
    let group: String
    let bank: String
    /// the type the bank printed ("savings", "current", "deposit"…), "" when it printed none
    var atype: String = ""
    let last4: String
    /// the other ways its mail wrote the digits ("821" for ••4821)
    var alias: [String] = []
    let who: String
    /// whose it is, in words ("Yours", "Asha")
    var whose: String = ""
    var id: String { group + "|" + bank + "|" + last4 + "|" + who }
}

/// one instrument's details on the page: the line that names it, its own numbers, and what kosh hasn't seen for it
struct DetailBlock: Identifiable, Hashable {
    let id: String
    /// savings · current · deposit · account · card · loan · known · unplaced
    let group: String
    let bank: String
    /// "Savings account ••4821 · Yours"
    let title: String
    let rows: [DetailEntry]
    /// what kosh can't say about it, in kosh's own words (a part missing is said, never filled in)
    var notes: [String] = []
    /// the short name a screen shows when it already says whose ("Account ••7310", "Savings account ••4821"), and
    /// whether the bank never printed its type (said apart, small, rather than in the name)
    var short: String = ""
    var typeUnknown: Bool = false
}

enum Details {
    /// the page's sections, each with the categories the engine files under it; anything else goes last
    static let sections: [(title: String, cats: [String])] = [
        ("Banks and cards", ["bank", "card"]),
        ("Investments", ["invest"]),
        ("Insurance", ["insurance"]),
        ("Loans", ["loan"]),
        ("Identity and tax", ["identity", "tax"]),
        ("Contact", ["contact"]),
        ("Other details", []),
    ]
    static func section(of cat: String) -> Int {
        sections.firstIndex { $0.cats.contains(cat) } ?? (sections.count - 1)
    }
    /// the engine's order of the categories (engine/21j-build-facts.js › FACT_CAT_ORDER)
    static let cats: [String] = ["bank", "card", "invest", "insurance", "loan", "tax", "identity", "contact"]
    static func catRank(_ c: String) -> Int { cats.firstIndex(of: c) ?? cats.count }
    /// the categories that belong to an account, a card or a loan rather than to the person
    static let money: Set<String> = ["bank", "card", "loan", "invest", "insurance"]
    /// what the institution knows the person by, not one account: shown once, under the institution
    static let wide: Set<String> = ["customerId", "crn", "cif", "ucic", "relationshipNo", "rmName", "rmPhone"]
    /// what you can file a detail under, by hand
    static let pickable: [(String, String)] = [("bank", "A bank account"), ("card", "A card"), ("invest", "Investments"),
                                               ("insurance", "Insurance"), ("loan", "A loan"), ("identity", "Identity"),
                                               ("tax", "Tax"), ("contact", "Contact")]
    /// a statement's category, in a word for the statements list
    static func catTitle(_ cat: String) -> String {
        switch cat {
        case "invest": return "Investments"
        case "insurance": return "Insurance"
        case "loan": return "Loan"
        case "bank": return "Bank"
        case "card": return "Card"
        case "tax": return "Tax"
        case "details", "identity": return "Your details"
        case "contact": return "Contact"
        default: return ""
        }
    }
    /// a paper's category from what kind of paper it is, until it's read
    static func catOf(kind: String) -> String {
        switch kind {
        case "cas", "contract", "nps", "fund": return "invest"
        case "policy": return "insurance"
        case "loan": return "loan"
        case "cardstmt": return "card"
        case "stmt", "fd", "society": return "bank"
        case "tax", "payslip": return "tax"
        default: return ""
        }
    }
    /// how a bank hides the middle or the end of a number
    static let maskChars: Set<Character> = ["X", "x", "*", "•"]
    /// the last four letters or digits of a value, the mask it was printed behind left off the end: "81000567XXX"
    /// ends 0567, not 7XXX, so two accounts masked that way are never read as one
    static func tail(_ s: String) -> String {
        var kept: String = s.filter { $0.isLetter || $0.isNumber }
        while let c = kept.last, maskChars.contains(c) { kept.removeLast() }
        return String(kept.suffix(4))
    }
    /// one detail's identity: whose, with whom, what it is, and its last four (two accounts at one bank are two)
    static func key(who: String, inst: String, k: String, v: String, last4: String?) -> String {
        let end: String = (last4?.isEmpty == false ? last4! : tail(v)).lowercased()
        return who + "|" + inst.lowercased() + "|" + k + "|" + end
    }
    /// what's shown before Face ID: the last four only
    /// details that are no secret (a branch, its IFSC and MICR, who your relationship manager is): always shown in full
    static let open: Set<String> = ["ifsc", "micr", "branch", "rmName"]
    /// the order within one institution: who you are to it, then the accounts and cards, then where they are held
    static let order: [String] = ["customerId", "crn", "cif", "ucic", "relationshipNo", "accountNo", "cardNo", "loanAccount", "upiId",
        "policyNo", "memberId", "nominee", "folio", "demat", "dpId", "boId", "clientId", "pran", "uan", "epfMemberId", "ppfAccount",
        "pan", "aadhaar", "ckyc", "dob", "mobile", "email", "pinCode", "ifsc", "micr", "branch", "rmName", "rmPhone"]
    static func rank(_ k: String) -> Int { order.firstIndex(of: k) ?? order.count }
    static func masked(_ e: DetailEntry) -> String {
        if e.masked { return partial(e.v) }
        if open.contains(e.k) { return e.v }
        let v: String = e.v.trimmingCharacters(in: .whitespaces)
        if v.count <= 4 { return v }
        return "••" + String(v.suffix(4))
    }
    /// what each detail is called, however the bank or the statement writes it (engine/21j-build-facts.js › FACT_LABEL)
    static let labels: [String: String] = [
        "customerId": "Customer ID", "crn": "CRN", "cif": "CIF number", "ucic": "UCIC", "relationshipNo": "Relationship number",
        "accountNo": "Account number", "cardNo": "Card number", "ifsc": "IFSC", "micr": "MICR", "branch": "Branch", "upiId": "UPI ID",
        "loanAccount": "Loan account", "policyNo": "Policy number", "memberId": "Member ID", "nominee": "Nominee", "folio": "Folio",
        "demat": "Demat account", "dpId": "DP ID", "boId": "BO ID", "clientId": "Client ID", "pran": "PRAN", "uan": "UAN",
        "epfMemberId": "EPF member ID", "ppfAccount": "PPF account", "pan": "PAN", "aadhaar": "Aadhaar", "ckyc": "CKYC number",
        "dob": "Date of birth", "mobile": "Mobile", "email": "Email", "pinCode": "PIN code", "rmName": "Relationship manager",
        "rmPhone": "Relationship manager’s phone",
    ]
    static func label(_ k: String, _ printed: String) -> String {
        if let l = labels[k] { return l }
        // (a word kosh has no name for, as the bank wrote it, with a capital to start: "account no." is "Account no.")
        let p: String = printed.trimmingCharacters(in: .whitespaces)
        return p.prefix(1).uppercased() + p.dropFirst()
    }
    /// a number the mail only printed in part, shown one way whatever the bank's mask: "XXXXX527", "XX1597" and
    /// "451460******9938" read "••527", "••1597", "••9938"
    static func partial(_ v: String) -> String {
        let s: String = v.trimmingCharacters(in: .whitespaces)
        guard let cut = s.lastIndex(where: { "Xx*•".contains($0) }) else { return s }
        let tail: String = String(s[s.index(after: cut)...]).filter { $0.isLetter || $0.isNumber }
        if !tail.isEmpty { return "••" + tail }
        // (hidden at the end instead, "8100056352XXX": what it shows, then the dots)
        guard let start = s.firstIndex(where: { "Xx*•".contains($0) }) else { return s }
        let head: String = String(s[..<start]).filter { $0.isLetter || $0.isNumber }
        return head.isEmpty ? s : head + "••"
    }
    /// a detail's kind from what it's called, for one added by hand
    static func kindOf(_ label: String) -> String {
        let l: String = label.lowercased()
        let words: [(String, String)] = [("crn", "crn"), ("customer", "custid"), ("cif", "custid"), ("ifsc", "ifsc"), ("folio", "folio"),
                                         ("policy", "policy"), ("pran", "pran"), ("uan", "uan"), ("pan", "pan"), ("dp", "dpid"),
                                         ("client", "clientid"), ("loan", "loanacct"), ("card", "card"), ("account", "acct"),
                                         ("mobile", "mobile"), ("phone", "mobile"), ("email", "email")]
        return words.first { l.contains($0.0) }?.1 ?? "other"
    }

    // MARK: whose, where, and which account

    /// one institution, by its whole name: "SBI" is not "SBI Card", "Axis" is not "Axis Max Life", "IDFC" is not
    /// "IDFC First". A part of a name matching was how an SBI savings page came to show SBI Card's numbers.
    static func sameInst(_ a: String, _ b: String) -> Bool {
        let x: String = a.trimmingCharacters(in: .whitespaces).lowercased()
        let y: String = b.trimmingCharacters(in: .whitespaces).lowercased()
        return !x.isEmpty && x == y
    }
    /// this person's, or the household's when looking at everyone
    static func mine(_ whose: String, _ who: String) -> Bool { whose == who || (who == "family" && whose == "me") }
    /// the digits agree: one ends with the other (an alert that printed "821" for ••4821)
    static func endsAgree(_ a: String, _ ends: Set<String>) -> Bool {
        guard !a.isEmpty else { return false }
        for b in ends where !b.isEmpty && (a == b || a.hasSuffix(b) || b.hasSuffix(a)) { return true }
        return false
    }
    /// the details that are one instrument's: at this institution (its whole name), this person's, and printed for
    /// these digits. An institution's own numbers (a Customer ID, a CRN) are no account's — instWide has those — and
    /// a number kosh can't place at that bank belongs to no account at all.
    static func forInst(_ inst: String, who: String, last4: String = "", alias: [String] = [], from all: [DetailEntry]) -> [DetailEntry] {
        guard !inst.isEmpty else { return [] }
        let ends: Set<String> = Set(([last4] + alias).map { $0.lowercased() }.filter { !$0.isEmpty })
        return all.filter { (e: DetailEntry) -> Bool in
            guard mine(e.who, who), sameInst(e.inst, inst), money.contains(e.cat), e.ok else { return false }
            // (a row kosh has no digits for at all — a debit card whose account it can't tell — takes the bank's)
            guard !ends.isEmpty else { return true }
            guard !wide.contains(e.k) else { return false }
            return endsAgree(e.last4.lowercased(), ends)
        }
        .sorted { (rank($0.k), $0.label, $0.v) < (rank($1.k), $1.label, $1.v) }
    }
    /// what the institution knows this person by, not one account: a Customer ID, a CRN, a CIF, the relationship
    /// manager. Shown once, under its own heading.
    static func instWide(_ inst: String, who: String, from all: [DetailEntry]) -> [DetailEntry] {
        guard !inst.isEmpty else { return [] }
        return all.filter { mine($0.who, who) && sameInst($0.inst, inst) && wide.contains($0.k) && $0.ok }
            .sorted { (rank($0.k), $0.label, $0.v) < (rank($1.k), $1.label, $1.v) }
    }
    /// printed, but kosh can't say which account: a number with no such account at that bank (or digits that fit
    /// several), and a branch, IFSC or MICR the mail printed without naming an account at a bank with more than one
    static func unplaced(_ inst: String, who: String, from all: [DetailEntry]) -> [DetailEntry] {
        guard !inst.isEmpty else { return [] }
        return all.filter { (e: DetailEntry) -> Bool in
            guard mine(e.who, who), sameInst(e.inst, inst), money.contains(e.cat) else { return false }
            return !e.ok || (open.contains(e.k) && e.last4.isEmpty)
        }
        .sorted { (rank($0.k), $0.label, $0.v) < (rank($1.k), $1.label, $1.v) }
    }

    // MARK: naming an instrument

    /// the account's type in the bank's own words; "" when the bank never printed one — never guessed from its name
    static let typeWords: [String: String] = ["savings": "Savings account", "current": "Current account",
        "salary": "Salary account", "nre": "NRE account", "nro": "NRO account", "deposit": "Fixed deposit",
        "od": "Overdraft account", "cc": "Cash credit account"]
    static func typeWord(_ atype: String?) -> String { typeWords[atype ?? ""] ?? "" }
    /// what kosh says in place of a type it has never been shown
    static let noType: String = "kosh hasn’t seen the type yet"
    /// which group an account's type is shown under
    static func groupOf(atype: String) -> String {
        switch atype {
        case "savings", "salary", "nre", "nro": return "savings"
        case "current", "od", "cc": return "current"
        case "deposit": return "deposit"
        default: return "account"
        }
    }
    /// the groups in the order the page shows them, and the heading over each; a group with nothing in it is never drawn
    static let groups: [(id: String, title: String)] = [("savings", "Savings"), ("current", "Current"),
        ("deposit", "Deposits"), ("account", "Accounts"), ("card", "Credit cards"), ("loan", "Loans"),
        ("invest", "Investments")]
    static func groupRank(_ g: String) -> Int { groups.firstIndex { $0.id == g } ?? groups.count }
    static func groupTitle(_ g: String) -> String { groups.first { $0.id == g }?.title ?? "" }
    /// an instrument named by all the parts kosh has: the bank's word for its type, its last four and whose it is.
    /// A part kosh hasn't been shown is said in words, never filled in: "Account ••7310 · Yours · kosh hasn’t seen
    /// the type yet". (Only an account has a type to miss: a card is a card, a loan a loan.)
    static func instrumentName(type: String, last4: String, whose: String, kind: String = "Account") -> String {
        var bits: [String] = []
        let head: String = type.isEmpty ? kind : type
        bits.append(last4.isEmpty ? head : head + " ••" + last4)
        if !whose.isEmpty { bits.append(whose) }
        if type.isEmpty && kind == "Account" { bits.append(noType) }
        return bits.joined(separator: " · ")
    }

    // MARK: the page, grouped by the instrument each number belongs to

    /// Every figure under the instrument that owns it, so none can be read against the wrong account: one block per
    /// account, card and loan, then what each institution knows the person by, then the numbers it can't place.
    /// Nothing is drawn that has nothing in it, and no block ever borrows another's value.
    static func blocks(holders: [DetailHolder], who: String, from all: [DetailEntry]) -> [DetailBlock] {
        var rowsOf: [String: [DetailEntry]] = [:]
        for h in holders { rowsOf[h.id] = forInst(h.bank, who: h.who, last4: h.last4, alias: h.alias, from: all) }
        // which accounts at each bank do have an IFSC, so one that hasn't can say so and point at the one that has
        var ifscAt: [String: [String]] = [:]
        for h in holders where h.group != "card" && h.group != "loan" && !h.last4.isEmpty {
            if (rowsOf[h.id] ?? []).contains(where: { $0.k == "ifsc" }) { ifscAt[h.bank.lowercased(), default: []].append(h.last4) }
        }
        var out: [DetailBlock] = []
        for h in holders {
            let rows: [DetailEntry] = rowsOf[h.id] ?? []
            if rows.isEmpty { continue }
            let kind: String = h.group == "card" ? "Card" : h.group == "loan" ? "Loan" : "Account"
            var notes: [String] = []
            if h.group != "card" && h.group != "loan" && !rows.contains(where: { $0.k == "ifsc" }),
               let one = (ifscAt[h.bank.lowercased()] ?? []).first(where: { $0 != h.last4 }) {
                notes.append("No IFSC for this account yet. The one below was printed for ••" + one + ".")
            }
            let type: String = kind == "Account" ? typeWord(h.atype) : ""
            out.append(DetailBlock(id: h.id, group: h.group, bank: h.bank,
                                   title: instrumentName(type: type, last4: h.last4, whose: h.whose, kind: kind),
                                   rows: rows, notes: notes,
                                   short: (type.isEmpty ? kind : type) + (h.last4.isEmpty ? "" : " ••" + h.last4),
                                   typeUnknown: type.isEmpty && kind == "Account"))
        }
        out.sort { (groupRank($0.group), $0.bank, $0.title) < (groupRank($1.group), $1.bank, $1.title) }
        // then what each institution knows the person by, and last the numbers it can't put under one account
        for b in instsIn(all, who: who) {
            let known: [DetailEntry] = instWide(b, who: who, from: all)
            if !known.isEmpty { out.append(DetailBlock(id: "known|" + b, group: "known", bank: b, title: "Known to " + b + " as", rows: known)) }
        }
        for b in instsIn(all, who: who) {
            let loose: [DetailEntry] = unplaced(b, who: who, from: all)
            if !loose.isEmpty {
                out.append(DetailBlock(id: "unplaced|" + b, group: "unplaced", bank: b,
                                       title: "Printed, but kosh can’t say which account",
                                       rows: loose,
                                       notes: [b + " printed these without saying which account they are for, so they stay here rather than go under the wrong one."]))
            }
        }
        return out
    }
    /// the institutions this person has details with, the one with the most first (the strip's order)
    static func instsIn(_ all: [DetailEntry], who: String) -> [String] {
        var count: [String: Int] = [:]
        var name: [String: String] = [:]
        for e in all where mine(e.who, who) && !e.inst.isEmpty {
            count[e.inst.lowercased(), default: 0] += 1
            name[e.inst.lowercased()] = e.inst
        }
        return count.keys.sorted { (a: String, b: String) -> Bool in
            count[a] == count[b] ? a < b : (count[a] ?? 0) > (count[b] ?? 0)
        }.compactMap { name[$0] }
    }
}
