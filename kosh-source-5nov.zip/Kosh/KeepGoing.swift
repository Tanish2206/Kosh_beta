import BackgroundTasks
import UIKit

// MARK: - Reading carries on when you lock the phone
//
// A year of mail, the wallets' and shops' mail, the reader going through what the rules missed: these take
// minutes, and you shouldn't have to keep kosh on screen for them. When kosh leaves the screen with reading under
// way (leaving()):
//  • kosh's own Lock Screen entry (ReadingLive) says what the bar above the tab bar was saying, and keeps moving;
//  • the mail still to read goes to a background download session (BackgroundMail), which iOS carries on with
//    while the phone is locked, waking kosh to read in what came back;
//  • the work on the phone itself gets the usual half-minute to go on, and to save what it has.
// When iOS wakes kosh later to catch up or refresh (BackgroundReading), the work carries on for as long as that
// task lasts.
//
// Every long piece of work calls begin() and end() in pairs. Whatever ends kosh's time (the half-minute running
// out, a task expiring) sets `stopped`: every loop winds down at its next step, and what was read is saved with
// what's still to read, so nothing starts over.

@MainActor
final class KeepGoing {
    static let shared = KeepGoing()

    /// the catch-up or refresh task iOS woke kosh for: work carries on while it lasts
    private var woken: [ObjectIdentifier: BGTask] = [:]
    private var holds = 0
    private var grace: UIBackgroundTaskIdentifier = .invalid
    private var timer: Timer?
    /// what to show and how far along: the bar's words, read from the session (the Lock Screen says the same)
    var status: (() -> ReadingNow?)?
    /// the first begin, and the last end (with whether it was stopped)
    var onStart: (() -> Void)?
    var onEnd: ((Bool) -> Void)?
    /// the system (its time is up) stopped the work: loops wind down and save
    private(set) var stopped = false
    /// iOS is letting the work carry on with kosh in the background (a catch-up or refresh task)
    var carrying: Bool { !woken.isEmpty && !stopped }
    /// some long work is under way
    var busy: Bool { holds > 0 }
    /// work may go on: kosh is on screen, or iOS is carrying it
    var mayRun: Bool { !stopped && (UIApplication.shared.applicationState == .active || carrying) }

    /// long work that should carry on if you lock the phone; pair every begin with an end
    func begin(_ title: String) {
        holds += 1
        guard holds == 1 else { return }
        stopped = false
        onStart?()
        holdGrace()
        startTimer()
    }

    /// kosh is going off screen (the phone locks, you switch apps), while it's still in front: kosh's own Lock Screen
    /// entry if reading is under way, and the mail still to read handed to the background downloads. iOS allows
    /// neither once kosh is in the background (the downloads would wait for iOS's convenience), so this comes first.
    func leaving() {
        // iOS 26 and later: the reading itself carries on in the background, its progress in iOS's own banner, for as
        // long as it takes (you can stop it there). Only if iOS says no: the Lock Screen entry and the downloads
        if holds > 0 && (continued != nil || continueInBackground()) { return }
        ReadingLive.shared.leaving()
        BackgroundMail.shared.leaving()
    }

    // MARK: carrying on in the background (iOS 26: continued processing)

    /// the background task iOS runs the reading in after you leave kosh, while it lasts
    private var continued: BGTask?
    /// asked for and not started yet
    private var continuedAsked = false
    private var continuedSeq = 0

    /// asks iOS to carry the work under way on after kosh leaves the screen; false when it can't (an older iOS, or iOS
    /// declined), and the half-minute and the catch-up later stand in
    private func continueInBackground() -> Bool {
        guard #available(iOS 26, *) else { return false }
        if continuedAsked { return true }
        guard UIApplication.shared.applicationState != .background, let bid = Bundle.main.bundleIdentifier else { return false }
        // (a new name each time, under the pattern Info.plist lists, registered just before it's asked for: iOS
        // routes each continued task to its own handler)
        continuedSeq += 1
        let id: String = bid + ".continued.r" + String(Int(Date().timeIntervalSince1970)) + "x" + String(continuedSeq)
        let registered: Bool = BGTaskScheduler.shared.register(forTaskWithIdentifier: id, using: .main) { t in
            MainActor.assumeIsolated { KeepGoing.shared.continuedStarted(t) }
        }
        guard registered else { return false }
        let now: ReadingNow? = status?()
        let r = BGContinuedProcessingTaskRequest(identifier: id, title: now?.title ?? "Reading your mail", subtitle: now?.detail ?? "kosh carries on")
        // (now or not at all: a read that waits for later is the catch-up's job)
        r.strategy = .fail
        // the GPU in the background too, on iPhones that allow it (the reader then keeps its on-screen speed)
        // (needs the Background GPU Access capability, which a paid Apple Developer account gives; a personal team
        // can't sign it, so it stays off until kosh moves to a paid account: then set askForBackgroundGPU to true
        // and add com.apple.developer.background-tasks.continued-processing.gpu to Kosh.entitlements)
        continuedGPU = KeepGoing.askForBackgroundGPU && BGTaskScheduler.supportedResources.contains(.gpu)
        if continuedGPU { r.requiredResources = .gpu }
        do { try BGTaskScheduler.shared.submit(r) } catch { continuedGPU = false; return false }
        continuedAsked = true
        return true
    }

    /// iOS started the task: the work goes on while it lasts, its progress kept up to date on iOS's banner
    /// the continued task was asked for with the GPU (iOS 26 on iPhones that support it)
    private var continuedGPU = false
    /// ask iOS for the GPU in the background (off: a personal team can't sign the capability)
    static let askForBackgroundGPU = false

    private func continuedStarted(_ t: BGTask) {
        continuedAsked = false
        // (the work ended, or you came back, before iOS started it)
        guard holds > 0, UIApplication.shared.applicationState != .active else { t.setTaskCompleted(success: true); return }
        continued = t
        KoshReader.setBackgroundGPU(continuedGPU)
        woke(t)
        t.expirationHandler = {
            DispatchQueue.main.async { MainActor.assumeIsolated { KeepGoing.shared.continuedOver(expired: true) } }
        }
        showContinued()
    }

    /// the banner's words and bar, as the bar above the tab bar has them
    private func showContinued() {
        guard #available(iOS 26, *), let c = continued as? BGContinuedProcessingTask, let now = status?() else { return }
        c.updateTitle(now.title, subtitle: now.detail)
        let total: Int64 = Int64(max(1, now.total)), done: Int64 = Int64(min(max(0, now.done), max(1, now.total)))
        if now.indeterminate || now.total <= 0 {
            c.progress.totalUnitCount = 100
            c.progress.completedUnitCount = max(1, min(99, c.progress.completedUnitCount + 1))
        } else {
            c.progress.totalUnitCount = total
            c.progress.completedUnitCount = done
        }
    }

    /// the task is over: the work ended, you came back to kosh (it goes on in front), or iOS took the time back
    private func continuedOver(expired: Bool) {
        guard let t = continued else { return }
        continued = nil
        KoshReader.setBackgroundGPU(false)
        if expired {
            // iOS wants its time back: the loops wind down and save, and what's left waits for the catch-up
            stop()
            BackgroundMail.shared.handOffNow()
            if LiveSession.current?.hasPlans == true { BackgroundReading.askForCatchUp() }
            ReadingLive.shared.settle()
        }
        doneWoken(ObjectIdentifier(t), success: !expired)
    }

    func end() {
        guard holds > 0 else { return }
        holds -= 1
        guard holds == 0 else { return }
        timer?.invalidate()
        timer = nil
        let wasStopped = stopped
        endGrace()
        // (the work is done: iOS's banner goes)
        if continued != nil { continuedOver(expired: false) }
        onEnd?(wasStopped)
        if UIApplication.shared.applicationState != .active {
            // off screen: anything listed meanwhile goes to the downloads, and the Lock Screen says what's next
            // (the downloads carrying on, all caught up, or paused)
            BackgroundMail.shared.handOffNow()
            ReadingLive.shared.settle()
        }
    }

    /// kosh's time is up: every loop winds down at its next step. What was read is saved now, with what's
    /// still to read, in case iOS suspends kosh before the loops get there.
    func stop() {
        stopped = true
        LiveSession.current?.checkpoint(force: true)
    }

    /// kosh is on screen again: the bar shows the reading (the Lock Screen entry goes), what the downloads still had
    /// on its way is cancelled, and the work goes on here from where it got to
    func backInFront() {
        // (back in front: the work goes on here, the background task is done with)
        if continued != nil { continuedOver(expired: false) }
        stopped = false
        ReadingLive.shared.backInFront()
        BackgroundMail.shared.backInFront()
        guard holds > 0 else { return }
        holdGrace()
        if timer == nil { startTimer() }
    }

    /// kosh is going to the background with work in hand: the half-minute, if it hasn't one already
    func toBackground() {
        guard holds > 0 else { return }
        holdGrace()
    }

    /// iOS woke kosh to catch up or refresh: work goes on until that task's time is up
    func woke(_ t: BGTask) {
        woken[ObjectIdentifier(t)] = t
        stopped = false
    }
    func isWoken(_ id: ObjectIdentifier) -> Bool { woken[id] != nil }
    /// that task is over: iOS is told, once
    func doneWoken(_ id: ObjectIdentifier, success: Bool) {
        woken.removeValue(forKey: id)?.setTaskCompleted(success: success)
    }

    private func holdGrace() {
        guard grace == .invalid else { return }
        grace = UIApplication.shared.beginBackgroundTask(withName: "kosh reading") {
            // on the main thread, and iOS suspends kosh as soon as it returns: save first
            MainActor.assumeIsolated { KeepGoing.shared.graceOver() }
        }
    }

    private func graceOver() {
        if !carrying {
            stop()
            // what's still listed goes to the downloads (with the tokens in hand: there's no time to fetch one), and
            // iOS is asked for time later for the rest
            BackgroundMail.shared.handOffNow()
            if LiveSession.current?.hasPlans == true { BackgroundReading.askForCatchUp() }
        }
        endGrace()
        ReadingLive.shared.settle()
    }

    private func endGrace() {
        if grace != .invalid {
            UIApplication.shared.endBackgroundTask(grace)
            grace = .invalid
        }
    }

    private func startTimer() {
        timer?.invalidate()
        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
            MainActor.assumeIsolated { KeepGoing.shared.tick() }
        }
    }

    /// each second while the work runs: the Lock Screen entry kept moving (every few seconds), and the tokens the
    /// downloads would carry kept fresh
    private func tick() {
        if continued != nil { showContinued() }
        ReadingLive.shared.tick()
        BackgroundMail.shared.tick()
    }
}

/// What kosh is reading right now, said the same way above the tab bar and on the Lock Screen
struct ReadingNow: Equatable {
    enum Kind: Equatable { case finding, reading, again, inbox, wallets, wider, statements, docs, year, reader, resuming, waiting, done }
    var kind: Kind
    var sym: String
    /// "Reading new mail"
    var title: String
    /// the one-line form, when the tab bar has shrunk: "Reading"
    var short: String
    /// beside the title: "2 min left", "March"
    var aside: String = ""
    /// on the right: "412 of 1,240", "2,340 found", "1,240 read"
    var count: String
    var done: Int
    var total: Int
    /// still counting: the bar seeks rather than fills
    var indeterminate = false
    /// waiting for the internet: grey, still
    var paused = false
    /// kosh was closed or stopped, and carries on from the email it got to
    var resumed = false
    /// all caught up
    var finished = false
    /// the Lock Screen's second line: "412 of 1,240 emails"
    var detail: String

    var fraction: Double { finished ? 1 : total > 0 ? min(1, Double(done) / Double(total)) : 0 }

    static func n(_ v: Int) -> String { Fmt.inr(Double(v)) }
    static func pair(_ done: Int, _ total: Int) -> String { n(done) + " of " + n(total) }

    @MainActor
    static func of(_ live: LiveSession) -> ReadingNow? {
        guard var s = working(live) else { return caughtUp(live) }
        if live.pickingUp && !s.indeterminate {
            s.kind = .resuming; s.sym = "arrow.clockwise"; s.title = "Picking up where it stopped"; s.short = "Picking up"; s.aside = ""; s.resumed = true
        }
        if !Net.shared.online {
            s.kind = .waiting; s.sym = "wifi.slash"; s.title = "Waiting for the internet"; s.short = "Offline"; s.aside = ""
            s.paused = true; s.resumed = false
            if s.indeterminate { s.count = "" }
            s.detail = s.total > 0 && !s.indeterminate ? "Paused at " + pair(s.done, s.total) : "Paused"
        }
        return s
    }

    /// the work under way, if any
    @MainActor
    private static func working(_ live: LiveSession) -> ReadingNow? {
        if live.phase == .claude && live.claudeTotal > 0 {
            let c: String = pair(live.claudeDone, live.claudeTotal)
            return ReadingNow(kind: .reader, sym: "sparkles", title: live.aiReadingTitle, short: live.aiMode == "claude" ? "Smart" : "Reader",
                              count: c, done: live.claudeDone, total: live.claudeTotal, detail: c + " money emails")
        }
        if live.phase == .listing {
            let c: String = live.found > 0 ? n(live.found) + " found" : "Looking"
            return ReadingNow(kind: .finding, sym: "magnifyingglass", title: "Finding your money mail", short: "Finding",
                              count: c, done: live.found, total: 0, indeterminate: true, detail: live.found > 0 ? n(live.found) + " found so far" : "Looking through your inbox")
        }
        if live.phase == .reading {
            var aside = ""
            if let s = live.secondsLeft, s > 20 { aside = s < 90 ? "a minute left" : String(Int((Double(s) / 60).rounded())) + " min left" }
            let c: String = pair(live.fetched, live.total)
            return ReadingNow(kind: .reading, sym: "envelope.fill", title: "Reading new mail", short: "Reading", aside: aside,
                              count: c, done: live.fetched, total: live.total, detail: c + " emails")
        }
        if live.reingesting && live.againTotal > 0 {
            let c: String = pair(live.againDone, live.againTotal)
            return ReadingNow(kind: .again, sym: "envelope.open.fill", title: "Rereading with new rules", short: "Rereading",
                              count: c, done: live.againDone, total: live.againTotal, detail: c + " emails")
        }
        if live.findingWallets || live.findingDocs || live.readingInbox || live.findingWider || live.lookingFor != nil {
            let kind: Kind = live.findingWallets ? .wallets : live.findingDocs ? .statements : (live.findingWider || live.lookingFor != nil) ? .wider : .inbox
            let sym: String = kind == .wallets ? "wallet.bifold.fill" : kind == .statements ? "doc.text.fill" : kind == .wider ? "scope" : "envelope.fill"
            let title: String = kind == .wallets ? "Reading wallet and shop mail" : kind == .statements ? "Finding statements and policies"
                : live.lookingFor != nil ? "Looking for " + (live.lookingFor ?? "") : kind == .wider ? "Looking wider for money mail" : "Reading the new inbox"
            let short: String = kind == .wallets ? "Wallets" : kind == .statements ? "Statements" : kind == .wider ? "Wider" : "Inbox"
            if live.bgListing {
                let c: String = live.bgTotal > 0 ? n(live.bgTotal) + " found" : "Looking"
                return ReadingNow(kind: kind, sym: sym, title: title, short: short, count: c, done: live.bgTotal, total: 0, indeterminate: true, detail: c)
            }
            let c: String = pair(live.bgFetched, live.bgTotal)
            return ReadingNow(kind: kind, sym: sym, title: title, short: short, count: c, done: live.bgFetched, total: live.bgTotal, detail: c + " emails")
        }
        if live.readingDocs && live.docTotal > 0 {
            let label: String = live.docLabel
            let short: String = label.hasSuffix("invoices") && !label.contains("statements") ? "Invoices" : "Statements"
            let c: String = pair(live.docDone, live.docTotal)
            return ReadingNow(kind: .docs, sym: "doc.text.fill", title: label, short: short, count: c, done: live.docDone, total: live.docTotal, detail: c + ", on this phone")
        }
        if live.backfilling {
            let month: String = live.bgMonth.isEmpty ? "" : SetupProgress.monthName(live.bgMonth)
            if live.yearListing || live.yearTotal == 0 {
                let c: String = live.yearTotal > 0 ? n(live.yearTotal) + " found" : "Counting"
                return ReadingNow(kind: .year, sym: "calendar", title: "Filling in the year", short: "The year", aside: "counting",
                                  count: c, done: live.yearTotal, total: 0, indeterminate: true, detail: live.yearTotal > 0 ? n(live.yearTotal) + " emails found so far" : "Counting the year’s mail")
            }
            let c: String = pair(live.yearDone, live.yearTotal)
            return ReadingNow(kind: .year, sym: "calendar", title: "Filling in the year", short: "The year", aside: month,
                              count: c, done: live.yearDone, total: live.yearTotal, detail: c + " emails" + (month.isEmpty ? "" : " · " + month))
        }
        return nil
    }

    /// all caught up, for a moment after the reading ends
    @MainActor
    private static func caughtUp(_ live: LiveSession) -> ReadingNow? {
        guard let c = live.caughtUp else { return nil }
        let count: String = c.read > 0 ? n(c.read) + " read" : "Nothing new"
        return ReadingNow(kind: .done, sym: "checkmark", title: "All caught up", short: "Caught up", count: count,
                          done: max(1, c.read), total: max(1, c.read), finished: true, detail: count)
    }
}
