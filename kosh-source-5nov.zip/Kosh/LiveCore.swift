import Foundation
import CryptoKit
import JavaScriptCore
import Security

// MARK: - The beta's plumbing: Keychain, Google sign-in, Gmail, Claude and the engine.
// Everything here runs only when no snapshot is bundled (the kosh beta build).

enum LiveError: LocalizedError {
    case noClientID, signIn(String), noGmailScope, http(Int, String), badKey, busy(Double), engine(String)
    var errorDescription: String? {
        switch self {
        case .noClientID: return "The Google client ID isn’t set. Paste it in Settings › Help and diagnostics."
        case .signIn(let s): return s
        case .noGmailScope: return "kosh needs to read Gmail. Sign in again and tick the Gmail box when Google asks."
        case .http(let c, let s): return "The server said \(c). \(s)"
        case .badKey: return "The AI key wasn’t accepted. Check it in Settings."
        case .busy: return "Busy, trying again shortly."
        case .engine(let s): return "The reader stopped: \(s)"
        }
    }
}

// MARK: Keychain: the Google refresh token and the Claude key, on this phone only

enum Keychain {
    static let service = "kosh.beta"
    /* (31 Oct) what each name holds, once read. Every read was a round trip to the phone's Keychain service, and the
       same few names were read dozens of times on the main thread: three for each person on the Statements page and in
       the diagnostics (each locked sender's details), and the details after every build. Only kosh writes them, and
       only through set() below, which keeps this in step. A read that failed for any reason but "nothing kept under
       that name" (the phone not unlocked since it started) is not remembered, so it's tried again. Never written
       anywhere: it lives as long as kosh runs, as the values read from the Keychain always did */
    private static let cacheLock = NSLock()
    nonisolated(unsafe) private static var cache: [String: String?] = [:]
    nonisolated(unsafe) private static var writeCount: Int = 0
    /// how many writes kosh has made: what's worked out from what the Keychain holds (lockedNeeds) is worked out again
    /// when it changes
    static var writes: Int { cacheLock.lock(); defer { cacheLock.unlock() }; return writeCount }

    static func set(_ value: String?, for key: String) {
        let base: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
                                   kSecAttrService as String: service,
                                   kSecAttrAccount as String: key]
        let gone: OSStatus = SecItemDelete(base as CFDictionary)
        var known: String?? = nil
        if let value, !value.isEmpty {
            var add = base
            add[kSecValueData as String] = Data(value.utf8)
            add[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
            if SecItemAdd(add as CFDictionary, nil) == errSecSuccess { known = .some(value) }
        } else if gone == errSecSuccess || gone == errSecItemNotFound {
            known = .some(nil)
        }
        cacheLock.lock()
        // (a write that may not have landed is forgotten, so the next read asks the Keychain)
        if let known { cache[key] = .some(known) } else { cache.removeValue(forKey: key) }
        writeCount &+= 1
        cacheLock.unlock()
    }
    static func get(_ key: String) -> String? {
        cacheLock.lock()
        if let hit: String? = cache[key] { cacheLock.unlock(); return hit }
        cacheLock.unlock()
        let q: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
                                kSecAttrService as String: service,
                                kSecAttrAccount as String: key,
                                kSecReturnData as String: true,
                                kSecMatchLimit as String: kSecMatchLimitOne]
        var out: AnyObject?
        let status: OSStatus = SecItemCopyMatching(q as CFDictionary, &out)
        if status == errSecSuccess, let d = out as? Data {
            let s: String? = String(data: d, encoding: .utf8)
            cacheLock.lock(); cache[key] = .some(s); cacheLock.unlock()
            return s
        }
        if status == errSecItemNotFound { cacheLock.lock(); cache[key] = .some(nil); cacheLock.unlock() }
        return nil
    }
    /// nothing is kept under this name (not merely unreadable while the phone is locked)
    static func missing(_ key: String) -> Bool {
        cacheLock.lock()
        if let hit: String? = cache[key] { cacheLock.unlock(); return hit == nil }
        cacheLock.unlock()
        let q: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
                                kSecAttrService as String: service,
                                kSecAttrAccount as String: key,
                                kSecMatchLimit as String: kSecMatchLimitOne]
        return SecItemCopyMatching(q as CFDictionary, nil) == errSecItemNotFound
    }
}

extension Data {
    var base64URL: String {
        base64EncodedString().replacingOccurrences(of: "+", with: "-").replacingOccurrences(of: "/", with: "_").replacingOccurrences(of: "=", with: "")
    }
    init?(base64URL s: String) {
        var b = s.replacingOccurrences(of: "-", with: "+").replacingOccurrences(of: "_", with: "/")
        while b.count % 4 != 0 { b += "=" }
        self.init(base64Encoded: b)
    }
}

// MARK: Google sign-in: OAuth with PKCE, the way Google asks iOS apps to do it

struct GoogleTokens { var access: String; var expires: Date; var refresh: String?; var email: String; var name: String; var scope: String }

enum GoogleOAuth {
    static let scopes = "openid email profile https://www.googleapis.com/auth/gmail.readonly"

    /// "123-abc.apps.googleusercontent.com" → "com.googleusercontent.apps.123-abc"
    static func scheme(_ clientID: String) -> String {
        "com.googleusercontent.apps." + clientID.replacingOccurrences(of: ".apps.googleusercontent.com", with: "")
    }
    static func redirect(_ clientID: String) -> String { scheme(clientID) + ":/oauth2redirect" }

    static func pkce() -> (verifier: String, challenge: String) {
        var bytes = [UInt8](repeating: 0, count: 32)
        _ = SecRandomCopyBytes(kSecRandomDefault, bytes.count, &bytes)
        let verifier = Data(bytes).base64URL
        let challenge = Data(SHA256.hash(data: Data(verifier.utf8))).base64URL
        return (verifier, challenge)
    }

    /// `pick`: show Google's account chooser even when one account is already signed in on this phone,
    /// so "Add another Gmail" doesn't silently come back with the first account
    static func authURL(clientID: String, challenge: String, state: String, hint: String?, pick: Bool = false) -> URL {
        var c = URLComponents(string: "https://accounts.google.com/o/oauth2/v2/auth")!
        var q: [URLQueryItem] = [
            URLQueryItem(name: "client_id", value: clientID),
            URLQueryItem(name: "redirect_uri", value: redirect(clientID)),
            URLQueryItem(name: "response_type", value: "code"),
            URLQueryItem(name: "scope", value: scopes),
            URLQueryItem(name: "code_challenge", value: challenge),
            URLQueryItem(name: "code_challenge_method", value: "S256"),
            URLQueryItem(name: "state", value: state),
            URLQueryItem(name: "prompt", value: pick ? "select_account consent" : "consent"),
        ]
        if let hint, !hint.isEmpty { q.append(URLQueryItem(name: "login_hint", value: hint)) }
        c.queryItems = q
        return c.url!
    }

    static func form(_ items: [String: String]) -> Data {
        var allowed = CharacterSet.alphanumerics
        allowed.insert(charactersIn: "-._~")
        let s = items.map { k, v in k + "=" + (v.addingPercentEncoding(withAllowedCharacters: allowed) ?? v) }.joined(separator: "&")
        return Data(s.utf8)
    }

    static func token(_ items: [String: String]) async throws -> [String: Any] {
        var req = URLRequest(url: URL(string: "https://oauth2.googleapis.com/token")!)
        req.httpMethod = "POST"
        req.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        req.httpBody = form(items)
        let (data, resp) = try await URLSession.shared.data(for: req)
        let code = (resp as? HTTPURLResponse)?.statusCode ?? 0
        let json = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] ?? [:]
        guard code == 200 else {
            let err = (json["error"] as? String) ?? ""
            let why = (json["error_description"] as? String) ?? (err.isEmpty ? String(data: data, encoding: .utf8) ?? "" : err)
            // the error's own code goes in too: "invalid_grant" is how the caller knows the sign-in has ended
            throw LiveError.signIn("Google said no (\(code)\(err.isEmpty ? "" : ", " + err)): \(why)")
        }
        return json
    }

    /// ends Google's grant for this app: the refresh token stops working at once, and the access shows as removed in the
    /// person's Google account. Best effort (offline, it lapses anyway once kosh forgets the token)
    static func revoke(_ refreshToken: String) {
        guard !refreshToken.isEmpty else { return }
        var req = URLRequest(url: URL(string: "https://oauth2.googleapis.com/revoke")!)
        req.httpMethod = "POST"
        req.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        req.httpBody = form(["token": refreshToken])
        URLSession.shared.dataTask(with: req).resume()
    }

    static func claims(_ idToken: String?) -> [String: Any] {
        guard let t = idToken else { return [:] }
        let parts = t.split(separator: ".")
        guard parts.count >= 2, let d = Data(base64URL: String(parts[1])),
              let j = try? JSONSerialization.jsonObject(with: d) as? [String: Any] else { return [:] }
        return j
    }

    /// the redirect Google sends back → tokens
    static func finish(callback: URL, clientID: String, verifier: String, state: String) async throws -> GoogleTokens {
        let items = URLComponents(url: callback, resolvingAgainstBaseURL: false)?.queryItems ?? []
        func item(_ n: String) -> String? { items.first { $0.name == n }?.value }
        if let e = item("error") { throw LiveError.signIn(e == "access_denied" ? "Sign-in was cancelled." : "Google said: \(e)") }
        guard item("state") == state, let code = item("code") else { throw LiveError.signIn("Sign-in didn’t come back as expected. Try again.") }
        let j = try await token(["code": code, "client_id": clientID, "redirect_uri": redirect(clientID),
                                 "grant_type": "authorization_code", "code_verifier": verifier])
        let scope = j["scope"] as? String ?? ""
        guard scope.contains("gmail.readonly") else { throw LiveError.noGmailScope }
        let c = claims(j["id_token"] as? String)
        return GoogleTokens(access: j["access_token"] as? String ?? "",
                            expires: Date().addingTimeInterval((j["expires_in"] as? Double) ?? 3000),
                            refresh: j["refresh_token"] as? String,
                            email: c["email"] as? String ?? "", name: c["name"] as? String ?? (c["given_name"] as? String ?? ""), scope: scope)
    }

    static func refresh(_ refresh: String, clientID: String) async throws -> (String, Date) {
        let j = try await token(["refresh_token": refresh, "client_id": clientID, "grant_type": "refresh_token"])
        return (j["access_token"] as? String ?? "", Date().addingTimeInterval((j["expires_in"] as? Double) ?? 3000))
    }
}

// MARK: Gmail: list and read, nothing else

struct Attach: Codable, Hashable { var id: String; var filename: String; var mime: String }
struct MailMsg: Codable { var id: String; var from: String; var date: String; var subject: String; var text: String; var html: String; var attachments: [Attach] = []
    /// Claude's reading of this mail (events JSON, checked), handed to the engine with it: it decides (engine.js › withClaude)
    var cl: String? = nil
    /// whom it was written to (its To: header): a family member's mail auto-forwarded to you keeps theirs, and is theirs
    /// (engine.js › parse); nil for a mail saved before kosh read the header
    var to: String? = nil
    /// a bank's SMS ("sms") or an app's notification ("notif") handed over by the "Add to kosh" action (Alerts.swift),
    /// and a notification's title; nil for a mail (so a mail reads exactly as before)
    var chan: String? = nil
    var title: String? = nil
    /// how much of a mail kosh keeps: the same when it comes from the inbox (Gmail.decode) and when it's read again from
    /// the sealed copy (MailVault), so a mail read again reads exactly as it did the first time
    static let textLimit = 32_000
    static let htmlLimit = 60_000

    /// A big email's HTML with what never carries a word taken out, before it is cut to the limit: its head and style
    /// sheets, comments, scripts, each tag's styling and layout attributes, and long tracking links. A shop's order mail
    /// can be 150,000 characters, nearly all styling, with the total and how it was paid past the first 60,000 (Nykaa's
    /// "Payment information · Wallet ₹1,410" sat at 88,000): cut as it came, kosh never saw how the order was paid.
    /// The words, the tables and their order are kept, so it reads as the whole email would. An email under the limit
    /// is left exactly as it came (it was always read whole).
    static func compactHTML(_ html: String) -> String {
        guard html.count > htmlLimit else { return html }
        var s = html as NSString
        for (pattern, with) in compactSteps {
            s = pattern.stringByReplacingMatches(in: s as String, range: NSRange(location: 0, length: s.length), withTemplate: with) as NSString
        }
        return s as String
    }
    private static let compactSteps: [(NSRegularExpression, String)] = [
        (#"(?is)<head\b.*?</head\s*>"#, ""),
        (#"(?is)<style\b.*?</style\s*>"#, ""),
        (#"(?is)<script\b.*?</script\s*>"#, ""),
        (#"(?s)<!--.*?-->"#, ""),
        (#"(?i)\s(?:style|width|height|align|valign|bgcolor|background|cellpadding|cellspacing|border|bordercolor|role|dir|lang|face|size|color|nowrap)\s*=\s*(?:"[^"]*"|'[^']*'|[^\s>]+)"#, ""),
        (#"(?i)\s(href|src)\s*=\s*"[^"]{100,}""#, " $1=\"#\""),
        (#"[ \t\r]+"#, " "),
        (#"\n(?: ?\n)+"#, "\n"),
    ].map { (try! NSRegularExpression(pattern: $0.0), $0.1) }
}

enum Gmail {
    struct Part: Decodable { let mimeType: String?; let filename: String?; let headers: [Header]?; let body: Body?; let parts: [Part]? }
    struct Body: Decodable { let data: String?; let size: Int?; let attachmentId: String? }
    struct Header: Decodable { let name: String; let value: String }
    struct Message: Decodable { let id: String; let internalDate: String?; let payload: Part? }
    struct ListResponse: Decodable { struct Ref: Decodable { let id: String }; let messages: [Ref]?; let nextPageToken: String?; let resultSizeEstimate: Int? }

    static let base = "https://gmail.googleapis.com/gmail/v1/users/me/"

    /// one request, inside the inbox's allowance (QuotaGate): a "too many" slows that inbox down and is tried again
    static func get(_ path: String, token: String) async throws -> Data {
        let inbox = QuotaGate.inbox
        await QuotaGate.shared.take(inbox, QuotaGate.cost(path))
        var req = URLRequest(url: URL(string: base + path)!)
        req.setValue("Bearer " + token, forHTTPHeaderField: "Authorization")
        req.timeoutInterval = 30
        let (data, resp) = try await URLSession.shared.data(for: req)
        let http = resp as? HTTPURLResponse
        let code = http?.statusCode ?? 0
        // Google's "too many" (429, or 403 rateLimitExceeded / userRateLimitExceeded): the inbox slows and pauses, and
        // the request is asked again (LiveSession.retrying), never dropped
        if QuotaPace.tooMany(code, code == 403 ? String(decoding: data.prefix(2000), as: UTF8.self) : "") {
            let after = http?.value(forHTTPHeaderField: "Retry-After").flatMap(Double.init)
            await QuotaGate.shared.throttled(inbox, retryAfter: after)
            throw LiveError.busy(after ?? 2)
        }
        if code >= 500 { throw LiveError.busy(2) }
        guard code == 200 else { throw LiveError.http(code, String(data: data.prefix(300), encoding: .utf8) ?? "") }
        return data
    }

    static func query(_ q: String) -> String {
        var allowed = CharacterSet.alphanumerics
        allowed.insert(charactersIn: "-._~")
        return q.addingPercentEncoding(withAllowedCharacters: allowed) ?? q
    }

    static func list(query: String, token: String, page: String?) async throws -> ([String], String?) {
        var path = "messages?maxResults=500&q=" + Self.query(query)
        if let page { path += "&pageToken=" + page }
        let r = try JSONDecoder().decode(ListResponse.self, from: try await get(path, token: token))
        return ((r.messages ?? []).map(\.id), r.nextPageToken)
    }

    /// the newest few emails a search finds, and Gmail's estimate of how many it would find in all
    static func peek(query: String, take: Int, token: String) async throws -> (ids: [String], estimate: Int) {
        let path = "messages?maxResults=" + String(take) + "&q=" + Self.query(query)
        let r = try JSONDecoder().decode(ListResponse.self, from: try await get(path, token: token))
        let ids = (r.messages ?? []).map(\.id)
        return (ids, Swift.max(ids.count, r.resultSizeEstimate ?? ids.count))
    }

    /// where the inbox is now: Gmail's history id, to ask later whether anything came since
    static func historyID(token: String) async throws -> String {
        struct P: Decodable { let historyId: String? }
        return try JSONDecoder().decode(P.self, from: try await get("profile", token: token)).historyId ?? ""
    }

    /// whether any email came in since that history id: false (nothing), true (something), nil (too old to tell)
    static func anythingSince(_ id: String, token: String) async throws -> Bool? {
        struct H: Decodable { let history: [AnyH]?; struct AnyH: Decodable {} }
        do {
            let d = try await get("history?startHistoryId=" + id + "&historyTypes=messageAdded&maxResults=1", token: token)
            return !(try JSONDecoder().decode(H.self, from: d).history ?? []).isEmpty
        } catch LiveError.http(let code, _) where code == 404 {
            return nil
        }
    }

    /// the mail added since a history id, a page at a time (ids and their labels): nil when the id is too old to answer
    struct Added { let id: String; let labels: [String] }
    static func added(since id: String, token: String, page: String?) async throws -> (msgs: [Added], next: String?)? {
        struct P: Decodable {
            struct H: Decodable { let messagesAdded: [A]? }
            struct A: Decodable { let message: M }
            struct M: Decodable { let id: String; let labelIds: [String]? }
            let history: [H]?; let nextPageToken: String?
        }
        var path = "history?startHistoryId=" + id + "&historyTypes=messageAdded&maxResults=500"
        if let page { path += "&pageToken=" + page }
        do {
            let p = try JSONDecoder().decode(P.self, from: try await get(path, token: token))
            let msgs: [Added] = (p.history ?? []).flatMap { h in (h.messagesAdded ?? []).map { Added(id: $0.message.id, labels: $0.message.labelIds ?? []) } }
            return (msgs, p.nextPageToken)
        } catch LiveError.http(let code, _) where code == 404 {
            return nil
        }
    }

    /// who sent a mail and what it's about, and nothing of its body
    static func headers(_ id: String, token: String) async throws -> (from: String, subject: String) {
        struct P: Decodable { let payload: Part? }
        let p = try JSONDecoder().decode(P.self, from: try await get("messages/\(id)?format=metadata&metadataHeaders=From&metadataHeaders=Subject", token: token))
        let hs = p.payload?.headers ?? []
        return (hs.first { $0.name.lowercased() == "from" }?.value ?? "", hs.first { $0.name.lowercased() == "subject" }?.value ?? "")
    }

    static func message(_ id: String, token: String) async throws -> MailMsg {
        try decode(try await get("messages/\(id)?format=full", token: token))
    }

    /// where one whole message is read from: on screen (message) and by the background downloads (BackgroundMail)
    static func messageURL(_ id: String) -> URL? { URL(string: base + "messages/" + id + "?format=full") }

    /// made once (one per email was a measurable part of reading in a big inbox); formatting with it is thread-safe
    static let isoStamp = ISO8601DateFormatter()

    /// one message as Gmail sends it (format=full), as kosh reads it: the same for a read on screen and for the
    /// background downloads, so an email reads the same whichever way it came
    static func decode(_ data: Data) throws -> MailMsg {
        let m = try JSONDecoder().decode(Message.self, from: data)
        var text = "", html = "", attachments: [Attach] = []
        func walk(_ p: Part) {
            if let fn = p.filename, !fn.isEmpty, let aid = p.body?.attachmentId {
                attachments.append(Attach(id: aid, filename: fn, mime: p.mimeType ?? ""))
            }
            if let parts = p.parts { parts.forEach(walk); return }
            guard let d = p.body?.data, let raw = Data(base64URL: d) else { return }
            let s = String(data: raw, encoding: .utf8) ?? String(data: raw, encoding: .isoLatin1) ?? ""
            let mt = (p.mimeType ?? "").lowercased()
            if mt == "text/plain" { text += s + "\n" } else if mt == "text/html" { html += s + "\n" }
        }
        if let p = m.payload { walk(p) }
        let h = m.payload?.headers ?? []
        func header(_ n: String) -> String { h.first { $0.name.lowercased() == n }?.value ?? "" }
        let ms = Double(m.internalDate ?? "") ?? Date().timeIntervalSince1970 * 1000
        let date = Self.isoStamp.string(from: Date(timeIntervalSince1970: ms / 1000))
        // keep the email small: the engine reads a few thousand characters at most
        var msg = MailMsg(id: m.id, from: header("from"), date: date, subject: header("subject"),
                          text: String(text.prefix(MailMsg.textLimit)), html: String(MailMsg.compactHTML(html).prefix(MailMsg.htmlLimit)), attachments: attachments)
        let to = header("to")
        if !to.isEmpty { msg.to = String(to.prefix(300)) }
        return msg
    }

    /// one attachment's bytes, for opening a statement on the phone
    static func attachment(message: String, attachment: String, token: String) async throws -> Data {
        let d = try await get("messages/\(message)/attachments/\(attachment)", token: token)
        let j = (try? JSONSerialization.jsonObject(with: d)) as? [String: Any]
        guard let b64 = j?["data"] as? String, let bytes = Data(base64URL: b64) else { throw LiveError.http(0, "no attachment data") }
        return bytes
    }
}

// MARK: The engine: engine.js in JavaScriptCore, JSON in and out

final class Engine {
    static let shared = Engine(label: "kosh.engine")
    /// a second engine, for laying the screens out off the main thread: a build running there never makes a read
    /// on the main thread wait for it. The engine keeps nothing from one call to the next that a build reads, so
    /// both lay the same records out the same way.
    static let builder = Engine(label: "kosh.builder")
    /// a third, small engine for the screens' quick questions (is this mail wanted, is this statement one folio's,
    /// whose password is this): never busy with a build, a statement or a mail being read, so a tap never waits behind
    /// one. Made off the main thread as kosh starts (warmQuick); until then those questions go to the main engine.
    static let quick = Engine(reader: "kosh.quick")
    /// (31 Oct: and the password's parts from its hint, the guesses from your details, the apps' websites, an inbox's
    /// provider, the EPFO's next page: each a function of what it's handed alone. The Statements page and the
    /// diagnostics asked pwBuildJSON for every locked sender on the main engine, behind whatever statement it was opening)
    static let quickCalls: Set<String> = ["mailWantedJSON", "casPart", "stmtKey", "docWantedJSON", "pwWhoJSON", "directoryVersion",
                                          "pwBuildJSON", "pwGuessJSON", "pwPartsJSON", "platformSites", "providerFor", "epfNext"]
    private static let quickLock = NSLock()
    nonisolated(unsafe) private static var quickMade = false
    static var quickReady: Bool { quickLock.lock(); defer { quickLock.unlock() }; return quickMade }
    static func warmQuick() {
        DispatchQueue.global(qos: .utility).async {
            _ = Engine.quick.problem
            quickLock.lock(); quickMade = true; quickLock.unlock()
        }
    }

    /// the calls that read one mail: each runs under ParseGuard.limit seconds (a build or a statement can take longer)
    static let perMail: Set<String> = ["parseJSON", "docWantedJSON", "mailWantedJSON", "clWantedJSON", "clReadRequestJSON",
                                       "clReadAnswerJSON", "readerCheckJSON", "readerAnswerJSON", "fromClaudeJSON", "localPromptJSON",
                                       "mailTableDocJSON", "trainingLabelJSON", "teachJSON", "teachNotJSON", "teachUndoJSON"]
    /// what a call stopped by the time limit throws
    static let tooLongMessage = "kosh stopped reading this mail: too long"
    /// what every call throws once `maxStuck` engines are still stuck in mail that ran long (until one of them returns,
    /// or the next launch, which skips those mails: ParseGuard guard 1)
    static let pausedMessage = "kosh paused reading: mail ran too long"
    /// how many abandoned engines may still be running at once. Each holds its own JavaScriptCore machine (the engine's
    /// scripts and whatever the runaway script built) and a thread that may keep spinning, so a few at most; past this
    /// the engine stops making new ones and calls throw `pausedMessage`.
    static let maxStuck: Int = 2
    /// the calls that hand the engine something it keeps (the learned rules, the reader's book): played again into a
    /// fresh engine, so it reads as the abandoned one did (the book from layouts.json, its latest saved state)
    static let stateCalls: [String] = ["setLearnedRulesJSON", "loadLayoutBookJSON"]

    private let label: String
    /// one call at a time, and `current`, `generation` and `kept` with it
    private let lock = NSLock()
    /// the engine calls run on: nil before the first call and after one was abandoned
    private var current: EngineRun?
    private var generation: Int = 0
    /// the last arguments of each of `stateCalls`
    private var kept: [String: [String]] = [:]
    /// `stuck` and each run's `busy` / `abandoned`, shared with the runs' own queues (never held while waiting)
    private let watch = NSLock()
    private var stuck: Int = 0
    private var lastProblem: String?

    private init(label: String) {
        self.label = label
        lock.lock()
        _ = try? live()
        lock.unlock()
    }

    /// an engine that reads mail (Readers): it reads with the learned rules and the reader's book from the start
    fileprivate init(reader label: String) {
        self.label = label
        kept["setLearnedRulesJSON"] = [LearnedRules.json]
        // (live() hands a fresh engine the book as last saved)
        kept["loadLayoutBookJSON"] = [""]
        lock.lock()
        _ = try? live()
        lock.unlock()
    }

    /// why the engine can't read (engine.js missing from the app, or paused by mail that ran long)
    var problem: String? {
        watch.lock(); defer { watch.unlock() }
        return lastProblem
    }

    /// the run to call: the current one, or a fresh one (a new JavaScriptCore machine on a new serial queue, the
    /// bundled scripts loaded and what the engine keeps played back in) unless too many are still stuck. Under `lock`.
    private func live() throws -> EngineRun {
        if let r = current { return r }
        watch.lock()
        let n: Int = stuck
        watch.unlock()
        if n >= Engine.maxStuck {
            watch.lock(); lastProblem = Engine.pausedMessage; watch.unlock()
            throw LiveError.engine(Engine.pausedMessage)
        }
        generation += 1
        let r = EngineRun(label: label + "." + String(generation))
        r.queue.sync { r.load() }
        watch.lock(); lastProblem = r.problem; watch.unlock()
        for name in Engine.stateCalls {
            guard var args = kept[name] else { continue }
            if name == "loadLayoutBookJSON" { args = [LayoutBook.stored()] }
            r.queue.sync { _ = r.invoke(name, args) }
        }
        current = r
        return r
    }

    /// mark: the mail this call reads, noted (ParseGuard.begin) while the engine works on it, so a launch after
    /// kosh stopped part-way skips it.
    /// Every call runs on the current run's serial queue. A per-mail call is waited for at most ParseGuard.limit
    /// seconds: past that the run is abandoned (never touched again: its queue may stay stuck in the script), the
    /// call throws `tooLongMessage`, and the next call starts a fresh run. Other calls (builds, statements) are waited
    /// for however long they take.
    func call(_ name: String, _ args: [String], mark: String? = nil) throws -> String {
        // (a call from the main thread waits for whatever the engine is doing, a mail being read included: timed, so a
        // freeze it causes names it in the diagnostics)
        if Thread.isMainThread {
            // (a quick question from the screens goes to the quick engine: the main one may be busy with a statement)
            if self === Engine.shared && Engine.quickCalls.contains(name) && Engine.quickReady { return try Engine.quick.call(name, args, mark: mark) }
            return try Perf.shared.measure("engine on main · " + name) { try callNow(name, args, mark: mark) }
        }
        return try callNow(name, args, mark: mark)
    }

    private func callNow(_ name: String, _ args: [String], mark: String?) throws -> String {
        lock.lock(); defer { lock.unlock() }
        let run: EngineRun = try live()
        if let mark { ParseGuard.begin(mark) }
        defer { if let mark { ParseGuard.end(mark) } }
        let answer: EngineAnswer
        if Engine.perMail.contains(name) {
            answer = try watched(run, name, args)
        } else {
            var got = EngineAnswer(text: "", thrown: nil)
            run.queue.sync { got = run.invoke(name, args) }
            answer = got
        }
        if let e = answer.thrown { throw LiveError.engine(e) }
        if Engine.stateCalls.contains(name) { kept[name] = args }
        return answer.text
    }

    /// a per-mail call under the watchdog. Under `lock`.
    private func watched(_ run: EngineRun, _ name: String, _ args: [String]) throws -> EngineAnswer {
        let box = EngineAnswerBox()
        let done = DispatchSemaphore(value: 0)
        watch.lock(); run.busy = true; watch.unlock()
        run.queue.async { [weak self] in
            let a: EngineAnswer = run.invoke(name, args)
            box.answer = a
            done.signal()
            self?.returned(run)
        }
        if done.wait(timeout: .now() + ParseGuard.limit) == .success { return box.answer }
        watch.lock()
        let still: Bool = run.busy
        if still {
            run.abandoned = true
            stuck += 1
        }
        watch.unlock()
        if !still {
            // it finished just as the time ran out: its answer stands
            done.wait()
            return box.answer
        }
        current = nil
        throw LiveError.engine(Engine.tooLongMessage)
    }

    /// a per-mail call came back, on its run's queue: if it had been abandoned, it no longer counts as stuck (the run
    /// is let go when this block ends and nothing else holds it)
    private func returned(_ run: EngineRun) {
        watch.lock()
        run.busy = false
        if run.abandoned {
            stuck -= 1
            if lastProblem == Engine.pausedMessage { lastProblem = nil }
        }
        watch.unlock()
    }
}

/// The engines that read mail, side by side: the iPhone has the cores for two or three, so a first read or a re-read
/// goes two or three times as fast, and the engine the screens call on (Engine.shared) never waits for a mail being
/// read. Each sender's mail always goes to the same one (by its domain), so each keeps the reader's book of templates
/// for its own senders exactly as a single engine would; the book is saved as one, each sender's templates from
/// whichever engine saw them last. Made when first needed, off the main thread.
enum Readers {
    // (three on a phone with six cores or more, today's iPhones, two below that: a build and the screens keep a core)
    static let count: Int = ProcessInfo.processInfo.activeProcessorCount >= 6 ? 3 : 2
    private static let lock = NSLock()
    private static var made: [Engine?] = Array(repeating: nil, count: count)

    /// the engine for reader `i`, made now if it isn't yet (loading the scripts takes a moment)
    static func engine(_ i: Int) -> Engine {
        lock.lock(); defer { lock.unlock() }
        if let e = made[i] { return e }
        let e = Engine(reader: "kosh.reader." + String(i))
        made[i] = e
        return e
    }
    /// the engines made so far
    static var all: [Engine] { lock.lock(); defer { lock.unlock() }; return made.compactMap { $0 } }

    /// a sender's domain as the reader keys its templates (the last three parts of the address's domain)
    static func domain(_ from: String) -> String {
        let s: String = from.lowercased()
        var addr: Substring = s[...]
        if let a = s.lastIndex(of: "<"), let b = s[a...].firstIndex(of: ">") { addr = s[s.index(after: a)..<b] }
        guard let at = addr.lastIndex(of: "@") else { return "" }
        let host: String = addr[addr.index(after: at)...].trimmingCharacters(in: .whitespaces)
        return host.split(separator: ".").suffix(3).joined(separator: ".")
    }
    static func index(dom: String) -> Int {
        var h: UInt32 = 2_166_136_261
        for b in dom.utf8 { h = (h ^ UInt32(b)) &* 16_777_619 }
        return Int(h % UInt32(count))
    }
    static func index(from: String) -> Int { index(dom: domain(from)) }
    static func engine(for from: String) -> Engine { engine(index(from: from)) }

    /// the learned rules, to every reader made (one made later reads them as it starts)
    static func setRules(_ json: String) {
        for e in all { _ = try? e.call("setLearnedRulesJSON", [json]) }
    }
    /// the book handed to every reader made (Readers made later take it from layouts.json as they start)
    static func loadBook(_ s: String) {
        for e in all { _ = try? e.call("loadLayoutBookJSON", [s]) }
    }
    /// the readers' books as one: each sender's templates from the engine that saw them last (nil when no reader has
    /// one yet). Off the main thread
    static func bookJSON() -> String? {
        let engines: [Engine] = all
        guard !engines.isEmpty else { return nil }
        var layouts: [String: Any] = [:], byDom: [String: Any] = [:], seenOf: [String: String] = [:]
        for e in engines {
            guard let s = try? e.call("layoutBookJSON", []), let d = s.data(using: .utf8),
                  let b = try? JSONSerialization.jsonObject(with: d) as? [String: Any] else { continue }
            let L: [String: Any] = b["layouts"] as? [String: Any] ?? [:]
            let D: [String: [String]] = b["byDom"] as? [String: [String]] ?? [:]
            for (dom, ids) in D {
                let seen: String = ids.compactMap { (L[$0] as? [String: Any])?["seen"] as? String }.max() ?? ""
                if let was = seenOf[dom], was >= seen { continue }
                // (this engine's copy of the sender is the newer: its templates replace the other's)
                if let old = byDom[dom] as? [String] { for id in old { layouts[id] = nil } }
                seenOf[dom] = seen
                byDom[dom] = ids
                for id in ids { if let l = L[id] { layouts[id] = l } }
            }
        }
        guard !layouts.isEmpty else { return nil }
        return JSONText.object(["v": 1, "layouts": layouts, "byDom": byDom])
    }
}

/// One engine: its own JavaScriptCore machine (a stuck script holds its machine's lock, so a fresh engine needs a new
/// machine, not just a new context), the scripts loaded into it, and the one serial queue every call to it runs on.
/// Its context and values are only touched on that queue.
final class EngineRun {
    let queue: DispatchQueue
    private let vm: JSVirtualMachine
    private let ctx: JSContext
    private var koshEngine: JSValue?
    private(set) var problem: String?
    /// what the last call threw
    private var thrown: String?
    /// set and read under Engine's `watch`: a per-mail call is running, and the watchdog gave up on it
    var busy: Bool = false
    var abandoned: Bool = false

    init(label: String) {
        queue = DispatchQueue(label: label, qos: .userInitiated)
        let machine: JSVirtualMachine = JSVirtualMachine()
        vm = machine
        ctx = JSContext(virtualMachine: machine)
    }

    /// the bundled scripts, loaded on `queue`
    func load() {
        ctx.exceptionHandler = { [weak self] _, e in
            self?.thrown = e?.toString()
        }
        if let url = Bundle.main.url(forResource: "engine", withExtension: "js"),
           let src = try? String(contentsOf: url, encoding: .utf8) {
            // India's banks, insurers and wallets, which the engine folds into who it knows mail from
            ctx.evaluateScript("var KoshDirectory = " + Directory.shared.json + ";")
            // the phone's own hashes, lent to unlock.js for the slow steps of opening a locked zip or workbook
            KoshNative.install(in: ctx)
            ctx.evaluateScript(src)
            // mail from inboxes that aren't Gmail (IMAP, Microsoft), read into the same emails; it adds itself to KoshEngine
            if let mw = Bundle.main.url(forResource: "mailwire", withExtension: "js"), let mws = try? String(contentsOf: mw, encoding: .utf8) {
                ctx.evaluateScript(mws)
            }
            // the papers beyond statements (payslips, deposits, loans, NPS, tax forms, contract notes), and what kosh
            // notices, the assistant's tools and the rules it learns: each adds itself to KoshEngine
            // what kosh knows of India's money mail, the reader that reads every mail into events beside the rules, and
            // the journey that links those events into threads: each adds itself to KoshEngine
            // what needs doing, from what the rest worked out (assist.js: snap.actions, after the journey and agent.js)
            // the live view: a question becomes a plan of what to draw, filled by agent.js's own figures (viewplan.js)
            // and last, the checks: how sure each reading is, and whether its own figures agree (checks.js)
            // (and unlock.js, which opens a locked zip or workbook with the passwords kosh worked out)
            for name in ["knowledge", "reader", "journey", "docread", "agent", "assist", "viewplan", "plan", "brief", "decide", "packs", "trips", "checks", "unlock"] {
                if let u = Bundle.main.url(forResource: name, withExtension: "js"), let src = try? String(contentsOf: u, encoding: .utf8) { ctx.evaluateScript(src) }
            }
            koshEngine = ctx.objectForKeyedSubscript("KoshEngine")
        } else {
            problem = "engine.js is missing from the app"
        }
    }

    /// one call into KoshEngine, on `queue`
    func invoke(_ name: String, _ args: [String]) -> EngineAnswer {
        guard let k = koshEngine, !k.isUndefined else { return EngineAnswer(text: "", thrown: problem ?? "not loaded") }
        thrown = nil
        let v: JSValue? = k.invokeMethod(name, withArguments: args)
        if let e = thrown { return EngineAnswer(text: "", thrown: e) }
        return EngineAnswer(text: v?.toString() ?? "", thrown: nil)
    }
}

/// what one engine call gave back: its text, or what it threw
struct EngineAnswer {
    var text: String
    var thrown: String?
}

/// a call's answer, handed from the run's queue to the caller (written before the semaphore is signalled, read after)
final class EngineAnswerBox {
    var answer: EngineAnswer = EngineAnswer(text: "", thrown: nil)
}

// MARK: What the engine says about one email

struct Check: Codable, Hashable { var status: String; var fields: [String] }

/// One email's reading, as engine.js writes it. Optional almost everywhere: kinds carry different fields.
/// where a shop's refund goes back to: a card or an account, its last digits, and its issuer when the mail names one
struct ReadingRefundTo: Codable, Hashable { var kind: String?; var last4: String?; var inst: String? }
/// one detail a mail or statement prints about you or your family: k is what it is (crn, custid, acct, ifsc, folio,
/// policy, pran, uan, dpid, clientid, pan, mobile, email…), label the institution's own word for it ("CRN", "Customer
/// ID"), v the value as printed, masked when the mail only shows part of it; whose (who) and in which category (cat:
/// bank, card, invest, insurance, loan, tax, identity, contact)
struct ReadingFact: Codable, Hashable {
    var k: String
    var label: String
    var v: String
    var masked: Bool? = nil
    var last4: String? = nil
    var inst: String? = nil
    var cat: String? = nil
    var who: String? = nil
}

struct Reading: Codable, Identifiable, Hashable {
    var id: String
    var kind: String
    var sent: String?; var from: String?; var inst: String?; var instKind: String?; var subject: String?
    var src: String?; var rule: String?; var conf: String?; var reason: String?
    var dir: String?; var amt: Double?; var date: String?; var time: String?
    var instr: String?; var last4: String?; var party: String?; var vpa: String?; var mode: String?
    var rupay: Bool?; var info: String?; var cat: String?; var sub: String?
    var min: Double?; var due: String?; var insurer: String?; var ptype: String?; var premium: Double?
    /// the card's issuing bank when the mail came from someone else (CRED, a payment app), and how sure the general reader was
    var issuer: String?; var score: Double?
    /// the balance an account's alert reported, when, and for which account if the alert named no payment
    var bal: Double?; var balAt: String?; var balLast4: String?
    /// the day a balance mail says its figure is for, when that's before the mail was sent
    var asOn: String?
    /// a fixed deposit the bank wrote about, and a card's own name and network
    var depNo: String?; var depEvent: String?; var rate: Double?; var mat: String?; var matAmt: Double?; var autoRenew: Bool?
    /// a deposit's booking request (the amount and how long, "1y6m1d"), its renewal carrying the interest, and the bank a
    /// forwarded interest certificate is from (engine.js depositBook)
    var depAmt: Double?; var depTerm: String?; var depCarry: Bool?; var depInst: String?
    /// the account a deposit's advice says paid for it ("Funded from: Savings Account XX4821"), a renewal's new start, and a card alert's
    /// authorisation code (two codes are two charges, however close together)
    var depFrom: String?; var depStart: String?; var auth: String?
    /// what the reader (reader.js) read in the mail, as events (JSON): the journey links them into threads
    var evs: String?
    var cardName: String?; var network: String?
    /// a debit card's mail ("Debit Card ending 1234"): the card belongs to the bank account, not among credit cards;
    /// dcard: that debit card's own digits, kept beside the account's
    var debit: Bool?; var dcard: String?
    /// the account a debit card's mail printed beside the card ("Debit Card XX7301 linked to A/c XX4821")
    var acctL4: String?
    /// whom the mail is written to ("Dear Mr Rohan Example", "Account holder: …"): whose the account or card is
    var named: [String]?
    /// the names only a holder field printed, never a greeting: a stranger named only so never takes the account
    var namedF: [String]?
    /// a policy's sum insured, as its mail states it
    var cover: Double?
    /// gift cards a store's mail delivered (each card's brand, value and expiry); voucherBuy: they were bought, so the
    /// mail is also a payment; via: where they were bought (PayZapp, SmartBuy), how the money left if no alert comes
    var vouchers: [ReadingVoucher]?; var voucherBuy: Bool?; var via: String?
    /// a shop's receipt: its category is certain; paid from the app's balance if no bank alert turns up for it
    /// (`walletIfAlone`); the parts paid another way (`also`), which wait for the bank's alert
    var catSure: Bool?; var walletIfAlone: String?; var also: [ReadingPart]?
    /// the shop's order number, on its receipt and on its refund; a refund from the shop itself (not the bank)
    var orderId: String?; var shopRefund: Bool?; var refundLater: Bool?; var shipStep: Bool?
    /// a shop's papers by their files' names (engine/05 parse, kept through openOrder); "fee" when every paper that gave a
    /// sum is a fee's own tax invoice (part of an order, never one of its own); what a paper's bill printed, line by line
    var files: [String]?; var part: String?; var bill: [ReadingBillLine]?
    /// a home's bill (engine/06d-bill-facts.js): the connection's number, the days it covers, the units used, where the
    /// supply is (PIN and town words only): what puts each bill on its home and spreads it over its days (engine/21s)
    var bf: ReadingBillFacts?
    /// the account a transfer out of yours went to, by its last digits (engine withToAcct)
    var toLast4: String?
    /// where a shop's refund goes back to, when its mail says ("Refund To Credit Card … ending in 2528")
    var refundTo: ReadingRefundTo?
    /// the details the mail prints about you (a Customer ID, CRN, account number, folio, policy number…): Your details
    var facts: [ReadingFact]?
    /// the payment's own reference (UPI reference, UTR, transaction id): two payments of one amount on one day are two
    var ref: String?
    /// what the account or card had left once it went through, as the alert prints it (available limit or balance):
    /// the same figure twice is one payment told twice, a figure moved by the sum is a second payment
    var after: Double?
    /// a card's whole credit limit as its alert or statement mail prints it; limitAll: the issuer's figures are for all
    /// your cards with it together
    var cardLimit: Double?; var limitAll: Bool?
    /// a charge in another currency: its code and amount; est: the rupee figure is kosh's estimate until the bank's says
    var cur: String?; var fxAmt: Double?; var est: Bool?
    /// accounts or deposits the bank says it closed (last four digits)
    var closedAccts: [String]?
    /// who decided the reading: "claude" (its reading, or the rules' agreeing with it), "rules" (kept against Claude's)
    var by: String?
    /// Claude's reading of the mail (its events, checked against the mail), and the version of the rules it read by
    var cl: String?; var clv: Int?
    // set on the phone
    var check: Check?
    var use: String?
    var claude: ReadingBox?
    var text: String?
    var html: String?
    var acct: String?       // which Gmail account this came from
    var doc: DocRef?        // a locked statement attachment worth opening
    /// the PDFs the mail carries (an invoice first), and, for a travel site's own mail, what a claim needs from it
    /// (packs.js): kept beside the reading, never changing the money in it
    var atts: [AttRef]?
    var trip: TripFacts?
    /// the rule a mail read by before it was set aside (a mail you said isn't money); what a payment was for, as the
    /// reader read it ("investment": a fund's debit, matched to the bank's)
    var was: String?; var purpose: String?
    /// how sure the reading is (high, medium, low, unsure: checks.js); why kosh isn't sure (each reason in plain words),
    /// and what the reading would have been had its own figures agreed
    var sure: String?; var doubt: [String]?; var heldKind: String?
    /// the reading fingerprint of the code that read it (ReadingPrint.mail): a reading from older code is read again
    var rp: String?
    /// whatever the engine wrote that this version has no place for (a newer field, or one in a type it doesn't
    /// expect), kept whole as JSON and handed back to the engine with the reading (LiveSession.recordsJSON): nothing the
    /// engine read is lost on the way to the screens
    var xtra: String?
}

extension Reading {
    /// every key a reading keeps, as Swift codes them (its stored properties)
    static let storedKeys: Set<String> = Set(Mirror(reflecting: Reading(id: "", kind: "")).children.compactMap { $0.label })

    /// One reading as the engine wrote it (JSON). What this version declares goes in its place; anything else (a field
    /// newer than this version, or a value of a type it doesn't expect) is kept whole in `xtra`, so it can't be dropped
    /// and can't make the whole reading fail. Nil only when the JSON isn't a reading at all (no id or kind).
    static func fromEngine(_ json: String) -> Reading? {
        guard let obj = (try? JSONSerialization.jsonObject(with: Data(json.utf8))) as? [String: Any] else { return nil }
        var known: [String: Any] = [:]
        var extra: [String: Any] = [:]
        for (k, v) in obj where !(v is NSNull) {
            if storedKeys.contains(k) && k != "xtra" { known[k] = v } else { extra[k] = v }
        }
        var tries = 0
        while tries < 16 {
            tries += 1
            guard JSONSerialization.isValidJSONObject(known), let d = try? JSONSerialization.data(withJSONObject: known) else { return nil }
            do {
                var r = try JSONDecoder().decode(Reading.self, from: d)
                r.xtra = extraJSON(extra)
                return r
            } catch let e as DecodingError {
                // the field that didn't fit moves aside whole, and the rest is read again
                guard let key = topKey(e), key != "id", key != "kind", let v = known.removeValue(forKey: key) else { return nil }
                extra[key] = v
            } catch {
                return nil
            }
        }
        return nil
    }

    /// the reading's own field a decoding error is about
    static func topKey(_ e: DecodingError) -> String? {
        let path: [CodingKey]
        switch e {
        case .typeMismatch(_, let c): path = c.codingPath
        case .valueNotFound(_, let c): path = c.codingPath
        case .dataCorrupted(let c): path = c.codingPath
        case .keyNotFound(let k, let c): path = c.codingPath.isEmpty ? [k] : c.codingPath
        @unknown default: return nil
        }
        return path.first?.stringValue
    }

    static func extraJSON(_ x: [String: Any]) -> String? {
        guard !x.isEmpty, JSONSerialization.isValidJSONObject(x),
              let d = try? JSONSerialization.data(withJSONObject: x, options: [.sortedKeys]) else { return nil }
        return String(data: d, encoding: .utf8)
    }

    /// the reading as the engine takes it for a build: without the mail's words, with what `xtra` kept put back
    /// beside the typed fields (its keys are never among them)
    func engineJSON(_ enc: JSONEncoder) -> String? {
        var x = self
        x.text = nil
        x.html = nil
        let extra: String? = x.xtra
        x.xtra = nil
        if let c = x.claude, c.r.xtra != nil {
            var inner = c.r
            inner.xtra = nil
            x.claude = ReadingBox(inner)
        }
        guard let d = try? enc.encode(x), var s = String(data: d, encoding: .utf8) else { return nil }
        guard let e = extra, e.count > 2, e.hasPrefix("{"), e.hasSuffix("}"), s.hasSuffix("}") else { return s }
        s.removeLast()
        let rest: String = String(e.dropFirst())
        let sep: String = s.hasSuffix("{") ? "" : ","
        return s + sep + rest
    }
}

/// What a reading was read with: a fingerprint of the code that turns a mail into a reading (the engine, the reader,
/// what kosh knows of India's money mail, the directory of senders, packs.js's travel facts, the checks) and of the
/// fields a reading keeps. Worked out from the app's own files when kosh starts, so nothing is bumped by hand: when it
/// changes, every reading made by older code is read again from the phone's sealed copy (reingestIfRulesChanged).
/// The papers' reader has its own: when it changes, the statements and policies already opened are read again from
/// their kept text (rereadDocumentsIfReaderChanged).
enum ReadingPrint {
    /// (the engine by the fingerprint of the parts that read, engine-read.json: tools/engine-join.js writes it, leaving
    /// out the parts that only build the screens, so a change to a screen never reads every email again)
    static let mailFiles: [(String, String)] = [("engine-read", "json"), ("mailwire", "js"), ("knowledge", "js"), ("reader", "js"), ("packs", "js"), ("checks", "js"), ("directory", "json")]
    /// (unlock.js too: when kosh learns to open a kind of locked file, the papers it couldn't open get another turn)
    static let docFiles: [(String, String)] = [("engine-read", "json"), ("docread", "js"), ("knowledge", "js"), ("reader", "js"), ("directory", "json"), ("unlock", "js")]
    static let mail: String = of(mailFiles, salt: "mail|" + Reading.storedKeys.sorted().joined(separator: ","))
    /// what read an SMS or a notification: the mail's code and the SMS part (engine-sms.json), so a change to either
    /// reads the SMS again, and a change to the SMS part alone never reads the mail (Alerts.swift › takeAlerts)
    static let sms: String = of(mailFiles + [("engine-sms", "json")], salt: "sms|" + Reading.storedKeys.sorted().joined(separator: ","))
    static let doc: String = of(docFiles, salt: "doc")

    static func of(_ files: [(String, String)], salt: String) -> String {
        var h = SHA256()
        h.update(data: Data(salt.utf8))
        for (name, ext) in files {
            h.update(data: Data((name + "." + ext + "|").utf8))
            if let u = Bundle.main.url(forResource: name, withExtension: ext), let d = try? Data(contentsOf: u) { h.update(data: d) }
        }
        let digest = h.finalize()
        let bytes: [UInt8] = Array(digest).prefix(8).map { $0 }
        return bytes.map { String(format: "%02x", $0) }.joined()
    }
}

/// one PDF a mail carries: its attachment id (a part path for IMAP) and its file name
struct AttRef: Codable, Hashable { var id: String; var f: String }

/// a travel site's mail, read for a claim (packs.js tripFacts): the kind of trip, the site, which paper it is
/// (invoice, ticket, receipt, booking), whether it was cancelled, the booking id, from and to, the days, the stay's
/// place and nights, the amount and its GST
struct TripFacts: Codable, Hashable {
    var p: String?; var k: String?; var doc: String?; var off: String?; var ref: String?
    var from: String?; var to: String?; var on: String?; var until: String?; var place: String?
    var nights: Int?; var amt: Double?; var tax: Double?
}

/// one gift card a store's mail delivered (engine.js voucher receipts): never its code or PIN, only what the shelf needs
struct ReadingVoucher: Codable, Hashable {
    var brand: String?; var value: Double?; var until: String?; var store: String?; var how: String?; var via: String?
}

/// another part of the same receipt: what a card or UPI paid beside the wallet
struct ReadingPart: Codable, Hashable {
    var kind: String?; var rule: String?; var amt: Double?; var instr: String?; var inst: String?; var instKind: String?; var mode: String?
}

/// one line of a shop's bill as its paper printed it: k fee · tax (a convenience fee's tax invoice: the fee, its IGST)
struct ReadingBillLine: Codable, Hashable {
    var k: String?; var n: String?; var amt: Double?
}

/// a utility bill's own facts, each only as printed: k (Electricity · Water · Gas · LPG · Internet · DTH · Maintenance ·
/// Mobile), no and nol (the connection's number and its label), from and to (the days covered), units and unit, cur (the
/// current charges apart from arrears), pin and place (the supply address's PIN and town words)
struct ReadingBillFacts: Codable, Hashable {
    var k: String?; var no: String?; var nol: String?; var from: String?; var to: String?
    var units: Double?; var unit: String?; var cur: Double?; var pin: String?; var place: String?
}

/// Where a statement PDF lives, and what it probably is, so kosh can open it on the phone
struct DocRef: Codable, Hashable {
    /// a statement sent as a spreadsheet, opened by DocTable rather than as a PDF
    static func isSheet(_ file: String) -> Bool { let f = file.lowercased(); return f.hasSuffix(".csv") || f.hasSuffix(".xlsx") }
    var kind: String        // cas, policy, cardstmt, stmt, contract, society
    var msg: String; var att: String; var file: String
    var acct: String        // which Gmail account to fetch it from
    var from: String = ""   // the statement's sender, for keying its saved password
    var hint: String = ""   // the password sentence from the sender's own email
    var state: String = ""  // read, locked, empty, older (a newer statement from the same sender counts)
    var note: String? = nil  // what reading it found, for the statements list
    var hinted: Int? = nil   // which version of the hint reader looked at the email
    var past: Bool? = nil    // an older holdings statement, opened once for what it said that month
    /// a "holdings statement" that opened with nothing held in it (a broker's margin or funds statement, a notice from a
    /// depository): false, and it no longer stands in the way of the sender's real holdings statement as the newest
    var held: Bool? = nil
    var more: [String]? = nil  // a shop's order: its other invoices (attachment ids), read together
    var auto: Bool? = nil      // its password was tried once from the sender's rule and your saved details
    var tried: String? = nil   // the mark of the sender's saved password this one was already tried with (SenderPasswords.tag: random, never made from the password), so it isn't fetched again for it
    var unread: Bool? = nil    // opened, but neither kosh's readers nor Claude could read it (Documents › Couldn't read)
    /// what the paper turned out to be about, once read: invest, insurance, loan, bank, card, tax or details
    var cat: String? = nil
}

/// Claude's own reading, nested inside a record
final class ReadingBox: Codable, Hashable {
    let r: Reading
    init(_ r: Reading) { self.r = r }
    required init(from decoder: Decoder) throws { r = try Reading(from: decoder) }
    func encode(to encoder: Encoder) throws { try r.encode(to: encoder) }
    static func == (a: ReadingBox, b: ReadingBox) -> Bool { a.r == b.r }
    func hash(into h: inout Hasher) { h.combine(r) }
}

enum JSONText {
    static func encode<T: Encodable>(_ v: T) -> String {
        guard let d = try? JSONEncoder().encode(v), let s = String(data: d, encoding: .utf8) else { return "null" }
        return s
    }
    static func decode<T: Decodable>(_ t: T.Type, _ s: String) throws -> T {
        try JSONDecoder().decode(t, from: Data(s.utf8))
    }
    static func object(_ v: Any) -> String {
        guard JSONSerialization.isValidJSONObject(v), let d = try? JSONSerialization.data(withJSONObject: v) else { return "{}" }
        return String(data: d, encoding: .utf8) ?? "{}"
    }
}
