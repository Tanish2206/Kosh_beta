import Foundation
import Darwin
#if canImport(UIKit)
import UIKit
#endif

// MARK: - Where the screens wait: kosh's own measure of its smoothness
//
// A watchdog off the main thread asks the main thread for a moment every tenth of a second; when it doesn't answer for
// a quarter of a second the screens have frozen, and how long, on which tab, and what kosh was doing go into the
// diagnostics. Named pieces of main-thread work (laying out a build, the reminders, the widgets) are timed too. It
// measures; it changes nothing. No content of any email or payment is kept, only times and names.
// While the screens are frozen, the watchdog also looks at where the main thread is (a few samples of its call stack,
// kosh's own functions by name), so a freeze no named piece of work covers ("inside ?") still says what it was in.

final class Perf: @unchecked Sendable {
    static let shared = Perf()
    private let lock = NSLock()
    private var hangs: [[String: Any]] = []
    private var spans: [String: (n: Int, total: Double, max: Double)] = [:]
    private var started = false
    /// the named pieces of main-thread work under way now, outermost first
    private var active: [String] = []
    /// what the screens show now and what kosh is doing, kept by the main thread for the watchdog to read
    var context: () -> String = { "" }
    nonisolated(unsafe) private var lastContext = ""
    /// kosh's own functions the main thread was found in during freezes, and how often (across every freeze)
    private var hot: [String: Int] = [:]
    /// the main thread, for the watchdog to look at, and a buffer filled while it's paused (nothing allocated then)
    nonisolated(unsafe) private var mainPort: mach_port_t = 0
    private let frames = UnsafeMutablePointer<UInt>.allocate(capacity: 96)
    /// one look at a time (the watchdog's and a probe's share the buffer above)
    private let sampling = NSLock()
    /// a probe's looks: for each thing a person did (a tab switch), how many looks, and where the main thread was
    private var probeLooks: [String: Int] = [:]
    private var probeHot: [String: [String: Int]] = [:]
    /// when kosh started (KoshApp's first line asks for Perf.shared), and whether the first screen has been timed
    private let born: CFAbsoluteTime = CFAbsoluteTimeGetCurrent()
    private var firstShown = false
    /// kosh is in the background: the watchdog sleeps until it's back (a screen nobody sees can't freeze, and asking
    /// the main thread ten times a second kept the phone awake for nothing)
    private let gate = NSCondition()
    private var paused = false
    private func pause(_ on: Bool) {
        gate.lock(); paused = on; if !on { gate.broadcast() }; gate.unlock()
    }

    /// the first screen is up: how long from kosh starting until the main thread was free after drawing it, once a launch
    func firstScreen() {
        lock.lock(); let first: Bool = !firstShown; firstShown = true; lock.unlock()
        guard first else { return }
        let born: CFAbsoluteTime = self.born
        DispatchQueue.main.async { [weak self] in self?.record("startup · first screen", ms: (CFAbsoluteTimeGetCurrent() - born) * 1000) }
    }

    func start() {
        lock.lock(); defer { lock.unlock() }
        guard !started else { return }
        started = true
        // (the main thread's own port, taken on it)
        // (kosh starts the watchdog from the main thread; from anywhere else the looks are skipped)
        if Thread.isMainThread { mainPort = mach_thread_self() }
        #if canImport(UIKit)
        let nc = NotificationCenter.default
        nc.addObserver(forName: UIApplication.didEnterBackgroundNotification, object: nil, queue: nil) { [weak self] _ in self?.pause(true) }
        nc.addObserver(forName: UIApplication.willEnterForegroundNotification, object: nil, queue: nil) { [weak self] _ in self?.pause(false) }
        nc.addObserver(forName: UIApplication.didBecomeActiveNotification, object: nil, queue: nil) { [weak self] _ in self?.pause(false) }
        #endif
        let t = Thread { [weak self] in self?.watch() }
        t.name = "kosh.watchdog"
        t.qualityOfService = .utility
        t.start()
    }

    private func watch() {
        while true {
            // (asleep while kosh is in the background)
            gate.lock(); while paused { gate.wait() }; gate.unlock()
            let sent = Date()
            var answered = false
            let sem = DispatchSemaphore(value: 0)
            DispatchQueue.main.async { [weak self] in
                self?.lastContext = self?.context() ?? ""
                answered = true
                sem.signal()
            }
            if sem.wait(timeout: .now() + 0.25) == .timedOut {
                // frozen: what the main thread is inside of, if it's a named piece of work, then how long
                lock.lock(); let inside = active.joined(separator: " › "); lock.unlock()
                // where it is, a look every fifth of a second while it stays frozen (eight looks at most)
                var samples: [[UInt]] = [sampleMain()]
                while sem.wait(timeout: .now() + 0.2) == .timedOut { if samples.count < 8 { samples.append(sampleMain()) } }
                let ms = Int(Date().timeIntervalSince(sent) * 1000)
                // (only while kosh is on screen: a phone locked or kosh in the background isn't a frozen screen)
                if !lastContext.hasPrefix("background") { note(ms: ms, at: sent, inside: inside, stack: locate(samples)) }
            }
            _ = answered
            Thread.sleep(forTimeInterval: 0.1)
        }
    }

    private func note(ms: Int, at: Date, inside: String, stack: [String]) {
        let f = ISO8601DateFormatter()
        lock.lock()
        hangs.append(["at": f.string(from: at), "ms": ms, "doing": lastContext, "inside": inside.isEmpty ? "?" : inside, "stack": stack])
        for fn in Set(stack) { hot[fn, default: 0] += 1 }
        if hangs.count > 60 { hangs.removeFirst(hangs.count - 60) }
        lock.unlock()
    }

    /// one look at the main thread's call stack: paused for a moment (nothing allocated or locked while it is), its
    /// return addresses read off its frame chain, then let go
    private func sampleMain() -> [UInt] {
        sampling.lock(); defer { sampling.unlock() }
        #if arch(arm64)
        let mask: UInt = 0x0000_000F_FFFF_FFFF   // (the pointer-authentication bits off a return address)
        var n = 0
        guard mainPort != 0, thread_suspend(mainPort) == KERN_SUCCESS else { return [] }
        var state = arm_thread_state64_t()
        var count = mach_msg_type_number_t(MemoryLayout<arm_thread_state64_t>.size / MemoryLayout<natural_t>.size)
        let kr: kern_return_t = withUnsafeMutablePointer(to: &state) { p in
            p.withMemoryRebound(to: natural_t.self, capacity: Int(count)) { thread_get_state(mainPort, thread_state_flavor_t(ARM_THREAD_STATE64), $0, &count) }
        }
        if kr == KERN_SUCCESS {
            frames[n] = UInt(state.__pc) & mask; n += 1
            frames[n] = UInt(state.__lr) & mask; n += 1
            var fp: UInt = UInt(state.__fp) & mask
            var pair: (UInt, UInt) = (0, 0)
            while fp != 0 && n < 96 {
                var got: vm_size_t = 0
                let r: kern_return_t = withUnsafeMutablePointer(to: &pair) { q in
                    vm_read_overwrite(mach_task_self_, vm_address_t(fp), vm_size_t(16), vm_address_t(UInt(bitPattern: q)), &got)
                }
                if r != KERN_SUCCESS || got != 16 { break }
                let next: UInt = pair.0 & mask, ret: UInt = pair.1 & mask
                if ret == 0 { break }
                frames[n] = ret; n += 1
                if next <= fp { break }
                fp = next
            }
        }
        thread_resume(mainPort)
        return Array(UnsafeBufferPointer(start: frames, count: n))
        #else
        return []
        #endif
    }

    /// kosh's own functions in the samples, innermost first, each once (the frames of the system's own code skipped,
    /// but the first of them kept, to say what kosh had called into)
    private func locate(_ samples: [[UInt]]) -> [String] {
        var out: [String] = []
        var seen = Set<String>()
        for frames in samples {
            var system: String? = nil
            var mine = 0
            for a in frames {
                var info = Dl_info()
                guard dladdr(UnsafeRawPointer(bitPattern: a), &info) != 0 else { continue }
                let image: String = info.dli_fname.map { String(cString: $0) } ?? ""
                let name: String = info.dli_sname.map { String(cString: $0) } ?? "?"
                let file: String = image.split(separator: "/").last.map(String.init) ?? ""
                if file.hasPrefix("Kosh") {
                    let fn: String = Self.readable(name)
                    if mine < 6 && seen.insert(fn).inserted { out.append(fn) }
                    mine += 1
                } else if system == nil && mine == 0 {
                    system = file + " " + Self.readable(name)
                }
            }
            if let s = system, seen.insert(s).inserted { out.append("in " + s) }
        }
        return Array(out.prefix(16))
    }

    /// a Swift symbol, shortened to the parts a person can read ("$s4Kosh10LedgerListV4bodyQrvg" → "LedgerList body")
    static func readable(_ sym: String) -> String {
        guard sym.hasPrefix("$s") || sym.hasPrefix("_$s") else { return String(sym.prefix(80)) }
        var words: [String] = []
        var i = sym.startIndex
        while i < sym.endIndex {
            guard sym[i].isNumber else { i = sym.index(after: i); continue }
            var j = i
            while j < sym.endIndex, sym[j].isNumber { j = sym.index(after: j) }
            guard let len = Int(sym[i..<j]), len > 0, let end = sym.index(j, offsetBy: len, limitedBy: sym.endIndex) else { i = j; continue }
            words.append(String(sym[j..<end]))
            i = end
        }
        return words.filter { $0 != "Kosh" }.prefix(5).joined(separator: " ")
    }

    /// a close look at the main thread just after something a person did (a tab switch), freeze or not: how long
    /// until it was free again, and where it spent the next moment (a look every 12 ms for 0.6 s). Only kosh's own
    /// function names and times are kept
    /// The close look pauses the main thread about fifty times a tab switch to see where it is, and that pausing is
    /// itself a cost a person feels. So it runs only while Beta › "Look closely at slow taps" is on; the plain timing
    /// (how long until the main thread was free) costs nothing and always runs.
    static let lookKey = "beta.probe"
    var looking: Bool { UserDefaults.standard.bool(forKey: Self.lookKey) }

    func probe(_ name: String, seconds: Double = 0.6) {
        let start: CFAbsoluteTime = CFAbsoluteTimeGetCurrent()
        // (two turns of the main queue: the switch's own work, then the screens it drew)
        DispatchQueue.main.async {
            DispatchQueue.main.async { [weak self] in self?.record(name, ms: (CFAbsoluteTimeGetCurrent() - start) * 1000) }
        }
        guard mainPort != 0, seconds > 0, looking else { return }
        DispatchQueue.global(qos: .userInteractive).async { [weak self] in
            guard let self else { return }
            var counts: [String: Int] = [:]
            var looks = 0
            while CFAbsoluteTimeGetCurrent() - start < seconds {
                let f: [UInt] = self.sampleMain()
                for fn in Set(self.locate([f])) { counts[fn, default: 0] += 1 }
                looks += 1
                Thread.sleep(forTimeInterval: 0.012)
            }
            if looks == 0 { return }
            self.lock.lock()
            self.probeLooks[name, default: 0] += looks
            for (k, v) in counts { self.probeHot[name, default: [:]][k, default: 0] += v }
            self.lock.unlock()
        }
    }

    /// time a named piece of main-thread work
    @discardableResult
    func measure<T>(_ name: String, _ work: () throws -> T) rethrows -> T {
        let t0 = CFAbsoluteTimeGetCurrent()
        lock.lock(); active.append(name); lock.unlock()
        defer {
            let dt = (CFAbsoluteTimeGetCurrent() - t0) * 1000
            lock.lock()
            if let i = active.lastIndex(of: name) { active.remove(at: i) }
            var s = spans[name] ?? (0, 0, 0)
            s.n += 1; s.total += dt; s.max = max(s.max, dt)
            spans[name] = s
            lock.unlock()
        }
        return try work()
    }

    /// a time measured elsewhere (a build off the main thread), kept with the rest
    func record(_ name: String, ms: Double) {
        lock.lock()
        var s = spans[name] ?? (0, 0, 0)
        s.n += 1; s.total += ms; s.max = max(s.max, ms)
        spans[name] = s
        lock.unlock()
    }

    /// how much memory kosh holds now (what iOS counts against it), in MB
    static func memoryMB() -> Int {
        var info = task_vm_info_data_t()
        var count = mach_msg_type_number_t(MemoryLayout<task_vm_info_data_t>.size / MemoryLayout<integer_t>.size)
        let kr = withUnsafeMutablePointer(to: &info) {
            $0.withMemoryRebound(to: integer_t.self, capacity: Int(count)) { task_info(mach_task_self_, task_flavor_t(TASK_VM_INFO), $0, &count) }
        }
        return kr == KERN_SUCCESS ? Int(info.phys_footprint / 1_048_576) : -1
    }

    /// for the diagnostics
    func summary() -> [String: Any] {
        lock.lock(); defer { lock.unlock() }
        var sp: [String: Any] = [:]
        for (k, v) in spans { sp[k] = ["n": v.n, "avgMs": Int(v.total / Double(max(v.n, 1))), "maxMs": Int(v.max)] }
        let total = hangs.reduce(0) { $0 + (($1["ms"] as? Int) ?? 0) }
        let top: [[String: Any]] = hot.sorted { $0.value > $1.value }.prefix(25).map { ["fn": $0.key, "freezes": $0.value] }
        var probes: [String: Any] = [:]
        for (k, looks) in probeLooks {
            let spots: [[String: Any]] = (probeHot[k] ?? [:]).sorted { $0.value > $1.value }.prefix(30).map { ["fn": $0.key, "looks": $0.value] }
            probes[k] = ["looks": looks, "hot": spots]
        }
        return ["hangs": hangs, "hangCount": hangs.count, "hangMsTotal": total, "spans": sp, "memoryMB": Self.memoryMB(), "hot": top, "probes": probes]
    }
}
