import Foundation

// MARK: - The papers beyond statements
//
// Payslips, Form 16 and interest certificates, a bank's deposit advice, a loan statement, the NPS statement and
// a broker's contract notes, found in the mail and opened on this phone (docread.js reads them). Each is counted
// only when its own figures add up: gross less deductions is the net it prints, the principal at its rate comes
// to the maturity amount, the trades and charges come to the net it says the client pays. A paper that doesn't
// add up says so on the statements list and changes nothing.

/// what a payslip or a tax form said
struct DocFact: Codable, Hashable {
    var k: String
    var month: String? = nil; var fy: String? = nil
    var employer: String? = nil; var payer: String? = nil
    var gross: Double? = nil; var deductions: Double? = nil; var net: Double? = nil
    var basic: Double? = nil; var hra: Double? = nil; var pf: Double? = nil; var tds: Double? = nil; var profTax: Double? = nil
    var amount: Double? = nil; var stcg: Double? = nil; var ltcg: Double? = nil
    var src: String? = nil; var owner: String? = nil
}

/// a deposit read off its advice: folded in with the bank's own mail about it (by bank and deposit number)
struct DocDeposit: Codable, Hashable {
    var src: String; var inst: String; var depNo: String
    var amt: Double; var rate: Double; var mat: String; var matAmt: Double; var start: String
    var owner: String
}

/// one trade off a contract note
struct Trade: Codable, Hashable {
    var date: String; var isin: String? = nil; var name: String; var side: String
    var qty: Double; var price: Double; var value: Double; var exch: String? = nil
    var src: String? = nil
    /// whose: the inbox the contract note came to (older notes kept before this have none: the one person holding it)
    var owner: String? = nil
}

/// a dated sum: put in (negative) or taken out (positive), and the units it moved, if any
struct CashFlow: Codable, Hashable { var d: String; var a: Double; var u: Double? = nil }

/// One scheme in one CAS: the units it opened and closed the statement's period on, and every purchase, SIP,
/// switch and redemption between, its rows adding up. Kept for older statements too; the engine joins them,
/// oldest first, into the money behind a fund's yearly return (engine.js fundFlows).
struct FundSeg: Codable, Hashable {
    var src: String; var owner: String; var isin: String; var folio: String
    var from: String; var to: String; var open: Double; var close: Double
    var flows: [CashFlow]
}

extension LiveSession {
    static let paperKinds: Set<String> = ["payslip", "tax", "fd", "loan", "nps", "epf", "contract"]

    /// one paper's reading, kept if it adds up; what it said, in a line, for the statements list
    @MainActor
    func applyPaper(kind: String, parsed: DocParsed, from: String, source: String, sent: String, owner: String, key: String) -> String {
        let note = parsed.check?.note ?? ""
        // (a passbook whose columns don't come to its closing balance holds no figure, but it was read: it says why)
        let anything = !(parsed.facts ?? []).isEmpty || !parsed.holdings.isEmpty || !(parsed.loans ?? []).isEmpty
            || !(parsed.trades ?? []).isEmpty || parsed.epf != nil
        guard parsed.check?.ok == true else {
            if !anything { return "Opened, but nothing kosh reads was in it" }
            // a wrong reading is worse than none: it waits for a reader that adds it up
            return "Its figures don’t add up" + (note.isEmpty ? "" : " (" + note + ")") + ", so it isn’t counted. Shake the phone to send the layout in."
        }
        var line = note
        switch kind {
        case "payslip", "tax":
            docFacts.removeAll { $0.src == source }
            for var f in parsed.facts ?? [] { f.src = source; f.owner = owner; docFacts.append(f) }
            if let f = parsed.facts?.first, f.k == "payslip" {
                var l: String = "Payslip"
                if let m = f.month { l += " for " + Self.monthWord(m) }
                l += ": " + Fmt.rupees(f.net ?? 0) + " net of " + Fmt.rupees(f.gross ?? 0)
                if (f.tds ?? 0) > 0 { l += ", " + Fmt.rupees(f.tds ?? 0) + " income tax" }
                line = l + ". Adds up."
            } else if let f = parsed.facts?.first {
                let what = f.k == "form16" ? "Form 16" : f.k == "interest" ? "Interest certificate" : f.k == "gains" ? "Capital gains" : "TDS certificate"
                var l: String = what
                if let fy = f.fy { l += " FY " + fy }
                if (f.tds ?? 0) > 0 { l += ": TDS " + Fmt.rupees(f.tds ?? 0) } else if (f.amount ?? 0) > 0 { l += ": " + Fmt.rupees(f.amount ?? 0) }
                line = l + ". Adds up."
            }
        case "fd":
            docDeposits.removeAll { $0.src == source }
            for h in parsed.holdings where h.amt > 0 {
                let dep = DocDeposit(src: source, inst: h.bank, depNo: h.depNo ?? "", amt: h.amt, rate: h.rate ?? 0, mat: h.mat ?? "", matAmt: h.matAmt ?? 0, start: h.start ?? "", owner: owner)
                // the same deposit from a later advice (renewed, say) replaces the earlier reading
                docDeposits.removeAll { !dep.depNo.isEmpty && $0.inst == dep.inst && $0.depNo == dep.depNo }
                docDeposits.append(dep)
            }
            let n = parsed.holdings.count
            line = (n == 1 ? "A deposit of " + Fmt.rupees(parsed.holdings[0].amt) : String(n) + " deposits") + (parsed.holdings.first?.mat.map { ", maturing " + Day.short($0) } ?? "") + ". Adds up."
        case "loan":
            for l in parsed.loans ?? [] where (l.outstanding ?? 0) > 0 {
                let bank = l.bank ?? ""
                let name = l.name ?? "Loan"
                var loan = userLoans.first { x in
                    x.bank.lowercased() == bank.lowercased() && (x.name == name || (x.emi > 0 && abs(x.emi - (l.emi ?? 0)) <= x.emi * 0.02))
                } ?? UserLoan(name: name, bank: bank)
                loan.outstanding = l.outstanding ?? loan.outstanding
                if let e = l.emi, e > 0 { loan.emi = e }
                if let r = l.rate, r > 0 { loan.rate = r }
                if let d = l.nextDue, d.count == 10, let day = Int(d.suffix(2)) { loan.day = day }
                loan.note = "From your loan statement" + (l.asOf.map { " of " + Day.short($0) } ?? "")
                if let i = userLoans.firstIndex(where: { $0.id == loan.id }) { userLoans[i] = loan } else { userLoans.append(loan) }
                line = name + " with " + (bank.isEmpty ? "the lender" : bank) + ": " + Fmt.rupees(loan.outstanding) + " left" + (loan.emi > 0 ? ", EMI " + Fmt.rupees(loan.emi) : "") + ". Adds up."
            }
        case "nps":
            let tag = "nps|" + key + "|"
            docHoldings.removeAll { $0.source.hasPrefix(tag) }
            for h in parsed.holdings where h.amt > 0 {
                var uh = UserHolding(bank: h.bank, type: h.type, cls: h.cls, amt: h.amt, rate: 0, rem: "", owner: owner, source: tag + sent, units: h.units, isin: nil, asOf: h.asOf)
                if let c = h.cost, c > 0 { uh.cost = c }
                docHoldings.append(uh)
                noteReading(src: tag, date: (h.asOf ?? "").count >= 10 ? (h.asOf ?? "") : sent, owner: owner, values: ["ret": h.amt])
            }
            line = "NPS " + Fmt.words(parsed.holdings.reduce(0) { $0 + $1.amt }) + ". Adds up."
        case "epf":
            // every job under the UAN, with its months and years (LiveSession+Extras.swift › applyEPFBook)
            guard let book = parsed.epf else { break }
            let read: [String] = applyEPFBook(book, source: source, owner: owner)
            let total: Double = parsed.holdings.reduce(0) { $0 + $1.amt }
            let n = read.count
            line = "EPF passbook: " + (n == 1 ? read[0] : String(n) + " jobs under your UAN, " + Fmt.words(total)) + ". Adds up."
        case "contract":
            trades.removeAll { $0.src == source }
            for var t in parsed.trades ?? [] { t.src = source; t.owner = owner; trades.append(t) }
            recomputeGains()
            let n = parsed.trades?.count ?? 0
            line = String(n) + " trade" + (n == 1 ? "" : "s") + " read. Adds up."
        default: break
        }
        save()
        return line
    }

    static func monthWord(_ m: String) -> String {
        guard let d = monthIn.date(from: String(m.prefix(7))) else { return m }
        return monthOut.string(from: d)
    }
    // (made once, one per pattern: a formatter shared between threads is never changed after it's made)
    private static let monthIn: DateFormatter = { let f = DateFormatter(); f.locale = Locale(identifier: "en_IN"); f.dateFormat = "yyyy-MM"; return f }()
    private static let monthOut: DateFormatter = { let f = DateFormatter(); f.locale = Locale(identifier: "en_IN"); f.dateFormat = "MMM yyyy"; return f }()

    /// a registrar's or fund house's statement of one folio (or one transaction), not the consolidated one: engine.js casPart
    static func casPart(_ subject: String, _ file: String) -> Bool {
        ((try? Engine.shared.call("casPart", [subject, file])) ?? "") == "part"
    }

    /// Once: statements of one folio were taken for the consolidated one (only the newest from a sender was opened, and
    /// it replaced every fund that sender had). They're read again as what they are, and the consolidated ones with them.
    func redoCASParts() {
        guard ud.integer(forKey: "cas.partV") < 1 else { return }
        ud.set(1, forKey: "cas.partV")
        var changed = false
        // the senders whose one-folio statement stood in for their CAS: their CAS is read again
        var wiped: Set<String> = []
        for j in records.indices {
            guard let d = records[j].doc, d.kind == "cas", d.state == "read", Self.casPart(records[j].subject ?? "", d.file) else { continue }
            let run: String = SenderPasswords.domain(d.from) + "|" + d.acct
            let tag: String = "cas|" + run + "|" + (records[j].sent ?? "")
            if docHoldings.contains(where: { $0.source == tag }) { wiped.insert(run) }
            docHoldings.removeAll { $0.source == tag }
            records[j].doc?.state = ""
            changed = true
        }
        for j in records.indices {
            guard let d = records[j].doc, d.kind == "cas", d.state != "" else { continue }
            let part: Bool = Self.casPart(records[j].subject ?? "", d.file)
            let run: String = SenderPasswords.domain(d.from) + "|" + d.acct
            let tag: String = "cas|" + run + "|" + (records[j].sent ?? "")
            if !part && wiped.contains(run) && (d.state == "read" || d.state == "older") {
                records[j].doc?.state = ""
                records[j].doc?.held = nil
                changed = true
            } else if !part && d.state == "read" && !docHoldings.contains(where: { $0.source == tag }) {
                // read as the newest, and nothing it held is shown (a margin statement, a depository's notice, or one a
                // newer statement replaced): it no longer stands in the way
                records[j].doc?.held = false
                changed = true
            } else if !part && d.state == "older" {
                records[j].doc?.state = ""
                changed = true
            }
        }
        if changed { save() }
    }

    /// the holdings a build made from the mail alone (bought since the newest statement), kept for the price fetch
    func noteMade(_ s: Snapshot) {
        madeHoldings = s.hold.filter { $0.roll?.made == true && ($0.units ?? 0) > 0 }.map { (h: Holding) -> UserHolding in
            UserHolding(bank: h.bank, type: h.type, cls: h.cls, amt: h.amt, rate: 0, rem: "", owner: h.person, source: "roll", units: h.units, isin: h.isin, asOf: h.asOf)
        }
    }

    /// last four digits of a folio, to tell two apart
    static func folio4(_ f: String?) -> String { String((f ?? "").filter(\.isNumber).suffix(4)) }

    /// one folio's statement read in: each of its funds sets the holding it is (same person, ISIN and folio) to its day,
    /// when that's later than the holding says; a fund not held yet (bought since the consolidated statement) is added
    func mergePart(_ hs: [DocParsed.H], day: String, tag: String, owner: String) -> String {
        var moved = 0, added = 0
        for h in hs {
            let isin: String = (h.isin ?? "").uppercased()
            guard !isin.isEmpty else { continue }
            let f4: String = Self.folio4(h.folio)
            let at = docHoldings.firstIndex { (u: UserHolding) -> Bool in
                guard u.source.hasPrefix("cas|"), u.owner == owner, (u.isin ?? "").uppercased() == isin else { return false }
                let g4: String = Self.folio4(u.folio)
                return f4.isEmpty || g4.isEmpty || f4 == g4
            }
            if let j = at {
                if (Self.asOfOf(docHoldings[j]) ?? "") >= day { continue }
                // redeemed in full: the folio's statement shows none left
                if (h.units ?? 0) <= 0 && h.amt <= 0 { docHoldings.remove(at: j); moved += 1; continue }
                docHoldings[j].units = h.units
                docHoldings[j].amt = h.amt
                docHoldings[j].asOf = day
                if let c = h.cost, c > 0 { docHoldings[j].cost = c }
                moved += 1
            } else if (h.units ?? 0) > 0 && h.amt > 0 {
                var uh = UserHolding(bank: h.bank, type: h.type, cls: h.cls, amt: h.amt, rate: h.rate ?? 0, rem: h.rem ?? "", owner: owner,
                                     source: tag, units: h.units, isin: h.isin, asOf: day)
                if let c = h.cost, c > 0 { uh.cost = c }
                if let f = h.folio, !f.isEmpty { uh.folio = f }
                docHoldings.append(uh)
                added += 1
            }
        }
        if moved + added == 0 { return "One folio’s statement: nothing newer than what kosh has" }
        var bits: [String] = []
        if moved > 0 { bits.append(String(moved) + " fund" + (moved == 1 ? "" : "s") + " brought up to " + Day.fmt(day, "d MMM")) }
        if added > 0 { bits.append(String(added) + " new fund" + (added == 1 ? "" : "s")) }
        return "One folio’s statement: " + bits.joined(separator: ", ")
    }

    /// a consolidated statement just read in: the one-folio statements' funds it now holds give way to its rows (a
    /// later one's figures carried onto its row), and the ones from before its day go
    func settleParts(owner: String, day: String, added: [Int], tag: String) {
        let parts: [UserHolding] = docHoldings.filter { $0.owner == owner && $0.source.hasPrefix("cas|") && $0.source.contains("|part|") }
        guard !parts.isEmpty else { return }
        // a statement says what's not held only of what it covers: the same registrar's, or a consolidated one (the
        // depositories', MF Central) with funds in it
        let consolidated: Bool = tag.range(of: #"^cas\|(?:[\w.-]*\.)?(?:nsdl|cdsl|mfcentral|camsonline|kfintech)"#, options: .regularExpression) != nil
        var classes: Set<String> = []
        for k in added where k < docHoldings.count { classes.insert(docHoldings[k].cls) }
        var drop: Set<String> = []
        for p in parts {
            let isin: String = (p.isin ?? "").uppercased()
            let pDay: String = Self.asOfOf(p) ?? ""
            if let j = added.first(where: { (k: Int) -> Bool in
                k < docHoldings.count && (docHoldings[k].isin ?? "").uppercased() == isin && !isin.isEmpty
                    && (Self.folio4(p.folio).isEmpty || Self.folio4(docHoldings[k].folio).isEmpty || Self.folio4(p.folio) == Self.folio4(docHoldings[k].folio))
            }) {
                if pDay > day {
                    docHoldings[j].units = p.units
                    docHoldings[j].amt = p.amt
                    docHoldings[j].asOf = pDay
                    if let c = p.cost, c > 0 { docHoldings[j].cost = c }
                }
                drop.insert(p.id)
            } else if pDay <= day && classes.contains(p.cls) && (p.source.hasPrefix(tag) || consolidated) {
                drop.insert(p.id)
            }
        }
        docHoldings.removeAll { drop.contains($0.id) }
    }

    /// What every share cost (first in, first out, from the contract notes), and the gains by financial year. A
    /// holding takes the cost only when the trades account for exactly the shares the statement says are held.
    func recomputeGains() {
        guard !trades.isEmpty, let out = try? Engine.shared.call("fifoGainsJSON", [JSONText.encode(trades), Self.today]),
              let g = try? JSONText.decode(Gains.self, out) else { fifoCost = [:]; gainsFY = [:]; return }
        var cost: [String: Gains.Pos] = [:]
        for p in g.byIsin where !p.isin.isEmpty { cost[p.isin] = p }
        fifoCost = cost
        gainsFY = g.fy
    }
    struct Gains: Decodable {
        struct Pos: Decodable { let isin: String; let name: String; let qty: Double; let cost: Double }
        struct FY: Decodable { let stcg: Double; let ltcg: Double }
        let byIsin: [Pos]; let fy: [String: FY]
    }

    /// Each scheme's rows in a CAS (its purchases, SIPs and redemptions, when they add up to its closing units),
    /// kept whether or not the statement is the newest: an older one may be what the newer ones join on to.
    /// A statement read again says it afresh.
    func noteFundRows(_ parsed: DocParsed, source: String, owner: String) {
        let to: String = String((parsed.asOf ?? "").prefix(10))
        guard to.count == 10 else { return }
        fundSegs.removeAll { $0.src == source }
        for h in parsed.holdings {
            guard let isin = h.isin, !isin.isEmpty, let flows = h.flows, !flows.isEmpty, let units = h.units, let open = h.open else { continue }
            fundSegs.append(FundSeg(src: source, owner: owner, isin: isin, folio: h.folio ?? "", from: parsed.from ?? "", to: to,
                                    open: open, close: units, flows: flows))
        }
    }

    /// A locked statement, tried with passwords made from the details you saved: the rule the sender's email
    /// prints first, then the formats Indian banks, card issuers, depositories, brokers, the tax department and
    /// insurers commonly use (agent.js pwGuess), with the card and account digits kosh has seen from that sender.
    /// Downloaded once and tried on the phone; the one that opens it is kept for the sender, so the rest of its
    /// statements (older ones too) open with it. Each statement gets this once.
    /// whose papers these probably are: the person the mail is written to ("Dear Mohan Example", a parent's paper in
    /// your inbox, or yours in theirs), then the person whose inbox it came to, then whoever owns the accounts and
    /// cards this sender (or its bank) writes about
    func likelyHolders(_ r: Reading) -> [String] {
        var out: [String] = addressees(r).map(\.id)
        let inboxOwner: String = ownerOf(inbox: r.doc?.acct ?? r.acct ?? "")
        if !out.contains(inboxOwner) { out.append(inboxOwner) }
        let inst = (r.inst ?? "").lowercased()
        if !inst.isEmpty {
            for (key, person) in owners where key.lowercased().hasPrefix(inst) && !out.contains(person) { out.append(person) }
        }
        return out
    }

    /// The same, with everyone's saved details: the paper's likely holder first, then you, then the rest of the family.
    /// Each person's details go with every detail kosh found for them with this sender (a CRN, an account number, a
    /// folio, a policy number: Your details), and the format that last opened this sender's statements is tried first.
    @MainActor
    func tryProfiles(at i: Int, _ profiles: [PasswordProfile]) async -> Bool {
        guard !profiles.isEmpty else { return false }
        guard i < records.count, var d = records[i].doc else { return false }
        d.auto = true
        records[i].doc = d
        let rid = records[i].id
        let domain: String = SenderPasswords.domain(d.from)
        let learnt: String = PwFormats.get(domain) ?? ""
        let ctxJSON = pwContext(at: i, learnt: learnt)
        let inst: String = records[i].inst ?? ""
        let groups: [FactGroup] = lastFacts
        let people: [PasswordProfile] = profiles.map { (p: PasswordProfile) -> PasswordProfile in
            var x = p
            let f: [PwFact] = Details.pwFacts(who: p.who ?? "", inst: inst, domain: domain, groups: groups)
            x.facts = f.isEmpty ? nil : f
            return x
        }
        // (more to try when the details give the formats new material; PDFKit answers a wrong password in a moment)
        let more: Int = people.contains { ($0.facts ?? []).isEmpty == false } ? 10 : 0
        let saved = SenderPasswords.get(d.from)
        // each person's details made into the sender's rule, and into the usual formats (PwTries.order decides the
        // order and how many: the saved one, the rule's, the format that opened this sender's last paper, the rest)
        var built: [[PwTries.Made]] = []
        var guessed: [[PwTries.Made]] = []
        for profile in people {
            let profileJSON = JSONText.encode(profile)
            if !d.hint.isEmpty, let out = try? Engine.shared.call("pwBuildJSON", [d.hint, profileJSON, ctxJSON]),
               let b = try? JSONText.decode(Built.self, out), b.ok {
                let fs: [String] = b.formats ?? []
                built.append(b.candidates.enumerated().map { PwTries.Made(pw: $0.element, format: $0.offset < fs.count ? fs[$0.offset] : nil) })
            }
            if let out = try? Engine.shared.call("pwGuessJSON", [profileJSON, ctxJSON]), let g = try? JSONText.decode(Guess.self, out) {
                let fs: [String] = g.formats ?? []
                guessed.append(g.candidates.enumerated().map { PwTries.Made(pw: $0.element, format: $0.offset < fs.count ? fs[$0.offset] : nil) })
            } else { guessed.append([]) }
        }
        // (each person in the family gets their turn: a parent's paper is tried with the parent's formats too; the likely
        // holder, first, gets the usual formats in full, everyone else the commonest)
        let cap: Int = profiles.count > 1 ? min(24 * profiles.count + 14 + more * 2, 160) : 32 + more
        let tries = PwTries.order(saved: saved, built: built, guessed: guessed, learnt: learnt, takeFirst: 30 + more, takeRest: 16 + more / 2, cap: cap)
        let candidates: [String] = tries.list
        let formatOf: [String: String] = tries.formatOf
        guard !candidates.isEmpty else { return false }
        guard let bytes = try? await docBytes(&d) else {
            // the inbox didn't hand it over (offline, a hiccup): not a try, so the details get their turn next time
            if let j = records.firstIndex(where: { $0.id == rid }) { records[j].doc?.auto = nil }
            return false
        }
        // (fetched by the attachment's id of today when the one kept had stopped working: kept on the paper)
        if let j = records.firstIndex(where: { $0.id == rid }), records[j].doc?.att != d.att { records[j].doc?.att = d.att }
        let from = d.from
        let file: String = d.file
        let list: [String] = candidates
        let t0: CFAbsoluteTime = CFAbsoluteTimeGetCurrent()
        let found: (String, DocUnlock.Result)? = await Task.detached(priority: .utility) { () async -> (String, DocUnlock.Result)? in
            // (a zip or a workbook Excel locked is tried by unlock.js with the same list: DocLocked)
            guard let pw = DocUnlock.firstPassword(bytes, list, file: file) else { return nil }
            // kept for the sender, exactly as one you typed
            let opened: DocUnlock.Result
            // (a statement inside a zip may be locked another way: it gets the rest of the list too)
            if DocLocked.isZip(file) { opened = await DocLocked.openZip(bytes, file: file, sender: from, typed: pw, also: list) }
            else if DocRef.isSheet(file) { opened = DocTable.open(bytes, file: file, sender: from, typed: pw) }
            else { opened = await DocUnlock.open(bytes, sender: from, typed: pw) }
            return (pw, opened)
        }.value
        Perf.shared.record("statement passwords tried", ms: (CFAbsoluteTimeGetCurrent() - t0) * 1000)
        guard let hit = found, case .opened(let text) = hit.1, let j = records.firstIndex(where: { $0.id == rid }) else {
            // nothing opened it, the saved password included: it waits for you, and isn't downloaded again for that one
            if saved != nil, let tag = SenderPasswords.tag(from), let j = records.firstIndex(where: { $0.id == rid }) { records[j].doc?.tried = tag }
            return false
        }
        // (the format that opened it, for this sender's next statements)
        if let format = formatOf[hit.0] { PwFormats.set(domain, format) }
        return await openDoc(at: j, typed: SenderPasswords.get(from), opened: text)
    }
    /// what a sender's password rule may use besides your details: the card or account digits this sender (or its
    /// bank) writes about, its domain, and the format that last opened its statements (learnt)
    func pwContext(at i: Int, learnt: String = "") -> String {
        guard i < records.count else { return "{}" }
        let inst: String = records[i].inst ?? ""
        let domain: String = SenderPasswords.domain(records[i].doc?.from ?? records[i].from ?? "")
        var digits: [String] = []
        for r in records where (SenderPasswords.domain(r.from ?? "") == domain || (!inst.isEmpty && r.inst == inst)) {
            if let l = r.last4, l.count >= 4, !digits.contains(l) { digits.append(l) }
            if digits.count >= 4 { break }
        }
        let known: String = learnt.isEmpty ? (PwFormats.get(domain) ?? "") : learnt
        let ctx: [String: Any] = ["last4": records[i].last4 ?? "", "domain": domain, "digits": digits, "inst": inst, "learnt": known]
        return JSONText.object(ctx)
    }

    /// one sender whose statements are still locked, and what kosh needs to open them, in plain words
    struct LockedNeed: Identifiable, Hashable {
        let id: String          // the sender's domain (what a typed password is kept by)
        let sender: String      // its name, where kosh knows it
        let count: Int
        let hint: String        // the sender's own words on how the password is made ("" when the email says nothing)
        let need: String        // what's missing, or what to do
        /// saving or fixing your details would open it (else: type the password the email describes)
        let details: Bool
        /// whose details it needs: the likeliest holder of the sender's newest locked paper ("me" unless the mail is
        /// written to someone else in the family). `need` is worked out from their details alone, in the engine's words
        /// ("your"); the screen says it with their name (PaperShelf.need)
        var holder: String = "me"
        /// one ask per sender, holder and rule (several can share a sender)
        var key: String { id + "|" + holder + "|" + hint }
        /// the same bank's other addresses this one ask stands for (its detail is kept under each)
        var also: [String] = []
        var ids: [String] { [id] + also }
    }

    /// every sender with locked statements: what each needs, worked out from its own rule and your saved details.
    /// (31 Oct) Worked out again only when something it reads has changed: the records, your saved details (any
    /// Keychain write), the household, the inboxes, the names hidden and the files added by hand. The Statements page
    /// asked for it on every visit and the diagnostics every minute, each a pass per sender over every mail, a Keychain
    /// read and an engine call: about a second on the main thread with 5,000 mails
    @MainActor
    func lockedNeeds() -> [LockedNeed] {
        recordsLock.lock(); let groups: Int = lastNameGroups.count; recordsLock.unlock()
        let namesHidden: String = hidden.filter { $0.hasPrefix("name:") }.sorted().joined(separator: ",")
        let head: [String] = [String(recordsVersion), String(Keychain.writes), name, email, String(groups), namesHidden]
        var key: String = head.joined(separator: "|")
        for p in people { key += "|p" + p.id + ":" + p.name + ":" + p.full }
        for a in accounts { key += "|a" + a.id + ":" + (a.person ?? "") }
        for (k, v) in owners.sorted(by: { $0.key < $1.key }) { key += "|o" + k + ":" + v }
        for d in localDocs { key += "|l" + d.id + ":" + d.state + ":" + d.kind }
        if let m = lockedNeedsMemo, m.key == key { return m.needs }
        let made: [LockedNeed] = lockedNeedsNow()
        lockedNeedsMemo = (key, made)
        return made
    }
    /// the last of them worked out, and whether the records are still as they were then: the diagnostics kept every
    /// minute say these and never work them out themselves (an export you ask for does)
    var lockedNeedsKept: (needs: [LockedNeed], fresh: Bool)? {
        guard let m = lockedNeedsMemo else { return nil }
        return (m.needs, m.key.hasPrefix(String(recordsVersion) + "|"))
    }
    @MainActor
    private func lockedNeedsNow() -> [LockedNeed] {
        var bySender: [String: [Int]] = [:]
        // (by sender, whose statement it is and the rule its mail gives: a father's statement mailed to your inbox
        // asks for his details, by its own rule, apart from yours)
        for i in records.indices where records[i].doc?.state == "locked" {
            let dom0: String = SenderPasswords.domain(records[i].doc?.from ?? "")
            let who0: String = likelyHolders(records[i]).first ?? "me"
            bySender[dom0 + "\u{1}" + who0 + "\u{1}" + (records[i].doc?.hint ?? ""), default: []].append(i)
        }
        let anyDetails: Bool = PasswordProfile.anyUsable
        var out: [LockedNeed] = []
        for (gk, idx0) in bySender {
            let dom: String = String(gk.split(separator: "\u{1}", omittingEmptySubsequences: false).first ?? Substring(gk))
            // (the sender's newest paper first: a sender that changed its rule is asked by its new rule, not an old one)
            let idx: [Int] = idx0.sorted { (records[$0].sent ?? "") > (records[$1].sent ?? "") }
            guard let first = idx.first else { continue }
            let r: Reading = records[first]
            let name: String = (r.inst ?? "").isEmpty ? dom : (r.inst ?? dom)
            let hint: String = idx.compactMap { (j: Int) -> String? in records[j].doc?.hint }.first { !$0.isEmpty } ?? ""
            let holder: String = likelyHolders(r).first ?? "me"
            var need: String
            var details: Bool
            if hint.isEmpty {
                details = !anyDetails
                need = anyDetails
                    ? "Your saved details didn’t open it, and the email doesn’t say how the password is made. Type it once below."
                    : "Save your details below: kosh tries the formats banks commonly use."
            } else {
                // the holder's own details, never someone else's in their place: a parent's paper with none of the
                // parent's details saved was worked out from yours, said "made from your saved details and it didn't
                // open", and asked for the whole password where the rule needed only the parent's date of birth
                var profile: PasswordProfile = PasswordProfile.ordered(first: [holder]).first { $0.who == holder } ?? PasswordProfile()
                // (someone the mail is written to and not in the household yet: the name it greets them by)
                if profile.name.isEmpty { profile.name = addressees(r).first { $0.id == holder }?.full ?? "" }
                let built: Built? = (try? Engine.shared.call("pwBuildJSON", [hint, JSONText.encode(profile), pwContext(at: first)]))
                    .flatMap { (s: String) -> Built? in try? JSONText.decode(Built.self, s) }
                if let b = built, !b.ok, !b.missing.isEmpty {
                    let what: String = b.missing.joined(separator: ", ")
                    // your own details can be saved; a card's digits or a policy number come from its mail
                    details = what.hasPrefix("your ")
                    need = details ? "Needs " + what + "." : "Needs " + what + ": type the password once below."
                } else if let b = built, b.ok {
                    details = true
                    need = "kosh made the password from your saved details and it didn’t open. Check them, or type it below."
                } else {
                    details = false
                    need = "Type the password the email describes, once."
                }
            }
            out.append(LockedNeed(id: dom, sender: name, count: idx.count, hint: hint, need: need, details: details, holder: holder))
        }
        // passbooks shared in from Files that are still locked ask here too, on the same card: their password is the
        // EPFO's rule and not that one file's, so one typed once opens every passbook, this one and the next
        let books: [LocalDoc] = localDocs.filter { $0.state == "locked" && Self.pwKey(forLocal: $0) == Self.epfDomain }
        if !books.isEmpty {
            out.append(LockedNeed(id: Self.epfDomain, sender: "EPFO passbook", count: books.count, hint: "",
                                  need: PasswordProfile.anyUsable
                                      ? "Your saved details didn’t open it. Type the password the EPFO’s download asked for, once — kosh keeps it for the EPFO, so your next passbook opens by itself."
                                      : "Save your date of birth below: a passbook is usually locked with it. Or type its password once.",
                                  details: !PasswordProfile.anyUsable))
        }
        return out.sorted { (a: LockedNeed, b: LockedNeed) -> Bool in a.sender.localizedCaseInsensitiveCompare(b.sender) == .orderedAscending }
    }

    /// statements found in the mail and not opened yet (new ones, or a run cut short)
    var hasUnopenedDocs: Bool {
        records.contains { (r: Reading) -> Bool in (r.doc?.state ?? "x").isEmpty }
    }

    /// the engine's tries, each with the format that made it (formats, beside candidates, when the engine gives them)
    struct Guess: Decodable { let candidates: [String]; var formats: [String]? = nil }
    struct Built: Decodable { let ok: Bool; let candidates: [String]; let missing: [String]; var formats: [String]? = nil }

    // MARK: harvesting the facts a statement password is made of, with no typing
    //
    // A password is built from the holder's name, a date of birth, a Customer ID/CRN, a PAN or a PIN code. kosh
    // already knows the names (the household it built from the mail), and a sender's own mail often prints a
    // Customer ID, PAN, date of birth or PIN code in plain sight (engine.js pwFacts reads only what's plainly
    // printed, never a masked value). Gathering these as it reads, with no typing, lets the auto-unlock run from a
    // name and the one date of birth the person may still need to enter. Stored on the phone's Keychain, apart from
    // anything the person typed, cleared by Erase, never shown or logged.

    struct PwFacts: Decodable { var names: [String]? = nil; var fields: [String]? = nil; var cid: String? = nil; var crn: String? = nil; var pan: String? = nil; var dob: String? = nil; var pin: String? = nil; var mobile: String? = nil }

    /// the names kosh already knows for each household person, saved as harvested facts (fills blanks only)
    @MainActor
    func harvestPasswordNames() {
        var h = PasswordProfile.harvested()
        var changed = false
        func set(_ id: String, _ raw: String) {
            let n = raw.trimmingCharacters(in: .whitespaces)
            guard n.count >= 2, n.lowercased() != "you" else { return }
            var p = h[id] ?? PasswordProfile()
            if p.name.isEmpty { p.name = n; h[id] = p; changed = true }
        }
        if !name.isEmpty { set("me", name) }
        for person in people where !person.full.isEmpty { set(person.id, person.full) }
        if changed { PasswordProfile.saveHarvested(h) }
    }

    /// facts a sender's own mail plainly prints, read on the phone (pwFacts), a Customer ID/CRN keyed by the sender's
    /// domain. They're the person's the mail is written to, not whoever owns the inbox: a father's date of birth
    /// printed in a mail that came to your inbox is his, and saved as yours it would be tried as yours. A mail that
    /// names no one kosh knows is set aside, unless the household is just one person (the inbox's own).
    /// Returns true when something new was harvested.
    @MainActor
    @discardableResult
    func harvestPasswordFacts(text: String, html: String, inbox: String, domain: String) -> Bool {
        guard let out = try? Engine.shared.call("pwFactsJSON", [text, html]),
              let f = try? JSONText.decode(PwFacts.self, out) else { return false }
        let owner: String = ownerOf(inbox: inbox)
        let named: [PwWho] = pwWho(names: f.names ?? [], fields: f.fields ?? [], inbox: owner)
        let person: String
        let alone: Bool = !people.contains(where: { $0.id != "me" }) && accounts.allSatisfy({ ($0.person ?? "me") == "me" })
        // (one mail's date of birth or PAN is one person's: a joint mail naming two people gives it to neither)
        if named.count == 1, let first = named.first { person = first.id }
        else if named.isEmpty && (f.names ?? []).isEmpty && alone { person = owner }
        else { return false }
        // the name as this sender writes it, only the one that is this person; a surname alone ("Dear Mrs Example") is
        // whose inbox it came to, which orders the tries but never fills anyone's details
        let theirs: String? = (f.names ?? []).first { (n: String) -> Bool in pwWho(names: [n], fields: [], inbox: owner).first?.id == person }
        if !(named.isEmpty && alone) {
            guard let n = theirs, Self.fullName(n) else { return false }
        }
        var h = PasswordProfile.harvested()
        var p = h[person] ?? PasswordProfile()
        var changed = false
        if p.name.isEmpty, let n = theirs, n.count >= 2 { p.name = n; changed = true }
        // (never a date that never was or a PAN printed masked: kept, it would read as known and nothing would ask for it)
        if p.dob.isEmpty, let d = f.dob, let v = PaperShelf.typed("dob", d) { p.dob = v; changed = true }
        if p.pan.isEmpty, let raw = f.pan, let v = PaperShelf.typed("pan", raw) { p.pan = v; changed = true }
        if p.pin.isEmpty, let v = f.pin, !v.isEmpty { p.pin = v; changed = true }
        if p.mobile.isEmpty, let v = f.mobile, v.count == 10 { p.mobile = v; changed = true }
        let id = (f.cid?.isEmpty == false ? f.cid : f.crn) ?? ""
        if !id.isEmpty, !domain.isEmpty, (p.ids[domain] ?? "").isEmpty { p.ids[domain] = id; changed = true }
        if changed { h[person] = p; PasswordProfile.saveHarvested(h) }
        return changed
    }

    /// HARVEST (3 Nov): every money mail kosh keeps and every paper it has opened, read once per version for the details
    /// a password is made of (harvestPasswordFacts decides whose each is, by the name it prints). An insurer's policy
    /// prints the date of birth, a CAS the PAN, a bank's statement the Customer ID and the mobile: any one of them opens
    /// the rest. Before, only a locked statement's own mail was read, once. Returns true when anything new was learnt.
    static let harvestV = 1
    @MainActor
    func harvestFromEverything() -> Bool {
        guard ud.integer(forKey: "pw.harvestV") < Self.harvestV else { return false }
        var learnt = false
        let moneyKinds: Set<String> = ["bank", "card", "wallet", "insurer", "amc", "broker", "depository", "fund", "investment", "insurance", "lender"]
        for r in records {
            let domain: String = SenderPasswords.domain(r.from ?? "")
            let money: Bool = r.doc != nil || moneyKinds.contains((r.instKind ?? "").lowercased()) || r.kind == "policy" || r.kind == "investment" || r.kind == "statement"
            guard money, !domain.isEmpty else { continue }
            if let m = MailVault.get(r.id), harvestPasswordFacts(text: m.text, html: m.html, inbox: r.acct ?? "", domain: domain) { learnt = true }
            if let d = r.doc, d.state == "read", let kept = MailVault.getText(Self.docTextKey(d)) {
                if harvestPasswordFacts(text: String(DocText.split(kept).body.prefix(20000)), html: "", inbox: d.acct, domain: domain) { learnt = true }
            }
        }
        ud.set(Self.harvestV, forKey: "pw.harvestV")
        if learnt { note("harvest: new details learnt from the mail and papers") }
        return learnt
    }

    /// a first name and a surname at least ("Rohan Example", "MOHAN K EXAMPLE"), not a title and a surname
    static func fullName(_ n: String) -> Bool {
        let titles: Set<String> = ["mr", "mrs", "ms", "miss", "dr", "shri", "sri", "smt", "kumari", "master", "m/s"]
        let words: [String] = n.lowercased().replacingOccurrences(of: ".", with: " ").split(separator: " ").map(String.init)
            .filter { !titles.contains($0) && $0.count > 1 }
        return words.count >= 2
    }

    /// Details saved for you or your family: the locked statements are opened in the background (with iOS's time asked
    /// for), never while you wait on the page you typed them on. Saved again meanwhile (the next person's details), it
    /// runs once more when it's done, so every detail gets its turn. What it came to is said on the screens (unlockNote).
    @MainActor
    func openLockedInBackground() {
        if unlocking { unlockAgain = true; return }
        unlocking = true
        unlockNote = "Opening locked statements in the background. You can leave this page."
        Task { @MainActor in
            KeepGoing.shared.begin("Opening locked statements")
            var total = 0
            repeat { unlockAgain = false; total += await openLockedWithProfile() } while unlockAgain && !KeepGoing.shared.stopped
            KeepGoing.shared.end()
            unlocking = false
            let left: Int = lockedDocs.count
            unlockNote = total > 0 ? "Opened \(Words.number(total)) locked statement\(total == 1 ? "" : "s")" + (left > 0 ? ". \(Words.number(left)) still locked." : ".")
                : (KeepGoing.shared.stopped ? "Paused: kosh carries on opening them next time." : "Nothing new opened. The rest need details not saved yet, or a password typed once.")
            note("unlock: opened \(total), \(left) still locked")
        }
    }

    /// after the details are saved or changed: every statement still locked, however old, gets its try again
    @MainActor
    func openLockedWithProfile() async -> Int {
        harvestPasswordNames()
        guard PasswordProfile.anyUsable else { return 0 }
        var opened = 0
        let locked: [String] = records.compactMap { r in
            guard let d = r.doc, d.state == "locked" else { return nil }
            return r.id
        }
        for id in locked {
            // found again each time: the reading may have added records meanwhile
            guard let i = records.firstIndex(where: { $0.id == id }), records[i].doc?.state == "locked" else { continue }
            records[i].doc?.auto = nil
            if await tryProfiles(at: i, PasswordProfile.ordered(first: likelyHolders(records[i]))) { opened += 1 }
        }
        save(); rebuildSoon()
        // the rest of each sender's statements open with the password that just worked
        if opened > 0 { await readDocuments() }
        return opened
    }
}

// MARK: - Whose each locked statement is, and the family's details it needs
//
// A family's papers land in each other's inboxes: a parent's deposit advice in yours, your policy in theirs. Each is
// locked with its holder's own details, so kosh works out whose each one is from the name its mail is written to
// (engine.js pwWho), tries that person's details first, and asks for the details of everyone it found: you, the
// household, and the people the locked mail is written to who aren't in the household yet.

struct PwWho: Decodable, Hashable { let id: String; let full: String }

/// one person a locked statement may be for, and what kosh still needs from them
struct UnlockPerson: Identifiable, Hashable {
    let id: String
    let name: String
    /// "You", their relation, or "" for someone the mail names who isn't in the household yet
    let rel: String
    let inHousehold: Bool
    /// locked statements written to them (or from their inbox, when the mail names no one)
    let locked: Int
    /// what of a name, date of birth and PAN isn't known for them yet
    let missing: [String]
    /// they typed details (else kosh only has what it found in the mail)
    let saved: Bool
}

extension LiveSession {
    /// the household, and the people the mail greets who aren't in it yet, as the engine's pwWho takes them
    func pwWhoContext() -> String {
        recordsLock.lock(); let groups: [NameGroup] = lastNameGroups; recordsLock.unlock()
        // (an inbox nobody is set for says nothing about whose name its address spells)
        var aliases: [String] = [email].map { $0.split(separator: "@").first.map(String.init) ?? "" }
        aliases += accounts.filter { $0.person != nil }.map { $0.id.split(separator: "@").first.map(String.init) ?? "" }
        let ctx: [String: Any] = [
            "name": name,
            "people": people.map { ["id": $0.id, "name": $0.name, "full": $0.full] },
            "hidden": Dictionary(uniqueKeysWithValues: hidden.map { ($0, true) }),
            "aliases": aliases.filter { !$0.isEmpty }.map { $0.replacingOccurrences(of: ".", with: " ") },
            "inboxes": Dictionary(uniqueKeysWithValues: accounts.compactMap { a in a.person.map { (a.id, $0) } }),
            "groups": groups.map { ["id": $0.id, "full": $0.full] },
        ]
        return JSONText.object(ctx)
    }

    /// the people these names are (greetings first, then holder fields), each once; [] for no one kosh knows
    func pwWho(names: [String], fields: [String], inbox: String) -> [PwWho] {
        guard !names.isEmpty,
              let out = try? Engine.shared.call("pwWhoJSON", [JSONText.encode(names), JSONText.encode(fields), inbox, pwWhoContext()]),
              let who = try? JSONText.decode([PwWho].self, out) else { return [] }
        return who.filter { !hidden.contains("name:" + $0.id) }
    }

    /// whom a statement's mail is written to
    func addressees(_ r: Reading) -> [PwWho] {
        pwWho(names: r.named ?? [], fields: r.namedF ?? [], inbox: ownerOf(inbox: r.doc?.acct ?? r.acct ?? ""))
    }

    /// everyone a locked statement may be for: you, the household, then the people the locked mail is written to who
    /// aren't in it yet; with how many are theirs and what kosh still needs
    func unlockPeople() -> [UnlockPerson] {
        var count: [String: Int] = [:]
        var named: [String: String] = [:]
        for r in lockedDocs {
            let who: [PwWho] = addressees(r)
            for w in who where named[w.id] == nil { named[w.id] = w.full }
            let holder: String = who.first?.id ?? ownerOf(inbox: r.doc?.acct ?? r.acct ?? "")
            count[holder, default: 0] += 1
        }
        let harvested: [String: PasswordProfile] = PasswordProfile.harvested()
        func row(_ id: String, _ name: String, _ rel: String, _ inHousehold: Bool) -> UnlockPerson {
            let typed: PasswordProfile? = PasswordProfile.load(for: id)
            let have: PasswordProfile = (typed ?? PasswordProfile()).filledWith(harvested[id] ?? PasswordProfile())
            var missing: [String] = []
            // (a detail that can't be right, read from a mail before this check existed, is still missing)
            if PaperShelf.typed("dob", have.dob) == nil { missing.append("date of birth") }
            if PaperShelf.typed("pan", have.pan) == nil { missing.append("PAN") }
            if have.name.isEmpty { missing.insert("name", at: 0) }
            return UnlockPerson(id: id, name: name, rel: rel, inHousehold: inHousehold, locked: count[id] ?? 0, missing: missing, saved: typed != nil)
        }
        var out: [UnlockPerson] = [row("me", name.isEmpty ? "You" : name, "You", true)]
        for p in people where p.id != "me" { out.append(row(p.id, p.full.isEmpty ? p.name : p.full, p.rel, true)) }
        // the people the locked mail is written to who aren't in the household: most locked first
        let outside: [String] = named.keys.filter { (id: String) -> Bool in id != "me" && !people.contains(where: { $0.id == id }) && !hidden.contains("name:" + id) }
            .sorted { (count[$0] ?? 0) == (count[$1] ?? 0) ? $0 < $1 : (count[$0] ?? 0) > (count[$1] ?? 0) }
        for id in outside { out.append(row(id, named[id] ?? id, "", false)) }
        return out
    }

    /// someone the locked mail is written to joins the household; the details saved or found for them go with them
    @MainActor
    @discardableResult
    func addUnlockPerson(_ id: String, full: String, rel: String) -> String? {
        addPerson(name: full, rel: rel)
        guard let added = people.last, added.full == full.trimmingCharacters(in: .whitespaces), added.id != id else { return nil }
        if let p = PasswordProfile.load(for: id) { PasswordProfile.save(p, for: added.id); PasswordProfile.save(nil, for: id) }
        var h = PasswordProfile.harvested()
        if let p = h.removeValue(forKey: id) { h[added.id] = p; PasswordProfile.saveHarvested(h) }
        rebuildSoon()
        return added.id
    }

    /// "not family": their name isn't asked about again, and what kosh kept for them goes
    @MainActor
    func notFamily(_ id: String) {
        setHidden("name:" + id, true)
        PasswordProfile.save(nil, for: id)
        var h = PasswordProfile.harvested()
        if h.removeValue(forKey: id) != nil { PasswordProfile.saveHarvested(h) }
        rebuildSoon()
    }
}
