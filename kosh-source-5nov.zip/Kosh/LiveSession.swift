import Foundation
import Observation
import UIKit
import Network

// MARK: - The beta's live session: your Gmail, read on this phone, into the same screens

struct Override: Codable, Hashable {
    var c: String?; var s: String?; var f: String?; var n: String?
    /// your share of the charge, when others owe you the rest
    var mine: Double?
    /// kept in the ledger but not counted as spending, with the reason
    var ex: String?
    /// parts split out of the charge, each its own row on the same card and day
    var parts: [Part]?
    struct Part: Codable, Hashable { var a: Double; var c: String?; var s: String?; var ex: String? }
    /// the month it counts in, when not its own (yyyy-MM)
    var cm: String? = nil
    /// a refund you're waiting for: how much, by when, a note, and that it came back without kosh seeing it
    var rf: Double? = nil; var rfBy: String? = nil; var rfNote: String? = nil; var rfDone: Bool? = nil
    /// count this one in spending, though kosh would leave it out (unnamed, a top-up, a trip's)
    var cnt: Bool? = nil
    /// who filed it: nil (you), "claude" (Claude, sure), "claude-guess" (Claude, likely: the payment shows it as a guess)
    var by: String? = nil
    /// on a credit: the payment it's the refund for
    var rfOf: String? = nil
    /// what was set for this payment only, not every payment to its payee: "c" its category, "f" whom it's for
    var only: String? = nil
    /// the trip or event it belongs to ("none": not one, whatever its days)
    var tr: String? = nil
    /// the same payment as this other one, told by another mail: not listed or counted again ("Counted twice?" › Merge)
    var dup: String? = nil
    /// payments you said are not this one told twice: never asked about again
    var dupNot: [String]? = nil
    /// the account a payment through an app (CRED) really left: "Bank|1234|its key"
    var from: String? = nil
    /// with mine: the money back the split already took into account (it split the payment less it, or left it yours).
    /// Money back beyond it splits the same way the payment did (engine 21b); none said (a split saved before 30 Oct
    /// 2026): all money back comes off yours, as it always did
    var sb: Double? = nil
    /// on a credit: the tenant's rent it is, "<property id>|<floor's place>" (engine/21q-build-rent-tags.js); learnt from
    /// for the payer's other credits of about the sum, unless only has "r"
    var rent: String? = nil
    /// what it was, in a word, as you said it (engine/21r-build-orders.js): tags you put on and tags of kosh's you took off.
    /// Learnt for the payee's other payments where it is a kind (Beauty, Electronics, Fashion, Books, Food) or a tag taken off
    var tags: [String]? = nil
    var tagsOff: [String]? = nil
}

/// a trip (it has days, and what's spent on them goes in) or an event (a wedding, a renovation: only what
/// you put in it), as you set it up
struct UserTrip: Codable, Identifiable, Hashable {
    var id: String
    var name: String
    var kind: String = "trip"
    var from: String = ""
    var to: String = ""
    var budget: Double = 0
    var sym: String = "airplane"
    var color: String = "#FF9500"
    /// put what's spent on its days in it, on its own
    var auto: Bool = true
    /// whose spending goes in on its own (empty: everyone's)
    var who: [String] = []
    var note: String = ""
}

/// An inbox kosh reads beside the one you signed in with: Gmail, Outlook (Microsoft) or any mail server (IMAP).
struct MailAccount: Codable, Identifiable, Hashable {
    var id: String        // the email address
    var name: String
    var color: String
    var scanFrom: String = ""
    var lastScan: String = ""
    var person: String? = nil   // whose inbox it is: their accounts and cards are theirs
    /// nil or "gmail", "microsoft", "imap"; and for IMAP, the server and the name it signs in with
    var provider: String? = nil
    var host: String? = nil
    var port: Int? = nil
    var login: String? = nil
    /// how its records are told apart ("a1-", "a2-"…), given once and never reused: before 18 Oct 2026 it was the
    /// inbox's place in the list, so removing one shifted the rest (LiveSession.tagInboxes carries the old ones over)
    var tag: String? = nil
}

/// Something you added by hand or read off a photo: a policy, a loan, a holding, a property.
struct UserPolicy: Codable, Identifiable, Hashable {
    var id = UUID().uuidString
    var insurer = ""; var type = "Health"; var cover: Double = 0; var premium: Double = 0
    var policyNo = ""; var nextDue = ""; var owner = "me"; var note = ""; var source = "manual"
    // read off a policy schedule
    var plan: String? = nil; var holder: String? = nil; var insured: String? = nil; var nominee: String? = nil
    var frequency: String? = nil; var start: String? = nil; var end: String? = nil; var term: Int? = nil; var ppt: Int? = nil
    /// the words its paper used about what kind of cover it is (term, unit linked, two-wheeler…)
    var hint: String? = nil
    /// what comes back: the maturity figure its schedule prints, or the fund value from its latest unit statement
    var maturity: Double? = nil; var fundValue: Double? = nil; var fundAsOf: String? = nil
    /// a motor policy's registration, and its cover type and add-ons as its schedule words them
    var vehicle: String? = nil; var addOns: String? = nil
}
/// a committee (chit fund) you're in, as you'd tell someone about it
struct UserCommittee: Codable, Identifiable, Hashable {
    var id = UUID().uuidString
    var name = ""                 // the organiser, or what you call it
    var members = 12              // one month each
    var face: Double = 0          // the monthly instalment at face value
    var start = ""                // yyyy-MM, the first month
    var draw: String? = nil       // yyyy-MM, the month you take (or took) the pool
    var paidSoFar: Double? = nil  // what you've actually paid in, if less than face value each month
    var received: Double? = nil   // what you got when you took the pool
    var day = 10                  // the day of the month it's paid
    var done = false
    var owner = "me"
    // the committee book (optional, so profiles saved before them still load)
    var kind: String? = nil       // auction · draw · fixed · custom
    var commission: Double? = nil // the organiser's cut of the pool, %
    var paid: [String: Double]? = nil   // yyyy-MM → what was actually paid that month
    var payee: String? = nil      // the person or account it's paid to: their payments are its instalments
    var payeeName: String? = nil
    var excluded: Bool? = nil     // left out of the month-by-month cash flow
    /// whose it is, as you said: people of the household (two or more: joint), ["family"] for the household's on
    /// purpose; nil lets kosh work it out from whose accounts pay its instalments
    var whose: [String]? = nil
}
struct UserLoan: Codable, Identifiable, Hashable {
    var id = UUID().uuidString
    var name = ""; var bank = ""; var emi: Double = 0; var outstanding: Double = 0; var rate: Double = 0; var day = 5; var note = ""
}
struct UserHolding: Codable, Identifiable, Hashable {
    var id = UUID().uuidString
    var bank = ""; var type = "MF"; var cls = "mf"; var amt: Double = 0; var rate: Double = 0; var rem = ""; var owner = "me"; var source = "manual"
    var units: Double? = nil; var isin: String? = nil; var asOf: String? = nil
    /// what was put in, where the statement prints it (a fund's cost value); a share's isn't in its statement
    var cost: Double? = nil
    /// the folio a fund sits in (its last digits), to find its rows among the statements'
    var folio: String? = nil
    /// (ppf-owner-4nov) the holders its paper names (whose a PPF is), and whether its line said it is closed
    var named: [String]? = nil; var closed: Bool? = nil
    /// a deposit's maturity date (yyyy-MM-dd) and what it pays then
    var mat: String? = nil; var matAmt: Double? = nil; var start: String? = nil
    /// physical gold: its weight in grams and purity (999, 995, 916, 750 or 585), valued at today's rate
    var grams: Double? = nil; var purity: Int? = nil
    /// the day you last entered or changed it (yyyy-MM-dd), for how fresh its figure is
    var said: String? = nil
}
struct UserUnit: Codable, Hashable {
    var label = ""; var tenant = ""; var rent: Double = 0; var deposit: Double = 0; var start = ""; var months = 0; var pays = ""; var renew = ""; var registered = false
    /// let, vacant or self (the family uses it)
    var status: String? = nil
    /// the day of the month rent is due
    var day: Int? = nil
    /// months marked received by hand (cash rent, or a credit kosh couldn't match), "YYYY-MM"
    var paidMonths: [String]? = nil
    /// credits kosh took for this floor's rent that weren't (their ids)
    var notRent: [String]? = nil
}
struct UserProperty: Codable, Identifiable, Hashable {
    var id = UUID().uuidString
    var name = ""; var short = ""; var type = "Flat"; var use = "own"
    var state = ""; var city = ""; var portalName = ""; var portalUrl = ""; var findBy = ""
    var pid = ""; var tax: Double = 0; var payableTill = ""; var note = ""
    var units: [UserUnit] = []
    // read off the state's portal
    var owner: String? = nil; var address: String? = nil; var category: String? = nil; var plotArea: String? = nil; var covered: String? = nil
    var arrears: Double? = nil; var demand: Double? = nil; var interest: Double? = nil; var swm: Double? = nil; var dueTotal: Double? = nil
    var oldPid: String? = nil; var portalReadAt: String? = nil
    var taxDue: Double? = nil; var dev: Double? = nil; var charge: String? = nil
    var floors: Int? = nil
    /// the property's photo from the portal, saved in kosh's folder
    var photo: String? = nil
    /// what the portal said was due, each day it was read: the trend on the tax tab
    var taxHistory: [TaxSnap]? = nil
    /// the land's rate per sq yd (typed, or looked up), where it came from, and when
    var landRate: Double? = nil; var landRateNote: String? = nil; var landRateAt: String? = nil
    /// whose it is, as you said: people of the household (two or more: joint), ["family"] for the household's on
    /// purpose; nil lets kosh work it out (the owners on the portal's record, else whose account the rent reaches)
    var whose: [String]? = nil
}

@Observable
final class LiveSession {
    enum Phase: String { case idle, listing, reading, claude, done, failed }

    // set up
    var clientID: String
    var email: String
    var name: String
    var signedIn: Bool
    /// kosh's app id with Microsoft, for Outlook, Hotmail and Microsoft 365 sign-in (beta.json or Settings)
    var msClientID: String = ""
    var claudeReady: Bool
    var checkMode: String { didSet { ud.set(checkMode, forKey: "beta.checkMode2") } }
    /// who reads what the bank rules can't: "reader" (kosh-reader on this phone), "claude" (your key), or "off"
    var aiMode: String { didSet { ud.set(aiMode, forKey: "beta.aiMode") } }
    var readerName = ""
    var scanDays: Int { didSet { ud.set(scanDays, forKey: "beta.scanDays") } }
    var scanFrom: String
    var lastScan: String

    // the household and what you changed
    var people: [PersonInfo] = []
    var owners: [String: String] = [:]
    var hidden: Set<String> = []
    var overrides: [String: Override] = [:]

    // more Gmail accounts, and what you added by hand or from a photo or a statement
    var accounts: [MailAccount] = []
    var userPolicies: [UserPolicy] = []
    /// policies you said aren't yours (by policy number, or insurer and type): kosh leaves them out
    var hiddenPolicies: [String] = []
    /// what you said kosh read wrong, by mail: the kinds of reading to leave out of it ("deposit", "move", "policy"...)
    var rejected: [String: [String]] = [:]
    /// a monthly budget you set (0: the usual month stands in), and one per category. These, the plan and the
    /// briefings live in the protected profile (profile.json, MoneyBits), never in plain UserDefaults
    var budget: Double = 0 { didSet { profileChanged() } }
    var budgets: [String: Double] = [:] { didSet { profileChanged() } }
    /// what you set for the plan (goals, the salary split; Plan.swift), as JSON: the engine's prof.plan
    var planJSON: String = "" { didSet { profileChanged() } }
    /// what you set for the briefings and the projection (Brief.swift), as JSON: the engine's prof.brief
    var briefJSON: String = "" { didSet { profileChanged() } }
    /// Store's own (money owed to you, the shares settled, what you added by hand or from a photo, your UPI ID) and
    /// the day's brief from Claude: in the profile too, set through Store and KoshAgent
    @ObservationIgnored var own: MoneyBits = MoneyBits()
    /// the profile is being read in (or wiped): the values going in aren't changes to save
    @ObservationIgnored var loadingProfile = false
    /// the money bits came from the old UserDefaults keys: those go once the profile holding them is on the disk
    @ObservationIgnored var moneyFromDefaults = false
    /// a budget, the plan or the briefings changed: saved with the profile, and laid out again
    func profileChanged() {
        guard !loadingProfile else { return }
        save()
        rebuildSoon()
    }
    /// what you said about your bank accounts (an account's page): these two are one, this one is two, yes it's mine,
    /// it's closed, its name, a debit card's account. JSON, the engine's prof.acctFix (AccountPage.swift › AcctFix)
    /// In the protected profile (MoneyBits.acctFix) since 18 Oct 2026, carried over from "beta.acctFix" once.
    var acctFixJSON: String = "" { didSet { profileChanged() } }
    /// count gift cards and wallet top-ups as spending ("Paid out"), or only what's actually spent ("Spent")
    var countPrepaid: Bool = UserDefaults.standard.bool(forKey: "beta.countPrepaid") {
        didSet { UserDefaults.standard.set(countPrepaid, forKey: "beta.countPrepaid"); rebuildSoon() }
    }
    /// the account payments through an app (CRED, a gateway) leave, app by app ("cred" → "Bank|1234|key"): its
    /// receipts name the card paid, never the bank behind the UPI. In the protected profile (MoneyBits.railFrom) since
    /// 18 Oct 2026, carried over from "beta.railFrom" once.
    var railFrom: [String: String] = [:] { didSet { profileChanged() } }
    /// everyday spending only: trips and events left out of spending (cash flow and balances keep them)
    var everyday: Bool = UserDefaults.standard.bool(forKey: "beta.everyday") {
        didSet { UserDefaults.standard.set(everyday, forKey: "beta.everyday"); rebuildSoon() }
    }
    /// what you said about a policy kosh thinks has lapsed or ended, by its key: "active" or "ended"
    var policyMarks: [String: String] = [:]
    /// what you said about your deposits: you still have it, it's closed, its terms, two are one, not yours (Deposits.swift)
    var depFix = DepFix()
    func markPolicy(_ key: String, _ mark: String?) {
        guard !key.isEmpty else { return }
        if let mark { policyMarks[key] = mark } else { policyMarks.removeValue(forKey: key) }
        // (ended or still running shows at once; back to kosh's own reckoning waits for its build: ShownRules)
        if let mark { showNow("policy|" + key) { s in ShownRules.policyMark(&s, key: key, mark: mark) } }
        save(); rebuildSoon()
    }
    /// what you typed for a policy where its mail and papers say nothing, by its key: "cover", "premium", "frequency",
    /// "nominee", "policyNo" (engine.js reads it as prof.policyFill; what you typed stands)
    var policyFill: [String: [String: String]] = [:]
    func fillPolicy(_ key: String, _ facts: [String: String]) {
        guard !key.isEmpty else { return }
        var cur: [String: String] = policyFill[key] ?? [:]
        for (k, v) in facts {
            let t: String = v.trimmingCharacters(in: .whitespaces)
            if t.isEmpty { cur.removeValue(forKey: k) } else { cur[k] = t }
        }
        policyFill[key] = cur.isEmpty ? nil : cur
        save(); rebuildSoon()
    }
    /// a card's credit limit as you typed it, by the card's id (engine.js reads it as prof.cardLimit; it stands over its mail's)
    var cardLimit: [String: Double] = [:]
    func setCardLimit(_ id: String, _ v: Double?) {
        guard !id.isEmpty else { return }
        if let v, v >= 1000 { cardLimit[id] = v.rounded() } else { cardLimit.removeValue(forKey: id) }
        if let v, v >= 1000 { showNow("limit|" + id) { s in ShownRules.cardLimit(&s, id: id, limit: v) } }
        save(); rebuildSoon()
    }
    /// a payee's name as you gave it, by the payee's key (Txn.lk: its UPI ID, else its name): for a payee the bank names
    /// with a code or a masked UPI ID ("UPI ••h89k"). engine.js reads it as prof.payeeNames and shows it on every
    /// payment to that payee, before and after
    var payeeNames: [String: String] = [:]
    func setPayeeName(_ key: String, _ name: String) {
        guard !key.isEmpty else { return }
        let n: String = String(name.trimmingCharacters(in: .whitespacesAndNewlines).prefix(40))
        if n.isEmpty { payeeNames.removeValue(forKey: key) } else { payeeNames[key] = n }
        save(); rebuildSoon()
    }
    /// people whose health cover is held where kosh can't see it (an employer's group cover), by person id: the day you said so
    var healthElsewhere: [String: String] = [:]
    func markHealthElsewhere(_ id: String, _ on: Bool) {
        guard !id.isEmpty else { return }
        if on { healthElsewhere[id] = Day.iso(Date()) } else { healthElsewhere.removeValue(forKey: id) }
        showNow("health|" + id) { s in ShownRules.healthElsewhere(&s, id: id, on: on) }
        save(); rebuildSoon()
    }
    /// what you said about repeats, by id: "no" (not a repeat), "gone:yyyy-MM-dd" (cancelled that day)
    var repeatMarks: [String: String] = [:]
    func markRepeat(_ id: String, _ mark: String?) {
        if let mark { repeatMarks[id] = mark } else { repeatMarks.removeValue(forKey: id) }
        showNow("repeat|" + id) { s in ShownRules.repeatMark(&s, id: id, mark: mark) }
        save(); rebuildSoon()
    }
    /// money owed to you still open (splits and money lent, with a name) and the credits you said paid none of it
    /// back: the engine settles a share when that person's money comes in. Store keeps them and sets these
    @ObservationIgnored var owedOpen: [OwedItem] = []
    /// the shares split off a payment that you marked paid back: so money that comes back on the payment is shared out
    /// between every share of it, not only the open ones (engine shareNow)
    @ObservationIgnored var owedDone: [OwedItem] = []
    @ObservationIgnored var owedNot: [String] = []
    /// bills you marked paid before the bank's mail showed it, by the calendar item's id (AgendaItem.id): the day you
    /// marked it. The engine counts each paid (prof.paid); a mark is for that one bill, so old ones are let go.
    var paidMarks: [String: String] = [:]
    func markPaid(_ id: String, _ on: Bool) {
        if on { paidMarks[id] = Self.today } else { paidMarks.removeValue(forKey: id) }
        let old: String = Self.daysAgo(120)
        paidMarks = paidMarks.filter { $0.value >= old }
        showNow("paid|" + id) { s in ShownRules.paid(&s, id: id, on: on) }
        save(); rebuildSoon()
    }
    /// your trips and events
    var userTrips: [UserTrip] = []
    func upsertTrip(_ t: UserTrip) {
        if let i = userTrips.firstIndex(where: { $0.id == t.id }) { userTrips[i] = t } else { userTrips.append(t) }
        save(); rebuild()
    }
    /// the trip goes; what you'd put in it goes back to being ordinary spending
    func removeTrip(_ id: String) {
        userTrips.removeAll { $0.id == id }
        for (k, o) in overrides where o.tr == id { overrides[k]?.tr = nil }
        showNow("trip|" + id) { s in ShownRules.removeTrip(&s, id: id) }
        save(); rebuild()
    }
    /// where the ledger starts (yyyy-MM-dd; empty for everything read). The whole year is read either way:
    /// this only decides how much spending lands in the ledger to tag
    var ledgerFrom: String = UserDefaults.standard.string(forKey: "beta.ledgerFrom") ?? "" {
        didSet { UserDefaults.standard.set(ledgerFrom, forKey: "beta.ledgerFrom"); rebuild() }
    }
    /// the first of the month n months back ("2026-09-01" for one, in October)
    static func monthStart(back n: Int) -> String {
        let cal = Calendar(identifier: .gregorian)
        let start = cal.date(from: cal.dateComponents([.year, .month], from: Date())) ?? Date()
        return iso(cal.date(byAdding: .month, value: -n, to: start) ?? start)
    }

    /// every line of a card or bank statement opened on this phone; the engine squares them with the alerts
    struct StmtDoc: Codable, Hashable {
        struct Row: Codable, Hashable {
            var date: String; var desc: String; var amt: Double; var dir: String
            /// its running balance follows from the line before: right even when the statement as a whole doesn't add up
            var chk: Bool? = nil
        }
        var src: String; var from: String; var instr: String; var last4: String; var rows: [Row]
        var sent: String; var owner: String; var periodFrom: String; var periodTo: String
        /// a bank statement's closing balance, and the day it closed on
        var close: Double? = nil; var closeDate: String? = nil
        /// whether its lines added up to its own balances or summary: false keeps its lines out of the ledger
        var ok: Bool? = nil; var note: String? = nil
        /// a bank statement's opening balance (with its closing, a balance the account's payments are checked
        /// against), and the holders it names (whose the account is)
        var open: Double? = nil; var named: [String]? = nil; var namedF: [String]? = nil
        /// a card statement's credit balance (the card owes you this; nothing is due)
        var credit: Double? = nil
        /// a card statement's credit limit, and what was left of it on the statement's day
        var limit: Double? = nil; var avail: Double? = nil
        /// (accttype-4nov) what the statement says of the account itself: "closed", "dormant"
        var status: String? = nil
        /// (cardbill-4nov) the bill a card statement prints for itself: its total amount due, minimum, due day and the
        /// statement's own day. The card's bill comes from here first, the issuer's word, before any mail that retells it
        var billAmt: Double? = nil; var billMin: Double? = nil; var billDue: String? = nil; var billOn: String? = nil
    }
    var statements: [StmtDoc] = []
    /// what payslips and tax forms said (gross, net, TDS, interest), for the assistant and the money-in view
    var docFacts: [DocFact] = []
    /// deposits read off a bank's advice PDF; the engine folds them in with the bank's own mail about them
    var docDeposits: [DocDeposit] = []
    /// every trade off the contract notes, for gains and what each share cost
    var trades: [Trade] = []
    /// each fund's rows in every CAS read (older ones too), for its yearly return (noteFundRows)
    var fundSegs: [FundSeg] = []
    /// what the trades say each share cost (by ISIN), and the gains by financial year (recomputeGains)
    @ObservationIgnored var fifoCost: [String: Gains.Pos] = [:]
    var gainsFY: [String: Gains.FY] = [:]
    var userLoans: [UserLoan] = []
    var userHoldings: [UserHolding] = []
    var docHoldings: [UserHolding] = []     // read from CAS statements
    var properties: [UserProperty] = []
    var localDocs: [LocalDoc] = []          // PDFs added from Files
    var readingDocs = false

    // background scan of the older months, after the quick 30-day pass
    var backfilling = false
    var backfillDone = false
    /// the twelve months kosh fills, oldest first, and which of them are read
    var yearMonths: [String] = []
    var monthsRead: Set<String> = []
    var bgMonth = ""            // the month being read in the background now
    var bgFetched = 0
    var bgTotal = 0
    var scanStarted: Date?
    /// the reader stopped because the phone got warm; it picks up again when it cools
    var pausedForHeat = false

    // progress
    var phase: Phase = .idle
    var found = 0
    var total = 0
    var fetched = 0
    var claudeTotal = 0
    var claudeDone = 0
    var message: String?
    var records: [Reading] = [] { didSet { recordsVersion &+= 1 } }

    // the reading bar: how far each long read is, in emails
    /// a quiet read is still listing its mail (bgTotal grows as it's found)
    var bgListing = false
    /// the year: every month still to read, listed first, then read month by month
    var yearListing = false
    var yearDone = 0
    var yearTotal = 0
    /// statements and invoices being opened
    var docDone = 0
    var docTotal = 0
    var docLabel = "Opening statements and invoices"
    /// mail read again because the rules changed
    var reingesting = false
    /// locked statements being opened with the family's details, in the background (openLockedInBackground); what it
    /// last came to, for the screens that started it; and whether details were saved again while it ran
    var unlocking = false
    var unlockNote: String = ""
    @ObservationIgnored var unlockAgain = false
    /// a paper read in this pass taught kosh a detail (a date of birth, a PAN, a Customer ID): the locked ones get another try
    @ObservationIgnored var harvestedNew = false
    /// what the reading did lately, in a line each ("12:01:07 reingest: 4,713 to read"), newest last: kept for the
    /// diagnostics, so a read that stalls says where (no figures, no names)
    @ObservationIgnored var trace: [String] = []
    var againDone = 0
    var againTotal = 0
    /// an inbox added after the first read, being read from as far back as the rest
    var readingInbox = false
    /// a read that was cut short is carrying on from where it stopped (said for a few seconds)
    var pickingUp = false
    /// the reading just ended: how much it read, said for a moment
    struct CaughtUp: Equatable { let read: Int; let at: Date }
    var caughtUp: CaughtUp?

    /// the session, for the background tasks iOS starts when kosh isn't on screen (set when it's made)
    nonisolated(unsafe) static weak var current: LiveSession?

    /// where each long read had got to, by job; saved as reading.json with the records (checkpoint)
    @ObservationIgnored var plans: [String: ReadingPlan] = [:]
    var hasPlans: Bool { !plans.isEmpty }
    /// jobs that were cut short (on the last run, or just now): carrying one on says so
    @ObservationIgnored var interrupted: Set<String> = []
    @ObservationIgnored var pickUpMark = Date.distantPast
    @ObservationIgnored var lastCheckpoint = Date()
    @ObservationIgnored var unsaved = 0
    /// emails (and statements) read since the reading last began, and whether there was anything to show
    @ObservationIgnored var stretchRead = 0
    @ObservationIgnored var stretchSeen = false
    /// what the time-left estimate counts from (a read picked up part-way counts from where it picked up)
    @ObservationIgnored var rateBase = 0
    @ObservationIgnored var resuming = false
    @ObservationIgnored var inboxesReading: Set<String> = []
    /// jobs a read on the phone is going through right now (sweep): it strikes off what it reads itself, so what
    /// the background downloads bring back for them is read but left on the list for it
    @ObservationIgnored var sweeping: Set<String> = []
    /// emails the background downloads have read (record ids): a read on the phone counts them, never fetches them again
    @ObservationIgnored var readInBackground: Set<String> = []

    @ObservationIgnored var onBuild: ((Snapshot) -> Void)?
    /// a change you made, shown on the screens at once (Store.showNow, Store+Shown.swift): set by Store
    @ObservationIgnored var onShow: ((String, Bool, @escaping (inout Snapshot) -> Void) -> Void)?
    /// show what a change you just made does to the screens, before the build that confirms it lands (ShownRules says
    /// how, by the engine's rule for that one thing). Called before the change's own rebuild, so the build that follows
    /// is known to have it; `feel`: a light tap under your finger
    func showNow(_ key: String, feel: Bool = true, _ change: @escaping (inout Snapshot) -> Void) {
        guard let onShow else { return }
        if Thread.isMainThread { onShow(key, feel, change) } else { DispatchQueue.main.async { onShow(key, feel, change) } }
    }
    /// funds and shares bought since the newest statement (holdings of the mail's alone, made by the engine), so the
    /// day's prices are fetched for them too
    @ObservationIgnored var madeHoldings: [UserHolding] = []
    /// the records change only as mail is read: each change counts up, and their JSON is kept between builds
    @ObservationIgnored var recordsVersion = 0
    /// a number no other LiveSession in this run of the app has: with recordsVersion, the records' name for the engine
    /// (RecordsHandover)
    let recordsSerial: UInt64 = RecordsHandover.serial()
    /// the locked statements, for the records as they were at a version (lockedDocs)
    @ObservationIgnored var lockedMemo: (version: Int, docs: [Reading])?
    /// what each locked sender needs, and the key of everything it was worked out from (Papers.swift lockedNeeds)
    @ObservationIgnored var lockedNeedsMemo: (key: String, needs: [LockedNeed])?
    /// the statements' list for each set of kinds (docItems)
    @ObservationIgnored var docItemsMemo: [String: [DocItem]] = [:]
    @ObservationIgnored var recordsCache: (version: Int, json: String)?
    /// each travel mail's booking (where, when), read by the trip pass (LiveSession+Extras tripPass)
    @ObservationIgnored var tripLegs: [String: TripLeg] = [:]
    @ObservationIgnored var savedRecordsVersion = -1
    @ObservationIgnored let recordsLock = NSLock()
    /// builds started, so one that finishes after a newer one began is dropped; and the one off the main thread
    @ObservationIgnored var buildGen = 0
    @ObservationIgnored var buildRunning = false
    @ObservationIgnored var buildAgain = false
    /// while a payment's sheet is open the build waits: its changes show at once (Store.edits) and nothing else on
    /// screen redraws under your taps; one build runs when it closes
    @ObservationIgnored var holdBuilds = false {
        didSet { if !holdBuilds && heldBuild { heldBuild = false; rebuildSoon() } }
    }
    @ObservationIgnored var heldBuild = false
    /// how long the last build took (seconds): while mail is read, builds come no more often than twice that apart
    @ObservationIgnored var lastBuildSecs: Double = 0
    /// a build for the reading's progress is due: `every` seconds since the last, and never sooner than twice the
    /// last build's time (a year of mail makes builds slow; the reading must not spend its time laying out screens)
    func readingBuildDue(every: Double) -> Bool {
        let gap: Double = max(every, 2 * lastBuildSecs)
        return Date().timeIntervalSince(lastRebuild) > gap
    }
    /// a build is on its way (running, asked for again, deferred, or waiting for a sheet to close)
    var buildPending: Bool { buildRunning || buildAgain || heldBuild || deferredBuild != nil }
    /// when the last build landed, and the one build waiting for the pace while mail is read (rebuildSoon)
    @ObservationIgnored var lastBuildEnd = Date.distantPast
    @ObservationIgnored var buildsDone = 0
    @ObservationIgnored var deferredBuild: DispatchWorkItem?
    /// mail or papers are being read: builds are paced and run below the screens' priority
    var readingActive: Bool { running || reingesting || findingDocs || backfilling || discovering || findingWallets || findingWider }
    static let buildQueue = DispatchQueue(label: "kosh.build", qos: .userInitiated)
    /// the inboxes' access tokens (LiveSession+Mail.swift › TokenCache: the sweep and the downloads ask at once)
    @ObservationIgnored let access = TokenCache()
    @ObservationIgnored var verifier = ""
    @ObservationIgnored var oauthState = ""
    @ObservationIgnored var addingAccount = false
    @ObservationIgnored let ud = UserDefaults.standard

    /// where each account's refresh token lives in the Keychain
    func refreshKey(_ acct: String) -> String { acct == email || acct.isEmpty ? "google.refresh" : "google.refresh." + acct }
    /// every account kosh reads: the one you signed in with, plus any you added
    var allAccounts: [String] { ([email] + accounts.map(\.id)).filter { !$0.isEmpty } }

    static let palette = ["#007AFF", "#FF2D55", "#34C759", "#FF9500", "#30B0C7", "#5AC8FA", "#FFCC00", "#A2845E"]

    init() {
        let bundled: String = {
            guard let u = Bundle.main.url(forResource: "beta", withExtension: "json"),
                  let d = try? Data(contentsOf: u),
                  let j = try? JSONSerialization.jsonObject(with: d) as? [String: Any] else { return "" }
            return (j["googleClientID"] as? String) ?? ""
        }()
        let saved = (UserDefaults.standard.string(forKey: "beta.clientID") ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        clientID = saved.isEmpty ? bundled : saved
        let msBundled: String = {
            guard let u = Bundle.main.url(forResource: "beta", withExtension: "json"),
                  let d = try? Data(contentsOf: u),
                  let j = try? JSONSerialization.jsonObject(with: d) as? [String: Any] else { return "" }
            return (j["microsoftClientID"] as? String) ?? ""
        }()
        let msSaved = (UserDefaults.standard.string(forKey: "beta.msClientID") ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        msClientID = msSaved.isEmpty ? msBundled : msSaved
        email = UserDefaults.standard.string(forKey: "beta.email") ?? ""
        name = UserDefaults.standard.string(forKey: "beta.name") ?? ""
        // signed in: the first inbox's own key is on this phone (Google's, Microsoft's, or a mail server's password)
        signedIn = Keychain.get(Self.credentialKey(UserDefaults.standard.string(forKey: "beta.provider") ?? "gmail", UserDefaults.standard.string(forKey: "beta.email") ?? "", primary: true)) != nil
        claudeReady = !(Keychain.get("claude.key") ?? "").isEmpty
        // the reader reads what the bank rules can't; checking every email the rules read is opt-in
        // (it kept the phone busy, and warm, for a long time after setup)
        checkMode = UserDefaults.standard.string(forKey: "beta.checkMode2") ?? "off"
        // your pick if you made one; else Apple Intelligence where the phone has it, kosh-reader where it's on the phone,
        // else the rules alone (LiveSession+AIPass › defaultAIMode; not saved, so it's worked out again at each launch)
        aiMode = UserDefaults.standard.string(forKey: "beta.aiMode") ?? Self.defaultAIMode
        let d = UserDefaults.standard.integer(forKey: "beta.scanDays")
        scanDays = d > 0 ? d : 30
        scanFrom = UserDefaults.standard.string(forKey: "beta.scanFrom") ?? ""
        lastScan = UserDefaults.standard.string(forKey: "beta.lastScan") ?? ""
        // (the screens as last laid out, read and decoded off the main thread while the records and settings load:
        // savedSnapshot takes them)
        let keptURL: URL = snapshotURL
        keptSoon = Prefetch { Self.readKept(keptURL) }
        Perf.shared.measure("startup · load") { load() }
        if loadedFromDisk { Perf.shared.measure("startup · documents check") { rereadDocumentsIfReaderChanged() } }
        Self.current = self
        NotificationCenter.default.addObserver(forName: UIApplication.protectedDataDidBecomeAvailableNotification, object: nil, queue: .main) { [weak self] _ in
            MainActor.assumeIsolated { self?.reloadIfNeeded() }
        }
        // the Lock Screen says what the bar says; the bar says when the reading ends
        Task { @MainActor [weak self] in self?.wireKeepGoing() }
    }

    @MainActor
    func wireKeepGoing() {
        KeepGoing.shared.status = { [weak self] in self.flatMap { ReadingNow.of($0) } }
        KeepGoing.shared.onStart = { [weak self] in
            self?.stretchRead = 0
            self?.stretchSeen = false
            self?.caughtUp = nil
        }
        KeepGoing.shared.onEnd = { [weak self] stopped in self?.stretchEnded(stopped: stopped) }
    }

    /// "All caught up · 1,240 read", for a moment, when a stretch of reading ends by itself
    @MainActor
    func stretchEnded(stopped: Bool) {
        guard !stopped, stretchSeen, phase != .failed else { return }
        let c = CaughtUp(read: stretchRead, at: Date())
        caughtUp = c
        Task { [weak self] in
            try? await Task.sleep(for: .seconds(2.5))
            if self?.caughtUp == c { self?.caughtUp = nil }
        }
    }

    /// When the statement readers improve, every statement is read again (with the passwords you
    /// already gave), so a wrong reading from an older build doesn't linger in net worth.
    /// And by itself: when the papers' reader changes (ReadingPrint.doc, worked out from the app's own scripts), every
    /// paper already opened is read again from the text kept of it (MailVault), with nothing downloaded or unlocked.
    /// (A bump here still works and does the same; the fingerprint makes it unnecessary.)
    static let docReaderVersion = 13
    func rereadDocumentsIfReaderChanged() {
        let printChanged: Bool = ud.string(forKey: "beta.docPrint") != ReadingPrint.doc
        guard ud.integer(forKey: "beta.docReader") < Self.docReaderVersion || printChanged else { return }
        for i in records.indices {
            guard var d = records[i].doc else { continue }
            // what each attachment is, by today's rules: a bank's deposit renewal advice is not a policy
            let msg: [String: Any] = ["from": records[i].from ?? d.from, "subject": records[i].subject ?? "", "attachments": [["filename": d.file]]]
            if let out = try? Engine.shared.call("docWantedJSON", [JSONText.object(msg)]), let want = try? JSONText.decode(DocWant.self, out) {
                if want.kind.isEmpty {
                    // not a statement after all: what it said goes with it
                    userPolicies.removeAll { $0.source == "doc:" + d.msg }
                    records[i].doc = nil; continue
                }
                if want.kind != d.kind { d.kind = want.kind; d.state = "" }
            }
            if d.state == "read" || d.state == "empty" { d.state = ""; d.note = nil }
            records[i].doc = d
        }
        for i in localDocs.indices where localDocs[i].state == "read" { localDocs[i].state = ""; localDocs[i].note = nil }
        // what each statement said stays until its new reading replaces it (applyDoc swaps a paper's
        // holdings and policies for its new ones), so Portfolio never sits empty while they're read again;
        // EPF and anything else read off a website isn't a statement and isn't touched
        ud.set(Self.docReaderVersion, forKey: "beta.docReader")
        ud.set(ReadingPrint.doc, forKey: "beta.docPrint")
        save()
    }

    // MARK: dates

    // kosh's days are India's, everywhere (Day in Style.swift): the engine files a mail by India's day, so "today"
    // handed to it must be India's too, or a phone abroad sees a day's payments on the wrong side of midnight
    static func iso(_ d: Date) -> String { Day.iso(d) }
    static var today: String { iso(Date()) }
    /// whole days from a yyyy-MM-dd to today (a lot, when there's no date)
    static func daysSince(_ isoDay: String) -> Int {
        guard let d = Day.parser.date(from: String(isoDay.prefix(10))) else { return 9999 }
        return Day.cal.dateComponents([.day], from: d, to: Date()).day ?? 9999
    }
    static func daysAgo(_ n: Int) -> String { iso(Day.cal.date(byAdding: .day, value: -n, to: Date()) ?? Date()) }

























    // MARK: building the screens

    var profileJSON: String {
        var p: [String: Any] = ["today": Self.today, "name": name.isEmpty ? "You" : name, "emails": records.count]
        if !scanFrom.isEmpty { p["scanFrom"] = scanFrom }
        // while the year is still being read back, how far it has got: the engine holds back the notes that need
        // months of history (a usual month, a salary late, a repeat not seen yet) until a few months are read
        if !yearIn && scanFrom.count == 10 { p["readFrom"] = scanFrom }
        let ppl = people.isEmpty ? [PersonInfo(id: "me", name: firstName, full: name.isEmpty ? "You" : name, rel: "You", color: Self.palette[0])] : people
        p["people"] = ppl.map { ["id": $0.id, "name": $0.name, "full": $0.full, "rel": $0.rel, "color": $0.color] }
        p["owners"] = owners
        p["hiddenPolicies"] = hiddenPolicies
        if !rejected.isEmpty { p["rejected"] = rejected }
        if budget > 0 { p["budget"] = budget }
        if !budgets.isEmpty { p["budgets"] = budgets.filter { $0.value > 0 } }
        p["countPrepaid"] = countPrepaid
        // the plan's and the briefings' settings, each a JSON object the views keep (Plan.swift, Brief.swift)
        for (key, raw) in [("plan", planJSON), ("brief", briefJSON), ("acctFix", acctFixJSON)] where !raw.isEmpty {
            if let d = raw.data(using: .utf8), let o = try? JSONSerialization.jsonObject(with: d), o is [String: Any] { p[key] = o }
        }
        // for the briefings (brief.js): what each fund house's Regular and Direct plans charge (AMFI, Brief.swift), and
        // the time of this build, India's, for tomorrow's briefing (its yesterday is today, read only so far)
        var brief: [String: Any] = (p["brief"] as? [String: Any]) ?? [:]
        if let ter = FundFees.shared.forEngine { brief["ter"] = ter }
        let clock: DateComponents = Day.cal.dateComponents([.hour, .minute], from: Date())
        brief["now"] = String(format: "%02d:%02d", clock.hour ?? 0, clock.minute ?? 0)
        p["brief"] = brief
        p["everyday"] = everyday
        // the bookings the trip pass read, and the drafts you said weren't trips (trips.js)
        if !tripLegs.isEmpty, let d = try? JSONEncoder().encode(tripLegs), let o = try? JSONSerialization.jsonObject(with: d) { p["tripLegs"] = o }
        let off: [String] = ud.stringArray(forKey: Self.tripDraftsOffKey) ?? []
        if !off.isEmpty { p["tripDraftsOff"] = off }
        // your word on homes and trips: which home a connection is, homes you named, trips renamed, joined or split
        learntPlaces(&p)
        if !railFrom.isEmpty { p["railFrom"] = railFrom }
        if !repeatMarks.isEmpty { p["repeats"] = repeatMarks }
        if !policyMarks.isEmpty { p["policyMarks"] = policyMarks }
        if !policyFill.isEmpty { p["policyFill"] = policyFill }
        if !healthElsewhere.isEmpty { p["healthElsewhere"] = healthElsewhere }
        if !cardLimit.isEmpty { p["cardLimit"] = cardLimit }
        if !payeeNames.isEmpty { p["payeeNames"] = payeeNames }
        if !depFix.isEmpty, let d = try? JSONEncoder().encode(depFix), let o = try? JSONSerialization.jsonObject(with: d) { p["depFix"] = o }
        if !paidMarks.isEmpty { p["paid"] = paidMarks }
        // the claims you made, your company's rules for them, what you ticked before, cases you set aside
        ClaimBook.shared.add(to: &p)
        p["trips"] = userTrips.map { t -> [String: Any] in
            ["id": t.id, "name": t.name, "kind": t.kind, "from": t.from, "to": t.to, "budget": t.budget, "sym": t.sym, "color": t.color, "auto": t.auto, "who": t.who, "note": t.note]
        }
        if !ledgerFrom.isEmpty { p["ledgerFrom"] = ledgerFrom }
        // what's owed to you, for the engine to settle when the money comes in (engine settleShares)
        // (each with the payment it was split off, so money back on that payment is shared out as it was split)
        if !owedOpen.isEmpty {
            p["owed"] = owedOpen.map { o -> [String: Any] in
                var d: [String: Any] = ["id": o.id, "name": o.name, "amount": o.amount, "date": o.date, "title": o.title, "kind": o.kind]
                if let t = o.tx, !t.isEmpty { d["tx"] = t }
                return d
            }
        }
        if !owedDone.isEmpty {
            p["owedDone"] = owedDone.compactMap { o -> [String: Any]? in
                guard let t = o.tx, !t.isEmpty else { return nil }
                return ["id": o.id, "name": o.name, "amount": o.amount, "date": o.date, "title": o.title, "kind": o.kind, "tx": t]
            }
        }
        if !owedNot.isEmpty { p["owedNot"] = owedNot }
        if !statements.isEmpty, let d = try? JSONEncoder().encode(statements), let o = try? JSONSerialization.jsonObject(with: d) { p["statements"] = o }
        if !typedBalances.isEmpty { p["balances"] = typedBalances.mapValues { ["v": $0.v, "at": $0.at] as [String: Any] } }
        // deposits off their advice PDFs, folded in with what the bank's mail said about them
        if !docDeposits.isEmpty {
            p["deposits"] = docDeposits.map { ["inst": $0.inst, "depNo": $0.depNo, "amt": $0.amt, "rate": $0.rate, "mat": $0.mat, "matAmt": $0.matAmt, "start": $0.start, "src": $0.src, "owner": $0.owner] as [String: Any] }
        }
        // the dated money behind yearly returns: the contract notes' trades, and each fund's rows from every CAS read
        if !trades.isEmpty, let d = try? JSONEncoder().encode(trades), let o = try? JSONSerialization.jsonObject(with: d) { p["trades"] = o }
        if !fundSegs.isEmpty, let d = try? JSONEncoder().encode(fundSegs), let o = try? JSONSerialization.jsonObject(with: d) { p["fundSegs"] = o }
        p["hidden"] = Dictionary(uniqueKeysWithValues: hidden.map { ($0, true) })
        var ov: [String: [String: Any]] = [:]
        for (k, o) in overrides {
            var d: [String: Any] = [:]
            if let c = o.c { d["c"] = c }
            if let s = o.s { d["s"] = s }
            if let f = o.f { d["f"] = f }
            if let n = o.n { d["n"] = n }
            if let m = o.mine { d["mine"] = m }
            if let b = o.sb, o.mine != nil { d["sb"] = b }
            if let e = o.ex, !e.isEmpty { d["ex"] = e }
            if let m = o.cm, !m.isEmpty { d["cm"] = m }
            if let r = o.rf, r > 0 { d["rf"] = r }
            if let b = o.rfBy, !b.isEmpty { d["rfBy"] = b }
            if let n = o.rfNote, !n.isEmpty { d["rfNote"] = n }
            if o.rfDone == true { d["rfDone"] = true }
            if let r = o.rfOf, !r.isEmpty { d["rfOf"] = r }
            if let t = o.tr, !t.isEmpty { d["tr"] = t }
            if let x = o.dup, !x.isEmpty { d["dup"] = x }
            if let x = o.dupNot, !x.isEmpty { d["dupNot"] = x }
            if let x = o.from, !x.isEmpty { d["from"] = x }
            if let x = o.rent, !x.isEmpty { d["rent"] = x }
            if let x = o.tags, !x.isEmpty { d["tags"] = x }
            if let x = o.tagsOff, !x.isEmpty { d["tagsOff"] = x }
            // count it anyway, who filed it, and what was meant for this payment only
            if o.cnt == true { d["cnt"] = true }
            if let b = o.by, !b.isEmpty { d["by"] = b }
            if let x = o.only, !x.isEmpty { d["only"] = x }
            if let ps = o.parts, !ps.isEmpty {
                d["parts"] = ps.map { p -> [String: Any] in
                    var x: [String: Any] = ["a": p.a]
                    if let c = p.c { x["c"] = c }
                    if let s = p.s { x["s"] = s }
                    if let e = p.ex { x["ex"] = e }
                    return x
                }
            }
            ov[k] = d
        }
        p["overrides"] = ov
        var aliases = [email].map { $0.split(separator: "@").first.map(String.init) ?? "" }
        aliases += accounts.map { $0.id.split(separator: "@").first.map(String.init) ?? "" }
        p["aliases"] = aliases.filter { !$0.isEmpty }.map { $0.replacingOccurrences(of: ".", with: " ") }
        p["inboxes"] = Dictionary(uniqueKeysWithValues: accounts.compactMap { a in a.person.map { (a.id, $0) } })
        p["policies"] = userPolicies.map { pol -> [String: Any] in
            var d: [String: Any] = ["id": pol.id, "insurer": pol.insurer, "type": pol.type, "cover": pol.cover, "premium": pol.premium, "policyNo": pol.policyNo, "nextDue": pol.nextDue, "owner": pol.owner, "note": pol.note, "source": pol.source]
            for (k, v) in [("plan", pol.plan), ("holder", pol.holder), ("insured", pol.insured), ("nominee", pol.nominee), ("frequency", pol.frequency), ("start", pol.start), ("end", pol.end), ("hint", pol.hint), ("vehicle", pol.vehicle), ("addOns", pol.addOns)] { if let v, !v.isEmpty { d[k] = v } }
            if let t = pol.term, t > 0 { d["term"] = t }
            if let t = pol.ppt, t > 0 { d["ppt"] = t }
            if let v = pol.maturity, v > 0 { d["maturity"] = v }
            if let v = pol.fundValue, v > 0 { d["fundValue"] = v; d["fundAsOf"] = pol.fundAsOf ?? "" }
            return d
        }
        p["committees"] = userCommittees.map { c -> [String: Any] in
            var d: [String: Any] = ["id": c.id, "name": c.name, "members": c.members, "face": c.face, "start": c.start, "day": c.day, "done": c.done, "owner": c.owner]
            if let v = c.draw, !v.isEmpty { d["draw"] = v }
            if let v = c.paidSoFar, v > 0 { d["paidSoFar"] = v }
            if let v = c.received, v > 0 { d["received"] = v }
            if let v = c.kind, !v.isEmpty { d["kind"] = v }
            if let v = c.commission, v > 0 { d["commission"] = v }
            if let v = c.paid, !v.isEmpty { d["paid"] = v }
            if let v = c.payee, !v.isEmpty { d["payee"] = v }
            if let v = c.payeeName, !v.isEmpty { d["payeeName"] = v }
            if c.excluded == true { d["excluded"] = true }
            return d
        }
        p["readings"] = readings.map { ["src": $0.src, "d": $0.d, "o": $0.o, "v": $0.v] as [String: Any] }
        // the jobs under your UAN, as the passbook and the EPFO's own pages have shown them: the Retirement screen's
        // own reckoning is a build's (engine/21l-build-retirement.js), so every phone gets it without reading again
        if !epfJobs.isEmpty {
            p["epfJobs"] = epfJobs.map { j -> [String: Any] in
                var d: [String: Any] = ["id": j.id, "establishment": j.establishment, "balance": j.balance, "employee": j.employee,
                                        "employer": j.employer, "pension": j.pension, "asOf": j.asOf, "lastCredit": j.lastCredit,
                                        "lastMonth": j.lastMonth, "firstMonth": j.firstMonth, "monthly": j.monthly,
                                        "interest": j.interest, "interestFY": j.interestFY, "rate": j.rate]
                if j.known == true { d["known"] = true }
                if j.book == true { d["book"] = true }
                if let v = j.joined, !v.isEmpty { d["joined"] = v }
                if let v = j.left, !v.isEmpty { d["left"] = v }
                if let v = j.trfIn, v > 0 { d["trfIn"] = v }
                if let v = j.months, v > 0 { d["months"] = v }
                if let v = j.wageMonths, !v.isEmpty { d["wageMonths"] = v }
                if let rs = j.mrows, !rs.isEmpty { d["mrows"] = rs.map { (r: EPFJob.MonthRow) -> [String: Any] in ["m": r.m, "ee": r.ee, "er": r.er] } }
                if let ys = j.years, !ys.isEmpty {
                    d["years"] = ys.map { ["fy": $0.fy, "ee": $0.ee, "er": $0.er, "pen": $0.pen, "trf": $0.trf, "interest": $0.interest, "months": $0.months] as [String: Any] }
                }
                return d
            }
        }
        p["loans"] = userLoans.map { ["id": $0.id, "name": $0.name, "bank": $0.bank, "emi": $0.emi, "outstanding": $0.outstanding, "rate": $0.rate, "day": $0.day, "note": $0.note] as [String: Any] }
        // the ones you added carry their id through (the row on screen opens that one, whatever it has grown to)
        let typedIDs: Set<String> = Set(userHoldings.map(\.id))
        p["holdings"] = (userHoldings + docHoldings).map { h -> [String: Any] in
            var d: [String: Any] = ["bank": h.bank, "type": h.type, "cls": h.cls, "amt": h.amt, "rate": h.rate, "rem": h.rem, "owner": h.owner]
            if typedIDs.contains(h.id) { d["uid"] = h.id }
            if let m = h.mat, !m.isEmpty { d["mat"] = String(m.prefix(7)); if m.count >= 10 { d["matDay"] = String(m.prefix(10)) } }
            if let a = h.matAmt, a > 0, h.rem.isEmpty { d["rem"] = Fmt.rupees(a) + " at maturity" }
            if let c = h.cost, c > 0 { d["cost"] = c }
            // a share's statement prints no cost: the contract notes say it, when they account for every share held
            else if h.cls == "stk", let i = h.isin, let f = fifoCost[i], let u = h.units, abs(u - f.qty) <= 0.5, f.cost > 0 { d["cost"] = f.cost }
            if let st = h.start, !st.isEmpty { d["start"] = st }
            if let a = h.matAmt, a > 0 { d["matAmt"] = a }
            if !h.source.isEmpty && h.source != "manual" { d["source"] = h.source }
            if let i = h.isin, !i.isEmpty { d["isin"] = i }
            if let u = h.units, u > 0 { d["units"] = u }
            if let f = h.folio, !f.isEmpty { d["folio"] = f }
            if let a = Self.asOfOf(h) { d["asOf"] = a }
            if let s = h.said, !s.isEmpty { d["said"] = s }
            // how many units, so a fund or share can be valued at the day's price (Prices.swift)
            if let u = h.units, u > 0 { d["units"] = u }
            return d
        }
        if !Prices.shared.isEmpty { p["prices"] = Prices.shared.forEngine }
        // the day's rupee rates, for a deposit in dollars (FXRates.swift)
        if !FXRates.shared.isEmpty { p["fx"] = FXRates.shared.forEngine }
        p["properties"] = properties.map { prop -> [String: Any] in
            var d: [String: Any] = ["id": prop.id, "name": prop.name, "short": prop.short.isEmpty ? prop.name : prop.short, "type": prop.type, "use": prop.use]
            d["state"] = prop.state; d["city"] = prop.city; d["portalName"] = prop.portalName; d["portalUrl"] = prop.portalUrl; d["findBy"] = prop.findBy
            d["pid"] = prop.pid; d["tax"] = prop.tax; d["payableTill"] = prop.payableTill; d["note"] = prop.note
            d["arrears"] = prop.arrears ?? 0; d["demand"] = prop.demand ?? 0; d["interest"] = prop.interest ?? 0; d["swm"] = prop.swm ?? 0; d["dueTotal"] = prop.dueTotal ?? 0
            d["taxDue"] = prop.taxDue ?? 0; d["dev"] = prop.dev ?? 0; d["charge"] = prop.charge ?? ""
            // (the portal's old PID too: a receipt may still print it, and it places the payment on this property)
            if let o = prop.oldPid, !o.isEmpty { d["oldPid"] = o }
            if let r = prop.landRate, r > 0 { d["landRate"] = r; d["landRateNote"] = prop.landRateNote ?? ""; d["landRateAt"] = prop.landRateAt ?? "" }
            d["owner"] = prop.owner ?? ""; d["address"] = prop.address ?? ""; d["category"] = prop.category ?? ""
            d["plotArea"] = prop.plotArea ?? ""; d["covered"] = prop.covered ?? ""; d["portalReadAt"] = prop.portalReadAt ?? ""
            d["units"] = prop.units.map { u -> [String: Any] in
                ["label": u.label, "tenant": u.tenant, "rent": u.rent, "deposit": u.deposit, "start": u.start, "months": u.months, "pays": u.pays, "renew": u.renew, "registered": u.registered,
                 "status": u.status ?? "", "day": u.day ?? 0, "paidMonths": u.paidMonths ?? [], "notRent": u.notRent ?? []]
            }
            d["floors"] = prop.floors ?? 0
            d["photo"] = prop.photo ?? ""
            d["taxHistory"] = (prop.taxHistory ?? []).map { ["d": $0.d, "total": $0.total, "arrears": $0.arrears, "interest": $0.interest, "demand": $0.demand] as [String: Any] }
            return d
        }
        return JSONText.object(p)
    }

    var firstName: String { name.split(separator: " ").first.map(String.init) ?? (name.isEmpty ? "You" : name) }

    /// the screens laid out from the records, now (a change you make shows at once)
    func build() -> Snapshot? {
        buildGen &+= 1
        return finish(Result { try make(Engine.shared, records, recordsVersion, profileJSON) })
    }
    /// a forced build asked for while one runs: the one after it is forced too
    @ObservationIgnored var buildAgainForce = false
    /// a change you made (a setting, a policy, a person): laid out off the main thread, so a tap never waits on the
    /// engine; the screens follow a moment later (a payment's own change shows at once through Store.edits)
    func rebuild() {
        rebuildSoon(force: true)
    }

    /// the same, off the main thread, for the reading: what it has read reaches the screens a moment later, the
    /// screens stay smooth meanwhile, and calls that come while a build runs fold into one more after it
    func rebuildSoon(force: Bool = false) {
        guard Thread.isMainThread else { DispatchQueue.main.async { [weak self] in self?.rebuildSoon(force: force) }; return }
        // a change that the open sheet can only show once built (a refund, the month it counts in) goes through
        if holdBuilds && !force { heldBuild = true; return }
        if buildRunning { buildAgain = true; if force { buildAgainForce = true }; return }
        /* while mail is being read, builds are paced: one every few seconds at most (and never closer than three times
           the last one's length), the rest folded into one deferred build. Back to back, each build kept a core busy
           and redrew every screen as it landed, which is what made switching tabs lag while kosh read */
        if !force && readingActive {
            let gap: Double = min(8, max(4, 3 * lastBuildSecs))
            let since: Double = Date().timeIntervalSince(lastBuildEnd)
            // (and never while you're touching the screen: the build waits for a pause, Interaction.swift)
            if since < gap || Interaction.shared.busy {
                if deferredBuild == nil {
                    let w = DispatchWorkItem { [weak self] in self?.deferredBuild = nil; self?.lastBuildEnd = .distantPast; self?.rebuildSoon() }
                    deferredBuild = w
                    DispatchQueue.main.asyncAfter(deadline: .now() + max(0.6, gap - since), execute: w)
                }
                return
            }
        }
        deferredBuild?.cancel(); deferredBuild = nil
        buildRunning = true
        buildGen &+= 1
        let gen: Int = buildGen, recs: [Reading] = records, version: Int = recordsVersion
        let profile: String = Perf.shared.measure("profile for a build") { profileJSON }
        // (while reading, below the screens' priority: a tap never waits on a build)
        Self.buildQueue.async(qos: readingActive ? .utility : .userInitiated, flags: .enforceQoS) { [weak self] in
            guard let self else { return }
            let started = Date()
            let out: Result<(Snapshot, String), Error> = Result { try self.makeWithJSON(Engine.builder, recs, version, profile) }
            let took: Double = Date().timeIntervalSince(started)
            // (smooth-5nov-c) the build lands between touches, never under a moving finger (4 s at most)
            Interaction.whenStill(upTo: 4) {
                self.buildRunning = false
                self.lastBuildSecs = took
                self.lastBuildEnd = Date()
                // a newer build (a change you made meanwhile, Erase) has already laid the screens out
                if gen == self.buildGen, let s = Perf.shared.measure("finish build", { self.finish(out.map { $0.0 }) }) {
                    if case .success(let pair) = out { self.recordsLock.lock(); self.lastBuild = pair.1; self.recordsLock.unlock() }
                    Perf.shared.measure("note build") { self.noteMade(s) }
                    let shown: CFAbsoluteTime = CFAbsoluteTimeGetCurrent()
                    // (where the main thread goes while the screens take the build: the redraw is the slowest moment)
                    Perf.shared.probe("a build lands", seconds: 1.5)
                    self.onBuild?(s)
                    // (the screens redraw with the new layout at the end of this turn of the main thread: timed to the
                    // next turn, so a slow redraw shows in the diagnostics)
                    DispatchQueue.main.async { Perf.shared.record("screens redrawn after a build", ms: (CFAbsoluteTimeGetCurrent() - shown) * 1000) }
                    self.keepDiagnosticsSoon()
                }
                Perf.shared.record("build, off screen", ms: took * 1000)
                self.buildsDone += 1
                if self.buildAgain { let f = self.buildAgainForce; self.buildAgain = false; self.buildAgainForce = false; self.rebuildSoon(force: f) }
            }
        }
    }

    /// what a build came to: the counts kept for a check, or what went wrong said where it shows
    func finish(_ out: Result<Snapshot, Error>) -> Snapshot? {
        switch out {
        case .success(let snap):
            snapCounts = (snap.tx.count, snap.accounts.count, snap.cards.count)
            lastFacts = snap.facts ?? []
            keepSnapshot()
            if loadProblem?.hasPrefix("Couldn’t lay out") == true { loadProblem = nil }
            return snap
        case .failure(let error):
            message = "Couldn’t lay out the screens: \(error.localizedDescription)"
            loadProblem = "Couldn’t lay out the screens: " + Self.describe(error)
            return nil
        }
    }

    /// one build, on whichever thread: the records as the engine takes them (without each email's text), the
    /// profile, the engine's layout, read back
    func make(_ engine: Engine, _ recs: [Reading], _ version: Int, _ profile: String) throws -> Snapshot {
        let pair = try makeWithJSON(engine, recs, version, profile)
        recordsLock.lock(); lastBuild = pair.1; recordsLock.unlock()
        return pair.0
    }
    /// the build and the engine's JSON it came from (kept, once the build is the one shown, for the next launch)
    func makeWithJSON(_ engine: Engine, _ recs: [Reading], _ version: Int, _ profile: String) throws -> (Snapshot, String) {
        // (the records named, so the engine keeps no copy of their text between builds: RecordsHandover)
        let out: String = try engine.call("buildJSON", [recordsJSON(recs, version), profile, RecordsHandover.name(serial: recordsSerial, version: version)])
        let snap: Snapshot = try JSONText.decode(Snapshot.self, out)
        recordsLock.lock(); lastNameGroups = snap.nameGroups ?? []; recordsLock.unlock()
        return (snap, out)
    }

    /// The screens as last laid out (the engine's JSON), kept so the next launch opens on them at once and lays them
    /// out afresh behind them, instead of making you wait on the engine before the first frame. Written a few seconds
    /// after a build, on the save queue; with the records, it goes with Erase, and stays out of backups.
    var snapshotURL: URL { Self.folder.appendingPathComponent("snapshot.json") }
    @ObservationIgnored var lastBuild: String?
    /// the last build's nameGroups: the people the mail greets who are no one in the household yet (pwWho)
    @ObservationIgnored var lastNameGroups: [NameGroup] = []
    @ObservationIgnored var snapshotSaveSoon = false
    func keepSnapshot() {
        guard !snapshotSaveSoon, loadedFromDisk else { return }
        snapshotSaveSoon = true
        let url = snapshotURL
        // (at most every 20 seconds: during a long read the builds come every few seconds)
        Self.saveQueue.asyncAfter(deadline: .now() + 20) { [weak self] in
            guard let self else { return }
            self.recordsLock.lock(); let json = self.lastBuild; self.recordsLock.unlock()
            DispatchQueue.main.async { self.snapshotSaveSoon = false }
            guard let json else { return }
            var u = url
            if (try? SavedFormat.write(Data(json.utf8), .snapshot, to: u, options: [.atomic, Self.protection])) != nil {
                var v = URLResourceValues(); v.isExcludedFromBackup = true
                try? u.setResourceValues(v)
            }
        }
    }
    /// the screens as last laid out, if kosh kept them (nil before the first build, after Erase, or from an older kosh)
    func savedSnapshot() -> Snapshot? {
        // (read at launch, off the main thread, as the records were: waited for here only if it's still coming)
        let soon: Prefetch<Snapshot>? = keptSoon
        keptSoon = nil
        let read: Snapshot?
        if let soon { read = Perf.shared.measure("startup · kept screens waited") { soon.wait() } } else { read = Self.readKept(snapshotURL) }
        guard let s = read else { return nil }
        recordsLock.lock(); if lastNameGroups.isEmpty { lastNameGroups = s.nameGroups ?? [] }; recordsLock.unlock()
        return s
    }
    /// the screens kept from the last build, read and decoded (nil when there are none, or they can't be read)
    static func readKept(_ url: URL) -> Snapshot? {
        let t0: CFAbsoluteTime = CFAbsoluteTimeGetCurrent()
        guard let d = try? Data(contentsOf: url), let s = try? SavedFormat.decode(Snapshot.self, d, .snapshot).value else { return nil }
        Perf.shared.record("startup · kept screens decoded, off screen", ms: (CFAbsoluteTimeGetCurrent() - t0) * 1000)
        return s
    }
    /// the kept screens being read at launch (savedSnapshot takes them once)
    @ObservationIgnored var keptSoon: Prefetch<Snapshot>?
    func recordsJSON(_ recs: [Reading], _ version: Int) -> String {
        recordsLock.lock()
        if let c = recordsCache, c.version == version { recordsLock.unlock(); return c.json }
        recordsLock.unlock()
        // each reading as the engine wrote it: its typed fields and, put back beside them, what only `xtra` holds; in
        // plain ASCII, so the engine holds the text at one byte a character (RecordsHandover)
        let enc = JSONEncoder()
        var parts: [String] = []
        parts.reserveCapacity(recs.count)
        for r in recs { if let s = r.engineJSON(enc) { parts.append(RecordsHandover.ascii(s)) } }
        let json: String = "[" + parts.joined(separator: ",") + "]"
        recordsLock.lock(); recordsCache = (version, json); recordsLock.unlock()
        return json
    }
    /// a decoding error, said precisely enough to fix: which field, and what was wrong with it
    static func describe(_ error: Error) -> String {
        if let e = error as? DecodingError {
            func path(_ c: DecodingError.Context) -> String { c.codingPath.map { $0.intValue.map(String.init) ?? $0.stringValue }.joined(separator: ".") }
            switch e {
            case .keyNotFound(let k, let c): return "missing " + path(c) + "." + k.stringValue
            case .typeMismatch(_, let c): return "wrong type at " + path(c) + " (" + c.debugDescription + ")"
            case .valueNotFound(_, let c): return "no value at " + path(c)
            case .dataCorrupted(let c): return "unreadable at " + path(c) + " (" + c.debugDescription + ")"
            @unknown default: return String(describing: e)
            }
        }
        return error.localizedDescription
    }

    /// the screens with nothing in them, when even the engine can't run
    static var blank: Snapshot {
        let t = today, m = String(t.prefix(7))
        let json = """
        {"generated":"","today":"\(t)","cm":"\(m)","name":"kosh beta","voice":[{"k":"p","t":"Nothing yet."}],"wealthVoice":"",
        "fc":{"d":1,"dim":30,"left":29,"spent":0,"likely":0,"low":0,"high":0,"usual":0,"budget":0,"actual":[0],"forecast":[],"lo":[],"hi":[],"cats":[]},
        "months":[{"m":"\(m)","name":"This month","short":"Now","year":2026,"days":30,"live":true,"total":0,"payments":0,"cum":[0],"prev":null,"prevTotal":0,"change":null,"lead":"","cats":[]}],
        "cats":{},"tx":[],"needs":[],"flow":{"ins":[],"outs":[],"insight":"","warn":"","tail":"","blocked":""},"agenda":[],"comm":[],"hold":[],
        "prop":{"fy":"","rent":0,"tax":0,"arrears":0,"due":0,"props":[],"events":[]},"lent":[],"dups":[],
        "people":[{"id":"me","name":"You","full":"You","rel":"You","color":"#007AFF"}],"accounts":[],"cards":[],"wallets":[],
        "cash":{"month":0,"last30":0,"count":0,"lastUsed":""},"loans":[],"policies":[],"recurring":[],"owed":[],
        "insights":{"forWhom":[],"trend":[]},"scan":[],"scanStats":{"emails":0,"from":"\(t)","months":1},"fy":""}
        """
        if let s = try? JSONDecoder().decode(Snapshot.self, from: Data(json.utf8)) { return s }
        // (Snapshot gained a field the lines above don't give: the engine lays out the screens of no mail at all)
        if let out = try? Engine.shared.call("buildJSON", ["[]", "{}"]), let s = try? JSONText.decode(Snapshot.self, out) { return s }
        fatalError("kosh couldn't lay out its empty screens: LiveSession.blank needs the field Snapshot gained")
    }
































































































































    // MARK: state the LiveSession+Storage.swift extension keeps (stored properties live in the class)

    var typedBalances: [String: TypedBalance] = [:]
    var readings: [WorthReading] = []
    /// whether what's on this phone was read in. Until it is, nothing is written over it: kosh may have
    /// started while the phone was locked (its files are encrypted until you unlock), and saving then would
    /// put an empty ledger in place of yours.
    @ObservationIgnored var loadedFromDisk = false
    /// why the last load or build didn't work, said on Home rather than leaving the screens empty
    var loadProblem: String?

    // MARK: state the LiveSession+Mail.swift extension keeps (stored properties live in the class)

    // MARK: more Gmail accounts

    @ObservationIgnored var addingFor: String? = nil
    @ObservationIgnored var msVerifier = ""
    @ObservationIgnored var msState = ""

    // MARK: state the reading extensions keep (LiveSession+Reading, +Sweep, +Ingest, +Reread, +AIPass, +Downloads;
    // stored properties live in the class)

    /// Policy schedules, CAS and demat statements, contract notes: every PDF of that kind from the
    /// last year, found with one search, so they can be opened during setup.
    var findingDocs = false
    /// The last pass: what a money sender's mail in Gmail's Promotions tab says about money (an alert or a statement
    /// Gmail filed there). The main read leaves Promotions out; this comes back for it once over the year, then for
    /// what's new each time it runs.
    var readingPromos = false
    var discovered: [Found] = []
    var discovering = false
    /// setup's first look (discover) is done, or wasn't needed: setup can carry on
    var firstLook = true
    var discoverDone = 0
    var discoverTotal = 0
    /// Once each time kosh learns new wallets and shops (its directory changes): their receipts and the wallets'
    /// own mail from as far back as the rest was read, so Zomato Money, Swiggy Money, Amazon Pay and the like
    /// show up in Transactions for the months already read, not only from today. New mail after that comes
    /// with every read.
    var findingWallets = false
    var findingWider = false
    /// "Missing something?": a bank, card or wallet you name, looked for again across the year's mail (its senders,
    /// its co-brands, its name with money words). What's new is read like any other mail; returns how many emails
    /// were new to kosh.
    var lookingFor: String? = nil
    @ObservationIgnored var lastRebuild = Date.distantPast
    /// The mail that came into one inbox since its mark, from Gmail's change log: what's in Spam, Bin, Drafts, Sent,
    /// Social and Forums is left, and of the rest only mail that could be about money (a sender kosh knows, or money
    /// words in the subject) is read, judged by its sender and subject alone. Nil when the mark is too old, or so much
    /// came that the searches are the cheaper way (the caller runs them instead).
    @ObservationIgnored var byChangeLogFellBack = false

    // MARK: state the LiveSession+Extras.swift extension keeps (stored properties live in the class)

    var goldPrice: GoldPrice? = {
        guard let d = UserDefaults.standard.data(forKey: "beta.goldPrice") else { return nil }
        return try? JSONDecoder().decode(GoldPrice.self, from: d)
    }()
    var userCommittees: [UserCommittee] = []
    var epfJobs: [EPFJob] = []
    /// The rate the EPFO declared last, and the financial year it is for. Kept across launches, like the gold price:
    /// before it came back as a hardcoded 2025-26 every time kosh started, so a year-old year was shown as this one's.
    /// With nothing read yet, the year is the one today falls in (the EPFO declares one rate a year, late).
    var epfLatest: (fy: String, rate: Double) = {
        let d = UserDefaults.standard
        let fy: String = d.string(forKey: "beta.epfLatestFY") ?? LiveSession.financialYear(LiveSession.today)
        let rate: Double = d.double(forKey: "beta.epfLatestRate")
        return (fy, rate > 0 ? rate : 8.25)
    }() {
        didSet {
            guard !epfLatest.fy.isEmpty, epfLatest.rate > 0 else { return }
            ud.set(epfLatest.fy, forKey: "beta.epfLatestFY")
            ud.set(epfLatest.rate, forKey: "beta.epfLatestRate")
        }
    }
    /// the Indian financial year a day falls in, as the EPFO writes it: April to March, "2025-26"
    static func financialYear(_ day: String) -> String {
        let y: Int = Int(day.prefix(4)) ?? 2026, m: Int = Int(day.dropFirst(5).prefix(2)) ?? 1
        let start: Int = m >= 4 ? y : y - 1
        return String(start) + "-" + String(format: "%02d", (start + 1) % 100)
    }
    /// the property removed last, for an undo on the Property tab
    var lastRemoved: UserProperty?
    /// photos that arrived before their property was read off the page
    @ObservationIgnored var pendingPhotos: [String: Data] = [:]
    @ObservationIgnored var portalReading = false
    @ObservationIgnored var portalAsked: Set<Int> = []
    var snapCounts: (tx: Int, acc: Int, cards: Int) = (0, 0, 0)

    // MARK: state the LiveSession+Statements.swift extension keeps (stored properties live in the class)

    @ObservationIgnored var lastDocKind = ""
    /// what the paper applyDoc read last was about (invest, insurance…), and the details it printed (Your details)
    @ObservationIgnored var lastDocCat = ""
    @ObservationIgnored var lastDocFacts: [ReadingFact] = []
    /// the details the last build gathered from the mail (Your details, and the tries on a locked statement)
    @ObservationIgnored var lastFacts: [FactGroup] = []
    /// the paper applyDoc read last had holdings in it
    @ObservationIgnored var lastDocHeld = false
    /// whether each paper read was understood (by kosh's readers, or by Claude with its reading checked out), by its
    /// source: two papers read at once (one waiting on Claude) never take each other's answer
    @ObservationIgnored var docUnderstood: [String: Bool] = [:]
}
