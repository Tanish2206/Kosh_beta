import SwiftUI

// MARK: - Folding: one motion for everything that opens and closes in place
//
// A folded section opens downward from under its heading and closes back up. Its content is built at its full
// height and revealed through a clip whose height springs open, while it fades in and settles from a few points
// above; nothing inside re-lays out mid-flight, and everything below moves with it in the same spring. The fold runs
// its own animation off the open flag, so it moves the same however the flag changed (a tap, a remembered setting,
// a jump from elsewhere). Content that's closed is built just before it opens and let go once it has closed, unless
// it's heavy (Home's sections: charts, the months' carousel), which stays built so opening never waits on it. Every fold in kosh uses it (Home's sections, the card piles, the bill groups, statements, committees,
// the balance help, the day's note), so they all feel the same. Reduce Motion: it cuts.

enum Fold {
    /// every fold opens with the motion scale's large step: no overshoot, unhurried, so it eases in rather than snapping
    static let spring: Animation = Motion.large
    /// and closes with its close: quicker than it opened, never bouncing
    static let close: Animation = Motion.close
    /// a heading's chevron turning with the fold
    static let turn: Animation = Motion.base
    /// a fold going one way or the other, for the tap that flips it: opens with `spring`, closes with `close` (a
    /// toggle animated with `spring` both ways closed slower than its own content did)
    static func motion(opening: Bool) -> Animation { opening ? spring : close }
}

/// content that unrolls from under its heading: open, its full height; closed, nothing (and out of reach)
struct Unfold<Content: View>: View {
    let open: Bool
    /// once built, kept while closed (a heavy section, its charts and carousel, then opens without building first)
    var keep: Bool = false
    let content: Content
    /// built (just before opening, until it has closed)
    @State private var present: Bool
    /// unrolled
    @State private var revealed: Bool
    @Environment(\.accessibilityReduceMotion) private var still

    init(open: Bool, keep: Bool = false, @ViewBuilder content: () -> Content) {
        self.open = open
        self.keep = keep
        self.content = content()
        _present = State(initialValue: open)
        _revealed = State(initialValue: open)
    }

    var body: some View {
        ZStack(alignment: .top) {
            if present {
                content
                    .fixedSize(horizontal: false, vertical: true)
                    // settles down into place from a breath above, a touch small, as it fades in
                    .scaleEffect(revealed ? 1 : 0.985, anchor: .top)
                    .offset(y: revealed ? 0 : -10)
                    .opacity(revealed ? 1 : 0)
                    .transition(.identity)
            }
        }
        .frame(maxWidth: .infinity, alignment: .topLeading)
        .frame(height: revealed ? nil : 0, alignment: .top)
        // clipped below as it unrolls; shadows still breathe at the sides and top
        .mask(alignment: .top) { Rectangle().padding(.horizontal, -40).padding(.top, -30) }
        .allowsHitTesting(revealed)
        .accessibilityHidden(!revealed)
        .onChange(of: open) { _, on in
            if on {
                if present {
                    withAnimation(still ? nil : Fold.spring) { revealed = true }
                } else {
                    present = true
                    // one turn later, once it's built at its height: unroll
                    DispatchQueue.main.async {
                        withAnimation(still ? nil : Fold.spring) { revealed = true }
                    }
                }
            } else {
                withAnimation(still ? nil : Fold.close) { revealed = false } completion: {
                    if !revealed && !keep { present = false }
                }
            }
        }
    }
}

extension View {
    /// a heading's chevron: turned with the fold's own spring, however the flag changed
    func foldTurn(_ open: Bool, degrees: Double = 180) -> some View {
        rotationEffect(.degrees(open ? degrees : 0)).animation(Fold.turn, value: open)
    }
}
