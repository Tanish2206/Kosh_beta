import SwiftUI

// MARK: - How you paid: a month's spending by the way it left — UPI, cards, wallets, the bank, cash
//
// Grouped as the Transactions filter groups it (PaidWith.key), for whoever is shown, counting what counts as spending.

/// one way of paying, over a month
struct PaidWay: Identifiable {
    /// PaidWith's key: upi, card, wallet, bank, cash, or "" when the mail didn't say
    let id: String
    var v: Double = 0
    var n: Int = 0
    /// the cards used, by id
    var cards: Set<String> = []
    /// the wallets used: key → the shortest name it went by, and what went through it
    var wallets: [String: WalletUse] = [:]
    /// of the bank ones, how many were auto-debits
    var auto: Int = 0

    struct WalletUse { var name: String; var v: Double }

    /// the order the bar and the rows keep, month to month
    static let order: [String] = ["upi", "card", "wallet", "bank", "cash", ""]

    var title: String {
        switch id {
        case "upi": return "UPI"
        case "card": return "Cards"
        case "wallet": return "Wallets"
        case "bank": return auto == n ? "Auto-debit" : (auto == 0 ? "Bank transfers" : "Bank & auto-debit")
        case "cash": return "Cash"
        default: return "Not said"
        }
    }
    /// the way, as it sits in a sentence: "went by UPI", "went by card"
    var word: String {
        switch id {
        case "upi": return "UPI"
        case "card": return "card"
        case "wallet": return "wallet"
        case "bank": return auto == n ? "auto-debit" : "bank transfer"
        case "cash": return "cash"
        default: return "other ways"
        }
    }
    var symbol: String {
        switch id {
        case "upi": return "arrow.left.arrow.right"
        case "card": return "creditcard"
        case "wallet": return "wallet.bifold"
        case "bank": return auto == n ? "arrow.triangle.2.circlepath" : "building.columns"
        case "cash": return "banknote"
        default: return "questionmark"
        }
    }
    var color: Color {
        switch id {
        case "upi": return Color.kosh
        case "card": return Color.sky
        case "wallet": return Color(hex: "#FF9F0A")
        case "bank": return Color(hex: "#8E8E93")
        case "cash": return Color(hex: "#34C759")
        default: return Color(uiColor: .systemGray3)
        }
    }
    /// the wallets' names, the most used first
    var walletNames: [String] {
        wallets.values.sorted { $0.v != $1.v ? $0.v > $1.v : $0.name < $1.name }.map(\.name)
    }
    /// "46 payments", "12 payments · 4 cards", "14 payments · Zomato Money, Swiggy Money, Amazon Pay"
    var line: String {
        let count: String = n == 1 ? "1 payment" : String(n) + " payments"
        switch id {
        case "card":
            return cards.count > 1 ? count + " · " + String(cards.count) + " cards" : count
        case "wallet":
            let names: [String] = walletNames
            if names.isEmpty { return count }
            let more: String = names.count > 3 ? " +" + String(names.count - 3) : ""
            return count + " · " + names.prefix(3).joined(separator: ", ") + more
        case "bank":
            return auto > 0 && auto < n ? count + " · " + String(auto) + " on auto-debit" : count
        case "":
            return count + " · the mail didn't say how"
        default:
            return count
        }
    }
}

/// a month's spending, split by how it was paid
struct PaidSplit {
    let month: String
    /// in PaidWay.order, nothing empty
    let ways: [PaidWay]
    let total: Double

    func share(_ w: PaidWay) -> Double { total > 0 ? w.v / total : 0 }

    /// one line with a little personality, true to the figures: which way carried the month
    var quip: String? {
        let known: [PaidWay] = ways.filter { !$0.id.isEmpty }
        guard total > 0, let top = known.max(by: { $0.v < $1.v }) else { return nil }
        let pct: String = Fmt.pct(share(top))
        if known.count == 1 && ways.count == 1 { return "Every rupee went by " + top.word + "." }
        switch top.id {
        case "upi":
            return share(top) >= 0.5 ? "UPI wins, obviously: " + pct + " went by scan and pay." : "UPI leads with " + pct + ". Scan, pay, repeat."
        case "card":
            return "Cards carried " + pct + " of it. Reward points, hopefully."
        case "wallet":
            if let name = top.walletNames.first { return "Wallets took " + pct + ", mostly " + name + "." }
            return "Wallets took " + pct + " of it."
        case "bank":
            return top.auto == top.n ? "Auto-debits led with " + pct + ". Set and forget." : "Bank transfers led with " + pct + "."
        case "cash":
            return "Cash led with " + pct + ". Old school, respect."
        default:
            return nil
        }
    }
}

extension Store {
    /// a month's spending (for whoever is shown) by how it was paid, in one pass over the payments
    func paidSplit(_ m: String) -> PaidSplit {
        var by: [String: PaidWay] = [:]
        var total: Double = 0
        for t in spends(in: [m]) {
            let k: String = PaidWith.key(t)
            var w: PaidWay = by[k] ?? PaidWay(id: k)
            w.v += t.a
            w.n += 1
            if k == "card" && !t.card.isEmpty { w.cards.insert(t.card) }
            if k == "bank" && t.md == "auto" { w.auto += 1 }
            if k == "wallet" {
                let name: String = PaidWith.walletName(t)
                let key: String = PaidWith.walletKey(name)
                if !key.isEmpty {
                    var use: PaidWay.WalletUse = w.wallets[key] ?? PaidWay.WalletUse(name: name, v: 0)
                    if name.count < use.name.count { use.name = name }
                    use.v += t.a
                    w.wallets[key] = use
                }
            }
            by[k] = w
            total += t.a
        }
        let ways: [PaidWay] = PaidWay.order.compactMap { by[$0] }.filter { $0.v > 0.5 }
        return PaidSplit(month: m, ways: ways, total: total)
    }
}

// MARK: The card

struct HowYouPaid: View {
    @Environment(Store.self) private var store
    @Environment(\.accessibilityReduceMotion) private var still
    /// the part of Accounts & cards that opens: the Wallets row sends you to the wallets
    @AppStorage("accts.part") private var acctsPart = "accounts"
    @State private var grown = false
    @ScaledMetric(relativeTo: .subheadline) private var amtW: CGFloat = 96
    /// the month Insights looks at ("" this month)
    @Environment(\.insightMonth) private var pickedMonth

    var body: some View {
        let cm: String = pickedMonth.isEmpty ? store.snap.cm : pickedMonth
        let now: PaidSplit = store.paidSplit(cm)
        // the first day or two of this month can be empty: show the month just gone instead, and say so (an earlier
        // month picked is that month, empty or not)
        let split: PaidSplit = now.total > 0 || cm != store.snap.cm ? now : store.paidSplit(Day.addMonths(cm, -1))
        if split.total > 0 {
            VStack(alignment: .leading, spacing: 12) {
                VStack(alignment: .leading, spacing: 3) {
                    HStack(alignment: .firstTextBaseline) {
                        InsightTitle(text: "How you paid")
                        Spacer(minLength: 8)
                        Text(split.month == store.snap.cm ? "this month" : "in " + Day.monthName(split.month))
                            .font(.subheadline).foregroundStyle(.secondary).lineLimit(1)
                    }
                    if let q = split.quip {
                        Text(q).font(.subheadline).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                    }
                }
                VStack(alignment: .leading, spacing: 0) {
                    InsightBar(parts: split.ways.map { ($0.color, $0.v) }, grown: grown)
                        .accessibilityElement(children: .ignore)
                        .accessibilityLabel(split.ways.map { $0.title + " " + Fmt.pct(split.share($0)) }.joined(separator: ", "))
                    VStack(spacing: 0) {
                        ForEach(Array(split.ways.enumerated()), id: \.element.id) { i, w in
                            if i > 0 { InsightDivider() }
                            if w.id == "wallet" {
                                Button {
                                    acctsPart = "wallets"
                                    withAnimation(still ? nil : Motion.open) { store.txSub = .accounts }
                                } label: {
                                    PaidRow(way: w, share: split.share(w), amtW: amtW, link: true)
                                }
                                .buttonStyle(.press)
                                .accessibilityHint("Opens your wallets in Accounts & cards")
                            } else {
                                PaidRow(way: w, share: split.share(w), amtW: amtW, link: false)
                            }
                        }
                    }
                    .padding(.top, 8)
                }
                .padding(.horizontal, 16)
                .padding(.top, 16)
                .padding(.bottom, 6)
                .frame(maxWidth: .infinity, alignment: .leading)
                .insightCard(26)
                .privacySensitive()
            }
            .onAppear { InsightMotion.start(still) { grown = true } }
        }
    }
}

private struct PaidRow: View {
    let way: PaidWay
    let share: Double
    let amtW: CGFloat
    /// a row that opens somewhere: "See wallets ›" where the share would be
    let link: Bool
    var body: some View {
        HStack(spacing: 12) {
            IconTile(symbol: way.symbol, color: way.color, size: 38)
            VStack(alignment: .leading, spacing: 1) {
                Text(way.title).font(.subheadline.weight(.semibold)).lineLimit(1)
                Text(way.line)
                    .font(.footnote).foregroundStyle(.secondary)
                    .lineLimit(2)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            VStack(alignment: .trailing, spacing: 1) {
                Text(Fmt.rupees(way.v))
                    .font(.system(.subheadline, design: .rounded, weight: .semibold)).monospacedDigit()
                    .lineLimit(1).minimumScaleFactor(0.7)
                if link {
                    HStack(spacing: 3) {
                        Text("See wallets")
                        Image(systemName: "chevron.right").font(.caption2.weight(.bold))
                    }
                    .font(.footnote.weight(.semibold))
                    .foregroundStyle(Color.kosh)
                    .lineLimit(1)
                    .minimumScaleFactor(0.8)
                } else {
                    Text(Fmt.pct(share))
                        .font(.system(.footnote, design: .rounded)).monospacedDigit()
                        .foregroundStyle(.secondary)
                }
            }
            .frame(minWidth: 64, maxWidth: amtW, alignment: .trailing)
        }
        .padding(.vertical, 10)
        .contentShape(Rectangle())
        .accessibilityElement(children: .combine)
    }
}
