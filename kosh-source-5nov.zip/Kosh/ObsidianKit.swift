import SwiftUI

// MARK: - Obsidian everywhere: the black look carried onto every page and sheet of Wealth and Insurance (1 Nov)
//
// Obsidian.swift holds the tokens and the main pages' pieces. This file holds what lets the older pages, lists, forms
// and sheets reached from those two tabs draw in the same look without being rewritten: a flag in the environment
// (`obsidian`, set by `.obsidianPage()` and `.obsidianSheet()`), a card fill that follows it, and List/Form stand-ins
// that put each row on a near-black card. A page shared with the rest of kosh (an account, a person's details) reads
// the flag, so it is black when opened from Wealth or Insurance and keeps its own look everywhere else.

private struct ObsidianKey: EnvironmentKey { static let defaultValue: Bool = false }

extension EnvironmentValues {
    /// drawn in the black look (Wealth, Insurance, and whatever they open)
    var obsidian: Bool {
        get { self[ObsidianKey.self] }
        set { self[ObsidianKey.self] = newValue }
    }
}

extension Obsidian {
    /// a card on a card: a chip, a box inside a card
    static let raised: Color = Color(hex: "#16161A")
    /// a row's separator, as quiet as a card's hairline
    static let rule: Color = Color.white.opacity(0.08)
}

/// a card's fill: near-black on the black screens, kosh's surface everywhere else
struct CardFill: ShapeStyle {
    var opacity: Double = 1
    /// a box inside a card (kosh's raised surface)
    var raised: Bool = false
    func resolve(in environment: EnvironmentValues) -> Color {
        let dark: Color = raised ? Obsidian.raised : Obsidian.card
        let light: Color = raised ? Color.raised : Color.surface
        let base: Color = environment.obsidian ? dark : light
        return base.opacity(opacity)
    }
}

/// a card's hairline that follows the look
struct CardEdge: ShapeStyle {
    func resolve(in environment: EnvironmentValues) -> Color {
        environment.obsidian ? Obsidian.cardBorder : Color.primary.opacity(0.05)
    }
}

/// a List whose rows sit on near-black cards on the black screens (and a plain List elsewhere)
struct ObsidianList<Content: View>: View {
    @Environment(\.obsidian) private var obsidian
    let content: Content
    init(@ViewBuilder content: () -> Content) { self.content = content() }
    var body: some View {
        List { rows }
    }
    private var fill: Color? { obsidian ? Obsidian.card : nil }
    private var rule: Color? { obsidian ? Obsidian.rule : nil }
    private var rows: some View {
        content
            .listRowBackground(fill)
            .listRowSeparatorTint(rule)
    }
}

/// a Form drawn the same way
struct ObsidianForm<Content: View>: View {
    @Environment(\.obsidian) private var obsidian
    let content: Content
    init(@ViewBuilder content: () -> Content) { self.content = content() }
    var body: some View {
        Form { rows }
    }
    private var fill: Color? { obsidian ? Obsidian.card : nil }
    private var rule: Color? { obsidian ? Obsidian.rule : nil }
    private var rows: some View {
        content
            .listRowBackground(fill)
            .listRowSeparatorTint(rule)
    }
}

/// a sheet in the black look. Sheets don't take the look of the page under them, so each one opened from Wealth or
/// Insurance says it (`on` false leaves a shared sheet as it was)
struct ObsidianSheet: ViewModifier {
    let on: Bool
    @ViewBuilder func body(content: Content) -> some View {
        if on {
            content
                .environment(\.colorScheme, .dark)
                .environment(\.obsidian, true)
                .scrollContentBackground(.hidden)
                .presentationBackground(Obsidian.bg)
        } else {
            content
        }
    }
}

extension View {
    func obsidianSheet(_ on: Bool = true) -> some View { modifier(ObsidianSheet(on: on)) }
}

/// which of the app's own sheets are Wealth's or Insurance's: their editors always, and the shared ones (where a figure
/// was read from, the details a locked paper needs, the papers) while one of those two tabs is open
enum ObsidianSheets {
    static func on(_ kind: BetaSheet, tab: AppTab) -> Bool {
        switch kind {
        case .policy, .loan, .holding, .epf: return true
        case .source, .passwords, .papers, .documents: return ours(tab)
        default: return false
        }
    }
    static func on(_ kind: SheetKind, tab: AppTab) -> Bool {
        switch kind {
        case .capture(let k): return k == "gold" || k == "other" || k.hasPrefix("policy:") || k.hasPrefix("loan:")
        case .arrange(let t): return ours(t)
        default: return false
        }
    }
    static func ours(_ tab: AppTab) -> Bool { tab == .portfolio || tab == .insurance }
}

/// a segmented control in the black look that never wraps: each choice as wide as its word, one line, the chosen one
/// white with black words, the track scrolling sideways when there are more choices than room (whose money: You, a
/// first name each, All)
struct ObsidianSegments: View {
    let items: [(id: String, label: String)]
    @Binding var picked: String
    @Environment(\.accessibilityReduceMotion) private var still
    var body: some View {
        ScrollView(.horizontal) {
            HStack(spacing: 2) {
                ForEach(items.indices, id: \.self) { (i: Int) in segment(items[i].id, items[i].label) }
            }
            .padding(3)
            .background(Obsidian.card, in: Capsule())
            .overlay(Capsule().strokeBorder(Obsidian.cardBorder, lineWidth: 1))
        }
        .scrollIndicators(.hidden)
        .scrollBounceBehavior(.basedOnSize, axes: .horizontal)
        .sensoryFeedback(.selection, trigger: picked)
    }
    func segment(_ id: String, _ label: String) -> some View {
        let on: Bool = id == picked
        let fill: Color = on ? Obsidian.ink : Color.clear
        return Button {
            withAnimation(still ? nil : Motion.base) { picked = id }
        } label: {
            Text(label)
                .font(.system(size: 13.5, weight: on ? .semibold : .medium))
                .lineLimit(1)
                .fixedSize()
                .foregroundStyle(on ? Color.black : Obsidian.ink2)
                .padding(.horizontal, 15)
                .frame(minWidth: 54, minHeight: 38)
                .background(fill, in: Capsule())
                .contentShape(Capsule())
        }
        .buttonStyle(.press)
        .accessibilityAddTraits(on ? .isSelected : [])
    }
}

extension ClassSum {
    /// the kind's colour on the black screens (Wealth's: deposits mint, funds violet, shares blue...)
    var kindColor: Color { WealthKind.color(key) }
}
