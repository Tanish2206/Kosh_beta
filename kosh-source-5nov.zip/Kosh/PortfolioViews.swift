import SwiftUI

// MARK: - The Portfolio's own views: how fresh each figure is, dividends, deposits maturing and closed
//
// Self-contained pieces the Portfolio's screens place where they fit (WealthView, Deposits, InvestGlance, ClassCards,
// EPFView), so a later redesign can take them as they are. Each draws what the engine worked out once a build
// (engine/21k-build-portfolio.js): nothing here scans the ledger or the deposits at a redraw.
//   HoldingAsOf       one quiet line under a holding: what its figure was read from, and when ("CAS, as of 26 Sep")
//   DividendsBook     the page: dividends by financial year (April to March) and by company, every payment dated
//                     (opened from Wealth's home, WealthHome.swift, and the stocks page)
//   DepositDatesPage  deposits maturing in the next twelve months and closed in the last six, each with its dates
//                     (opened from Wealth › Deposits and Holdings' deposits)

// MARK: the engine's books (snap.dividends, snap.depDates)

/// one person's dividends (or the family's): from the day the mail is read from to today, by year and by company
struct DividendBook: Decodable, Hashable {
    let from: String
    let to: String
    let total: Double
    let n: Int
    let years: [DividendYear]
    let cos: [DividendCompany]
}
/// one financial year: its own from and to (part: the mail's start or today cuts it short), and its companies
struct DividendYear: Decodable, Hashable, Identifiable {
    let fy: String
    let label: String
    let from: String
    let to: String
    let total: Double
    let n: Int
    let cos: [DividendShare]
    var part: Bool? = nil
    var id: String { fy }
}
/// a company's dividends within a year
struct DividendShare: Decodable, Hashable, Identifiable {
    let key: String
    let name: String
    let total: Double
    let n: Int
    var id: String { key }
}
/// a company's dividends over the whole book, each payment newest first
struct DividendCompany: Decodable, Hashable, Identifiable {
    let key: String
    let name: String
    let total: Double
    let n: Int
    let first: String
    let last: String
    let pays: [DividendPay]
    var id: String { key }
}
struct DividendPay: Decodable, Hashable, Identifiable {
    let id: String
    let d: String
    let a: Double
    let fy: String
}

/// deposits maturing from today to a year on, and those closed in the six months to today
struct DepDates: Decodable, Hashable {
    let ahead: DepDateList
    let closed: DepDateList
}
struct DepDateList: Decodable, Hashable {
    let from: String
    let to: String
    let items: [DepDateItem]
}
/// one maturity or closure: the deposit kosh follows (id), one you added ("user|<id>"), or a closure credit kosh
/// couldn't put on a deposit (tx); its day, bank and name; what was put in, is worth today and pays at maturity; or,
/// closed, how (label) and what came back
struct DepDateItem: Decodable, Hashable {
    var id: String? = nil
    var tx: String? = nil
    let d: String
    let bank: String
    let title: String
    let person: String
    var amt: Double? = nil; var now: Double? = nil; var matAmt: Double? = nil; var rate: Double? = nil
    var auto: Bool? = nil; var carry: Bool? = nil; var rd: Bool? = nil; var look: Bool? = nil; var you: Bool? = nil
    var label: String? = nil; var back: Double? = nil
    var key: String { (id ?? tx ?? title) + "|" + d }
}

extension Store {
    /// whoever is being looked at: their dividends, and their deposits maturing and closed
    func dividends(_ p: Person) -> DividendBook? { snap.dividends?[p.rawValue] }
    func depositsAhead(_ p: Person) -> [DepDateItem] { (snap.depDates?.ahead.items ?? []).filter { p.owns($0.person) } }
    func depositsClosed(_ p: Person) -> [DepDateItem] { (snap.depDates?.closed.items ?? []).filter { p.owns($0.person) } }
    /// a maturity's row opens its deposit's journey, or the one you added to edit
    func openDepositDate(_ d: DepDateItem) {
        guard let id = d.id else { return }
        if deposit(id) != nil { push(.deposit(id)) }
        else if id.hasPrefix("user|"), live != nil { betaSheet = .holding(String(id.dropFirst(5))) }
    }
}

// MARK: words

enum FreshWords {
    /// what a figure was read from
    static func source(_ by: String, cls: String) -> String {
        switch by {
        case "cas": return "CAS"
        case "statement": return "Statement"
        case "mail": return cls == "dep" ? "Bank’s mail" : "Mail"
        case "advice": return "Its advice"
        case "you": return "Your entry"
        case "epf": return "EPFO passbook"
        case "bullion": return "Bullion rate"
        case "insurer": return "Insurer’s figure"
        case "interest": return "Its interest credit"
        default: return "Read"
        }
    }
    /// "10 Oct", or "10 Oct 2025" in another year
    static func day(_ d: String, today: String) -> String {
        Day.fmt(d, d.prefix(4) == today.prefix(4) ? "d MMM" : "d MMM yyyy")
    }
    /// "7 weeks ago", "3 months ago", "over a year ago"
    static func ago(_ days: Int) -> String {
        if days < 60 { return String(max(1, days / 7)) + " weeks ago" }
        if days < 365 {
            let m: Int = Int((Double(days) / 30.44).rounded())
            return (m <= 1 ? "a month" : String(m) + " months") + " ago"
        }
        let y: Int = days / 365
        return y == 1 ? "over a year ago" : "over " + String(y) + " years ago"
    }
    /// "CAS, as of 26 Sep", "Statement, 9 Oct", "Your entry, 2 Oct", "CAS, as of 2 Aug, 3 months ago",
    /// "CAS, as of 26 Sep · prices of 23 Oct", "CAS, as of 31 Aug + 2 trades since"
    static func line(_ f: Holding.Fresh, cls: String, roll: Holding.Roll?, today: String) -> String {
        // bought since the newest statement: the mail's alone
        if let r = roll, r.made == true, r.last.count >= 10 { return "Bought " + day(r.last, today: today) + ", since your statement" }
        var s: String = source(f.by, cls: cls)
        if let d = f.d, d.count >= 10 {
            s += (f.by == "cas" ? ", as of " : ", ") + day(d, today: today)
            if f.old == true { s += ", " + ago(Day.between(d, today)) }
        }
        if let r = roll, r.n > 0 {
            let noun: String = cls == "stk" ? "trade" : "transaction"
            s += " + " + String(r.n) + " " + noun + (r.n == 1 ? "" : "s") + " since"
        }
        if let p = f.pd, p.count >= 10 { s += " · prices of " + day(p, today: today) }
        return s
    }
}

enum DividendWords {
    /// "1 Apr – 24 Oct 2026", "1 Oct 2025 – 31 Mar 2026"
    static func range(_ a: String, _ b: String) -> String {
        if a == b { return Day.fmt(a, "d MMM yyyy") }
        let sameYear: Bool = a.prefix(4) == b.prefix(4)
        return Day.fmt(a, sameYear ? "d MMM" : "d MMM yyyy") + " – " + Day.fmt(b, "d MMM yyyy")
    }
    /// rupees with their paise when a dividend has them: "₹84.75", "₹504"
    static func money(_ v: Double) -> String {
        let paise: Int = Int((abs(v) * 100).rounded()) % 100
        if paise == 0 { return Fmt.rupees(v) }
        return "₹" + Fmt.inr(Double(Int(abs(v)))) + String(format: ".%02d", paise)
    }
    static func count(_ n: Int, _ one: String, _ many: String) -> String { String(n) + " " + (n == 1 ? one : many) }
    /// "so far" when the year runs to today
    static func yearSpan(_ y: DividendYear, today: String) -> String {
        range(y.from, y.to) + (y.to == today ? ", so far" : "")
    }
}

// MARK: how fresh a figure is

/// one quiet line under a holding or a deposit: what its figure was read from and when; orange once it's old
struct HoldingAsOf: View {
    @Environment(Store.self) private var store
    let fresh: Holding.Fresh?
    let cls: String
    let roll: Holding.Roll?
    init(h: Holding) { fresh = h.fresh; cls = h.cls; roll = h.roll }
    init(deposit d: DepositItem) { fresh = d.fresh; cls = "dep"; roll = nil }
    var body: some View {
        if let f = fresh {
            let old: Bool = f.old == true
            let words: String = FreshWords.line(f, cls: cls, roll: roll, today: store.snap.today)
            HStack(spacing: 4) {
                if old { Image(systemName: "clock").font(.caption2.weight(.semibold)) }
                Text(words).font(.caption2).lineLimit(1).minimumScaleFactor(0.85)
            }
            .foregroundStyle(old ? Color.orange : Color.secondary)
            .accessibilityElement(children: .ignore)
            .accessibilityLabel("Figure from " + words)
        }
    }
}

// MARK: dividends

/// the company's own icon when kosh knows its site, else its initials
struct DividendMark: View {
    let name: String
    var size: CGFloat = 36
    var body: some View {
        if let site = CompanySites.shared.domain(name: name, isin: nil) {
            InstIcon(name: name, color: Color.gray, size: size, site: site, plain: true)
        } else {
            Monogram(name: name, size: size)
        }
    }
}

/// the same, as a row inside a List (the stocks page)
struct DividendsLink: View {
    @Environment(Store.self) private var store
    var body: some View {
        if let b = store.dividends(store.who), let now = b.years.first {
            Button { store.push(.dividends) } label: {
                HStack(spacing: 12) {
                    IconTile(symbol: "indianrupeesign.circle.fill", color: Color.green, size: 30)
                    VStack(alignment: .leading, spacing: 1) {
                        Text("Dividends").font(.subheadline.weight(.semibold)).foregroundStyle(Color.primary)
                        Text(DividendWords.money(now.total) + " in " + now.label + ", " + DividendWords.range(now.from, now.to))
                            .font(.footnote).foregroundStyle(.secondary).privacySensitive()
                    }
                    Spacer()
                    Image(systemName: "chevron.right").font(.footnote.weight(.semibold)).foregroundStyle(.tertiary)
                }
            }
        }
    }
}

/// every dividend: the total over a year or all of them, by year and by company, each company's payments dated
struct DividendsBook: View {
    @Environment(Store.self) private var store
    /// a financial year ("2025-26"), or "all"
    @State private var year: String = "all"
    var body: some View {
        if let b = store.dividends(store.who) {
            let today: String = store.snap.today
            let y: DividendYear? = b.years.first { $0.fy == year }
            let total: Double = y?.total ?? b.total
            let span: String = y.map { DividendWords.yearSpan($0, today: today) } ?? DividendWords.range(b.from, b.to)
            let shares: [DividendShare] = y?.cos ?? b.cos.map { DividendShare(key: $0.key, name: $0.name, total: $0.total, n: $0.n) }
            let byKey: [String: DividendCompany] = Dictionary(b.cos.map { ($0.key, $0) }, uniquingKeysWith: { a, _ in a })
            let payments: Int = y?.n ?? b.n
            ObsidianList {
                Section {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(y?.label ?? "Every financial year").font(.subheadline.weight(.medium)).foregroundStyle(.secondary)
                        Text(DividendWords.money(total))
                            .font(.system(size: 40, weight: .bold, design: .rounded)).monospacedDigit()
                            .minimumScaleFactor(0.6).lineLimit(1)
                            .privacySensitive()
                        Text(span + " · " + DividendWords.count(payments, "payment", "payments") + " from " + DividendWords.count(shares.count, "company", "companies"))
                            .font(.subheadline).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                    }
                    .padding(.vertical, 4)
                    .listRowBackground(Color.clear)
                    if b.years.count > 1 {
                        InstrumentChips(options: [("all", "All years")] + b.years.map { ($0.fy, $0.label) }, selection: $year)
                            .listRowBackground(Color.clear)
                            .listRowInsets(EdgeInsets(top: 0, leading: 0, bottom: 0, trailing: 0))
                    }
                }
                if y == nil && b.years.count > 1 {
                    Section("By financial year") {
                        ForEach(b.years) { yr in
                            Button { withAnimation(Motion.base) { year = yr.fy } } label: { DividendYearRow(y: yr).foregroundStyle(Color.primary) }
                        }
                    }
                }
                Section {
                    ForEach(shares) { s in DividendCompanyRow(share: s, co: byKey[s.key], fy: y?.fy) }
                } header: {
                    Text("By company")
                } footer: {
                    Text("Dividends credited to your accounts, as your bank’s alerts and the registrars’ mails tell them. A financial year runs from April to March.")
                }
            }
            .listStyle(.insetGrouped)
            .navigationTitle("Dividends")
            .animation(Motion.base, value: year)
            .sensoryFeedback(.selection, trigger: year)
            .obsidianPage()
        } else {
            ContentUnavailableView("No dividends yet", systemImage: "indianrupeesign.circle",
                                   description: Text("Dividends credited to your accounts appear here, by year and by company."))
                .obsidianPage()
        }
    }
}

struct DividendYearRow: View {
    @Environment(Store.self) private var store
    let y: DividendYear
    var body: some View {
        HStack(spacing: 12) {
            VStack(alignment: .leading, spacing: 2) {
                Text(y.label).font(.body.weight(.medium))
                Text(DividendWords.yearSpan(y, today: store.snap.today) + " · " + DividendWords.count(y.cos.count, "company", "companies"))
                    .font(.caption).foregroundStyle(.secondary).lineLimit(1)
            }
            Spacer(minLength: 8)
            Text(DividendWords.money(y.total)).font(.body.weight(.semibold)).monospacedDigit().privacySensitive()
            Image(systemName: "chevron.right").font(.footnote.weight(.semibold)).foregroundStyle(.tertiary)
        }
    }
}

/// a company: its total over the year picked (or all of them), and, opened, each payment with its day
struct DividendCompanyRow: View {
    let share: DividendShare
    let co: DividendCompany?
    /// the financial year picked, or nil for all of them
    let fy: String?
    @State private var open = false
    var body: some View {
        let pays: [DividendPay] = (co?.pays ?? []).filter { fy == nil || $0.fy == fy }
        let last: String = pays.first.map { ", last on " + Day.fmt($0.d, "d MMM yyyy") } ?? ""
        DisclosureGroup(isExpanded: $open) {
            ForEach(pays) { p in
                HStack {
                    Text(Day.fmt(p.d, "d MMM yyyy")).font(.subheadline)
                    Text("FY " + p.fy).font(.caption).foregroundStyle(.secondary)
                    Spacer()
                    Text(DividendWords.money(p.a)).font(.subheadline.weight(.medium)).monospacedDigit().privacySensitive()
                }
            }
        } label: {
            HStack(spacing: 12) {
                DividendMark(name: share.name)
                VStack(alignment: .leading, spacing: 2) {
                    Text(share.name).font(.body.weight(.medium)).lineLimit(1)
                    Text(DividendWords.count(share.n, "payment", "payments") + last).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                }
                Spacer(minLength: 8)
                Text(DividendWords.money(share.total)).font(.body.weight(.semibold)).monospacedDigit().privacySensitive()
            }
        }
    }
}

// MARK: deposits maturing and closed

/// one maturity (what it pays, its rate, whether it renews) or one closure (how, and what came back)
struct DepositDateRow: View {
    @Environment(Store.self) private var store
    let d: DepDateItem
    let closed: Bool
    var showWho: Bool = false
    var title: String {
        if d.tx != nil { return d.bank.isEmpty ? "A deposit closed" : d.bank + " deposit closed" }
        return HoldingName.pretty(d.title)
    }
    var sub: String {
        var bits: [String] = []
        if closed {
            bits.append((d.label ?? "Closed") + " on " + Day.fmt(d.d, "d MMM yyyy"))
        } else {
            bits.append("Matures " + Day.fmt(d.d, "d MMM yyyy"))
            if let r = d.rate, r > 0 { bits.append(Fmt.trim(r, 2) + "%") }
            if d.auto == true { bits.append(d.carry == true ? "renews with its interest" : "renews on its own") }
            if d.look == true { bits.append("needs a look") }
            if d.you == true { bits.append("you added it") }
        }
        if showWho { bits.append(store.ownerName(d.person)) }
        return bits.joined(separator: " · ")
    }
    /// the figure on the right, and what it is
    var figure: (String, String) {
        if closed {
            if let b = d.back, b > 0 { return ("+" + Fmt.words(b), "came back") }
            return ("", "")
        }
        if let m = d.matAmt, m > 0 { return (Fmt.words(m), "at maturity") }
        if let n = d.now, n > 0 { return (Fmt.words(n), "worth today") }
        if let a = d.amt, a > 0 { return (Fmt.words(a), "put in") }
        return ("", "")
    }
    var body: some View {
        let fig: (String, String) = figure
        HStack(spacing: 12) {
            DateBadge(date: d.d, today: d.d == store.snap.today)
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(.body.weight(.medium)).foregroundStyle(Color.primary).lineLimit(1)
                Text(sub).font(.caption).foregroundStyle(d.look == true ? Color.orange : Color.secondary).lineLimit(2)
            }
            Spacer(minLength: 8)
            if !fig.0.isEmpty {
                VStack(alignment: .trailing, spacing: 2) {
                    Text(fig.0).font(.body.weight(.semibold)).monospacedDigit()
                        .foregroundStyle(closed ? Color.green : Color.primary).privacySensitive()
                    Text(fig.1).font(.caption).foregroundStyle(.secondary)
                }
                .fixedSize(horizontal: true, vertical: false)
            }
        }
        .contentShape(Rectangle())
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(store.hidden || fig.0.isEmpty ? title + ", " + sub : title + ", " + sub + ", " + fig.0 + " " + fig.1)
    }
}

/// a row inside a List (the deposits page) that opens every maturity and closure
struct DepositDatesLink: View {
    @Environment(Store.self) private var store
    let person: Person
    /// "2 maturing in the next 12 months · 1 closed since 24 Apr"
    static func words(ahead: Int, closed: Int, from: String) -> String {
        var bits: [String] = [String(ahead) + " maturing in the next 12 months"]
        if closed > 0 { bits.append(String(closed) + " closed since " + Day.fmt(from, "d MMM")) }
        return bits.joined(separator: " · ")
    }
    var body: some View {
        if let dd = store.snap.depDates {
            let ahead: Int = store.depositsAhead(person).count
            let closed: Int = store.depositsClosed(person).count
            Button { store.push(.maturities) } label: {
                HStack(spacing: 12) {
                    IconTile(symbol: "calendar.badge.clock", color: Color(hex: "#007AFF"), size: 30)
                    VStack(alignment: .leading, spacing: 1) {
                        Text("Maturities and closures").font(.subheadline.weight(.semibold)).foregroundStyle(Color.primary)
                        Text(Self.words(ahead: ahead, closed: closed, from: dd.closed.from)).font(.footnote).foregroundStyle(.secondary)
                    }
                    Spacer()
                    Image(systemName: "chevron.right").font(.footnote.weight(.semibold)).foregroundStyle(.tertiary)
                }
            }
        }
    }
}

/// every deposit maturing from today to a year on, and every one closed in the six months to today
struct DepositDatesPage: View {
    @Environment(Store.self) private var store
    var body: some View {
        let p: Person = store.who
        let ahead: [DepDateItem] = store.depositsAhead(p)
        let closed: [DepDateItem] = store.depositsClosed(p)
        if let dd = store.snap.depDates {
            let aheadSpan: String = DividendWords.range(dd.ahead.from, dd.ahead.to)
            let closedSpan: String = DividendWords.range(dd.closed.from, dd.closed.to)
            let comes: Double = ahead.reduce(0) { (s: Double, d: DepDateItem) -> Double in s + (d.matAmt ?? d.now ?? d.amt ?? 0) }
            let back: Double = closed.reduce(0) { (s: Double, d: DepDateItem) -> Double in s + (d.back ?? 0) }
            ObsidianList {
                Section {
                    if ahead.isEmpty {
                        Text("Nothing matures between " + Day.fmt(dd.ahead.from, "d MMM yyyy") + " and " + Day.fmt(dd.ahead.to, "d MMM yyyy") + ".").font(.subheadline).foregroundStyle(.secondary)
                    }
                    ForEach(ahead, id: \.key) { d in
                        Button { store.openDepositDate(d) } label: { DepositDateRow(d: d, closed: false, showWho: p == .family) }
                    }
                } header: {
                    HStack {
                        Text("Maturing, " + aheadSpan)
                        Spacer()
                        if comes > 0 { Text(Fmt.words(comes)).monospacedDigit().privacySensitive() }
                    }
                } footer: {
                    if ahead.contains(where: { $0.auto == true }) {
                        Text("A deposit that renews on its own starts a new term on the day it matures, unless you tell the bank otherwise.")
                    }
                }
                Section {
                    if closed.isEmpty {
                        Text("Nothing closed between " + Day.fmt(dd.closed.from, "d MMM yyyy") + " and " + Day.fmt(dd.closed.to, "d MMM yyyy") + ".").font(.subheadline).foregroundStyle(.secondary)
                    }
                    ForEach(closed, id: \.key) { d in
                        Button { store.openDepositDate(d) } label: { DepositDateRow(d: d, closed: true, showWho: p == .family) }
                    }
                } header: {
                    HStack {
                        Text("Closed, " + closedSpan)
                        Spacer()
                        if back > 0 { Text(Fmt.words(back)).monospacedDigit().privacySensitive() }
                    }
                } footer: {
                    Text("From your banks’ mail and the deposits you added. What came back is the bank’s credit for it.")
                }
            }
            .listStyle(.insetGrouped)
            .navigationTitle("Maturities and closures")
            .obsidianPage()
        } else {
            ContentUnavailableView("No deposits yet", systemImage: "building.columns",
                                   description: Text("Deposits your bank emails about appear here as they mature or close."))
                .obsidianPage()
        }
    }
}
