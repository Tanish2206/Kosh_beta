/* kosh trips: a booking's journey read from its mail, and the trips the bookings make, drafted as chapters.

   tripLegsJSON(msg, kind, provider)   one travel mail → where and when ({ k, p, from, to, on, until, place, ref, amt,
                                       off }), or "null" when it books nothing (an offer, a survey, a newsletter).
                                       Flights, trains and buses by their places (airport codes and towns, in the
                                       order the mail gives them) and the day of travel (never the day it was booked);
                                       stays by their town and their check-in and check-out.
   (postBuild) snap.tripDrafts         the bookings (prof.tripLegs, read by the phone's trip pass: LiveSession+Extras
                                       tripPass) grouped into trips: out from home and back, the stays between, each
                                       a draft ("A trip to Goa, 3 – 7 Dec?") with the payments that booked it (pay)
                                       and what was spent on its days that looks like the trip's (near: food, stays,
                                       cabs there, forex bought in the month before), and the days they run over
                                       (payFrom, payTo); never one that's already a chapter of yours or one you said
                                       wasn't a trip.

   Loaded after engine.js and packs.js, outside the reading's fingerprint (ReadingPrint.mail): a change here never
   reads the year's mail again; the trip pass reads only the travel mail, by its own fingerprint. */
(function (E) {
  'use strict';
  if (!E) return;

  var AIRPORTS = {
    DEL: 'Delhi', BOM: 'Mumbai', BLR: 'Bangalore', MAA: 'Chennai', CCU: 'Kolkata', HYD: 'Hyderabad', PNQ: 'Pune', IXC: 'Chandigarh',
    GOX: 'Goa', COK: 'Kochi', AMD: 'Ahmedabad', LKO: 'Lucknow', ATQ: 'Amritsar', SXR: 'Srinagar',
    IXB: 'Bagdogra', GAU: 'Guwahati', IXZ: 'Port Blair', TRV: 'Thiruvananthapuram', VNS: 'Varanasi', BBI: 'Bhubaneswar',
    IDR: 'Indore', NAG: 'Nagpur', CJB: 'Coimbatore', IXE: 'Mangalore', IXM: 'Madurai', UDR: 'Udaipur', DED: 'Dehradun', IXL: 'Leh',
    JDH: 'Jodhpur', BDQ: 'Vadodara', STV: 'Surat', RPR: 'Raipur', IXR: 'Ranchi', VTZ: 'Visakhapatnam', TIR: 'Tirupati', IXJ: 'Jammu',
    DHM: 'Dharamshala', KUU: 'Kullu', BHO: 'Bhopal', IXA: 'Agartala', IMF: 'Imphal', HBX: 'Hubli', PBH: 'Paro',
    KTM: 'Kathmandu', CMB: 'Colombo', DXB: 'Dubai', AUH: 'Abu Dhabi', DOH: 'Doha', SIN: 'Singapore', BKK: 'Bangkok',
    HKT: 'Phuket', DPS: 'Bali', KUL: 'Kuala Lumpur', LHR: 'London', CDG: 'Paris', FRA: 'Frankfurt', JFK: 'New York', EWR: 'New York',
    SFO: 'San Francisco', YYZ: 'Toronto', SYD: 'Sydney', MEL: 'Melbourne', NRT: 'Tokyo', HND: 'Tokyo', ICN: 'Seoul', AMS: 'Amsterdam', ZRH: 'Zurich', HKG: 'Hong Kong', MRU: 'Mauritius', SEZ: 'Seychelles', DAC: 'Dhaka', SGN: 'Ho Chi Minh City'
  };
  // towns by the names mail writes them, each to the name kosh shows
  var TOWNS = [
    ['new delhi', 'Delhi'], ['delhi', 'Delhi'], ['mumbai', 'Mumbai'], ['bombay', 'Mumbai'], ['bengaluru', 'Bangalore'], ['bangalore', 'Bangalore'],
    ['chennai', 'Chennai'], ['kolkata', 'Kolkata'], ['hyderabad', 'Hyderabad'], ['pune', 'Pune'], ['chandigarh', 'Chandigarh'], ['goa', 'Goa'],
    ['kochi', 'Kochi'], ['cochin', 'Kochi'], ['ahmedabad', 'Ahmedabad'], ['jaipur', 'Jaipur'], ['lucknow', 'Lucknow'], ['amritsar', 'Amritsar'],
    ['srinagar', 'Srinagar'], ['guwahati', 'Guwahati'], ['varanasi', 'Varanasi'], ['udaipur', 'Udaipur'], ['dehradun', 'Dehradun'], ['leh', 'Leh'],
    ['jodhpur', 'Jodhpur'], ['jaisalmer', 'Jaisalmer'], ['gurugram', 'Gurugram'], ['gurgaon', 'Gurugram'], ['noida', 'Noida'], ['mysuru', 'Mysore'],
    ['mysore', 'Mysore'], ['ooty', 'Ooty'], ['munnar', 'Munnar'], ['manali', 'Manali'], ['shimla', 'Shimla'], ['rishikesh', 'Rishikesh'],
    ['haridwar', 'Haridwar'], ['mussoorie', 'Mussoorie'], ['nainital', 'Nainital'], ['alibaug', 'Alibaug'], ['lonavala', 'Lonavala'],
    ['coorg', 'Coorg'], ['pondicherry', 'Puducherry'], ['puducherry', 'Puducherry'], ['agra', 'Agra'], ['indore', 'Indore'], ['bhopal', 'Bhopal'],
    ['nagpur', 'Nagpur'], ['surat', 'Surat'], ['vadodara', 'Vadodara'], ['coimbatore', 'Coimbatore'], ['madurai', 'Madurai'],
    ['mangalore', 'Mangalore'], ['mangaluru', 'Mangalore'], ['thiruvananthapuram', 'Thiruvananthapuram'], ['trivandrum', 'Thiruvananthapuram'],
    ['bhubaneswar', 'Bhubaneswar'], ['gangtok', 'Gangtok'], ['darjeeling', 'Darjeeling'], ['shillong', 'Shillong'],
    ['port blair', 'Port Blair'], ['dharamshala', 'Dharamshala'], ['kasauli', 'Kasauli'], ['ambala', 'Ambala'], ['ludhiana', 'Ludhiana'],
    ['mohali', 'Mohali'], ['panchkula', 'Panchkula'], ['dubai', 'Dubai'], ['singapore', 'Singapore'], ['bangkok', 'Bangkok'], ['phuket', 'Phuket'],
    ['bali', 'Bali'], ['london', 'London'], ['paris', 'Paris'], ['colombo', 'Colombo'], ['kathmandu', 'Kathmandu'], ['paro', 'Paro'],
    ['thimphu', 'Thimphu'], ['maldives', 'Maldives']
  ];
  var CODE_RE = new RegExp('\\b(' + Object.keys(AIRPORTS).join('|') + ')\\b', 'g');
  var TOWN_RE = new RegExp('\\b(' + TOWNS.map(function (t) { return t[0].replace(/ /g, '\\s+'); }).join('|') + ')\\b', 'gi');
  var TOWN_OF = {};
  TOWNS.forEach(function (t) { TOWN_OF[t[0]] = t[1]; });

  var MON = { jan: 1, feb: 2, mar: 3, apr: 4, may: 5, jun: 6, jul: 7, aug: 8, sep: 9, sept: 9, oct: 10, nov: 11, dec: 12 };
  var MONS = '(jan|feb|mar|apr|may|jun|jul|aug|sept?|oct|nov|dec)[a-z]*\\.?';
  // "23 Dec 2025", "11 Jan 26", "25-Jun-26", "11Jan2026", "03Dec25"
  var D_DMY = new RegExp('\\b(\\d{1,2})(?:st|nd|rd|th)?[\\s\\-\\/]?' + MONS + '[\\s\\-,\\/\']*(\\d{4}|\\d{2})?(?![\\d:])', 'gi');
  // "January 11, 2026", "Sep 14", "DEC 23"
  var D_MDY = new RegExp('\\b' + MONS + '\\s+(\\d{1,2})(?:st|nd|rd|th)?(?:,?\\s+(\\d{4}))?\\b', 'gi');
  var D_ISO = /\b(20\d\d)-(\d\d)-(\d\d)\b/g;
  var D_NUM = /\b(\d{1,2})[\/.](\d{1,2})[\/.](20\d\d)\b/g;
  // a stay's span written once: "September 14 – 15", "14 – 15 Sep"
  var SPAN_MD = new RegExp('\\b' + MONS + '\\s+(\\d{1,2})\\s*[–\\-]\\s*(\\d{1,2})\\b', 'i');
  var SPAN_DM = new RegExp('\\b(\\d{1,2})\\s*[–\\-]\\s*(\\d{1,2})\\s+' + MONS, 'i');
  // a day that isn't the day of travel: when it was booked, paid, issued
  var NOT_TRAVEL_DAY = /(?:book(?:ed|ing)?\s*(?:on|date)|date of booking|booking date|(?:time|date) of booking|of booking\s*:?|booking time|issued?(?: on)?|invoice date|paid on|payment (?:date|on)|transaction date|generated on|printed on|cancel+ation|valid till|valid until|expires?)(?:\W{0,4}(?:mon|tue|wed|thu|fri|sat|sun)[a-z]*)?\W{0,8}$/i;
  // a mail that books something, and one that only sells
  var BOOKED = /\bpnr\b|booking (?:id|ref|reference|no|number|status|is confirmed|confirmed)|trip id|confirmation (?:code|number|no)|\be-?tickets?\b|itinerary|boarding pass|check-?in (?:is complete|confirmation)|reservation (?:for|confirmed|number)|you(?:'|’)re all set|your (?:booking|trip|flight|stay|journey)|tax ?invoice|receipt|is confirmed/i;
  var SELLS = /\b(?:offers?|sale|deals?|save|discount|escape|explore|calling|holidays? packages?|packages?|tour packages?|newsletter|rate your|review|survey|feedback|limited time|flat \d|% off|refer|earn|points?|membership|welcome)\b/i;
  var REF_RE = /\b(?:pnr(?: no\.?| number)?|booking (?:id|ref(?:erence)?|no\.?|number)|trip id|confirmation (?:code|number|no\.?)|e-?ticket (?:no\.?|number))\s*[:\-#.]?\s*[A-Z0-9<][A-Z0-9<>\-]{4,}/i;
  // the day of travel where the mail labels it
  var DAY_LABEL = /\b(?:date of (?:journey|travel|departure|boarding|flight)|departure date|travel date|journey date|date of boarding|departs? on|departing on|check-?in(?: date)?)\b\s*[:\-]?\s*/i;
  // a journey's places where the mail labels them: "From : CHANDIGARH (CDG) … To : DELHI (DLI)"
  var FROM_LABEL = /\bfrom\s*[:\-]\s*([a-z][a-z .]{1,30}?)\s*(?:\(|date|$|\bto\b)/i;
  var TO_LABEL = /\bto\s*[:\-]\s*([a-z][a-z .]{1,30}?)\s*(?:\(|boarding|date|$)/i;
  var OFF = /\bcancel+ed\b|\bcancel+ation (?:confirmed|successful)|booking (?:status\s*:?\s*)?failed|\bfailed\b|\brefund\b/i;

  function iso(y, m, d) { return y + '-' + (m < 10 ? '0' : '') + m + '-' + (d < 10 ? '0' : '') + d; }
  function valid(y, m, d) { if (!(m >= 1 && m <= 12 && d >= 1 && d <= 31)) return ''; var t = new Date(Date.UTC(y, m - 1, d)); return t.getUTCMonth() === m - 1 ? iso(y, m, d) : ''; }
  // a day with no year: the next one on or after a week before the mail
  function withYear(m, d, sent) {
    var y = +sent.slice(0, 4);
    var a = valid(y, m, d);
    if (a && a < shift(sent, -7)) a = valid(y + 1, m, d);
    return a;
  }
  function shift(day, n) { var t = new Date(day + 'T00:00:00Z'); t.setUTCDate(t.getUTCDate() + n); return t.toISOString().slice(0, 10); }
  function days(a, b) { return Math.round((Date.parse(b + 'T00:00:00Z') - Date.parse(a + 'T00:00:00Z')) / 86400000); }
  function year(s) { var y = +s; return y < 100 ? 2000 + y : y; }

  /* every day the text names, where it is, never one written as the day it was booked or paid */
  function datesIn(text, sent) {
    var out = [], m;
    function add(at, day, len) {
      if (!day) return;
      if (NOT_TRAVEL_DAY.test(text.slice(Math.max(0, at - 40), at))) return;
      out.push({ at: at, d: day, end: at + len });
    }
    D_DMY.lastIndex = 0;
    while ((m = D_DMY.exec(text))) add(m.index, m[3] ? valid(year(m[3]), MON[m[2].toLowerCase().slice(0, 3)], +m[1]) : withYear(MON[m[2].toLowerCase().slice(0, 3)], +m[1], sent), m[0].length);
    D_MDY.lastIndex = 0;
    while ((m = D_MDY.exec(text))) add(m.index, m[3] ? valid(+m[3], MON[m[1].toLowerCase().slice(0, 3)], +m[2]) : withYear(MON[m[1].toLowerCase().slice(0, 3)], +m[2], sent), m[0].length);
    D_ISO.lastIndex = 0;
    while ((m = D_ISO.exec(text))) add(m.index, valid(+m[1], +m[2], +m[3]), m[0].length);
    D_NUM.lastIndex = 0;
    while ((m = D_NUM.exec(text))) add(m.index, valid(+m[3], +m[2], +m[1]), m[0].length);
    // (a day is a day of travel only from a little before the mail to a year and a bit after it)
    return out.filter(function (x) { return x.d >= shift(sent, -3) && x.d <= shift(sent, 420); }).sort(function (a, b) { return a.at - b.at; });
  }

  /* the places the text names, in order: airport codes (in capitals) and towns */
  function placesIn(text, air) {
    var out = [], m;
    CODE_RE.lastIndex = 0;
    while (air !== false && (m = CODE_RE.exec(text))) out.push({ at: m.index, p: AIRPORTS[m[1]] });
    TOWN_RE.lastIndex = 0;
    while ((m = TOWN_RE.exec(text))) out.push({ at: m.index, p: TOWN_OF[m[1].toLowerCase().replace(/\s+/g, ' ')] });
    return out.sort(function (a, b) { return a.at - b.at; });
  }
  // a labelled place as kosh names it: a known town, else the words themselves in ordinary case
  function townName(raw) {
    var w = String(raw || '').trim().toLowerCase().replace(/\s+/g, ' ');
    if (!w || w.length < 3) return '';
    TOWN_RE.lastIndex = 0;
    var m = TOWN_RE.exec(w);
    if (m) return TOWN_OF[m[1].toLowerCase().replace(/\s+/g, ' ')];
    return w.replace(/\b[a-z]/g, function (c) { return c.toUpperCase(); });
  }
  function route(list) {
    var from = '', to = '', at = -1;
    for (var i = 0; i < list.length; i++) {
      if (!from) { from = list[i].p; at = list[i].at; continue; }
      if (list[i].p !== from) { to = list[i].p; break; }
    }
    return to ? { from: from, to: to, at: at } : null;
  }

  function legsOf(msg, kind, provider) {
    var subj = String(msg.subject || '');
    var text = String(E.lib && E.lib.normalize ? E.lib.normalize(msg.text || '', msg.html || '') : (msg.text || ''));
    // (links carry dates and towns of their own: a hotel offer's "checkin=2026-01-11" is no stay of yours)
    text = text.replace(/https?:\/\/\S+|\S*[?&][a-z_]+=\S*/gi, ' ').replace(/\s+/g, ' ').slice(0, 6000);
    var sent = String(msg.date || '').slice(0, 10);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(sent)) return null;
    var head = subj + ' \n ' + text.slice(0, 1500);
    // (booked: the subject says so, or the mail gives the booking's reference; an offer that only mentions booking doesn't)
    if (!BOOKED.test(subj) && !REF_RE.test(head)) return null;
    if (SELLS.test(subj) && !/\bpnr\b|e-?ticket|booking (?:id|confirmed)|itinerary|boarding pass|receipt|invoice/i.test(subj)) return null;
    if (kind === 'cab') return null;
    var leg = { k: kind || '', p: provider || '' };
    if (!leg.k) leg.k = /\bcheck-?in\b[\s\S]{0,80}\bcheck-?out\b|\bnights?\b|\bhotel\b|\bstay\b|\bhosted by\b/i.test(head) ? 'stay' : /\btrain\b|\bpnr\b.*\bberth\b|\birctc\b/i.test(head) ? 'train' : /\bbus\b|boarding point/i.test(head) ? 'bus' : /\bflight\b|\bairport\b|\bairlines?\b/i.test(head) ? 'flight' : '';
    if (OFF.test(subj) || OFF.test(text.slice(0, 600))) leg.off = 'cancelled';
    var m = /\b(?:pnr|booking (?:id|ref(?:erence)?)|trip id|confirmation (?:code|number))\s*[:\-#]?\s*([A-Z0-9]{5,14})\b/i.exec(head);
    if (m) leg.ref = m[1];
    if (leg.k === 'stay') {
      var span = SPAN_MD.exec(subj) || SPAN_MD.exec(text.slice(0, 2000));
      if (span) { leg.on = withYear(MON[span[1].toLowerCase().slice(0, 3)], +span[2], sent); leg.until = withYear(MON[span[1].toLowerCase().slice(0, 3)], +span[3], sent); }
      else if ((span = SPAN_DM.exec(subj) || SPAN_DM.exec(text.slice(0, 2000)))) { leg.on = withYear(MON[span[3].toLowerCase().slice(0, 3)], +span[1], sent); leg.until = withYear(MON[span[3].toLowerCase().slice(0, 3)], +span[2], sent); }
      if (!leg.on) {
        var ci = /\bcheck-?in\b/i.exec(text);
        var ds = datesIn(ci ? text.slice(ci.index) : text, sent);
        if (ds.length) { leg.on = ds[0].d; var co = ds.filter(function (x) { return x.d > ds[0].d; })[0]; if (co) leg.until = co.d; }
      }
      if (leg.until && leg.until < leg.on) delete leg.until;
      var pl = placesIn(subj).concat(placesIn(text.slice(0, 2500)));
      if (pl.length) leg.place = pl[0].p;
      return leg.on && leg.place ? leg : null;
    }
    // a journey: where the mail labels its places ("From : … To : …"), else its places in order (the subject first:
    // "IXC-PNQ", "Pune - New Delhi"). A railway's and a bus's codes aren't airports' (CDG is Chandigarh by train)
    var air = leg.k !== 'train' && leg.k !== 'bus';
    var r = null, fl = FROM_LABEL.exec(text.slice(0, 3000)), tl = fl ? TO_LABEL.exec(text.slice(fl.index + fl[0].length, fl.index + 600)) : null;
    if (fl && tl) {
      var f1 = townName(fl[1]), t1 = townName(tl[1]);
      if (f1 && t1 && f1 !== t1) r = { from: f1, to: t1, at: fl.index };
    }
    var inSubj = false;
    if (!r) { r = route(placesIn(subj, air)); inSubj = !!r; }
    if (!r) r = route(placesIn(text.slice(0, 3000), air));
    if (!r) return null;
    leg.from = r.from;
    leg.to = r.to;
    // the day: where the mail labels it, else in the subject, else by the journey (from just before its first place,
    // as a table puts the day in the row's first cell)
    var lab = DAY_LABEL.exec(text), ds = lab ? datesIn(text.slice(lab.index + lab[0].length, lab.index + lab[0].length + 40), sent) : [];
    if (!ds.length) ds = datesIn(subj, sent);
    if (!ds.length) ds = datesIn(inSubj ? text : text.slice(Math.max(0, r.at - 60)), sent);
    if (!ds.length) return null;
    leg.on = ds[0].d;
    m = /\b(?:total|amount paid|grand total|total fare|total amount)\b[^₹\d]{0,20}(?:₹|rs\.?|inr)?\s?([\d,]+(?:\.\d{1,2})?)/i.exec(text);
    if (m) { var a = +m[1].replace(/,/g, ''); if (a > 0 && a < 1e7) leg.amt = a; }
    return leg;
  }

  E.tripLegsJSON = function (msg, kind, provider) {
    try { return JSON.stringify(legsOf(JSON.parse(msg), kind || '', provider || '')); } catch (e) { return 'null'; }
  };

  /* ------------------------------------------------------------ the bookings, grouped into trips */
  function drafts(snap, prof) {
    var legs = [];
    var by = prof.tripLegs || {};
    Object.keys(by).forEach(function (id) { var l = by[id]; if (l && l.on && !l.off && (l.to || l.place)) legs.push(Object.assign({ id: id }, l)); });
    if (!legs.length) return [];
    // one booking told by many mails (the airline's, the agency's, a ticket for each traveller): one leg
    var seen = {};
    legs = legs.sort(function (a, b) { return a.on.localeCompare(b.on) || String(a.id).localeCompare(String(b.id)); }).filter(function (l) {
      var key = l.k === 'stay' ? 'stay|' + l.place + '|' + l.on : (l.from + '>' + l.to + '|' + l.on);
      if (seen[key]) { seen[key].ids.push(l.id); return false; }
      l.ids = [l.id];
      seen[key] = l;
      return true;
    });
    /* a trip: a journey out, what follows it from where it arrived (on, or back), and the stays between, within a
       month; a stay or a journey within two days of the trip's end is part of it. Its town is where the first journey
       went (or the first stay's). No home needs knowing: out and back between two towns is a trip to the second */
    var trips = [], cur = null;
    legs.forEach(function (l) {
      var end = l.until || l.on;
      var chain = cur && !cur.closed && l.from && cur.at && l.from === cur.at && days(cur.start, l.on) <= 30;
      var near = cur && l.on <= shift(cur.end, 2);
      if (cur && (chain || near)) {
        cur.legs.push(l);
        if (end > cur.end) cur.end = end;
        if (l.to) cur.at = l.to;
        if (l.to && l.to === cur.origin) cur.closed = true;
        return;
      }
      cur = { start: l.on, end: end, legs: [l], origin: l.from || '', at: l.to || l.place || '' };
      trips.push(cur);
    });
    var home = '';
    var mine = (prof.trips || []).filter(function (x) { return x && x.from; });
    var off = prof.tripDraftsOff || [];
    var tx = snap.tx || [];
    var out = [];
    /* what was spent around a trip that looks like the trip's, offered with the draft so one tap files it all (each
       payment yours to untick). The same rule as a chapter's own days (engine/21b-build-payments.js tripFor), so what's
       offered is what the chapter would take: money out on its days, never life at home (rent, bills, EMIs,
       subscriptions, insurance, tax, fees, family support, what's bought for the home), never one already in a
       chapter; a shop or person you pay on two or more other days in the 90 days around it is home's; a payment that
       names the trip's town goes in, one that names the town it left from stays out; travel and cabs always go in.
       And forex bought in the month before it (a forex card's load, a markup) */
    var STAY_HOME = { Home: 1, Bills: 1, Subscriptions: 1, EMI: 1, Insurance: 1, Tax: 1, Education: 1, 'Family Support': 1 };
    var FOREX = /\bforex\b|foreign exchange|currency exchange|multi-?currency|travel ?card|\bfx card\b/i;
    var dayOf = function (x) { return String(x.od || x.d || ''); };
    var payKey = function (x) { var v = String(x.vpa || '').toLowerCase(); return v.indexOf('@') > 0 ? 'v:' + v : 'n:' + String(x.m || '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim(); };
    // (a payment you said is in no chapter, whatever its day, is never offered)
    var over = prof.overrides || {};
    var unfiled = function (x) { return (over[x.id] || {}).tr === 'none' || (x.partOf && (over[x.partOf] || {}).tr === 'none'); };
    var spends = tx.filter(function (x) { return x.k === 'out' && x.dr !== 'in' && !x.ex && x.a > 0 && !x.refOf; });
    var daysOf = {};
    spends.forEach(function (x) { var k = payKey(x); if (k.length > 3) (daysOf[k] = daysOf[k] || []).push(dayOf(x)); });
    function townIn(s) { TOWN_RE.lastIndex = 0; var m = TOWN_RE.exec(String(s || '')); return m ? TOWN_OF[m[1].toLowerCase().replace(/\s+/g, ' ')] || '' : ''; }
    function homePayee(x, from, to) {
      var lo = shift(from, -90), hi = shift(to, 90), seen = {};
      (daysOf[payKey(x)] || []).forEach(function (d) { if (d >= lo && d <= hi && (d < from || d > to)) seen[d] = 1; });
      return Object.keys(seen).length >= 2;
    }
    function around(from, to, dest, origin, taken) {
      var runUp = shift(from, -30);
      return spends.filter(function (x) {
        var d = dayOf(x);
        if (x.tr || taken[x.id] || x.nc === 'unnamed' || unfiled(x)) return false;
        if (d >= runUp && d < from) return FOREX.test(String(x.m || '') + ' ' + String(x.s || '')) || x.s === 'Forex markup';
        if (d < from || d > to) return false;
        if (STAY_HOME[x.c] || x.f === 'home') return false;
        if (x.c === 'Hidden Charges' && x.s !== 'Forex markup') return false;
        var town = townIn(x.m);
        if (town && town === dest) return true;
        if (town && origin && town === origin && origin !== dest) return false;
        if (x.c === 'Travel' || x.s === 'Cabs') return true;
        return !homePayee(x, from, to);
      }).sort(function (a, b) { return dayOf(a).localeCompare(dayOf(b)) || String(a.id).localeCompare(String(b.id)); }).slice(0, 80);
    }
    // where the trip was: the town it spent the most nights in (a connection, the same day or the next, is only
    // passed through; the last arrival keeps the trip's remaining days; a stay counts its own nights)
    function destOf(t) {
      var first = t.legs[0], nights = {};
      t.legs.forEach(function (l, i) {
        if (l.k === 'stay' && l.place) { nights[l.place] = (nights[l.place] || 0) + Math.max(1, days(l.on, l.until || l.on)); return; }
        if (!l.to) return;
        var next = t.legs.slice(i + 1).filter(function (x) { return x.k !== 'stay'; })[0];
        var n = next ? days(l.on, next.on) : Math.max(1, days(l.on, t.end));
        if (n >= 1) nights[l.to] = (nights[l.to] || 0) + n;
      });
      var dest = Object.keys(nights).filter(function (x) { return x !== t.origin; }).sort(function (a, b) { return nights[b] - nights[a]; })[0] || (first.k === 'stay' ? first.place : first.to);
      return !dest || dest === first.from ? '' : dest;
    }
    function idOf(t) { var dest = destOf(t); return t.keepId || (dest ? 'draft:' + t.start + ':' + dest.toLowerCase().replace(/[^a-z]+/g, '-') : ''); }
    function group(legs0, origin) {
      var g = { legs: legs0, start: legs0[0].on, end: legs0[0].until || legs0[0].on, origin: origin || legs0[0].from || '' };
      legs0.forEach(function (l) { if ((l.until || l.on) > g.end) g.end = l.until || l.on; });
      return g;
    }
    /* your word on a draft, learnt for good (it rides every build): split in two at a day (prof.tripSplit: { <draft id>:
       <the second part's first day> }), two drafts joined into one (prof.tripJoin: ["<id>|<id>"], the earlier's id kept),
       a draft renamed (prof.tripNames: { <draft id>: <name> }). Not a trip is prof.tripDraftsOff, as before */
    var splitAt = prof.tripSplit || {}, joins = (prof.tripJoin || []).map(function (x) { return String(x).split('|'); }).filter(function (x) { return x.length === 2; }), names = prof.tripNames || {};
    if (Object.keys(splitAt).length) {
      trips = [].concat.apply([], trips.map(function (t) {
        var day = splitAt[idOf(t)];
        if (!day) return [t];
        var a = t.legs.filter(function (l) { return l.on < day; }), b = t.legs.filter(function (l) { return l.on >= day; });
        return a.length && b.length ? [group(a, t.origin), group(b, a[a.length - 1].to || t.origin)] : [t];
      }));
    }
    joins.forEach(function (pair) {
      var A = trips.filter(function (t) { return idOf(t) === pair[0]; })[0], B = trips.filter(function (t) { return idOf(t) === pair[1]; })[0];
      if (!A || !B || A === B) return;
      var keep = idOf(A.start <= B.start ? A : B), into = A.start <= B.start ? A : B, other = into === A ? B : A;
      into.legs = into.legs.concat(other.legs).sort(function (x, y) { return x.on.localeCompare(y.on); });
      if (other.end > into.end) into.end = other.end;
      into.keepId = keep;
      trips = trips.filter(function (t) { return t !== other; });
    });
    trips.forEach(function (t) {
      var dest = destOf(t);
      if (!dest) return;
      var id = idOf(t);
      if (off.indexOf(id) >= 0) return;
      if (mine.some(function (x) { return x.from <= t.end && (x.to || x.from) >= t.start; })) return;
      var ids = [];
      t.legs.forEach(function (l) { ids = ids.concat(l.ids); });
      var pay = tx.filter(function (x) { return ids.indexOf(String(x.id).split('#')[0]) >= 0 && x.k === 'out'; });
      // (and the payment that booked each: travel paid the day its mail came, to the site that sent it)
      var squash = function (v) { return String(v || '').toLowerCase().replace(/[^a-z]/g, ''); };
      t.legs.forEach(function (l) {
        if (!l.p) return;
        // (the site by its whole name, "airindia", "cleartrip"; or its first word when that is its own, "indigo")
        var whole = squash(l.p), first = squash(l.p.split(/\s+/)[0]), two = squash(l.p.split(/\s+/).slice(0, 2).join(''));
        tx.forEach(function (x) {
          if (x.k !== 'out' || pay.indexOf(x) >= 0) return;
          var sent = String((by[l.ids[0]] || {}).sent || '');
          var name = squash(x.m) + ' ' + squash(x.py);
          if (name.indexOf(whole) < 0 && !(two.length >= 7 && two !== whole && name.indexOf(two) >= 0) && !(first.length >= 5 && !/^(?:example|travel|trips?|hotels?|flights?)$/.test(first) && name.indexOf(first) >= 0)) return;
          if (sent && Math.abs(days(sent, x.d)) > 1) return;
          if (!sent && (x.d > t.start || days(x.d, t.start) > 90)) return;
          pay.push(x);
        });
      });
      var kinds = {};
      t.legs.forEach(function (l) { kinds[l.k || 'trip'] = (kinds[l.k || 'trip'] || 0) + 1; });
      var taken = {};
      pay.forEach(function (x) { taken[x.id] = 1; });
      var near = around(t.start, t.end, dest, t.origin || '', taken);
      // (the days the payments offered with it run over, for the total to say)
      var all = pay.concat(near).map(dayOf).filter(Boolean).sort();
      var d0 = { id: id, name: names[id] ? String(names[id]).slice(0, 60) : 'A trip to ' + dest, place: dest, from: t.start, to: t.end, home: t.origin || home, legs: t.legs.length, kinds: kinds,
        paid: Math.round(pay.reduce(function (a, x) { return a + (x.a || 0); }, 0)), pay: pay.map(function (x) { return x.id; }) };
      if (near.length) { d0.near = near.map(function (x) { return x.id; }); d0.nearPaid = Math.round(near.reduce(function (a, x) { return a + (x.a || 0); }, 0)); }
      if (all.length) { d0.payFrom = all[0]; d0.payTo = all[all.length - 1]; }
      if (names[id]) d0.named = true;
      if (t.keepId) d0.joined = true;
      out.push(d0);
    });
    // the last year's and what's ahead, newest first
    var since = shift(String(prof.today || snap.today || '').slice(0, 10) || new Date().toISOString().slice(0, 10), -365);
    return out.filter(function (d) { return d.to >= since; }).sort(function (a, b) { return b.from.localeCompare(a.from); }).slice(0, 12);
  }

  if (E.postBuild) E.postBuild.push(function (snap, prof) { snap.tripDrafts = drafts(snap, prof || {}); });
  E.tripDrafts = drafts;
})(typeof KoshEngine !== 'undefined' ? KoshEngine : require('./engine.js'));
