import SwiftUI
import WidgetKit

// MARK: - The widgets' side of the app: what they're handed after each rebuild, and where a tap lands

@MainActor
enum WidgetLink {
    /// write what the widgets show and ask them to draw again. Nothing is written until the phone's own
    /// files have been read in: kosh may have started while the phone was locked, and an empty ledger
    /// would blank the widgets.
    static func publish(_ store: Store) {
        guard let live = store.live, live.loadedFromDisk else { return }
        let f: WFeed = feed(store)
        // (while mail is read this runs every few seconds: the feed is written and the widgets redrawn only when what
        // they show changed. When it was made is left out of the comparison, since no widget shows it)
        var same: WFeed = f
        same.made = .distantPast
        let enc = JSONEncoder()
        enc.outputFormatting = .sortedKeys
        let bytes: Data? = try? enc.encode(same)
        if let bytes, bytes == lastFeed, let url = WFStore.file, FileManager.default.fileExists(atPath: url.path) { return }
        WFStore.write(f)
        lastFeed = bytes
        WidgetCenter.shared.reloadAllTimelines()
    }
    /// what was last written, as compared above
    private static var lastFeed: Data?

    static func feed(_ store: Store) -> WFeed {
        let s: Snapshot = store.snap.whole
        let isEmpty: Bool = s.tx.isEmpty && s.accounts.isEmpty && s.cards.isEmpty
        var f = WFeed(made: Date(), today: s.today, empty: isEmpty, month: month(store), cats: cats(s), due: due(s),
                      worth: worth(store), cards: cards(s), banks: banks(s), recent: recent(s), noticed: noticed(s),
                      people: people(store), owedIn: owed(store, "in"), owedOut: owed(store, "out"))
        f.chapter = chapter(store)
        f.rent = rent(s)
        return f
    }

    /// the chapter Home would show; failing that, the next one within six weeks
    static func chapter(_ store: Store) -> WFChapter? {
        let today: String = store.snap.today
        var t: TripInfo? = store.homeTrip
        if t == nil {
            t = store.trips.filter { $0.state == "soon" && !$0.from.isEmpty && Day.between(today, $0.from) <= 45 }.sorted { $0.from < $1.from }.first
        }
        guard let c = t else { return nil }
        return WFChapter(id: c.id, name: c.name, from: c.from, to: c.to, state: c.state, total: c.total, budget: c.budget,
                         days: c.days, sym: c.sym, color: c.color, event: c.isEvent)
    }

    /// each let floor's rent this month, by the floor's own name (never the tenant's)
    static func rent(_ s: Snapshot) -> WFRent? {
        var units: [WFRentUnit] = []
        var expected: Double = 0
        var received: Double = 0
        for p in s.prop.props {
            for u in p.units where u.rent > 0 && !u.tenant.isEmpty && (u.status ?? "let") == "let" {
                let st: String = u.now?.st ?? ""
                expected += u.rent
                if st == "booked" { received += u.rent }
                units.append(WFRentUnit(label: u.label.isEmpty ? u.code : u.label, rent: u.rent, st: st, late: u.now?.late ?? 0))
            }
        }
        if units.isEmpty { return nil }
        return WFRent(expected: expected, received: received, units: units)
    }

    /// the running month: spent, the forecast, each day so far, and last month alongside
    static func month(_ store: Store) -> WFMonth {
        let s: Snapshot = store.snap.whole
        let F: Forecast = s.fc
        let cur: MonthInfo? = store.current
        var cum: [Double] = []
        if let mo = cur {
            for p in store.actualPoints(mo) { cum.append(p.v) }
        } else {
            cum = F.actual
        }
        let days: [Double] = steps(cum)
        var ahead: [Double] = []
        for p in store.forecastPoints() { ahead.append(p.v) }
        var prevM: String = ""
        var prevName: String = ""
        var prevCum: [Double] = []
        if let mo = cur, let p = mo.prev, let pm = store.month(p) {
            prevM = pm.m
            prevName = pm.name
            prevCum = pm.cum
        }
        var today: Double = 0
        var n: Int = 0
        for t in s.tx where t.sp && t.d.hasPrefix(s.cm) {
            n += 1
            if t.d == s.today { today += t.a }
        }
        let short: String = cur?.short ?? ""
        let own: Bool = F.own ?? false
        return WFMonth(m: s.cm, name: store.monthName, short: short, d: F.d, dim: F.dim,
                       spent: store.spentNow, likely: store.likelyNow, usual: F.usual, budget: F.budget,
                       left: store.leftNow, own: own, today: today, payments: n,
                       days: days, cum: cum, ahead: ahead,
                       prevM: prevM, prevName: prevName, prevDays: steps(prevCum), prevCum: prevCum)
    }
    /// a running total back into each day's own amount
    static func steps(_ cum: [Double]) -> [Double] {
        var out: [Double] = []
        var before: Double = 0
        for v in cum {
            out.append(max(0, v - before))
            before = v
        }
        return out
    }

    static func cats(_ s: Snapshot) -> [WFCat] {
        var out: [WFCat] = []
        for c in s.fc.cats where c.sofar > 0 {
            out.append(WFCat(name: c.cat, v: c.sofar, usual: c.usual, color: c.color, sym: c.sym))
        }
        out.sort { $0.v > $1.v }
        return out
    }

    /// bills, EMIs, premiums, card bills, committee instalments, rent: six weeks ahead, and this month's any-day ones
    static func due(_ s: Snapshot) -> [WFDue] {
        let end: String = Day.add(s.today, 45)
        var out: [WFDue] = []
        for a in s.agenda where !a.booked {
            if let d = a.date {
                if d < s.today || d > end { continue }
            } else if a.m != s.cm || a.lock {
                continue
            }
            out.append(WFDue(id: a.id, date: a.date, name: a.name, sub: a.sub, amt: a.amt, incoming: a.kind == "in",
                             cat: a.cat, sym: a.sym, color: dueColor(a, s)))
        }
        out.sort { x, y in
            let dx: String = x.date ?? "9999"
            let dy: String = y.date ?? "9999"
            if dx != dy { return dx < dy }
            return x.amt > y.amt
        }
        return out
    }
    static func dueColor(_ a: AgendaItem, _ s: Snapshot) -> String {
        if a.kind == "in" { return "#34C759" }
        if a.cat == "committee" { return "#5AC8FA" }
        return s.cats[a.cat]?.color ?? "#8E8E93"
    }

    /// the household's net worth and each person's: today, month by month, and its parts
    static func worth(_ store: Store) -> [WFWorth] {
        var out: [WFWorth] = []
        for p in store.whoOptions {
            var pts: [WFPoint] = []
            for x in store.worthSeries(p) { pts.append(WFPoint(m: x.m, v: x.v)) }
            var parts: [WFPart] = []
            for c in store.netClasses(p) { parts.append(WFPart(key: c.key, title: c.title, v: c.v)) }
            out.append(WFWorth(who: p.id, title: p.title, now: store.netWorth(p), debts: store.debts(p), points: pts, parts: parts))
        }
        return out
    }

    static func cards(_ s: Snapshot) -> [WFCard] {
        var out: [WFCard] = []
        for c in s.cards {
            let key: String = c.id.replacingOccurrences(of: " CC ", with: " card ")
            let b: AgendaItem? = CardFocus.bill(s.agenda, key: key)
            let product: String = c.product ?? ""
            let title: String = product.isEmpty ? c.name : product
            out.append(WFCard(id: c.id, bank: c.bank, name: title, last: c.last, network: c.network ?? "", color: c.color,
                              owner: c.owner, month: c.month, last30: c.last30, lastUsed: c.lastUsed,
                              bill: b?.amt, billDue: b?.date, billPaid: b?.booked ?? false))
        }
        out.sort { $0.month > $1.month }
        return out
    }

    static func banks(_ s: Snapshot) -> [WFBank] {
        var out: [WFBank] = []
        for a in s.accounts {
            let at: String = a.bal?.at ?? a.asOf
            out.append(WFBank(id: a.id, bank: a.bank, name: a.name, last: a.last, color: a.color, owner: a.owner,
                              balance: a.balance, asOf: at, src: a.bal?.src ?? "", month: a.month))
        }
        out.sort { ($0.balance ?? -1) > ($1.balance ?? -1) }
        return out
    }

    /// the newest payments out and in, whatever paid them
    static func recent(_ s: Snapshot) -> [WFTx] {
        var rows: [Txn] = []
        for t in s.tx where (t.k == "out" || t.k == "in") && t.partOf == nil { rows.append(t) }
        rows.sort { a, b in
            if a.d != b.d { return a.d > b.d }
            return a.t > b.t
        }
        var out: [WFTx] = []
        for t in rows.prefix(16) {
            let col: String = t.k == "in" ? "#34C759" : (s.cats[t.c]?.color ?? "#8E8E93")
            out.append(WFTx(id: t.id, d: t.d, t: t.t, name: t.m, a: t.a, kind: t.k, spend: t.sp, cat: t.c, sym: t.sym,
                            color: col, way: t.md ?? "", bank: t.bk ?? ""))
        }
        return out
    }

    static func noticed(_ s: Snapshot) -> [WFNote] {
        var out: [WFNote] = []
        for p in s.insights.patterns ?? [] {
            out.append(WFNote(id: p.id, title: p.title, detail: p.detail, sym: p.sym, color: p.color, tone: p.tone, amount: p.amount))
        }
        return out
    }

    static func people(_ store: Store) -> [WFPerson] {
        var out: [WFPerson] = []
        for p in store.whoOptions { out.append(WFPerson(id: p.id, title: p.title)) }
        return out
    }

    static func owed(_ store: Store, _ dir: String) -> Double {
        var sum: Double = 0
        for o in store.owed where !o.settled && o.dir == dir { sum += o.amount }
        return sum
    }

    // MARK: where a tap on a widget lands

    /// back from Shortcuts after kosh's test (AlertsTurnOn): a shortcut of that name ran, or there is none. Never the
    /// check passed: only "Add to kosh" hearing the test's words is that (AlertIntake.take), so an old copy whose filter
    /// or wiring drops them can't look set up (until 30 Oct it did)
    static func open(alert what: String) {
        UserDefaults.standard.set(Date().timeIntervalSince1970, forKey: what == "alerts-ok" ? AlertSetup.ranKey : AlertSetup.failedKey)
    }

    /// kosh://month, days, split, due, worth, cards, banks, latest, noticed, add
    static func open(_ url: URL, _ store: Store) {
        guard url.scheme == "kosh" else { return }
        let what: String = url.host ?? ""
        // (the setup's test coming back leaves whatever is open as it is)
        if what == "alerts-ok" || what == "alerts-failed" { open(alert: what); return }
        store.sheet = nil
        switch what {
        case "month", "days", "split":
            store.tab = .home
            store.homeSub = .overview
            store.homePath = [.month(store.snap.cm)]
        case "due":
            store.tab = .home
            store.homeSub = .overview
            store.homePath = [.calendar]
        case "worth":
            store.portSub = .overview
            store.land(.portfolio)
        case "cards", "banks":
            UserDefaults.standard.set(what == "cards" ? "cards" : "accounts", forKey: "accts.part")
            store.txSub = .accounts
            store.land(.transactions)
        case "latest":
            store.txSub = .all
            store.ledgerChapter = nil
            store.ledgerMonth = store.snap.cm
            store.land(.transactions)
        case "noticed":
            // what kosh noticed lives behind Home's bell
            store.tab = .home
            store.homeSub = .overview
            store.homePath = []
            store.betaSheet = .headsUp
        case "add":
            store.sheet = .add(nil)
        case "chapters":
            store.land(.chapters)
        case "rent":
            store.propSub = .tenants
            store.land(.property)
        default:
            break
        }
    }
}

/// Settings › Privacy: amounts on the widgets, the same switch as the eye on them
struct WidgetAmountsToggle: View {
    @AppStorage(WFStore.hiddenKey, store: WFStore.defaults) private var hidden = false
    var body: some View {
        Toggle(isOn: Binding(get: { !hidden }, set: { hidden = !$0 })) {
            SettingsRow(symbol: "rectangle.3.group.fill", color: Color(hex: "#FF9500"), title: "Amounts on widgets")
        }
            .onChange(of: hidden) { _, _ in WidgetCenter.shared.reloadAllTimelines() }
    }
}
