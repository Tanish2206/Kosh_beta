import SwiftUI

// MARK: - Rent, tagged on a payment's sheet
//
// Money in can be called rent from one tenant: the "Rent" mark among the kinds asks whose, from the tenants kosh knows
// (or adds one there and then). The tag is your override on that payment (Override.rent), so it holds through every
// re-read, and the engine learns from it the way it learns a payee's category: the same payer's other credits of about
// that sum are proposed as the same tenant's rent (engine/21q-build-rent-tags.js), each one a tap to keep or undo. The
// Tenants tab then says, per tenant, whether this month's rent is here, and how late it is from its due day.

/// one let floor a credit can be the rent of
struct RentPlace: Identifiable, Hashable {
    /// "<property id>|<floor's place>": the engine's key for the floor (rentUnitKey)
    let key: String
    let prop: String
    let idx: Int
    let tenant: String
    let floor: String
    let place: String
    var id: String { key }
    /// the tenant's name (the floor's, when none was typed) and where: "Ground floor, Example House"
    var title: String { (tenant.isEmpty ? floor : tenant) }
    var detail: String { tenant.isEmpty ? place : floor + ", " + place }
}

extension Store {
    /// the floors you let out (a tenant, a rent or marked let), as you set them up, in order
    var rentPlaces: [RentPlace] {
        guard let live else { return [] }
        var out: [RentPlace] = []
        for p in live.properties {
            let place: String = p.short.isEmpty ? p.name : p.short
            for (j, u) in p.units.enumerated() {
                let st: String = u.status ?? ""
                // (a floor the family uses, or one standing empty, is nobody's rent unless it names a tenant)
                guard st == "let" || !u.tenant.isEmpty || (u.rent > 0 && st != "self" && st != "vacant") else { continue }
                out.append(RentPlace(key: p.id + "|" + String(j), prop: p.id, idx: j, tenant: u.tenant, floor: u.label.isEmpty ? "Floor " + String(j + 1) : u.label, place: place))
            }
        }
        return out
    }
    func rentPlace(_ key: String?) -> RentPlace? {
        guard let key, !key.isEmpty else { return nil }
        return rentPlaces.first { $0.key == key }
    }

    /// this credit is that floor's rent: filed as rent for this payment only (the payer's other credits follow the tag's
    /// sum, not the payee's category), the tag saved as yours. A floor with no rent set takes this credit's sum.
    func tagRent(_ id: String, _ place: RentPlace) {
        guard let live, let t = txn(id), Self.part(id) == nil else { return }
        live.override(id) { o in
            o.c = "Rent received"; o.s = ""; o.by = nil; o.rent = place.key
            o.only = Self.with(Self.without(o.only, "r"), "c")
        }
        if let i = live.properties.firstIndex(where: { $0.id == place.prop }), place.idx < live.properties[i].units.count {
            var u: UserUnit = live.properties[i].units[place.idx]
            u.notRent = (u.notRent ?? []).filter { $0 != id }
            if u.rent <= 0 { u.rent = t.a }
            if (u.status ?? "").isEmpty || u.status == "vacant" { u.status = "let" }
            live.properties[i].units[place.idx] = u
            live.save()
        }
        let sym: String = symbol("Rent received")
        edit(id) { x in x.c = "Rent received"; x.s = ""; x.u = false; x.g = false; x.sym = sym; x.rt = place.key; x.rtl = nil }
        live.rebuildSoon()
    }

    /// not rent after all: a tag you made comes off (and the category goes back to what kosh read); one kosh proposed is
    /// set aside for that floor for good (the floor's notRent, as on the Tenants tab)
    func untagRent(_ id: String) {
        guard let live, let t = txn(id) else { return }
        if (live.overrides[id]?.rent ?? "").isEmpty {
            if let p = rentPlace(t.rt) { live.notRent(property: p.prop, unit: p.idx, tx: id) }
        } else {
            live.override(id) { o in
                o.rent = nil
                if o.c == "Rent received" { o.c = nil; o.s = nil; o.only = Self.without(o.only, "c") }
            }
        }
        edit(id) { x in x.rt = nil; x.rtl = nil }
        live.rebuildSoon()
    }

    /// a floor added from a payment's sheet: the tenant, the rent (this credit's sum unless typed), in a property you
    /// have or a new one; then this credit is tagged as its rent
    func addTenantAndTag(_ id: String, tenant: String, rent: Double, property: String?, newProperty: String) {
        guard let live else { return }
        let name: String = String(tenant.trimmingCharacters(in: .whitespacesAndNewlines).prefix(60))
        guard !name.isEmpty else { return }
        var u = UserUnit()
        u.tenant = name; u.rent = max(0, rent); u.status = "let"
        var prop: UserProperty
        if let pid = property, let found = live.properties.first(where: { $0.id == pid }) {
            prop = found
        } else {
            prop = UserProperty()
            let n: String = newProperty.trimmingCharacters(in: .whitespacesAndNewlines)
            prop.name = n.isEmpty ? "Rented property" : String(n.prefix(60)); prop.short = prop.name; prop.use = "let"
        }
        u.label = prop.units.isEmpty ? "Ground floor" : "Floor " + String(prop.units.count + 1)
        prop.units.append(u)
        let idx: Int = prop.units.count - 1
        live.upsertProperty(prop)
        tagRent(id, RentPlace(key: prop.id + "|" + String(idx), prop: prop.id, idx: idx, tenant: name, floor: u.label, place: prop.short))
    }
}

/// under the kinds, on money in filed as rent (or proposed as one tenant's): whose rent it is
struct RentFrom: View {
    @Environment(Store.self) private var store
    let t: Txn
    @State private var adding = false
    @State private var tenant = ""
    @State private var rentText = ""
    @State private var propId: String? = nil
    @State private var newProp = ""
    @FocusState private var nameFocus: Bool

    var body: some View {
        let places: [RentPlace] = store.rentPlaces
        let at: RentPlace? = store.rentPlace(t.rt)
        SheetCard {
            VStack(alignment: .leading, spacing: 12) {
                if let at {
                    tagged(at, learnt: t.rtl == true, others: places.filter { $0.key != at.key })
                } else {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Whose rent is it?").font(.body.weight(.semibold))
                        Text(Fmt.rupees(t.a) + " from " + t.m).font(.footnote).foregroundStyle(.secondary).lineLimit(1).privacySensitive()
                    }
                    let ranked: [RentPlace] = RentFrom.ranked(places, payer: t.m)
                    let likely: String? = RentFrom.likely(places, payer: t.m)?.key
                    VStack(spacing: 0) {
                        ForEach(Array(ranked.enumerated()), id: \.element.id) { i, p in
                            if i > 0 { Divider().padding(.leading, 58) }
                            Button { withAnimation(Motion.base) { store.tagRent(t.id, p) } } label: {
                                RentPlaceRow(p: p, tint: store.catColor("Rent received"), likely: p.key == likely)
                            }
                            .buttonStyle(.press)
                            .accessibilityLabel("Rent from " + p.title + ", " + p.detail + (p.key == likely ? ", likely" : ""))
                        }
                        if !adding {
                            if !ranked.isEmpty { Divider().padding(.leading, 58) }
                            Button {
                                rentText = Fmt.trim(t.a, 2); propId = store.live?.properties.first?.id
                                withAnimation(Motion.open) { adding = true }
                                nameFocus = true
                            } label: {
                                HStack(spacing: 14) {
                                    Image(systemName: "plus").font(.system(size: 14, weight: .bold)).foregroundStyle(Color.kosh)
                                        .frame(width: 36, height: 36)
                                        .background(Color.kosh.opacity(0.12), in: Circle())
                                    Text(places.isEmpty ? "Add the tenant" : "Someone else").font(.body.weight(.medium)).foregroundStyle(Color.kosh)
                                    Spacer(minLength: 0)
                                }
                                .padding(.vertical, 10)
                                .contentShape(Rectangle())
                            }
                            .buttonStyle(.press)
                        }
                    }
                    .padding(.horizontal, 12)
                    .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                    if adding { addForm }
                    Text(places.isEmpty ? "kosh knows no tenants yet. Add the one who paid this, and the Tenants tab follows their rent." :
                            "Pick once: kosh then proposes the same payer’s credits of about this sum as their rent.")
                        .font(.footnote).foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                }
            }
            .padding(16)
        }
        .animation(Motion.base, value: t.rt)
    }

    /// whose it is, and what you can do: keep kosh's proposal, move it to another tenant, or say it isn't rent
    func tagged(_ p: RentPlace, learnt: Bool, others: [RentPlace]) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 10) {
                Image(systemName: "key.fill")
                    .font(.system(size: 13, weight: .bold))
                    .foregroundStyle(Color.black.opacity(0.8))
                    .frame(width: 30, height: 30)
                    .background(store.catColor("Rent received"), in: Circle())
                VStack(alignment: .leading, spacing: 1) {
                    Text("Rent from " + p.title).font(.body.weight(.semibold)).lineLimit(1).privacySensitive()
                    Text(p.detail).font(.footnote).foregroundStyle(.secondary).lineLimit(1).privacySensitive()
                }
                Spacer(minLength: 0)
            }
            if learnt {
                Text("kosh’s guess: the same payer, about the sum you tagged as " + p.title + "’s rent before.")
                    .font(.footnote).foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
            HStack(spacing: 8) {
                if learnt {
                    Button { withAnimation(Motion.base) { store.tagRent(t.id, p) } } label: { pill("Yes, it’s rent", solid: true) }
                        .buttonStyle(.press)
                }
                if !others.isEmpty {
                    Menu {
                        ForEach(others) { o in
                            Button(o.title + " · " + o.detail) { withAnimation(Motion.base) { store.tagRent(t.id, o) } }
                        }
                    } label: { pill("Another tenant", solid: false) }
                }
                Button(role: .destructive) { withAnimation(Motion.base) { store.untagRent(t.id) } } label: { pill("Not rent", solid: false) }
                    .buttonStyle(.press)
            }
        }
    }

    var addForm: some View {
        VStack(alignment: .leading, spacing: 10) {
            TextField("Tenant’s name", text: $tenant)
                .textInputAutocapitalization(.words)
                .focused($nameFocus)
                .padding(.horizontal, 12).frame(height: 40)
                .background(Color.primary.opacity(0.06), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
            HStack(spacing: 8) {
                Text("Rent ₹").font(.subheadline).foregroundStyle(.secondary)
                TextField("0", text: $rentText)
                    .keyboardType(.decimalPad)
                    .font(.subheadline.weight(.semibold))
                    .privacySensitive()
                Spacer(minLength: 0)
                Menu {
                    ForEach(store.live?.properties ?? []) { p in
                        Button(p.short.isEmpty ? p.name : p.short) { propId = p.id }
                    }
                    Button("A new property") { propId = nil }
                } label: {
                    Label(propName, systemImage: "house").font(.subheadline.weight(.semibold)).lineLimit(1)
                }
            }
            if propId == nil {
                TextField("The property’s name", text: $newProp)
                    .textInputAutocapitalization(.words)
                    .padding(.horizontal, 12).frame(height: 40)
                    .background(Color.primary.opacity(0.06), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
            }
            HStack {
                Button("Cancel") { withAnimation(Motion.quick) { adding = false } }
                    .font(.subheadline.weight(.semibold)).foregroundStyle(.secondary)
                Spacer()
                Button {
                    let r: Double = Double(rentText.replacingOccurrences(of: ",", with: "").replacingOccurrences(of: "₹", with: "")) ?? t.a
                    withAnimation(Motion.base) {
                        store.addTenantAndTag(t.id, tenant: tenant, rent: r, property: propId, newProperty: newProp)
                        adding = false
                    }
                } label: { pill("Add and tag", solid: true) }
                .buttonStyle(.press)
                .disabled(tenant.trimmingCharacters(in: .whitespaces).isEmpty)
            }
            Text("Its due day goes in under Tenants › Edit tenant. Without one, kosh learns it from the rents you tag.")
                .font(.footnote).foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
        .transition(.opacity)
    }

    var propName: String {
        guard let id = propId, let p = store.live?.properties.first(where: { $0.id == id }) else { return "A new property" }
        return p.short.isEmpty ? p.name : p.short
    }

    func chip(_ title: String, sub: String) -> some View {
        VStack(alignment: .leading, spacing: 0) {
            Text(title).font(.subheadline.weight(.semibold)).lineLimit(1)
            Text(sub).font(.caption2).foregroundStyle(.secondary).lineLimit(1)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 6)
        .background(Color.primary.opacity(0.07), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        .foregroundStyle(Color.primary)
        .privacySensitive()
    }

    func pill(_ text: String, solid: Bool) -> some View {
        Text(text)
            .font(.footnote.weight(.semibold))
            .lineLimit(1)
            .foregroundStyle(solid ? Color.white : Color.primary)
            .padding(.horizontal, 12)
            .frame(minHeight: 34)
            .background(solid ? Color.kosh : Color.primary.opacity(0.07), in: Capsule())
    }
}


extension RentFrom {
    /// the tenant the payer's own name points to: a word of the tenant's name (four letters or more) in the payer's
    /// ("MAGELLAN TELESERVIC" → Magellan); none when it points to two
    static func likely(_ places: [RentPlace], payer: String) -> RentPlace? {
        let pay: Set<String> = Set(payer.lowercased().split(whereSeparator: { !$0.isLetter }).map(String.init).filter { $0.count >= 4 })
        let hits: [RentPlace] = places.filter { p in
            p.tenant.lowercased().split(whereSeparator: { !$0.isLetter }).map(String.init).contains { $0.count >= 4 && pay.contains($0) }
        }
        return hits.count == 1 ? hits[0] : nil
    }
    /// the likely one first, the rest as they are
    static func ranked(_ places: [RentPlace], payer: String) -> [RentPlace] {
        guard let l = likely(places, payer: payer) else { return places }
        return [l] + places.filter { $0.key != l.key }
    }
}

/// one tenant to pick: their initial in the rent colour, their name, the floor and property; kosh's likely one marked
struct RentPlaceRow: View {
    let p: RentPlace
    let tint: Color
    let likely: Bool
    var body: some View {
        HStack(spacing: 14) {
            Text(String(p.title.prefix(1)).uppercased())
                .font(.system(size: 15, weight: .semibold, design: .rounded))
                .foregroundStyle(Color.black.opacity(0.75))
                .frame(width: 36, height: 36)
                .background(tint.opacity(likely ? 1 : 0.55), in: Circle())
            VStack(alignment: .leading, spacing: 2) {
                HStack(spacing: 6) {
                    Text(p.title).font(.body.weight(.semibold)).foregroundStyle(Color.primary).lineLimit(1)
                    if likely {
                        Text("Likely").font(.caption2.weight(.bold)).foregroundStyle(Color.kosh)
                            .padding(.horizontal, 7).padding(.vertical, 2)
                            .background(Color.kosh.opacity(0.12), in: Capsule())
                    }
                }
                Text(p.detail).font(.footnote).foregroundStyle(.secondary).lineLimit(1)
            }
            Spacer(minLength: 6)
            Image(systemName: "chevron.right").font(.caption.weight(.bold)).foregroundStyle(.tertiary)
        }
        .padding(.vertical, 10)
        .contentShape(Rectangle())
        .privacySensitive()
    }
}
