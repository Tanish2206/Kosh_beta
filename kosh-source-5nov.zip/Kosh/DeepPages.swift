import SwiftUI

// MARK: - The pages behind Month in review and Understanding you (find-review, 1 Nov; black look, insights-obsidian)
//
// Every tap on those two pages opens a page in the same black look and card language (InsightsKit.swift): a hero card,
// then cards, never a system grey list, under a dark bar with a readable title. The payments behind a card
// (`Route.payments`), a life event (`Route.lifeEvent`), a trip (`Route.personaTrip`), a person (`Route.personaPerson`)
// and a habit (`Route.personaHabit`). Figures are the engine's or the payments' own; a page that adds payments up says it
// is their total, with their dates.

// MARK: shared pieces

/// the card at the top: an icon or initials in a ring, a caption, a title, the figure large, and what it covers
struct DeepHero: View {
    let sym: String
    var initials: String = ""
    let tint: Color
    let title: String
    var caption: String = ""
    var figure: String = ""
    var sub: String = ""
    var line: String = ""
    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(alignment: .center, spacing: 12) {
                badge
                VStack(alignment: .leading, spacing: 3) {
                    if !caption.isEmpty { Text(caption).caption(tint) }
                    Text(title).font(.title3.weight(.semibold)).foregroundStyle(Obsidian.ink).fixedSize(horizontal: false, vertical: true)
                }
                Spacer(minLength: 0)
            }
            if !figure.isEmpty { ObsFigure(text: figure, size: 44) }
            if !sub.isEmpty { Text(sub).font(.footnote).foregroundStyle(Obsidian.ink2).fixedSize(horizontal: false, vertical: true) }
            if !line.isEmpty {
                ObsRule()
                Text(line).font(.subheadline).foregroundStyle(Obsidian.ink).fixedSize(horizontal: false, vertical: true)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .obsidianCard(24, padding: 18)
        .privacySensitive()
    }
    @ViewBuilder private var badge: some View {
        if initials.isEmpty {
            Image(systemName: sym).font(.system(size: 17, weight: .semibold)).foregroundStyle(tint)
                .frame(width: 44, height: 44).background(tint.opacity(0.16), in: Circle())
                .overlay(Circle().strokeBorder(tint.opacity(0.32), lineWidth: 1))
        } else {
            ObsAvatar(text: initials, tint: tint, size: 44)
        }
    }
}

/// a caption above a page's cards
struct DeepTitle: View {
    let text: String
    var trailing: String = ""
    var body: some View { ObsHead(text: text, trailing: trailing) }
}

/// a page's frame: black, the cards spaced, a dark bar with the title inline
struct DeepScroll<Content: View>: View {
    let title: String
    @ViewBuilder let content: () -> Content
    var body: some View {
        ObsScroll(title: title, inline: true, content: content)
    }
}

/// two figures side by side as bars: this against that (a weekend day against a weekday; this month against usual)
struct DeepCompare: View {
    let a: (label: String, v: Double)
    let b: (label: String, v: Double)
    let tint: Color
    var body: some View {
        let most: Double = max(1, max(a.v, b.v))
        VStack(alignment: .leading, spacing: 16) {
            DeepCompareBar(label: a.label, v: a.v, share: a.v / most, tint: tint)
            DeepCompareBar(label: b.label, v: b.v, share: b.v / most, tint: Obsidian.ink3)
            if b.v > 0 { Text(DeepWords.times(a.v, b.v, b.label)).caption() }
        }
        .obsidianCard(22, padding: 16)
        .privacySensitive()
    }
}

struct DeepCompareBar: View {
    let label: String
    let v: Double
    let share: Double
    let tint: Color
    var body: some View {
        VStack(alignment: .leading, spacing: 7) {
            HStack(alignment: .firstTextBaseline) {
                Text(label).font(.subheadline).foregroundStyle(Obsidian.ink2).fixedSize(horizontal: false, vertical: true)
                Spacer(minLength: 8)
                Text(Fmt.rupees(v)).font(.system(.headline, design: .rounded, weight: .semibold)).monospacedDigit().foregroundStyle(Obsidian.ink)
            }
            ObsTrack(share: share, tint: tint, height: 8)
        }
        .accessibilityElement(children: .combine)
    }
}

// MARK: payments, by day, in cards

/// the payments behind a figure, a card a day with the day's total; ids kosh holds no payment for (a mail, a
/// delivery) are offered as "the mails behind it"
struct DeepPayments: View {
    @Environment(Store.self) private var store
    let ids: [String]
    var mailType: String = "move"
    var body: some View {
        let rows: [Txn] = DeepPayments.rows(store, ids)
        let groups: [DayGroup] = LedgerFind.byDay(rows)
        let mails: [String] = DeepPayments.mailsOnly(store, ids)
        VStack(alignment: .leading, spacing: 10) {
            ForEach(Array(groups.enumerated()), id: \.element.id) { (pair: EnumeratedSequence<[DayGroup]>.Element) in
                DeepDayCard(g: pair.element).obsArrive(pair.offset)
            }
            if !mails.isEmpty && store.live != nil {
                Button {
                    store.betaSheet = .source(SourceRef(title: "Where kosh read this", mails: mails, type: mailType))
                } label: {
                    ObsLinkRow(title: mails.count == 1 ? "The mail behind it" : "The " + String(mails.count) + " mails behind it", sym: "envelope.open", tint: InsightsInk.voice)
                        .obsidianCard(20, padding: 14)
                }
                .buttonStyle(.press)
            }
        }
    }
    /// the ids kosh holds a payment for, newest first, each once
    @MainActor static func rows(_ store: Store, _ ids: [String]) -> [Txn] {
        var seen: Set<String> = []
        var out: [Txn] = []
        for id in ids where !seen.contains(id) {
            seen.insert(id)
            if let t = store.txn(id) { out.append(t) }
        }
        return out.sorted { (a: Txn, b: Txn) -> Bool in a.d != b.d ? a.d > b.d : a.t > b.t }
    }
    /// the ids that are mails, not payments
    @MainActor static func mailsOnly(_ store: Store, _ ids: [String]) -> [String] {
        var out: [String] = []
        for id in ids where store.txn(id) == nil {
            let m: String = String(id.split(separator: "#").first ?? Substring(id))
            if !out.contains(m) { out.append(m) }
        }
        return out
    }
}

/// a day's payments in a card: the day as a caption, its total, the rows with hairlines between
struct DeepDayCard: View {
    @Environment(Store.self) private var store
    let g: DayGroup
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .firstTextBaseline) {
                Text(Day.label(g.day, today: store.snap.today)).caption()
                Spacer(minLength: 8)
                if g.total > 0 { Text(Fmt.rupees(g.total)).caption().monospacedDigit() }
            }
            ForEach(Array(g.items.enumerated()), id: \.element.id) { (pair: EnumeratedSequence<[Txn]>.Element) in
                if pair.offset > 0 { ObsRule(inset: 48) }
                TxRow(t: pair.element, when: Day.time12(pair.element.t))
            }
        }
        .obsidianCard(20, padding: 14)
    }
}

/// the payments behind a figure: "Top brands · Oct", what it covers, how many and their total, then a card a day
struct PaymentsPage: View {
    @Environment(Store.self) private var store
    let title: String
    let sub: String
    let ids: [String]
    var body: some View {
        let rows: [Txn] = DeepPayments.rows(store, ids)
        let total: Double = DeepWords.total(rows)
        let span: String = DeepWords.span(rows.map(\.d))
        DeepScroll(title: title) {
            DeepHero(sym: "list.bullet.rectangle", tint: Obsidian.ulip, title: title, caption: DeepWords.count(rows.count),
                     figure: total > 0 ? Fmt.rupees(total) : "",
                     sub: span + (sub.isEmpty || sub == span ? "" : (span.isEmpty ? "" : " · ") + sub))
            if rows.isEmpty && DeepPayments.mailsOnly(store, ids).isEmpty {
                ObsEmpty(title: "No payments here now", sym: "tray", text: "They may have been refiled or taken out since this was worked out.")
            }
            DeepPayments(ids: ids)
            ObsNote(text: "The figure at the top is these payments added up as each one counts (your share), less any money back set against them.")
        }
    }
}

enum DeepWords {
    /// what a page's payments come to: money out as each counts, less the money back set against them (as Insights)
    static func total(_ rows: [Txn]) -> Double {
        let out: Double = rows.filter { $0.k != "in" }.reduce(0) { $0 + $1.a }
        let back: Double = rows.filter { $0.k == "in" }.reduce(0) { $0 + ($1.nta ?? 0) }
        return max(0, out - back)
    }
    static func count(_ n: Int) -> String { n == 1 ? "1 payment" : String(n) + " payments" }
    /// "4 Aug – 21 Sep 2026" over the days given
    static func span(_ days: [String]) -> String {
        let ds: [String] = days.filter { !$0.isEmpty }.sorted()
        guard let a = ds.first, let b = ds.last else { return "" }
        if a == b { return Day.fmt(a, "d MMM yyyy") }
        return Day.fmt(a, a.prefix(4) == b.prefix(4) ? "d MMM" : "d MMM yyyy") + " – " + Day.fmt(b, "d MMM yyyy")
    }
    /// "1 – 31 Oct 2026" for an evidence line's dates
    static func range(_ from: String?, _ to: String?) -> String {
        guard let f = from, !f.isEmpty else { return "" }
        let t: String = (to ?? "").isEmpty ? f : (to ?? f)
        return span([f, t])
    }
    /// the first figure against the second, in words: "1.4× a weekday", "62% of a usual month", "About a weekday's"
    static func times(_ a: Double, _ b: Double, _ against: String) -> String {
        guard b > 0 else { return "" }
        let r: Double = a / b
        let what: String = against.prefix(1).lowercased() + against.dropFirst()
        if r >= 0.95 && r <= 1.05 { return "About the same as " + what }
        if r > 1 { return String(format: "%.1f", r) + "× " + what }
        return String(Int((r * 100).rounded())) + "% of " + what
    }
}

// MARK: evidence, as cards

/// what kosh read, a row a line in one card: the line, and its payments or mails
struct DeepEvidence: View {
    let ev: [Persona.Evidence]
    let type: (Int) -> String
    var body: some View {
        if !ev.isEmpty {
            DeepTitle(text: "How kosh knows")
            VStack(alignment: .leading, spacing: 0) {
                ForEach(Array(ev.enumerated()), id: \.offset) { (pair: EnumeratedSequence<[Persona.Evidence]>.Element) in
                    if pair.offset > 0 { ObsRule(inset: 44).padding(.vertical, 10) }
                    DeepEvidenceCard(e: pair.element, type: type(pair.offset))
                }
            }
            .obsidianCard(22, padding: 16)
        }
    }
}

struct DeepEvidenceCard: View {
    @Environment(Store.self) private var store
    let e: Persona.Evidence
    let type: String
    var body: some View {
        let ids: [String] = e.ids ?? []
        let pays: Int = DeepPayments.rows(store, ids).count
        let mails: [String] = store.evidenceMails(e)
        Button {
            if pays > 0 {
                store.push(.payments(EvidenceRow.words(e.line), DeepWords.range(e.from, e.to), ids))
            } else if !mails.isEmpty && store.live != nil {
                store.betaSheet = .source(SourceRef(title: "Where kosh read this", mails: mails, type: type))
            }
        } label: {
            ObsLinkRow(title: EvidenceRow.words(e.line), sub: DeepEvidenceCard.what(pays, mails.count),
                       sym: pays > 0 ? "indianrupeesign" : "doc.text.magnifyingglass", tint: InsightsInk.voice)
        }
        .buttonStyle(.press)
        .disabled(pays == 0 && (mails.isEmpty || store.live == nil))
        .privacySensitive()
    }
    static func what(_ pays: Int, _ mails: Int) -> String {
        if pays > 0 { return "See the " + DeepWords.count(pays) }
        if mails > 0 { return mails == 1 ? "See the mail" : "See the " + String(mails) + " mails" }
        return "Worked out from your months"
    }
}

// MARK: a life event

struct LifeEventPage: View {
    @Environment(Store.self) private var store
    let id: String
    var body: some View {
        if let e = store.persona?.events?.first(where: { $0.id == id }) {
            DeepScroll(title: e.title) {
                DeepHero(sym: PersonaWords.sym(event: e.k), tint: InsightsInk.event(e.k), title: e.title, caption: Day.fmt(e.on, "d MMMM yyyy"), line: e.line)
                if e.ask == true && store.live != nil { PersonaMoveAsk(id: e.id) }
                if let s = e.story, s.n > 0 { LifeEventStory(s: s, said: !(e.storyLine ?? "").isEmpty) }
                DeepEvidence(ev: e.ev ?? [], type: { (_: Int) -> String in PersonaEventRow.type(e.k) })
                ObsNote(text: "Spent around it is counted as Insights counts a month: card bills paid, money between your own accounts, money sent to family and investments are never in it.")
            }
        } else {
            DeepScroll(title: "Life event") {
                ObsEmpty(title: "Not in kosh any more", sym: "calendar.badge.exclamationmark", text: "It may have changed with the latest read of your mail.")
            }
        }
    }
}

/// what was spent around an event: its total and dates, a day's against a usual day's, its biggest kinds as rows
struct LifeEventStory: View {
    @Environment(Store.self) private var store
    let s: Persona.Story
    /// the engine said it (a day's spending around it was 25% or more off a usual day's)
    let said: Bool
    var body: some View {
        let top: [Persona.Cat] = s.top ?? []
        let most: Double = max(1, top.map(\.v).max() ?? 1)
        DeepTitle(text: "Spent around it", trailing: DeepWords.range(s.from, s.to))
        VStack(alignment: .leading, spacing: 16) {
            ObsFigure(text: Fmt.rupees(s.spent), size: 34)
            if let pd = s.perDay, let u = s.usual, u > 0 {
                DeepCompareBar(label: "A day around it", v: pd, share: pd / max(pd, u), tint: said ? InsightsInk.voice : Obsidian.ink2)
                DeepCompareBar(label: "A usual day", v: u, share: u / max(pd, u), tint: Obsidian.ink3)
            }
            if !top.isEmpty {
                ObsRule()
                ForEach(Array(top.enumerated()), id: \.element.cat) { (pair: EnumeratedSequence<[Persona.Cat]>.Element) in
                    ObsKindRow(name: pair.element.cat, value: Fmt.rupees(pair.element.v), share: pair.element.v / most, tint: InsightsInk.kind(pair.offset))
                }
            }
        }
        .obsidianCard(22, padding: 16)
        .privacySensitive()
    }
}

// MARK: a trip

struct PersonaTripPage: View {
    @Environment(Store.self) private var store
    let id: String
    @State private var draftOpen: TripDraft?
    var body: some View {
        if let t = store.persona?.trips?.first(where: { $0.id == id }) {
            let ids: [String] = PersonaTripPage.ids(store, t)
            DeepScroll(title: t.name) {
                DeepHero(sym: "airplane", tint: Obsidian.ulip, title: (t.place ?? "").isEmpty ? t.name : (t.place ?? t.name),
                         caption: t.draft == true ? "Found in your mail" : "Your chapter",
                         figure: (t.total ?? 0) > 0 ? Fmt.rupees(t.total ?? 0) : "",
                         sub: DeepWords.range(t.from, t.to) + PersonaTripPage.daysWord(t))
                PersonaTripActions(t: t) { draftOpen = (store.snap.tripDrafts ?? []).first { $0.id == t.id } }
                if !PersonaWords.split(t).isEmpty { PersonaTripSplitCard(t: t) }
                if !ids.isEmpty {
                    DeepTitle(text: "Its payments", trailing: String(ids.count))
                    DeepPayments(ids: ids)
                }
                DeepEvidence(ev: t.ev ?? [], type: { (_: Int) -> String in "move" })
            }
            .modifier(TripDraftPresenter(draft: $draftOpen))
        } else {
            DeepScroll(title: "Trip") {
                ObsEmpty(title: "Not a trip any more", sym: "airplane", text: "It may have been joined, split or set aside.")
            }
        }
    }
    /// " · 5 days · ₹8,460 a day"
    static func daysWord(_ t: Persona.Trip) -> String {
        var s: String = ""
        if let d = t.days, d > 0 { s += " · " + String(d) + (d == 1 ? " day" : " days") }
        if let pd = t.perDay, pd > 0 { s += " · " + Fmt.rupees(pd) + " a day" }
        return s
    }
    /// a draft's payments (booked and near), or a chapter's own
    @MainActor static func ids(_ store: Store, _ t: Persona.Trip) -> [String] {
        if t.chapter == true { return store.tx.filter { $0.tr == t.id }.map(\.id) }
        guard let d = (store.snap.tripDrafts ?? []).first(where: { $0.id == t.id }) else { return [] }
        return d.pay + (d.near ?? [])
    }
}

/// open the chapter, or look over the draft (file it as a chapter): a white button, and an outlined one
struct PersonaTripActions: View {
    @Environment(Store.self) private var store
    let t: Persona.Trip
    let review: () -> Void
    var body: some View {
        HStack(spacing: 10) {
            if t.chapter == true {
                Button { store.push(.chapter(t.id)) } label: { DeepButtonFace(text: "Open the chapter", sym: "book.pages", lit: true) }
                    .buttonStyle(.press)
            } else {
                Button(action: review) { DeepButtonFace(text: "Review and keep", sym: "checkmark", lit: true) }
                    .buttonStyle(.press)
                Button { store.live?.dropTripDraft(t.id) } label: { DeepButtonFace(text: "Not a trip", sym: "xmark", lit: false) }
                    .buttonStyle(.press)
            }
            Spacer(minLength: 0)
        }
    }
}

/// a capsule button's face in the black look: lit (white, black words) or outlined
struct DeepButtonFace: View {
    let text: String
    let sym: String
    let lit: Bool
    var body: some View {
        HStack(spacing: 6) {
            Image(systemName: sym).font(.footnote.weight(.bold))
            Text(text).font(.subheadline.weight(.semibold)).lineLimit(1).minimumScaleFactor(0.8)
        }
        .foregroundStyle(lit ? Color.black : Obsidian.ink)
        .padding(.horizontal, 16)
        .frame(minHeight: 44)
        .background(lit ? Obsidian.ink : Color.clear, in: Capsule())
        .overlay(Capsule().strokeBorder(Color.white.opacity(lit ? 0 : 0.25), lineWidth: 1))
        .contentShape(Capsule())
    }
}

struct PersonaTripSplitCard: View {
    let t: Persona.Trip
    var body: some View {
        let parts: [PersonaWords.TripPart] = PersonaWords.split(t)
        let most: Double = max(1, parts.map(\.v).max() ?? 1)
        DeepTitle(text: "What it went on")
        VStack(alignment: .leading, spacing: 16) {
            ObsSegBar(segs: parts.map { (p: PersonaWords.TripPart) -> ObsSegBar.Seg in ObsSegBar.Seg(id: p.k, v: p.v, tint: PersonaSplitBar.tint(p.k)) }, height: 12)
            ForEach(parts) { (p: PersonaWords.TripPart) in
                ObsKindRow(name: PersonaWords.splitName(p.k), value: Fmt.rupees(p.v), share: p.v / most, tint: PersonaSplitBar.tint(p.k))
            }
        }
        .obsidianCard(22, padding: 16)
        .privacySensitive()
    }
}

// MARK: a person

struct PersonaPersonPage: View {
    @Environment(Store.self) private var store
    let key: String
    var body: some View {
        if let w = store.persona?.people?.first(where: { $0.key == key }) {
            let ids: [String] = (w.parts ?? []).filter { $0.k != "split" }.flatMap { $0.ids ?? [] }
            DeepScroll(title: w.who) {
                DeepHero(sym: "person.fill", initials: PersonaWords.initials(w.who), tint: InsightsInk.family, title: w.who,
                         caption: (w.rel ?? "").isEmpty ? "Last 12 months" : (w.rel ?? ""),
                         figure: w.total > 0 ? Fmt.rupees(w.total) : "",
                         sub: PersonaWords.caption(w) + (DeepWords.range(w.from, w.to).isEmpty ? "" : " · " + DeepWords.range(w.from, w.to)))
                PersonaPartsCards(parts: w.parts ?? [])
                if !ids.isEmpty {
                    DeepTitle(text: "The payments", trailing: String(ids.count))
                    DeepPayments(ids: ids, mailType: "order")
                }
                ObsNote(text: "Money sent and gifts make the total; bills split are their share and stay apart from it. Money sent to family is moved, not spent: it is in no month's spending. Money between your own accounts is never anyone's.")
            }
        } else {
            DeepScroll(title: "Person") {
                ObsEmpty(title: "Not in kosh any more", sym: "person.crop.circle.badge.questionmark", text: "It may have changed with the latest read of your mail.")
            }
        }
    }
}

/// sent · gift · split, one card, a row each
struct PersonaPartsCards: View {
    let parts: [Persona.Part]
    static func head(_ k: String) -> (sym: String, title: String, tint: Color) {
        switch k {
        case "sent": return ("arrow.up.right", "Money sent", InsightsInk.family)
        case "gift": return ("gift.fill", "Gifts", Obsidian.savings)
        default: return ("person.2.fill", "Bills split (their share)", Obsidian.health)
        }
    }
    var body: some View {
        if !parts.isEmpty {
            VStack(alignment: .leading, spacing: 0) {
                ForEach(Array(parts.enumerated()), id: \.element.k) { (pair: EnumeratedSequence<[Persona.Part]>.Element) in
                    if pair.offset > 0 { ObsRule(inset: 44).padding(.vertical, 12) }
                    PersonaPartCard(p: pair.element)
                }
            }
            .obsidianCard(22, padding: 16)
        }
    }
}

struct PersonaPartCard: View {
    let p: Persona.Part
    var body: some View {
        let h: (sym: String, title: String, tint: Color) = PersonaPartsCards.head(p.k)
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: h.sym).font(.subheadline.weight(.semibold)).foregroundStyle(h.tint)
                .frame(width: 32, height: 32).background(h.tint.opacity(0.14), in: RoundedRectangle(cornerRadius: 9, style: .continuous))
            VStack(alignment: .leading, spacing: 3) {
                HStack(alignment: .firstTextBaseline) {
                    Text(h.title).font(.subheadline.weight(.semibold)).foregroundStyle(Obsidian.ink)
                    Spacer(minLength: 8)
                    Text(Fmt.rupees(p.amt)).font(.subheadline.weight(.semibold)).monospacedDigit().foregroundStyle(Obsidian.ink)
                }
                Text(String(p.n) + (p.n == 1 ? " time" : " times") + (DeepWords.range(p.from, p.to).isEmpty ? "" : " · " + DeepWords.range(p.from, p.to)))
                    .font(.caption).foregroundStyle(Obsidian.ink2).fixedSize(horizontal: false, vertical: true)
                if let what = p.what, !what.isEmpty {
                    Text(what.prefix(4).joined(separator: ", ")).font(.footnote).foregroundStyle(Obsidian.ink3).lineLimit(3)
                }
            }
        }
        .privacySensitive()
    }
}

// MARK: a habit

struct PersonaHabitPage: View {
    @Environment(Store.self) private var store
    let k: String
    var body: some View {
        if let h = store.persona?.habits?.first(where: { $0.k == k }) {
            let t: (title: String, value: String, sub: String) = PersonaWords.tile(h, money: Fmt.rupees)
            let ids: [String] = (h.ev ?? []).flatMap { $0.ids ?? [] }
            DeepScroll(title: t.title) {
                DeepHero(sym: PersonaWords.sym(habit: h.k), tint: Obsidian.savings, title: t.title, caption: DeepWords.range(h.from, h.to), figure: t.value, line: h.line)
                if let pair = PersonaHabitPage.compare(h) { DeepCompare(a: pair.0, b: pair.1, tint: Obsidian.savings) }
                if !ids.isEmpty {
                    DeepTitle(text: "The payments", trailing: String(ids.count))
                    DeepPayments(ids: ids)
                }
                DeepEvidence(ev: (h.ev ?? []).filter { ($0.ids ?? []).isEmpty }, type: { (_: Int) -> String in "move" })
                ObsNote(text: "Said plainly, never judged: only everyday spending (food, groceries, shopping, going out, getting about, subscriptions), never health.")
            }
        } else {
            DeepScroll(title: "Habit") {
                ObsEmpty(title: "Not a habit any more", sym: "circle.dashed", text: "It may have changed with the latest read of your mail.")
            }
        }
    }
    /// the two figures a habit holds against each other, when it has both
    static func compare(_ h: Persona.Habit) -> ((label: String, v: Double), (label: String, v: Double))? {
        switch h.k {
        case "weekend":
            if let a = h.weekend, let b = h.weekday { return ((label: "A weekend day", v: a), (label: "A weekday", v: b)) }
        case "payday":
            if let a = h.payWeek, let b = h.other { return ((label: "A day in the week after payday", v: a), (label: "Any other day", v: b)) }
        case "change":
            if let a = h.now, let b = h.usual { return ((label: "This month", v: a), (label: "A usual month", v: b)) }
        default:
            break
        }
        return nil
    }
}
