import SwiftUI

// MARK: - Where you shop: spending by app and store (Amazon, Myntra, Blinkit, Swiggy, MakeMyTrip...), overall or in one category
//
// Which app gets a kind of spending, and how loyal you are to it: the go-to's share, how many orders, what an order
// usually comes to. The app is engine.js › platformOf, read from the payee, its UPI ID and the shop's own receipt.

// (ShopUse and ShopSplit, the figures, live in InsightsMath.swift; the words are here)
extension ShopSplit {
    /// one line true to the figures: the go-to, and how much of the category goes through apps at all
    func quip(cat: String) -> String? {
        guard let top = shops.first, onApps > 0 else { return nil }
        let pct = Fmt.pct(share(top))
        let what = cat.isEmpty ? "" : " for " + cat.lowercased()
        if shops.count == 1 { return top.id + " has all of it" + what + ": no other app gets a look in." }
        let loyal = share(top) >= 0.6 ? "a loyal one" : share(top) >= 0.4 ? "the favourite" : "first among equals"
        var line = top.id + " is " + loyal + what + ": " + pct + " of it, across \(shops.count) apps."
        if !cat.isEmpty && elsewhere.v > 0 {
            line += " " + Fmt.pct(onApps / (onApps + elsewhere.v)) + " of all " + cat.lowercased() + " goes through apps."
        }
        return line
    }
}

extension Store {
    /// spending (for whoever is shown, as it counts) by app or store over the months, in one category or all
    func shopSplit(_ months: [String], cat: String) -> ShopSplit {
        ShopSplit.make(spends(in: Set(months)).map { (pf: $0.pf ?? "", c: $0.c, a: $0.a) }, cat: cat)
    }
    /// each app's website, for its icon (engine.js › PLATFORMS)
    static var shopSites: [String: String] { AppIcons.apps.mapValues(\.site) }
}

struct WhereYouShop: View {
    @Environment(Store.self) private var store
    @Environment(\.accessibilityReduceMotion) private var still
    /// months looked at: 1, 3 or 12
    @AppStorage("shops.span") private var span = 3
    @AppStorage("shops.cat") private var cat = ""
    @State private var grown = false
    @ScaledMetric(relativeTo: .subheadline) private var amtW: CGFloat = 96
    /// the month Insights looks at ("" this month): the span ends there
    @Environment(\.insightMonth) private var pickedMonth

    var body: some View {
        let upTo: String = pickedMonth.isEmpty ? store.snap.cm : pickedMonth
        let months: [String] = InsightMonths.ending(upTo, n: span, all: store.snap.months.map(\.m))
        let thisOne: String = upTo == store.snap.cm ? "this month" : Day.monthName(upTo)
        let split: ShopSplit = store.shopSplit(months, cat: cat)
        let any: ShopSplit = cat.isEmpty ? split : store.shopSplit(months, cat: "")
        if !any.shops.isEmpty || !cat.isEmpty {
            VStack(alignment: .leading, spacing: 12) {
                VStack(alignment: .leading, spacing: 3) {
                    HStack(alignment: .firstTextBaseline) {
                        InsightTitle(text: "Where you shop")
                        Spacer(minLength: 8)
                        Menu {
                            Picker("Months", selection: $span) {
                                Text(upTo == store.snap.cm ? "This month" : Day.monthName(upTo)).tag(1)
                                Text("3 months").tag(3)
                                Text("12 months").tag(12)
                            }
                        } label: {
                            HStack(spacing: 3) {
                                Text(span == 1 ? thisOne : "\(span) months")
                                Image(systemName: "chevron.up.chevron.down").font(.caption2.weight(.semibold))
                            }
                            .font(.subheadline).foregroundStyle(.secondary)
                        }
                    }
                    if let q = split.quip(cat: cat) {
                        Text(q).font(.subheadline).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                    }
                }
                chips(any.cats)
                if split.shops.isEmpty {
                    Text(cat.isEmpty ? "No spending through apps in these months." : "No " + cat.lowercased() + " through apps in these months.")
                        .font(.subheadline).foregroundStyle(.secondary)
                        .padding(16).frame(maxWidth: .infinity, alignment: .leading)
                        .insightCard(26)
                } else {
                    VStack(alignment: .leading, spacing: 0) {
                        InsightBar(parts: split.shops.prefix(8).enumerated().map { (Self.ink($0.offset), $0.element.v) }, grown: grown)
                            .accessibilityElement(children: .ignore)
                            .accessibilityLabel(split.shops.prefix(8).map { $0.id + " " + Fmt.pct(split.share($0)) }.joined(separator: ", "))
                        VStack(spacing: 0) {
                            ForEach(Array(split.shops.prefix(10).enumerated()), id: \.element.id) { i, s in
                                if i > 0 { InsightDivider() }
                                Button { store.push(.platform(s.id, cat, span)) } label: {
                                    ShopRow(name: s.id, line: Self.line(s), v: s.v, share: Fmt.pct(split.share(s)), amtW: amtW, site: Store.shopSites[s.id], link: true)
                                }
                                .buttonStyle(.press)
                                .accessibilityHint("Shows the payments")
                            }
                            if split.shops.count > 10 {
                                InsightDivider()
                                let more = split.shops.dropFirst(10)
                                ShopRow(name: "\(more.count) more", line: more.map(\.id).joined(separator: ", "), v: more.reduce(0) { $0 + $1.v }, share: "", amtW: amtW, site: nil, plainIcon: "ellipsis")
                            }
                            if !cat.isEmpty && split.elsewhere.v > 0.5 {
                                InsightDivider()
                                // what went elsewhere: the corner shop's UPI, a card machine, a person, cash
                                Button { store.push(.platform("", cat, span)) } label: {
                                    ShopRow(name: "Not through an app", line: Self.line(split.elsewhere, payments: true), v: split.elsewhere.v, share: "", amtW: amtW, site: nil, plainIcon: "storefront", link: true)
                                }
                                .buttonStyle(.press)
                                .accessibilityHint("Shows the payments")
                            }
                        }
                        .padding(.top, 8)
                    }
                    .padding(.horizontal, 16)
                    .padding(.top, 16)
                    .padding(.bottom, 6)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .insightCard(26)
                    .privacySensitive()
                }
            }
            .onAppear { InsightMotion.start(still) { grown = true } }
            // every app's icon, the whole list (asking for all of them says nothing about where you shop)
            .task { await AppIcons.warmAll() }
        }
    }

    /// All, then the categories there is app spending in, and the one chosen even when these months have none of it
    /// (so the row always shows what is chosen, and All to go back)
    func chips(_ cats: [String]) -> some View {
        ScrollView(.horizontal) {
            HStack(spacing: 6) {
                ForEach(InsightsMath.chips(cats, chosen: cat), id: \.self) { c in
                    let on: Bool = c == cat
                    Button { withAnimation(Motion.open) { cat = c } } label: {
                        Text(c.isEmpty ? "All" : c)
                            .font(.subheadline.weight(.semibold))
                            .lineLimit(1)
                            .padding(.horizontal, 14)
                            .frame(minHeight: 36)
                            .foregroundStyle(on ? Color(uiColor: .systemBackground) : Color.primary)
                            .background(on ? AnyShapeStyle(Color.primary) : AnyShapeStyle(Color.surface), in: Capsule())
                            .contentShape(Capsule())
                    }
                    .buttonStyle(.press)
                    .accessibilityAddTraits(on ? .isSelected : [])
                }
            }
            .padding(.horizontal, 20)
        }
        .scrollIndicators(.hidden)
        .padding(.horizontal, -20)
        .sensoryFeedback(.selection, trigger: cat)
    }

    static func line(_ s: ShopUse, payments: Bool = false) -> String {
        let one = payments ? "payment" : "order"
        return (s.n == 1 ? "1 " + one : "\(s.n) \(one)s") + (s.n > 1 ? " · usually " + Fmt.rupees(s.avg) : "")
    }
    /// the bar's inks: one hue, the go-to darkest
    static func ink(_ i: Int) -> Color {
        let tones: [Double] = [1, 0.78, 0.6, 0.46, 0.36, 0.28, 0.22, 0.18]
        return InsightInk.blue.opacity(tones[min(i, tones.count - 1)])
    }
}

private struct ShopRow: View {
    let name: String
    let line: String
    let v: Double
    let share: String
    let amtW: CGFloat
    let site: String?
    var plainIcon: String? = nil
    /// it opens the payments
    var link: Bool = false
    var body: some View {
        HStack(spacing: 12) {
            if let plainIcon {
                IconTile(symbol: plainIcon, color: Color(uiColor: .systemGray3), size: 38)
            } else {
                AppMark(name: name, site: site, size: 38)
            }
            VStack(alignment: .leading, spacing: 1) {
                Text(name).font(.subheadline.weight(.semibold)).lineLimit(1)
                Text(line).font(.footnote).foregroundStyle(.secondary).lineLimit(2).fixedSize(horizontal: false, vertical: true)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            VStack(alignment: .trailing, spacing: 1) {
                Text(Fmt.rupees(v))
                    .font(.system(.subheadline, design: .rounded, weight: .semibold)).monospacedDigit()
                    .lineLimit(1).minimumScaleFactor(0.7)
                if !share.isEmpty {
                    Text(share).font(.system(.footnote, design: .rounded)).monospacedDigit().foregroundStyle(.secondary)
                }
            }
            .frame(minWidth: 64, maxWidth: amtW, alignment: .trailing)
            if link { Image(systemName: "chevron.right").font(.caption.weight(.semibold)).foregroundStyle(.tertiary) }
        }
        .padding(.vertical, 10)
        .contentShape(Rectangle())
        .accessibilityElement(children: .combine)
    }
}

// MARK: - One app's payments, opened from Where you shop

struct CatSum: Identifiable { let id: String; let v: Double }

/// One app's payments, or (name "") the spending that went through no app: the corner shop's UPI, a card machine, a
/// person, cash. Both say how it was paid, and can be narrowed to one way
struct PlatformPage: View {
    @Environment(Store.self) private var store
    let name: String
    /// the category it was opened in ("" for all), the months, and how it was paid ("" any way); all can be changed here
    @State var cat: String
    @State var span: Int
    @State private var way = ""

    init(name: String, cat: String, span: Int) {
        self.name = name
        _cat = State(initialValue: cat)
        _span = State(initialValue: span)
    }

    var elsewhere: Bool { name.isEmpty }
    var title: String { elsewhere ? "Not through an app" : name }

    var body: some View {
        let months = Set(store.latestMonths(span))
        let all: [Txn] = store.spends(in: months).filter { elsewhere ? ($0.pf ?? "").isEmpty : $0.pf == name }
        // (a payment with no kind is Other here as everywhere on Insights: "" is the All chip)
        let inCat: [Txn] = cat.isEmpty ? all : all.filter { InsightsMath.kind($0.c) == cat }
        let ways: [CatSum] = Self.sums(Dictionary(grouping: inCat, by: { Self.wayOf($0) }), keep: way)
        let rows: [Txn] = (way.isEmpty ? inCat : inCat.filter { Self.wayOf($0) == way }).sorted { ($0.d, $0.t) > ($1.d, $1.t) }
        let total: Double = rows.reduce(0) { $0 + $1.a }
        let cats: [CatSum] = Self.sums(Dictionary(grouping: all, by: { InsightsMath.kind($0.c) }), keep: cat)
        let today = store.snap.today
        let one: String = elsewhere ? "payment" : "order"
        let countLine: String = rows.count == 1 ? "1 " + one : "\(rows.count) \(one)s"
        let usualLine: String = rows.count > 1 ? " · usually " + Fmt.rupees(total / Double(rows.count)) : ""
        let spanLine: String = span == 1 ? "this month" : "\(span) months"
        let headLine: String = countLine + usualLine + " · " + spanLine
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                HStack(spacing: 14) {
                    if elsewhere {
                        IconTile(symbol: "storefront", color: Color(uiColor: .systemGray3), size: 56)
                    } else {
                        AppMark(name: name, site: Store.shopSites[name], size: 56)
                    }
                    VStack(alignment: .leading, spacing: 2) {
                        Text(Fmt.rupees(total)).font(.system(.title, design: .rounded, weight: .bold)).monospacedDigit().privacySensitive()
                        Text(headLine)
                            .font(.subheadline).foregroundStyle(.secondary)
                    }
                    Spacer(minLength: 0)
                }
                Picker("Months", selection: $span) {
                    Text("This month").tag(1)
                    Text("3 months").tag(3)
                    Text("12 months").tag(12)
                }
                .pickerStyle(.segmented)
                if cats.count > 1 {
                    chips([CatSum(id: "", v: all.reduce(0) { $0 + $1.a })] + cats, on: $cat) { $0.isEmpty ? "All" : $0 }
                }
                // how it was paid: UPI, card, bank, cash, a wallet
                if !ways.isEmpty && !(ways.count == 1 && ways[0].id == "other") {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("How it was paid").font(.footnote.weight(.semibold)).foregroundStyle(.secondary)
                        chips([CatSum(id: "", v: inCat.reduce(0) { $0 + $1.a })] + ways, on: $way) { Self.wayName($0) }
                    }
                }
                if rows.isEmpty {
                    Text(elsewhere ? "Nothing outside the apps in these months." : "Nothing paid to \(name) in these months.").font(.subheadline).foregroundStyle(.secondary)
                } else {
                    LazyVStack(spacing: 0) {
                        ForEach(Array(rows.prefix(200).enumerated()), id: \.element.id) { i, t in
                            if i > 0 { RowRule(inset: 48) }
                            TxRow(t: t, when: Day.label(t.d, today: today)).padding(.vertical, 10)
                        }
                    }
                    .rowsCard()
                    if rows.count > 200 { Text("The latest 200 of \(rows.count).").font(.caption).foregroundStyle(.secondary) }
                }
                Text(elsewhere
                     ? "Spending kosh couldn’t put down to an app or online store: a shop’s own UPI or card machine, a person you paid, cash. If one of these was an app, tap it and change its payee."
                     : "Every payment kosh put down to \(name): by card, UPI or wallet, from the payee, its UPI ID or \(name)’s own receipt. Tap one to change it.")
                    .font(.footnote).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            }
            .padding(.horizontal, 20)
            .padding(.top, 8)
            .padding(.bottom, 40)
        }
        .contentMargins(.bottom, 72, for: .scrollContent)
        .animation(Motion.open, value: span)
        .animation(Motion.open, value: way)
        // another category may not have been paid that way
        .onChange(of: cat) { _, _ in way = "" }
        .navigationTitle(title)
        .navigationBarTitleDisplayMode(.inline)
    }

    /// how a payment was paid, "other" when the mail didn't say
    static func wayOf(_ t: Txn) -> String { let k = PaidWith.key(t); return k.isEmpty ? "other" : k }
    /// each choice with what it comes to, the most first (ties by name, so the row holds still), and the one chosen kept
    /// at nothing when these months have none of it, so the row always shows what is chosen
    static func sums(_ by: [String: [Txn]], keep chosen: String) -> [CatSum] {
        var out: [CatSum] = by.map { CatSum(id: $0.key, v: $0.value.reduce(0) { $0 + $1.a }) }
            .sorted { $0.v != $1.v ? $0.v > $1.v : $0.id < $1.id }
        if !chosen.isEmpty && !out.contains(where: { $0.id == chosen }) { out.append(CatSum(id: chosen, v: 0)) }
        return out
    }
    static func wayName(_ k: String) -> String {
        switch k {
        case "": return "Any way"
        case "wallet": return "Wallet"
        default: return PaidWith.ways.first { $0.0 == k }?.1 ?? "Other"
        }
    }

    /// a row of choices, each with what it comes to; the one chosen filled
    func chips(_ items: [CatSum], on: Binding<String>, label: @escaping (String) -> String) -> some View {
        ScrollView(.horizontal) {
            HStack(spacing: 6) {
                ForEach(items) { c in
                    let sel = c.id == on.wrappedValue
                    Button { withAnimation(Motion.open) { on.wrappedValue = c.id } } label: {
                        Text(label(c.id) + " · " + Fmt.short(c.v))
                            .font(.subheadline.weight(.semibold)).lineLimit(1)
                            .padding(.horizontal, 14).frame(minHeight: 36)
                            .foregroundStyle(sel ? Color(uiColor: .systemBackground) : Color.primary)
                            .background(sel ? AnyShapeStyle(Color.primary) : AnyShapeStyle(Color.surface), in: Capsule())
                            .contentShape(Capsule())
                    }
                    .buttonStyle(.press)
                    .accessibilityAddTraits(sel ? .isSelected : [])
                }
            }
            .padding(.horizontal, 20)
        }
        .scrollIndicators(.hidden)
        .padding(.horizontal, -20)
    }
}
