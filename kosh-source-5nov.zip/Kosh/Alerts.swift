import Foundation
import SwiftUI
import UIKit
import AppIntents

// MARK: - Payments told only by SMS or a notification
//
// An iPhone app can't read SMS. What it can do is offer an action ("Add to kosh") that a Shortcuts automation runs
// for each new message. There is one shortcut, "kosh alerts", and one automation that runs it. Three gates, narrowing:
//  1. the shortcut's own Match Text (AlertSetup.filter), run by Shortcuts on the phone for each message the automation
//     sees: only a message with a sum or a money word and no code to type in is handed to kosh at all;
//  2. the action checks the same words again (AlertIntake.looksLikeMoney) and keeps nothing of a message that fails;
//  3. the engine that reads mail reads it (engine/22s-sms-alerts.js) and keeps only a payment.
// Honest about gate 1: iOS runs the automation for every message it is set to see and the shortcut tests each one,
// inside Shortcuts on the phone; nothing that fails the test is handed to kosh or kept.
//
// The shortcut is written from code (tools/make-shortcut.js reads `filter` and `name` below out of this file), so its
// filter can never drift from the app's. iOS gives an app no way to make an automation: the user makes it in Shortcuts
// (AlertsTurnOn walks it), and kosh checks the shortcut and the action itself, and the automation by the messages that
// arrive (AlertsSetupView says when the last one did, or that none has).
//
// A message that reached kosh is never lost on the way in: it is sealed into MailVault, or, when the phone's Keychain
// can't be read yet, held in a file iOS keeps unreadable until the phone is unlocked (AlertIntake.hold), and read into
// the ledger when kosh next runs on screen (takeAlerts). The engine never runs inside the action: a cold engine in a
// background launch is slow and can be stopped mid-read, and what it would decide is decided at takeAlerts.

/// the action the automation runs
struct AddToKoshIntent: AppIntent {
    static let title: LocalizedStringResource = "Add to kosh"
    static let description = IntentDescription("Hands a bank’s SMS or a payment app’s notification to kosh. kosh keeps it only if it’s a payment, and nothing leaves your phone.")
    static let openAppWhenRun: Bool = false
    static let isDiscoverable: Bool = true

    /// (the message, from the shortcut's input: kosh's own check hands over its test words instead, and keeps nothing of
    /// them; a run that hands over no words at all is counted, so a shortcut wired wrong shows in Settings)
    @Parameter(title: "Message", inputConnectionBehavior: .connectToPreviousIntentResult)
    var message: String?

    @Parameter(title: "From", description: "Who sent it: the SMS sender, or the app the notification is from")
    var from: String?

    @Parameter(title: "Title", description: "A notification’s title")
    var title: String?

    @Parameter(title: "Is a notification", default: false)
    var notification: Bool

    static var parameterSummary: some ParameterSummary {
        Summary("Add \(\.$message) to kosh") {
            \.$from
            \.$title
            \.$notification
        }
    }

    func perform() async throws -> some IntentResult {
        AlertIntake.take(text: message ?? "", from: from ?? "", title: title ?? "", notification: notification)
        return .result()
    }
}

enum AlertIntake {
    /// every record from an SMS or a notification carries this before its id: never fetched from an inbox
    static let prefix = "sms-"
    static let pendingKey = "alerts.pending"
    /// when the last message reached kosh (past the shortcut's filter), and how many have
    static let lastKey = "alerts.last"
    static let reachedKey = "alerts.reached"
    /// how many payments came this way into the ledger
    static let countKey = "alerts.count"
    static let droppedKey = "alerts.dropped"
    static let dropLogKey = "alerts.dropLog"
    /// how many times the shortcut called kosh with no words, and when last: its message isn't wired to its input
    static let emptyKey = "alerts.empty"
    static let emptyAtKey = "alerts.emptyAt"
    /// how many SMS came with no sender (the shortcut didn't hand it over): kosh reads the bank from the words then
    static let noSenderKey = "alerts.noSender"
    /// every message the shortcut handed kosh, newest last: when, who (a business's sender, never a person's number) and
    /// "in" or why not; never the words. Beside the bank's own mail it tells a payment kosh never got from one it dropped
    static let arrivalsKey = "alerts.arrivals"
    /// the pending list and the words seen lately are changed by the action (on its own thread) and by takeAlerts (on
    /// the main thread): one at a time, so neither loses the other's
    private static let lock = NSLock()

    /// (cheap, before the engine is asked, and the same words the shortcut itself matched on the phone
    /// (AlertSetup.money, AlertSetup.never): only a message with a sum of money (₹, Rs, INR, $) or a money word
    /// (debited, credited, spent, paid, UPI…) and a number goes on, and never one carrying a code to type in.
    /// The engine then keeps only a payment.)
    static let money = try! NSRegularExpression(pattern: "(?i)(?:" + AlertSetup.money + ")")
    static let digit = try! NSRegularExpression(pattern: #"\d"#)
    /// a one-time password, a verification, security or login code, a passcode or a PIN with its digits beside it:
    /// dropped whatever else the message says. Never the "never share your OTP" line a bank's own alert ends with,
    /// which carries no digits. The same words as the engine's (engine/22s-sms-alerts.js › SMS_OTP, SMS_CODE).
    static let code = try! NSRegularExpression(pattern: "(?i)(?:" + AlertSetup.never + ")")

    static func looksLikeMoney(_ s: String) -> Bool { whyNot(s) == nil }
    /// why a message isn't sent on, or nil when it is (engine-test/sms-filter.js runs the same three patterns)
    static func whyNot(_ s: String) -> String? {
        let r = NSRange(s.startIndex..., in: s)
        if code.firstMatch(in: s, range: r) != nil { return "code" }
        if money.firstMatch(in: s, range: r) == nil || digit.firstMatch(in: s, range: r) == nil { return "no-money" }
        return nil
    }

    /// every message whose words kosh has already seen, and when that telling of it started: at most a day back
    static let seenKey = "alerts.seen"
    /// the record's id: one message handed over twice is one record. A Shortcuts automation can fire more than once
    /// for the same message, and not always in the same minute, so the id is the sender and the words alone; the same
    /// words from the same sender more than ten minutes later are a second payment and take an id of their own.
    static func id(text: String, from: String, at: Date) -> String {
        let key = from.lowercased() + "|" + text.trimmingCharacters(in: .whitespacesAndNewlines)
        let base = String(LiveSession.stable(key), radix: 36) + String(LiveSession.stable(String(key.reversed())), radix: 36)
        lock.lock(); defer { lock.unlock() }
        let ud = UserDefaults.standard
        let now = at.timeIntervalSince1970
        var seen: [String: Double] = (ud.dictionary(forKey: seenKey) as? [String: Double]) ?? [:]
        seen = seen.filter { now - $0.value < 86_400 }          // (yesterday's words forgotten: the list stays short)
        let began: Double = seen[base].map { now - $0 <= 600 ? $0 : now } ?? now
        seen[base] = began
        ud.set(seen, forKey: seenKey)
        return prefix + base + String(Int(began / 60), radix: 36)
    }

    /// the messages sealed and waiting to be read into the ledger
    static var pending: [String] { lock.lock(); defer { lock.unlock() }; return UserDefaults.standard.stringArray(forKey: pendingKey) ?? [] }
    static func addPending(_ ids: [String]) {
        guard !ids.isEmpty else { return }
        lock.lock(); defer { lock.unlock() }
        let ud = UserDefaults.standard
        var p: [String] = ud.stringArray(forKey: pendingKey) ?? []
        for id in ids where !p.contains(id) { p.append(id) }
        ud.set(Array(p.suffix(500)), forKey: pendingKey)
    }
    /// those read (or gone for good) off the list; any handed over meanwhile stay on it
    static func clearPending(_ done: Set<String>) {
        guard !done.isEmpty else { return }
        lock.lock(); defer { lock.unlock() }
        let ud = UserDefaults.standard
        let p: [String] = (ud.stringArray(forKey: pendingKey) ?? []).filter { !done.contains($0) }
        if p.isEmpty { ud.removeObject(forKey: pendingKey) } else { ud.set(p, forKey: pendingKey) }
    }

    /// one message from the automation, past the shortcut's filter: checked once more, then sealed to wait for the
    /// ledger (or held, when it can't be sealed yet). Anything else is gone, and nothing of it is kept.
    static func take(text raw: String, from rawFrom: String, title rawTitle: String, notification: Bool, at: Date = Date()) {
        let text = String(raw.prefix(1200)).trimmingCharacters(in: .whitespacesAndNewlines)
        let from = String(rawFrom.prefix(80)).trimmingCharacters(in: .whitespacesAndNewlines)
        let title = String(rawTitle.prefix(120)).trimmingCharacters(in: .whitespacesAndNewlines)
        let ud = UserDefaults.standard
        // kosh's own check while turning it on: its words came through the shortcut's filter and this action, so both
        // are in place. Nothing of it is kept.
        if text == AlertSetup.testText { ud.set(at.timeIntervalSince1970, forKey: AlertSetup.verifiedKey); return }
        // no words at all: the shortcut ran but its message isn't wired to its input (or it was run by hand). Never a
        // pass for the check (until 30 Oct it was, so a shortcut handing over nothing looked set up and every SMS was
        // swallowed without a trace); counted, so Settings can say so
        if text.isEmpty && title.isEmpty {
            ud.set(ud.integer(forKey: emptyKey) + 1, forKey: emptyKey)
            ud.set(at.timeIntervalSince1970, forKey: emptyAtKey)
            return
        }
        ud.set(at.timeIntervalSince1970, forKey: lastKey)
        ud.set(ud.integer(forKey: reachedKey) + 1, forKey: reachedKey)
        let why0: String? = whyNot(title + " " + text)
        noteArrival(why0 ?? "in", from: from, notification: notification, at: at)
        if let why = why0 { noteDrop(why, from: from, notification: notification, at: at); return }
        if from.isEmpty && !notification { ud.set(ud.integer(forKey: noSenderKey) + 1, forKey: noSenderKey) }
        var m = MailMsg(id: id(text: text, from: from, at: at), from: from, date: Gmail.isoStamp.string(from: at), subject: "", text: text, html: "")
        m.chan = notification ? "notif" : "sms"
        if !title.isEmpty { m.title = title }
        if MailVault.putNow(m, id: m.id) { addPending([m.id]) } else { hold(m) }
        // kosh on screen: into the ledger now. Woken in the background for this (the phone may be locked), it waits
        // for kosh to come to the front (RootView.catchUp), where the engine is warm and has time
        Task { @MainActor in
            guard UIApplication.shared.applicationState == .active else { return }
            LiveSession.current?.takeAlerts()
        }
    }

    /// a message dropped, for Settings and the diagnostics: when, the bank's sender ID or the app's name (never a
    /// person's number, never the words) and why
    /// who sent it, as the logs may name it: a business's sender ID or app as the phone shows it ("AX-HDFCBK-S",
    /// "HDFCBANK": capitals and digits, as iOS shows a sender ID), or the app's name for a notification; else only what kind
    /// of sender (never a person's number or a contact's name)
    static func whoOf(_ from: String, notification: Bool) -> String {
        if notification { return from }
        if from.isEmpty { return "no sender" }
        if from.range(of: #"^[A-Z0-9]{2,9}(-[A-Z0-9]{1,9}){0,2}$"#, options: .regularExpression) != nil,
           from.range(of: #"\d{5,}"#, options: .regularExpression) == nil, from.range(of: #"[A-Z]{4,}"#, options: .regularExpression) != nil { return from }
        let digits: Int = from.filter(\.isNumber).count
        return digits >= 5 ? "a number (\(digits) digits)" : "a contact"
    }
    static func noteArrival(_ what: String, from: String, notification: Bool, at: Date) {
        lock.lock(); defer { lock.unlock() }
        let ud = UserDefaults.standard
        var log = ud.stringArray(forKey: arrivalsKey) ?? []
        log.append(Gmail.isoStamp.string(from: at) + " · " + whoOf(from, notification: notification) + " · " + what)
        ud.set(Array(log.suffix(120)), forKey: arrivalsKey)
    }
    static func noteDrop(_ why: String, from: String, notification: Bool, at: Date = Date()) {
        lock.lock(); defer { lock.unlock() }
        let ud = UserDefaults.standard
        ud.set(ud.integer(forKey: droppedKey) + 1, forKey: droppedKey)
        let who: String = whoOf(from, notification: notification)
        var log = ud.stringArray(forKey: dropLogKey) ?? []
        log.append(Gmail.isoStamp.string(from: at) + " · " + who + " · " + why)
        ud.set(Array(log.suffix(30)), forKey: dropLogKey)
    }

    /// a drop's reason in plain words (the drop log keeps the engine's own rule name)
    static func plain(_ why: String) -> String {
        // (smsshape-5nov-b) the shape kept beside a reason isn't part of it
        let w0: String = why.components(separatedBy: " [").first ?? why
        let w = w0.replacingOccurrences(of: "sms-", with: "").replacingOccurrences(of: "notif-", with: "")
        switch w {
        case "code": return "A code to type in"
        case "no-money", "not-money": return "No sum of money"
        case "not-payment": return "Not a payment that went through (due, failed, a request)"
        case "offer": return "An offer"
        case "unknown-sender": return "Not from a bank or an app kosh knows"
        case "no-direction": return "Couldn’t tell money in from money out"
        case "shop-not-order": return "A shop’s message, not an order"
        case "unreadable": return "Couldn’t be read"
        default: return "Not a payment"
        }
    }

    // MARK: held, not lost

    /// A message that passed both gates but couldn't be sealed (the Keychain not readable yet): kept in a file iOS
    /// protects "unless open", which can be written while the phone is locked and can't be read by anyone until it is
    /// unlocked; sealed into the vault, and this file removed, the next time kosh runs (takeAlerts). Inside kosh's own
    /// folder, so Erase takes it too.
    static var heldFolder: URL { LiveSession.folder.appendingPathComponent("alerts-held", isDirectory: true) }
    static func hold(_ m: MailMsg) {
        try? FileManager.default.createDirectory(at: heldFolder, withIntermediateDirectories: true)
        guard let d = try? JSONEncoder().encode(m) else { return }
        try? d.write(to: heldFolder.appendingPathComponent(m.id + ".json"), options: [.atomic, .completeFileProtectionUnlessOpen])
    }
    /// the held messages sealed now, their ids (one still unreadable stays where it is for next time)
    static func sealHeld() -> [String] {
        let fm = FileManager.default
        guard let items = try? fm.contentsOfDirectory(at: heldFolder, includingPropertiesForKeys: nil) else { return [] }
        var ids: [String] = []
        for u in items where u.pathExtension == "json" {
            guard let d = try? Data(contentsOf: u) else { continue }
            guard let m = try? JSONDecoder().decode(MailMsg.self, from: d) else { try? fm.removeItem(at: u); continue }
            if MailVault.putNow(m, id: m.id) { try? fm.removeItem(at: u); ids.append(m.id) }
        }
        return ids
    }
    static var heldCount: Int {
        ((try? FileManager.default.contentsOfDirectory(at: heldFolder, includingPropertiesForKeys: nil)) ?? []).count(where: { $0.pathExtension == "json" })
    }

    /// when the last message reached kosh, and how many payments came that way
    static var lastAt: Date? { let t = UserDefaults.standard.double(forKey: lastKey); return t > 0 ? Date(timeIntervalSince1970: t) : nil }
    static var count: Int { UserDefaults.standard.integer(forKey: countKey) }
}

extension LiveSession {
    /// the payments handed over by SMS or a notification, into the ledger; and those read by older code, read again
    /// from their sealed copy (ReadingPrint.sms: a change to how an SMS is read never reads the year of mail). Nothing
    /// is struck off unless it was read: a copy the Keychain can't open yet, or an engine that can't answer now, waits
    /// for the next time (until 30 Oct both were dropped, and the payment with them).
    @MainActor
    func takeAlerts() {
        guard loadedFromDisk else { return }
        // what waited unsealed (it came while the Keychain couldn't be read): sealed now
        AlertIntake.addPending(AlertIntake.sealHeld())
        let pending: Set<String> = Set(AlertIntake.pending)
        let want = ReadingPrint.sms
        let stale: [String] = records.filter { $0.id.hasPrefix(AlertIntake.prefix) && $0.rp != want }.map(\.id)
        let ids: [String] = Array(pending.union(stale))
        guard !ids.isEmpty else { return }
        let had: Set<String> = Set(records.lazy.filter { $0.id.hasPrefix(AlertIntake.prefix) }.map(\.id))
        var fresh: [Reading] = []
        var gone: Set<String> = []
        var done: Set<String> = []
        var waiting = 0
        for id in ids {
            guard let m = MailVault.get(id) else {
                // sealed, but not openable now: next time. No copy at all: nothing to read (a stale record keeps its reading)
                if MailVault.has(id) { waiting += 1 } else if pending.contains(id) { done.insert(id) }
                continue
            }
            let isNew: Bool = pending.contains(id) && !had.contains(id)
            // (one that stopped the engine before, by this code: never tried again)
            if ParseGuard.skip(id) {
                done.insert(id); gone.insert(id); MailVault.drop(id)
                if isNew { AlertIntake.noteDrop("unreadable", from: m.from, notification: m.chan == "notif") }
                continue
            }
            guard var r = Self.readingOf(m, acct: "", tag: "", me: email, checkMode: "off") else { waiting += 1; continue }
            done.insert(id)
            if r.kind == "noise" || r.kind == "unknown" {
                gone.insert(id)
                MailVault.drop(id)
                // (smsshape-5nov) a business sender's dropped SMS: its shape in kosh's own words, never its words
                var why: String = r.rule ?? "not-payment"
                if m.chan != "notif", AlertIntake.whoOf(m.from, notification: false) == m.from,
                   let out = try? Engine.shared.call("smsShapeJSON", [m.text]), let shape = try? JSONText.decode(String.self, out), !shape.isEmpty {
                    why += " [" + shape + "]"
                }
                if isNew { AlertIntake.noteDrop(why, from: m.from, notification: m.chan == "notif") }
            } else {
                r.rp = want
                fresh.append(r)
            }
        }
        AlertIntake.clearPending(done)
        guard !fresh.isEmpty || !gone.isEmpty else { if waiting > 0 { note("alerts: \(waiting) waiting") }; return }
        // one write for all of them: the screens redraw once
        var next = records
        var at: [String: Int] = [:]
        for i in next.indices { at[next[i].id] = i }
        var added = 0
        for r in fresh {
            if let i = at[r.id] {
                next[i] = r
            } else { at[r.id] = next.count; next.append(r); added += 1 }
        }
        if !gone.isEmpty { next.removeAll { gone.contains($0.id) && $0.id.hasPrefix(AlertIntake.prefix) } }
        records = next
        if added > 0 { UserDefaults.standard.set(AlertIntake.count + added, forKey: AlertIntake.countKey) }
        note("alerts: \(fresh.count) in, \(gone.count) dropped, \(waiting) waiting")
        save()
        rebuildSoon()
    }
}

// MARK: - Turning it on

enum AlertSetup {
    /// The one ready-made shortcut, "kosh alerts", written by tools/make-shortcut.js from `filter` and `name` below (never
    /// built by hand: the hand-built one kept a stale filter for days), signed on the Mac and shared as this link. It
    /// filters (Match Text, `filter`) and hands over ("Add to kosh"): a message that doesn't match ends there, on the
    /// phone, and never reaches kosh. The automation that runs it is made by the user in Shortcuts: iOS has no way for
    /// an app to make one. When the shortcut is rebuilt, the new link goes here.
    static let shortcutLink = "https://www.icloud.com/shortcuts/845a6ca7658f413494f19d8f3d469a6c"
    /// a sum of money, or a money word with a number somewhere in the message
    static let money = #"₹|\brs\.?\s?\d|\binr\b|\busd\b|\$\s?\d|\b(?:debited|credited|spent|withdrawn|withdrawal|deducted|refunded|reversed|transferred|paid|payment|purchase|txn|transaction|upi|neft|imps|rtgs|autopay)\b"#
    /// a code to type in, with its digits beside it: a one-time password, a verification, security or login code, a
    /// passcode, a PIN. Never the "never share your OTP" line a bank's own alert ends with, which carries no digits
    static let never = #"\b(?:otp|o\.t\.p|one[- ]?time\s+(?:password|passcode|pass code|pin)|verification\s+code|security\s+code|login\s+code|passcode)\b[^.\n]{0,40}?\b\d{3,8}\b|\b\d{3,8}\b[^.\n]{0,30}?\b(?:otp|one[- ]?time\s+(?:password|passcode)|verification\s+code|security\s+code|login\s+code)\b|\b\d{3,8}\b[^.\n]{0,25}?\b(?:is|as)\s+(?:your|the)\s+(?:[a-z]+\s+){0,2}?(?:code|pin|password|passcode)\b|\b(?:code|pin|passcode|password)\b[^.\n]{0,25}?\bis\b\s*[:\-]?\s*\d{3,8}\b"#
    /// the pattern the shortcut's Match Text step holds, and the whole of what is handed to kosh: money in it, and no
    /// code in it. tools/make-shortcut.js writes it into the shortcut from here; it is in the diagnostics too
    static let filter = "(?si)^(?!.*(?:" + never + ")).*(?:" + money + ").*$"
    /// what the automation's "Message Contains" holds: one space. iOS 26 asks for a sender or some words, a bank's
    /// sender ID can't be picked as a sender, and banks write Rs, Rs., INR, ₹ or (SBI's UPI alerts) no currency at all,
    /// so no one word catches them all; a space is in every one. The shortcut's filter does the choosing.
    static let contains = " "
    /// on: a message reached kosh in the last fortnight
    static var on: Bool { AlertIntake.lastAt.map { Date().timeIntervalSince($0) < 14 * 86_400 } ?? false }
    /// the shortcut's name, as Shortcuts URLs take it
    static let name = "kosh alerts"
    static var nameQuery: String { name.addingPercentEncoding(withAllowedCharacters: .alphanumerics) ?? "kosh%20alerts" }
    /// The message kosh hands the shortcut while checking the setup. It carries a sum, so it goes through the shortcut's
    /// own filter as a bank's SMS would, and only the action hearing it marks the check passed (`verifiedKey`): Shortcuts
    /// coming back alone (`ranKey`) proves only that a shortcut of that name exists. Nothing of it is kept.
    static let testText = "kosh setup check Rs 1"
    static var testQuery: String { testText.addingPercentEncoding(withAllowedCharacters: .alphanumerics) ?? "" }
    static let verifiedKey = "alerts.verified"
    static let ranKey = "alerts.ran"
    static let failedKey = "alerts.failed"
    /// the setup's step while it's under way (and when), so it carries on if iOS closes kosh meanwhile
    static let stageKey = "alerts.setupStage"
    static var pendingStage: String? {
        let ud = UserDefaults.standard
        guard let s = ud.string(forKey: stageKey), Date().timeIntervalSince1970 - ud.double(forKey: stageKey + "At") < 1200 else { return nil }
        return s
    }
    static func keep(_ stage: String?) {
        let ud = UserDefaults.standard
        ud.set(stage, forKey: stageKey)
        ud.set(Date().timeIntervalSince1970, forKey: stageKey + "At")
    }
}

/// What Settings › Payments by SMS says, from what the phone recorded: when it was set up, when the last message
/// reached kosh, what was kept and what dropped and why, and what is wrong when nothing arrives
struct AlertsState {
    var setUp: Date?
    var last: Date?
    var reached: Int
    var kept: Int
    var dropped: Int
    /// the drop log's reasons, most first (plain words, count)
    var reasons: [(String, Int)]
    var empty: Int
    var emptyAt: Date?
    var waiting: Int

    static func now(kept: Int) -> AlertsState {
        let ud = UserDefaults.standard
        let d = { (k: String) -> Date? in let t = ud.double(forKey: k); return t > 0 ? Date(timeIntervalSince1970: t) : nil }
        var by: [String: Int] = [:]
        for line in ud.stringArray(forKey: AlertIntake.dropLogKey) ?? [] {
            guard let why = line.components(separatedBy: " · ").last else { continue }
            by[AlertIntake.plain(why), default: 0] += 1
        }
        let reasons: [(String, Int)] = by.sorted { $0.value != $1.value ? $0.value > $1.value : $0.key < $1.key }.map { ($0.key, $0.value) }
        return AlertsState(setUp: d(AlertSetup.verifiedKey), last: AlertIntake.lastAt, reached: ud.integer(forKey: AlertIntake.reachedKey), kept: kept,
                           dropped: ud.integer(forKey: AlertIntake.droppedKey), reasons: reasons, empty: ud.integer(forKey: AlertIntake.emptyKey),
                           emptyAt: d(AlertIntake.emptyAtKey), waiting: AlertIntake.pending.count + AlertIntake.heldCount)
    }

    enum Health { case off, working, silent, unwired, stopped }   // (smsstop-5nov) stopped: worked, then nothing for 4 days
    /// off: never set up; working: messages arrive; silent: set up, and nothing has arrived since; unwired: the shortcut
    /// calls kosh with no words (an old or hand-built copy)
    var health: Health {
        if let e = emptyAt, e > (last ?? .distantPast) { return .unwired }
        if let s = setUp, (last ?? .distantPast) < s { return .silent }
        if let l = last, Date().timeIntervalSince(l) > 4 * 86400 { return .stopped }
        return last == nil ? (setUp == nil ? .off : .silent) : .working
    }
}

/// Settings › Payments by SMS: whether it works, told plainly, and the way to turn it on or mend it
struct AlertsSetupView: View {
    @Environment(Store.self) private var store
    @State private var turningOn = false
    // (watched so the screen redraws as a check passes or a message arrives while it's open)
    @AppStorage(AlertSetup.verifiedKey) private var verified: Double = 0
    @AppStorage(AlertIntake.lastKey) private var lastSeen: Double = 0

    var body: some View {
        let kept: Int = store.live?.records.count(where: { $0.id.hasPrefix(AlertIntake.prefix) }) ?? AlertIntake.count
        let _ = verified + lastSeen
        let s = AlertsState.now(kept: kept)
        List {
            Section {
                VStack(alignment: .leading, spacing: 14) {
                    AlertsArt().frame(maxWidth: .infinity)
                    Eyebrow(text: "Payments by SMS", color: Color.kosh)
                    Text(s.health == .working ? "kosh catches your bank’s SMS" : "Catch every payment, even the ones that never email you")
                        .font(.system(.title2, design: .serif, weight: .semibold))
                    Text("A quick UPI at a shop, an order on Blinkit or Flipkart: some payments come only by SMS. kosh reads those too, right here on your iPhone.")
                        .font(.subheadline).foregroundStyle(.secondary)
                    status(s)
                    Button { turningOn = true } label: {
                        Text(s.health == .off ? "Turn on" : "Set it up again").font(.headline).frame(maxWidth: .infinity).padding(.vertical, 8)
                    }
                    .buttonStyle(.borderedProminent)
                    .buttonBorderShape(.capsule)
                }
                .padding(.vertical, 8)
            }
            if s.health != .off {
                Section {
                    row("Last message reached kosh", s.last.map { AlertsTurnOn.when($0) } ?? "None yet")
                    row("Payments kept", Fmt.inr(Double(s.kept)))
                    row("Messages dropped", Fmt.inr(Double(s.dropped)))
                    if s.waiting > 0 { row("Waiting for you to open kosh", Fmt.inr(Double(s.waiting))) }
                    if let set = s.setUp { row("Shortcut last checked", AlertsTurnOn.when(set)) }
                } header: { Text("What has come in") } footer: {
                    Text("Counts only. kosh keeps no words of a message it drops.")
                }
                if !s.reasons.isEmpty {
                    Section {
                        ForEach(Array(s.reasons.enumerated()), id: \.offset) { _, r in row(r.0, Fmt.inr(Double(r.1))) }
                    } header: { Text("Why the last ones were dropped") }
                }
            }
            Section {
                Label("Your iPhone runs the kosh alerts shortcut for each new message and checks it right there, in Shortcuts. Only a message with a sum like ₹2,30,908 or a bank word is handed to kosh; a chat never is.", systemImage: "lock.shield")
                Label("A one-time password never reaches kosh. Nor a code, a PIN or a password, even when the message mentions money too.", systemImage: "eye.slash")
                Label("Nothing leaves your iPhone. Each SMS is read here, like your mail.", systemImage: "iphone")
                Label("A payment told by SMS, by your UPI app and by email counts once.", systemImage: "equal.circle")
                Label("When kosh isn’t sure a message is a payment, it keeps nothing of it.", systemImage: "hand.raised")
            } header: { Text("What kosh does with them") }
        }
        .navigationTitle("Payments by SMS")
        .navigationBarTitleDisplayMode(.inline)
        .fullScreenCover(isPresented: $turningOn) { AlertsTurnOn() }
    }

    /// the one line of truth under the title: working, or what's wrong and the fix
    @ViewBuilder func status(_ s: AlertsState) -> some View {
        switch s.health {
        case .off: EmptyView()
        case .working:
            Label("On · last message " + (s.last.map { AlertsTurnOn.when($0) } ?? ""), systemImage: "checkmark.circle.fill")
                .font(.subheadline.weight(.semibold)).foregroundStyle(Color(hex: "#2E7D4F"))
        case .silent:
            VStack(alignment: .leading, spacing: 6) {
                Label("No message has reached kosh since you set it up" + (s.setUp.map { ", " + AlertsTurnOn.when($0) } ?? ""), systemImage: "exclamationmark.triangle.fill")
                    .font(.subheadline.weight(.semibold)).foregroundStyle(.orange)
                Text("If your bank has texted since, the automation isn’t running it. In Shortcuts › Automation, the Message one must say Message Contains “ ” (one space), Run Immediately, and run kosh alerts. Or tap Set it up again.")
                    .font(.footnote).foregroundStyle(.secondary)
            }
        case .stopped:
            VStack(alignment: .leading, spacing: 6) {
                Label("No message has reached kosh since " + (s.last.map { AlertsTurnOn.when($0) } ?? "a while"), systemImage: "exclamationmark.triangle.fill")
                    .font(.subheadline.weight(.semibold)).foregroundStyle(.orange)
                Text("It worked before, so the automation has likely been turned off (an iOS update or a Focus can do that). In Shortcuts › Automation, check the Message one is on and set to Run Immediately. Until then, balances may miss payments your bank only texted.")
                    .font(.footnote).foregroundStyle(.secondary)
            }
        case .unwired:
            VStack(alignment: .leading, spacing: 6) {
                Label("The shortcut ran \(s.empty) time\(s.empty == 1 ? "" : "s") without handing kosh the message", systemImage: "exclamationmark.triangle.fill")
                    .font(.subheadline.weight(.semibold)).foregroundStyle(.orange)
                Text("It’s an old copy. Delete kosh alerts in Shortcuts, then tap Set it up again to add the new one.")
                    .font(.footnote).foregroundStyle(.secondary)
            }
        }
    }

    func row(_ k: String, _ v: String) -> some View {
        HStack { Text(k); Spacer(); Text(v).foregroundStyle(.secondary).monospacedDigit() }
    }
}

/// Turning it on, in three steps and nothing else: add the one shortcut, make the one automation that runs it, and
/// kosh checks it worked. Each step says one thing, with one button; coming back to kosh moves to the next step by
/// itself. There is no second path and no second shortcut: when a step won't go through, the same step waits.
struct AlertsTurnOn: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.openURL) private var openURL
    @Environment(\.scenePhase) private var phase
    @AppStorage(AlertSetup.verifiedKey) private var verified: Double = 0
    @AppStorage(AlertSetup.ranKey) private var ran: Double = 0
    @AppStorage(AlertSetup.failedKey) private var failed: Double = 0

    enum Stage: String { case start, adding, flip, checking, done }
    /// where the setup is, kept on the phone: iOS may close kosh while you're in Shortcuts, and coming back carries on
    /// from the same step (KoshApp reopens it)
    @State private var stage: Stage = AlertSetup.pendingStage.flatMap(Stage.init(rawValue:)) ?? .start
    @State private var checkedOnce = false
    @State private var started = Date()
    /// the check came back from Shortcuts but the action never heard kosh's words: the shortcut is an old copy
    @State private var oldCopy = false

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Spacer()
                Button { AlertSetup.keep(nil); dismiss() } label: {
                    Image(systemName: "xmark").font(.system(size: 15, weight: .semibold)).frame(width: 44, height: 44)
                }
                .buttonStyle(.glass)
                .accessibilityLabel("Close")
            }
            .padding(.horizontal, 20).padding(.top, 8)
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    dots
                    content
                }
                .padding(.horizontal, 24).padding(.top, 8).padding(.bottom, 40)
                .animation(Motion.open, value: stage)
            }
        }
        .background(Color(.systemBackground))
        .onChange(of: stage) { _, s in stageChanged(s) }
        .onDisappear { if stage == .done { AlertSetup.keep(nil) } }
        // back in kosh from Shortcuts: on to the next step by itself
        .onChange(of: phase) { _, p in phaseChanged(p) }
        .onChange(of: verified) { _, v in verifiedChanged(v) }
        .sensoryFeedback(.success, trigger: stage == .done)
    }

    func stageChanged(_ s: Stage) {
        let keep: Bool = s == .adding || s == .flip || s == .checking
        AlertSetup.keep(keep ? s.rawValue : nil)
    }
    func phaseChanged(_ p: ScenePhase) {
        guard p == .active else { return }
        let since: Double = started.timeIntervalSince1970
        switch stage {
        case .adding: stage = .flip
        case .checking:
            // (the check came back: done by verifiedChanged; if not, it stays here to be run again)
            if verified < since {
                checkedOnce = true
                // Shortcuts found no "kosh alerts": back to adding it
                if failed >= since { stage = .start }
                // it ran, and the action never heard kosh's words: an old or hand-built copy
                else if ran >= since { oldCopy = true; stage = .start }
            }
        default: break
        }
    }
    func verifiedChanged(_ v: Double) {
        guard v >= started.timeIntervalSince1970 else { return }
        oldCopy = false
        withAnimation(Motion.base) { stage = .done }
    }

    var dots: some View {
        let n: Int = stage == .start ? 0 : stage == .adding || stage == .flip ? 1 : 2
        return HStack(spacing: 6) {
            ForEach(0..<3, id: \.self) { i in
                Capsule().fill(i <= n ? Color.kosh : Color(.systemGray4)).frame(width: i == n ? 22 : 8, height: 8)
            }
        }
    }

    /// what to say under the first button: the plain line, or what the last check found
    var addHint: String {
        if oldCopy { return "The kosh alerts in your Shortcuts is an old copy. Delete it there (press and hold it, then Delete), then tap the button above and Add Shortcut." }
        let justFailed: Bool = failed > 0 && failed >= started.timeIntervalSince1970 - 600
        if justFailed { return "The shortcut isn’t in Shortcuts yet. Tap the button above, then tap Add Shortcut." }
        return "Shortcuts opens. Tap Add Shortcut at the bottom, then come back here."
    }

    @ViewBuilder var content: some View {
        switch stage {
        case .start:
            AlertsArt().frame(maxWidth: .infinity).padding(.vertical, 8)
            title("Catch every payment", "Even the ones that never email you. One shortcut, about a minute.")
            promise
            big("Add the kosh shortcut") { started = Date(); stage = .adding; if let u = URL(string: AlertSetup.shortcutLink) { openURL(u) } }
            note(addHint)
        case .adding, .flip:
            AutomationArt().frame(maxWidth: .infinity).padding(.vertical, 8)
            title("Now tell it when to run", "Your iPhone only lets you set this yourself, in Shortcuts › Automation:")
            handStep(1, "Tap + (or New Automation), then Message")
            handStep(2, "Tap Message Contains, type one space, tap Done")
            handStep(3, "Choose Run Immediately, turn Notify When Run off, tap Next")
            handStep(4, "Tap kosh alerts")
            note("The space lets every bank’s SMS through to the shortcut, whichever way it writes the sum; the shortcut then hands kosh only the money ones.")
            big("Open Shortcuts") { started = Date(); stage = .flip; if let u = URL(string: "shortcuts://automation") { openURL(u) } }
            Button("I’ve made it") { started = Date(); checkedOnce = false; stage = .checking }
                .font(.headline).frame(maxWidth: .infinity).padding(.vertical, 12)
        case .checking:
            AllowArt().frame(maxWidth: .infinity).padding(.vertical, 8)
            title("Last, a quick check", "kosh runs the shortcut once with a test message. If iPhone asks to allow “kosh alerts”, tap Allow, then come back here.")
            big(checkedOnce ? "Run the check again" : "Run the check") { check() }
            if checkedOnce { note("Didn’t finish? Tap Allow when iPhone asks, then come back to kosh.") }
        case .done:
            DoneArt().frame(maxWidth: .infinity).padding(.vertical, 8)
            title("You’re all set", "Your next bank SMS lands in kosh by itself. Settings › Payments by SMS shows when the last one came in.")
            big("Done") { AlertSetup.keep(nil); dismiss() }
        }
    }

    /// the check: the shortcut is run once on kosh's own test message, so the filter and the "Add to kosh" action are
    /// both proved (only the action hearing those words passes it); Shortcuts coming back alone proves only the name
    func check() {
        started = Date()
        let back = "kosh://alerts-ok", fail = "kosh://alerts-failed"
        let q = "shortcuts://x-callback-url/run-shortcut?name=" + AlertSetup.nameQuery
            + "&input=text&text=" + AlertSetup.testQuery
            + "&x-success=" + (back.addingPercentEncoding(withAllowedCharacters: .alphanumerics) ?? "")
            + "&x-error=" + (fail.addingPercentEncoding(withAllowedCharacters: .alphanumerics) ?? "")
        if let u = URL(string: q) { openURL(u) }
    }

    var promise: some View {
        VStack(alignment: .leading, spacing: 10) {
            row("lock.shield.fill", "Only money messages reach kosh. Your iPhone checks each message in Shortcuts and hands kosh only one with a sum or a bank word, so chats never get here.")
            row("eye.slash.fill", "A one-time password, a code, a PIN or a password never reaches kosh, even when the message mentions money too.")
            row("iphone", "Read on your iPhone. Nothing leaves it.")
            row("equal.circle.fill", "Never counted twice: SMS, UPI app and email together count once.")
            row("hand.raised.fill", "Unsure? Then nothing is kept. kosh would rather miss one than keep what it shouldn’t.")
        }
    }
    func row(_ sym: String, _ text: String) -> some View {
        HStack(spacing: 12) {
            Image(systemName: sym).font(.system(size: 17, weight: .semibold)).foregroundStyle(Color.kosh).frame(width: 26)
            Text(text).font(.subheadline)
        }
    }
    func title(_ t: String, _ sub: String) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(t).font(.system(.largeTitle, design: .serif, weight: .semibold))
            Text(sub).font(.body).foregroundStyle(.secondary)
        }
        .transition(.asymmetric(insertion: .move(edge: .trailing).combined(with: .opacity), removal: .opacity))
    }
    func big(_ label: String, _ act: @escaping () -> Void) -> some View {
        Button(action: act) { Text(label).font(.headline).frame(maxWidth: .infinity).padding(.vertical, 10) }
            .buttonStyle(.borderedProminent).buttonBorderShape(.capsule).padding(.top, 6)
    }
    func note(_ t: String) -> some View {
        Text(t).font(.footnote).foregroundStyle(.secondary).padding(14)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(RoundedRectangle(cornerRadius: 18).fill(Color(.secondarySystemBackground)))
    }
    /// one of the taps to make in Shortcuts, named as iOS names it on the screen
    func handStep(_ n: Int, _ text: String) -> some View {
        HStack(alignment: .center, spacing: 14) {
            Text("\(n)").font(.system(.subheadline, design: .rounded, weight: .bold)).foregroundStyle(Color.onKosh)
                .frame(width: 26, height: 26).background(Circle().fill(Color.kosh))
            Text(text).font(.subheadline.weight(.semibold))
        }
        .padding(.horizontal, 16).padding(.vertical, 12)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(RoundedRectangle(cornerRadius: 20).fill(Color(.secondarySystemBackground)))
    }

    static func when(_ d: Date) -> String {
        let f = DateFormatter(); f.locale = Locale(identifier: "en_IN")
        f.dateFormat = Calendar.current.isDateInToday(d) ? "h:mm a" : "d MMM, h:mm a"
        return (Calendar.current.isDateInToday(d) ? "today " : "") + f.string(from: d)
    }
}

/// An SMS arriving and becoming a payment in kosh, played on a loop
struct AlertsArt: View {
    @State private var on = false
    var body: some View {
        VStack(spacing: 14) {
            HStack(alignment: .top, spacing: 8) {
                Image(systemName: "message.fill").font(.system(size: 13, weight: .semibold)).foregroundStyle(.white)
                    .frame(width: 26, height: 26).background(Circle().fill(Color(hex: "#34C759")))
                Text("Sent Rs.250.00 From A/C *4821 To BLINKIT").font(.system(size: 13)).foregroundStyle(.primary)
                    .padding(.horizontal, 12).padding(.vertical, 8)
                    .background(RoundedRectangle(cornerRadius: 16).fill(Color(.systemGray5)))
            }
            .opacity(on ? 0.35 : 1).offset(y: on ? -4 : 0)
            Image(systemName: "arrow.down").font(.system(size: 14, weight: .bold)).foregroundStyle(Color.kosh).opacity(on ? 1 : 0.3)
            HStack(spacing: 12) {
                Text("B").font(.system(size: 16, weight: .semibold, design: .rounded)).foregroundStyle(Color(hex: "#FF9500"))
                    .frame(width: 38, height: 38).background(RoundedRectangle(cornerRadius: 10).fill(Color(hex: "#FF9500").opacity(0.16)))
                VStack(alignment: .leading, spacing: 1) {
                    Text("Blinkit").font(.system(size: 16, weight: .semibold))
                    Text("Groceries · UPI").font(.system(size: 13)).foregroundStyle(.secondary)
                }
                Spacer()
                Text("₹250").font(.system(size: 17, weight: .semibold, design: .serif))
                Image(systemName: "checkmark.circle.fill").foregroundStyle(Color(hex: "#2E7D4F")).opacity(on ? 1 : 0).scaleEffect(on ? 1 : 0.4)
            }
            .padding(14)
            .background(RoundedRectangle(cornerRadius: 22).fill(Color(.secondarySystemBackground)))
            .scaleEffect(on ? 1 : 0.94).opacity(on ? 1 : 0.5)
        }
        .frame(maxWidth: 340)
        .onAppear { withAnimation(.easeInOut(duration: 1.1).repeatForever(autoreverses: true).delay(0.3)) { on = true } }
        .accessibilityHidden(true)
    }
}

/// iPhone's own question the first time the shortcut runs, with Allow
struct AllowArt: View {
    @State private var step = 0
    var body: some View {
        VStack(spacing: 12) {
            Text("Allow “kosh alerts” to run actions from “kosh”?").font(.system(size: 15, weight: .semibold)).multilineTextAlignment(.center)
            HStack(spacing: 10) {
                Text("Don’t Allow").font(.system(size: 15, weight: .medium)).frame(maxWidth: .infinity).padding(.vertical, 10)
                    .background(Capsule().fill(Color(.systemGray5)))
                Text("Allow").font(.system(size: 15, weight: .semibold)).foregroundStyle(.white).frame(maxWidth: .infinity).padding(.vertical, 10)
                    .background(Capsule().fill(Color.kosh))
                    .overlay(Capsule().stroke(Color.kosh, lineWidth: 2).padding(-5).opacity(step % 2 == 0 ? 0.8 : 0))
            }
        }
        .padding(16)
        .background(RoundedRectangle(cornerRadius: 22).fill(Color(.secondarySystemBackground)))
        .frame(maxWidth: 340)
        .task { while !Task.isCancelled { withAnimation(Motion.reveal) { step += 1 }; try? await Task.sleep(for: .seconds(0.9)) } }
        .accessibilityHidden(true)
    }
}

/// The Automation screens as Shortcuts shows them, with the one row to tap lighting up in turn: New Automation,
/// Message, Message Contains with its one space, Run Immediately, then kosh alerts
struct AutomationArt: View {
    @State private var step = 0
    private let rows: [(String, String)] = [("plus.circle.fill", "New Automation"), ("message.fill", "Message"), ("text.cursor", "Message Contains “ ”"),
                                            ("bolt.circle.fill", "Run Immediately"), ("bolt.fill", "kosh alerts")]
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            Text("Automation").font(.system(size: 13, weight: .semibold)).foregroundStyle(.secondary).padding(.bottom, 8)
            ForEach(Array(rows.enumerated()), id: \.offset) { i, r in
                if i > 0 { Divider() }
                HStack(spacing: 10) {
                    Image(systemName: r.0).font(.system(size: 15)).foregroundStyle(i == step ? Color.kosh : .secondary).frame(width: 22)
                    Text(r.1).font(.system(size: 15, weight: i == step ? .semibold : .regular))
                    Spacer()
                    Image(systemName: "chevron.right").font(.system(size: 12, weight: .semibold)).foregroundStyle(.tertiary)
                }
                .padding(.vertical, 11)
                .opacity(i == step ? 1 : 0.4)
            }
        }
        .padding(16)
        .background(RoundedRectangle(cornerRadius: 22).fill(Color(.secondarySystemBackground)))
        .frame(maxWidth: 340)
        .task {
            // down the rows, over and over
            while !Task.isCancelled {
                for s in rows.indices {
                    withAnimation(Motion.large) { step = s }
                    try? await Task.sleep(for: .seconds(s == rows.count - 1 ? 1.8 : 1.1))
                }
            }
        }
        .accessibilityHidden(true)
    }
}

struct DoneArt: View {
    @State private var on = false
    var body: some View {
        Image(systemName: "checkmark.circle.fill").font(.system(size: 84, weight: .semibold))
            .foregroundStyle(Color(hex: "#2E7D4F"))
            .symbolEffect(.bounce, value: on)
            .onAppear { on = true }
            .accessibilityHidden(true)
    }
}
