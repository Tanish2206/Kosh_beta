import SwiftUI

// MARK: - What kosh noticed
//
// Found by rules on the ledger every time it's laid out (agent.js watch): a late fee or a card's annual fee, the
// same charge twice, a spend far bigger than usual, a repeat that went up, a new subscription, what's due this
// week against what's in the accounts, a deposit maturing, a premium due, rent that hasn't come, the month's pace
// against its budget, money idle in savings. Most pressing first. Each opens to the payments behind it and a
// question for Ask kosh to take it further.

extension WatchItem {
    var tint: Color { sev >= 3 ? Color.red : sev == 2 ? Color.orange : Color.kosh }
    var level: String { sev >= 3 ? "Act now" : sev == 2 ? "Worth a look" : "Good to know" }
}

struct NoticedRow: View {
    let f: WatchItem
    var expanded = false
    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: f.sym)
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(f.tint)
                .frame(width: 34, height: 34)
                .background(f.tint.opacity(0.12), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
            VStack(alignment: .leading, spacing: 3) {
                // how pressing, in words as well as colour
                Text(f.level.uppercased()).font(.caption2.weight(.bold)).foregroundStyle(f.tint)
                Text(f.title).font(.subheadline.weight(.semibold)).foregroundStyle(Color.primary)
                    .fixedSize(horizontal: false, vertical: true)
                Text(f.detail).font(.footnote).foregroundStyle(.secondary)
                    .lineLimit(expanded ? nil : 2)
                    .fixedSize(horizontal: false, vertical: true)
            }
            Spacer(minLength: 0)
        }
        .padding(.vertical, 10)
        .contentShape(Rectangle())
        .privacySensitive()
    }
}

/// everything noticed; one opened shows the payments behind it and a question to take further
struct NoticedSheet: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    @Environment(\.askKosh) private var askKosh
    @State var open: String?

    var body: some View {
        let items = store.watchShown
        NavigationStack {
            List {
                if items.isEmpty {
                    Text("Nothing stands out right now. kosh looks again every time new mail comes in.").foregroundStyle(.secondary)
                }
                ForEach([3, 2, 1], id: \.self) { sev in
                    let group = items.filter { min(3, $0.sev) == sev }
                    if !group.isEmpty {
                        Section(group[0].level) {
                            ForEach(group) { f in
                                VStack(alignment: .leading, spacing: 10) {
                                    Button { withAnimation(Motion.base) { open = open == f.id ? nil : f.id } } label: { NoticedRow(f: f, expanded: open == f.id) }
                                        .buttonStyle(.press)
                                    if open == f.id {
                                        let set = Set(f.rows)
                                        let rows = store.tx.filter { set.contains($0.id) }
                                        ForEach(rows) { t in TxRow(t: t, when: Day.short(t.d)).allowsHitTesting(false) }
                                        // a trial or two doing one job: how to cancel each (Plan.swift)
                                        if !f.reps.isEmpty { PlanCancelButtons(reps: f.reps) }
                                        // a deposit that needs a look, or matures soon: its journey and what you can say
                                        if let dep = DepositNotice.depositID(f.id), store.deposit(dep) != nil {
                                            Button {
                                                dismiss()
                                                DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) { store.push(.deposit(dep)) }
                                            } label: {
                                                Label("See the deposit", systemImage: "building.columns")
                                                    .font(.subheadline.weight(.semibold))
                                            }
                                            .buttonStyle(.glass)
                                        }
                                        if !f.ask.isEmpty {
                                            Button {
                                                if let askKosh { askKosh(f.ask) } else { store.openAsk(f.ask) }
                                            } label: {
                                                Label(f.ask, systemImage: "sparkles").font(.subheadline.weight(.semibold))
                                            }
                                            .buttonStyle(.glass)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            .listStyle(.insetGrouped)
            .navigationTitle("kosh noticed")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } } }
        }
    }
}
