import SwiftUI
import Charts

// MARK: - Committees, rebuilt around the one thing you do every month
//
// A committee asks for an instalment each month (less than face value in an auction month: that saving is what
// it earns), and once in its life hands you the pool. So the page opens on this month: what's due across them all,
// how many you've recorded, and whose pool it is. Then each committee's instalment, one tap to record it; the cash
// a year ahead, out against in; what it has earned; and the whole book, each committee's run with your pool month
// marked on it.

struct CommitteesHome: View {
    @Environment(Store.self) private var store
    @State private var recording: CommRecordTarget?

    var body: some View {
        let all: [Committee] = store.committees(store.who).filter { $0.excluded != true }
        ScrollView {
            VStack(alignment: .leading, spacing: 26) {
                if all.isEmpty {
                    BetaEmpty(sym: "circle.dotted.circle", title: "No committees yet",
                              text: "Add a committee you're in: how it's decided (auction, draw or fixed turns), the monthly amount, the members and your month. kosh keeps every month's instalment and works out what it earns you.",
                              add: "Add a committee") { store.betaSheet = .committee(nil) }
                } else {
                    // the next turn and its rate against your deposit (TabSmarts.swift): the household's
                    if store.who == .family, let s = store.snap.smarts?.committees { TabSmartLine(line: s.line, notes: s.notes ?? []) }
                    // the page's sections, in the order you arranged them (Arrange this tab)
                    PlanStack(.commHome, spacing: 26) { id in section(id, all: all) }
                    if store.live != nil {
                        Button { store.betaSheet = .committee(nil) } label: { Label("Add a committee", systemImage: "plus.circle.fill").font(.body.weight(.semibold)) }
                            .padding(.leading, 4)
                    }
                }
            }
            .padding(.horizontal, 20)
            .padding(.top, 8)
            .padding(.bottom, 40)
        }
        .sheet(item: $recording) { t in RecordInstalment(c: t.c, row: t.row).presentationDetents([.medium]) }
        .tabHeader("Committees", add: store.live == nil ? [] : [
            HeaderAction(title: "Add a committee", symbol: "plus.circle") { store.betaSheet = .committee(nil) },
        ], extra: HeaderAction.arrange(.committees) { store.sheet = .arrange(.committees) })
    }

    /// one section of the page: this month, its instalments, the cash ahead, what they've earned, the book, the finished ones
    @ViewBuilder func section(_ id: String, all: [Committee]) -> some View {
        let running: [Committee] = all.filter { !$0.done }
        let done: [Committee] = all.filter { $0.done }
        let cm: String = store.snap.cm
        switch id {
        case "month":
            CommMonthHero(running: running, all: all)
        case "instalments":
            if !running.isEmpty {
                GroupedSection(title: CommText.instalments(cm), trailing: nil) {
                    let order: [Committee] = CommNow.order(running, cm)
                    ForEach(Array(order.enumerated()), id: \.element.id) { i, c in
                        if i > 0 { Rectangle().fill(Color.primary.opacity(0.08)).frame(height: 0.5).padding(.leading, 62) }
                        CommNowRow(c: c, color: CommColor.of(c, in: store.snap.comm), cm: cm) { row in recording = CommRecordTarget(c: c, row: row) }
                    }
                }
            }
        case "ahead":
            CommCashAhead(months: store.commMonths(store.who).filter { $0.m >= cm }.prefix(12).map { $0 })
        case "earned":
            CommEarned(months: store.commMonths(store.who).filter { !$0.ahead })
        case "book":
            GroupedSection(title: "The book", trailing: CommText.running(running.count)) {
                ForEach(Array(running.sorted { ($0.draw ?? "9") < ($1.draw ?? "9") }.enumerated()), id: \.element.id) { i, c in
                    if i > 0 { Rectangle().fill(Color.primary.opacity(0.08)).frame(height: 0.5).padding(.leading, 16) }
                    Button { store.push(.committee(c.id)) } label: { CommBookRow(c: c, color: CommColor.of(c, in: store.snap.comm), cm: cm) }
                        .buttonStyle(.press)
                }
            }
        case "done":
            if !done.isEmpty { CommDoneGroup(done: done) }
        default:
            EmptyView()
        }
    }
}

struct CommRecordTarget: Identifiable { let c: Committee; let row: CommRow; var id: String { c.id + row.m } }

/// a committee's month in a word: recorded or not, and what it cost
enum CommNow {
    static func row(_ c: Committee, _ m: String) -> CommRow? { c.rows?.first { $0.m == m } }
    static func recorded(_ c: Committee, _ m: String) -> Bool {
        guard let r = row(c, m) else { return false }
        return r.st == "paid" && !(r.src ?? "").isEmpty
    }
    static func monthShort(_ m: String) -> String { Day.fmt(m + "-01", "MMM ''yy") }
    /// the ones still to record first, then by name
    static func order(_ cs: [Committee], _ m: String) -> [Committee] {
        let todo: [Committee] = cs.filter { !recorded($0, m) }.sorted { $0.name < $1.name }
        let done: [Committee] = cs.filter { recorded($0, m) }.sorted { $0.name < $1.name }
        return todo + done
    }
}

/// the page's words, built in small steps (long chains of + in a view are too slow for the compiler)
enum CommText {
    /// "1 committee", "3 committees"
    static func many(_ n: Int, _ noun: String) -> String {
        let tail: String = n == 1 ? "" : "s"
        return String(n) + " " + noun + tail
    }
    static func count(_ n: Int, _ recorded: Int) -> String {
        let a: String = many(n, "committee") + " · "
        let b: String = String(recorded) + " of " + String(n)
        return a + b + " recorded"
    }
    static func poolNow(_ c: Committee) -> String {
        let amt: Double = c.net > 0 ? c.net : c.pool
        let head: String = "Your pool this month: " + c.name
        return head + " · " + Fmt.words(amt)
    }
    static func pct(_ part: Double, of whole: Double) -> String? {
        guard whole > 0 else { return nil }
        let v: String = Fmt.trim(part / whole * 100, 1)
        return v + "%"
    }
    static func payPools(_ out: Double, _ inn: Double, hint: Bool) -> String {
        let a: String = "pay " + Fmt.short(out)
        let b: String = " · pools " + Fmt.short(inn)
        let c: String = hint ? " · drag to read a month" : ""
        return a + b + c
    }
    static func signed(_ v: Double, words: Bool) -> String {
        let sign: String = v >= 0 ? "+" : "−"
        let amt: String = words ? Fmt.words(abs(v)) : Fmt.rupees(abs(v))
        return sign + amt
    }
    static func next(_ n: Int) -> String { n == 1 ? "Next month" : "Next " + many(n, "month") }
    static func onPaid(_ pct: Double) -> String { Fmt.trim(pct, 1) + "% on what you've paid" }
    static func earnedPct(_ pct: Double) -> String { pct > 0 ? Fmt.trim(pct, 1) + "% earned" : "earned" }
    static func down(_ pct: Double) -> String { "↓ " + Fmt.trim(pct, 1) + "%" }
    static func paidOf(_ paid: Int, _ total: Int) -> String {
        let a: String = String(paid) + " of "
        return a + String(total) + " paid"
    }
    static func poolWhen(_ draw: String?, _ cm: String) -> String {
        guard let d = draw else { return "pool month not set" }
        let head: String = d <= cm ? "pool taken " : "pool "
        return head + CommNow.monthShort(d)
    }
    static func doneLine(_ n: Int, _ earned: Double) -> String {
        let a: String = String(n) + " · earned "
        return a + Fmt.short(earned)
    }
    static func kindLine(_ c: Committee) -> String {
        let a: String = c.kindTitle + " · "
        return a + many(c.members, "member")
    }
    static func earnedLabel(_ pct: Double) -> String { pct > 0 ? "Earned · " + Fmt.trim(pct, 1) + "%" : "Earned" }
    static func stillLabel(_ left: Int) -> String { left > 0 ? "Still to pay · " + many(left, "month") : "Still to pay" }
    static func initials(_ first: String, _ tail: String) -> String { (first + tail).uppercased() }
    static func instalments(_ cm: String) -> String { Day.fmt(cm + "-01", "MMMM") + "'s instalments" }
    static func running(_ n: Int) -> String { String(n) + " running" }
    static func toPay(_ cm: String) -> String { Day.fmt(cm + "-01", "MMMM") + " · to pay" }
}

// MARK: This month, at the top

struct CommMonthHero: View {
    @Environment(Store.self) private var store
    let running: [Committee]
    let all: [Committee]
    var body: some View {
        let cm: String = store.snap.cm
        let months: [CommMonth] = store.commMonths(store.who)
        let now: CommMonth? = months.first { $0.m == cm }
        let payNow: Double = now?.out ?? running.reduce(0) { $0 + $1.now }
        let recorded: Int = running.filter { CommNow.recorded($0, cm) }.count
        let mine: Committee? = running.first { $0.draw == cm }
        let profit: Double = all.reduce(0) { $0 + $1.profit }
        let paidIn: Double = all.reduce(0) { $0 + $1.contributed }
        let still: Double = running.reduce(0) { $0 + $1.outstanding }
        let toCome: Double = months.filter { $0.m > cm }.reduce(0) { $0 + $1.recv }
        VStack(alignment: .leading, spacing: 16) {
            VStack(alignment: .leading, spacing: 2) {
                Text(CommText.toPay(cm)).font(.subheadline.weight(.medium)).foregroundStyle(.secondary)
                Text(Fmt.rupees(payNow)).font(.system(size: 38, weight: .bold, design: .rounded)).monospacedDigit().privacySensitive()
                Text(CommText.count(running.count, recorded))
                    .font(.subheadline).foregroundStyle(.secondary)
            }
            CommTally(running: running, cm: cm)
            if let mine {
                Label(CommText.poolNow(mine), systemImage: "gift.fill")
                    .font(.subheadline.weight(.semibold)).foregroundStyle(Color.green).privacySensitive()
            }
            Rectangle().fill(Color.primary.opacity(0.08)).frame(height: 0.5)
            HStack(alignment: .top, spacing: 12) {
                CommStat(label: "Earned", value: Fmt.short(profit), sub: CommText.pct(profit, of: paidIn), tone: Color.green)
                CommStat(label: "Still to pay", value: Fmt.short(still), sub: "at most", tone: Color.primary)
                CommStat(label: "Pools to come", value: toCome > 0 ? Fmt.short(toCome) : "—", sub: nil, tone: Color.primary)
            }
            .privacySensitive()
        }
        .padding(18)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.surface, in: RoundedRectangle(cornerRadius: 28, style: .continuous))
    }
}

/// one segment per committee: filled once this month's instalment is recorded
struct CommTally: View {
    let running: [Committee]
    let cm: String
    var body: some View {
        HStack(spacing: 4) {
            ForEach(running) { c in
                Capsule().fill(CommNow.recorded(c, cm) ? AnyShapeStyle(Color.green.gradient) : AnyShapeStyle(Color.primary.opacity(0.10)))
                    .frame(height: 6)
            }
        }
    }
}

struct CommStat: View {
    let label: String
    let value: String
    let sub: String?
    let tone: Color
    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(label.uppercased()).font(.system(.caption2, weight: .semibold)).tracking(0.5).foregroundStyle(.secondary).lineLimit(1).minimumScaleFactor(0.8)
            Text(value).font(.system(.body, design: .rounded, weight: .semibold)).monospacedDigit().foregroundStyle(tone).lineLimit(1).minimumScaleFactor(0.75)
            // "at most", "4.2%": a muted line under the figure, so it never runs into the next column
            if let sub { Text(sub).font(.caption2.weight(.semibold)).foregroundStyle(.secondary).lineLimit(1) }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

/// a committee in this month's list: what it asked, or a button to record it
struct CommNowRow: View {
    @Environment(Store.self) private var store
    let c: Committee
    let color: Color
    let cm: String
    let record: (CommRow) -> Void
    var body: some View {
        let row: CommRow? = CommNow.row(c, cm)
        let done: Bool = CommNow.recorded(c, cm)
        let editable: Bool = store.live?.userCommittees.contains(where: { $0.id == c.id }) == true
        HStack(spacing: 12) {
            CommBadge(name: c.name, color: color)
            VStack(alignment: .leading, spacing: 1) {
                Text(c.name).font(.body.weight(.medium)).lineLimit(1)
                Text(CommNowRow.sub(c, cm)).font(.footnote).foregroundStyle(c.draw == cm ? Color.green : Color.secondary).lineLimit(1)
            }
            Spacer(minLength: 8)
            if done, let r = row {
                VStack(alignment: .trailing, spacing: 1) {
                    Text(Fmt.rupees(r.amt)).font(.body.weight(.semibold)).monospacedDigit().privacySensitive()
                    if r.pct > 0 {
                        Text(CommText.down(r.pct)).font(.caption.weight(.semibold)).foregroundStyle(Color.green)
                    } else {
                        Image(systemName: "checkmark.circle.fill").font(.caption).foregroundStyle(Color.green)
                    }
                }
            } else if editable, let r = row {
                Button { record(r) } label: {
                    Text("Record").font(.subheadline.weight(.semibold))
                        .padding(.horizontal, 12).padding(.vertical, 6)
                        .background(Color.kosh.opacity(0.12), in: Capsule())
                        .foregroundStyle(Color.kosh)
                }
                .buttonStyle(.press)
            } else {
                Text(Fmt.rupees(c.now > 0 ? c.now : c.face)).font(.body).monospacedDigit().foregroundStyle(.secondary).privacySensitive()
            }
        }
        .padding(.horizontal, 14).padding(.vertical, 11)
        .contentShape(Rectangle())
        .onTapGesture { store.push(.committee(c.id)) }
    }
    static func sub(_ c: Committee, _ cm: String) -> String {
        if c.draw == cm { return "Your pool this month" }
        let face: String = Fmt.short(c.face) + " face"
        guard let d = c.draw else { return face + " · set your pool month" }
        if d < cm { return face + " · pool taken " + CommNow.monthShort(d) }
        return face + " · your pool " + CommNow.monthShort(d)
    }
}

/// a committee's initials on its colour
struct CommBadge: View {
    let name: String
    let color: Color
    var size: CGFloat = 36
    var body: some View {
        let parts: [Substring] = name.split(separator: " ")
        let first: String = parts.first.map { String($0.prefix(1)) } ?? "?"
        let tail: String = parts.count > 1 ? String(parts.last!.prefix(2)) : ""
        Text(CommText.initials(first, tail))
            .font(.system(size: size * 0.34, weight: .bold, design: .rounded))
            .foregroundStyle(.white)
            .frame(width: size, height: size)
            .background(color.gradient, in: RoundedRectangle(cornerRadius: size * 0.28, style: .continuous))
    }
}

// MARK: Cash, a year ahead

struct CommCashAhead: View {
    let months: [CommMonth]
    @State private var picked: String?
    var body: some View {
        if months.count > 1 {
            let sel: CommMonth? = months.first { $0.m == picked }
            VStack(alignment: .leading, spacing: 12) {
                Text("Cash, month by month").font(.title3.weight(.bold))
                VStack(alignment: .leading, spacing: 14) {
                    CommCashHead(sel: sel, months: months)
                    CommCashChart(months: months, picked: $picked)
                        .frame(height: 170)
                    HStack(spacing: 14) {
                        CommKey(color: Color.orange, text: "you pay")
                        CommKey(color: Color.green, text: "pools in")
                        CommKey(color: Color.kosh, text: "cash after", line: true)
                    }
                }
                .padding(18)
                .background(Color.surface, in: RoundedRectangle(cornerRadius: 28, style: .continuous))
                .privacySensitive()
            }
        }
    }
}

struct CommCashHead: View {
    let sel: CommMonth?
    let months: [CommMonth]
    var body: some View {
        if let s = sel {
            VStack(alignment: .leading, spacing: 2) {
                Text(Day.fmt(s.m + "-01", "MMMM yyyy")).font(.subheadline.weight(.medium)).foregroundStyle(.secondary)
                Text(CommText.signed(s.net, words: false)).font(.system(.title, design: .rounded, weight: .bold)).monospacedDigit()
                    .foregroundStyle(s.net >= 0 ? Color.green : Color.primary)
                Text(CommText.payPools(s.out, s.recv, hint: false)).font(.footnote).foregroundStyle(.secondary)
            }
        } else {
            let out: Double = months.reduce(0) { $0 + $1.out }
            let inn: Double = months.reduce(0) { $0 + $1.recv }
            VStack(alignment: .leading, spacing: 2) {
                Text(CommText.next(months.count)).font(.subheadline.weight(.medium)).foregroundStyle(.secondary)
                Text(CommText.signed(inn - out, words: true)).font(.system(.title, design: .rounded, weight: .bold)).monospacedDigit()
                    .foregroundStyle(inn - out >= 0 ? Color.green : Color.primary)
                Text(CommText.payPools(out, inn, hint: true)).font(.footnote).foregroundStyle(.secondary)
            }
        }
    }
}

struct CommCashChart: View {
    let months: [CommMonth]
    @Binding var picked: String?
    var body: some View {
        Chart {
            ForEach(months) { m in
                BarMark(x: .value("Month", m.m), y: .value("₹", -m.out), width: .ratio(0.55))
                    .foregroundStyle(Color.orange.opacity(picked == nil || picked == m.m ? 0.85 : 0.3).gradient)
                    .cornerRadius(3)
                if m.recv > 0 {
                    BarMark(x: .value("Month", m.m), y: .value("₹", m.recv), width: .ratio(0.55))
                        .foregroundStyle(Color.green.opacity(picked == nil || picked == m.m ? 0.9 : 0.3).gradient)
                        .cornerRadius(3)
                }
            }
            ForEach(months) { m in
                LineMark(x: .value("Month", m.m), y: .value("Cash", m.cum))
                    .foregroundStyle(Color.kosh)
                    .lineStyle(StrokeStyle(lineWidth: 2, lineCap: .round))
                    .interpolationMethod(.monotone)
            }
            RuleMark(y: .value("Zero", 0)).foregroundStyle(Color.primary.opacity(0.15))
            if let p = picked { RuleMark(x: .value("Month", p)).foregroundStyle(Color.secondary.opacity(0.3)) }
        }
        .chartXSelection(value: $picked)
        .chartYAxis {
            AxisMarks(position: .trailing, values: .automatic(desiredCount: 4)) { v in
                AxisGridLine().foregroundStyle(Color.hairline)
                AxisValueLabel { if let d = v.as(Double.self) { Text(Compact.amount(d)) } }
            }
        }
        .chartXAxis { CommAxis.marks(months.map(\.m)) }
        .accessibilityElement(children: .ignore)
        .spokenFigures(Self.spoken(months, figures: true), hidden: Self.spoken(months, figures: false))
    }
    /// what VoiceOver says of the bars and the line; the sums only while amounts show
    static func spoken(_ months: [CommMonth], figures: Bool) -> String {
        let span: String = "What goes into your committees and comes back, over " + SpokenWords.count(months.count, "month", "months")
        guard figures else { return span }
        let out: Double = months.reduce(0) { $0 + $1.out }
        let back: Double = months.reduce(0) { $0 + $1.recv }
        let end: Double = months.last?.cum ?? 0
        return span + ": " + Fmt.rupees(out) + " paid in, " + Fmt.rupees(back) + " back, " + CommText.signed(end, words: false) + " by the end"
    }
}

struct CommKey: View {
    let color: Color
    let text: String
    var line: Bool = false
    var body: some View {
        HStack(spacing: 5) {
            if line { Capsule().fill(color).frame(width: 12, height: 2.5) } else { RoundedRectangle(cornerRadius: 2).fill(color).frame(width: 9, height: 9) }
            Text(text).font(.caption2).foregroundStyle(.secondary)
        }
    }
}

// MARK: What it has earned

struct CommEarned: View {
    let months: [CommMonth]
    var body: some View {
        let pts: [CommMonth] = months.filter { $0.cumProfit > 0 }
        if pts.count > 1, let last = pts.last {
            VStack(alignment: .leading, spacing: 12) {
                Text("Earned so far").font(.title3.weight(.bold))
                VStack(alignment: .leading, spacing: 12) {
                    HStack(alignment: .firstTextBaseline, spacing: 8) {
                        Text(Fmt.rupees(last.cumProfit)).font(.system(.title, design: .rounded, weight: .bold)).monospacedDigit().foregroundStyle(Color.green)
                        Text(CommText.onPaid(last.cumPct)).font(.subheadline).foregroundStyle(.secondary)
                    }
                    Chart {
                        ForEach(pts) { m in
                            AreaMark(x: .value("Month", m.m), y: .value("₹", m.cumProfit))
                                .foregroundStyle(LinearGradient(colors: [Color.green.opacity(0.25), Color.green.opacity(0.02)], startPoint: .top, endPoint: .bottom))
                                .interpolationMethod(.monotone)
                            LineMark(x: .value("Month", m.m), y: .value("₹", m.cumProfit))
                                .foregroundStyle(Color.green).lineStyle(StrokeStyle(lineWidth: 2.4, lineCap: .round)).interpolationMethod(.monotone)
                        }
                    }
                    .chartYAxis(.hidden)
                    .chartXAxis { CommAxis.marks(pts.map(\.m)) }
                    .frame(height: 120)
                    .accessibilityElement(children: .ignore)
                    .spokenFigures("Earned so far, month by month: " + Fmt.rupees(last.cumProfit) + " by " + Day.monthName(last.m), hidden: "Earned so far, month by month")
                    Text("Face value less what you actually paid, month after month. A pool taken isn't counted as earning.")
                        .font(.caption).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                }
                .padding(18)
                .background(Color.surface, in: RoundedRectangle(cornerRadius: 28, style: .continuous))
                .privacySensitive()
            }
        }
    }
}

// MARK: The book

/// a committee's run: months paid, months to go, and your pool month marked
struct CommBookRow: View {
    let c: Committee
    let color: Color
    let cm: String
    var body: some View {
        let total: Int = max(1, c.members)
        let paid: Int = min(total, c.paid)
        let drawAt: Int? = c.drawIndex > 0 ? min(total, c.drawIndex) : nil
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 12) {
                CommBadge(name: c.name, color: color, size: 32)
                VStack(alignment: .leading, spacing: 1) {
                    Text(c.name).font(.body.weight(.medium)).lineLimit(1)
                    Text(CommBookRow.sub(c)).font(.footnote).foregroundStyle(.secondary).lineLimit(1)
                }
                Spacer(minLength: 8)
                VStack(alignment: .trailing, spacing: 1) {
                    Text(Fmt.short(c.profit)).font(.subheadline.weight(.semibold)).monospacedDigit().foregroundStyle(c.profit > 0 ? Color.green : Color.secondary)
                    Text(CommText.earnedPct(c.pct)).font(.caption2).foregroundStyle(.secondary)
                }
                Image(systemName: "chevron.right").font(.caption.weight(.semibold)).foregroundStyle(.tertiary)
            }
            .privacySensitive()
            CommRunBar(total: total, paid: paid, drawAt: drawAt, color: color)
            HStack {
                Text(CommText.paidOf(paid, total)).font(.caption2).foregroundStyle(.secondary)
                Spacer()
                Text(CommText.poolWhen(c.draw, cm)).font(.caption2.weight(.semibold))
                    .foregroundStyle(c.draw == cm ? Color.green : Color.secondary)
            }
        }
        .padding(.horizontal, 16).padding(.vertical, 13)
        .contentShape(Rectangle())
    }
    static func sub(_ c: Committee) -> String {
        Fmt.words(c.pool) + " pool · " + String(c.members) + " × " + Fmt.short(c.face) + (c.left > 0 ? " · " + String(c.left) + " left" : "")
    }
}

/// one tick per month of a committee: paid ones in its colour, your pool month as a ring
struct CommRunBar: View {
    let total: Int
    let paid: Int
    let drawAt: Int?
    let color: Color
    var body: some View {
        GeometryReader { g in
            let gap: CGFloat = total > 24 ? 1 : 2
            let w: CGFloat = max(2, (g.size.width - gap * CGFloat(total - 1)) / CGFloat(total))
            HStack(spacing: gap) {
                ForEach(0..<total, id: \.self) { i in
                    RoundedRectangle(cornerRadius: 2, style: .continuous)
                        .fill(i < paid ? AnyShapeStyle(color.gradient) : AnyShapeStyle(Color.primary.opacity(0.09)))
                        .frame(width: w, height: 8)
                        .overlay {
                            if let d = drawAt, i == d - 1 {
                                RoundedRectangle(cornerRadius: 2, style: .continuous).strokeBorder(Color.green, lineWidth: 1.6)
                                    .frame(width: w + 2, height: 12)
                            }
                        }
                }
            }
            .frame(maxHeight: .infinity)
        }
        .frame(height: 12)
    }
}

struct CommDoneGroup: View {
    @Environment(Store.self) private var store
    let done: [Committee]
    @State private var open = false
    var body: some View {
        let earned: Double = done.reduce(0) { $0 + $1.profit }
        VStack(alignment: .leading, spacing: 8) {
            Button { withAnimation(Fold.motion(opening: !open)) { open.toggle() } } label: {
                HStack {
                    Text("COMPLETED").font(.footnote.weight(.semibold)).foregroundStyle(.secondary)
                    Text(CommText.doneLine(done.count, earned)).font(.footnote).foregroundStyle(.secondary).privacySensitive()
                    Spacer()
                    Image(systemName: "chevron.down").font(.caption.weight(.bold)).foregroundStyle(.tertiary).foldTurn(open)
                }
                .padding(.horizontal, 16)
                .contentShape(Rectangle())
            }
            .buttonStyle(.press)
            Unfold(open: open) {
                VStack(spacing: 0) {
                    ForEach(Array(done.enumerated()), id: \.element.id) { i, c in
                        if i > 0 { Rectangle().fill(Color.primary.opacity(0.08)).frame(height: 0.5).padding(.leading, 16) }
                        Button { store.push(.committee(c.id)) } label: { CommBookRow(c: c, color: Color.gray, cm: store.snap.cm) }.buttonStyle(.press)
                    }
                }
                .background(Color.surface, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
            }
        }
    }
}

// MARK: - One committee

struct CommitteePage: View {
    @Environment(Store.self) private var store
    let id: String
    @State private var recording: CommRow?
    var body: some View {
        if let c = store.committee(id) {
            CommitteePageBody(c: c, mine: store.live?.userCommittees.contains(where: { $0.id == id }) == true) { r in recording = r }
                .sheet(item: $recording) { r in RecordInstalment(c: c, row: r).presentationDetents([.medium]) }
        } else {
            ContentUnavailableView("No such committee", systemImage: "circle.dotted.circle")
        }
    }
}

struct CommitteePageBody: View {
    @Environment(Store.self) private var store
    let c: Committee
    let mine: Bool
    let record: (CommRow) -> Void
    var body: some View {
        let cm: String = store.snap.cm
        let color: Color = CommColor.of(c, in: store.snap.comm)
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                VStack(alignment: .leading, spacing: 10) {
                    HStack(spacing: 12) {
                        CommBadge(name: c.name, color: color, size: 44)
                        VStack(alignment: .leading, spacing: 1) {
                            Text(CommText.kindLine(c)).font(.subheadline).foregroundStyle(.secondary)
                            Text(Fmt.rupees(c.pool)).font(.system(.title, design: .rounded, weight: .bold)).monospacedDigit().privacySensitive()
                        }
                    }
                    Text(CommitteePageBody.status(c, cm)).font(.subheadline.weight(.semibold))
                        .foregroundStyle(c.draw == cm ? Color.green : Color.kosh)
                    CommRunBar(total: max(1, c.members), paid: min(c.members, c.paid), drawAt: c.drawIndex > 0 ? c.drawIndex : nil, color: color)
                }
                if let rows = c.rows, !rows.isEmpty {
                    CommMonthStrip(rows: rows, draw: c.draw, cm: cm, color: color, editable: mine, record: record)
                        .padding(.horizontal, -20)
                }
                LazyVGrid(columns: [GridItem(.flexible(), spacing: 12), GridItem(.flexible(), spacing: 12)], spacing: 12) {
                    CommMetric(label: "Paid in", value: Fmt.words(c.contributed), tone: Color.primary)
                    CommMetric(label: CommText.earnedLabel(c.pct), value: Fmt.words(c.profit), tone: Color.green)
                    CommMetric(label: c.taken == true ? "You received" : "You'll receive", value: Fmt.words(c.net > 0 ? c.net : c.pool), tone: Color.primary)
                    CommMetric(label: CommText.stillLabel(c.left), value: c.done ? "—" : Fmt.words(c.outstanding), tone: Color.orange)
                }
                .privacySensitive()
                if let end = c.endNet, c.net > 0 {
                    Label(CommitteeDetail.endLine(end), systemImage: end >= 0 ? "arrow.up.right.circle.fill" : "arrow.down.right.circle.fill")
                        .font(.subheadline).foregroundStyle(end >= 0 ? Color.green : Color.orange).privacySensitive()
                }
                if store.live != nil && mine && !c.done { CommLinkCard(c: c) }
                Text(CommKind(rawValue: c.kind ?? "")?.line ?? "A committee earns when you pay less than face value in the months before your pool.")
                    .font(.footnote).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            }
            .padding(.horizontal, 20)
            .padding(.top, 8)
            .padding(.bottom, 40)
        }
        .navigationTitle(c.name)
        .toolbar {
            if mine {
                ToolbarItem(placement: .primaryAction) { Button { store.betaSheet = .committee(c.id) } label: { Image(systemName: "pencil") }.accessibilityLabel("Edit") }
            }
        }
    }
    static func status(_ c: Committee, _ cm: String) -> String {
        if c.done { return "Finished" }
        if c.draw == cm { return "Your month to take the pool" }
        if let d = c.draw { return d < cm ? "Pool taken in " + Day.fmt(d + "-01", "MMMM yyyy") : "Your pool comes in " + Day.fmt(d + "-01", "MMMM yyyy") }
        return "Your pool month isn't set"
    }
}

struct CommMetric: View {
    let label: String
    let value: String
    let tone: Color
    var body: some View {
        VStack(alignment: .leading, spacing: 3) {
            Text(label.uppercased()).font(.system(.caption2, weight: .semibold)).tracking(0.5).foregroundStyle(.secondary).lineLimit(1).minimumScaleFactor(0.8)
            Text(value).font(.system(.title3, design: .rounded, weight: .bold)).monospacedDigit().foregroundStyle(tone).lineLimit(1).minimumScaleFactor(0.7)
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.surface, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
    }
}

/// every month of the committee as a tile, swiped sideways: what it cost and what it saved; your pool month
/// ringed; this month outlined; a tap records it
struct CommMonthStrip: View {
    let rows: [CommRow]
    let draw: String?
    let cm: String
    let color: Color
    let editable: Bool
    let record: (CommRow) -> Void
    var body: some View {
        ScrollViewReader { proxy in
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 8) {
                    ForEach(rows) { r in
                        Button { if editable && r.m <= cm { record(r) } } label: {
                            CommMonthTile(r: r, pool: r.m == draw, now: r.m == cm, color: color)
                        }
                        .buttonStyle(.press)
                        .id(r.m)
                    }
                }
                .padding(.horizontal, 20)
            }
            .onAppear { proxy.scrollTo(cm, anchor: .center) }
        }
    }
}

struct CommMonthTile: View {
    let r: CommRow
    let pool: Bool
    let now: Bool
    let color: Color
    var body: some View {
        let known: Bool = r.st == "paid" || r.st == "assumed"
        VStack(alignment: .leading, spacing: 4) {
            Text(Day.fmt(r.m + "-01", "MMM ''yy")).font(.caption.weight(.semibold)).foregroundStyle(now ? Color.kosh : Color.secondary)
            Text(known || now ? Compact.amount(r.amt) : Compact.amount(r.face)).font(.system(.callout, design: .rounded, weight: .semibold)).monospacedDigit()
                .foregroundStyle(known ? Color.primary : Color.secondary)
            if pool {
                Text("Pool").font(.caption2.weight(.bold)).foregroundStyle(Color.green)
            } else if r.pct > 0 && known {
                Text(CommText.down(r.pct)).font(.caption2.weight(.semibold)).foregroundStyle(Color.green)
            } else {
                Text(CommMonthTile.word(r)).font(.caption2).foregroundStyle(.tertiary)
            }
        }
        .frame(width: 78, alignment: .leading)
        .padding(10)
        .background(known ? AnyShapeStyle(color.opacity(0.10)) : AnyShapeStyle(Color.surface), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .strokeBorder(pool ? Color.green : (now ? Color.kosh : Color.clear), lineWidth: 1.5)
        }
        .privacySensitive()
    }
    static func word(_ r: CommRow) -> String {
        if r.st == "due" { return "due" }
        if r.st == "ahead" { return "ahead" }
        if r.st == "assumed" && (r.src ?? "").isEmpty { return "not recorded" }
        return "paid"
    }
}
