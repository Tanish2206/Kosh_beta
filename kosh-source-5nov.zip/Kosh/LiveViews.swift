import SwiftUI
import UniformTypeIdentifiers
import AuthenticationServices

// MARK: - The beta's own screens: sign-in, the real scan, the household, the parser check

/// Google's sign-in sheet, then back into kosh
struct GoogleSignInButton: View {
    @Environment(Store.self) private var store
    @Environment(\.webAuthenticationSession) private var webAuth
    var title = "Connect Gmail"
    var prominent = true
    var onDone: () -> Void = {}
    @State private var busy = false
    @State private var error: String?

    var body: some View {
        VStack(spacing: 8) {
            Button {
                Task { await go() }
            } label: {
                HStack(spacing: 8) {
                    if busy { ProgressView().tint(prominent ? .white : Color.kosh) } else { Image(systemName: "envelope.badge.shield.half.filled") }
                    Text(title)
                }
                .font(.headline)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 6)
            }
            .modifier(SignInStyle(prominent: prominent))
            .controlSize(.large)
            .disabled(busy)
            if let error {
                Text(error).font(.footnote).foregroundStyle(Color.red).fixedSize(horizontal: false, vertical: true)
            }
        }
    }

    @MainActor
    func go() async {
        guard let live = store.live else { return }
        busy = true
        error = nil
        defer { busy = false }
        do {
            let req = try live.signInRequest()
            let callback = try await webAuth.authenticate(using: req.url, callbackURLScheme: req.scheme)
            try await live.finishSignIn(callback)
            onDone()
        } catch {
            let ns = error as NSError
            if ns.domain == ASWebAuthenticationSessionErrorDomain && ns.code == ASWebAuthenticationSessionError.canceledLogin.rawValue { return }
            self.error = error.localizedDescription
        }
    }
}

struct SignInStyle: ViewModifier {
    let prominent: Bool
    @ViewBuilder
    func body(content: Content) -> some View {
        if prominent { content.buttonStyle(.glassProminent).koshFilled() } else { content.buttonStyle(.glass) }
    }
}

/// What the scan or Claude is doing right now
struct LiveStatusLine: View {
    let live: LiveSession
    var body: some View {
        switch live.phase {
        case .listing:
            HStack(spacing: 8) {
                ProgressView()
                Text(live.found > 0 ? "Finding money mail · \(live.found)" : "Finding money mail…")
            }
            .font(.subheadline).foregroundStyle(.secondary)
        case .reading:
            VStack(alignment: .leading, spacing: 6) {
                ProgressView(value: Double(live.fetched), total: Double(max(1, live.total)))
                Text("Reading \(live.fetched) of \(live.total) emails").font(.subheadline).foregroundStyle(.secondary)
            }
        case .claude:
            VStack(alignment: .leading, spacing: 6) {
                ProgressView(value: Double(live.claudeDone), total: Double(max(1, live.claudeTotal))).tint(Color.sky)
                Text("\(live.aiReadingTitle): \(live.claudeDone) of \(live.claudeTotal)").font(.subheadline).foregroundStyle(.secondary)
            }
        case .failed:
            Label(live.message ?? "The scan stopped.", systemImage: "exclamationmark.triangle.fill")
                .font(.subheadline).foregroundStyle(Color.orange).fixedSize(horizontal: false, vertical: true)
        default:
            if let m = live.message {
                Label(m, systemImage: "info.circle").font(.subheadline).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            }
        }
    }
}

// MARK: Onboarding, live

struct BetaNote: View {
    let text: String
    var body: some View {
        Label(text, systemImage: "flask.fill")
            .font(.footnote)
            .foregroundStyle(.secondary)
            .padding(.horizontal, 12)
            .padding(.vertical, 8)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.sky.opacity(0.10), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
    }
}

/// what kosh reads and why, before Gmail is connected: each kind of data and what it's for, where it's read, what
/// (if anything) leaves the phone, and how to take it all back (India's data protection rules ask for this notice)
struct ReadNotice: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            Text("What kosh reads, and why").font(.subheadline.weight(.semibold)).padding(.bottom, 6)
            MailLine(sym: "envelope", color: Color.kosh, text: "Money mail: bank and card alerts, statements, receipts, policies and deposits, to build your money picture")
            MailLine(sym: "person.2", color: Color.kosh, text: "Details you type for your family, only to open their locked statements")
            Divider().padding(.vertical, 6)
            MailLine(sym: "iphone", color: Color.green, text: "Read on this phone. There is no kosh server, and nothing is sent to one")
            MailLine(sym: "eye.slash", color: Color.green, text: "Read only: never sends, deletes or moves a message")
            MailLine(sym: "sparkles", color: Color.secondary, text: "Smart reading is off. If you turn it on, emails the rules can’t read go to an AI service with names and long numbers masked")
            MailLine(sym: "arrow.uturn.backward", color: Color.secondary, text: "Stop any time: Settings › Erase ends Google’s access and deletes everything kosh read")
        }
        .card(16)
    }
}

struct LiveMailStep: View {
    @Environment(Store.self) private var store
    let next: () -> Void
    @State private var days = 30
    @State private var client = ""
    /// months of spending the ledger starts with (1: last month and this one)
    @State private var window = 1

    var body: some View {
        let live = store.live!
        VStack(spacing: 0) {
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    StepTitle(sym: "envelope.badge.shield.half.filled", title: live.signedIn ? "Which inboxes should kosh read?" : "Let kosh read your money mail",
                              text: live.signedIn ? "Add every inbox where bank, card or bill mail lands: Gmail, Outlook, Yahoo, iCloud, a work address, a parent’s. kosh reads them all into one picture." : "Bank alerts, card statements, receipts and premiums. kosh reads them on this phone and builds everything from them.")
                    if live.signedIn {
                        GmailAccountsCard()
                    } else {
                        ReadNotice()
                    }
                    VStack(alignment: .leading, spacing: 0) {
                        MailLine(sym: "checkmark.circle.fill", color: Color.green, text: "Bank and card alerts, statements")
                        MailLine(sym: "checkmark.circle.fill", color: Color.green, text: "Bills, premiums, EMIs and receipts")
                        if !live.signedIn {
                            MailLine(sym: "plus.circle.fill", color: Color.kosh, text: "More than one inbox? Add the rest next")
                        }
                        Divider().padding(.vertical, 6)
                        MailLine(sym: "xmark.circle.fill", color: Color.secondary, text: "Read-only: never sends, moves or deletes")
                        MailLine(sym: "xmark.circle.fill", color: Color.secondary, text: "Mail that isn’t about money is skipped")
                    }
                    .card(16)
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Where your ledger starts").font(.headline)
                        Picker("Where your ledger starts", selection: $window) {
                            Text("Last month").tag(1)
                            Text("3 months").tag(3)
                            Text("The year").tag(12)
                        }
                        .pickerStyle(.segmented)
                        Text(window == 1 ? "Start small: last month and this one, few enough payments to name them all, and kosh learns from every one. Widen it any time in Settings."
                             : window == 3 ? "Three months of spending to name. kosh learns from each one you name and fills in the rest."
                             : "Every payment from the last year. A lot to name at once; most people start with last month.")
                            .font(.footnote).foregroundStyle(.secondary)
                        Label("kosh still reads the whole year: policies, statements, balances and what repeats.", systemImage: "calendar")
                            .font(.footnote).foregroundStyle(.secondary)
                    }
                    if live.clientID.isEmpty {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Google client ID").font(.headline)
                            TextField("…apps.googleusercontent.com", text: $client)
                                .textInputAutocapitalization(.never)
                                .autocorrectionDisabled()
                                .padding(12)
                                .background(Color.surface, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                                .onSubmit { live.setClientID(client) }
                                .onChange(of: client) { _, v in
                                    if v.trimmingCharacters(in: .whitespaces).hasSuffix(".apps.googleusercontent.com") { live.setClientID(v) }
                                }
                            Text("The beta needs the iOS client ID from your Google Cloud project before it can sign in.")
                                .font(.footnote).foregroundStyle(.secondary)
                        }
                    }
                }
                .padding(.horizontal, 24)
                .padding(.top, 72)
                .padding(.bottom, 20)
            }
            Group {
                if live.signedIn {
                    StepButton(title: live.allAccounts.count > 1 ? "Read \(Words.number(live.allAccounts.count)) inboxes" : "Read my mail") { start(live) }
                    Text(live.allAccounts.count == 2 ? "Both are read together, newest mail first." : live.allAccounts.count > 2 ? "All \(Words.number(live.allAccounts.count)) are read together, newest mail first." : "You can add more inboxes later in Settings too.")
                        .font(.footnote).foregroundStyle(.secondary).padding(.bottom, 8)
                } else {
                    // sign in first, then stay here so more inboxes can be added before the first read
                    VStack(spacing: 14) {
                        GoogleSignInButton(title: "Connect Gmail")
                            .disabled(live.clientID.isEmpty)
                        OtherEmailButton()
                    }
                    .padding(.horizontal, 24)
                    .padding(.bottom, 12)
                }
            }
        }
        .onAppear { days = live.scanDays }
    }

    func start(_ live: LiveSession) {
        // the ledger starts where they chose; the mail is read for the year either way (newest first)
        live.ledgerFrom = window >= 12 ? "" : LiveSession.monthStart(back: window)
        days = window >= 12 ? 365 : 30
        live.scanDays = days
        // setup's next screen waits on the first look, which starts now (only a new inbox has one: a read that's
        // already going, or an inbox read before, goes straight on)
        if !live.running && (live.records.isEmpty || live.scanFrom.isEmpty) { live.firstLook = false }
        Task { await live.scan(days: days) }
        next()
    }
}

/// Which kosh-reader model is on the phone, and a way to bring one in from Files
struct ReaderModelRow: View {
    let live: LiveSession
    @State private var picking = false
    @State private var note: String?
    var body: some View {
        let url = KoshReader.installed()
        LabeledContent("Model", value: url.map { $0.deletingPathExtension().lastPathComponent } ?? "Not on this phone yet")
        Button { picking = true } label: { Label(url == nil ? "Add kosh-reader from Files" : "Replace the model", systemImage: "square.and.arrow.down") }
            .fileImporter(isPresented: $picking, allowedContentTypes: [UTType(filenameExtension: "gguf") ?? .data, .data], allowsMultipleSelection: true) { result in
                switch result {
                case .success(let us):
                    // (the model and its .prompt.json together: the format file first, so the model reads with it)
                    do { for u in us.sorted(by: { $0.pathExtension == "json" && $1.pathExtension != "json" }) { _ = try KoshReader.importModel(from: u) }
                         note = "Added. kosh-reader reads new mail from now on."; Task { await live.aiPass() } }
                    catch { note = error.localizedDescription }
                case .failure(let e): note = e.localizedDescription
                }
            }
        if let note { Text(note).font(.footnote).foregroundStyle(.secondary) }
    }
}

/// Builds the training file for kosh-reader on request (it can be thousands of emails), then offers it to share
struct TrainingExportRow: View {
    let live: LiveSession
    @State private var url: URL?
    @State private var busy = false
    var body: some View {
        if let url {
            ShareLink(item: url) {
                Label("Share the training file", systemImage: "brain.head.profile")
            }
            Text("\(live.trainingCount) money emails, long numbers cut to the last four digits, each with what the bank rules read. Save it to Google Drive and AirDrop it to your Mac.")
                .font(.footnote).foregroundStyle(.secondary)
        } else {
            Button {
                busy = true
                Task { @MainActor in
                    url = live.exportForTraining()
                    busy = false
                }
            } label: {
                HStack {
                    Label(busy ? "Preparing…" : "Export for training kosh-reader", systemImage: "brain.head.profile")
                    Spacer()
                    Text("\(live.trainingCount)").foregroundStyle(.secondary)
                }
            }
            .disabled(busy || live.trainingCount == 0)
        }
    }
}

/// The inboxes kosh will read, with a way to add more, shown up front during setup
struct GmailAccountsCard: View {
    @Environment(Store.self) private var store
    var body: some View {
        let live = store.live!
        VStack(alignment: .leading, spacing: 10) {
            VStack(spacing: 0) {
                AccountLine(title: live.name.isEmpty ? live.email : live.name, email: live.email, color: Color.kosh, badge: "Signed in")
                ForEach(live.accounts) { a in
                    Divider().padding(.leading, 60)
                    AccountLine(title: a.person.flatMap { id in live.people.first { $0.id == id }.map { "\($0.name)’s · " + a.name } } ?? a.name, email: a.id, color: Color(hex: a.color), badge: nil) {
                        live.removeAccount(a.id)
                    }
                }
                Divider().padding(.leading, 60)
                AddAccountButton {}
                    .font(.body.weight(.semibold))
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.vertical, 14)
                    .padding(.horizontal, 16)
            }
            .background(Color.surface, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
            .animation(Motion.open, value: live.accounts.map(\.id))
            Text("During the beta, each extra address must be on the app’s test-user list in Google Cloud, or Google will block the sign-in.")
                .font(.footnote).foregroundStyle(.secondary)
        }
    }
}

private struct AccountLine: View {
    let title: String
    let email: String
    let color: Color
    let badge: String?
    var remove: (() -> Void)? = nil
    var body: some View {
        HStack(spacing: 12) {
            Avatar(name: title, color: color, size: 34)
            VStack(alignment: .leading, spacing: 1) {
                Text(title).font(.body.weight(.semibold)).lineLimit(1)
                if title != email { Text(email).font(.footnote).foregroundStyle(.secondary).lineLimit(1) }
            }
            Spacer(minLength: 8)
            if let badge {
                Text(badge).font(.caption.weight(.semibold)).foregroundStyle(Color.green)
            } else if let remove {
                RemoveInboxButton(addr: email, remove: remove)
            }
        }
        .padding(.vertical, 10)
        .padding(.horizontal, 14)
    }
}

/// Removing an inbox: everything read from it goes too, so it asks first, saying so. A 44-point target named for
/// VoiceOver: the red minus, or a word ("Disconnect") where a row has room for one.
struct RemoveInboxButton: View {
    let addr: String
    var word: String? = nil
    let remove: () -> Void
    @State private var asking = false
    var body: some View {
        Button(role: .destructive) { asking = true } label: {
            Group {
                if let word {
                    Text(word).font(.caption.weight(.semibold))
                } else {
                    Image(systemName: "minus.circle.fill").font(.title3)
                }
            }
            .frame(minWidth: 44, minHeight: 44)
            .contentShape(Rectangle())
        }
        .buttonStyle(.press)
        .foregroundStyle(Color.red)
        .accessibilityLabel("Remove " + addr)
        .confirmationDialog("Remove " + addr + "?", isPresented: $asking, titleVisibility: .visible) {
            Button("Remove inbox", role: .destructive) { withAnimation(Motion.open) { remove() } }
        } message: {
            Text("kosh signs out of it and deletes everything it read from it: its payments, bills and statements. Your mail stays in the inbox.")
        }
    }
}

/// Removing someone from the household: what was theirs becomes yours, so it asks first, saying so
struct RemovePersonButton: View {
    let person: PersonInfo
    let remove: () -> Void
    @State private var asking = false
    var body: some View {
        Button(role: .destructive) { asking = true } label: {
            Image(systemName: "minus.circle.fill").font(.title3)
                .frame(minWidth: 44, minHeight: 44)
                .contentShape(Rectangle())
        }
        .buttonStyle(.press)
        .foregroundStyle(Color.red)
        .accessibilityLabel("Remove " + person.full)
        .confirmationDialog("Remove " + person.full + "?", isPresented: $asking, titleVisibility: .visible) {
            Button("Remove " + person.name, role: .destructive) { withAnimation(Motion.open) { remove() } }
        } message: {
            Text("Their inboxes, accounts and cards become yours, with anything you added for them. Nothing read from their mail is deleted.")
        }
    }
}

// MARK: Setup's reading, in stages (LiveFoundStep): waiting, under way, done

enum SetupProgress {
    enum Stage { case waiting, active, done }

    /// "2026-09" → "September", for the reading bar and the Lock Screen
    static func monthName(_ m: String) -> String {
        guard let d = monthIn.date(from: m) else { return m }
        return monthOut.string(from: d)
    }
    /// made once: the reading bar asks for the month's name with every email read
    private static let monthIn: DateFormatter = {
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_IN"); f.dateFormat = "yyyy-MM"
        return f
    }()
    private static let monthOut: DateFormatter = {
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_IN"); f.dateFormat = "MMMM"
        return f
    }()

    struct StageRow: View {
        let title: String
        let detail: String
        let stage: Stage
        var body: some View {
            HStack(alignment: .top, spacing: 12) {
                ZStack {
                    Circle().fill(stage == .done ? Color.green : stage == .active ? Color.kosh.opacity(0.14) : Color.primary.opacity(0.06))
                    if stage == .done {
                        Image(systemName: "checkmark").font(.caption.weight(.heavy)).foregroundStyle(.white)
                            .transition(.scale.combined(with: .opacity))
                    } else if stage == .active {
                        Circle().fill(Color.kosh).frame(width: 8, height: 8)
                            .phaseAnimator([0.6, 1.0]) { v, p in v.scaleEffect(p).opacity(p) } animation: { _ in .easeInOut(duration: 0.7) }
                    }
                }
                .frame(width: 24, height: 24)
                VStack(alignment: .leading, spacing: 1) {
                    Text(title).font(.subheadline.weight(.semibold))
                        .foregroundStyle(stage == .waiting ? Color.secondary : Color.primary)
                    Text(detail).font(.footnote).foregroundStyle(.secondary)
                        .contentTransition(.numericText())
                }
                Spacer(minLength: 0)
            }
            .animation(Motion.large, value: stage == .done)
        }
    }
}

/// A capsule that fills with kosh's blues, with a light sweeping across while it works
struct GlowBar: View {
    var value: Double
    var active: Bool
    var tint: Color? = nil
    var height: CGFloat = 14
    @State private var sweep: CGFloat = -0.3
    var body: some View {
        GeometryReader { g in
            let w = max(height, g.size.width * min(1, max(0, value)))
            ZStack(alignment: .leading) {
                Capsule().fill(Color.primary.opacity(0.07))
                Capsule()
                    .fill(tint.map { AnyShapeStyle($0) } ?? AnyShapeStyle(LinearGradient(colors: [Color.kosh, Color.sky], startPoint: .leading, endPoint: .trailing)))
                    .frame(width: w)
                    .overlay(alignment: .leading) {
                        if active {
                            LinearGradient(colors: [.white.opacity(0), .white.opacity(0.6), .white.opacity(0)], startPoint: .leading, endPoint: .trailing)
                                .frame(width: 60)
                                .offset(x: sweep * w - 30)
                        }
                    }
                    .clipShape(Capsule())
                    .shadow(color: Color.kosh.opacity(active ? 0.35 : 0.15), radius: active ? 8 : 3, y: 2)
                    .animation(Motion.reveal, value: value)
            }
        }
        .frame(height: height)
        .onAppear { withAnimation(.linear(duration: 1.5).repeatForever(autoreverses: false)) { sweep = 1.15 } }
    }
}

/// Above the tab bar while kosh reads: what it's doing and how far it has got, on one line, with a slim bar under
/// it that fills as the emails are read. When the tab bar shrinks it's a single line: a word, the bar, the count.
struct ReadingBar: View {
    let now: ReadingNow
    @Environment(\.tabViewBottomAccessoryPlacement) private var placement

    /// the check when it's all caught up
    static let green = Color(light: "#1F8A3C", dark: "#5FD38A")

    var body: some View {
        let s: ReadingNow = now
        Group {
            if placement == .inline {
                HStack(spacing: 10) {
                    Text(s.short)
                        .font(.subheadline.weight(.semibold))
                        .lineLimit(1)
                        .fixedSize()
                    ReadingTrack(now: s)
                    ReadingCount(now: s)
                }
            } else {
                VStack(alignment: .leading, spacing: 8) {
                    HStack(spacing: 6) {
                        ReadingSymbol(now: s)
                        PlayfulTitle(now: s)
                        Spacer(minLength: 6)
                        ReadingCount(now: s)
                    }
                    ReadingTrack(now: s)
                }
            }
        }
        .padding(.horizontal, 18)
        .animation(Motion.large, value: s)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(s.title)
        .accessibilityValue(s.kind == .reading && !s.aside.isEmpty ? s.detail + ", " + s.aside : s.detail)
    }
}

/// The title, and now and then a lighter line in its place: it always starts on the plain words ("Reading new
/// mail", with "· 2 min left" beside them), then every few seconds takes a turn through a few gentler ones for
/// the same job, and back. The count on the right never jokes. VoiceOver reads the plain title (ReadingBar).
private struct PlayfulTitle: View {
    let now: ReadingNow
    @State private var turn = 0
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    /// a little personality while it works (each short enough to sit beside the count on a small phone)
    static func lines(_ kind: ReadingNow.Kind, aside: String) -> [String] {
        switch kind {
        case .finding: return ["Swiping left on spam", "Receipts, assemble", "Inbox ka hisaab", "Ignoring ‘Dear Customer’", "OTPs? Not our type"]
        case .wider: return ["No bank left behind", "Checking every sender", "Peeking in Promotions", "Leaving love letters alone"]
        case .reading, .inbox: return ["Hisaab-kitaab mode on", "Following the rupee trail", "Chasing every chillar", "UPI, you can’t hide", "Where did that ₹500 go?", "Skipping ‘pre-approved’"]
        case .again: return ["Old mail, sharper eyes", "Revision before exams", "Second look, no judgement", "Re-reading, chai in hand"]
        case .resuming: return ["Bookmark found", "Chai break over", "Right, where were we", "Not starting over, promise"]
        case .year: return (aside.isEmpty ? [] : ["Rewinding to " + aside]) + ["Last Diwali’s receipts", "Old statements, new tricks", "Time travel, minus the DeLorean"]
        case .wallets: return ["Counting chai money", "Samosa trail found", "Cashback? Noted.", "Wallets, empty your pockets"]
        case .statements, .docs: return ["Reading the fine print", "PDFs, but make it fun", "Totals: checking twice", "Unlocking the PDF vault"]
        case .reader: return ["Decoding bank-speak", "Reading between lines", "The tricky ones, slowly", "Translating bank Hindi"]
        case .waiting: return ["Wi-Fi, where art thou", "Bookmark’s safe, relax", "Back when you’re online"]
        case .done: return ["Hisaab done", "Every rupee home", "Ledger: spotless"]
        }
    }

    var body: some View {
        let extra: [String] = Self.lines(now.kind, aside: now.aside)
        // turn 0 is the plain title; then one lighter line, then plain again, so the meaning is never far away
        let plain: Bool = turn % 2 == 0 || extra.isEmpty
        let line: String = plain ? now.title : extra[(turn / 2) % extra.count]
        // the aside goes before the words are cut: the whole line, or the line alone, shrunk a touch if it must
        ViewThatFits(in: .horizontal) {
            HStack(spacing: 6) {
                titleText(line)
                if plain && !now.aside.isEmpty {
                    Text("· " + now.aside)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                        .fixedSize()
                        .transition(.opacity)
                }
            }
            titleText(line)
                .minimumScaleFactor(0.8)
        }
        .layoutPriority(1)
        .clipped()
        .animation(Motion.reveal, value: line)
        .task(id: now.kind) {
            turn = 0
            // the plain words stay a little longer than the light ones
            while !Task.isCancelled {
                try? await Task.sleep(for: .seconds(turn % 2 == 0 ? 4.2 : 3.2))
                if Task.isCancelled { break }
                turn += 1
            }
        }
    }
}

extension ReadingNow {
    /// the lighter lines for this job, the same the bar takes turns with: kosh's Lock Screen entry uses them too (ReadingLive)
    @MainActor var lighter: [String] { PlayfulTitle.lines(kind, aside: aside) }
}

extension PlayfulTitle {
    func titleText(_ line: String) -> some View {
        Text(line)
            .font(.subheadline.weight(.semibold))
            .lineLimit(1)
            .id(line)
            .transition(reduceMotion ? .opacity : .push(from: .bottom))
    }
}


/// what it's doing, in kosh blue: an envelope while it reads, a check (green) when it's done; it breathes
/// while it picks up where it stopped
private struct ReadingSymbol: View {
    let now: ReadingNow
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    var body: some View {
        Image(systemName: now.sym)
            .font(.system(size: 13, weight: .semibold))
            .foregroundStyle(now.finished ? ReadingBar.green : now.paused ? Color.secondary : Color.kosh)
            .symbolEffect(.pulse, isActive: now.resumed && !reduceMotion)
            .contentTransition(.symbolEffect(.replace))
            .frame(width: 18)
    }
}

/// "412 of 1,240", the figures rolling as they change
private struct ReadingCount: View {
    let now: ReadingNow
    var body: some View {
        Text(now.count)
            .font(.system(.caption, design: .rounded, weight: .semibold))
            .monospacedDigit()
            .foregroundStyle(now.paused ? Color.secondary : Color.primary.opacity(0.78))
            .contentTransition(.numericText(value: Double(now.done)))
            .lineLimit(1)
            .fixedSize()
            .layoutPriority(2)
    }
}

/// The slim bar: a 4 pt capsule. kosh's gradient is laid across the whole track and shown only as far as the
/// reading has got, so the colour reveals as it fills; a soft light sits at the leading edge and a slow white
/// sheen crosses the fill. While it's still counting, a short stretch of blue slides across instead. Waiting
/// for the internet: grey and still. With Reduce Motion, nothing moves but the fill itself.
struct ReadingTrack: View {
    /// off while its tab is behind another (kosh keeps visited tabs alive): its animation rests
    @Environment(\.tabActive) private var tabActive
    let now: ReadingNow
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    static var mid: Color { Look.shared.accent == .kosh ? Color(light: "#4C86FB", dark: "#69AEFF") : Color.kosh.mix(with: Color.sky, by: 0.5) }
    static let glow = Color(red: 0x7F / 255.0, green: 0xD6 / 255.0, blue: 0xFF / 255.0)
    static let grey = Color(uiColor: .systemGray3)

    var body: some View {
        GeometryReader { g in
            let w: CGFloat = g.size.width
            let least: CGFloat = now.fraction > 0 ? 4 : 0
            let fill: CGFloat = now.indeterminate ? 0 : min(w, max(least, w * CGFloat(now.fraction)))
            ZStack(alignment: .leading) {
                Capsule().fill(now.paused ? Color.primary.opacity(0.10) : Color.kosh.opacity(0.13))
                if now.indeterminate {
                    if !now.paused { seek(w) }
                } else {
                    ZStack(alignment: .leading) {
                        if now.paused {
                            Self.grey
                        } else {
                            LinearGradient(colors: [Color.kosh, Self.mid, Color.sky], startPoint: .leading, endPoint: .trailing)
                        }
                        if !reduceMotion && !now.paused && !now.finished { sheen(fill) }
                    }
                    .frame(width: w, height: 4)
                    .mask(alignment: .leading) { Capsule().frame(width: fill, height: 4) }
                }
            }
            .frame(width: w, height: 4)
            .clipShape(Capsule())
            .overlay(alignment: .leading) {
                // a soft light at the leading edge, where the reading has got to
                if !now.indeterminate && !now.paused && !now.finished && fill > 0 {
                    Circle()
                        .fill(Self.glow)
                        .frame(width: 12, height: 12)
                        .blur(radius: 4)
                        .offset(x: fill - 6)
                        .allowsHitTesting(false)
                }
            }
            .animation(reduceMotion ? nil : Motion.reveal, value: fill)
        }
        .frame(height: 4)
        .accessibilityHidden(true)
    }

    /// a 46 pt band of white crossing the filled part, slowly, over and over
    private func sheen(_ fill: CGFloat) -> some View {
        TimelineView(.animation(minimumInterval: 1.0 / 20, paused: !tabActive)) { ctx in
            let period: Double = 2.4
            let p: Double = ctx.date.timeIntervalSinceReferenceDate.truncatingRemainder(dividingBy: period) / period
            LinearGradient(colors: [.white.opacity(0), .white.opacity(0.7), .white.opacity(0)], startPoint: .leading, endPoint: .trailing)
                .frame(width: 46, height: 4)
                .offset(x: -46 + CGFloat(p) * (fill + 46))
        }
        .frame(maxWidth: .infinity, maxHeight: 4, alignment: .leading)
        .transaction { $0.animation = nil }
    }

    /// still counting: a short stretch of blue sliding across, easing in and out (still, with Reduce Motion)
    private func seek(_ w: CGFloat) -> some View {
        let segment: CGFloat = w * 0.34
        let band = LinearGradient(stops: [.init(color: Color.kosh.opacity(0), location: 0), .init(color: Color.kosh, location: 0.4),
                                          .init(color: Color.sky, location: 0.7), .init(color: Color.sky.opacity(0), location: 1)],
                                  startPoint: .leading, endPoint: .trailing)
        return Group {
            if reduceMotion {
                band.frame(width: segment, height: 4).offset(x: (w - segment) / 2)
            } else {
                TimelineView(.animation(minimumInterval: 1.0 / 20, paused: !tabActive)) { ctx in
                    let period: Double = 1.35
                    let t: Double = ctx.date.timeIntervalSinceReferenceDate.truncatingRemainder(dividingBy: period) / period
                    let e: Double = t * t * (3 - 2 * t)
                    band.frame(width: segment, height: 4).offset(x: -segment + CGFloat(e) * (w + segment))
                }
            }
        }
        .frame(width: w, height: 4, alignment: .leading)
        .transaction { $0.animation = nil }
    }
}

// MARK: Setup: insurance, investments and property, read and laid out before you start

struct LivePapersStep: View {
    @Environment(Store.self) private var store
    let next: () -> Void
    @State private var portalState = "Haryana"
    @State private var showPortal = false

    var body: some View {
        let live = store.live!
        let policies = store.snap.policies
        let classes = store.classes(.family)
        let holdings = store.holdings(.family)
        let props = live.properties
        let busy = live.findingDocs || live.readingDocs
        VStack(spacing: 0) {
            List {
                Section {
                    StepTitle(sym: "doc.text.magnifyingglass", title: "Insurance, investments and property",
                              text: "kosh looked through the year’s mail for policy schedules and statements. Locked ones need their password once per sender. Your properties come from the state’s portal.")
                        .listRowBackground(Color.clear)
                        .listRowInsets(EdgeInsets(top: 8, leading: 4, bottom: 8, trailing: 4))
                    if busy {
                        VStack(alignment: .leading, spacing: 8) {
                            Text(live.findingDocs ? "Finding policies and statements across the year…" : "Opening and reading them…")
                                .font(.subheadline.weight(.semibold))
                            GlowBar(value: live.findingDocs ? (live.bgTotal > 0 ? Double(live.bgFetched) / Double(live.bgTotal) : 0.05) : 0.7, active: true, height: 10)
                        }
                        .padding(.vertical, 4)
                    }
                }

                Section {
                    if policies.isEmpty {
                        Text(busy ? "Looking…" : "No policies found in your mail yet. Add a policy PDF below, or later from the Insurance tab.")
                            .font(.subheadline).foregroundStyle(.secondary)
                    }
                    ForEach(policies) { p in
                        HStack(spacing: 12) {
                            IconTile(symbol: "shield.lefthalf.filled", color: Color(hex: "#30B0C7"), size: 34)
                            VStack(alignment: .leading, spacing: 2) {
                                Text("\(p.insurer)\(p.type.isEmpty ? "" : " · " + p.type)").font(.body.weight(.semibold)).lineLimit(1)
                                Text([p.cover.map { $0 > 0 ? "Cover " + Fmt.words($0) : "" } ?? "",
                                      p.premium > 0 ? "Premium " + Fmt.rupees(p.premium) : "",
                                      p.nextDue.isEmpty ? "" : "Next " + Day.short(p.nextDue)].filter { !$0.isEmpty }.joined(separator: " · "))
                                    .font(.footnote).foregroundStyle(.secondary).lineLimit(2)
                                if let n = p.nominee, !n.isEmpty { Text("Nominee: \(n)").font(.caption).foregroundStyle(.secondary) }
                            }
                        }
                        .privacySensitive()
                    }
                } header: {
                    Text("Insurance · \(policies.count) polic\(policies.count == 1 ? "y" : "ies")")
                }
                StatementsSection(kinds: ["policy"], title: "Policy PDFs", empty: busy ? "Looking…" : "No policy PDFs in your mail.")

                Section {
                    if holdings.isEmpty {
                        Text(busy ? "Looking…" : "No investments read yet. A CAS from NSDL, CDSL, CAMS or KFintech fills this in.")
                            .font(.subheadline).foregroundStyle(.secondary)
                    } else {
                        ForEach(classes) { c in
                            HStack {
                                Circle().fill(c.color).frame(width: 9, height: 9)
                                Text(c.title)
                                Spacer()
                                Text("\(c.n) · \(Fmt.words(c.v))").fontWeight(.semibold).privacySensitive()
                            }
                        }
                        HStack {
                            Text("Total").fontWeight(.semibold)
                            Spacer()
                            Text(Fmt.words(holdings.reduce(0) { $0 + $1.amt })).font(.title3.weight(.bold)).privacySensitive()
                        }
                    }
                } header: {
                    Text("Investments")
                }
                StatementsSection(kinds: ["cas", "contract"], title: "Statements", empty: busy ? "Looking…" : "No CAS or demat statements in your mail.")

                Section {
                    Picker("State", selection: $portalState) {
                        ForEach(LiveSession.states, id: \.self) { Text($0).tag($0) }
                    }
                    if let p = LiveSession.portal(for: portalState) {
                        Button { showPortal = true } label: {
                            HStack(spacing: 12) {
                                IconTile(symbol: "building.columns.fill", color: Color.kosh, size: 34)
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(props.isEmpty ? "Read my properties from \(p.name)" : "Read again from \(p.name)").font(.body.weight(.semibold)).foregroundStyle(Color.primary)
                                    Text("Log in with your mobile and OTP. kosh reads every property on your number and each one’s dues, and only reads.")
                                        .font(.footnote).foregroundStyle(.secondary)
                                }
                            }
                        }
                    }
                    ForEach(props) { pr in
                        HStack(spacing: 12) {
                            IconTile(symbol: "building.2.fill", color: Color.orange, size: 34)
                            VStack(alignment: .leading, spacing: 2) {
                                Text(pr.name.isEmpty ? "PID " + pr.pid : pr.name).font(.body.weight(.semibold)).lineLimit(1)
                                Text(["PID " + pr.pid, pr.owner ?? "", pr.plotArea ?? ""].filter { !$0.isEmpty }.joined(separator: " · "))
                                    .font(.footnote).foregroundStyle(.secondary).lineLimit(1)
                            }
                            Spacer()
                            if let d = pr.dueTotal {
                                VStack(alignment: .trailing, spacing: 1) {
                                    Text(d > 0 ? Fmt.rupees(d) : "Nothing due").font(.subheadline.weight(.semibold)).foregroundStyle(d > 0 ? Color.orange : Color.green)
                                    if d > 0 { Text("due").font(.caption2).foregroundStyle(.secondary) }
                                }
                            }
                        }
                        .privacySensitive()
                    }
                } header: {
                    Text("Property · \(props.count)")
                } footer: {
                    Text("Haryana’s ULB portal is read in full. Other states’ portals are read where kosh knows their layout; more are coming.")
                }
            }
            .listStyle(.insetGrouped)
            .animation(Motion.open, value: policies.count)
            .animation(Motion.open, value: props.count)
            StepButton(title: policies.isEmpty && holdings.isEmpty && props.isEmpty ? "Skip for now" : "Looks right", action: next)
        }
        .sheet(isPresented: $showPortal) {
            PortalSheet(state: portalState).environment(store).tint(Color.kosh)
        }
        .task {
            // statements found but not opened yet (the read is still running, or setup came back here)
            if !live.readingDocs && live.records.contains(where: { $0.doc?.state == "" }) { await live.readDocuments() }
        }
    }
}

/// Policies, investments and property, from Home's "Finish setting up" (setup no longer stops for them)
struct PapersSheet: View {
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            LivePapersStep { dismiss() }
                .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } } }
                .navigationBarTitleDisplayMode(.inline)
        }
    }
}

/// The household: you, plus whoever's accounts show up
struct HouseholdEditor: View {
    @Environment(Store.self) private var store
    @State private var newName = ""
    @State private var rel = "Spouse"
    let rels = ["Spouse", "Mom", "Papa", "Child", "Sibling", "Other"]

    var body: some View {
        let live = store.live!
        let people = live.people.isEmpty ? [PersonInfo(id: "me", name: live.firstName, full: live.name.isEmpty ? "You" : live.name, rel: "You", color: LiveSession.palette[0])] : live.people
        VStack(alignment: .leading, spacing: 16) {
            VStack(spacing: 0) {
                ForEach(Array(people.enumerated()), id: \.element.id) { i, p in
                    if i > 0 { Divider().padding(.leading, 66) }
                    HStack(spacing: 12) {
                        Avatar(name: p.full, color: Color(hex: p.color), size: 42)
                        VStack(alignment: .leading, spacing: 2) {
                            Text(p.full).font(.body.weight(.semibold))
                            Text(p.id == "me" ? "You" + (live.email.isEmpty ? "" : " · " + live.email) : p.rel).font(.subheadline).foregroundStyle(.secondary).lineLimit(1)
                            if live.signedIn { PersonGmailButton(person: p).padding(.top, 2) }
                        }
                        Spacer()
                        if p.id != "me" {
                            RemovePersonButton(person: p) { live.removePerson(p.id); store.refreshPeople() }
                        }
                    }
                    .padding(.vertical, 10)
                    .padding(.horizontal, 14)
                }
            }
            .background(Color.surface, in: RoundedRectangle(cornerRadius: 26, style: .continuous))
            VStack(alignment: .leading, spacing: 10) {
                Text("Add someone").font(.headline)
                TextField("Name", text: $newName)
                    .textInputAutocapitalization(.words)
                    .padding(12)
                    .background(Color.surface, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                Picker("Relation", selection: $rel) {
                    ForEach(rels, id: \.self) { Text($0).tag($0) }
                }
                .pickerStyle(.segmented)
                Button {
                    withAnimation(Motion.open) { live.addPerson(name: newName, rel: rel); store.refreshPeople() }
                    newName = ""
                } label: {
                    Label("Add", systemImage: "person.badge.plus").frame(maxWidth: .infinity)
                }
                .buttonStyle(.glass)
                .disabled(newName.trimmingCharacters(in: .whitespaces).isEmpty)
            }
        }
    }
}

/// Accounts and cards found, each with whose it is and whether to keep it
struct FoundList: View {
    @Environment(Store.self) private var store
    struct Item: Identifiable, Hashable { let id: String; let bank: String; let name: String; let last: String; let color: String; let count: Int; let card: Bool }
    @State private var items: [Item] = []

    var body: some View {
        let live = store.live!
        let people = live.people
        VStack(alignment: .leading, spacing: 18) {
            ForEach([false, true], id: \.self) { isCard in
                let rows = items.filter { $0.card == isCard }
                if !rows.isEmpty {
                    VStack(alignment: .leading, spacing: 10) {
                        Text(isCard ? "Cards" : "Bank accounts").font(.headline)
                        VStack(spacing: 0) {
                            ForEach(Array(rows.enumerated()), id: \.element.id) { i, it in
                                if i > 0 { Divider().padding(.leading, 64) }
                                let on = !live.hidden.contains(it.id)
                                HStack(spacing: 12) {
                                    InstIcon(name: it.bank, color: Color(hex: it.color), size: 36, hint: it.name)
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text(it.name + (it.last.isEmpty ? "" : " ••" + it.last)).font(.body.weight(.medium)).lineLimit(1)
                                        Text("\(it.count) payment\(it.count == 1 ? "" : "s")").font(.subheadline).foregroundStyle(.secondary)
                                    }
                                    Spacer(minLength: 6)
                                    if people.count > 1 && on {
                                        Menu {
                                            ForEach(people) { p in
                                                Button(p.id == "me" ? "You" : p.full) { live.setOwner(it.id, p.id) }
                                            }
                                        } label: {
                                            let o = live.owners[it.id] ?? "me"
                                            Text(o == "me" ? "You" : (people.first { $0.id == o }?.name ?? o))
                                                .font(.subheadline.weight(.semibold))
                                        }
                                    }
                                    Button {
                                        withAnimation(Motion.base) { live.setHidden(it.id, on) }
                                    } label: {
                                        Image(systemName: on ? "checkmark.circle.fill" : "circle")
                                            .font(.title3)
                                            .foregroundStyle(on ? Color.kosh : Color.secondary)
                                            .contentTransition(.symbolEffect(.replace))
                                    }
                                    .buttonStyle(.press)
                                }
                                .opacity(on ? 1 : 0.5)
                                .padding(.vertical, 10)
                                .padding(.horizontal, 14)
                            }
                        }
                        .background(Color.surface, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
                    }
                }
            }
        }
        // the list keeps what it showed (an account you unticked stays, to tick again) and takes in what the reading
        // finds meanwhile, so it grows while setup reads
        .onAppear { merge() }
        .onChange(of: store.snap.generated) { _, _ in withAnimation(Motion.open) { merge() } }
    }

    func merge() {
        let accts: [Item] = store.snap.accounts.map { Item(id: $0.id, bank: $0.bank, name: $0.name, last: $0.last, color: $0.color, count: $0.count, card: false) }
        let cards: [Item] = store.snap.cards.map { Item(id: $0.id, bank: $0.bank, name: $0.name, last: $0.last, color: $0.color, count: $0.count, card: true) }
        let now: [Item] = accts + cards
        var byID: [String: Item] = [:]
        for it in now where byID[it.id] == nil { byID[it.id] = it }
        let kept: [Item] = items.map { byID[$0.id] ?? $0 }
        let seen = Set(items.map(\.id))
        items = kept + now.filter { !seen.contains($0.id) }
    }
}

// MARK: Reading check: only what needs you. The counts that don't change anything are gone.

struct ParserCheckView: View {
    @Environment(Store.self) private var store
    @State private var allDiffs = false
    @State private var allUnread = false
    @State private var teach: Teach?
    struct Teach: Identifiable { let id: String }

    var body: some View {
        if let live = store.live {
            List {
                Section {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("\(live.readCount) emails read")
                            .font(.title3.weight(.bold))
                        let money = live.ruleCount + live.claudeRead
                        let total = max(1, money + live.noiseCount + live.waitingCount)
                        GeometryReader { g in
                            HStack(spacing: 2) {
                                Capsule().fill(Color.kosh).frame(width: g.size.width * CGFloat(money) / CGFloat(total))
                                Capsule().fill(Color.primary.opacity(0.12)).frame(width: g.size.width * CGFloat(live.noiseCount) / CGFloat(total))
                                if live.waitingCount > 0 { Capsule().fill(Color.orange).frame(width: max(4, g.size.width * CGFloat(live.waitingCount) / CGFloat(total))) }
                            }
                        }
                        .frame(height: 8)
                        HStack(spacing: 14) {
                            Legend(color: Color.kosh, text: "\(money) about money")
                            Legend(color: Color.primary.opacity(0.25), text: "\(live.noiseCount) not")
                            if live.waitingCount > 0 { Legend(color: Color.orange, text: "\(live.waitingCount) unread") }
                        }
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        if live.running || live.message != nil { LiveStatusLine(live: live) }
                    }
                    .padding(.vertical, 4)
                    if live.aiReady && !live.running && live.waitingCount > 0 {
                        Button("Read the \(live.waitingCount) now with \(live.aiName)") { Task { await live.aiPass() } }
                    }
                } footer: {
                    Text(live.waitingCount == 0 && live.differs.isEmpty ? "Nothing needs you here." : "Below: only the emails that need a look.")
                }
                let diffs = live.differs
                if !diffs.isEmpty {
                    Section {
                        ForEach(allDiffs ? diffs : Array(diffs.prefix(5))) { r in DifferRow(r: r) }
                        if diffs.count > 5 && !allDiffs { Button("Show all \(diffs.count)") { withAnimation(Motion.open) { allDiffs = true } } }
                    } header: {
                        Text("Read two ways")
                    } footer: {
                        Text("The bank rules and \(live.aiName) disagree. Pick the right one; it goes into the ledger.")
                    }
                }
                let unread = live.unread
                if !unread.isEmpty {
                    Section {
                        ForEach(allUnread ? unread : Array(unread.prefix(5))) { r in UnreadRow(r: r) }
                        if unread.count > 5 && !allUnread { Button("Show all \(unread.count)") { withAnimation(Motion.open) { allUnread = true } } }
                    } header: {
                        Text("Couldn’t read yet")
                    }
                    // a sender whose layout no rule reads: Claude can write one, which kosh keeps only if it reads them all
                    let senders = Dictionary(grouping: unread.filter { !($0.text ?? "").isEmpty }, by: { SenderPasswords.domain($0.from ?? "") })
                        .map { (domain: $0.key, n: $0.value.count) }.sorted { $0.n > $1.n }.prefix(5)
                    if !senders.isEmpty {
                        Section {
                            ForEach(Array(senders), id: \.domain) { x in
                                Button { teach = Teach(id: x.domain) } label: {
                                    HStack {
                                        Label("Teach kosh " + x.domain, systemImage: "graduationcap.fill")
                                        Spacer()
                                        Text("\(x.n)").foregroundStyle(.secondary)
                                    }
                                }
                            }
                        } footer: {
                            Text("With smart reading, an AI looks at a few of a sender’s emails, numbers masked, and writes a reading rule. kosh uses it only if it reads every one right.")
                        }
                    }
                }
                let missed = live.coverage.filter { $0.missed > 0 }.sorted { $0.missed > $1.missed }.prefix(5)
                if !missed.isEmpty {
                    Section {
                        ForEach(Array(missed)) { c in
                            HStack {
                                Text(c.inst)
                                Spacer()
                                Text("\(c.missed) not read").foregroundStyle(Color.orange)
                            }
                            .font(.subheadline)
                        }
                    } header: {
                        Text("Senders kosh is still learning")
                    } footer: {
                        Text("Shake the phone on one of their emails to tell me which bank it is.")
                    }
                }
            }
            .navigationTitle("Reading check")
            .navigationBarTitleDisplayMode(.inline)
            .sheet(item: $teach) { t in ReaderTutorSheet(domain: t.id).environment(store).tint(Color.kosh) }
        } else {
            Text("The reading check is part of the beta.").foregroundStyle(.secondary)
        }
    }

    struct Legend: View {
        let color: Color
        let text: String
        var body: some View {
            HStack(spacing: 5) {
                Circle().fill(color).frame(width: 7, height: 7)
                Text(text)
            }
        }
    }
}

struct ReadingLines: View {
    let title: String
    let r: Reading
    let marked: [String]
    var body: some View {
        VStack(alignment: .leading, spacing: 3) {
            Text(title).font(.caption.weight(.semibold)).foregroundStyle(.secondary)
            if r.kind == "noise" {
                Text("Not a money email").font(.subheadline)
            } else {
                line("amount", (r.dir == "in" ? "+ " : "") + Fmt.rupees(r.amt ?? 0) + " " + (r.dir == "in" ? "in" : "out"), key: "amount", alt: "direction")
                line("date", r.date.map { Day.short($0) } ?? "–", key: "date")
                line("account", [r.inst ?? "", r.instr ?? "", (r.last4 ?? "").isEmpty ? "" : "••" + r.last4!].filter { !$0.isEmpty }.joined(separator: " "), key: "account")
                line("party", r.party?.isEmpty == false ? r.party! : (r.vpa ?? "–"), key: "party")
                if r.kind != "txn" { line("kind", r.kind, key: "kind") }
            }
        }
    }
    func line(_ label: String, _ value: String, key: String, alt: String = "") -> some View {
        let hot = marked.contains(key) || (!alt.isEmpty && marked.contains(alt))
        return HStack(alignment: .firstTextBaseline, spacing: 6) {
            Text(label).font(.caption).foregroundStyle(.secondary).frame(width: 56, alignment: .leading)
            Text(value).font(.subheadline.weight(hot ? .semibold : .regular)).foregroundStyle(hot ? Color.orange : Color.primary).lineLimit(2)
        }
    }
}

struct DifferRow: View {
    @Environment(Store.self) private var store
    let r: Reading
    @State private var open = false
    var body: some View {
        let live = store.live!
        let fields = r.check?.fields ?? []
        VStack(alignment: .leading, spacing: 10) {
            Text(r.subject ?? "").font(.subheadline.weight(.semibold)).lineLimit(2)
            Text("\(r.from ?? "") · \(r.sent.map { Day.short($0) } ?? "")").font(.caption).foregroundStyle(.secondary)
            HStack(alignment: .top, spacing: 12) {
                ReadingLines(title: "BANK RULE · \(r.rule ?? "")", r: r, marked: fields)
                    .frame(maxWidth: .infinity, alignment: .leading)
                if let c = r.claude?.r {
                    ReadingLines(title: (c.src == "reader" ? "KOSH-READER" : "SMART READING") + " · \(c.conf ?? "")", r: c, marked: fields)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
            }
            HStack {
                Button { live.choose(r.id, claude: false) } label: {
                    Label("Rule is right", systemImage: r.use == "rule" ? "checkmark.circle.fill" : "circle")
                }
                .buttonStyle(.glass)
                Button { live.choose(r.id, claude: true) } label: {
                    Label(r.claude?.r.src == "reader" ? "Reader is right" : "Smart reading is right", systemImage: r.use == "claude" ? "checkmark.circle.fill" : "circle")
                }
                .buttonStyle(.glass)
            }
            .font(.subheadline)
            if let t = r.text, !t.isEmpty {
                DisclosureGroup("The email", isExpanded: $open) {
                    Text(String(t.prefix(3000))).font(.caption).foregroundStyle(.secondary).textSelection(.enabled)
                }
                .font(.subheadline)
            }
        }
        .padding(.vertical, 4)
    }
}

struct UnreadRow: View {
    let r: Reading
    @State private var open = false
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(r.subject ?? "").font(.subheadline.weight(.semibold)).lineLimit(2)
            Text("\(r.from ?? "") · \(r.sent.map { Day.short($0) } ?? "")").font(.caption).foregroundStyle(.secondary)
            if let why = r.reason { Text(why).font(.caption).foregroundStyle(Color.orange) }
            if let t = r.text, !t.isEmpty {
                DisclosureGroup("The email", isExpanded: $open) {
                    Text(String(t.prefix(3000))).font(.caption).foregroundStyle(.secondary).textSelection(.enabled)
                }
                .font(.subheadline)
            }
        }
        .padding(.vertical, 2)
    }
}

// MARK: Settings, live

/// Mail: the inboxes kosh reads, and reading them again. Every inbox kosh holds is a row, each saying whose it is and
/// when it was last read; one whose key is gone says so on its own row with Reconnect, and the others stay listed.
/// (Until 28 Oct the page read only `signedIn`, the first inbox's flag: when that went false, every inbox vanished
/// behind a "Sign in to Google" button, though the others were still being read.)
struct MailSettings: View {
    @Environment(Store.self) private var store
    @State private var connecting: Bool = false
    var body: some View {
        if let live = store.live {
            let inboxes: [String] = live.allAccounts
            List {
                Section {
                    if inboxes.isEmpty {
                        Button { connecting = true } label: {
                            SettingsRow(symbol: "envelope.fill", color: Color(hex: "#007AFF"), title: "Connect your email",
                                        caption: "Gmail, Outlook, Yahoo, iCloud")
                        }
                        .buttonStyle(.press)
                    } else {
                        ForEach(inboxes, id: \.self) { (addr: String) in
                            InboxRow(live: live, addr: addr) { connecting = true }
                        }
                        Button { connecting = true } label: {
                            Label("Add another inbox", systemImage: "plus")
                                .font(SettingsType.title)
                                .foregroundStyle(Color.kosh)
                                .frame(minHeight: 44)
                        }
                        .buttonStyle(.press)
                    }
                } header: { SettingsHeader("Inboxes") } footer: {
                    Text("kosh reads only money mail. It never sends, moves or deletes.")
                }
                if live.signedIn {
                    Section {
                        Button { Task { await live.scan() } } label: {
                            SettingsRow(symbol: "arrow.clockwise", color: Color(hex: "#34C759"), title: "Read new mail",
                                        value: MailSettings.when(live.lastScan))
                        }
                        .buttonStyle(.press)
                        .disabled(live.running)
                        if live.scanDays < 365 {
                            Button { Task { await live.scan(days: 365) } } label: {
                                SettingsRow(symbol: "calendar", color: Color(hex: "#FF9500"), title: "Read the rest of the year")
                            }
                            .buttonStyle(.press)
                            .disabled(live.running)
                        }
                        if live.running || live.message != nil { LiveStatusLine(live: live) }
                        if live.backfilling {
                            Label("Filling in older months", systemImage: "clock.arrow.circlepath")
                                .font(SettingsType.caption).foregroundStyle(.secondary)
                        }
                    } header: { SettingsHeader("Reading") } footer: {
                        if !live.scanFrom.isEmpty && live.readCount > 0 {
                            Text("\(live.readCount) emails read since \(Day.fmt(live.scanFrom, "d MMM yyyy")).")
                        }
                    }
                    Section { Button("Sign out of Google", role: .destructive) { live.signOut() } }
                }
            }
            .settingsPage("Mail")
            .onAppear { live.recheckSignIn() }
            .sheet(isPresented: $connecting) {
                ConnectInboxSheet(person: nil, onDone: { Task { await live.scan() } }).presentationDetents([.large])
            }
        }
    }

    /// when mail was last read, for a row's right side: "9:40 AM" today, else "26 Oct"
    static func when(_ iso: String) -> String {
        guard let d = isoIn.date(from: iso) else { return "" }
        return (Calendar.current.isDateInToday(d) ? clock : dayMonth).string(from: d)
    }
    // (made once: every row and redraw made new ones, and making a formatter is slow)
    private static let isoIn = ISO8601DateFormatter()
    private static let clock: DateFormatter = { let f = DateFormatter(); f.dateFormat = "h:mm a"; return f }()
    private static let dayMonth: DateFormatter = { let f = DateFormatter(); f.dateFormat = "d MMM"; return f }()
}

/// one inbox: its person's initials, the address, the provider and when kosh last read it, and whose it is on the
/// right (a menu: whose it is, or remove it). One whose key is gone says Reconnect instead.
struct InboxRow: View {
    @Environment(Store.self) private var store
    let live: LiveSession
    let addr: String
    let reconnect: () -> Void
    @State private var asking: Bool = false

    var body: some View {
        let primary: Bool = addr == live.email
        let acct: MailAccount? = live.accounts.first { $0.id == addr }
        let connected: Bool = primary ? live.signedIn : live.keyKept(addr)
        let owner: String = primary ? "me" : (acct?.person ?? "me")
        let ownerName: String = owner == "me" ? "You" : (live.people.first { $0.id == owner }?.name ?? "You")
        let read: String = MailSettings.when(acct?.lastScan.isEmpty == false ? (acct?.lastScan ?? "") : live.lastScan)
        HStack(spacing: 12) {
            Avatar(name: ownerName == "You" ? (live.name.isEmpty ? addr : live.name) : ownerName,
                   color: owner == "me" ? Color.koshFill : Color(hex: acct?.color ?? "#8E8E93"), size: 36,
                   ink: owner == "me" ? Color.onKosh : Color.white)
            VStack(alignment: .leading, spacing: 2) {
                Text(addr).font(SettingsType.title).lineLimit(1).truncationMode(.middle)
                Text(connected ? live.providerName(addr) + (read.isEmpty ? "" : ", read " + read) : "Not connected")
                    .font(SettingsType.caption)
                    .foregroundStyle(connected ? Color.secondary : Color.orange)
                    .lineLimit(1)
            }
            Spacer(minLength: 8)
            if !connected && primary {
                Button("Reconnect", action: reconnect)
                    .font(.subheadline.weight(.semibold))
                    .buttonStyle(.bordered).buttonBorderShape(.capsule).controlSize(.small)
                    .tint(Color.kosh)
            } else if primary {
                Text("You").font(SettingsType.value).foregroundStyle(.secondary).fixedSize()
            } else {
                Menu {
                    Section("Whose inbox") {
                        ForEach(live.people.isEmpty ? [PersonInfo(id: "me", name: "You", full: "You", rel: "You", color: "#007AFF")] : live.people) { (p: PersonInfo) in
                            Button { live.setInboxOwner(addr, p.id) } label: {
                                if p.id == owner { Label(p.id == "me" ? "Mine" : p.full, systemImage: "checkmark") } else { Text(p.id == "me" ? "Mine" : p.full) }
                            }
                        }
                    }
                    Button("Remove inbox…", role: .destructive) { asking = true }
                } label: {
                    HStack(spacing: 3) {
                        Text(ownerName)
                        Image(systemName: "chevron.up.chevron.down").font(.caption2.weight(.semibold))
                    }
                    .font(SettingsType.value)
                    .foregroundStyle(.secondary)
                    .frame(minHeight: 44)
                    .contentShape(Rectangle())
                }
                .fixedSize()
                .accessibilityLabel("Whose inbox: " + ownerName)
            }
        }
        .frame(minHeight: 52)
        .confirmationDialog("Remove " + addr + "?", isPresented: $asking, titleVisibility: .visible) {
            Button("Remove inbox", role: .destructive) { withAnimation(Motion.open) { live.removeAccount(addr) } }
        } message: {
            Text("kosh signs out of it and deletes everything it read from it: its payments, bills and statements. Your mail stays in the inbox.")
        }
    }
}

/// Reading: what reads the mail the rules can't, the statements, and the checks
struct ReadingSettings: View {
    @Environment(Store.self) private var store
    @State private var key = ""
    var body: some View {
        if let live = store.live {
            List {
                Section {
                    Picker("Reader", selection: Binding(get: { live.aiMode }, set: { live.aiMode = $0 })) {
                        if AppleBrain.available || live.aiMode == "apple" { Text("Apple Intelligence (on this phone)").tag("apple") }
                        Text("kosh-reader (on this phone)").tag("reader")
                        Text("Smart reading (reads every money mail)").tag("claude")
                        Text("Off").tag("off")
                    }
                    if live.aiMode == "reader" { ReaderModelRow(live: live) }
                    if live.aiMode == "claude" {
                        if live.claudeReady {
                            LabeledContent("API key", value: "Saved on this phone")
                            Button("Remove the key", role: .destructive) { live.setClaudeKey(nil) }
                        } else {
                            SecureField("sk-ant-…", text: $key).textInputAutocapitalization(.never).autocorrectionDisabled()
                            Button("Save key") { live.setClaudeKey(key); key = ""; Task { await live.aiPass() } }.disabled(key.count < 20)
                        }
                        let c = live.claudeCoverage
                        LabeledContent("Read by smart reading", value: "\(c.read) of \(c.of) emails")
                        if live.aiReady && c.read < c.of {
                            Button("Read the other \(c.of - c.read) now") { Task { await live.aiPass() } }.disabled(live.running)
                        }
                    }
                    if live.aiMode != "off" && live.aiMode != "claude" {
                        Picker("Double-check the rules", selection: Binding(get: { live.checkMode }, set: { live.checkMode = $0 })) {
                            Text("Every email").tag("all")
                            Text("One in five").tag("some")
                            Text("Off").tag("off")
                        }
                        Button("Run \(live.aiName) now") { Task { await live.aiPass() } }.disabled(live.running || !live.aiReady)
                        Button("Read everything again with \(live.aiName)") { Task { await live.rereadWithCurrentReader() } }.disabled(live.running || !live.aiReady)
                    }
                } header: { SettingsHeader(live.aiMode == "claude" ? "Who reads your mail" : "What the rules can’t read") } footer: {
                    Text(live.aiMode == "claude" ? "Smart reading sends each money email to an AI, masked on this phone first: your and your family’s names become Name1, Name2…, long numbers keep their last four digits, personal email addresses and PANs are blanked. One-time passwords and security mail never leave the phone. Every amount it names is checked against the email before it counts. About ₹10 for every thousand emails, billed to your AI key (or kosh’s service, on Plus)."
                         : live.aiMode == "apple" ? "Read on this phone with the model built into iOS, checked against each email the same way as kosh-reader. Free; nothing leaves the phone." + (AppleBrain.available ? "" : " " + AppleBrain.unavailableReason + (KoshReader.available ? " Until then kosh-reader reads." : ""))
                         : live.aiMode == "reader" ? "A small model trained on money mail, running on this phone. Free; nothing leaves the phone." + (AppleBrain.available ? "" : " " + AppleBrain.unavailableReason)
                         : "Only the bank rules read your mail.")
                }
                Section {
                    Picker("Show spending from", selection: Binding(get: { live.ledgerFrom }, set: { live.ledgerFrom = $0 })) {
                        let opts: [(String, String)] = LedgerChoice.options(current: live.ledgerFrom)
                        ForEach(opts.indices, id: \.self) { i in Text(opts[i].1).tag(opts[i].0) }
                    }
                } header: { SettingsHeader("Your ledger") } footer: {
                    Text("How much spending shows in Transactions, Insights and Home. kosh reads the whole year either way: policies, statements, balances and what repeats.")
                }
                // (statements and their passwords: Settings › Statements and papers; the reading check: Settings ›
                // Help and diagnostics, with the other tools that look under the hood)
            }
            .settingsPage("Reading")
        }
    }
}

/// Help and diagnostics: the intro, notes, the reading check, exports and the sign-in IDs, every beta tool in one
/// place (erase lives in Privacy and security, as EraseSection)
struct BetaSettings: View {
    @Environment(Store.self) private var store
    /// plays a walkthrough after Settings closes (nil: no intro row)
    var show: ((Showcase) -> Void)? = nil
    @State private var client = ""
    @State private var msID = ""
    @State private var book = FeedbackBook.shared
    /// (the diagnostics' close look at where a tab switch spends its time: off unless asked, since looking costs a little)
    @AppStorage(Perf.lookKey) private var lookClosely = false
    var exportURL: URL? { store.live?.exportForClaude() }
    var body: some View {
        if let live = store.live {
            List {
                if let show {
                    Section {
                        Button { show(.intro) } label: { SettingsRow(symbol: "sparkles.rectangle.stack", color: Color.kosh, title: "Play the intro") }
                            .buttonStyle(.press)
                    } header: { SettingsHeader("Show kosh to someone") }
                }
                Section {
                    NavigationLink { ParserCheckView() } label: {
                        SettingsRow(symbol: "checkmark.seal.fill", color: Color(hex: "#34C759"), title: "Reading check",
                                    value: live.openDiffers + live.waitingCount > 0 ? String(live.openDiffers + live.waitingCount) : "",
                                    alert: live.openDiffers + live.waitingCount > 0)
                    }
                } footer: {
                    Text("Emails the rules and the reader read differently, and the ones still waiting to be read.")
                }
                Section {
                    NavigationLink { FeedbackListView() } label: {
                        SettingsRow(symbol: "bubble.left.and.text.bubble.right.fill", color: Color(hex: "#007AFF"), title: "Feedback notes", value: String(book.notes.count))
                    }
                    Button { FeedbackPresenter.shared.show(screen: "Settings") } label: {
                        SettingsRow(symbol: "square.and.pencil", color: Color(hex: "#5E5CE6"), title: "Write a note now")
                    }
                    .buttonStyle(.press)
                    if let url = exportURL {
                        ShareLink(item: url) { SettingsRow(symbol: "square.and.arrow.up.fill", color: Color(hex: "#30B0C7"), title: "Export diagnostics") }
                    }
                    Toggle(isOn: $lookClosely) { SettingsRow(symbol: "stopwatch.fill", color: Color(hex: "#FF9500"), title: "Look closely at slow taps") }
                    TrainingExportRow(live: live)
                } footer: {
                    Text("Shake the phone on any screen to write a note. The export is a diagnostics file with long numbers cut.")
                }
                Section {
                    TextField("…apps.googleusercontent.com", text: $client).textInputAutocapitalization(.never).autocorrectionDisabled().font(.footnote).onSubmit { live.setClientID(client) }
                    Button("Save client ID") { live.setClientID(client) }.disabled(client.isEmpty || client == live.clientID)
                } header: { SettingsHeader("Google client ID") }
                .onAppear { client = live.clientID; msID = live.msClientID }
                Section {
                    TextField("Application (client) ID", text: $msID).textInputAutocapitalization(.never).autocorrectionDisabled().font(.footnote).onSubmit { live.setMSClientID(msID) }
                    Button("Save Microsoft app ID") { live.setMSClientID(msID) }.disabled(msID == live.msClientID)
                } header: { SettingsHeader("Microsoft app ID (Outlook)") }
            }
            .settingsPage("Help and diagnostics")
        }
    }
}

/// Erase kosh beta: its own section, at the foot of Privacy and security (moved from Beta, 28 Oct; unchanged)
struct EraseSection: View {
    @Environment(Store.self) private var store
    @State private var confirmErase = false
    var body: some View {
        Section {
            Button("Erase kosh beta", role: .destructive) { confirmErase = true }
        } footer: {
            Text("Ends kosh’s access to your Gmail at Google, removes the AI key and deletes everything kosh read or you added: the ledger, statements, budgets, plans, saved decisions and your feedback notes. The look, the lock and Hide amounts stay as they are.")
        }
        .confirmationDialog("Erase everything kosh beta read?", isPresented: $confirmErase, titleVisibility: .visible) {
            Button("Erase", role: .destructive) { store.erase() }
        } message: {
            Text("Everything read from your mail, everything you added and your feedback notes go from this phone. This can’t be undone.")
        }
    }
}


/// where the ledger can start: this month, last month, three, six or twelve months back, or everything read
enum LedgerChoice {
    static func options(current: String) -> [(String, String)] {
        var out: [(String, String)] = [
            (LiveSession.monthStart(back: 0), "This month"),
            (LiveSession.monthStart(back: 1), "Last month"),
            (LiveSession.monthStart(back: 3), "3 months back"),
            (LiveSession.monthStart(back: 6), "6 months back"),
            ("", "Everything kosh read"),
        ]
        if !current.isEmpty && !out.contains(where: { $0.0 == current }) {
            out.insert((current, Day.fmt(current, "d MMM yyyy")), at: 0)
        }
        return out
    }
}
