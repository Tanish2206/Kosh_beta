import Foundation
import Observation
import UIKit
import Network

// MARK: - LiveSession: reading the mail: the scan, reading what's new, the searches, the year's backfill, counts
// (split out of LiveSession.swift, 17 Oct 2026; its stored state stays in the class there). The rest of reading, split
// out 30 Oct 2026: LiveSession+Sweep (each inbox's window), +Ingest (one email into a Reading), +Reread (when the rules
// change), +AIPass (kosh-reader, Apple, Claude), +Downloads (the background downloads).

extension LiveSession {
    // MARK: the scan: list the money mail, read each email once, keep what it says

    var running: Bool { phase == .listing || phase == .reading || phase == .claude }

    /// A new inbox is read in the order that gets you going soonest. First a look at who writes to it (discover:
    /// a quick search per bank, card, wallet, insurer and broker, and their newest few mails, in seconds); then
    /// the last week, which is what setup waits on; then the year's statements and policies are found (so Insurance
    /// and Portfolio fill in); then the last three months' mail, newest first, so Home stands on a quarter within
    /// minutes; then the statements are opened, newest first (balances, holdings, policies, and every month's lines);
    /// then the rest of the year's mail month by month, newest first, in the background while you use kosh; Gmail's
    /// Promotions tab last; then the reader, on what the rules couldn't read. Later reads only fetch what's new since
    /// the last one. A read that was cut short carries on from the email it got to. Until the year is in, the engine
    /// is told how far back the reading has got (profile readFrom), and holds back the notes that need months of
    /// history ("salary late", "a usual month", a repeat not seen) until a few months are read.
    static let firstDays = 7
    /// the first stretch read after the week: about three months, newest first
    static let recentDays = 90

    /// the whole year is read (the reading reached a year back): Home's history-based notes can speak. (backfillDone
    /// lives only as long as kosh runs; how far scanFrom reaches says the same after a relaunch.)
    var yearIn: Bool { backfillDone || (scanFrom.count == 10 && scanFrom <= Self.daysAgo(365)) }
    /// the last three months are read
    var recentIn: Bool { yearIn || (scanFrom.count == 10 && scanFrom <= Self.daysAgo(Self.recentDays)) }

    @MainActor

    func scan(days: Int? = nil) async {
        if running { return }
        KeepGoing.shared.begin("Reading new mail")
        defer { KeepGoing.shared.end() }
        let fresh = records.isEmpty || scanFrom.isEmpty
        if fresh {
            firstLook = false
            if !ud.bool(forKey: "beta.discovered") { await discover() }
            firstLook = true
        }
        if halted { return }
        guard await readNew(days: days, first: fresh ? min(days ?? Self.firstDays, Self.firstDays) : nil) else { return }
        phase = .done
        // the year's statements and policies are found next, so Insurance and Portfolio fill in during setup; then the
        // last three months, so Home has a quarter to stand on; then the statements are opened and the months behind
        // have their lines; then the rest of the year's mail. Each stops if kosh's time is up.
        if halted { return }
        // (once a day: a statement that lands is opened the day it comes)
        if fresh || Self.daysSince(ud.string(forKey: "beta.lastDocSearch") ?? "") >= 1 { await findStatements() }
        if halted { return }
        if !recentIn { await backfill(back: Self.recentDays) }
        if halted { return }
        await readDocuments()
        if halted { return }
        await findWallets()
        if halted { return }
        await findWider()
        if halted { return }
        if !backfillDone { await backfill() }
        if halted { return }
        await readDocuments()
        if halted { return }
        await readPromotions()
        if halted { return }
        if backfillDone { await findOlderStatements() }
        if halted { return }
        if aiReady { await aiPass() }
    }

    /// Once the year is read: the two years before it, statements only (bank, card, fund, broker, tax and policy
    /// papers), so gains, returns and the patterns behind them have their history. Locked ones open like the rest.
    @MainActor

    func findOlderStatements() async {
        let version = 1
        guard !findingDocs, signedIn, ud.integer(forKey: "beta.olderDocs") < version else { return }
        findingDocs = true
        let after = Self.daysAgo(3 * 365), before = Self.daysAgo(395)
        var qs = (try? JSONText.decode([String].self, try Engine.shared.call("docQueriesJSON", [after]))) ?? [Self.statementQuery(after)]
        if qs.isEmpty { qs = [Self.statementQuery(after)] }
        if let w = plan("older")?.windows.first, let pq = w.queries, !pq.isEmpty { qs = pq }
        let done = await sweep(after: after, before: before, quiet: true, queries: qs, job: "older")
        findingDocs = false
        guard done else { return }
        ud.set(version, forKey: "beta.olderDocs")
        await readDocuments()
    }

    /// kosh's time is up (KeepGoing): what's under way winds down and saves, nothing new starts
    @MainActor

    var halted: Bool { KeepGoing.shared.stopped }

    /// new mail since the last read (or the first `first` days, then `days`), and nothing after it; false if it
    /// failed or was stopped. Where each Gmail inbox's history stood before the listing is kept with it, so the next
    /// quick look can ask Gmail whether anything came in at all before listing (historyGate).
    @MainActor

    func readNew(days: Int? = nil, first: Int? = nil) async -> Bool {
        if let days { scanDays = days }
        scanStarted = Date()
        let fresh = records.isEmpty || scanFrom.isEmpty
        if yearMonths.isEmpty { planYear() }
        let marks = await historyMarks()
        var from: String = {
            if fresh { return Self.daysAgo(first ?? scanDays) }
            // since the last read, with two days' overlap for mail that arrives late
            let last = String(lastScan.prefix(10))
            return last.count == 10 ? Self.shift(last, days: -2) : Self.daysAgo(scanDays)
        }()
        // a read that was cut short carries on with the same window (unless you asked for a different span)
        if let w = plan("scan")?.windows.first, days == nil || w.after == from { from = w.after }
        // within a day of a full read, Gmail's change log says exactly which mail came since the last read (each
        // inbox's own mark); once a day, and whenever a mark is too old, every search runs again as a safety net
        var since: [String: String] = [:]
        let lastFull = ud.string(forKey: "beta.fullRead") ?? ""
        if !fresh, days == nil, lastFull.count >= 10, lastFull >= Self.daysAgo(1) {
            for acct in allAccounts where isGmail(acct) { if let m = ud.string(forKey: "beta.history." + acct), !m.isEmpty { since[acct] = m } }
        }
        byChangeLogFellBack = false
        guard await sweep(after: from, before: nil, job: "scan", since: since) else { return false }
        if since.isEmpty || byChangeLogFellBack { ud.set(Self.today, forKey: "beta.fullRead") }
        markRead(after: from)
        for (acct, id) in marks { ud.set(id, forKey: "beta.history." + acct) }
        return true
    }

    /// each Gmail inbox's history id now (a unit of its allowance each)
    @MainActor

    func historyMarks() async -> [String: String] {
        var out: [String: String] = [:]
        for acct in allAccounts where isGmail(acct) {
            guard let tok = try? await token(acct) else { continue }
            if let id = try? await QuotaGate.$inbox.withValue(acct, operation: { try await Gmail.historyID(token: tok) }), !id.isEmpty { out[acct] = id }
        }
        return out
    }

    /// Before a quick look lists anything: has any mail come in since the last read, in any inbox? Gmail's history
    /// answers for two units of its allowance where listing costs a hundred. False only when every inbox is Gmail
    /// and every one says nothing came; any doubt (an old mark, another kind of inbox) means look.
    @MainActor

    func anythingNew() async -> Bool {
        for acct in allAccounts {
            guard isGmail(acct), let mark = ud.string(forKey: "beta.history." + acct), !mark.isEmpty, let tok = try? await token(acct) else { return true }
            let said = try? await QuotaGate.$inbox.withValue(acct, operation: { try await Gmail.anythingSince(mark, token: tok) })
            if said != false { return true }
        }
        return false
    }

    /// a short read of new mail and nothing after it: the refresh iOS runs every few hours
    @MainActor

    func quickRead() async {
        guard signedIn, !running, !scanFrom.isEmpty else { return }
        KeepGoing.shared.begin("Reading new mail")
        defer { KeepGoing.shared.end() }
        // nothing came in anywhere since the last read: nothing to list
        guard await anythingNew() else { phase = .done; return }
        if await readNew() { phase = .done }
    }

    /// Pull down on Home or Transactions: new mail since the last read, and nothing after it. A read already
    /// under way is waited on instead (up to half a minute), so the spinner stays until there's something new.
    /// The read runs on its own, so letting go of the screen mid-read doesn't cut it short.
    @MainActor

    func pullRefresh() async {
        // the day's prices too, beside the mail
        let prices = Task { @MainActor in await self.refreshPrices(pulled: true) }
        if running {
            var waited = 0
            while running && waited < 60 { try? await Task.sleep(for: .milliseconds(500)); waited += 1 }
            await prices.value
            return
        }
        let read = Task { @MainActor in await self.quickRead() }
        await read.value
        await prices.value
    }

    /// funds and shares at the day's prices (Prices.swift): fetched at most once a day, or on a pull; the screens
    /// are laid out again only when a price changed
    @MainActor

    func refreshPrices(pulled: Bool = false) async {
        guard loadedFromDisk else { return }
        let held: [UserHolding] = userHoldings + docHoldings + madeHoldings
        let want: [Prices.Want] = Prices.wants(held)
        if !want.isEmpty, await Prices.shared.refresh(want, pulled: pulled) { rebuildSoon() }
        // the day's rupee rate for what's held in dollars (and other FCNR currencies), once a day
        // (only for a household that holds something in another currency: no one else's phone asks)
        recordsLock.lock(); let holdsForeign: Bool = lastBuild?.contains("\"ccy\":\"") ?? false; recordsLock.unlock()
        if holdsForeign || !FXRates.shared.isEmpty, await FXRates.shared.refresh(pulled: pulled) { rebuildSoon() }
        // what Regular plans cost against Direct: AMFI's fee lists for the fund houses held, weekly (Brief.swift)
        let funds: [String] = held.filter { $0.cls == "mf" }.map(\.bank)
        if await FundFees.shared.refresh(funds) { rebuildSoon() }
    }

    /// What was cut short last time carries on first, from the email it got to, before anything new is read:
    /// the mail read again with new rules, the read of new mail (and what follows it), statements, wallets,
    /// an added inbox, the documents, the year, the reader.
    @MainActor

    func resumeReading() async {
        guard loadedFromDisk, signedIn, !resuming, hasPlans else { return }
        resuming = true
        defer { resuming = false }
        KeepGoing.shared.begin("Picking up where it stopped")
        defer { KeepGoing.shared.end() }
        let order = ["reingest", "scan", "statements", "wallets", "wider", "inbox:", "docs", "backfill", "promos", "older", "reader"]
        func rank(_ job: String) -> Int { order.firstIndex { job == $0 || ($0 == "inbox:" && job.hasPrefix($0)) } ?? order.count }
        for job in plans.keys.sorted(by: { rank($0) < rank($1) }) {
            if halted { break }
            guard plan(job) != nil else { continue }
            switch job {
            case "reingest": await reingestIfRulesChanged()
            case "scan": await scan()
            case "statements": await findStatements()
            case "wallets": await findWallets()
            case "wider": await findWider()
            case "docs": await readDocuments()
            case "backfill":
                // the last three months first (a first read cut short there), then the statements found meanwhile are
                // opened, then the rest of the year
                if !recentIn {
                    await backfill(back: Self.recentDays)
                    if halted { break }
                    await readDocuments()
                    if halted { break }
                }
                await backfill()
            case "promos": await readPromotions()
            case "older": await findOlderStatements()
            case "reader":
                if aiReady && (aiMode == "reader" || aiMode == "apple") { await readerPass() } else { plans[job] = nil }
            default:
                let addr = String(job.dropFirst("inbox:".count))
                if job.hasPrefix("inbox:") && accounts.contains(where: { $0.id == addr }) { await readInbox(addr) } else { plans[job] = nil }
            }
        }
        writePlans()
    }

    @MainActor

    func findStatements() async {
        guard !findingDocs, signedIn else { return }
        findingDocs = true
        defer { findingDocs = false }
        // the first time, the whole year; after that, since the last look (with a few days' overlap)
        let last = ud.string(forKey: "beta.lastDocSearch") ?? ""
        var after = last.count == 10 ? Self.shift(last, days: -5) : Self.daysAgo(400)
        // by what the papers are called, and by who sends them (engine docQueries)
        var qs = (try? JSONText.decode([String].self, try Engine.shared.call("docQueriesJSON", [after]))) ?? [Self.statementQuery(after)]
        if qs.isEmpty { qs = [Self.statementQuery(after)] }
        // a search that was cut short carries on with the same one
        if let w = plan("statements")?.windows.first, let pq = w.queries, !pq.isEmpty { after = w.after; qs = pq }
        if await sweep(after: after, before: nil, quiet: true, queries: qs, job: "statements") { ud.set(Self.today, forKey: "beta.lastDocSearch") }
    }

    @MainActor

    func readPromotions() async {
        guard !readingPromos, signedIn, !scanFrom.isEmpty else { return }
        readingPromos = true
        defer { readingPromos = false }
        let last = ud.string(forKey: "beta.promoFrom") ?? ""
        var after = last.count == 10 ? Self.shift(last, days: -2) : max(scanFrom, Self.daysAgo(400))
        var qs = (try? JSONText.decode([String].self, try Engine.shared.call("promoQueriesJSON", [after]))) ?? []
        if let w = plan("promos")?.windows.first, let pq = w.queries, !pq.isEmpty { after = w.after; qs = pq }
        guard !qs.isEmpty else { return }
        if await sweep(after: after, before: nil, quiet: true, queries: qs, job: "promos") { ud.set(Self.today, forKey: "beta.promoFrom") }
    }

    /// Setup's first look, in seconds: which money senders write to each Gmail inbox (one small search each,
    /// a quarter of a read), and their newest few mails, read at once, so setup can show the banks, cards,
    /// wallets, insurers and brokers before anything else is read.
    struct Found: Codable, Identifiable, Hashable { var id: String; var name: String; var short: String; var kind: String; var mails: Int }

    struct DiscoverQuery: Decodable { let id: String; let name: String; let short: String; let kind: String; let take: Int; let q: String }

    @MainActor

    func discover() async {
        guard signedIn, !discovering else { return }
        let inboxes = allAccounts.filter { isGmail($0) }
        guard !inboxes.isEmpty, let qs = try? JSONText.decode([DiscoverQuery].self, try Engine.shared.call("discoverQueriesJSON", [Self.daysAgo(400)])), !qs.isEmpty else { return }
        discovering = true
        defer { discovering = false }
        stretchSeen = true
        discoverTotal = qs.count * inboxes.count
        discoverDone = 0
        var found: [String: Found] = [:]
        let known = knownIDs
        for acct in inboxes {
            guard let tok = try? await token(acct) else { continue }
            let tag = inboxTag(acct)
            var picks: [String] = []
            var i = 0
            while i < qs.count {
                if halted { return }
                if !Net.shared.online { guard await Net.shared.waitOnline() else { return } }
                let slice = Array(qs[i..<min(i + 12, qs.count)])
                // a dozen searches at a time; the allowance paces them
                let res: [(DiscoverQuery, [String], Int)] = await withTaskGroup(of: (DiscoverQuery, [String], Int)?.self) { g in
                    for q in slice {
                        g.addTask {
                            guard let r = try? await QuotaGate.$inbox.withValue(acct, operation: { try await LiveSession.retrying(3) { try await Gmail.peek(query: q.q, take: q.take, token: tok) } }) else { return nil }
                            return (q, r.ids, r.estimate)
                        }
                    }
                    var out: [(DiscoverQuery, [String], Int)] = []
                    for await r in g { if let r { out.append(r) } }
                    return out
                }
                discoverDone += slice.count
                for (q, ids, n) in res where !ids.isEmpty {
                    var f = found[q.id] ?? Found(id: q.id, name: q.name, short: q.short, kind: q.kind, mails: 0)
                    f.mails += n
                    found[q.id] = f
                    picks += ids.filter { !known.contains(tag + $0) }
                }
                discovered = found.values.sorted { $0.mails > $1.mails }
                i += slice.count
            }
            // the newest few from each sender, read now: they name the accounts and cards
            var left = picks
            while !left.isEmpty {
                if halted { return }
                let chunk = Array(left.prefix(15))
                left.removeFirst(chunk.count)
                guard let msgs = try? await fetchMessages(chunk, acct: acct) else { continue }
                for m in msgs { ingest(m, acct: acct, tag: tag) }
                rebuildSoon()
            }
        }
        ud.set(true, forKey: "beta.discovered")
        save()
        rebuildSoon()
    }

    static func statementQuery(_ after: String) -> String {
        "has:attachment filename:pdf after:" + after.replacingOccurrences(of: "-", with: "/")
            + " {policy insurance premium renewal \"sum insured\" \"policy schedule\" \"account statement\" \"card statement\" \"credit card statement\" \"e-statement\" \"statement of account\" \"monthly statement\" CAS NSDL CDSL CAMS KFintech demat \"mutual fund\" \"contract note\"}"
    }

    @MainActor

    func findWallets() async {
        guard !findingWallets, signedIn, !scanFrom.isEmpty else { return }
        let version = (try? Engine.shared.call("directoryVersion", [])) ?? ""
        guard !version.isEmpty, ud.string(forKey: "beta.walletDir") != version else { return }
        findingWallets = true
        defer { findingWallets = false }
        var after = max(scanFrom, Self.daysAgo(400))
        var qs = (try? JSONText.decode([String].self, try Engine.shared.call("walletQueriesJSON", [after]))) ?? []
        // a read that was cut short carries on with the same searches
        if let w = plan("wallets")?.windows.first, let pq = w.queries, !pq.isEmpty { after = w.after; qs = pq }
        guard !qs.isEmpty else { return }
        if await sweep(after: after, before: nil, quiet: true, queries: qs, job: "wallets") { ud.set(version, forKey: "beta.walletDir") }
    }

    /// Once each time kosh's searches widen (a new version of the engine's queries: more banks, card issuers,
    /// registrars, lenders, and money words rather than a short list of subjects): the mail they now match, from as
    /// far back as the rest was read, so what the earlier searches missed is read without anything being read twice.
    /// 4 (27 Oct): couriers' own mail and parcel shops' delivery and pickup mail, by sender with a parcel's words in the
    /// subject (engine/00 parcelQueries), for the assistant's pickups and deliveries
    /// 5 (1 Nov): any shop's own order confirmation ("Order #774064 confirmed", "Thank you for your order"), so a small
    /// store's items are read and the card charge they match says what was bought (engine › whatWasBought)
    /// 6 (1 Nov): "Ordered: …" and receipts Gmail filed under Promotions, from senders kosh reads (engine › gmailQueries)
    static let queriesVersion = 6

    @MainActor

    func findWider() async {
        guard !findingWider, signedIn, !scanFrom.isEmpty, ud.integer(forKey: "beta.queries") < Self.queriesVersion else { return }
        findingWider = true
        defer { findingWider = false }
        var after = max(scanFrom, Self.daysAgo(400))
        var qs = (try? JSONText.decode([String].self, try Engine.shared.call("queriesJSON", [after]))) ?? []
        if let w = plan("wider")?.windows.first, let pq = w.queries, !pq.isEmpty { after = w.after; qs = pq }
        guard !qs.isEmpty else { return }
        if await sweep(after: after, before: nil, quiet: true, queries: qs, job: "wider") { ud.set(Self.queriesVersion, forKey: "beta.queries") }
    }

    @MainActor

    func lookAgain(for name: String) async -> Int {
        let n = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard signedIn, !n.isEmpty, lookingFor == nil else { return 0 }
        let after = max(scanFrom.isEmpty ? Self.daysAgo(400) : scanFrom, Self.daysAgo(400))
        guard let qs = try? JSONText.decode([String].self, try Engine.shared.call("missingQueriesJSON", [n, after])), !qs.isEmpty else { return 0 }
        lookingFor = n
        defer { lookingFor = nil }
        KeepGoing.shared.begin("Looking for " + n)
        defer { KeepGoing.shared.end() }
        let before = records.count
        _ = await sweep(after: after, before: nil, quiet: true, queries: qs, job: "missing")
        plans["missing"] = nil
        writePlans()
        rebuildSoon()
        return records.count - before
    }

    /// a quiet read of new mail when kosh comes back to the front, if the last one was a while ago
    @MainActor

    func refreshIfStale(hours: Double = 4) async {
        await refreshGold()
        await LearnedRules.refreshShared()
        if docHoldings.contains(where: { $0.cls == "stk" }) { Task.detached(priority: .utility) { await CompanySites.shared.refreshIfStale() } }
        // the day's NAVs and closes, beside the mail rather than before it
        Task { @MainActor [weak self] in await self?.refreshPrices() }
        guard signedIn, !running, !backfilling, !scanFrom.isEmpty else { return }
        let f = ISO8601DateFormatter()
        if let last = f.date(from: lastScan), Date().timeIntervalSince(last) < hours * 3600 {
            // statements waiting to be read (a better reader, a password just given) don't wait for new mail
            if records.contains(where: { $0.doc?.state.isEmpty == true }) || localDocs.contains(where: { $0.state.isEmpty }) { await readDocuments() }
            return
        }
        await scan()
    }

    /// Read the months before the quick pass, newest first, one month at a time, in the background. Every month
    /// still to read is listed first (three at a time), so the bar knows how many emails the year is; then each
    /// is read, and marked read (and scanFrom moved back) as it finishes. `back` is how far, in days: the year
    /// (365), or the first stretch (recentDays), which stops once the reading reaches it and leaves a plan listed
    /// for the whole year (an older run's) with its months still to read, for the next call to carry on.
    @MainActor

    func backfill(back: Int = 365) async {
        guard !backfilling, signedIn, scanFrom.count == 10 else { return }
        let whole: Bool = back >= 365
        let target: String = Self.daysAgo(whole ? 365 : back)
        guard target < scanFrom else {
            if whole {
                backfillDone = true
                if plans["backfill"] != nil { plans["backfill"] = nil; writePlans() }
            }
            return
        }
        if yearMonths.isEmpty { planYear() }
        KeepGoing.shared.begin(whole ? "Filling in the year" : "Reading the last three months")
        defer { KeepGoing.shared.end() }
        backfilling = true
        stretchSeen = true
        defer { backfilling = false; bgMonth = ""; yearListing = false }
        var first = true
        while target < scanFrom {
            // a plan from before carries on if it starts where the reading got to; otherwise what's left of the
            // year is listed (again, if the plan went: an inbox added meanwhile, say)
            if first, let p = plan("backfill"), p.windows.isEmpty || p.windows.first.flatMap({ $0.before }) == scanFrom {
                pickUp("backfill")
            } else {
                guard await planBackfill(from: scanFrom, to: target) else {
                    if halted { interrupted.insert("backfill") }
                    return
                }
            }
            first = false
            yearTotal = plans["backfill"]?.total ?? 0
            yearDone = plans["backfill"]?.done ?? 0
            // (newest first: a plan listed for the whole year stops here once the first stretch is read)
            while target < scanFrom, let w = plans["backfill"]?.windows.first {
                bgMonth = String(w.after.prefix(7))
                let ok = await sweep(after: w.after, before: w.before, quiet: true, job: "backfill")
                if !ok { return }
                monthsRead.insert(String(w.after.prefix(7)))
                if w.after <= scanFrom { scanFrom = w.after }
                // the month, where the year now starts and what's left of it, saved together
                checkpoint(force: true)
                if halted { cutShort("backfill"); return }
                if UIApplication.shared.applicationState == .background && !KeepGoing.shared.carrying { try? await Task.sleep(for: .seconds(1)) }
            }
        }
        if !whole {
            // the first stretch is in: its plan goes once every window is read (a year's plan keeps the months left)
            if plans["backfill"]?.windows.isEmpty == true { plans["backfill"] = nil }
            save(); writePlans(); rebuildSoon()
            return
        }
        backfillDone = true
        monthsRead.formUnion(yearMonths)
        plans["backfill"] = nil
        save(); writePlans(); rebuildSoon()
    }

    /// every month from `from` back to `target`, listed into the year's plan three at a time; false if kosh
    /// was stopped or an inbox couldn't be listed (nothing is kept, and it's listed again next time)
    @MainActor

    func planBackfill(from: String, to target: String) async -> Bool {
        var months: [(after: String, before: String)] = []
        var before = from
        while before > target {
            // the month that ends where the last read began
            let monthStart = String(before.prefix(7)) + "-01"
            let after = max(monthStart == before ? Self.shift(monthStart, months: -1) : monthStart, target)
            months.append((after, before))
            before = after
        }
        yearListing = true
        yearTotal = 0
        yearDone = 0
        defer { yearListing = false }
        let known = knownIDs
        var p = ReadingPlan(job: "backfill", accounts: allAccounts)
        var start = 0
        while start < months.count {
            if halted { return false }
            if !Net.shared.online { guard await Net.shared.waitOnline() else { return false } }
            let slice = Array(months[start..<min(start + 3, months.count)])
            let listed: [MailWindow?] = await withTaskGroup(of: (Int, MailWindow?).self) { g in
                for (n, m) in slice.enumerated() {
                    g.addTask { (n, await self.listWindow(after: m.after, before: m.before, only: nil, queries: nil, known: known)) }
                }
                var out = [MailWindow?](repeating: nil, count: slice.count)
                for await r in g { out[r.0] = r.1 }
                return out
            }
            for w in listed {
                guard let w, w.failed == nil else { return false }
                p.windows.append(w)
                p.total += w.total
            }
            yearTotal = p.total
            start += slice.count
        }
        plans["backfill"] = p
        writePlans()
        return true
    }

    /// the twelve months the scan covers, oldest first
    func planYear() {
        var out: [String] = []
        var m = String(Self.today.prefix(7))
        for _ in 0..<12 { out.insert(m, at: 0); m = String(Self.shift(m + "-01", months: -1).prefix(7)) }
        yearMonths = out
        // anything already read before this build counts
        if !scanFrom.isEmpty { for x in out where x >= String(scanFrom.prefix(7)) { monthsRead.insert(x) } }
    }

    func markRead(after: String) {
        for x in yearMonths where x >= String(after.prefix(7)) { monthsRead.insert(x) }
    }

    static func shift(_ isoDay: String, days: Int = 0, months: Int = 0) -> String {
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX"); f.timeZone = TimeZone(identifier: "Asia/Kolkata"); f.dateFormat = "yyyy-MM-dd"
        guard let d = f.date(from: String(isoDay.prefix(10))) else { return isoDay }
        var c = DateComponents(); c.day = days; c.month = months
        return f.string(from: Calendar.current.date(byAdding: c, to: d) ?? d)
    }

    /// seconds left on the visible read, from how fast it has gone since it started (or picked up)
    var secondsLeft: Int? {
        guard phase == .reading, let started = scanStarted, fetched - rateBase > 10, total > fetched else { return nil }
        let rate = Double(fetched - rateBase) / max(1, Date().timeIntervalSince(started))
        return Int((Double(total - fetched) / max(rate, 0.5)).rounded())
    }

    // MARK: counts, for the scan screen and Settings

    var readCount: Int { records.count }

    var ruleCount: Int { records.count(where: { $0.src == "rule" && $0.kind != "noise" && $0.kind != "unknown" }) }

    var noiseCount: Int { records.count(where: { $0.kind == "noise" }) }

    var waitingCount: Int { records.count(where: { $0.kind == "unknown" && $0.use == nil }) }

    var claudeRead: Int { records.count(where: { $0.use == "claude" }) }

    var agreeCount: Int { records.count(where: { $0.check?.status == "agree" }) }

    var differs: [Reading] { records.filter { $0.check?.status == "differ" } }

    var openDiffers: Int { records.count(where: { $0.check?.status == "differ" && $0.use == nil }) }

    var unread: [Reading] { records.filter { $0.kind == "unknown" && $0.use == nil } }

    struct Coverage: Identifiable { let inst: String; let rules: Int; let missed: Int; var id: String { inst } }

    /// per sender: how much the rules read, for feedback on coverage
    var coverage: [Coverage] {
        var t: [String: (Int, Int)] = [:]
        for r in records where r.kind != "noise" {
            let k = (r.inst ?? "").isEmpty ? (r.from?.split(separator: "@").last.map(String.init) ?? "other") : r.inst!
            var x = t[k] ?? (0, 0)
            if r.kind == "unknown" { x.1 += 1 } else if r.src == "rule" { x.0 += 1 }
            t[k] = x
        }
        return t.map { Coverage(inst: $0.key, rules: $0.value.0, missed: $0.value.1) }.sorted { $0.rules + $0.missed > $1.rules + $1.missed }
    }
}
