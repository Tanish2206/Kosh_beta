import SwiftUI

// MARK: - Money threads
//
// The journey the mail tells, joined up (journey.js, from what the reader read in each mail): a card's statement
// and the payment that cleared it, a bill and what paid it, an order from placed to charged to refunded, a policy's
// premiums and its next due, a deposit from opened to matured, an IPO, a fund's purchases, a subscription's
// charges. Home shows what needs a look and what's coming; the sheet has every thread, each with its steps.

/// one step of a thread: a mail's event, dated
struct ThreadStep: Decodable, Hashable {
    var d: String = ""
    var t: String = ""
    var amt: Double? = nil
    var min: Double? = nil
    var due: String? = nil
    var by: String? = nil
    var how: String? = nil
    var units: Double? = nil
    var nav: Double? = nil
    var qty: Double? = nil
    var shares: Double? = nil
    var mail: String? = nil
    /// the words in the mail this step was read from
    var q: String? = nil
    enum K: String, CodingKey { case d, t, amt, min, due, by, how, units, nav, qty, shares, mail, q }
    init(from dec: Decoder) throws {
        let c = try dec.container(keyedBy: K.self)
        d = (try? c.decodeIfPresent(String.self, forKey: .d)) ?? ""
        t = (try? c.decodeIfPresent(String.self, forKey: .t)) ?? ""
        amt = try? c.decodeIfPresent(Double.self, forKey: .amt)
        min = try? c.decodeIfPresent(Double.self, forKey: .min)
        due = try? c.decodeIfPresent(String.self, forKey: .due)
        by = try? c.decodeIfPresent(String.self, forKey: .by)
        how = try? c.decodeIfPresent(String.self, forKey: .how)
        units = try? c.decodeIfPresent(Double.self, forKey: .units)
        nav = try? c.decodeIfPresent(Double.self, forKey: .nav)
        qty = try? c.decodeIfPresent(Double.self, forKey: .qty)
        shares = try? c.decodeIfPresent(Double.self, forKey: .shares)
        mail = try? c.decodeIfPresent(String.self, forKey: .mail)
        q = try? c.decodeIfPresent(String.self, forKey: .q)
    }
}

/// a card statement's cycle, or a bill: the steps that belong to it and where it stands
struct ThreadGroup: Decodable, Hashable {
    var head: String = ""
    var total: Double? = nil
    var min: Double? = nil
    var due: String = ""
    var paid: Double? = nil
    var status: String = ""
    var early: Int? = nil
    var steps: [ThreadStep] = []
    enum K: String, CodingKey { case stmt, total, amt, min, due, paid, status, early, steps }
    init(from dec: Decoder) throws {
        let c = try dec.container(keyedBy: K.self)
        head = (try? c.decodeIfPresent(String.self, forKey: .stmt)) ?? ""
        total = (try? c.decodeIfPresent(Double.self, forKey: .total)) ?? (try? c.decodeIfPresent(Double.self, forKey: .amt)) ?? nil
        min = try? c.decodeIfPresent(Double.self, forKey: .min)
        due = (try? c.decodeIfPresent(String.self, forKey: .due)) ?? ""
        paid = try? c.decodeIfPresent(Double.self, forKey: .paid)
        status = (try? c.decodeIfPresent(String.self, forKey: .status)) ?? ""
        early = try? c.decodeIfPresent(Int.self, forKey: .early)
        steps = ThreadStep.list(c, .steps)
    }
}

struct ThreadNext: Decodable, Hashable {
    var d: String = ""
    var amt: Double? = nil
    var what: String = ""
    enum K: String, CodingKey { case d, amt, what }
    init(from dec: Decoder) throws {
        let c = try dec.container(keyedBy: K.self)
        d = (try? c.decodeIfPresent(String.self, forKey: .d)) ?? ""
        amt = try? c.decodeIfPresent(Double.self, forKey: .amt)
        what = (try? c.decodeIfPresent(String.self, forKey: .what)) ?? ""
    }
}

/// one thread. Every field is read leniently: a thread the app can't read is left out, never the screens
struct MoneyThread: Decodable, Identifiable, Hashable {
    var id: String = ""
    var kind: String = ""
    var title: String = ""
    var status: String = ""
    var last: String = ""
    var next: ThreadNext? = nil
    var steps: [ThreadStep] = []
    /// a card's statements, or a biller's bills
    var groups: [ThreadGroup] = []
    var onTime: Int = 0
    var late: Int = 0
    /// days before the due date it's usually paid
    var usualEarly: Int? = nil
    var total: Double? = nil
    var premium: Double? = nil
    var cover: Double? = nil
    var invested: Double? = nil
    var units: Double? = nil
    var rate: Double? = nil
    var price: Double? = nil
    var every: String? = nil
    var no: String? = nil
    enum K: String, CodingKey { case id, kind, title, status, last, next, steps, cycles, items, onTime, late, usualEarly, total, premium, cover, invested, units, rate, price, every, no, amt }
    init(from dec: Decoder) throws {
        let c = try dec.container(keyedBy: K.self)
        id = (try? c.decodeIfPresent(String.self, forKey: .id)) ?? ""
        kind = (try? c.decodeIfPresent(String.self, forKey: .kind)) ?? ""
        title = (try? c.decodeIfPresent(String.self, forKey: .title)) ?? ""
        status = (try? c.decodeIfPresent(String.self, forKey: .status)) ?? ""
        last = (try? c.decodeIfPresent(String.self, forKey: .last)) ?? ""
        next = (try? c.decodeIfPresent(ThreadNext.self, forKey: .next)) ?? nil
        steps = ThreadStep.list(c, .steps)
        let cycles: [ThreadGroup] = ((try? c.decodeIfPresent([Lenient<ThreadGroup>].self, forKey: .cycles)) ?? nil)?.compactMap(\.value) ?? []
        let items: [ThreadGroup] = ((try? c.decodeIfPresent([Lenient<ThreadGroup>].self, forKey: .items)) ?? nil)?.compactMap(\.value) ?? []
        groups = cycles + items
        onTime = (try? c.decodeIfPresent(Int.self, forKey: .onTime)) ?? 0
        late = (try? c.decodeIfPresent(Int.self, forKey: .late)) ?? 0
        usualEarly = try? c.decodeIfPresent(Int.self, forKey: .usualEarly)
        total = (try? c.decodeIfPresent(Double.self, forKey: .total)) ?? (try? c.decodeIfPresent(Double.self, forKey: .amt)) ?? nil
        premium = try? c.decodeIfPresent(Double.self, forKey: .premium)
        cover = try? c.decodeIfPresent(Double.self, forKey: .cover)
        invested = try? c.decodeIfPresent(Double.self, forKey: .invested)
        units = try? c.decodeIfPresent(Double.self, forKey: .units)
        rate = try? c.decodeIfPresent(Double.self, forKey: .rate)
        price = try? c.decodeIfPresent(Double.self, forKey: .price)
        every = try? c.decodeIfPresent(String.self, forKey: .every)
        no = try? c.decodeIfPresent(String.self, forKey: .no)
    }
}

/// what's coming and what's late, across threads
struct JourneyItem: Decodable, Hashable, Identifiable {
    var id: String = ""
    var kind: String = ""
    var title: String = ""
    var d: String = ""
    var amt: Double? = nil
    var what: String = ""
    var status: String = ""
    enum K: String, CodingKey { case id, kind, title, d, amt, what, status }
    init(from dec: Decoder) throws {
        let c = try dec.container(keyedBy: K.self)
        id = (try? c.decodeIfPresent(String.self, forKey: .id)) ?? ""
        kind = (try? c.decodeIfPresent(String.self, forKey: .kind)) ?? ""
        title = (try? c.decodeIfPresent(String.self, forKey: .title)) ?? ""
        d = (try? c.decodeIfPresent(String.self, forKey: .d)) ?? ""
        amt = try? c.decodeIfPresent(Double.self, forKey: .amt)
        what = (try? c.decodeIfPresent(String.self, forKey: .what)) ?? ""
        status = (try? c.decodeIfPresent(String.self, forKey: .status)) ?? ""
    }
}

/// the second witness (journey.js › checksOf): an account's balances checked against the payments between them,
/// payments told by two senders, and mails that disagree
struct BalanceGap: Decodable, Hashable, Identifiable {
    var acct: String = ""; var from: String = ""; var to: String = ""; var dir: String = ""; var amt: Double = 0
    var by: String = ""; var byText: String = ""
    var id: String { acct + from + to }
    enum K: String, CodingKey { case acct, from, to, dir, amt, by, byText }
    init(from dec: Decoder) throws {
        let c = try dec.container(keyedBy: K.self)
        acct = (try? c.decodeIfPresent(String.self, forKey: .acct)) ?? ""
        from = (try? c.decodeIfPresent(String.self, forKey: .from)) ?? ""
        to = (try? c.decodeIfPresent(String.self, forKey: .to)) ?? ""
        dir = (try? c.decodeIfPresent(String.self, forKey: .dir)) ?? ""
        amt = (try? c.decodeIfPresent(Double.self, forKey: .amt)) ?? 0
        by = (try? c.decodeIfPresent(String.self, forKey: .by)) ?? ""
        byText = (try? c.decodeIfPresent(String.self, forKey: .byText)) ?? ""
    }
}
struct Disagreement: Decodable, Hashable, Identifiable {
    var d: String = ""; var what: String = ""; var ref: String = ""; var amts: [Double] = []; var fields: [String] = []; var amt: Double? = nil
    var mails: [String] = []
    var id: String { what + d + ref + mails.joined() }
    enum K: String, CodingKey { case d, what, ref, amts, fields, amt, mails }
    init(from dec: Decoder) throws {
        let c = try dec.container(keyedBy: K.self)
        d = (try? c.decodeIfPresent(String.self, forKey: .d)) ?? ""
        what = (try? c.decodeIfPresent(String.self, forKey: .what)) ?? ""
        ref = (try? c.decodeIfPresent(String.self, forKey: .ref)) ?? ""
        amts = (try? c.decodeIfPresent([Double].self, forKey: .amts)) ?? []
        fields = (try? c.decodeIfPresent([String].self, forKey: .fields)) ?? []
        amt = try? c.decodeIfPresent(Double.self, forKey: .amt)
        mails = (try? c.decodeIfPresent([String].self, forKey: .mails)) ?? []
    }
}
struct JourneyChecks: Decodable, Hashable {
    var links = 0, held = 0, unclear = 0, witnessed = 0, alone = 0, accounts = 0
    var breaks: [BalanceGap] = []
    var contradictions: [Disagreement] = []
    enum K: String, CodingKey { case links, held, unclear, witnessed, alone, accounts, breaks, contradictions }
    struct Acct: Decodable { var links: Int? }
    init(from dec: Decoder) throws {
        let c = try dec.container(keyedBy: K.self)
        links = (try? c.decodeIfPresent(Int.self, forKey: .links)) ?? 0
        held = (try? c.decodeIfPresent(Int.self, forKey: .held)) ?? 0
        unclear = (try? c.decodeIfPresent(Int.self, forKey: .unclear)) ?? 0
        witnessed = (try? c.decodeIfPresent(Int.self, forKey: .witnessed)) ?? 0
        alone = (try? c.decodeIfPresent(Int.self, forKey: .alone)) ?? 0
        let accts: [Acct] = ((try? c.decodeIfPresent([Lenient<Acct>].self, forKey: .accounts)) ?? nil)?.compactMap(\.value) ?? []
        accounts = accts.filter { ($0.links ?? 0) > 0 }.count
        breaks = ((try? c.decodeIfPresent([Lenient<BalanceGap>].self, forKey: .breaks)) ?? nil)?.compactMap(\.value) ?? []
        contradictions = ((try? c.decodeIfPresent([Lenient<Disagreement>].self, forKey: .contradictions)) ?? nil)?.compactMap(\.value) ?? []
    }
}

struct JourneyInfo: Decodable, Hashable {
    var coming: [JourneyItem] = []
    var late: [JourneyItem] = []
    var cardsOnTime: Int = 0
    var cardsLate: Int = 0
    var checks: JourneyChecks? = nil
    enum K: String, CodingKey { case coming, late, stats, checks }
    enum S: String, CodingKey { case cardsOnTime, cardsLate }
    init(from dec: Decoder) throws {
        let c = try dec.container(keyedBy: K.self)
        coming = ((try? c.decodeIfPresent([Lenient<JourneyItem>].self, forKey: .coming)) ?? nil)?.compactMap(\.value) ?? []
        late = ((try? c.decodeIfPresent([Lenient<JourneyItem>].self, forKey: .late)) ?? nil)?.compactMap(\.value) ?? []
        checks = try? c.decodeIfPresent(JourneyChecks.self, forKey: .checks)
        if let s = try? c.nestedContainer(keyedBy: S.self, forKey: .stats) {
            cardsOnTime = (try? s.decodeIfPresent(Int.self, forKey: .cardsOnTime)) ?? 0
            cardsLate = (try? s.decodeIfPresent(Int.self, forKey: .cardsLate)) ?? 0
        }
    }
}

/// a list element read on its own: one that doesn't read is dropped, the rest stay
struct Lenient<T: Decodable>: Decodable {
    let value: T?
    init(from dec: Decoder) throws { value = try? T(from: dec) }
}

extension ThreadStep {
    static func list<Key: CodingKey>(_ c: KeyedDecodingContainer<Key>, _ k: Key) -> [ThreadStep] {
        ((try? c.decodeIfPresent([Lenient<ThreadStep>].self, forKey: k)) ?? nil)?.compactMap(\.value) ?? []
    }
}

// MARK: words and colours

enum ThreadLook {
    static func kindName(_ k: String) -> String {
        switch k {
        case "card": return "Card bills"
        case "bill": return "Bills"
        case "order": return "Orders"
        case "policy": return "Insurance"
        case "deposit": return "Deposits"
        case "ipo": return "IPOs"
        case "fund": return "Mutual funds"
        case "stock": return "Shares"
        case "dividend": return "Dividends"
        case "sub": return "Subscriptions"
        case "standing": return "Standing instructions"
        case "refund": return "Refunds"
        default: return k.capitalized
        }
    }
    static func symbol(_ k: String) -> String {
        switch k {
        case "card": return "creditcard"
        case "bill": return "doc.text"
        case "order": return "shippingbox"
        case "policy": return "shield.lefthalf.filled"
        case "deposit": return "building.columns"
        case "ipo": return "sparkles"
        case "fund": return "chart.pie"
        case "stock": return "chart.bar"
        case "dividend": return "indianrupeesign.circle"
        case "sub": return "arrow.triangle.2.circlepath"
        case "standing": return "arrow.left.arrow.right.circle"
        case "refund": return "arrow.uturn.backward.circle"
        default: return "circle"
        }
    }
    static let order: [String] = ["card", "bill", "policy", "sub", "standing", "order", "refund", "deposit", "fund", "stock", "ipo", "dividend"]
    static func tint(_ status: String) -> Color {
        let s = status.lowercased()
        if s.contains("overdue") || s.contains("late") || s.contains("unpaid") || s.contains("lapsed") || s == "not seen" || s.contains("renewal not seen") { return .red }
        if s.contains("open") || s.contains("grace") || s.contains("part") || s.contains("waiting") || s.contains("minimum") || s.contains("blocked") || s == "placed" || s == "shipped" || s == "out" { return .orange }
        if s.contains("paid") || s == "active" || s == "delivered" || s.contains("refund") || s == "allotted" || s == "came" || s == "held" || s.contains("running") || s.contains("sip") { return .green }
        return .secondary
    }
    static func statusText(_ status: String) -> String {
        switch status {
        case "out": return "Out for delivery"
        case "delivered": return "Delivered"
        case "sub": return "Subscription"
        default: return status.prefix(1).uppercased() + status.dropFirst()
        }
    }
    static func stepName(_ t: String, kind: String) -> String {
        switch t {
        case "statement": return "Statement"
        case "reminder": return "Reminder"
        case "paid": return kind == "policy" ? "Premium paid" : "Paid"
        // (a card's balance update counting what came in since the statement: journey.js)
        case "confirmed": return "Paid, by the card’s own count"
        case "bill": return "Bill"
        case "auto-debit set": return "Auto-debit due"
        case "placed": return kind == "order" ? "Ordered" : "Placed"
        case "shipped": return "Shipped"
        case "out": return "Out for delivery"
        case "delivered": return "Delivered"
        case "cancelled": return "Cancelled"
        case "returned": return "Returned"
        case "declined": return "Payment declined"
        case "refund promised": return "Refund promised"
        case "refund started": return "Refund started"
        case "refunded": return "Refund credited"
        case "charged": return "Charged"
        case "issued": return "Policy issued"
        case "due": return "Premium due"
        case "renewed": return "Renewed"
        case "lapsed": return "Lapsed"
        case "open": return "Opened"
        case "renew": return "Renewed"
        case "close": return "Closed"
        case "mature": return "Matured"
        case "money in": return "Money put in"
        case "paid out": return "Paid out"
        case "applied": return "Applied"
        case "blocked": return "Money blocked"
        case "allotted": return "Allotted"
        case "not-allotted": return "Not allotted"
        case "unblocked": return "Unblocked"
        case "unblock due", "unblock promised": return "To be unblocked"
        case "buy": return "Bought"
        case "sip": return "SIP"
        case "redeem": return "Redeemed"
        case "switch": return "Switched"
        case "sell": return "Sold"
        case "dividend": return "Dividend"
        case "started": return "Started"
        case "renewing": return "Renews"
        case "came": return "Credited"
        default: return t.prefix(1).uppercased() + t.dropFirst()
        }
    }
    static func nextLine(_ n: ThreadNext, today: String) -> String {
        var s: String = n.what.isEmpty ? "Next" : n.what.prefix(1).uppercased() + n.what.dropFirst()
        if !n.d.isEmpty { s += " " + Day.when(n.d, today: today) }
        if let a = n.amt, a > 0 { s += " · " + Fmt.rupees(a) }
        return s
    }
}

// MARK: Home's card

struct JourneyRow: View {
    let item: JourneyItem
    let today: String
    var body: some View {
        let late: Bool = !item.status.isEmpty
        let tint: Color = late ? ThreadLook.tint(item.status) : (item.d <= Day.add(today, 3) ? .orange : Color.kosh)
        HStack(alignment: .center, spacing: 12) {
            Image(systemName: ThreadLook.symbol(item.kind))
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(tint)
                .frame(width: 34, height: 34)
                .background(tint.opacity(0.12), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
            VStack(alignment: .leading, spacing: 2) {
                Text(item.title).font(.subheadline.weight(.semibold)).foregroundStyle(Color.primary).lineLimit(1)
                Text(Self.line(item, today: today)).font(.footnote).foregroundStyle(late ? tint : .secondary).lineLimit(1)
            }
            Spacer(minLength: 0)
            if let a = item.amt, a > 0 { Text(Fmt.rupees(a)).font(.subheadline.weight(.semibold)).monospacedDigit() }
        }
        .padding(.vertical, 10)
        .contentShape(Rectangle())
        .privacySensitive()
    }
    static func line(_ i: JourneyItem, today: String) -> String {
        if !i.status.isEmpty { return ThreadLook.statusText(i.status) + (i.d.isEmpty ? "" : " · " + Day.short(i.d)) }
        let what: String = i.what.isEmpty ? "Due" : i.what.prefix(1).uppercased() + i.what.dropFirst()
        return what + " " + Day.when(i.d, today: today)
    }
}

// MARK: every thread

struct ThreadsSheet: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    var open: String? = nil
    @State private var kind: String = "all"
    @State private var path: [String] = []
    var body: some View {
        let all: [MoneyThread] = store.snap.threads ?? []
        let kinds: [String] = ThreadLook.order.filter { k in all.contains { $0.kind == k } }
        let shown: [MoneyThread] = kind == "all" ? all : all.filter { $0.kind == kind }
        NavigationStack(path: $path) {
            List {
                if all.isEmpty {
                    Text("As kosh reads your mail it links each step: a statement to the payment that cleared it, an order to its charge and refund, a premium to its policy. Nothing to link yet.")
                        .foregroundStyle(.secondary)
                }
                if !kinds.isEmpty {
                    Picker("Kind", selection: $kind) {
                        Text("All").tag("all")
                        ForEach(kinds, id: \.self) { k in Text(ThreadLook.kindName(k)).tag(k) }
                    }
                    .pickerStyle(.menu)
                }
                if kind == "all", let j = store.snap.journey {
                    if !j.coming.isEmpty {
                        Section("Coming up") {
                            ForEach(j.coming.prefix(12)) { item in NavigationLink(value: item.id) { JourneyRow(item: item, today: store.snap.today) } }
                        }
                    }
                    if let ch = j.checks, ch.links > 0 || ch.witnessed > 0 || !ch.contradictions.isEmpty {
                        ChecksSection(ch: ch)
                    }
                }
                Section(kind == "all" ? "Every thread" : ThreadLook.kindName(kind)) {
                    ForEach(shown.prefix(400)) { t in NavigationLink(value: t.id) { ThreadRow(t: t) } }
                }
            }
            .navigationTitle("Money threads")
            .navigationBarTitleDisplayMode(.inline)
            .navigationDestination(for: String.self) { id in
                if let t = all.first(where: { $0.id == id }) { ThreadDetail(t: t) } else { Text("This thread has moved on.").foregroundStyle(.secondary) }
            }
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } } }
        }
        // opened from Home's row: straight to that thread
        .onAppear { if let o = open, path.isEmpty { path = [o] } }
    }
}

/// what one mail says, checked against another: balances that add up, money that moved with no mail saying so,
/// mails that disagree
struct ChecksSection: View {
    let ch: JourneyChecks
    var body: some View {
        Section {
            if ch.links > 0 {
                Label(ch.held == ch.links ? "Every balance adds up: \(ch.links) step\(ch.links == 1 ? "" : "s") on \(max(ch.accounts, 1)) account\(ch.accounts == 1 ? "" : "s")"
                      : "\(ch.held) of \(ch.links) balance steps add up on \(max(ch.accounts, 1)) account\(ch.accounts == 1 ? "" : "s")",
                      systemImage: ch.held == ch.links ? "checkmark.seal" : "equal.circle")
                    .font(.subheadline)
            }
            if ch.witnessed + ch.alone > 0 {
                Label("\(ch.witnessed) payment\(ch.witnessed == 1 ? "" : "s") confirmed by a second mail or the balance; \(ch.alone) on one mail alone", systemImage: "doc.on.doc")
                    .font(.subheadline).foregroundStyle(.secondary)
            }
            ForEach(ch.breaks.prefix(8)) { g in
                VStack(alignment: .leading, spacing: 2) {
                    HStack {
                        Text((g.dir == "in" ? "Came into " : "Left ") + g.acct).font(.subheadline.weight(.semibold)).lineLimit(1)
                        Spacer(minLength: 0)
                        Text(Fmt.rupees(g.amt)).font(.subheadline.weight(.semibold)).monospacedDigit()
                    }
                    Text(g.by.isEmpty ? "Between \(Day.short(g.from)) and \(Day.short(g.to)), and no mail kosh has read says so"
                         : "Between \(Day.short(g.from)) and \(Day.short(g.to)): the \(g.byText.isEmpty ? "payment" : g.byText + " payment") that named no account")
                        .font(.footnote).foregroundStyle(g.by.isEmpty ? Color.orange : .secondary)
                }
                .privacySensitive()
            }
            ForEach(ch.contradictions.prefix(6)) { c in
                VStack(alignment: .leading, spacing: 2) {
                    Text(c.what == "amount" ? "Two mails, one payment, different amounts" : "Read differently from this sender's usual mail")
                        .font(.subheadline.weight(.semibold))
                    Text(c.what == "amount" ? c.amts.map { Fmt.rupees($0) }.joined(separator: " or ") + " · " + Day.short(c.d)
                         : (c.amt.map { Fmt.rupees($0) + " · " } ?? "") + Day.short(c.d))
                        .font(.footnote).foregroundStyle(.orange)
                }
                .privacySensitive()
            }
        } header: {
            Text("Checked against each other")
        } footer: {
            Text("An account's alerts carry its balance: between two of them, the payments kosh read must add up. Where they don't, money moved that no mail told kosh about.")
        }
    }
}

struct ThreadRow: View {
    let t: MoneyThread
    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: ThreadLook.symbol(t.kind)).font(.subheadline).foregroundStyle(Color.kosh).frame(width: 28)
            VStack(alignment: .leading, spacing: 2) {
                Text(t.title).font(.subheadline.weight(.medium)).lineLimit(1)
                Text(Self.sub(t)).font(.caption).foregroundStyle(.secondary).lineLimit(1)
            }
            Spacer(minLength: 0)
            Text(ThreadLook.statusText(t.status)).font(.caption.weight(.semibold)).foregroundStyle(ThreadLook.tint(t.status))
        }
        .privacySensitive()
    }
    static func sub(_ t: MoneyThread) -> String {
        var parts: [String] = []
        if t.kind == "card", t.onTime + t.late > 0 { parts.append("\(t.onTime) on time" + (t.late > 0 ? ", \(t.late) late" : "")) }
        if let e = t.usualEarly { parts.append(e >= 0 ? "paid \(e) days early, usually" : "paid \(-e) days late, usually") }
        if let p = t.premium { parts.append(Fmt.rupees(p) + " premium") }
        if let i = t.invested, i > 0 { parts.append(Fmt.rupees(i) + " in") }
        if let x = t.total, x > 0, t.kind != "card" { parts.append(Fmt.rupees(x)) }
        if let p = t.price { parts.append(Fmt.rupees(p) + (t.every.map { "/" + $0 } ?? "")) }
        if !t.last.isEmpty { parts.append(Day.fmt(t.last, "d MMM yyyy")) }
        return parts.joined(separator: " · ")
    }
}

/// one thread, step by step (a card's statements and a biller's bills each with their own steps)
struct ThreadDetail: View {
    @Environment(Store.self) private var store
    let t: MoneyThread
    @State private var source: SourceRef? = nil
    func step(_ i: Int, _ s: ThreadStep, last: Bool) -> some View {
        StepRow(s: s, kind: t.kind, lastOne: last)
            .contentShape(Rectangle())
            .onTapGesture { if let m = s.mail, store.live != nil { source = SourceRef(title: ThreadLook.stepName(s.t, kind: t.kind), mails: [m], type: StepRow.readingType(kind: t.kind, step: s)) } }
    }
    var body: some View {
        List {
            Section {
                VStack(alignment: .leading, spacing: 6) {
                    Label(ThreadLook.kindName(t.kind), systemImage: ThreadLook.symbol(t.kind)).font(.caption.weight(.semibold)).foregroundStyle(.secondary)
                    Text(t.title).font(.title3.weight(.semibold))
                    Text(ThreadLook.statusText(t.status)).font(.subheadline.weight(.semibold)).foregroundStyle(ThreadLook.tint(t.status))
                    if let n = t.next { Text(ThreadLook.nextLine(n, today: store.snap.today)).font(.subheadline).foregroundStyle(.secondary) }
                    ForEach(Self.facts(t), id: \.self) { f in Text(f).font(.footnote).foregroundStyle(.secondary) }
                }
                .padding(.vertical, 4)
                .privacySensitive()
            }
            ForEach(Array(t.groups.enumerated()), id: \.offset) { _, g in
                Section {
                    ForEach(Array(g.steps.enumerated()), id: \.offset) { i, s in step(i, s, last: i == g.steps.count - 1) }
                } header: {
                    HStack {
                        Text(Self.groupHead(t, g))
                        Spacer()
                        Text(ThreadLook.statusText(g.status)).foregroundStyle(ThreadLook.tint(g.status))
                    }
                }
            }
            if !t.steps.isEmpty {
                Section("Steps") {
                    ForEach(Array(t.steps.enumerated()), id: \.offset) { i, s in step(i, s, last: i == t.steps.count - 1) }
                }
            }
            Section {
                Text("Each step is a mail kosh read; kosh links them by amount, date and name. Tap a step to see the mail it came from, or to tell kosh it got it wrong. A step with nothing after it means the mail that would close it hasn't come, or isn't in your inbox.")
                    .font(.footnote).foregroundStyle(.secondary)
            }
        }
        .navigationTitle(ThreadLook.kindName(t.kind))
        .navigationBarTitleDisplayMode(.inline)
        .sheet(item: $source) { r in SourceSheet(ref: r).presentationDetents([.medium, .large]) }
    }
    static func groupHead(_ t: MoneyThread, _ g: ThreadGroup) -> String {
        if t.kind == "card" {
            var s: String = g.head.isEmpty ? "Statement" : "Statement " + Day.fmt(g.head, "d MMM yyyy")
            if let x = g.total { s += " · " + Fmt.rupees(x) }
            return s
        }
        var s: String = g.due.isEmpty ? "Bill" : "Due " + Day.fmt(g.due, "d MMM yyyy")
        if let x = g.total, x > 0 { s += " · " + Fmt.rupees(x) }
        return s
    }
    static func facts(_ t: MoneyThread) -> [String] {
        var out: [String] = []
        if let no = t.no, !no.isEmpty { out.append("No. " + no) }
        if let c = t.cover, c > 0 { out.append("Cover " + Fmt.rupees(c)) }
        if let r = t.rate, r > 0 { out.append(String(format: "%.2f%% a year", r)) }
        if let u = t.units, u != 0 { out.append(String(format: "%.3f units", u)) }
        if t.kind == "card", t.onTime + t.late > 0 { out.append("\(t.onTime) statement\(t.onTime == 1 ? "" : "s") paid on time, \(t.late) late or unpaid") }
        if let e = t.usualEarly { out.append(e >= 0 ? "Usually paid \(e) days before it's due" : "Usually paid \(-e) days after it's due") }
        return out
    }
}

struct StepRow: View {
    let s: ThreadStep
    let kind: String
    var lastOne = false
    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            VStack(spacing: 0) {
                Circle().fill(Color.kosh).frame(width: 8, height: 8).padding(.top, 6)
                if !lastOne { Rectangle().fill(Color.kosh.opacity(0.25)).frame(width: 1.5).frame(maxHeight: .infinity) }
            }
            .frame(width: 10)
            VStack(alignment: .leading, spacing: 2) {
                HStack {
                    Text(ThreadLook.stepName(s.t, kind: kind)).font(.subheadline.weight(.medium))
                    Spacer(minLength: 8)
                    if let a = s.amt, a > 0 { Text(Fmt.rupees(a)).font(.subheadline).monospacedDigit() }
                }
                Text(Self.line(s)).font(.caption).foregroundStyle(.secondary)
                if let q = s.q, !q.isEmpty {
                    Text("“" + q + "”").font(.caption2).foregroundStyle(.tertiary).lineLimit(2)
                }
            }
        }
        .privacySensitive()
    }
    /// the kind of reading a step stands on, to leave out when the person says it's wrong
    static func readingType(kind: String, step s: ThreadStep) -> String {
        switch s.t {
        case "paid": return kind == "policy" && (s.how ?? "").isEmpty ? "policy" : "move"
        case "charged", "money in", "paid out", "came", "refunded": return "move"
        case "statement": return "statement"
        case "confirmed": return "balance"
        case "reminder", "bill": return "due"
        case "auto-debit set", "started", "renewing", "cancelled", "autopay stopped": return kind == "order" ? "order" : "mandate"
        case "refund promised", "money promised", "ordered", "unblock due", "unblock promised": return "expect"
        default: break
        }
        switch kind {
        case "deposit": return "deposit"
        case "policy": return "policy"
        case "order": return "order"
        case "ipo": return "ipo"
        case "fund": return "fund"
        case "stock": return "trade"
        case "dividend": return "dividend"
        default: return "move"
        }
    }
    static func line(_ s: ThreadStep) -> String {
        var parts: [String] = [s.d.isEmpty ? "" : Day.fmt(s.d, "EEE d MMM yyyy")]
        if let d = s.due, !d.isEmpty { parts.append("due " + Day.fmt(d, "d MMM")) }
        if let b = s.by, !b.isEmpty { parts.append("by " + Day.fmt(b, "d MMM")) }
        if let m = s.min, m > 0 { parts.append("minimum " + Fmt.rupees(m)) }
        if let h = s.how, !h.isEmpty { parts.append(h) }
        if let u = s.units, u > 0 { parts.append(String(format: "%.3f units", u)) }
        if let n = s.nav, n > 0 { parts.append(String(format: "NAV %.2f", n)) }
        if let q = s.qty, q > 0 { parts.append(String(format: "%.0f shares", q)) }
        if let q = s.shares, q > 0 { parts.append(String(format: "%.0f shares", q)) }
        return parts.filter { !$0.isEmpty }.joined(separator: " · ")
    }
}
