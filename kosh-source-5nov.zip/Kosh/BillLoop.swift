import SwiftUI
import UIKit

// MARK: - A bill paid, and its loop (3 Nov 2026)
//
// A card's bill paid through CRED, a bank app, PhonePe or Amazon Pay, and a home's bill paid through any of them, says
// three things in a row: where it was paid (the app, its order and UTR), what it paid (the card in the stack, or the
// biller and its connection number with the Bharat Connect reference) and where the money came from, then whether the
// bank said so: the card's issuer's "payment received" within two days closes the loop. The engine works it out
// (billLoopBook: Txn.bl, Txn.lp, CardInfo.pays); this shows it on the payment and on the card.

enum LoopWords {
    static func tint(_ st: String) -> Color {
        switch st {
        case "done": return BillInk.paid
        case "wait": return Color.sky
        case "open": return BillInk.soon
        default: return Color.secondary
        }
    }
    static func sym(_ st: String) -> String {
        switch st {
        case "done": return "checkmark.seal.fill"
        case "wait": return "hourglass"
        case "open": return "exclamationmark.circle.fill"
        default: return "questionmark.circle"
        }
    }
    /// the bank that should confirm it, in words
    static func bank(_ lp: Txn.PayLoop, _ store: Store) -> String {
        if let by = lp.by, !by.isEmpty { return by }
        if let id = lp.card, let c = store.snap.cards.first(where: { $0.id == id }) { return c.bank }
        return "the bank"
    }
    /// one line for where the loop stands
    static func line(_ lp: Txn.PayLoop, paid: String, card: Bool, _ store: Store) -> String {
        let bank: String = bank(lp, store)
        switch lp.st {
        case "done":
            let on: String = lp.on.map { Day.fmt($0, "d MMM") } ?? ""
            return card ? bank + " confirmed it" + (on.isEmpty ? "" : ", " + on) : "Paid" + (on.isEmpty ? "" : ", " + on) + (lp.by.map { " · " + $0 + " confirms the money left" } ?? "")
        case "wait":
            return card ? "Waiting for " + bank + " to confirm. Banks take up to 2 days." : "Waiting for the bank's word that the money left"
        case "open":
            let days: Int = max(0, Day.between(paid, store.snap.today))
            return card ? bank + " hasn’t confirmed it yet: \(days) days since you paid" : "No word from the bank yet: \(days) days"
        default:
            return card ? "No confirmation from " + bank + " in your mail" : "No confirmation in your mail"
        }
    }
    static func cardName(_ lp: Txn.PayLoop, _ store: Store) -> String {
        if let id = lp.card, let c = store.snap.cards.first(where: { $0.id == id }) {
            return c.bank + ((c.product ?? "").isEmpty ? "" : " " + (c.product ?? "")) + " ••" + c.last
        }
        if let l = lp.l4, !l.isEmpty { return "Card ••" + l }
        return ""
    }
    /// the note kosh writes on a bill paid (AutoNote): where, for what, from where, its references
    static func note(_ t: Txn, _ store: Store) -> String? {
        guard let lp = t.lp else { return nil }
        var lines: [String] = []
        let pt: String = lp.pt ?? ""
        if t.k == "cardpay" {
            let card: String = cardName(lp, store)
            guard !card.isEmpty || !pt.isEmpty else { return nil }
            lines.append((card.isEmpty ? "Card bill" : card + " bill") + (pt.isEmpty ? "" : " · paid via " + pt))
        } else if let bl = t.bl {
            var head: String = bl.bn ?? t.m
            if let k = bl.k, !k.isEmpty, !head.lowercased().contains(k.lowercased()) { head += " (" + k.lowercased() + ")" }
            lines.append(head + (pt.isEmpty ? "" : " · paid via " + pt))
            if let no = bl.no { lines.append((bl.nol ?? "Account") + " " + no) }
        } else { return nil }
        if let src = lp.src, !src.isEmpty { lines.append("From " + src) }
        var refs: [String] = []
        if let o = lp.ord ?? t.bl?.ord { refs.append("Order " + o) }
        if let r = t.bl?.ref ?? lp.ref { refs.append("Bharat Connect " + r) }
        if let u = lp.utr ?? t.bl?.utr { refs.append("UTR " + u) }
        if !refs.isEmpty { lines.append(refs.joined(separator: " · ")) }
        return lines.count > 1 || !pt.isEmpty ? lines.joined(separator: "\n") : nil
    }
}

/// the sheet's place for a bill paid: nothing for any other payment (one small view in the sheet's body, never a branch)
struct BillLoopSlot: View {
    let t: Txn
    var body: some View {
        if t.lp != nil || t.bl != nil { BillLoopCard(t: t) }
    }
}

/// a bill paid, on its payment's sheet: the loop's three steps, then every detail kosh read (each copied on a long press)
struct BillLoopCard: View {
    @Environment(Store.self) private var store
    let t: Txn
    var body: some View {
        let lp: Txn.PayLoop? = t.lp
        let bl: Txn.BillLine? = t.bl
        let card: Bool = t.k == "cardpay"
        let st: String = lp?.st ?? "old"
        VStack(alignment: .leading, spacing: 8) {
            SheetCard {
                VStack(alignment: .leading, spacing: 14) {
                    HStack(spacing: 8) {
                        Text(card ? "Card bill paid" : "Bill paid").font(.headline)
                        Spacer(minLength: 8)
                        if let lp {
                            Label(st == "done" ? "Loop closed" : st == "wait" ? "Confirming" : st == "open" ? "Not confirmed" : "Unconfirmed", systemImage: LoopWords.sym(st))
                                .font(.caption.weight(.semibold))
                                .foregroundStyle(LoopWords.tint(st))
                                .padding(.horizontal, 9).padding(.vertical, 4)
                                .background(LoopWords.tint(st).opacity(0.13), in: Capsule())
                                .accessibilityLabel(LoopWords.line(lp, paid: t.d, card: card, store))
                        }
                    }
                    if let lp {
                        LoopSteps(t: t, lp: lp, card: card)
                        Text(LoopWords.line(lp, paid: t.d, card: card, store))
                            .font(.subheadline)
                            .foregroundStyle(st == "open" ? BillInk.soon : Color.secondary)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                }
                .padding(16)
                Divider().padding(.leading, 16)
                VStack(alignment: .leading, spacing: 0) {
                    if let pt = lp?.pt, !pt.isEmpty { LoopRow(label: "Paid through", value: pt) }
                    if card, let lp, !LoopWords.cardName(lp, store).isEmpty { LoopRow(label: "For card", value: LoopWords.cardName(lp, store)) }
                    if let bn = bl?.bn, !bn.isEmpty { LoopRow(label: "Biller", value: bn + ((bl?.k).map { " · " + $0 } ?? "")) }
                    if let no = bl?.no { LoopRow(label: bl?.nol ?? "Connection", value: no, copy: true) }
                    if let src = lp?.src, !src.isEmpty { LoopRow(label: "Money from", value: src) }
                    if let f = bl?.from, let to = bl?.to { LoopRow(label: "Covers", value: Day.fmt(f, "d MMM") + " – " + Day.fmt(to, "d MMM yyyy")) }
                    if let u = bl?.units, u > 0 { LoopRow(label: "Used", value: Fmt.trim(u, 1) + " " + (bl?.unit ?? "")) }
                    if let r = bl?.ref ?? lp?.ref { LoopRow(label: "Bharat Connect ref", value: r, copy: true) }
                    if let r = bl?.oref { LoopRow(label: "Biller’s ref", value: r, copy: true) }
                    if let o = lp?.ord ?? bl?.ord { LoopRow(label: "Order", value: o, copy: true) }
                    if let u = lp?.utr ?? bl?.utr { LoopRow(label: "UTR", value: u, copy: true) }
                    if let fee = bl?.fee, fee > 0 { LoopRow(label: "Convenience fee", value: Fmt.rupees(fee)) }
                    if let cr = lp?.cr { LoopRow(label: (lp?.pt ?? "The app") + " says credited", value: Day.fmt(cr, "EEE d MMM")) }
                }
                .padding(.vertical, 6)
            }
            SheetFootnote(card ? "The loop closes when the card’s bank says the payment reached the card (its “payment received”), usually within 2 days." : "Kept from the receipt, so the biller can be told the reference if the payment doesn’t show on its side.")
        }
    }
}

/// paid in the app → money left the account → the bank confirmed: three dots on a line, filled as each is known
struct LoopSteps: View {
    @Environment(Store.self) private var store
    let t: Txn
    let lp: Txn.PayLoop
    let card: Bool
    var body: some View {
        let steps: [(String, String, Bool)] = [
            ((lp.pt ?? "").isEmpty ? "Paid" : "Paid on " + (lp.pt ?? ""), Day.fmt(t.d, "d MMM"), true),
            ("Money left", (lp.src ?? "").isEmpty ? "—" : (lp.src ?? ""), !(lp.src ?? "").isEmpty || !card),
            (card ? LoopWords.bank(lp, store) + " confirmed" : "Confirmed", lp.st == "done" ? (lp.on.map { Day.fmt($0, "d MMM") } ?? "") : lp.st == "wait" ? "within 2 days" : "not yet", lp.st == "done"),
        ]
        HStack(alignment: .top, spacing: 0) {
            ForEach(Array(steps.enumerated()), id: \.offset) { (i, s) in
                VStack(spacing: 5) {
                    HStack(spacing: 0) {
                        Rectangle().fill(i == 0 ? Color.clear : (s.2 ? BillInk.paid : Color.secondary.opacity(0.25))).frame(height: 2)
                        Image(systemName: s.2 ? "checkmark.circle.fill" : "circle.dashed")
                            .font(.system(size: 18, weight: .semibold))
                            .foregroundStyle(s.2 ? BillInk.paid : (i == 2 ? LoopWords.tint(lp.st) : Color.secondary))
                        Rectangle().fill(i == steps.count - 1 ? Color.clear : (steps[i + 1].2 ? BillInk.paid : Color.secondary.opacity(0.25))).frame(height: 2)
                    }
                    Text(s.0).font(.caption.weight(.semibold)).multilineTextAlignment(.center).lineLimit(2)
                    Text(s.1).font(.caption2).foregroundStyle(.secondary).multilineTextAlignment(.center).lineLimit(2).privacySensitive()
                }
                .frame(maxWidth: .infinity)
            }
        }
        .accessibilityElement(children: .combine)
    }
}

/// a label and its value; a reference can be copied
struct LoopRow: View {
    let label: String
    let value: String
    var copy: Bool = false
    @State private var copied = false
    var body: some View {
        HStack(alignment: .firstTextBaseline, spacing: 12) {
            Text(label).font(.subheadline).foregroundStyle(.secondary)
            Spacer(minLength: 8)
            Text(copied ? "Copied" : value)
                .font(.subheadline.weight(.medium))
                .monospacedDigit()
                .multilineTextAlignment(.trailing)
                .lineLimit(2)
                .truncationMode(.middle)
                .textSelection(.enabled)
                .privacySensitive()
            if copy {
                Button {
                    UIPasteboard.general.string = value
                    withAnimation(Motion.base) { copied = true }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) { withAnimation(Motion.base) { copied = false } }
                } label: {
                    Image(systemName: "doc.on.doc").font(.footnote)
                }
                .buttonStyle(.borderless)
                .accessibilityLabel("Copy " + label)
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 7)
    }
}

/// on a card in the stack: its latest bill payments, where each was paid from, and whether the bank confirmed it
struct CardPaysBlock: View {
    @Environment(Store.self) private var store
    let pays: [CardInfo.Pay]
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Bills paid").font(.system(.footnote, weight: .semibold)).foregroundStyle(.secondary)
            ForEach(pays.prefix(4), id: \.id) { p in
                Button { store.openTx(p.id) } label: {
                    HStack(spacing: 10) {
                        Image(systemName: LoopWords.sym(p.st))
                            .foregroundStyle(LoopWords.tint(p.st))
                            .frame(width: 22)
                        VStack(alignment: .leading, spacing: 1) {
                            Text(Fmt.rupees(p.a) + " · " + Day.fmt(p.d, "d MMM"))
                                .font(.subheadline.weight(.semibold)).monospacedDigit().privacySensitive()
                            Text(Self.sub(p))
                                .font(.caption).foregroundStyle(p.st == "open" ? BillInk.soon : Color.secondary)
                                .lineLimit(2)
                        }
                        Spacer(minLength: 6)
                        Image(systemName: "chevron.right").font(.caption.weight(.semibold)).foregroundStyle(.tertiary)
                    }
                    .contentShape(Rectangle())
                }
                .buttonStyle(.press)
                .foregroundStyle(Color.primary)
            }
        }
    }
    static func sub(_ p: CardInfo.Pay) -> String {
        var bits: [String] = []
        if let pt = p.pt, !pt.isEmpty { bits.append("via " + pt) }
        if let s = p.src, !s.isEmpty { bits.append("from " + s) }
        let how: String = bits.joined(separator: " ")
        let st: String
        switch p.st {
        case "done": st = "confirmed" + (p.on.map { " " + Day.fmt($0, "d MMM") } ?? "")
        case "wait": st = "confirming"
        case "open": st = "not confirmed yet"
        default: st = "no confirmation in mail"
        }
        return how.isEmpty ? st.prefix(1).uppercased() + st.dropFirst() : how.prefix(1).uppercased() + how.dropFirst() + " · " + st
    }
}
