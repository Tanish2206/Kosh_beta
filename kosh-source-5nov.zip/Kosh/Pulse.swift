import SwiftUI

// MARK: - The pulse: a handful of figures that say how things stand, in a strip you thumb through
//
// Under the net-worth line on Home: liquid, invested, property, owed and the runway. Each tile is
// one bold figure, one line on what's in it, and a thin bar of its share of what you own; a tap opens
// the page behind it. A tile with nothing behind it stays away.

struct PulseTile: Identifiable {
    let id: String
    let label: String
    let value: String
    let sub: String
    let color: Color
    let sym: String
    /// up, down or flat: the small arrow by the figure (nil for none)
    var trend: Int? = nil
    /// its share of what's owned (or, for the year, of what came in), drawn as a thin bar
    var share: Double? = nil
    var shareOf: String = "of what you own"
    let go: () -> Void
}

extension Store {
    /// the tiles for whoever is picked, in the order they matter
    func pulse(_ p: Person) -> [PulseTile] {
        var out: [PulseTile] = []
        let mine = p == .family || p == .me
        let own = max(1, assets(p))
        // liquid: the bank, deposits and cash
        let bank = bankBalance(p)
        let deps = holdings(p).filter { $0.cls == "dep" }.reduce(0) { $0 + $1.amt }
        let cash = mine ? cashInHand : 0
        if bank + deps + cash > 0 {
            var parts: [String] = []
            if bank > 0 { parts.append("bank") }
            if deps > 0 { parts.append("deposits") }
            if cash > 0 { parts.append("cash") }
            out.append(PulseTile(id: "liquid", label: "Liquid", value: Fmt.short(bank + deps + cash), sub: parts.joined(separator: ", "), color: Color(hex: "#5AC8FA"), sym: "drop.fill", share: (bank + deps + cash) / own) { [weak self] in
                guard let self else { return }
                self.txSub = .accounts; self.open(.transactions)
            })
        }
        // invested: the markets, retirement and gold
        let inv = holdings(p).filter { $0.cls != "dep" }
        let invested = inv.reduce(0) { $0 + $1.amt }
        if invested > 0 {
            let g = Gains(inv)
            // a gain only once what went in is known for most of the money, as the Portfolio cards show it
            let up: Bool = g.covered && g.cost > 0
            let sub = up ? Gains.line(g.gain, g.pct) : "\(inv.count) holding\(inv.count == 1 ? "" : "s")"
            out.append(PulseTile(id: "invested", label: "Invested", value: Fmt.short(invested), sub: sub, color: Color(hex: "#30B0C7"), sym: "chart.line.uptrend.xyaxis", trend: up ? (g.gain >= 0 ? 1 : -1) : nil, share: invested / own) { [weak self] in
                guard let self else { return }
                self.portSub = .investments; self.open(.portfolio)
            })
        }
        // property: the land, at the rates set
        let land = propertyWorth(p)
        if land > 0 {
            let n = properties(p).filter { ($0.worth ?? 0) > 0 }.count
            out.append(PulseTile(id: "land", label: "Property", value: Fmt.short(land), sub: "land under \(n) propert\(n == 1 ? "y" : "ies")", color: Color(hex: "#8E6E53"), sym: "building.2.fill", share: land / own) { [weak self] in
                self?.open(.property)
            })
        }
        // owed on loans
        let owed = debts(p)
        if owed > 0 {
            // (the EMIs of the loans the figure counts: whoever is picked, as debts(p) goes by whose each loan is)
            let emi = snap.loans.filter { $0.active && p.owns($0.owner ?? "me") }.reduce(0) { $0 + $1.emi }
            out.append(PulseTile(id: "owed", label: "Owed", value: Fmt.short(owed), sub: emi > 0 ? Fmt.short(emi) + " EMI a month" : "on loans", color: Color.orange, sym: "building.columns.fill", share: owed / own, shareOf: "against what you own") { [weak self] in
                guard let self else { return }
                self.portSub = .loans; self.open(.portfolio)
            })
        }
        // runway: how many months of your usual spending the liquid money would cover
        let usual: Double = snap.fc.usual
        let liquid: Double = bank + deps + cash
        if p == .family && usual > 0 && liquid > 0 {
            let months: Double = liquid / usual
            let value: String = months < 1 ? "Under a month" : months >= 24 ? String(format: "%.1f years", months / 12) : String(Int(safe: months)) + " months"
            out.append(PulseTile(id: "runway", label: "Runway", value: value, sub: "of usual spending, from liquid money", color: Color.indigo, sym: "hourglass", share: nil) { [weak self] in
                guard let self else { return }
                self.txSub = .insights; self.open(.transactions)
            })
        }
        return out
    }
}

struct PulsePress: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.96 : 1)
            .opacity(configuration.isPressed ? 0.85 : 1)
            .animation(configuration.isPressed ? Motion.quick : Motion.base, value: configuration.isPressed)
    }
}
