import SwiftUI

// MARK: - Obsidian: the black look of the Insurance and Wealth screens (his pick, 1 Nov)
//
// Pure black page, near-black cards with a hairline, warm white ink, one colour per kind of cover. These screens are
// drawn dark whatever Settings › Appearance says (`.obsidianPage()`), as the design was approved; the rest of kosh keeps
// the look picked. Shared by the Insurance screens (feat/insurance-obsidian) and the Wealth ones (feat/wealth-obsidian):
// the token names are agreed between them, so keep them as they are.

enum Obsidian {
    /// the page, a card on it and the card's hairline
    static let bg: Color = Color(hex: "#000000")
    static let card: Color = Color(hex: "#0A0A0D")
    static let cardBorder: Color = Color.white.opacity(0.07)
    /// ink: words and figures; ink2: what a figure is; ink3: captions and the quietest words
    static let ink: Color = Color(hex: "#F5F5F7")
    static let ink2: Color = Color(hex: "#A1A1AA")
    static let ink3: Color = Color(hex: "#8A8A93")
    /// one colour per kind of cover
    static let health: Color = Color(hex: "#5EE6B8")
    static let term: Color = Color(hex: "#A78BFA")
    static let savings: Color = Color(hex: "#F5C46B")
    static let ulip: Color = Color(hex: "#6CA8FF")
    static let motor: Color = Color(hex: "#FF8F5A")
    static let property: Color = Color(hex: "#F27C9B")
}

/// the warm light at the top of a black page, in its colour (1 Nov: the first one, at 16%, was barely there on the
/// phone). A wide wash with a brighter core, off to the left, under the bars; fixed while the page scrolls
struct ObsidianAura: View {
    let tint: Color
    /// how strong a card's own corner light is
    static let card: Double = 0.42
    var body: some View {
        ZStack {
            RadialGradient(stops: [.init(color: tint.opacity(0.30), location: 0), .init(color: tint.opacity(0.11), location: 0.45),
                                   .init(color: .clear, location: 1)], center: .center, startRadius: 0, endRadius: 330)
                .frame(width: 560, height: 640).offset(x: -70, y: -250)
            RadialGradient(colors: [tint.opacity(0.10), .clear], center: .center, startRadius: 0, endRadius: 180)
                .frame(width: 360, height: 360).offset(x: 150, y: -140)
        }
        .frame(maxWidth: .infinity, alignment: .top)
        .ignoresSafeArea()
        .allowsHitTesting(false)
        .accessibilityHidden(true)
    }
}

/// a caption in capitals, spaced out, in the monospaced face: "PREMIUMS A YEAR"
struct Caption: ViewModifier {
    var color: Color = Obsidian.ink3
    func body(content: Content) -> some View {
        content
            .font(.system(size: 11, weight: .medium, design: .monospaced))
            .textCase(.uppercase)
            .tracking(1.4)
            .foregroundStyle(color)
    }
}

extension View {
    func caption(_ color: Color = Obsidian.ink3) -> some View { modifier(Caption(color: color)) }
    /// a near-black card with its hairline
    func obsidianCard(_ radius: CGFloat = 22, padding: CGFloat = 16) -> some View {
        self.padding(padding)
            .background(Obsidian.card, in: RoundedRectangle(cornerRadius: radius, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: radius, style: .continuous).strokeBorder(Obsidian.cardBorder, lineWidth: 1))
    }
    /// a page in the black look: drawn dark whatever the app's look, on black, its bars dark too; `aura`, the page's
    /// colour, glows from its top left (ObsidianAura) — one strength for every black page
    func obsidianPage(aura: Color? = nil) -> some View {
        self.background(alignment: .top) { if let aura { ObsidianAura(tint: aura) } }
            .background(Obsidian.bg.ignoresSafeArea())
            // (lists and forms on it drop their grey and put each row on a card: ObsidianKit.swift)
            .scrollContentBackground(.hidden)
            .environment(\.obsidian, true)
            .environment(\.colorScheme, .dark)
            .toolbarColorScheme(.dark, for: .navigationBar)
            .toolbarBackground(Obsidian.bg, for: .navigationBar)
    }
}

/// a segmented control in the black look: a pill per choice, the chosen one white with black words
struct ObsidianChips<T: Hashable>: View {
    let items: [(T, String)]
    @Binding var picked: T
    var body: some View {
        HStack(spacing: 2) {
            ForEach(Array(items.enumerated()), id: \.offset) { pair in
                let it: (T, String) = pair.element
                let on: Bool = it.0 == picked
                Button { withAnimation(Motion.base) { picked = it.0 } } label: {
                    Text(it.1)
                        .font(.system(size: 13, weight: on ? .semibold : .medium))
                        .lineLimit(1).minimumScaleFactor(0.8)
                        .foregroundStyle(on ? Color.black : Obsidian.ink2)
                        .frame(maxWidth: .infinity, minHeight: 44)
                        .background(on ? Obsidian.ink : Color.clear, in: Capsule())
                        .contentShape(Capsule())
                }
                .buttonStyle(.press)
                .accessibilityAddTraits(on ? .isSelected : [])
            }
        }
        .padding(4)
        .background(Obsidian.card, in: Capsule())
        .overlay(Capsule().strokeBorder(Color.white.opacity(0.08), lineWidth: 1))
    }
}
