import SwiftUI
import SafariServices

// MARK: - What the land is worth
//
// The portal gives the plot's size; the rate per square yard is the one thing kosh can't read anywhere private.
// Two ways to get it: kosh asks Claude (on your key) to look up the going rate for that sector and city — the
// query names the area, never you or the property — or you look it up yourself in the browser and type it in.
// The worth is plot × rate, shown as "potential": land sells at a price, not a rate card.

enum LandRate {
    struct Found { let rate: Double; let note: String }

    /// the going rate per sq yd for land in this area, looked up on the web by Claude; nil when it can't say
    static func lookup(city: String, area: String, state: String, kind: String, key: String) async -> Found? {
        let place = [area, city, state].filter { !$0.isEmpty }.joined(separator: ", ")
        guard !place.isEmpty, !key.isEmpty else { return nil }
        let use = kind.lowercased().contains("sco") || kind.lowercased().contains("shop") || kind.lowercased().contains("office") ? "commercial" : "residential"
        let q = "Current market rate and the government circle (collector) rate for \(use) land per square yard in \(place), India. Reply with only a JSON object: {\"market\": <rupees per sq yd or null>, \"circle\": <rupees per sq yd or null>, \"source\": \"<url>\", \"asOf\": \"<month year>\"}. Convert from per sq ft (×9) or per sq m (÷1.196) if the source quotes those."
        let body: [String: Any] = [
            "model": "claude-sonnet-4-5", "max_tokens": 600,
            "tools": [["type": "web_search_20250305", "name": "web_search", "max_uses": 4]],
            "messages": [["role": "user", "content": q]],
        ]
        guard let data = try? JSONSerialization.data(withJSONObject: body), let json = String(data: data, encoding: .utf8) else { return nil }
        var req = URLRequest(url: URL(string: "https://api.anthropic.com/v1/messages")!)
        req.httpMethod = "POST"
        req.setValue(key, forHTTPHeaderField: "x-api-key")
        req.setValue("2023-06-01", forHTTPHeaderField: "anthropic-version")
        req.setValue("application/json", forHTTPHeaderField: "content-type")
        req.timeoutInterval = 90
        req.httpBody = Data(json.utf8)
        guard let (out, resp) = try? await URLSession.shared.data(for: req), (resp as? HTTPURLResponse)?.statusCode == 200,
              let j = (try? JSONSerialization.jsonObject(with: out)) as? [String: Any], let content = j["content"] as? [[String: Any]] else { return nil }
        let text = content.compactMap { $0["type"] as? String == "text" ? $0["text"] as? String : nil }.joined(separator: "\n")
        guard let a = text.range(of: "{"), let b = text.range(of: "}", options: .backwards), a.lowerBound < b.upperBound,
              let o = (try? JSONSerialization.jsonObject(with: Data(text[a.lowerBound..<b.upperBound].utf8))) as? [String: Any] else { return nil }
        let market = o["market"] as? Double ?? Double(o["market"] as? String ?? "")
        let circle = o["circle"] as? Double ?? Double(o["circle"] as? String ?? "")
        guard let rate = market ?? circle, rate >= 1000, rate < 5_000_000 else { return nil }
        var note = (market != nil ? "market rate" : "circle rate") + " for " + place
        if let s = o["asOf"] as? String, !s.isEmpty { note += ", " + s }
        if let src = o["source"] as? String, let host = URL(string: src)?.host { note += " · " + host.replacingOccurrences(of: "www.", with: "") }
        return Found(rate: rate.rounded(), note: note)
    }

    /// a web search to look it up yourself, opened in the app's browser
    static func searchURL(city: String, area: String, state: String, kind: String) -> URL {
        let use = kind.lowercased().contains("sco") || kind.lowercased().contains("shop") ? "commercial" : "residential"
        let q = ["\(use) land rate per sq yard", area, city, state, "2026"].filter { !$0.isEmpty }.joined(separator: " ")
        return URL(string: "https://www.google.com/search?q=" + (q.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""))!
    }
}

/// the land's rate and worth, in the property editor
struct LandRateRows: View {
    @Environment(Store.self) private var store
    @Binding var p: UserProperty
    @State private var busy = false
    @State private var note: String?
    @State private var browsing = false
    var sqyd: Double { store.snap.prop.props.first { $0.uid == p.id }?.plotSqYd ?? 0 }
    var body: some View {
        Section {
            if sqyd > 0 { LabeledContent("Plot", value: Fmt.trim(sqyd, 2) + " sq yd") } else { Text("Plot size comes from the tax portal; read the property there first.").font(.footnote).foregroundStyle(.secondary) }
            HStack {
                Text("Rate per sq yd")
                Spacer()
                TextField("₹", value: Binding(get: { p.landRate ?? 0 }, set: { v in p.landRate = v > 0 ? v : nil; p.landRateNote = "typed by you"; p.landRateAt = store.snap.today }), format: .number)
                    .keyboardType(.numberPad).multilineTextAlignment(.trailing).frame(maxWidth: 120)
            }
            if let r = p.landRate, r > 0, sqyd > 0 { LabeledContent("Worth, about", value: Fmt.words(r * sqyd)) }
            if store.live?.claudeReady == true {
                Button { Task { await find() } } label: { Label(busy ? "Looking up the going rate…" : "Look up the going rate", systemImage: "sparkle.magnifyingglass") }.disabled(busy)
            }
            Button { browsing = true } label: { Label("Search the web myself", systemImage: "safari") }
            if let note { Text(note).font(.footnote).foregroundStyle(.secondary) }
        } header: { Text("What the land is worth") } footer: {
            Text(Self.footer(p))
        }
        .sheet(isPresented: $browsing) { SafariSheet(url: LandRate.searchURL(city: p.city, area: p.name, state: p.state, kind: p.type)).ignoresSafeArea() }
    }
    /// what the rate is and where it came from, or why to set one
    static func footer(_ p: UserProperty) -> String {
        let note: String = p.landRateNote ?? ""
        if note.isEmpty { return "Land is the bulk of a property's value. Set the rate once; kosh shows the worth on the property and counts it in net worth as \"potential\"." }
        let at: String = p.landRateAt ?? ""
        let when: String = at.isEmpty ? "" : ", " + Day.fmt(at, "d MMM yyyy")
        return "Rate: " + note + when + ". The lookup names only the area, never you or the property."
    }
    @MainActor func find() async {
        guard let key = Keychain.get("claude.key"), !key.isEmpty else { return }
        busy = true; note = nil
        defer { busy = false }
        if let f = await LandRate.lookup(city: p.city, area: p.name, state: p.state, kind: p.type, key: key) {
            p.landRate = f.rate; p.landRateNote = f.note; p.landRateAt = store.snap.today
            note = "Found " + Fmt.rupees(f.rate) + " a sq yd: " + f.note + ". Change it if you know better."
        } else {
            note = "Couldn't find a figure for this area. Search yourself and type the rate in."
        }
    }
}

struct SafariSheet: UIViewControllerRepresentable {
    let url: URL
    func makeUIViewController(context: Context) -> SFSafariViewController { SFSafariViewController(url: url) }
    func updateUIViewController(_ v: SFSafariViewController, context: Context) {}
}
