/* kosh plan: what you're working towards and what could trip you up on the way — goals (an emergency fund, a joint
   goal), the salary split you set (SIP, PPF, rent, spending) ticked off as the money goes, a low balance before an
   auto-debit, and subscriptions (a free trial about to turn into a charge, two services doing one job, how to cancel).

   Arithmetic on the household's own ledger, done on the phone, like agent.js. It hangs off build() (E.postBuild),
   after agent.js has laid out what kosh noticed (snap.watch), so its own heads-ups join that list.

   What the person sets comes in as prof.plan (LiveSession.planJSON):
     { goals: [{ id, name, kind: 'emergency'|'custom', target (0: kosh's suggestion), by: 'yyyy-mm-dd'|'',
                 who: 'all'|person id, sources: ['a:<account id>', 'h:<holding id>', 'c:<class>'], manual, made }],
       split: { who: ''|person id, parts: [{ id, name, kind: 'sip'|'ppf'|'rent'|'savings'|'spending'|'other', amt, words }] },
       hideSuggest: bool,
       cancelled: { '<trial id>': 'yyyy-mm-dd' } }   (a trial you said you cancelled, and when)
   A holding's id is its name and person run together, as the phone's Holding.id is; 'c:bank' is every bank account,
   'c:dep' every deposit, 'c:mf' every fund, and so on.

   Loaded after agent.js; Swift reads snap.plan (Plan.swift). */

var KoshPlan = (function (E) {
  'use strict';
  var L = (E && E.lib) || {};
  var inr = L.inr || function (n) { return '₹' + Math.round(Math.abs(+n || 0)); };

  /* ------------------------------------------------------------ small things */
  function lc(s) { return String(s == null ? '' : s).toLowerCase(); }
  function r0(n) { return Math.round(+n || 0); }
  function sum(list, f) { var s = 0; for (var i = 0; i < list.length; i++) s += +(f ? f(list[i]) : list[i]) || 0; return s; }
  function median(xs) { if (!xs.length) return 0; var s = xs.slice().sort(function (a, b) { return a - b; }), m = Math.floor(s.length / 2); return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2; }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function isDay(s) { return /^\d{4}-\d{2}-\d{2}$/.test(String(s || '')); }
  function dayOf(iso) { var p = String(iso || '').slice(0, 10).split('-'); return Date.UTC(+p[0], +p[1] - 1, +p[2]); }
  function addDays(iso, n) { var d = new Date(dayOf(iso) + n * 864e5); return d.getUTCFullYear() + '-' + pad(d.getUTCMonth() + 1) + '-' + pad(d.getUTCDate()); }
  function daysBetween(a, b) { return Math.round((dayOf(b) - dayOf(a)) / 864e5); }
  /** a month n months on from yyyy-mm */
  function addMonthsM(m, n) { var y = +m.slice(0, 4), mo = +m.slice(5, 7) - 1 + n; y += Math.floor(mo / 12); mo = ((mo % 12) + 12) % 12; return y + '-' + pad(mo + 1); }
  var MON3 = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  var MONF = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  function dShort(iso) { return isDay(iso) ? +iso.slice(8, 10) + ' ' + MON3[+iso.slice(5, 7) - 1] : ''; }
  function mWord(m) { return MONF[+m.slice(5, 7) - 1] + ' ' + m.slice(0, 4); }
  function mShort(m) { return MON3[+m.slice(5, 7) - 1]; }
  function words(list) { return list.length < 2 ? list.join('') : list.slice(0, -1).join(', ') + ' and ' + list[list.length - 1]; }
  var NUMW = ['no', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten'];
  function numw(n) { return NUMW[n] || String(n); }
  function capFirst(s) { return s ? s.charAt(0).toUpperCase() + s.slice(1) : s; }
  /** "₹3.6 lakh", "₹1.25 crore": a big figure the way people say it; smaller ones in full */
  function lakh(n) {
    var a = Math.abs(+n || 0);
    if (a >= 1e7) return '₹' + String(Math.round(a / 1e5) / 100).replace(/\.0+$/, '') + ' crore';
    if (a >= 1e5) return '₹' + String(Math.round(a / 1e4) / 10).replace(/\.0$/, '') + ' lakh';
    return inr(a);
  }
  /** "a month", "every six months": how often a charge comes, said; nothing when kosh doesn't know */
  function everyPhrase(every) { return every === 'month' ? 'a month' : every === 'year' ? 'a year' : every === 'quarter' ? 'a quarter' : every === 'week' ? 'a week' : every === 'six months' ? 'every six months' : ''; }
  function owns(who, owner) { return !who || who === 'all' || (owner || 'me') === who; }
  /** "3 Feb", or "3 Feb 2025" when it isn't this year */
  function dWhen(iso, today) { return dShort(iso) + (isDay(iso) && iso.slice(0, 4) !== String(today || '').slice(0, 4) ? ' ' + iso.slice(0, 4) : ''); }
  function isOut(t) { return t.dirRaw ? t.dirRaw === 'out' : (t.k === 'out' || t.k === 'invest' || t.k === 'move' || t.k === 'cardpay'); }
  function isIn(t) { return t.dirRaw ? t.dirRaw === 'in' : t.k === 'in'; }
  function byDayId(a, b) { return String(a.d).localeCompare(String(b.d)) || String(a.id).localeCompare(String(b.id)); }

  /* ================================================================ 1. goals
     Saved is the sum of what the goal counts: bank accounts at their latest balance, holdings at their latest value,
     a whole kind (every bank account, every deposit...), and what you said you have elsewhere. How fast it's growing
     comes from net worth month by month (snap.worth), by kind: exact when the goal counts whole kinds, a hint when it
     counts some accounts of a kind (said so), unknown for money kosh can't see move. */
  var EMERGENCY_MONTHS = 6;
  // a balance older than this (a month) is left out of a whole kind and flagged where you picked the account
  var STALE_DAYS = 30;
  var KINDS = { bank: 'every bank account', dep: 'every deposit', mf: 'every mutual fund', stk: 'every share', ret: 'EPF, PPF and NPS', gold: 'gold', ins: 'insurance savings' };
  var KINDS_ALL = { bank: 'bank balances', dep: 'deposits', mf: 'mutual funds', stk: 'shares', ret: 'EPF, PPF and NPS', gold: 'gold', ins: 'insurance savings' };

  function acctName(a) { return (a.name || a.bank || 'Account') + (a.last ? ' ••' + String(a.last).slice(-4) : ''); }
  function findAcct(snap, id) { return (snap.accounts || []).filter(function (a) { return a.id === id || (a.keys || []).indexOf(id) >= 0; })[0] || null; }
  function holdId(h) { return String(h.bank || '') + String(h.person || ''); }

  /** what one of a goal's sources holds now, and the money it is (ids: which accounts and holdings, to see two goals
      counting the same money) */
  function source(ref, snap, who, today) {
    var t = String(ref || '').slice(0, 2), id = String(ref || '').slice(2);
    var old = isDay(today) ? addDays(today, -STALE_DAYS) : '';
    if (t === 'a:') {
      var a = findAcct(snap, id);
      if (!a) return { ref: ref, name: 'An account kosh no longer sees', amt: 0, asOf: '', gone: true, cls: 'bank', ids: [] };
      var o = { ref: ref, name: acctName(a), amt: a.balance != null && isFinite(+a.balance) ? Math.max(0, +a.balance) : 0, asOf: a.asOf || '', none: a.balance == null, cls: 'bank', ids: ['a:' + a.id] };
      // (counted as you picked it, and said to be old)
      if (a.balance != null && a.asOf && old && a.asOf < old) o.old = true;
      return o;
    }
    if (t === 'h:') {
      var h = (snap.hold || []).filter(function (x) { return holdId(x) === id; })[0];
      if (!h) return { ref: ref, name: 'A holding kosh no longer sees', amt: 0, asOf: '', gone: true, cls: '', ids: [] };
      return { ref: ref, name: h.bank, amt: Math.max(0, +h.amt || 0), asOf: h.asOf || '', cls: h.cls || '', ids: ['h:' + holdId(h)], holds: [h] };
    }
    if (t === 'c:') {
      if (id === 'bank') {
        // every bank account with a balance from the last month; an older one is left out, and said so
        var ac = (snap.accounts || []).filter(function (x) { return x.kind !== 'wallet' && x.balance != null && isFinite(+x.balance) && owns(who, x.owner); });
        var fresh = ac.filter(function (x) { return !(old && x.asOf && x.asOf < old); });
        var stale = ac.filter(function (x) { return fresh.indexOf(x) < 0; }).sort(function (x, y) { return acctName(x).localeCompare(acctName(y)); });
        var asOf = fresh.map(function (x) { return x.asOf || ''; }).filter(Boolean).sort()[0] || '';
        var c = { ref: ref, name: capFirst(KINDS.bank), amt: sum(fresh, function (x) { return Math.max(0, +x.balance); }), asOf: asOf, n: fresh.length, cls: 'bank', whole: true,
                  ids: fresh.map(function (x) { return 'a:' + x.id; }) };
        if (stale.length) {
          c.left = stale.map(function (x) { return { name: acctName(x), asOf: x.asOf }; });
          c.note = 'Leaves out ' + words(stale.map(function (x) { return acctName(x) + ' (its balance is from ' + dWhen(x.asOf, today) + ')'; })) + '.';
        }
        return c;
      }
      var hs = (snap.hold || []).filter(function (x) { return x.cls === id && owns(who, x.person); });
      return { ref: ref, name: capFirst(KINDS[id] || id), amt: sum(hs, function (x) { return Math.max(0, +x.amt || 0); }), asOf: '', n: hs.length, cls: id, whole: true,
               ids: hs.map(function (x) { return 'h:' + holdId(x); }), holds: hs };
    }
    return null;
  }

  /** how fast these kinds have grown a month, over the last three whole months of net worth (snap.worth), or null.
      This month's row is today's money, halfway through a month (a salary in, the rent not yet out): only months that
      are over count. moved: whether the money changed at all (a kind kosh has one reading of is carried flat) */
  function kindPace(snap, kinds, who, today) {
    var cur = String(today || '').slice(0, 7);
    // person by person, so money that only appears lately (an account kosh found last month) isn't taken for growth
    var byO = {}, all = {};
    (snap.worth || []).forEach(function (r) {
      if (!r || !r.m || (cur && r.m >= cur) || !owns(who, r.o)) return;
      var v = 0; kinds.forEach(function (k) { v += +((r.v || {})[k]) || 0; });
      var o = r.o || 'me';
      byO[o] = byO[o] || {};
      byO[o][r.m] = (byO[o][r.m] || 0) + v;
      all[r.m] = 1;
    });
    var ms = Object.keys(all).sort();
    if (ms.length < 3) return null;
    var now = ms[ms.length - 1], from = addMonthsM(now, -3), base = null;
    for (var i = ms.length - 2; i >= 0; i--) if (ms[i] <= from) { base = ms[i]; break; }
    if (!base) base = ms[0];
    var months = Math.max(1, (+now.slice(0, 4) - +base.slice(0, 4)) * 12 + (+now.slice(5, 7) - +base.slice(5, 7)));
    if (months < 2) return null;
    var change = 0, any = false, moved = false;
    Object.keys(byO).sort().forEach(function (o) {
      var s = byO[o];
      if (s[now] === undefined || s[base] === undefined) return;
      change += s[now] - s[base]; any = true;
      ms.forEach(function (m) { if (m >= base && m <= now && s[m] !== undefined && Math.abs(s[m] - s[base]) >= 1) moved = true; });
    });
    return any ? { v: change / months, months: months, from: base, to: now, moved: moved } : null;
  }

  /** how fast a goal's money has grown a month, kind by kind. Bank money from net worth's month ends (the last three
      whole months). A fund or a share from its own values, the statement's and today's at the latest price: net worth
      carries a statement's value flat until the next one. A deposit, EPF or gold from net worth, when it moves there.
      null when kosh can't see some of it move (one reading, carried flat; a source it no longer sees). own: the goal
      counts its kinds whole, or the holdings themselves, not some accounts of a kind */
  function goalPace(srcs, snap, who, today) {
    if (!srcs.length || srcs.some(function (x) { return !x.cls || x.gone; })) return null;
    var parts = [], own = true, kinds = [];
    srcs.forEach(function (x) { if (kinds.indexOf(x.cls) < 0) kinds.push(x.cls); });
    for (var i = 0; i < kinds.length; i++) {
      var k = kinds[i], ks = srcs.filter(function (x) { return x.cls === k; });
      if (k === 'bank') {
        var b = kindPace(snap, ['bank'], who, today);
        if (!b) return null;
        if (!ks.every(function (x) { return x.whole; })) own = false;
        parts.push({ k: k, v: b.v, months: b.months });
        continue;
      }
      var hs = [];
      ks.forEach(function (x) { (x.holds || []).forEach(function (h) { if (hs.indexOf(h) < 0) hs.push(h); }); });
      var dated = hs.length && hs.every(function (h) { return +h.stAmt > 0 && isDay(h.stAsOf) && isDay(h.asOf) && daysBetween(h.stAsOf, h.asOf) >= 28; });
      if (dated) {
        var v = sum(hs, function (h) { return (+h.amt - +h.stAmt) / (daysBetween(h.stAsOf, h.asOf) / 30.44); });
        parts.push({ k: k, v: v, since: hs.map(function (h) { return h.stAsOf; }).sort()[0], change: sum(hs, function (h) { return +h.amt - +h.stAmt; }) });
        continue;
      }
      var w = kindPace(snap, [k], who, today);
      if (!w || !w.moved) return null;
      // (net worth has the whole kind: one holding of it gets only a hint)
      if (!ks.every(function (x) { return x.whole; })) own = false;
      parts.push({ k: k, v: w.v, months: w.months });
    }
    return parts.length ? { v: sum(parts, function (p) { return p.v; }), parts: parts, own: own } : null;
  }
  /** "It grew about ₹10,000 a month over the last three months.", "It grew ₹20,000 since 31 Aug, about ₹16,024 a month." */
  function paceSaid(pace, mine, today) {
    var ps = pace.parts, v = r0(pace.v);
    function span(p) { return p.since ? ' since ' + dWhen(p.since, today) : ' over the last ' + numw(p.months) + ' months'; }
    function signed(n) { return (r0(n) < 0 ? 'down ' : '') + inr(n) + ' a month'; }
    if (ps.length === 1) {
      var p = ps[0];
      if (!mine) {
        var kw = 'Your ' + (KINDS_ALL[p.k] || p.k) + ' as a whole';
        return v > 0 ? kw + ' grew about ' + inr(p.v) + ' a month' + span(p) + '; kosh can’t tell how much of that is for this goal.'
          : v < 0 ? kw + ' went down about ' + inr(-p.v) + ' a month' + span(p) + '.' : kw + ' stayed about the same' + span(p) + '.';
      }
      if (p.since) return r0(p.change) > 0 ? 'It grew ' + inr(p.change) + span(p) + ', about ' + inr(p.v) + ' a month.'
        : r0(p.change) < 0 ? 'It went down ' + inr(-p.change) + span(p) + ', about ' + inr(-p.v) + ' a month.' : 'It hasn’t moved' + span(p) + '.';
      return v > 0 ? 'It grew about ' + inr(p.v) + ' a month' + span(p) + '.' : v < 0 ? 'It went down about ' + inr(-p.v) + ' a month' + span(p) + '.' : 'It hasn’t moved' + span(p) + '.';
    }
    var each = ps.map(function (p) { return (KINDS_ALL[p.k] || p.k) + ' ' + signed(p.v) + span(p); });
    var lead = v > 0 ? 'It grew about ' + inr(v) + ' a month lately' : v < 0 ? 'It went down about ' + inr(-v) + ' a month lately' : 'It hasn’t moved lately';
    return lead + ': ' + words(each) + '.' + (mine ? '' : ' kosh can’t tell how much of that is for this goal.');
  }

  /** what goes out in a usual month: the middle of the last three whole months' money out (a month the mail starts
      partway through, or this one, is no whole month), else the usual month's spending */
  function usualOut(snap, scanFrom, today) {
    var cur = String(today || '').slice(0, 7), sf = isDay(scanFrom) ? scanFrom : '';
    var cf = (snap.cashflow || []).filter(function (c) {
      return c && !c.live && +c.out > 0 && (!cur || c.m < cur) && (!sf || c.m > sf.slice(0, 7) || sf.slice(8, 10) === '01');
    }).slice(-3);
    if (cf.length) return { v: median(cf.map(function (c) { return +c.out; })), months: cf.map(function (c) { return c.m; }), how: 'cashflow' };
    var u = +((snap.fc || {}).usual) || 0;
    return u > 0 ? { v: u, months: [], how: 'usual' } : null;
  }

  function goal(g, snap, today, suggestion) {
    var who = g.who || 'all';
    var srcs = (g.sources || []).map(function (ref) { return source(ref, snap, who, today); }).filter(Boolean);
    var manual = Math.max(0, +g.manual || 0);
    var saved = sum(srcs, function (x) { return x.amt; }) + manual;
    var auto = g.kind === 'emergency' && !(+g.target > 0);
    var target = auto ? (suggestion ? suggestion.target : 0) : Math.max(0, +g.target || 0);
    var left = Math.max(0, target - saved);
    var pct = target > 0 ? Math.min(100, Math.floor(saved / target * 100)) : 0;
    var out = { id: String(g.id || ''), name: String(g.name || (g.kind === 'emergency' ? 'Emergency fund' : 'Goal')), kind: g.kind === 'emergency' ? 'emergency' : 'custom',
      target: r0(target), by: isDay(g.by) ? g.by : '', who: who, saved: r0(saved), pct: pct, left: r0(left), auto: auto,
      manual: r0(manual), sources: srcs.map(function (x) {
        var o = { ref: x.ref, name: x.name, amt: r0(x.amt) };
        if (x.asOf) o.asOf = x.asOf; if (x.gone) o.gone = true; if (x.none) o.none = true; if (x.old) o.old = true; if (x.note) o.note = x.note;
        return o;
      }),
      perMonth: 0, months: 0, state: 'open', pace: 0, paceOf: '', eta: '', note: '' };
    // (the money each source is, for build() to see two goals counting the same; not in the snapshot)
    Object.defineProperty(out, '_ids', { value: srcs.map(function (x) { return x.ids || []; }), enumerable: false });
    // an account you picked whose balance kosh hasn't heard of in a month: counted, and said
    var olds = srcs.filter(function (x) { return x.old; });
    var oldWords = olds.length ? ' kosh’s latest balance for ' + words(olds.map(function (x) { return x.name; })) + ' is from ' + words(olds.map(function (x) { return dWhen(x.asOf, today); })) + '; it may have changed.' : '';
    if (!(target > 0)) { out.state = 'open'; out.note = auto ? 'kosh will suggest a figure once it has seen a few months of your spending.' : 'Set how much this goal needs.'; return out; }
    if (saved >= target) { out.state = 'done'; out.note = 'Done: ' + inr(saved) + ' against ' + inr(target) + '.' + oldWords; return out; }
    // how fast it's growing, from the money's own values (goalPace), never what kosh can't see move. The goal's own money
    // (whole kinds, the holdings themselves, nothing you said is elsewhere) or only a hint from its kinds as a whole: the
    // state and the month it gets there come from its own money alone
    var pace = goalPace(srcs, snap, who, today);
    if (pace) { out.pace = r0(pace.v); out.paceOf = pace.own && !manual ? 'goal' : 'kind'; }
    var mine = out.paceOf === 'goal';
    var paceWords = pace ? paceSaid(pace, mine, today) : '';
    if (out.by) {
      var days = daysBetween(today, out.by);
      if (days < 0) { out.state = 'late'; out.note = 'The date has passed with ' + inr(left) + ' still to go.' + oldWords; return out; }
      var months = days / 30.44, when = dWhen(out.by, today);
      out.months = Math.round(months * 10) / 10;
      if (months < 1) {
        // under a month to go: what's left is what it needs, not a monthly rate of it
        out.perMonth = r0(left);
        if (mine) out.state = pace.v * months >= left * 0.95 ? 'on' : 'behind';
        out.note = inr(left) + ' still to go' + (days === 0 ? ', and the date is today.' : ' by ' + when + '.') + (paceWords ? ' ' + paceWords : '');
      } else {
        out.perMonth = r0(Math.ceil(left / months / 100) * 100);
        if (mine) out.state = pace.v >= out.perMonth * 0.95 ? 'on' : 'behind';
        out.note = inr(out.perMonth) + ' a month gets there by ' + when + '. ' + (paceWords || 'kosh can’t see this money move yet, so it can’t say whether you’re on pace.');
      }
    } else {
      if (mine && pace.v > 0) {
        var n = Math.ceil(left / pace.v);
        if (n <= 120) out.eta = addMonthsM(today.slice(0, 7), n);
      }
      out.note = (paceWords || 'kosh can’t see this money move yet, so it can’t say how fast it’s growing.') + (out.eta ? ' At that pace, about ' + mWord(out.eta) + '.' : '');
    }
    out.note += oldWords;
    return out;
  }

  /** money two goals both count (every bank account in one, an account of it in another) is counted in each: said on
      the source and in the goal's note */
  function shared(goals) {
    goals.forEach(function (go, i) {
      var others = [];
      go.sources.forEach(function (s, j) {
        var mine = (go._ids || [])[j] || [];
        if (!mine.length) return;
        var sh = [];
        goals.forEach(function (g2, k) {
          if (k === i || sh.indexOf(g2.name) >= 0) return;
          if ((g2._ids || []).some(function (list) { return list.some(function (id) { return mine.indexOf(id) >= 0; }); })) sh.push(g2.name);
        });
        if (sh.length) { s.shared = sh; sh.forEach(function (x) { if (others.indexOf(x) < 0) others.push(x); }); }
      });
      if (others.length) go.note = (go.note ? go.note + ' ' : '') + 'Some of this money also counts toward ' + words(others) + ', so the goals share it.';
    });
  }

  function suggestEmergency(snap, cfg, today, scanFrom) {
    var u = usualOut(snap, scanFrom, today);
    if (!u || !(u.v > 0)) return null;
    var target = Math.ceil(u.v * EMERGENCY_MONTHS / 10000) * 10000;
    // (fewer than three whole months seen so far: said, as the figure may move)
    var n = u.months.length;
    var basis = n >= 3 ? 'the middle of ' + words(u.months.map(mShort))
      : n === 2 ? 'the average of ' + words(u.months.map(function (m) { return MONF[+m.slice(5, 7) - 1]; })) + ', the two whole months kosh has seen so far'
      : MONF[+u.months[0].slice(5, 7) - 1] + ', the one whole month kosh has seen so far';
    var how = u.how === 'cashflow'
      ? 'About ' + inr(u.v) + ' goes out in a usual month (' + basis + '); six months of that is ' + lakh(target) + '.'
      : 'Your usual month is about ' + inr(u.v) + '; six months of that is ' + lakh(target) + '.';
    // what's in the bank towards it: balances from the last month (an older one is left out, and said)
    var bank = source('c:bank', snap, 'all', today);
    var have = bank ? bank.amt : 0;
    var leftOut = bank && bank.left ? ' What’s in the bank leaves out ' + words(bank.left.map(function (x) { return x.name; })) + ': ' + (bank.left.length === 1 ? 'its balance is' : 'their balances are') + ' more than a month old.' : '';
    return { kind: 'emergency', name: 'Emergency fund', target: target, months: EMERGENCY_MONTHS, monthly: r0(u.v), how: how + leftOut,
             saved: r0(have), pct: target > 0 ? Math.min(100, Math.floor(have / target * 100)) : 0, sources: ['c:bank'] };
  }

  /* ================================================================ 2. the salary split
     The split you set, laid against the latest salary: from the day it landed, each part ticks off as a payment that
     matches it goes out (your words first, then SIPs, PPF, rent, money moved out of the salary's account to another of
     yours or into an FD), each payment used once; a payment that came back (reversed, refunded within days) counts for
     nothing; spending is measured, not matched. Salaries within a week of each other count together, and say so: two
     earners, two employers, one paid on the last working day of the month before. A split set for one person counts
     only their salary and their payments. Payments are matched, and the split shown on Home, for twenty days. */
  var SPLIT_KINDS = ['sip', 'ppf', 'rent', 'savings', 'spending', 'other'];
  var SPLIT_DAYS = 20;
  function wordsOf(s) { return String(s || '').split(/[,;\n]+/).map(function (w) { return lc(w).trim(); }).filter(function (w) { return w.length >= 2; }); }
  function hay(t) { return lc([t.m, t.n, t.s, t.c].join(' ')); }
  function fits(kind, t, salAccts) {
    var h = hay(t);
    if (kind === 'sip') return t.k === 'invest' && t.s !== 'PPF' && t.s !== 'FD' && t.s !== 'Chit fund' && !/\bppf\b|public provident/.test(h);
    if (kind === 'ppf') return t.s === 'PPF' || /\bppf\b|public provident|sukanya/.test(h);
    if (kind === 'rent') return (t.c === 'Home' && t.s === 'Rent') || /\brent\b/.test(h);
    // (money moved into the salary's account from savings is the opposite of saving)
    if (kind === 'savings') return (t.c === 'Self Transfer' && (!t.card || !salAccts || !Object.keys(salAccts).length || !!salAccts[t.card])) || (t.k === 'invest' && t.s === 'FD');
    return false;
  }
  /** payments that came back: a reversal or refund of the same sum to the same account within three days, each used once */
  function cameBack(tx) {
    var back = tx.filter(function (t) { return isIn(t) && (t.c === 'Refund' || /\b(?:revers(?:al|ed)|refund(?:ed)?)\b/.test(lc([t.m, t.n, t.py].join(' ')))); }).sort(byDayId);
    var used = {}, gone = {};
    tx.filter(isOut).sort(byDayId).forEach(function (t) {
      if (t.refunded) { gone[t.id] = 1; return; }
      var b = back.filter(function (x) { return !used[x.id] && Math.abs(+x.a - +t.a) <= 1 && (!t.card || !x.card || x.card === t.card) && x.d >= t.d && daysBetween(t.d, x.d) <= 3; })[0];
      if (b) { used[b.id] = 1; gone[t.id] = 1; }
    });
    return gone;
  }
  function split(snap, cfg, today) {
    var sc = cfg.split || {};
    var parts = (sc.parts || []).filter(function (p) { return p && SPLIT_KINDS.indexOf(p.kind) >= 0 && +p.amt > 0; });
    if (!parts.length) return null;
    var who = sc.who || '';
    var tx = snap.tx || [];
    var sal = tx.filter(function (t) { return t.k === 'in' && t.c === 'Salary' && +t.a >= 5000 && owns(who, t.o) && t.d <= today; }).sort(byDayId);
    var planned = sum(parts, function (p) { return +p.amt; });
    var base = { parts: parts.map(function (p) { return { id: String(p.id || ''), name: String(p.name || ''), kind: p.kind, amt: r0(p.amt), paid: 0, state: 'waiting', ids: [] }; }), planned: r0(planned) };
    if (!sal.length) return Object.assign(base, { state: 'nosalary', amt: 0, date: '', from: [], left: 0, open: false, note: 'kosh hasn’t seen a salary come in yet. The split starts the day one does.' });
    // the salary it runs from: the latest that's a salary in its own right (a small extra after it, a bonus or a
    // reimbursement filed as salary, doesn't start the split again), with those within a week of it
    var lastD = sal[sal.length - 1].d, big = 0;
    sal.forEach(function (t) { if (daysBetween(t.d, lastD) <= 45) big = Math.max(big, +t.a); });
    var anchor = sal[sal.length - 1];
    for (var i = sal.length - 1; i >= 0; i--) if (+sal[i].a >= big * 0.5) { anchor = sal[i]; break; }
    var got = sal.filter(function (t) { return Math.abs(daysBetween(t.d, anchor.d)) <= 7; });
    var start = got[0].d;
    var amt = sum(got, function (t) { return +t.a; });
    var payers = [], salAccts = {};
    got.forEach(function (t) { if (payers.indexOf(t.m) < 0) payers.push(t.m); if (t.card) salAccts[t.card] = 1; });
    var from = addDays(start, -1), to = addDays(start, SPLIT_DAYS);
    var gone = cameBack(tx);
    // each payment out in the window (of the split's person), used once: parts with your words first, then by kind
    var used = {};
    var cands = tx.filter(function (t) { return t.d >= from && t.d <= to && t.d <= today && !t.ex && !gone[t.id] && owns(who, t.o) && isOut(t) && (t.k === 'out' || t.k === 'invest' || t.k === 'move'); })
      .sort(byDayId);
    // spending is measured last, from what the other parts didn't take
    var order = base.parts.map(function (p, i) { return i; }).sort(function (a, b) {
      var sa = parts[a].kind === 'spending' ? 1 : 0, sb = parts[b].kind === 'spending' ? 1 : 0;
      var wa = wordsOf(parts[a].words).length ? 0 : 1, wb = wordsOf(parts[b].words).length ? 0 : 1;
      return sa - sb || wa - wb || SPLIT_KINDS.indexOf(parts[a].kind) - SPLIT_KINDS.indexOf(parts[b].kind) || a - b;
    });
    order.forEach(function (i) {
      var p = parts[i], o = base.parts[i], ws = wordsOf(p.words);
      if (p.kind === 'spending') {
        var sp = tx.filter(function (t) { return t.d >= start && t.d <= today && t.sp && t.k === 'out' && !t.ex && !gone[t.id] && !used[t.id] && owns(who, t.o); });
        o.paid = r0(sum(sp, function (t) { return +t.a; }));
        o.state = o.paid > o.amt ? 'over' : 'spending';
        return;
      }
      var want = +p.amt, paid = 0;
      cands.forEach(function (t) {
        if (used[t.id] || paid >= want * 0.95) return;
        var ok = ws.length ? ws.some(function (w) { return hay(t).indexOf(w) >= 0; }) : fits(p.kind, t, salAccts);
        if (!ok) return;
        used[t.id] = 1; paid += +t.a; o.ids.push(t.id); o.date = t.d;
      });
      o.paid = r0(paid);
      o.state = paid >= want * 0.95 ? 'done' : paid > 0 ? 'part' : 'waiting';
    });
    var doneN = base.parts.filter(function (o) { return o.state === 'done'; }).length;
    var matchable = base.parts.filter(function (o) { return o.kind !== 'spending'; }).length;
    var days = daysBetween(start, today);
    var note = got.length > 1 ? capFirst(numw(got.length)) + ' salaries, counted together: ' + got.map(function (t) { return inr(t.a) + ' from ' + t.m + ' on ' + dShort(t.d); }).join(' and ') + '.' : '';
    if (planned > amt) note = (note ? note + ' ' : '') + 'The split comes to ' + inr(planned) + ', ' + inr(planned - amt) + ' more than the salary.';
    return Object.assign(base, { state: matchable && doneN === matchable ? 'done' : 'running', amt: r0(amt), date: start, from: payers, month: start.slice(0, 7), left: r0(amt - planned),
      open: days >= 0 && days <= SPLIT_DAYS, note: note });
  }

  /* ================================================================ 3. a low balance before an auto-debit
     For each bank account whose balance kosh has from the last ten days: what's due from it in the next five (the
     calendar knows the account when the mail or the last payment said: agenda.acct), against that balance. One
     payment told twice (the bank's pre-debit notice and the lender's own mail, a repeat kosh learnt beside the mail's
     bill) counts once. Only an auto-debit (NACH, an SI: agenda.auto) bounces; a payment you make yourself from there
     (rent by UPI, learnt from your spending) is a reminder to keep the money there, not an alarm. */
  function fundLike(n) { return /\b(?:fund|scheme|sip|growth|direct)\b/i.test(String(n || '')); }
  function lowBalance(snap, today) {
    var out = [];
    var soon = addDays(today, 5), fresh = addDays(today, -10);
    var due = (snap.agenda || []).filter(function (a) { return a && a.kind === 'out' && !a.booked && !a.marked && !a.trial && a.acct && a.date && a.date >= today && a.date <= soon && +a.amt > 0; });
    var byAcct = {};
    due.forEach(function (a) { (byAcct[a.acct] = byAcct[a.acct] || []).push(a); });
    Object.keys(byAcct).sort().forEach(function (id) {
      var acc = findAcct(snap, id);
      if (!acc || acc.balance == null || !isFinite(+acc.balance) || !acc.asOf || acc.asOf < fresh) return;
      // the mail's bills before what kosh learnt, then by name: the line kept of two that are one payment
      var items = byAcct[id].slice().sort(function (a, b) { return a.date.localeCompare(b.date) || (a.learnt ? 1 : 0) - (b.learnt ? 1 : 0) || String(a.name).localeCompare(String(b.name)) || (+a.amt - +b.amt); });
      var kept = [];
      items.forEach(function (a) {
        var twin = kept.filter(function (o) {
          if (Math.abs(+o.amt - +a.amt) > Math.max(1, +a.amt * 0.01) || (o.learnt && a.learnt)) return false;
          // (two funds' SIPs of one sum on one day are two)
          if (!o.learnt && !a.learnt) return o.date === a.date && !(fundLike(o.name) && fundLike(a.name) && lc(o.name) !== lc(a.name));
          return Math.abs(daysBetween(o.date, a.date)) <= 3;
        })[0];
        if (!twin) { kept.push(a); return; }
        if (twin.learnt && !a.learnt) kept[kept.indexOf(twin)] = a;
      });
      kept.sort(function (a, b) { return a.date.localeCompare(b.date) || String(a.name).localeCompare(String(b.name)); });
      var total = sum(kept, function (a) { return +a.amt; }), bal = +acc.balance;
      if (total <= bal) return;
      var autoTotal = sum(kept.filter(function (a) { return a.auto; }), function (a) { return +a.amt; });
      out.push({ acct: acc.id, name: acctName(acc), bank: acc.bank || '', balance: r0(bal), asOf: acc.asOf, total: r0(total), short: r0(total - bal),
                 // the auto-debits alone are more than is there: something bounces
                 bounce: autoTotal > bal,
                 first: kept[0].date, last: kept[kept.length - 1].date,
                 due: kept.map(function (a) { var d = { name: a.name, date: a.date, amt: r0(a.amt) }; if (a.auto) d.auto = true; if (a.learnt) d.learnt = true; return d; }) });
    });
    return out.sort(function (a, b) { return a.first.localeCompare(b.first) || a.acct.localeCompare(b.acct); });
  }

  /* ================================================================ 4. subscriptions
     Each repeat that's a subscription, the service it is (a curated list: what it covers, what it bundles, how it's
     cancelled), two or more doing one job, and free trials about to turn into a charge. A service is named by its
     payee's words; one kosh doesn't know stays a subscription with a drafted cancellation mail. */
  var FAMILIES = {
    music: { name: 'music', sym: 'music.note', sev: 2 },
    video: { name: 'film and TV', sym: 'play.tv', sev: 1 },
    storage: { name: 'cloud storage', sym: 'icloud', sev: 2 },
    news: { name: 'news', sym: 'newspaper', sev: 1 },
    food: { name: 'food delivery', sym: 'takeoutbag.and.cup.and.straw', sev: 2 },
    shopping: { name: 'shopping', sym: 'bag', sev: 1 },
    fitness: { name: 'fitness', sym: 'figure.run', sev: 1 },
    ai: { name: 'AI assistant', sym: 'sparkles', sev: 1 },
  };
  // fam: what it's for (counts toward two-doing-one-job); also: what it bundles (named, never counted against you);
  // how: 'appstore' (cancelled in the iPhone's settings), 'web' (its own account page); url: that page
  var SERVICES = [
    { id: 'appleone', name: 'Apple One', re: /\bapple ?one\b/, fam: ['music', 'video', 'storage'], also: 'Apple Music, Apple TV+ and iCloud+', how: 'appstore' },
    { id: 'applemusic', name: 'Apple Music', re: /\bapple ?music\b/, fam: ['music'], how: 'appstore' },
    { id: 'appletv', name: 'Apple TV+', re: /\bapple ?tv\b/, fam: ['video'], how: 'appstore' },
    { id: 'icloud', name: 'iCloud+', re: /\bicloud\b/, fam: ['storage'], how: 'appstore' },
    { id: 'fitnessplus', name: 'Apple Fitness+', re: /\bfitness ?\+|\bapple fitness\b/, fam: ['fitness'], how: 'appstore' },
    { id: 'ytpremium', name: 'YouTube Premium', re: /\byou ?tube ?(?:premium|prem\b)|\byoutubepremium\b/, fam: ['music'], also: 'YouTube Music and ad-free YouTube', how: 'web', url: 'https://www.youtube.com/paid_memberships' },
    { id: 'ytmusic', name: 'YouTube Music', re: /\byou ?tube ?music\b/, fam: ['music'], how: 'web', url: 'https://www.youtube.com/paid_memberships' },
    { id: 'spotify', name: 'Spotify', re: /\bspotify\b/, fam: ['music'], how: 'web', url: 'https://www.spotify.com/account/', where: 'Account › Your plan › Cancel' },
    { id: 'jiosaavn', name: 'JioSaavn', re: /\b(?:jio ?)?saavn\b/, fam: ['music'], how: 'web' },
    { id: 'gaana', name: 'Gaana', re: /\bgaana\b/, fam: ['music'], how: 'web' },
    { id: 'wynk', name: 'Wynk Music', re: /\bwynk\b/, fam: ['music'], how: 'web' },
    { id: 'amazonmusic', name: 'Amazon Music Unlimited', re: /\bamazon ?music ?unlimited\b/, fam: ['music'], how: 'web' },
    { id: 'netflix', name: 'Netflix', re: /\bnetflix\b/, fam: ['video'], how: 'web', url: 'https://www.netflix.com/cancelplan' },
    // (a membership that says "prime" but isn't Amazon's comes first: the first that fits names it)
    { id: 'timesprime', name: 'Times Prime', re: /\btimes ?prime\b/, fam: ['shopping'], how: 'web' },
    { id: 'etprime', name: 'ET Prime', re: /\bet ?prime\b|\beconomic times\b/, fam: ['news'], how: 'web' },
    { id: 'prime', name: 'Amazon Prime', re: /\bamazon ?prime\b|\bprime ?(?:membership|video)\b|\bprimevideo\b/, fam: ['shopping'], also: 'Prime Video and Amazon Music', how: 'web', url: 'https://www.amazon.in/gp/primecentral' },
    { id: 'hotstar', name: 'JioHotstar', re: /\b(?:jio ?)?hotstar\b|\bjio ?cinema\b/, fam: ['video'], how: 'web' },
    { id: 'sonyliv', name: 'SonyLIV', re: /\bsony ?liv\b/, fam: ['video'], how: 'web' },
    { id: 'zee5', name: 'ZEE5', re: /\bzee ?5\b/, fam: ['video'], how: 'web' },
    { id: 'sunnxt', name: 'Sun NXT', re: /\bsun ?nxt\b/, fam: ['video'], how: 'web' },
    { id: 'hoichoi', name: 'hoichoi', re: /\bhoichoi\b/, fam: ['video'], how: 'web' },
    { id: 'aha', name: 'aha', re: /\baha ?(?:video|gold|premium)\b/, fam: ['video'], how: 'web' },
    { id: 'discovery', name: 'discovery+', re: /\bdiscovery ?(?:\+|plus)/, fam: ['video'], how: 'web' },
    { id: 'lionsgate', name: 'Lionsgate Play', re: /\blionsgate ?play\b/, fam: ['video'], how: 'web' },
    { id: 'googleone', name: 'Google One', re: /\bgoogle ?one\b|\bgoogle storage\b/, fam: ['storage'], how: 'web', url: 'https://one.google.com/settings' },
    { id: 'dropbox', name: 'Dropbox', re: /\bdropbox\b/, fam: ['storage'], how: 'web', url: 'https://www.dropbox.com/account/plan' },
    { id: 'm365', name: 'Microsoft 365', re: /\b(?:microsoft|office) ?365\b|\bonedrive\b/, fam: [], also: 'OneDrive storage', how: 'web', url: 'https://account.microsoft.com/services' },
    { id: 'swiggyone', name: 'Swiggy One', re: /\bswiggy ?one\b/, fam: ['food'], how: 'web' },
    { id: 'zomatogold', name: 'Zomato Gold', re: /\bzomato ?(?:gold|pro)\b/, fam: ['food'], how: 'web' },
    { id: 'flipkartblack', name: 'Flipkart Black', re: /\bflipkart ?(?:black|vip)\b/, fam: ['shopping'], how: 'web' },
    { id: 'cult', name: 'cult.fit', re: /\bcult ?(?:pass|\.?fit)\b|\bcurefit\b/, fam: ['fitness'], how: 'web' },
    { id: 'healthify', name: 'HealthifyMe', re: /\bhealthify/, fam: ['fitness'], how: 'web' },
    { id: 'fittr', name: 'Fittr', re: /\bfittr\b/, fam: ['fitness'], how: 'web' },
    { id: 'strava', name: 'Strava', re: /\bstrava\b/, fam: ['fitness'], how: 'web' },
    { id: 'chatgpt', name: 'ChatGPT', re: /\bchat ?gpt\b|\bopenai\b/, fam: ['ai'], how: 'web', where: 'chatgpt.com › Settings › Subscription' },
    { id: 'claude', name: 'Claude', re: /\bclaude\.ai\b|\banthropic\b|\bclaude (?:pro|max)\b/, fam: ['ai'], how: 'web', url: 'https://claude.ai/settings/billing' },
    { id: 'gemini', name: 'Google AI', re: /\bgemini\b|\bgoogle ai (?:pro|plus|ultra)\b/, fam: ['ai'], how: 'web', url: 'https://one.google.com/settings' },
    { id: 'perplexity', name: 'Perplexity', re: /\bperplexity\b/, fam: ['ai'], how: 'web' },
    { id: 'thehindu', name: 'The Hindu', re: /\bthe ?hindu\b/, fam: ['news'], how: 'web' },
    { id: 'toi', name: 'TOI+', re: /\btoi ?\+|\btimes of india\b/, fam: ['news'], how: 'web' },
    { id: 'ht', name: 'HT Premium', re: /\bhindustan times\b|\bht premium\b/, fam: ['news'], how: 'web' },
    { id: 'bs', name: 'Business Standard', re: /\bbusiness standard\b/, fam: ['news'], how: 'web' },
    { id: 'theken', name: 'The Ken', re: /\bthe ?ken\b/, fam: ['news'], how: 'web' },
    { id: 'nyt', name: 'The New York Times', re: /\bnew ?york ?times\b|\bnytimes\b/, fam: ['news'], how: 'web' },
  ];
  // the stores that sell other services' subscriptions: cancelled there, whatever the service
  var APPLE_BILLED = /\bapple(?:\.com\/bill| media services| services)\b|\bitunes\b|\bapp ?store\b/;
  var PLAY_BILLED = /\bgoogle ?play\b|\bplay ?store\b/;
  // a card line "GOOGLE *..." is Google's own billing: Play's for an app kosh doesn't know, the service's own page for
  // YouTube Premium or Google One
  var GOOGLE_STAR = /\bgoogle \*/;
  /** who bills it, from the mail's sender or the payee's words */
  function storeOf(from, text, sv) {
    var f = lc(from), h = lc(text);
    if (/(?:^|[@.])apple\.com$/.test(f) || APPLE_BILLED.test(h)) return 'appstore';
    if (/googleplay|play\.google\.com$/.test(f) || PLAY_BILLED.test(h) || (!sv && GOOGLE_STAR.test(h))) return 'playstore';
    return '';
  }
  /** whom the cancellation mail is signed by: the subscription's owner */
  function signer(prof, owner) {
    var ps = prof.people || [], o = owner || 'me';
    var p = ps.filter(function (x) { return x && x.id === o; })[0];
    if (p && (p.full || p.name)) return p.full || p.name;
    return o === 'me' ? (prof.name || '') : '';
  }

  function serviceOf(text) {
    var h = lc(text);
    for (var i = 0; i < SERVICES.length; i++) if (SERVICES[i].re.test(h)) return SERVICES[i];
    return null;
  }
  function everyOf(r) { return r.per === 12 ? 'year' : r.per === 6 ? 'six months' : r.per === 3 ? 'quarter' : 'month'; }

  /** how to cancel: where, the steps, and a drafted mail the person sends themselves (kosh never sends it) */
  function cancelHow(name, sv, billed, amount, every, next, who) {
    var steps = [], how = 'email', url = '';
    if (billed === 'appstore' || (sv && sv.how === 'appstore' && billed !== 'playstore')) {
      how = 'appstore'; url = 'https://apps.apple.com/account/subscriptions';
      steps = ['Open Settings on your iPhone and tap your name.', 'Tap Subscriptions, then ' + name + '.', 'Tap Cancel Subscription. It runs until the end of what you’ve paid for.'];
    } else if (billed === 'playstore') {
      how = 'playstore'; url = 'https://play.google.com/store/account/subscriptions';
      steps = ['Open the Google Play Store and tap your profile picture.', 'Tap Payments & subscriptions, then Subscriptions.', 'Choose ' + name + ' and tap Cancel subscription.'];
    } else if (sv && sv.how === 'web') {
      how = 'web'; url = sv.url || '';
      steps = sv.where ? ['Sign in to ' + name + '.', 'Go to ' + sv.where + '.']
        : url ? ['Sign in to ' + name + ' and open its subscription page (the link below).', 'Choose to cancel, or turn off auto-renew.']
        : ['Open the ' + name + ' app or website and go to your account’s subscription or membership.', 'Choose to cancel, or turn off auto-renew.'];
    } else {
      steps = ['Open the ' + name + ' app or website and look for your plan or membership under your account.', 'Cancel it there, or send them the mail below.'];
    }
    steps.push('If it’s paid by UPI Autopay, you can also stop the mandate in the UPI app you set it up in (under Autopay or Mandates), after cancelling.');
    var greet = who ? '\n\nThank you,\n' + who : '\n\nThank you';
    var mail = { to: '', subject: 'Please cancel my ' + name + ' subscription',
      body: 'Hello,\n\nPlease cancel my ' + name + ' subscription and stop any further charges.' +
        (amount > 0 ? ' It renews' + (isDay(next) ? ' around ' + dShort(next) : '') + ' for ' + inr(amount) + (everyPhrase(every) ? ' ' + everyPhrase(every) : '') + '.' : '') +
        ' The account is under this email address.\n\nPlease confirm by email once it is cancelled.' + greet };
    var o = { how: how, steps: steps, mail: mail };
    if (url) o.url = url;
    return o;
  }

  /** of two reminders for one trial: the newer mail; of one morning's, the one with a price, then a day, then the earlier
      day (cancel before the first it could charge), then the mail's id: never the order the mail came in */
  function betterTrial(a, b) {
    if (a.sent !== b.sent) return a.sent > b.sent;
    if ((a.amt > 0) !== (b.amt > 0)) return a.amt > 0;
    if (!!a.date !== !!b.date) return !!a.date;
    if (a.date !== b.date) return a.date < b.date;
    return a.rid < b.rid;
  }

  function subscriptions(snap, prof, records, today, cfg) {
    var subs = [];
    (snap.recurring || []).forEach(function (r) {
      if (!r || r.gone || r.lapsed) return;
      var text = [r.name, r.sub, r.cat].join(' ');
      var sv = serviceOf(text);
      if (!(r.kind === 'sub' || (sv && (r.cat === 'Subscriptions' || r.cat === 'Entertainment' || r.cat === 'Bills')))) return;
      // still going: last seen within its cycle and a fortnight
      if (r.last && daysBetween(r.last, today) > (r.per || 1) * 31 + 15) return;
      var billed = storeOf('', text, sv);
      var name = sv ? sv.name : r.name, every = everyOf(r), monthly = +r.amount / Math.max(1, r.per || 1);
      var o = { id: r.id, name: name, payee: r.name, amount: r0(r.amount), every: every, monthly: Math.round(monthly * 100) / 100, yearly: r0(monthly * 12),
                next: r.date || '', last: r.last || '', fam: sv ? sv.fam.slice() : [], cancel: cancelHow(name, sv, billed, +r.amount, every, r.date, signer(prof, r.o)) };
      if (sv) o.service = sv.id;
      if (sv && sv.also) o.also = sv.also;
      if (billed) o.billed = billed;
      subs.push(o);
    });
    subs.sort(function (a, b) { return a.name.localeCompare(b.name) || String(a.id).localeCompare(String(b.id)); });
    // two or more doing one job: by what each is for (a bundle's extras are named, never counted)
    var overlaps = [];
    Object.keys(FAMILIES).forEach(function (f) {
      var in_ = subs.filter(function (s) { return s.fam.indexOf(f) >= 0; });
      // one service told twice (two cards, two people) is a duplicate, not two services: kosh's "twice" check has those
      var seen = {}, uniq = [];
      in_.forEach(function (s) { var k = s.service || s.id; if (!seen[k]) { seen[k] = 1; uniq.push(s); } });
      if (uniq.length < 2) return;
      var monthly = sum(uniq, function (s) { return s.monthly; });
      overlaps.push({ fam: f, name: FAMILIES[f].name, sev: FAMILIES[f].sev, ids: uniq.map(function (s) { return s.id; }), names: uniq.map(function (s) { return s.name; }),
                      monthly: Math.round(monthly * 100) / 100, yearly: r0(monthly * 12) });
    });
    // free trials about to turn into a charge: the reader marks the reminder (mandate upcoming, trial)
    var inboxes = prof.inboxes || {};
    var trials = {}, done = {};
    (records || []).forEach(function (rec) {
      if (!rec || !rec.evs || rec.evs.indexOf('"mandate"') < 0) return;
      var evs; try { evs = JSON.parse(rec.evs); } catch (e) { return; }
      (evs || []).forEach(function (e) {
        if (!e || e.type !== 'mandate') return;
        var party = String(e.party || '').trim();
        if (!party) return;
        var key = lc(party).replace(/[^a-z0-9]+/g, '');
        // (the record's day is India's: the engine reads the mail's moment that way)
        var sent = String(rec.sent || rec.date || '').slice(0, 10);
        if (e.action === 'done' || e.action === 'cancelled') { if (!done[key] || sent > done[key]) done[key] = sent; return; }
        // a trial's reminder, or a subscription started on a trial ("1 month free trial · Renews 24 Oct")
        if ((e.action !== 'upcoming' && e.action !== 'created') || !e.trial) return;
        var date = isDay(e.date) ? e.date : '';
        if (date ? date < today : (!sent || daysBetween(sent, today) > 10)) return;
        var c = { key: key, party: party, amt: +e.amt > 0 ? +e.amt : 0, every: e.every || '', date: date, sent: sent, rid: String(rec.id || ''),
                  from: rec.from || '', owner: (rec.acct && inboxes[rec.acct]) || 'me' };
        if (trials[key] && !betterTrial(c, trials[key])) return;
        trials[key] = c;
      });
    });
    var cancelled = cfg.cancelled || {};
    var trialList = Object.keys(trials).map(function (k) { return trials[k]; })
      // charged or cancelled since the reminder (the service's mail, or you said so)
      .filter(function (t) { return !(done[t.key] && done[t.key] >= t.sent) && !(isDay(cancelled['trial|' + t.key]) && cancelled['trial|' + t.key] >= t.sent); })
      .map(function (t) {
        var sv = serviceOf(t.party), name = sv ? sv.name : t.party;
        var o = { id: 'trial|' + t.key, name: name, amt: r0(t.amt), every: t.every, date: t.date, sent: t.sent,
                  cancel: cancelHow(name, sv, storeOf(t.from, t.party, sv), t.amt, t.every, t.date, signer(prof, t.owner)) };
        if (sv) o.service = sv.id;
        return o;
      })
      .sort(function (a, b) { return (a.date || '9').localeCompare(b.date || '9') || a.name.localeCompare(b.name); });
    return { subs: subs, overlaps: overlaps, trials: trialList };
  }

  /* ================================================================ heads-ups, in what kosh noticed */
  function notices(plan, today) {
    var out = [];
    (plan.lowbal || []).forEach(function (l) {
      var one = l.due.length === 1, learnt = l.due.every(function (d) { return d.learnt; });
      // each payment, by when and how it goes (one alone needs no sum: the title has it)
      var list = l.due.map(function (d) {
        return d.name + (one ? '' : ' ' + inr(d.amt)) + (d.learnt ? ' around ' : ' on ') + dShort(d.date) + (d.auto ? ' by auto-debit' : d.learnt ? ', as you usually pay it' : '');
      });
      var asOf = l.asOf < today ? ' (The balance is from ' + dShort(l.asOf) + '.)' : '';
      out.push({ id: 'lowbal|' + l.acct + '|' + l.first, kind: 'lowbal', sev: l.bounce ? 3 : 2, sym: l.bounce ? 'exclamationmark.circle.fill' : 'banknote',
        title: inr(l.total) + (learnt ? ' usually goes out of ' : ' goes out of ') + l.name + ' by ' + dShort(l.last) + ', ' + inr(l.balance) + ' in it',
        detail: capFirst(words(list)) + '. ' + (l.bounce
          ? 'Move ' + inr(l.short) + ' in before ' + dShort(l.first) + ' so nothing bounces.'
          : 'Keep ' + inr(l.short) + ' more there' + (one ? ' for it, or pay it from another account.' : ' before ' + dShort(l.first) + ', or pay some from another account.')) + asOf,
        amt: l.short, date: l.first, rows: [], ask: 'What goes out of my ' + (l.bank || 'bank') + ' account in the next week?' });
    });
    ((plan.subs || {}).trials || []).forEach(function (t) {
      var soon = t.date && daysBetween(today, t.date) <= 2;
      var when = t.date ? ' on ' + dShort(t.date) : ' soon', ep = everyPhrase(t.every);
      out.push({ id: t.id + '|' + (t.date || t.sent), kind: 'trial', sev: soon ? 3 : 2, sym: 'hourglass',
        title: !(t.amt > 0) ? 'Your ' + t.name + ' free trial ends' + when
          : ep ? 'Your ' + t.name + ' trial turns into ' + inr(t.amt) + ' ' + ep + when
          : 'Your ' + t.name + ' trial ends' + when + ', then it charges ' + inr(t.amt),
        detail: 'If you don’t want it, cancel before then. kosh has the steps, and a cancellation mail ready to send.',
        amt: t.amt, date: t.date || t.sent, rows: [], reps: [t.id], ask: 'How do I cancel ' + t.name + '?' });
    });
    ((plan.subs || {}).overlaps || []).forEach(function (o) {
      var subs = (plan.subs.subs || []).filter(function (s) { return o.ids.indexOf(s.id) >= 0; });
      var n = o.names.length;
      out.push({ id: 'overlap|' + o.fam + '|' + o.ids.slice().sort().join(','), kind: 'overlap', sev: o.sev, sym: FAMILIES[o.fam].sym,
        title: capFirst(numw(n)) + ' ' + o.name + ' subscriptions: ' + words(o.names),
        detail: subs.map(function (s) { return s.name + ' ' + inr(s.amount) + (everyPhrase(s.every) ? ' ' + everyPhrase(s.every) : '') + (s.also ? ' (it includes ' + s.also + ')' : ''); }).join(', ') +
          '. Together ' + inr(o.yearly) + ' a year. If one does the job, ' + (n > 2 ? 'the others' : 'the other') + ' can go.',
        amt: o.yearly, date: today, rows: [], reps: o.ids.slice(), ask: 'Which subscriptions do I pay for, and what do they cost a year?' });
    });
    return out;
  }

  /** everything this module adds to the snapshot; each part on its own, so one that fails leaves the rest */
  function build(snap, prof, records) {
    snap = snap || {}; prof = prof || {};
    var cfg = prof.plan || {};
    var today = snap.today || prof.today || '';
    var plan = { goals: [], suggest: null, emergency: null, split: null, lowbal: [], subs: { subs: [], overlaps: [], trials: [] } };
    if (!isDay(today)) return plan;
    var problems = [];
    var sug = null;
    var scanFrom = prof.scanFrom || ((snap.scanStats || {}).from) || '';
    try { sug = suggestEmergency(snap, cfg, today, scanFrom); } catch (e) { problems.push('suggest: ' + e.message); }
    // kosh's figure for an emergency fund, whether or not it's offered (the editor shows it for one you set)
    if (sug) plan.emergency = { target: sug.target, months: sug.months, monthly: sug.monthly, how: sug.how, saved: sug.saved, pct: sug.pct };
    try {
      plan.goals = (cfg.goals || []).filter(function (g) { return g && g.id; }).map(function (g) { return goal(g, snap, today, sug); });
      shared(plan.goals);
    } catch (e) { problems.push('goals: ' + e.message); }
    // (kosh no longer offers to create an emergency fund on its own: the owner asked for it to go, 18 Oct. `sug` still
    // gives the figure behind an emergency goal made earlier with kosh's figure.)
    try { plan.split = split(snap, cfg, today); } catch (e) { problems.push('split: ' + e.message); }
    try { plan.lowbal = lowBalance(snap, today); } catch (e) { problems.push('lowbal: ' + e.message); }
    try { plan.subs = subscriptions(snap, prof, records || [], today, cfg); } catch (e) { problems.push('subs: ' + e.message); }
    try { plan.notices = notices(plan, today); } catch (e) { problems.push('notices: ' + e.message); plan.notices = []; }
    if (problems.length) plan.problems = problems;
    return plan;
  }

  /** one heads-up per thing. A low balance names what's due from its account, so the calendar's own "due" line for each
      of those goes (agent.js), and the week's "short" goes when the low balances account for all of it */
  function fold(snap, plan) {
    var lows = plan.lowbal || [];
    if (!lows.length || !snap.watch || !isDay(snap.today)) return;
    var accts = {}, dueIds = {}, soon = addDays(snap.today, 5);
    lows.forEach(function (l) { accts[l.acct] = 1; });
    // (every line due from those accounts in the window, the twin of one counted once among them)
    (snap.agenda || []).forEach(function (a) { if (a && accts[a.acct] && a.date >= snap.today && a.date <= soon) dueIds['due|' + a.name + '|' + a.date] = 1; });
    var covered = sum(lows, function (l) { return l.short; });
    snap.watch = snap.watch.filter(function (w) { return !(w.kind === 'due' && dueIds[w.id]) && !(w.kind === 'short' && +w.amt <= covered + 1); });
  }

  /** the heads-ups join what kosh noticed, most pressing first (as agent.js orders it); they never push one of its out:
      at most a few more than room is left */
  function bySevDate(a, b) { return b.sev - a.sev || String(b.date).localeCompare(String(a.date)); }
  function addNotices(snap, items) {
    if (!items || !items.length) return;
    var ids = {};
    items.forEach(function (y) { ids[y.id] = 1; });
    var theirs = (snap.watch || []).filter(function (x) { return !ids[x.id]; });
    var mine = items.slice().sort(bySevDate);
    var room = Math.max(16 - theirs.length, Math.min(mine.length, 4));
    snap.watch = theirs.concat(mine.slice(0, room)).sort(bySevDate);
  }

  var api = { build: build, serviceOf: serviceOf, cancelHow: cancelHow, SERVICES: SERVICES, FAMILIES: FAMILIES };
  if (E && E.postBuild) E.postBuild.push(function (snap, prof, records) {
    var plan = build(snap, prof || {}, records || []);
    var items = plan.notices || [];
    delete plan.notices;
    snap.plan = plan;
    fold(snap, plan);
    addNotices(snap, items);
  });
  return api;
})(typeof KoshEngine !== 'undefined' ? KoshEngine : require('./engine.js'));
if (typeof module !== 'undefined' && module.exports) module.exports = KoshPlan;
