import Foundation

// MARK: - Wealth's arithmetic, off the screen
//
// What the Wealth screens add up, rank and bucket, worked out from figures the build already made (holdings, bank
// balances, deposits and their maturities, repeats): never a figure of its own. Foundation only, so
// engine-test/wealth-book.js compiles it with swiftc and checks it on invented households. The screens
// (WealthHome, WealthFunds, WealthDeposits) hand it plain values through Store+Wealth.swift.

/// one thing owned, as Wealth lists it: its name, its kind (dep, stk, mf, ret, gold, ins, prop), whose it is (a person's
/// id, or "family" for a joint one), where it sits (the bank, fund house, platform; "" when kosh can't say) and its worth
struct WealthThing: Hashable {
    let name: String
    let kind: String
    let who: String
    let at: String
    let amt: Double
    /// what a tap opens: "dep:<deposit id>", "acct:<account id>", "kind:<kind>", "prop" ("" for nothing)
    var ref: String = ""
    /// what it has made a year, in percent, when kosh has its dated money (a fund's XIRR, a deposit's rate)
    var ret: Double? = nil
    /// "eq" (shares, an equity or index fund), "fix" (a deposit, a bank account, EPF, PPF, a debt fund) or "" (gold,
    /// land, a hybrid fund, an insurance fund, NPS: neither, or both)
    var sleeve: String = ""
}

/// one block of the map of everything owned: a thing on its own, or a kind's smaller things together (`n` of them)
struct WealthBlock: Hashable, Identifiable {
    let id: String
    let name: String
    let kind: String
    let amt: Double
    let n: Int
    /// a thing's own return (a block of several has none: their returns aren't one figure)
    var ret: Double? = nil
    /// what a tap opens: a thing's own ref, or "kind:<kind>" for a block of several
    var ref: String = ""
}

/// a block's place on the map, in the map's own units
struct WealthBox: Hashable {
    let x: Double
    let y: Double
    let w: Double
    let h: Double
}

/// how concentrated it is: the biggest three things' share of everything, the bank holding the most (its share), and
/// equity against fixed income over what is clearly one or the other (each a share of 100)
struct WealthSpread: Hashable {
    let top: Int
    let topShare: Double
    var bank: String? = nil
    var bankShare: Double = 0
    var equity: Int? = nil
    var fixed: Int? = nil
    /// what is neither (gold, land, a hybrid fund…), as a share of everything
    var neither: Double = 0
}

/// the deposits coming back, as a line from today to the last of them
struct WealthRunway: Hashable {
    /// each deposit with a maturity day ahead, soonest first, and where it sits on the line (0 today, 1 the last)
    let items: [WealthMaturing]
    let at: [Double]
    /// what comes back within a year from today (figure: what it pays, else worth today), how many, and whether every
    /// one of them says what it pays
    let year: Double
    let yearN: Int
    let yearKnown: Bool
    /// what all of them pay at maturity, only when every one says so
    let all: Double?
    let last: String
}

/// one month of EPF as the chart draws it: your share, your employer's, the year's interest on its March; `row` false
/// for a month the passbook has no row for
struct WealthEPFMonth: Hashable, Identifiable {
    let m: String
    let ee: Double
    let er: Double
    let int: Double
    let row: Bool
    var id: String { m }
    var paid: Double { ee + er }
}

/// a run of months to look at: "none" (nothing went in) or "noER" (your share went in, your employer's didn't)
struct WealthEPFGap: Hashable {
    let from: String
    let to: String
    let what: String
}

/// one line of "Everything you own": a thing, or a group of them, with its share of the biggest (`bar`, 0–1) or, for the
/// tail, none; `sub` is the quiet line under it; `kind` sets its colour when the line is one kind
struct WealthRow: Hashable, Identifiable {
    let id: String
    let name: String
    let amt: Double
    let kind: String?
    let sub: String
    let bar: Double
    let tail: Bool
}

/// a deposit coming back: its day (yyyy-MM-dd), what went in, what it pays at maturity, what it's worth today, its
/// rate; each only as the build knows it
struct WealthMaturing: Hashable, Identifiable {
    let id: String
    let name: String
    let who: String
    let day: String
    var putIn: Double? = nil
    var back: Double? = nil
    var now: Double? = nil
    var rate: Double? = nil
    /// the figure it is drawn at: what it pays at maturity, else what it's worth today
    var figure: Double { back ?? now ?? putIn ?? 0 }
}

/// one month of the maturity ladder: what comes back that month (`known` only when every deposit in it says what it
/// pays), and the deposits
struct WealthMonth: Hashable, Identifiable {
    let m: String
    let items: [WealthMaturing]
    var id: String { m }
    var figure: Double { items.reduce(0) { $0 + $1.figure } }
    var known: Bool { !items.isEmpty && items.allSatisfy { $0.back != nil } }
}

/// money held at one bank, for its deposit insurance: the bank as shown, the key that says two names are one bank,
/// whose (each person is a depositor of their own; a joint account is one more), and the figure
struct WealthHeld: Hashable {
    let bank: String
    let key: String
    let who: String
    let amt: Double
}

/// one bank under DICGC's cover: what is held there, how much of it the cover reaches (₹5 lakh a depositor), the rest
struct WealthCover: Hashable, Identifiable {
    let bank: String
    let key: String
    let who: [String]
    let total: Double
    let insured: Double
    var above: Double { max(0, total - insured) }
    var id: String { key }
}

enum WealthBook {
    /// DICGC insures up to ₹5 lakh a depositor at each bank, principal and interest together (since 4 Feb 2020)
    static let dicgc: Double = 500_000
    /// how many things "Each thing" names before the rest are added up in one line
    static let named: Int = 10

    // MARK: what it's in

    /// the kinds a household's worth is in, biggest first: money in the bank (key "bank") is a deposit's kin and
    /// counts in Deposits ("dep"); every other kind stays itself
    static func kinds(_ parts: [(key: String, v: Double)]) -> [(key: String, v: Double)] {
        var by: [String: Double] = [:]
        var order: [String] = []
        for p in parts where p.v > 0 {
            let k: String = p.key == "bank" ? "dep" : p.key
            if by[k] == nil { order.append(k) }
            by[k, default: 0] += p.v
        }
        return order.map { (key: $0, v: by[$0] ?? 0) }.sorted { $0.v > $1.v }
    }

    // MARK: everything you own

    /// "Each thing": the biggest `named` by name, the rest added up in one line with no bar; "kind", "whose" or
    /// "where": one line a group, biggest first, each with its share of the whole
    static func rows(_ things: [WealthThing], by: String, showWho: Bool, kindName: (String) -> String, whoName: (String) -> String) -> [WealthRow] {
        let all: [WealthThing] = things.filter { $0.amt > 0 }
        let total: Double = all.reduce(0) { $0 + $1.amt }
        guard total > 0 else { return [] }
        if by == "each" {
            let sorted: [WealthThing] = all.sorted { $0.amt != $1.amt ? $0.amt > $1.amt : $0.name < $1.name }
            let top: Double = sorted.first?.amt ?? 1
            var out: [WealthRow] = []
            for (i, t) in sorted.prefix(named).enumerated() {
                var bits: [String] = []
                if showWho { bits.append(whoName(t.who)) }
                if !t.at.isEmpty { bits.append(t.at) }
                if bits.isEmpty { bits.append(kindName(t.kind)) }
                out.append(WealthRow(id: "t\(i)|" + t.name, name: t.name, amt: t.amt, kind: t.kind, sub: bits.joined(separator: " · "), bar: t.amt / top, tail: false))
            }
            let rest: [WealthThing] = Array(sorted.dropFirst(named))
            if !rest.isEmpty {
                let sum: Double = rest.reduce(0) { $0 + $1.amt }
                let word: String = rest.count == 1 ? "1 more" : "\(rest.count) more"
                out.append(WealthRow(id: "tail", name: word + ", added up", amt: sum, kind: nil, sub: share(sum, of: total) + " of it", bar: 0, tail: true))
            }
            return out
        }
        var by_: [String: Double] = [:]
        for t in all {
            let k: String = by == "kind" ? t.kind : by == "whose" ? t.who : (t.at.isEmpty ? "" : t.at)
            by_[k, default: 0] += t.amt
        }
        let top: Double = by_.values.max() ?? 1
        return by_.keys.sorted { (by_[$0] ?? 0) != (by_[$1] ?? 0) ? (by_[$0] ?? 0) > (by_[$1] ?? 0) : $0 < $1 }.map { (k: String) -> WealthRow in
            let v: Double = by_[k] ?? 0
            let name: String = by == "kind" ? kindName(k) : by == "whose" ? whoName(k) : (k.isEmpty ? "Not said where" : k)
            return WealthRow(id: by + "|" + k, name: name, amt: v, kind: by == "kind" ? k : nil, sub: share(v, of: total), bar: v / top, tail: false)
        }
    }

    /// "4.2%", or "<0.1%" for a sliver that isn't nothing
    static func share(_ v: Double, of total: Double) -> String {
        guard total > 0 else { return "" }
        let p: Double = v / total * 100
        if p > 0 && p < 0.05 { return "<0.1%" }
        return String(format: "%.1f", p) + "%"
    }

    // MARK: coming back

    /// the months from `cm` (yyyy-MM) on, `count` of them, each with the deposits maturing in it
    static func ladder(_ items: [WealthMaturing], cm: String, count: Int) -> [WealthMonth] {
        var months: [String] = []
        var m: String = cm
        for _ in 0..<max(0, count) { months.append(m); m = nextMonth(m) }
        return months.map { (mo: String) -> WealthMonth in
            WealthMonth(m: mo, items: items.filter { $0.day.hasPrefix(mo) }.sorted { $0.day < $1.day })
        }
    }

    /// "2026-12" → "2027-01"
    static func nextMonth(_ m: String) -> String {
        let parts: [Int] = m.split(separator: "-").compactMap { Int($0) }
        guard parts.count >= 2 else { return m }
        let y: Int = parts[1] == 12 ? parts[0] + 1 : parts[0]
        let mo: Int = parts[1] == 12 ? 1 : parts[1] + 1
        return String(format: "%04d-%02d", y, mo)
    }

    // MARK: is it insured

    /// each bank's money against DICGC's cover: by person (a joint account is a depositor of its own), each up to ₹5
    /// lakh; biggest bank first
    static func cover(_ held: [WealthHeld]) -> [WealthCover] {
        var banks: [String: (name: String, per: [String: Double], order: [String])] = [:]
        var keys: [String] = []
        for h in held where h.amt > 0 && !h.key.isEmpty {
            if banks[h.key] == nil { banks[h.key] = (name: h.bank, per: [:], order: []); keys.append(h.key) }
            if banks[h.key]?.per[h.who] == nil { banks[h.key]?.order.append(h.who) }
            banks[h.key]?.per[h.who, default: 0] += h.amt
        }
        let rows: [WealthCover] = keys.compactMap { (k: String) -> WealthCover? in
            guard let b = banks[k] else { return nil }
            let total: Double = b.per.values.reduce(0, +)
            let insured: Double = b.per.values.reduce(0) { $0 + min($1, dicgc) }
            return WealthCover(bank: b.name, key: k, who: b.order, total: total, insured: insured)
        }
        return rows.sorted { $0.total != $1.total ? $0.total > $1.total : $0.bank < $1.bank }
    }

    // MARK: going in every month

    /// what repeats into investments every month (each repeat at its monthly figure), and the soonest next day on or
    /// after today
    static func monthly(_ repeats: [(amt: Double, per: Int, next: String)], today: String) -> (amt: Double, next: String?) {
        let amt: Double = repeats.reduce(0) { $0 + $1.amt / Double(max(1, $1.per)) }
        let next: String? = repeats.map(\.next).filter { $0 >= today }.min()
        return (amt, next)
    }

    // MARK: Holdings' sub-tabs

    /// the kinds Holdings has a tab for, in their order (Deposits, Mutual funds and Retirement always; Stocks, Gold and
    /// Other only when something is in them), and the one it opens on: the biggest, or Deposits when all are empty
    static let tabOrder: [String] = ["dep", "mf", "ret", "stk", "gold", "other"]
    static func tabs(_ v: [String: Double]) -> (tabs: [String], pick: String) {
        let always: Set<String> = ["dep", "mf", "ret"]
        let tabs: [String] = tabOrder.filter { always.contains($0) || (v[$0] ?? 0) > 0 }
        var pick: String = "dep"
        var most: Double = 0
        for k in tabs where (v[k] ?? 0) > most { most = v[k] ?? 0; pick = k }
        return (tabs, pick)
    }

    // MARK: the map of everything owned

    /// the map's blocks, biggest first: the biggest things on their own (up to `named` of them, each at least `least` of
    /// the whole), the rest of each kind together in one block ("4 more funds", "8 stocks"); a kind's lone leftover is
    /// itself. `noun(kind, n, more)` says a block of several in words
    static func blocks(_ things: [WealthThing], named: Int = 8, least: Double = 0.03, noun: (String, Int, Bool) -> String) -> [WealthBlock] {
        let all: [WealthThing] = things.filter { $0.amt > 0 }.sorted { $0.amt != $1.amt ? $0.amt > $1.amt : $0.name < $1.name }
        let total: Double = all.reduce(0) { $0 + $1.amt }
        guard total > 0 else { return [] }
        var out: [WealthBlock] = []
        var rest: [String: [WealthThing]] = [:]
        var kinds: [String] = []
        var shown: Set<String> = []
        for (i, t) in all.enumerated() {
            if out.count < named && t.amt / total >= least {
                out.append(WealthBlock(id: "t\(i)", name: t.name, kind: t.kind, amt: t.amt, n: 1, ret: t.ret, ref: t.ref))
                shown.insert(t.kind)
            } else {
                if rest[t.kind] == nil { kinds.append(t.kind) }
                rest[t.kind, default: []].append(t)
            }
        }
        for k in kinds {
            let ts: [WealthThing] = rest[k] ?? []
            if ts.count == 1, let t = ts.first {
                out.append(WealthBlock(id: "one|" + k, name: t.name, kind: k, amt: t.amt, n: 1, ret: t.ret, ref: t.ref))
            } else if !ts.isEmpty {
                let sum: Double = ts.reduce(0) { $0 + $1.amt }
                out.append(WealthBlock(id: "rest|" + k, name: noun(k, ts.count, shown.contains(k)), kind: k, amt: sum, n: ts.count, ref: "kind:" + k))
            }
        }
        return out.sorted { $0.amt != $1.amt ? $0.amt > $1.amt : $0.id < $1.id }
    }

    /// the blocks laid out on a w × h map, each as near square as the rest allow (the squarified treemap: Bruls,
    /// Huizing and van Wijk, 2000); values biggest first; a value at nothing gets an empty box
    static func squarify(_ vs: [Double], w: Double, h: Double) -> [WealthBox] {
        let none: WealthBox = WealthBox(x: 0, y: 0, w: 0, h: 0)
        var out: [WealthBox] = Array(repeating: none, count: vs.count)
        let total: Double = vs.reduce(0) { $0 + max(0, $1) }
        guard total > 0, w > 0, h > 0 else { return out }
        let scale: Double = w * h / total
        let idx: [Int] = vs.indices.filter { vs[$0] > 0 }
        let areas: [Double] = idx.map { vs[$0] * scale }
        var rx: Double = 0, ry: Double = 0, rw: Double = w, rh: Double = h
        var i: Int = 0
        while i < areas.count {
            let side: Double = min(rw, rh)
            var row: [Double] = [areas[i]]
            var j: Int = i + 1
            while j < areas.count && worst(row + [areas[j]], side) <= worst(row, side) {
                row.append(areas[j])
                j += 1
            }
            let sum: Double = row.reduce(0, +)
            if rw >= rh {
                // a column down the left
                let cw: Double = rh > 0 ? sum / rh : 0
                var yy: Double = ry
                for k in i..<j {
                    let hh: Double = cw > 0 ? areas[k] / cw : 0
                    out[idx[k]] = WealthBox(x: rx, y: yy, w: cw, h: hh)
                    yy += hh
                }
                rx += cw; rw -= cw
            } else {
                // a row along the top
                let rhh: Double = rw > 0 ? sum / rw : 0
                var xx: Double = rx
                for k in i..<j {
                    let ww: Double = rhh > 0 ? areas[k] / rhh : 0
                    out[idx[k]] = WealthBox(x: xx, y: ry, w: ww, h: rhh)
                    xx += ww
                }
                ry += rhh; rh -= rhh
            }
            i = j
        }
        return out
    }

    /// the worst (most stretched) box a row of areas makes along a side
    static func worst(_ row: [Double], _ side: Double) -> Double {
        let s: Double = row.reduce(0, +)
        guard s > 0, side > 0, let hi = row.max(), let lo = row.min(), lo > 0 else { return .infinity }
        let s2: Double = s * s
        let w2: Double = side * side
        return max(w2 * hi / s2, s2 / (w2 * lo))
    }

    // MARK: how concentrated

    /// the top three things' share of everything; the bank with the most of it (its row from `cover`); equity against
    /// fixed income, over what is clearly one or the other; nil when nothing is owned
    static func spread(_ things: [WealthThing], banks: [WealthCover]) -> WealthSpread? {
        let all: [WealthThing] = things.filter { $0.amt > 0 }.sorted { $0.amt > $1.amt }
        let total: Double = all.reduce(0) { $0 + $1.amt }
        guard total > 0 else { return nil }
        let top: Int = min(3, all.count)
        let topSum: Double = all.prefix(top).reduce(0) { $0 + $1.amt }
        var out: WealthSpread = WealthSpread(top: top, topShare: topSum / total)
        if let b = banks.first, b.total > 0 {
            out.bank = b.bank
            out.bankShare = min(1, b.total / total)
        }
        let eq: Double = all.filter { $0.sleeve == "eq" }.reduce(0) { $0 + $1.amt }
        let fix: Double = all.filter { $0.sleeve == "fix" }.reduce(0) { $0 + $1.amt }
        if eq + fix > 0 && eq > 0 && fix > 0 {
            let e: Int = Int((eq / (eq + fix) * 100).rounded())
            out.equity = e
            out.fixed = 100 - e
        }
        out.neither = max(0, total - eq - fix) / total
        return out
    }

    // MARK: when it comes back

    /// every deposit with a maturity day on or after today, on a line from today to the last; what comes back within a
    /// year; what all of them pay, only when each says so. nil when nothing is ahead
    static func runway(_ items: [WealthMaturing], today: String) -> WealthRunway? {
        guard let t0 = dayNumber(today) else { return nil }
        let ahead: [WealthMaturing] = items.filter { $0.day >= today && dayNumber($0.day) != nil }.sorted { $0.day != $1.day ? $0.day < $1.day : $0.name < $1.name }
        guard let last = ahead.last, let tl = dayNumber(last.day) else { return nil }
        let span: Double = Double(max(1, tl - t0))
        let at: [Double] = ahead.map { (m: WealthMaturing) -> Double in Double((dayNumber(m.day) ?? t0) - t0) / span }
        let yearEnd: String = yearLater(today)
        let inYear: [WealthMaturing] = ahead.filter { $0.day < yearEnd }
        let year: Double = inYear.reduce(0) { $0 + $1.figure }
        let known: Bool = inYear.allSatisfy { $0.back != nil }
        let all: Double? = ahead.allSatisfy { $0.back != nil } ? ahead.reduce(0) { $0 + ($1.back ?? 0) } : nil
        return WealthRunway(items: ahead, at: at, year: year, yearN: inYear.count, yearKnown: known, all: all, last: last.day)
    }

    /// how far a deposit is through its term (0–1) and what's left in words ("1y 8m left", "5m left", "12 days left",
    /// "matured"); nil without both ends, or when they're the wrong way round
    static func term(start: String?, end: String?, today: String) -> (done: Double, left: String)? {
        guard let s = start, let e = end, let a = dayNumber(s), let b = dayNumber(e), let t = dayNumber(today), b > a else { return nil }
        let done: Double = min(1, max(0, Double(t - a) / Double(b - a)))
        return (done, leftWords(today, e))
    }

    static func leftWords(_ today: String, _ end: String) -> String {
        guard let t = dayNumber(today), let e = dayNumber(end) else { return "" }
        if e < t { return "matured" }
        let ty: [Int] = today.split(separator: "-").compactMap { Int($0) }
        let ey: [Int] = end.split(separator: "-").compactMap { Int($0) }
        guard ty.count == 3, ey.count == 3 else { return "" }
        var months: Int = (ey[0] - ty[0]) * 12 + (ey[1] - ty[1])
        if ey[2] < ty[2] { months -= 1 }
        if months >= 12 {
            let y: Int = months / 12
            let m: Int = months % 12
            return "\(y)y" + (m > 0 ? " \(m)m" : "") + " left"
        }
        if months >= 1 { return "\(months)m left" }
        let d: Int = e - t
        if d == 0 { return "matures today" }
        return d == 1 ? "1 day left" : "\(d) days left"
    }

    /// "2026-11-01" → "2027-11-01" (29 Feb → 1 Mar)
    static func yearLater(_ day: String) -> String {
        let p: [Int] = day.split(separator: "-").compactMap { Int($0) }
        guard p.count == 3 else { return day }
        if p[1] == 2 && p[2] == 29 { return String(format: "%04d-03-01", p[0] + 1) }
        return String(format: "%04d-%02d-%02d", p[0] + 1, p[1], p[2])
    }

    /// days since 1 Jan 1970 for a "yyyy-MM-dd" (a "yyyy-MM" is its first day), worked out without a calendar or a
    /// time zone; nil for anything else
    static func dayNumber(_ s: String) -> Int? {
        let p: [Int] = s.prefix(10).split(separator: "-").compactMap { Int($0) }
        guard p.count >= 2, p[1] >= 1, p[1] <= 12 else { return nil }
        let d: Int = p.count >= 3 ? p[2] : 1
        guard d >= 1, d <= 31 else { return nil }
        // (Howard Hinnant's days-from-civil)
        let y: Int = p[1] <= 2 ? p[0] - 1 : p[0]
        let era: Int = (y >= 0 ? y : y - 399) / 400
        let yoe: Int = y - era * 400
        let mp: Int = (p[1] + 9) % 12
        let doy: Int = (153 * mp + 2) / 5 + d - 1
        let doe: Int = yoe * 365 + yoe / 4 - yoe / 100 + doy
        return era * 146097 + doe - 719468
    }

    // MARK: EPF month by month

    /// the last `count` months up to the newest with money in, every month there (a month with no row is drawn empty),
    /// and the runs of months to look at: after the first month with money in, a month with nothing in ("none") or
    /// with your share and not your employer's ("noER")
    static func epfWindow(_ rows: [(m: String, ee: Double, er: Double, int: Double)], count: Int) -> (months: [WealthEPFMonth], gaps: [WealthEPFGap]) {
        var by: [String: (ee: Double, er: Double, int: Double)] = [:]
        for r in rows { by[r.m] = (ee: r.ee, er: r.er, int: r.int) }
        let paidMonths: [String] = rows.filter { $0.ee + $0.er > 0 }.map { $0.m }
        guard let end = paidMonths.max(), count > 0 else { return ([], []) }
        var ms: [String] = [end]
        while ms.count < count { ms.insert(prevMonth(ms[0]), at: 0) }
        let months: [WealthEPFMonth] = ms.map { (m: String) -> WealthEPFMonth in
            let r: (ee: Double, er: Double, int: Double)? = by[m]
            return WealthEPFMonth(m: m, ee: r?.ee ?? 0, er: r?.er ?? 0, int: r?.int ?? 0, row: r != nil)
        }
        var gaps: [WealthEPFGap] = []
        var started: Bool = false
        for mo in months {
            if mo.paid > 0 && !started { started = true }
            guard started else { continue }
            let what: String = mo.paid <= 0 ? "none" : (mo.er <= 0 ? "noER" : "")
            if what.isEmpty { continue }
            if let g = gaps.last, g.what == what, nextMonth(g.to) == mo.m {
                gaps[gaps.count - 1] = WealthEPFGap(from: g.from, to: mo.m, what: what)
            } else {
                gaps.append(WealthEPFGap(from: mo.m, to: mo.m, what: what))
            }
        }
        return (months, gaps)
    }

    /// "2027-01" → "2026-12"
    static func prevMonth(_ m: String) -> String {
        let parts: [Int] = m.split(separator: "-").compactMap { Int($0) }
        guard parts.count >= 2 else { return m }
        let y: Int = parts[1] == 1 ? parts[0] - 1 : parts[0]
        let mo: Int = parts[1] == 1 ? 12 : parts[1] - 1
        return String(format: "%04d-%02d", y, mo)
    }
}
