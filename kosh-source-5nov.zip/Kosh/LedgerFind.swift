import SwiftUI

// MARK: - Find: every payment, by name, and by anything kosh files it under
//
// The magnifying glass at the end of Transactions' sub-tab row (on All) opens Find. Type a shop, a person, a note,
// a card or a wallet; or don't type at all and open Filters (FindSheet.swift): what to show, when, how it was paid,
// how big, the category and who it was for. What's on sits under the search field as chips you take off with a tap;
// what matches comes up under them by day, with what it adds up to.

enum FindSpan: String, CaseIterable, Identifiable {
    case all, month, three, year, fy, lastFY
    var id: String { rawValue }
    var title: String {
        switch self {
        case .all: return "Any time"
        case .month: return "This month"
        case .three: return "3 months"
        case .year: return "This year"
        case .fy: return "This FY"
        case .lastFY: return "Last FY"
        }
    }
    /// the year April starts: this financial year's, from the month
    static func fyStart(_ cm: String) -> Int {
        let y: Int = Int(cm.prefix(4)) ?? 2026
        let m: Int = Int(cm.suffix(2)) ?? 1
        return m >= 4 ? y : y - 1
    }
    /// the first day it takes in (yyyy-MM-dd); empty: no limit
    func from(cm: String) -> String {
        switch self {
        case .all: return ""
        case .month: return cm + "-01"
        case .three: return Day.addMonths(cm, -2) + "-01"
        case .year: return String(cm.prefix(4)) + "-01-01"
        case .fy: return String(Self.fyStart(cm)) + "-04-01"
        case .lastFY: return String(Self.fyStart(cm) - 1) + "-04-01"
        }
    }
    /// the last day it takes in; empty: up to today
    func to(cm: String) -> String {
        self == .lastFY ? String(Self.fyStart(cm)) + "-03-31" : ""
    }
}

enum FindFlow: String, CaseIterable, Identifiable {
    case any, out, moneyIn, moves
    var id: String { rawValue }
    var title: String {
        switch self {
        case .any: return "Everything"
        case .out: return "Money out"
        case .moneyIn: return "Money in"
        case .moves: return "Moves"
        }
    }
    var sym: String {
        switch self {
        case .any: return "tray.full"
        case .out: return "arrow.up.right"
        case .moneyIn: return "arrow.down.left"
        case .moves: return "arrow.left.arrow.right"
        }
    }
}

enum FindSize: String, CaseIterable, Identifiable {
    case any, small, mid, big, huge
    var id: String { rawValue }
    var title: String {
        switch self {
        case .any: return "Any amount"
        case .small: return "Under ₹500"
        case .mid: return "₹500–5k"
        case .big: return "₹5k–50k"
        case .huge: return "Over ₹50k"
        }
    }
    func fits(_ a: Double) -> Bool {
        switch self {
        case .any: return true
        case .small: return a < 500
        case .mid: return a >= 500 && a < 5000
        case .big: return a >= 5000 && a < 50000
        case .huge: return a >= 50000
        }
    }
}

/// what Find is looking for
struct FindQuery: Equatable {
    var text: String = ""
    var span: FindSpan = .all
    var flow: FindFlow = .any
    var unnamed = false
    var chapter = false
    var cats: Set<String> = []
    var subs: Set<String> = []
    var whom: Set<String> = []
    var ways: Set<String> = []
    var size: FindSize = .any
    /// the amount range from the sheet: stops into FindAmount.steps (0 and the top: no limit that side)
    var lo: Int = 0
    var hi: Int = FindAmount.top
    var ranged: Bool { lo > 0 || hi < FindAmount.top }
    /// months picked elsewhere (Insights: a category's month), yyyy-MM; empty: any
    var months: Set<String> = []
    /// only what still has no category (what Sort these takes in)
    var uncat = false
    /// only money back: refunds and money set against a payment
    var refunds = false
    /// the payments behind a figure elsewhere (a Month in review card), and what to call them
    var ids: [String] = []
    var idsTitle: String = ""

    var words: String { text.trimmingCharacters(in: .whitespaces) }
    /// how many filters are on, typing aside
    var on: Int {
        var n: Int = cats.count + subs.count + whom.count + ways.count
        if span != .all { n += 1 }
        if !months.isEmpty { n += 1 }
        if flow != .any { n += 1 }
        if unnamed { n += 1 }
        if chapter { n += 1 }
        if size != .any { n += 1 }
        if ranged { n += 1 }
        if uncat { n += 1 }
        if refunds { n += 1 }
        if !ids.isEmpty { n += 1 }
        return n
    }
    var blank: Bool { words.isEmpty && on == 0 }

    /// what the typing was taken to mean (FindParse.swift): words, kinds, "uncategorised", months, amounts
    @MainActor func understood(_ store: Store) -> FindParse {
        FindParse.parse(words, cats: Array(store.snap.cats.keys), cm: store.snap.cm)
    }

    /// every payment that matches, newest first
    @MainActor func run(_ store: Store) -> [Txn] {
        if blank { return [] }
        let p: FindParse = understood(store)
        let typed: String = (p.words + p.amounts).joined(separator: " ")
        let base: [Txn] = typed.isEmpty ? store.tx : store.search(typed)
        let from: String = span.from(cm: store.snap.cm)
        let to: String = span.to(cm: store.snap.cm)
        let only: Set<String> = Set(ids)
        let pCats: Set<String> = Set(p.cats)
        let pMonths: Set<String> = Set(p.months)
        return base.filter { t in
            if !store.who.owns(t.o) { return false }
            if !only.isEmpty && !only.contains(t.id) { return false }
            if !pCats.isEmpty && !pCats.contains(t.c) { return false }
            if (p.uncat || uncat) && !Store.needsSorting(t) { return false }
            if !pMonths.isEmpty && !pMonths.contains(String(t.d.prefix(7))) { return false }
            if refunds && !(t.refOf != nil || t.nt != nil) { return false }
            if !from.isEmpty && t.d < from { return false }
            if !to.isEmpty && t.d > to { return false }
            if !months.isEmpty && !months.contains(String(t.d.prefix(7))) { return false }
            switch flow {
            case .any: break
            case .out: if t.k != "out" { return false }
            case .moneyIn: if t.k != "in" { return false }
            case .moves: if !store.isMove(t) { return false }
            }
            if unnamed && !t.u { return false }
            if chapter && store.trip(t.tr) == nil { return false }
            if !cats.isEmpty && !cats.contains(t.c) { return false }
            if !subs.isEmpty && !subs.contains(t.s) { return false }
            if !whom.isEmpty && !(t.k == "out" && whom.contains(t.f)) { return false }
            if !ways.isEmpty && !ways.contains(where: { PaidWith.matches(t, $0 == "wallet" ? "wallets" : $0) }) { return false }
            if !size.fits(t.a) { return false }
            if ranged && !FindAmount.fits(t.a, lo, hi) { return false }
            return true
        }
        .sorted { a, b in a.d != b.d ? a.d > b.d : a.t > b.t }
    }
}

// (LedgerFind itself: FindPremium.swift, 3 Nov)

/// "34 payments · ₹12,340 out · +₹2,000 in"
struct FindTotal: View {
    let count: Int
    let out: Double
    let came: Double
    var body: some View {
        let n: String = String(count) + (count == 1 ? " payment" : " payments")
        HStack(spacing: 6) {
            Text(n).foregroundStyle(.secondary)
            if out > 0 { Text("· " + Fmt.rupees(out) + " out").foregroundStyle(Color.primary) }
            if came > 0 { Text("· +" + Fmt.rupees(came) + " in").foregroundStyle(Color.green) }
        }
        .font(.subheadline.weight(.semibold))
        .monospacedDigit()
        .lineLimit(1)
        .minimumScaleFactor(0.8)
        .privacySensitive()
    }
}

// MARK: the filters

/// a row of chips for each kind of filter, under a small label; categories open their subcategories under them
struct FindFilters: View {
    @Environment(Store.self) private var store
    @Binding var q: FindQuery

    var body: some View {
        let unnamed: Int = store.findCounts.unnamed
        let cats: [String] = Self.categories(store)
        let subs: [String] = Self.subcategories(store, of: q.cats)
        VStack(alignment: .leading, spacing: 14) {
            FindRow(label: "Quick") {
                FindChip(title: unnamed > 0 ? "Needs a name · " + String(unnamed) : "Needs a name", sym: "questionmark.circle", tint: Color.orange, on: q.unnamed) {
                    q.unnamed.toggle()
                }
                ForEach(FindFlow.allCases.filter { $0 != .any }) { f in
                    FindChip(title: f.title, sym: f.sym, tint: f == .moneyIn ? Color.green : Color.kosh, on: q.flow == f) {
                        q.flow = q.flow == f ? .any : f
                    }
                }
                FindChip(title: "In a chapter", sym: "book.pages", tint: Color.purple, on: q.chapter) { q.chapter.toggle() }
            }
            FindRow(label: "When") {
                // months picked on another page: one chip, off to clear them
                if !q.months.isEmpty {
                    FindChip(title: Self.monthsTitle(q.months), sym: "calendar", tint: Color.kosh, on: true) { q.months = [] }
                }
                ForEach(FindSpan.allCases.filter { $0 != .all }) { s in
                    FindChip(title: s.title, sym: "calendar", tint: Color.kosh, on: q.span == s) { q.span = q.span == s ? .all : s }
                }
            }
            FindRow(label: "For") {
                ForEach(Self.whom(store), id: \.0) { w in
                    FindChip(title: w.1, sym: w.2, tint: w.3, on: q.whom.contains(w.0)) { Self.flip(&q.whom, w.0) }
                }
            }
            if !cats.isEmpty {
                FindRow(label: "Category") {
                    ForEach(cats, id: \.self) { c in
                        FindChip(title: c, sym: store.symbol(c), tint: store.catColor(c), on: q.cats.contains(c)) {
                            Self.flip(&q.cats, c)
                            // a category taken off takes its subcategories with it
                            let keep: Set<String> = Set(Self.subcategories(store, of: q.cats))
                            q.subs = q.subs.intersection(keep)
                        }
                    }
                }
            }
            if !subs.isEmpty {
                FindRow(label: "Subcategory") {
                    ForEach(subs, id: \.self) { s in
                        FindChip(title: s, sym: "", tint: Color.kosh, on: q.subs.contains(s)) { Self.flip(&q.subs, s) }
                    }
                }
                .transition(.opacity.combined(with: .move(edge: .top)))
            }
            FindRow(label: "Paid with") {
                ForEach(Self.ways, id: \.0) { w in
                    FindChip(title: w.1, sym: w.2, tint: Color.kosh, on: q.ways.contains(w.0)) { Self.flip(&q.ways, w.0) }
                }
                // each wallet you've paid from, by name
                ForEach(Array(store.walletsUsed.prefix(6)), id: \.self) { w in
                    FindChip(title: w, sym: "wallet.bifold", tint: Color(hex: "#FF9F0A"), on: q.ways.contains("w:" + w)) { Self.flip(&q.ways, "w:" + w) }
                }
            }
            FindRow(label: "Amount") {
                ForEach(FindSize.allCases.filter { $0 != .any }) { z in
                    FindChip(title: z.title, sym: "", tint: Color.kosh, on: q.size == z) { q.size = q.size == z ? .any : z }
                }
            }
        }
    }

    /// "Oct 2026", or "Aug – Oct 2026"
    static func monthsTitle(_ ms: Set<String>) -> String {
        let s: [String] = ms.sorted()
        guard let a = s.first, let b = s.last else { return "" }
        return a == b ? Day.monthShort(a) + " " + String(a.prefix(4)) : Day.monthShort(a) + " – " + Day.monthShort(b) + " " + String(b.prefix(4))
    }
    static func flip(_ set: inout Set<String>, _ v: String) {
        if set.contains(v) { set.remove(v) } else { set.insert(v) }
    }

    /// how a payment was paid, as Find offers it
    static let ways: [(String, String, String)] = PaidWith.ways + [("wallet", "Wallet", "wallet.bifold")]

    /// who a payment was for: the four tags, as the payments row shows them
    static func whom(_ store: Store) -> [(String, String, String, Color)] {
        [("me", "Me", "person", Color(hex: "#007AFF")),
         ("mom", store.live != nil ? "Family" : "Mom", "heart", Color(hex: "#FF2D55")),
         ("home", "Home", "house", Color(hex: "#FF9500")),
         ("work", "Work", "briefcase", Color(hex: "#30B0C7"))]
    }

    /// the categories your payments are in, the most used first
    @MainActor static func categories(_ store: Store) -> [String] {
        let n: [String: Int] = store.findCounts.cats
        return n.sorted { $0.value != $1.value ? $0.value > $1.value : $0.key < $1.key }.map(\.key)
    }

    /// the subcategories of the categories picked, the ones your payments use first, then the rest kosh knows
    @MainActor static func subcategories(_ store: Store, of cats: Set<String>) -> [String] {
        if cats.isEmpty { return [] }
        var n: [String: Int] = [:]
        let byCat: [String: [String: Int]] = store.findCounts.subs
        for c in cats { for (sub, k) in byCat[c] ?? [:] { n[sub, default: 0] += k } }
        var out: [String] = n.sorted { $0.value != $1.value ? $0.value > $1.value : $0.key < $1.key }.map(\.key)
        for c in cats.sorted() {
            for s in store.snap.cats[c]?.subs ?? [] where !out.contains(s) && s != "Other" { out.append(s) }
        }
        return out
    }
}

extension Store {
    /// Find's chips, counted once a change to the payments for whoever is shown (FindFilters asked on every redraw and
    /// every tap, each a pass over every payment): payments that need a name, each category's payments (named ones),
    /// and each category's subcategories
    var findCounts: (unnamed: Int, cats: [String: Int], subs: [String: [String: Int]]) {
        if findMemo.gen == txGen && findMemo.who == who.id { return (findMemo.unnamed, findMemo.cats, findMemo.subs) }
        var unnamed = 0
        var cats: [String: Int] = [:]
        var subs: [String: [String: Int]] = [:]
        for t in tx where who.owns(t.o) {
            if t.u { unnamed += 1 } else if !t.c.isEmpty { cats[t.c, default: 0] += 1 }
            if !t.s.isEmpty && t.s != "Other" { subs[t.c, default: [:]][t.s, default: 0] += 1 }
        }
        findMemo = (txGen, who.id, unnamed, cats, subs)
        return (unnamed, cats, subs)
    }
}

/// a filter's label over its chips, which scroll sideways
struct FindRow<Content: View>: View {
    let label: String
    @ViewBuilder let content: Content
    var body: some View {
        VStack(alignment: .leading, spacing: 7) {
            Text(label.uppercased())
                .font(.system(.caption2, weight: .bold)).tracking(0.8)
                .foregroundStyle(.secondary)
                .padding(.leading, 20)
            ScrollView(.horizontal) {
                HStack(spacing: 8) { content }
                    .padding(.horizontal, 20)
            }
            .scrollIndicators(.hidden)
        }
    }
}

/// a chip: its symbol and words, filled with its colour when on
struct FindChip: View {
    let title: String
    let sym: String
    let tint: Color
    let on: Bool
    let tap: () -> Void
    var body: some View {
        let ink: Color = on ? Color.white : Color.primary
        let wash: Color = on ? tint : Color(uiColor: .secondarySystemGroupedBackground)
        let traits: AccessibilityTraits = on ? [.isButton, .isSelected] : [.isButton]
        Button {
            withAnimation(Motion.base) { tap() }
        } label: {
            HStack(spacing: 6) {
                if !sym.isEmpty {
                    Image(systemName: sym)
                        .font(.system(.caption, weight: .semibold))
                        .foregroundStyle(on ? Color.white : tint)
                }
                Text(title).lineLimit(1)
            }
            .font(.system(.footnote, weight: .semibold))
            .foregroundStyle(ink)
            .padding(.horizontal, 13)
            .frame(minHeight: 34)
            .background(wash, in: Capsule())
            .overlay(Capsule().strokeBorder(Color.primary.opacity(on ? 0 : 0.06), lineWidth: 0.5))
            .contentShape(Capsule())
        }
        .buttonStyle(.press)
        .accessibilityAddTraits(traits)
    }
}

/// Find's "Change all": every payment found, filed, marked for someone, or counted in one go (with Undo)
struct ChangeAllMenu: View {
    @Environment(Store.self) private var store
    let rows: [Txn]
    var body: some View {
        let n: Int = rows.count
        let label: String = n == 1 ? "this payment" : "all \(n)"
        Menu {
            Section("Change " + label) {
                RefileItems(rows: rows)
                Button { store.changeMany(rows, what: n == 1 ? "Counted in spending" : "\(n) payments counted") { o in o.ex = nil; o.cnt = true } } label: {
                    Label("Count " + (n == 1 ? "it" : "them"), systemImage: "eye")
                }
                Button { store.changeMany(rows, what: n == 1 ? "Left out of spending" : "\(n) payments left out") { o in o.ex = Store.leftOut; o.cnt = nil } } label: {
                    Label("Don’t count " + (n == 1 ? "it" : "them"), systemImage: "eye.slash")
                }
            }
        } label: {
            Image(systemName: "checklist")
        }
        .accessibilityLabel("Change all the payments found")
    }
}

/// "File as…" and "For…" for many payments at once (Find's "Change all", Transactions' select mode): they change on
/// screen at once, with one Undo for all of them. One payee's payments teach kosh the payee, so its next ones follow
/// too; a mix of payees is changed for these payments only.
struct RefileItems: View {
    @Environment(Store.self) private var store
    let rows: [Txn]
    var body: some View {
        Menu {
            ForEach(store.spendCategories, id: \.self) { c in
                let subs: [String] = store.snap.cats[c]?.subs ?? []
                if subs.isEmpty {
                    Button(c) { file(c, "") }
                } else {
                    Menu(c) {
                        Button("Just " + c) { file(c, "") }
                        ForEach(subs, id: \.self) { s in Button(s) { file(c, s) } }
                    }
                }
            }
            Button("My own account") { file("Self Transfer", "") }
        } label: {
            Label("File as…", systemImage: "tag")
        }
        Menu {
            ForEach([("me", "Me"), ("mom", "Family"), ("home", "Home"), ("work", "Work")], id: \.0) { f in
                Button(f.1) { mark(f.0, f.1) }
            }
        } label: {
            Label("For…", systemImage: "person")
        }
    }

    func file(_ c: String, _ s: String) {
        store.fileMany(rows, c, s, learn: Store.onePayee(rows), what: Store.filedWords(rows.count, c, s))
    }
    func mark(_ f: String, _ name: String) {
        let n: Int = rows.count
        let what: String = (n == 1 ? "Marked" : String(n) + " payments marked") + " for " + name
        store.markMany(rows, for: f, learn: Store.onePayee(rows), what: what)
    }
}
