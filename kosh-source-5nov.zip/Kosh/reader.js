/* kosh reader: what a money mail says happened, as typed events.

   The engine's first reader (engine.js parseOnce) is a list of sentence patterns, one per layout someone had
   already seen, first match wins, one record per mail. This one reads the way a person does: it takes the mail
   apart into lines, table cells and label/value pairs, finds the things money mail is made of (amounts, dates,
   masked card and account digits, UPI IDs and references, order numbers, ISINs), decides what each amount IS
   from its label or the words around it (moved, a balance, a limit, what's due, the minimum, an offer, a fee, a
   premium, a cover...), works out what the mail is doing (an alert, a statement, a reminder, a promise, an
   order's step, an allotment, a receipt), and says it as events: zero, one or several per mail, every field
   taken from the mail.

   Nothing here is one bank's template. What the sender is (engine.js institution: a bank, a card company, a
   wallet, a broker, a registrar, an insurer, a gateway) and what kosh knows of India's money (knowledge.js:
   shops, billers, registrars, UPI handles, payment rails) decide what words mean.

   read(msg)       one email → { kind, events, layout }
   toRecord(r, m)  the main money event as the engine's record, so build() reads it as it reads the old one
   docOf(msg)      the mail taken apart (lines, tokens, label/value pairs), for layouts.js and the tests

   Loaded after engine.js and knowledge.js; in Node, require('./reader.js'). */

var KoshReader = (function (E) {
  'use strict';
  var VERSION = 2;
  var K = (function () {
    if (typeof KoshKnowledge !== 'undefined' && KoshKnowledge) return KoshKnowledge;
    try { if (typeof require === 'function') return require('./knowledge.js'); } catch (e) { /* not bundled */ }
    return {};
  })();

  /* ------------------------------------------------------------ small things */
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function lc(s) { return String(s == null ? '' : s).toLowerCase(); }
  function trim(s) { return String(s == null ? '' : s).replace(/\s+/g, ' ').trim(); }
  function money(n) { return Math.round(n * 100) / 100; }
  function num(s) { var v = parseFloat(String(s || '').replace(/[,\s]/g, '')); return isFinite(v) ? v : 0; }
  function dayNum(iso) { var p = String(iso).split('-'); return Date.UTC(+p[0], +p[1] - 1, +p[2]) / 864e5; }
  function isoOf(n) { var d = new Date(n * 864e5); return d.getUTCFullYear() + '-' + pad(d.getUTCMonth() + 1) + '-' + pad(d.getUTCDate()); }
  function addDays(iso, n) { return isoOf(dayNum(iso) + n); }
  function validDay(y, m, d) { if (!(m >= 1 && m <= 12 && d >= 1 && y >= 1990 && y <= 2100)) return false; return d <= new Date(Date.UTC(y, m, 0)).getUTCDate(); }
  function uniq(a) { var o = []; a.forEach(function (x) { if (o.indexOf(x) < 0) o.push(x); }); return o; }
  function onDomain(d, list) { return (list || []).some(function (x) { return d === x || d.slice(-(x.length + 1)) === '.' + x; }); }
  function capWords(s) { return String(s || '').replace(/\b([a-z])([a-z]*)/g, function (a, b, c) { return b.toUpperCase() + c; }); }

  /* the day a mail was sent, in India (Gmail's date is UTC: an alert sent at 1 a.m. IST is the day before in UTC) */
  function mailDay(date) {
    var t = Date.parse(date || '');
    if (!isFinite(t)) return String(date || '').slice(0, 10);
    return isoOf(Math.floor((t + 5.5 * 3600e3) / 864e5));
  }

  /* ------------------------------------------------------------ 1. the mail as lines
     Plain text when it says something, else the HTML turned into lines. Links, invisible characters and
     emphasis marks come out; a table's cells stay apart (" | ") so a label and its value can be paired. */
  var ENT = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ', rsquo: '’', lsquo: '‘', rdquo: '”', ldquo: '“', ndash: '–', mdash: '—', bull: '•', middot: '·', rupee: '₹', hellip: '…', zwnj: '', zwj: '', shy: '', times: '×' };
  function decodeOnce(s) {
    return s.replace(/&(#x?[0-9a-f]+|[a-z]+);/gi, function (all, e) {
      if (e[0] === '#') { var n = e[1] === 'x' || e[1] === 'X' ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10); return isFinite(n) && n > 0 && n < 0x110000 ? String.fromCodePoint(n) : all; }
      var v = ENT[e.toLowerCase()]; return v === undefined ? all : v;
    });
  }
  function decode(s) { s = decodeOnce(String(s || '')); return /&(?:#\d+|#x[0-9a-f]+|[a-z]+);/i.test(s) ? decodeOnce(s) : s; }   // "&amp;#8377;" is ₹ after two passes
  /* the mail's HTML as lines and cells: engine.js htmlLines, the one converter the rules read too */
  function htmlText(h) { return decode(E.lib.htmlLines(String(h || ''))); }
  var INVISIBLE = /[\u00AD\u034F\u061C\u115F\u1160\u17B4\u17B5\u180E\u200B-\u200F\u202A-\u202E\u2060-\u206F\u3164\uFE00-\uFE0F\uFEFF\uFFA0]/g;
  function cleanText(s) {
    s = String(s || '');
    if (/<(?:span|div|td|tr|table|p|br|b|a|font|strong)\b[^>]*>/i.test(s)) s = htmlText(s);
    s = s.replace(/\r/g, '').replace(INVISIBLE, '').replace(/[\u00A0\u2007\u202F\u2000-\u200A]/g, ' ');
    if (/&(?:#\d+|#x[0-9a-f]+|[a-z]+);/i.test(s)) s = decode(s);
    s = s.replace(/!?\[([^\]\n]{0,200})\]\((?:<[^>\n]*>|[^()\s]*(?:\([^()\s]*\)[^()\s]*)*)\)/g, '$1');   // [label](url) → label
    s = s.replace(/<?\b(?:https?:\/\/|www\.)[^\s<>"'\])|]+>?/gi, ' ').replace(/\(\s*mailto:[^)\s]*\)/gi, ' ').replace(/\[\s*\]/g, ' ');
    s = s.replace(/[“”«»]/g, '"').replace(/[‘’‚‛′`]/g, "'").replace(/[‐‑‒–—]/g, '-').replace(/\t/g, ' | ');
    // markdown emphasis and headings, never the stars of a masked number ("**1234")
    // (a narration's single "*" between words, "ACH*ICICI LOMBARD GIC*PMSBY", parts them; markdown's bold doesn't)
    s = s.replace(/([A-Za-z0-9])\*(?=[A-Za-z0-9])/g, '$1 ').replace(/^\s{0,3}#{1,6}\s+/gm, '').replace(/\*+(?=[A-Za-z(])|([A-Za-z:).])\*+/g, '$1').replace(/_{2,}/g, ' ');
    // a currency in its own cell before the figure ("Order Amount: | INR | 1234.50") is that figure's
    s = s.replace(/(^|[|\s])(INR|Rs\.?|₹)\s*\|\s*(?=\d)/gim, '$1$2 ');
    // a date set out in cells ("01 | 08 | 2026") is one date
    s = s.replace(/\b(\d{1,2})\s*\|\s*(\d{1,2})\s*\|\s*((?:19|20)\d{2})\b/g, '$1-$2-$3');
    // bullets used as separators between label and value ("Refund amount * ₹768.70 * Estimated refund time * by Tue")
    s = s.replace(/(\S)[ ]+[*•][ ]+(?=\S)/g, '$1 | ');
    return s;
  }
  function linesOf(s) {
    var out = [];
    s.split('\n').forEach(function (line) {
      var bullet = /^\s*[*•·]\s+/.test(line);
      var cells = line.split('|').map(trim).filter(function (c) { return c && /[\p{L}\p{N}₹$€£%]/u.test(c); });
      if (!cells.length) return;
      var l = cells.join(' | ');
      out.push(bullet ? '• ' + l.replace(/^[*•·]\s*/, '') : l);
    });
    return out;
  }
  var MONEY_HINT = /(?:₹|\brs\.?\s?\d|\binr\s?\d|\d\s?inr\b|debited|credited|spent|paid|refund|statement|due|allot|dividend|deposit|premium|order)/i;
  function moneyScore(lines) { var n = 0; for (var i = 0; i < lines.length && i < 400; i++) if (MONEY_HINT.test(lines[i])) n++; return n; }
  function bodyOf(msg) {
    // (a mail in an Indian script, read in the English its money words gloss to: engine.js glossMail)
    if (E.lib && E.lib.glossMail) msg = E.lib.glossMail(msg);
    var subject = trim(cleanText(String(msg.subject || '').replace(/\b(?:https?:\/\/)?(?:www\.)?([a-z0-9][a-z0-9-]*\.(?:com|in|co\.in|net|org|io|app|store|shop)(?:\.[a-z]{2})?)(?:\/[^\s]*)?/gi, '$1'))).replace(/\s*\|\s*/g, ' | ');
    var tl = linesOf(cleanText(msg.text || ''));
    var useHtml = false, hl = null, tlen = tl.join(' ').length;
    if (msg.html && (tlen < 80 || moneyScore(tl) === 0 || /^default email text body\.?$/i.test(tl.join(' ').trim()))) {
      hl = linesOf(cleanText(htmlText(msg.html)));
      if (moneyScore(hl) > moneyScore(tl) || (tlen < 80 && hl.join(' ').length > tlen)) useHtml = true;
    }
    var lines = useHtml ? hl : tl;
    // a very long mail (a newsletter, a statement pasted in) is read for its first part: money mail says it up top
    if (lines.length > 500) lines = lines.slice(0, 500);
    var body = lines.join('\n');
    if (body.length > 24000) body = body.slice(0, 24000);
    return { subject: subject, body: body, src: useHtml ? 'html' : 'text' };
  }

  /* ------------------------------------------------------------ 2. tokens: what money mail is made of */
  var MON = { jan: 1, feb: 2, mar: 3, apr: 4, may: 5, jun: 6, jul: 7, aug: 8, sep: 9, sept: 9, oct: 10, nov: 11, dec: 12 };
  var MONRE = '(jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|june?|july?|aug(?:ust)?|sep(?:t(?:ember)?)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)';
  function monOf(s) { return MON[lc(s).slice(0, 3)] || 0; }
  function y4(y) { y = +y; return y < 100 ? 2000 + y : y; }
  var DATE_RES = [
    [/\b(\d{4})-(\d{1,2})-(\d{1,2})(?![\d-])/g, function (m) { return [+m[1], +m[2], +m[3]]; }],
    [/\b(\d{1,2})([-\/.])(\d{1,2})\2(\d{4}|\d{2})(?![\d\/.-]\d)/g, function (m) { return [y4(m[4]), +m[3], +m[1]]; }],
    // (a year of four figures may end its clause with a colon, "on 11-Oct-2026:"; two figures before a colon are a time)
    // (never a time after the day: "Mon, 26 Oct, 10 AM - 6 PM" is 26 Oct at ten, not 26 Oct 2010)
    [new RegExp('\\b(\\d{1,2})(?:st|nd|rd|th)?[\\s\\-\\/.,]*' + MONRE + '\\.?[\\s\\-\\/.,\']*(\\d{4}(?!\\d|:\\d)|\\d{2}(?![\\d:]|\\s*(?:am|pm|a\\.m|p\\.m|hrs?|hours)\\b))', 'gi'), function (m) { return [y4(m[3]), monOf(m[2]), +m[1]]; }],
    [new RegExp('\\b' + MONRE + '\\.?(?:\\s+|-)(\\d{1,2})(?:st|nd|rd|th)?,?(?:\\s*|-)(\\d{4})\\b', 'gi'), function (m) { return [+m[3], monOf(m[1]), +m[2]]; }],
    [new RegExp('\\b(\\d{1,2})(?:st|nd|rd|th)?\\s+' + MONRE + '\\b(?![\\s\\-\\/.,\']*\\d)', 'gi'), function (m) { return [0, monOf(m[2]), +m[1]]; }],
    [new RegExp('\\b' + MONRE + '\\.?\\s+(\\d{1,2})(?:st|nd|rd|th)?\\b(?!,?\\s*\\d{4}|\\s*\\d|:)', 'gi'), function (m) { return [0, monOf(m[1]), +m[2]]; }],
  ];
  /* a date with no year: the year that puts it nearest the mail (a promise "by Jul 15" is ahead of it) */
  function yearFor(mo, d, ref) {
    var y = +ref.slice(0, 4), best = null, gap = 1e9;
    [y - 1, y, y + 1].forEach(function (yy) {
      if (!validDay(yy, mo, d)) return;
      var g = Math.abs(dayNum(yy + '-' + pad(mo) + '-' + pad(d)) - dayNum(ref));
      if (g < gap) { gap = g; best = yy; }
    });
    return best;
  }
  function lex(flat, ref) {
    var toks = [], m;
    var taken = [];   // character spans already a token: a later, weaker reading never overlaps one
    // (the characters taken, marked: a span is free when none of its characters is; a mail of a thousand figures
    // checked every new token against every one before it. Spans that aren't plain ones are checked the old way)
    var mark = typeof Uint8Array === 'function' ? new Uint8Array(flat.length + 1) : null, odd = [];
    function free(s, e) {
      if (!mark || !(e > s) || s < 0 || e > flat.length) { for (var i = 0; i < taken.length; i++) { var t = taken[i]; if (s < t.e && t.s < e) return false; } return true; }
      for (var j = 0; j < odd.length; j++) { var o = odd[j]; if (s < o.e && o.s < e) return false; }
      for (var p = s; p < e; p++) if (mark[p]) return false;
      return true;
    }
    function add(t) {
      if (!free(t.s, t.e)) return false;
      toks.push(t); taken.push(t);
      if (mark && t.e > t.s && t.s >= 0 && t.e <= flat.length) { for (var p = t.s; p < t.e; p++) mark[p] = 1; } else odd.push(t);
      return true;
    }
    // masked digits: XX1234, **1234, ••••1234, 15XXXXXX9876, XXXX-1234, ending 1234, ending with/in 1234
    // (the second form starts where a run of x, * or • starts: tried from inside one, a run with no digits after it was
    // walked again from every one of its characters, 24,000 x's in a broken link seconds without a JIT; the match a
    // run can give is the one its first character gives)
    var mask = /\b\d{0,6}(?:[x*•]{2,}|\.{3,})[\s\-]?(\d{2,6})\b|(?<![x*•])(?:[x*•]{2,})[\s\-]?(\d{2,6})\b|\bending(?:\s+(?:with|in|no\.?))?\s*[:\-]?\s*(?:[x*•]+[\s\-]?)?(\d{2,6})\b/gi;
    while ((m = mask.exec(flat))) { var d = m[1] || m[2] || m[3]; if (d) add({ t: 'MASK', v: d.slice(-4), s: m.index, e: m.index + m[0].length, raw: m[0] }); }
    // "A/c ...6083" (dots for the hidden digits) and IDBI's "A/c NN5826"
    var dotted = /\b(?:[aA]\/[cC]|[aA](?:ccount|CCOUNT|cct|CCT)|[cC](?:ard|ARD))(?:\s*[nN][oO]\.?)?[\s:]*(?:\.{2,}|NN)(\d{3,6})\b/g;
    while ((m = dotted.exec(flat))) { var ds0 = m.index + m[0].lastIndexOf(m[1]); add({ t: 'MASK', v: m[1].slice(-4), s: ds0, e: ds0 + m[1].length, raw: m[1] }); }
    // "x1234", "X5678" after an account or card word (Kotak's "Ac X6610" too); "account 4321" (four digits alone, after the word)
    var single = /(?:^|[^\w])([xX*])(\d{4})\b(?!\d)/g;
    while ((m = single.exec(flat))) {
      var at = m.index + m[0].indexOf(m[1]);
      if (/(?:a\/c|\bac|account|acct|card|ending|no\.?|number|debit|credit)[\s:|.\-#]*$/i.test(flat.slice(Math.max(0, at - 40), at))) add({ t: 'MASK', v: m[2], s: at, e: at + 5, raw: m[1] + m[2] });
    }
    // and a whole account number printed after the word (old alerts: "Your a/c 30001234 is credited"): its last four
    var bare = /\b(?:a\/c|account|acct)(?:\s*(?:no\.?|number|ending(?:\s*(?:with|in))?))?\s*[:\-]?\s*(\d{4}|\d{6,18})\b(?![\d,.]|\s*[x*•])/gi;
    while ((m = bare.exec(flat))) { var bs = m.index + m[0].lastIndexOf(m[1]); add({ t: 'MASK', v: m[1].slice(-4), s: bs, e: bs + m[1].length, raw: m[1] }); }
    var cardNo = /\b(?:on|your|using)\s+(?:\w+\s+){0,2}card\s*(?:no\.?|number|ending)?\s*[:\-]?\s*(\d{4})\b(?![\d,.\/-])/gi;
    while ((m = cardNo.exec(flat))) { var cs = m.index + m[0].lastIndexOf(m[1]); add({ t: 'MASK', v: m[1], s: cs, e: cs + 4, raw: m[1] }); }
    // order numbers: Amazon's 3-7-7, Myntra's 7-7-7
    var ord = /\b(\d{3}-\d{7}-\d{7}|\d{7}-\d{7}-\d{7})\b/g;
    while ((m = ord.exec(flat))) add({ t: 'ORDER', v: m[1], s: m.index, e: m.index + m[0].length, raw: m[0] });
    var isin = /\b(IN[EF0-9][A-Z0-9]{8}\d)\b/g;
    while ((m = isin.exec(flat))) add({ t: 'ISIN', v: m[1], s: m.index, e: m.index + m[0].length, raw: m[0] });
    DATE_RES.forEach(function (pair) {
      var re = new RegExp(pair[0].source, pair[0].flags), mm;
      while ((mm = re.exec(flat))) {
        var p = pair[1](mm), y = p[0], mo = p[1], dd = p[2];
        if (!mo) continue;
        if (!y) { y = yearFor(mo, dd, ref); if (!y) continue; }
        if (!validDay(y, mo, dd)) continue;
        add({ t: 'DATE', v: y + '-' + pad(mo) + '-' + pad(dd), s: mm.index, e: mm.index + mm[0].length, raw: mm[0], noYear: !p[0] });
      }
    });
    // days said in words, from the day the mail was sent
    var rel = /\b(today|tomorrow|yesterday)\b/gi;
    while ((m = rel.exec(flat))) add({ t: 'DATE', v: addDays(ref, { today: 0, tomorrow: 1, yesterday: -1 }[lc(m[1])]), s: m.index, e: m.index + m[0].length, raw: m[0], rel: true });
    var tm = /\b([01]?\d|2[0-3]):([0-5]\d)(?::([0-5]\d))?\s*(am|pm|a\.m\.|p\.m\.)?(?:\s*(?:ist|hrs?))?/gi;
    while ((m = tm.exec(flat))) {
      var h = +m[1];
      if (m[4]) { var pm = /^p/i.test(m[4]); if (pm && h < 12) h += 12; if (!pm && h === 12) h = 0; }
      add({ t: 'TIME', v: pad(h) + ':' + m[2], s: m.index, e: m.index + m[0].length, raw: m[0] });
    }
    // ₹ 1,234.56 / Rs.1234 / INR 1,050,000.00 / Rs 20000.00 / ₹1.5 Cr / 632/-
    var lead = /(₹|₨|\brs\.?|\binr\.?|\brupees)\s*[:.]?\s*(-?\d[\d,]*(?:\.\d{1,3})?)(\s*\/-)?(\s*(?:lakhs?|lacs?|crores?|cr\b))?/gi;
    while ((m = lead.exec(flat))) {
      var raw = m[2].replace(/^-/, '');
      if (!/\d/.test(raw) || /^\d/.test(flat.charAt(m.index + m[0].length))) continue;
      var v = num(raw), unit = lc(m[4] || '').trim();
      if (unit) v = v * (/^cr/.test(unit) ? 1e7 : 1e5);
      add({ t: 'AMT', v: money(v), s: m.index, e: m.index + m[0].length, raw: m[0], cur: 'INR' });
    }
    var trail = /(?:^|[^\w.,])(\d[\d,]*(?:\.\d{1,2})?)\s*(inr\b|rupees\b|\/-|rs\b\.?)/gi;
    while ((m = trail.exec(flat))) {
      var s0 = m.index + m[0].indexOf(m[1]);
      if (/^rs/i.test(m[2]) && /^\s*\d/.test(flat.slice(m.index + m[0].length, m.index + m[0].length + 3))) continue;
      add({ t: 'AMT', v: money(num(m[1])), s: s0, e: m.index + m[0].length, raw: m[0].trim(), cur: 'INR' });
    }
    // a balance printed bare after its words, paise and all ("The balance in the account is now 653003.23")
    var balBare = /\bbalance\s+(?:in|of|on)\s+(?:the|your)\s+(?:a\/c|account)\s+is\s+(?:now\s+)?(\d[\d,]*\.\d{2})\b(?![\d\/-]|\s*%)/gi;
    while ((m = balBare.exec(flat))) { var bb = m.index + m[0].lastIndexOf(m[1]); add({ t: 'AMT', v: money(num(m[1])), s: bb, e: bb + m[1].length, raw: m[1], cur: 'INR', bare: true }); }
    var ofAmt = /\b(?:payment|premium|amount|sum)\s+of\s+(\d[\d,]*(?:\.\d{1,2})?)\b(?![\d\/-]|\s*(?:%|units|shares|days|months|years))/gi;
    while ((m = ofAmt.exec(flat))) { var os = m.index + m[0].lastIndexOf(m[1]); if (num(m[1]) >= 10) add({ t: 'AMT', v: money(num(m[1])), s: os, e: os + m[1].length, raw: m[1], cur: 'INR', bare: true }); }
    var fx = /(?:\b(usd|eur|gbp|aed|sgd|aud|cad|jpy)\s*|([$€£¥]))\s*(\d[\d,]*(?:\.\d{1,2})?)/gi;
    while ((m = fx.exec(flat))) add({ t: 'AMT', v: money(num(m[3])), s: m.index, e: m.index + m[0].length, raw: m[0], cur: (m[1] || { '$': 'USD', '€': 'EUR', '£': 'GBP', '¥': 'JPY' }[m[2]] || '').toUpperCase() });
    // ...and the figure before its code: "300.00 USD", "Your USD balance: 1,240.55 USD"
    var fxT = /(?:^|[^\w.,])(\d[\d,]*(?:\.\d{1,2})?)\s?(usd|eur|gbp|aed|sgd|aud|cad|jpy)\b/gi;
    while ((m = fxT.exec(flat))) { var fts = m.index + m[0].indexOf(m[1]); add({ t: 'AMT', v: money(num(m[1])), s: fts, e: m.index + m[0].length, raw: m[0].replace(/^[^\d]+/, ''), cur: m[2].toUpperCase() }); }
    var vpa = /\b([a-z0-9][a-z0-9.\-_]{1,60})@([a-z][a-z0-9]{1,24})\b(?![.\-@][a-z])/gi;
    while ((m = vpa.exec(flat))) add({ t: 'VPA', v: lc(m[1] + '@' + m[2]), s: m.index, e: m.index + m[0].length, raw: m[0] });
    var pct = /\b(\d{1,3}(?:\.\d{1,4})?)\s?%/g;
    while ((m = pct.exec(flat))) add({ t: 'PCT', v: +m[1], s: m.index, e: m.index + m[0].length, raw: m[0] });
    toks.sort(function (a, b) { return a.s - b.s; });
    return toks;
  }

  /* ------------------------------------------------------------ 3. label/value pairs
     Money mail is mostly tables, however it's drawn: "Label: value" (one line or several to a line), a label
     cell and the cell after it, a label line and the line under it, a row of labels over a row of values. Each
     pair keeps where its value sits, so the tokens inside it (an amount, a date, digits) are the label's. */
  var LABELISH = /\b(?:amount|amt|date|time|merchant|name|number|no\.?|id|balance|bal|due|total|limit|ref|reference|utr|rrn|status|mode|method|description|info|remarks?|narration|account|a\/c|card|units|nav|folio|scheme|fund|price|quantity|qty|premium|policy|sum|plan|tenure|interest|rate|maturity|deposit|company|isin|security|biller|beneficiary|payee|sender|remitter|bank|ifsc|order|invoice|bill|refund|charges?|fee|tax|gst|tds|dividend|shares?|allot\w*|bid|hold|application|applied|unblock\w*|period|cycle|statement|instruction|transfer|frequency|type|channel|location|terminal|category|code|holder|nominee|insured|cover|idv|plan|value|asset|fare|price|paid|payment|method|receipt|booking|ticket|pnr|crn|product|vehicle|registration|insurer|validity|expiry|tenor|term|pension|arrears|sub-?total|discounts?|coupon|savings|shipping|handling)\b/i;
  function normLabel(s) {
    return lc(s).replace(/\([^)]*\)/g, ' ').replace(/₹|\b(?:rs|inr)\b\.?/g, ' ').replace(/^[\s\d.)•*#-]*(?=[a-z])/, '').replace(/[*:#.\-–\s]+$/, '').replace(/\s+/g, ' ').trim();
  }
  // shipping still to come ("Once packed and shipped, we shall update you", "it will be shipped soon"): no step taken yet
  var NOT_YET_SHIPPED = /\bonce (?:it(?:'s| is) |they(?:'re| are) )?(?:packed and )?(?:shipped|dispatched)\b|\b(?:will|shall) be (?:packed and )?(?:shipped|dispatched)\b|\bwhen (?:it(?:'s| is)|they(?:'re| are)) (?:shipped|dispatched)\b|\bbefore (?:it(?:'s| is) )?(?:shipped|dispatched)\b/g;
  function isLabel(cell, strict) {
    var c = trim(cell).replace(/^[•*\-]\s*/, '');
    if (!c || c.length > 64) return false;
    var body = c.replace(/\([^)]*\)/g, '').replace(/[:*#]+\s*$/, '');
    if (!/[a-z]/i.test(body) || /\d{3,}/.test(body) || /[.!?]\s*$/.test(c.replace(/\b(?:no|rs|nos)\.\s*$/i, ''))) return false;
    // (a line that carries its own sum, "Cover ₹1 Crore", is a label with its value, not a label over the next line)
    if (/(?:₹|\brs\.?|\binr)\s*\d/i.test(body)) return false;
    var words = body.trim().split(/\s+/).length;
    if (words > 9) return false;
    if (/:\s*$/.test(c)) return true;
    return strict ? LABELISH.test(body) && words <= 9 : LABELISH.test(body);
  }
  function valueish(cell) { var c = trim(cell); return !!c && c.length <= 140 && !/:\s*$/.test(c); }
  function pairsOf(lines, lineAt, flat) {
    var out = [];
    function push(label, value, at) {
      var key = normLabel(label);
      value = trim(value).replace(/^(?:[:–|]|-(?!\d))\s*/, '');
      if (!key || !value || key.length > 60) return;
      out.push({ key: key, label: trim(label), value: value, s: at, e: at + value.length });
    }
    // (where each cell of a line starts, worked out once a line: a row of a thousand cells was split a thousand times)
    var cellOffs = {};
    function cellAt(li, ci) {
      var offs = cellOffs[li];
      if (!offs) {
        var cells = lines[li].split(' | '), off = lineAt[li];
        offs = cellOffs[li] = [off];
        for (var k = 0; k < cells.length; k++) { off += cells[k].length + 3; offs.push(off); }
      }
      return offs[ci];
    }
    var used = {};
    for (var r0 = 0; r0 < lines.length; r0++) {
      var k = 0;
      // (a "Label: value" line, "Qty: 38", is a pair of its own, never a bare label over a line below)
      while (r0 + k < lines.length && lines[r0 + k].indexOf(' | ') < 0 && isLabel(lines[r0 + k], true) && !/:\s*$/.test(lines[r0 + k]) && !/^[A-Za-z][A-Za-z\/&'. ]{1,40}:\s+\S/.test(lines[r0 + k])) k++;
      if (k >= 2 && r0 + 2 * k <= lines.length) {
        var ok = true;
        for (var q = 0; q < k; q++) { var v = lines[r0 + k + q]; if (v.indexOf(' | ') >= 0 || isLabel(v, true) || !/\d/.test(v + lines[r0 + k].slice(0, 1)) && q === 0) { ok = false; break; } }
        if (ok) { for (var q2 = 0; q2 < k; q2++) { push(lines[r0 + q2], lines[r0 + k + q2], lineAt[r0 + k + q2]); used[r0 + q2] = used[r0 + k + q2] = 1; } r0 += 2 * k - 1; }
      }
    }
    for (var i = 0; i < lines.length; i++) {
      if (used[i]) continue;
      var cells = lines[i].split(' | ').map(function (c) { return c.replace(/^•\s*/, ''); });
      // numbered rows ("01. | Net Dividend (Rs.) | 504.00"): the number is not a cell of the table
      var startCi = /^\d{1,2}\.?$/.test(cells[0]) && cells.length >= 3 ? 1 : 0;
      // a row of labels over a row of values with as many cells
      if (cells.length - startCi >= 2 && cells.slice(startCi).every(function (c) { return isLabel(c, true); }) && i + 1 < lines.length) {
        var vals = lines[i + 1].split(' | ');
        // (not two "Label | value" lines: "Paid towards | Example Postpaid" over "Amount | Rs. 478.00")
        var twoPairs = cells.length - startCi === 2 && LABELISH.test(trim(vals[startCi] || '')) && !/\d/.test(vals[startCi] || '') && /\d/.test(vals[startCi + 1] || '');
        if (vals.length === cells.length && vals.some(function (v) { return /\d/.test(v); }) && !twoPairs) {
          for (var c0 = startCi; c0 < cells.length; c0++) {
            var vs = cellAt(i + 1, c0);
            push(cells[c0], vals[c0], flat.indexOf(trim(vals[c0]), vs - 2) >= 0 ? flat.indexOf(trim(vals[c0]), vs - 2) : vs);
          }
          continue;
        }
      }
      var rawCells = lines[i].split(' | ');
      for (var c = startCi; c < cells.length; c++) {
        var cell = cells[c], base = cellAt(i, c) + (rawCells[c].length - cell.length);
        // "Label: value" segments inside one cell (several to a line: "Amount: INR 1234.56 Date: 30/09/2026")
        var segRe = /(?:^|(?:[.,;]\s+|\s{1,3}))((?:[A-Z][A-Za-z\/&'.]*|[a-z][a-z\/&'.]*)(?:[ \t][A-Za-z\/&'.()]+){0,6}?)\s*(?:\([^)]{0,12}\))?\s*:\s+(?=\S)/g, sm, segs = [];
        while ((sm = segRe.exec(cell))) {
          var lab = sm[1].split(/[.!?]\s+/).pop();
          if (!lab || !LABELISH.test(lab) && !/^(?:[A-Z][a-z]+\s?){1,4}$/.test(lab)) continue;
          if (lab.split(/\s+/).length > 7) continue;
          segs.push({ label: lab, s: sm.index + sm[0].lastIndexOf(lab), vs: sm.index + sm[0].length });
        }
        // (a label doubled up with nothing after it, "Invoice Date: : | 30-Nov-2019": the next cell is its value)
        if (segs.length === 1 && c + 1 < cells.length && !/[^\s:.\-–|]/.test(cell.slice(segs[0].vs)) && valueish(cells[c + 1])) { push(segs[0].label, cells[c + 1], cellAt(i, c + 1)); c++; continue; }
        if (segs.length) {
          segs.forEach(function (g, k) {
            var end = k + 1 < segs.length ? segs[k + 1].s : cell.length;
            push(g.label, cell.slice(g.vs, end).replace(/[\s.,;]+$/, ''), base + g.vs);
          });
          continue;
        }
        if (isLabel(cell, c + 1 >= cells.length)) {
          var next = null, at = 0;
          if (c + 1 < cells.length) { next = cells[c + 1]; at = cellAt(i, c + 1); c++; }
          else if (i + 1 < lines.length && cells.length === 1) {
            var nl = lines[i + 1].split(' | ')[0].replace(/^•\s*/, '');
            if (valueish(nl) && !isLabel(nl, true)) { next = nl; at = lineAt[i + 1]; }
          }
          // a label broken over two lines ("Payment" / "ID" / "300000001"): the word above is part of it
          var lab = cell;
          if (cells.length === 1 && i > 0 && !used[i - 1] && /^[A-Z][a-z]{2,14}$/.test(trim(lines[i - 1])) && /^(?:[A-Z][a-z]{1,14}|ID|No\.?)$/.test(trim(cell))) lab = trim(lines[i - 1]) + ' ' + cell;
          if (next && valueish(next)) push(lab, next, at);
        }
      }
    }
    return out;
  }
  /* A table sent as plain text one cell to a line, each cell led by a tab, a long header wrapping onto the next line
     (a registrar's allotment advice: "\t\tSHARES APPLIED FOR" / "(FIGURE IN NOS.)" … then "\t\t10800" …): each block of
     cells becomes one row, "a | b | c", and a row of labels is put right over its row of values, so the pairs read as a
     table's do. Only blocks of three or more cells followed by another block of as many: indented prose is left alone. */
  /* An order paid in part from a shop's own wallet, its summary printing the part ("Amazon Pay balance: -Rs.3,020.90"
     over "Order Total: Rs.1,578.10"): the wallet's part is money spent from that wallet (no bank's mail tells of it);
     the rest is the card's or the bank's, and their own mail tells of that */
  function walletPartOfOrder(doc, ctx, events) {
    if (ctx.failed || ctx.future || ctx.nudge) return;
    var ord = events.filter(function (e) { return e.type === 'order' && !/^(?:cancelled|declined|returned|refunded)$/.test(e.status || ''); })[0];
    if (!ord || events.some(function (e) { return e.type === 'move' && e.dir === 'out'; })) return;
    var m = /^[ \t|*]*((?:amazon|flipkart|paytm|mobikwik|freecharge|phonepe|airtel|jio|tata neu|myntra|ajio|swiggy|zomato|ola)\s+(?:pay(?: balance)?|wallet|money|cash|balance|credits?))(?:\s+balance)?\s*(?:used|applied|redeemed)?\s*[:|]\s*-\s*(?:₹|rs\.?|inr)\s*(\d[\d,]*(?:\.\d{1,2})?)\s*\|?\s*$/im.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 6000));
    if (!m || !(num(m[2]) > 0)) return;
    var w = capWords(lc(m[1])).replace(/ Pay Balance$/, ' Pay').replace(/ Balance$/, '');
    var mv = { type: 'move', dir: 'out', amt: num(m[2]), date: doc.ref, via: { kind: 'wallet', inst: w }, party: ord.shop || senderBrand(doc), purpose: 'purchase' };
    if (ord.order) mv.order = ord.order;
    events.push(mv);
  }
  function tabTables(body) {
    if (body.indexOf('\t') < 0) return body;
    var L = body.split('\n'), blocks = [], i = 0;
    var cellStart = function (x) { return /^[ \u00a0]*\t/.test(x) && trim(x) !== ''; };
    // the blocks: runs of tab-led cells (with their wrapped lines), and where each starts and ends
    while (i < L.length) {
      if (!cellStart(L[i])) { i++; continue; }
      var b0 = i, cells = [];
      while (i < L.length && trim(L[i]) !== '') {
        if (cellStart(L[i])) cells.push(trim(L[i])); else if (cells.length) cells[cells.length - 1] += ' ' + trim(L[i]); else break;
        i++;
      }
      blocks.push({ s: b0, e: i, cells: cells });
    }
    var keep = {};
    for (var k = 0; k + 1 < blocks.length; k++) {
      var a = blocks[k], z = blocks[k + 1];
      var gap = L.slice(a.e, z.s).every(function (x) { return trim(x) === ''; });
      if (gap && a.cells.length >= 2 && a.cells.length === z.cells.length && (a.cells.length >= 3 || keep[k]) ) { keep[k] = 1; keep[k + 1] = 1; }
    }
    if (!Object.keys(keep).length) return body;
    var out = [], bi = 0;
    for (var j = 0; j < L.length; j++) {
      while (bi < blocks.length && blocks[bi].e <= j) bi++;
      var bk = blocks[bi];
      if (bk && keep[bi] && j === bk.s) {
        out.push(bk.cells.join(' | '));
        j = bk.e - 1;
        // (no blank line between a row of labels and the row of its values)
        if (keep[bi + 1]) { var nx = blocks[bi + 1]; if (L.slice(bk.e, nx.s).every(function (x) { return trim(x) === ''; })) j = nx.s - 1; }
        continue;
      }
      out.push(L[j]);
    }
    return out.join('\n');
  }
  function docOf(msg) {
    if (msg && typeof msg.text === 'string' && msg.text.indexOf('\t') >= 0) { var tt = tabTables(msg.text); if (tt !== msg.text) msg = Object.assign({}, msg, { text: tt }); }
    var b = bodyOf(msg);
    var ref = mailDay(msg.date);
    var lines = (b.subject + '\n' + b.body).split('\n');
    var flat = lines.join('\n');
    var lineAt = [], n = 0;
    lines.forEach(function (l) { lineAt.push(n); n += l.length + 1; });
    var toks = lex(flat, ref);
    var inst = E.institution ? E.institution(msg.from || '') : null;
    var from = lc((/<([^>]+)>/.exec(msg.from || '') || [0, msg.from || ''])[1]).trim();
    var doc = { msg: msg, subject: b.subject, lines: lines, lineAt: lineAt, flat: flat, low: lc(flat), bodyAt: b.subject.length + 1, toks: toks,
                ref: ref, from: from, domain: from.split('@')[1] || '', inst: inst, kind: inst ? inst.kind : '', src: b.src,
                files: (msg.attachments || []).map(function (a) { return String((a && a.filename) || a || ''); }).join(' ') };
    doc.pairs = pairsOf(lines.slice(1), lineAt.slice(1), flat);
    doc.lead = lc(flat.slice(doc.bodyAt, doc.bodyAt + 700));
    doc.head = lc(b.subject) + '\n' + doc.lead;
    // each token inside a pair's value belongs to that pair
    doc.pairs.forEach(function (p) {
      p.toks = toks.filter(function (t) { return t.s >= p.s - 1 && t.e <= p.e + 2; });
      p.toks.forEach(function (t) { if (!t.pair) t.pair = p; });
      // (rupees given as the foreign figure's worth, "Total: ¥86.00 (approx ₹1,032)", over it; never a fee, tax or saving beside it)
      var pa = p.toks.filter(function (t) { return t.t === 'AMT'; }), amt = fxWorth(flat, pa) || pa[0];
      if (amt) { p.amt = amt.v; if (amt.cur && amt.cur !== 'INR') p.amtCur = amt.cur; }
      else { var nm = /^(-?\d[\d,]*(?:\.\d{1,3})?)\s*(?:\/-)?\s*(?:dr|cr)?$/i.exec(p.value.replace(/^(?:rs\.?|inr|₹)\s*/i, '')); if (nm && nm[1].split('.')[0].replace(/[,\-]/g, '').length <= 10 && !(/\b(?:no|number|id|code|account|a\/c|phone|mobile|pin)\b/.test(p.key) && !/amount/.test(p.key))) p.amt = money(num(nm[1])); }
      var dt = p.toks.filter(function (t) { return t.t === 'DATE'; })[0];
      if (dt) p.date = dt.v;
      var mk = p.toks.filter(function (t) { return t.t === 'MASK'; })[0];
      if (mk) p.mask = mk.v;
      // a bare figure under a money label ("Amount (INR) | 297,367.00") is an amount like any other
      // (a sentence above a number, "We have processed your payment" over a policy's number, is no label)
      if (p.amt != null && !amt && MONEY_KEY.test(p.key) && !/\b(?:no|number|id|code|units?|quantity|qty|shares?|count|%|percent|rate|days?|months?|years?|tenure)\b/.test(p.key) &&
          p.key.split(' ').length <= 5 && !/\b(?:we|you|your|have|has|had|is|was|were|been|thank|dear|please)\b/.test(p.key)) {
        var vs = flat.indexOf(p.value, p.s - 2); if (vs < 0) vs = p.s;
        var syn = { t: 'AMT', v: p.amt, s: vs, e: vs + p.value.length, raw: p.value, cur: 'INR', pair: p, synth: true };
        toks.push(syn); p.toks.push(syn);
      }
    });
    toks.sort(function (a, b) { return a.s - b.s; });
    // the same text with every amount and date filled in (same length, same offsets): patterns that read a
    // sentence's words ("payment of ... credited towards your card") no longer trip on the dots inside "Rs.456.00"
    var nl = '', at = 0;
    toks.forEach(function (t) {
      if (t.t !== 'AMT' && t.t !== 'DATE') return;
      var c = t.t === 'AMT' ? '9' : '0';
      if (t.s >= at) { nl += doc.low.slice(at, t.s) + new Array(t.e - t.s + 1).join(c); at = t.e; }
      else if (t.e > at) { nl += new Array(t.e - at + 1).join(c); at = t.e; }
    });
    // and the dot of an abbreviation ("Account No. 15XX8888", "Mr. Example") is not the end of a sentence
    doc.nlow = (nl + doc.low.slice(at)).replace(/\b(no|nos|a\/c|acct|ac|mr|mrs|ms|dr|st|ltd|pvt|co|txn|ref|avl|bal|amt|approx|dt|sr|jr|vs|inc|corp|m\/s|i\.e|e\.g)\./g, '$1 ');
    doc.lead = doc.nlow.slice(doc.bodyAt, doc.bodyAt + 700);
    doc.head = doc.nlow.slice(0, doc.bodyAt - 1) + '\n' + doc.lead;
    return doc;
  }
  var MONEY_KEY = /amount|amt\b|total|balance|\bbal\b|premium|value|price|\bdue\b|dues|payable|paid|refund|dividend|principal|cover|sum (?:assured|insured)|limit|outstanding|fee|charges?|order size|invoice|bill\b|nav\b|payment$/;
  // the rupee worth printed right after a foreign figure: "¥86.00 (approx ₹1,032)", "$20.00 (₹1,700 approx)", "€120 (≈ INR 10,800)"
  function fxWorth(flat, toks) {
    var a = toks.filter(function (t) { return t.t === 'AMT'; });
    for (var i = 0; i + 1 < a.length; i++) {
      if (!a[i].cur || a[i].cur === 'INR' || a[i + 1].cur !== 'INR' || !(a[i + 1].v > 0)) continue;
      var gap = lc(flat.slice(a[i].e, a[i + 1].s)), after = lc(flat.slice(a[i + 1].e, a[i + 1].e + 12));
      if (/^\s*[(\[]?\s*(?:approx\.?|approximately|about|~|≈|equivalent to|i\.e\.?)?\s*$/.test(gap) && (/approx|about|~|≈|equivalent|i\.e/.test(gap) || /^\s*(?:approx|\))/.test(after))) return a[i + 1];
    }
    return null;
  }
  function kv(doc, re) { for (var i = 0; i < doc.pairs.length; i++) if (re.test(doc.pairs[i].key)) return doc.pairs[i]; return null; }
  function kvAll(doc, re) { return doc.pairs.filter(function (p) { return re.test(p.key); }); }

  /* ------------------------------------------------------------ 4. what each amount is
     Its label first ("Avl Bal", "Minimum Amount Due", "Sum Assured"), then the words right before it, then the
     words right after it ("is debited", "will be credited"). */
  var KEY_ROLES = [
    ['bal', /\b(?:avl|available|avail|closing|ledger|clear(?:ed)?|wallet|updated|current|account|a\/c)\b.*\bbal(?:ance)?\b|^bal(?:ance)?$|^balance (?:available|amount)/],
    ['limit', /\blimit\b|\blmt\b|available credit/],
    ['min', /\bmin(?:imum)?\b.*\b(?:due|payable|payment)\b|^mad$/],
    ['total', /\btotal\b.*\b(?:due|outstanding|payable|dues)\b|\b(?:amount|amt) due\b|^outstanding|statement (?:balance|amount)|current (?:dues|outstanding)|^total dues|last statement balance/],
    ['bill', /\b(?:bill|invoice) amount\b|^amount payable|^bill$/],
    ['refund', /refund/],
    ['premium', /premium/],
    ['cover', /sum (?:assured|insured)|\bcover|\bidv\b|insured declared value/],
    ['maturity', /maturity (?:amount|value)/],
    ['principal', /(?:deposit|principal|fd|td) amount|^principal|amount of deposit/],
    ['block', /hold amount|blocked|bid amount|amount applied|application amount/],
    ['unblock', /unblock|released/],
    ['allot', /adjusted towards allotment|allotment amount|amount adjusted/],
    ['fee', /\bfee\b|\bfees\b|charges?\b|\bgst\b|\btax\b|\btds\b|surcharge|markup|discount|saved|coupon/],
    ['price', /\bprice\b|\bmrp\b|\bnav\b|per share|per unit|face value/],
    ['orderTotal', /^(?:order |grand |net )?total(?: amount| paid| payable| order value| fare| price| cost| (?:including|incl\.?|inclusive of) (?:gst|taxes|tax|all taxes))?$|^amount paid$|^net paid$|^you paid$|^total paid$/],
    ['dividend', /dividend/],
    ['moved', /^(?:txn |transaction |payment |debit |credit |paid |withdrawal |transfer |order )?(?:amount|amt|value)(?: (?:debited|credited|paid|received|spent|transferred))?$|^amount (?:debited|credited|paid|received|spent)$|^paid amount$|^payment$|^order size$/],
    // a pension slip's "Net Pension credited": the money that came in (never its basic, its DR, its arrears or the gross)
    ['moved', /^net (?:pension|family pension) (?:credited|paid)$/],
  ];
  var BEFORE = [
    ['bal', /(?:avl\.?|available|avail\.?|a\/c|acct|account|closing|ledger|clear(?:ed)?|total available|wallet|updated|net available|current|curr\.?)\s*bal(?:ance)?\.?(?:\s+(?:available|is|was|as on [^₹\n]{0,25}|on your (?:card|wallet|account|a\/c)[^₹\n]{0,15}? is|in (?:your |the )?(?:(?:sb|savings|current|salary|ca|sa|linked)\s+)?(?:a\/c|account)[^₹\n]{0,30}))?[\s:\-|.]*(?:is|of|:)?\s*$|\bbal(?:ance)?\s*(?:available\s+)?(?:in (?:your )?(?:a\/c|account)\s*(?:is)?|is|:|-)?\s*$|balance available in your (?:a\/c|account) is\s*$/],
    ['bal', /\bbalance in (?:your|the) (?:\w+ ){0,2}(?:a\/c|account)\b[^\n₹]{0,40}?\bis(?:\s+now)?\s*$/],
    // Bank of Baroda's "Avlbl Amt:Rs.105230.00(01-11-2025 12:21:00)"
    ['bal', /\bavlbl\.?\s*(?:amt|amount|bal(?:ance)?)\.?[\s:\-|]*$/],
    ['limit', /(?:avl\.?|available|avail\.?)\s*(?:credit\s*|cash\s*)?(?:limit|lmt)\.?[\s:\-|]*(?:is|of|:)?\s*$|credit limit[\s:\-|]*(?:is|of)?\s*$/],
    ['min', /min(?:imum)?\.?\s*(?:amount|amt\.?|payment)?\s*(?:due|payable)?[\s:\-|]*(?:is|of)?\s*$/],
    ['total', /(?:total|net)\s*(?:amount|amt\.?)?\s*(?:due|outstanding|payable|dues)[\s:\-|]*(?:is|of)?\s*$|\b(?:amount|amt\.?)\s*due[\s:\-|]*(?:is|of)?\s*$|\boutstanding(?:\s*(?:amount|balance))?[\s:\-|]*(?:is|of)?\s*$|statement (?:balance|amount)[\s:\-|]*$|bill amount[\s:\-|]*(?:is|of)?\s*$|total dues?[\s:\-|]*$/],
    ['due', /(?:make|pay|clear)\s+(?:the\s+)?(?:remaining|balance|outstanding|minimum|total|pending)?\s*(?:payment|amount|dues?|bill)?\s*(?:of)?\s*$|(?:bill|dues?) of\s*$/],
    // (each a whole word: a "Life Cover ₹2.5 Crore" ends in "over" but is no "over ₹…")
    ['offer', /\b(?:up ?to|upto|worth|save|earn|win|starting (?:at|from)|as low as|at just|for just|off on|get flat|flat|extra|minimum (?:transaction|purchase|spend|order)(?: value)?(?: of)?|min\.? (?:txn|order|spend|purchase)(?: of)?|spend(?:s)? (?:of|above|over)|above|over|max(?:imum)?(?: of)?|capped at|limit of|lowest|coupon|less than|more than|below|not exceeding|exceeding|upto|minimum)\s*$/],
    ['fee', /(?:convenience|processing|late payment|late|annual|joining|renewal|service|platform|delivery|handling|surcharge|markup)\s*(?:fee|fees|charges?)?[\s:\-|]*(?:of)?\s*$|\bgst(?: @ ?[\d.]+%)?[\s:\-|]*$|\bcharges?[\s:\-|]*(?:of)?\s*$|\bfee[\s:\-|]*(?:of)?\s*$/],
    ['price', /(?:per (?:equity )?share|per unit|face value|nav)(?: of)?[\s:\-|]*$|dividend of\s*$/],
    ['premium', /premium(?:\s+payment)?(?:\s*(?:amount|paid|due|payable|received|of))?[\s:\-|]*(?:is|of|rs\.?)?\s*$/],
    // ("would be paid (Sum Assured at death) ₹ 1,50,000": the cover, its label in brackets before it)
    ['cover', /(?:sum\s*(?:assured|insured)(?:\s+(?:at|on)\s+death)?|cover(?:age)?(?: amount)?|life cover|insured for)\)?[\s:\-|]*(?:of)?\s*$/],
    ['refund', /refund(?:ed)?(?:\s*(?:amount|of|subtotal|value))?[\s:\-|]*$|total refund[\s:\-|]*$/],
    ['block', /(?:amount\s*blocked|blocked\s*amount|block(?:ed)?\s*(?:for|of|amount)|application amount|bid amount|amount (?:of|for) (?:the )?(?:bid|application)|blocked an amount of)[\s:\-|]*$/],
    ['unblock', /(?:unblock(?:ed)?(?:\s*amount)?|released|amount (?:to be )?(?:refunded|unblocked)|refund(?:ed)? ?(?:\/|or|and) ?unblock(?:ed)?(?:\s*amount)?|(?:balance|blocked) amount of)[\s:\-|()a-z.,]{0,20}$/],
    ['maturity', /maturity (?:amount|value)[\s:\-|]*(?:of)?\s*$/],
    // (a deposit's principal printed in brackets beside its interest or its Form 15H: "(Principal Rs 10,00,000.00 @ 7.00%")
    ['principal', /(?:deposit|principal|fd|td)\s*amount[\s:\-|]*(?:of)?\s*$|amount of (?:deposit|fd)[\s:\-|]*$|\(\s*principal(?:\s+amount)?[\s:\-]*$/],
    ['moved', /(?:txn\.?|transaction|payment|debit|credit|paid|withdrawal|transfer)?\s*(?:amount|amt\.?)(?:\s*(?:debited|credited|paid|received|spent|transferred))?[\s:\-|]*(?:of|is)?\s*$|(?:debited|credited|dbt|cdt|spent|paid|withdrawn|withdrawal|sent|received|transferred|deposited|refunded|reversed|charged|used|deducted|added|payment|purchase|transaction|txn\.?|imps|neft|rtgs|upi|transfer|credits|debits|reversal|instruction|withdrawal)(?:\s+(?:with|for|by|of|from|to|in|on|via|towards|worth|amounting to|amount))*[\s:\-|.]*$|unused funds of\s*$/],
    // a receipt's own words for what it received ("Received with thanks Rs.", "We acknowledge the receipt of Rs.", "your
    // donation of ₹"), and money a person sent you ("Ravi Example paid you ₹1,500")
    ['moved', /received with thanks(?: (?:a sum|an amount) of)?[\s:\-|.]*$|acknowledge (?:the )?receipt of[\s:\-|.]*$|\b(?:donation|contribution) of[\s:\-|.]*$|\b(?:paid|sent|transferred) you[\s:\-|.]*$/],
    // SBI's "Your A/C XXXXX4417 has a credit by <narration> of Rs 67,568.00": whatever the narration ("CPPC PENSION SEP26",
    // "ECS/SCSS INT/…", "INT.PD:TD A/C XXXXX7731"), the amount after it moved
    ['moved', /\b(?:a\/c|account)(?: no\.?)? [x*]*\d{3,6} has a (?:credit|debit) by [^₹\n]{1,90}? of\s*$/],
  ];
  var AFTER = [
    ['moved', /^\s*(?:\/-)?\s*(?:has been|have been|is|was|were|got|being)?\s*(?:successfully\s*)?(?:debited|credited|spent|paid|withdrawn|sent|received|transferred|deposited|refunded|reversed|charged|deducted|added|used)\b/],
    ['moved', /^\s*(?:txn\.?|transaction|payment)\s*(?:reversed|done|successful|made)|^\s*(?:cliq cash|cash|cashback)?\s*added to your/],
    // Bank of Baroda's shorthand: "Rs.540.00 Dr. from A/C XXXXXX6083", "Rs.900.00 Cr. to A/C …"
    ['moved', /^\s*(?:dr|cr)\.?\s+(?:from|to|in)\s+(?:your\s+)?(?:a\/c|account|acct)\b/],
    ['bal', /^\s*(?:is (?:your )?)?(?:available )?bal(?:ance)?\b/],
    ['offer', /^\s*(?:cashback|off\b|discount|instant discount|worth of|reward)/],
    ['due', /^\s*(?:is|are)\s*(?:due|overdue|pending|payable)\b|^\s*(?:within timeline|to avoid)/],
  ];
  function roleOf(doc, t) {
    if (t.role) return t.role;
    var role = '';
    if (t.pair) for (var k = 0; k < KEY_ROLES.length && !role; k++) if (KEY_ROLES[k][1].test(t.pair.key)) role = KEY_ROLES[k][0];
    // an amount in brackets right after another is its breakdown ("₹88.5 (₹75 + GST)")
    // a threshold, not money that moved: "INR 5 crores and above", "₹500 or more"
    // (a card mailer's footnote mark may sit between: "spent ₹20,000(*) and above in a month")
    if (!role && /^\s*(?:\(\s*[*\d†#]{1,3}\s*\)|[*†#])?\s*(?:\/-\s*)?(?:and|or|&)\s+(?:above|more|over|below|less|beyond|upwards)\b|^\s*(?:onwards|\+\s)/.test(lc(doc.flat.slice(t.e, t.e + 26)))) role = 'offer';
    // a reward rate: "2 Reward Points on every ₹150 spent", "1 point for every(2) ₹50 spent", "per ₹100 spent"
    if (!role && /\b(?:every|per|each)\s*(?:\(\s*[*\d†#]{1,3}\s*\)|[*†#])?\s*$/.test(lc(doc.flat.slice(Math.max(0, t.s - 20), t.s)))) role = 'offer';
    // a rate, not money: "1 Tata NeuCoin = ₹1 Savings", "1 Reward Point = Rs. 0.25", "100 coins = ₹10"
    if (!role && /\b\d[\d,.]*\s*(?:[a-z]+\s+){0,2}(?:coins?|neucoins?|points?|miles|credits?|supercoins?)\s*(?:=|is worth|equals?)\s*$/.test(lc(doc.flat.slice(Math.max(0, t.s - 50), t.s)))) role = 'offer';
    if (!role && /\(\s*$/.test(doc.flat.slice(Math.max(0, t.s - 3), t.s)) && /\d\s*\(\s*$/.test(doc.flat.slice(Math.max(0, t.s - 12), t.s).replace(/[^\d(\s]/g, ''))) role = 'part';
    if (!role) {
      var pre = lc(doc.flat.slice(Math.max(0, t.s - 90), t.s)).replace(/\s+/g, ' ');
      for (var i = 0; i < BEFORE.length && !role; i++) if (BEFORE[i][1].test(pre)) role = BEFORE[i][0];
    }
    if (!role) {
      var post = lc(doc.flat.slice(t.e, t.e + 60));
      for (var j = 0; j < AFTER.length && !role; j++) if (AFTER[j][1].test(post)) role = AFTER[j][0];
    }
    t.role = role || 'other';
    return t.role;
  }
  function amts(doc, from, to) { return doc.toks.filter(function (t) { return t.t === 'AMT' && t.cur === 'INR' && t.s >= (from || 0) && t.s < (to == null ? 1e9 : to); }); }
  function near(doc, type, at, before, after, pred) {
    var best = null, gap = 1e9;
    doc.toks.forEach(function (t) {
      if (t.t !== type || (pred && !pred(t))) return;
      var g = t.s >= at ? t.s - at : at - t.e;
      if (g <= (t.s >= at ? after : before) && g < gap) { gap = g; best = t; }
    });
    return best;
  }
  function inBody(doc, t) { return t.s >= doc.bodyAt; }
  /* the sentence an offset sits in: from the last full stop, line break or "!" before it to the next */
  function stopChar(c) { return c === '.' || c === '!' || c === '?'; }
  /* where sentences end in a mail: a line break, or a full stop, "!" or "?" before a space that isn't an abbreviation's
     or a figure's. Found once a mail (sentenceAt was asked for every amount, walking up to 600 characters each way) */
  var SENT_ENDS = typeof WeakMap === 'function' ? new WeakMap() : null;
  var NOT_END = /(?:\b(?:rs|no|nos|a\/c|ltd|pvt|inr|mr|ms|mrs|dr|st|vs|co|txn|ref|avl|bal|amt|acct|approx|www|i\.e|e\.g|dt|max|min)|\d)$/i;
  function sentenceEnds(doc) {
    var f = doc.flat, m = SENT_ENDS && SENT_ENDS.get(doc);
    if (m && m.f === f) return m.ends;
    var ends = [];
    for (var x = 0; x < f.length; x++) {
      var c = f[x];
      if (c === '\n' || (stopChar(c) && /\s/.test(f[x + 1] || '') && !NOT_END.test(f.slice(Math.max(0, x - 7), x)))) ends.push(x);
    }
    if (SENT_ENDS) SENT_ENDS.set(doc, { f: f, ends: ends });
    return ends;
  }
  function sentenceAt(doc, at) {
    var f = doc.flat, ends = sentenceEnds(doc);
    // (at most 600 characters each way: a run of figures with no full stop is a table, not a sentence)
    // the first end at or after the offset, and the last before it
    var lo = 0, hi = ends.length;
    while (lo < hi) { var mid = (lo + hi) >> 1; if (ends[mid] < at) lo = mid + 1; else hi = mid; }
    var e = at >= f.length ? at : Math.min(lo < ends.length ? ends[lo] : f.length, at + 600);
    var s = at <= 0 ? at : Math.max(lo > 0 ? ends[lo - 1] + 1 : 0, at - 600, 0);
    return { s: s, e: e, text: f.slice(s, e) };
  }

  /* ------------------------------------------------------------ 5. pieces of a movement */
  /* which way the money went. Relations beat verbs: "from your account" took money out, "to your account" put it
     in, "credited to the destination account" (of the person you paid) is money out; then the money verb nearest
     the amount; then the subject; a card company's "payment received" is money onto the card. */
  var VERB = /\b(debited|debit(?!\s*card)|dbt|dbtd|spent|paid|withdrawn|withdrawal|sent|transferred|charged|used|using|deducted|purchase|credited|credit(?!\s*card|\s*limit|\s*score|\s*card|\s*intimation)|cdt|received|deposited|refunded|reversed|reversal|added|repayment|initiated)\b/g;
  /* a receipt written by whoever was paid, in the sentence of its amount (lower case, figures as 9s): "We have received
     your payment of 9999", "Received with thanks 9999 towards EMI", "We acknowledge the receipt of 9999", "Thank you for
     your donation of 9999", "I have received 9999 as rent". Never from a bank or a card company (whose "payment received"
     is your card being paid), never money coming back to you (a refund, a payout, a claim) or into a wallet */
  var PAYEE_RECEIPT = /\b(?:we|i)\s+(?:have\s+|['’]ve\s+)?(?:successfully\s+|duly\s+)?received\s+(?:your\s+|the\s+)?(?:(?:[a-z]+\s+){0,2}(?:payment|contribution|emi|instal+ment|premium|rent|maintenance|fees?|donation|deposit|subscription|dues)\b|(?:rs\.?\s*|₹\s*|inr\s*)?9)|\breceived with thanks\b|\backnowledge (?:the )?receipt of\b|\bthank you for your (?:donation|contribution) of\b/;
  function payeeReceipt(doc, s) {
    return !(doc.inst && /^(?:bank|card)$/.test(doc.inst.kind)) && PAYEE_RECEIPT.test(s) &&
      !/\b(?:refunds?|refunded|reversal|reversed|cashback|payout|claim|maturity|dividend|redemption|redeemed|disburs\w*|salary)\b|\b(?:in|into|to) your (?:\w+\s+){0,2}(?:wallet|balance)\b/.test(s);
  }
  /* worked out once per amount: an amount the sentences say nothing about asks every other amount of the same figure
     (the money detector, section 6), so a statement row of a thousand "Rs 1,234" cells was every amount × every amount, a sentence
     found character by character each time. An amount is a token of one mail, read once: its answer kept beside it */
  var DIR_MEMO = typeof WeakMap === 'function' ? new WeakMap() : null;
  function dirOf(doc, t) {
    if (!DIR_MEMO || !t || typeof t !== 'object') return dirOfOnce(doc, t);
    var m = DIR_MEMO.get(t);
    if (m && m.doc === doc && m.pair === t.pair && m.s === t.s && m.e === t.e) return m.v;
    var v = dirOfOnce(doc, t);
    DIR_MEMO.set(t, { doc: doc, pair: t.pair, s: t.s, e: t.e, v: v });
    return v;
  }
  /* an amount whose own sentences say nothing: the way the first other amount of the same figure went (in the mail's
     order, its direction told). The same answer for every amount of that figure (the amount asking has none of its
     own, so leaving it out changes nothing): worked out once per figure, by the mail and its tokens */
  var SAME_FIG = typeof WeakMap === 'function' ? new WeakMap() : null;
  function sameFigureDir(doc, t) {
    var memo = SAME_FIG && SAME_FIG.get(doc);
    if (!memo || memo.toks !== doc.toks || memo.n !== doc.toks.length) { memo = { toks: doc.toks, n: doc.toks.length, by: {} }; if (SAME_FIG) SAME_FIG.set(doc, memo); }
    var k = 'v' + t.v;
    if (Object.prototype.hasOwnProperty.call(memo.by, k)) return memo.by[k];
    var dir = '';
    amts(doc).forEach(function (o) { if (!dir && o !== t && o.v === t.v) dir = dirOf(doc, o); });
    memo.by[k] = dir;
    return dir;
  }
  function dirOfOnce(doc, t) {
    var sen = sentenceAt(doc, t.s), s = doc.nlow.slice(sen.s, sen.e), where = t.s - sen.s;
    var key = t.pair ? t.pair.key : '';
    // ("Interest paid", "Dividend paid", "Coupon paid" on an investment: paid to you, never by you; a loan's interest paid is yours)
    if (/^(?:interest|dividend|coupon|bonus|maturity|payout|claim|redemption)(?: amount)? (?:paid|credited|disbursed)$/.test(key) && !/\bloan\b|\bemi\b/.test(doc.head)) return 'in';
    if (/^(?:amount |txn |transaction )?(?:credit(?:ed)?|received|refund(?:ed)?|reversal)\b|\b(?:credited|received|refunded)$/.test(key)) return 'in';
    // a table's own word for which way its amount went ("Transaction Type | Credit", "Dr/Cr | DR", "Type | Debit")
    if (t.pair) {
      // (looked up once a mail: a statement's table asks it of every amount)
      if (doc.ttype === undefined) { var ttp = kv(doc, /^(?:transaction |txn |trans\.? )?(?:type|nature)$|^(?:dr|cr)\s*\/\s*(?:cr|dr)$|^(?:debit|credit)\s*\/\s*(?:credit|debit)$/); doc.ttype = ttp ? lc(trim(ttp.value)) : ''; }
      var ttv = doc.ttype;
      if (/^(?:credit|cr|credited|deposit)\b/.test(ttv)) return 'in';
      if (/^(?:debit|dr|debited|withdrawal)\b/.test(ttv)) return 'out';
    }
    // (relations beat verbs, as this section says: an insurer's "Amount paid: ₹X by NEFT to your account ••1234" is a
    //  claim paid *to you*, so the label's verb must not decide it alone — the relation rules below read it right)
    if (/^(?:amount |txn |transaction )?(?:debit(?:ed)?|paid|spent|withdrawal)\b|\b(?:debited|paid|spent|withdrawn)$/.test(key)
        && !/\b(?:to|in(?:to)?)\s+your\s+(?:(?!beneficiary|payee|benef)\w+\s+){0,2}(?:a\/c|account|acct)\b/.test(s)) return 'out';
    if (((doc.inst && /^(?:bank|card)$/.test(doc.inst.kind)) || /\byour\b[^.\n]{0,30}\bcredit card\b/.test(s)) && /thank you for (?:your |the )?payment|\bpayment\b[^.\n]{0,90}?\b(?:received|credited|posted)\b|credited (?:to|towards) your [^.\n]{0,40}card|received (?:your |a )?payment|merchant credit|refund[^.\n]{0,40}\b(?:on|to) your [^.\n]{0,40}card/.test(s) && /card/.test(s + ' ' + lc(doc.subject)) && !/received your request|payment received by/.test(s)) return 'in';
    // a bank's or card company's mail thanking you for a payment on its card: the money went onto the card
    if (doc.inst && /^(?:bank|card)$/.test(doc.inst.kind) && /payment received|thank you for (?:making )?(?:your |the |a )?payment|payment (?:has been |was |is )?(?:received|credited|posted)/.test(lc(doc.subject) + ' ' + doc.lead.slice(0, 200)) && /\bcard\b/.test(lc(doc.subject) + ' ' + doc.lead.slice(0, 300)) && !/\bdebited\b|\bspent\b/.test(s)) return 'in';
    // "A charge of INR X at SHOP ... was made on your Card": a purchase
    if (/\bcharge of\b[^\n]{0,120}\b(?:made|posted) on your\b/.test(s)) return 'out';
    // "A Transaction of INR 39,831.67 has been done on your Kotak Bank Credit Card No.xx1234 at EXAMPLE ELECTRONICS": a
    // purchase on the card ("Credit" in its name and "Credit Limit" are no money in)
    if (/\btransaction of\b[^\n]{0,80}\b(?:has been|was|is)\s+(?:done|made|carried out|performed|used)\s+(?:on|using|with|through|via)\s+your\b[^.\n]{0,60}\bcard\b/.test(s) && !/\b(?:refund|reversal|reversed|credited to)\b/.test(s)) return 'out';
    // money a person sent you through an app ("Ravi Example paid you ₹1,500", "Kiran sent you ₹500"): in
    if (/\b(?:paid|sent|transferred)\s+you\b[\s:\-|.]*$/.test(s.slice(0, where))) return 'in';
    // a person's own note in Hinglish that they have paid you ("₹15,340 NEFT kar diya hai invoice ka", "paise bhej diye"):
    // the writer sent it, so it came to you
    if (personalMail(doc) && /^[^.\n]{0,30}?\b(?:neft|imps|rtgs|upi|gpay|transfer|payment|pay)\s+(?:kar|kr)\s+(?:diya|diye|di|dia|chuka|chuki|chuke)\b|^[^.\n]{0,30}?\b(?:bhej|daal|dal|transfer)\s+(?:diya|diye|di|dia)\b/.test(s.slice(where + (t.e - t.s)))) return 'in';
    // a receipt written by whoever was paid ("We have received your payment of Rs.1,894", "Received with thanks Rs.3,000
    // towards maintenance", "We acknowledge the receipt of Rs.14,250", "I have received Rs.18,000 as rent"): the owner paid
    // them. Only a bank or a card company's "received" is money into your account or onto your card (above)
    if (payeeReceipt(doc, s)) return 'out';
    // a broker's or platform's withdrawal or payout goes to your bank: money in, whatever account it left there ("Your
    // withdrawal request of ₹12,000 from your Zerodha account … sent to your bank account ending 2290")
    if (doc.inst && /^(?:broker|exchange)$/.test(doc.inst.kind) && /\b(?:withdrawal|withdraw|payout|pay-out)\b/.test(s) && !/\bfrom (?:your )?(?:bank|savings)\b|\bto your (?:\w+\s+){0,2}(?:trading|demat|broking|wallet)\b/.test(s)) return 'in';
    // ("Your monthly donation of ₹500 to Example Animal Shelter has been processed via UPI AutoPay": paid)
    // (never one that came to you: "rent payment of ₹25,000 from your tenant … has been processed")
    if (/\b(?:donation|contribution|payment|instal+ment|emi|sip|subscription)\b[^.\n]{0,80}\b(?:has been|was|is) (?:successfully )?processed\b/.test(s) && !/\b(?:refund|reversal|redemption|withdrawal|claim|payout|credited to your)\b|\bfrom\s+(?!your\s+(?:account|a\/c|bank|card|wallet|savings)\b)[a-z]/.test(s)) return 'out';
    // money into your own PPF, NPS, Sukanya or deposit "by transfer from your account" left that account
    if (/\b(?:to|in(?:to)?) your (?:ppf|nps|ssy|sukanya[^.\n]{0,20}|recurring deposit|rd|fixed deposit|fd)\b[^.\n]{0,80}\bfrom your\b/.test(s)) return 'out';
    // your transfer "credited to beneficiary: X" left you, whatever word the bank used
    if (/(?:credited|deposited|transferred|sent|remitted)\s+(?:to|in(?:to)?)\s+(?:the\s+)?(?:destination|beneficiary|payee|recipient|receiver)/.test(s)) return 'out';
    // (and its figures on lines of their own under the bank's word that your transfer went through: "Your RTGS transfer
    // has been completed successfully … Amount: INR 2,00,000.00 / Credited to beneficiary A/c ending: XX5032")
    if (doc.inst && doc.inst.kind === 'bank' && (!key || /^(?:transaction |transfer |remittance )?(?:amount|details)\b/.test(key)) && /\byour (?:neft|rtgs|imps|fund|online)?\s*(?:transfer|remittance)\b[^.\n]{0,30}\b(?:has been|was|is)\s+(?:completed|successful|processed|executed)\b/.test(doc.head) && /\bcredited\s+to\s+(?:the\s+)?beneficiary\b/.test(doc.nlow.slice(doc.bodyAt, doc.bodyAt + 1500))) return 'out';
    // the account itself said to be credited or debited ("Your A/c No. 15XX8888 has been Credited for INR 2,700 towards IFT/FROM/...")
    var own = /\byour\b[^.\n]{0,60}?\b(?:has been|have been|is|was|got)\s+(credited|debited)\b/.exec(s);
    if (own) return own[1] === 'credited' ? 'in' : 'out';
    // the verb on the amount itself, before where it went: "An amount of INR 2,745.00 has been DEBITED to your account
    // XXX7724" took money out (Canara writes "debited to"); "Your A/c NN5826 credited for INR 44,100 towards SALARY" put it in
    var drcr = /^\s*(dr|cr)\.?\s+(?:from|to|in)\s+(?:your\s+)?(?:a\/c|account|acct)\b/.exec(s.slice(where + (t.e - t.s)));
    if (drcr) return drcr[1] === 'cr' ? 'in' : 'out';
    var amtVerb = /^\s*(?:\/-)?\s*(?:has been|have been|is|was)?\s*(debited|credited|charged)\s+(to|from|in|into|on)\s+(?:your|ur)\s+((?:[a-z]+\s+){0,2})/.exec(s.slice(where + (t.e - t.s)));
    if (amtVerb) {
      if (amtVerb[1] === 'charged' || (amtVerb[1] === 'credited' && amtVerb[2] === 'from')) return 'out';
      if (!(amtVerb[1] === 'debited' && /\bloan\b/.test(amtVerb[3]))) return amtVerb[1] === 'credited' ? 'in' : 'out';
      // ("has been debited to your loan account XX9911 … and credited to your savings account XX4821": the loan drawn into savings)
      if (/\band\s+(?:has been\s+|is\s+)?credited\s+(?:to|in|into)\s+your\b/.test(s.slice(where))) return 'in';
    }
    var acRe = /\byour\b[^.\n]{0,40}?\b(?:a\/c|account|acct)\s*(?:no\.?\s*)?[a-z]*\d*\s+(credited|debited)\s+(?:for|with|by)\b/g, acVerb;
    while ((acVerb = acRe.exec(s))) if (acVerb.index + acVerb[0].length <= where && /^\s*(?:inr|rs\.?|\u20b9)?\s*$/.test(s.slice(acVerb.index + acVerb[0].length, where))) return acVerb[1] === 'credited' ? 'in' : 'out';
    // a lender's "we have received your EMI payment of Rs.6,500.00 for loan XX9911": you paid it (a card's payment received
    // is the card being paid, above)
    if (/\breceived your\s+(?:\w+\s+){0,2}(?:emi|instal+ment|loan)\b|\breceived your\s+(?:\w+\s+){0,2}payment\b[^.\n]{0,60}\b(?:emi|instal+ment|loan)\b/.test(s) && !/\bcard\b/.test(s) && !(doc.inst && doc.inst.kind === 'wallet')) return 'out';
    // money added to your trading account, a wallet or an app's balance from a bank account or card left that account
    // (a broker's "Rs. 10,000 has been added to your trading account via UPI from Kotak Mahindra Bank A/c XXXX4402", a
    // top-up): out, LABELING rule 10 (the account it came from is the via; "to your … account" alone said "in")
    var addTo = /\b(?:added|credited|transferred|deposited|loaded)\s+(?:to|in|into)\s+your\s+(?:\w+\s+){0,2}?(?:trading|demat|broking|wallet|balance|funds?)\b/.exec(s);
    if (addTo && /\b(?:from|using|via)\s+(?:your\s+)?[^.\n]{0,50}?\b(?:a\/c|account|acct|card|bank)\b/.test(s.slice(addTo.index + addTo[0].length))) return 'out';
    // relations, anywhere in the sentence
    if (/(?:credited|deposited|transferred|sent|remitted)\s+(?:to|in(?:to)?)\s+(?:the\s+)?(?:destination|beneficiary|payee|recipient|receiver)/.test(s)) return 'out';
    if (/\b(?:to|into|in)\s+your\s+(?:\w+\s+){0,2}(?:a\/c|account|acct|card|wallet)\b|\bback to your\b|\b(?:credited|added|refunded|reversed|deposited)\s+(?:to|in|into)\s+(?:your|ur)\b|\byour [^.\n]{0,40}(?:has been|is|was) credited|received (?:credits|payment|a payment)|we have received|payment received|repayment/.test(s)) {
      if (!/received your request|has been received by|payment received by/.test(s)) return 'in';
    }
    if (/\bfrom\s+(?:your\s+)?(?:\w+\s+)?(?:bank\s+|savings\s+|current\s+)?(?:a\/c|account|acct)\b(?!\s*\(?cf)/.test(s) && !/trading account|demat/.test(s.slice(s.search(/\bfrom\s/))) ) return 'out';
    if (/\b(?:initiated|processed|made|done|placed)\s+(?:an?\s+|your\s+)?(?:imps|neft|rtgs|upi|fund transfer|transfer|payment)\b|\bpayment (?:to|for) /.test(s)) return 'out';
    if (/\btowards\b|\bused for\b|\bspent\b|\bpaid (?:on|to|for|at|using)\b/.test(s)) return 'out';
    // the money verb nearest the amount in its sentence
    var best = null, gap = 1e9, m;
    // a verb that ends the sentence before ("Your A/C XX1234 Credited. INR 8,000.00 on ...") counts when this one has none
    if (!/\b(?:debit|credit|spent|paid|withdr|sent|transfer|charg|used|deduct|purchas|receiv|deposit|refund|revers|add|repay)/.test(s)) {
      var prev = lc(doc.flat.slice(Math.max(0, sen.s - 50), sen.s));
      if (/\b(?:debited|withdrawn|spent|paid)\.?\s*$/.test(prev)) return 'out';
      if (/\b(?:credited|received|deposited|refunded)\.?\s*$/.test(prev)) return 'in';
    }
    VERB.lastIndex = 0;
    while ((m = VERB.exec(s))) {
      var g = m.index >= where ? m.index - where : where - (m.index + m[0].length);
      if (g < gap) { gap = g; best = m[1]; }
    }
    if (best && best !== 'initiated') return /^(?:credited|credit|cdt|received|deposited|refunded|reversed|reversal|added|repayment)$/.test(best) ? 'in' : 'out';
    var sd = lc(doc.subject);
    if (/credit intimation|for credit to your|credit(?:ed)? (?:to|in) your/.test(doc.head)) return 'in';
    if (/payment received|received (?:a )?payment/.test(sd) && doc.inst && /^(?:bank|card|wallet)$/.test(doc.inst.kind)) return 'in';
    if (/\b(?:credited|received|refund|reversed|cashback|added)\b|\bcredit (?:alert|intimation|advice|notification)\b/.test(sd) && !/\b(?:debited|spent|paid|payment)\b|\bdebit (?:alert|intimation|advice)\b/.test(sd)) return 'in';
    if (/\b(?:debited|spent|paid|payment|purchase|transaction|used)\b/.test(sd)) return 'out';
    // a receipt from a society, a biller or a shop: you paid them
    if (/\breceipt\b|payment received by|received by\b|paid successfully|payment (?:is |was )?successful/.test(doc.head) && !(doc.inst && /^(?:bank|card|wallet)$/.test(doc.inst.kind))) return 'out';
    // a card alert with a merchant and nothing said about direction is a purchase
    if (kv(doc, /merchant|paid to|payee|beneficiary/) && !/credit|refund|revers/.test(lc(doc.flat.slice(0, 1200)))) return 'out';
    return '';
  }

  /* the card, account or wallet a movement was on: the masked digits nearest the amount that are yours (not a
     beneficiary's or a deposit's), and what the words before them call it */
  var NOT_MINE = /(?:beneficiary|benef\.?|payee|destination|recipient|receiver|for (?:fd|td|rd)\s*(?:a\/c|account)|of (?:td|fd|rd)\s*(?:a\/c|account)|closure of (?:td|fd|rd)|\b(?:td|fd|rd)\s*(?:a\/c|account)|deposit\s*(?:a\/c|account|no\.?|number)|dp\s*id|client id|folio)[^\n]{0,30}$/;
  function viaFor(doc, t, dir) {
    var best = null, score = -1e9;
    doc.toks.forEach(function (x) {
      if (x.t !== 'MASK') return;
      var pre = lc(doc.flat.slice(Math.max(0, x.s - 50), x.s)).replace(/\s+/g, ' ');
      var key = x.pair ? x.pair.key : '';
      if (NOT_MINE.test(pre) || /beneficiary|destination|payee|to account|credit account|dp\s*id|client|folio/.test(key)) return;
      // (a loan's own number, "Loan Account Number XXXXXXXX7720", is never the account money left or reached)
      if (/\bloan\b/.test(key) || /\bloan\s*(?:a\/c|account|acct)(?:\s*(?:no\.?|number))?[\s:\-|]*$/.test(pre)) return;
      // (a number printed whole is never your bank account or card, which their mail masks: from a biller, a lender or a
      // landlord it is the consumer, loan or their own account: "We have received your payment for account 1000556677")
      if (!(doc.inst && /^(?:bank|card)$/.test(doc.inst.kind)) && /^\d{8,}$/.test(String(x.raw || '').replace(/[\s\-]/g, ''))) return;
      // (a mobile number, "recharge for 98XXXXXX45", "bill for 97XXXXXX12", and a vehicle's plate, "vehicle KA01XX4321":
      // someone's phone or car, never the account or card that paid)
      if (/^[6-9]\d[x*•]{5,6}\d{2,3}$/i.test(String(x.raw || '').trim()) || /\b(?:mobile|phone|recharge for|bill for)(?:\s*(?:no\.?|number))?[\s:\-|]*$/.test(pre)) return;
      if (/\bvehicle(?:\s*(?:no\.?|number|reg(?:istration)?(?:\s*no\.?)?))?[\s:\-|]*[a-z]{2}\s?\d{1,2}\s?[a-z]{0,3}\s?$|\b(?:reg(?:istration)?|tag id)\b[^\n]{0,12}$/.test(pre) || /[A-Z]{2}\d{1,2}[A-Z]{0,3}$/.test(doc.flat.slice(Math.max(0, x.s - 7), x.s))) return;
      if (dir === 'out' && /(?:transfer(?:red)?|sent|credited|paid|imps|neft|rtgs|remitted)\b[^.\n]{0,40}\bto\s+(?!your\b)(?:(?!your\b)[a-z.]+\s+){0,5}(?:a\/c|account|acct)(?:\s*no\.?)?[\s:]*$/.test(pre)) return;
      // ("Rs.60000.00 is debited from Kotak Bank Ac X6610 to Axis Bank A/c XX2290 ROHIT EXAMPLE": the other bank's account
      // is who was paid; never "debited to your account", "debited to savings A/c")
      if (dir === 'out' && /\bdebited\b[^.\n]{0,60}\bto\s+(?!your\b|savings\b|current\b|sb\b|salary\b)(?:(?!your\b)[a-z.&]+\s+){0,3}bank\s+(?:a\/c|account|acct)(?:\s*no\.?)?[\s:]*$/.test(pre)) return;
      // (money paid into your PPF, Sukanya or NPS left another account: the scheme's own number, its PRAN, is where it went)
      if (dir === 'out' && /\b(?:ppf|ssy|sukanya samriddhi|nps|pran|tier ?(?:i|ii|1|2))\b(?:\s*(?:a\/c|account|acct))?(?:\s*(?:no\.?|number))?[\s:\-|]*$/.test(pre)) return;
      var dist = t ? (x.s >= t.s ? x.s - t.e : t.s - x.e) : x.s;
      var sc = -Math.min(dist, 2000) / 3;
      if (dir === 'in' && /\bloan\s*(?:a\/c|account|acct)(?:\s*no\.?)?[\s:]*$/.test(pre)) sc -= 300;
      if (/(?:card|a\/c|account|acct|wallet|no\.?|number|ending(?: with| in)?)[\s:.\-|]*$/.test(pre.replace(/[x*•\d\s]+$/, ''))) sc += 60;
      if (/\byour\b[^\n]{0,30}$/.test(pre)) sc += 40;
      if (/account|a\/c|card|debit|from|hold/.test(key)) sc += 70;
      if (!inBody(doc, x)) sc += 25;   // the subject names the account the alert is about
      if (sc > score) { score = sc; best = x; }
    });
    var kind = '', debit = false, last4 = best ? best.v : '';
    var ctx = best ? lc((best.pair ? best.pair.key + ' ' : '') + doc.flat.slice(Math.max(0, best.s - 70), best.s)).replace(/\s+/g, ' ') : '';
    var whole = lc(doc.flat.slice(0, 2500));
    if (best) {
      if (/\bwallet card[^\n]{0,40}$|\bwallet\b[^\n]{0,20}$/.test(ctx) && !/credit card|debit card/.test(ctx)) kind = 'wallet';
      else if (/debit\s*card[^\n]{0,40}$/.test(ctx)) { kind = 'card'; debit = true; }
      else if (/credit\s*card(?:\s*(?:a\/c|account))?[^\n]{0,40}$/.test(ctx) || (/(?:\bcard\b|\bcc\b)[^\n]{0,40}$/.test(ctx) && !/(?:a\/c|account|acct)[^\n]{0,12}$/.test(ctx.replace(/card number$/, '')))) kind = 'card';
      // a card named by its network alone ("your Visa ••4410" on a subscription's receipt) is still a card: without
      // this the kind fell through to 'other' and the merchant's own name was stamped on as the institution.
      // (instrumentIn already knows this rule; viaFor did not)
      else if (/\b(?:visa|master\s?card|amex|american express|rupay|diners(?: club)?|discover)\b[^\n]{0,12}$/.test(ctx)) kind = 'card';
      else if (/(?:a\/c|account|acct|\bac\b|savings|current)[^\n]{0,40}$/.test(ctx)) kind = 'account';
      else if (/wallet[^\n]{0,20}$/.test(ctx)) kind = 'wallet';
      // a bank named right before the digits is an account ("Credited to: Example Bank XX2290"): without this the
      // sender's own kind decides below, so a wallet app's mail about a bank credit reads as a wallet's own money
      // (never on a card's own mail: a bill-paying app writes the card it paid as "Example Bank •••• 1234")
      else if (/\bbank\b[^\n]{0,24}$/.test(ctx) && !/credit card/.test(whole)) kind = 'account';
    }
    if (!kind) {
      if (doc.kind === 'card') kind = 'card';
      else if (doc.kind === 'wallet') kind = 'wallet';
      else if (/\bdebit card\b/.test(whole) && !/\bcredit card\b/.test(whole)) { kind = 'card'; debit = true; }
      else if (/\bcredit card\b|\bcard (?:no|ending|number)\b/.test(whole.slice(0, 900))) kind = 'card';
      else if (/(?:\bmy)?wallet\b/.test(lc(doc.subject))) kind = 'wallet';
      else if (/\b(?:a\/c|account|acct)\b/.test(whole.slice(0, 900))) kind = 'account';
      else if (/\bwallet\b/.test(whole.slice(0, 600))) kind = 'wallet';
      else if (/\bupi\b/.test(whole.slice(0, 900))) kind = 'upi';
    }
    // money that went into a wallet (a shop's credits, a refund to its balance) moved through the wallet, not a card
    if (!best && /\b(?:added to|credited to|in|into) (?:your )?(?:\w+ )?(?:wallet|credits|money|cash balance|pay balance)\b|\bwallet credit/.test(lc(doc.subject + ' ' + doc.flat.slice(0, 500)))) kind = 'wallet';
    // (a cashback with the wallet's balance after it, "Your updated Amazon Pay balance is …": into that wallet)
    var cbPay = !best && dir === 'in' && /cashback/.test(lc(doc.subject)) && /\b(?:updated|new|current)\b[^.\n]{0,30}\bpay balance\s+is\b/.test(whole);
    if (cbPay) kind = 'wallet';
    // a card company's "account" is its card (Amex, SBI Card)
    if (kind === 'account' && doc.kind === 'card') kind = 'card';
    var inst = '';
    if (doc.inst && /^(?:bank|card)$/.test(doc.inst.kind)) {
      inst = doc.inst.short;
      // (a bank's mail about money paid into your account at another bank names that bank right before its digits: SBI's
      // deposit interest "credited to ICICI Bank A/c XXXXXXXX0551" is in ICICI's account)
      var ob = best && kind === 'account' && dir === 'in' && E.issuerIn ? /\b(?:to|into|in)\s+(?:your\s+)?([a-z][a-z&.]*(?:\s+[a-z&.]+){0,3}?\s+bank)\s+(?:a\/c|account|acct)(?:\s*no\.?)?[\s:]*$/.exec(lc(doc.flat.slice(Math.max(0, best.s - 60), best.s))) : null;
      var obi = ob ? E.issuerIn(ob[1], false) : null;
      if (obi && obi.short && obi.short !== doc.inst.short && obi.kind === 'bank') inst = obi.short;
    }
    else if (doc.inst && doc.inst.kind === 'wallet' && (kind === 'wallet' || !kind)) { inst = doc.inst.short; kind = 'wallet'; }
    else if (kind === 'wallet') inst = cbPay ? walletName(doc).replace(/ Pay Balance$/, ' Pay') : walletName(doc);
    else {
      // a rail's mail (CRED, BillDesk, a gateway, a broker, a shop) names the bank: the one nearest the digits
      var around = best ? doc.flat.slice(Math.max(0, best.s - 80), best.e + 20) : '';
      // (the bank the mail calls yours right before the digits, "your Airtel Payments Bank a/c ending 0631", is the
      // account's; the bank of whoever sent or got the money, "received from Example Bank XX2290", never is)
      var yb = best && kind === 'account' ? /\byour\s+([a-z][a-z&.]*(?:\s+[a-z&.]+){0,3}?\s+bank)\s+(?:a\/c|account|acct)(?:\s*(?:no\.?|number|ending(?: with| in)?))?[\s:]*[x*•]*$/.exec(lc(doc.flat.slice(Math.max(0, best.s - 70), best.s))) : null;
      if (yb) {
        var ybi = E.issuerIn ? E.issuerIn(yb[1], false) : null;
        inst = ybi && ybi.kind === 'bank' ? ybi.short : capWords(yb[1]);
      }
      if (around) around = around.replace(/\b(?:from|to|by)\s+[A-Za-z][A-Za-z&. ]{1,30}?\bbank\b\s*(?:a\/c\s*)?[x*•]+\d{2,6}/gi, ' ');
      var who = inst ? null : E.issuerIn ? ((around && E.issuerIn(around, kind === 'card')) || (kind === 'card' ? E.issuerIn(doc.flat.slice(0, 1500), true) : null)) : null;
      if (who) inst = who.short;
    }
    var v = { kind: kind || 'other' };
    if (inst) v.inst = inst;
    if (last4) v.last4 = last4;
    if (debit) v.debit = true;
    return v;
  }

  /* who was paid, or who paid: a label's value, the VPA's name, a narration's name, or what follows towards / at /
     to / from in the amount's own sentence. Never an instruction ("to raise a dispute", "to manage your mandates") */
  var STOP_AFTER = /\s+(?:on|dated|via|using|with|ref(?:erence)?|upi\b|txn|at\s+\d|for\s+(?:inr|rs)|vide|from\s+(?:your|a\/c|account)|has been|have been|is|was|avl|available|bal(?:ance)?|info|if you|in case|to check|not you|please|thru|through|of\s+inr|as per|date|time|and the|in favou?r|towards your|in(?:to)?\s+your|(?:is |was |has been )?successful(?:ly)?|for (?:credit|debit|payment|your)|use your|click|for details|for more|to report|to know|kindly|regards|for\s+(?:the\s+)?(?:[a-z]+\s+){0,2}(?:due|payable)|due\s+(?:on|by|date))\b|[.,;!?(\[|]|\s{2,}|\n|$/i;
  var NOT_A_PARTY = /^(?:your|you|the|a|an|my|our|this|that|it|beneficiary|merchant|payee|account|a\/c|card|credit card|debit card|vpa|upi|imps|neft|rtgs|india|in|on|of|dear|customer|bank|amount|inr|rs|transfer|payment|transaction|txn|self|us|them|him|her|card holder|cardholder|destination account|registered|your account|your card|online)$/i;
  var IMPERATIVE = /^(?:raise|report|check|block|reach|manage|view|know|avoid|ensure|confirm|help|keep|update|try|click|pay|call|contact|visit|log|login|register|enable|activate|unsubscribe|download|track|cancel|request|get|share|read|learn|see|find|use|secure|stop|verify|be|do|make|apply|claim|redeem|explore|enjoy|book|start|add|set|change|continue|complete|submit|send|write|chat|connect|give|let|tap|reply|note|kindly|please|avail|discover|switch|refer|earn|win|save|protect|safeguard|consult|seek|monitor)\b/i;
  function cleanParty(s) {
    s = trim(String(s || '').replace(/^(?:vpa|m\/s\.?|upi|merchant(?: name)?|beneficiary(?: name)?|payee|name)\s*[:\-]?\s+/i, ''));
    s = s.replace(/\b(Mr|Mrs|Ms|Dr|Smt|Shri|Sri)\.\s*/g, '$1 ').replace(/^(?:transfer(?:red)?|payment|sent|paid)\s+to\s+/i, '');
    if (/^\d{6,}\s*[:\/]/.test(s)) return '';   // "Mr. EXAMPLE" is one name, not the end of a sentence
    var m = STOP_AFTER.exec(' ' + s);
    if (m) s = (' ' + s).slice(0, m.index).trim();
    s = s.replace(/[\s\-–:*#'"]+$/, '').replace(/^[\s\-–:*#'"]+/, '').replace(/\s+(?:INR|USD|EUR|GBP|AED|SGD)$/, '').replace(/\s*\/\s*\d{5,}$/, '');
    if (!s || s.length < 2 || NOT_A_PARTY.test(s) || IMPERATIVE.test(s) || /^[\d\s•x*.\-/]+$/i.test(s) || s.split(/\s+/).length > 8) return '';
    if (/\b(?:your|please|click|toll[- ]free|helpline|customer care|sms|call us|dispute)\b/i.test(s)) return '';
    // the mail's own footer, never a payee: "Please do not reply to this auto generated email"
    if (/^(?:this|that|these)\b|\be-?mails?\b|\b(?:auto|system|computer)[- ]?generated\b/i.test(s)) return '';
    return s.slice(0, 60);
  }
  /* a bank narration: "UPI/P2A/300000000001/EXAMPLE/ICIC/Sent", "IMPS/P2A/600000000002/EXAMPLEP",
     "ACH-CR-IOCL-NACH-20000000-", "IFT/FROM/200000000003/", "NACH-DR- CTEXAMPLELIF" (a space after its dash) */
  function narration(s) {
    var out = { mode: '', ref: '', party: '', vpa: '' };
    // (and a reference after a dash, "NEFT-EXAMPLE PAYMENTS PVT LTD-551204937711", is a part of its own)
    var parts = String(s || '').split(/\s*[\/]\s*|\s+-\s+|-\s?(?=[A-Z])|-(?=\d{6,}\b)/).map(trim).filter(Boolean);
    var head = lc(parts[0] || '');
    var mm = /^(upi|imps|neft|rtgs|ach|nach|ecs|ift|mmt|bil|inf|pos|pur|atm|nfs|ecom)/.exec(head);
    if (mm) out.mode = mm[1] === 'ach' || mm[1] === 'ecs' ? 'NACH' : mm[1].toUpperCase();
    // a card's bill paid from the account names the card by its digits ("BIL/ONL/000123456/CREDIT CARD/XX9004")
    if (out.mode === 'BIL') for (var ci = 1; ci < parts.length - 1; ci++) if (/^(?:[a-z]{2,12} )?credit card$/i.test(parts[ci]) && /^[x*•]*\d{4,}\b/i.test(parts[ci + 1])) out.party = 'Credit card ••' + /\d{4,}/.exec(parts[ci + 1])[0].slice(-4);
    parts.forEach(function (p) {
      if (/^[\w.\-]+@[a-z][\w]*$/i.test(p)) { out.vpa = lc(p); return; }
      if (!out.ref && /^[A-Z0-9]{9,22}$/i.test(p) && /\d{6,}/.test(p)) { out.ref = p; return; }
      if (out.party) return;
      if (/^(?:upi|imps|neft|rtgs|ach|nach|ecs|ift|mmt|bil|inf|cr|dr|from|to|p2a|p2m|p2p|ref|onl|mob|ib|mb|pos|pur|ecom|nfs|atw|si|tpt|inb|sent|received|icic|hdfc|sbin|utib|kkbk|barb|punb|cnrb|idfb|yesb|indb|fdrl|ubin)$/i.test(p) || /\d{4,}/.test(p) || p.length < 3) return;
      // (a "PAY*SHOP" descriptor loses its shop here: cleanText parts the star, and cleanParty then reads the bare
      //  "PAY …" as an instruction. Left alone on purpose — the naming layer pairs the alert with the shop's own mail
      //  and names it from there, which reads better: engine-test/mail-guards-22.js G33. Giving this a party breaks it)
      if (/[a-z]/i.test(p)) out.party = cleanParty(p);
    });
    return out;
  }
  /* a loan named as kosh shows it ("HDFC Home Loan"): the lender and the kind of loan the mail says */
  function loanName(doc) {
    var k = /\b(home|housing|car|auto|vehicle|personal|education|gold|two[- ]wheeler|business|property)\s+loan\b/.exec(lc(doc.subject) + ' ' + doc.lead.slice(0, 600));
    var who = doc.inst ? doc.inst.short : senderBrand(doc);
    return trim((who || '') + ' ' + (k ? capWords(k[1] === 'housing' ? 'home' : k[1]) + ' Loan' : 'Loan'));
  }
  function partyFor(doc, t, dir) {
    var out = { party: '', vpa: '' };
    var pick = dir === 'in'
      ? kv(doc, /^(?:sender|remitter|received from|from|paid by|payer|credited by|by|transferred by|remitted by)(?: name)?$|sender name|remitter name|^from merchant$/)
      : kv(doc, /^(?:merchant|paid to|payee|beneficiary|to|sent to|transferred to|at|store|shop|biller|vendor|from merchant)(?: name| details)?$|merchant name|beneficiary name|biller name|payee name|^(?:payment (?:received |made )?|paid )?towards$/);
    if (pick) out.party = cleanParty(pick.value.replace(/\(?\bvpa:?[^)]*\)?/i, ''));
    // (the beneficiary's account by its last digits, "Credited to beneficiary A/c ending: XX5032": whose account it went
    // to, so a transfer to your own account at another bank is seen as both sides)
    var bm;
    if (!out.party && dir === 'out' && (bm = /\bbeneficiary\s+(?:a\/c|account|acct)(?:\s*(?:no\.?|number))?\s*(?:ending(?:\s+(?:with|in))?)?\s*[:\-]?\s*[x*•]*(\d{4})\b/i.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 2000)))) { out.party = 'A/c ••' + bm[1]; out.toLast4 = bm[1]; }
    var sen = sentenceAt(doc, t.s);
    var after = doc.flat.slice(t.e, Math.max(t.e, sen.e) + 2), before = doc.flat.slice(sen.s, t.s), m;
    var vpaT = near(doc, 'VPA', t.e, 160, 240);
    // (the UPI ID a gateway's receipt prints as how you paid, "Method | upi | asha@okhdfcbank", is yours, never the payee's)
    if (vpaT && /\b(?:method|paid (?:using|via|from|with|through)|payment (?:mode|method|instrument|source)|pay(?:ment)? mode|payer(?: vpa| upi id)?|your (?:upi id|vpa))\b[\s:|\-]*(?:upi)?[\s:|\-]*$/i.test(doc.flat.slice(Math.max(0, vpaT.s - 40), vpaT.s))) { out.payerVpa = vpaT.v; vpaT = null; }
    if (vpaT) out.vpa = vpaT.v;
    if (!out.party && vpaT) {
      var va = doc.flat.slice(vpaT.e, vpaT.e + 60), vb = doc.flat.slice(Math.max(0, vpaT.s - 70), vpaT.s);
      if ((m = /^\s*\(([^)]{2,50})\)/.exec(va))) out.party = cleanParty(m[1]);
      // (whole words: the "to" inside "towards VPA" names no one)
      else if ((m = /\b(?:sender|from|by|to)\b\s*:?\s*([A-Za-z][A-Za-z.&' ]{2,40}?)\s*\(?\s*vpa:?\s*$/i.exec(vb))) out.party = cleanParty(m[1]);
      else if ((m = /^\s+([A-Z][A-Za-z.&' ]{2,40}?)(?=\s+on\b|\s+dated|[.,]|\s*$)/.exec(va))) out.party = cleanParty(m[1]);
    }
    // a masked UPI ID ("towards VPA ***7712@ex (Example Traders)") is no VPA of its own: the name in brackets is who
    if (!out.party && !vpaT && (m = /\b(?:towards|to|from|by)\s+(?:vpa\s+)?[*x•]{2,}[\w.\-]*@[a-z][\w.]*\s*\(([^)]{2,50})\)/i.exec(after))) out.party = cleanParty(m[1]);
    if (!out.party) {
      // (a credit "towards" a narration names who paid: Canara's "CREDITED to your account … towards NEFT-EXAMPLE
      // GLOBAL SERVICES PVT LTD-REIMB CLAIMS"; an all-caps alert's "BY NEFT EXAMPLE INDIA PRIVATE LIMITED")
      var pats = dir === 'in'
        ? [/\butr\s*(?:no\.?\s*)?[:\-]?\s*[A-Z0-9]{8,}\s+from\s+([A-Za-z][A-Za-z.&' ]{2,60}?)(?=\s+[A-Za-z0-9]*\d[A-Za-z0-9]*\b|\s+via\b|[.,|]|\s*$)/i, /\b(?:initiated by|received from|credited by|remitted by|transferred by)\s+(?:our client\s*[-:]?\s*)?(?:vpa\s+)?([^\n]{2,80})/i, /\bfrom\s+(?!your\b|the\b|a\/c|account|merchant\b)(?:vpa\s+)?([A-Za-z][^\n]{1,80})/i, /\bby\s+([A-Z][^\n]{2,80})/, /\bBY\s+((?:NEFT|IMPS|RTGS|UPI|ACH|NACH)\b[ \-\/]*[A-Z][^\n]{2,80})/,
           /\btowards\s+((?:neft|imps|rtgs|upi|ach|nach|ift|mmt)[\-\/][A-Za-z0-9][^\n]{2,80})/i]
        : [/\bbeneficiary(?:\s*name)?\s*[:\-]\s*([A-Za-z][^\n]{1,80})/i, /\btowards\s+(?!your\b|the\b|payment\b|imps\b|neft\b|rtgs\b|upi\b|(?:[a-z]+\s+){1,2}(?:due|payable)\b|(?:interest|principal|emi|instal+ments?|charges?|dues|fees?|premium|maintenance|rent)\b)(?:vpa\s+)?([^\n]{2,80})/i, /\bfor payment to\s+([^\n]{2,80})/i, /\b(?:paid|sent|transferred|payment|transfer|imps|neft|rtgs)(?:\s+of\s+[^\n]{0,25}?)?\s+to\s+(?:vpa\s+)?(?!your\b)([A-Za-z0-9][^\n]{1,80})/i,
           /\bat\s+(?!\d{1,2}[:.]\d)([A-Za-z0-9][^\n]{1,80})/i, /\bto\s+(?:vpa\s+)?(?!your\b|the\b|you\b|a\/c|account|be\b)([A-Za-z0-9][^\n]{1,80})/i, /\bon\s+(?!\d)([A-Za-z][\w.]*\.(?:in|com))\b/i];
      for (var i = 0; i < pats.length && !out.party; i++) if ((m = pats[i].exec(after))) out.party = cleanParty(m[1]);
      // the narration in brackets straight after the date ("credit by transfer of Rs 38,000.00 on 01Mar26 (PENSION FEB
      // CPPC)"): the bank's own words for who and what
      if (!out.party && (m = /^\s*on\s+[0-9A-Za-z][0-9A-Za-z\/\-., ]{4,14}?\s*\(([A-Za-z][^()\n]{1,60})\)/.exec(after))) out.party = cleanParty(m[1]);
      // ("Ravi Example paid you ₹1,500": the name before it)
      if (!out.party && dir === 'in' && (m = /([A-Z][A-Za-z.'&]+(?:\s+[A-Z][A-Za-z.'&]+){0,4})\s+(?:paid|sent|transferred)\s+you\s*[:\-]?\s*$/.exec(before))) out.party = cleanParty(m[1]);
      if (!out.party && dir === 'in') { if ((m = /\b(?:initiated by|from)\s+(?:[Oo]ur [Cc]lient\s*[-:]?\s*)?([A-Z][^\n]{2,80})/.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 600)))) out.party = cleanParty(m[1]); }
      if (!out.party && (m = /\b(?:spent|used|paid)\b[^\n]{0,30}?\bat\s+([^\n]{2,60})$/i.exec(before))) out.party = cleanParty(m[1]);
      // SBI's "has a credit by CPPC PENSION SEP26 of Rs …": the narration is who paid (never a bare rail, "by transfer",
      // nor a deposit's own interest line, "INT.PD:TD A/C …")
      if (!out.party && (m = /\bhas a (?:credit|debit) by ([^₹\n]{2,90}?) of\s*(?:₹|rs\.?|inr)?\s*$/i.exec(before)) && !/^(?:transfer|upi|cash|cheque|clearing|neft|imps|rtgs|atm)$/i.test(trim(m[1])) && !/\bint\.?\s*pd\b|\b(?:td|fd|rd)\s*a\/c\b/i.test(m[1])) {
        var hn = /[\/]/.test(m[1]) ? narration(m[1]).party : cleanParty(m[1]);
        if (hn) out.party = hn;
      }
      if (!out.party && (m = /\binfo\s*[:\-]\s*([^\n]{2,90})/i.exec(doc.flat.slice(t.e, t.e + 240))) && !/\//.test(m[1].split(/\s/)[0])) out.party = cleanParty(m[1]);
      // the subject: "INR 98.14 txn. reversed at 1000 EXAMPLE MART", "spent at X"
      if (!out.party && (m = /\b(?:at|to|towards)\s+([A-Za-z0-9][^\n]{1,60})$/i.exec(doc.subject))) out.party = cleanParty(m[1]);
      // (a gateway's receipt names the payee in its subject: "Payment successful for EXAMPLE SMALL FINANCE BANK LIMITED")
      if (!out.party && dir === 'out' && (m = /\bpayment (?:successful|success|done|completed|confirmed|received)\s+(?:for|to)\s+([A-Za-z0-9][^\n]{1,70})$/i.exec(doc.subject))) out.party = cleanParty(m[1]);
      // a mandate's biller named before the verb ("Your Example Cloud bill, set up through E-mandate")
      if (!out.party && (m = /\b[Yy]our\s+([A-Z][A-Za-z0-9&.' ]{1,30}?)\s+(?:bill|subscription|payment)\b/.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 600)))) out.party = cleanParty(m[1]);
    }
    // a narration names the payee in its middle
    var nar = kv(doc, /^(?:transaction info|info|remarks?|description|narration|transaction details|particulars|reference no|reference)$/);
    var narText = nar ? nar.value : (/\b((?:upi|imps|neft|rtgs|ach|nach|ift|mmt)[\/\-][A-Z0-9\/\-@. ]{6,80})/i.exec(doc.flat.slice(t.e, t.e + 260)) || /\b([A-Z0-9][A-Z0-9 .@&\-]{1,30}(?:\/[A-Z0-9 .@&\-]{0,40}){2,})/.exec(doc.flat.slice(t.e, Math.max(t.e, sen.e))) || [])[1];
    // (a credit's narration in brackets after its date, "credited to your A/c XX2290 on 17-09-2026 (NEFT-EXAMPLE
    // PAYMENTS PVT LTD-551204937711)": the bank's own words)
    var brk = dir === 'in' && !nar ? /\bon\s+[0-9A-Za-z][0-9A-Za-z\/\-., ]{4,14}?\s*\(((?:neft|imps|rtgs|upi|ach|nach|ift|mmt)[\-\/][A-Za-z0-9][^()\n]{2,90})\)/i.exec(after) : null;
    if (brk) narText = brk[1];
    if (narText && /[\/]|^(?:ach|nach|neft|imps|rtgs|upi|ift|mmt)-/i.test(narText)) {
      var n = narration(narText);
      if ((!out.party || /^(?:imps|neft|upi|rtgs|ach|nach|ift)\b/i.test(out.party)) && n.party) out.party = n.party;
      out.nar = n;
    }
    /* a bank's own words for the payment in a labelled row (Federal's "Description | INWARD REMITTANCE-EXAMPLE
       EXCHANGE-ANIL EXAMPLE", "INTEREST CREDIT", "NEFT-EXAMPLE NAME-LAND LEASE"; a "Narration", "Remarks", "Particulars"
       or "Info" row): what it says rides along as the narration (narText), so what the money was (a remittance, interest,
       a lease) can be read; and, where nothing else named who, the narration is who */
    var narRow = doc.inst && /^(?:bank|card)$/.test(doc.inst.kind) ? kv(doc, /^(?:description|narration|remarks?|particulars|info|transaction (?:info|details|remarks|narration|description))$/) : null;
    var nt = trim(narRow ? narRow.value : (brk ? brk[1] : (out.nar && nar && /^(?:reference(?: no)?|transaction info|info)$/.test(nar.key) ? nar.value : '')));
    // (a narration, not a sentence the pair reader took for one's value: "… has been debited …", "AIRTEL. The Available Balance …")
    if (nt && /[a-z]{3}/i.test(nt) && nt.length <= 90 && !/[.!?]\s/.test(nt) && !/\b(?:has been|have been|is|was|your|you|the|please|dear)\b/i.test(nt)) {
      out.narText = nt;
      if (!out.party && narRow && !/^(?:ach|nach|ecs|ift|neft|imps|rtgs|upi|mmt|bil|inf)[\-\/]/i.test(nt)) out.party = cleanParty(nt.replace(/\s+\d{6,}\s*$/, ''));
    }
    // (and a debit card's purchase, "PUR/PAY*EXAMPLE ENTERTAINM/600000000001/979586": the shop between the slashes)
    if (/^(?:ach|nach|ecs|ift|neft|imps|rtgs|upi|mmt|bil|inf|pur|pos)[\-\/]/i.test(out.party)) out.party = narration(out.party).party;
    // ("NEFT PAYONEER INDIA PRIVATE LIMITED": the rail, then who)
    if (/^(?:neft|imps|rtgs)\s+[a-z]+\s+[a-z]/i.test(out.party)) out.party = out.party.replace(/^(?:neft|imps|rtgs)\s+/i, '');
    // money sent to another bank's account names that account, then whose it is ("to Axis Bank A/c XX2290 ROHIT EXAMPLE
    // IMPS Ref …"): the name is the payee, the digits the other account's
    if (dir === 'out' && (m = /^((?:[A-Za-z.&]+\s+){1,4})(?:a\/c|account|acct)(?:\s*no\.?)?\s*[:\-]?\s*[x*•]+(\d{2,6})\s+([A-Za-z][^\n]{1,60})$/i.exec(out.party || '')) && /\bbank\b/i.test(m[1])) {
      var tp = cleanParty(m[3].replace(/\s+(?:imps|neft|rtgs|upi|ift|mmt)\b.*$/i, ''));
      if (tp) { out.party = tp; out.toLast4 = m[2].slice(-4); }
    }
    if (!out.party && dir === 'out' && (m = /\bto\s+(?:a\/c|account|acct)(?:\s*no\.?)?\s*[:\-]?\s*(?:[x*•]+)?(\d{4,18})\b/i.exec(after))) { out.party = 'A/c ' + m[1].slice(-4); out.toLast4 = m[1].slice(-4); }
    // money added to your trading account, wallet or balance from your account: whoever holds it now is the broker or
    // app that wrote, by the name it writes under (rule 10; "Kotak Securities" mails from the bank's own domain)
    if (!out.party && dir === 'out') {
      var sl0 = doc.nlow.slice(sen.s, sen.e), at0 = /\b(?:added|credited|transferred|deposited|loaded)\s+(?:to|in|into)\s+your\s+(?:\w+\s+){0,2}?(?:trading|demat|broking|wallet|balance|funds?)\b/.exec(sl0);
      if (at0 && /\b(?:from|using|via)\s/.test(sl0.slice(at0.index))) { var dn0 = /^\s*"?([^"<]{2,60}?)"?\s*</.exec((doc.msg && doc.msg.from) || ''); out.party = dn0 ? cleanParty(dn0[1]) : senderBrand(doc); }
    }
    if (out.vpa && !out.party) out.party = out.vpa;
    return out;
  }
  function dateFor(doc, t) {
    var dp = kv(doc, /^(?:txn |transaction |payment |value |posting |execution |credit |debit |booking |deposit |refund )?date(?: (?:&|and) time)?$|^date of (?:transaction|payment|credit)$|^(?:credited|paid|debited|received|payment received) on$|^date (?:received|of receipt|paid|credited)$|^date time$|^transaction date and time$/);
    var sen = sentenceAt(doc, t.s);
    // a date the mail gives as what's expected or coming ("Expected processing date: ...") is not the day money moved
    // (a "by" is a promise, "by 05 Oct", "renews by auto-debit on 05 Jan", except the way it was paid: "by bank transfer
    // on 01-10-2026" is the day it moved)
    // (nor a pay-later line's or a card's billing date, "Bill date: 16 Sep" under a purchase made on the 14th)
    var ahead = function (x) { var pre = lc(doc.flat.slice(Math.max(0, x.s - 40), x.s)); return /\b(?:bill(?:ing)?|statement|billing cycle) date\s*[:|\-]?\s*$/.test(pre) || /\b(?:expected|scheduled|will|shall|due|before|till|until|valid|expir\w*|next|upcoming|on or before|renew\w*)\b[^\n.]{0,24}$/.test(pre) || (/\bby\b[^\n.]{0,24}$/.test(pre) && !/\bby (?:bank transfer|neft|imps|rtgs|upi|cheque|check|cash|card|debit card|credit card|net ?banking|online transfer)\b[^\n.]{0,20}$/.test(pre)); };
    var ok = function (x) { return inBody(doc, x) && !x.rel && !ahead(x); };
    var said = doc.toks.filter(function (x) { return x.t === 'DATE' && ok(x) && x.s >= sen.s && x.s <= sen.e + 2 && /\b(?:credited|reversed|refunded|debited|deposited|cleared)\b(?: back)?(?:[^.\n]{0,70}?)\s+on\s*$/.test(lc(doc.flat.slice(Math.max(sen.s, x.s - 90), x.s))); })[0];
    var d = said || near(doc, 'DATE', t.e, 0, Math.max(40, sen.e - t.e), ok) || near(doc, 'DATE', t.s, Math.max(30, t.s - sen.s), 0, ok);
    var pick = (dp && dp.date) ? { v: dp.date, e: dp.e } : d;
    if (!pick) pick = doc.toks.filter(function (x) { return x.t === 'DATE' && ok(x) && x.s < doc.bodyAt + 300; })[0] || null;
    var date = pick ? pick.v : '';
    if (date) { var gap = dayNum(doc.ref) - dayNum(date); if (gap < -2 || gap > 400) date = ''; }
    var tm = pick && pick.e ? near(doc, 'TIME', pick.e, 0, 40) : null;
    if (!tm) tm = near(doc, 'TIME', t.e, 0, Math.max(60, sen.e - t.e));
    return { date: date || doc.ref, time: tm ? tm.v : '', dated: !!date };
  }
  /* a bill's or recharge's own reference: the BBPS one first, then the biller's or operator's, then a "Transaction ID is"
     the mail gives (never the app's order number) */
  function billRef(doc) {
    var t = doc.flat.slice(doc.bodyAt, doc.bodyAt + 3000), m;
    var res = [/\b(?:bbps (?:ref(?:erence)?|txn|transaction) ?(?:no\.?|number|id)?|b-?connect txn id)\s*[:|\-]?\s*([A-Za-z0-9][A-Za-z0-9\-]{5,40})/i,
      /\b(?:operator|biller) (?:ref(?:erence)?|txn|transaction) ?(?:no\.?|number|id)?\s*[:|\-]?\s*([A-Za-z0-9][A-Za-z0-9\-]{5,40})/i,
      // (the sentence's own opening, never a promo's "Once they recharge, your transaction ID is REFER…")
      /\byour transaction id is\s*[:\-]?\s*([A-Z0-9][A-Z0-9\-]{6,40})/i];
    for (var i = 0; i < res.length; i++) {
      if (!(m = res[i].exec(t)) || !/\d/.test(m[1]) || /^(?:number|reference)$/i.test(m[1]) || /^\d{1,2}[-\/]\d{1,2}[-\/]\d{2,4}$/.test(m[1])) continue;
      if (i === 2 && /\b(?:refer|once|win|friend|offer)\b/i.test(t.slice(Math.max(0, m.index - 80), m.index).split(/[.!?\n](?=\s)/).pop())) continue;
      return m[1];
    }
    return '';
  }
  function refFor(doc) {
    var keys = [/\butr\b/, /\brrn\b/, /upi\s*(?:transaction\s*)?ref/, /(?:^|\s)ref(?:erence)?(?:\s*(?:no|number|id))?$|reference (?:no|number)/, /^payment (?:id|ref(?:erence)? (?:id|no|number))$/, /txn\.? ?(?:id|no)\b|transaction (?:id|number|no)\b/, /imps ref|neft ref|advice no/, /order id/, /^receipt(?: ?(?:no\.?|number|#))?$/, /^transfer(?: ?(?:#|no\.?|number|id))?$/];   // normLabel drops a trailing "#", so
    // "Transfer #" and "Receipt #" arrived here as "transfer" and "receipt" and neither key could ever match: both rules
    // have never once run. (And "transfer" was missing from LABELISH, so the row was never even a label and value pair.)
    for (var i = 0; i < 3; i++) {
      var p0 = kv(doc, keys[i]);
      if (p0) { var v0 = (/[A-Z0-9][A-Z0-9\-]{5,40}/i.exec(p0.value.replace(/^(?:no\.?|number)\s*/i, '')) || [])[0]; if (v0 && /\d/.test(v0)) return v0; }
    }
    var mu = /\b(?:upi\s*(?:transaction\s*)?ref(?:erence)?|utr|rrn)\s*(?:no\.?|number|id)?\s*[:.\-]*\s*(?:is\s+)?(\d{10,22})\b/i.exec(doc.flat);
    if (mu) return mu[1];
    // (a shop's plain-text refund, "bank_reference : 5221058624": the bank's own reference for it)
    var mbr = /\bbank[_ ]ref(?:erence)?(?:[_ ](?:no|number|id))?\s*[:=]\s*([A-Z0-9]{6,30})\b/i.exec(doc.flat);
    if (mbr && /\d{5,}/.test(mbr[1])) return mbr[1];
    // (a NEFT UTR is the bank's code and the digits, "UTR CITIN20132690000": the transfer's, over a footer's "Reference No")
    var ma = /\butr\s*(?:no\.?|number)?\s*[:.\-]*\s*(?:is\s+)?([A-Z]{4}[A-Z0-9]{8,20})\b/i.exec(doc.flat);
    if (ma && /\d{6,}/.test(ma[1])) return ma[1];
    for (var i = 3; i < keys.length; i++) {
      // (a branch's code beside a reference, "Remitter Reference 0040-MTS004", is not the transfer's: the next one is)
      var ps = kvAll(doc, keys[i]);
      for (var j = 0; j < ps.length; j++) { var v = (/[A-Z0-9][A-Z0-9\-]{5,40}/i.exec(ps[j].value.replace(/^(?:no\.?|number)\s*/i, '')) || [])[0]; if (!v || !/\d/.test(v)) break; if (j + 1 < ps.length && /^\d{1,8}-[A-Z]{2,5}\d{1,4}$/i.test(v)) continue; return v; }
    }
    var re = /\b(?:upi\s*(?:transaction\s*)?ref(?:erence)?|ref(?:erence)?|rrn|utr|imps ref(?:erence)?|payment\s*id|transaction(?:\s*id)?|txn\.?\s*(?:id|no\.?))\s*(?:no\.?|number|id)?\s*(?:[:.\-]*|#)\s*(?:is\s+)?([A-Z0-9][A-Z0-9\-]{7,40})\b/gi, m;
    while ((m = re.exec(doc.flat))) if (/\d{4,}/.test(m[1]) && !/^(?:number|reference)$/i.test(m[1])) return m[1];
    return '';
  }
  function modeOf(doc, via, vpa, nar) {
    var l = doc.lead + ' ' + lc(doc.subject);
    if (nar && nar.mode && nar.mode !== 'IFT') return nar.mode;
    if (via.kind === 'wallet') return 'WALLET';
    if (/\batm\b|cash withdrawal|atm withdrawal/.test(l)) return 'ATM';
    if (/standing instruction|\bsi execution\b/.test(l)) return 'SI';
    if (/\b(?:nach|ach)\b|\becs\b|\bumrn\b|e-?mandate|auto-?debit|autopay/.test(l)) return 'NACH';
    if (vpa || /\bupi\b/.test(l)) return 'UPI';
    var rm = /\b(imps|neft|rtgs)\b/.exec(doc.lead) || /\b(imps|neft|rtgs)\b/.exec(lc(doc.subject));
    if (rm) return rm[1].toUpperCase();
    if (via.kind === 'card') return /\bpos\b/.test(l) ? 'POS' : '';
    return '';
  }
  /* a party a receipt says was paid, matched by name against knowledge.js's billers ("Mahanagar Gas Limited" is the gas
     biller): paying one of these is paying a bill (rule 2), whatever words an app wraps around it — a wallet's "Payment
     Successful for <biller>" never says "bill". Exact on the name, so a shop whose name merely contains one can't match. */
  function billerNamed(name) {
    var norm = function (x) { return lc(x || '').replace(/\b(?:ltd\.?|limited|pvt\.?|private)\b/g, ' ').replace(/[^a-z0-9]+/g, ' ').trim(); };
    var n = norm(name);
    if (n.length < 4) return null;
    var list = K.billers || [];
    // (every biller's names, normalised once: the first biller in the list that has the name wins, as before)
    if (BILLER_IX.list !== list || BILLER_IX.n !== list.length) {
      var ix = Object.create(null);
      list.forEach(function (b) { [b.short, b.name].concat(b.aliases || []).forEach(function (x) { if (x) { var k = norm(x); if (!(k in ix)) ix[k] = b; } }); });
      BILLER_IX = { list: list, n: list.length, ix: ix };
    }
    return BILLER_IX.ix[n] || null;
  }
  var BILLER_IX = {};
  var INS_PAYOUT = /survival benefit|money[- ]?back (?:payout|instal+ment|benefit|amount|plan)|\bsb (?:payout|amount)\b|maturity (?:claim|amount|benefit|value|proceeds|payout)|annuity (?:payout|payment|instal+ment)|policy payout|claim (?:settled|settlement)|settled claim|claim amount (?:settled|paid|approved)/;
  function purposeOf(doc, dir, party, via, mode, t) {
    var l = doc.head, p = lc(party);
    // (a payment with its fees listed beside it, "Rent ₹32,000 / Platform fee ₹384", "Fees 412.50 INR": the payment is no fee)
    // (never a bank's or a card's own charge, its GST listed beside it: that is the fee)
    var feeBeside = !!t && !(doc.inst && /^(?:bank|card)$/.test(doc.inst.kind)) && roleOf(doc, t) !== 'fee' && amts(doc).some(function (o) { return o !== t && o.v !== t.v && roleOf(doc, o) === 'fee'; });
    if (/revers/.test(factual(l, true))) return 'reversal';
    if (dir === 'in' && /refund/.test(l)) return 'refund';
    if (dir === 'in' && /cashback/.test(l)) return 'cashback';
    // (never a card's EMI footer, "Processing Fee and/or Interest applicable as per tenure")
    if (dir === 'in' && /\binterest\b|\bint\.?\s*pd\b/.test(l.replace(/[^.\n]*\binterest (?:applicable|rate applicable|charges? applicable|as per|will be|may be)[^.\n]*/g, ' '))) return 'interest';
    if (dir === 'in' && /\bdiv(?:idend)?\b/.test(l)) return 'dividend';
    if (dir === 'in' && /\bsal(?:ary)?\b/.test(l)) return 'salary';
    if (via.kind === 'card' && dir === 'in' && /payment (?:received|of)|repayment|received (?:your )?payment|thank you for (?:your )?payment|credited to (?:your )?card|bill payment|payment was successful|received credits/.test(l)) return 'cardpay';
    if (dir === 'out' && via.kind !== 'card' && /\bcred\b|credit card (?:bill|payment)|card bill|\bcc payment|american express|sbi ?card|towards (?:your )?credit card/.test(p + ' ' + l)) return 'cardpay';
    if (/\batm\b|cash withdrawal/.test(l)) return 'withdrawal';
    // a bank's own charge: a fee, a penalty, its GST
    if (dir === 'out' && !feeBeside && /\b(?:charges?|fee|fees|penalty|non[- ]maintenance|amc|annual fee|sms (?:alert )?charges?|late payment|gst on|return charge|bounce charge)\b/.test(p + ' ' + lc(doc.subject) + ' ' + factual(l.slice(0, 300), true)) && !/\b(?:bill|recharge|purchase|order)\b/.test(lc(doc.subject))) return 'fee';
    if (dir === 'out' && /recurring deposit|\brd\b (?:instal+ment|a\/c)/.test(p + ' ' + l)) return 'investment';
    if (doc.kind === 'broker' || /zerodha|groww|upstox|indian clearing|iccl|nsccl|\bmutual fund\b|\bsip\b/.test(p + ' ' + l)) return dir === 'in' ? 'payout' : 'investment';
    // a tax paid (to the tax department, a challan, GST), and money into a pension or a small-savings scheme
    if (dir === 'out' && ((doc.inst && doc.inst.kind === 'tax') || /\b(?:advance tax|self[- ]assessment tax|income tax|cbdt|gst (?:payment|challan)|challan)\b|^gst\b/.test(p) || /\b(?:tax payment|challan|gst payment)\b/.test(lc(doc.subject)))) return 'tax';
    if (dir === 'out' && /\bnps\b|nps trust|\bpran\b|\bppf\b|public provident|sukanya|\bssy\b|sovereign gold|\bsgb\b/.test(p + ' ' + lc(doc.subject))) return 'investment';
    if (/\bfd\b|\btd\b|fixed deposit|term deposit/.test(p + ' ' + l) && dir === 'out') return 'investment';
    if (/\bfd\b|\btd\b|fixed deposit|term deposit/.test(l) && dir === 'in' && /clos|matur|premat/.test(l)) return 'redemption';
    // a life policy paying out (a survival benefit, a money-back instalment, its maturity, an annuity) into the account:
    // money in from the insurer, not a transfer
    if (dir === 'in' && INS_PAYOUT.test(p + ' ' + l) && (insurerIn(doc) || /insurance|assurance|\blife\b/.test(p + ' ' + lc(senderBrand(doc) || '') + ' ' + (doc.domain || '')) || /\bpolicy\b/.test(l))) return 'payout';
    if (dir === 'in' && (/added to (?:your )?(?:\w+ )?(?:wallet|balance)|money added|top-?up/.test(l) || via.kind === 'wallet')) return /cash|credit/.test(l) && !/added to your amazon pay|money added/.test(l) ? '' : 'topup';
    // (a bill paid: through a bank or an app, a biller's own receipt for it, a pay-later bill repaid: rule 2)
    if (/bill payment|\bbbps\b|electricity|broadband|postpaid|gas bill|dues|\bfastag\b|\bdth\b|(?:mobile|prepaid|data|dth) recharge|recharge (?:of|for) (?:your )?(?:mobile|prepaid|dth|fastag|99|\d)/.test(l) || (/receipt/.test(l) && billerSender(doc)) || (dir === 'out' && billerSender(doc)) || (dir === 'out' && billerNamed(p)) ||
        (dir === 'out' && /\b(?:towards|for) (?:your )?[\w ]{0,30}?\b(?:bill|dues)\b|\bpay ?later\b[^.\n]{0,40}\b(?:payment|repayment|repaid)\b|\b(?:payment|repayment)\b[^.\n]{0,40}\bpay ?later\b/.test(l))) return 'billpay';
    // (an EMI is what the payee or the subject says, not a footer's "convert to EMI" offer)
    if (/\bemi\b/.test(p + ' ' + lc(doc.subject)) || /\b(?:emi|instal+ment) (?:of|for|debited|paid|amount)\b/.test(l.slice(0, 400))) return 'emi';
    if (/premium/.test(l)) return 'premium';
    if (/fund transfer|\bp2a\b|\bp2p\b|\bift\b|transfer/.test(l) || (/^(?:IMPS|NEFT|RTGS|SI)$/.test(mode || '') && dir)) return 'transfer';
    if (dir === 'out' && (via.kind === 'card' || via.kind === 'wallet')) return 'purchase';
    // (bought on a pay-later line, "Your payment of ₹349 to Example Cafe via Simpl was successful": a purchase on credit)
    if (dir === 'out' && doc.inst && doc.inst.kind === 'lender' && p && !/\bemi\b|\bloan\b/.test(p + ' ' + l)) return 'purchase';
    if (dir === 'out' && /^upi$/i.test(mode || '') && p && !/\s/.test(p) === false) return 'purchase';
    return '';
  }

  /* the sender's kind, widened with knowledge.js's shops and registrars */
  function shopOf(doc) {
    var list = K.shops || [];
    for (var i = 0; i < list.length; i++) if (onDomain(doc.domain, list[i].domains)) return list[i];
    if (doc.inst && doc.inst.kind === 'merchant') return { name: doc.inst.short, id: doc.inst.id };
    return null;
  }
  /* a shop kosh doesn't know: an order mail from a sender that isn't a bank, card, wallet, broker or insurer is
     the shop its domain names ("orders@brand.in" → Brand) */
  // the part of a domain that names someone ("amul" in shop@amul.coop, not the "coop" or "jp" it ends in)
  var DOMAIN_FILLER = /^(?:mail|mailer|mailers|email|e|em|info|noreply|no-reply|alerts?|updates?|notifications?|orders?|care|support|news|net|in|co|com|org|app|shop|store|coop|io|ai|me|biz|online|xyz|jp|uk|us|au|sg|ae|tech|club|cards?|live|living|customer|hello|mobi|services?)$/;
  // platforms that ship or sell for other shops: the shop is the one the mail names ("your Clan Shoes order")
  var SHIP_PLATFORM = /shiprocket|prozo|clickpost|delhivery|bluedart|ecomexpress|xpressbees|shadowfax|ekart|dunzo|shopify|instamojo|dukaan|aftership|narvar|parcelx|pickrr|nimbuspost|velocity|shipway|ithinklogistics|shipyaari|unicommerce|easyecom/;
  // a person's own mailbox (Gmail, Outlook, Yahoo…): a person wrote it, so it is never a shop, nor one owing a refund
  var WEBMAIL = /^(?:gmail\.com|googlemail\.com|yahoo\.(?:com|co\.in|in)|ymail\.com|rocketmail\.com|outlook\.(?:com|in)|hotmail\.(?:com|co\.in)|live\.(?:com|in)|msn\.com|icloud\.com|me\.com|mac\.com|rediffmail\.com|aol\.com|protonmail\.com|proton\.me|pm\.me)$/;
  function personalMail(doc) { return WEBMAIL.test(doc.domain || ''); }
  // the name a personal mailbox writes under ("Example Classes <exampleclasses@gmail.com>": Example Classes): a small
  // society, tutor, landlord or shop that mails from Gmail is still who you paid; never the mailbox's own name
  function personalName(doc) {
    var dn = /^\s*"?([^"<]{2,60}?)"?\s*</.exec((doc.msg && doc.msg.from) || '');
    var n = dn ? trim(dn[1]) : '';
    return n.length >= 2 && !/@|no-?reply|^(?:gmail|outlook|yahoo|hotmail|icloud|rediff(?:mail)?)$/i.test(n) ? n : '';
  }
  // a person's own note about money, not a record of it: a forward, a reply, or a complaint or request to a company
  // ("Fwd: …", "Re: …", "Dear Team, … please reverse"). The company's own mail is the record of what it mentions.
  function personalNote(doc) {
    if (!personalMail(doc)) return false;
    if (/^\s*(?:fwd?|fw|re|aw|wg|tr)\s*:/i.test(doc.subject || '')) return true;
    var top = doc.flat.slice(0, 6000);
    if (/-{3,}\s*forwarded message\s*-{3,}|begin forwarded message|\bwrote:\s*(?:\n|$)/i.test(top)) return true;
    // (someone writing that they sent money, "Sent Rs.45,000 for the lease … to Anil's NRO account today by NEFT", "I have
    // transferred ₹5,000 to your account": the writer's payment, told; the bank's alert of the credit is the record)
    if (/(?:^|\n|[.!]\s+)\s*(?:i\s+(?:have\s+|['’]ve\s+)?(?:just\s+)?|we\s+(?:have\s+|['’]ve\s+)?(?:just\s+)?)?(?:sent|transferred|remitted|deposited|paid)\s+(?:you\s+)?(?:rs\.?|₹|inr)\s?\d/i.test(doc.flat.slice(doc.bodyAt, doc.bodyAt + 800)) &&
        !/\b(?:received|receipt|invoice|order|bill)\b/i.test(doc.subject || '')) return true;
    return /\b(?:dear (?:team|sir|madam|sir\/madam|customer care|support)|please (?:reverse|refund|look into|resolve|investigate)|kindly (?:reverse|refund|resolve|look into)|wrongful(?:ly)?|i (?:was|have been) (?:wrongly )?(?:charged|debited))\b/.test(doc.low.slice(doc.bodyAt, doc.bodyAt + 800));
  }
  // a store a platform hosts for its owner (Shopify, Instamojo, Dukaan) mails as the store: the sender's own name
  // ("Example Athleisure Pvt Ltd <store+1@t.shopifyemail.com>": Example Athleisure)
  var HOSTED_STORE = /shopify|instamojo|dukaan/;
  function hostedShop(doc) {
    if (!HOSTED_STORE.test(doc.domain || '')) return '';
    var dn = /^\s*"?([^"<]{2,60}?)"?\s*</.exec((doc.msg && doc.msg.from) || '');
    var n = dn ? trim(dn[1]).replace(/\s+(?:pvt\.?|private)?\s*(?:ltd\.?|limited|llp)$/i, '').replace(/\s+(?:pvt\.?|private)$/i, '') : '';
    if (n.length < 2 || SHIP_PLATFORM.test(lc(n)) || /no-?reply|@|\bteam\b|\bnotifications?\b/i.test(n)) return '';
    return n;
  }
  function shopGuess(doc) {
    if (personalMail(doc)) { var pn = personalNote(doc) ? '' : personalName(doc); return pn ? { name: pn, id: lc(pn).replace(/\s+/g, ''), guessed: true } : null; }
    var s = shopOf(doc);
    /* GUARDRAIL a courier's or shipping platform's mail about a shop's order ("Your Order from Example Crafts is being
       shipped via Example Shipping"): the shop is the one the mail names, never the courier who sent it. Known platforms
       by name; any other sender kosh doesn't know whose own domain isn't the shop it names is one too */
    var head0 = doc.subject + '\n' + doc.flat.slice(doc.bodyAt, doc.bodyAt + 600);
    var named0 = /\b[Yy]our\s+([A-Z][\w&'.]*(?:\s+[A-Z][\w&'.]*){0,3})\s+[Oo]rder\b/.exec(doc.subject) || /\b[Oo]rder\s+(?:from|with|at)\s+([A-Z][\w&'.]*(?:\s+[A-Z][\w&'.]*){0,3})/.exec(head0) ||
      /\b([A-Z][\w&'.]*(?:\s+[A-Z][\w&'.]*){0,3})\s+has\s+(?:handed|shipped|dispatched)\s+your\s+order\b/.exec(head0) || /\b(?:shopping|ordering)\s+with\s+([A-Z][\w&'.]*(?:\s+[A-Z][\w&'.]*){0,3})/.exec(head0);
    var listed = (K.shops || []).some(function (x) { return onDomain(doc.domain, x.domains); });
    var courier = !!named0 && !listed && (!doc.inst || doc.inst.kind === 'merchant') && /\b(?:awb|tracking (?:number|no\.?|id)|shipped via|shipping partner|delivery partner|courier partner|handed (?:over )?your order to)\b/i.test(doc.subject + ' ' + doc.flat.slice(doc.bodyAt, doc.bodyAt + 3000)) &&
      (function () {
        // (the shop is the sender only when the sender's own name is the shop's: "lynkcrafts.com" for "Lynk Crafts")
        var dn = (doc.domain || '').split('.').filter(function (p) { return !DOMAIN_FILLER.test(p); }).join(''), nn = lc(named0[1]).replace(/[^a-z0-9]/g, '');
        return !dn || !nn || (dn.indexOf(nn) < 0 && nn.indexOf(dn) < 0);
      })();
    if (SHIP_PLATFORM.test(doc.domain) || courier) {
      var named = named0;
      if (named) return { name: trim(named[1]), id: lc(named[1]).replace(/\s+/g, ''), guessed: true };
      var hs = hostedShop(doc);
      if (hs) return { name: hs, id: lc(hs).replace(/\s+/g, ''), guessed: true };
    }
    if (s) return s;
    if (doc.inst && doc.inst.kind !== 'merchant') return null;
    var parts = doc.domain.split('.').filter(function (p) { return !DOMAIN_FILLER.test(p); });
    return parts.length ? { name: capWords(parts[parts.length - 1]), id: parts[parts.length - 1], guessed: true } : null;
  }

  /* ------------------------------------------------------------ 6. detectors: each looks for one kind of event */

  /* money moved: an alert, a receipt, a credit. The amount moved is the one its label or words call moved (or the
     only amount in a mail that says money moved), its direction from the sentence, then the card or account, who,
     when, the reference, how, and what for. */
  // a sender that can hold or pay out your money: a bank, a card, a wallet or an app's balance, a broker or registrar,
  // an insurer, a lender, a gateway paying a merchant's refund. Anyone else (a shop, a biller, a telecom) only
  // ever sends money back as a refund or a cashback
  function holdsMoney(doc) { return !!doc.inst && /^(?:bank|card|wallet|app|broker|rta|insurer|lender|gateway|exchange|pension|depository|amc)$/.test(doc.inst.kind); }
  var PAST_MONEY = /\b(?:debited|credited|spent|withdrawn|has been (?:paid|used|processed|received|deposited|transferred)|was (?:paid|used|processed|successful)|is (?:debited|credited)|reversed|refunded to|payment (?:of .{0,30})?(?:is |was |has been )?(?:successful|received|done|completed)|successfully (?:paid|processed|completed|received)|txn\.? reversed|added to your|we've transferred|have been transferred|has been initiated|we have initiated|has been successfully|received credits|is successful|was made on your (?:\w+ ){0,4}(?:card|account))\b/i;
  // "credited" in "will be credited" is a promise, not money that moved; so is "you'll be charged", "it'd be debited"
  var FUTURE_VERB = /(?:\b(?:will|shall|would|to|can|may|could|might)|\w['’](?:ll|d))\s+(?:be\s+)?(?:\w+\s+)?(?:debited|credited|deducted|charged|paid|refunded|transferred|reversed|added|processed|disbursed|billed)\b/g;
  /* what a text says happened, clause by clause (a clause ends at ";", ", ", " - " or the sentence's end): a condition
     ("in case of a failed transaction", "if debited", "if the transaction fails") and a disclaimer ("the bank is not
     responsible for any transaction declined") are cut to their clause's end; with promises too, a promise of money back
     ("the amount will be reversed within 3 days"), never the clause before it that says money moved, nor the part of
     its own clause that does ("INR 5,000 has been debited …, and the return charge will be refunded") */
  var CLAUSE_CUT = /(;|,\s|\s[-\u2013]\s|[.!?](?=\s)|\n)/;
  var PROMISE_BACK = /\b(?:will|shall|would)\s+(?:be\s+)?(?:\w+\s+)?(?:reversed|refunded|credited(?: back)?|returned|paid back)\b/i;
  var AUX_PAST = /\b(?:has been|have been|was|were|is|got)\s+(?:successfully\s+)?(?:debited|credited|deducted|charged|paid|reversed|refunded|transferred|withdrawn|spent)\b/i;
  function factual(text, promises) {
    return String(text || '').split(CLAUSE_CUT).map(function (c, i) {
      if (i % 2) return c;
      var x = c.replace(/\b(?:if|in case|incase|in the event|should (?:the|your|any|this))\b[\s\S]*$/i, ' ');
      if (/\bnot (?:be )?(?:held )?(?:responsible|liable)\b/i.test(x)) x = ' ';
      if (promises) {
        var pb = PROMISE_BACK.exec(x);
        if (pb) {
          var ap = AUX_PAST.exec(x);
          if (!ap || ap.index > pb.index) x = ' ';
          else {
            // ("… has been debited …, and the earlier charge will be refunded": the promise's own part)
            var tail = x.slice(ap.index + ap[0].length, pb.index), cj = -1, m, cjRe = /\b(?:and|but|while|which|whereas)\b/gi;
            while ((m = cjRe.exec(tail))) cj = m.index;
            if (cj >= 0) x = x.slice(0, ap.index + ap[0].length + cj);
          }
        }
      }
      return x;
    }).join('');
  }
  /* a sentence that says an amount is still to pay ("The payment of INR 17,436.50 for your Card is due on 22-Oct") and
     nothing paid, sent or received: a bill, not a payment ("Rs.1,480.00 paid … for bill due on 15-10" was paid) */
  var OWED = /\b(?:is|are|falls?)\s+(?:now\s+)?(?:over)?due\b|\bdue\s+(?:on|by)\b|\bpayable\s+(?:by|on|before)\b|\bis payable\b/;
  var PAID_WORD = /\b(?:paid|sent|received|deducted|charged|transferred|debited|credited|confirmed|spent|used|using|withdrawn|successful(?:ly)?|processed|deposited|reversed|refunded)\b/;
  function owedOnly(ns) { var x = factual(ns).replace(new RegExp(FUTURE_VERB.source, 'g'), ' '); return OWED.test(x) && !PAID_WORD.test(x); }
  function moves(doc, ctx) {
    var out = [];
    if (ctx.failed || ctx.otp || ctx.future || ctx.promo) return out;
    var cand = amts(doc).filter(function (t) { return roleOf(doc, t) === 'moved'; });
    // an amount whose own sentence promises it ("is eligible for a reversal of Rs.499 ... will be processed and
    // will reflect in the next statement") hasn't moved yet, whatever word sits next to it
    cand = cand.filter(function (t) {
      var sen = sentenceAt(doc, t.s), ns = lc(doc.flat.slice(sen.s, Math.min(sen.e, sen.s + 400)));
      if (t.pair) return true;
      // ("The payment of INR 17,436.50 for your Credit Card is due on 22-Oct": still to pay; "Rs.1,480.00 paid from your
      // A/c to EXAMPLE ELECTRICITY for bill due on 15-10" was paid)
      if (owedOnly(ns)) return false;
      var promised = new RegExp(FUTURE_VERB.source).test(ns) || /\b(?:is|are) eligible for\b|will reflect|will be (?:processed|reversed|waived|refunded)/.test(ns);
      return !promised || PAST_MONEY.test(ns.replace(new RegExp(FUTURE_VERB.source, 'g'), ''));
    });
    // a refund said paid or credited ("The refund for AY 2026-27 has been paid to your bank account", its "Refund amount"
    // row): that amount moved, never a line inside it (the interest it includes, a fee beside it)
    if (!cand.length && /\brefund\b[^.\n]{0,60}\b(?:has been|was|is) (?:paid|credited|deposited|issued)\b/.test(doc.head) && !ctx.failed) cand = amts(doc).filter(function (t) { return roleOf(doc, t) === 'refund' && inBody(doc, t); }).slice(0, 1);
    if (!cand.length) {
      var plain = amts(doc).filter(function (t) { return t.role === 'other' && inBody(doc, t); });
      var subjAmt = amts(doc).filter(function (t) { return !inBody(doc, t) && t.role !== 'offer'; });
      if (PAST_MONEY.test(doc.head.replace(FUTURE_VERB, '')) && plain.length && uniq(plain.map(function (t) { return t.v; })).length === 1) cand = [plain[0]];
      else if (subjAmt.length && PAST_MONEY.test(lc(doc.subject))) cand = [subjAmt[0]];
    }
    // a bank's own word that your transfer went through, its figures as labelled lines ("Your RTGS transfer has been
    // completed successfully … Amount: INR 2,00,000.00 / Credited to beneficiary A/c ending: XX5032"): that amount left
    if (!cand.length && doc.inst && doc.inst.kind === 'bank' && /\byour (?:neft|rtgs|imps|fund|online|upi)?\s*(?:transfer|remittance|payment|transaction)\b[^.\n]{0,30}\b(?:has been|was|is)\s+(?:completed|successful|processed|executed)\b/.test(doc.head)) {
      var tAmt = kv(doc, /^(?:transaction |transfer |remittance )?amount(?: \(?(?:rs|inr|₹)\.?\)?)?$/);
      if (tAmt && tAmt.amt > 0) cand = amts(doc).filter(function (t) { return t.pair === tAmt || (t.s >= tAmt.s && t.s <= tAmt.e); }).slice(0, 1);
    }
    // a wallet's cashback added to its balance ("Here's your ₹ 25 cashback … It has been added to your Amazon Pay balance"):
    // the cashback is the money that came in (never the balance after it)
    // (or said as the cashback that's yours with the balance after it: "Here's your ₹ 25 cashback … Your updated Amazon Pay
    // balance is ₹ 7611.72")
    // (a shop's own mail about its wallet, "Your updated Amazon Pay balance is …" from amazon.com, is the wallet's too)
    var cbWallet = (doc.inst && doc.inst.kind === 'wallet') || (!doc.inst && /\bpay balance\b/i.test(doc.flat.slice(0, 4000)) && WALLET_NAMED.test(doc.flat.slice(0, 4000)));
    if (!cand.length && cbWallet && /cashback/.test(lc(doc.subject)) && (/\b(?:has been|have been|was|is)\s+(?:added|credited)\s+(?:to|in(?:to)?)\s+your\b[^.\n]{0,30}\b(?:balance|wallet)\b/.test(doc.head) ||
        (/\bhere(?:'|\u2019)?s\s+your\b[^.\n]{0,24}\bcashback\b/.test(doc.head) && /\b(?:updated|new|current)\b[^.\n]{0,30}\bbalance\s+is\b/.test(doc.nlow.slice(0, doc.bodyAt + 1500)))))
      cand = amts(doc).filter(function (t) { return inBody(doc, t) && /^\s*cashback\b/.test(doc.nlow.slice(t.e, t.e + 12)); }).slice(0, 1);
    // a deposit's maturity or closure money said credited to your account ("Maturity amount of Rs.53,850.00 has been
    // credited to your Savings A/c XXXX1234"): that money came in, beside the deposit's own step (LABELING rule 8)
    if (!cand.length && !ctx.failed) {
      var matT = amts(doc).filter(function (t) {
        if (!inBody(doc, t) || !/^(?:maturity|principal|other)$/.test(roleOf(doc, t))) return false;
        var msn = sentenceAt(doc, t.s), msl = doc.nlow.slice(msn.s, msn.e);
        return /\b(?:maturity|premature|closure|matured|proceeds)\b/.test(msl) && /^[^.\n]{0,12}?\b(?:has been|have been|was|is)\s+(?:successfully\s+)?(?:credited|transferred|paid)\s+(?:to|in(?:to)?)\s+your\b/.test(msl.slice(t.e - msn.s));
      });
      if (matT.length) cand = [matT[0]];
    }
    // a fee charged on its own ("A cancellation fee of ₹50 was charged for your cancelled ride … debited from your Ola
    // Money wallet"): the fee is the money that moved
    if (!cand.length && !ctx.failed) {
      var feeT = amts(doc).filter(function (t) {
        if (!inBody(doc, t) || roleOf(doc, t) !== 'fee') return false;
        var fsn = sentenceAt(doc, t.s), fsl = factual(doc.nlow.slice(fsn.s, fsn.e)).replace(new RegExp(FUTURE_VERB.source, 'g'), ' ');
        return /\b(?:was|has been|have been|is)\s+(?:successfully\s+)?(?:charged|debited|deducted|levied)\b/.test(fsl.slice(t.e - fsn.s));
      });
      if (feeT.length === 1 && uniq(amts(doc).filter(function (t) { return inBody(doc, t); }).map(function (t) { return t.v; })).length === 1) cand = feeT;
    }
    // "A charge of INR 8,412.60 at EXAMPLE HOTEL ... was made on your Card": a spend, though "charge" reads as a fee
    if (!cand.length && /\ba charge of\b[^.\n]{0,80}\bat\b[^\n]{2,120}\bwas made on your\b/.test(doc.head)) cand = amts(doc).filter(function (t) { return inBody(doc, t); }).slice(0, 1);
    if (!cand.length && /refunded successfully|\b(?:have|has)\s+rec(?:ei|ie)ved (?:a |the |your )?refund|refund (?:has been |was )?(?:credited|completed|successful)|should (?:have )?reflect(?:ed)? in your (?:\w+ )?(?:account|card|bank|source)[^.\n]{0,20}by now/.test(doc.head)) {
      cand = amts(doc).filter(function (t) { return roleOf(doc, t) === 'refund' || t.role === 'other'; }).slice(0, 1);
    }
    if (!cand.length) {
      // a movement told in one sentence: an amount, your card or account, a money word ("Thank you for using your
      // card ending 4321 for Rs 160.20 at EXAMPLE FOODS", "received merchant credit refund on your card XX9876 for INR 1,234")
      // (the first 400 figures only: past that it is a table)
      var walked = 0;
      amts(doc).forEach(function (t) {
        if (cand.length || !inBody(doc, t) || t.role !== 'other' || ++walked > 400) return;
        var sen = sentenceAt(doc, t.s), ns0 = Math.max(sen.s, t.s - 160), ns = doc.nlow.slice(ns0, Math.min(sen.e, t.e + 60));
        // (an aside in brackets after the amount is passed over: "interest of Rs 17,500.00 on your Term Deposit A/c
        // XXXX4410 (Principal Rs 10,00,000.00 @ 7.00%, maturing 01/03/2027) has been credited to …")
        var aside = doc.nlow.slice(t.e, Math.max(t.e, Math.min(sen.e, t.e + 300)));
        if (/\([^()\n]{0,160}\)/.test(aside.slice(0, 120))) ns = doc.nlow.slice(ns0, t.e) + aside.replace(/\s*\([^()\n]{0,160}\)/, '').slice(0, 60);
        // the amount's own sentence ends at the first full stop after it ("... on 31-DEC-19. In case this transaction
        // was not initiated by you, click here" is the next sentence)
        var stop = ns.indexOf('. ', t.e - ns0);
        if (stop > 0) ns = ns.slice(0, stop);
        if (!/\b(?:using|used|spent|debited|credited|paid|payment|purchase|transaction|txn|received|refund|reversal|reversed|withdrawn|withdrawal|transferred|charged|deducted|disbursed|settled|settlement|charge of|was made on)\b/.test(ns)) return;
        ns = ns.replace(/\b(?:in case|if)\b[^.\n]{0,30}\b(?:not (?:initiated|done|made|authori[sz]ed|carried out)|wasn'?t you|did not (?:do|make|initiate|authori[sz]e)|not you)\b[^\n]*/g, ' ');
        if (/\b(?:will|shall|would|can|could|may|eligible|if|in case|up ?to|minimum|offer|avail|when you|get|earn|win|t&c|apply)\b/.test(ns)) return;
        // ("The payment of INR 17,436.50 for your … Card XX9052 is due on 22-Oct-2026": a bill, not a payment made)
        if (owedOnly(ns) || /\boverdue\b|\breminder\b/.test(ns)) return;
        var own = doc.toks.some(function (x) { return x.t === 'MASK' && x.s >= sen.s && x.e <= sen.e; }) || /\byour\b[^.\n]{0,40}\b(?:card|a\/c|account|wallet)\b/.test(ns);
        if (own) cand = [t];
      });
    }
    // a figure in another currency that a wallet's or an app's sentence says moved: money received into a multi-currency
    // balance ("You've received 300.00 USD from …", in that currency), a card from an app that fronts a bank's spent
    // abroad with its rupees beside it ("USD 42.50 spent at … on your Niyo Global Card … (₹ 3,592.20 at 0 markup)": those
    // rupees; its account's card, so its "Available balance" is the account's)
    if (!cand.length && doc.inst && (doc.inst.kind === 'wallet' || (doc.inst.kind === 'app' && doc.inst.cobrand)) && !ctx.promo) {
      var fw0 = null, fwIn = false, fwSen = null;
      for (var wi = 0; wi < doc.toks.length && !fw0 && wi < 400; wi++) {
        var wt = doc.toks[wi];
        if (wt.t !== 'AMT' || !wt.cur || wt.cur === 'INR' || !inBody(doc, wt)) continue;
        var wsen = sentenceAt(doc, wt.s), wl = factual(lc(wsen.text));
        if (/\b(?:will|would|could|may|if|rate|send)\b|=/.test(wl)) continue;
        if (/\b(?:spent|charged|debited|used|purchase)\b/.test(wl)) { fw0 = wt; fwSen = wsen; }
        else if (/\b(?:received|credited|added)\b/.test(wl) && !/\byou (?:have )?sent\b/.test(wl)) { fw0 = wt; fwSen = wsen; fwIn = true; }
      }
      if (fw0) {
        var fwDir = fwIn ? 'in' : 'out';
        var fwInr = fwIn ? null : amts(doc).filter(function (t) { return t.s > fw0.e && t.e <= fwSen.e + 2 && /\(\s*$/.test(doc.flat.slice(Math.max(0, t.s - 3), t.s)); })[0];
        var fwv = viaFor(doc, fw0, fwDir);
        if (fwv.kind === 'card' && doc.inst.cobrand && doc.inst.cobrand.kind === 'account') fwv.debit = true;
        var fwd = dateFor(doc, fw0), fwp = partyFor(doc, fw0, fwDir);
        var fwe = { type: 'move', dir: fwDir, amt: fwInr ? fwInr.v : fw0.v, date: fwd.date, via: fwv, conf: 'medium' };
        if (!fwInr) fwe.cur = fw0.cur;
        if (fwd.time) fwe.time = fwd.time;
        if (fwp.party) fwe.party = fwp.party;
        fwe.ev = { amt: (fwInr || fw0).raw };
        return [fwe];
      }
    }
    if (!cand.length && doc.inst && /^(?:bank|card)$/.test(doc.inst.kind) && !amts(doc).length) {
      // (the first 100 foreign figures only: past that it is a table)
      var fx0 = null, fxN = 0;
      // (a bank abroad's account is credited in its own currency too: "credited with AED 38,500.00 from SALARY …")
      var fxIn = false;
      for (var fi = 0; fi < doc.toks.length && !fx0 && fxN < 100; fi++) { var ft = doc.toks[fi]; if (ft.t !== 'AMT' || !ft.cur || ft.cur === 'INR' || !inBody(doc, ft)) continue; fxN++; var fsl = lc(sentenceAt(doc, ft.s).text); if (/\b(?:spent|charged|debited|used|purchase|transaction)\b|\bthank you for using your\b[^.\n]{0,60}\bcard\b/.test(fsl)) fx0 = ft; else if (doc.inst.ccy && /\b(?:credited|received|deposited)\b/.test(fsl) && !/\b(?:will|would|may)\b/.test(fsl)) { fx0 = ft; fxIn = true; } }
      if (fx0) {
        var fxDir = fxIn ? 'in' : 'out';
        var fv = viaFor(doc, fx0, fxDir), fdt = dateFor(doc, fx0);
        var fe = { type: 'move', dir: fxDir, amt: fx0.v, cur: fx0.cur, date: fdt.date, via: fv, conf: 'medium' };
        var fw = partyFor(doc, fx0, fxDir); if (fw.party) fe.party = fw.party;
        return [fe];
      }
    }
    if (!cand.length) return out;
    // the body's telling before the subject's (the body says who and when), one movement per amount
    cand.sort(function (a, b) { return (inBody(doc, b) - inBody(doc, a)) || a.s - b.s; });
    var seen = {};
    cand.forEach(function (t) {
      if (!(t.v > 0)) return;
      var pre = lc(doc.flat.slice(Math.max(0, t.s - 80), t.s)), post = lc(doc.flat.slice(t.e, t.e + 80));
      // (an app's own credit, "₹50 SuperCash", "120 SuperCoins", CRED coins, points: never money in a bank or a wallet, rule 9)
      if (/^\s*(?:supercash|super ?coins?|neu ?coins?|cred coins|coins|reward points|points|credits)\b/.test(post)) return;
      // the future, an offer, a wish: not a movement
      // ("will be charged", and the contracted future: "you'll be charged", "it'd be debited")
      if (/(?:\b(?:will be|shall be|would be|to be|is scheduled|scheduled|upcoming|due on|due by|will get|you can get|get|earn|win|you could|pay)|\w['’](?:ll|d) be|\w['’]ll (?:get|pay|charge|debit|bill))\b\s*(?:[a-z]+\s*){0,3}$/.test(pre) || /^\s*(?:\/-)?\s*(?:will be|shall be|would be|is (?:due|scheduled|pending)|to be)\b/.test(post)) return;
      var dir = dirOf(doc, t);
      if (!dir) dir = sameFigureDir(doc, t);
      // a payment gateway's "we have received your order" is your money gone to it (a refund or payout says so)
      if (dir === 'in' && doc.inst && doc.inst.kind === 'gateway' && /\b(?:we have |we've )?received your (?:order|payment|purchase)\b/.test(doc.nlow.slice(doc.bodyAt, doc.bodyAt + 600)) &&
        !/refund|reversal|reversed|cashback|payout|settle/.test(doc.nlow.slice(0, doc.bodyAt + 1500))) dir = 'out';
      if (/summary of the reversal|transaction (?:status:? )?reversed|txn\.? reversed|has been reversed|transaction reversal/.test(doc.head)) dir = 'in';
      if (!dir) return;
      var key = String(t.v);
      if (seen[key]) return;
      seen[key] = 1;
      var via = viaFor(doc, t, dir);
      // (a contribution "credited to your PRAN" (NPS), or into a PPF or Sukanya account: money put into the scheme,
      // which the bank's debit already tells; never money coming in to you)
      if (dir === 'in' && /\b(?:contribution|subscription|deposit|instal+ment)\b[^.\n]{0,60}\bcredited\s+(?:to|in(?:to)?)\s+(?:your\s+)?(?:pran|nps|ppf|sukanya samriddhi|ssy)\b/.test(doc.nlow.slice(Math.max(0, t.s - 120), t.e + 120))) return;
      if (dir === 'in' && !holdsMoney(doc) && via.kind !== 'wallet' && !via.last4 && !/refund|cashback|reversal|reversed|payout|claim|maturity|dividend|interest|salary|redeem|redemption|settle|disburs/.test(doc.nlow.slice(Math.max(0, t.s - 160), t.e + 80) + ' ' + lc(doc.subject))) return;
      // CRED, a gateway or a shop confirming a card's bill paid: the money went onto the card
      if (via.kind === 'card' && !(doc.inst && /^(?:bank|card)$/.test(doc.inst.kind)) && /(?:bill|card) payment (?:was|is|has been) successful|credited to card|payment confirmation/.test(doc.head)) dir = 'in';
      var who = partyFor(doc, t, dir);
      // a receipt written by whoever was paid names them as its sender (the lender, the society's treasurer, the
      // landlord), never the words after "towards" ("EMI for your Home Loan"); a donation through a platform keeps who
      // it went to ("your donation of ₹2,500 to Example Foundation via GiveIndia")
      var senT = sentenceAt(doc, t.s), slT = doc.nlow.slice(senT.s, senT.e);
      if (dir === 'out' && payeeReceipt(doc, slT) && !/\b(?:donation|contribution|gift)\s+of\s+9[9,.]*\s+to\s+[a-z]/.test(slT)) { var pyB = doc.inst ? doc.inst.short : senderBrand(doc); if (pyB) who.party = pyB; }
      var when = dateFor(doc, t);
      var ev = { type: 'move', dir: dir, amt: t.v, date: when.date, via: via };
      if (when.time) ev.time = when.time;
      if (who.party) ev.party = who.party;
      if (who.vpa) ev.vpa = who.vpa;
      if (who.toLast4) ev.toLast4 = who.toLast4;   // the other account, by its digits: a transfer between your own accounts shows up as both
      if (who.narText) ev.nar = who.narText;       // the bank's narration as it printed it (the record's info)
      var ref = refFor(doc) || (who.nar && who.nar.ref) || '';
      if (ref) ev.ref = ref;
      var mode = modeOf(doc, via, who.vpa, who.nar);
      if (mode) ev.mode = mode;
      var purpose = purposeOf(doc, dir, who.party, via, mode, t);
      if (purpose) ev.purpose = purpose;
      // (the insurer that paid it, as the narration names it without what it was for: "LIFE INSURANCE CORPORATION OF INDIA
      // SURVIVAL BENEFIT" is the corporation; the insurer's own mail names none, so it is the insurer)
      if (purpose === 'payout') {
        if (ev.party) { var pc = trim(ev.party.replace(/[\s\-\/]*\b(?:survival benefit|money[- ]?back(?: payout| instal+ment| benefit| amount)?|sb payout|maturity (?:claim|amount|benefit|value|proceeds|payout)|annuity(?: payout| payment)?|policy payout|payout)\b[\s\-\/]*$/i, '')); if (pc.length >= 3) ev.party = pc; }
        else { var pi0 = insurerIn(doc) || senderBrand(doc); if (pi0) ev.party = pi0; }
      }
      // a receipt from a society, a biller or a shop's wallet: who it was paid to is the sender
      if (!ev.party && dir === 'out' && /receipt|payment received by|received (?:by|from you)/.test(doc.head)) {
        var rb = /(?:payment )?received by\s+([^\n]{2,80})/i.exec(doc.flat.slice(0, 1500));
        // (else the sender who wrote it: the society, the biller by its own name)
        ev.party = rb ? cleanParty(rb[1]) : (doc.inst ? doc.inst.short : (billerOf(doc) ? senderBrand(doc) : ''));
        if (!ev.party) delete ev.party;
      }
      if (via.kind === 'other' && !via.inst) { var brand = senderBrand(doc); if (brand) via.inst = brand; }
      // a gateway's mail names the merchant it collected for ("Your transaction with Example LLP is successful")
      if (doc.inst && doc.inst.kind === 'gateway') {
        var gm = /\b(?:transaction|payment|order)\s+(?:with|to|at|for)\s+([A-Za-z0-9][^\n|]{1,60}?)\s+(?:on\s+\S+\s+)?(?:is|was|has been)\s+successful/i.exec(doc.subject + '\n' + doc.flat.slice(doc.bodyAt, doc.bodyAt + 600))
          || /^\s*payment\s+(?:successful|done|received|completed)\s+(?:for|to|at)\s+(.{2,60}?)\s*$/i.exec(doc.subject);
        // (the UPI ID on a gateway's receipt is the payer's: yours)
        if (gm && cleanParty(gm[1])) { if (ev.vpa && ev.party === ev.vpa) delete ev.vpa; ev.party = cleanParty(gm[1]); }
      }
      // (an EMI the bank's loan desk says it debited is paid to the loan: "HDFC Home Loan")
      if ((!ev.party || /^(?:emi|payment|loan|instal+ment|emi payment)$/i.test(ev.party)) && dir === 'out' && purpose === 'emi' && doc.inst && /^(?:bank|lender)$/.test(doc.inst.kind) && /\bloan\s*(?:a\/c|account|acct)\b/.test(doc.low)) ev.party = loanName(doc);
      if (!ev.party && doc.inst && /^(?:broker|rta|app|gateway|wallet|insurer|lender)$/.test(doc.inst.kind) && via.kind !== 'wallet') ev.party = doc.inst.short;
      // (a shop's own mail charging you, a fee from its wallet, names no one else: the shop charged it, rule 5)
      if (!ev.party && dir === 'out' && !doc.inst && shopOf(doc)) ev.party = shopOf(doc).name;
      // cashback or a refund into a shop's own balance: the shop paid it
      if (!ev.party && dir === 'in' && via.kind === 'wallet' && /cashback|refund/.test(ev.purpose || '')) { var sb0 = senderBrand(doc); if (sb0) ev.party = sb0; }
      ev.ev = { amt: t.raw };
      ev.conf = (via.last4 || via.kind === 'wallet' || via.kind === 'upi') && when.dated ? 'high' : 'medium';
      out.push(ev);
    });
    out = out.slice(0, 1);
    // ("INR 500.00 debited from A/c XX4821 to Asha Example on 05-10-26; your account XX4821 credited with INR 25.00
    // cashback": the debit, and the cashback credited beside it, as money in of its own)
    if (out[0] && out[0].dir === 'out') {
      var cbRe = /\b(?:a\/c|account|acct|card|wallet)\s*(?:no\.?\s*)?[x*\u2022\d]*\s+(?:has been\s+|is\s+|was\s+)?credited\s+(?:with|by|for)\s+(?=(?:inr|rs\.?|\u20b9)\s*[\d,]+(?:\.\d+)?\s+(?:as\s+)?cashback\b)|\bcashback\s+of\s+(?=(?:inr|rs\.?|\u20b9)\s*[\d,]+(?:\.\d+)?\s+(?:has been|is|was)\s+credited\s+(?:to|in)\s+your\b)/gi, cbm;
      var body = doc.flat.slice(doc.bodyAt, doc.bodyAt + 1500);
      while ((cbm = cbRe.exec(body))) {
        var at = doc.bodyAt + cbm.index + cbm[0].length;
        var ct = amts(doc).filter(function (x) { return x.s >= at && x.s <= at + 2; })[0];
        if (!ct || !(ct.v > 0) || ct.v >= out[0].amt) continue;
        var cbv = viaFor(doc, ct, 'in'), cbw = dateFor(doc, ct);
        out.push({ type: 'move', dir: 'in', amt: ct.v, date: cbw.date, via: cbv, purpose: 'cashback', ev: { amt: ct.raw }, conf: 'medium' });
        break;
      }
    }
    return out;
  }
  function senderBrand(doc) {
    if (doc.inst) return doc.inst.short;
    var s = shopOf(doc);
    if (s) return s.name;
    // (a biller by its own name: "BESCOM", "Adani Electricity", "ACT", never its domain run together)
    var bl = billerOf(doc);
    if (bl) return bl.short || bl.name;
    // (never the mailbox a person wrote from, "Gmail", but the name they write under; a hosted store is its own name)
    if (personalMail(doc)) return personalNote(doc) ? '' : personalName(doc);
    var hs = hostedShop(doc);
    if (hs) return hs;
    var parts = doc.domain.split('.').filter(function (p) { return !DOMAIN_FILLER.test(p); });
    var d = parts.length ? parts[parts.length - 1] : '';
    // (the name its mail is sent under, when that is the domain spelt out: "Times Prime <noreply@timesprime.com>")
    var dn0 = /^\s*"?([^"<]{2,40}?)"?\s*</.exec((doc.msg && doc.msg.from) || '');
    if (d && dn0 && lc(dn0[1]).replace(/[^a-z0-9]/g, '') === d) return trim(dn0[1]);
    // (a bank, lender or insurer kosh has no entry for, by the name it writes under, never its domain run together:
    // "The Cosmos Co-operative Bank <alerts@cosmosbank.in>" is Cosmos Co-operative Bank, not "Cosmosbank")
    var dn1 = /^\s*"?([^"<]{2,70}?)"?\s*</.exec((doc.msg && doc.msg.from) || '');
    if (dn1 && /\b(?:bank|co-?op(?:erative)?|sahakari|gramin|grameena|payments bank|finance|financial services|insurance|assurance)\b/i.test(dn1[1])) {
      var bn = trim(dn1[1].replace(/\s*[-|:]\s*(?:insta\s*)?(?:alerts?|notifications?|customer ?care|e-?statements?|transactions?|no-?reply)\b.*$/i, '').replace(/\b(?:insta\s*)?alerts?$/i, '')
        .replace(/^the\s+/i, '').replace(/,?\s+(?:co\.?\s*)?(?:ltd|limited)\.?$/i, ''));
      if (bn.length >= 3) return bn;
    }
    return d ? capWords(d.replace(/living$/, '')) : '';
  }

  /* ------------------------------------------------------------ tax facts read off mail
     The financial year a day falls in ("2026-27"), and the tax deducted at source that a client's payment advice or the
     tax department's Form 26AS mail tells: events of type 'tax' (what 'tds': the deductor, the amount paid, the TDS,
     the year), facts for tax that move no money of their own */
  function fyOfDay(iso) { var y = +String(iso).slice(0, 4), s = +String(iso).slice(5, 7) >= 4 ? y : y - 1; return s + '-' + pad((s + 1) % 100); }
  // the name a company's accounts desk writes under ("Example Media House Accounts <accounts@…>": Example Media House)
  function payerName(doc) {
    var n = personalName(doc).replace(/\s*[-–|,]?\s*\b(?:accounts?(?:\s+(?:team|dept\.?|department|payable))?|finance(?:\s+team)?|payables?|a\/?p\s+team|payments?\s+team|treasury)\s*$/i, '');
    return n.length >= 3 ? n : senderBrand(doc);
  }
  /* a client's payment advice to you ("We have released payment against your invoice. Invoice amount: Rs.60,000.00 / TDS
     u/s 194J @10%: Rs.6,000.00 / Net paid: Rs.54,000.00"): money coming to you from the client (its bank's credit is the
     same money), never your own purchase; the TDS it kept back is a tax fact */
  function paymentAdvice(doc, ctx) {
    if (ctx.promo || ctx.person || (doc.inst && /^(?:bank|card|wallet|insurer|broker|rta|tax|lender|gateway)$/.test(doc.inst.kind))) return null;
    if (!/\b(?:payment|remittance) advice\b|\breleased (?:the |your )?payment (?:against|towards|for) your (?:invoice|bill)s?\b|\bpayment (?:has been |was )?released (?:against|towards|for) your (?:invoice|bill)s?\b/.test(doc.head)) return null;
    var net = kv(doc, /^(?:net (?:paid|payment|amount(?: paid| released| remitted)?|payable)|amount (?:paid|released|remitted)|net amount)$/);
    if (!net || !(net.amt > 0)) return null;
    var gross = kv(doc, /^(?:invoice|bill|gross)(?: amount| value)?$/), tds = kv(doc, /^tds\b|tax deducted/);
    // (a label the pair reader passes over, "TDS u/s 194J @10%: Rs.6,000.00")
    if (!tds) { var tm = /^\s*((?:tds|tax deducted)\b[^:\n]{0,40}):\s*(?:rs\.?|₹|inr)\s*(\d[\d,]*(?:\.\d{1,2})?)\s*$/im.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 3000)); if (tm) tds = { key: lc(tm[1]), value: tm[2], amt: num(tm[2]) }; }
    var who = payerName(doc);
    var day = doc.ref;
    var ev = { type: 'move', dir: 'in', amt: net.amt, date: day, via: { kind: 'other' }, purpose: 'payout', conf: 'medium', ev: { amt: net.value } };
    if (who) ev.party = who;
    var out = [ev];
    if (tds && tds.amt > 0 && (!gross || !(gross.amt > 0) || Math.abs(gross.amt - tds.amt - net.amt) < 1)) {
      var tx = { type: 'tax', what: 'tds', amt: tds.amt, fy: fyOfDay(day), date: day };
      if (gross && gross.amt > 0) tx.gross = gross.amt;
      if (who) tx.payer = who;
      var sec = /\b(?:u\/s|section|sec\.?)\s*(19[0-9][a-z]{0,2})\b/i.exec(tds.key + ' ' + tds.value); if (sec) tx.section = sec[1].toUpperCase();
      out.push(tx);
    }
    return { events: out };
  }
  /* the tax department's Form 26AS / AIS mail with the TDS each deductor deposited ("EXAMPLE ADVERTISING PVT LTD (194J):
     Amount paid Rs.85,000.00, TDS Rs.8,500.00 … Total TDS: Rs.12,700.00"): one fact per deductor, and the total, for
     the financial year before its assessment year */
  function taxStatement(doc) {
    if (!/form ?26 ?as\b|annual (?:tax|information) statement|\bais\b/.test(doc.head)) return null;
    if (!(doc.inst && doc.inst.kind === 'tax') && !/(?:^|\.)(?:tdscpc|incometax)\.gov\.in$/.test(doc.domain || '')) return null;
    var body = doc.flat.slice(doc.bodyAt, doc.bodyAt + 6000);
    var ay = /\b(?:assessment year|a\.?y\.?)\s*[:\-]?\s*(20\d{2})\s*[-–\/]\s*(\d{2,4})\b/i.exec(doc.subject + '\n' + body);
    var fy = ay ? (+ay[1] - 1) + '-' + pad(+ay[1] % 100) : fyOfDay(doc.ref);
    var out = [], re = /^\s*([A-Z][A-Za-z0-9&.,' \-]{2,80}?)\s*(?:\((19[0-9][A-Z]{0,2})\))?\s*:\s*amount (?:paid|credited)\s*(?:rs\.?|₹|inr)\s*(\d[\d,]*(?:\.\d{1,2})?)\s*,\s*tds\s*(?:deducted|deposited)?\s*(?:rs\.?|₹|inr)\s*(\d[\d,]*(?:\.\d{1,2})?)/gim, m;
    while ((m = re.exec(body)) && out.length < 40) {
      var e = { type: 'tax', what: 'tds', src: '26as', payer: trim(m[1]), amt: num(m[4]), gross: num(m[3]), fy: fy };
      if (m[2]) e.section = m[2].toUpperCase();
      if (e.amt > 0) out.push(e);
    }
    var tot = /\btotal tds\s*(?:deposited|deducted)?\s*[:\-]?\s*(?:rs\.?|₹|inr)\s*(\d[\d,]*(?:\.\d{1,2})?)/i.exec(body);
    var sum = out.reduce(function (a, x) { return a + x.amt; }, 0);
    if (tot && num(tot[1]) > 0 && (!out.length || Math.abs(num(tot[1]) - sum) < 1)) out.push({ type: 'tax', what: 'tds', src: '26as', total: true, amt: num(tot[1]), fy: fy });
    return out.length ? { events: out } : null;
  }

  /* the balance an alert reports, for an account or a wallet (a card's available limit is not a balance) */
  function balances(doc, mv) {
    var out = [];
    // (a move in another currency into a multi-currency balance: that currency's balance, "Your USD balance: 1,240.55 USD")
    // (and a bank abroad's account alert: "Available balance AED 41,915.00", that account's balance in its currency)
    if (mv && mv.cur && mv.cur !== 'INR' && mv.via && (mv.via.kind === 'wallet' || ((mv.via.kind === 'account' || mv.via.debit) && doc.inst && doc.inst.ccy === mv.cur))) {
      doc.toks.forEach(function (t) { if (!out.length && t.t === 'AMT' && t.cur === mv.cur && t.v !== mv.amt && roleOf(doc, t) === 'bal') out.push({ type: 'balance', via: Object.assign({}, mv.via), amt: t.v, cur: t.cur, ev: { amt: t.raw } }); });
      return out;
    }
    amts(doc).forEach(function (t) {
      if (roleOf(doc, t) !== 'bal') return;
      var pre = lc(doc.flat.slice(Math.max(0, t.s - 60), t.s));
      if (/limit|outstanding/.test(pre.slice(-40))) return;
      // (what was paid from a balance is not what's left in it: "Paid by Amazon Pay balance: ₹3,020.90")
      if (/\b(?:paid|payment|pay)\s+(?:by|from|using|via|with|through)\s+[^\n]{0,30}\bbalance\s*[:\-|]?\s*$/.test(pre)) return;
      // (a FASTag's, a DTH box's or a prepaid phone's balance is no account's, rule 21; nor a biller's of you. Its own
      // clause says whose it is: "Bill Payment to EXAMPLE DTH (Txn ID …). Bal Rs.1,941.00" is the account's after paying it)
      var clause = pre.split(/[.;|\n]\s/).pop();
      if (/fastag|\bdth\b|\btag\b|talk ?time|prepaid|recharge/.test(/^\s*(?:avl\.?|available|clear(?:ed)?|closing)?\s*bal(?:ance)?\b/.test(clause) ? clause : pre) || billerSender(doc)) return;
      var via = mv && mv.via ? Object.assign({}, mv.via) : viaFor(doc, t, '');
      if (via.kind === 'card' && !via.debit) return;
      if (via.debit) { via = { kind: 'account', inst: via.inst }; }
      if (out.some(function (b) { return b.amt === t.v; })) return;
      var b = { type: 'balance', via: via, amt: t.v, ev: { amt: t.raw } };
      // ("balance as on 05-OCT-2026 is …": the balance at that day's end, whenever the mail was sent)
      var k = pre.lastIndexOf('as on');
      if (k >= 0) { var d = near(doc, 'DATE', Math.max(0, t.s - 60) + k + 5, 0, 30); if (d && d.v) b.asOn = d.v; }
      out.push(b);
    });
    return out.slice(0, 1);
  }

  /* a card's statement or bill: what's due, the minimum, by when, for which card */
  function statements(doc, ctx) {
    var s = lc(doc.subject), l = doc.low.slice(0, 4000);
    var stmtish = /statement|new bill|bill (?:for|is) (?:here|ready|generated)|bill summary|bill generated/.test(s) || /\bstatement date\b|\btotal amount due\b|\bminimum amount due\b|bill summary/.test(l);
    if (!stmtish) return [];
    // a reminder that a bill is due is the due, not the statement it came from
    if (/\bdue in\b|\bis due\b|reminder|due date is|overdue|pay (?:now|by|before)|\b(?:bill|payment) (?:is )?due\b/.test(s) && !/statement|generated|is ready|is here|new bill/.test(s)) return [];
    var cardish = doc.kind === 'card' || /credit card|card (?:statement|bill)|\bcard\b.{0,20}(?:xx|•|\*)/.test(s + ' ' + l.slice(0, 1500));
    if (!cardish) return [];
    var totP = kv(doc, /\btotal\b.*\b(?:due|outstanding|dues)\b|^total amount due|^amount due$|statement balance|last statement balance|total dues|^closing balance|^new balance/);
    var minP = kv(doc, /\bmin(?:imum)?\b.*\b(?:due|payment)\b/);
    var tot = totP && totP.amt != null ? totP.amt : null, min = minP && minP.amt != null ? minP.amt : null;
    if (tot === null || min === null) amts(doc).forEach(function (t) { var r = roleOf(doc, t); if (r === 'total' && tot === null) tot = t.v; if (r === 'min' && min === null) min = t.v; });
    // (figures printed bare after their label, no rupee sign and no paise: "Total Amount Due 12,400")
    var bareFig = function (re) { var m = new RegExp(re.source + '\\s*(?:of|is|:|-)?\\s*(?:rs\\.?|inr|₹)?\\s*(\\d[\\d,]*(?:\\.\\d{1,2})?)(?![\\d,]|[\\/\\-.]\\d|\\s*%)', 'i').exec(doc.flat.slice(doc.bodyAt)); return m ? num(m[1]) : null; };
    if (tot === null) tot = bareFig(/\btotal (?:amount )?due\b/);
    if (min === null) min = bareFig(/\bmin(?:imum)? (?:amount )?due\b/);
    var due = dueDateIn(doc), stmtDate = '';
    var sd = kv(doc, /^(?:statement|bill) date$|^statement generat|^bill generated on|^closing date|^generated on/);
    if (sd && sd.date) stmtDate = sd.date; else stmtDate = labeledDate(doc, /(?:statement|bill)\s*(?:date|generated on)|bill generated on|closing date/);
    var period = periodIn(doc);
    if (tot === null && /no payment (?:due|required)|nil|zero/.test(l)) tot = 0;
    // (a "your statement is ready" notice with no figures is the card's statement all the same: its card, nothing else;
    // the screens wait for the figures, from the PDF or the next mail)
    var ready = tot === null && !due && /statement[^\n]{0,60}\b(?:is |are )?(?:ready|available|now available|enclosed|attached)|online statement|statement online|e-?statement/.test(s + ' ' + l.slice(0, 1500));
    if (tot === null && !due && !ready) return [];
    var t0 = totP && totP.toks && totP.toks[0];
    var via = viaFor(doc, t0 || null, '');
    via.kind = 'card'; delete via.debit;
    // the card's digits may only be in the statement's file name ("4000XXXXXXXXXX12_19-12-2026.pdf")
    if (!via.last4) { var fm = /(?:^|[^\d])\d{0,6}[x*]{2,}(\d{2,4})(?!\d)/i.exec(doc.files); if (fm) via.last4 = fm[1]; }
    var ev = { type: 'statement', via: via };
    if (stmtDate) ev.stmtDate = stmtDate;
    if (period) { ev.from = period.from; ev.to = period.to; }
    if (tot !== null) ev.total = tot;
    if (min !== null) ev.min = min;
    if (due) ev.due = due;
    ev.conf = tot !== null && due ? 'high' : 'medium';
    return [ev];
  }
  function labeledDate(doc, re) {
    var m, rx = new RegExp(re.source, 'gi');
    while ((m = rx.exec(doc.flat))) { var d = near(doc, 'DATE', m.index + m[0].length, 0, 45); if (d) return d.v; }
    return '';
  }
  function dueDateIn(doc) {
    // (an overdue bill or a failed AutoPay, "were due on 07-10-2026 … Pay ₹1,612 by 10-10-2026": the day to pay by now)
    if (/\b(?:were|was) due on\b|\boverdue\b|\bfailed\b|could not be (?:processed|collected)/.test(doc.head)) { var pbNow = labeledDate(doc, /\b(?:please )?pay\b(?:[^.\n]|\.(?=\s?\d)){0,30}?\b(?:by|before)/); if (pbNow) return pbNow; }
    var p = kv(doc, /(?:payment\s*)?due\s*(?:date|on|by)|^due$|pay(?:ment)? by|last date/);
    if (p && p.date) return p.date;
    // ("…is due from 23-Aug-2026. Please pay by 29-Aug-2026": the day to pay by, not the day it fell due)
    var pb = labeledDate(doc, /\b(?:please )?(?:pay|clear (?:your |the )?dues)\s+(?:by|before)/);
    if (pb) return pb;
    var anyDue = kvAll(doc, /\bdue\b|pay by|last date/).filter(function (q) { return q.date; })[0];
    if (anyDue) return anyDue.date;
    // "before 29-March-2026 (your due date)": the date the mail names as the due date
    var yd = doc.toks.filter(function (t) { return t.t === 'DATE' && /^\s*\(\s*(?:your|the) due date\s*\)/i.test(doc.flat.slice(t.e, t.e + 30)); })[0];
    if (yd) return yd.v;
    return labeledDate(doc, /(?:payment\s*)?due\s*(?:date|on|by)|due date is|pay(?:ment)? by|pay before|on or before|\bpay\b(?:[^.\n]|\.(?=\s?\d)){0,30}?\bby|last date(?: of payment| to pay)?|is due on|bill (?:is )?due on|due in \d+ days? on|to be paid by|(?:is )?payable (?:by|on|before)|before the due date \(/);
  }
  function periodIn(doc) {
    var ds = doc.toks.filter(function (t) { return t.t === 'DATE'; });
    for (var i = 0; i + 1 < ds.length; i++) {
      var a = ds[i], b = ds[i + 1];
      if (/^\s*(?:-|to|till|until)\s*$/i.test(doc.flat.slice(a.e, b.s)) && dayNum(b.v) > dayNum(a.v) && dayNum(b.v) - dayNum(a.v) <= 45 && /statement|period|bill|for\s*(?:the\s*)?$/i.test(doc.flat.slice(Math.max(0, a.s - 80), a.s))) return { from: a.v, to: b.v };
    }
    return null;
  }

  /* something to pay by a date: a card bill reminder, a utility bill, maintenance. (Premiums are policies(),
     auto-debits coming up are mandates()) */
  function dues(doc, ctx) {
    var s = lc(doc.subject), l = doc.head;
    var dueish = /\b(?:due|overdue|reminder|pay now|pay before|pay by|payment pending|dues|invoice|charges?\b.{0,20}generated|bill (?:generated|is ready)|bill of (?:₹|rs\.?|inr)\s?[\d,.]+ is ready)\b/.test(s) || /\b(?:bill|payment|dues?|amount)\s+(?:is\s+)?(?:due|overdue)\b|\bdue (?:date|on|in|by)\b|\bpayment reminder\b|make the (?:remaining )?payment/.test(l);
    var payAfterFail = ctx.failed && /\b(?:please )?pay\b(?:[^.\n]|\.(?=\s?\d)){0,30}?\b(?:by|before)\b/.test(doc.lead);
    if (payAfterFail) dueish = true;
    // a bill that says when to pay it, with no word "due" ("Your gas bill … is Rs. 892.00. Please pay by 25-Oct-2026")
    if (!dueish && /\b(?:please |kindly )?pay\b(?:[^.\n]|\.(?=\s?\d)){0,30}?\b(?:by|before|on or before)\s+\d/.test(doc.nlow.slice(doc.bodyAt, doc.bodyAt + 1500)) && /\b(?:bill|invoice|dues|charges)\b/.test(s + ' ' + l)) dueish = true;
    if (!dueish || ctx.paidNow || ctx.insurer || ctx.stmt || (ctx.mandate && !payAfterFail) || ctx.policy || ctx.order || ctx.creditReport) return [];
    if (/receipt|payment received|paid successfully|is successful/.test(s)) return [];
    if (/\bno (?:outstanding|amount|dues?|balance)\b[^.\n]{0,30}\bdue\b|\bnothing (?:is )?(?:due|outstanding)\b|\b(?:has been|is|was) (?:permanently )?(?:closed|cancell?ed)\b/.test(doc.lead)) return [];
    // "will be charged tomorrow" is a promise (expects()), not a bill
    if (/\bwill be (?:charged|debited|deducted|auto-?debited)\b/.test(doc.lead) && !/\bpay\b[^.\n]{0,40}\bby\b|\bdue (?:date|on|by)\b/.test(doc.lead)) return [];
    var cardish = doc.kind === 'card' || /credit card|card bill|card (?:payment|dues)|\bcard\b.{0,30}(?:xx|•|\*)|minimum (?:amount )?due|\bmad\b/.test(s + ' ' + doc.low.slice(0, 1200));
    var what = cardish ? 'card' : /water|electricity|power|gas\b|broadband|internet|mobile|postpaid|dth|lpg/.test(s) || /\bpostpaid bill\b/.test(doc.low.slice(doc.bodyAt, doc.bodyAt + 400)) ? 'bill' : (/maintenance|society|association|apartment/.test(s + ' ' + doc.low.slice(0, 600)) || (/\bdues\b/.test(s + ' ' + doc.low.slice(0, 600)) && !(doc.inst && /^(?:lender|wallet|app)$/.test(doc.inst.kind)))) ? 'maintenance' : /\bemi\b|loan/.test(s) ? 'emi' : /subscription|membership/.test(s) ? 'subscription' : /\btax\b/.test(s) ? 'tax' : /\b(?:tuition|school|college|coaching|class(?:es)?|course|exam|admission|term)\b[^.\n]{0,20}\bfees?\b|^\s*fees?\b/.test(s) ? 'fee' : 'bill';
    var NOT_DUE_KEY = /\b(?:min(?:imum)?|after|late|paid|previous|last|past)\b/;
    var totP = kv(doc, new RegExp('^(?!.*' + NOT_DUE_KEY.source + ').*(?:total dues|\\btotal\\b.*\\bdue|total amount)')) || kv(doc, new RegExp('^(?!.*' + NOT_DUE_KEY.source + ').*(?:amount due|bill amount|invoice amount|outstanding|amount payable)'));
    // (a sentence's "Total amount due of INR 9,862.00" before a pair's "Minimum amount due: INR 494.00")
    if (totP && /\bmin(?:imum)?\b/.test(totP.key)) totP = null;
    if (!totP) { var tsen = /\btotal (?:amount )?(?:due|outstanding|payable)\s*(?:of|is|:)?\s*(?:rs\.?|inr|₹)\s*(\d[\d,]*(?:\.\d+)?)/i.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 1500)); if (tsen) totP = { amt: num(tsen[1]), key: 'total due' }; }
    var tot = totP && totP.amt != null ? totP.amt : null;
    if (tot === null) amts(doc).forEach(function (t) { var r = roleOf(doc, t); if (tot === null && (r === 'total' || r === 'due' || r === 'bill')) tot = t.v; });
    if (tot === null) { var first = amts(doc).filter(function (t) { return t.role === 'other' || t.role === 'moved'; })[0]; if (first && /due|bill|pay|outstanding|amount|dues|invoice|charges/.test(lc(doc.flat.slice(Math.max(0, first.s - 80), first.s)) + s)) tot = first.v; }
    // the amount a sentence says is still to pay ("your EMI of Rs.6,500.00 for loan XX9911 is payable on 05-11-2026")
    if (tot === null) { var owed = amts(doc).filter(function (t) { var r = roleOf(doc, t); return inBody(doc, t) && r !== 'offer' && r !== 'bal' && r !== 'limit' && r !== 'min' && owedOnly(lc(sentenceAt(doc, t.s).text)); })[0]; if (owed) tot = owed.v; }
    var due = dueDateIn(doc);
    var anyAmt = amts(doc).some(function (t) { var r = roleOf(doc, t); return r !== 'offer' && r !== 'bal' && r !== 'limit'; });
    if (!due && !anyAmt && !cardish) return [];
    // (a due is something to pay by a date, rule 11: an amount only "outstanding", "kindly clear it at the earliest",
    // with no date and no word that it is due or overdue, is not one. That is a card's or a bank's alert: a society's or
    // a biller's dues reminder, "dues of Rs. 4,500 are pending for flat A-1203", is a due without a date)
    var duesNote = what !== 'card' && !(doc.inst && /^(?:bank|cobrand|app|wallet)$/.test(doc.inst.kind)) && !/\bpending (?:confirmation|from the biller)|in progress|being processed/.test(s)
      && (/\bdues?\b|\breminder\b|maintenance/.test(lc(doc.subject)) || (doc.inst && doc.inst.kind === 'society'));
    if (!due && !duesNote && !/\b(?:over ?due|is due|are due|due (?:in|today|tomorrow|now|immediately)|past due)\b/.test(s + ' ' + l)) return [];
    if (tot === null && !due && !/overdue|is due|due in/.test(s + ' ' + l)) return [];
    var ev = { type: 'due', what: what };
    var payee = billerIn(doc);
    if (!payee && doc.inst && /^(?:lender|wallet|app)$/.test(doc.inst.kind) && what !== 'card') payee = doc.inst.short;
    if (payee) ev.payee = payee.replace(/^your\s+/i, '');
    if (tot !== null) ev.amt = tot;
    if (due) ev.due = due;
    if (cardish) { var v = viaFor(doc, null, ''); v.kind = 'card'; delete v.debit; ev.via = v; }
    ev.conf = tot !== null && due ? 'high' : 'medium';
    return [ev];
  }
  /* the biller a bill names: knowledge.js's billers by name, else the society or company the mail is for */
  // a mail sent by a biller itself (its own domain), not one that merely names one ("near the IOCL petrol pump")
  // (by its own domain, or by the whole name its mail is sent under: "BESCOM <ebill@bescom.co.in>", "Adani Electricity
  // <noreply@…>"; never a bank's, a card's, a wallet's or an app's, nor a person's mailbox)
  // (a lender or an insurer that takes its EMIs or premiums through BBPS is listed among the billers too, "Ujjivan Small
  // Finance Bank", "Bajaj Allianz General Insurance": its own mail is a bank's, lender's or insurer's, never a utility's
  // bill, and the balance it prints is your account's)
  var NOT_BILL_SENDER = /^(?:loan emi|insurance)$/i, BILL_SENDERS = null;
  function billerOf(doc) {
    var list = BILL_SENDERS || (BILL_SENDERS = (K.billers || []).filter(function (b) { return !NOT_BILL_SENDER.test(b.cat || ''); }));
    for (var i = 0; i < list.length; i++) if (onDomain(doc.domain, list[i].domains)) return list[i];
    if (personalMail(doc) || (doc.inst && /^(?:bank|card|wallet|app|broker|rta|insurer|lender|gateway|merchant)$/.test(doc.inst.kind))) return null;
    var dn = /^\s*"?([^"<]{2,60}?)"?\s*</.exec((doc.msg && doc.msg.from) || ''), n = dn ? lc(trim(dn[1])) : '';
    if (n.length < 2) return null;
    for (var j = 0; j < list.length; j++) { var b = list[j]; if ([b.short, b.name].concat(b.aliases || []).some(function (x) { return x && lc(x) === n; })) return b; }
    return null;
  }
  function billerSender(doc) { return !!billerOf(doc); }
  function billerIn(doc) {
    var lt = doc.low.slice(0, 2500);
    var list = K.billers || [];
    var best = null, at = 1e9;
    for (var i = 0; i < list.length; i++) {
      var b = list[i];
      var names = [b.short].concat(b.aliases || []);
      for (var j = 0; j < names.length; j++) {
        var n = lc(names[j]);
        if (!n || n.length < 4) continue;
        var k = lt.indexOf(n);
        // (never a footer's menu word on a line of its own: "Get help / Connect / Download")
        while (k >= 0 && (/[a-z0-9]/.test(lt.charAt(k - 1)) || /[a-z0-9]/.test(lt.charAt(k + n.length)) || (n.indexOf(' ') < 0 && /(?:^|\n)\s*$/.test(lt.slice(Math.max(0, k - 3), k)) && /^\s*(?:\n|$)/.test(lt.slice(k + n.length, k + n.length + 3))))) k = lt.indexOf(n, k + 1);
        if (k >= 0 && k < at) { at = k; best = b.short || b.name; }
      }
    }
    if (best) return best;
    // a society app's bill names the society it is for ("Invoice EXR/0456 from Example Residency", "Outstanding dues at
    // Example Lake View Apartments")
    if (doc.inst && doc.inst.kind === 'society') { var soc = /\b(?:from|at|for)\s+([A-Z][A-Za-z0-9&.' -]{2,60}?)\s*$/.exec(trim(doc.subject)); if (soc && !/^(?:the|your|you)\b/i.test(soc[1])) return trim(soc[1]); }
    // a pay-later or postpaid account's own name in the subject ("Example Postpaid bill generated")
    var sm = /^([A-Za-z][A-Za-z ]{2,40}?\s(?:postpaid|pay later|paylater))\b/i.exec(trim(doc.subject));
    if (sm) return trim(sm[1]);
    // (a society's name on a line of its own; never the greeting, "Dear Resident", nor a sentence asking you to pay)
    var line = doc.lines.filter(function (x) { return /\b(?:society|association|sanstha|sahakari|residents?|apartments?|chs|condominium)\b/i.test(x) && x.length < 90 && !/^\s*(?:dear|hi|hello|respected)\b/i.test(x) && !/\b(?:please|kindly|you|your|is due|due (?:by|on)|pay|payable)\b/i.test(x); })[0];
    if (line) return cleanParty(line.replace(/^.*?\b(?:generated by|from|by|of)\s+/i, '')).slice(0, 60);
    var bp = kv(doc, /^biller(?: name)?$/);
    if (bp) return cleanParty(bp.value);
    // a biller's own mail, when its body never spells the name knowledge.js keeps: the brand it writes under. The name
    // match above needs four letters, so "IGL", "Vi", "MGL", "BEST", "CESC", "KSEB" can never win it, and a regional
    // entry's short ("Tata Power Mumbai") is a name no mail prints. billerOf has already matched the sender by domain
    // or display name, and refuses banks, cards, wallets, apps, brokers, insurers, lenders, gateways and webmail.
    if (billerOf(doc)) {
      var bdn = /^\s*"?([^"<]{2,60}?)"?\s*</.exec((doc.msg && doc.msg.from) || '');
      if (bdn) { var bn = cleanParty(bdn[1]); if (bn.length >= 2) return bn; }
    }
    // (a society, tutor or landlord writing from a personal mailbox: the name it writes under)
    return personalMail(doc) && !personalNote(doc) ? personalName(doc) : '';
  }

  /* an auto-debit's step: coming up, done, set up, cancelled */
  // a line that invites you to set something up ("To register for JioAutoPay, click", "Set up AutoPay now") says
  // nothing about a mandate you have
  var INVITE = /^(?:[^a-z\n]*)(?:to |please |you can |now |simply )?(?:register|enable|set ?up|activate|opt|sign ?up|switch|try|subscribe|link|start)\b[^\n]{0,80}(?:click|tap|visit|here|now|app|today|link)\b[^\n]*$/gm;
  function mandates(doc, ctx) {
    var head = doc.head.replace(INVITE, ' ');
    if (!/e-?mandate|standing instruction|\bsi\b|\bauto-?debit|\bautopay|\bauto pay|automatic payment|\bnach\b|\bumrn\b|recurring payment|\bsmartpay|due for debit/.test(head)) return [];
    var action = /revoked|cancel+ed|deactivat(?:ed|ion)|de-?registration|paused|\bdelet(?:e|ed|ion)\b|\bremoved\b/.test(head.slice(0, 500)) ? 'cancelled'
      : ctx.failed ? (/e-?mandate|standing instruction|auto-?debit|autopay|\bsi\b/.test(lc(doc.subject)) ? 'failed' : '')
      : /upcoming (?:debit|payment|auto-?debit|automatic payment|e-?mandate|mandate|si\b|transaction|charge|renewal|instal+ment|emi)|will be (?:auto(?:matic(?:ally)?)?[- ]?)?(?:debited|paid|charged)|scheduled for|is due on|due for debit|would be debited|to be debited|pre-?debit/.test(head) ? 'upcoming'
      : /processed successfully|(?:has been|have been|was|were) (?:successfully )?(?:paid|processed|debited|executed)|successfully paid|execution - success|\bexecuted\b/.test(head) ? 'done'
      : /registered|created|set up|\bsetup\b|has been set\b|activated|successfully (?:registered|created)|(?:have|has been|was) accepted|accepted your/.test(head) ? 'created' : '';
    if (!action) return [];
    var amtP = kv(doc, /^(?:payment |debit |mandate |si )?amount$|^amount$/);
    var a = amtP && amtP.toks && amtP.toks.filter(function (t) { return t.t === 'AMT'; })[0];
    var amt = amtP && amtP.amt != null ? amtP.amt : (a ? a.v : null);
    if (amt === null) { var f = amts(doc).filter(function (t) { var r = roleOf(doc, t); return r !== 'bal' && r !== 'limit' && r !== 'offer' && r !== 'fee' && r !== 'part'; })[0]; if (f) { a = f; amt = f.v; } }
    // (a card's charge in another currency, printed in no rupees: "a payment of USD 23.60 for EXAMPLEAI will be auto
    // debited from your Credit Card": that sum in that currency, never rupees)
    var fxCur = '';
    if (amt === null) { var fxa = doc.toks.filter(function (t) { return t.t === 'AMT' && t.cur && t.cur !== 'INR' && inBody(doc, t); })[0]; if (fxa) { a = fxa; amt = fxa.v; fxCur = fxa.cur; } }
    var ev = { type: 'mandate', action: action };
    var bp = kv(doc, /^(?:biller|merchant|beneficiary|payee)(?: name)?$/);
    var fq = kv(doc, /^(?:payment |premium |debit |mandate |si )?frequency$|^(?:mode|frequency) of (?:payment|premium|debit)$/);
    // (an insurer's own mail about the standing instruction or autopay on its policy: the premium goes to the insurer,
    // whatever the request is called: "Your Service request … for Autopay Deactivation has been processed")
    var party = bp ? cleanParty(bp.value) : doc.inst && doc.inst.kind === 'insurer' ? insurerIn(doc) : '';
    var m;
    // ("payment of USD 23.60 for OpenAILLC will be auto debited": whom the payment is for, in its own sentence)
    if (!party && (m = /\bpayment of\s+(?:[A-Z]{3}|₹|rs\.?|inr)\s*[\d,]+(?:\.\d+)?\s+for\s+([A-Za-z0-9][\w&.' ]{1,40}?)\s+(?:will|shall|is|has|would)\b/i.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 1200)))) party = cleanParty(m[1]);
    if (!party && (m = /\b(?:issued to|in fav(?:ou)?r of)\s+([A-Za-z][^\n]{2,60})/i.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 1200)))) party = cleanParty(m[1]);
    if (!party && (m = /\btowards\s+(?!your\b|the\b)([A-Za-z][^\n]{2,60})/i.exec(doc.flat.slice(a ? a.e : doc.bodyAt, (a ? a.e : doc.bodyAt) + 160)))) party = cleanParty(m[1]);
    if (!party && (m = /\bfor\s+(?:beneficiary\s+)?([A-Za-z][^\n]{2,60})/i.exec(doc.flat.slice(a ? a.e : doc.bodyAt, (a ? a.e : doc.bodyAt) + 120)))) party = cleanParty(m[1]);
    if (!party && (m = /\byour\s+([A-Z][A-Za-z0-9&.' ]{1,30}?)\s+(?:bill|subscription|payment)\b/.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 600)))) party = cleanParty(m[1]);
    // what the debit is for, not who ("for loan account EHL0012345 will be auto-debited") names nobody: a lender's or a
    // biller's own mail is from the party itself (a bank's is from the bank, which isn't who's paid)
    if (party && (/^(?:your |the |my )?(?:loan|a\/c|account|card|policy|folio|emi|mandate|instal+ment)\b/i.test(party) || /\b(?:will|shall|would)\b/i.test(party))) party = '';
    // (who an app's AutoPay pays, never the app: "₹449 will be automatically paid to Example Broadband on 12 Oct", "Your
    // AutoPay of ₹649 to Example OTT is scheduled", "AutoPay set up successfully for Example Broadband")
    if (!party && (m = /\b(?:[Pp]aid|[Pp]ayment|[Aa]uto ?[Pp]ay|AUTOPAY|[Aa]uto-?[Dd]ebit|[Mm]andate)\b[^.\n]{0,40}?\bto\s+([A-Z][A-Za-z0-9&.' ]{1,40}?)(?=\s+(?:on|is|was|from|via|for|will|of|has)\b|[.,]|\s*$)/.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 600)))) party = cleanParty(m[1]);
    if (!party && (m = /\b(?:set ?up|registered|created|activated)\b[^.\n]{0,30}?\bfor\s+([A-Z][A-Za-z0-9&.' ]{1,40}?)(?=[ \t]*(?:\n|$)|[.,]|\s+(?:on|from)\b)/.exec(doc.subject + '\n' + doc.flat.slice(doc.bodyAt, doc.bodyAt + 400)))) party = cleanParty(m[1]);
    if (!party && !(doc.inst && /^(?:bank|card)$/.test(doc.inst.kind))) party = senderBrand(doc);
    if (party) ev.party = party;
    if (amt !== null) ev.amt = amt;
    if (fq) { var f0 = lc(fq.value); var every = /month/.test(f0) ? 'month' : /quarter/.test(f0) ? 'quarter' : /year|annual/.test(f0) ? 'year' : /week/.test(f0) ? 'week' : ''; if (every) ev.every = every; }
    // (its amount's own term, "Max amount | ₹1,500 per month")
    var perM = !ev.every && a ? /^\s*(?:\/-)?\s*(?:\/|per |a |every )\s*(month|year|week|quarter)\b/i.exec(doc.flat.slice(a.e, a.e + 20)) : null;
    if (perM) ev.every = lc(perM[1]);
    var dp = action === 'done' ? kv(doc, /execution date|^date$|transaction date|debit date|paid on/) : action === 'created' ? kv(doc, /^start date$|first (?:debit|payment|execution) date|scheduled date|debit date|^date$/) : kv(doc, /scheduled date|debit date|due date|execution date|^date$/);
    var d = dp && dp.date ? dp.date : labeledDate(doc, action === 'done' ? /(?:executed on|paid on|debited on|date)/ : /(?:on|scheduled (?:on|for)|due on|debit date|will be debited on)/);
    // (an upcoming debit's day is the one its own sentence names, "will be auto debited from your card … on 28-12-2023",
    // never the notice's own date printed above it)
    // ("… will be auto debited via Axis Bank Card No. XX9938 by 28-12-2023": by that day)
    if (action === 'upcoming' && !(dp && dp.date)) { var wd = labeledDate(doc, /\bwill be (?:auto(?:matic(?:ally)?)?[- ]?)?(?:debited|charged|paid)\b[^\n]{0,100}?\b(?:on|by)\b/); if (wd) d = wd; }
    if (d) ev.date = d;
    if (fxCur) ev.cur = fxCur;
    var via = viaFor(doc, a || null, 'out');
    if (via.last4 || via.inst) ev.via = via;
    ev.conf = amt !== null && d ? 'high' : 'medium';
    return [ev];
  }

  /* how a receipt says it was paid: a card by its digits ("Payment method - 1234", "Method card XXXX-XXXX-5555",
     "Visa •••• 1234"), or a label's word (UPI, store credit, net banking). Nothing printed: nothing known */
  function instrumentIn(doc) {
    var f = doc.flat.slice(doc.bodyAt, doc.bodyAt + 4000), m;
    if ((m = /(?:payment method|paid (?:with|using|via|by)|\bmethod)\s*[:\-|]?\s*(?:card\s*)?(?:visa|master\s?card|amex|american express|rupay|diners(?: club)?|discover)?\s*(?:credit card|debit card|card)?\s*(?:ending(?:\s+(?:in|with))?)?\s*[:\-]?\s*(?:[x*•·]{2}[x*•·\s\-]{0,38}?)?(\d{4})\b(?![\d,.])/i.exec(f))) return { kind: 'card', last4: m[1] };
    if ((m = /\b(?:visa|master\s?card|amex|american express|rupay|diners)\b[^\n]{0,12}?[x*•·]{2}[x*•·\s\-]{0,38}?(\d{4})\b/i.exec(f))) return { kind: 'card', last4: m[1] };
    // (a receipt's PAYMENT block, the card by its network and last digits beside the amount, "PAYMENT / Visa 4321 ₹1,594.96":
    // often far down a long booking mail, below its house rules)
    if ((m = /\bpayments?[ \t]*\n[ \t|]*(visa|master ?card|amex|american express|rupay|diners(?: club)?)[ \t]+(?:[x*•·]+[ \t]*)?(\d{4})\b[^\n]{0,40}?(?:₹|rs\.?|inr)\s?\d/i.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 12000)))) {
      var cp = { kind: 'card', last4: m[2] };
      if (/^diners/i.test(m[1])) cp.inst = 'Diners'; else if (/^(?:amex|american)/i.test(m[1])) cp.inst = 'Amex';
      return cp;
    }
    // (a shop's payment block, the network and the card's kind run together over the masked number: "DINERSCREDIT" /
    // "************9542")
    if ((m = /\b(visa|master ?card|amex|american express|rupay|diners(?: ?club)?)(?: ?(?:credit|debit))?(?: ?card)?[ \t|]*\n[ \t|]*[x*•·]{4,}[x*•·\s\-]{0,12}?(\d{4})\b/i.exec(f))) {
      var ci0 = { kind: 'card', last4: m[2] };
      if (/^diners/i.test(m[1])) ci0.inst = 'Diners'; else if (/^(?:amex|american)/i.test(m[1])) ci0.inst = 'Amex';
      return ci0;
    }
    // (a card named by its network and its last digits, "Card: Diners Club ending 3311": Diners and Amex are the issuer too)
    if ((m = /\b(?:card(?: name| type)?|paid (?:with|using|by))\s*[:\-|]?\s*(visa|master\s?card|amex|american express|rupay|diners(?: club)?)\s+(?:(?:credit|debit) )?(?:card )?ending(?:\s+(?:in|with))?\s*[:\-]?\s*(\d{4})\b/i.exec(f))) {
      var nw = lc(m[1]), ci = { kind: 'card', last4: m[2] };
      if (/^diners/.test(nw)) ci.inst = 'Diners'; else if (/amex|american express/.test(nw)) ci.inst = 'Amex';
      return ci;
    }
    // (a shop's "Payment details / Card number: 4XXXXXXXXXXX9542": the card, masked but for its first and last digits)
    if ((m = /\bcard (?:number|no\.?)\s*[:\-|]?\s*\d{0,6}[x*•·]{4,}[x*•·\s\-]{0,12}?(\d{4})\b/i.exec(f))) return { kind: 'card', last4: m[1] };
    // ("Paid by Cash Rs. 792", never "To be paid by cash Rs. 999 at delivery" or cash on delivery)
    if ((m = /(\b(?:to|will) be\s+)?\bpaid by cash\s*[:|]?\s*(?:rs\.?|₹|inr)\s*[1-9]/i.exec(f)) && !m[1] && !/cash on delivery|\bcod\b|pay on delivery|at (?:the )?(?:delivery|doorstep)\b/i.test(f)) return { kind: 'other' };
    // ("Payment information … You've paid ¥23,540 … •••• 6620": the card under the paying line)
    if ((m = /\bpayment information\b[^]{0,240}?\byou(?:'|’)?ve paid\b[^]{0,120}?[•x*]{3,}\s*(\d{4})\b/i.exec(f))) return { kind: 'card', last4: m[1] };
    var pm = kv(doc, /^(?:payment (?:method|mode|type|via|option)|paid (?:via|using|with|by)|mode of payment|billed to|pay(?:ment)? mode|payment instrument)$/);
    // (a label paired with a sentence is no method: "MODE OF PAYMENT" over "Credit Card", a label-like cell skipped)
    var v = pm && pm.value.length <= 40 ? lc(pm.value) : '';
    var pv = kv(doc, /^paid (?:via|using|with|by|through)\s+\S/);
    var vm = /\b(?:paid|payment)\b[^\n]{0,40}?\bvia\s+(credit\s*card|debit\s*card|creditcard|debitcard|upi|net\s*banking|netbanking|wallet)\b/i.exec(f);
    if (!v && vm) v = lc(vm[1]).replace(/creditcard/, 'credit card').replace(/debitcard/, 'debit card');
    if (!v && pv) v = pv.key.replace(/^paid (?:via|using|with|by|through)\s+/, '');
    if (!v && (m = /\b(?:billed to|payment (?:method|mode|type)|paid (?:via|using|with|through|by))\s*[:\-|]?\s*\n?\s*([^\n|]{2,40})/i.exec(f))) v = lc(m[1]);
    // ("| MODE OF PAYMENT |" with its value a cell or two below: "| Credit Card |")
    if (!v && (m = /\bmode of payment[ \t]*\|?[ \t]*\n(?:[ \t|]*\n){0,3}[ \t|]*((?:credit|debit) card|upi|net ?banking|wallet|cash on delivery|cod|card)\b/i.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 9000)))) v = lc(m[1]);
    if (!v && (m = /\bpayment ?mode\s*((?:credit|debit) ?card|upi|net ?banking|wallet|cash on delivery|cod)\b/i.exec(f))) v = lc(m[1]);
    // ("Order Number: | ORDER DATE: | Payment Information: | Shipping Method:" over its row: the cell under the label)
    for (var hi = 1; !v && hi < doc.lines.length - 1; hi++) {
      if (/\d{3,}/.test(doc.lines[hi])) continue;
      var hc = doc.lines[hi].split(' | '), hk = -1;
      for (var q = 0; hc.length >= 2 && q < hc.length; q++) if (/^(?:payment (?:information|method|mode|type|details)|mode of payment)\s*:?$/i.test(trim(hc[q]))) hk = q;
      var vc = hk >= 0 ? doc.lines[hi + 1].split(' | ') : [];
      if (vc.length === hc.length && trim(vc[hk]).length >= 2 && trim(vc[hk]).length <= 60) v = lc(trim(vc[hk]));
    }
    // (a line that is only "Payment", over the way it was paid, "Payment / Gokwik cards": only when that names a way to pay)
    if (!v && (m = /(?:^|\n)[ \t]*payment[ \t]*\n[ \t]*([^\n|]{2,40}?)[ \t]*(?=\n|$)/i.exec(f)) && /\b(?:cards?|upi|net ?banking|wallet|visa|master ?card|amex|rupay|gpay|google pay|phonepe|paytm)\b/i.test(m[1])) v = lc(m[1]);
    // ("Total Amount Paid | ₹2,201.40" then "| via card" on its own line)
    // (only when it is the one way it was paid: a bill split between a card and the app's money is neither alone)
    if (!v && (m = /^[\s|]*via\s+(card|credit card|debit card|upi|wallet|net ?banking)[\s|]*$/im.exec(f)) && (f.match(/^[\s|]*via\s+[^\n|]{2,30}[\s|]*$/gim) || []).length === 1) v = lc(m[1]);
    if (!v) return null;
    if (/cash on delivery|\bcod\b|pay on delivery|pay at (?:the )?(?:counter|hotel|property|venue)|to be paid|unpaid|pending/.test(v)) return null;
    // (an option that covers both, "UPI & Cards - Extra 5% off": paid ahead, by one of them)
    if (/\bupi\b/.test(v) && /\bcards?\b/.test(v)) return { kind: 'other' };
    // a payment mode glued to its label in a converted table ("Payment ModeCredit Card"); "Gokwik cards"
    if (/credit card|debit card|\bcards?\b|visa|master|amex|rupay/.test(v) && !/gift cards?/.test(v)) { var mm = /(\d{4})\b/.exec(v); return mm ? { kind: 'card', last4: mm[1] } : { kind: 'card' }; }
    // cash: paid when the mail says it was (a ride's receipt, "Paid by Cash", cash collected), else still to pay
    if (/^\s*(?:by |in )?cash\b(?!\s*back)|paid (?:by|in) cash/.test(v) && !/wallet|balance|money/.test(v))
      return /paid (?:by|in|with|using)\s*[:|]?\s*cash|cash (?:paid|collected)|(?:has been|was) delivered|thanks for (?:riding|travel+ing)|ride (?:receipt|completed|id)|trip (?:receipt|completed)|time of ride/.test(lc(f) + ' ' + doc.head + ' ' + (pv ? pv.key : '')) || (/\binvoice\b|\breceipt\b/.test(lc(doc.subject)) && !/shipped|dispatched|on (?:its|the) way|will be delivered|out for delivery|to be delivered|arriving/.test(lc(f) + ' ' + doc.head)) ? { kind: 'other' } : null;
    if (/store credit|balance|wallet|credits?\b|\bmoney\b|\bcash\b|gift card/.test(v)) return { kind: 'wallet' };
    // (an app named as the method, "Payment Method | Paytm": paid through it, from where it doesn't say)
    if ((m = /^\s*(paytm|mobikwik|freecharge|amazon pay|airtel money|jio ?money|ola money)\s*$/.exec(v))) return { kind: 'other', inst: capWords(m[1]) };
    // (a restaurant's own receipt for an order paid through a delivery app, "Paid via Swiggy Prepaid ₹330": the app
    // charged you, rule 5)
    if ((m = /^\s*(swiggy|zomato|magicpin|eazydiner)\s+prepaid\b/.exec(v))) return { kind: 'other', inst: capWords(m[1]), app: true };
    if (/\bupi\b|gpay|google pay|phonepe|bhim/.test(v)) return { kind: 'upi' };
    if (/net ?banking|bank transfer|neft|imps/.test(v)) return { kind: 'account' };
    // (bought on a pay-later line, "Payment method: Amazon Pay Later": charged to it, as to a card)
    if (/pay ?later|\bsimpl\b|\blazypay\b/.test(v) && !/\bemi\b/.test(v)) return { kind: 'other', inst: capWords(trim(v.replace(/\(.*$/, ''))) };
    // (a method the mail names, on an order it says is complete: paid, by whatever it was)
    if (pm && !/\bemi\b|cheque|\bcheck\b|\binvoice\b|pay ?later|\bpostpaid\b|\bdd\b|demand draft|^\s*(?:credit|free|n\/?a|none|nil|-+)\s*$/.test(v) && /order is (?:now )?complete|finished processing your order|order (?:has been )?completed/.test(lc(doc.subject) + ' ' + lc(f.slice(0, 600)))) return { kind: 'other' };
    return null;
  }
  // paid with reward vouchers or points, not money (rule 9): "Payment Type : evocherredemption_standard", a rewards
  // catalogue's "your recent order of e-voucher is completed … Points | 2"
  function rewardsRedemption(doc) {
    var l = doc.low.slice(doc.bodyAt, doc.bodyAt + 3000);
    return /\bpayment (?:type|mode|method)\s*[:|\-]?\s*e?-?vou?cher[\s_-]*redemption/.test(l) ||
      (/\brewards?\b/.test(lc(doc.subject)) && /\border of e-?vouchers?\b|\breward experience\b|(?:^|\n)\s*points\s*\|/.test(l));
  }
  // "PAYMENT / RAZORPAY ₹10,132.01": who took the money, when the receipt names only that
  function payBlockIn(doc) {
    var m = /\bpayment\s*\n\s*([A-Za-z][A-Za-z .]{2,30}?)\s+(?:₹|rs\.?|inr)\s*\d/i.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 4000));
    return m ? trim(m[1]) : '';
  }
  // a shop's own balance, as the mail names it ("Apple ID", "Zomato Credits", "Swiggy Money")
  function decodeURIComponentSafe(x) { try { return decodeURIComponent(x); } catch (e) { return x.replace(/%20/g, ' '); } }
  var WALLET_NAMED = /\b((?:apple|google|amazon|zomato|swiggy|ola|paytm|freecharge|mobikwik|phonepe|airtel|jio|tata neu|cred|cliq|myntra|flipkart|makemytrip|goibibo|yatra|ixigo)\s+(?:id|account|balance|wallet|mywallet|credits|money|cash|pay(?: balance)?|play balance|supercoins))\b/i;
  function walletName(doc) {
    var m = WALLET_NAMED.exec(doc.flat.slice(0, 4000));
    return m ? capWords(lc(m[1])).replace(/\bId\b/, 'ID') : senderBrand(doc);
  }
  /* a receipt or invoice from whoever was paid (an app store, a payment gateway, a SaaS, a bill-pay app): money out
     on the instrument it prints, or into the shop's own balance when it was money added. A receipt that doesn't say
     how it was paid is a record of a purchase, not a movement (the bank's alert is that) */
  function receipts(doc, ctx) {
    if (doc.inst && /^(?:bank|card|broker|rta|insurer)$/.test(doc.inst.kind)) return [];
    // (paid with reward vouchers or points, not money: rule 9)
    if (rewardsRedemption(doc)) return [];
    var head = doc.head, s = lc(doc.subject), m;
    var payBlock = /\bpayments?\s*\n\s*(?:paytm|upi|gpay|google pay|phonepe|amazon pay|visa|master ?card|rupay|amex|card|cash|wallet|apple pay|net ?banking)[^\n]{0,40}(?:₹|rs\.?|inr)\s?\d/i.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 3000));
    // ("Thank you for making the payment of ₹ 5,815": paid now; never "thank you for your payment … last month" in an offer)
    var THANK_PAID = /\bthank you for making (?:the |your |a )?payment of\s*(?:₹|rs\.?|inr)\s*(\d[\d,]*(?:\.\d+)?)(?![^.\n]{0,40}\b(?:last|previous|earlier)\b)/i;
    var thankPaid = THANK_PAID.test(doc.flat.slice(doc.bodyAt, doc.bodyAt + 4000));
    if (!instrumentIn(doc) && !payBlock && !thankPaid && !ctx.prepaidShip && !/cash collected|paid online|\breceipt\b|\binvoice\b|payment (?:successful|confirmation|confirmed|received|complete)|paid successfully|amount paid|you paid|total paid|billed to|has been charged|charged to your|recharge (?:is )?successful|bill payment (?:is |was )?successful|\bpaid\s+9|\bpaid (?:via|using|with|through)\b|9\s+paid\b|\b(?:order|payment|transaction|recharge)\b[^\n]{0,80}\b(?:is|was|has been) successful|you have successfully (?:made|paid|completed)|payment successful/.test(head)) return [];
    // (a receipt's "your next payment ... is due on" is the next charge, not this one unpaid)
    if (/\b(?:amount due|payable by|pay (?:now|by|before)|due date|due on)\b/.test(head.replace(/\bnext (?:payment|charge|bill(?:ing)?)(?:[^.\n]|\.\d){0,80}/g, '')) && !/\bpaid\b/.test(head)) return [];
    if (ctx.failed || ctx.future) return [];
    // a payment still to make ("Payment status: Pending", "awaiting payment", "please complete payment")
    var paidLabel = doc.pairs.some(function (p0) { return /^(?:amount paid|total paid|you paid|paid amount|paid online|paid)$/.test(p0.key) && p0.amt > 0; }) || /\b(?:total paid|amount paid|you paid)\b[^\n]{0,20}?(?:₹|rs\.?|inr)\s?[1-9]|\bpaid (?:via|with|using|by)\b(?![^\n]{0,25}\?)|^\s*(?:payment )?status\s*[:|]\s*(?:paid|successful|success|completed)\b/m.test(doc.low.slice(doc.bodyAt, doc.bodyAt + 1500));
    var payLabels = doc.pairs.filter(function (p0) { return /payment (?:status|method|mode)|mode of payment|^status$/.test(p0.key); }).map(function (p0) { return lc(p0.value); }).join(' ');
    // (a pay-later product named as the method, "Amazon Pay Later", is a credit line it was charged to, not "pay later")
    if (!paidLabel && /pending|failed|declined|unpaid|awaiting|pay later|pay at (?:the )?(?:hotel|property|check-?in|counter)|pay after delivery/.test((payLabels + ' ' + doc.low.slice(doc.bodyAt, doc.bodyAt + 300)).replace(/\b[a-z]+(?: pay)? pay ?later\b/g, ' credit line '))) return [];
    if (/payment status\s*[:|]?\s*(?:pending|failed|declined|unpaid|awaiting)|complete (?:the |your )?payment within/.test(doc.low.slice(doc.bodyAt, doc.bodyAt + 3000))) return [];
    // (with nothing paid printed, a mail that asks for the payment anywhere: "awaiting payment", "please complete your payment")
    if (!paidLabel && /awaiting payment|\bcomplete (?:the |your )?payment\b(?!\s+(?:profile|details|methods?|options?))|\bpayment (?:is )?pending\b|pending at your bank/.test(doc.low.slice(doc.bodyAt, doc.bodyAt + 3000).split('\n').filter(function (ln) { return !/\?|\bif\b|^\s*(?:faq|tip)\b/.test(ln); }).join('\n'))) return [];
    // (what was paid first: "Total Amount Paid ₹2,201.40" over the "Bill amount ₹2,400" before discounts)
    var tpRe = /(?:\s*\((?:inr|rs\.?|₹|incl\.? (?:of )?(?:gst|taxes?)|inclusive of (?:gst|taxes?))\))?$/.source;
    // (a bill split between ways to pay, "Paid via Swiggy Money ₹100 / Paid via Card ₹320": all of them, never one part or a ₹0 one)
    // (each way once: the summary line and the table's row are one payment; a coupon, points or cashback is no money paid)
    var pvSeen = {}, pvRows = kvAll(doc, new RegExp('^paid via [a-z ]{2,30}' + tpRe)).map(function (p0) {
      if (/cashback|earned|saved|discount|coupon|voucher|reward|points|coins/.test(p0.key)) return null;
      var a0 = p0.toks ? p0.toks.filter(function (t) { return t.t === 'AMT'; })[0] : null;
      if (!a0 || !(a0.v > 0) || pvSeen[p0.key.replace(/\s+/g, ' ') + '|' + a0.v]) return null;
      pvSeen[p0.key.replace(/\s+/g, ' ') + '|' + a0.v] = 1; return a0;
    }).filter(Boolean);
    // (points and cash, "Paid by Points Rs. 4,000 / Paid by Cash Rs. 792": the money is the cash)
    var cashRow = kvAll(doc, /^paid by (?:points|reward points|rewards|coins|supercoins|vouchers?|gift ?card)$/).length ? kv(doc, /^paid by (?:cash|card|upi)$/) : null;
    // (what was paid after the shop's credit and the bank's cashback came off, "Total Amount 5928.00 … Bank CashBack
    // - 592.00 … Net Paid 5336.00": the card was charged the net, and that is what the bank's alert says)
    var tp = (cashRow && (cashRow.toks || []).some(function (t) { return t.t === 'AMT' && t.v > 0; }) ? cashRow : null) || kv(doc, new RegExp('^(?:net paid|net amount paid|final amount paid)' + tpRe)) ||
      kv(doc, new RegExp('^(?:total amount paid|amount paid|total paid|you paid|net amount paid|paid amount|total charged|amount charged)' + tpRe)) ||
      (pvRows.length ? null : kv(doc, new RegExp('^(?:total|grand total|total amount|order total|order amount|bill amount|recharge amount|total fare|total price|total cost|total (?:including|incl\\.?|inclusive of) (?:gst|taxes|tax|all taxes))' + tpRe)));
    var tt = tp && tp.toks ? tp.toks.filter(function (t) { return t.t === 'AMT'; })[0] : null;
    if (!tt && pvRows.length) tt = pvRows.length === 1 ? pvRows[0] : Object.assign({}, pvRows[0], { v: Math.round(pvRows.reduce(function (a0, t) { return a0 + t.v; }, 0) * 100) / 100, raw: '' });
    var tot = tt ? tt.v : null, fxCur = '';
    // (a total in another currency with its rupees beside it, "Total: ¥86.00 (approx ₹1,032)": the rupees; alone, its own currency)
    if (tt && tt.cur && tt.cur !== 'INR') { var inr0 = fxWorth(doc.flat, (tp && tp.toks) || []); if (inr0) { tt = inr0; tot = inr0.v; } else fxCur = tt.cur; }
    if (tot === null) {
      // what was paid first, then a total; never an item's or a sub-total ("Item total ₹449 … Total paid ₹487.40")
      var bestR = 9;
      amts(doc).forEach(function (t) {
        var pre = doc.nlow.slice(Math.max(0, t.s - 40), t.s), post = doc.nlow.slice(t.e, t.e + 20);
        if (/(?:item|sub)[\s-]*total[\s:\-|]*$/.test(pre)) return;
        // (never a fee whose next line is the payment's own: "Delivery fee ₹40 / Paid Via UPI ₹420")
        // (…or a "Paid" row of its own: "Delivery & platform fee | ₹39 / Paid | ₹680 via UPI")
        var nextPaid = /^[ \t|]*\n\s*paid(?: (?:via|using|with|through|by)\b[^\n\d₹]{0,40}?|\s*[|:]\s*)(?:₹|rs\.?|inr)\s*(\d[\d,]*(?:\.\d+)?)/.exec(doc.low.slice(t.e, t.e + 80));
        var r0 = /(?:total paid|amount paid|you paid|amount charged|total charged|cash collected|paid online)(?:\s*\((?:inr|rs\.?|₹)\))?[\s:\-|]*$/.test(pre) || (/^\s*(?:paid|was paid|has been paid|charged)\b/.test(post) && !(nextPaid && Math.abs(num(nextPaid[1]) - t.v) > 0.011)) ? 1
          : roleOf(doc, t) === 'orderTotal' || /(?:\btotal(?: amount| charged| price| cost)?(?:\s*\((?:inr|rs\.?|₹)\))?|receipt from [^\n]{2,40}|\bpaid(?: (?:via|using|with|through) [^\n|]{1,30})?|(?:recharge|bill payment|payment) of)[\s:\-|]*$/.test(pre) ? 2 : 9;
        if (r0 < bestR) { bestR = r0; tot = t.v; tt = t; }
      });
    }
    // a bill paid through an app, its one figure beside the biller ("00001234 EXAMPLE WATER | ₹2750" under "Bill Payment
    // Successful!"): one amount in the mail, said successful
    if (tot === null && /\b(?:bill payment|recharge|payment) (?:is |was |has been )?successful\b|you have successfully (?:made|paid)/.test(doc.nlow.slice(0, 3000))) {
      var only = amts(doc).filter(function (t) { return inBody(doc, t) && roleOf(doc, t) !== 'fee' && roleOf(doc, t) !== 'offer' && roleOf(doc, t) !== 'bal'; });
      if (only.length && uniq(only.map(function (t) { return t.v; })).length === 1) { tt = only[0]; tot = tt.v; }
    }
    var cur = fxCur;
    if (tot === null && !amts(doc).length) {
      // a receipt in another currency ("Total $6.00"): kept as charged, in its currency
      doc.toks.forEach(function (t) { if (tot === null && t.t === 'AMT' && t.cur && t.cur !== 'INR' && /\btotal|amount|charge/.test(doc.nlow.slice(Math.max(0, t.s - 30), t.s))) { tot = t.v; tt = t; cur = t.cur; } });
    }
    if (tot === null || !(tot > 0)) return [];
    var ins = instrumentIn(doc);
    // said outright that you were charged: a movement even if the method isn't printed
    if (!ins) { var pb = payBlockIn(doc); if (pb) ins = /visa|master|amex|rupay|card/i.test(pb) ? { kind: 'card' } : /upi/i.test(pb) ? { kind: 'upi' } : { kind: 'other', inst: pb }; }
    if (!ins && payBlock) ins = /visa|master|amex|rupay|card/i.test(payBlock[0]) ? { kind: 'card' } : /upi|paytm|gpay|google pay|phonepe/i.test(payBlock[0]) ? { kind: 'upi' } : /cash/i.test(payBlock[0]) ? { kind: 'other' } : { kind: 'other' };
    // a label that says this figure was paid ("Amount Paid | ₹206.20 (UPI)", "Paid online | ₹1,098", "Cash collected: ₹642")
    if (!ins) { var paidP = doc.pairs.filter(function (p0) { return /^(?:amount paid|total paid|you paid|paid online|paid|cash collected|amount collected|payment made)$/.test(p0.key) && p0.amt > 0 && Math.abs(p0.amt - tot) < 0.011; })[0];
      if (paidP) ins = /\bupi\b/i.test(paidP.value) ? { kind: 'upi' } : /card/i.test(paidP.value) ? { kind: 'card' } : { kind: 'other' }; }
    if (!ins && ctx.prepaidShip) ins = { kind: 'other' };
    if (!ins && /receipt for your charges|charge date|you(?:'ve| have| were) (?:been )?charged|has been charged|charged to your/.test(doc.nlow.slice(0, 3000))) ins = { kind: 'other' };
    // ("Thank you for making the payment of ₹ 5,815": that figure, paid)
    if (!ins && (m = THANK_PAID.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 4000))) && Math.abs(num(m[1]) - tot) < 0.011) ins = { kind: 'other' };
    // how it was paid, as a label ("Payment method | UPI AutoPay", "Payment Mode: Cash on Delivery"): cash on delivery is
    // paid only once the mail says it was delivered or collected
    if (!ins) {
      var pmK = kv(doc, /^(?:payment method|payment mode|mode of payment|paid (?:by|with|using|via|from)|billed to|payment)$/);
      if (pmK) {
        var pv = lc(pmK.value);
        if (/cash on delivery|\bcod\b|pay (?:on|after) delivery|pay at (?:the )?(?:counter|hotel|property|venue|check-?in)|pay later|to be paid|unpaid|pending|awaiting|^\s*cash\s*$/.test(pv)) { if (/cash collected|(?:has been|was) delivered|delivered successfully/.test(head)) ins = { kind: 'other' }; }
        else ins = /card|visa|master|amex|rupay/.test(pv) ? { kind: 'card' } : /upi/.test(pv) ? { kind: 'upi' } : /wallet|balance/.test(pv) ? { kind: 'wallet' } : { kind: 'other' };
      }
    }
    // the figure's own words say it was paid: "Amount Paid ₹5,555", "Total paid - ₹210.50", "Paid ₹480", "recharge of
    // Rs. 299.00 is successful", a bill-pay receipt whose status is Success (cash on delivery says "to pay" instead)
    if (!ins && tt) {
      var pre0 = doc.nlow.slice(Math.max(0, tt.s - 50), tt.s), post0 = doc.nlow.slice(tt.e, tt.e + 40);
      var key0 = tt.pair ? lc(tt.pair.key) : '';
      if (/^(?:amount paid|total paid|you paid|paid amount|net amount paid|amount charged|total amount paid)$/.test(key0) ||
          /(?:amount paid|total paid|you paid|paid amount|net amount paid|amount charged|\bpaid|(?:recharge|payment|bill payment) of)[\s:\-|]*$/.test(pre0) ||
          /^\s*(?:\.0+)?\s*(?:is|was|has been)\s+(?:successful|completed|paid|received)\b/.test(post0) ||
          (/\b(?:bill payment|payment|recharge) successful\b|\bstatus\s*\|?\s*success(?:ful)?\b/.test(doc.nlow.slice(0, 3000)) && !/\b(?:to pay|payable|pay on delivery|cash on delivery|\bcod\b|amount due)\b/.test(doc.nlow.slice(0, 3000)))) ins = { kind: 'other' };
    }
    // an order paid partly from a wallet's balance and partly another way ("Paid by American Express: ₹1,578.10 / Paid by
    // Amazon Pay balance: ₹381.90"): a movement for each part, each on what paid it (rule 27)
    // (Amazon's "Paid by" rows; a bill's "Paid via" rows stay one payment of their sum, as pvRows reads them)
    var spSeen = {}, split = kvAll(doc, /^paid by [a-z][a-z .]{1,40}$/).filter(function (p0) {
      if (!(p0.amt > 0) || p0.amtCur || /cashback|earned|saved|discount|coupon|voucher|reward|points|coins|gift ?card/.test(p0.key) || spSeen[p0.key + '|' + p0.amt]) return false;
      spSeen[p0.key + '|' + p0.amt] = 1; return true;
    });
    var walletRow = function (k) { return /\b(?:balance|wallet)\b|\b(?:pay|money|cash|credits)$/.test(k.replace(/^paid \w+ /, '')) && !/\b(?:card|upi|net ?banking|cash on delivery)\b/.test(k); };
    if (!(split.length >= 2 && split.some(function (p0) { return walletRow(p0.key); }) && split.some(function (p0) { return !walletRow(p0.key); }))) split = null;
    if (!ins && split) ins = { kind: 'other' };
    if (!ins) return [];
    var topup = /add(?:ed)? funds|add money|top ?-?up|money added|added to (?:your )?[\w ]{0,20}(?:balance|wallet)/.test(doc.nlow.slice(0, 3000));
    var via;
    if (topup || ins.kind === 'wallet') via = { kind: 'wallet', inst: walletName(doc) };
    else {
      via = { kind: ins.kind };
      if (ins.last4) via.last4 = ins.last4;
      if (ins.inst) via.inst = ins.inst;
      var who = !ins.inst && E.issuerIn ? E.issuerIn(doc.flat.slice(doc.bodyAt, doc.bodyAt + 3000), ins.kind === 'card') : null;
      if (who) via.inst = who.short;
    }
    var ev = { type: 'move', dir: topup ? 'in' : 'out', amt: tot };
    if (cur) ev.cur = cur;
    var dp = kv(doc, /^(?:paid on|payment date|date of payment|transaction date|invoice date|date|order date|receipt date|booking date(?: & time)?)$/);
    var d = dp && dp.date ? dp.date : '';
    if (!d && tt) { var n1 = near(doc, 'DATE', tt.e, 0, 60, function (x) { return !x.rel; }); if (n1 && /^\s*(?:paid|on|dated)?\s*$/i.test(doc.flat.slice(tt.e, n1.s).replace(/paid/i, ''))) d = n1.v; }
    // (an order's own cell, "Order No. 412|27-09-2026|20:41:05": its day and time)
    var ocell = !d ? /\border\s*(?:no\.?|id|number)\s*[:#]?\s*[A-Z0-9\-]{2,30}\s*\|\s*((?:\d{1,2}[-\/ ](?:\d{1,2}|[a-z]{3,9})[-\/ ,]+\d{2,4}|\d{4}-\d{2}-\d{2}|[a-z]{3,9} \d{1,2},? \d{4}))\s*\|\s*(\d{1,2}:\d{2})/i.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 1500)) : null;
    if (ocell) { var od0 = doc.toks.filter(function (t) { return t.t === 'DATE' && doc.flat.slice(t.s, t.e) === ocell[1]; })[0]; if (od0) { d = od0.v; ev.time = (ocell[2].length === 4 ? '0' : '') + ocell[2]; } }
    ev.date = d || doc.ref;
    // its time, printed beside its day at the top ("Sat, 03 October, 8:53 PM")
    if (!ev.time) { var tdt = doc.toks.filter(function (x) { return x.t === 'DATE' && inBody(doc, x) && x.s < doc.bodyAt + 400 && !x.rel; })[0]; var ttm = tdt ? doc.toks.filter(function (x) { return x.t === 'TIME' && x.s > tdt.e && x.s - tdt.e < 6; })[0] : null; if (!tdt) ttm = doc.toks.filter(function (x) { return x.t === 'TIME' && inBody(doc, x) && x.s < doc.bodyAt + 250 && /\b(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*,?\s*$/i.test(doc.flat.slice(Math.max(0, x.s - 14), x.s)); })[0]; if (ttm && (!d || !tdt || d === tdt.v)) ev.time = ttm.v; }
    var tm = dp ? near(doc, 'TIME', dp.s, 0, 80) : null;
    if (tm) ev.time = tm.v;
    ev.via = via;
    // who was paid: a gateway's merchant ("Payment successful for Example Academy"), the receipt's issuer, the sender
    var party = '';
    if ((doc.inst && doc.inst.kind === 'gateway') || /razorpay|payu|cashfree|ccavenue|instamojo|stripe|easebuzz|juspay/.test(doc.domain)) {
      if ((m = /\b(?:at|on|to|for|with)\s+([A-Za-z0-9][^\n|]{1,60}?)\s+(?:on\s+\S+\s+)?(?:is|was|has been)\s+successful/i.exec(doc.subject))) party = cleanParty(m[1]);
      if (!party && (m = /\b(?:for|to)\s+([A-Za-z0-9][^\n|]{1,60})$/i.exec(doc.subject))) party = cleanParty(m[1]);
      if (!party && (m = /\b(?:your )?payment to\s+([A-Z][^\n|]{1,60}?)\s+(?:was|is|has been)\s+successful/.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 800)))) party = cleanParty(m[1]);
      // (never a thanks that names no one: "Thank you for your purchase!", "We have received your order:")
      var gwThanks = /^(?:thank(?:s| you) for (?:your )?(?:purchase|order|shopping)|we have received your order)\W*$/i;
      if (!party) { var hl0 = doc.lines.slice(1, 5).map(trim).filter(function (x) { return x && !/^(?:payment receipt|receipt|payment successful|dear|hello|hi|hey)\b/i.test(x) && !gwThanks.test(x) && !/\d{3,}|₹/.test(x); })[0]; party = cleanParty(hl0 || (gwThanks.test(trim(doc.lines[1] || '')) ? '' : doc.lines[1] || '')); }
    }
    if (!party && ins.app && ins.inst) party = ins.inst;
    if (!party && (m = /\breceipt from\s+([A-Za-z0-9][^\n#|₹]{1,60}?)(?:\s+(?:₹|rs\.?|inr|#)|\s*$|\s*\()/i.exec(doc.flat.slice(0, 600)))) party = cleanParty(m[1]);
    if (!party && (m = /\bi just supported\s+([A-Za-z][^\n]{1,40}?)\s+on\b/i.exec(decodeURIComponentSafe(doc.flat.slice(doc.bodyAt, doc.bodyAt + 1500))))) party = cleanParty(m[1]);
    if (!party) { var tw = kv(doc, /^(?:payment (?:received |made )?|paid )?towards$|^biller(?: name)?$|^operator(?: name)?$/); if (tw) party = cleanParty(tw.value); }
    if (!party && !topup) party = senderBrand(doc);
    if (party && !topup) ev.party = party;
    // (a biller labels its reference with no noun after it, "Transaction Ref: IHM2610060112", the way refFor's own key
    //  list already allows; a store names it "Order number"; and an app store's id carries dots, "GPA.3344-5566-7788")
    var rp = kv(doc, /^(?:receipt (?:number|no\.?|#|id)|payment id|transaction id|order (?:id|number|no\.?)|invoice (?:number|no\.?)|txn id|(?:transaction |txn |payment )?ref(?:erence)?(?: (?:no\.?|number|id))?)$/);
    if (!rp && (m = /\btransaction id\s*[:#\-]?\s*([A-Za-z0-9][A-Za-z0-9_\-]{5,40})/i.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 1500))) && /\d/.test(m[1])) rp = { value: m[1] };
    var ref = rp ? (/[A-Za-z0-9][A-Za-z0-9_.\-]{3,39}[A-Za-z0-9]/.exec(rp.value) || [''])[0] : '';
    if (!ref && (m = /\b(?:receipt|payment id|order (?:id|number|no\.?)|transaction id)\s*(?:number|no\.?|#|id)?\s*[:#\-]?\s*([A-Za-z0-9][A-Za-z0-9_.\-]{4,39}[A-Za-z0-9])/i.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 3000))) && /\d/.test(m[1])) ref = m[1];
    if (ref) ev.ref = ref;
    if (via.kind === 'upi' || ins.kind === 'upi') ev.mode = 'UPI'; else if (via.kind === 'wallet') ev.mode = 'WALLET';
    // (a bill paid, rule 2: the biller's own receipt, a utility or recharge, a pay-later bill repaid "towards your Simpl bill")
    ev.purpose = topup ? 'topup' : (billerSender(doc) || /bill payment|electricity|water|gas\b|broadband|postpaid|recharge|fastag/.test(s) ||
      /\b(?:towards|for) (?:your )?[\w ]{0,30}?\b(?:bill|dues)\b|\bpay ?later\b[^.\n]{0,40}\b(?:payment|repayment|repaid)\b/.test(doc.head)) ? 'billpay' : 'purchase';
    ev.ev = { amt: tt ? tt.raw : '' };
    ev.conf = 'medium';
    if (split && !topup) return split.map(function (p0) {
      var how = p0.label.replace(/^\s*paid \w+\s+/i, '').replace(/[\s:]+$/, ''), sv;
      if (walletRow(p0.key)) sv = { kind: 'wallet', inst: capWords(lc(how)) };
      else if (/\bupi\b/i.test(how)) sv = { kind: 'upi' };
      else {
        var iss = E.issuerIn ? E.issuerIn(how, true) : null;
        sv = /card|visa|master|amex|american express|rupay|diners/i.test(how) || (iss && iss.kind === 'card') ? { kind: 'card' } : { kind: 'other' };
        if (iss) sv.inst = iss.short;
      }
      var pe = Object.assign({}, ev, { amt: p0.amt, via: sv, ev: { amt: ((p0.toks || []).filter(function (t) { return t.t === 'AMT'; })[0] || {}).raw || '' } });
      if (sv.kind === 'wallet') pe.mode = 'WALLET'; else if (sv.kind === 'upi') pe.mode = 'UPI'; else delete pe.mode;
      return pe;
    });
    return [ev];
  }

  /* a subscription (an app, streaming, a SaaS plan): started, renewing soon, cancelled. The charges come as
     receipts or card alerts; this is the promise of the next one */
  // a trial of yours ending ("Your free trial ends on 24 Oct", "your Notes Pro trial is ending", "when your trial ends",
  // "your trial now ends on 31 Oct")
  var TRIAL_END = /\byour (?:[\w+'’.-]+ ){0,4}trial (?:now )?(?:ends|is ending|will end|expires|is expiring|is about to end|period (?:ends|is ending|will end))\b|\b(?:when|once|after) your (?:free )?trial (?:ends|is over|expires)\b/;
  // ...and turns into a charge by itself (a trial that just ends, "upgrade to keep listening", "renew your plan", charges nothing)
  var TRIAL_CHARGE = /\b(?:will|you'll|you’ll|you will|we'll|we’ll|we will|it will|it'll|it’ll) (?:be )?(?:charge|charged|bill|billed|debit|debited|renew|auto-?renew)\b|\bauto-?renews?\b|\bauto-?renewal\b|\brenews\b|\bautomatically\b|\bconverts? (?:to|into)\b|\bturns? into\b|\bbecomes? a paid\b|\bunless you cancel\b/;
  // what a sentence says won't happen ("No auto-renewal and no charges", "It will not renew automatically", "we won't
  // charge you"), taken out (to the next comma or stop) before looking for a charge
  function unsaid(t) { return String(t || '').replace(/\b(?:no|not|never|won['’]t|will not|doesn['’]t|does not|without)\b[^.,;\n]{0,40}/g, ' ¦ '); }
  // a renewal reminder's own words ("will renew", "renews automatically", "next charge")
  var RENEWAL = /will (?:auto(?:matically)?[- ]?)?renew|renews? (?:soon|automatically)|automatically renews|renewal (?:reminder|notice)|subscription renewal|upcoming (?:renewal|charge|payment)|next (?:charge|billing date|payment)/;
  // an offer to start one ("Start your free trial today", "claim your 1-month free trial", "try it free")
  var TRIAL_OFFER = /\b(?:start|claim|activate|unlock|grab|get|begin) (?:your |a |an )?(?:(?:\d+|one|seven|fourteen|thirty)[- ](?:day|week|month)s? )?(?:free )?trial\b|\btry\b[^.\n]{0,30}\bfree\b/;
  // a plan's tier or term, never the name of who charges for it ("Premium", "Standard", "Family", "Annual")
  var PLAN_TIER = /^(?:(?:premium|plus|pro|basic|standard|family|individual|student|duo|mini|gold|silver|platinum|monthly|annual|yearly|quarterly|free|lite|max|super|ultra|mobile|personal|team|business|starter|essential|advanced|ultimate|deluxe|vip|prime|new|current|existing|the)\s*)+$/i;
  // a trial of yours that has begun ("Your 7-day free trial of Example Pro has started", "your trial is now active")
  var TRIAL_START = /\btrial(?: (?:of|for) [^.\n]{1,40}?)? (?:has (?:now )?(?:started|begun)|is (?:now )?(?:active|live)|starts (?:today|now))\b/;
  function subscriptions(doc, ctx) {
    if (doc.inst && /^(?:bank|card|broker|rta|insurer)$/.test(doc.inst.kind)) return [];
    var s = lc(doc.subject), t = s + '\n' + doc.lead, m;
    var renewsOn = /\brenews\s+(?:on\s+)?0{2,}/.test(doc.nlow.slice(doc.bodyAt, doc.bodyAt + 3000));
    var nextPay = /next (?:payment|charge|bill(?:ing)?)\s+(?:will be\s+)?(?:automatically\s+)?(?:deducted|charged|debited|collected|billed)?\s*(?:on|is on)\s+0{2,}|next (?:payment|charge) (?:date|is)\b/.test(doc.nlow.slice(doc.bodyAt, doc.bodyAt + 3000));
    // a subscription's receipt (rule 6): charged now, and it renews. "Premium", an auto-renewing plan, a price per month
    // (an insurance premium is no subscription; a store's footer about subscriptions is not this receipt)
    var top = s + ' ' + doc.nlow.slice(doc.bodyAt, doc.bodyAt + 900);
    var recurring = !/\bpolicy\b|insurance|insurer|pay (?:your )?premium|premium (?:due|amount|payment) (?:for|of|towards)|premium (?:economy|room|suite|seat|class|lounge)|lifetime|one-?time|bill payment|towards (?:your )?[\w ]{0,20}(?:credit )?card|added to (?:your )?[\w ]{0,20}wallet|top-?up|\bbooking\b|e-?ticket|\bpnr\b|\bbroadband\b|\bpostpaid\b/.test(top) &&
      (/subscription|membership|\brenew/.test(s) || /\b(?:premium|plus|pro) (?:mini|individual|family|duo|student|plan|membership|subscription)\b|auto-?renew|\brenews (?:on )?(?:\d|[a-z]{3,9} \d)|\/\s?(?:month|mo|year|yr)\b|\((?:monthly|yearly|annual)\)|\b(?:monthly|yearly|annual) (?:plan|subscription|membership)\b/.test(top) ||
       // a plan billed for a period ("Sep 29–Oct 29, 2026 Max plan", "Plan · 1 Oct – 31 Oct")
       /\b(?:[a-z]{3,9} )?\d{1,2}\s?[–-]\s?(?:[a-z]{3,9} )?\d{1,2},? (?:\d{4} )?[^\n]{0,40}\bplan\b|\bplan\b[^\n]{0,40}\b\d{1,2} [a-z]{3,9}\s?[–-]\s?\d{1,2} [a-z]{3,9}\b/.test(s + ' ' + doc.low.slice(doc.bodyAt, doc.bodyAt + 1800)));
    // (a membership bought for a period its invoice prints, "Activation Date 02-Dec-2019 / Expiry Date 01-Jan-2020", that
    // says nothing of renewing, is a purchase of that period: nothing will charge again by itself)
    if (recurring && kv(doc, /^(?:activation|start|commencement) date$/) && kv(doc, /^(?:expiry|end|valid till|valid upto) date$|^(?:expiry|valid till|valid upto)$/) && !/auto-?renew|\brenews?\b|\brenewal\b|next (?:payment|charge|bill)|recurring|auto-?debit|autopay/.test(s + ' ' + doc.low.slice(doc.bodyAt, doc.bodyAt + 2500))) recurring = false;
    var charged = /\breceipt\b|\binvoice\b|order receipt|you(?:'ve| have) made a purchase|thanks? (?:you )?for (?:your )?(?:purchase|payment)|has been charged|you were charged|payment (?:was |is )?successful|\bbilled to\b|\bamount (?:paid|charged)\s*[:|]?\s*(?:₹|rs\.?|inr|9)/.test(s + ' ' + doc.lead.slice(0, 600)) &&
      !/will (?:be )?(?:auto-?)?(?:renew|charged|debited)|renews soon|upcoming|reminder|failed|unsuccessful|declined/.test(s) &&
      !/will be (?:auto-?)?(?:debited|charged|deducted)|we will charge|\bamount due\b|\bdue on\b|awaiting payment|payment (?:is )?pending/.test(doc.low.slice(doc.bodyAt, doc.bodyAt + 2000).replace(/\bnext (?:payment|charge|bill(?:ing)?)(?:[^.\n]|\.\d){0,80}/g, ''));
    // (a trial of yours ending is a charge coming, whatever the mail calls it: "Your Notes Pro trial is ending on 20 Oct";
    // an offer to start one is not)
    var trialEnd = !ctx.promo && TRIAL_END.test(t) && TRIAL_CHARGE.test(unsaid(t)) && !TRIAL_OFFER.test(t);
    // (a trial begun that turns into a charge by itself, "You'll be charged ₹399/month starting Oct 16": that mandate set
    // up, from its first charge: rule 12)
    var trialStart = !ctx.promo && !charged && TRIAL_START.test(t) && TRIAL_CHARGE.test(unsaid(t)) && !TRIAL_OFFER.test(t);
    if (!/subscription|membership|renew/.test(t) && !renewsOn && !nextPay && !(charged && recurring) && !trialEnd && !trialStart) return [];
    var first = s + ' ' + lc(doc.flat.slice(doc.bodyAt, doc.bodyAt + 1200)).replace(/[\s|]+/g, ' ').slice(0, 500);
    var failedSub = !charged && /was not renewed|billing problem|problem with your (?:current )?payment method|couldn(?:'|’)?t (?:renew|charge)|unable to (?:renew|charge)|\bpayment\b[^.\n]{0,80}\b(?:was |has been )?declined\b/.test(first) &&
      /subscription|membership|\bplan\b|renew/.test(first) && !/\bpolicy\s+(?:no\b|number|#|renewal|[a-z]{0,3}\/?\d)|renewal of (?:your )?policy|insurance|insurer|broadband|postpaid|\border\b|telecom|fiber|fibre|has been renewed|you have been charged/.test(first + ' ' + s);
    var action = failedSub ? 'failed'
      : charged && recurring && !/cancel/.test(s) ? 'done' : /(?:subscription|membership|plan)[^.\n]{0,30}\b(?:was|has been|is|been)\s+(?:cancell?ed|ended|terminated|expired)|cancell?ation (?:confirmed|of your subscription)|you(?:'ve| have) cancell?ed/.test(t) ? 'cancelled'
      : /(?:subscription|membership)[^.\n]{0,20}\b(?:is )?confirmed|confirms your subscription|subscription (?:purchase|confirmation)|thanks? (?:you )?for (?:starting|subscribing)|you(?:'re| are) now subscribed/.test(t) || trialStart ? 'created'
      : RENEWAL.test(t) || /trial (?:now )?(?:ends|is ending|will end)/.test(t) || renewsOn || nextPay ? 'upcoming' : '';
    if (!action) return [];
    // a trial that only ends ("It will not renew automatically", "renew your plan to keep Pro") is no charge coming
    var tU = unsaid(t);
    if (action === 'upcoming' && /\btrial\b/.test(t) && !renewsOn && !nextPay && !RENEWAL.test(tU) && !TRIAL_CHARGE.test(tU)) return [];
    var ev = { type: 'mandate', action: action };
    var pp = kv(doc, /^(?:subscription|plan|membership)(?: name)?$/);
    // (never its term, "Membership: 12 months (till 08 Oct 2027)")
    if (pp && /^\s*(?:\d+|one|two|three|six|twelve)[- ](?:day|week|month|year)s?\b|^\s*(?:monthly|yearly|annual|quarterly|lifetime)\b/i.test(pp.value)) pp = null;
    var party = pp ? cleanParty(pp.value) : '';
    // (a plan's tier is no one's name: "Your Premium subscription", "Standard" is the plan, the sender is who charges)
    if (!party && (m = /\b[Yy]our\s+([A-Z][A-Za-z0-9+&.' ]{1,40}?)\s+(?:subscription|membership|plan)\b/.exec(doc.subject + '\n' + doc.flat.slice(doc.bodyAt, doc.bodyAt + 600))) && !PLAN_TIER.test(trim(m[1]))) party = cleanParty(m[1]);
    // (a trial's own product: "Your free trial of Example Music Premium ends on …")
    if (!party && (m = /\btrial (?:of|for) ([A-Z][A-Za-z0-9+&.' ]{1,40}?)\s+(?:ends|is ending|will end|expires|has (?:now )?(?:started|begun)|is (?:now )?active)\b/.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 600) + '\n' + doc.subject))) party = cleanParty(m[1]);
    if (!party) {
      // a product named on its own line and again with its term ("Apple TV+" then "Apple TV+ (1 month)")
      var ls = doc.lines.slice(1, 14).map(trim);
      for (var i = 0; i < ls.length - 1 && !party; i++) if (ls[i].length >= 2 && ls[i].length <= 40 && (ls[i + 1].indexOf(ls[i] + ' (') === 0 || (ls[i + 2] || '').indexOf(ls[i] + ' (') === 0)) party = ls[i];
    }
    if (!party && renewsOn) {
      // the product named just above "Renews …" (not a "Label | value" line, not a price): its shortest form
      var bl = doc.lines.map(trim), ri = -1;
      for (var bi = 1; bi < bl.length && ri < 0; bi++) if (/^renews\b/i.test(bl[bi])) ri = bi;
      var cands = [];
      for (var bj = ri - 1; bj >= Math.max(1, ri - 3); bj--) { if (/\|/.test(bl[bj]) || /(?:₹|rs\.?|inr)\s?\d|^\d/i.test(bl[bj]) || bl[bj].length < 2 || bl[bj].length > 60) break; cands.push(bl[bj]); }
      var pick = cands[0] || '';
      for (var bk = 1; bk < cands.length; bk++) if (pick.indexOf(cands[bk]) === 0) pick = cands[bk];
      if (pick) party = cleanParty(pick);
    }
    // ("The following subscription will renew soon:" / "Example Plus – 18 August": the line under it, before the dash)
    var soonAt = -1;
    if (!party && (m = /\bfollowing subscriptions? (?:will|is going to|is set to) (?:auto(?:matically)?[- ]?)?renew(?: soon| shortly)?\s*:?[ \t]*\n+[ \t|]*([A-Za-z0-9][^\n–—|]{1,50}?)[ \t]+[–—-][ \t]+/i.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 1200)))) { party = cleanParty(m[1]); soonAt = doc.bodyAt + m.index + m[0].length; }
    if (!party) party = senderBrand(doc);
    if (party) ev.party = party;
    // the price of each renewal ("renews for ₹ 99.00/month", "Renewal Price: ₹ 299/month")
    var price = null, every = '', priceTok = null;
    amts(doc).forEach(function (a) {
      if (price !== null) return;
      var post = doc.nlow.slice(a.e, a.e + 14), pre = doc.nlow.slice(Math.max(0, a.s - 40), a.s);
      // ("/month", "per year", "every 6 months"; six months is its own period, three a quarter, twelve a year)
      var per = /^\s*(?:\/|per |a |every )\s*(?:(\d+|three|six|twelve) )?(month|mo|year|yr|week|quarter)s?\b/.exec(doc.nlow.slice(a.e, a.e + 24));
      if (per || /renew(?:s|al)?(?: price)?(?: for| at| of)?[\s:\-|]*$|(?:will be|you['’]ll be) charged[\s:\-|]*$/.test(pre) || /^\s*will be (?:auto-?)?(?:charged|debited|billed|deducted)\b/.test(post + doc.nlow.slice(a.e + 14, a.e + 30))) {
        price = a.v; priceTok = a;
        if (per) {
          var n0 = per[1] ? ({ three: 3, six: 6, twelve: 12 }[per[1]] || +per[1]) : 1, u0 = per[2];
          every = /^y/.test(u0) ? 'year' : /^w/.test(u0) ? (n0 === 1 ? 'week' : '') : /^q/.test(u0) ? 'quarter'
            : n0 === 1 ? 'month' : n0 === 3 ? 'quarter' : n0 === 6 ? 'six months' : n0 === 12 ? 'year' : '';
        } else if (/^[^.\n]{0,12}?\b(?:for (?:the |a |your )?)?(?:yearly|annual)\b/.test(doc.nlow.slice(a.e, a.e + 30))) every = 'year';
      }
    });
    if (price === null && action !== 'cancelled') {
      // its charge as the receipt or the reminder labels it ("Total (incl. GST) | ₹119.00", "Amount: ₹899")
      var pk = kv(doc, action === 'done' ? /^(?:total|amount paid|total paid|amount charged|order total)(?:\s*\([^)]{1,20}\))?$/ : /^(?:amount|price|plan price|renewal (?:amount|price)|amount to be charged)(?:\s*\([^)]{1,20}\))?$/);
      if (pk && pk.amt > 0) price = pk.amt;
    }
    // (a receipt with no figure is nothing to go on, unless it says outright the subscription was charged: "Thanks for
    // starting your Max subscription. Your payment method has been charged.")
    if (action === 'done' && price === null && !amts(doc).some(function (a) { return inBody(doc, a) && a.v > 0; }) && !(/subscription|membership/.test(s) && /\b(?:has been|was|were) charged\b/.test(doc.lead.slice(0, 600)))) return [];
    // (a charge that failed, "Your payment of ₹129.00 for … (monthly) was declined": the figure it tried to take)
    if (price === null && action === 'failed') { var fpT = amts(doc).filter(function (t) { return inBody(doc, t) && /\b(?:declined|failed|unsuccessful|could not|couldn(?:'|’)?t)\b/.test(lc(sentenceAt(doc, t.s).text)); })[0]; if (fpT) price = fpT.v; if (!every && /\(monthly\)|\bper month\b|\/month\b/i.test(doc.flat.slice(doc.bodyAt, doc.bodyAt + 600))) every = 'month'; }
    if (price !== null && action !== 'cancelled') ev.amt = price;
    if (every) ev.every = every;
    if (action === 'failed') { ev.conf = 'medium'; return [ev]; }
    if (action === 'done') { var pd0 = kv(doc, /^(?:date|order date|receipt date|invoice date|paid on|payment date)$/); if (pd0 && pd0.date) ev.date = pd0.date; }
    else if (action !== 'cancelled') {
      var dm = /\b(?:starting(?: from)?|renews?(?: on)?|renewal date|next (?:charge|payment|billing)(?: date)?(?: will be)?(?: automatically)?(?: deducted| charged| debited| billed)?(?: on)?|will (?:auto-?)?renew on|trial(?: of [^.\n]{1,40}?)? (?:now )?(?:ends|is ending|will end|expires)(?: on)?|(?:won['’]t|will not) be (?:charged|billed) (?:until|till|before))\s*[:\-]?\s*/gi, dd = '';
      if (priceTok) { var pdm = /^[^\n]{0,30}?\bstarting(?: from| on)?\s*/i.exec(doc.flat.slice(priceTok.e, priceTok.e + 50)); if (pdm) { var pdt = near(doc, 'DATE', priceTok.e + pdm[0].length, 0, 6); if (pdt) dd = pdt.v; } }
      while (!dd && (m = dm.exec(doc.flat))) { var dt = near(doc, 'DATE', m.index + m[0].length, 0, 6); if (dt) dd = dt.v; }
      if (!dd && soonAt >= 0) { var sd = near(doc, 'DATE', soonAt, 0, 4); if (sd) dd = sd.v; }
      if (dd) ev.date = dd;
    }
    // an offer of a trial with its terms ("Start your free trial today! After your trial ends, your plan renews at
    // ₹119/month"): no charge of yours is coming, there's no day for one
    if (action === 'upcoming' && !ev.date && /\btrial\b/.test(t) && TRIAL_OFFER.test(t)) return [];
    // a free trial that turns into a charge by itself ("Your free trial ends on 24 Oct; then it renews at ₹119/month",
    // "1 month free trial · Renews 24 Oct for ₹99/month"): marked for the heads-up and the calendar's line (plan.js).
    // A trial that only ends ("upgrade to keep listening") is no charge coming, and isn't marked
    // (a trial named as such: the store's product line, "Example TV+ (1 month free trial)", or the trial's own end; a
    // trial offered of something else, "start a free trial of Family", or a past one mentioned in passing, is not)
    var productTrial = /\(\s*(?:(?:\d+|one|two|three|seven|fourteen|thirty)[- ](?:day|week|month|year)s?\s+)?free trial\s*\)/.test(t);
    if ((action === 'upcoming' || action === 'created') && !ctx.promo && !TRIAL_OFFER.test(t) && (trialEnd || trialStart || TRIAL_END.test(t) || productTrial) && TRIAL_CHARGE.test(tU)) ev.trial = true;
    ev.conf = 'medium';
    return [ev];
  }

  /* money promised: a refund on its way, a debit or credit that will happen */
  function expects(doc, ctx) {
    var out = [], l = doc.head;
    if (ctx.promo) return out;   // "will be credited in 10 seconds" in a loan offer is a sales line
    var refundish = /refund/.test(lc(doc.subject) + ' ' + doc.low.slice(0, 1600)) && /(?:initiated|issued|processed|approved|will be (?:credited|refunded|reflected|processed)|has been (?:initiated|issued|processed)|refund (?:of|for|amount)|refund summary|refund method|original payment method|return (?:request )?(?:processed|received|picked)|cancel+ation|cancel+ed|estimated refund)/.test(doc.low.slice(0, 2500));
    if (/will initiate (?:your |the )?refund after|after (?:your|the) (?:return|item) is picked up|refund (?:will be )?initiated (?:once|after) (?:we receive|the item|your return)/.test(doc.low.slice(doc.bodyAt, doc.bodyAt + 800)) &&
      // (unless a refund was already issued: "Your refund was issued … For other items … after your return is picked up")
      !/^[^(]{0,200}?\brefund (?:of [^.\n]{0,30})?(?:was|has been) (?:issued|initiated|processed)\b(?![^.\n]{0,40}\bearlier\b)/.test(doc.low.slice(doc.bodyAt, doc.bodyAt + 300))) refundish = false;
    // (a pending payment's "if it fails, the amount will be refunded" promises nothing yet)
    if (refundish && ctx.future && /\b(?:if|in case|incase|should)\b[^.\n]{0,40}\b(?:fails?|failed|declined|unsuccessful|not (?:go through|successful))\b/.test(doc.low.slice(doc.bodyAt, doc.bodyAt + 1500))) refundish = false;
    if (refundish && !ctx.failedSubject && !ctx.paidNow && !/\b(?:credited to your (?:a\/c|account|card)|has been credited|is credited)\b/.test(doc.lead.slice(0, 300))) {
      var rp = kv(doc, /total refund|refund amount|^refund$|amount refunded|refund value/);
      var amt = rp && rp.amt != null ? rp.amt : null;
      // ("Refund subtotal ₹286.00 … deductions … Total refund ₹259.38": the total)
      var trm = /\btotal refund(?: amount)?\s*[:|]?\s*(?:₹|rs\.?|inr)\s*(\d[\d,]*(?:\.\d+)?)/i.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 3000));
      if (trm) amt = num(trm[1]);
      if (amt === null) amts(doc).forEach(function (x) { if (amt === null && roleOf(doc, x) === 'refund') amt = x.v; });
      // (never a cap: "cancellation refund up to an annual total of Rs. 20,000", "capped at")
      if (amt === null) { var x0 = amts(doc).filter(function (x) { return (x.role === 'moved' || x.role === 'other') && /refund/.test(lc(sentenceAt(doc, x.s).text)) && !/\b(?:up ?to|capped at|maximum of|max(?:imum)?\.?)\b[^\n]{0,30}$/i.test(doc.flat.slice(Math.max(0, x.s - 40), x.s)); })[0]; if (x0) amt = x0.v; }
      var byP = kv(doc, /refund (?:time|date|by)|estimated refund|credited by|refund expected|^expected (?:refund |credit )?(?:date|by)$/);
      var by = byP && byP.date ? byP.date : labeledDate(doc, /(?:\bby|before|on or before|credited (?:to [^\n]{0,40})?by|reflect (?:in your account )?by)/);
      if (amt !== null && amt > 0) {
        var ev = { type: 'expect', dir: 'in', what: 'refund', amt: amt };
        if (by && dayNum(by) >= dayNum(doc.ref) - 3) ev.by = by;
        var ord = doc.toks.filter(function (x) { return x.t === 'ORDER'; })[0];
        var oid = ord ? ord.v : orderIdIn(doc);
        if (oid) ev.order = oid;
        var shop = shopGuess(doc);
        ev.party = shop ? shop.name : senderBrand(doc);
        if (!ev.party) delete ev.party;
        out.push(ev);
      }
    }
    // "will be debited / charged / credited (on DATE | tomorrow)", not a mandate, not an IPO's unblocking
    if (!ctx.mandate && !ctx.ipo) {
      var m = ctx.policy ? null : /\b(?:will be|shall be)\s+(debited|credited|deducted|charged|paid|refunded|auto-?debited)\b|\bto be\s+(debited|credited|refunded|auto-?debited)\b/i.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 3000));
      // (never one said on a condition, "if it fails, the amount will be refunded", "any amount debited will be refunded")
      if (m) { var mSen = sentenceAt(doc, doc.bodyAt + m.index), mPre = lc(doc.flat.slice(mSen.s, doc.bodyAt + m.index)); if (/\b(?:if|in case|incase|should)\b|\bany (?:amount|money)\b/.test(mPre)) m = null; }
      if (m) {
        var at = doc.bodyAt + m.index;
        var a = near(doc, 'AMT', at, 200, 60, function (x) { var r = roleOf(doc, x); return r === 'moved' || r === 'other' || r === 'due' || r === 'total' || r === 'bill'; });
        var on = near(doc, 'DATE', at + m[0].length, 0, 80);
        if (a && !out.some(function (e) { return e.amt === a.v; })) {
          var w = lc(m[1] || m[2]);
          // (money debited for a payment that didn't go through, "will be credited back": a refund)
          var backRe = /^\s*back\b/.test(doc.flat.slice(at + m[0].length, at + m[0].length + 8)) || /didn['’]?t go through|did not go through|\bfailed\b|could not be (?:completed|processed)|unsuccessful/.test(doc.head);
          var e2 = { type: 'expect', dir: /credited|refunded/.test(w) ? 'in' : 'out', what: /refund/.test(w) || (/credit/.test(w) && backRe) ? 'refund' : /credit/.test(w) ? 'credit' : 'debit', amt: a.v };
          if (on) e2.on = on.v;
          else {
            // "will be charged tomorrow", "in 3 days": days from the mail's own day
            var rel = /^[^.\n]{0,40}?\b(today|tomorrow|in (\d{1,2}) days?)\b/i.exec(doc.flat.slice(at + m[0].length, at + m[0].length + 60));
            if (rel && doc.ref) e2.on = addDays(doc.ref, /today/i.test(rel[1]) ? 0 : /tomorrow/i.test(rel[1]) ? 1 : +rel[2]);
          }
          var who = senderBrand(doc);
          if (who) e2.party = who;
          out.push(e2);
        }
      }
    }
    return out;
  }
  function orderIdIn(doc) {
    var sb = /\b(?:booking|order)\s*(?:with\s+)?(?:id|no\.?|#)\s*[:#\-]?\s*#?\s*-?\s*([A-Z0-9]{6,30})\b/i.exec(doc.subject);
    if (sb && /\d{3,}/.test(sb[1])) return sb[1].toUpperCase();
    var sb2 = /\border\s*(?:id|no\.?|number)?\s*[:#]?\s*[#\[(]?\s*([A-Z0-9][A-Za-z0-9_\-]{2,29})\b[\])]?/i.exec(doc.subject);
    if (sb2 && /\d/.test(sb2[1]) && !/^(?:\d{1,2}|20\d\d)$/.test(sb2[1]) && (/\d{3,}/.test(sb2[1]) || /^[A-Z0-9]{5,}$/.test(sb2[1]))) return sb2[1].toUpperCase();
    var sb4 = /\byour order\s+#?([A-Z0-9]{6,20})\s+(?:has|is|was)\b/i.exec(doc.subject);
    if (sb4 && /\d/.test(sb4[1]) && /[A-Z]/.test(sb4[1])) return sb4[1];
    var sb3 = /\b(?:purchase|order)\b[^(\n]{0,60}\((\d{8,20})\)/i.exec(doc.subject);
    if (sb3) return sb3[1];
    // (a marketplace's order by its receipt's number: "Your Etsy Order dispatched (Receipt #2320340000)")
    var sr = /\border\b[^\n]{0,60}\breceipt\s*(?:no\.?|number)?\s*#\s*(\d{6,20})\b/i.exec(doc.subject);
    if (sr) return sr[1];
    // a booking's reference in its subject ("Air Ticket Confirmation with Refno : EXMPLQRS", "Refno EXMPLQRS|Airline PNR …")
    var rn = /\b[Rr]ef\.?\s*[Nn]o\.?\s*[:#\-]?\s*([A-Z0-9]{6,20})\b/.exec(doc.subject);
    if (rn) return rn[1];
    // (a marketplace's sub-order carries an underscore, "112233445566_2": the subject's own pattern already allows it,
    //  and because this one ends on \b the match failed outright inside the digits rather than stopping short)
    var fo = /\b(?:for|of) (?:your )?order\s*(?:id|no\.?|number|#)?\s*[:#]?\s*([A-Z0-9][A-Z0-9_\-]{4,40})\b/i.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 2500));
    if (fo && /\d{5,}/.test(fo[1]) && !/^(?:id|no|number)$/i.test(fo[1])) return fo[1].replace(/-+$/, '').toUpperCase();
    var p = kv(doc, /order\s*(?:id|no|number|#)|your order id/);
    var dateish = /^\d{1,2}[-\/.]\d{1,2}[-\/.]\d{2,4}$|^\d{4}-\d{2}-\d{2}$/;
    if (p) {
      // the label's own value, up to the next cell ("Order No. 181|05-12-2021|20:08:31": 181)
      var first = trim(p.value.split('|')[0]);
      if (/^[A-Z0-9][A-Z0-9\-]{1,30}$/i.test(first) && /\d{2,}/.test(first) && !dateish.test(first)) return first.toUpperCase();
      var v = /[A-Z0-9][A-Z0-9\-]{5,30}/i.exec(p.value); if (v && /\d{4,}/.test(v[0]) && !dateish.test(v[0])) return v[0].toUpperCase();
    }
    // a restaurant's short order number in its own cell ("Order Confirmed Order No. 412|27-09-2026|20:41:05")
    // ("[Order #15790] (December 20, 2026)": a store's short order number in brackets)
    var sb5 = /\[order\s*#\s*(\d{3,8})\]/i.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 1500));
    if (sb5) return sb5[1];
    // ("Example Air Web Booking eTicket (AB12CD)", "invoice for your Example transaction ABCD001EFGH2 on …",
    // "Bus booking id NU2000000000001")
    var sb6 = /\be-?ticket\s*\(([A-Z0-9]{5,8})\)/i.exec(doc.subject) || /\btransaction\s+([A-Z0-9]{10,24})\b/.exec(doc.subject) || /\bbooking id\s*[:#]?\s*([A-Z0-9]{8,30})\b/i.exec(doc.subject);
    if (sb6 && /\d/.test(sb6[1])) return sb6[1].toUpperCase();
    var sh = /\border\s*no\.?\s*[:#]?\s*(\d{2,6})\s*\|\s*(?:\d{1,2}[-\/ ](?:\d{1,2}|[a-z]{3,9})[-\/ ,]+\d{2,4}|\d{4}-\d{2}-\d{2}|[a-z]{3,9} \d{1,2},? \d{4})/i.exec(doc.flat);
    if (sh) return sh[1];
    var m = /\border\s*(?:id|no\.?|number|#)\s*[:#\-]?\s*#?\s*([A-Z]{0,4}\d[\dA-Z\-]{5,40})\b/i.exec(doc.flat);
    if (m && /\d{5,}/.test(m[1].replace(/-/g, '')) && !/^\d{1,2}-\d{1,2}-\d{2,4}$|^\d{4}-\d{2}-\d{2}$/.test(m[1])) return m[1].replace(/-+$/, '').toUpperCase();
    // "we have cancelled your order 1200000000000301", "Your order PE0000005001 has been delivered", "Your Tata 1mg order
    // PO2610240012345 has been shipped", "Your order NYK-20261019-123456" (the shop's name may stand between, and its code
    // may be joined to its digits by a hyphen)
    var yo = /\byour (?:[A-Z0-9][\w.&'-]*\s+){0,3}?order\s+#?\s*([A-Z]{0,4}-?\d[A-Z0-9\-]{5,30})\b/i.exec(doc.subject + '\n' + doc.flat.slice(doc.bodyAt, doc.bodyAt + 1500));
    if (yo && /\d{5,}/.test(yo[1].replace(/-/g, '')) && !/^\d{1,2}-\d{1,2}-\d{2,4}$|^\d{4}-\d{2}-\d{2}$/.test(yo[1])) return yo[1].replace(/-+$/, '').toUpperCase();
    // (a store's short code marked as an order's with "#": "Your order #EC1042 from Example Crafts")
    var oh = /\border\s*#\s*((?=[A-Z0-9-]*\d{3})[A-Z0-9][A-Z0-9-]{3,30})\b/i.exec(doc.subject + '\n' + doc.flat.slice(doc.bodyAt, doc.bodyAt + 1500));
    if (oh && /[A-Z]/i.test(oh[1]) && !/^\d{1,2}-\d{1,2}-\d{2,4}$/.test(oh[1])) return oh[1].replace(/-+$/, '').toUpperCase();
    // (an order told by its number right after the word, "(Order UL260109876)", "order 2611034455 because": six digits
    // or more, at most a short code before them)
    var ob = /\b[Oo]rder\s+#?((?:[A-Z]{1,4}-?)?\d{6,}[A-Z0-9]*)\b(?![\/.-]\d)/.exec(doc.subject + '\n' + doc.flat.slice(doc.bodyAt, doc.bodyAt + 1500));
    if (ob && !/^\d{1,2}-\d{1,2}-\d{2,4}$|^20\d{6}$/.test(ob[1])) return ob[1].toUpperCase();
    // a travel site's own booking id over the airline's PNR ("Booking ID - EXT100000451" above "PNR: QWERTY")
    var bi = /\bbooking\s*id\s*[:#\-]\s*([A-Z]{2,5}\d{6,20})\b/i.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 2500));
    if (bi) return bi[1].toUpperCase();
    // a booking, a ticket, a ride: its own number ("Booking ID EXMPL12", "Ticket Number: EX1234567890", "CRN1000000001")
    var bp = kv(doc, /^(?:booking|ticket|reservation|trip|ride|itinerary|confirmation)\s*(?:id|no\.?|number|ref(?:erence)?\.?|code)$|^confirmation$|^crn$|^pnr(?:\s*(?:no\.?|number))?$|^pnr\/booking ref\.?$|^(?:\w+ )?bus id$/);
    if (bp) { var bv = /[A-Z0-9][A-Z0-9\-]{4,30}/i.exec(bp.value); if (bv && ((bv[0].match(/\d/g) || []).length >= 2 || /^[A-Z0-9]{5,12}$/.test(bv[0]))) return bv[0].toUpperCase(); }
    var bm = /\b(?:booking|ticket|reservation|trip|ride|itinerary|confirmation)\s*(?:id|no\.?|number|ref(?:erence)?|code)\s*[:#\-]?\s*#?\s*([A-Z0-9][A-Z0-9\-]{4,24})\b/.exec(doc.flat) || /\b(?:booking|ticket|reservation|trip|ride|itinerary|confirmation)\s*(?:id|no\.?|number|ref(?:erence)?|code)\s*[:#\-]?\s*#?\s*([A-Z0-9][A-Z0-9\-]{4,24})\b/i.exec(doc.flat) || /\b(CRN\d{6,})\b/.exec(doc.flat) || /\b(?:booking|reservation)\s+#?([A-Z0-9]{6,20})\s+(?:is\s+)?confirmed\b/i.exec(doc.subject);
    if (bm && (bm[1].match(/\d/g) || []).length >= 2) return bm[1].toUpperCase();
    // (a train's or a flight's PNR, "Refund of Rs. 255.00 for PNR 4512233446", "against PNR K9XMPL")
    var pnr = /\bpnr\s*(?:no\.?|number)?\s*[:#\-]?\s*([A-Z0-9]{6,10})\b/i.exec(doc.subject + '\n' + doc.flat.slice(doc.bodyAt, doc.bodyAt + 1500));
    if (pnr && (/\d{6,}/.test(pnr[1]) || /^[A-Z0-9]{6}$/.test(pnr[1]))) return pnr[1].toUpperCase();
    // (a small shop's receipt, "Order 1BR55A" on a line of its own: its order's code, letters and digits)
    var ol = /(?:^|\n)[ \t]*[Oo]rder[ \t]+#?((?=[A-Z0-9]*\d)(?=[A-Z0-9]*[A-Z])[A-Z0-9]{5,12})[ \t]*(?=\n|$)/.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 2500));
    if (ol) return ol[1];
    // an order id printed only inside a link still counts (rule 14): "…/orders?orderId=ES12345678", "…/order/ES12345678"
    var raw = String((doc.msg && (doc.msg.text || '') + ' ' + (doc.msg.html || '')) || '');
    // (only a link to the shop's own site, never a courier's tracking, a campaign's click id, an image or a review page)
    var shopName = ((doc.domain || '').toLowerCase().split('.').filter(function (x) { return !/^(?:com|in|co|net|org|io|club|app|me|shop|store|www|mail|email|mailer|mailers|e|em|info|noreply|no-reply)$/.test(x); }).pop() || '').replace(/(?:mail|mailer|email|news|alerts?|notify|updates)$/, '');
    var urlRe = /https?:\/\/([a-z0-9.-]+)(\/[^\s"'<>]*)?/gi, um, lk = null;
    while (shopName.length >= 3 && !lk && (um = urlRe.exec(raw))) {
      var host = um[1].toLowerCase(), path = um[2] || '';
      if (host.indexOf(shopName) < 0 || /^(?:cdn|img|images?|static|assets?|media|click|links?|track(?:ing)?|t|e|em|email|go)\./.test(host)) continue;
      if (/review|\brate\b|rating|feedback|survey|banner|unsubscribe|\.(?:png|jpe?g|gif|webp|svg)$/i.test(path.split(/[?#]/)[0])) continue;
      // (the shop's own tracking page counts only with the order's own number in it)
      if (/^\/track/i.test(path) && !/[?&](?:order[_-]?id|orderid|oid)=/i.test(path)) continue;
      lk = /[?&](?:order[_-]?id|orderid|oid)=([A-Z0-9][A-Z0-9-]{5,30})/i.exec(path) || /\/orders?\/([A-Z0-9][A-Z0-9-]{5,30})(?=[\/?#]|$)/i.exec(path);
    }
    if (lk && /\d/.test(lk[1]) && !/^\d{1,2}-\d{1,2}-\d{2,4}$|^\d{4}-\d{2}-\d{2}$/.test(lk[1])) return lk[1].toUpperCase();
    return '';
  }

  /* A refund that has happened, said in one sentence of the mail (rule 14: "refunded" once the money is back): a past
     verb (has been credited, was refunded, we have refunded, credited back), about this refund (its amount, "your" or
     "the refund", the order), and nothing in the same sentence that makes it a promise (will, within 5-7 days, takes,
     once, after, usually, expected) or a store's coins and points. The sentence, where it sits, and its amount. */
  function sentencesOf(text) {
    var out = [], at = 0;
    var re = /[.!?](?=\s)|\n/g, m;
    while ((m = re.exec(text))) {
      var before = text.slice(Math.max(0, m.index - 4), m.index);
      if (m[0] === '.' && /(?:^|\W)(?:rs|no|mr|mrs|ms|dr|inr|st|vs|approx|pvt|ltd|co|inc|ref|e\.g|i\.e)$/i.test(before)) continue;
      // ("a/c." or a single letter mid-name, unless a new sentence starts after it: "…your Example Bank a/c. It will be…")
      if (m[0] === '.' && /(?:^|\W)(?:a\/c|acct|[a-z])$/i.test(before) && !/^\s+(?:it|we|you|your|this|the|please|thank|note|for|if|i)\b/i.test(text.slice(m.index + 1, m.index + 12))) continue;
      out.push({ text: text.slice(at, m.index + 1), s: at });
      at = m.index + 1;
    }
    if (at < text.length) out.push({ text: text.slice(at), s: at });
    return out;
  }
  function refundSaid(doc) {
    var body = doc.flat.slice(doc.bodyAt, doc.bodyAt + 2500);
    // a mail that says anywhere near its top that the refund is still on its way ("will be credited ... by Jul 15", "is
    // processing your refund") is a promise, whatever its summary lines say ("₹259.38 refunded to your original payment method")
    var ss = sentencesOf(body);
    // ("will reflect in your balance instantly" is credited now; "immediately after the quality check" is not)
    var nowRe = /\b(?:instantly|immediately|right away)\b(?!\s+(?:after|once|when|upon|on)\b)/;
    if (ss.some(function (x) { var t = lc(x.text); return x.s < 1200 && (/will be (?:credited|refunded|reflected|reversed)|(?:is|are) processing your refund|being processed|should (?:reflect|be credited) by|expected (?:by|within)/.test(t) || (/will reflect/.test(t) && !nowRe.test(t))) &&
      !(/\brefunds\b|^\s*note\b/.test(t) && !/(?:₹|rs\.?|inr|\$|€|£)\s?\d/.test(t)); })) return null;
    // a refund only "processed" is a promise when the mail gives it a timeline ("It may take 5-7 working days to reflect",
    // "Timeline: 5-7 business days"); one "credited to your account" is credited, whatever help text sits near it
    var timeline = ss.some(function (x) { var t = lc(x.text); return x.s < 1200 && !/\?|^\s*(?:faq|note)\b/.test(t) && /may take|takes? (?:up to )?\d|allow (?:up to )?\d|\b\d+\s*(?:-|to)?\s*\d*\s*(?:working|business) days|to reflect\b/.test(t) && !nowRe.test(t); });
    for (var i = 0; i < ss.length; i++) {
      var t = lc(ss[i].text);
      if (!/(?:has been|have been|was|were|is) (?:successfully )?(?:refunded|credited|reversed)\b|\b(?:processed|been) and credited\b|\brefund of (?:rs\.?|₹|inr)\s?[\d,.]+ has been processed\b|\brefunded to\b|\bwe(?:'ve| have) refunded\b|\b(?:refund|amount)(?: of [^\n]{0,30})? credited to your|credited back/.test(t)) continue;
      if (!/(?:₹|rs\.?|inr|\$|usd|€|£)\s?\d|\b(?:your|the) refund\b|\brefund of\b|^\s*refund (?:has|was)\b|\b(?:order|payment)\b[^\n]{0,60}\brefunded\b/.test(t)) continue;
      if (timeline && /\bprocessed\b/.test(t) && !/(?:refunded|credited|reversed)\b/.test(t)) continue;
      if (/\bwill\b|\bwithin\b|\btakes?\b|\bonce\b|\bafter (?:\d|pick ?up|we receive\b|the (?:item|product) (?:is|reaches))|usually|may take|in \d+(?:\s*-\s*\d+)? (?:business |working )?days|expected|shortly|should reflect|to reflect|\bcoins?\b|\bpoints\b|supercoins|store credits?|\?/.test(t)) continue;
      var a = /(?:₹|rs\.?|inr)\s*(\d[\d,]*(?:\.\d+)?)/i.exec(ss[i].text), fx = a ? null : /(\$|usd|€|eur|£|gbp)\s*(\d[\d,]*(?:\.\d+)?)/i.exec(ss[i].text);
      return { text: ss[i].text, s: doc.bodyAt + ss[i].s, e: doc.bodyAt + ss[i].s + ss[i].text.length, amt: a ? num(a[1]) : fx ? num(fx[2]) : 0, cur: fx ? (/\$|usd/i.test(fx[1]) ? 'USD' : /€|eur/i.test(fx[1]) ? 'EUR' : 'GBP') : '' };
    }
    return null;
  }

  /* a shop's order: each order number the mail names, what's in it, what it came to, and the step it's at */
  function said(text, re) {
    var g = new RegExp(re.source, 'g'), m;
    while ((m = g.exec(text))) { if (!/\b(?:once|when|after|as soon as|will|until|if)\b[^.\n]{0,40}$/.test(text.slice(Math.max(0, m.index - 50), m.index))) return true; if (!m[0].length) g.lastIndex++; }
    return false;
  }
  function orders(doc, ctx) {
    var s = lc(doc.subject), l = doc.low;
    if (/\b(?:ticket|request|query|complaint|case)\s+(?:has been\s+)?(?:received|created|raised|registered|logged|acknowledged)\b|we (?:have )?received your (?:request|query|complaint|email)|ticket has been created/.test(s + ' ' + l.slice(doc.bodyAt, doc.bodyAt + 300))) return [];
    // a shop asking you to complete a payment is a request (rule 16); a cashback in points is the shop's info
    if (/please complete (?:the |your )?payment|complete (?:your )?payment for (?:your )?order/.test(s)) { ctx.consent = true; return []; }
    if (/cashback|reward|points|coins/.test(s) && !/\border\b|refund|return|deliver|ship|dispatch|cancel/.test(s)) return [];
    // an order paid with reward points or vouchers (a rewards catalogue's) is no money and no shop's order (rule 9)
    if (rewardsRedemption(doc)) return [];
    // someone else's request on your ride or listing ("Booking request from Ravi cancelled", "Ravi's booking request
    // has expired") is no booking of yours
    if (/\bbooking request from\b/.test(s) || /\b[a-z]+(?:'|’)s booking request\b/.test(l.slice(doc.bodyAt, doc.bodyAt + 400))) return [];
    var orderish = /\border(?:ed)?\b|\bpurchase from\b|shipped|dispatched|out for delivery|arriving|delivered|cancel+ed|cancell?ation of (?:your )?(?:pnr|booking|ticket|order|reservation)|return(?:ed)?\b|refund|payment declined/.test(s) || /\border\s*(?:id|no|number|#)/.test(l.slice(0, 1500));
    // a return only asked for (a pickup scheduled, the item not yet picked up) is nothing yet (rule 14)
    if (/\breturn\b/.test(s) && /return request|pickup (?:is )?scheduled|we have received your return request/.test(s + ' ' + l.slice(doc.bodyAt, doc.bodyAt + 600)) && !/(?:has been|was|were|we have) picked up|picked up on|(?:has been|was) (?:received at|collected)|\bis complete\b|\bcompleted\b|(?:has been|was|is) (?:refunded|credited)|\brefunded to\b|\b(?:refund|amount)(?: of [^.\n]{0,30})? credited to your|refund (?:of [^.\n]{0,30})?(?:has been|is|was) (?:initiated|processed|credited|issued)/.test(l.slice(doc.bodyAt, doc.bodyAt + 1500))) return [];
    // a booking, a ticket, a ride: what you bought is a trip or a seat
    var travelBody = /\bride (?:id|details|charge)\b|time of ride|confirmation code|\bnights? in\b|check-?in|\bpnr\b/.test(l.slice(0, 1500));
    var booking = (/\bbook(?:ing|ed)\b|\btickets?\b|e-?ticket|\bride\b|\btrip\b|reservation|itinerary|boarding pass|\bpnr\b/.test(s) || (/invoice|receipt/.test(s) && travelBody)) && /\b(?:booking|ticket|reservation|trip|ride|itinerary)\s*(?:id|no\.?|number|ref|code)\b|\bcrn\d{6,}|\bpnr\b|confirmed|thanks for (?:travel+ing|riding)|amount paid|total|fare/.test(l.slice(0, 2500));
    if (!booking && /\be-?ticket\s*\([A-Z0-9]{5,8}\)|\bbooking id\s*[:#]?\s*(?=[A-Z]*\d)[A-Z0-9]{8,}|\binvoice for your [\w ]{2,30} transaction (?=[A-Z]*\d)[A-Z0-9]{10,}/i.test(doc.subject)) booking = true;
    if (booking && !orderish) { if (billerSender(doc)) return []; orderish = true; }
    // a subscription's mail is a mandate's; a bill paid or a receipt for a payment is a movement, not an order
    if (/subscription|membership|bill payment|\brecharge\b/.test(s)) return [];
    var bodyOrder = /\b(?:for|of) (?:your )?order\s*(?:id|no\.?|number|#)?\s*[:#]?\s*[A-Z0-9\-]*\d{4,}|\border\s*(?:no|id|number)\.?[\s:#|]*[A-Z0-9\-]*\d{5,}/i.test(doc.flat.slice(doc.bodyAt, doc.bodyAt + 2500));
    var shopBill = bodyOrder && /\binvoice\b|payment (?:has been |was |is )?(?:successfully )?received/.test(s) && !/bill payment|recharge/.test(s) && !billerSender(doc) && !instrumentIn(doc) && !(doc.inst && /^(?:bank|card|gateway|wallet|app|broker|insurer)$/.test(doc.inst.kind));
    ctx.shopBill = shopBill;
    // (a small business's own numbered invoice, paid, "Tax Invoice #642 … Payment Made | ₹11,800": its order, rule 15)
    var invNo = (/^\s*(?:tax )?invoice\s*#\s*(\d{2,10})\s*$/i.exec(doc.subject) || [])[1] || '';
    if (invNo && !(doc.inst && doc.inst.kind) && !billerSender(doc) && kvAll(doc, /^(?:payment made|amount paid|paid amount|total paid)$/).some(function (p0) { return p0.amt > 0; })) orderish = true; else invNo = '';
    // (an order's own invoice names the order by its number: "Your Zepto order invoice #ZP2610091122", "Order 1234567 - Tax
    // Invoice"; the word between "order" and its number is the paper's name, never a bill paid)
    if (!invNo && /bill payment|recharge|\breceipt\b|\binvoice\b|payment (?:received|successful|confirmation)/.test(s) && !/\border(?:ed)?\s*(?:#|id|no|number)?\s*[:#]?\s*[A-Z0-9]*\d|\border\s+(?:tax\s+)?(?:invoice|receipt|bill)\s*(?:no\.?|number)?\s*[:#]\s*[a-z]{0,4}\d{4,}|\bride\b|\btrip\b|\bbooking\b|\btickets?\b|deliver|shipped|dispatched|\btransaction (?=[A-Z]*\d)[A-Z0-9]{10,}/i.test(doc.subject) && !travelBody && !shopBill) return [];
    // a shipping platform's tracking mail for another shop's order ("your order from Example Home with AWB# …5972 is now
    // delivered"): status chatter, no money (the shop's own mail is the order's record)
    var fromBrand = /\byour (?:order|package|parcel|shipment) from\s+([A-Z][A-Za-z0-9&'. ]{1,40}?)\s+(?:with|is|has|was)\b/.exec(doc.subject + '\n' + doc.flat.slice(doc.bodyAt, doc.bodyAt + 400));
    if (fromBrand && /\bawb\b/i.test(doc.flat.slice(0, 1500)) && (doc.domain || '').replace(/[^a-z0-9]/g, '').indexOf(lc(fromBrand[1]).replace(/[^a-z0-9]/g, '')) < 0) { ctx.delivery = true; return []; }
    // a class or session booked against a pack or membership ("Booking confirmed: Yoga Flow … Credits used: 1"): nothing paid
    if (booking && /\b(?:class|session|slot|workout)\b/.test(s + ' ' + l.slice(doc.bodyAt, doc.bodyAt + 300)) && !/\b(?:amount paid|total paid|you paid|paid|payment|charged|fare|invoice|receipt|order total|grand total)\b/.test(s + ' ' + l.slice(doc.bodyAt, doc.bodyAt + 1500))) return [];
    var shop = orderish ? shopGuess(doc) : null;
    if (!shop) return [];
    // (a sender only guessed a shop from its domain, whose mail names no order, booking, item or return: a payment's money
    // back, a tax refund, no order: "Your payment of ₹2,000 to Example Store didn't go through … will be credited back")
    var guessedRefund = shop.guessed && /refund|\breturn|cancel|credited back|fail|declin/.test(s) && !/\b(?:order|booking|item|items|product|return|pnr|ticket|delivery|invoice|receipt)\b/.test(lc(doc.subject) + ' ' + l.slice(doc.bodyAt, doc.bodyAt + 1500));
    if (guessedRefund) return [];
    // (rule 14) the money is back: the subject or the body says it was refunded or credited, not that it will be
    var bodyR = l.slice(doc.bodyAt, doc.bodyAt + 1500);
    var refundDone = /has been refunded|\bis refunded\b|refund (?:credited|completed|successful)/.test(s) || !!refundSaid(doc);
    // (the body says the order or booking itself was cancelled: "Your order 1100223344 was cancelled", "Cancellation charges")
    // (or that the refund is for its cancellation: "We have processed your refund based on cancellation of your booking")
    var cancelSaid = /\b(?:order|booking|ticket|flight|pnr|reservation|ride|trip)\b[^.\n]{0,60}\b(?:has been|was|were|is|got)\s+cancel+ed\b|\bcancel+ation charges?\b|\brefund\b[^.\n]{0,100}\b(?:based on|on|against|towards|due to)\s+(?:the\s+)?cancel+ation\b/.test(bodyR) && !/\breturn(?:ed)?\b[^.\n]{0,40}\b(?:picked|received|request)\b/.test(bodyR);
    // a restaurant's bill paid through the app (Dineout, Zomato Pay) is the app's payment, no order (rule 5)
    if (/swiggy|zomato|eazydiner|dineout/.test(doc.domain) && (/dineout|bill payment at/i.test(doc.subject) || /\bdineout\b/.test(doc.domain) || /\byou paid\s+(?:rs\.?|₹|inr)\s?[\d,.]+\s+at\s+[A-Z][a-z]/.test(doc.flat.slice(doc.bodyAt, doc.bodyAt + 300)))) return [];
    // a payment that failed for an order is no step of it (rule 26 is for bookings that failed to confirm)
    if (!booking && /payment (?:has )?failed|payment (?:was )?(?:declined|unsuccessful)|payment (?:was )?not completed/.test(s) && !/(?:now|is|has been) confirmed|retry (?:was )?succe/.test(s)) return [];
    var status = /payment declined|payment (?:failed|was declined|not received(?!\s*\?))|update your (?:payment|information)|(?:booking|order)\b[^|]{0,30}\b(?:failed|unsuccessful|not confirmed)\b/.test(s) ? 'declined'
      : /cancel+(?:ed|ation)/.test(s) ? 'cancelled'
      : /refund|\breturn/.test(s) ? (cancelSaid ? 'cancelled' : refundDone ? 'refunded' : 'returned')
      // (a subject that says "on its way" over a body that says only that the order was placed: placed, rule 22)
      : /on (?:its|the) way/.test(s) && !/shipped|dispatched|deliver/.test(s) && /\border\b[^.\n]{0,30}\b(?:has been|is|was) (?:successfully )?placed\b/.test(bodyR.slice(0, 600)) && !/shipped|dispatched|out for delivery|on (?:its|the) way|in transit/.test(bodyR.slice(0, 1200).replace(NOT_YET_SHIPPED, ' ')) ? 'placed'
      : /out for delivery|arriving today|arriving tomorrow|arriving/.test(s) ? 'out'
      : /delivered|signed for/.test(s) ? 'delivered'
      // (out only when the mail says it is: never "will be out for delivery soon", or a tracker's "Shipped > Out for delivery")
      : /shipped|dispatched|on (?:its|the) way/.test(s) ? (/\b(?:is|are|now|has gone) out for delivery\b/.test(bodyR.slice(0, 800)) ? 'out' : 'shipped')
      : booking && /\be-?ticket\b|\bbooking id\b|\binvoice for your\b/.test(s) && !/cancel|refund|\bride\b|\btrip\b|fail|not received|pending|could not|unsuccessful/.test(s) ? 'placed'
      // (a stay's receipt, paid before it begins: "Check-in Sat, 3 Oct 2026" after the day it was sent is a booking made,
      // rule 15's "delivered" is for a stay that ended)
      : booking && /\breceipt\b|\binvoice\b/.test(s) && /check-?in/.test(l.slice(0, 1500)) && (function () { var ci = labeledDate(doc, /check-?in/); return !!ci && ci > doc.ref; })() ? 'placed'
      // (a stay booked for a trip, "Confirmed: Your September 14 – 15 trip, here's your receipt" with its check-in, is a
      // booking made, never a ride taken)
      : (/\bride\b|\btrip\b/.test(s) || /\bride (?:id|details|charge)\b|time of ride/.test(l.slice(0, 1500))) && /thanks for (?:travel+ing|riding)|ride details|ride id|ride date|trip date|invoice|receipt|completed|hope you enjoyed/.test(s + ' ' + l.slice(0, 800)) &&
        !(/\bconfirmed\b|\ball set\b|\bupcoming\b/.test(s + ' ' + l.slice(0, 400)) && /\bcheck-?in\b/.test(l.slice(0, 3000))) ? 'delivered'
      : /ordered|order (?:was |has been |is )?(?:placed|confirm|received)|\border\b[^|]{0,30}\b(?:confirmed|placed|successful)\b|thanks for your order|confirmation|success|booking (?:is )?confirmed|\bbooking\b[^\n]{0,30}\bconfirmed\b|\bbooked\b|your tickets?|itinerary|e-?ticket|ticket (?:information|details|booked|confirmed)|reservation confirmed/.test(s) ? 'placed'
      : /initiated (?:a |the |your )?refund|refund (?:has been |is |was )?(?:initiated|processed|issued)/.test(l.slice(0, 1500)) ? 'refunded'
      : /(?:marked as|has been|have been|was|is|been)\s+cancel+ed|unable to (?:process|fulfil+) your order|order (?:has been |was |is )?cancel+ed/.test(l.slice(0, 1500)) ? 'cancelled'
      : /(?:booking|order|payment)[^.\n]{0,40}\b(?:was not|wasn't|could not be|couldn't be) (?:completed|processed|confirmed)|payment error/.test(l.slice(0, 1200)) ? 'declined'
      // (a quick-commerce invoice's opening line, "Order #ZP2610091122 delivered in 9 mins": the order by its number, then
      // delivered; never "will be delivered by", "delivered within")
      : /out for delivery/.test(l.slice(0, 800)) ? 'out' : /(?:has been|was|is)(?: successfully)? delivered|(?:^|\n)\s*delivered\s*(?:\n|$)|(?:^|\n)\s*(?:your )?order\s*(?:id|no\.?|number)?\s*#?\s*[a-z0-9-]*\d[a-z0-9-]*\s+(?:is |has been )?delivered\b(?!\s+(?:by|within|before|on or|tomorrow|today|soon))/.test(l.slice(0, 800)) ? 'delivered' : said(l.slice(0, 800), /\b(?:has been|have been|was|is|been)\s+shipped|\bshipped (?:on|via|by|today)\b/) ? 'shipped'
      : /thank you for (?:ordering|your order|booking)|thanks for (?:ordering|booking)|congratulations on your (?:\w+ )?order|finished processing your order|your booking is confirmed|booking confirmed|ticket (?:number|no)|order (?:id|no)|confirmation code|reservation|thank you for shopping|thanks for shopping/.test(l.slice(0, 1500)) ? 'placed'
      // (a subject that is the order's own title, "Your Example Shoes order 220000451", over its "Order Number:")
      : /^\s*your\s+[^|:]{0,40}?\border\s*#?\s*(?=[A-Z0-9-]*\d{5})[A-Z0-9-]{5,30}\s*$/i.test(doc.subject) && /\border number\b/.test(l.slice(doc.bodyAt, doc.bodyAt + 1500)) ? 'placed' : '';
    if (!status && (shopBill || invNo)) status = 'placed';
    if (!status) return [];
    // a booking's reminder or its schedule changed is no booking made ("Reminder: your bus leaves tomorrow - Booking id …")
    // (unless it confirms or charges something: "Booking confirmed … (reminder: carry ID)", "rescheduled, fare difference paid")
    if (status === 'placed' && /\breminder\b|schedule change|\bhas changed\b|\brescheduled\b|web check-?in|\bupcoming (?:trip|journey|flight|stay)\b|\bleaves tomorrow\b/.test(s) &&
      !/confirm|\bbooked\b|\bpaid\b|successful/.test(s) && !/(?:booking|order|reservation|ticket)\b[^.\n]{0,40}\b(?:is |has been )?confirmed|\bis booked\b|total fare|amount paid|you paid|\bpaid (?:with|via|using|by)\b|fare difference paid/.test(l.slice(doc.bodyAt, doc.bodyAt + 1500))) return [];
    var all = doc.toks.filter(function (t) { return t.t === 'ORDER'; });
    var groups = [];
    all.forEach(function (t) { if (!groups.some(function (g) { return g.id === t.v; })) groups.push({ id: t.v, s: t.s }); });
    if (!groups.length) { var oid = orderIdIn(doc) || invNo; groups.push({ id: oid, s: oid ? Math.max(0, doc.flat.indexOf(oid)) : 0 }); }
    // a return or refund told by its return number names no order (rule 14): no order's step from it
    if ((status === 'returned' || status === 'refunded') && !groups.some(function (g) { return g.id; }) && /\breturn (?:number|no\.?|id)\b/i.test(doc.flat.slice(doc.bodyAt, doc.bodyAt + 1500)) ) return [];
    return groups.map(function (g) {
      // its part of the mail: from its first mention to the next order's first mention after its last one
      var mine = all.filter(function (t) { return t.v === g.id; });
      var start = mine.length ? mine[0].s : g.s;
      var lastMine = mine.length ? mine[mine.length - 1].s : g.s;
      var nextOther = all.filter(function (t) { return t.v !== g.id && t.s > lastMine; })[0];
      var end = nextOther ? nextOther.s : doc.flat.length;
      var ev = { type: 'order', shop: shop.name, status: status };
      // (a shop kosh only guessed, from a courier's words or a domain: kosh knows no habits of its mail)
      if (shop.guessed) ev.guessed = true;
      if (g.id) ev.order = g.id;
      var tot = null;
      var span = groups.length === 1 ? [0, doc.flat.length] : [start, end];
      // what was paid, by the label that says so most plainly
      if (groups.length === 1) [/^amount paid(?: \(inr\))?$|^you paid$|^total paid$/, /^grand total$|^net (?:amount )?payable$|^total payable$/, /^total fare$|^order total$|^total amount$/, /^total(?: \(inr\))?$/].forEach(function (re) { if (tot !== null) return; var tk = kv(doc, re); if (tk && tk.amt > 0) { tot = tk.amt; if (tk.amtCur) ev.cur = tk.amtCur; } });
      if (tot === null) {
        // the plainest label wins: what was paid, then a grand or order total, then a total, then a fare; never an item's
        // or a sub-total ("Item total ₹449 ... Total paid ₹487.40", "Total ₹286.47 ... Trip fare ₹251.00")
        var best = 9;
        amts(doc, span[0], span[1]).forEach(function (t) {
          var r = roleOf(doc, t);
          var pre = lc(doc.flat.slice(Math.max(0, t.s - 40), t.s));
          if (/(?:item|sub)[\s-]*total[\s:\-|(]*(?:inr|rs\.?)?[\s:\-|)]*$/.test(pre) || !(t.v > 0)) return;
          var rank = /(?:amount\s*paid|total\s*paid|you paid|net\s*(?:amount\s*)?paid|total\s*charged)[\s:\-|(]*(?:inr|rs\.?)?[\s:\-|)]*$/.test(pre) ? 1
            : r === 'orderTotal' || /(?:order\s*total|grand\s*total|total\s*amount|total\s*payable|net\s*payable|\bto pay|amount\s*(?:to be\s*)?(?:paid|payable))[\s:\-|(]*(?:inr|rs\.?)?[\s:\-|)]*$/.test(pre) ? 2
            : /\btotal(?:\s*(?:fare|price|cost))?[\s:\-|(]*(?:inr|rs\.?)?[\s:\-|)]*$/.test(pre) ? 3
            : /(?:(?:ticket|trip|ride)\s*(?:price|fare|cost)|\bfare|paid (?:via|using|with|by|through)[^\n|]{0,30})[\s:\-|(]*(?:inr|rs\.?)?[\s:\-|)]*$/.test(pre) ? 4 : 9;
          if (rank < best) { best = rank; tot = t.v; }
        });
      }
      // a ride or booking receipt with one amount on it: that's what it came to
      if (tot === null) { var vals = uniq(amts(doc, span[0], span[1]).filter(function (t) { var r = roleOf(doc, t); return r !== 'offer' && r !== 'fee' && r !== 'part' && r !== 'price'; }).map(function (t) { return t.v; })); if (vals.length === 1 && amts(doc, span[0], span[1]).length <= 2) tot = vals[0]; }
      if (tot === null && groups.length === 1) {
        // a total in another currency ("Order Total: $400.00") is kept in it
        var fx = doc.toks.filter(function (t) { return t.t === 'AMT' && t.cur && t.cur !== 'INR' && /total|amount|paid/.test(doc.nlow.slice(Math.max(0, t.s - 30), t.s)); })[0];
        if (fx && !amts(doc).length) { tot = fx.v; ev.cur = fx.cur; }
      }
      if (tot !== null) ev.total = tot;
      var items = itemsIn(doc, start, end);
      if (items.length) ev.items = items;
      // (each line bought, with its count and figure as printed; the restaurant a delivery app's order came from)
      if (!booking) { var lines = lineItems(doc, groups.length === 1 ? doc.bodyAt : start, end); if (lines.length) ev.lines = lines; }
      /* (unknown-3nov) a marketplace prints each one's price under its count ("Quantity: 3", "4499 INR", Total 13161.09):
         when the counts times the figures come near the total and the figures alone don't, the figures are each one's */
      if (ev.lines && ev.total > 0 && ev.lines.every(function (l) { return l.amt > 0 && !(l.unit > 0); }) && ev.lines.some(function (l) { return l.q > 1; })) {
        var sA = 0, sQ = 0;
        ev.lines.forEach(function (l) { sA += l.amt; sQ += l.amt * (l.q || 1); });
        if (Math.abs(sA - ev.total) > ev.total * 0.05 && sQ >= ev.total * 0.8 && sQ <= ev.total * 1.3)
          ev.lines.forEach(function (l) { if (l.q > 1) { l.unit = l.amt; delete l.amt; } });
      }
      var outlet = outletOf(doc, shop);
      if (outlet) ev.outlet = outlet;
      // (what it cost, line by line as the mail prints it; what it was for: an event's name, day, place and tickets; a gift;
      // whom it goes to)
      var bill = /^(?:placed|shipped|out|delivered)$/.test(status) ? billOf(doc, groups.length === 1 ? doc.bodyAt : start, end) : [];
      if (bill.length) ev.bill = bill;
      if (booking && status !== 'declined') { var show = showOf(doc); if (show) ev.show = show; }
      var gift = giftOf(doc);
      if (gift) ev.gift = gift;
      var to = shipToOf(doc);
      if (to) ev.to = to;
      // (where it went: the delivery address's PIN and town words, never its house line)
      var shipAt = shipPlaceOf(doc);
      if (shipAt) { if (shipAt.pin) ev.pin = shipAt.pin; if (shipAt.place) ev.place = shipAt.place; }
      ev.conf = g.id ? 'high' : 'medium';
      return ev;
    });
  }
  function itemsIn(doc, start, end) {
    var seg = doc.flat.slice(start, end).split('\n'), out = [];
    for (var i = 0; i < seg.length && out.length < 8; i++) {
      var m = /^•\s+(.{3,160})$/.exec(seg[i].trim());
      if (m && /quantity|qty/i.test(seg[i + 1] || '')) out.push(m[1].split(' | ')[0].slice(0, 80));
    }
    return out;
  }
  /* what was bought, line by line (kosh-brain step 1: payment facts): each line of an order's or invoice's list of
     items, as the mail prints it: { n: the item, q: how many, amt: the line's figure, unit: a figure printed as each
     one's price }. Only what the line itself says: a quantity or a figure the line doesn't print is left out, never
     worked out from the others. The shapes Indian shops print:
       "2 x Example Snack | ₹100.00" · "1 X Veg Thali"                 (a count before the item: food and quick commerce)
       "Example Paneer Roll x 2  ₹240"                                 (a count after it)
       "Example Steel Bottle 1L" then "Quantity: 2"                     (a marketplace's order mail)
       "Example Socks" then "Unit Price: Rs. 199.00 | Qty:2 item(s)"    (an invoice)
       "Example Top | Qty 1 | 679.00" · "Example Bar | 2.0 gm Qty 1 Price ₹ 17,675.00"   (a row with its count)
       "Item | Qty | Price" over rows of the same cells                 (a table with a head)
     Never a total, a sub-total, a fee, a tax, a discount, a saving, a tip or a delivery charge (those are the bill's,
     not things bought); never a booking's fare lines (a seat or a night is the booking's own reading) */
  var LINE_NOT_ITEM = /^(?:item(?:s)?\s*(?:total|bill|subtotal|sub-total|value)|(?:sub|grand|order|cart|bill|net|final|invoice)?[\s-]*total\b|amount\b|total\b|(?:c|s|i|u)?gst\b|tax(?:es)?\b|vat\b|cess\b|discount|coupon|promo|offer|savings?\b|you (?:save|saved|paid)\b|paid\b|payable|(?:delivery|shipping|handling|packaging|packing|platform|convenience|service|small cart|surge|late night|rain)\b[^|]{0,20}\b(?:fee|charges?|cost)|delivery\b|shipping\b|tip\b|donation|round(?:ing)?\s*off|refund|cashback|wallet|points?\b|balance\b|order (?:id|no|number|date|summary)|invoice (?:no|number|date)|payment\b|mode of payment|qty\b|quantity\b|price\b|mrp\b|rate\b|item\b|items\b|product\b|description\b|particulars\b|hsn\b|sold by\b|size\b|colou?r\b|seller\b)/i;
  var LINE_HEAD_ITEM = /^(?:items?|products?|item name|product name|item description|description|particulars|product details|item details)$/i;
  var LINE_HEAD_QTY = /^(?:qty|quantity|units?|nos?|no\. of units)\.?$/i;
  var LINE_HEAD_AMT = /^(?:price|amount|total|rate|unit price|mrp|value|item total|net amount|line total|cost)(?:\s*\((?:inr|₹|rs\.?)\))?$/i;
  function lineAmt(s) {
    var m = /(?:₹|rs\.?|inr)\s*(\d[\d,]*(?:\.\d{1,2})?)/i.exec(s) || /^\s*(\d[\d,]*\.\d{2})\s*$/.exec(s);
    var v = m ? num(m[1]) : 0;
    return v > 0 && v < 1e8 ? Math.round(v * 100) / 100 : 0;
  }
  /* (itemfigs-4nov) a thing bought has a name, never a row of a table's figures: more figures than words, two figures or
     more before its first word, or a summary's own label (Total, Taxable, CGST, Round off) is the bill's, not an item */
  function itemNameOk(n) {
    n = String(n || '').replace(/\s+/g, ' ').trim();
    if (n.length < 3 || !/[a-z]{2}/i.test(n)) return false;
    var toks = n.split(' ');
    var fig = function (t) { return /^[(\-₹]*(?:rs\.?)?\d[\d,]*(?:\.\d+)?%?\)*$/i.test(t); };
    var figs = toks.filter(fig).length, words = toks.filter(function (t) { return /[a-z]{2}/i.test(t); }).length;
    if (figs > words) return false;
    var lead = 0;
    while (lead < toks.length && fig(toks[lead])) lead++;
    if (lead >= 2) return false;
    var rest = toks.slice(lead).join(' ');
    if (/^(?:sub ?-?total|grand total|total|taxable|(?:c|s|i|ut)?gst|cess|tax(?:es)?|round(?:ing)? ?off|amount in words|net (?:amount|payable))\b/i.test(rest)) return false;
    if (figs >= 2 && /\b(?:sub ?-?total|grand total|total|taxable|cgst|sgst|igst|utgst|round(?:ing)? ?off)\b/i.test(n)) return false;
    return true;
  }
  function lineName(s) {
    var n = trim(String(s || '').replace(/^[•*\-–·\s]+/, '').replace(/\s*[|:]\s*$/, ''));
    if (n.length < 3 || n.length > 120 || !/[a-z]{2}/i.test(n) || LINE_NOT_ITEM.test(n)) return '';
    if (!itemNameOk(n)) return '';
    // (a figure, a date or a code alone is no item; neither is a line that is only a sentence of the mail's)
    if (/^[\d\s.,₹:\/-]+$/.test(n) || /(?:₹|rs\.?\s|inr\s)\s*\d/i.test(n) || /\b(?:your|we|our|thank|please|order|dear|hello|hi)\b/i.test(n) && n.split(/\s+/).length > 5) return '';
    // (an offer's words are no item: "2x rewards on every order", "3 X faster delivery")
    if (/\b(?:rewards?|cashback|coupons?|offers?|discount|earn|win|faster|free delivery|% off)\b/i.test(n)) return '';
    // (unknown-3nov: a long name cut at its own seam, " | ", or a word's end: never "… 1kg (2.2 lbs) | 2")
    if (n.length <= 80) return n;
    var cut = n.slice(0, 80), bar = cut.lastIndexOf(' | ');
    return (bar >= 24 ? cut.slice(0, bar) : cut.replace(/\s+\S*$/, '')).replace(/[\s|,(\-]+$/, '');
  }
  function lineItems(doc, start, end) {
    var seg = doc.flat.slice(start, end).split('\n'), out = [], head = null;
    function put(n, q, amt, unit) {
      n = lineName(n);
      if (!n) return;
      var it = { n: n };
      if (q > 0 && q < 1000 && Math.round(q) === q) it.q = q;
      if (amt > 0) it.amt = amt;
      if (unit > 0) it.unit = unit;
      // (the same line printed twice, the text and the HTML of one mail, is one line)
      if (out.some(function (o) { return o.n === it.n && o.q === it.q && o.amt === it.amt; })) return;
      out.push(it);
    }
    for (var i = 0; i < seg.length && out.length < 25; i++) {
      // (a table's row as the mail's HTML gives it, "| 2 x Example Snack | ₹100.00 |": its outer bars aren't cells)
      var line = seg[i].trim().replace(/^\|\s*|\s*\|$/g, '');
      if (!line) continue;
      var cells = line.split('|').map(trim).filter(Boolean), m;
      // a table's head: its rows follow, cell for cell
      var hi = cells.findIndex(function (c) { return LINE_HEAD_ITEM.test(c); }), hq = cells.findIndex(function (c) { return LINE_HEAD_QTY.test(c); });
      if (cells.length >= 2 && hi >= 0 && (hq >= 0 || cells.some(function (c) { return LINE_HEAD_AMT.test(c); }))) {
        head = { n: hi, q: hq, a: cells.reduce(function (a, c, k) { return LINE_HEAD_AMT.test(c) ? k : a; }, -1), w: cells.length };
        continue;
      }
      if (head && cells.length === head.w) {
        if (!lineName(cells[head.n])) { if (LINE_NOT_ITEM.test(cells[head.n] || '')) head = null; continue; }
        put(cells[head.n], head.q >= 0 ? +(/^\d{1,3}$/.exec(cells[head.q]) || [0])[0] : 0, head.a >= 0 ? lineAmt(cells[head.a]) : 0, 0);
        continue;
      }
      head = null;
      // "2 x Example Snack | ₹100.00"
      if ((m = /^[•*\-\s]*(\d{1,3})\s*[x×]\s+([^|₹]{3,120}?)\s*(?:\||$|(?=(?:₹|rs\.?\s|inr\s)\s*\d))(.*)$/i.exec(line)) && !/^\d+\s*[x×]\s*\d/.test(line)) { put(m[2], +m[1], lineAmt(m[3]), 0); continue; }
      // "Example Paneer Roll x 2  ₹240" (never a size, "20 x 30 cm": the name ends in a letter)
      if ((m = /^[•*\-\s]*([^|₹]{3,120}?)\s+[x×]\s*(\d{1,3})\b\s*\|?\s*(.*)$/i.exec(line)) && /[a-z)]$/i.test(m[1]) && !/^\s*(?:cm|mm|m|in|inch|inches|ft|feet)\b/i.test(m[3])) { put(m[1], +m[2], lineAmt(m[3]), 0); continue; }
      // a row with its count in a cell: "Example Top | Qty 1 | 679.00", "Example Bar | 2.0 gm Qty 1 Price ₹ 17,675.00"
      var qc = cells.findIndex(function (c, k) { return k > 0 && /\b(?:qty|quantity)\b\.?\s*:?\s*\d{1,3}\b/i.test(c); });
      if (qc > 0) {
        var q0 = +(/\b(?:qty|quantity)\b\.?\s*:?\s*(\d{1,3})\b/i.exec(cells[qc]) || [0, 0])[1];
        // (its figure: the first after the count, in the count's own cell or the cells after it)
        var rowAmt = [cells[qc].replace(/^.*?\b(?:qty|quantity)\b\.?\s*:?\s*\d{1,3}\b/i, '')].concat(cells.slice(qc + 1)).map(lineAmt).filter(function (v) { return v > 0; })[0] || 0;
        var unitSaid = /\bunit price\b|\beach\b|\bper (?:unit|item|piece)\b/i.test(cells.slice(qc).join(' '));
        put(cells[qc - 1], q0, unitSaid ? 0 : rowAmt, unitSaid ? rowAmt : 0);
        continue;
      }
      /* a name on its own line, its count on the next: "Quantity: 2", "Unit Price: Rs. 199.00 | Qty:2 item(s)", "Size XL
         (Brand size XL) Qty 1" (what comes before the count is never a name of its own), and a "Price ₹ 599.00" line
         after it is each one's price */
      var nx = (seg[i + 1] || '').trim().replace(/^\|\s*|\s*\|$/g, ''), qm = /\b(?:qty|quantity)\b\.?\s*:?\s*(\d{1,3})\b/i.exec(nx);
      // (a name with bars of its own and no figure on its line is one name: "Native Lock Pro | Smart Door Lock | …")
      if (cells.length > 2 && qm && !/\d[\d,]*(?:\.\d{1,2})?\s*(?:₹|rs\.?|inr)?\s*$/i.test(cells[cells.length - 1]) && !lineAmt(line) && lineName(cells[0])) cells = [cells.join(' | ')];
      // (a marketplace's long product name over its count is still its name: the first 118 letters of it)
      if (cells.length <= 2 && qm && cells[0].length > 120 && !lineAmt(cells[0])) cells[0] = cells[0].slice(0, 118);
      if (cells.length <= 2 && qm && lineName(cells[0]) && !lineName(nx.slice(0, qm.index).replace(/[|\s]+$/, ''))) {
        var before = nx.slice(0, qm.index), after = nx.slice(qm.index + qm[0].length);
        var unitP = /\b(?:unit price|price|rate|each)\b/i.test(before) ? lineAmt(before) : 0, rest = lineAmt(after);
        var nx2 = (seg[i + 2] || '').trim().replace(/^\|\s*|\s*\|$/g, '');
        if (!unitP && !rest && /^(?:unit price|price|selling price|rate)\b/i.test(nx2)) unitP = lineAmt(nx2);
        // ("286 INR" on the line after the count: the line's figure)
        var sfx = /^(\d[\d,]*(?:\.\d{1,2})?)\s*(?:inr|₹|rs\.?)$/i.exec(nx2);
        if (!unitP && !rest && sfx) rest = num(sfx[1]);
        put(cells[0], +qm[1], unitP ? 0 : rest, unitP);
        i++;
        continue;
      }
    }
    return out;
  }
  /* the restaurant an order came from, when a delivery app's mail names it ("Your order from Example Snacks was
     delivered", "Your Zomato order from Example Cafe"): where the food was from, beside the app it was paid through.
     Only for a food delivery app kosh knows (knowledge.js sub "Delivery"), and never the app's own name */
  function outletOf(doc, shop) {
    var known = (K.shops || []).filter(function (x) { return x.name === shop.name && x.sub === 'Delivery'; })[0];
    if (!known || shop.guessed) return '';
    var m = /\b[Oo]rder from\s+([A-Z0-9][A-Za-z0-9&'’.\- ]{1,40}?)\s*(?:\(|\bwas\b|\bis\b|\bhas\b|\bhave\b|\bhad\b|\|| - |\n|\.(?:\s|$)|,|!|$)/.exec(doc.subject + '\n' + doc.flat.slice(doc.bodyAt, doc.bodyAt + 600));
    var n = m ? trim(m[1]).replace(/[.\-]+$/, '') : '';
    if (!n || n.length < 3 || lc(n) === lc(known.name) || /^(?:us|our|the|your|a|an|this)\b/i.test(n) || LINE_NOT_ITEM.test(n)) return '';
    return n.slice(0, 60);
  }

  /* ------------------------------------------------------------ what an order cost, what it was for, whom it is for
     (kosh-brain: the order layer, engine/21r-build-orders.js). Each only as the mail prints it, never worked out. */
  /* the bill, line by line: { k, n, amt } with k sub (what the things came to) · disc (a discount, coupon or offer taken
     off) · fee (convenience, booking, platform, handling, delivery, packaging, service) · tax (GST and its parts, cess) ·
     tip · paid (what was paid in the end), in the order printed. A "You saved" or "Savings" line says a discount again and
     is left out; a line without a figure ("Delivery: Free") is no line. Kept only when it says something a total alone
     doesn't: a fee, a tax, a discount or a tip, or what the things came to beside what was paid */
  var BILL_KINDS = [
    ['tip', /\btips?\b/],
    ['fee', /\b(?:convenience|booking|platform|internet handling|handling|delivery|shipping|packaging|packing|service|small (?:cart|order)|surge|late night|rain|cod|processing|restaurant packaging)\s*(?:fees?|charges?)\b|^(?:delivery|shipping)$/],
    ['tax', /^(?:(?:c|s|i|ut)gst|gst|igst|taxes?|cess|vat|service tax)\b|^(?:total )?(?:gst|tax(?:es)?) (?:amount|@|\d)/],
    ['disc', /\b(?:discount|coupon|promo(?: code)?|offer applied|bank offer|instant discount|voucher (?:applied|discount)|special price)\b/],
    ['sub', /^(?:items? ?(?:total|subtotal|sub-total|value|amount)|sub ?-?total|cart (?:total|value)|bag total|total mrp|mrp total|order value|tickets? (?:price|amount|total|cost|value)|base (?:fare|price|amount))$/],
    ['paid', /^(?:total (?:amount )?paid|amount paid|paid amount|you paid|net (?:amount )?paid|grand total|order total|total payable|net payable|amount payable|total amount|total|total price|bill total|to pay)$/],
  ];
  var BILL_SAID_AGAIN = /\b(?:you (?:have )?saved|savings?|you save|saved)\b/;
  function billKind(label) {
    var l = lc(label).replace(/\([^)]*\)/g, ' ').replace(/[:*#|\-–]+\s*$/, '').replace(/\s+/g, ' ').trim();
    if (!l || l.length > 48 || BILL_SAID_AGAIN.test(l)) return '';
    for (var i = 0; i < BILL_KINDS.length; i++) if (BILL_KINDS[i][1].test(l)) return BILL_KINDS[i][0];
    return '';
  }
  function billOf(doc, start, end) {
    var out = [];
    function put(label, amt, at) {
      var k = billKind(label);
      if (!k || !(amt > 0) || amt >= 1e8) return;
      var n = trim(String(label).replace(/[:|]+\s*$/, '').replace(/^[•*\-\s]+/, '')).slice(0, 40);
      n = n.charAt(0).toUpperCase() + n.slice(1);
      // (the text and the HTML of one mail print each line twice: one line)
      if (out.some(function (o) { return o.k === k && o.amt === amt && lc(o.n) === lc(n); })) return;
      out.push({ k: k, n: n, amt: Math.round(amt * 100) / 100, s: at });
    }
    doc.pairs.forEach(function (p) {
      if (p.s < start || p.s >= end || !(p.amt > 0) || p.amtCur) return;
      put(p.label, p.amt, p.s);
    });
    // "Delivery fee ₹40", "Discount -₹100" on one line with no colon or cell between
    var seg = doc.flat.slice(start, end), re = /(^|\n)[•*\s]*([A-Za-z][A-Za-z0-9 &()%@.,\/'+]{1,46}?)\s*[-−–]?\s*(?:₹|rs\.?\s?|inr\s?)\s*(\d[\d,]*(?:\.\d{1,2})?)\s*(?=\n|$)/gi, m;
    while ((m = re.exec(seg))) put(m[2], num(m[3]), start + m.index + m[1].length);
    out.sort(function (a, b) { return a.s - b.s; });
    out = out.slice(0, 14).map(function (o) { return { k: o.k, n: o.n, amt: o.amt }; });
    var tells = out.some(function (o) { return /^(?:fee|tax|disc|tip)$/.test(o.k); }) || (out.some(function (o) { return o.k === 'sub'; }) && out.some(function (o) { return o.k === 'paid'; }));
    return tells ? out : [];
  }
  /* an event booked (a concert, a film, a play, a match): { name, perf, k, on, n, venue, at }, each only where the mail
     says it. The name by its label ("Event: …"), the subject's "tickets for …", a line that names a tour or a live show,
     else the line just above the event's own day; the day by its label or that line (never before the mail's day: that
     is when it was booked); the venue by its label or the line under the day; how many tickets as printed. The
     performer only where the name is shaped "<who> - <the tour>", "<who> Live in …", "<who>'s … Tour". Never for a
     journey or a stay: trips.js reads those */
  var SHOW_KEY = /^(?:event|event name|show|show name|movie|movie name|film|concert|title|event title|experience|activity)$/;
  var SHOW_TRAVEL = /\bpnr\b|\bflights?\b|\btrains?\b|\bbus(?:es)?\b|\bcheck-?in\b|\bhotels?\b|\brides?\b|\bcabs?\b|boarding pass|itinerary|\bstay\b|\bnights?\b|\bair(?:line|ways)\b|\bdeparture\b|\barrival\b/;
  var SHOW_WORDS = /\b(?:concerts?|gigs?|live|tour|shows?|movies?|films?|cinemas?|screens?|audi(?:torium)?|venue|events?|festival|fest|stand-?up|comedy|plays?|theatre|theater|match|stadium|arena|exhibition|workshop|admission|entry)\b/;
  var SHOW_NOT_NAME = /\b(?:your|you|we|our|thank|thanks|hi|hello|dear|booking|booked|confirmed|order|tickets?|payment|paid|receipt|invoice|qr|code|entry gate|please|team|regards|download|app)\b|^(?:mon|tue|wed|thu|fri|sat|sun)[a-z]*\b|^\d|₹|rs\.?\s?\d|@/i;
  function showName(s) {
    var n = trim(String(s || '').replace(/^[•*\-\s]+/, ''));
    if (n.length < 3 || n.length > 90 || !/[a-z]{2}/i.test(n) || n.split(/\s+/).length > 14 || SHOW_NOT_NAME.test(n.split(' | ')[0])) return '';
    return n;
  }
  function showOf(doc) {
    var head = lc(doc.subject) + '\n' + doc.low.slice(doc.bodyAt, doc.bodyAt + 2500);
    if (SHOW_TRAVEL.test(head)) return null;
    var seller = (K.shops || []).filter(function (x) { return onDomain(doc.domain, x.domains || []) && /^(?:Ticketing|Movies|Events|Concerts)$/.test(x.sub || ''); })[0];
    if (!seller && !SHOW_WORDS.test(head)) return null;
    var body = doc.lines.slice(1), at0 = 1, name = '', from = 'label';
    var p = kv(doc, SHOW_KEY);
    if (p) name = showName(p.value);
    if (!name) { var sm = /\b(?:tickets?|booking|booked|seats?|passes?)\s+(?:for|to)\s+(.{3,80}?)(?:\s+(?:at|on|is|are|has|have)\b|\s*[!.,(]|$)/i.exec(doc.subject); if (sm) { name = showName(sm[1]); from = 'subject'; } }
    // (the event's own day: the first day in the body on or after the mail's, never the day it was booked)
    var day = '', dayLine = -1;
    var dp = kv(doc, /^(?:date|event date|show date|when|date (?:&|and) time|show time|showtime|date and time)$/);
    if (dp && dp.date && dp.date >= doc.ref) day = dp.date;
    if (!day) { var ld = labeledDate(doc, /\b(?:event|show)\s+date\b|\bdate\s*(?:&|and)\s*time\b|(?:^|\n)\s*date\b/); if (ld && ld >= doc.ref) day = ld; }
    for (var i = 0; i < body.length && i < 60; i++) {
      var ln = body[i];
      if (!name && /\b(?:tour|live|concert|unplugged|festival|fest)\b/i.test(ln)) { var tn = showName(ln); if (tn) { name = tn; from = 'line'; } }
      if (dayLine < 0) {
        var at = doc.lineAt[i + at0];
        var dt = doc.toks.filter(function (t) { return t.t === 'DATE' && t.s >= at && t.s < at + ln.length && !t.rel && t.v >= doc.ref; })[0];
        if (dt && !/\b(?:booking|booked|order|purchase|transaction|invoice)\s*(?:date|on)\b/i.test(ln)) {
          dayLine = i;
          if (!day) day = dt.v;
          if (!name) for (var b = i - 1; b >= 0 && b >= i - 3; b--) { var bn = showName(body[b]); if (bn) { name = bn; from = 'line'; break; } }
        }
      }
    }
    if (!name) return null;
    var o = { name: name.split(' | ')[0].trim().slice(0, 80) };
    var tail = name.split(' | ').slice(1).join(', ').trim();
    if (tail) o.at = tail.slice(0, 60);
    // (a page's own nav word the line picked up before the name: "All", "Events", "Music")
    o.name = o.name.replace(/^(?:[Aa]ll|[Hh]ome|[Ee]vents?|[Mm]usic|[Cc]oncerts?|[Cc]omedy|[Pp]lays?|[Ss]ports)\s+(?=[A-Z][a-z]+\s+[A-Z])/, '');
    var pm = /^(.{2,40}?)\s+[-–:]\s+(?:the\s+)?.*\b(?:tour|live|concert|unplugged|show)\b/i.exec(o.name) || /^(.{2,40}?)\s+live(?:\s+in\s+.+)?$/i.exec(o.name) || /^(.{2,40}?)(?:'s|’s)\s+.*\btour\b/i.exec(o.name);
    if (pm && pm[1].split(/\s+/).length <= 5 && /^[A-Z]/.test(pm[1]) && !/\b(?:the|tour|live|concert|show)\b/i.test(pm[1])) o.perf = trim(pm[1]);
    var words = lc(o.name + ' ' + doc.subject);
    o.k = /\b(?:films?|movies?|cinemas?|screen|imax|audi|3d|2d)\b/.test(words) ? 'movie' : /\b(?:concerts?|gigs?|live|tour|unplugged|music)\b/.test(words) ? 'concert' : 'event';
    if (day) o.on = day;
    var vp = kv(doc, /^(?:venue|location|where|address|theatre|theater|cinema|place)$/);
    var venue = vp ? trim(vp.value) : dayLine >= 0 && body[dayLine + 1] && /,/.test(body[dayLine + 1]) && showName(body[dayLine + 1].replace(/,/g, ' , ')) ? trim(body[dayLine + 1]) : '';
    if (!venue && from === 'subject') { var sv = /\s+at\s+(.{3,60}?)(?:\s*[!.,(]|$)/i.exec(doc.subject.slice(doc.subject.indexOf(name) + name.length)); if (sv) venue = trim(sv[1]); }
    if (venue && venue.length <= 90) o.venue = venue;
    var hay = doc.flat.slice(doc.bodyAt, doc.bodyAt + 3000);
    var nm = /\b(\d{1,2})\s*(?:x\s*)?(?:tickets?|seats?|passes|admits?)\b/i.exec(hay) || /\b(?:no\.?\s*of\s*(?:tickets|seats|persons|guests)|tickets?|seats?|quantity|qty|admits?)\s*[:\-|]?\s*(\d{1,2})\b(?![:.\d])/i.exec(hay);
    if (nm && +nm[1] > 0 && +nm[1] <= 40) o.n = +nm[1];
    return o;
  }
  /* a gift, only where the mail says it is one: a gift message or note, gift wrap on the order, "this order is a gift",
     "sent as a gift", "gifted to <Name>". { to: <Name> } when it names whom. Never a gift card or voucher (that is money
     parked), never a line that offers gifting ("gift wrap available", "perfect gift ideas") */
  var GIFT_SAID = /\bgift(?:ed)?\s+(?:message|note|wrap(?:ped|ping)?|receipt|box)\b|\b(?:this|your)\s+(?:order|item|parcel|package)\s+(?:is|was)\s+(?:sent\s+as\s+)?a\s+gift\b|\bsent\s+as\s+a\s+gift\b/i;
  var GIFT_TO = /\b[Gg]ift(?:ed)?\s+(?:to|for)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+){0,2})\b/;
  var GIFT_PROMO = /\bavailable\b|\boffers?\b|\bideas?\b|\bperfect gift\b|\bgifting (?:store|season|guide)\b|\bshop\b|\bexplore\b|\bgift ?cards?\b|\bgift vouchers?\b|\bfree gift\b|\bunsubscribe\b|\bwhy not\b|\badd (?:a )?gift\b/i;
  function giftOf(doc) {
    var lines = doc.flat.slice(doc.bodyAt, doc.bodyAt + 5000).split('\n');
    for (var i = 0; i < lines.length; i++) {
      var l = lines[i];
      var to = GIFT_TO.exec(l);
      if (to && /^(?:You|Your|The|This|Every|All|Him|Her|Them|Someone|Everyone|Diwali|Holi|Christmas|Rakhi|Raksha|Eid|Valentine|Valentines|Mother|Father|Mothers|Fathers|Birthday|Anniversary|New)$/.test(to[1].split(' ')[0])) to = null;
      if (!(GIFT_SAID.test(l) || to) || GIFT_PROMO.test(l)) continue;
      var o = { said: true };
      if (to) o.to = to[1];
      return o;
    }
    return null;
  }
  /* whom the parcel goes to, as the mail prints it ("Delivering to: Ravi Example", "Ship to | Ravi Example, Flat 2…"): a
     name of one to four words, never an address */
  /* where an order went (kosh-brain: understanding you, a move): the delivery address's PIN code and the town words
     before it ("Delivery address | Asha Example, Flat 12, Example Towers, Exampleton, Haryana 134003" → 134003 and
     "Exampleton, Haryana"), or the town a delivered mail names after the name ("delivered … to Asha Example, Pune.").
     Never the house line, a shop's or courier's own address, or a town with no address label */
  function shipPlaceOf(doc) {
    var PINRE = /\b[1-9]\d{2}\s?\d{3}\b/;
    var p = kv(doc, /^(?:deliver(?:ing|y)? (?:to|address)|ship(?:ping)? (?:to|address)|delivery location)$/), v = p ? String(p.value) : '';
    // (the label alone on its line, the address on the lines under it: "Delivery Address" / "Home" / "Flat 4B, …, Pune 411001")
    if (!PINRE.test(v)) {
      var m = /\b(?:[Dd]elivery|[Ss]hipping|[Dd]elivering) (?:[Aa]ddress|[Tt]o)\s*[:\-|]?\s*((?:[^\n]{0,160}\n?){1,4})/.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 5000));
      if (m && PINRE.test(m[1])) v = m[1].split('\n').filter(function (l) { return !/[:|]/.test(l) || PINRE.test(l); }).join(', ');
    }
    var pins = v.match(/\b[1-9]\d{2}\s?\d{3}\b/g), pin = pins ? pins[pins.length - 1].replace(/\s/g, '') : '';
    var head = pin ? v.slice(0, v.lastIndexOf(pins[pins.length - 1])) : v;
    var parts = head.split(/[,\n|]/).map(function (x) { return trim(x.replace(/\b(?:pin(?:\s*code)?|india)\b[:\s\-]*/gi, '').replace(/[\s\-.:]+$/, '')); });
    var segs = parts.filter(function (x) { return x && !/\d/.test(x) && /^[A-Za-z][A-Za-z .'()]{1,40}$/.test(x); });
    // (the name the parcel is for is no town: the first part, when house lines follow it)
    if (segs.length > 2 && parts[0] === segs[0]) segs = segs.slice(1);
    var place = pin ? segs.slice(-2).join(', ') : '';
    if (!pin) {
      var dm = /\b[Dd]elivered\b[^.\n]{0,40}\bto\s+[A-Z][A-Za-z.']+(?:\s+[A-Z][A-Za-z.']+){0,3},\s*([A-Z][a-z]+(?:\s[A-Z][a-z]+)?)\s*(?:[.\n]|$)/.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 2000));
      if (dm && !/\b(?:front|door|reception|security|guard|neighbour|neighbor|locker|today|tomorrow)\b/i.test(dm[1])) place = dm[1];
    }
    if (!pin && !place) return null;
    var o = {};
    if (pin) o.pin = pin;
    if (place) o.place = place.slice(0, 60);
    return o;
  }
  function shipToOf(doc) {
    var p = kv(doc, /^(?:deliver(?:ing|y)? to|ship(?:ping)? to|shipping address|delivery address|recipient(?: name)?|consignee(?: name)?|address)$/);
    var v = p ? p.value : (/\b(?:[Dd]eliver(?:ing|y)?|[Ss]hip(?:ping)?) [Tt]o\s*[:\-]?\s*([A-Z][A-Za-z.]+(?:\s+[A-Z][A-Za-z.]+){0,3})/.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 4000)) || [])[1] || '';
    var n = trim(String(v).split(/[,\n|]|\s{2,}/)[0]);
    if (!/^[A-Z][A-Za-z.']+(?:\s+[A-Z][A-Za-z.']+){0,3}$/.test(n) || /\b(?:road|street|sector|flat|house|floor|near|nagar|colony|apartment|tower|city|block|lane|phase|home|office|address|india|your|the)\b/i.test(n)) return '';
    return n.slice(0, 40);
  }

  /* ------------------------------------------------------------ a parcel's steps (ASSISTANT.md §5.1)
     A shop's or a courier's own mail about a parcel on its way to the door, or a return on its way back: the return's
     pickup booked (its day and its window), picked up, on its way (the day it is expected), out for delivery (today), a
     delivery tried and missed (and what the mail says happens next), rescheduled, held for collection, delivered. One
     event a mail, with the order's number, the courier's tracking number, the shop, the courier, any cash to pay at the
     door and the courier's or shop's own tracking link, each only as the mail prints it (a day said in words, "tomorrow",
     only against the mail's own day). Never money: it moves no figure, rides apart from the reading's events (the
     reader's `parcels`, joined to the record's evs by engine.js withReader), and is made only with a key (an order or a
     tracking number), so a mail that names neither says nothing. */
  var COURIERS = K.couriers || [];
  function courierOf(doc) { for (var i = 0; i < COURIERS.length; i++) if (onDomain(doc.domain, COURIERS[i].domains)) return COURIERS[i]; return null; }
  var COURIER_RE = null;
  // the courier a mail names ("shipped via Delhivery", "Courier Partner: Blue Dart Express"), by the names it goes by
  function courierNamed(text) {
    if (!COURIER_RE) {
      var names = [];
      COURIERS.forEach(function (c) { if (c.kind === 'courier') (c.names || [c.name]).forEach(function (n) { names.push([n, c]); }); });
      names.sort(function (a, b) { return b[0].length - a[0].length; });
      COURIER_RE = { list: names, re: new RegExp('\\b(' + names.map(function (n) { return n[0].replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/\s+/g, '\\s+'); }).join('|') + ')\\b', 'i') };
    }
    if (!COURIER_RE.list.length) return null;
    var m = COURIER_RE.re.exec(text || '');
    if (!m) return null;
    var hit = lc(m[1]).replace(/\s+/g, ' ');
    for (var i = 0; i < COURIER_RE.list.length; i++) if (lc(COURIER_RE.list[i][0]) === hit) return COURIER_RE.list[i][1];
    return null;
  }
  // a shop that sends parcels (knowledge.js `ships`): shopping, online groceries and quick commerce, pharmacies
  function shipsShop(doc) {
    var list = K.shops || [];
    for (var i = 0; i < list.length; i++) if (list[i].ships && onDomain(doc.domain, list[i].domains)) return list[i];
    return null;
  }
  // a progress strip ("Ordered > Shipped > Out for delivery > Delivered", "Order Confirmed Packed Shipped Out for Delivery
  // Delivered") names every step and says none of them happened: its lines are left out
  var STEP_LABELS = /\b(?:ordered|order (?:placed|confirmed)|confirmed|packed|shipped|dispatched|in transit|out for delivery|delivered|picked up|pickup scheduled|return requested|refund (?:initiated|processed))\b/g;
  function withoutStrips(text) {
    // (each left-out line kept as spaces, so every offset still points into the mail)
    return text.split('\n').map(function (l) { var n = (l.match(STEP_LABELS) || []).length; return n >= 3 || (n >= 2 && /[>→»]|\|/.test(l) && l.replace(STEP_LABELS, '').replace(/[\s>→»|:,.\-]+/g, '').length < 12) ? l.replace(/[^\n]/g, ' ') : l; }).join('\n');
  }
  // the first place the words say it: never "will be out for delivery", "once delivered", "if we couldn't deliver", "should
  // it be undelivered", "before the pickup", "expected to be delivered"
  var NOT_YET = /\b(?:once|when|after|as soon as|will|shall|would|until|unless|if|in case|incase|should|before|expected to|likely to|may|might|soon|to be|yet to)\b[^.\n|]{0,40}$/;
  // ("has not been delivered", "never picked up": the word that denies the step stands right before it)
  var NOT_SAID = /\b(?:not|never|n['’]t)\s+(?:yet\s+)?(?:been\s+)?(?:be\s+)?$/;
  function told(text, re) {
    var g = new RegExp(re.source, re.flags.indexOf('g') >= 0 ? re.flags : re.flags + 'g'), m;
    while ((m = g.exec(text))) {
      var before = text.slice(Math.max(0, m.index - 55), m.index);
      if (!NOT_YET.test(before) && !NOT_SAID.test(before)) return m.index;
      if (!m[0].length) g.lastIndex++;
    }
    return -1;
  }
  var P_ATTEMPT = /\b(?:delivery attempt(?:ed)?|attempted (?:the )?delivery|attempt(?:ed)? to deliver)\b[^.\n|]{0,50}\b(?:fail|unsuccessful|could not|couldn['’]?t|was not|wasn['’]?t|missed)|\b(?:failed|unsuccessful|missed) (?:delivery )?attempt\b|\b(?:could not|couldn['’]?t|were unable to|was unable to|unable to) (?:be )?deliver(?:ed)?\b|\bundelivered\b|\bdelivery (?:was |has )?(?:failed|unsuccessful|not (?:completed|successful))\b|\bwe missed you\b|\btried to deliver\b|\bnot delivered\b/;
  var P_PICKFAIL = /\b(?:pick ?-?up|collection) (?:attempt )?(?:was |has )?(?:failed|unsuccessful|not (?:completed|successful)|missed)\b|\b(?:could not|couldn['’]?t|were unable to|was unable to|unable to) (?:pick ?-?up|collect) (?:the |your )?(?:item|product|return|package|parcel|shipment|order)\b|\b(?:failed|unsuccessful|missed) (?:return )?pick ?-?up\b/;
  var P_HELD = /\b(?:held|kept|waiting|is available|ready) (?:at|for) (?:the |our |your )?(?:nearest |local )?(?:collection|pick ?-?up|self[- ]?collection|self[- ]?pick ?-?up|post office|branch|hub|facility|counter|cent(?:re|er)|delivery cent(?:re|er))\b|\bready for (?:self[- ]?)?(?:collection|pick ?-?up)\b|\bawaiting (?:your )?collection\b/;
  var P_RESCHED = /\b(?:delivery|pick ?-?up)\b[^.\n|]{0,40}\b(?:has been |is |was |been )rescheduled\b|\brescheduled (?:your |the )?(?:delivery|pick ?-?up)\b|\bnew (?:delivery|pick ?-?up) (?:date|slot)\b/;
  var P_PICKED = /\b(?:has been|have been|was|were|been|successfully|is) picked ?-?up\b|\bpicked ?-?up (?:on|at|today|successfully|from you)\b|^\s*(?:return )?picked ?-?up\b|\b(?:return(?:ed)? (?:item|product|package|parcel|shipment)s?|your return|the (?:item|product)s? you returned) (?:has been |have been |was |were |is )?(?:received|collected)\b|\b(?:we(?:'ve| have)?|has|have) (?:received|collected) (?:your |the )?return(?:ed)?(?! request)(?: (?:item|product|package|parcel|shipment)s?)?\b|\breturn (?:received|collected|picked ?-?up)\b/;
  var P_BOOKED = /\bpick ?-?up\b[^.\n|]{0,40}\b(?:is |has been |was )?(?:scheduled|booked|confirmed|arranged|fixed)\b|\b(?:scheduled|booked|arranged|confirmed) (?:a |the |your )?(?:return |reverse )?pick ?-?up\b|\b(?:return |reverse )?pick ?-?up (?:date|slot|time|window)\b|\b(?:return |reverse )pick ?-?up\s*(?:on|for|:)|\bwill (?:be )?pick(?:ed)? ?-?up\b|\bwill (?:come to |visit (?:you |your (?:address|place) )?to )?(?:pick ?-?up|collect) (?:the |your )?(?:item|product|return|package|parcel)/;
  var P_DELIVERED = /\b(?:has been|have been|was|were|is|are|got|been|successfully|now) delivered\b|\bdelivered (?:successfully|today|on|at|to you|to your)\b|^\s*delivered\b|\byour (?:order|package|parcel|shipment|item|consignment)s?\b(?:(?!\b(?:will|shall|would|to be|once|when|after|if|not|should|expected)\b)[^.\n|]){0,60}\b(?:is |are |has |have )?(?:been )?delivered\b(?! (?:by|within|before|on or|soon|today|tomorrow))|\bdelivery (?:is )?(?:complete|completed|successful)\b/;
  var P_OUT = /\bout for delivery\b/;
  // on its way: shipped, dispatched, in transit, handed to the courier
  var P_MOVING = /\b(?:has been|have been|was|were|is|are|got|been|successfully) (?:shipped|dispatched)\b|\b(?:shipped|dispatched) (?:on|via|by|today|with|through)\b|^\s*(?:shipped|dispatched)\b|\bin transit\b|\bon (?:its|the) way\b|\bhanded (?:over )?(?:your (?:order|package|parcel|shipment) )?to (?:our |the )?(?:courier|delivery|shipping|logistics) partner|\bpicked ?-?up from (?:the )?(?:seller|warehouse|store|merchant)\b/;
  // when it is expected: on its way only with the day it gives
  var P_ETA = /\barriving\b|\b(?:expected|estimated) (?:date of )?delivery\b|\bwill be delivered (?:by|on|before|tomorrow|today)\b|\bdelivery (?:expected|by|date)\b|\bexpected to (?:be delivered|arrive|reach)\b|\bwill (?:arrive|reach (?:you|your))\b/;
  var P_TRANSIT = new RegExp(P_MOVING.source + '|' + P_ETA.source);
  // a return's leg (the courier collects from you): said of a return, an exchange or a replacement, never a shop's
  // "easy returns" footer
  var P_RET = /\breturn(?:ed)? (?:request|pick ?-?up|id|no\b|number|of your|for your|is|has|was|initiated|approved|accepted|received|collected|picked|item|product|package|parcel|shipment|order)|\byour return\b|\b(?:exchange|replacement) (?:request|pick ?-?up|order|id)\b|\breverse pick ?-?up\b|\brto\b/;
  var WEEKDAY = { sun: 0, mon: 1, tue: 2, wed: 3, thu: 4, fri: 5, sat: 6 };
  // the day a step is for, from where the words say it: a printed date, a day said in words against the mail's own day,
  // or a weekday within the week ahead ("Arriving Thursday")
  function parcelDay(doc, at, span) {
    var d = near(doc, 'DATE', at, 0, span || 70);
    if (d) return d.v;
    var w = /\b(sun|mon|tues?|wed(?:nes)?|thu(?:rs?)?|fri|sat(?:ur)?)(?:day)?\b/i.exec(doc.flat.slice(at, at + (span || 70)));
    if (w && doc.ref) {
      var want = WEEKDAY[lc(w[1]).slice(0, 3)], now = new Date(dayNum(doc.ref) * 864e5).getUTCDay();
      if (want != null) return addDays(doc.ref, (want - now + 7) % 7);
    }
    return '';
  }
  function hhmm(h, m, ap) {
    h = +h; m = +(m || 0); ap = lc(ap || '').replace(/\./g, '');
    if (ap === 'pm' && h < 12) h += 12;
    if (ap === 'am' && h === 12) h = 0;
    return h <= 23 && m <= 59 ? pad(h) + ':' + pad(m) : '';
  }
  // a window, only as printed: "10 AM - 6 PM", "07:00 am - 10:00 pm", "between 10:00 and 18:00 hrs"
  function windowIn(text) {
    var re = /\b(\d{1,2})(?:[:.](\d{2}))?\s*(am|pm|a\.m\.|p\.m\.)?\s*(?:-|to|and|till|until)\s*(\d{1,2})(?:[:.](\d{2}))?\s*(am|pm|a\.m\.|p\.m\.|hrs|hours)?(?![\w\/-])/gi, m;
    while ((m = re.exec(text))) {
      var ap2 = /^(?:hrs|hours)$/i.test(m[6] || '') ? '' : m[6], hasAp = !!(m[3] || ap2), clock = m[2] && m[5];
      if (!hasAp && !clock) continue;
      // (a range like "2-3 days" or a date's "10-12" never: one side at least a clock or an am/pm)
      var from = hhmm(m[1], m[2], m[3] || (ap2 && !m[3] && +m[1] <= +m[4] ? ap2 : '')), to = hhmm(m[4], m[5], ap2);
      if (from && to && from < to) return { from: from, to: to };
    }
    return null;
  }
  var P_AWB = /\b(?:awb|air ?way ?bill|way ?bill|tracking|track(?:ing)? id|consignment|shipment|docket|article|lr)\s*(?:no\.?|number|num|#|id)?\s*[:#.\-]?\s*(?:is\s+)?#?\s*((?=[A-Z0-9-]*\d{6})[A-Z]{0,5}\d[A-Z0-9-]{5,24})\b/i;
  function awbIn(doc) {
    var t = doc.flat.replace(/\s*\|\s*/g, ' : ');
    var m = P_AWB.exec(t);
    if (!m || /[x*•]{2}/i.test(m[1])) return '';
    return m[1].replace(/-+$/, '').toUpperCase();
  }
  // the courier's or shop's own tracking page, from the mail itself: on the sender's own domain (or the courier it
  // names), a path that tracks a parcel, an order or a return; never a click-counter, an image or an unsubscribe
  function trackLink(doc, courier) {
    var raw = String((doc.msg && (doc.msg.text || '') + ' ' + (doc.msg.html || '')) || '');
    var own = (doc.domain || '').split('.').slice(-((/\.(?:co|gov|org|net)\.in$/.test(doc.domain || '')) ? 3 : 2)).join('.');
    var hosts = [own].concat(courier ? courier.domains || [] : []).filter(Boolean);
    var re = /https?:\/\/([a-z0-9.-]+)(\/[^\s"'<>)\]]*)?/gi, m;
    while ((m = re.exec(raw))) {
      var host = lc(m[1]), path = m[2] || '';
      if (!hosts.some(function (h) { return host === h || host.slice(-(h.length + 1)) === '.' + h; })) continue;
      if (/^(?:cdn|img|images?|static|assets?|media|click|links?|t|e|em|email|go|ablink|mailer)\./.test(host)) continue;
      if (/unsubscribe|\.(?:png|jpe?g|gif|webp|svg)$|review|rate|feedback|survey/i.test(path.split(/[?#]/)[0])) continue;
      if (!/track|awb|shipment|consignment|order|return|reschedul|deliver|parcel|progress/i.test(path)) continue;
      // (the link as the mail gives it, for the person to open: kosh never fetches it)
      return m[0].length <= 300 ? m[0] : '';
    }
    return '';
  }
  // cash to pay at the door: only when the mail says it is cash (or pay) on delivery, and the sum it prints for it
  function codIn(doc) {
    var low = doc.low.slice(doc.bodyAt, doc.bodyAt + 6000);
    if (!/cash on delivery|\bcod\b|pay(?:able)? (?:on|at|after) (?:the time of )?delivery|pay (?:in cash|by cash|cash)\b|\bpay (?:₹|rs\.?|inr)\s?[\d,.]+\s*(?:in |by )?cash\b|to be (?:paid|collected) (?:at|on) (?:the time of )?delivery|amount to (?:be )?collect|cash to (?:be )?collect|collectable amount|keep (?:the )?(?:exact )?(?:change|cash|₹|rs\.?\s?\d)/.test(low)) return 0;
    if (/\bcod (?:is )?not available|\bno cash on delivery\b|\bprepaid\b(?![^.\n]{0,30}\bcod\b)/.test(low) && !/\bcod amount\b|cash on delivery amount|amount to (?:be )?(?:paid|collected)/.test(low)) return 0;
    var p = kv(doc, /(?:^|\b)(?:cod amount|cash on delivery(?: amount)?|amount (?:to be )?(?:paid|collected|payable)(?: (?:on|at) delivery)?|amount to pay|amount payable|to pay|pay on delivery|cash to (?:be )?collect(?:ed)?|collectable amount|^cod|amount due on delivery|net payable|total payable)$/);
    if (p && p.amt > 0) return p.amt;
    var m = /(?:cash on delivery|\bcod\b)\s*(?:amount)?\s*(?:of|:|-)?\s*(?:₹|rs\.?|inr)\s*(\d[\d,]*(?:\.\d{1,2})?)|(?:₹|rs\.?|inr)\s*(\d[\d,]*(?:\.\d{1,2})?)\s*(?:\(cod\)|in cash|by cash|cash)?\s*(?:to be (?:paid|collected)|at (?:the time of )?delivery|on delivery|when (?:it|your order|the parcel) arrives)|\b(?:pay|keep|collect)\s+(?:₹|rs\.?|inr)\s*(\d[\d,]*(?:\.\d{1,2})?)\s*(?:ready|in cash|by cash|cash|at|on|to)/i.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 6000));
    return m ? num(m[1] || m[2] || m[3]) : 0;
  }
  // the shop a courier's mail is about: as it names it ("your order from Example Store", "Seller: Example Store")
  function shopNamedBy(doc) {
    var h = doc.subject + '\n' + doc.flat.slice(doc.bodyAt, doc.bodyAt + 1500);
    var m = /\b(?:[Oo]rder|[Pp]ackage|[Pp]arcel|[Ss]hipment|[Cc]onsignment)s?\b[^\n]{0,50}?\b[Ff]rom\s+([A-Z][\w&'.-]*(?:\s+[A-Z][\w&'.-]*){0,4})/.exec(h) || /\b(?:[Oo]rder|[Pp]ackage|[Pp]arcel|[Ss]hipment|[Cc]onsignment)s?\s+(?:by|of)\s+([A-Z][\w&'.-]*(?:\s+[A-Z][\w&'.-]*){0,3})/.exec(h) || /\b[Yy]our\s+([A-Z][\w&'.-]*(?:\s+[A-Z][\w&'.-]*){0,3})\s+(?:order|package|parcel|shipment)\b/.exec(h) ||
      /(?:^|\n|\|)\s*(?:seller|shipper|sender|merchant|sold by|shipped by|consignor|from)\s*[:|-]\s*([A-Z][\w&'.-]*(?:\s+[A-Z][\w&'.-]*){0,4})/.exec(h) ||
      /\b(?:your )?return (?:to|for)\s+([A-Z][\w&'.-]*(?:\s+[A-Z][\w&'.-]*){0,3})/.exec(h);
    if (!m) return '';
    var n = trim(m[1].replace(/\s+(?:with|is|has|was|are|have|will|via|through|on|in|and|for|to|AWB|Order|Shipment)\b.*$/, ''));
    n = n.replace(/\.(?:in|com|co\.in)$/i, '');
    if (!n || n.length < 2 || courierNamed(n) || /^(?:Your|The|Our|This|Delivery|Courier|Order|Shipment|Package|Parcel|Customer|Item|Items)$/.test(n)) return '';
    return n;
  }
  function parcels(doc, ctx, od) {
    if (ctx.person || ctx.promo || ctx.nudge || ctx.verify || ctx.consent || ctx.letter) return [];
    // (a bank's, card's, wallet's, broker's or insurer's own mail is that account's: a card on its way is the bank's step)
    if (doc.inst && doc.inst.kind !== 'merchant') return [];
    var cr = courierOf(doc), shop = shipsShop(doc);
    // (a shop kosh knows that sends no parcel, a food order, a ride, a ticket, a stream: its "delivered" is its order's)
    if (!cr && !shop && shopOf(doc)) return [];
    var sj = lc(doc.subject);
    var body = withoutStrips(doc.low.slice(doc.bodyAt, doc.bodyAt + 2500));
    var hay = sj + '\n' + body;
    if (!/deliver|ship|dispatch|transit|on (?:its|the) way|arriv|pick(?:ed)? ?-?up|parcel|package|consignment|courier|\bawb\b|tracking|collect/.test(hay)) return [];
    // (a booking, a ticket, a ride or a stay: no parcel; a cab "arriving" is a driver)
    if (!cr && /\b(?:ride|trip|cab|driver|flight|pnr|boarding|check-?in|ticket|booking|reservation|table)\b/.test(sj) && !/\b(?:order|package|parcel|shipment)\b/.test(sj)) return [];
    // who may say a parcel's step: a courier or tracking platform, a shop that ships, a shop the order reading found, or
    // any sender whose mail names a tracking number beside the step
    var awb = awbIn(doc);
    if (!cr && !shop && !od.length && !awb && !SHIP_PLATFORM.test(doc.domain || '')) return [];
    var ret = P_RET.test(sj + '\n' + body.slice(0, 900));
    // the step: what the subject says, else what the body's opening says
    function stepIn(t) {
      // (kept for you to collect is where a missed delivery ends up: the later step)
      if (told(t, P_HELD) >= 0) return { step: 'held' };
      if (told(t, P_PICKFAIL) >= 0) return { step: 'attempted', ret: true };
      if (told(t, P_ATTEMPT) >= 0) return { step: 'attempted' };
      if (told(t, P_RESCHED) >= 0) return { step: 'rescheduled', ret: /pick ?-?up/.test(t) && ret };
      if (ret && told(t, P_PICKED) >= 0) return { step: 'picked-up', ret: true };
      if (ret && told(t, P_BOOKED) >= 0) return { step: 'pickup-booked', ret: true };
      if (told(t, P_DELIVERED) >= 0) return { step: 'delivered' };
      if (told(t, P_OUT) >= 0) return { step: 'out' };
      if (told(t, P_MOVING) >= 0 || (!ret && told(t, /\b(?:has been|was|successfully) picked ?-?up\b/) >= 0)) return { step: 'transit' };
      // ("Arriving tomorrow", "Expected delivery: 30 Oct" with nothing said of it moving: on its way only with that day)
      if (told(t, P_ETA) >= 0) return { step: 'transit', eta: true };
      return null;
    }
    // the step: what the subject says and what the body's opening says, the later of the two when they differ (a subject's
    // "will be delivered today" over a body's "Shipment is out for delivery"); a subject's expected day alone gives way
    var RANK = { transit: 1, out: 2, attempted: 3, rescheduled: 3, held: 4, delivered: 5, 'pickup-booked': 1, 'picked-up': 3 };
    var s1 = stepIn(sj), s2 = stepIn(body.slice(0, 1500));
    var st = !s1 ? s2 : !s2 ? s1 : (s1.eta && !s2.eta) || (!!s1.ret === !!s2.ret && RANK[s2.step] > RANK[s1.step]) ? s2 : s1;
    if (!st) return [];
    // (a mail asking for a rating or feedback on a delivery is the ask; the delivered mail before it was the step)
    if (/\brate (?:us|your|the)\b|\bhow was (?:your|the)\b|\bfeedback\b|\breview (?:your|the)\b/.test(sj)) return [];
    // (a parcel sent back to the seller after its attempts, "has been returned to the seller", comes to no door: the shop's)
    if (!st.ret && /\b(?:has been|have been|was|is being|is) returned to (?:the )?(?:seller|sender|shipper|origin|merchant)\b|\brto (?:initiated|delivered|in transit)\b/.test(hay)) return [];
    var order = (od[0] && od[0].order) || orderIdIn(doc);
    if (order && awb && order.replace(/[^A-Z0-9]/gi, '') === awb.replace(/[^A-Z0-9]/gi, '')) awb = '';
    if (!order && !awb) return [];
    var ev = { type: 'parcel', step: st.step };
    if (st.ret) ev.ret = true;
    if (order) ev.order = order;
    if (awb) ev.awb = awb;
    var named = cr && cr.kind === 'courier' ? cr : courierNamed(doc.subject + '\n' + doc.flat.slice(doc.bodyAt, doc.bodyAt + 3000));
    // (a courier's mail names the shop; a platform a store mails through writes under the store's own name)
    var shopName = cr ? ((cr.kind === 'platform' && hostedShop(doc)) || shopNamedBy(doc)) : ((od[0] && od[0].shop) || (shop && shop.name) || (shopGuess(doc) || {}).name || '');
    if (shopName && !(named && lc(shopName) === lc(named.name))) ev.shop = shopName;
    if (named) ev.courier = named.name;
    // where the step's words are, for its day, its window and its quote
    var flatLow = doc.low, at = -1, words = { attempted: st.ret ? P_PICKFAIL : P_ATTEMPT, held: P_HELD, rescheduled: P_RESCHED, 'picked-up': P_PICKED, 'pickup-booked': P_BOOKED, delivered: P_DELIVERED, out: P_OUT, transit: P_TRANSIT }[st.step];
    var bodyAt = told(withoutStrips(flatLow.slice(doc.bodyAt)), words);
    at = bodyAt >= 0 ? doc.bodyAt + bodyAt : told(flatLow.slice(0, doc.bodyAt), words);
    // (a parcel delivered back to the seller, a return's end or one sent back undelivered, is the shop's, not at your door)
    if (st.step === 'delivered' && at >= 0 && /\b(?:to|at) (?:the )?(?:seller|merchant|warehouse|origin|sender)\b|\breturn(?:ed)? (?:to|back to)\b|\brto\b/.test(lc(sentenceAt(doc, at).text))) return [];
    // the day a step is for, after the words that give it, wherever in the mail they first come with a day
    function dayAfter(re, span, ok) {
      var g = new RegExp(re.source, 'g'), m;
      while ((m = g.exec(flatLow))) {
        var to = m.index + m[0].length, d = parcelDay(doc, to, span);
        if (d && (!ok || ok(d))) return { d: d, at: to, pre: flatLow.slice(to, to + 40), w: m[0] };
        if (!m[0].length) g.lastIndex++;
      }
      return null;
    }
    var ahead = function (d) { return d >= doc.ref; }, dayAt = -1;
    if (st.step === 'out') ev.on = doc.ref;
    else if (st.step === 'pickup-booked') {
      // the pickup's own day: under a pickup label ("Pickup scheduled: Sat, 11 Oct, 10 AM - 6 PM"), or next to its words
      var pk = kv(doc, /\bpick ?-?up\b/);
      var day = (pk && pk.date) || labeledDate(doc, /\bpick ?-?up\b[^.\n|]{0,60}?\b(?:on|for|date|scheduled|slot|:)/) || (at >= 0 ? parcelDay(doc, at, 90) : '');
      // (a pickup is booked for the days ahead: a day before the mail, or months off, is some other date)
      if (day && (dayNum(day) < dayNum(doc.ref) - 1 || dayNum(day) > dayNum(doc.ref) + 30)) day = '';
      if (day) ev.on = day;
      var win = windowIn(((pk && pk.value) || '') + '\n' + (at >= 0 ? sentenceAt(doc, at).text + '\n' + doc.flat.slice(at, at + 200) : '') + '\n' + ((kv(doc, /\b(?:time ?)?slot\b|\bwindow\b/) || {}).value || ''));
      if (win) ev.win = win;
    } else if (st.step === 'transit') {
      // the day it is expected: "Arriving tomorrow", "Expected delivery: 29 Oct", "will be delivered by Fri, 30 Oct",
      // "should reach you by 6 Nov"
      var ex = dayAfter(/\b(?:arriving|arrives|expected (?:date of )?delivery(?: date)?|estimated (?:date of )?delivery(?: date)?|expected (?:to (?:be delivered|arrive|reach(?: you)?)|by|on)|delivery (?:expected|by|date)|(?:will|should|shall) be delivered|(?:will|should) (?:reach|arrive)(?: (?:you|at your (?:address|doorstep)))?|delivered by)\b/, 60, ahead);
      if (ex) {
        dayAt = ex.at;
        if (/^\s*[:|-]?\s*(?:by|before|on or before|latest by)\b/.test(ex.pre) || /\bby$/.test(ex.w) || /^\s*(?:between|from)\b/.test(ex.pre)) ev.by = lastDay(doc, ex.at, ex.d); else ev.on = ex.d;
      }
    } else if (st.step === 'rescheduled' || st.step === 'attempted') {
      var rs = dayAfter(/\b(?:rescheduled (?:to|for)|new (?:delivery|pick ?-?up) (?:date|slot)\s*[:|-]?|(?:re-?attempt(?:ed)?|try (?:again|to deliver(?: it)? again)|attempt (?:the )?(?:delivery |pick ?-?up |it )?again|make another (?:delivery |pick ?-?up )?attempt|next (?:delivery |pick ?-?up )?attempt)(?:\s+(?:the )?(?:delivery|pick ?-?up|it))?(?:\s+(?:on|is|by))?)/, 50, ahead);
      if (rs) { ev.on = rs.d; dayAt = rs.at; }
    } else if (st.step === 'delivered') {
      var dv = dayAfter(/\bdelivered(?: successfully)?\s+(?:on|at)\b/, 30, function (d) { return d <= doc.ref; });
      if (dv) ev.on = dv.d;
    }
    // (a window the mail gives for that day, "between 10:00 AM and 2:00 PM", "8:00 and 13:00")
    if (dayAt >= 0 && !ev.win) { var w2 = windowIn(doc.flat.slice(dayAt, dayAt + 90)); if (w2) ev.win = w2; }
    if (st.eta && !ev.on && !ev.by) return [];
    if (st.step === 'held') {
      var hu = dayAfter(/\b(?:collect(?: it)?|pick (?:it )?up|held|kept|available)\b[^.\n|]{0,60}?\b(?:by|before|till|until|on or before|within)\b|\bwill be returned to (?:the )?(?:sender|seller|shipper|origin)\b[^.\n|]{0,60}?\b(?:after|on|by)\b/, 30, ahead);
      if (hu) ev.holdUntil = hu.d;
    }
    if (st.step === 'attempted' || st.step === 'held') {
      // what happens next, as the mail says it
      var nx = /\b(?:will|shall|we['’]ll)\s+(?:be\s+)?(?:re-?attempt(?:ed)?|try (?:again|to deliver)|attempt (?:the )?(?:delivery |pick ?-?up |it )?again|make another (?:delivery |pick ?-?up )?attempt|deliver (?:it )?(?:again )?(?:tomorrow|on))|\bnext (?:delivery |pick ?-?up )?attempt\b|\bre-?attempt(?:ed)? (?:the )?(?:delivery |pick ?-?up )?(?:on|tomorrow|today|in)\b/.test(flatLow.slice(doc.bodyAt)) ? 'retry'
        : /\breschedul(?:e|ing)\b|\b(?:choose|select|pick) (?:a )?(?:new |convenient |another )?(?:delivery |pick ?-?up )?(?:date|slot|time)\b/.test(flatLow.slice(doc.bodyAt)) ? 'reschedule'
        : st.step === 'held' || /\bcollect (?:it|your (?:parcel|package|shipment|order|item))?\s*(?:from|at)\b|\bself[- ]?(?:collect|pick ?-?up)|\bvisit (?:the |our )?(?:nearest )?(?:branch|hub|facility|post office|cent(?:re|er))/.test(flatLow.slice(doc.bodyAt)) ? 'collect'
        : /\b(?:call|contact|reach|write to) (?:us|the delivery (?:agent|executive|partner|boy|associate)|our (?:[a-z]+ ){0,2}(?:team|support|service|care|helpline|cent(?:re|er)))|\bupdate (?:your )?(?:address|phone|contact|location)|\bshare (?:your )?(?:correct |complete )?(?:address|location)/.test(flatLow.slice(doc.bodyAt)) ? 'contact' : '';
      if (nx) ev.next = nx;
    }
    if (!st.ret && /^(?:transit|out|attempted|rescheduled|held)$/.test(st.step)) { var cod = codIn(doc); if (cod > 0) ev.cod = cod; }
    var link = trackLink(doc, named);
    if (link) ev.link = link;
    // the line the step was read from (never one with a code in it: quoteOf's guard)
    var q = at >= 0 ? (function () {
      var sn = sentenceAt(doc, at), line = trim(sn.text.replace(/\s*\|\s*/g, ' · '));
      if (SECRET_LINE.test(line) || /\botp\b/i.test(line)) return '';
      if (line.length <= 140) return line;
      var off = Math.max(0, Math.min(at - sn.s - 40, line.length - 138));
      return (off > 0 ? '…' : '') + line.slice(off, off + 136).trim() + '…';
    })() : '';
    ev.q = safeQuote(q || trim(doc.subject).slice(0, 140));
    return [ev];
  }
  // the last day of a range the words give ("between Oct 28 - Oct 30"), else the day found
  function lastDay(doc, at, first) {
    var ds = doc.toks.filter(function (t) { return t.t === 'DATE' && t.s >= at && t.s < at + 60; });
    return ds.length >= 2 && /^\s*(?:-|to|and|–)\s*$/.test(doc.flat.slice(ds[0].e, ds[1].s)) && ds[1].v > ds[0].v ? ds[1].v : first;
  }

  /* an IPO's step: applied, money blocked, allotted (in full or part), not allotted, unblocked */
  function ipos(doc, ctx) {
    var head = doc.head, l = doc.low.slice(0, 5000);
    if (!/\bipo\b|public issue|initial public offer|asba|allotment advice|basis of allotment/.test(head + ' ' + l.slice(0, 2000))) return [];
    if (/\bbonus\b|rights entitlement|buyback|offer for sale/.test(lc(doc.subject))) return [];
    var company = ipoCompany(doc);
    var out = [];
    var allotP = kv(doc, /shares allotted|allotted (?:shares|quantity)|no\.? of (?:equity )?shares allotted|number of (?:equity )?shares allotted|securities allotted/);
    // a count is a plain number in its cell: "Number of Equity Shares Allotted | 322"
    var nAllot = allotP ? (allotP.amt != null ? allotP.amt : (/^\s*(\d[\d,]*)\b/.test(allotP.value) ? num(/\d[\d,]*/.exec(allotP.value)[0]) : null)) : null;
    var m;
    if (nAllot === null && (m = /\b(\d[\d,]*)\s*(?:equity\s*)?shares?\s*(?:have|has)?\s*been\s*(?:partially\s*|fully\s*)?allotted/i.exec(doc.flat))) nAllot = num(m[1]);
    if (nAllot === null && (m = /(?:shares|securities)\s*allotted\s*[:\-]?\s*(\d[\d,]*)/i.exec(doc.flat))) nAllot = num(m[1]);
    if (nAllot === null && (m = /\b(?:been|were|was)\s+allotted\s+(\d[\d,]*)\s*(?:equity\s*)?shares?\b/i.exec(doc.flat))) nAllot = num(m[1]);
    if (/not allotted|non[\s-]?allot|no allotment|no shares (?:have been|were) allotted|could not be allotted|allotment not received|not (?:been )?received (?:an |any )?allotment|did not get (?:an |any )?allotment/.test(head + ' ' + l.slice(0, 1500)) && !(nAllot > 0)) nAllot = 0;
    var appliedP = kv(doc, /shares applied|bid quantity|quantity applied|applied for|number of equity shares applied/);
    var shares = appliedP ? num((/\d[\d,]*/.exec(appliedP.value) || [''])[0]) : 0;
    if (!shares && (m = /(?:for|of)\s+(\d[\d,]*)\s*(?:equity\s*)?shares/i.exec(doc.flat.slice(0, 2000)))) shares = num(m[1]);
    var adjP = kv(doc, /adjusted towards allotment|allotment amount|amount adjusted/);
    var unP = kv(doc, /amount unblocked|unblock(?:ed)? amount|amount (?:to be )?refunded|refund amount|released/);
    var holdP = kv(doc, /hold amount|blocked amount|amount blocked|bid amount|amount applied|application amount|amount invested/);
    var unAmt = unP && unP.amt > 0 ? unP.amt : null;
    if (unAmt === null) amts(doc).forEach(function (t) { if (unAmt === null && roleOf(doc, t) === 'unblock') unAmt = t.v; });
    var holdAmt = holdP && holdP.amt > 0 ? holdP.amt : null;
    if (holdAmt === null) amts(doc).forEach(function (t) { if (holdAmt === null && roleOf(doc, t) === 'block') holdAmt = t.v; });
    if (holdAmt === null && (m = /(?:of|for)\s+(₹|rs\.?|inr)\s*([\d,]+(?:\.\d{1,2})?)\s*has been\s*\*?accepted/i.exec(doc.flat))) holdAmt = num(m[2]);
    if (holdAmt === null && (m = /(₹|rs\.?|inr)\s*([\d,]+(?:\.\d{1,2})?)\s*(?:has been|is|was)\s+(?:blocked|put on hold|held)\b/i.exec(doc.flat))) holdAmt = num(m[2]);
    var dateP = kv(doc, /date of refund|unblock(?:ing)? date|refund date|date of unblock/);
    var unblockDate = dateP && dateP.date ? dateP.date : labeledDate(doc, /(?:date of unblock(?:ing)?|unblock(?:ed|ing)? (?:on|date|by)|will be unblocked (?:on|by)|unblocked on|date of refund)/);
    var isBank = doc.inst && doc.inst.kind === 'bank';
    if (nAllot !== null) {
      var ev = { type: 'ipo', action: nAllot > 0 ? 'allotted' : 'not-allotted', company: company };
      if (nAllot > 0) { ev.shares = nAllot; if (adjP && adjP.amt > 0) ev.amt = adjP.amt; } else if (allotP) { ev.shares = 0; if (holdAmt > 0) ev.amt = holdAmt; }
      out.push(ev);
      // what was held back comes free: done when the bank says so, promised when the registrar does
      var freed = unAmt !== null ? unAmt : (nAllot === 0 && holdAmt !== null && /available for use|unblocked|released/.test(l.slice(0, 1500)) ? holdAmt : null);
      if (freed > 0) {
        // (a registrar's advice that prints "Amount Unblocked, If any" is the money unblocked, rule 17: its footer's "amount
        // to be unblocked, if any, has not been unblocked … contact us" is boilerplate)
        var rtaSays = !isBank && unP && /amount unblocked|unblock(?:ed)? amount/.test(unP.key) && !/to be/.test(unP.key) && /allotment advice|unblocking intimation|refund intimation/.test(head + ' ' + l.slice(0, 1500)) &&
          // (…unless it says the unblocking is still to come: "will be unblocked by", "unblocking will be done", "pending")
          !/will be (?:unblocked|released|refunded)(?![^.\n]{0,40}if any)|unblocking (?:will|is|shall)|unblocking pending|pending (?:at|with) (?:the )?scsb|will be initiated|basis of allotment/.test(l.replace(/amount to be unblocked, if any, has not been unblocked/g, ''));
        // (or the advice says it plainly: "Refund/unblocked Amount, if any, has been remitted to your Bank Account")
        var saysDone = /\b(?:refund|unblock)\w*(?:\s*\/\s*\w+)?\s+amount\b[^.\n]{0,30}?(?:has been|have been)\s+(?:remitted|credited|unblocked|released|refunded)\b/.test(l);
        var done = rtaSays || saysDone || (isBank && /unblocked|available for use|released/.test(l.slice(0, 1500))) ||
          (!/to be (?:unblocked|refunded|released)|will be (?:unblocked|refunded|released)|unblocking (?:will|is|shall)|will be initiated|basis of allotment/.test(l.slice(0, 1500)) && ((unP && /unblocked|released|refunded/.test(unP.key) && !/to be|if any/.test(unP.key)) || /(?:has been|have been|was) (?:unblocked|released|refunded)/.test(l.slice(0, 1500))));
        if (done) out.push({ type: 'ipo', action: 'unblocked', company: company, amt: freed });
        else { var ex = { type: 'expect', dir: 'in', what: 'unblock', amt: freed, party: company }; if (unblockDate) ex.on = unblockDate; out.push(ex); }
      }
      return out;
    }
    if (isBank && holdAmt !== null && /accepted|blocked|request|hold/.test(head)) {
      var b = { type: 'ipo', action: 'blocked', company: company, amt: holdAmt };
      // (the account the money is held in, "Hold Account Number | xxxx4821": net worth counts it while it's held)
      var hac = kv(doc, /^hold account(?: number| no\.?)?$|^(?:bank )?account (?:number|no\.?) (?:blocked|on hold)$/), hd = hac ? /(\d{4})\s*$/.exec(hac.value) : null;
      if (hd) b.via = { kind: 'account', inst: doc.inst.short, last4: hd[1] };
      // the bank accepting the application is the application made: applied, and the money held for it
      if (/application[^.\n]{0,120}\b(?:has been |was |is )?accepted|application request:? accepted/.test(head)) {
        var ap = { type: 'ipo', action: 'applied', company: company, amt: holdAmt };
        if (shares) { ap.shares = shares; b.shares = shares; }
        return [ap, b];
      }
      if (shares) b.shares = shares;
      return [b];
    }
    if (/application|bid/.test(head) && /submitted|placed|received|accepted|successful/.test(head)) {
      var a = { type: 'ipo', action: 'applied', company: company };
      if (shares) a.shares = shares;
      if (holdAmt !== null) a.amt = holdAmt;
      else { var apA = kv(doc, /^(?:total )?amount(?: \(?(?:rs|inr|₹)\.?\)?)?$|^investment amount$|^bid value$/); if (apA && apA.amt > 0) a.amt = apA.amt; }
      return [a];
    }
    return [];
  }
  function ipoCompany(doc) {
    var p = kv(doc, /^company(?: name)?$|^issuer(?: name)?$|^issue name$|^name of (?:the )?(?:company|issue)$/);
    if (p) return trim(p.value);
    var t = doc.subject + '\n' + doc.flat.slice(doc.bodyAt, doc.bodyAt + 2500), m;
    if ((m = /(?:^|[-–:]\s*|\bof\s+|\bfor\s+)([A-Z][A-Z0-9&.,()' ]{2,70}?\b(?:LIMITED|LTD)\.?)(?=\s*(?:[-–:(_]|ipo\b|IPO\b|$))/.exec(doc.subject))) return trim(m[1]);
    if ((m = /^\s*([A-Za-z0-9&.,()' \-]{3,80}?)\s*[-–:]\s*(?:ipo|public issue)\b/i.exec(doc.subject))) return trim(m[1]);
    if ((m = /^\s*([A-Za-z0-9&.,()' \-]{3,80}?)\s*[-–:]\s*(?:ipo\s*)?(?:allotment|application|bid|refund|mandate)\b/i.exec(doc.subject)) && !/^(?:ipo|your|re|fwd|non|not|no)\b/i.test(m[1])) return trim(m[1]);
    if ((m = /\bof (?:the\s+)?([A-Z][A-Za-z0-9&.' \-]{2,80}?)\s+ipo\b/.exec(t))) return trim(m[1]);
    if ((m = /(?:ipo|public issue|initial public offer(?:ing)?)\s*(?:application\s*)?(?:of|for|in)\s+(?:m\/s\.?\s*)?([A-Za-z0-9&.,()' \-]{3,80}?)(?:\s+(?:is|has|was|ipo)\b|[.(\n"]|\s+-\s)/i.exec(t))) return trim(m[1].replace(/\s*-\s*ipo$/i, ''));
    if ((m = /\bfor\s+([A-Z][A-Z0-9&.' \-]{2,60}\b(?:LIMITED|LTD))\b/.exec(t))) return trim(m[1]);
    if ((m = /\b([A-Z][A-Z0-9&.' \-]{2,60}\b(?:LIMITED|LTD))\b/.exec(t))) return trim(m[1]);
    return '';
  }

  /* a dividend advice: which company, how much (net of TDS where it says), paid on what day */
  function dividends(doc, ctx) {
    var s = lc(doc.subject), head = doc.head;
    if (!/dividend|\bidcw\b/.test(s + ' ' + doc.lead.slice(0, 400))) return [];
    if (!/credit|paid|payment|intimation|remit|disburse/.test(head)) return [];
    if (/declared|record date|book closure/.test(s) && !/credit|paid|remit/.test(s)) return [];
    var company = '', m;
    // a company in capitals in the subject ("Dividend payment intimation - EXAMPLE STEEL LIMITED - Final Dividend")
    if ((m = /(?:^|[-–:]\s*)([A-Z][A-Z0-9&.,()' ]{2,70}?\b(?:LIMITED|LTD|LIMTIED)\.?)(?=\s*(?:[-–:]|$))/.exec(doc.subject))) company = trim(m[1]);
    // an IDCW: the scheme it was paid under ("under …", "for Example Equity Savings Fund - Monthly IDCW", or the scheme the
    // subject names after its dash)
    if (!company && /\bidcw\b/.test(s) && (m = /\bunder\s+([A-Z][\w&'.() \-]{3,100}?(?:IDCW|Fund|Plan))\b/.exec(doc.flat) || /\b(?:for|in)\s+([A-Z][\w&'.()\-]*(?: [A-Z][\w&'.()\-]*){0,10}? (?:Fund|Plan|Scheme))\b/.exec(doc.flat.slice(doc.bodyAt)) || /[-–:]\s*([A-Z][\w&'. ]{3,80}?\b(?:Fund|Plan|Scheme))\s*$/.exec(doc.subject))) company = trim(m[1]);
    if (!company && (m = /^\s*([A-Za-z0-9&.,()' \-]{3,80}?)\s*(?:[-–:]|\s)\s*(?:intimation|dividend|interim|final)\b/i.exec(doc.subject))) company = trim(m[1]).replace(/\s*[-–:]+$/, '');
    if (!company || /^(?:intimation|dividend|your|credit)/i.test(company)) {
      var first = doc.lines.slice(1, 6).filter(function (x) { return /\b(?:limited|ltd)\b/i.test(x) && x.length < 80; })[0];
      if (first) company = trim(first.split(' | ')[0].replace(/\s*CIN.*$/i, ''));
      else if ((m = /\b([A-Z][A-Za-z0-9&.' \-]{2,70}?\s(?:LIMITED|Limited|LTD|Ltd)\.?)\b/.exec(doc.flat))) company = trim(m[1]);
    }
    company = company.replace(/\bLimtied\b/i, 'Limited').replace(/\s+(?:cin|registered).*$/i, '');
    // (never the registrar that sent it, "KFin Technologies Ltd." signing the mail: no company at all beats the wrong one)
    if (company && doc.inst && /^(?:rta|depository)$/.test(doc.inst.kind) && (lc(company).indexOf(lc(doc.inst.short)) >= 0 || /\b(?:kfin|karvy|computer age|cams|link intime|bigshare|nsdl|cdsl)\b/i.test(company))) company = '';
    var net = kv(doc, /net (?:amount of )?dividend|net dividend|dividend amount \(?net|net amount|net payable|amount (?:of dividend )?(?:paid|credited|remitted)/);
    var gross = kv(doc, /gross (?:amount of )?dividend|gross dividend|dividend amount$|gross amount/);
    var amt = net && net.amt > 0 ? net.amt : gross && gross.amt > 0 ? gross.amt : null;
    if (amt === null) amts(doc).forEach(function (t) { var r = roleOf(doc, t); if (amt === null && (r === 'dividend' || r === 'moved') && r !== 'price') amt = t.v; });
    // "IDCW of Rs. 1,250.00 ... has been credited", "dividend of ₹216 has been paid"
    if (amt === null && (m = /\b(?:idcw|dividend)(?: amount| payout)?\s+of\s+(?:rs\.?|inr|₹)\s*(\d[\d,]*(?:\.\d+)?)(?![\d.,])(?!\s*(?:\/-\s*)?per (?:unit|share))/i.exec(doc.flat))) amt = num(m[1]);
    if (!(amt > 0)) return [];
    var ev = { type: 'dividend', company: company, amt: amt };
    var dp = kv(doc, /date of (?:credit|payment)|payment date|credit date|paid on|pay date|date of credit/);
    var d = dp && dp.date ? dp.date : labeledDate(doc, /(?:payment date|date of payment|credit date|paid on|credited on|date of credit|(?:credited|paid|transferred) to your [^.\n]{0,40}? on)/);
    if (!d && (m = /credited to your (?:registered )?bank account on\s+/i.exec(doc.flat))) { var dt = near(doc, 'DATE', m.index + m[0].length, 0, 10); if (dt) d = dt.v; }
    if (d) ev.date = d;
    return [ev];
  }

  /* a fixed or term deposit's step: booked, renewed, matured, closed */
  // who takes deposits: banks, and the finance companies and apps that book them
  var DEPOSIT_TAKER = /bajajfinserv|bajajfinance|shriramfinance|shriram|mahindrafinance|stablemoney|upswing|tatacapital|sundaramfinance|sundaramhome|pnbhousing|icicihfc|lichousing|hdfcltd|muthootfinance|indiapost|ippbonline|blostem|wint/;
  function deposits(doc, ctx) {
    var s = lc(doc.subject), head = doc.head;
    /* a post office small-savings deposit told by its own mail (a TDS certificate, a statement: "Senior Citizens Savings
       Scheme account no. XXXXXX5521 (Deposit Rs. 15,00,000, ROI 8.2% p.a., date of maturity 18-01-2029)"): facts about
       the deposit, never money that moved (its interest comes into the bank on its own day) */
    var ssm = /\b(senior citizens?'? savings scheme|scss|monthly income (?:scheme|account)|pomis|national savings certificate|nsc|kisan vikas patra|kvp|post office time deposit|mahila samman)\b/i.exec(doc.subject + ' ' + doc.flat.slice(doc.bodyAt, doc.bodyAt + 1500));
    if (ssm && (/indiapost|ippbonline/.test(doc.domain) || /\bpost office\b|department of posts|india post/i.test(doc.flat))) {
      var sp0 = /\b(?:deposit|principal|amount invested|investment)(?: amount)?\s*(?:of\s*)?[:\-]?\s*(?:rs\.?|inr|₹)\s*(\d[\d,]*(?:\.\d{1,2})?)/i.exec(doc.flat);
      if (sp0 && num(sp0[1]) >= 1000) {
        var sk = lc(ssm[1]), skind = /senior|scss/.test(sk) ? 'SCSS' : /monthly|pomis/.test(sk) ? 'POMIS' : /national|nsc/.test(sk) ? 'NSC' : /kisan|kvp/.test(sk) ? 'KVP' : /mahila/.test(sk) ? 'MSSC' : 'POTD';
        var sev = { type: 'deposit', action: 'facts', inst: 'India Post', kind: lc(skind), amt: num(sp0[1]) };
        var sno = /\b(?:account|a\/c)\s*(?:no\.?|number)?\s*[:\-]?\s*[x*•]*\d*?(\d{4})\b/i.exec(doc.flat);
        if (sno) sev.no = sno[1];
        var srt = /\b(?:roi|rate of interest|interest rate|rate)\s*[:\-]?\s*(\d{1,2}(?:\.\d{1,3})?)\s*%/i.exec(doc.flat);
        if (srt && +srt[1] > 0 && +srt[1] < 20) sev.rate = +srt[1];
        var smd = labeledDate(doc, /(?:date of maturity|maturity date|matures on|maturity)/);
        if (smd) sev.mat = smd;
        return [sev];
      }
    }
    // the words themselves ("fixed deposit"), or the short forms (FD, TD, RD) only from someone who takes deposits:
    // "Station Rd" in a hotel's address is a road, and a "security deposit" is a landlord's
    var taker = (doc.inst && /^(?:bank|lender)$/.test(doc.inst.kind)) || DEPOSIT_TAKER.test(doc.domain);
    // (a bank kosh has no entry for, that signs as one: "Example Small Finance Bank <customercare@example.com>", a
    // co-operative bank: its own name, from the name its mail is sent under)
    var bankName = !doc.inst && !personalMail(doc) ? (/^\s*"?([A-Z][A-Za-z.&' ]{1,40}?\s(?:small finance |co-?operative |urban co-?operative |payments )?bank(?: ltd\.?| limited)?)"?\s*</i.exec((doc.msg && doc.msg.from) || '') || [])[1] || '' : '';
    if (bankName) taker = true;
    // (a foreign-currency deposit an NRI keeps, "FCNR(B) deposit", is a term deposit in that currency)
    var named = /fixed deposit|term deposit|recurring deposit|\bfcnr\s*(?:\(b\))?\s*(?:deposit|fd|td)\b/.test(head) && !/\b(?:security|caution|refundable|rent(?:al)?|advance|earnest)\s+deposit/.test(head);
    // a Senior Citizens' Savings Scheme account (the post office's or a bank's): a deposit of its own kind
    var scss = /senior citizens?['’]?\s*savings scheme|\bscss\b/.test(lc(doc.subject) + ' ' + head);
    if (scss) named = true;
    var short = taker && /\b(?:FDs?|TDs?|RDs?|TDR|STDR)\b/.test(doc.subject + '\n' + doc.flat.slice(doc.bodyAt, doc.bodyAt + 2500));
    if (!named && !short) return [];
    if (!taker && !(doc.inst && /^(?:app|broker|wallet)$/.test(doc.inst.kind))) return [];
    if (/rates? (?:are|have been) revised|new (?:fd )?rates|book (?:an? )?(?:fd|fixed deposit) (?:now|today)|earn up ?to|interest rates? (?:on|for) (?:fixed|term)/.test(head)) return [];
    var lead = lc(doc.subject) + ' ' + doc.lead.slice(0, 350);
    var action = /premature|closed|closure|liquidat|encashed/.test(s) ? 'close' : /renew/.test(s) ? 'renew' : /matur/.test(s) ? 'mature' : /booked|opened|open|advice|created|confirmation|deposit (?:e-?)?receipt/.test(s) ? 'open' : '';
    // (a deposit's proceeds credited close it, early or at maturity: rule 8; a bank that "processed your Fixed Deposit
    // request" or sends its e-receipt opened it)
    if (!action) action = /premature closure|premat(?:ure)? proceeds|has been closed|closure of|liquidated/.test(lead) ? 'close' : /renew/.test(lead) ? 'renew' : /has matured|maturity proceeds/.test(lead) ? 'mature' : /booked|opened|opening|created|placed|deposit request and we have processed|processed the same successfully|deposit e-?receipt/.test(lead) ? 'open' : '';
    // money sent into a deposit's account ("TRF TO FD 5030...", "Debit for TD A/c ...") books it
    var intoDeposit = /\b(?:debited|debit|transfer(?:red)?|trf|tfr|towards)\b/.test(lead) && /\b(?:to|for|towards)\s*(?:\/\s*debit\s*for\s*)?(?:fd|td|tdr|stdr|rd|fixed deposit|term deposit|recurring deposit)\b|\b(?:fd|td|rd)\s*(?:a\/c|ac|acct|account|no\.?)\s*[:#]?\s*[x*]*\d{4,}/.test(lead);
    // a recurring deposit is paid into month by month: each debit is an instalment of the same deposit
    var rd = /\brd\b|recurring deposit/.test(lead);
    // (money sent into a deposit's account books it: the app shows the deposit from that day, before its advice comes.
    //  On purpose, against the rulebook's rule 8 — NEXT.md: eval counts the one event it costs as false. Don't "fix" it:
    //  engine-test/deposits.js builds on the booking, and the app would lose the deposit until the bank's advice came)
    if (!action && intoDeposit) action = 'open';
    if (rd && intoDeposit && action !== 'close' && action !== 'mature') action = 'instalment';
    // a tax form's acknowledgement (Form 15G or 15H received for the year) tells of the deposit: its principal, rate and
    // maturity, facts about it, never a booking (and its principal is no money that moved)
    if (/\bform\s*15\s*[gh]\b|\b15[gh]\b[^.\n]{0,40}\b(?:received|acknowledg|submitted)|tds exemption/.test(lead)) action = 'facts';
    // so does a bank's interest credit that prints the deposit beside it ("interest of Rs 17,500.00 on your NRE Term
    // Deposit A/c XX4410 (Principal Rs 10,00,000.00 @ 7.00%, maturing 01/03/2027)"): the deposit's facts; the interest
    // is the money that moved
    if (!action && /\binterest\b/.test(lead) && /\(\s*principal\b/i.test(doc.flat.slice(doc.bodyAt, doc.bodyAt + 1500))) { action = 'facts'; ctx.factsWithMove = true; }
    // (…and an SCSS account's TDS certificate, "Form 16A … (Deposit Rs. 15,00,000, ROI 8.2% p.a., date of maturity …)": its
    // interest line is the year's, the deposit's facts are the deposit)
    if (scss && /\bform\s*16\s*a\b|\btds certificate\b/.test(lead)) action = 'facts';
    if (!action) return [];
    var ev = { type: 'deposit', action: action };
    if (rd) ev.kind = 'rd';
    else if (scss) ev.kind = 'scss';
    var inst = doc.inst && doc.inst.kind === 'bank' ? doc.inst.short : (bankName ? trim(bankName.replace(/\s+(?:ltd\.?|limited)$/i, '')) : '');
    if (!inst && scss && (/(?:^|\.)indiapost\.gov\.in$/.test(doc.domain || '') || /\bdepartment of posts\b|\bindia post\b|\bpost office\b/.test(doc.low.slice(doc.bodyAt, doc.bodyAt + 3000)))) inst = 'India Post';
    if (inst) ev.inst = inst;
    var noP = kv(doc, /(?:term |fixed )?deposit (?:no|number|account)|fd (?:no|number|a\/c|account)|td (?:no|number)|fdr (?:no|number)|deposit receipt (?:no|number)/);
    var no = noP ? (noP.mask || (/\d{3,}/.exec(noP.value) || [''])[0].slice(-4)) : '';
    var m;
    if (!no && (m = /\b(?:premat(?:ure)?|maturity) proceeds\s*[:\-]?\s*(\d{4,})/i.exec(doc.flat))) no = m[1].slice(-4);
    // (a number masked in its middle, "Fixed Deposit No. 4500XXXX2231", "FDR No: SF2XXXX7711": the digits after the mask)
    if (!no && (m = /(?:fixed deposit|term deposit|recurring deposit|deposit|\bfdr|\bfd|\btd|\brd)\s*(?:account\s*|a\/c\s*|receipt\s*)?(?:no\.?|number|#)?\s*[:.\-]?\s*(?:[a-z0-9]*?[x*•]{2,})?\s*(\d{3,})\b/i.exec(doc.flat))) no = m[1].slice(-4);
    if (!no && (m = /[x*]{2,}(\d{3,})/i.exec(doc.files))) no = m[1].slice(-4);
    if (!no && scss && (m = /\b(?:scheme|scss)\s*(?:account|a\/c)?\s*(?:no\.?|number)?\s*[:.\-]?\s*[x*•]*(\d{3,})\b/i.exec(doc.flat))) no = m[1].slice(-4);
    if (no) ev.no = no;
    // whose: the first (or sole) holder its advice prints ("First holder: PRIYA EXAMPLE  Second holder: …")
    var fhm = /\bfirst (?:\/\s*sole )?holder(?:['’]s name)?\s*[:\-|]\s*([A-Za-z][A-Za-z.]*(?:[ \t][A-Za-z][A-Za-z.]*){0,3}?)(?=[ \t]{2,}|\s*\||\s+(?:second|joint|2nd)\b|\s*[\n,;]|$)/i.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 4000)) ||
      (kv(doc, /^(?:first|sole|primary) holder(?:['’]s)?(?: name)?$/) ? [null, kv(doc, /^(?:first|sole|primary) holder(?:['’]s)?(?: name)?$/).value] : null);
    if (fhm) { var fhn = personName(fhm[1]); if (fhn) ev.holder = fhn; }
    var pp = kv(doc, action === 'open' ? /(?:deposit|principal|fd|td) amount|^principal|amount of deposit|^amount$/ : /(?:deposit|principal|fd|td) amount|^principal|amount of deposit/), mp = kv(doc, /maturity (?:amount|value)/);
    var princ = pp && pp.amt > 0 ? pp.amt : null, mat = mp && mp.amt > 0 ? mp.amt : null;
    amts(doc).forEach(function (t) { var r = roleOf(doc, t); if (r === 'maturity' && mat === null) mat = t.v; if (r === 'principal' && princ === null) princ = t.v; });
    // ("(Principal Rs 5,00,000.00, ROI 7.75% p.a., …)": a figure in brackets after its word)
    if (princ === null && (m = /\b(?:principal|deposit amount)\s*(?:amount)?\s*[:\-]?\s*(?:rs\.?|inr|₹)\s*(\d[\d,]*(?:\.\d{1,2})?)/i.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 3000)))) princ = num(m[1]);
    // ("(Deposit Rs. 15,00,000, ROI 8.2% p.a., …)": the deposit's figure in brackets)
    if (princ === null && (m = /\(\s*deposit\s*[:\-]?\s*(?:rs\.?|inr|₹)\s*(\d[\d,]*(?:\.\d{1,2})?)/i.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 3000)))) princ = num(m[1]);
    if (princ === null && (action === 'open' || action === 'renew')) { var t0 = amts(doc).filter(function (t) { return (t.role === 'moved' || t.role === 'other') && inBody(doc, t); })[0]; if (t0) princ = t0.v; }
    // ("Maturity on 08-01-2028: Rs.84,450.00": what it pays then)
    if (mat === null && (m = /\bmaturity(?: amount| value)?(?:\s+on\s+\d{1,2}[-\/.]\d{1,2}[-\/.]\d{2,4})?\s*[:\-]\s*(?:rs\.?|inr|₹)\s*(\d[\d,]*(?:\.\d{1,2})?)/i.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 3000))) && num(m[1]) > (princ || 0)) mat = num(m[1]);
    if (princ !== null) ev.amt = princ;
    if (mat !== null) ev.matAmt = mat;
    // a deposit in another currency ("Principal: USD 20,000.00"): its figures are in that currency, never rupees
    if (pp && pp.amt > 0 && pp.amtCur && princ === pp.amt) { ev.cur = pp.amtCur; if (mat !== null && !(mp && mp.amtCur === pp.amtCur)) delete ev.matAmt; }
    var rp = kv(doc, /^(?:rate of )?interest(?: rate)?$|^roi$|^rate$|interest rate/);
    var rate = rp ? /(\d{1,2}(?:\.\d{1,3})?)\s*%?/.exec(rp.value) : /(?:rate of interest|interest rate|roi|interest)\s*(?:\(p\.?a\.?\))?\s*[:\-|]?\s*(\d{1,2}(?:\.\d{1,3})?)\s*%/i.exec(doc.flat);
    if (!rate) rate = /\bat\s+(\d{1,2}(?:\.\d{1,3})?)\s*%\s*(?:p\.?\s*a\.?|per annum|a year)/i.exec(doc.flat);
    // ("Principal Rs 10,00,000.00 @ 7.00%": the rate after the principal)
    if (!rate) rate = /\bprincipal\b[^()\n]{0,40}?@\s*(\d{1,2}(?:\.\d{1,3})?)\s*%/i.exec(doc.flat);
    if (rate && +rate[1] > 0 && +rate[1] < 20) ev.rate = +rate[1];
    var sp = kv(doc, /deposit date|value date|date of deposit|opened on|booking date|start date|date of opening|effective date|renewed on|renewal date/);
    var mdp = kv(doc, /maturity date|date of maturity|matures on/);
    var start = sp && sp.date ? sp.date : labeledDate(doc, /(?:deposit date|value date|date of deposit|opened on|booking date|start date|date of opening|effective date|renewed on|renewal date|booked on)/);
    var md = mdp && mdp.date ? mdp.date : labeledDate(doc, /(?:maturity date|date of maturity|matures on|mature on|maturing(?: on)?|maturity on)/);
    // a date found in prose ("renewed on or after May 1, 2014" in the terms) is only the start when it is near the mail
    if (start && !(sp && sp.date) && doc.ref && Math.abs(dayNum(start) - dayNum(doc.ref)) > 120) start = '';
    // (a notice that the deposit "will be renewed on" or "will mature on" a day names its maturity: rule 19)
    var willD = labeledDate(doc, /(?:will be (?:auto-?)?renewed on|will matur(?:e|ing) on|due for (?:renewal|maturity) on)/);
    if (willD && (action === 'renew' || action === 'mature')) { if (!md) md = willD; if (start === willD) start = ''; }
    if (start) ev.start = start;
    if (md) ev.mat = md;
    return [ev];
  }

  /* insurance: a policy issued, a premium paid, a premium due, renewed, lapsed */
  var INSURERS = (function () {
    var out = [];
    (E.INST || []).forEach(function (i) {
      if (i.kind !== 'insurer' || /policybazaar|bima central|insurance ?dekho|renewbuy|turtlemint|coverfox|ditto|paybima|bankbazaar|repository/i.test(i.name)) return;
      uniq([i.short, i.name].filter(Boolean)).forEach(function (n) {
        var k = lc(n).replace(/\s+(?:insurance|life insurance|general insurance|health insurance)?\s*(?:co(?:mpany)?\.?\s*)?(?:ltd\.?|limited)?$/, '').trim();
        if (k.length >= 4 && !/^(?:icici|hdfc|sbi|tata|bajaj|axis|kotak|max|star|care|aditya birla|reliance|future|bharti|edelweiss|iffco|liberty|magma|manipal|national|new india|oriental|united india|raheja|royal|shriram|universal|zuno|go digit|acko|niva)$/.test(k)) out.push([k, i.short]);
      });
    });
    // (an insurer still printed under its former name on a broker's mail: "Reliance General Insurance Company Ltd",
    // "your Reliance Travel Insurance", general insurance only: Reliance's life arm names itself "Nippon Life")
    out.push(['reliance general', 'Reliance General'], ['reliance travel', 'Reliance General'], ['reliance health', 'Reliance General'], ['reliance motor', 'Reliance General']);
    out.sort(function (a, b) { return b[0].length - a[0].length; });
    return out;
  })();
  // (asked up to six times of one mail: worked out once, by the mail and what it reads from)
  var INS_MEMO = { doc: null, subject: null, flat: null, inst: null, out: '' };
  function insurerIn(doc) {
    var M = INS_MEMO;
    if (M.doc === doc && M.subject === doc.subject && M.flat === doc.flat && M.inst === doc.inst) return M.out;
    var out = insurerInOnce(doc);
    INS_MEMO = { doc: doc, subject: doc.subject, flat: doc.flat, inst: doc.inst, out: out };
    return out;
  }
  function insurerInOnce(doc) {
    if (doc.inst && doc.inst.kind === 'insurer' && !/policybazaar|bima central|ditto|renewbuy|turtlemint|coverfox|insurance ?dekho/i.test(doc.inst.name)) return doc.inst.short;
    var lt = lc(doc.subject + ' ' + doc.flat.slice(0, 3000));
    var best = null, at = 1e9;
    for (var i = 0; i < INSURERS.length; i++) {
      var n = INSURERS[i][0], k = lt.indexOf(n);
      while (k >= 0 && (/[a-z0-9]/.test(lt.charAt(k - 1)) || /[a-z0-9]/.test(lt.charAt(k + n.length)))) k = lt.indexOf(n, k + 1);
      if (k >= 0 && k < at) { at = k; best = INSURERS[i][1]; }
    }
    if (best) return best;
    // an insurer kosh has no entry for, or one renamed since ("Bajaj General Insurance" writing from its new domain): the
    // name its mail is sent under, when that name says it insures (never an aggregator's, a bank's, a broker's or a shop's)
    var dn = /^\s*"?([^"<]{2,70}?)"?\s*</.exec((doc.msg && doc.msg.from) || '');
    if (dn && /\b(?:insurance|assurance)\b/i.test(dn[1]) && !/policybazaar|bima|dekho|renewbuy|turtlemint|coverfox|ditto|bankbazaar|\bbank\b|broker|repository|marketing|advisor/i.test(dn[1]) &&
        !(doc.inst && /^(?:bank|card|wallet|app|broker|merchant|gateway|rta|amc)$/.test(doc.inst.kind)) && !personalMail(doc)) return trim(dn[1].replace(/^the\s+/i, '').replace(/\s+(?:co(?:mpany)?\.?\s*)?(?:ltd\.?|limited)\.?$/i, ''));
    return '';
  }
  /* A bank's or card's mail that isn't a plain payment: a cheque in clearing (it will be debited), a cheque or a NACH
     debit returned unpaid (a mandate failed, and the return charge that was debited), a recurring payment that
     failed, a payment that failed and was credited back, a card bill now overdue, a purchase converted to EMI (the
     instalments to come, never a second spend), a late fee (the fee, never the bill it's for), a balance told on its
     own, an account's e-statement, a card blocked or activated. Null when the mail is none of these. */
  function bankSteps(doc, ctx) {
    if (!(doc.inst && /^(?:bank|card|app|wallet)$/.test(doc.inst.kind))) return null;
    var s = lc(doc.subject), lead = s + ' ' + lc(doc.flat.slice(doc.bodyAt, doc.bodyAt + 600)).replace(/\s+/g, ' ');
    var amtIn = function (re) { var p = kv(doc, re); if (p && p.amt > 0) return p.amt; var m = new RegExp('(?:' + re.source + ')[^₹\\d\\n]{0,40}?(?:rs\\.?|inr|₹)\\s*(\\d[\\d,]*(?:\\.\\d+)?)', 'i').exec(doc.flat); return m ? num(m[1]) : 0; };
    var first = function () { var a = amts(doc).filter(function (t) { return inBody(doc, t); })[0]; return a ? a.v : 0; };
    // (a customer's id is no account's number: "your e-statement for Customer ID- XXXXX527" names no account)
    var notAcct = function (t) { return /\b(?:customer\s*(?:id|no\.?|number)|cust\.?\s*id|crn|cif|client\s*id|folio(?:\s*no\.?)?|dp\s*id|ucic)\b[\s:|.\-#]*$/i.test(doc.flat.slice(Math.max(0, t.s - 30), t.s)); };
    var mask = function () { var m = doc.toks.filter(function (t) { return t.t === 'MASK' && inBody(doc, t) && !notAcct(t); })[0]; return m ? viaFor(doc, m, '') : { kind: /card/.test(s) ? 'card' : 'account', inst: doc.inst.short }; };
    // a charge debited alongside (a return or bounce charge, a late fee): the money that did move
    var feeMove = function (re) {
      var f = amtIn(re);
      if (!(f > 0)) return [];
      var v = mask(); var d = labeledDate(doc, /debited on|charged on/);
      var e = { type: 'move', dir: 'out', amt: f, date: d || doc.ref, via: v, purpose: 'fee' };
      if (v.kind === 'card' && /late (?:payment )?fee/.test(lead)) e.party = 'Late payment fee';
      return [e];
    };
    if (/cheque|chq/.test(lead) && /(?:received|presented) (?:in|for) clearing|in clearing/.test(lead) && !/returned|bounced|dishono|has been (?:paid|debited|cleared|credited)|(?:paid|debited) from/.test(lead)) {
      var ca = first();
      if (ca > 0) return { events: [{ type: 'expect', dir: 'out', what: 'debit', amt: ca, party: doc.inst.short }] };
    }
    if (/\b(?:nach|ecs|e-?mandate|auto-?debit|si)\b[^.]{0,80}\b(?:returned|bounced|dishono(?:u)?red|unpaid|rejected)\b|\breturned unpaid\b/.test(lead) && !/cheque|chq/.test(lead)) {
      var na = amtIn(/nach debit of|ecs debit of|debit of|mandate of|amount of/) || first();
      var mf = { type: 'mandate', action: 'failed', amt: na };
      var pm = /presented by ([A-Z][A-Za-z0-9&.' ]{2,50}?)(?: on| for|,|\.)/.exec(doc.flat); if (pm) mf.party = trim(pm[1]);
      return { events: [mf].concat(feeMove(/return charges?|bounce charges?|charges? of|penalty of/)), failedOk: true };
    }
    if (/cheque|chq/.test(lead) && /returned|bounced|dishono/.test(lead)) return { events: [{ type: 'noise', reason: 'failed' }].concat(feeMove(/return charges?|bounce charges?|charges? of/)), failedOk: true };
    if (/recurring (?:payment|mandate)|e-?mandate|standing instruction|auto-?pay|autopay|subscription/.test(lead) && /unsuccessful|failed|could not be (?:processed|completed)|declined/.test(lead)) {
      var ra = first();
      var rf = { type: 'mandate', action: 'failed' }; if (ra > 0) rf.amt = ra;
      var tow = /(?:towards|to|for) ([A-Z][A-Za-z0-9&.' ]{2,40}?)(?: on| of| for|,|\.| using)/.exec(doc.flat.slice(doc.bodyAt)); if (tow) rf.party = trim(tow[1]);
      return { events: [rf], failedOk: true };
    }
    // a payment that failed, its money already back in the account
    if (/(?:failed|could not be (?:completed|processed)|unsuccessful|declined)/.test(lead) && /(?:has been|was|is) (?:credited|refunded|reversed) back|credited back|amount (?:has been )?reversed|refunded to your/.test(factual(lead, true))) {
      var fa = first();
      if (!(fa > 0)) return null;
      var bd = labeledDate(doc, /credited back to your [^.\n]{0,40}? on|credited back on|reversed on|refunded on/);
      return { events: [{ type: 'move', dir: 'in', amt: fa, date: bd || doc.ref, via: mask(), purpose: /\brefund/.test(lead) ? 'refund' : 'reversal' }], failedOk: true };
    }
    if (/card/.test(lead) && /\b(?:is |now )?overdue\b|past due|missed (?:your )?(?:card )?payment/.test(s + ' ' + lead.slice(0, 300)) && !/late (?:payment )?fee (?:of [^.]{0,30})?(?:has been |was )?(?:charged|levied|debited)/.test(lead)) {
      var oa = amtIn(/payment of|amount (?:due|overdue)|total (?:amount )?due|overdue amount|minimum (?:amount )?due/) || first();
      var od = { type: 'due', what: 'card', payee: doc.inst.short }; if (oa > 0) od.amt = oa;
      var odd = labeledDate(doc, /was due on|due on|due date/); if (odd) od.due = odd;
      var ov = mask(); if (ov.last4) od.via = { kind: 'card', last4: ov.last4 };
      return { events: [od] };
    }
    if (/late (?:payment )?fee/.test(lead) && /(?:charged|levied|debited)/.test(lead)) return { events: feeMove(/late (?:payment )?fee of|late (?:payment )?fee|fee of/) };
    if (/converted (?:in)?to (?:an? )?(?:easy|flexi|smart)?emi|emi conversion|has been (?:successfully )?converted/.test(lead) && /\b(?:easy|flexi|smart)?emi\b/.test(lead)) {
      var ea = amtIn(/monthly emi|emi amount|instal+ment amount|emi of/);
      if (!(ea > 0)) return { events: [{ type: 'noise', reason: 'service' }] };
      var ed = labeledDate(doc, /first emi date|first instal+ment|emi (?:will be )?(?:start|due) on|starting/);
      var de = { type: 'due', what: 'emi', amt: ea, payee: doc.inst.short }; if (ed) de.due = ed;
      return { events: [de] };
    }
    // a card's balance update (RBI's monthly notice: "Last statement balance … Current balance … Payment due date"): no
    // statement, the card's balance today and the last statement's bill to pay by its day
    if (/\bbalance update\b/.test(s) && !/statement/.test(s) && doc.inst.kind === 'card') {
      var cbv = amtIn(/current balance|total outstanding(?: balance)?/), lsb = amtIn(/last statement balance/), bu4 = mask(), bue = [];
      if (cbv > 0) bue.push({ type: 'balance', amt: cbv, via: { kind: 'card', inst: doc.inst.short, last4: bu4.last4 || '' } });
      var bud = labeledDate(doc, /payment due date|\bdue date|minimum payment due|payment due/);
      if (lsb > 0 && bud) { var bdu = { type: 'due', what: 'card', payee: doc.inst.name || doc.inst.short, amt: lsb, due: bud }; if (bu4.last4) bdu.via = { kind: 'card', last4: bu4.last4 }; bue.push(bdu); }
      /* what came in since the last statement, as the issuer counts it ("Last statement balance INR 12,300.00 closing
         date 01-Oct-2026 · Recent credits INR 12,300.00 since 02-Oct-2026"): the issuer's word on how much of that bill
         is paid, as of this mail. It moves no money of its own (the payment is the bank's debit, when kosh has it) */
      // (its own line, not the notice's opening words "along with recent credits and debits")
      var rcp = kvAll(doc, /^\W*(?:recent (?:credits|payments)|(?:payments?|credits?) (?:received )?since (?:the |your )?last statement)\W*$/i).filter(function (q) { return q.amt >= 0; })[0];
      var rcm = rcp ? null : /(?:^|\n)[\s|]*(?:recent (?:credits|payments)|(?:payments?|credits?) (?:received )?since (?:the |your )?last statement)[\s|:\-]{0,16}(?:rs\.?|inr|₹)\s*(\d[\d,]*(?:\.\d+)?)/i.exec(doc.flat);
      var rcv = rcp ? +rcp.amt || 0 : rcm ? num(rcm[1]) : 0;
      // (on the balance it prints, else on the bill it restates; with neither, nothing to hang it on)
      if (lsb > 0 && rcv > 0 && bue.length) {
        var rcs = labeledDate(doc, /recent (?:credits|payments)[\s\S]{0,60}?\bsince\b/), lsc = labeledDate(doc, /closing date|statement date/);
        bue[0].stmtBal = lsb; bue[0].credits = rcv;
        if (rcs) bue[0].since = rcs;
        if (lsc) bue[0].closed = lsc;
      }
      bue.forEach(function (e) { if (e.via && !e.via.last4) delete e.via.last4; });
      if (bue.length) return { events: bue };
    }
    if (/\bbalance\b/.test(s) && !/statement|update|limit|minimum|low/.test(s)) {
      var bp = kv(doc, /balance/);
      var bv = bp && bp.amt > 0 ? bp.amt : 0, bm;
      if (!bv && (bm = /\bbalance\b[^₹\n]{0,90}?\b(?:is|:)\s*(?:rs\.?|inr|₹)\s*(\d[\d,]*(?:\.\d+)?)/i.exec(doc.flat))) bv = num(bm[1]);
      if (bv > 0) { var bvia = mask(); if (bvia.kind === 'card') bvia.kind = 'account'; return { events: [{ type: 'balance', amt: bv, via: bvia }] }; }
    }
    // an account's e-statement (the PDF is read on its own): the account, and the closing balance when it's printed
    // ("Transaction summary for your A/c XX4410" over one debit's alert is that debit, not a statement)
    // (a week's or a month's summary is one still: "in the past week your account was credited with … and debited with …")
    var txSum = /transaction summary/.test(s) && (/attached|enclosed|\bpdf\b|weekly|monthly|daily|\bpast (?:week|month)\b|this (?:week|month)|closing balance|total (?:debits|credits)/.test(s + ' ' + lead) || !/(?:has been|is|was|were) (?:debited|credited)\b|\b(?:debited|credited) (?:with|by|for)\b/.test(lead));
    if ((/statement/.test(s) || txSum) && !/credit card|card statement|card ending|\bcard\b.{0,20}(?:xx|•|\*)/.test(lead) && doc.inst.kind === 'bank' && !/\bdue\b/.test(s)) {
      var sv = mask(); sv.kind = 'account';
      // (the account's digits may be only in the subject: "Statement for Account Number XXXXXXX4410"; never a product's, "Maxx2026")
      if (!sv.last4) { var sm4 = /(?:^|[^a-z0-9])[x*•]{2,}(\d{4})\b/i.exec(doc.subject); if (sm4) sv.last4 = sm4[1]; }
      // (or printed whole in the bank's own sentence: "your account statement for A/C 10012345678242")
      if (!sv.last4) { var sw4 = /\bstatement\b[^\n.]{0,40}\b(?:a\/c|account|acct)(?:\s*(?:no\.?|number))?[\s:.-]*\d{5,14}(\d{4})\b/i.exec(lead); if (sw4) sv.last4 = sw4[1]; }
      var se = { type: 'statement', via: sv };
      var cl = kv(doc, /^closing balance|closing bal/); if (cl && cl.amt != null) se.close = cl.amt;
      var pd = periodIn(doc); if (pd) { se.from = pd.from; se.to = pd.to; }
      // (the month's interest printed in the mail's summary, "Monthly Interest Received in Sep'26 | ₹33.00", is money
      // that came in; the year's total beside it is not)
      var mi = kv(doc, /^monthly interest (?:received|credited|earned|paid)\b/);
      // (on the last day of the month it names, "in Sep'26", the month the bank paid it in, not the day of the mail)
      var miD = doc.ref, miM = mi ? /\b(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\W{0,2}(\d{2}|\d{4})\b/i.exec(mi.key) : null;
      if (miM) { var mo = 'janfebmaraprmayjunjulaugsepoctnovdec'.indexOf(miM[1].toLowerCase()) / 3 + 1, yr = +miM[2] < 100 ? 2000 + +miM[2] : +miM[2]; var last = new Date(Date.UTC(yr, mo, 0)).toISOString().slice(0, 10); if (last <= doc.ref) miD = last; }
      if (mi && mi.amt > 0 && !mi.amtCur) return { events: [se, { type: 'move', dir: 'in', amt: mi.amt, date: miD, via: Object.assign({}, sv), purpose: 'interest', conf: 'medium' }] };
      return { events: [se] };
    }
    if (/card/.test(s) && /\b(?:blocked|hotlisted|hot-?listed|deactivated|frozen)\b/.test(s + ' ' + lead.slice(0, 300))) return { events: [{ type: 'noise', reason: 'security' }] };
    if (/card/.test(s) && /\b(?:is now active|has been activated|activated successfully|activation (?:is )?successful)\b/.test(s + ' ' + lead.slice(0, 300))) { var av = mask(); av.kind = 'card'; return { events: [{ type: 'account', step: 'activated', via: av }] }; }
    return null;
  }
  /* Investing, borrowing and tax mail that says one plain thing, read for what it is (the sender's kind decides which
     way money went: a lender, a broker, a platform or the tax department "receiving" your money is money out of you).
     Mutual-fund confirmations with a scheme, units and NAV are funds()'s; this is everything around them: an order
     placed at a platform (a promise), a SIP cancelled, a holdings or capital-gains statement, a contract note (its
     trades are in the PDF), a trade confirmed, money added to a broker or a platform, rights entitlements (no money),
     a pension contribution or balance, a loan disbursed, an EMI paid, due or bounced, a prepayment, a tax demand, a
     crypto or gold purchase. Null when the mail is none of these. */
  /* An SIP that goes on, changed: "stepped up from ₹3,000 to ₹4,000 … applies from 05 Oct 2026" (action "changed": amt
     the new sum, was the old, date the first instalment at it), "paused … no instalments until 05 Jan 2027" ("paused":
     date the day they resume), "switched from <fund A> to <fund B>" ("switched": party the fund it goes to now, fromFund
     the one it left, date the first instalment there). Only what has been done: an offer to step up, a request received
     or a change that "will be" made is none of these. Null otherwise (a cancelled SIP is investSteps' own). */
  function sipChange(doc, lead, k, investing) {
    if (!((/\bsip\b/.test(lead) && !/stock sip/.test(lead)) || /systematic investment/.test(lead))) return null;
    // (a sender kosh doesn't know must say it of yours: "your SIP …")
    if (!investing && !/\byour (?:monthly |weekly |quarterly )?(?:sip|systematic investment)/.test(lead)) return null;
    // (never a change still to come or only asked for, an offer to make one, nor a cancellation: that one stops it)
    if (/will be (?:paused|stepped up|increased|switched|changed|revised)|request (?:has been )?(?:received|submitted|placed)|\bwhy not\b|\bapply now\b/.test(lead) ||
        /(?:has been |is |was )(?:cancelled|canceled|stopped|terminated)\b|cancellation (?:is )?(?:successful|processed|confirmed)/.test(lead)) return null;
    var body = doc.flat.slice(doc.bodyAt, doc.bodyAt + 900);
    var AMT = '(?:rs\\.?|inr|₹)\\s*(\\d[\\d,]*(?:\\.\\d+)?)';
    var FUND = '([A-Z][\\w&\'.() \\-]{3,90}?(?:Fund|Plan|ETF|FoF)(?:\\s*-\\s*(?:Direct|Regular)(?:\\s+Plan)?)?(?:\\s*-?\\s*(?:Growth|IDCW))?)';
    var at = function (re) { return labeledDate(doc, re); };
    var inFund = new RegExp('\\b(?:in|of|for)\\s+' + FUND).exec(body);
    var monthly = /\bmonthly\b|every month|per month|\/month/.test(lead) ? 'month' : '';
    var ev = null, m;
    if (/stepped[- ]up|step[- ]up (?:is |has been )?(?:successful|registered|activated|confirmed|processed|done|applied)|top[- ]up (?:has been |is )?(?:registered|activated|successful|processed|applied)|amount (?:has been |is |was )?(?:changed|increased|revised|updated|modified|raised)|(?:has been|was) (?:increased|revised|changed|modified|raised) (?:from|to)\b/.test(lead)) {
      var ft = new RegExp('from\\s*' + AMT + '\\s*(?:\\/-)?\\s*to\\s*' + AMT, 'i').exec(body);
      var nw = ft ? num(ft[2]) : ((m = new RegExp('(?:increased|revised|changed|raised|stepped up|updated|modified) to\\s*' + AMT + '|new (?:sip |instal+ment )?amount\\s*(?:is|:|of)?\\s*' + AMT, 'i').exec(body)) ? num(m[1] || m[2]) : 0);
      if (!(nw > 0)) return null;
      ev = { type: 'mandate', action: 'changed', amt: nw };
      if (ft) ev.was = num(ft[1]);
      var cd = at(/applies from|applicable from|effective (?:from|date)|with effect from|w\.?e\.?f\.?|starting(?: from)?|from (?:the |your )?(?:next )?(?:instal+ment|sip)(?: date)?(?: on| dated| of)?|next (?:instal+ment|sip)(?: date)?(?: on| of| is)?/);
      if (cd) ev.date = cd;
    } else if (/(?:has been|is|was|have been) (?:successfully )?paused\b|\b(?:put|placed) on (?:hold|pause)\b|\bpause (?:is |has been )?(?:successful|registered|activated|confirmed|applied)|\binstal+ments? (?:have been|has been|are) (?:paused|skipped|put on hold)/.test(lead) && !/(?:has been|is|was) resumed/.test(lead)) {
      ev = { type: 'mandate', action: 'paused' };
      var pa = new RegExp('(?:sip|instal+ment) of\\s*' + AMT, 'i').exec(body) || new RegExp(AMT).exec(body);
      if (pa && num(pa[1]) > 0) ev.amt = num(pa[1]);
      var rd = at(/\buntil\b|\btill\b|resume[sd]?(?: on| from)?|restart(?:s|ed)?(?: on| from)?|(?:next|first) instal+ment (?:after the pause )?(?:will be )?(?:on|from)/);
      if (rd) ev.date = rd;
    } else if ((m = new RegExp('(?:has been|was|is|have been) (?:successfully )?(?:switched|moved|transferred|changed)\\s+from\\s+' + FUND + '\\s+to\\s+' + FUND).exec(body)) ||
               (/\bsip\b[^.\n]{0,60}\bswitch(?:ed)?\b|\bswitched\b[^.\n]{0,60}\bsip\b/.test(lead) && (m = new RegExp('from\\s+' + FUND + '\\s+(?:to|into)\\s+' + FUND).exec(body)))) {
      ev = { type: 'mandate', action: 'switched', party: trim(m[2]), fromFund: trim(m[1]) };
      var sa = new RegExp('(?:sip|instal+ment) of\\s*' + AMT, 'i').exec(body) || new RegExp(AMT).exec(body);
      if (sa && num(sa[1]) > 0) ev.amt = num(sa[1]);
      var sd0 = at(/(?:instal+ments?|sips?) from|applies from|effective (?:from|date)|with effect from|w\.?e\.?f\.?|starting(?: from)?|next (?:instal+ment|sip)(?: date)?(?: on| of| is)?/);
      if (sd0) ev.date = sd0;
    }
    if (!ev) return null;
    if (!ev.party && inFund) ev.party = trim(inFund[1]);
    if (monthly) ev.every = monthly;
    ev.sip = true;
    return ev;
  }
  function investSteps(doc, ctx) {
    if (ctx.promo || ctx.nudge) return null;
    var k = doc.inst ? doc.inst.kind : '';
    var s = lc(doc.subject), body = lc(doc.flat.slice(doc.bodyAt, doc.bodyAt + 900)).replace(/\s+/g, ' '), lead = s + ' ' + body;
    // a registrar or depository acting as the pension's record-keeper (a CRA: KFintech, CAMS, Protean) writes of the NPS
    // account by its PRAN: read as the pension's own mail, never as a mutual fund's (no folio, no fund house paid)
    if ((k === 'rta' || k === 'depository') && /\bpran\b|national pension|\bnps\b/.test(lead) && /\btier\s*(?:i|ii|1|2)\b|\bpran\b/.test(lead) && !/\bfolio\b|mutual fund/.test(lead)) k = 'pension';
    var amtIn = function (re) { var p = kv(doc, re); if (p && p.amt > 0) return p.amt; var m = new RegExp('(?:' + re.source + ')[^₹\\d\\n]{0,40}?(?:rs\\.?|inr|₹)\\s*(\\d[\\d,]*(?:\\.\\d+)?)', 'i').exec(doc.flat); return m ? num(m[1]) : 0; };
    var first = function () { var a = amts(doc).filter(function (t) { return inBody(doc, t); })[0]; return a ? a.v : 0; };
    var acct = function () { var m = doc.toks.filter(function (t) { return t.t === 'MASK' && inBody(doc, t); })[0]; var v = m ? viaFor(doc, m, '') : { kind: 'account' }; if (v.kind === 'card' && !/card/.test(lead)) v.kind = 'account'; return v; };
    var when = function (re) { return (re && labeledDate(doc, re)) || ((doc.toks.filter(function (t) { return t.t === 'DATE' && inBody(doc, t) && !t.rel; })[0] || {}).v) || doc.ref; };
    var who = doc.inst ? doc.inst.short : '';
    var fundish = (/\bsip\b/.test(lead) && !/stock sip/.test(lead)) || /mutual fund|\bfund\b(?!s? (?:added|received|transfer))|\bnfo\b|systematic/.test(lead);
    // a "Label | value" line, for labels the pair reader passes over (a name in capitals, "Buy")
    var lineVal = function (re) { for (var i = 1; i < doc.lines.length; i++) { var c = doc.lines[i].split(' | '); if (c.length === 2 && re.test(lc(trim(c[0])))) return trim(c[1]); } return ''; };
    var investing = /^(?:broker|rta|amc|exchange|pension|depository)$/.test(k);

    // money to a lender, a platform or the tax department, told by them as "received": out of you
    var loanish = k === 'lender' || (/\bloan\b/.test(s) && !/\bcard\b|credit card/.test(lead) && !/(?:has been|was) debited|debited (?:from|on)/.test(body.slice(0, 400)));
    if (loanish && /\bemi\b|loan|instal+ment|prepayment|foreclos/.test(lead) && !/pre-?approved|\boffers?\b|apply now|top-?up loan/.test(s)) {
      // a loan's year told after the fact (an interest certificate: principal repaid and interest paid during the FY, what
      // is outstanding, the EMI): no money moves in this mail, its EMIs were each debited in their month. Its figures go to
      // the loans side as facts
      if (/interest certificate|repayment certificate|(?:principal|interest)\s+(?:re)?paid\s+(?:during|in)\s+(?:the\s+)?(?:fy|financial year|year)\b/.test(lead) && !/(?:has been|was) (?:debited|credited|disbursed)/.test(body)) {
        var lf = { type: 'loan', action: 'certificate', lender: who };
        var lno = kv(doc, /^loan (?:a\/c|account|acct)(?: (?:no\.?|number))?$/);
        var lnoV = lno ? (lno.mask || (/\d{4,}/.exec(lno.value) || [''])[0].slice(-4)) : '';
        if (!lnoV) { var lnm = /\bloan\s*(?:a\/c|account|acct)\s*(?:no\.?|number)?\s*[:\-]?\s*[x*•]*(\d{4,})/i.exec(doc.subject + '\n' + doc.flat); if (lnm) lnoV = lnm[1].slice(-4); }
        if (lnoV) lf.no = lnoV;
        var lo = amtIn(/principal outstanding|outstanding principal|outstanding (?:amount|balance)|balance outstanding/), le = amtIn(/^emi$|\bemi(?: amount)?\b/);
        var lpp = amtIn(/principal (?:re)?paid/), lip = amtIn(/interest paid/);
        // ("Principal outstanding as on 31-03-2026: Rs. 38,40,112.00": a date inside its label)
        if (!(lo > 0)) { var lom = /\b(?:principal outstanding|outstanding principal|outstanding (?:amount|balance))\b[^\n₹]{0,40}?(?:rs\.?|inr|₹)\s*(\d[\d,]*(?:\.\d+)?)/i.exec(doc.flat); if (lom) lo = num(lom[1]); }
        if (lo > 0) lf.outstanding = lo;
        if (le > 0) lf.emi = le;
        if (lpp > 0) lf.paidPrincipal = lpp;
        if (lip > 0) lf.paidInterest = lip;
        var lr = /(?:rate of interest|interest rate|roi)\s*[:\-|]?\s*(\d{1,2}(?:\.\d{1,3})?)\s*%/i.exec(doc.flat);
        if (lr) lf.rate = +lr[1];
        var lfy = /\bfy\s*(20\d{2})\s*[-–\/]\s*(\d{2,4})\b/i.exec(doc.subject + ' ' + doc.flat);
        if (lfy) lf.fy = lfy[1] + '-' + lfy[2].slice(-2);
        return { events: [lf] };
      }
      if (/(?:has been|was|have been) disbursed|disbursal (?:is |has been )?(?:successful|completed|done)/.test(lead) && !/will be disbursed|to be disbursed|sanction/.test(s)) {
        var da = amtIn(/net disburs(?:al|ed) amount|amount disbursed|disbursal amount|disbursed amount/) || amtIn(/loan of|loan amount/) || first();
        var out = [];
        // (a gold loan paid out at the branch names no account of yours: the loan is in its facts, no money came into
        // an account kosh follows)
        var goldCash = /\bgold loan\b/.test(lead) && !doc.toks.some(function (t) { return t.t === 'MASK' && inBody(doc, t); });
        // (the lender is who paid it out: a lender kosh has no entry for, by the name it writes under)
        if (da > 0 && !goldCash) out.push({ type: 'move', dir: 'in', amt: da, date: when(/disbursed (?:to your [^.\n]{0,40}? )?on|disbursal date|date of disbursal/), via: acct(), purpose: 'loan', party: who || senderBrand(doc) });
        var fe = /first emi[^₹\n]{0,30}?(?:rs\.?|inr|₹)\s*(\d[\d,]*(?:\.\d+)?)/i.exec(doc.flat), fd0 = labeledDate(doc, /first emi[^\n]{0,40}?due on|first emi date|due on/);
        if (fe) { var de = { type: 'due', what: 'emi', amt: num(fe[1]), payee: who }; if (fd0) de.due = fd0; out.push(de); }
        if (out.length) return { events: out };
      }
      if (/\bbounced\b|\bemi bounce\b|bounce (?:intimation|alert)|could not be (?:collected|processed|presented)|returned unpaid|dishono(?:u)?red/.test(lead)) {
        var ov = amtIn(/overdue amount of|overdue amount|total overdue|amount overdue/) || amtIn(/emi of|emi amount/) || first();
        var bo = { type: 'due', what: 'emi', payee: who }; if (ov > 0) bo.amt = ov;
        // (the day the lender asks it paid by: "Please pay by 12/10/2026")
        var bod = labeledDate(doc, /\b(?:please )?pay\b(?:[^.\n]|\.(?=\s?\d)){0,30}?\b(?:by|before)|pay on or before|clear (?:the )?(?:dues|overdue) by/); if (bod) bo.due = bod;
        return { events: [bo], failedOk: true };
      }
      // a consumer loan booked (an EMI card, a product on EMI): its first EMI, due from the day it starts
      if (/\bloan\b[^.\n]{0,40}\b(?:has been |is |was )?(?:booked|sanctioned|created|approved)\b/.test(lead) && !/(?:has been|was) disbursed/.test(lead)) {
        var fe1 = /\bemi\s*(?:amount)?\s*[:|\-]?\s*(?:rs\.?|inr|₹)\s*(\d[\d,]*(?:\.\d+)?)\s*(?:\/-)?\s*(?:per month\s*)?(?:starting|from|beginning|w\.?e\.?f\.?)\s*/i.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 1500));
        var fd1 = fe1 ? near(doc, 'DATE', doc.bodyAt + fe1.index + fe1[0].length, 0, 4) : null;
        if (fe1 && fd1) return { events: [{ type: 'due', what: 'emi', amt: num(fe1[1]), due: fd1.v, payee: who }] };
      }
      if (/(?:we have |has been |have been )?received (?:your |a |the )?(?:emi|payment|part[- ]?prepayment|prepayment|instal+ment|foreclosure)|(?:emi|payment|prepayment) (?:has been |was )?received|thank you for (?:your )?(?:emi )?payment|received with thanks|acknowledge (?:the )?receipt of/.test(lead) && !/will be|due on|reminder/.test(s)) {
        var ra = amtIn(/part[- ]?prepayment of|prepayment of|emi of|payment of|instal+ment of|amount of|amount received|received with thanks|receipt of|emi amount/) || first();
        if (ra > 0) {
          var pp = /prepay|foreclos/.test(lead);
          var rm = { type: 'move', dir: 'out', amt: ra, date: when(/(?:received|paid)[^.\n]{0,80}? on|payment date|date of (?:payment|receipt)|receipt date/), via: acct(), purpose: pp ? 'loan' : 'emi', party: pp ? who : loanName(doc) };
          // (how it was paid and the receipt's own number, as the receipt labels them: "Mode: UPI", "Receipt No: RCPT…")
          var lmo = kv(doc, /^(?:payment )?mode(?: of payment)?$/), lmv = lmo ? /\b(upi|nach|ach|ecs|neft|imps|rtgs)\b/i.exec(lmo.value) : null;
          if (lmv) rm.mode = /^(?:ach|ecs)$/i.test(lmv[1]) ? 'NACH' : lmv[1].toUpperCase();
          var lrf = kv(doc, /^(?:receipt|reference|transaction|txn)(?: (?:no\.?|number|id))?$/), lrv = lrf ? /[A-Za-z0-9][A-Za-z0-9\-\/]{5,40}/.exec(lrf.value) : null;
          if (lrv && /\d{4}/.test(lrv[0])) rm.ref = lrv[0];
          return { events: [rm] };
        }
      }
      if (/reminder|is due|due on|due date|upcoming emi|will be (?:debited|presented)/.test(lead) && /\bemi\b/.test(lead) && !/received|debited from|has been (?:paid|debited)|debited on/.test(body.slice(0, 300))) {
        var ea = amtIn(/emi of|emi amount|instal+ment of|amount due/) || first();
        var due = labeledDate(doc, /due on|due date|will be (?:debited|presented) on|on or before/);
        var ed = { type: 'due', what: 'emi', payee: who }; if (ea > 0) ed.amt = ea; if (due) ed.due = due;
        if (ea > 0 || due) return { events: [ed] };
      }
    }
    // a tax demand to pay by a date
    var nilDemand = /\b(?:no|nil|zero) demand\b|\bdemand\b[^.\n]{0,30}?(?:\bnil\b|\bnone\b|\bzero\b|(?:rs\.?|₹|inr)\s*0(?:\.0+)?\b|:\s*0\b)/.test(lead);
    // a TDS intimation ("EXAMPLE FINANCE has deducted TDS of … on interest of …, reflected in Form 26AS"): information, rule 18
    // (the Form 26AS mail that lists each deductor's TDS: those facts, for tax; any other TDS intimation stays information)
    if (k === 'tax' && /\btds\b|form 26as|\b26as\b|annual information statement/.test(lead) && !/\brefund\b|\bdemand\b|challan|paid successfully/.test(lead)) return taxStatement(doc) || { events: [{ type: 'noise', reason: 'info' }] };
    // a demand only proposed to be set against a refund (section 245): nothing to pay, no refund coming yet
    if (k === 'tax' && /proposed to be adjusted|(?:to be |will be )?adjusted against (?:your |the )?refund|proposed adjustment/.test(lead)) return { events: [{ type: 'noise', reason: 'info' }] };
    if (k === 'tax' && /\bdemand\b/.test(lead) && /(?:has been |is )?(?:determined|raised|outstanding|payable)/.test(lead) && !nilDemand) {
      var ta = amtIn(/demand of|demand amount|amount of demand|outstanding demand|demand payable/);
      var tdue = labeledDate(doc, /pay (?:the demand )?(?:by|before|on or before)|due date|payable by/);
      if (ta > 0) { var td = { type: 'due', what: 'tax', amt: ta, payee: who }; if (tdue) td.due = tdue; return { events: [td] }; }
    }
    // an SIP's course changed, said by its platform, registrar or fund house (or a sender kosh doesn't know, in so many
    // words): stepped up from a day, paused until one, switched to another fund (a cancelled one is read below)
    var sipLc = sipChange(doc, lead, k, investing);
    if (sipLc) return { events: [sipLc] };
    // (a contract note from a broker kosh doesn't know yet: read only when its trades carry their ISINs, below)
    var newBroker = !doc.inst && /contract note/.test(s) && !/margin/.test(s);
    if (!investing && !newBroker && !(k === 'bank' && /\bipo\b|demat/.test(s))) return null;

    // a broker's own regulatory filing ("Statement of Financial Condition for Example Brokers LLC") is the firm's, not yours
    if (/statement of financial condition/.test(s)) return { events: [{ type: 'noise', reason: 'info' }] };
    // a statement of holdings, gains or the account at a broker or registrar (the PDF is read on its own)
    if (/statement|\bcas\b|holding report|funds? (?:\/ ?securities )?balance/.test(s) && !/contract note|order|confirmation|\bsip\b (?:registration|cancel)/.test(s) && !/\b(?:due|reminder)\b/.test(s)) {
      // (the account it names: "for EX12345", "Client ID: EX12345", "now available for account U***71234")
      var cid = /\b(?:for|-)\s*([A-Z]{1,4}\d{3,8})\b/.exec(doc.subject) || /\b(?:client (?:id|code)|ucc)\s*[:\-]?\s*([A-Z]{0,4}\d{3,8})\b/i.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 1500)) ||
        /\b[Aa]ccount(?: (?:[Nn]o\.?|[Nn]umber|I[Dd]|id))?\s*[:\-]?\s*([A-Z]{0,3}[*xX•]{2,}\d{3,10}|[A-Z]{1,3}\d{5,10})\b/.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 1500));
      var sv = { kind: 'demat', inst: who };
      // (never a month and year from the subject, "AUG2026", for the account's digits)
      if (cid && /^(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\d{4}$/i.test(cid[1])) cid = null;
      if (cid) sv.last4 = cid[1].replace(/\D/g, '').slice(-4);
      // a depository's own name for the account ("for BO ID 12081600XXXX5566"): the masked digits its body prints. The
      // context test keeps an unrelated mask out (a mobile "ending 1234"), so only an account's own label can win.
      else {
        var smk = doc.toks.filter(function (t) {
          return t.t === 'MASK' && inBody(doc, t) &&
            /\b(?:bo|dp|demat|beneficiary owner|client|trading|folio|a\/c|acc(?:oun)?t)\s*(?:id|code|no\.?|number)?[\s:|.#-]*\d{0,12}$/i.test(doc.flat.slice(Math.max(0, t.s - 48), t.s));
        })[0];
        if (smk) sv.last4 = String(smk.v).slice(-4);
      }
      // an exchange forwarding a broker's balances: the broker's ("provided by EXAMPLE BROKING LTD."), as on its day
      // (never the regulator, "the circular provided by SEBI", nor the words before the name: "THE …", "M/s …")
      // (a firm's name: capitals or a firm's word, "EXAMPLE BROKING LTD", "Example Broking Ltd."; past "Stock Broker", "Trading Member (TM)")
      var prov = null, pvRe = /\b(?:provided|reported) by\s+((?:[A-Za-z&()\/.]+\s+){0,7}[A-Za-z&.]+)/gi, pvM, pvSkip = /^(?:your|the|m\/?s\.?|m\.s\.?|stock|broker|brokers|trading|members?|participants?|depository|\(tm\)|tm)$/i;
      if (k === 'exchange') while ((pvM = pvRe.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 2000)))) {
        var pw = pvM[1].split(/\s+/), pi = 0; while (pi < pw.length && pvSkip.test(pw[pi])) pi++;
        var pname = pw.slice(pi, pi + 4).join(' ');
        if (pi < pw.length && /^[A-Z]/.test(pw[pi]) && !/^(?:sebi|nse|bse|cdsl|nsdl|mcx|ncdex|exchange)\b/i.test(pw[pi]) && (/^[A-Z&]{2,}$/.test(pw[pi].replace(/\.$/, '')) || /\b(?:ltd|limited|llp|pvt|private|securities|broking|capital|financial|investments?|stock ?brokers?)\b/i.test(pname))) { prov = [pvM[0], pw[pi]]; break; }
      }
      if (prov) sv.inst = capWords(lc(prov[1].replace(/\.+$/, '')));
      var se = { type: 'statement', via: sv };
      var sd = /(\d{1,2}\s+[a-z]{3,9},?\s+\d{4}|[a-z]{3,9}\s+\d{1,2},\s+\d{4})\s*$/i.exec(doc.subject);
      var sdt = sd ? doc.toks.filter(function (t) { return t.t === 'DATE' && !inBody(doc, t); }).pop() : null;
      if (sdt && /margin|daily/.test(s)) se.stmtDate = sdt.v;
      if (prov && !se.stmtDate) { var asOn = labeledDate(doc, /\bas on/); if (asOn) se.stmtDate = asOn; }
      var pd = periodIn(doc); if (pd) { se.from = pd.from; se.to = pd.to; }
      return { events: [se] };
    }
    // a trade printed as labels in the mail's body ("Security | Buy/Sell | Qty", or "Buy/Sell: Buy" line by line): its side,
    // name, ISIN, quantity, price and day (rule 30's date alone when that is all there is)
    var pairTrade = function (d0) {
      // (a trade table's header over its rows, "Symbol | Buy/Sell | Quantity | Trade Price" / "EXAMPLEPOW | Sell | 120 | 245.30":
      // every row under it that is a trade, each with its own name, ISIN, price and value, never the first row's for all)
      for (var hl = 1; hl < doc.lines.length - 1; hl++) {
        var hc = doc.lines[hl].split(' | ').map(function (c) { return lc(trim(c)); });
        var si = hc.findIndex(function (c) { return /^(?:buy\s*\/\s*sell|b\s*\/\s*s|side)$/.test(c); }), qi = hc.findIndex(function (c) { return /^(?:qty|quantity|traded quantity)$/.test(c); });
        if (si < 0 || qi < 0) continue;
        var ni = hc.findIndex(function (c) { return /^(?:symbol|security|scrip|stock|instrument|company)(?: name)?$/.test(c); });
        var pi = hc.findIndex(function (c) { return /^(?:(?:gross |net |trade |traded |avg\.? |average |market |executed )?(?:rate|price)(?: per (?:unit|share|security))?(?: \(?(?:rs\.?|inr|₹)\)?)?|wap|gross rate ?\/ ?trade price per unit)$/.test(c); });
        var ic = hc.findIndex(function (c) { return /^isin(?: code)?$/.test(c); });
        var vi = hc.findIndex(function (c) { return /^(?:net total|net value|trade value|value|net amount|total|amount)(?: \(?(?:rs\.?|inr|₹)\)?)?$/.test(c); });
        var rows = [];
        for (var rl = hl + 1; rl < doc.lines.length; rl++) {
          var rc = doc.lines[rl].split(' | ').map(trim);
          if (rc.length !== hc.length || !/^(?:buy|sell|b|s)$/i.test(rc[si]) || !/^\d[\d,]*$/.test(rc[qi])) break;
          var tt = { type: 'trade', side: /^s/i.test(rc[si]) ? 'sell' : 'buy', qty: num(rc[qi]) };
          if (ni >= 0 && /[a-z]/i.test(rc[ni])) tt.name = rc[ni];
          var iv = ic >= 0 ? /\b(IN[A-Z0-9]{9}\d)\b/.exec(rc[ic]) : /\b(IN[A-Z0-9]{9}\d)\b/.exec(rc.join(' '));
          if (iv) tt.isin = iv[1];
          if (pi >= 0 && num(rc[pi]) > 0) tt.price = num(rc[pi]);
          if (vi >= 0 && num(rc[vi]) > 0) tt.value = num(rc[vi]);
          tt.date = d0;
          rows.push(tt);
        }
        if (!rows.length) continue;
        // (one row and no ISIN of its own column: the one the mail prints, as before)
        if (rows.length === 1 && !rows[0].isin) { var ii = doc.toks.filter(function (t) { return t.t === 'ISIN'; })[0]; if (ii) rows[0].isin = ii.v; }
        return rows;
      }
      var sp = kv(doc, /^(?:buy\s*\/\s*sell|side|b\s*\/\s*s|trade type|transaction type)$/), side = sp ? (/\bsell\b|^\s*s\s*$/i.test(sp.value) ? 'sell' : /\bbuy\b|^\s*b\s*$/i.test(sp.value) ? 'buy' : '') : '';
      var sl = !side && /^[ \t]*(?:buy\s*\/\s*sell|b\s*\/\s*s)[ \t]*[:|\-][ \t]*(buy|sell)\b/im.exec(doc.flat.slice(doc.bodyAt));
      if (sl) side = lc(sl[1]);
      var qp = kv(doc, /^(?:quantity|qty|traded quantity|trade quantity)$/), qty = qp ? num((/\d[\d,]*(?:\.\d+)?/.exec(qp.value) || [''])[0]) : 0;
      if (!side || !(qty > 0)) return null;
      var te = { type: 'trade', side: side, qty: qty };
      var np = kv(doc, /^(?:security|scrip|symbol|stock|instrument|company)(?: name)?$/); if (np && /[a-z]/i.test(np.value)) te.name = trim(np.value).slice(0, 80);
      var it = doc.toks.filter(function (t) { return t.t === 'ISIN'; })[0]; if (it) te.isin = it.v;
      var rp = kv(doc, /^(?:(?:gross |net |trade |traded |avg\.? |average |market |executed )?(?:rate|price)(?: per (?:unit|share|security))?(?: \(?(?:rs\.?|inr|₹)\)?)?|wap|gross rate ?\/ ?trade price per unit)$/), pr = rp ? num((/\d[\d,]*(?:\.\d+)?/.exec(rp.value.replace(/^[^\d]*/, '')) || [''])[0]) : 0; if (pr > 0) te.price = pr;
      var tdp = kv(doc, /^(?:trade date|date)$/); te.date = (tdp && tdp.date) || d0;
      return [te];
    };
    // a contract note: the day's trades, in its PDF (docread reads them); the mail says only that there were some, unless
    // it prints them
    if (/contract note/.test(s) && !/margin/.test(s)) {
      var cd = doc.toks.filter(function (t) { return t.t === 'DATE' && !inBody(doc, t); })[0] || doc.toks.filter(function (t) { return t.t === 'DATE'; })[0];
      var cnt = pairTrade(cd ? cd.v : doc.ref);
      if (newBroker && !(cnt && cnt.every(function (t) { return t.isin; }))) return null;
      return { events: cnt || [{ type: 'trade', note: true, date: cd ? cd.v : doc.ref }] };
    }
    // an exchange's word that you traded ("You have traded on 15-07-2026 through your trading member", "Trades executed
    // at NSE"): the trade, with what it prints of it (rule 30)
    if (k === 'exchange' && /\btrad(?:ed|es?)\b/.test(lead) && /\byou have traded\b|\btrades? (?:were |was |have been |has been )?executed\b|details of your trades?\b|\btrades? (?:done|carried out)\b/.test(lead) && !/obligation|funds? (?:and|&) securities|balance|margin|statement/.test(s)) {
      var xd = labeledDate(doc, /\btraded on|executed on|trade date|on/) || doc.ref;
      return { events: pairTrade(xd) || [{ type: 'trade', date: xd }] };
    }
    // rights entitlements credited, a bonus or a split: units in the demat, no money
    if (/rights entitlement|\bre(?:s)? credited|bonus (?:shares|issue)|stock split|sub-?division/.test(lead)) return { events: [{ type: 'noise', reason: 'info' }] };
    // a demat or account maintenance charge, told before it's taken
    // (one that "will be charged tomorrow" from the account there is a debit to come, not a bill to pay: expects())
    if (/maintenance charge|\bamc\b/.test(s) && /\bdue\b/.test(lead) && !/will be (?:debited|deducted|charged|recovered)/.test(lead)) {
      var ma = amtIn(/charge \(amc\) of|charges? of|amc of|amount of/) || first();
      if (ma > 0) return { events: [{ type: 'due', what: 'fee', amt: ma, payee: who }] };
    }
    // a withdrawal or payout from a broker's or platform's account to your bank, on its way while it "should reflect" (a
    // promise: money in once the mail says it was credited, as moves() reads it), never money invested
    if (/^(?:broker|exchange)$/.test(k) && /\b(?:withdrawal|withdraw|payout|pay-out)\b/.test(lead) && /\b(?:processed|initiated|sent|transferred)\b/.test(lead) &&
        /should (?:reflect|be credited)|will (?:reflect|be credited)|within \d+\s*(?:hours?|working days?|business days?|days?)|expected (?:by|within)/.test(lead) && !/(?:has been|was) credited to your/.test(lead)) {
      var wa = amtIn(/withdrawal request of|withdrawal of|payout of|amount of/) || first();
      if (wa > 0) return { events: [{ type: 'expect', dir: 'in', what: 'payout', amt: wa, party: who }] };
    }
    // money added to a broker's or platform's account from yours: out of the bank, into the account there
    if (k !== 'bank' && !fundish && /funds? (?:have been |has been )?(?:added|received) (?:to|in|into)|(?:has been|have been|was) added to your [\w ]{0,30}(?:account|wallet)|(?:we have )?received (?:rs\.?|₹|inr)\s?\d[^.\n]{0,60} from your (?:bank|account)|(?:has been|was) debited from your (?:bank )?account/.test(lead) &&
        !/withdraw|payout|settle|redeem|redemption|will be (?:debited|added|credited|transferred)|to be (?:debited|credited)|request|credited to your bank/.test(lead)) {
      var fa = amtIn(/received|was debited|has been debited|funds? of|amount of|amount added/) || first();
      if (fa > 0) {
        var fv = acct();
        return { events: [{ type: 'move', dir: 'out', amt: fa, date: when(/via [a-z]+ on|debited from [^.\n]{0,60}? on|on/), via: fv, purpose: 'investment', party: who }] };
      }
    }
    // a pension's contribution credited to the account there, or its balance
    if (k === 'pension') {
      // an EPF contribution the EPFO tells of (your share and your employer's, put into the provident fund against your
      // UAN): no money moved in or out of any account of yours at a bank; kosh reads EPF from the passbook (a claim
      // settled to your bank is money in, read as any credit)
      // (the fund's balance it prints is kept, as below)
      if (/contribution/.test(lead) && /\bepf\b|provident|\buan\b/.test(lead) && /received|credited|deposited|remitted|updated/.test(lead) && !/\bclaim\b|settle|withdraw|\badvance\b|(?:sent|transferred|credited|paid) to your (?:\w+ )?bank/.test(lead)) {
        var eb = /\bbalance\b[^₹\n]{0,60}?(?:is|:)\s*(?:rs\.?|inr|₹)\s*(\d[\d,]*(?:\.\d+)?)/i.exec(doc.flat);
        return { events: eb ? [{ type: 'balance', amt: num(eb[1]), via: { kind: 'other', inst: who } }] : [] };
      }
      // (never EPF: it has no scheme, NAV or units, so a contribution credited to it is the balance it states and not a
      //  fund bought. The exclusions beside this were written for EPFO's passbook mail and miss its "EE:/ER:" wording)
      if (/contribution/.test(lead) && /credited|allotted|received|processed/.test(lead) && !/employer share|employee share|passbook|\bepf\b|provident/.test(lead)) {
        var ca = amtIn(/contribution amount|contribution of|amount of/) || first();
        if (ca > 0) {
          var tier = /tier\s*(ii|2)\b/.test(lead) ? 'II' : 'I', cdt = when(/settlement date|credited[^.\n]{0,60}? on|on/);
          // (units still to come, "Units will be allotted at the NAV of …": the money paid, never yet the units bought; the
          // allotment's own mail is the buy, so one contribution is one buy when both mails come)
          var later = /\bunits? (?:will|shall) be (?:allotted|alloted|credited)\b|\bwill be allotted\b/.test(lead) && !/(?:has|have) been (?:allotted|alloted)|units allotted\s*[:|]/.test(lead);
          var pevs = [{ type: 'fund', action: 'buy', scheme: who + ' Tier ' + tier, amt: ca, date: cdt }];
          // (the subscriber's own contribution received, through eNPS or a bank: the money paid in, rule 24; an employer's
          // credit to a provident fund is not money the owner paid now)
          if (/\b(?:we have |we've )?received your (?:\w+ ){0,2}contribution|\byour (?:\w+ ){0,2}contribution\b[^.\n]{0,40}\b(?:has been |was )?received/.test(lead) && !/employer|\bepf\b|provident/.test(lead)) {
            var pref = kv(doc, /^(?:transaction|txn|reference)(?: (?:id|no\.?|number))?$/), prv = pref ? /[A-Za-z0-9][A-Za-z0-9\-]{5,40}/.exec(pref.value) : null;
            var pm = { type: 'move', dir: 'out', amt: ca, date: cdt, via: { kind: 'other' }, purpose: 'investment', party: who };
            if (prv && /\d{4}/.test(prv[0])) pm.ref = prv[0];
            if (later) pevs = [];
            pevs.unshift(pm);
          }
          return { events: pevs };
        }
      }
      var bm = /\bbalance\b[^₹\n]{0,60}?(?:is|:)\s*(?:rs\.?|inr|₹)\s*(\d[\d,]*(?:\.\d+)?)/i.exec(doc.flat);
      if (bm) return { events: [{ type: 'balance', amt: num(bm[1]), via: { kind: 'other', inst: who } }] };
    }
    // a SIP order placed at a platform: the money it will take (the fund's allotment is the purchase)
    if (/\bsip\b/.test(s) && /order (?:has been |is )?placed|order placed/.test(lead) && !/(?:has|have) been allotted|allotment details|units allotted\s*[:|]/.test(lead)) {
      var oa = amtIn(/order of|instal+ment of|sip of|amount of/) || first();
      var sch = /\bfor\s+([A-Z][\w&'.() \-]{3,90}?(?:Fund|Plan|ETF|Growth|IDCW)(?:\s+(?:Direct|Regular)(?:\s+Plan)?)?(?:\s*-?\s*(?:Growth|IDCW))?)\b/.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 600));
      if (oa > 0) { var oe = { type: 'expect', dir: 'out', what: 'sip', amt: oa, on: doc.ref }; if (sch) oe.party = trim(sch[1]); return { events: [oe] }; }
    }
    // a SIP stopped
    if (/\bsip\b|systematic investment/.test(lead) && /(?:has been |is |was )?(?:cancelled|canceled|stopped|terminated|ceased)\b|cancellation (?:is )?(?:successful|processed|confirmed)/.test(lead) && !/will be cancelled|request (?:received|submitted)/.test(lead)) {
      var xa = amtIn(/sip of|sip amount|instal+ment of|amount of/) || first();
      var xs = /\bin\s+([A-Z][\w&'.() \-]{3,90}?(?:Fund|Plan|ETF)(?:\s*-\s*(?:Direct|Regular)(?:\s+Plan)?)?(?:\s*-?\s*(?:Growth|IDCW))?)/.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 600));
      var xe = { type: 'mandate', action: 'cancelled' }; if (xa > 0) xe.amt = xa; if (xs) xe.party = trim(xs[1]);
      return { events: [xe] };
    }
    // a trade confirmed by the broker, a stock SIP executed, an order filled abroad, crypto bought or sold
    var sideW = /\b(?:buy|bought|purchased?)\b/.test(lead) ? 'buy' : /\b(?:sell|sold)\b/.test(lead) ? 'sell' : '';
    if (/order (?:has been )?(?:executed|filled|completed)|order filled|trade confirmation|trade executed|stock sip (?:executed|completed)|you (?:bought|sold)\b|has been filled/.test(lead) && !fundish &&
        /\byour\b[^.\n]{0,60}\b(?:order|stock sip|trade)\b|\byou (?:bought|sold)\b|trade confirmation/.test(lead) && !/investors like you|users (?:bought|purchased)|trending/.test(lead)) {
      var tside = (kv(doc, /^(?:buy\/sell|side|transaction type|order type)$/) || {}).value || lineVal(/^(?:buy\/sell|side|transaction type|order type)$/);
      tside = /sell|sold/i.test(tside || '') ? 'sell' : /buy|bought/i.test(tside || '') ? 'buy' : (/stock sip/.test(lead) ? 'buy' : sideW);
      var qp = kv(doc, /^(?:quantity|qty|filled quantity|shares|units)$/);
      var qty = qp ? num((/\d[\d,]*(?:\.\d+)?/.exec(qp.value) || [''])[0]) : 0, m;
      var flat = doc.flat.slice(doc.bodyAt, doc.bodyAt + 1200);
      if (!qty && (m = /\b(?:buy|sell|bought|sold)\s+(\d[\d,]*(?:\.\d+)?)\s+(?:shares?|units?|qty|[A-Z]{2,10}\b)/i.exec(flat))) qty = num(m[1]);
      if (!qty && (m = /\b(\d[\d,]*(?:\.\d+)?)\s+shares\s+of\b/i.exec(flat))) qty = num(m[1]);
      var pp0 = kv(doc, /^(?:(?:gross |net |trade |traded |avg\.? |average |market |executed )?(?:rate|price)(?: per (?:unit|share|security))?(?: \(?(?:rs\.?|inr|₹)\)?)?|wap|gross rate ?\/ ?trade price per unit)$/);
      var price = pp0 ? num((/\d[\d,]*(?:\.\d+)?/.exec(pp0.value.replace(/^[^\d]*/, '')) || [''])[0]) : 0;
      if (!price && (m = /\bat\s*(?:₹|rs\.?|inr|\$|usd)\s*(\d[\d,]*(?:\.\d+)?)/i.exec(flat))) price = num(m[1]);
      var vp = kv(doc, /^(?:trade value|order value|total|value|net amount|total amount)$/);
      var value = vp ? num((/\d[\d,]*(?:\.\d+)?/.exec(vp.value.replace(/^[^\d]*/, '')) || [''])[0]) : 0;
      if (!value && (m = /\btotal\s*[:\-]?\s*(?:₹|rs\.?|inr|\$|usd)\s*(\d[\d,]*(?:\.\d+)?)/i.exec(flat))) value = num(m[1]);
      var cur = /\$|\busd\b/i.test(flat) && !/₹|\brs\.?\s?\d|\binr\b/i.test(flat) ? 'USD' : '';
      var isin = doc.toks.filter(function (t) { return t.t === 'ISIN'; })[0];
      var np = kv(doc, /^(?:stock|scrip|security|instrument|symbol|company|share)(?: name)?$/);
      var name = np ? trim(np.value) : lineVal(/^(?:stock|scrip|security|instrument|symbol|company|share)(?: name)?$/);
      if (!name && (m = /\bshares of\s+([A-Z][A-Z0-9&.' \-]{2,60}?(?:LIMITED|LTD))\b/.exec(flat) || /\b(?:for|of)\s+([A-Z][A-Z0-9&.\-]{3,30})\b/.exec(doc.subject))) name = trim(m[1]);
      // (the company or symbol after "shares of" in any case, "5 shares of Example Pharma Ltd has been executed", "BUY 10
      // shares of EXAMPLEPOWER on NSE"; else the symbol the subject buys or sells, "Order Executed: BUY EXAMPLEPOWER")
      if (!name && (m = /\bshares of\s+([A-Z][A-Za-z0-9&.'\-]*(?:\s+[A-Z][A-Za-z0-9&.'\-]*){0,6}?)(?=\s+(?:on|at|has|have|was|were|is|for|@|in)\b|\s*[.,(]|\s*$)/.exec(flat) || /\b(?:buy|sell|bought|sold)\s+(?:\d[\d,]*\s+(?:shares?\s+(?:of\s+)?)?)?([A-Z][A-Z0-9&\-]{3,30})\b/i.exec(doc.subject))) name = trim(m[1]);
      if (tside && qty > 0) {
        var te = { type: 'trade', side: tside, qty: qty };
        if (name) te.name = name; if (isin) te.isin = isin.v; if (price > 0) te.price = price; if (value > 0) te.value = value; if (cur) te.cur = cur;
        te.date = when(/trade date|executed on|filled on|date/);
        var evs = [te];
        // crypto bought with rupees from your account: the money too (no bank alert names the exchange's coin)
        var paid = /(?:for|of)\s*(?:₹|rs\.?|inr)\s*(\d[\d,]*(?:\.\d+)?)[^\n]{0,120}?\b(?:paid|debited|via upi|from your)/i.exec(flat);
        if (paid && /you (?:bought|sold)/.test(lead)) evs.unshift({ type: 'move', dir: tside === 'buy' ? 'out' : 'in', amt: num(paid[1]), date: te.date, via: acct(), purpose: 'investment', party: who });
        return { events: evs };
      }
    }
    // gold or silver bought (digital gold): the money paid
    if (/\bgold\b|\bsilver\b/.test(lead) && /(?:successfully )?purchased|you (?:have )?bought|purchase (?:is )?successful/.test(lead) && !/\bsell|sold\b/.test(s)) {
      var ga = amtIn(/for|amount paid|total amount|amount/) || first();
      if (ga > 0) return { events: [{ type: 'move', dir: 'out', amt: ga, date: when(/on|date/), via: acct(), purpose: 'investment', party: who }] };
    }
    return null;
  }
  /* A payment made through an app, a wallet, a society's app or a payment gateway (LABELING.md rules 2, 5, 6, 10):
     a bill or recharge paid (party the biller, ref the bill payment's own reference), rent or fees paid by card, a
     merchant paid through a gateway (party the merchant), money added to a wallet (out of the account or card it came
     from, party the wallet), cashback credited to a wallet (in). The account, card or wallet it came from is the one
     the mail names ("Debited from: SBI XX4567", "Paid using Paytm UPI from HDFC Bank - 1234", "Card used | ... XX4321").
     Null when the mail is none of these. */
  /* the credit card a bill payment paid, as an app's receipt names it ("towards your Example Bank credit card ••4410",
     "card | Example Bank Credit Card XX4321", "for Example Bank Credit Card"): its digits and its issuer as printed,
     never the account, card or UPI the money came from ("paid from", "card used", "debited from") */
  var PAID_FROM = /(?:paid|debited|charged|sent|funded)\s+(?:from|using|with|via|by)\b[^\n|]{0,40}$|\b(?:card used|payment (?:source|mode|method)|source|from)\s*[:|\-]?\s*[^\n|]{0,40}$/;
  function paidCardIn(doc) {
    var cardAt = function (pre) { return /credit\s*card\s*(?:no\.?|number|ending(?: in| with)?)?[\s:|\-]*$/.test(pre); };
    var mk = doc.toks.filter(function (t) {
      if (t.t !== 'MASK') return false;
      var ls = doc.flat.lastIndexOf('\n', t.s - 1) + 1, pre = lc(doc.flat.slice(Math.max(ls, t.s - 60), t.s)).replace(/\s+/g, ' ');
      var key = t.pair ? t.pair.key : '';
      if (PAID_FROM.test(pre) || /from|source|used|debit|account/.test(key)) return false;
      return cardAt(pre) || (/^(?:credit )?card(?: (?:no\.?|number|paid))?$/.test(key) && /credit card/.test(lc(t.pair.value)));
    })[0];
    var line = '';
    if (mk) line = doc.flat.slice(doc.flat.lastIndexOf('\n', mk.s - 1) + 1, mk.e);
    else {
      // (no digits printed: the card the payment names, "for HDFC Bank Credit Card", by its issuer alone)
      var nm = /\b(?:to|towards|for)\s+(?:your\s+)?([A-Za-z][\w&. ]{1,30}?)\s+credit card\b/i.exec(doc.subject + '\n' + doc.flat.slice(doc.bodyAt, doc.bodyAt + 900));
      if (nm) line = nm[1] + ' credit card';
    }
    var who = line && E.issuerIn ? E.issuerIn(line, true) : null;
    if (!mk && !who) return null;
    var v = { kind: 'card' };
    if (who) v.inst = who.short;
    if (mk) v.last4 = mk.v;
    return v;
  }
  function appPaySteps(doc, ctx) {
    var k = doc.inst ? doc.inst.kind : '';
    // (a payment gateway's receipt is receipts()'s: it reads their layouts already)
    if (!/^(?:app|wallet|society)$/.test(k) || ctx.promo || ctx.nudge || ctx.failed || ctx.future) return null;
    var s = lc(doc.subject), body = doc.flat.slice(doc.bodyAt, doc.bodyAt + 2500), lb = lc(body).replace(/\s+/g, ' '), lead = s + ' ' + lb.slice(0, 900), m;
    // what this mail is not: a reminder or a bill generated, a payment pending, scheduled or set up, a mandate, money
    // that came to you (from a person, a tenant, credited to your bank), a card's bill (the card's side), coins or points
    // (in the subject, or in a sentence about this payment: one with a figure or "your payment", never a footer's "Set up
    // AutoPay for faster payments" or "Any refund will be credited to the source account")
    var leadSens = sentencesOf(lc(body.slice(0, 900))).map(function (x) { return x.text.replace(/\bwill (?:be )?(?:updated|reflect(?:ed)?|posted)\b[^.\n]*/g, ''); }).filter(function (t) { return !/^\s*(?:if|in case)\b|\bif you (?:have|had)\b/.test(t) && /(?:₹|rs\.?|inr)\s?\d|\byour (?:payment|bill|recharge|transaction|order|rent)\b|\bthis (?:payment|transaction)\b/.test(t); });
    var said = function (re, noNext) { return [s].concat(leadSens).some(function (t) { return re.test(noNext ? t.replace(/\bnext (?:due|payment|billing(?: date)?|bill)\b[^.\n]{0,60}/g, '') : t); }); };
    if (said(/amount due|due date|\bis due\b|is generated|has been generated|pay now|pay by|pay before|pay again|recharge now|expir(?:es|ing|y)|fetched|last month|pending|scheduled|set ?up|auto-?pay|mandate|will be|to be (?:paid|debited)|reminder/, true)) return null;
    if (said(/received from|sent you|you(?:'ve| have)? received|from your tenant|sent by|received in your|credited to your (?:\w+ ){0,3}(?:bank )?(?:a\/c|account)(?! [\w ]{0,20}wallet)|gift card/) && !/cashback/.test(s)) return null;
    // (a refund, "₹299 has been refunded to your Paytm Wallet": never a payment this mail makes; moves() and bankSteps() read it)
    if (said(/\b(?:has been|was|is) (?:successfully )?refunded\b|\brefunded to your\b|\brefund of (?:rs\.?|₹|inr)?\s?[\d,.]+ (?:has been |was )?(?:processed|credited)/) || /^\s*refund\b/.test(s)) return null;
    var cardBill = /credit card bill|card bill payment|(?:bill )?payment (?:of [^.\n]{0,30})?(?:to|towards|for) (?:your )?[\w ]{0,30}credit card|\btowards (?:your )?[\w ]{0,30}credit card\b|credited to (?:your )?card/.test(lead);
    if (/credited to (?:your )?card/.test(lead) || /\bcoins?\b|\bpoints\b|\brewards?\b/.test(s)) return null;
    var lv = function (re) { var p0 = kv(doc, re); if (p0) return p0; for (var i = 1; i < doc.lines.length; i++) { var c = doc.lines[i].split(' | '); if (c.length === 2 && re.test(lc(trim(c[0])))) return { key: lc(trim(c[0])), value: trim(c[1]) }; } return null; };
    var amtOf = function (p0) { var a = p0 ? /\d[\d,]*(?:\.\d+)?/.exec(String(p0.value).replace(/^[^\d]*/, '')) : null; return a ? num(a[0]) : 0; };
    var cashback = /cashback/.test(s) && /(?:has been |was )?credited to your [\w ]{0,20}(?:wallet|balance)|cashback (?:of [^.\n]{0,20})?(?:has been |was )?(?:credited|added) to your [\w ]{0,20}(?:wallet|balance)|here(?:'|’)?s (?:rs\.?|₹|inr)\s?\d[\d,.]*\s+cashback|cashback of (?:rs\.?|₹|inr)\s?\d[\d,.]* is here/.test(lead) && !/up to|get (?:up to )?(?:rs\.?|₹)|on your next/.test(lb.slice(0, 300));
    // the account or card it came from, as the mail labels it (never "paid by" a person, never a consumer, phone or vehicle number)
    var src = null;
    [/card used\s*[:|]?\s*([^\n]{2,80})/i, /debited from\s*[:|]?\s*([^\n]{2,80})/i, /paid from\s*[:|]?\s*([^\n]{2,80})/i, /payment source\s*[:|]?\s*([^\n]{2,80})/i, /paid (?:using|with)\s*[:|]?\s*([^\n]{2,80})/i, /funded by\s*[:|]?\s*([^\n]{2,80})/i,
     /\busing\s+((?:your\s+)?[A-Z][\w ]{0,30}(?:bank|card|upi)\b[^\n]{0,40})/i, /paid via\s*[:|]?\s*([^\n]{2,80})/i,
     // (a receipt's own "Card | Example Bank Credit Card XX6610" row: the card it was charged to)
     /(?:^|\n)\s*\|?\s*(?:card|payment card|card charged)\s*[:|]\s*([^\n]{2,80})/i,
     // (a "From | Kotak Mahindra Bank - 4402" row: a bank's or card's, never a person who paid you)
     /(?:^|\n)\s*\|?\s*from\s*[:|]\s*((?:[A-Za-z][\w&.]*\s+){0,4}(?:bank|card|a\/c|account)\b[^\n]{0,40})/i,
     // (a receipt's own rail line with no label, "via CRED UPI · Example Bank ••8812": the account it was paid from.
     //  Last, so every labelled source above still wins, and it only does anything when the line carries masked digits)
     /(?:^|\n)\s*via\s+([^\n]{2,80})/i].forEach(function (re) { if (!src) src = re.exec(body); });
    var srcFrom = /\b(?:added|transferred)\b[^\n]{0,60}?\bfrom\s+((?:your\s+)?[A-Z][\w ]{1,30}?(?:bank|a\/c|account|card)\b[^\n]{0,30})/i.exec(body);
    var sv = src ? src[1] : srcFrom ? srcFrom[1] : '';
    var d4 = /(?:x{2,}|\*{2,}|•{2,}|ending(?: in| with)?)\s*(\d{4})\b|\bxx?(\d{4})\b|\s-\s*(\d{4})\s*$/i.exec(sv);
    var via = null;
    if (sv && d4) {
      via = { kind: /credit card|debit card|\bcard\b/i.test(sv) ? 'card' : 'account', last4: d4[1] || d4[2] || d4[3] };
      if (/debit card/i.test(sv)) via.debit = true;
      var who = E.issuerIn ? E.issuerIn(sv, via.kind === 'card') : null; if (who) via.inst = who.short;
    }
    // money added to a wallet: from an account or card the mail names, or one the mail says you paid ("Your payment was
    // successful"); never one a person sent, a refund or a gift card
    var topup = !cashback && /(?:money|amount|rs\.?|₹|inr)(?:[^.\n]|\.\d){0,40}(?:has been |was )?added to your [\w ]{0,20}(?:wallet|balance)|\badded (?:rs\.?|₹|inr)\s?[\d,.]+ to your [\w ]{0,20}(?:wallet|balance)|money added|add(?:ed)? money/.test(lead) && !/refund/.test(lead) &&
      (!!via || /your payment (?:was|is|has been) successful|payment successful|\byou (?:have )?paid\b/.test(lead));
    var paid = /(?:payment|recharge|bill payment|rent payment|transaction)\b[^.\n]{0,60}\b(?:is |was |has been )?(?:successful|processed successfully|completed)|payment (?:successful|received|confirmation)|we have received your payment|has been processed successfully|recharge successful|\byou paid\b|\bpayment receipt\b|\b(?:bill payment|recharge)\b[^\n]{0,160}?\b(?:is|was|has been) successful|\b(?:rent|fees?|maintenance|bill) paid successfully\b|\b(?:rent|fees?|maintenance) of (?:rs\.?|inr|₹)\s?[\d,.]+ (?:has been |was )?(?:paid|sent) to\b/.test(lead);
    if (!cashback && !topup && !paid) return null;
    // a credit card's bill paid through the app is the card being paid (LABELING.md rule 29): money in on the card the
    // mail names, party the app, whatever account or UPI it came from (that account's own alert is the money out)
    var billCard = cardBill && !cashback && !topup ? paidCardIn(doc) : null;
    // a card's bill paid through the app with no account named is the card's side (the reader's grammar: money onto it)
    if (cardBill && !billCard && !via && !/\bupi\b/i.test(sv + ' ' + lead)) return null;
    // a wallet's own payments (from its balance, with the balance left) are the reader's grammar: here only what came from
    // an account or card the mail names, a cashback, money added; and a society's or an app's bill paid by UPI
    var billish0 = /\bbill payment\b|\brecharge\b|fastag|\bbbps\b/.test(lead);
    if (!cashback && !topup && !via && !billish0 && !billCard && (k === 'wallet' || !/\bupi\b|net ?banking|\bcard\b|payment mode/i.test(sv + ' ' + lead))) return null;
    // (a wallet's own balance named as the source: "Paid from: Freecharge Balance", "Paid using Paytm Wallet")
    if (!via && k === 'wallet' && /\b(?:balance|wallet)\b/i.test(sv)) via = { kind: 'wallet', inst: doc.inst.short };
    if (!via) via = cashback || topup ? { kind: 'wallet', inst: doc.inst.short } : /\bupi\b/i.test(sv + ' ' + lead) ? { kind: 'upi' } : { kind: 'other' };
    // the figure: a cashback by its own line (the subject first), else what was charged (a fee included), else what was paid
    // (the subject's own figure, never its promo: "Cashback credited! Get ₹100 cashback on your next bill")
    var amt = 0, sa = amts(doc).filter(function (t) { var rest = (/^[^!|\n]*/.exec(doc.flat.slice(t.e, t.e + 60)) || [''])[0]; return !inBody(doc, t) && !(/\b(?:get|up ?to|earn|win|flat)\s*$/i.test(doc.flat.slice(Math.max(0, t.s - 12), t.s)) && !/credited|added|here|received/i.test(rest)) && !/\bon your next\b/i.test(rest); })[0];
    if (cashback) {
      if (sa && /cashback/.test(s)) amt = sa.v;
      if (!amt && (m = /(?:rs\.?|inr|₹)\s*(\d[\d,]*(?:\.\d+)?)\s+cashback|cashback of\s+(?:rs\.?|inr|₹)\s*(\d[\d,]*(?:\.\d+)?)/i.exec(body))) amt = num(m[1] || m[2]);
    } else {
      amt = amtOf(lv(/^(?:total charged|amount charged|total amount paid|amount paid|total paid|paid amount|total|total debited|amount debited|total amount debited|total amount charged)$/));
      if (!amt && (m = /\b(?:amount paid|total paid|total charged)\s*[:|\-]?\s*(?:rs\.?|inr|₹)\s*(\d[\d,]*(?:\.\d+)?)/i.exec(body))) amt = num(m[1]);
      if (!amt && (m = /\b(?:payment|recharge|rent payment|bill payment|you paid)\s+(?:of\s+)?(?:rs\.?|inr|₹)\s*(\d[\d,]*(?:\.\d+)?)/i.exec(body))) amt = num(m[1]);
      if (!amt && (m = /(?:rs\.?|inr|₹)\s*(\d[\d,]*(?:\.\d+)?)\s+(?:has been|was)\s+(?:added|credited|paid)/i.exec(body))) amt = num(m[1]);
      if (!amt) amt = amtOf(lv(/^(?:amount|bill amount|recharge amount|rent amount)$/));
      if (!amt && (m = /\badded\s+(?:rs\.?|inr|₹)\s*(\d[\d,]*(?:\.\d+)?)/i.exec(body))) amt = num(m[1]);
      if (!amt && topup && sa) amt = sa.v;
      // a receipt with one figure on it ("₹ 1,875 / Paid to …"): that figure
      if (!amt) { var one = uniq(amts(doc).filter(function (t) { return inBody(doc, t) && roleOf(doc, t) !== 'bal' && roleOf(doc, t) !== 'offer'; }).map(function (t) { return t.v; })); if (one.length === 1) amt = one[0]; }
    }
    if (!(amt > 0)) return null;
    // its day: the payment's own label, else the mail's (never a due or next date)
    var dp = lv(/^(?:paid on|payment date|transaction date|date of payment|date)$/);
    var d = dp ? ((doc.toks.filter(function (t) { return t.t === 'DATE' && (dp.s == null || t.s >= dp.s) && !/(?:next|due)[^\n]{0,20}$/i.test(doc.flat.slice(Math.max(0, t.s - 25), t.s)); })[0] || {}).v) : '';
    var ev = { type: 'move', amt: amt, date: d || doc.ref, via: via };
    var tm = doc.toks.filter(function (t) { return t.t === 'TIME' && inBody(doc, t); })[0]; if (tm) ev.time = tm.v;
    var wb = /\b(?:updated |available |new |current )?(?:\w+ )?(?:wallet )?balance\s*(?:is|:|\|)?\s*(?:rs\.?|inr|₹)\s*(\d[\d,]*(?:\.\d+)?)/i.exec(body);
    var bal = wb ? [{ type: 'balance', amt: num(wb[1]), via: { kind: 'wallet', inst: doc.inst.short } }] : [];
    if (cashback) { ev.dir = 'in'; ev.purpose = 'cashback'; ev.party = doc.inst.short; if (/credited to your [\w ]{0,20}(?:bank )?(?:a\/c|account)/.test(lead)) { var mk = doc.toks.filter(function (t) { return t.t === 'MASK' && inBody(doc, t); })[0]; if (mk) ev.via = viaFor(doc, mk, 'in'); } return { events: [ev].concat(bal) }; }
    var rxU = /\b(?:upi ref(?:erence)?(?: no\.?| id)?|utr(?: no\.?)?|rrn)\s*[:|\-]?\s*(\d{10,22})\b/i.exec(body);
    var rx = rxU || /\b(?:upi ref(?:erence)?(?: no\.?)?|utr|transaction id|txn id|reference (?:no\.?|id)|receipt no\.?|order id|payment id)\s*[:|\-]?\s*([A-Za-z0-9][A-Za-z0-9\-]{5,40})/i.exec(body);
    if (billCard) {
      ev.dir = 'in'; ev.via = billCard; ev.party = doc.inst.short; ev.purpose = 'cardpay';
      if (rx && /\d/.test(rx[1])) ev.ref = rx[1];
      if (/\bupi\b/i.test(sv + ' ' + lead)) ev.mode = 'UPI';
      return { events: [ev] };
    }
    ev.dir = 'out';
    if (topup) { ev.purpose = 'topup'; ev.party = doc.inst.short; return { events: [ev].concat(bal) }; }
    // who was paid: the biller or merchant the mail names
    var party = '';
    var pk = lv(/^(?:biller|biller name|paid to|merchant|merchant name|operator|payee|society|towards|provider name|provider|landlord|owner|landlord name|beneficiary(?: name)?)$/);
    if (pk) party = cleanParty(pk.value);
    // ("Rent of ₹15,000 paid to Example Owner (Bank A/c …)", "your rent of ₹21,000 has been sent to Example Owner.")
    if (!party && (m = /\b(?:rent|fees?|maintenance|amount)\s+of\s+(?:rs\.?|inr|₹)\s*[\d,.]+\s+(?:has been\s+|was\s+)?(?:paid|sent|transferred)\s+to\s+([A-Za-z][^\n.|(]{1,50}?)(?=\s*\(|\s*\.|\s+(?:on|via|using|from)\b|\s*$)/i.exec(body))) party = cleanParty(m[1]);
    if (!party && (m = /\b(?:payment|recharge|bill payment|rent payment)\s+(?:of\s+(?:rs\.?|inr|₹)\s*[\d,.]+\s+)?(?:to|for)\s+([A-Za-z][^\n.|]{1,70}?)(?=\s+(?:account|consumer|subscriber|customer|mobile|landline|ca|k)\s+(?:number|no\.?|id)\b|\s+for\s|\s+(?:was|is|has been)\s+successful|\s*\.|\s*$)/i.exec(body))) party = cleanParty(m[1]);
    if (!party && (m = /\byou paid\s+(?:rs\.?|inr|₹)\s*[\d,.]+\s+to\s+([A-Za-z][^\n.|]{1,50}?)(?=\s*\.|\s+(?:on|via|using|from)\b|[ \t]*\n|\s*$)/i.exec(body))) party = cleanParty(m[1]);
    if (!party && (m = /\bpaid successfully to\s+([A-Za-z][^\n|]{1,50}?)[ \t]*(?:\||\n|$)/i.exec(body))) party = cleanParty(m[1]);
    if (!party && (m = /^\s*paid to\s+([^\n|]{2,60})$/im.exec(body))) party = cleanParty(m[1]);
    if (!party && (m = /\bfor\s+([A-Z][\w&.' -]{1,40}?)\s+bill\b/.exec(doc.subject) || /(?:successful|successfully)\s*[-–:]\s*([A-Z][\w&.' -]{1,40})$/.exec(doc.subject))) party = cleanParty(m[1]);
    // (never a phone, vehicle or consumer number for the party)
    if (party && (/^(?:mobile|vehicle|number|consumer|account|ca|k)\b/i.test(party) || /[x*•]{2,}|\d{6,}/i.test(party))) party = '';
    if (party) ev.party = party;
    var billish = /\bbill\b|recharge|electricity|postpaid|broadband|\bgas\b|\bwater\b|fastag|\bdth\b|maintenance|society|invoice|\bpremium\b|insurance|\bpolicy (?:no|number)\b|\bbiller\b|\bbbps\b/.test(lead) || k === 'society' || billerSender(doc);
    // a payer's own note is the mark of money sent to a person, not a shop: a UPI app prints "Message", "Remarks" or
    // "Payment note" only when you paid someone, never on a merchant's receipt. Needs the row to be short and on its
    // own line (a footer's "Note: this mail is auto-generated" is a sentence, not a note) and the rail to be UPI.
    var p2pNote = /(?:^|\n)\s*\|?\s*(?:message|remarks?|payment note|note to (?:self|payee))\s*[:|]\s*[^\n|]{1,60}(?:\||\n|$)/i.test(body)
      && (!!rxU || /\bupi\b/i.test(String(sv || '') + ' ' + lead));
    ev.purpose = cardBill ? 'cardpay' : /\brent\b/.test(s) ? 'transfer' : billish ? 'billpay' : p2pNote ? 'transfer' : 'purchase';
    // what the total was made of, when the receipt prints the rent or the bill and the fees on top ("Rent amount ₹32,000,
    // Platform fee ₹384, GST on fee ₹69.12, Total paid ₹32,453.12"): the total moved, the rent and the fees its detail
    var baseA = amtOf(lv(/^(?:rent amount|rent|bill amount|maintenance amount|fee amount)$/));
    if (!baseA && (m = /\b(?:rent|maintenance)\s+of\s+(?:rs\.?|inr|₹)\s*(\d[\d,]*(?:\.\d+)?)/i.exec(body))) baseA = num(m[1]);
    if (baseA > 0 && baseA < amt - 0.005) ev.parts = [{ what: /\brent\b/.test(s + ' ' + lb.slice(0, 300)) ? 'rent' : 'bill', amt: baseA }, { what: 'fee', amt: money(amt - baseA) }];
    var bb = billRef(doc) ? [0, billRef(doc)] : null;
    if (bb) ev.ref = bb[1]; else if (rx) ev.ref = rx[1];
    // (paid by UPI from an account the mail names, "paid via | UPI · Kotak Mahindra Bank ••4402": still UPI)
    if (via.kind === 'upi' || (via.kind === 'account' && /\bupi\b/i.test(sv)) || (rxU && via.kind !== 'wallet')) ev.mode = 'UPI';
    return { events: [ev].concat(k === 'wallet' ? bal : []) };
  }
  /* A policy's own number, wherever the mail prints it */
  function policyNoOf(doc) {
    var np = kv(doc, /^policy (?:no|number|#|id)/), m;
    var pno = np ? (/[A-Z0-9][A-Z0-9\-\/]{5,24}/i.exec(np.value.replace(/(\d) (?=\d{3,})/g, '$1')) || [])[0] : '';
    // (a template's unfilled "<Policy No>" is no number: the subject's may be)
    if (pno && !/\d{4,}/.test(pno)) pno = '';
    if (!pno && (m = /policy\s*(?:no\.?|number|#|id)\s*[:.\-|]?\s*<?\s*([A-Z0-9][A-Z0-9\-\/]{5,24})\b/i.exec(doc.subject + '\n' + doc.flat)) && /\d{4,}/.test(m[1])) pno = m[1];
    if (!pno && (m = /\bpolicy\s+([A-Z]{0,3}\d{6,20})\b/i.exec(doc.subject + '\n' + doc.flat))) pno = m[1];
    // "Policy No/ Application No.: 12345678": the number printed for both
    if (!pno && (m = /policy\s*no\.?\s*\/\s*application\s*no\.?\s*[:.\-]?\s*([A-Z0-9]{6,20})/i.exec(doc.flat))) pno = m[1];
    // (a number in parts, "Star Comprehensive Insurance Policy (Individual) P/211200/01/2026/004512 is issued")
    if (!pno && (m = /\b(?:policy|insurance)\b[^\n]{0,60}?(?:^|[\s(\-:])([A-Z]{1,4}\/\d{3,}(?:\/[A-Z0-9]{1,10}){2,})(?![\/\w])/i.exec(doc.subject + '\n' + doc.flat.slice(0, 2000)))) pno = m[1];
    // (a number set out in groups after the word, "Health Guard Policy OG-26-1234-8403-00001234", "policy 2856/2026/1234/5678")
    if (!pno && (m = /\bpolicy\s+([A-Z]{0,4}[\-\/]?\d[0-9A-Z]*(?:[\-\/][0-9A-Z]+){2,8})\b/i.exec(doc.subject + '\n' + doc.flat)) && (m[1].match(/\d/g) || []).length >= 8 && m[1].length <= 32) pno = m[1];
    return pno && /\d{4,}/.test(pno) ? pno.toUpperCase() : '';
  }
  /* The rest of a policy's life, beyond a premium paid or due: an auto-debit that failed, the grace period, a revival,
     a free-look cancellation, a surrender, a loan against it, money it will pay (survival benefit, maturity), cover
     about to expire (motor, health), and a claim (registered, approved, settled, rejected, waiting on documents).
     Null when the mail is none of these; otherwise what it says, and whether the money it moved should be read too. */
  function insuranceSteps(doc, ctx) {
    var insurer = insurerIn(doc);
    if (!insurer) return null;
    var s = lc(doc.subject), body = lc(doc.flat.slice(doc.bodyAt, doc.bodyAt + 2500)).replace(/\s+/g, ' ');
    var both = s + ' ' + body;
    if (!/\bpolic(?:y|ies)\b|premium|\bclaim\b|insurance|\bcover\b/.test(both)) return null;
    // what the mail is about is in its subject and its opening lines: an insurer's footer mentions revival, free look,
    // surrender and claims in every mail
    var lead = s + ' ' + body.slice(0, 450);
    var pno = policyNoOf(doc);
    var base = function (action) { var e = { type: 'policy', action: action, insurer: insurer }; if (pno) e.policyNo = pno; return e; };
    var amtBy = function (re) { var p = kv(doc, re); if (p && p.amt > 0) return p.amt; var m = new RegExp('(?:' + re.source + ')[^₹\\d\\n]{0,40}?(?:rs\\.?|inr|₹)\\s*(\\d[\\d,]*(?:\\.\\d+)?)', 'i').exec(doc.flat); return m ? num(m[1]) : 0; };
    var firstAmt = function () { var a = amts(doc).filter(function (t) { return inBody(doc, t); })[0] || amts(doc)[0]; return a ? a.v : 0; };
    // a premium paid certificate (for income tax), an endorsement, a nominee or address change, a fund switch: no step
    if (/premium (?:paid )?certificate|tax certificate|80c|80d certificate/.test(s)) return { events: [] };
    // matured, its maturity money paid ("Maturity claim settled … your policy has matured … the maturity amount has
    // been credited"): the policy ended, and the money came in. Before the claims, whose words a maturity shares
    if (/\bhas matured\b|\bpolicy (?:has )?matured\b|\bmaturity (?:claim|amount|value|benefit|proceeds|payout)\b/.test(lead) && /(?:has been|have been|was|is) (?:successfully )?(?:credited|paid|settled|transferred|processed)|\bsettled\b/.test(lead) && !/will be|shall be|is due|payable on/.test(lead)) {
      return null;   // (the policy reader reads the money and says it matured)
    }
    // a claim
    if (/\bclaim\b/.test(s) || /\bclaim (?:no|number|id|reference)\b|\bcashless (?:request|claim)\b/.test(body.slice(0, 600))) {
      var st = /settled|has been paid|credited|reimburs\w* (?:is )?(?:processed|paid)/.test(lead) ? 'settled'
        : /approved|sanctioned|authori[sz]ed/.test(lead) ? 'approved'
        : /rejected|repudiated|denied|not admissible/.test(lead) ? 'rejected'
        : /query|deficien|documents? (?:are )?(?:pending|required)|additional documents/.test(lead) ? 'query'
        : /registered|intimat|received|initiated|lodged/.test(lead) ? 'registered' : '';
      if (st) {
        var c = { status: st }, cm = /claim\s*(?:no\.?|number|id|reference(?: no\.?)?)?\s*[:#\-|]?\s*([A-Z]{0,6}[\-\/]?\d[A-Z0-9\-\/]{4,30})/i.exec(doc.subject + '\n' + doc.flat);
        if (cm) c.no = cm[1].replace(/[\/\-]$/, '');
        var ca = amtBy(/settled amount|approved amount|amount (?:settled|approved|sanctioned|paid|credited)|claim amount|an amount of/);
        if (!ca && /settled|approved/.test(st)) ca = firstAmt();
        if (ca > 0) c.amt = ca;
        var ce = base('claim'); ce.claim = c;
        return { events: [ce], movesIn: st === 'settled' ? 'payout' : '' };
      }
    }
    // an auto-debit or payment of the premium that didn't go through
    if (/(?:auto[- ]?debit|\becs\b|\bnach\b|standing instruction|e-?mandate|si\b|premium payment|payment)[^.]{0,80}(?:unsuccessful|failed|could not be processed|not be processed|dishono(?:u)?red|bounced|declined|rejected|was not successful)/.test(lead)) {
      var f = base('debitfailed'), fp = amtBy(/premium(?: amount)?|amount|auto debit of/) || firstAmt();
      if (fp > 0) f.premium = fp;
      var fd = labeledDate(doc, /due (?:on|date)|was due on|due on/);
      if (fd) f.due = fd;
      return { events: [f], failedOk: true };
    }
    if (/\b(?:has been|is|was) (?:successfully )?(?:revived|reinstated)\b|revival (?:is |has been )?(?:successful|processed|done|completed)/.test(lead)) {
      var rv = base('revived'), ra = amtBy(/revival amount(?: received)?|amount (?:received|paid)/);
      if (ra > 0) rv.premium = ra;
      return { events: [rv] };
    }
    // a proposal the insurer cancelled ("due to Non Acceptance of Counter Offer … The Premium Paid will be refunded"):
    // the premium is to come back, nothing has yet
    if (/\bproposal\b/.test(lead) && /\b(?:cancel+ed|withdrawn|rejected|declined)\b/.test(lead) && /\b(?:premium|amount)(?: paid)? (?:will|shall) be refunded\b|\brefund (?:will|shall) be (?:processed|initiated|credited)\b/.test(lead) && !/(?:has been|have been|was) (?:refunded|credited)\b/.test(lead)) {
      var rfx = { type: 'expect', dir: 'in', what: 'refund', party: insurer }, rfa = amtBy(/premium paid|refund amount|amount paid/);
      if (rfa > 0) rfx.amt = rfa;
      return { events: [rfx] };
    }
    if (/free[- ]?look/.test(lead) && /\bcancel(?:led|lation)\b/.test(lead) && /\b(?:has been|is|was) (?:successfully )?(?:cancelled|processed)|cancellation (?:is |has been )?(?:processed|completed|done)/.test(lead)) return { events: [base('cancelled')], keepExpects: true };
    if (/\bsurrender/.test(lead) && /(?:has been|is|was) (?:successfully )?(?:processed|credited|paid|settled|approved)|surrender value (?:of [^.]{0,30})?(?:has been|was) (?:credited|paid)/.test(lead)) return { events: [base('surrendered')], movesIn: 'payout', keepExpects: true };
    if (/loan (?:against|on) (?:your )?policy|policy loan/.test(lead) && /disbursed|credited/.test(lead) && !/eligible|avail|apply|get a loan|offer/.test(s)) return { events: [], movesIn: 'loan' };
    // money the policy will pay: a survival benefit, a maturity, an annuity, due on a day (not yet in the account)
    if (/survival benefit|maturity (?:amount|benefit|value|claim)|money[- ]?back|annuity/.test(lead) && /(?:is |are )?(?:payable|due) on|will be (?:credited|paid|transferred)|shall be (?:credited|paid)|is due for payment/.test(lead) &&
        !/(?:has been|have been|was) (?:credited|paid|transferred)/.test(lead)) {
      var pa = amtBy(/survival benefit|maturity (?:amount|benefit|value)|amount payable|payout/) || firstAmt();
      if (!(pa > 0)) return null;
      var xp = { type: 'expect', dir: 'in', what: 'payout', amt: pa, party: insurer };
      var pdd = labeledDate(doc, /payable on|due on|will be credited on|on or after/);
      if (pdd) xp.on = pdd;
      return { events: [xp] };
    }
    // (a renewal notice the policy reader reads whole, premium, cover and all, is read there)
    var plainRead = function () { var pl0 = policies(doc, ctx); return pl0.length && pl0[0].premium > 0; };
    // cover about to end (motor, health, travel, home): renew by its day
    if (!plainRead() && /expir(?:es|ing|y)|will expire|due for renewal|renewal (?:is )?due|renew (?:now|before|today)|policy (?:is )?ending/.test(s + ' ' + body.slice(0, 600)) && !/\b(?:has|have) (?:expired|lapsed)\b|renewed|thank you for renewing/.test(both) && !ctx.promo) {
      var dueE = base('due');
      var dd0 = kv(doc, /expiry date|valid (?:till|upto|until)|policy end date|renewal date|due date/);
      var de = dd0 && dd0.date ? dd0.date : labeledDate(doc, /expires on|expiring on|will expire on|valid (?:till|upto|until)|renew (?:it )?(?:before|by)|ends on|renewal date|due on|due date/);
      if (de) dueE.due = de;
      var pr = amtBy(/renewal premium|premium(?: amount)?|renew (?:now )?(?:for|at)|total premium/) ;
      if (pr > 0) dueE.premium = pr;
      if (!de && !pr) return null;
      return { events: [dueE] };
    }
    // past its due day, in the grace period: still due
    if (!plainRead() && /grace period/.test(lead) && /\bin the grace period|grace period (?:ends|is till|till|until|of \d+ days (?:ends|is on))|within the grace period/.test(lead) && !/\b(?:has|have) lapsed\b/.test(lead)) {
      var g = base('due'), gp = amtBy(/premium(?: amount)?|amount/) || firstAmt();
      if (gp > 0) g.premium = gp;
      var gd = labeledDate(doc, /was due on|due on|due date/);
      if (gd) g.due = gd;
      return { events: [g] };
    }
    return null;
  }
  function policies(doc, ctx) {
    var s = lc(doc.subject), head = doc.head;
    var insurer = insurerIn(doc), m0;
    if (!insurer && (m0 = /\b([A-Z][A-Za-z]+(?: [A-Z][A-Za-z]+)?)\s+(?:policy|insurance)\s+(?:issued|renewed|purchased|bought)\b/.exec(doc.subject.replace(/\b(?:POLICY|INSURANCE|ISSUED|RENEWED|PURCHASED|BOUGHT)\b/g, function (w) { return w.toLowerCase(); })))) insurer = m0[1];
    if (!insurer) return [];
    var fromInsurer = doc.inst && doc.inst.kind === 'insurer';
    if (!fromInsurer && !/\bpolicy\b|premium|insurance/.test(s)) return [];
    if (!/\bpolicy\b|premium|insurance|sum assured|sum insured/.test(head)) return [];
    if (!/payment acknowledg|premium (?:paid|received|receipt)|payment (?:received|success)/.test(s) && /\b(?:otp|one[- ]time password|benefit illustration|sales illustration|quote|save (?:up ?to|upto)|install|download (?:the|our) app|survey|feedback|webinar|newsletter|counter offer|proposal|application (?:no|number|is under|status)|under review|additional information|medical (?:report|test)|questionnaire|e-?kyc|kyc|download documents|review and confirm|status report|payment pending|is failing|complete your|missing|add (?:nominee|details)|update (?:your )?(?:nominee|details))\b/.test(s)) return [];
    // an insurer's service note isn't a policy's step: a fraud warning, "update your address", "queries? here's how
    // to reach us", a payment-method change request, "check your policy on Bima Central"
    var paidWords = /payment acknowledg|premium (?:paid|received|receipt)|payment (?:received|success)/.test(s);
    if (!paidWords && /\bbeware\b|\bfraud|\bqueries\b|how you can|reach (?:out|us)|update your (?:address|kyc|contact|email|e-?mail|mobile|nominee|bank)|verify\/?update|check your .{0,40}\bon\b|payment method change|change request|service request|\bnominee\b|\bkyc\b|know your|\btips\b|\bfaq/.test(s + ' ' + doc.lead.slice(0, 200))) return [];
    // a policy the insurer could not issue ("Health insurance policy not issued due to …"): no policy
    if (/\bnot (?:been )?issued\b|\b(?:could|can) ?not be issued\b|\bunable to issue\b/.test(s + ' ' + doc.lead.slice(0, 300))) return [];
    // a standing instruction or auto-debit set up, changed or stopped for the premium: the mandate is the mail's step
    // (mandates() reads it), and the policy's details printed beside it are no premium due
    if (!paidWords && /(?:standing instruction|auto[- ]?debit|auto[- ]?pay|e-?mandate|\bnach\b|\bsi\b)[^.\n]{0,40}\b(?:registered|registration|updated?|activated|activation|set up|setup|enabled|modified|changed|cancel+ed|cancellation|deactivated|de-?registered|successful(?:ly)?|confirmed)\b|\b(?:registered|registration|updated|activated|set up|enabled|modified)\b[^.\n]{0,30}(?:standing instruction|auto[- ]?debit|auto[- ]?pay|e-?mandate|\bnach\b)/.test(s) &&
        !/premium (?:is )?due|\bdue (?:on|date|for)\b|reminder|unsuccessful|\bfailed\b|declined|bounced|dishono|lapse/.test(s)) return [];
    // money the policy pays out (a survival benefit, an annuity's cash income, a maturity, a claim): coming in
    if (/\b(?:cash income|survival benefit|maturity (?:benefit|amount|claim)|annuity|claim (?:amount|settled|settlement)|payout)\b/.test(s + ' ' + doc.lead.slice(0, 400)) && /credited|processed|paid|settled|payable|released/.test(s + ' ' + doc.lead.slice(0, 500))) {
      var po = amts(doc).filter(function (t) { return /net|payable|amount/.test(lc(doc.flat.slice(Math.max(0, t.s - 60), t.s))); });
      var pv = po.length ? po[po.length - 1] : amts(doc)[0];
      if (!pv) return [];
      // paid already (the subject says credited, or the mail gives the bank transfer's date and reference): it came in
      var txd = kv(doc, /^(?:transaction|payment|credit|transfer|payout) date$/), refp = kv(doc, /^(?:reference|utr|transaction ref(?:erence)?)(?: (?:no|number|id))?\.?$/);
      // (the amount's own sentence says it was paid: "payout of INR 65,432.10 for Maturity has been credited to ... AXIS
      // BANK account number ending with xxxx1234 via UTRN no EXMPN5... on 12/04/2026", wherever it sits in the mail)
      var psen = sentenceAt(doc, pv.s), said = lc(doc.flat.slice(psen.s, psen.e));
      var paidOut = /(?:has been|have been|was|were|is) (?:successfully )?(?:credited|paid|transferred|deposited|remitted|disbursed)\b|credited (?:to|in(?:to)?) your|paid (?:to|into) your/.test(said.replace(FUTURE_VERB, ''));
      if (paidOut || /has been credited|credited (?:to|in(?:to)?) your|paid (?:to|into) your|has been paid|transferred to your/.test(s + ' ' + doc.lead.slice(0, 400)) || (txd && txd.date && refp)) {
        var acp = kv(doc, /^(?:bank )?(?:account|a\/c) (?:no|number)\.?$/), bnp = kv(doc, /^bank(?: name)?$/);
        var via = { kind: 'account' };
        var bk = bnp && E.issuerIn ? E.issuerIn(bnp.value, false) : null;
        if (bk) via.inst = bk.short;
        var dg = acp ? (/(\d{2,4})\s*$/.exec(acp.value.replace(/[^\dx*•]/gi, '')) || [])[1] : '';
        if (dg) via.last4 = dg;
        if (!via.last4 || !via.inst) {
          var sv = viaFor(doc, pv, 'in');
          if (!via.last4 && sv.last4) via.last4 = sv.last4;
          if (!via.inst && sv.inst) via.inst = sv.inst;
          if (!via.inst && E.issuerIn) { var bk2 = E.issuerIn(doc.flat.slice(psen.s, psen.e), false); if (bk2) via.inst = bk2.short; }
        }
        var pdt = txd && txd.date ? txd.date : (dateFor(doc, pv).date || '');
        if (!pdt) { var dn = doc.toks.filter(function (x) { return x.t === 'DATE' && x.s > pv.e && x.s < psen.e && !x.rel; })[0]; if (dn) pdt = dn.v; }
        var mv = { type: 'move', dir: 'in', amt: pv.v, date: pdt || doc.ref, via: via, party: insurer, purpose: 'payout', ev: { amt: pv.raw } };
        if (refp) { var rv = /[A-Z0-9]{6,}/i.exec(refp.value); if (rv) mv.ref = rv[0]; }
        if (!mv.ref) { var ru = /\b(?:utrn?|reference)(?: no\.?| number)?\s*[:\-]?\s*([A-Z0-9]{8,})/i.exec(doc.flat.slice(psen.s, psen.e)); if (ru) mv.ref = ru[1]; }
        // (a maturity paid: the policy has ended too)
        if (/\bhas matured\b|\bpolicy (?:has )?matured\b|\bmaturity (?:claim|amount|value|benefit|proceeds|payout)\b/.test(s + ' ' + doc.lead.slice(0, 500))) {
          var mte = { type: 'policy', action: 'matured', insurer: insurer, date: doc.ref }, mno = policyNoOf(doc);
          if (mno) { mte.policyNo = mno; return [mv, mte]; }
        }
        return [mv];
      }
      return [{ type: 'expect', dir: 'in', what: 'payout', amt: pv.v, party: insurer }];
    }
    // the subject says what the mail is; the body decides only when the subject doesn't
    var subjAct = /\bhas matured\b|policy (?:has )?matured|maturity of your policy/.test(s) ? 'matured'
      : /bonus letter|bonus (?:declared|accrued|statement)|annual (?:policy )?statement|unit statement|fund value statement|(?:ulip )?fund statement|policy statement/.test(s) ? 'statement'
      : /\blapsed\b/.test(s) && !/avoid|before/.test(s) ? 'lapsed'
      : /renewal (?:is )?(?:successful|done|confirmed)|\b(?:successfully )?renewed\b/.test(s) ? 'renewed'
      : /payment received|premium (?:paid|received|receipt)|\breceipt\b|payment (?:is )?success|payment acknowledg/.test(s) ? 'paid'
      : /\bissued\b|policy document with|policy copy|policy bond|policy kit|welcome to (?:the )?\S+(?: \S+)? family|\bbooked\b|policy (?:pdf|document) (?:is )?(?:here|attached)/.test(s) ? 'issued'
      : /premium (?:is )?due|\bdue\b|reminder|pay now|renewal notice/.test(s) ? 'due' : '';
    var lapsedBody = /\b(?:has|have|had)\s+(?:expired|lapsed)\b|\bpolicy (?:is|has) (?:now )?lapsed\b|\bexpired on\b/.test(doc.lead);
    var action = subjAct && !(lapsedBody && subjAct === 'due') ? subjAct
      : lapsedBody ? 'lapsed'
      : /is now insured|policy (?:pdf|document|copy) is attached|\byour policy(?: schedule| document| copy| pdf)? (?:is|has been) (?:attached|enclosed)\b|\bpolicy\b[^.\n]{0,50}\b(?:has been|is|was)\s+(?:successfully\s+)?issued|\bpolicy (?:no|number)\b[^.\n]{0,100}\b(?:has been|is|was)\s+(?:successfully\s+)?issued\b/.test(head) ? 'issued'
      : /\bpayment\b[^.\n]{0,90}\b(?:has been|was|is)\s+(?:successfully\s+)?received\b/.test(head) ? 'paid'
      : /lapsed|lapse/.test(s) && !/avoid|before/.test(s) ? 'lapsed'
      : /renewal (?:is )?(?:successful|done|confirmed)|renewed|successfully renewed|congratulations on (?:securing|renewing)/.test(head) ? 'renewed'
      : /premium (?:is )?due|due for (?:debit|renewal|payment)|renewal premium is due|payment is due|premium due|renewal (?:due|reminder|notice)|pay (?:your )?premium|is due on|is due!/.test(head) ? 'due'
      : /premium receipt|payment received|premium (?:paid|received|acknowledg)|receipt for (?:your )?premium|thank you for (?:your )?(?:premium )?payment|acknowledgement|premium payment (?:is )?successful/.test(head) ? 'paid'
      : /policy (?:has been |is )?issued|policy (?:document|copy|pdf|kit|bond) (?:is |has been )?(?:attached|enclosed|here|sent|dispatched)|your policy (?:is|has been) (?:ready|issued|generated)|issued successfully|congratulations on (?:your|buying|purchasing|choosing)|policy issued/.test(head) ? 'issued' : '';
    if (!action) return [];
    var ev = { type: 'policy', action: action, insurer: insurer };
    var m, pno = policyNoOf(doc);
    if (pno) ev.policyNo = pno;
    var pl = kv(doc, /^(?:(?:insurance )?plan|product)(?: name)?$|^policy name$/);
    if (pl && /^\s*(?:policy (?:no|number)|premium|sum (?:assured|insured)|[a-z ]*\bdate\b|amount)/i.test(pl.value)) pl = null;   // a header row, not a plan's name
    if (pl && !/[<>]/.test(pl.value)) ev.plan = trim(pl.value).slice(0, 60);
    else if ((m = /\b(?:insurance|policy|cover) (?:of|for) your ([A-Za-z0-9][^\n.]{2,50}?) (?:has|have|had|is|will)\b/i.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 800)))) ev.plan = trim(m[1]);
    // ("Plan:HDFC SL Example Star Super Premium |": a plan may have "Premium" in its name; a header row starts with it)
    else if ((m = /(?:plan(?:\s*name)?|product(?:\s*name)?)\s*[:\-|]\s*([A-Za-z][A-Za-z0-9+ ()&'\-]{3,60}?)(?:\n|\s{2,}|\||$)/i.exec(doc.flat)) && !/^\s*(?:policy (?:no|number)|premium|sum (?:assured|insured)|[a-z ]*\bdate\b|amount)|\b(?:policy (?:no|number)|sum (?:assured|insured)|amount)\b/i.test(m[1])) ev.plan = trim(m[1]);
    // ("The premium for your Tata AIA Example Guarantee Supreme policy is due on …")
    else if ((m = /\bpremium (?:for|of|on) your ([A-Z][A-Za-z0-9+&'’ \-]{3,60}?) (?:policy|plan)\b/.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 1500))) && m[1].split(/\s+/).length >= 2) ev.plan = trim(m[1]);
    else if ((m = planBesideCode(doc, insurer))) ev.plan = m;
    // (a label and its value on one line with nothing between them, "Policy name Bajaj Life eTouch")
    else if ((m = /^(?:[Pp]olicy|[Pp]lan|[Pp]roduct) [Nn]ame[ \t]+([A-Z][A-Za-z0-9+&'’ \-]{2,50})$/m.exec(doc.flat.slice(doc.bodyAt)))) ev.plan = trim(m[1]);
    // (a booking flattened to one line, "… Policy name Bajaj Life Etouch Plan Application number 61643… Life Cover ₹2.5
    // Crore": the name runs to the next label)
    else if ((m = /\b[Pp]olicy [Nn]ame[ \t]+([A-Z][A-Za-z0-9+&'’ \-]{2,50}?)\s+(?=(?:[Aa]pplication|[Pp]olicy|[Pp]roposal|[Ll]ife [Cc]over|[Ss]um [Aa]ssured|[Pp]remium|[Cc]over)\b)/.exec(doc.flat.slice(doc.bodyAt)))) ev.plan = trim(m[1]);
    // ("my:Optima Secure - Optima Super Secure": the brand's prefix off, and of a family and its variant, the variant)
    if (ev.plan) {
      ev.plan = trim(String(ev.plan).replace(/^[a-z]{1,4}:\s*/, ''));
      var fam = /^(.{3,40}?)\s+[-–]\s+(.{3,40})$/.exec(ev.plan);
      if (fam && fam[1].split(/\s+/).some(function (w) { return w.length > 2 && fam[2].indexOf(w) >= 0; })) ev.plan = trim(fam[2]);
    }
    // a motor policy's vehicle, by its make and model ("Make/Model: Triumph Scrambler 400 X"), else the subject's
    // "Policy for <vehicle>"
    var mm = kv(doc, /^(?:make\s*(?:\/|&|and)\s*model|vehicle(?: make(?:\s*(?:\/|&|and)\s*model)?| model| name)?|model|make)$/);
    if (mm && /[a-z]{2}/i.test(mm.value) && !/^\s*(?:no|number|registration)\b/i.test(mm.value)) ev.model = trim(String(mm.value).replace(/\s*\|.*$/, '')).slice(0, 50);
    else if ((m = /\b(?:bike|car|two[- ]wheeler|motor|vehicle|auto)\s+insurance(?:\s+policy)?\s+for\s+(?:your\s+)?([A-Z][A-Za-z0-9 .+\-]{2,40}?)\s*(?:[-|:]|$)/i.exec(doc.subject || ''))) ev.model = trim(m[1]);
    // (LIC's "Plan | 914" is the plan's number, not its name)
    if (ev.plan && !/[a-z]{3}/i.test(ev.plan)) { if (/^\s*\d{2,4}\s*$/.test(ev.plan)) ev.planNo = trim(ev.plan); delete ev.plan; }
    // the premium: each instalment, as a receipt or a reminder prints it; a figure labelled for the year ("Annualized
    // premium", "Annual premium") is the year's, and the premium only when it is the one printed
    var pp = null, pyp = null;
    for (var pi = 0; pi < doc.pairs.length; pi++) {
      if (!/premium/.test(doc.pairs[pi].key)) continue;
      if (YEAR_PREMIUM.test(doc.pairs[pi].key)) { if (!pyp) pyp = doc.pairs[pi]; } else if (!pp) pp = doc.pairs[pi];
    }
    if (!pp) pp = pyp;
    // (a motor policy's cover is its vehicle's insured declared value, the IDV)
    var cp = kv(doc, /sum (?:assured|insured)|\bcover|\bidv\b|insured declared value/);
    var prem = pp && pp.amt > 0 ? pp.amt : null, cov = cp && cp.amt > 0 && !cp.amtCur ? cp.amt : null;
    // (a travel plan's cover in dollars, "Sum insured | $50,000", is never that many rupees: told apart as its currency's)
    if (cp && cp.amt > 0 && cp.amtCur) { ev.coverFx = cp.amt; ev.coverCur = cp.amtCur; }
    var pyear = pyp && pyp.amt > 0 ? pyp.amt : 0;
    // ("What you pay every year? (Annualized premium) ₹ 24,000": the year's, in a sentence)
    if (!pyear && (m = /\bannuali[sz]ed premium\)?\s*[:\-|]?\s*(?:₹|rs\.?|inr)\s*(\d[\d,]*(?:\.\d+)?)/i.exec(doc.flat))) pyear = num(m[1]);
    // the premium said in a sentence is the whole of it (a table can list the plan and each rider apart)
    amts(doc).forEach(function (t) { var r = roleOf(doc, t); if (r === 'premium' && !t.pair && (prem === null || t.v > prem)) prem = t.v; else if (r === 'premium' && prem === null) prem = t.v; if (r === 'cover' && cov === null) cov = t.v; });
    if (prem === null && (action === 'paid' || action === 'due' || action === 'renewed')) { var f = amts(doc).filter(function (t) { return t.role === 'moved' || t.role === 'total' || t.role === 'due' || t.role === 'other'; })[0]; if (f) prem = f.v; }
    // (the cover on a line of its own with its label and no colon, "Cover ₹1 Crore")
    if (cov === null) amts(doc).forEach(function (t) { if (cov === null && /^(?:life )?cover(?: amount)?|^sum (?:assured|insured)$/i.test(trim(doc.flat.slice(doc.flat.lastIndexOf('\n', t.s - 1) + 1, t.s))) && t.v >= 10000) cov = t.v; });
    if (prem !== null && cov !== null && prem >= cov) prem = null;
    if (prem >= 100) ev.premium = prem;
    if (pyear >= 100 && !(cov !== null && pyear >= cov)) ev.premiumYear = pyear;
    if (cov >= 10000) ev.cover = cov;
    if (action === 'due' || action === 'renewed') { var dd = kv(doc, /next due date|due date|renewal date|premium due on|^due on$|expiry date|policy end date/); var d = dd && dd.date ? dd.date : dueDateIn(doc) || labeledDate(doc, /(?:next due date|due date|renewal date|premium due on|due on|is due on|due for renewal on|expires on|expiring on|will expire on|renew (?:it )?before|will be (?:auto(?:matic(?:ally)?)?[- ]?)?(?:debited|charged|paid)(?:[^\n]){0,100}?\b(?:on|by))/); if (d) ev.due = d; }
    policyFacts(doc, ev);
    policyNames(doc, ev);
    // a statement or a maturity note says something of a policy only when it names it
    if ((action === 'statement' || action === 'matured') && !ev.policyNo) return [];
    if (action === 'statement' || action === 'matured') { delete ev.premium; delete ev.premiumYear; ev.date = doc.ref; }
    // (a statement's figures are no premium paid, but the premium it says the next due day asks for is the policy's)
    if (action === 'statement' && doc.nextPremium > 0) ev.premium = doc.nextPremium;
    return [ev];
  }
  /* how often a premium comes, from the word for it: "Half-Yearly", "Semi-Annual", "HLY", "Qly", "Mly", "ECS Monthly",
     "One Time", "Single Premium" (a half before an annual: "Semi-Annual" is twice a year) */
  function premiumEvery(v) {
    var w = lc(v).replace(/[^a-z ]+/g, ' ').trim();
    if (!w || w.length > 40) return '';
    if (/\b(?:month|monthly|mly|mthly|mnthly)\b/.test(w)) return 'Monthly';
    if (/\b(?:quarter|quarterly|qly|qtly|qtrly)\b/.test(w)) return 'Quarterly';
    if (/\b(?:half|halfyearly|semi|semiannual|semiannually|hly|hlyly)\b|\bhalf ?yearly\b|\bsemi ?annual/.test(w)) return 'Half-yearly';
    if (/\b(?:single|one ?time|onetime|lump ?sum|sp)\b/.test(w)) return 'Single';
    if (/\b(?:annual|annually|yearly|yly|year)\b/.test(w)) return 'Yearly';
    return '';
  }
  // a premium labelled as the year's: "Annualized premium", "Annual premium", "Premium per annum", "Yearly premium"
  var YEAR_PREMIUM = /annuali[sz]ed|\bannual\b|per annum|\byearly\b|\ba year\b|every year/;

  /* the plan's name where the mail prints it on a line of its own, between the policy's number and its product code
     ("Policy No. 20000001" / "HDFC Life Example Plus" / "UIN: 101N000V01"): the line just above the code, when it
     sits under the number or starts with the insurer's own name */
  function planBesideCode(doc, insurer) {
    var clean = function (l) { return trim(String(l || '').replace(/[|#*]+/g, ' ')); };
    for (var i = 2; i < doc.lines.length; i++) {
      if (!/^\s*\|?\s*uin\s*(?:no\.?)?\s*[:\-]?\s*\d{3}[LN]\d{3}V\d{2}\b/i.test(clean(doc.lines[i]))) continue;
      var j = i - 1;
      while (j > 1 && !clean(doc.lines[j])) j--;
      var cand = clean(doc.lines[j]), above = clean(doc.lines[j - 1] || '');
      if (!/^[A-Za-z][A-Za-z0-9+&'’() \-]{4,68}[A-Za-z0-9+)]$/.test(cand) || cand.split(/\s+/).length < 2) continue;
      if (/\b(?:policy|premium|sum (?:assured|insured)|dear|date|amount|uin|no\.?|number)\b|:/i.test(cand)) continue;
      var first = lc(String(insurer || '').split(/\s+/)[0] || '');
      if (/^\s*policy\s*(?:no\.?|number|#)\s*[:.\-]?\s*[A-Z]{0,3}\d{5,}/i.test(above) || (first.length >= 3 && lc(cand).indexOf(first) === 0)) return cand.slice(0, 60);
    }
    return '';
  }

  /* whose a policy is, as its mail prints it: the policyholder (or proposer), the person insured (the life assured, or
     each member a floater covers) and the nominee; with no holder printed, the person the mail is addressed to ("Dear
     …"). A name is kept as printed without its title ("Mr.", "Smt."), an all-capitals name in ordinary capitals
     ("ROHAN EXAMPLE" is "Rohan Example"); words that are no one's name ("Customer", "Policyholder") are none. The
     engine decides from these whose the policy is (engine.js, policyPerson). */
  var NOT_A_NAME = /^(?:(?:valued|dear|respected|esteemed)\s+)?(?:customers?|clients?|sir|madam|sir\s*\/\s*madam|policy\s*holders?|holders?|insured|members?|users?|investors?|patrons?|friends?|partners?|applicants?|proposers?|beneficiar(?:y|ies)|nominees?|owners?|assured|life assured|team|all|there|guests?|subscribers?|parents?|family|patient|sir or madam|valued customer|customer care)$/i;
  function personName(s) {
    var v = trim(String(s || '').replace(/ /g, ' ')).replace(/^(?:(?:mr|mrs|ms|miss|mx|dr|shri|sri|smt|kumari|kum|km|master|prof|capt|col|maj|lt|late)\.?\s+)+/i, '');
    // ("Rohan Example (Self)", "Rohan Example, Mumbai", "Rohan Example Thank you for choosing …")
    v = v.replace(/\s*[,(;|].*$/, '').replace(/\s+(?:thank|thanks|greetings|welcome|we|your|congratulations|hope|warm|hearty|this|please|kindly|as|in|on|for|with|the|it|you|and)\b.*$/i, '');
    v = trim(v).replace(/([A-Za-z]{2,})\.+$/, '$1');
    if (!/^[A-Za-z][A-Za-z.'’ \-]{0,58}[A-Za-z.]$/.test(v) || NOT_A_NAME.test(v)) return '';
    var w = v.split(/\s+/);
    if (w.length > 5 || w.some(function (x) { return x.length > 20; }) || !w.some(function (x) { return x.replace(/\./g, '').length >= 3; })) return '';
    if (v === v.toUpperCase() || v === v.toLowerCase()) v = capWords(v.toLowerCase());
    return v;
  }
  function policyNames(doc, ev) {
    // (a label and its name on one line, "Name of Policyholder : Rohan Example", read off the line itself when the
    // pairs took two such lines for labels over the lines under them)
    var pick = function (re, words) {
      var p = kv(doc, re), n = p ? personName(p.value) : '';
      if (n) return n;
      var lm = new RegExp('^[\\s|•*]*(?:name of (?:the )?)?(?:' + words + ')(?:\'s|’s)?(?: name)?\\s*[:\\-|]\\s*([^\\n|]{2,60})', 'im').exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 6000));
      return lm ? personName(lm[1]) : '';
    };
    var holder = pick(/^(?:name of (?:the )?)?(?:policy ?holder|proposer|policy owner)(?:'s|’s)?(?: name)?$/, 'policy ?holder|proposer|policy owner');
    var insured = pick(/^(?:name of (?:the )?)?(?:life assured|life insured|insured(?: person| member| life)?|person insured)(?:'s|’s)?(?: name)?$|^insured name$/, 'life assured|life insured|insured(?: person| member| life)?|person insured');
    var nominee = pick(/^(?:name of (?:the )?)?nominee(?:'s|’s)?(?: name)?(?:\s*\d)?$/, 'nominee'), m;
    // a floater's members: a table of names with their relationship, age or birthday
    var nameCol = /^(?:name of (?:the )?)?(?:insured|members?)(?: (?:person|persons|member|members|name))?$|^name(?: of (?:the )?(?:insured|member|life assured|insured person))?$|^(?:insured|member)(?:'s|’s)? name$/;
    var tb = tableWith(doc, nameCol, /relation|^age\b|dob|date of birth|gender/);
    var members = [];
    if (tb) tb.rows.forEach(function (r) {
      var n = personName(r.cell(nameCol));
      if (n && members.indexOf(n) < 0 && members.length < 12) members.push(n);
    });
    // the members as a list after their label ("Insured persons: Suresh Example, Kamala Example", "Insured Members |
    // Vikram Example, Neha Example", "Insured: Vikram Example (Self), Neha Example (Spouse)"), or in the policy's own
    // sentence ("your Senior First policy covering Suresh Example and Kamala Example")
    if (members.length < 2) {
      var listRe = /^(?:insured(?: (?:persons?|members?|lives?|names?))?|(?:members?|persons?|lives?) (?:insured|covered)|covered (?:members?|persons?|lives?)|name of (?:the )?insured (?:persons|members))$/;
      var lv = (kv(doc, listRe) || {}).value || '';
      if (!/[,&;]|\band\b/i.test(lv)) {
        lv = '';
        var ll = /^[\s|•*]*(?:insured(?: (?:persons?|members?|lives?))?|(?:members?|persons?|lives?) (?:insured|covered)|covered (?:members?|persons?|lives?))\s*[:\-|]\s*([^\n|]{3,200})$/im.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 6000));
        if (ll) lv = ll[1];
      }
      var NAMEW = '[A-Z][a-z]+(?: [A-Z][a-z]+){1,3}';
      if (!/[,&;]|\band\b/i.test(lv) && (m = new RegExp('\\b(?:policy|plan|cover)\\s+(?:covering|that covers|insuring)\\s+(' + NAMEW + '(?:\\s*,\\s*' + NAMEW + ')*\\s+and\\s+' + NAMEW + ')').exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 3000))) &&
          !/\b(?:death|disability|hospital\w*|cover|benefits?|expenses?|accidents?|illness\w*|treatment|care|insurance|policy|plan)\b/i.test(m[1])) lv = m[1];
      var listed = [];
      // (a count with the names in brackets: "Members covered: 6 (Hitesh, Payal, Dhruv, Diya, Jayantilal, Hansa)")
      var lvc = /^\s*\d{1,2}\s*(?:members?|persons?|lives?|adults?)?\s*[(\[]([^)\]]{3,200})[)\]]\s*\.?\s*$/i.exec(lv);
      if (lvc) lv = lvc[1];
      if (/[,&;]|\band\b/i.test(lv)) lv.split(/\s*(?:,|;|&|\band\b)\s*/i).forEach(function (x) { var n = personName(x); if (n && listed.indexOf(n) < 0 && listed.length < 12) listed.push(n); });
      if (listed.length >= 2) members = listed;
    }
    if (members.length === 1 && !insured) insured = members[0];
    /* the policy's card ("To download your policy copy … my:Optima Secure / Vikram Example / DOWNLOAD"): the plan's name
       printed again with the one person it covers under it. A name there that isn't the one the mail greets is the
       person insured (a parent's health cover bought and paid by their son, the mail written to him) */
    if (!insured && members.length < 2 && ev.plan && ev.plan.length >= 6) {
      var pl0 = ev.plan.toLowerCase(), lines0 = doc.flat.slice(doc.bodyAt).split('\n').map(function (x) { return trim(x.replace(/\|/g, ' ')); }).filter(Boolean);
      for (var li = lines0.length - 2; li >= 0; li--) {
        if (lines0[li].toLowerCase().indexOf(pl0) < 0 || lines0[li].length > pl0.length + 40) continue;
        var cand0 = personName(lines0[li + 1]);
        // (a card: the name under the plan, a button under the name, or the mail saying it covers one person)
        var card0 = /^(?:download|view|get|open)\b|policy copy|e-?card/i.test(lines0[li + 2] || '') || /\bno\.? of (?:members|persons|insured)\W{0,4}1\s*(?:adult|member|person)?\b/i.test(doc.flat);
        if (!card0 || /\b(?:premium|amount|instal+ment|please|find|attached|details|due|date|receipt|renewal|summary|number|total|paid)\b/i.test(cand0 || '')) break;
        var greet0 = (/(?:^|[\s|#>])dear\s+([^\n,|!:;]{2,60}?)\s*(?:[,!:;\n|]|$)/i.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 900)) || [])[1];
        if (cand0 && cand0.split(/\s+/).length >= 2 && !/download|policy|plan|secure|insurance|view|click/i.test(cand0) && personName(greet0 || '') !== cand0) insured = cand0;
        break;
      }
    }
    // "your nominee Asha would be paid"
    if (!nominee && (m = /\byour nominee,?\s+([A-Z][A-Za-z.]*(?:\s+[A-Z][A-Za-z.]*){0,3}?)\s+(?:would|will|shall|gets?|is|receives?)\b/.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 4000)))) nominee = personName(m[1]);
    // whom the mail is addressed to ("Dear …"): the holder, for the engine, when none is printed
    var to = (m = /(?:^|[\s|#>])dear\s+([^\n,|!:;]{2,60}?)\s*(?:[,!:;\n|]|$)/i.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 900))) ? personName(m[1]) : '';
    if (holder) ev.holder = holder;
    if (to && to !== holder) ev.to = to;
    if (members.length >= 2) { ev.members = members; ev.insured = members.join(', '); }
    else if (insured) ev.insured = insured;
    if (nominee) ev.nominee = nominee;
  }

  /* what a policy's mail says of the policy itself, wherever it says it: its UIN (IRDAI's product code, whose fourth
     character says linked, "L", a ULIP, or not, "N"), when it started, its term and paying term, how often it's paid,
     its fund value and the day of it, the bonus accrued, and whether it's in force */
  function policyFacts(doc, ev) {
    var flat = doc.flat, m;
    if ((m = /\b(\d{3}([LN])\d{3}V\d{2})\b/.exec(flat))) { ev.uin = m[1]; ev.linked = m[2] === 'L'; }
    var st = kv(doc, /^(?:policy )?(?:start|commencement|inception|risk commencement)(?: date)?$|^date of (?:commencement|inception|risk commencement)|^policy (?:start|commencement|issue) date$|^date of issue of (?:the )?policy$/);
    if (st && st.date && st.date <= doc.ref) ev.start = st.date;
    // when the cover ends ("Policy End Date", "Valid till", "Period of insurance … to")
    var en = kv(doc, /^(?:policy )?(?:end|expiry|expiration) date$|^(?:valid|cover(?:ed)?) (?:till|upto|until)$|^policy (?:period )?(?:to|end(?:s)? on)$|^date of expiry$|^policy expiry$/);
    if (en && en.date && en.date > doc.ref) ev.end = en.date;
    // the period the cover runs, as one line ("Period of Insurance: 01/07/2026 to 30/06/2027", "Policy period:
    // 05-Dec-2025 to 04-Dec-2026"): its first day and its last; a cover bought or renewed for that period next falls
    // due the day after it ends (the renewal day), whatever day it was paid
    var prd = /\b(?:period of (?:insurance|cover(?:age)?)|(?:policy|insurance|cover(?:age)?) period)\b|(?:^|\n)period(?=\s*:)/ig, pm0;
    while ((pm0 = prd.exec(doc.flat))) {
      var pds = doc.toks.filter(function (t) { return t.t === 'DATE' && !t.rel && t.s >= pm0.index && t.s <= pm0.index + pm0[0].length + 60; });
      if (pds.length < 2 || !/^\s*(?:to|till|until|upto|-|–)\s*$/i.test(doc.flat.slice(pds[0].e, pds[1].s)) || !(pds[1].v > pds[0].v)) continue;
      var span = (Date.parse(pds[1].v) - Date.parse(pds[0].v)) / 864e5;
      if (span < 25 || span > 5 * 366) break;
      if (!ev.start && pds[0].v <= doc.ref) ev.start = pds[0].v;
      else if (!ev.start && /^(?:renewed|paid|issued)$/.test(ev.action || '')) ev.start = pds[0].v;
      if (pds[1].v > doc.ref && !(ev.end > pds[1].v)) ev.end = pds[1].v;
      if (/^(?:renewed|paid|issued)$/.test(ev.action || '') && pds[1].v > doc.ref && !ev.nextDue) {
        var nx = new Date(Date.parse(pds[1].v) + 864e5).toISOString().slice(0, 10);
        if (nx > doc.ref) ev.nextDue = nx;
      }
      break;
    }
    // (a year's cover with its last day printed on its own, "Policy End Date: 20/05/2027": renewed the day after)
    if (!ev.nextDue && ev.end && /^(?:renewed|paid|issued)$/.test(ev.action || '')) {
      var yspan = (Date.parse(ev.end) - Date.parse(ev.start || doc.ref)) / 864e5;
      if (yspan >= 330 && yspan <= 400) ev.nextDue = new Date(Date.parse(ev.end) + 864e5).toISOString().slice(0, 10);
    }
    var yrs = function (re) { var p = kv(doc, re); var y = p ? /^\s*(\d{1,2})\s*(?:years?|yrs?\.?)?\s*$/i.exec(p.value) : null; return y && +y[1] > 0 && +y[1] <= 99 ? +y[1] : 0; };
    var term = yrs(/^policy term|^(?:policy )?tenure$/), ppt = yrs(/^premium pay(?:ing|ment) term|^ppt\b/);
    // ("How long would you pay for? (Premium Payment term) 12 Years": the label in brackets, the years after it)
    if (!ppt && (m = /\bpremium pay(?:ing|ment) term\)?\s*[:\-|]?\s*(\d{1,2})\s*(?:years?|yrs?)\b/i.exec(flat)) && +m[1] > 0) ppt = +m[1];
    if (!term && (m = /\(\s*policy term\s*\)\s*[:\-|]?\s*(\d{1,2})\s*(?:years?|yrs?)\b/i.exec(flat)) && +m[1] > 0) term = +m[1];
    if (term) ev.term = term;
    if (ppt) ev.ppt = ppt;
    // ("Premium Payment Frequency", "Premium Payment Mode", "Mode of Premium Payment", "Billing Frequency", LIC's "Mode : Qly")
    var fq = null;
    for (var fi = 0; fi < doc.pairs.length && !fq; fi++) if (/^(?:(?:premium|payment|billing|policy) )*(?:frequency|mode)(?: of (?:premium )?(?:payment|premium|billing))?$/.test(doc.pairs[fi].key) && premiumEvery(doc.pairs[fi].value)) fq = doc.pairs[fi];
    var freq = fq ? premiumEvery(fq.value) : '';
    if (freq) ev.frequency = freq;
    // a receipt's "Next Due Date": when the next premium falls (the engine takes it over its own step)
    var nd = kv(doc, /^next (?:premium )?(?:due|payment)(?: date)?$|^next premium(?: date)?$|^next due on$/);
    if (nd && nd.date && nd.date > doc.ref) ev.nextDue = nd.date;
    // (and the premium it will ask for, in brackets beside that day: "Next premium due 20-Feb-2027 (₹1,50,000)")
    if (nd && (m = /\(\s*(?:rs\.?|inr|₹)\s*(\d[\d,]*(?:\.\d{1,2})?)\s*\)/i.exec(nd.value || '')) && num(m[1]) >= 100) { doc.nextPremium = num(m[1]); if (!(ev.premium > 0)) ev.premium = doc.nextPremium; }
    var fv = kv(doc, /^(?:total )?fund value/);
    var fval = fv && fv.amt > 0 ? fv.amt : 0;
    if (!fval && (m = /\bfund value\b[^₹\d\n]{0,40}?(?:as on|as of)?\s*(\d{1,2}[\/\-. ](?:\d{1,2}|[A-Za-z]{3,9})[\/\-. ]\d{2,4})?[^₹\d\n]{0,20}(?:rs\.?|inr|₹)\s*(\d[\d,]*(?:\.\d+)?)/i.exec(flat))) fval = num(m[2]);
    // ("Fund value of your policy 26123456 (Example Signature) as on 30-Sep-2026: Rs.2,38,410.55": the value on that day)
    var fvd = null;
    if ((m = /\bfund value\b[^\n₹]{0,90}?\bas (?:on|of)\s*(\d{1,2}[\/\-. ](?:\d{1,2}|[A-Za-z]{3,9})[\/\-. ]\d{2,4})\s*[:\-|]?\s*(?:rs\.?|inr|₹)\s*(\d[\d,]*(?:\.\d+)?)/i.exec(flat)) && (!fval || Math.abs(fval - num(m[2])) < 1)) {
      fval = num(m[2]);
      var fvAt = doc.flat.indexOf(m[0]), fdt = fvAt >= 0 ? doc.toks.filter(function (t) { return t.t === 'DATE' && t.s >= fvAt && t.e <= fvAt + m[0].length; })[0] : null;
      if (!fdt) fdt = lex(m[1], doc.ref).filter(function (t) { return t.t === 'DATE'; })[0] || null;
      if (fdt && fdt.v <= doc.ref) fvd = fdt.v;
    }
    if (fval >= 1000) {
      ev.fundValue = fval;
      var fa = fvd || labeledDate(doc, /fund value (?:as on|as of)|as on|as of/);
      if (fa) ev.fundAsOf = fa;
    }
    var bn = kv(doc, /^total (?:reversionary )?bonus|^(?:accrued|vested) bonus/);
    if (bn && bn.amt > 0) ev.bonus = bn.amt;
    if (/status is in-?force|policy status\s*[:|\-]?\s*in-?force|in-?force as on/i.test(flat)) ev.inForce = true;
    if (/policy status\s*[:|\-]?\s*(?:lapsed|discontinued)|has been discontinued|discontinued policy fund/i.test(flat)) ev.discontinued = true;
    // a motor policy's vehicle, by its registration ("MH01AB1234"): which car a renewal is of
    if ((m = /\b([A-Z]{2}[ -]?\d{1,2}[ -]?[A-Z]{1,3}[ -]?\d{4})\b/.exec(flat)) && /\b(?:vehicle|registration|reg\.? no|private car|car|bike|two[- ]?wheeler|motor|idv)\b/i.test(flat)) ev.vehicle = m[1].replace(/[ -]/g, '').toUpperCase();
    // which kind of vehicle, as the mail calls it ("bike insurance", "two-wheeler", "private car"): the engine's kind
    if (ev.vehicle || /\b(?:motor|vehicle) (?:insurance|policy)\b/i.test(doc.subject)) {
      var vk = lc(doc.subject + ' ' + doc.flat.slice(doc.bodyAt, doc.bodyAt + 1500));
      if (/\b(?:two[- ]?wheeler|bike|scooter|motor ?cycle)\b/.test(vk)) ev.hint = 'two-wheeler';
      else if (/\b(?:private car|car|four[- ]?wheeler)\b/.test(vk)) ev.hint = 'car';
    }
  }

  /* what a mail says is held, on a day: a fund house's or registrar's portfolio table in the body of its statement mail
     ("| Scheme | Units | NAV | Market Value |", the PDF beside it often locked), one holding per row; a digital-gold
     app's "Total gold in locker 8.7120 gm" at the rate it printed (less the GST the rate carries). Never a total row,
     a row without units and a value, or a promotion */
  function holdingFacts(doc, ctx) {
    if (ctx.promo || ctx.person) return [];
    var out = [], s = lc(doc.subject), m;
    // (only a mail that prints units and a NAV or market value is looked through for its table)
    var head0 = doc.flat.slice(0, 20000);
    var tb = /\b(?:units?|unit balance)\b/i.test(head0) && /\bnav\b|market value|valuation|current value/i.test(head0) ? tableWith(doc, /scheme|fund|security|holding/, /^units?$|unit balance|closing units|^balance units$|^quantity$/) : null;
    if (tb && tb.head.some(function (c) { return /market value|^value|valuation|current value|amount/.test(c); })) {
      var asOfT = null, aoRe = /\b(?:as (?:on|of)|valuation (?:date|as on)|portfolio (?:summary|value) as on)\b/ig, am;
      while (!asOfT && (am = aoRe.exec(doc.flat))) asOfT = near(doc, 'DATE', am.index + am[0].length, 0, 20);
      var asOf = asOfT && asOfT.v <= doc.ref ? asOfT.v : doc.ref;
      tb.rows.forEach(function (r) {
        var name = r.cell(/scheme|fund|security|holding/);
        if (!name || /^(?:grand )?total\b|^sub-?total/i.test(name) || !/[a-z]{3}/i.test(name)) return;
        var units = num(r.cell(/^units?$|unit balance|closing units|^balance units$|^quantity$/).replace(/[^\d.,]/g, ''));
        var nav = num(r.cell(/\bnav\b|price/).replace(/[^\d.,]/g, ''));
        var value = num(r.cell(/market value|^value|valuation|current value|amount/).replace(/[^\d.,]/g, ''));
        if (!(units > 0) || !(value > 0)) return;
        // (a value that isn't its units at its NAV is some other column's)
        if (nav > 0 && Math.abs(units * nav - value) > Math.max(2, value * 0.01)) return;
        var h = { type: 'holding', cls: 'mf', name: trim(name).slice(0, 90), units: units, value: money(value), asOf: asOf };
        if (nav > 0) h.nav = nav;
        var isin = /\b(IN[A-Z0-9]{9}[0-9])\b/.exec(r.text); if (isin) h.isin = isin[1];
        var fo = r.cell(/folio/); if (fo && /\d{4,}/.test(fo)) h.folio = trim(fo);
        out.push(h);
      });
    }
    // a consolidated statement's mail that prints its own summary ("Equity (2 ISINs) ₹16,438.50", "Mutual Funds (1
    // scheme) ₹1,04,521.16", "Total portfolio value ₹1,20,959.66"): each class's worth on the statement's last day, read
    // from the body when the PDF can't be opened
    if (!out.length && /consolidated account statement|\bcas\b|\becas\b/.test(s + ' ' + lc(doc.lead.slice(0, 300))) && /\btotal portfolio value\b|\bportfolio value\b/i.test(doc.flat)) {
      var per = /\bperiod\s+(?:from\s+)?\d{1,2}[-\/ ][A-Za-z0-9]{2,9}[-\/ ]\d{2,4}\s+(?:to|till|-)\s+(\d{1,2}[-\/ ][A-Za-z0-9]{2,9}[-\/ ]\d{2,4})/i.exec(doc.flat);
      var perTo = per ? doc.toks.filter(function (t) { return t.t === 'DATE' && t.s >= per.index && t.s <= per.index + per[0].length; }).pop() : null;
      var asOfS = perTo && perTo.v <= doc.ref ? perTo.v : doc.ref;
      var cls0 = [['stk', /^(?:equity|equities|shares|stocks|demat holdings?)\b/i], ['mf', /^mutual funds?\b/i]];
      var tot = 0, parts = [];
      doc.pairs.forEach(function (p) {
        var lab = trim(p.label || p.key || ''), amt = p.amt > 0 ? p.amt : num(String(p.value || '').replace(/[^\d.,]/g, ''));
        if (/^(?:total )?portfolio value$/i.test(lab) && amt > 0) tot = amt;
        cls0.forEach(function (c) { if (c[1].test(lab) && amt > 0 && !parts.some(function (x) { return x.cls === c[0]; })) parts.push({ cls: c[0], label: lab, value: amt }); });
      });
      // (a row the pair reader passes over: "Equity (2 ISINs) | ₹16,438.50")
      var lre = /(?:^|\n|\|)\s*((?:equity|equities|shares|stocks|mutual funds?|total portfolio value|portfolio value)[^\n|₹]{0,40}?)\s*[|:]?\s*(?:₹|rs\.?|inr)\s*(\d[\d,]*(?:\.\d+)?)/gi, lm2;
      while ((lm2 = lre.exec(doc.flat))) {
        var lab2 = trim(lm2[1]), amt2 = num(lm2[2]);
        if (/portfolio value/i.test(lab2)) { if (!tot) tot = amt2; continue; }
        cls0.forEach(function (c) { if (c[1].test(lab2) && amt2 > 0 && !parts.some(function (x) { return x.cls === c[0]; })) parts.push({ cls: c[0], label: lab2, value: amt2 }); });
      }
      var src = doc.inst && doc.inst.short ? doc.inst.short : senderBrand(doc);
      // (the parts must make the total the mail prints, or the total stands alone)
      var sumP = parts.reduce(function (a, x) { return a + x.value; }, 0);
      if (parts.length && (!tot || Math.abs(sumP - tot) <= Math.max(2, tot * 0.005))) parts.forEach(function (x) {
        var hs = { type: 'holding', cls: x.cls, summary: true, name: x.label.replace(/\s*\(.*\)\s*$/, ''), value: money(x.value), asOf: asOfS, src: src };
        var hn = /\((\d{1,3})\s*(?:schemes?|isins?|funds?|securities|stocks?|scrips?)\)/i.exec(x.label); if (hn) hs.n = +hn[1];
        out.push(hs);
      });
      else if (tot > 0) out.push({ type: 'holding', cls: 'mf', summary: true, name: 'Portfolio', value: money(tot), asOf: asOfS, src: src });
    }
    /* (ppf-owner-4nov) a PPF's closure, as its bank words it: the account closed (at maturity or before it), its
       proceeds paid out, a death claim settled to its nominee. The account then holds nothing, whatever it last said */
    var ppfShut = /\b(?:(?:ppf\s+)?account\s+(?:has\s+been\s+|is\s+|was\s+|stands\s+)?closed|closed\s+on\s+\d|closure\s+(?:proceeds|amount|of\s+(?:the\s+|your\s+)?(?:ppf\s+)?(?:a\/c|account))|premature(?:ly)?\s+clos|death\s+claim|claim\s+(?:has\s+been\s+)?settled|(?:paid|credited|transferred)\s+to\s+(?:the\s+)?nominee|settled\s+(?:in\s+favou?r\s+of|to)\s+(?:the\s+)?nominee|account\s+status\s*[:\-]?\s*closed)\b/i;
    // a PPF account's statement ("PPF A/c No XXXXXXX9014 … Closing Balance (31-03-2026) Rs. 9,01,617.00"): what it
    // holds on that day; its number is the PPF account's, never a savings account's. (ppf-owner-4nov) Only a mail
    // ABOUT a PPF account: its subject says so, or it prints the PPF account's number. A savings statement that only
    // mentions PPF ("open a PPF in minutes") is never one, and neither is a mutual fund house named PPFAS
    var ppfHay = (s + ' ' + lc(doc.lead.slice(0, 400))).replace(/\bppfas\b/g, ' ');
    var ppfAbout = /\bppf\s*(?:a\/c|account)\s+(?:statement|passbook|closure|closed|maturity|no\b|number)|\b(?:statement|passbook|closure|maturity)\s+of\s+(?:your\s+)?(?:ppf|public provident fund)|\b(?:ppf|public provident fund)\s+(?:annual\s+|account\s+)?(?:statement|passbook|closure|maturity)/.test(ppfHay)
      || /\bppf\s*(?:a\/c|account)\s*(?:no\.?|number)?\s*[:\-]?\s*[x*•]*\d{3,}/i.test(doc.flat.slice(0, 4000));
    if (/\b(?:savings|current|salary)\s+(?:a\/c|account)\s+statement\b/.test(s)) ppfAbout = false;
    if (!out.length && ppfAbout) {
      var pno = kv(doc, /^(?:ppf )?(?:a\/c|account)(?: no\.?| number)?$|^ppf (?:a\/c|account)(?: no\.?| number)?$/), pnv = pno ? (String(pno.value).match(/[\dX*•]{4,}/gi) || []).pop() : '';
      if (!pnv) { var pnm = /\bppf\s*(?:a\/c|account)\s*(?:no\.?|number)?\s*[:\-]?\s*[x*•]*\d*?(\d{4})\b/i.exec(doc.subject + '\n' + doc.flat); if (pnm) pnv = pnm[1]; }
      var pcl = null, pd = null;
      doc.pairs.forEach(function (p) { var lab = String(p.label || p.key || ''); if (!pcl && /^closing balance\b|^balance as (?:on|of)\b/i.test(lab) && p.amt > 0) pcl = p; });
      if (!pcl) { var pcm = /\bclosing balance\s*(?:\(([^)]{6,20})\)|as (?:on|of) ([\d\-\/ A-Za-z]{6,20}))?\s*[:|]?\s*(?:rs\.?|inr|₹)\s*(\d[\d,]*(?:\.\d+)?)/i.exec(doc.flat); if (pcm) pcl = { amt: num(pcm[3]), label: pcm[1] || pcm[2] || '' }; }
      // (a closure notice: the account it closed, with no balance of its own)
      if (ppfShut.test(doc.flat.slice(doc.bodyAt, doc.bodyAt + 5000)) && pnv) {
        var shut = { type: 'holding', cls: 'ppf', name: 'PPF', value: 0, closed: true, asOf: doc.ref, no: String(pnv).replace(/\D/g, '').slice(-4) };
        if (doc.inst && doc.inst.short) shut.inst = doc.inst.short;
        out.push(shut);
      } else if (pcl && pcl.amt > 0) {
        var pdm = /(\d{1,2})[-\/.](\d{1,2})[-\/.](20\d{2})/.exec(String(pcl.label || pcl.key || ''));
        pd = pdm ? pdm[3] + '-' + ('0' + pdm[2]).slice(-2) + '-' + ('0' + pdm[1]).slice(-2) : doc.ref;
        var ph = { type: 'holding', cls: 'ppf', name: 'PPF', value: money(pcl.amt), asOf: pd <= doc.ref ? pd : doc.ref };
        if (pnv) ph.no = String(pnv).replace(/\D/g, '').slice(-4);
        if (doc.inst && doc.inst.short) ph.inst = doc.inst.short;
        out.push(ph);
      }
    }
    /* an NPS statement from its record keeper ("Tier I holding value as on 30-Sep-2026 | Rs. 4,82,113.40"), and a Sukanya
       Samriddhi account's annual statement ("Balance as on 31-03-2026: Rs.2,14,830.00"): what the scheme holds on that
       day, as a PPF statement's closing balance is (never a contribution or a deposit made that year) */
    var schemeAt = s + ' ' + doc.lead.slice(0, 400);
    var npsMail = /\bnps\b|national pension|\bpran\b/.test(schemeAt) && /\bstatement\b|holding value|\bholdings?\b/.test(schemeAt) && ((doc.inst && /^(?:pension|depository)$/.test(doc.inst.kind)) || /(?:^|\.)(?:nsdl\.co\.in|proteantech\.in|kfintech\.com|camsonline\.com|npscra\.nsdl\.co\.in|npstrust\.org\.in)$/.test(doc.domain || ''));
    var ssyMail = /sukanya samriddhi|\bssy\b/.test(schemeAt) && /\bstatement\b|\bpassbook\b|\bannual\b/.test(schemeAt) && ((doc.inst && doc.inst.kind === 'bank') || /(?:^|\.)(?:indiapost\.gov\.in|ippbonline\.(?:in|com))$/.test(doc.domain || ''));
    if (!out.length && (npsMail || ssyMail)) {
      var sbody = doc.flat.slice(doc.bodyAt, doc.bodyAt + 5000);
      var vre = npsMail ? /\b(tier[ -]?(?:i|ii|1|2))?\s*(?:total\s+)?holding value\s*(?:\(?as (?:on|of)\s*(\d{1,2}[-\/. ][A-Za-z0-9]{2,9}[-\/. ]\d{2,4})\)?)?\s*[:|\-]?\s*(?:rs\.?|inr|₹)\s*(\d[\d,]*(?:\.\d{1,2})?)/i
        : /\b(?:closing )?balance\s*(?:\(?as (?:on|of)\s*(\d{1,2}[-\/. ][A-Za-z0-9]{2,9}[-\/. ]\d{2,4})\)?)\s*[:|\-]?\s*(?:rs\.?|inr|₹)\s*(\d[\d,]*(?:\.\d{1,2})?)/i;
      var vm = vre.exec(sbody);
      if (vm) {
        var sv = num(npsMail ? vm[3] : vm[2]), sd = npsMail ? vm[2] : vm[1];
        var sdt = sd ? doc.toks.filter(function (t) { return t.t === 'DATE' && t.s >= doc.bodyAt + vm.index && t.s <= doc.bodyAt + vm.index + vm[0].length; })[0] : null;
        if (sv > 0) {
          var sh = { type: 'holding', cls: npsMail ? 'nps' : 'ssy', name: npsMail ? 'NPS' + (vm[1] ? ' ' + trim(vm[1]).replace(/^tier[ -]?(?:i|1)$/i, 'Tier I').replace(/^tier[ -]?(?:ii|2)$/i, 'Tier II') : '') : 'Sukanya Samriddhi', value: money(sv), asOf: sdt && sdt.v <= doc.ref ? sdt.v : doc.ref };
          var sno = npsMail ? /\bpran\b[\s:|\-]*(?:no\.?|number)?[\s:|\-]*[x*•]*(\d{4,})/i.exec(doc.flat) : /\b(?:sukanya samriddhi|ssy)\s*(?:a\/c|account)?\s*(?:no\.?|number)?\s*[:|\-]?\s*[x*•]*(\d{4,})/i.exec(doc.flat);
          if (sno) sh.no = sno[1].slice(-4);
          if (ssyMail) { var srt = /@\s*(\d{1,2}(?:\.\d{1,2})?)\s*%/.exec(sbody); if (srt && +srt[1] > 0 && +srt[1] < 15) sh.rate = +srt[1]; sh.inst = doc.inst && doc.inst.kind === 'bank' ? doc.inst.short : 'India Post'; }
          out.push(sh);
        }
      }
    }
    // a fund platform's SIP mail that prints the units now held and the NAV: the fund's worth that day
    if (!out.length && /\bsip\b|\bunits? allotted\b/.test(s + ' ' + lc(doc.lead.slice(0, 400)))) {
      var tu = /\btotal units(?: held)?\s*[:|\-]?\s*(\d[\d,]*(?:\.\d+)?)/i.exec(doc.flat), nv = /\bnav\s*(?:of|:|@)?\s*(?:₹|rs\.?|inr)\s*(\d[\d,]*(?:\.\d+)?)/i.exec(doc.flat);
      var sch = /\bin\s+([A-Z][A-Za-z0-9&'.() \-]{4,90}?(?:[Ff]und|ETF|FoF|FOF)(?:\s+(?:[Dd]irect|[Rr]egular))?(?:\s+(?:[Pp]lan\s+)?(?:[Gg]rowth|IDCW|[Dd]ividend))?)\b/.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 1500));
      if (tu && nv && sch && num(tu[1]) > 0 && num(nv[1]) > 0) {
        var un = num(tu[1]), nav0 = num(nv[1]);
        out.push({ type: 'holding', cls: 'mf', name: trim(sch[1]).slice(0, 90), units: un, nav: nav0, value: money(un * nav0), asOf: doc.ref, sip: true });
      }
    }
    // digital gold: the grams held after this purchase, and its rate a gram
    var gl = /\b(?:total gold (?:in (?:your )?locker|balance|holdings?|accumulated|saved)|gold (?:locker )?balance|your (?:total )?gold (?:balance|savings|holdings?)|gold in (?:your )?locker)\b[^\d\n]{0,12}(\d{1,4}(?:\.\d{1,4})?)\s*(?:gm|gms|grams?|g)\b/i.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 4000));
    if (gl && /\bgold\b/.test(s + ' ' + doc.lead.slice(0, 400))) {
      var grams = num(gl[1]);
      var rk = /\b(?:rate|price|gold (?:rate|price)|buy (?:rate|price))\b[^\d\n₹]{0,12}(?:₹|rs\.?|inr)\s?(\d[\d,]*(?:\.\d+)?)\s*(?:\/|per)\s*(?:gm|gram|g)\b/i.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 4000));
      var rate = rk ? num(rk[1]) : 0;
      // (a buy rate "incl. 3% GST" is the gold's worth and the tax: the gold alone is the rate less it)
      var gst = /\bincl(?:usive|\.)?(?: of)?\s*(\d(?:\.\d+)?)\s*%\s*gst\b/i.exec(doc.flat);
      if (rate > 0 && gst) rate = rate / (1 + num(gst[1]) / 100);
      if (grams > 0 && grams < 10000) {
        var prov = /\b(safegold|mmtc[- ]?pamp|augmont)\b/i.exec(doc.flat);
        var app = /\b(phonepe|paytm|google pay|gpay|jar|amazon pay|tanishq|caratlane)\b/i.exec(doc.from + ' ' + doc.subject + ' ' + doc.flat.slice(0, 2000));
        var g = { type: 'holding', cls: 'gold', name: 'Digital gold', grams: grams, asOf: doc.ref };
        if (prov) g.provider = /mmtc/i.test(prov[1]) ? 'MMTC-PAMP' : /safegold/i.test(prov[1]) ? 'SafeGold' : 'Augmont';
        if (app) g.app = /gpay|google pay/i.test(app[1]) ? 'Google Pay' : /phonepe/i.test(app[1]) ? 'PhonePe' : capWords(lc(app[1]));
        if (rate > 1000) { g.rate = money(rate); g.value = money(grams * rate); }
        out.push(g);
      }
    }
    // a PPF account's statement from the bank or post office that keeps it ("Closing Balance (31-03-2026) Rs. 9,01,617.00"):
    // what the account holds on that day (never a bank account of its digits)
    var ppfAt = (s + ' ' + doc.lead.slice(0, 300)).replace(/\bppfas\b/gi, ' ');
    if (!out.length && ppfAbout && /\bppf\b|public provident fund/i.test(ppfAt) && /\bstatement\b|\bpassbook\b|\bannual\b/i.test(ppfAt) && ((doc.inst && doc.inst.kind === 'bank') || /(?:^|\.)indiapost\.gov\.in$/.test(doc.domain || ''))) {
      var body = doc.flat.slice(doc.bodyAt, doc.bodyAt + 5000);
      var cbm = /\bclosing balance\b\s*(?:\(\s*(?:as on\s*)?(\d{1,2})[\-\/.](\d{1,2})[\-\/.](\d{4})\s*\))?\s*[:|\-]?\s*(?:rs\.?|inr|₹)\s*(\d[\d,]*(?:\.\d{1,2})?)/i.exec(body);
      if (cbm && num(cbm[4]) > 0) {
        var p = { type: 'holding', cls: 'ppf', name: 'PPF', value: money(num(cbm[4])), asOf: cbm[3] && validDay(+cbm[3], +cbm[2], +cbm[1]) ? cbm[3] + '-' + pad(+cbm[2]) + '-' + pad(+cbm[1]) : doc.ref };
        if (doc.inst && doc.inst.kind === 'bank') p.inst = doc.inst.short; else p.inst = 'India Post';
        var pno = /\bppf\s*(?:a\/c|account)\s*(?:no\.?|number)?\s*[:|\-]?\s*[x*•]*(\d{3,})\b/i.exec(body); if (pno) p.no = pno[1].slice(-4);
        var prt = /@\s*(\d{1,2}(?:\.\d{1,2})?)\s*%/.exec(body); if (prt && +prt[1] > 0 && +prt[1] < 15) p.rate = +prt[1];
        var pmt = /\bmaturity date\b\s*[:|\-]?\s*(\d{1,2})[\-\/.](\d{1,2})[\-\/.](\d{4})/i.exec(body); if (pmt && validDay(+pmt[3], +pmt[2], +pmt[1])) p.mat = pmt[3] + '-' + pad(+pmt[2]) + '-' + pad(+pmt[1]);
        out.push(p);
      }
    }
    return out;
  }

  /* a loan's own figures, from its lender's mail: an interest certificate (what's outstanding on a day, the rate, the
     EMI, the principal and interest repaid in the year) or an EMI's confirmation (the EMI, the day it was debited, its
     principal and interest). The loan's number is its last four. Never an offer ("pre-approved"), a credit bureau's
     report, or a mail that names no loan account */
  function loanFacts(doc, ctx) {
    if (ctx.promo || ctx.person || ctx.creditReport) return [];
    var s = lc(doc.subject), body = doc.flat.slice(doc.bodyAt, doc.bodyAt + 5000), m;
    if (!/\bloan\b/.test(s + ' ' + lc(body.slice(0, 1500)))) return [];
    if (/pre-?approved|\boffer\b|apply now|top-?up loan (?:offer|available)|eligible for a loan/.test(s + ' ' + lc(body.slice(0, 600)))) return [];
    // a card purchase turned into EMIs ("Your EMI conversion request is successful"): a loan on the card, its EMIs billed
    // in the card's statements from a month on, so many of them
    if (/emi conversion|converted (?:in)?to (?:an? )?emis?\b|emi (?:has been )?booked/.test(s + ' ' + lc(body.slice(0, 800))) && !/\b(?:failed|rejected|unsuccessful|cancel+ed)\b/.test(s)) {
      var cm = doc.toks.filter(function (t) { return t.t === 'MASK'; }).map(function (t) { return String(t.v || '').replace(/\D/g, ''); }).filter(function (d) { return d.length >= 4; })[0];
      var ce = kv(doc, /^(?:monthly )?emi(?: amount)?$/), ca = kv(doc, /^(?:loan|principal|transaction|emi) amount$/), ct = kv(doc, /^tenure$|^tenor$|^no\.? of (?:emis|instal+ments)$/);
      if (!(ce && ce.amt > 0)) { var cem = /\b(?:monthly )?emi(?: amount)?\b\s*[:|·\-]?\s*(?:inr|rs\.?|₹)\s*(\d[\d,]*(?:\.\d{1,2})?)/i.exec(body.slice(0, 2000)); if (cem) ce = { amt: num(cem[1]) }; }
      var cn = ct ? /(\d{1,2})\s*(?:months?|emis?|instal+ments?)?/i.exec(ct.value) : /\b(\d{1,2})\s*(?:-\s*)?months?\b/i.exec(body.slice(0, 1500));
      if (cm && ce && ce.amt > 0 && cn && +cn[1] >= 2 && +cn[1] <= 60) {
        var cev = { type: 'loan', kind: 'Card EMI', no: cm.slice(-4), emi: ce.amt, n: +cn[1] };
        if (doc.inst && doc.inst.short) cev.lender = doc.inst.short;
        if (ca && ca.amt > 0) cev.amount = ca.amt;
        var crt = kv(doc, /^(?:rate of interest|interest rate|roi)(?: \(?p\.?a\.?\)?)?$/), crv = crt ? /(\d{1,2}(?:\.\d{1,3})?)\s*%/.exec(crt.value) : null;
        if (crv) cev.rate = +crv[1];
        // (the first month it is billed: "billed in your monthly statement from March 2026"; else the month after)
        var cf = /\b(?:billed|charged|start(?:s|ing)?)\b[^.\n]{0,60}?\bfrom\s+(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?\s+(20\d{2})\b/i.exec(body);
        var MO = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'];
        if (cf) cev.from = cf[2] + '-' + ('0' + (MO.indexOf(lc(cf[1]).slice(0, 3)) + 1)).slice(-2);
        else if (/^\d{4}-\d{2}/.test(doc.ref || '')) { var ry = +doc.ref.slice(0, 4), rmn = +doc.ref.slice(5, 7) + 1; if (rmn > 12) { rmn = 1; ry++; } cev.from = ry + '-' + ('0' + rmn).slice(-2); }
        var cw = /\btransaction at\s+([A-Za-z0-9][A-Za-z0-9 &.'\-]{1,60}?)\s+(?:for|of)\s+(?:inr|rs\.?|₹)/i.exec(body);
        if (cw) cev.what = capWords(lc(cw[1].replace(/\s+(?:internet|india|pvt|private|ltd|limited|llp|services|retail)\b.*$/i, '')));
        return [cev];
      }
    }
    /* a jewel (gold) loan sanctioned, as a cooperative bank writes it ("JEWEL LOAN NO. JL/1187 SANCTIONED FOR RS.80,000/-
       AGAINST 21.600 GMS GOLD ORNAMENTS … RATE OF INTEREST 9.50% P.A. … NEXT INTEREST DUE 20-11-2026 RS.1,900/-. DUE DATE
       19-08-2027"): the loan, owed in full from the day it was sanctioned, and the interest it next asks for, a due */
    var jl = /\b(?:jewel|gold)\s+loan\s*(?:no\.?|number|a\/c|account)?\s*[:.\-]?\s*([A-Z]{0,4}[\/\-]?\d{3,})\b[^\n]{0,40}?\bsanctioned\s+(?:for|of)\s*(?:rs\.?|inr|₹)\s*(\d[\d,]*(?:\.\d{1,2})?)/i.exec(body.slice(0, 2000));
    if (jl && !/\b(?:closed|foreclosed|repaid in full|redeemed)\b/i.test(s)) {
      var jev = { type: 'loan', no: jl[1].replace(/\D/g, '').slice(-4), kind: 'Gold loan', outstanding: num(jl[2]), disbursed: num(jl[2]), asOf: doc.ref };
      var jlen = doc.inst && doc.inst.short ? doc.inst.short : (personalName(doc) || senderBrand(doc));
      if (jlen) jev.lender = jlen;
      var jr = /\brate of interest\s*[:\-]?\s*(\d{1,2}(?:\.\d{1,3})?)\s*%/i.exec(body);
      if (jr && +jr[1] > 0 && +jr[1] < 40) jev.rate = +jr[1];
      var jd = /(?:^|[.\n]\s*)(?:loan\s+)?due date\s*[:\-]?\s*(\d{1,2})[-\/.](\d{1,2})[-\/.](20\d{2})\b/i.exec(body);
      if (jd && validDay(+jd[3], +jd[2], +jd[1])) jev.due = jd[3] + '-' + pad(+jd[2]) + '-' + pad(+jd[1]);
      var jout = [jev];
      var ji = /\bnext interest due\s*(?:on)?\s*[:\-]?\s*(\d{1,2})[-\/.](\d{1,2})[-\/.](20\d{2})\s*[,:\-]?\s*(?:rs\.?|inr|₹)\s*(\d[\d,]*(?:\.\d{1,2})?)/i.exec(body);
      if (ji && validDay(+ji[3], +ji[2], +ji[1]) && num(ji[4]) > 0) {
        var jdue = { type: 'due', what: 'emi', amt: num(ji[4]), due: ji[3] + '-' + pad(+ji[2]) + '-' + pad(+ji[1]), payee: (jlen || 'Gold loan') + ' interest' };
        jout.push(jdue);
      }
      return jout;
    }
    var no = kv(doc, /^loan (?:account|a\/c|acct)(?: no\.?| number)?$|^loan (?:no\.?|number)$/);
    // (the number's last run of digits: "4012-GL-0098765" is the loan ending 8765, not 4012)
    var nm = no ? (String(no.value).match(/[\dX*•]{4,}/gi) || []).pop() : null;
    var last4 = nm ? (nm.replace(/\D/g, '').slice(-4)) : '';
    if (!last4 && (m = /\bloan (?:account|a\/c|acct)(?: no\.?| number)?\s*[:.\-]?\s*[x*•]*\d*?(\d{4})\b/i.exec(doc.subject + '\n' + body))) last4 = m[1];
    // (a gold loan's own number, "Gold Loan 4012-GL-0098765", "Loan No. 4012-GL-0098765")
    if (!last4 && (m = /\b(?:gold )?loan(?: no\.?| number)?\s*[:.\-]?\s*(\d{3,}(?:-[A-Z]{1,4})?-\d{4,})\b/i.exec(doc.subject + '\n' + body))) last4 = m[1].replace(/\D/g, '').slice(-4);
    // (a loan named by its kind and masked number, "your Auto Loan XXXXXX8812")
    if (!last4 && (m = /\b(?:home|housing|car|auto|vehicle|personal|education|two[- ]wheeler|business)\s+loan\s*(?:a\/c|account)?\s*(?:no\.?)?\s*[:\-]?\s*[x*•]{2,}\d*?(\d{4})\b/i.exec(doc.subject + '\n' + body))) last4 = m[1];
    if (!last4 || last4.length < 4) return [];
    // (a figure by its label: the pairs, else a line of its own, "Principal outstanding as on 31-03-2026: Rs. 38,40,112.00")
    var amtOf = function (re) {
      var p = kv(doc, re);
      if (p && p.amt > 0) return p;
      var lr = /^[ \t|•*]*([A-Za-z][A-Za-z ()\/.\-]{1,60}?(?:\s+as (?:on|of|at)\s+[\w\-\/ ,]{6,20})?)\s*[:|]\s*(?:rs\.?|inr|₹)\s*(\d[\d,]*(?:\.\d{1,2})?)/gim, lm;
      while ((lm = lr.exec(body))) if (re.test(lc(trim(lm[1])))) return { label: trim(lm[1]), amt: num(lm[2]), s: doc.bodyAt + lm.index + lm[0].lastIndexOf(lm[2]) };
      return null;
    };
    var ev = { type: 'loan', no: last4 };
    var kind = /home loan|housing loan|home finance/.test(s + ' ' + lc(body)) ? 'Home loan' : /car loan|auto loan|vehicle loan/.test(s + ' ' + lc(body)) ? 'Car loan' : /education loan/.test(s + ' ' + lc(body)) ? 'Education loan' : /personal loan/.test(s + ' ' + lc(body)) ? 'Personal loan' : /gold loan/.test(s + ' ' + lc(body)) ? 'Gold loan' : '';
    if (kind) ev.kind = kind;
    if (doc.inst && doc.inst.short) ev.lender = doc.inst.short;
    else if (/\bgold loan\b/.test(ev.kind ? lc(ev.kind) : '') && senderBrand(doc)) ev.lender = senderBrand(doc);
    var os = amtOf(/principal outstanding|outstanding (?:principal|amount|balance|loan)|^outstanding\b|loan outstanding|balance principal|principal balance/);
    if (os) {
      ev.outstanding = os.amt;
      var od = /as (?:on|of|at)\b/i.test(os.label) ? doc.toks.filter(function (t) { return t.t === 'DATE' && t.s < os.s && t.s > os.s - 60; }).pop() : null;
      ev.asOf = od ? od.v : (os.date || doc.ref);
    }
    // a loan just disbursed: what's owed is what was lent, on the day it was
    if (!os && /\bdisburs/.test(s + ' ' + lc(body.slice(0, 400)))) {
      var la = amtOf(/^(?:loan|sanctioned|disbursed|disbursal|disbursement) amount$|^amount (?:disbursed|sanctioned)$/);
      if (la && la.amt > 0) { ev.outstanding = la.amt; ev.asOf = doc.ref; ev.disbursed = la.amt; }
    }
    // when the whole loan falls due (a gold loan's term: "Tenure: 12 months (due 15-12-2026)", "Due date: …")
    var due = kv(doc, /^(?:loan )?(?:due|maturity|repayment|closure) date$|^due on$/);
    if (due && due.date) ev.due = due.date;
    else if ((m = /\b(?:tenure|term)\b[^\n]{0,40}?\bdue\s*(?:on|by|date)?\s*[:\-]?\s*(\d{1,2})[-\/.](\d{1,2})[-\/.](20\d{2})\b/i.exec(body))) ev.due = m[3] + '-' + ('0' + m[2]).slice(-2) + '-' + ('0' + m[1]).slice(-2);
    var rt = kv(doc, /^(?:rate of interest|interest rate|roi|rate)(?: \(?p\.?a\.?\)?)?$/);
    var rv = rt ? /(\d{1,2}(?:\.\d{1,3})?)\s*%/.exec(rt.value) : null;
    if (rv && +rv[1] > 0 && +rv[1] < 40) ev.rate = +rv[1];
    var emi = amtOf(/^(?:emi|emi amount|instal+ment(?: amount)?|monthly instal+ment)$/);
    if (emi) ev.emi = emi.amt;
    // (a reminder's EMI in its sentence: "Your Auto Loan XXXXXX8812 EMI of Rs. 14,250 is due on 07-Oct-2026")
    var remind = !emi && /\bemi\b[^.\n]{0,20}\bof\s*(?:rs\.?|inr|₹)\s*(\d[\d,]*(?:\.\d{1,2})?)[^.\n]{0,30}\b(?:is |will be )?due\b/i.exec(body.slice(0, 1500));
    if (remind) ev.emi = num(remind[1]);
    var pfy = amtOf(/principal (?:repaid|paid)(?: during| in| for)? (?:the )?(?:fy|financial year|year)/), ify = amtOf(/interest (?:repaid|paid)(?: during| in| for)? (?:the )?(?:fy|financial year|year)/);
    if (pfy) ev.principalFY = pfy.amt;
    if (ify) ev.interestFY = ify.amt;
    var pc = amtOf(/^principal(?: component| portion| part| paid)?$/), ic = amtOf(/^interest(?: component| portion| part| paid)?$/);
    if (pc && !pfy) ev.principal = pc.amt;
    if (ic && !ify) ev.interest = ic.amt;
    var dd = kv(doc, /^(?:date of debit|debit date|emi (?:date|debit date)|date of payment|payment date|instal+ment date)$/);
    if (dd && dd.date && (ev.emi || ev.principal)) ev.date = dd.date;
    else if (ev.emi && !ev.outstanding && /\bemi\b[^.\n]{0,60}\b(?:debited|received|paid|processed)\b|\b(?:debited|received|paid)\b[^.\n]{0,40}\bemi\b/.test(s + ' ' + lc(body.slice(0, 800)))) ev.date = doc.ref;
    // (a figure for the loan, or nothing: a number alone says nothing of it; a certificate's principal and interest
    // for the year, without what is still owed, are the tax year's, not an EMI's)
    if (!ev.date) { delete ev.principal; delete ev.interest; }
    if (!ev.outstanding && !ev.date && !remind) return [];
    return [ev];
  }

  /* mutual funds: a purchase, SIP, redemption or switch confirmed; a platform's list of orders */
  function funds(doc, ctx) {
    var s = lc(doc.subject), l = doc.low.slice(0, 6000);
    if (!/\bsip\b|units? allot|purchase|redemption|redeem|switch|mutual fund|\bnav\b|folio|order placed|fund updates/.test(s + ' ' + l.slice(0, 2000))) return [];
    if (doc.kind === 'bank' || doc.kind === 'card') return [];
    if (/portfolio of schemes|monthly portfolio|factsheet|newsletter|addendum|annual report|receipt of your request/.test(s)) return [];
    if (!/order(?:s)? placed|orders? (?:executed|processed)|allot|purchase|redemption|redeemed|switch|\bstp\b|\bswp\b|systematic (?:transfer|withdrawal)|sip (?:instal+ment )?(?:processed|successful|executed|registered)|units|nav applicable/.test(doc.head)) return [];
    var out = [];
    // an order placed at a platform ("Order placed", "Your SIP order due today has been placed. Please complete the
    // payment") is money that will go to the fund once paid; the fund's own allotment (units, NAV) is the purchase
    var placedOnly = /\border(?:s)? placed\b|\border (?:due today )?has been placed|\bsip orders?\b/.test(s + ' ' + l.slice(0, 2500)) &&
      !/(?:units?(?: allotted)?|\bnav(?: applied| applicable)?|net asset value)\s*[:|]\s*(?:rs\.?|₹|inr)?\s*\d|has been (?:processed|executed|allotted)|have been allotted|allotment details/.test(l.slice(0, 4000));
    var scheme = /\b([A-Z][A-Za-z0-9&'.() \-]{4,100}?(?:fund|scheme|etf|fof|plan|growth|direct|idcw)[A-Za-z0-9&'.() \-]{0,40})/i;
    var ref = doc.toks.filter(function (t) { return t.t === 'DATE' && !inBody(doc, t); })[0];
    for (var i = 1; i < doc.lines.length && out.length < 15; i++) {
      var line = doc.lines[i], cells = line.split(' | ');
      if (cells[0].length > 110) {
        var inner = /\b(?:under|in|into)\s+((?:[A-Z0-9][\w&'.()]*\s*(?:-\s*)?){1,14}?(?:[Ff]und|[Pp]lan|ETF|[Ss]cheme|[Gg]rowth|IDCW|[Oo]ption)\b(?:\s*-\s*[A-Z][\w ]{2,30}?)?)\s+(?:for|of|with|has|is|was|at)\b/.exec(cells[0]);
        if (!inner) continue;
        cells = [inner[1]].concat(cells.slice(1));
      }
      var sm = scheme.exec(cells[0]);
      if (!sm || !/fund|scheme|etf/i.test(cells[0])) continue;
      // "₹ 128 Add Funds to Apple Account" is a wallet top-up, not a scheme: a scheme's name holds no price
      if (/^(?:rs\.?|inr|₹)\s?\d/i.test(trim(sm[1])) || /\badd(?:ed)? funds?\b|\bfunds? (?:added|transfer)/i.test(cells[0])) continue;
      var ls = doc.lineAt[i];
      var a = amts(doc, ls, ls + line.length + 1)[0];
      if (!a) continue;
      var act = /redeem|redemption|sell/i.test(line + ' ' + s) ? 'redeem' : /switch/i.test(line + ' ' + s) ? 'switch' : /\bsip\b|monthly|weekly|instal/i.test(line + ' ' + s) ? 'sip' : 'buy';
      var ev = { type: 'fund', action: act, scheme: trim(cells[0]), amt: a.v, date: ref ? ref.v : doc.ref };
      // (no day of its own printed: dated by its mail, which can come days after the move)
      if (!ref) ev.byMail = true;
      if (placedOnly && act !== 'redeem' && act !== 'switch') ev = { type: 'expect', dir: 'out', what: act === 'sip' ? 'sip' : 'buy', amt: a.v, party: trim(cells[0]), on: ref ? ref.v : doc.ref };
      var u = /(\d[\d,]*\.\d{2,4})\s*units/i.exec(line);
      if (u) ev.units = num(u[1]);
      if (!out.some(function (o) { return (o.scheme || o.party) === (ev.scheme || ev.party) && o.amt === ev.amt; })) out.push(ev);
    }
    if (!out.length) {
      // a table with a header row ("Date | Fund | Folio no. | Amount | Stamp Duty | NAV | Units") and a row per fund
      var tb = tableWith(doc, /\bfund\b|scheme/, /amount|units|nav/);
      if (tb) tb.rows.forEach(function (r) {
        var sc = r.cell(/\bfund\b|scheme/);
        var am = num((/\d[\d,]*(?:\.\d+)?/.exec(r.cell(/^amount|amount$|^value/).replace(/^(?:rs\.?|inr|₹)\s*/i, '')) || [''])[0]);
        if (!sc || !/[a-z]{3}/i.test(sc) || !(am > 0)) return;
        var act3 = /redeem|redemption|sell/i.test(r.text + ' ' + s) ? 'redeem' : /switch/i.test(r.text + ' ' + s) ? 'switch' : /\bsip\b/i.test(r.text + ' ' + s) ? 'sip' : 'buy';
        var ev3 = { type: 'fund', action: act3, scheme: trim(sc), amt: money(am) };
        var un = num(r.cell(/^units?$|units? allot/)); if (un > 0) ev3.units = un;
        var nv = num(r.cell(/^nav$|^nav \(|purchase nav/)); if (nv > 0) ev3.nav = nv;
        var fo = r.cell(/folio/); if (/\d{4,}/.test(fo)) ev3.folio = trim(fo);
        var dt = doc.toks.filter(function (t) { return t.t === 'DATE' && t.s >= r.s && t.e <= r.e; })[0];
        ev3.date = dt ? dt.v : doc.ref;
        if (!dt) ev3.byMail = true;
        out.push(ev3);
      });
    }
    if (!out.length) {
      // a registrar's or fund house's confirmation, told as one transaction: "Processing of Purchase in <scheme>",
      // then Amount / Units allotted / NAV / Value date / Folio as labels
      var sm2 = /(?:processing of|confirmation of|confirmation for|your|successful)\s+(purchase|additional purchase|sip(?: purchase| instal+ment)?|systematic investment|redemption|switch(?:[\s-]*(?:in|out))?)\s+(?:transaction\s+)?(?:in|into|of|for|from)\s+([^\n|]{4,120}?)(?:\s*$|\s+(?:has|is|was|for folio)\b)/i.exec(doc.subject) ||
                /(?:invest(?:ment)?|purchase|redemption|redeem|switch)\s+in\s+([^\n.]{4,100}?(?:fund|plan|growth|etf|scheme)[^\n.]{0,40}?)\.?\s+the allotment details for your\s+'?(purchase|redemption|switch|sip)/i.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 1200));
      var amtP = kv(doc, /^(?:purchase |redemption |investment |transaction |gross |net )?amount(?: \(?(?:rs|inr|₹)\.?\)?)?$|^amount invested$/);
      var unP = kv(doc, /units? (?:allotted|redeemed|purchased|alloted)|^units$|no\.? of units/);
      var navP = kv(doc, /^(?:net asset value|nav)(?: \(?(?:rs|inr|₹)\.?\)?)?(?: per unit)?$|^purchase nav$|^nav applied$/);
      if (sm2 && (amtP || unP)) {
        var first = sm2[1], second = sm2[2];
        var kindWord = /fund|plan|growth|etf|scheme/i.test(first) && !/purchase|redemption|switch|sip/i.test(first) ? second : first;
        var schemeName = kindWord === first ? second : first;
        var act2 = /redeem|redemption/i.test(kindWord) ? 'redeem' : /switch/i.test(kindWord) ? 'switch' : /sip|systematic/i.test(kindWord) ? 'sip' : 'buy';
        var ev2 = { type: 'fund', action: act2, scheme: trim(schemeName.replace(/\s*[-–]\s*$/, '')) };
        if (amtP && amtP.amt != null) ev2.amt = amtP.amt;
        if (unP) { var uu = /\d[\d,]*(?:\.\d+)?/.exec(unP.value); if (uu) ev2.units = num(uu[0]); }
        if (navP) { var nn = /\d[\d,]*(?:\.\d+)?/.exec(navP.value); if (nn) ev2.nav = num(nn[0]); }
        var fo = kv(doc, /^folio(?: no\.?| number)?$/) || null, fm2 = fo ? /[\w\/]+/.exec(fo.value) : /\bfolio(?:\s*(?:no\.?|number))?\s*[:\-]?\s*([0-9][0-9\/]{4,20})/i.exec(doc.flat);
        if (fm2) ev2.folio = fo ? fm2[0] : fm2[1];
        var vd = kv(doc, /value date|nav date|transaction date|date of (?:allotment|transaction)|allotment date/);
        ev2.date = vd && vd.date ? vd.date : doc.ref;
        if (!(vd && vd.date)) ev2.byMail = true;
        out.push(ev2);
      }
    }
    if (!out.length) {
      // a registrar's, fund house's or platform's confirmation told as labels: "Scheme | <name>", "Amount | Rs. 5,000",
      // "Units Allotted | 58.526", "NAV | 85.43", "Folio No | ...", the scheme sometimes only in a sentence ("Your order
      // for <scheme> has been allotted", "the New Fund Offer of <scheme>"). Done only: allotted, processed, confirmed.
      var lv = function (re) { var p0 = kv(doc, re); if (p0) return p0; for (var i = 1; i < doc.lines.length; i++) { var c = doc.lines[i].split(' | '); if (c.length === 2 && re.test(lc(trim(c[0])))) return { key: lc(trim(c[0])), value: trim(c[1]) }; } return null; };
      var numOf = function (p0) { var m0 = p0 ? /\d[\d,]*(?:\.\d+)?/.exec(String(p0.value).replace(/^[^\d]*/, '')) : null; return m0 ? num(m0[0]) : 0; };
      var schK = lv(/^(?:scheme(?: name)?|fund(?: name)?|from scheme|scheme \/ plan|plan name)$/);
      var amK = lv(/^(?:(?:purchase|redemption|investment|transaction|gross|net|switch|transfer|withdrawal|sip|instal+ment|contribution) )?amount(?: \(?(?:rs|inr|₹)\.?\)?)?$|^amount invested$|^amount paid$/);
      var unK = lv(/^units?(?: allotted| redeemed| purchased| alloted)?(?: \(?no\.?\)?)?$|^no\.? of units$|^units allotted$/);
      var navK = lv(/^(?:net asset value|nav)(?: \(?(?:rs|inr|₹)\.?\)?)?(?: per unit)?$|^purchase nav$|^nav applied$/);
      // (a registrar's "Redemption confirmation", "We confirm the redemption in your folio": done)
      var done = /\b(?:has been |have been |was |were )?(?:processed|allotted|alloted|executed|confirmed)\b|allotment (?:details|report)|(?:transaction|redemption|purchase|switch|sip) confirmation|\bwe (?:hereby )?confirm (?:the|your)\b|units allotted|successful(?:ly)?/.test(doc.head);
      var placed = /order (?:has been |is )?placed|will be allotted|request (?:has been )?(?:received|submitted)/.test(doc.head) && !/(?:has|have) been allotted|units allotted/.test(doc.head);
      if ((amK || unK) && done && !placed) {
        var sname = schK ? schK.value : '';
        var mS = !sname && /(?:in|of|for|into|under)\s+(?:the\s+)?(?:[Nn]ew [Ff]und [Oo]ffer (?:\(NFO\) )?of\s+)?([A-Z][\w&'.()]*(?:\s+[\w&'.()]+){0,12}?\s(?:Fund|FoF|ETF|FOF)(?:\s*-\s*(?:Direct|Regular)(?: Plan)?(?:\s*-\s*|\s+)(?:Growth|IDCW))?)(?=[\s.,]|$)/.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 1500) + '\n' + doc.subject);
        if (mS && !/^(?:New Fund|Mutual Fund)$/.test(mS[1])) sname = mS[1];
        if (sname && /[a-z]{3}/i.test(sname)) {
          var both = lc(doc.subject) + ' ' + doc.head;
          var actK = /redeem|redemption|\bswp\b|systematic withdrawal|withdrawal/.test(both) ? 'redeem' : /switch|\bstp\b|systematic transfer/.test(both) ? 'switch' : /\bsip\b|systematic investment/.test(both) ? 'sip' : 'buy';
          var evK = { type: 'fund', action: actK, scheme: trim(sname) };
          if (numOf(amK) > 0) evK.amt = numOf(amK);
          if (numOf(unK) > 0) evK.units = numOf(unK);
          if (numOf(navK) > 0) evK.nav = numOf(navK);
          var foK = lv(/^folio(?: no\.?| number)?$/), fmK = foK ? /[0-9][0-9\/]{3,24}/.exec(foK.value) : /\bfolio(?:\s*(?:no\.?|number))?\s*[:\-]?\s*([0-9][0-9\/]{4,20})/i.exec(doc.flat);
          if (fmK) evK.folio = foK ? fmK[0] : fmK[1];
          var dK = kv(doc, /nav date|allotment date|transaction date|value date|date of (?:allotment|transaction)|settlement date|^date$/);
          evK.date = dK && dK.date ? dK.date : doc.ref;
          if (!(dK && dK.date)) evK.byMail = true;
          if (evK.amt > 0 || evK.units > 0) out.push(evK);
        }
      }
    }
    if (!out.length) {
      // a fund house telling it as a sentence: "We have processed your purchase request for Rs. 19999.00 in <scheme>.
      // Accordingly 1869.992 units have been allotted as per applicable NAV of 30/11/2026 for Rs. 10.6947 per unit."
      var prose = doc.flat.slice(doc.bodyAt, doc.bodyAt + 4000).replace(/\s+/g, ' ');
      var pm = /(?:processed|executed|received and processed)\s+your\s+(purchase|additional purchase|sip(?: instal+ment)?|systematic investment|redemption|switch)(?:\s+(?:request|transaction|order|instal+ment))?\s+(?:for|of)\s+(?:rs\.?|inr|₹)\s*(\d[\d,]*(?:\.\d+)?)\s+(?:in|into|from|under)\s+(?:the\s+)?(.{4,120}?(?:fund|plan|growth|etf|scheme|option|idcw))\b\s*[.,]/i.exec(prose);
      if (pm) {
        var actP = /redeem|redemption/i.test(pm[1]) ? 'redeem' : /switch/i.test(pm[1]) ? 'switch' : /sip|systematic/i.test(pm[1]) ? 'sip' : 'buy';
        var evP = { type: 'fund', action: actP, scheme: trim(pm[3]), amt: num(pm[2]) };
        var after = prose.slice(pm.index, pm.index + 600);
        var uP = /(\d[\d,]*\.\d{2,4})\s+units?\s+(?:have|has|were|was)\s+been\s+(?:allotted|alloted|redeemed|credited)/i.exec(after);
        if (uP) evP.units = num(uP[1]);
        var nP = /\bnav\b(?:\s+of\s+(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{4}))?\s*(?:for|at|of|@|:)?\s*(?:rs\.?|inr|₹)\s*(\d[\d,]*\.\d+)/i.exec(after);
        if (nP) {
          evP.nav = num(nP[4]);
          if (nP[3]) evP.date = nP[3] + '-' + ('0' + nP[2]).slice(-2) + '-' + ('0' + nP[1]).slice(-2);
        }
        if (!evP.date) { evP.date = doc.ref; evP.byMail = true; }
        var foP = /\bfolio(?:\s*(?:no\.?|number))?\s*[:\-]?\s*([0-9][0-9\/]{4,20})/i.exec(prose);
        if (foP) evP.folio = foP[1];
        if (evP.amt > 0 || evP.units > 0) out.push(evP);
      }
    }
    return out;
  }

  /* The money a fund's or a dividend's mail moved. A purchase or SIP confirmed, by the fund house, the registrar or the
     platform it was bought through (Coin, Groww, Kuvera), is the fund event AND your money gone to the fund, party the
     fund house (LABELING.md rule 24; a bank's alert of the same money, when there is one, is folded into it by build());
     a redemption it says was credited came in, one it says will be credited is a promise. A dividend or IDCW the mail
     says was credited to your account is money in. */
  function fundMoney(doc, ctx, fd, dv) {
    var out = [], k = doc.inst ? doc.inst.kind : '', head = doc.head;
    // (rule 24: a fund house's or registrar's own purchase confirmation is the money out; a broker's or platform's only when
    // it says the money went from the bank for it, "paid via UPI from HDFC ••1234". A platform's allotment report is
    // funded from the trading account, a payment made earlier on its own, so it is the fund alone)
    var platformPaid = k === 'broker' && /\b(?:paid|debited|deducted|payment (?:of|made|received))\b[^.\n]{0,80}\b(?:upi|net ?banking|nach|e-?mandate|autopay|mandate|from (?:your )?(?:[a-z]+ )?(?:bank|a\/c|account|savings))\b/.test(doc.low.slice(doc.bodyAt, doc.bodyAt + 2000)) && !/trading account|ledger|funds? balance|allotment report|from (?:your )?(?:zerodha|kite|groww|upstox|broker)\b/.test(lc(doc.subject) + ' ' + doc.low.slice(doc.bodyAt, doc.bodyAt + 2000));
    var depo = /\bcdsl\b|\bnsdl\b|mf ?central/i.test((doc.inst && doc.inst.short) || '');
    var house = (/^(?:rta|amc)$/.test(k) || platformPaid) && !depo;
    // (a redemption credited to the bank is money in, from the fund house's mail or the platform's alike)
    var payer = /^(?:rta|amc|broker)$/.test(k) && !depo;
    var mask = doc.toks.filter(function (t) { return t.t === 'MASK' && inBody(doc, t); })[0];
    var via = mask ? viaFor(doc, mask, '') : { kind: 'other', inst: doc.inst ? doc.inst.short : '' };
    if (via.kind === 'card') via.kind = 'account';
    // (a dividend's letter under a long letterhead is read whole, sentence by sentence: a credit that happened, never one
    // that will, could not, or happened last year; never the tax paid to the government)
    var dvSens = dv.length ? sentencesOf(lc(doc.flat.slice(doc.bodyAt, doc.bodyAt + 3000)).replace(/[ \t]+/g, ' ')).map(function (x) { return x.text; }) : [];
    var dvPast = dvSens.some(function (t) { return /(?:has been|have been|was|were) (?:\w+ly )?(?:credited|paid|remitted)\b|\bremitted to your bank account\b/.test(t) && !/\b(?:will|shall|once|could not|cannot|not been|unable|last year|previous|earlier|tds|tax deducted|government|to those members)\b/.test(t); });
    var credited = /(?:has been|have been|was|were) (?:(?:\w+ly )?(?:credited|paid|remitted)|transferred to your)|credited to your (?:registered )?(?:bank )?(?:a\/c|account)[^.\n]{0,40}\bon\b|proceeds have been credited/.test(head) || dvPast;
    var promised = /will be (?:credited|paid|remitted)|will reach|within \d+ (?:working |business )?days|in \d+ (?:working |business )?days|expected (?:to be credited|by)/.test(head) ||
      (dv.length > 0 && !dvPast && dvSens.some(function (t) { return /\b(?:will|shall) be (?:credited|paid|remitted)/.test(t); }));
    var houseOf = function (scheme) {
      var sh = doc.inst ? doc.inst.short : '';
      if (/mutual fund|\bmf\b|\bamc\b/i.test(sh)) return sh;
      var w = String(scheme || '').split(/\s+/)[0];
      return w && /^[A-Z]/.test(w) ? w.replace(/[^A-Za-z]/g, '') + ' Mutual Fund' : sh;
    };
    if (payer) fd.forEach(function (f) {
      if (!(f.amt > 0)) return;
      if (f.action === 'buy' || f.action === 'sip') {
        if (!house) return;
        if (/order (?:has been |is )?placed|will be (?:debited|allotted)/.test(head) && !/(?:has|have) been allotted|processed/.test(head)) return;
        out.push({ type: 'move', dir: 'out', amt: f.amt, date: f.date || doc.ref, via: mask ? via : { kind: 'other', inst: doc.inst.short }, purpose: 'investment', party: houseOf(f.scheme) });
      } else if (f.action === 'redeem') {
        var d = labeledDate(doc, /credited to your [^.\n]{0,60}? on|credited on|paid on|remitted on/);
        if (credited && !promised) out.push({ type: 'move', dir: 'in', amt: f.amt, date: d || f.date || doc.ref, via: via, purpose: 'redemption', party: houseOf(f.scheme) });
        else if (promised || credited) out.push({ type: 'expect', dir: 'in', what: 'payout', amt: f.amt, party: houseOf(f.scheme) });
      }
    });
    // a dividend or IDCW credited: the account's credit, as the alert would read it where the mail prints it, else from the advice
    if (dv.length && credited && !promised) {
      var a = dv[0].amt;
      var mm = moves(doc, ctx).filter(function (e) { return e.type === 'move' && e.dir === 'in' && Math.abs(e.amt - a) < 0.011; })[0];
      if (!mm) {
        mm = { type: 'move', dir: 'in', amt: a, date: dv[0].date || doc.ref, via: via };
        // the advice's own lines: its credit reference, the bank it went to; a company's dividend is paid by NACH
        var dref = kv(doc, /(?:credit|electronic|payment) reference|advice no|^reference (?:no\.?|number)$|^ref(?:erence)? no\.?$|^utr/);
        var dr0 = dref ? /[A-Z0-9][A-Z0-9\-]{3,30}/i.exec(dref.value) : null; if (dr0 && /\d{3,}/.test(dr0[0])) mm.ref = dr0[0];
        var dbank = kv(doc, /^bank name$|^name of (?:the )?bank$/), dbm = /\b(?:bank name|name of (?:the )?bank)\s*[:|]?\s*\n?\s*([A-Za-z][^\n|]{2,60})/i.exec(doc.flat.slice(doc.bodyAt));
        // (never a footer's "our bankers" or the company's own dividend account)
        if (dbank && /company|dividend account|our banker/i.test(dbank.value)) dbank = null;
        if (dbm && /company|dividend account|our banker/i.test(dbm[1] + doc.flat.slice(Math.max(0, doc.bodyAt + dbm.index - 60), doc.bodyAt + dbm.index))) dbm = null;
        var dwho = E.issuerIn && (dbank || dbm) ? E.issuerIn(dbank ? dbank.value : dbm[1], false) : null; if (dwho && via.kind === 'account' && !via.inst) via.inst = dwho.short;
        // (the advice's table, "Bank Account Number | Date of Credit & Reference No. | … Name of the Bank and Branch" over
        // one row: the account's last four, the credit's own reference after its date, the bank; over the advice's number)
        var dtab = !mask ? tableWith(doc, /bank account (?:number|no)/, /reference|name of (?:the )?bank|ifsc/) : null;
        if (dtab && dtab.rows.length === 1) {
          var drow = dtab.rows[0], dacct = drow.cell(/bank account (?:number|no)/).replace(/\s+/g, '');
          if (/^[x*•]*\d{4,20}$/i.test(dacct)) { mm.via = { kind: 'account', last4: dacct.slice(-4) }; via = mm.via; }
          var dcr = /(?:\d{1,2}[-\/.]\d{1,2}[-\/.]\d{2,4}|\d{4}-\d{2}-\d{2})\s+([A-Z0-9]{6,30})\s*$/i.exec(drow.cell(/reference/));
          if (dcr && /\d{4,}/.test(dcr[1])) mm.ref = dcr[1];
          var dbn = drow.cell(/name of (?:the )?bank|ifsc/), dwh = dbn && E.issuerIn ? E.issuerIn(dbn, false) : null;
          if (dwh && mm.via.kind === 'account') mm.via.inst = dwh.short;
        }
        if (!/demand draft|\bwarrant\b|\bcheque\b/i.test(doc.flat.slice(doc.bodyAt, doc.bodyAt + 3000))) mm.mode = 'NACH';
      }
      mm.purpose = 'dividend';
      if (dv[0].company && (!mm.party || /^(?:cams|kfintech|mufg intime|link intime)$/i.test(mm.party))) mm.party = dv[0].company;
      out.push(mm);
    }
    return out;
  }

  /* a table drawn as a header row of labels over rows of values: the first header line whose cells match both
     patterns, and the rows under it with as many cells, each row able to say what is in the column a label names */
  function tableWith(doc, reA, reB) {
    for (var i = 1; i < doc.lines.length; i++) {
      var head = doc.lines[i].split(' | ').map(function (c) { return lc(trim(c)); });
      if (head.length < 3 || !head.some(function (c) { return reA.test(c); }) || !head.some(function (c) { return reB.test(c); })) continue;
      if (head.some(function (c) { return /\d{3,}/.test(c); })) continue;
      var rows = [];
      for (var j = i + 1; j < doc.lines.length; j++) {
        var cells = doc.lines[j].split(' | ');
        if (cells.length < Math.max(3, head.length - 1)) break;
        (function (cells, at, text) {
          rows.push({ cells: cells, s: at, e: at + text.length, text: text,
            cell: function (re) { for (var k = 0; k < head.length; k++) if (re.test(head[k]) && cells[k] != null) return trim(cells[k]); return ''; } });
        })(cells, doc.lineAt[j], doc.lines[j]);
      }
      if (rows.length) return { head: head, rows: rows };
    }
    return null;
  }

  /* shares moving in or out of a demat account (CDSL/NSDL), with the ISIN, name and quantity */
  function trades(doc, ctx) {
    var s = lc(doc.subject);
    var dlead = s + ' ' + doc.lead.slice(0, 400);
    if (!/transactions? in your demat|demat account (?:debit|credit)|securities (?:(?:have|has) been |were |was )?(?:debited|credited)|(?:debit|credit) of securities|debit transaction|credit transaction/.test(dlead)) return [];
    // (the way the mail says they went, when a row doesn't: "The following securities have been debited from your demat
    // account", rule 31: a debit is a sell, a credit a buy)
    var saidSide = /securities (?:(?:have|has) been |were |was )?debited|\bdebit of securities|demat account debit/.test(dlead) ? 'sell' : /securities (?:(?:have|has) been |were |was )?credited|\bcredit of securities|demat account credit/.test(dlead) ? 'buy' : '';
    if (/rights entitlement/.test(s)) return [];
    var out = [];
    doc.toks.filter(function (t) { return t.t === 'ISIN'; }).forEach(function (t) {
      var ls = doc.flat.lastIndexOf('\n', t.s) + 1, le = doc.flat.indexOf('\n', t.e); if (le < 0) le = doc.flat.length;
      var line = doc.flat.slice(ls, le), row = doc.flat.slice(ls, Math.min(doc.flat.length, le + 300));
      var side = /\b(?:debit|dr|sell|sold)\b/i.test(line) ? 'sell' : /\b(?:credit|cr|buy|bought)\b/i.test(line) ? 'buy' : (/debit/i.test(row) ? 'sell' : /credit/i.test(row) ? 'buy' : saidSide);
      var name = /([A-Z][A-Z0-9&.' \-]{3,60}(?:LIMITED|LTD|LIMTED|LIMTD)\.?)/.exec(row);
      var qty = null, cells = line.split(' | ');
      var after = cells.slice(cells.findIndex(function (c) { return c.indexOf(t.v) >= 0; }) + 1);
      for (var i = 0; i < after.length; i++) { var c = trim(after[i]); if (/^\d[\d,]*(?:\.\d+)?$/.test(c)) { qty = num(c); break; } }
      if (qty === null) { var q = /(?:qty|quantity)\s*[:\-|]?\s*(\d[\d,]*)/i.exec(row) || /\b(\d[\d,]*)\s*(?:shares|securities)/i.exec(row); if (q) qty = num(q[1]); }
      var d = near(doc, 'DATE', t.s, 300, 200);
      if (!side || !qty) return;
      var ev = { type: 'trade', side: side, isin: t.v, qty: qty, date: d ? d.v : doc.ref };
      if (name) ev.name = trim(name[1]);
      out.push(ev);
    });
    return out;
  }

  /* a card or account that exists: delivered, activated, its limit changed, closed; or a statement mail with
     nothing in it but the card's digits */
  function accounts(doc, ctx) {
    var s = lc(doc.subject);
    if (!(doc.inst && /^(?:bank|card|app|broker)$/.test(doc.inst.kind))) return [];
    var step = /deliver(?:ed|y)|dispatched|on its way/.test(s) && /card/.test(s + ' ' + doc.lead) ? 'delivered'
      : /activated|activation/.test(s) && /card/.test(s) ? 'activated'
      : /limit (?:has been )?(?:enhanced|increased|changed|revised|updated)|credit limit/.test(s) ? 'limit'
      : /(?:account|card) (?:has been |is )?closed|closure/.test(s) || /\b(?:card|account|a\/c)\b[^.\n]{0,40}\b(?:has been|is|was)\s+(?:permanently\s+)?(?:closed|cancell?ed|terminated)\b/.test(doc.lead) ? 'closed'
      : /statement/.test(s) && !ctx.stmt ? 'seen' : '';
    if (!step) return [];
    var masks = doc.toks.filter(function (t) { return t.t === 'MASK'; });
    // the digits the body's own sentence names (the subject may carry another number)
    var m = masks.filter(function (t) { return inBody(doc, t) && /closed|cancell?ed|deliver|dispatch|activated|limit/.test(lc(sentenceAt(doc, t.s).text)); })[0] || masks[0];
    var cf = /\b(?:for|id)\s+([A-Z]{2}\d{3,6})\b/.exec(doc.subject);
    if (!m && !cf && step === 'seen' && !/[x*]{2,}\d{2,4}/i.test(doc.files)) return [];
    var via = m ? viaFor(doc, m, '') : { kind: doc.kind === 'broker' ? 'account' : 'card', inst: doc.inst.short, last4: cf ? cf[1].slice(-4) : '' };
    if (!via.last4) { var fm = /(?:^|[^\d])\d{0,6}[x*]{2,}(\d{2,4})(?!\d)/i.exec(doc.files); if (fm) via.last4 = fm[1]; }
    if (/card/.test(s)) via.kind = 'card';
    if (!via.last4) delete via.last4;
    return [{ type: 'account', via: via, step: step }];
  }

  /* ------------------------------------------------------------ 7. reading a mail */
  var OTP = /\b(?:otp|one[\s-]?time[\s-]?pass(?:word|code)|verification code|security code)\b/i;
  // a mail that says it is marketing, in its own unsubscribe line
  var MARKETING_MAIL = /\b(?:further|any|receive|these|our) (?:promotional |marketing )?(?:marketing|promotional) (?:e-?mails?|e-?mailers?|communications?|messages|mails?)\b|\bthis is a (?:promotional|marketing) (?:e-?mail|mail|message|communication)\b/;
  // (that footer rides on alerts too, "if you do not wish to receive further marketing e-mails": a mail is marketing only
  // when its own opening sells something)
  var OFFER_CUE = /\b(?:lifetime free|reward points?|cashback|win (?:a|up to|flat)|apply (?:now|today)|pre-?approved|explore the features|get (?:your |a |an )?[\w ]{0,30}card\b[^.\n]{0,20}\b(?:instantly|today|now)|limited (?:period|time))\b/;
  // a reward rate or an offer's threshold, never a spend: "3 Reward Points per ₹100 spent", "on every ₹200 spent"
  var REWARD_RATE = /\b(?:per|for every|on every|every|on spends? (?:of|above)|when you spend)\s+(?:(?:₹|rs\.?|inr)\s?)?[\d,]+(?:\.\d+)?(?:\s+(?:or more|and above))?(?:\s+(?:spent|spend|spends))?/gi;
  var PROMO = /\b(?:offer|offers|deal|deals|sale|win|exclusive|pre-?approved|limited period|last chance|hurry|apply now|upgrade|invite|introducing|discover|get up to|upto|flat \d+%|% off|cashback up to|festive|webinar|newsletter|survey|feedback|rate us|save on)\b/i;
  // a payment that didn't go through (not a seller who "declined" an order, not a "failed delivery attempt")
  var FAILED = /\b(?:payment|transaction|txn|debit|transfer|bill payment|auto-?pay|mandate|purchase|recharge)\b(?:[^.\n]|\.(?=\s?\d)){0,40}\b(?:declined|failed|failing|unsuccessful|could not be (?:processed|completed)|was not successful|rejected)\b|\b(?:declined|failed|unsuccessful)\b[^.\n]{0,20}\b(?:payment|transaction|txn)\b|insufficient (?:funds|balance)|\brefund\b[^.\n]{0,60}\bcould not be (?:credited|paid|processed|issued)\b|\brefund fail(?:ed|ure)\b/i;
  // a sentence that says a payment did not go through, however long ("your transaction of INR X using your card
  // XX0099 has been declined"), and not a conditional ("if your transaction is declined, call us")
  function failedSentence(text) {
    return text.split(/(?:[.!?](?=\s)|\n)+/).some(function (sn) {
      var m = /\b(?:declined|failed|unsuccessful|could not be (?:processed|completed)|was not successful|rejected)\b/.exec(sn);
      if (!m) return false;
      var before = sn.slice(0, m.index);
      // ("… has failed", "… could not be completed", or a sentence about your payment that ends on the word: "Your UPI
      // transaction of INR 1,850 to EXAMPLE on 04/10/2026 failed.")
      return /\b(?:payment|transaction|txn|debit|transfer|purchase|recharge|auto-?pay|mandate)\b/.test(before) && !/\b(?:if|in case|incase|should|whenever|avoid|prevent|may be|might be|can be|could be)\b/.test(before) &&
        (/\b(?:has been|have been|has|have|had|was|were|is|got)\s*(?:\w+\s+)?$/.test(before) || /^(?:could not|was not)/.test(m[0]) ||
         (/^\s*(?:your|the)\b/i.test(sn) && /^\s*$/.test(sn.slice(m.index + m[0].length)) && !/\?/.test(sn)));
    });
  }
  function noiseReason(doc, ctx) {
    var s = lc(doc.subject), l = doc.lead;
    if (ctx.otp) return 'otp';
    if (ctx.verify) return 'security';
    if (ctx.consent) return 'request';
    if (ctx.failed) return 'failed';
    if (ctx.delivery) return 'delivery';
    if (ctx.creditReport) return 'info';
    if (/\bkyc\b|re-?kyc|update your (?:pan|aadhaar|details)/.test(s)) return 'kyc';
    if (/log(?:ged)? ?in|login|password (?:changed|reset)|new device|security alert|profile (?:updated|changed)|mobile number (?:updated|changed)|email (?:id )?(?:updated|changed)/.test(s)) return 'security';
    if (/statement/.test(s)) return 'statement-ready';
    if (/receipt of (?:your )?request|request (?:received|registered)|service request|we have received your (?:request|query)|\bticket\s*(?:no\.?|number|id|#)|\b(?:raised|your|support)\s+(?:a\s+)?ticket\b|complaint|grievance|counter offer|review and confirm|payment pending|proposal/.test(s + ' ' + l.slice(0, 200))) return 'request';
    if (ctx.nudge || PROMO.test(s) || (/unsubscribe/.test(doc.low) && !PAST_MONEY.test(l))) return 'offer';
    if (/plan (?:is )?active|recharge successful|converted|activated|welcome|thank you for (?:choosing|registering)|is failing/.test(s)) return 'service';
    return 'info';
  }
  /* read(msg, { book, learn, weight }): with a book, a known template fills or reads the mail, and (unless learn is
     false) the reading is learnt into it. teach(book, msg, events): a teacher's reading of a mail (Claude's, a
     correction) learnt with three times the weight */
  function read(msg, opts) {
    var r = readOnce(msg);
    if (!opts || !opts.book) return judged(r);
    var doc = r._doc, fp = fingerprint(doc), L = bookFind(opts.book, fp);
    if (L) {
      var ctx = { otp: r.events.some(function (e) { return e.reason === 'otp'; }), failed: r.events.some(function (e) { return e.reason === 'failed'; }), promo: r._promo };
      var evs = applyBook(L, doc, r.events.filter(function (e) { return e.type !== 'noise'; }), ctx);
      var main = evs.filter(function (e) { return e.type !== 'account'; });
      if (main.length && !ctx.failed) { r.events = evs; r.kind = main[0].type; r.template = L.id; }
      if (L.no) {
        var kept = r.events.filter(function (e) { return !(L.no[e.type] > 0); });
        if (kept.length < r.events.length) {
          r.events = kept;
          var left = kept.filter(function (e) { return e.type !== 'account' && e.type !== 'noise'; });
          if (!left.length) { r.events = [{ type: 'noise', reason: 'corrected' }].concat(kept.filter(function (e) { return e.type === 'account'; })); r.kind = 'noise'; }
          else r.kind = left[0].type;
          r.corrected = true;
        }
      }
    }
    if (opts.learn !== false && teachable(r.events)) learnInto(opts.book, fp, doc, r.events, opts.weight || 1, L);
    trimBook(opts.book);
    return judged(r);
  }
  /* A mail teaches its template once: read again (new rules, a re-read of the year), it's the same mail, not a second
     sure reading, so one mail can never carry a template to the bar it needs three to reach. The template keeps the
     ids of the last mail that taught it (their stable hash, a dozen) */
  function teach(book, msg, events) {
    var doc = docOf(msg), fp = fingerprint(doc), L0 = bookFind(book, fp);
    var mid = msg && msg.id ? String(msg.id).split('|')[0] : '';
    var tag = mid ? hashId(mid) : '';
    if (L0 && tag && (L0.taught || []).indexOf(tag) >= 0) return;
    var L = learnInto(book, fp, doc, events, 3, L0) || bookFind(book, fp);
    if (L && tag) { L.taught = (L.taught || []).concat([tag]).slice(-12); }
    trimBook(book);
  }
  function hashId(s) { var h = 5381; for (var i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0; return (h >>> 0).toString(36); }
  /* the person says a mail isn't what kosh read ("this isn't a deposit", "not a payment"): its template learns it, so
     the next mail of the same shape isn't read that way either. Only a teacher (Claude, or the person correcting it
     the other way) can say it is again; the reader's own sure readings don't outvote the person. */
  function teachNot(book, msg, type) {
    var doc = docOf(msg), fp = fingerprint(doc);
    var L = bookFind(book, fp) || learnInto(book, fp, doc, [{ type: 'noise' }], 1, null);
    L.no = L.no || {};
    L.no[type] = (L.no[type] || 0) + 3;
    if (L.types[type]) delete L.types[type];
    trimBook(book);
    return L.id;
  }
  // the correction taken back
  function teachUndo(book, msg, type) {
    var L = bookFind(book, fingerprint(docOf(msg)));
    if (!L || !L.no || !(L.no[type] > 0)) return '';
    L.no[type] -= 3;
    if (L.no[type] <= 0) delete L.no[type];
    if (!Object.keys(L.no).length) delete L.no;
    return L.id;
  }
  /* the words an event was read from, to show beside it ("Where kosh read this"): the line holding its amount (the
     exact text the amount was taken from, when the reading kept it), else its date, its number or its name; at most
     140 characters, cut around what it points to. Every figure on the screen can say where it came from. */
  function quoteOf(doc, e) {
    var raw = e.ev && e.ev.amt, at = -1;
    if (raw) at = doc.flat.indexOf(raw, doc.bodyAt);
    if (raw && at < 0) at = doc.flat.indexOf(raw);
    var v = e.amt != null ? e.amt : e.total != null ? e.total : e.premium != null ? e.premium : null;
    if (at < 0 && v != null) {
      var tk = doc.toks.filter(function (t) { return t.t === 'AMT' && Math.abs(t.v - v) < 0.011; });
      tk = tk.filter(function (t) { return inBody(doc, t); })[0] || tk[0];
      if (tk) at = tk.s;
    }
    if (at < 0) {
      var key = e.no || e.policyNo || e.order || e.folio || e.company || e.scheme || e.shop || e.party || '';
      if (key) { at = doc.flat.indexOf(String(key), doc.bodyAt); if (at < 0) at = doc.flat.indexOf(String(key)); }
    }
    if (at < 0) return safeQuote(trim(doc.subject).slice(0, 140));
    var ls = doc.flat.lastIndexOf('\n', at) + 1, le = doc.flat.indexOf('\n', at); if (le < 0) le = doc.flat.length;
    var line = doc.flat.slice(ls, le).replace(/\s*\|\s*/g, ' · ').replace(/\s+/g, ' ').trim();
    // GUARDRAIL a quote never carries a secret: a line that holds a code, a PIN, a one-time password, a CVV or a
    // password is not quoted (the subject stands in), and long numbers keep only their last four digits
    // (a row under a header of secrets, "Voucher Code | Voucher Pin | ...", is as secret as the header)
    var above = doc.flat.slice(Math.max(0, doc.flat.lastIndexOf('\n', Math.max(0, ls - 2)) - 400), ls);
    if (SECRET_LINE.test(line) || SECRET_LINE.test(above.split('\n').slice(-3).join(' '))) return safeQuote(trim(doc.subject).slice(0, 140));
    if (line.length <= 140) return safeQuote(line);
    var off = Math.max(0, Math.min(at - ls - 60, line.length - 140));
    return safeQuote((off > 0 ? '…' : '') + line.slice(off, off + 138).trim() + '…');
  }
  var SECRET_LINE = /\b(?:code|pin|otp|one[- ]time|cvv|cvc|password|passcode|passkey|voucher (?:no|number)|claim|e-?gift card (?:no|number)|gift card (?:no|number|code)|card number|egv|serial (?:no|number)|activation key|secret)\b/i;
  function safeQuote(q) {
    q = String(q || '');
    if (SECRET_LINE.test(q)) q = q.replace(/\b(?=[A-Z0-9-]*\d)[A-Z0-9][A-Z0-9-]{5,}\b/g, '••••');
    return E.redact ? E.redact(q) : q.replace(/\d[\d -]{6,}\d/g, function (d) { var g = d.replace(/\D/g, ''); return g.length >= 8 ? '••' + g.slice(-4) : d; });
  }
  /* an app bank kosh's directory doesn't know ("Orbit <alerts@orbit.money>"), or an app that fronts a bank's account
     (Fi, Jupiter): a mail of its own that prints your account's digits AND its balance is that account's. Its
     institution is the bank the mail says holds it ("Orbit savings accounts are held at Federal Bank"), else the app's
     own brand. Never a person's mailbox, a shop, or a mail whose account already has its bank */
  var APP_BANK_HOME = /\b(?:(?:are|is)\s+)?(?:held|maintained|opened|hosted|offered|provided|issued)\s+(?:at|with|by)\s+([^.\n|]{3,50})|\bin partnership with\s+([^.\n|]{3,50})|\bpowered by\s+([^.\n|]{3,50})|\bbanking services\s+(?:are\s+)?(?:provided|offered)\s+by\s+([^.\n|]{3,50})/i;
  function appBankAccount(doc, ctx, events) {
    if (ctx.person || ctx.failed || personalMail(doc)) return;
    var di = doc.inst;
    if (di && !(di.kind === 'app' && di.cobrand && /^(?:account|app)$/.test(di.cobrand.kind || ''))) return;
    if (!di && (shopOf(doc) || billerOf(doc))) return;
    // (a bank named only somewhere else in the mail, "from ROHAN EXAMPLE (HDFC ••3390)", is not this account's: only a
    // bank printed right before the account's own digits names it)
    var guessed = function (e) {
      if (!e.via.inst || !E.issuerIn) return false;
      return !doc.toks.some(function (t) {
        if (t.t !== 'MASK' || String(t.v || '').slice(-String(e.via.last4).length) !== String(e.via.last4)) return false;
        var b = E.issuerIn(doc.flat.slice(Math.max(0, t.s - 30), t.s), false);
        return !!b && b.short === e.via.inst;
      });
    };
    var bare = function (e) { return e.via && e.via.kind === 'account' && String(e.via.last4 || '').length >= 3 && (!e.via.inst || guessed(e)); };
    var bals = events.filter(function (e) { return e.type === 'balance' && bare(e); });
    if (!bals.length) return;
    var l4 = bals[0].via.last4;
    var home = '', m = APP_BANK_HOME.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 4000));
    if (m && E.issuerIn) { var b = E.issuerIn(m[1] || m[2] || m[3] || m[4], false); if (b && b.kind === 'bank') home = b.short; }
    if (!home && di && di.cobrand && di.cobrand.issuer && E.issuerIn) { var ci = E.issuerIn(di.cobrand.issuer + ' bank', false); if (ci && ci.kind === 'bank') home = ci.short; }
    // (else the name its mail is sent under, "Orbit <alerts@…>", or its domain's)
    if (!home) { var dnm = /^\s*"?([A-Za-z][A-Za-z0-9&.' ]{1,30}?)"?\s*</.exec((doc.msg && doc.msg.from) || ''); home = dnm && !/no-?reply|alerts?|notifications?|team|support|bank\b/i.test(dnm[1]) ? trim(dnm[1]) : senderBrand(doc); }
    if (!home) return;
    events.forEach(function (e) { if ((e.type === 'move' || e.type === 'balance') && bare(e) && e.via.last4 === l4) e.via.inst = home; });
  }
  /* a pension slip ("Pension Slip for the month of September 2026", "Net Pension credited Rs. 67,568.00") sent after the
     month's pension: the money came on the day it was credited, which the slip prints, or, when it doesn't, the
     month's last working day (when the pension is credited), never the day the slip was mailed */
  function pensionSlipDay(doc, events) {
    var ms = /\bpension slip\b[^\n]{0,30}?\b(january|february|march|april|may|june|july|august|september|october|november|december)\s+(\d{4})\b/i.exec(doc.subject);
    if (!ms) return;
    var mv = events.filter(function (e) { return e.type === 'move' && e.dir === 'in'; })[0];
    if (!mv || !kv(doc, /^net (?:pension|family pension) (?:credited|paid)$/)) return;
    var cd = kv(doc, /^(?:date of credit|credit date|credited on|pension credited on|date of payment|paid on)$/), day = cd && cd.date ? cd.date : '';
    if (!day) {
      var y = +ms[2], mo = monOf(ms[1]), last = isoOf(dayNum(y + '-' + pad(mo) + '-01') + new Date(Date.UTC(y, mo, 0)).getUTCDate() - 1);
      while ([0, 6].indexOf(new Date(dayNum(last) * 864e5).getUTCDay()) >= 0) last = addDays(last, -1);
      day = last;
    }
    if (day && doc.ref && day <= doc.ref && dayNum(doc.ref) - dayNum(day) <= 20) { mv.date = day; delete mv.time; }
    // (the slip's own label says what it is: the net pension, from whoever pays it)
    if (!mv.party) mv.party = 'Pension';
    mv.conf = 'high';
  }
  function readOnce(msg) {
    var doc = docOf(msg);
    var s = lc(doc.subject);
    var ctx = {};
    ctx.otp = (OTP.test(s) && !/order|deliver|arriv/.test(s)) || /\b(?:otp|one[- ]time password) (?:is|for)\b|\bis your (?:otp|one[- ]time password)\b/.test(doc.lead.slice(0, 300));
    ctx.failedSubject = FAILED.test(s) && !/(?:now|is|has been) confirmed|retry (?:was )?succe|\bsucceeded\b/.test(s);
    // the subject decides first: a body that is a failure template under a subject saying it worked is the template
    // (an app's template can keep "is successful" in the subject of its failure mail: "We are sorry that your Electricity
    // bill payment for Rs.1000.00 has failed")
    ctx.failed = ctx.failedSubject || /\b(?:we are|we're|we regret|sorry)\b[^.\n]{0,30}\b(?:that )?your\b[^.\n]{0,80}(?:\.\d+)?[^.\n]{0,40}\b(?:has|have) (?:failed|been declined)\b/.test(doc.lead.slice(0, 300)) && !/\b(?:is |was )?now successful|\bon retry\b|retr(?:y|ied) (?:was )?success|\bhas been debited\b|previous attempt/.test(doc.lead.slice(0, 500)) || (!/\b(?:successful|success|successfully|confirmed|received)\b/.test(s.replace(/\b(?:not|un)\s*successful\b/g, '')) && (FAILED.test(factual(doc.lead.slice(0, 400))) || failedSentence(factual(doc.lead.slice(0, 500)))) &&
        // (no money moved is said: "if debited, it will be reversed" and "… debited for a failed transaction will be reversed"
        // promise it back; "INR 1,250 has been debited …; in case of a failed transaction, the amount will be reversed" moved it)
        !PAST_MONEY.test(factual(doc.lead.slice(0, 400), true).replace(FAILED, '')));
    // (a payment that didn't go through, its money debited and "will be credited back": failed, its refund only promised)
    // (never a condition: "if the transaction failed, the amount will be reversed")
    if (!ctx.failed && /didn['’]?t go through|did not go through|\b(?:payment|transaction|txn)\b[^.\n]{0,40}\bfailed\b/.test(factual(doc.lead.slice(0, 400))) && /\bwill be (?:credited back|refunded|reversed)\b/.test(factual(doc.lead.slice(0, 600)))) ctx.failed = true;
    // (a subject's "scheduled" or "in progress" over a debit the mail says happened is that debit: "NEFT transfer in
    // progress … has been debited"; one still pending may yet reverse)
    // (in a sentence about this payment: never "your last payment of Rs.900 was paid on 20-09-26")
    var pastDebit = sentencesOf(doc.head).some(function (x) { return /\b(?:has been|have been|was)\s+(?:successfully\s+)?(?:debited|paid|processed)\b/.test(x.text) && !/\b(?:last|previous|earlier) (?:payment|month|bill|recharge|transaction|debit)s?\b|\blast month\b/.test(x.text); });
    ctx.future = /\b(?:payment|transaction|transfer) (?:is )?pending|\bpayment pending\b/.test(s) || /\b(?:payment|transaction|transfer) (?:is )?(?:scheduled|in progress)|\bis scheduled\b/.test(s) && !pastDebit || /\b(?:scheduled for (?:automatic )?payment|will be (?:auto-?)?debited|upcoming (?:payment|debit|e-?mandate)|pre-?debit notification|due for debit)\b/.test(doc.head) && !pastDebit;
    ctx.insurer = !!insurerIn(doc) && /\bpolicy\b|premium/.test(doc.head);
    // (a mail that calls itself marketing, "further marketing e-mails on your CRN ending with 1234", is one, whatever its
    // subject; a reward rate, "3 Reward Points per ₹100 spent", is no spend)
    ctx.promo = (PROMO.test(s) || /\bget\s+9[9,.]*\s+(?:cashback|off|discount|reward)|\bpre-?approved\b|\bapply now\b|\bt&c apply\b|when you spend/.test(doc.head) || (MARKETING_MAIL.test(doc.low.slice(doc.bodyAt)) && OFFER_CUE.test(doc.head))) &&
      !/\b(?:has been|have been|was|is)\s+(?:successfully\s+)?(?:debited|credited|paid|spent|received|refunded|reversed)\b|\bdebited from\b|\bspent\b|\bwas used\b|thank you for (?:your )?payment|\b(?:bill payment|payment|recharge|transaction) (?:is |was |has been )?successful\b|you have successfully (?:made|paid|completed)|\b(?:initiated|processed|issued) (?:your |the )?refund\b|\brefund (?:has been |is |was )?(?:initiated|processed|issued)\b/.test(doc.lead.replace(FUTURE_VERB, '').replace(REWARD_RATE, ' '));
    // a credit bureau's or a score app's report ("Your CIBIL score is 768", "Your Experian credit report is ready"): what
    // it says you paid or owe across your loans is the report's, never a payment, a bill or a promise this mail makes
    // (the lender's and the bank's own mail are the record)
    // (a subject about the report itself: never a bill's "Pay now to maintain your credit score")
    ctx.creditReport = /\b(?:cibil|experian|equifax|crif(?: high mark)?)\b|\bcredit (?:score|report|health|rating)\b/.test(s) && !/\b(?:receipt|invoice|payments?|paid|pay|order|subscription|membership|refund|due|bill|statement|reminder|emi)\b/.test(s);
    if (ctx.creditReport) ctx.promo = true;
    /* GUARDRAIL a newsletter that pictures a payment and calls it an illustration ("RENT PAYMENT ✓ Approved ₹50,000 Paid
       by credit card … Illustrative example", "EXAMPLE: ₹50,000 RENT"): marketing, never a payment of yours */
    if (!ctx.promo && /\bunsubscribe\b/.test(doc.low) && /\billustrative\b|\bfor (?:the purpose of )?illustration\b|\bsample (?:receipt|payment|transaction)\b|(?:^|\n)\s*example\s*:/.test(doc.low.slice(doc.bodyAt))) ctx.promo = true;
    // a bank checking a payment with you ("Verify your recent transaction", "was this you?") or waiting on your
    // consent for one ("FD ... is awaiting your consent"): nothing has happened yet that this mail can count
    var asks = lc(doc.subject) + ' ' + doc.lead.slice(0, 500);
    ctx.verify = /verify (?:your |a )?(?:recent )?transaction|confirm (?:a |your |the )?(?:recent )?transaction|transaction monitoring|was this (?:you|transaction done by you)|did you (?:make|authori[sz]e|do) this/.test(asks);
    ctx.consent = /awaiting your consent|provide your consent|consent reminder|confirm by entering the otp|pending (?:your )?(?:approval|authori[sz]ation)/.test(asks);
    ctx.letter = /\bsurvey\b|we value your feedback|(?:share|give) (?:us )?your feedback on|\b(?:your|the|this) complaint\b|\bcomplaint\s*(?:no\.?|number|id|ref)|grievance (?:no\.?|number|id|ref)|case ?id\b|we thank you for writing|in response to your (?:mail|e-?mail|letter|query|complaint)|with reference to your (?:mail|e-?mail|letter|query|complaint)|your (?:mail|e-?mail|letter) dated/.test(asks);
    // someone asking you for money (a UPI collect request, a split) hasn't been paid: a request, nothing moved
    // (a request received is a request, unless the same mail says money moved: "Rs.100 has been debited as charges")
    ctx.consent = ctx.consent || /\byour request for (?:the )?(?:registration|set ?up|setting up|activation|cancellation|change|updat)[^.\n]{0,80}(?:has been|is) received\b/.test(asks) && !/\b(?:has been|have been|was)\s+(?:\w+ )?(?:debited|credited|refunded)\b/.test(doc.lead.slice(0, 500));
    ctx.consent = ctx.consent || (/\bhas requested (?:₹|rs\.?|inr)\s?\d|\brequested (?:₹|rs\.?|inr)\s?\d[^.\n]{0,60}\bfrom you\b|\bcollect request\b|\bpayment request from\b|\bhas requested (?:a |the )?payment\b|\bplease complete the payment of\b|\bcomplete (?:the |your )?payment (?:of [^.\n]{0,30})?within\b/.test(asks) &&
      !/\byou paid\b|\bdebited\b|\bpaid from\b|(?:payment|transaction)[^.\n]{0,80}\b(?:successful|completed)\b|has been paid/.test(asks));
    // a shop's nudge to buy (a cart left behind, a price drop, a coupon for your next order): no order, no money
    var nudgeAt = lc(doc.subject) + ' ' + lc((doc.lines.slice(1).filter(function (x) { return trim(x).length > 3 && !/\|/.test(x); })[0]) || '');
    ctx.nudge = /left (?:something|it|items?) behind|(?:still )?(?:waiting )?in your (?:bag|cart)|your (?:bag|cart) (?:misses|is waiting)|price (?:has )?dropped|price drop|\bwishlist\b|back in stock|\boff on (?:your )?(?:next )?orders?\b|\bflat (?:₹|rs\.?|inr)\s?\d[\d,]*\s?off\b|\b(?:order|buy|shop) now\b|complete your (?:order|purchase) now/.test(nudgeAt) &&
      !PAST_MONEY.test(doc.lead.slice(0, 500).replace(FUTURE_VERB, '')) && !/order (?:id|no\.?|number|#)\s*[:#]?\s*[a-z0-9-]{5,}/i.test(doc.flat.slice(0, 1500));
    // (a subject that asks you to pay or recharge again is a nudge, whatever past payment its body recalls)
    if (/\brecharge now\b|\bpay again\b|\b(?:is |are )?expiring soon\b|\bexpires soon\b|\brenew now\b/.test(s) && !/\b(?:receipt|invoice)\b/.test(s)) ctx.nudge = true;
    if (ctx.nudge) ctx.promo = true;
    // (a reply in a thread about a refund you asked for, "Re: Refund request for order #…", "We have noted your request"):
    // a request, nothing moved or promised yet
    ctx.consent = ctx.consent || /^\s*(?:re|aw)\s*:/i.test(doc.subject) && /\brefund request\b|\brequest(?:ed)? (?:for )?(?:a )?refund\b|\brequest for (?:a )?refund\b/.test(asks) && !/\b(?:has been|have been|was|is)\s+(?:successfully\s+)?(?:initiated|processed|credited|refunded|issued|approved)\b|\bwe(?:'ve| have) (?:initiated|processed|issued|refunded)\b/.test(doc.lead.slice(0, 600));
    ctx.consent = ctx.consent || /\b(?:complaint|dispute|grievance|service request|ticket)\b[^.\n]{0,80}\b(?:submitted|raised|registered|received|created|logged)\b|\b(?:submitted|raised|registered|logged) (?:the |a |your )?(?:complaint|dispute|grievance|ticket)/.test(asks);
    // a person's own note from a personal mailbox (Gmail, Outlook, Yahoo…: a forward, a reply to the bank, a complaint)
    // reports no money, order or promise: the bank's or the shop's own mail is the record of any it mentions. A receipt
    // or a due a society, tutor or landlord sends from Gmail is read like any other. (Insurance's own readers still read
    // either, as they always have: an agent may write from a personal mailbox.)
    ctx.person = personalNote(doc);
    var events = [];
    var steps = !ctx.otp && !ctx.verify ? (insuranceSteps(doc, ctx) || (ctx.person ? null : (paymentAdvice(doc, ctx) || investSteps(doc, ctx) || appPaySteps(doc, ctx) || bankSteps(doc, ctx)))) : null;
    if (steps) {
      events = steps.events.slice();
      if (steps.failedOk) ctx.failed = false;
      // the money it moved in (a settled claim, a surrender, a loan against the policy): the account's credit
      if (steps.movesIn) moves(doc, ctx).filter(function (e) { return e.type === 'move' && e.dir === 'in'; }).slice(0, 1).forEach(function (mv0) { if (!mv0.purpose || mv0.purpose === 'other') mv0.purpose = steps.movesIn; events.push(mv0); });
      if (steps.keepExpects) events = events.concat(expects(doc, ctx).filter(function (e) { return e.dir === 'in'; }));
      // the balance the same mail prints for what it moved ("Updated Wallet Balance: ₹341.00"). A detector that answers
      // for the mail returns its own events whole, so every balance line in one was lost here unless the detector
      // happened to add it itself: only appPaySteps did. The instrument must be named, and balances() already refuses a
      // card's limit, an "outstanding", an amount paid out of a balance, and a biller's or prepaid sender's own figure.
      var mvS = events.filter(function (e) { return e.type === 'move'; })[0];
      if (mvS && mvS.via && (mvS.via.kind === 'wallet' || mvS.via.last4) && !events.some(function (e) { return e.type === 'balance'; })) events = events.concat(balances(doc, mvS));
    }
    if (!steps && !ctx.otp && !ctx.verify && !ctx.consent && ctx.person) { var plP = policies(doc, ctx); ctx.policy = plP.length > 0; events = events.concat(plP); }
    if (!steps && !ctx.otp && !ctx.verify && !ctx.consent && !ctx.person) {
      var st = statements(doc, ctx); ctx.stmt = st.length > 0;
      var ip = ipos(doc, ctx); ctx.ipo = ip.length > 0;
      var dv = dividends(doc, ctx);
      var dp = deposits(doc, ctx);
      var pl = policies(doc, ctx); ctx.policy = pl.length > 0;
      var od = orders(doc, ctx); ctx.order = od.length > 0;
      var tr = trades(doc, ctx);
      var fd = funds(doc, ctx);
      var md = (ctx.policy && pl[0].action === 'due' && !/e-?mandate|standing instruction|due for debit|auto-?debit/.test(doc.head)) || dv.length || ip.length ? [] : mandates(doc, ctx);
      // a subscription's receipt (charged now) wins over its "next payment" line read as an auto-debit to come
      var md0n = md.length > 0, sb = subscriptions(doc, ctx);
      if (sb.length && sb[0].action === 'done') md = md.filter(function (x) { return !(x.action === 'upcoming' && (!x.amt || !sb[0].amt || Math.abs(x.amt - sb[0].amt) < 1)); });
      ctx.mandate = md.length > 0;
      var noMove = st.length || ip.length || dv.length || (dp.length && dp[0].action === 'facts' && !ctx.factsWithMove) || (od.length && !/\bpaid\b|payment (?:of|was)|wallet/.test(s)) || tr.length || fd.length || (pl.length && pl[0].action !== 'paid') || (md.length && md[0].action !== 'done' && !/\b(?:has been|was)\s+debited\b/.test(doc.lead.slice(0, 400)));
      // a card delivered, activated or its limit changed lists limits, not payments
      var ac0 = accounts(doc, ctx);
      if (ac0.length && /^(?:activated|limit|delivered)$/.test(ac0[0].step) && !/\b(?:has been|was|is)\s+(?:debited|credited|spent|charged)\b|\bdebited from\b/.test(doc.lead.replace(FUTURE_VERB, ''))) noMove = true;
      var mv = noMove ? [] : moves(doc, ctx);
      // the money a fund house's own confirmation moved, and a dividend's credit (fundMoney)
      var fm = fd.length || dv.length ? fundMoney(doc, ctx, fd, dv) : [];
      if (fm.length) { mv = mv.concat(fm.filter(function (e) { return e.type === 'move'; })); events = events.concat(fm.filter(function (e) { return e.type !== 'move'; })); }
      if (sb.length && sb[0].action !== 'done' && md0n) sb = [];
      // a receipt that prints how it was paid is the movement (an app store, a gateway, a SaaS, a bill-pay app); never
      // in a mail that sells something or reports (an offer, a credit report), as moves() never reads one either
      // (a shop's shipping mail for an order it says was prepaid, "Payment mode: Prepaid", is that order paid: the purchase
      // where no confirmation of it came; the engine folds the two when both did)
      // (the label and its value run into the next words when the mail's table is flattened: "Mode of Payment Prepaid Please note")
      ctx.prepaidShip = !!od.length && od[0].status === 'shipped' && (/^\s*prepaid\s*$/i.test((kv(doc, /^(?:payment (?:mode|method|type)|mode of payment)$/) || {}).value || '') ||
        /\b(?:mode of payment|payment (?:mode|method|type))\s*[:|\-]?\s*prepaid\b/i.test(doc.flat.slice(doc.bodyAt, doc.bodyAt + 6000)) ||
        // (a dispatch mail that prints what paid for it, "Paid by Amex: Rs.1,578.10": paid, whatever its step)
        kvAll(doc, /^paid (?:by|via|with|using) [a-z][a-z .]{1,40}$/).some(function (p0) { return p0.amt > 0 && !/cash on delivery|\bcod\b|points|coins|reward|voucher|gift ?card/.test(p0.key); }));
      if (!mv.length && !ctx.promo && !st.length && !ip.length && !dv.length && !tr.length && !fd.length && !(pl.length && pl[0].action !== 'paid') && !(od.length && !/^(?:placed|delivered)$/.test(od[0].status || '') && !/\bpaid\b|payment|receipt|invoice/.test(s) && !ctx.prepaidShip) && !(od.length && ctx.shopBill)) mv = receipts(doc, ctx);
      // (a courier's mail about a shop's prepaid order: the money went to the shop the order names, never the courier)
      if (ctx.prepaidShip && od.length && od[0].shop) mv.forEach(function (m0) { if (m0.type === 'move' && m0.dir === 'out') m0.party = od[0].shop; });
      md = md.concat(sb); ctx.mandate = md.length > 0;
      // a shop's or gateway's mail read as a movement: its receipt lines say how it was paid and to whom
      if (mv.length && mv[0].type === 'move' && !(doc.inst && /^(?:bank|card|broker|rta|insurer)$/.test(doc.inst.kind))) {
        var rc = receipts(doc, ctx)[0], m0 = mv[0];
        if (rc && rc.amt === m0.amt && rc.dir === m0.dir) {
          if ((m0.via.kind === 'other' || (m0.via.kind === 'account' && !m0.via.last4)) && rc.via.kind !== 'other') m0.via = rc.via;
          if (rc.party && (!m0.party || (doc.inst && doc.inst.kind === 'gateway'))) m0.party = rc.party;
          if (rc.ref && (!m0.ref || (doc.inst && doc.inst.kind === 'gateway'))) m0.ref = rc.ref;
          if (m0.purpose === 'billpay' && rc.purpose === 'purchase') m0.purpose = 'purchase';
          if (!m0.purpose && rc.purpose && doc.inst && doc.inst.kind === 'gateway') m0.purpose = rc.purpose;
          if (rc.mode && !m0.mode) m0.mode = rc.mode;
          if (rc.time && !m0.time && rc.date === m0.date) m0.time = rc.time;
        }
      }
      // an auto-debit done is the movement's: same day, same account
      md.forEach(function (x) { if (x.action === 'done' && mv.length && mv[0].amt === x.amt) { if (!x.date) x.date = mv[0].date; if (!x.via) x.via = mv[0].via; } });
      // an insurer's receipt is the policy's; the money's own movement is the bank's alert
      if (pl.length && pl[0].action === 'paid' && doc.inst && doc.inst.kind === 'insurer') mv = [];
      if (doc.inst && doc.inst.kind === 'tax') mv.forEach(function (m0) { if (m0.type !== 'move') return; if (m0.dir === 'out') m0.purpose = 'tax'; else if (/refund/.test(doc.head)) m0.purpose = 'refund'; });
      if (!od.length && /swiggy|zomato|eazydiner|dineout/.test(doc.domain) && (/dineout|bill payment at/i.test(doc.subject) || /\byou paid\s+(?:rs\.?|₹|inr)\s?[\d,.]+\s+at\s+[A-Z][a-z]/.test(doc.flat.slice(doc.bodyAt, doc.bodyAt + 300))))
        mv.forEach(function (m0) { if (m0.type === 'move' && m0.dir === 'out') { m0.party = /dineout/i.test(doc.subject) ? 'Swiggy Dineout' : (shopGuess(doc) || {}).name || m0.party; m0.purpose = 'purchase'; } });
      // a cashback the subject names ("Here's ₹25 cashback") is that figure, not a payment the body mentions
      var cbS = /(?:₹|rs\.?|inr)\s?(\d[\d,]*(?:\.\d+)?)\s+cashback|cashback of\s+(?:₹|rs\.?|inr)\s?(\d[\d,]*(?:\.\d+)?)/i.exec(doc.subject.replace(/[^!|]*\bon your next\b[^!|]*/gi, '').replace(/\b(?:get|up ?to|earn|win|flat)\s+(?:up ?to\s+)?(?:₹|rs\.?|inr)\s?[\d,.]+[^!|]*/gi, function (c) { return /credited|added|here|received/i.test(c) ? c : ''; }));
      if (cbS) mv.forEach(function (m0) { if (m0.type === 'move' && m0.purpose === 'cashback') m0.amt = num(cbS[1] || cbS[2]); });
      if (od.length && !/\bbill\b|recharge/.test(s)) mv.forEach(function (m0) { if (m0.type === 'move' && m0.dir === 'out' && m0.purpose === 'billpay') m0.purpose = 'purchase'; });
      if (od.length && !mv.some(function (m0) { return m0.type === 'move' && m0.dir === 'in'; })) {
        var rs0 = refundSaid(doc);
        var ro = od.filter(function (o) { return o.status === 'refunded' || o.status === 'cancelled' || o.status === 'returned'; })[0];
        if (rs0 && ro) {
          var rcur = rs0.cur || '';
          var ramt = rs0.amt || (kv(doc, /^refund(?:ed)? amount$|^amount refunded$/) || {}).amt || 0;
          // a refund in another currency ("Refund: | -$37.99")
          if (!(ramt > 0)) { var fx = /\brefund(?:ed)?(?: amount)?[\s:|]*-?\s*(\$|usd|€|eur|£|gbp)\s*(\d[\d,]*(?:\.\d+)?)/i.exec(doc.flat); if (fx) { ramt = num(fx[2]); rcur = /\$|usd/i.test(fx[1]) ? 'USD' : /€|eur/i.test(fx[1]) ? 'EUR' : 'GBP'; } }
          if (!(ramt > 0) && ro.total > 0 && uniq(amts(doc).filter(function (t) { return inBody(doc, t); }).map(function (t) { return t.v; })).length <= 1) ramt = ro.total;
          if (ramt > 0) {
            var rsen = lc(rs0.text);
            var rmask = doc.toks.filter(function (t) { return t.t === 'MASK' && t.s >= rs0.s && t.e <= rs0.e; })[0];
            // ("…has been credited.\nCredited to: Example Bank account ending 1234")
            if (!rmask && /^\s*(?:credited|refunded) to\b|^\s*refund(?:ed)? (?:to|mode|via)\b/i.test(doc.flat.slice(rs0.e, rs0.e + 150))) rmask = doc.toks.filter(function (t) { return t.t === 'MASK' && t.s >= rs0.e && t.e <= rs0.e + 150; })[0];
            var rw = /(amazon pay|paytm|phonepe|mobikwik|flipkart|myntra|swiggy|zomato)/i.exec(rs0.text);
            var rvia = rmask ? viaFor(doc, rmask, 'in') : /balance|wallet/.test(rsen) ? { kind: 'wallet', inst: rw ? capWords(rw[1]) : od[0].shop } : /\bupi\b/.test(rsen) ? { kind: 'upi' } : { kind: 'other' };
            if (rvia.kind === 'other' && /payment method[^\n]{0,20}(?:credit|debit)?\s*\/?\s*(?:debit )?cards?/i.test(doc.flat)) rvia = { kind: 'card' };
            // (the card the receipt names by its digits, "Card: Diners Club ending 3311")
            if (rvia.kind === 'other' || (rvia.kind === 'card' && !rvia.last4)) { var rci = instrumentIn(doc); if (rci && rci.kind === 'card' && rci.last4) { rvia = { kind: 'card', last4: rci.last4 }; if (rci.inst) rvia.inst = rci.inst; } }
            var rdt = doc.toks.filter(function (t) { return t.t === 'DATE' && t.s >= rs0.s && t.e <= rs0.e && !t.rel && !/(?:dated|placed on|ordered on|order date|purchased on|booked on)\s*:?\s*$/i.test(doc.flat.slice(Math.max(0, t.s - 20), t.s)); })[0];
            var rm = { type: 'move', dir: 'in', amt: ramt, date: rdt ? rdt.v : doc.ref, via: rvia, purpose: 'refund', party: od[0].shop };
            if (rcur) rm.cur = rcur;
            var rref = kv(doc, /^refund reference(?: no\.?| number)?$|^arn(?: number)?$|^reference no\.?$|^rrn(?: no\.?)?$|^utr(?: no\.?)?$/); if (rref) { var rv0 = /(?=[A-Za-z0-9\-]*\d)[A-Za-z0-9][A-Za-z0-9\-]{5,40}/.exec(rref.value); if (rv0) rm.ref = rv0[0]; }
            if (!rm.ref) { var arnM = /\bARN(?: (?:no\.?|number))?[ \t]*[:\-]?[ \t]*(?=[A-Z]*\d)([A-Z0-9]{10,30})\b/i.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 3000)); if (arnM) rm.ref = arnM[1]; }
            mv.push(rm);
          }
        }
      }
      if (/cashback/.test(s + ' ' + doc.lead.slice(0, 300)) && /\b(?:as|in|into)\s+(?:\w+\s+){0,2}(?:reward\s+)?(?:points|coins|credits|supercoins)\b/.test(doc.lead.slice(0, 500))) mv = mv.filter(function (m0) { return !(m0.type === 'move' && m0.purpose === 'cashback'); });
      // money a person sent you through an app: the app's own mail, said in its subject or first sentence (never a bank's
      // debit alert, whose safety tip may mention a request someone "sent you")
      var firstSen = lc(s + ' ' + sentencesOf(doc.flat.slice(doc.bodyAt, doc.bodyAt + 600)).slice(0, 2).map(function (x) { return x.text; }).join(' '));
      if (doc.inst && /^(?:app|wallet)$/.test(doc.inst.kind) && !/\bdebited\b/.test(doc.head) && /\bsent you\b|\byou(?:'ve| have)? received (?:rs\.?|₹|inr|#)|\breceived (?:rs\.?|₹|inr|#)\s?[\d#,.]+ from\b/.test(firstSen)) mv.forEach(function (m0) { if (m0.type === 'move' && m0.dir === 'out' && !/refund|cashback/.test(m0.purpose || '')) { m0.dir = 'in'; m0.purpose = 'transfer'; } });
      if (doc.inst && /^(?:app|wallet)$/.test(doc.inst.kind) && /credit card bill|card bill payment/.test(doc.head)) mv.forEach(function (m0) { if (m0.type === 'move' && m0.dir === 'out' && /purchase|billpay|^$/.test(m0.purpose || '')) m0.purpose = 'cardpay'; });
      // a shop's or app store's receipt or invoice that prints its order id is that order too (a bill paid never is: rule 2)
      if (!od.length && /\b(?:receipt|invoice)\b/.test(s) && !/\bbill\b|recharge|premium|policy/.test(s) && !billerSender(doc) && !(doc.inst && /^(?:bank|card|insurer|broker|rta|gateway|wallet|tax|amc|lender)$/.test(doc.inst.kind))) {
        var oidK = kv(doc, /^order (?:id|number|no\.?)$/), oidV = oidK ? /^[A-Z0-9][A-Z0-9\-]{5,30}/i.exec(trim(oidK.value)) : null;
        if (!oidV) { var oidM = /\border id\s*[:|]?\s*([A-Z0-9][A-Z0-9\-]{5,30})(?![A-Za-z0-9])/i.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 2000)); if (oidM) oidV = [oidM[1]]; }
        // (an app store's order id can be all capitals: "MSABCDEFGH")
        if (oidV && /[A-Z]/i.test(oidV[0]) && (/\d/.test(oidV[0]) || /^[A-Z]{8,}$/.test(oidV[0]))) {
          var oev = { type: 'order', shop: (mv[0] && mv[0].party) || senderBrand(doc), order: oidV[0].toUpperCase(), status: 'placed' };
          var otot = kv(doc, /^(?:total|order total|grand total|total amount)$/); if (otot && otot.amt > 0) oev.total = otot.amt; else if (mv[0] && mv[0].dir === 'out') oev.total = mv[0].amt;
          // (never a subscription's renewal, which is its mandate's: rule 6; never a free item, priced at nothing; a receipt
          // cut short before its prices is still the order)
          if ((oev.total > 0 || mv.length || !amts(doc).some(function (t) { return inBody(doc, t); })) && !sb.length && !/\brenews?\b|\(monthly\)|\(yearly\)|\(annual\)/i.test(doc.flat.slice(doc.bodyAt, doc.bodyAt + 2500))) od.push(oev);
        }
      }
      // a bill or recharge paid: its own reference (BBPS, the operator's), never the app's order number (rule 10)
      var bref = billRef(doc);
      if (bref) mv.forEach(function (m0) { if (m0.type === 'move' && m0.dir === 'out' && /^(?:billpay|topup)$/.test(m0.purpose || '') && (!m0.ref || /^\d{3}-\d{7}-\d{7}$/.test(m0.ref) || !/\d{4}/.test(m0.ref))) m0.ref = bref; });
      // an order the mail paid or refunded carries that sum as its total (rule: "total = the total paid"; a refunded
      // order's, the refund)
      od.forEach(function (o) {
        if (o.total != null) return;
        var pay = mv.filter(function (m0) { return m0.type === 'move' && m0.dir === (/^(?:refunded|returned|cancelled)$/.test(o.status) ? 'in' : 'out'); })[0];
        if (pay && (pay.dir === 'out' || pay.purpose === 'refund')) o.total = pay.amt;
      });
      ctx.paidNow = mv.length > 0;
      // a subscription's receipt names what it charged where the move does
      sb.forEach(function (x) { if (x.action === 'done' && !(x.amt > 0) && mv.length && mv[0].dir === 'out') x.amt = mv[0].amt; });
      // …and on the day it charged
      md.forEach(function (x) { if (x.action === 'done' && !x.date && mv.length && mv[0].type === 'move' && Math.abs((x.amt || 0) - mv[0].amt) < 0.011) x.date = mv[0].date; });
      // a standing instruction or auto-debit the bank carried out is the money only, not also the mandate (rule 7)
      // (a NACH debit that names its UMRN keeps its mandate: the screens follow the mandate by that number)
      if (doc.inst && /^(?:bank|card)$/.test(doc.inst.kind) && /standing instruction|\bsi execution\b/.test(doc.head) && mv.some(function (m0) { return m0.type === 'move'; })) {
        md = md.filter(function (x) { return !(x.action === 'done' && (!x.amt || mv.some(function (m0) { return m0.type === 'move' && Math.abs(m0.amt - x.amt) < 0.011; }))); });
        // (its beneficiary is who was paid: "for beneficiary EXAMPLE PERSON a/c XX1995")
        var benM = /\bfor beneficiary\s+([A-Za-z][A-Za-z .&']{2,60}?)\s+(?:a\/c|account)\b/i.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 800));
        if (benM) mv.forEach(function (m0) { if (m0.type === 'move' && m0.dir === 'out' && !m0.party) m0.party = trim(benM[1]); });
      }
      events = events.concat(st, ip, dv, dp, pl, od, tr, fd, mv, md);
      if (mv.length && (holdsMoney(doc) || mv[0].via.kind === 'wallet' || mv[0].via.last4)) events = events.concat(balances(doc, mv[0]));
      else if (/\bbalance\b/.test(s) && !st.length && !/\bupdate\b|statement|limit/.test(s)) events = events.concat(balances(doc, null));
      if (!st.length) events = events.concat(dues(doc, ctx));
      // (a tax form's acknowledgement promises no money: its principal is the deposit's)
      var ex0 = dp.length && dp[0].action === 'facts' ? [] : expects(doc, ctx);
      od.forEach(function (o) { if (o.total == null && /^(?:refunded|returned|cancelled)$/.test(o.status)) { var er = ex0.filter(function (e) { return e.type === 'expect' && e.what === 'refund' && e.amt > 0; })[0]; if (er) o.total = er.amt; } });
      // (never a figure from a fee table, "Dues from Rs.201 to Rs.500 … Rs.75 per month"; a refund's "will be
      // credited" is that refund's promise, not a second one)
      ex0 = ex0.filter(function (e) {
        if (e.type !== 'expect') return true;
        var tk = amts(doc).filter(function (t) { return Math.abs(t.v - e.amt) < 0.011; });
        if (tk.length && tk.every(function (t) { return /\bdues? (?:from|up ?to|more than)\b|\bfrom\s*$|\bto\s*$|late fee/i.test(doc.flat.slice(Math.max(0, t.s - 30), t.s)) || /^\s*(?:per|a|every)\s+(?:month|day|week)\b/i.test(doc.flat.slice(t.e, t.e + 15)); })) return false;
        return !(e.what === 'credit' && ex0.some(function (x) { return x !== e && x.what === 'refund' && Math.abs(x.amt - e.amt) < 0.011; }));
      });
      var ex = ex0.filter(function (e) {
        // a promise of what this mail says already happened is that happening
        // (and a fund's redemption to be paid, fundMoney's promise of it, is the only promise of that sum: never also a debit)
        return !events.some(function (x) { return ((x.type === 'move' || x.type === 'ipo' || x.type === 'mandate' || x.type === 'due') || (x.type === 'expect' && x.what === 'payout')) && x.amt === e.amt; });
      });
      // a refund the shop says has already reached you ("processed on Jun 11 and should reflect in your account by
      // now", "has been credited to your card") is money back, not a promise
      if (/should (?:have )?reflect(?:ed)? in your (?:\w+ )?(?:account|card|bank|source)[^.\n]{0,20}by now|refund (?:of [^.\n]{0,40})?has been credited to your|has been refunded to your/.test(doc.head)) {
        ex = ex.map(function (e) {
          if (e.type !== 'expect' || e.dir !== 'in' || e.what !== 'refund' || events.some(function (x) { return x.type === 'move' && x.amt === e.amt; })) return e;
          var at = amts(doc).filter(function (t) { return Math.abs(t.v - e.amt) < 0.011; })[0];
          var via = at ? viaFor(doc, at, 'in') : { kind: 'other' };
          var d0 = at ? dateFor(doc, at) : { date: doc.ref };
          var m0 = { type: 'move', dir: 'in', amt: e.amt, date: d0.date || doc.ref, via: via, purpose: 'refund' };
          if (e.party) m0.party = e.party;
          return m0;
        });
      }
      events = events.concat(ex);
      events = events.concat(accounts(doc, ctx));
      // a deposit opened by an alert's debit: the debit's amount is the deposit's
      if (dp.length && mv.length) dp.forEach(function (d) { if (!d.amt) d.amt = mv[0].amt; });
    }
    // a letter about an FD's renewal or a survey on opening one is not the FD's step
    // (a shop's order with its own item lines is no letter's aside: "Your order was delivered … Order Items")
    if (ctx.letter) events = events.filter(function (e) { return e.type === 'move' || e.type === 'balance' || (e.type === 'order' && e.lines && e.lines.length > 0); });
    /* GUARDRAIL a bank's or shop's reply in a thread about a complaint ("Re: … Wrongful FASTag debit of Rs 100", "We write
       with reference to your query"): it moves no money of its own, the debit it is about is the alert's; only a reply
       that says money came back ("has been credited / refunded / reversed") keeps that move */
    if (ctx.letter && /^\s*(?:re|fwd?|aw)\s*:/i.test(doc.subject) && !/\b(?:has been|have been|was|is)\s+(?:successfully\s+)?(?:credited|refunded|reversed)\b/i.test(doc.lead.slice(0, 700)))
      events = events.filter(function (e) { return e.type === 'balance'; });
    if (ctx.nudge) events = events.filter(function (e) { return e.type === 'account'; });
    // a premium paid is the policy's step AND the money (LABELING.md rule 1): a receipt, a renewal or a policy bought
    // with its premium printed. (The engine keeps the insurer's record; a bank's alert of the same premium is the same
    // payment: build() folds a confirmation into it.) An insurer's premium reminder is the policy's due alone, never
    // also an auto-debit to come (rule 12).
    if (!ctx.failed) {
      var pSaysPaid = /acknowledge (?:the )?receipt of your (?:payment|premium)/.test(doc.head) || /\bpremium paid\s*[:|]\s*(?:₹|rs\.?|inr)\s?[1-9]/.test(doc.low.slice(doc.bodyAt, doc.bodyAt + 2500)) || /payment (?:success|successful|received|acknowledg)|acknowledge your payment|(?:we have |we've )?received (?:your )?(?:premium|payment)|payment (?:of|for) [^.\n]{0,40}(?:is|was|has been) (?:successful|received)/.test(doc.head);
      var pPaid = events.filter(function (e) { return e.type === 'policy' && (e.action === 'paid' || (/^(?:renewed|issued)$/.test(e.action || '') && pSaysPaid)) && e.premium > 0 && !e.unsure; })[0];
      // (never a notice, a copy, an endorsement, a year's consolidated receipt for tax, or a premium someone else paid)
      // (the vetoes yield to a sentence that says this payment was received; a premium paid by a person named is theirs)
      var paidByOther = /\bpaid by (?:mr\.? |ms\.? |mrs\.? )?([A-Z][a-z]+(?: [A-Z][a-z]+)+)\b/.exec(doc.subject + '\n' + doc.flat.slice(doc.bodyAt, doc.bodyAt + 700));
      if (paidByOther && /\b(?:bank|card|credit|debit|auto|upi|net|cheque|cash|wallet|pay)\b/i.test(paidByOther[1])) paidByOther = null;
      if (paidByOther || (!pSaysPaid && /will be (?:auto-?)?(?:renewed|debited|charged)|auto-?renew|as requested|copy of (?:your )?policy|endorsement|\bfy\b|financial year|certificate|consolidated/.test(doc.head))) pPaid = null;
      // (the mail must say a payment was made: a receipt, "payment success", "we have received your premium"; a policy's
      // "Premium amount" line on a thank-you or a reminder is the premium it carries, not money paid now)
      var paidSaid = /premium receipt|payment (?:success|successful|received|acknowledg)|acknowledge your payment|(?:we have |we've )?received (?:your )?(?:premium|payment)|amount paid|payment (?:of|for) [^.\n]{0,40}(?:is|was|has been) (?:successful|received)|thank you for (?:buying|your purchase|the payment)/.test(doc.head) || pSaysPaid;
      if (pPaid && paidSaid && !events.some(function (e) { return e.type === 'move'; })) {
        var pdk = kv(doc, /^(?:payment date|date of payment|transaction date|paid on|receipt date|date)$/);
        // ("We have received premium of ₹ 1,04,500.00 for your policy C200000001 on 23-Dec-2026": that day)
        // ("Your premium payment of INR 50000.00 for the given policy is successful as on 23/02/2026 at 04:12:37 AM IST")
        if (!(pdk && pdk.date)) { var rcvM = /(?:have received|receipt of your (?:payment|premium)|received (?:your )?(?:premium|payment)|\bpayment\b(?:[^\n.]|\.(?=\d)){0,100}?\b(?:is|was|has been)\s+(?:successful(?:ly (?:received|processed))?|received|processed)\b(?:\s+as)?)[^\n]{0,140}?\bon\s+/i.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 1500)); var rcvD = rcvM ? near(doc, 'DATE', doc.bodyAt + rcvM.index + rcvM[0].length, 0, 4) : null; if (rcvD) pdk = { date: rcvD.v, s: rcvD.s }; }
        // (paid through a broker or aggregator, the party is who charged you: rule 5)
        var viaBroker = /policybazaar|coverfox|insurancedekho|renewbuy|turtlemint|ditto|beshak/.test(doc.domain);
        // (what was paid: the total with its tax, where the receipt prints one)
        var ptot = kv(doc, /^(?:total premium(?: paid)?|amount paid|total amount(?: paid)?|premium paid|total)(?:\s*\((?:rs\.?|inr|₹)\))?$/);
        var taxRow = kv(doc, /\b(?:gst|igst|cgst|sgst|tax)\b/);
        var pm = { type: 'move', dir: 'out', amt: ptot && taxRow && ptot.amt > pPaid.premium && ptot.amt < pPaid.premium * 1.5 ? ptot.amt : pPaid.premium, date: (pdk && pdk.date) || doc.ref, via: { kind: 'other' }, party: viaBroker ? senderBrand(doc) : pPaid.insurer, purpose: 'premium' };
        var ptm = pdk ? near(doc, 'TIME', pdk.s, 0, 80) : null; if (ptm) pm.time = ptm.v;
        // (an insurer labels its own receipt "Payment Ref" or "Payment ID" as often as "Transaction ID", and a
        //  gateway's id carries an underscore, "pay_EXAMPLE0099887")
        var prf = kv(doc, /^(?:(?:transaction|payment) (?:id|ref(?:erence)?(?: no\.?)?)|reference (?:no\.?|number|id)|receipt (?:no\.?|number))$/); if (prf) { var prv = /[A-Za-z0-9][A-Za-z0-9_\-]{5,40}/.exec(prf.value); if (prv) pm.ref = prv[0]; }
        // ("Transaction ID:HL0000…", the number glued to its label)
        if (!pm.ref) { var prg = /\b(?:transaction|payment)\s*(?:id|ref(?:erence)?(?:\s*no\.?)?)\s*[:#\-]\s*([A-Za-z0-9][A-Za-z0-9_\-]{7,40})\b/i.exec(doc.flat.slice(doc.bodyAt, doc.bodyAt + 3000)); if (prg && /\d{4,}/.test(prg[1])) pm.ref = prg[1]; }
        events.push(pm);
      }
      // (an insurer's premium reminder is the policy's due alone, rule 12: an insurer kosh knows by name only, too)
      var fromName = /^\s*"?([^"<]{2,70}?)"?\s*</.exec((doc.msg && doc.msg.from) || ''), insName = !doc.inst && !!fromName && /\b(?:insurance|assurance)\b/i.test(fromName[1]) && !/\bbank\b/i.test(fromName[1]);
      if (events.some(function (e) { return e.type === 'policy' && e.action === 'due'; }) && (doc.inst ? !/^(?:bank|card)$/.test(doc.inst.kind) && (ctx.insurer || doc.inst.kind === 'insurer') : insName)) events = events.filter(function (e) { return !(e.type === 'mandate' && e.action === 'upcoming'); });
    }
    // what the mail says is held (a portfolio table, digital gold) and a loan's own figures: facts beside whatever else
    // it is (a statement's mail, a gold purchase, an EMI's debit)
    if (!ctx.failed && !ctx.otp && !ctx.verify && !ctx.nudge) events = events.concat(holdingFacts(doc, ctx), loanFacts(doc, ctx));
    if (ctx.failed) {
      // (a failed AutoPay's "Please pay by 20 Oct" is still that bill, due: the due stays)
      // (and the refund it promises for money already debited: "will be credited back within 3-5 working days")
      events = events.filter(function (e) { return e.type === 'order' || e.type === 'mandate' || e.type === 'account' || (e.type === 'due' && e.due && e.amt > 0) || (e.type === 'expect' && e.dir === 'in' && e.what === 'refund'); });
      events.forEach(function (e) { if (e.type === 'order' && e.status !== 'cancelled') e.status = 'declined'; if (e.type === 'mandate') e.action = 'failed'; });
    }
    // (a booking that failed to confirm, "But don't worry, we have processed a refund": the refund is promised, its sum
    // only where the mail prints one for it; rule 26)
    var fo = events.filter(function (e) { return e.type === 'order' && e.status === 'declined'; })[0], frm;
    if (fo && !events.some(function (e) { return e.type === 'expect'; }) && (frm = /\b(?:we have|we've|has been|have been)\s+(?:processed|initiated|issued)\s+(?:(?:a|the|your|full)\s+){0,2}refund\b[^.\n]{0,40}|\brefund\b[^.\n]{0,40}?\s+(?:has been|is|was)\s+(?:processed|initiated|issued)\b/.exec(doc.lead.slice(0, 700))) && !/\b(?:if|in case|should)\b[^.\n]{0,60}$/.test(doc.lead.slice(Math.max(0, frm.index - 60), frm.index))) {
      var fx0 = { type: 'expect', dir: 'in', what: 'refund' }, fra = /(?:₹|rs\.?|inr)\s*(\d[\d,]*(?:\.\d+)?)/i.exec(doc.flat.slice(doc.bodyAt + frm.index, doc.bodyAt + frm.index + frm[0].length));
      if (fra) fx0.amt = num(fra[1]);
      if (fo.order) fx0.order = fo.order;
      if (fo.shop) fx0.party = fo.shop;
      events.push(fx0);
    }
    walletPartOfOrder(doc, ctx, events);
    appBankAccount(doc, ctx, events);
    pensionSlipDay(doc, events);
    events.forEach(function (e) { if (e.type !== 'noise') { var q = quoteOf(doc, e); if (q) e.q = q; } });
    var main = events.filter(function (e) { return e.type !== 'account'; });
    if (!main.length || ctx.failed) events.unshift({ type: 'noise', reason: noiseReason(doc, ctx) });
    var out = { v: VERSION, kind: main.length && !ctx.failed ? main[0].type : 'noise', events: events, src: doc.src };
    // a parcel's step, read apart from the money (never one of the events, so no figure, score or template sees it)
    var pc = parcels(doc, ctx, events.filter(function (e) { return e.type === 'order'; }));
    if (pc.length) out.parcels = pc;
    // (the layout key, a skeleton of the whole mail hashed, is read by nothing on the phone: worked out, and kept, the
    // first time something reads it; it serialises as before)
    Object.defineProperty(out, 'layout', { enumerable: true, configurable: true,
      get: function () { var v = layoutOf(doc); Object.defineProperty(out, 'layout', { value: v, enumerable: true, writable: true, configurable: true }); return v; },
      set: function (v) { Object.defineProperty(out, 'layout', { value: v, enumerable: true, writable: true, configurable: true }); } });
    // for read(): the mail taken apart, and whether it sells something (neither is serialised)
    Object.defineProperty(out, '_doc', { value: doc, enumerable: false });
    Object.defineProperty(out, '_promo', { value: !!ctx.promo, enumerable: false });
    Object.defineProperty(out, '_ctx', { value: ctx, enumerable: false });
    return out;
  }

  /* ------------------------------------------------------------ 8. layouts: one string per template
     Every value becomes its type, words stay, case and spacing fold. Two mails from the same template (and the
     same sender) have the same layout whatever moved in them. */
  function skeletonOf(doc) {
    var out = [], at = 0;
    doc.toks.forEach(function (t) { out.push(doc.flat.slice(at, t.s)); out.push('⟨' + t.t + '⟩'); at = t.e; });
    out.push(doc.flat.slice(at));
    return lc(out.join('')).replace(/\d+/g, '#').replace(/[^\p{L}#⟨⟩\n ]+/gu, ' ').replace(/[ ]+/g, ' ').replace(/ ?\n ?/g, '\n').trim().slice(0, 4000);
  }
  function hash(s) { var h = 2166136261; for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return (h >>> 0).toString(36); }
  function layoutOf(doc) {
    var sk = skeletonOf(doc).split('\n').slice(0, 14).join('\n');
    return doc.domain.split('.').slice(-3).join('.') + '|' + hash(sk);
  }

  /* ------------------------------------------------------------ 9. the engine's record
     The main money event said the way engine.js parse() says it, so build() reads it as it reads the old reader's
     records. Payments and statements become records; every event rides along for the journey. */
  function toRecord(r, msg) {
    var mv = r.events.filter(function (e) { return e.type === 'move'; })[0];
    // (only a card's statement is the rules' "statement": an account's, a broker's or a registrar's is read from its PDF)
    var st = r.events.filter(function (e) { return e.type === 'statement' && !(e.via && e.via.kind && e.via.kind !== 'card'); })[0];
    var inst = E.institution ? E.institution(msg.from || '') : null;
    // (the day it came in India, as the rules' records have it: a mail at 1 a.m. IST is the day before in UTC)
    var base = { id: msg.id, sent: mailDay(msg.date), from: lc((/<([^>]+)>/.exec(msg.from || '') || [0, msg.from || ''])[1]).trim(), inst: inst ? inst.short : '', instKind: inst ? inst.kind : '',
                 subject: String(msg.subject || '').slice(0, 140), src: 'rule' };
    if (mv) {
      var instr = mv.via.kind === 'card' ? (mv.via.debit ? 'account' : 'card') : mv.via.kind === 'account' ? 'account' : mv.via.kind === 'wallet' ? 'wallet' : mv.via.kind === 'upi' ? 'upi' : 'other';
      var rec = Object.assign(base, { kind: 'txn', rule: 'reader-' + (mv.purpose || mv.dir), dir: mv.dir, amt: mv.amt, date: mv.date, time: mv.time || '', instr: instr,
        last4: mv.via.debit ? '' : (mv.via.last4 || ''), party: mv.party || '', vpa: mv.vpa || '', mode: mv.mode === 'WALLET' ? 'Wallet' : (mv.mode || ''), info: mv.nar || '', conf: mv.conf || 'medium' });
      if (mv.via.inst) { rec.inst = mv.via.inst; rec.instKind = mv.via.kind === 'wallet' ? 'wallet' : (instr === 'card' && inst && inst.kind === 'card' ? 'card' : (instr === 'other' ? (inst ? inst.kind : '') : 'bank')); }
      if (mv.via.debit) { rec.debit = true; rec.dcard = mv.via.last4 || ''; }
      if (mv.ref) rec.ref = mv.ref;
      var od0 = r.events.filter(function (e) { return e.type === 'order' && e.order; })[0];
      if (od0 && mv.dir === 'out') rec.orderId = String(od0.order).toUpperCase();
      var bal = r.events.filter(function (e) { return e.type === 'balance'; })[0];
      if (bal && (instr === 'account' || instr === 'wallet')) { rec.bal = bal.amt; rec.balAt = bal.asOn && bal.asOn < mv.date ? bal.asOn + 'T23:59:59' : mv.date + (mv.time ? 'T' + mv.time : ''); }
      if (mv.purpose === 'reversal') rec.rule = 'reader-reversed';
      return rec;
    }
    if (st && (st.total != null || st.due)) {
      return Object.assign(base, { kind: 'statement', rule: 'reader-statement', dir: 'out', amt: st.total || 0, min: st.min || 0, due: st.due || '', date: base.sent, time: '', instr: 'card',
        last4: (st.via && st.via.last4) || '', party: '', vpa: '', mode: '', conf: st.conf || 'medium', inst: (st.via && st.via.inst) || base.inst, instKind: inst && inst.kind === 'card' ? 'card' : 'bank' });
    }
    // something to pay by a date, or an auto-debit coming up: the rules' "bill"
    // (one in another currency is not that many rupees)
    var du = r.events.filter(function (e) { return e.type === 'due' && e.amt > 0 && !e.cur; })[0];
    var mu = r.events.filter(function (e) { return e.type === 'mandate' && e.action === 'upcoming' && e.amt > 0 && !e.cur; })[0];
    if (du || mu) {
      var b = du || mu;
      return Object.assign(base, { kind: 'bill', rule: du ? 'reader-due' : 'mandate-upcoming', dir: 'out', amt: b.amt, due: (du ? du.due : mu.date) || '', date: base.sent,
        party: (du ? du.payee : mu.party) || base.inst || '', instr: b.via && b.via.kind === 'card' ? 'card' : (b.via && b.via.kind === 'account' ? 'account' : ''), last4: (b.via && b.via.last4) || '',
        cat: '', sub: du && du.what === 'card' ? '' : '', conf: 'medium' });
    }
    // a policy the rules didn't read: its insurer, number, premium and cover
    var po = r.events.filter(function (e) { return e.type === 'policy' && (e.premium > 0 || e.policyNo); })[0];
    if (po) {
      // (a policy on a vehicle, its registration or its kind read: a motor policy, its cover the IDV)
      return Object.assign(base, { kind: 'policy', rule: 'reader-policy-' + po.action, insurer: po.insurer, ptype: po.vehicle || po.hint === 'two-wheeler' || po.hint === 'car' ? 'Motor' : '', premium: po.premium || 0, cover: po.cover || 0,
        last4: po.policyNo || '', due: po.due || '', date: base.sent, conf: 'medium' });
    }
    return null;
  }


  /* ------------------------------------------------------------ 10. learning from old mail
     Banks and shops send the same template thousands of times. A template is recognised by its frame: the subject
     and the first lines with every value blanked (amounts, dates, digits, card numbers, runs of capitalised names),
     compared as word sets with the sender's other templates, so a merchant's name or a changed footer doesn't make a
     new one. For each template kosh keeps a little book: how often it was each kind of mail, and for each field of
     its main event which part of the mail supplied it (a slot): "the amount under the label 'Amount Debited'", "the
     second amount in the body", "the date after it", "the name after 'at'". A slot is learnt from readings that are
     sure of themselves, and from teachers (a reading Claude made, a correction): one teacher's reading is worth three.
     When a mail of a known template comes in, its book fills what the reading left out, and reads the mail if the
     reading found nothing a template that always moves money should have. Every value is still taken from the
     mail: a slot is where to look, never what to find. */
  var CONST_FIELDS = /^(?:type|dir|via\.kind|via\.inst|via\.debit|mode|purpose|what|status|action|shop|insurer|cur|every)$/;
  var ID_FIELDS = /^(?:ref|order|policyNo|folio|no)$/;
  var NAME_FIELDS = /^(?:party|payee|company|scheme|plan)$/;
  var TEXT_CONSTS = /^(?:shop|insurer)$/;
  var OVERRIDE_FIELDS = /^(?:amt|total|min|premium|dir|purpose|what|status|action|date|due|via\.kind|via\.last4|via\.debit)$/;
  var LEARN_TYPES = /^(?:move|statement|due|balance|order|expect|mandate|policy|deposit|fund|ipo|dividend)$/;
  function frameOf(doc) {
    var out = [], at = 0;
    doc.toks.forEach(function (t) { out.push(doc.flat.slice(at, t.s)); out.push(' _' + t.t.toLowerCase() + '_ '); at = t.e; });
    out.push(doc.flat.slice(at));
    return out.join('').replace(/\b[A-Z][A-Z0-9&.'\-]+(?:\s+[A-Z][A-Z0-9&.'\-]+)*\b/g, ' _n_ ').replace(/\S*\d\S*/g, ' _d_ ')
      .toLowerCase().replace(/[^a-z_\n ]+/g, ' ').replace(/[ ]+/g, ' ');
  }
  function fingerprint(doc) {
    var f = frameOf(doc).split('\n');
    var subj = uniq(f[0].trim().split(' ').filter(Boolean));
    var w = f.slice(1).filter(function (l) { return l.replace(/_[a-z]+_/g, '').trim().length > 3; }).slice(0, 8).join(' ').split(/\s+/).filter(Boolean);
    var lead = [];
    for (var i = 0; i + 2 < w.length && lead.length < 60; i++) { var g = w[i] + ' ' + w[i + 1] + ' ' + w[i + 2]; if (lead.indexOf(g) < 0) lead.push(g); }
    return { dom: doc.domain.split('.').slice(-3).join('.'), subj: subj, lead: lead };
  }
  function jac(a, b) {
    if (!a.length && !b.length) return 1;
    var set = {}, n = 0;
    a.forEach(function (x) { set[x] = 1; });
    b.forEach(function (x) { if (set[x]) n++; });
    return n / (a.length + b.length - n || 1);
  }
  function bookFind(book, fp) {
    var best = null, bs = 0, ids = (book.byDom && book.byDom[fp.dom]) || [];
    ids.forEach(function (id) {
      var L = book.layouts[id];
      if (!L || jac(L.subj, fp.subj) < 0.7) return;
      var s = jac(L.lead, fp.lead);
      if (s > bs) { bs = s; best = L; }
    });
    return best && bs >= 0.5 ? best : null;
  }
  // which part of the mail holds a value: a label's value, the k-th token of its type, or the words after an anchor
  function slotFor(doc, field, val) {
    if (val == null || val === '') return null;
    var i, t;
    var kinds = field === 'via.last4' ? ['MASK'] : /^(?:date|due|by|on|start|mat|stmtDate|from|to)$/.test(field) ? ['DATE'] : field === 'time' ? ['TIME'] : typeof val === 'number' ? ['AMT'] : [];
    if (kinds.length) {
      var hits = doc.toks.filter(function (x) { return kinds.indexOf(x.t) >= 0 && (x.t === 'AMT' ? Math.abs(x.v - val) < 0.011 : x.t === 'MASK' ? (String(x.v).slice(-4) === String(val).slice(-4) || String(val).length < 4 && String(x.v).slice(-String(val).length) === String(val)) : x.v === val); });
      if (!hits.length) {
        // a number in a label's value that isn't money (units, shares, a rate)
        if (typeof val === 'number') { var pk = doc.pairs.filter(function (p) { var m = /-?\d[\d,]*(?:\.\d+)?/.exec(p.value); return m && Math.abs(num(m[0]) - val) < 0.0011; })[0]; if (pk) return 'K:' + pk.key; }
        return null;
      }
      // the one a label names, else one in the body, else the subject's
      t = hits.filter(function (x) { return x.pair; })[0] || hits.filter(function (x) { return inBody(doc, x); })[0] || hits[0];
      if (t.pair) return 'K:' + t.pair.key;
      var same = doc.toks.filter(function (x) { return x.t === t.t && inBody(doc, x) === inBody(doc, t); });
      return (inBody(doc, t) ? 'T:' : 'S:') + t.t + ':' + same.indexOf(t);
    }
    // a name or an identifier: where its text sits
    var v = lc(String(val)).trim();
    if (v.length < 2) return null;
    var p = doc.pairs.filter(function (q) { return lc(q.value).indexOf(v) === 0; })[0];
    if (p) return 'K:' + p.key;
    var at = doc.low.indexOf(v, doc.bodyAt);
    var inSubj = false;
    if (at < 0) { at = doc.low.indexOf(v); inSubj = at >= 0 && at < doc.bodyAt; }
    if (at < 0) return null;
    var before = doc.nlow.slice(Math.max(inSubj ? 0 : doc.bodyAt, at - 48), at).replace(/\d+/g, '#').replace(/[^a-z#/ ]+/g, ' ').trim().split(/\s+/).filter(Boolean);
    if (!before.length) return null;
    var anchor = before.slice(-2).join(' ');
    if (!/[a-z]{2}/.test(anchor)) anchor = before.slice(-3).join(' ');
    return (inSubj ? 'SA:' : 'A:') + anchor;
  }
  function resolveSlot(doc, field, slot) {
    var kind = slot.slice(0, slot.indexOf(':')), rest = slot.slice(slot.indexOf(':') + 1), m;
    if (kind === 'K') {
      var p = kv(doc, new RegExp('^' + rest.replace(/[.*+?^${}()|[\]\\\/]/g, '\\$&') + '$'));
      // a label with a word that changes from mail to mail ("your gas bill payment is" for "your electricity ..."):
      // the label most like it, if it is close enough
      if (!p) {
        var kw = rest.split(' '), bestP = null, bs = 0;
        doc.pairs.forEach(function (q) { var j = jac(kw, q.key.split(' ')); if (j > bs) { bs = j; bestP = q; } });
        if (bestP && bs >= 0.6 && kw.length >= 3) p = bestP;
      }
      if (!p) return null;
      if (field === 'via.last4') return p.mask || null;
      if (/^(?:date|due|by|on|start|mat|stmtDate|from|to)$/.test(field)) return p.date || null;
      if (field === 'time') { var tt = (p.toks || []).filter(function (x) { return x.t === 'TIME'; })[0]; return tt ? tt.v : null; }
      if (/^(?:amt|total|min|premium|cover|matAmt|units|nav|shares|qty|price|value|rate)$/.test(field)) {
        if (p.amt != null && p.amt !== 0) return p.amt;
        m = /-?\d[\d,]*(?:\.\d+)?/.exec(p.value); return m ? num(m[0]) : null;
      }
      if (ID_FIELDS.test(field)) { var idv = /[A-Za-z0-9][A-Za-z0-9_\-\/]{3,40}/.exec(p.value); return idv && /\d/.test(idv[0]) ? idv[0] : null; }
      return trim(p.value).slice(0, 80) || null;
    }
    if (kind === 'T' || kind === 'S') {
      var bits = rest.split(':'), list = doc.toks.filter(function (x) { return x.t === bits[0] && (kind === 'T') === inBody(doc, x); });
      var t = list[+bits[1]];
      return t ? t.v : null;
    }
    if (kind === 'A' || kind === 'SA') {
      var hay = kind === 'SA' ? doc.nlow.slice(0, doc.bodyAt) : doc.nlow.slice(doc.bodyAt);
      var base = kind === 'SA' ? 0 : doc.bodyAt;
      var re = new RegExp('(?:^|[^a-z0-9])' + rest.split(' ').map(function (w) { return w.split('#').map(function (x) { return x.replace(/[.*+?^${}()|[\]\\\/]/g, '\\$&'); }).join('\\d+'); }).join('[^a-z0-9]+') + '[^a-z0-9]*', 'i');
      var mm = re.exec(hay);
      if (!mm) return null;
      var from = base + mm.index + mm[0].length, after = doc.flat.slice(from, from + 90);
      if (ID_FIELDS.test(field)) { var id = /^\s*[:#\-]?\s*([A-Za-z0-9][A-Za-z0-9_\-\/]{3,40})/.exec(after); return id && /\d/.test(id[1]) ? id[1] : null; }
      return cleanParty(after) || null;
    }
    return null;
  }
  // an event's fields, flattened: { amt: 540, 'via.last4': '1234', ... }
  function flat(ev) {
    var out = {};
    Object.keys(ev).forEach(function (k) {
      var v = ev[k];
      if (k === 'ev' || k === 'conf' || k === 'learned' || k === 'unsure' || k === 'items' || k === 'doubt' || k === 'nar') return;
      if (v && typeof v === 'object' && !Array.isArray(v)) Object.keys(v).forEach(function (k2) { out[k + '.' + k2] = v[k2]; });
      else if (!Array.isArray(v)) out[k] = v;
    });
    return out;
  }
  function setPath(ev, k, v) {
    var i = k.indexOf('.');
    if (i < 0) { ev[k] = v; return; }
    var a = k.slice(0, i), b = k.slice(i + 1);
    ev[a] = ev[a] || {};
    ev[a][b] = v;
  }
  function getPath(ev, k) { var i = k.indexOf('.'); return i < 0 ? ev[k] : (ev[k.slice(0, i)] || {})[k.slice(i + 1)]; }
  // what a template teaches: its kind, and for each event type its constant fields and where each other field sits
  function learnInto(book, fp, doc, events, weight, L) {
    var main = events.filter(function (e) { return e.type !== 'account' && e.type !== 'noise'; });
    if (!L) {
      var id = fp.dom + '|' + hash(fp.subj.slice().sort().join(' ') + '|' + fp.lead.slice(0, 12).join('|'));
      L = book.layouts[id] = book.layouts[id] || { id: id, dom: fp.dom, subj: fp.subj, lead: fp.lead, n: 0, kinds: {}, types: {} };
      (book.byDom[fp.dom] = book.byDom[fp.dom] || []);
      if (book.byDom[fp.dom].indexOf(id) < 0) book.byDom[fp.dom].push(id);
    }
    // past a few hundred readings every count halves: the book follows a sender that changes its mail, and stays small
    if (L.n > 400) {
      L.n /= 2;
      Object.keys(L.kinds).forEach(function (k) { L.kinds[k] /= 2; });
      Object.keys(L.types).forEach(function (ty) {
        var T = L.types[ty]; T.n /= 2;
        [T.consts, T.slots].forEach(function (g) { Object.keys(g).forEach(function (f) { Object.keys(g[f]).forEach(function (v) { g[f][v] /= 2; if (g[f][v] < 0.5) delete g[f][v]; }); }); });
      });
    }
    L.n += weight;
    L.seen = doc.ref;
    var kind = main.length ? main[0].type : 'noise';
    L.kinds[kind] = (L.kinds[kind] || 0) + weight;
    // a teacher's word (Claude's reading, the person's correction) is kept apart as well, and never halved: what it
    // taught overrides the reader's own reading of the template's next mail
    var teacher = weight >= 3;
    if (teacher) { L.tkinds = L.tkinds || {}; L.tkinds[kind] = (L.tkinds[kind] || 0) + weight; L.tn = (L.tn || 0) + weight; }
    main.forEach(function (e) {
      if (!LEARN_TYPES.test(e.type) || e.learned) return;
      // what the person said this template isn't: only a teacher's word (weight 3) can say it is again
      if (L.no && L.no[e.type] > 0) { if (weight < 3) return; L.no[e.type] -= weight; if (L.no[e.type] <= 0) delete L.no[e.type]; }
      var T = L.types[e.type] = L.types[e.type] || { n: 0, consts: {}, slots: {} };
      T.n += weight;
      if (teacher) { T.tn = (T.tn || 0) + weight; T.tconsts = T.tconsts || {}; T.tslots = T.tslots || {}; }
      var f = flat(e);
      Object.keys(f).forEach(function (k) {
        var v = f[k];
        if (v == null || v === '' || k === 'type' || k === 'q' || k === 'p') return;
        if (CONST_FIELDS.test(k) || typeof v === 'boolean') {
          var c = T.consts[k] = T.consts[k] || {}; c[String(v)] = (c[String(v)] || 0) + weight;
          if (teacher) { var tc = T.tconsts[k] = T.tconsts[k] || {}; tc[String(v)] = (tc[String(v)] || 0) + weight; }
          // a shop or an insurer that changes from mail to mail (a gateway's, an aggregator's) is also kept as a place
          if (!TEXT_CONSTS.test(k)) return;
        }
        var slot = slotFor(doc, k, v);
        if (!slot) return;
        var sl = T.slots[k] = T.slots[k] || {};
        // one label told two ways ("your gas bill ..." and "your electricity bill ...") is one place
        if (!sl[slot] && slot.slice(0, 2) === 'K:') {
          var kw = slot.slice(2).split(' ');
          Object.keys(sl).forEach(function (o) { if (o.slice(0, 2) === 'K:' && kw.length >= 3 && jac(kw, o.slice(2).split(' ')) >= 0.6) slot = o; });
        }
        sl[slot] = (sl[slot] || 0) + weight;
        if (teacher) { var ts = T.tslots[k] = T.tslots[k] || {}; ts[slot] = (ts[slot] || 0) + weight; }
      });
    });
    return L;
  }
  function dominant(counts, total, min) {
    var best = null, bn = 0;
    Object.keys(counts || {}).forEach(function (k) { if (counts[k] > bn) { bn = counts[k]; best = k; } });
    return best !== null && bn >= min && bn / (total || 1) >= 0.6 ? best : null;
  }
  // a known template's book on a new mail: fill what the reading left out; read it if the reading found nothing
  function applyBook(L, doc, events, ctx) {
    if (!L || ctx.otp) return events;
    var main = events.filter(function (e) { return e.type !== 'account' && e.type !== 'noise'; });
    var kind = dominant(L.kinds, L.n, 2);
    var used = [];
    function fillFrom(T, ev, onlyMissing) { fillFromBook(doc, T, ev, onlyMissing, used); }
    // the reading is of another kind than the one a teacher taught this template (a "payment" the person said is a
    // statement, a limit read as a spend): the teacher's kind, read by the book
    var tkind = L.tkinds ? dominant(L.tkinds, L.tn, 3) : null;
    if (main.length && tkind && tkind !== 'noise' && L.types[tkind] && !main.some(function (e) { return e.type === tkind; }) && !ctx.failed) {
      var byT = readByBook(L, doc, ctx, tkind, true);
      if (byT.length) return byT.concat(events.filter(function (e) { return e.type === 'account'; }));
    }
    if (main.length) {
      main.forEach(function (e) {
        var T = L.types[e.type];
        if (!T) return;
        // what a teacher taught about this template's fields wins over the reader's own reading of them
        if (T.tslots || T.tconsts) {
          var taught = [];
          // (the money's own facts: what, how much, which way, on what, when; a name or a reference the reader read is
          // only filled where it read none)
          Object.keys(T.tconsts || {}).forEach(function (k) { if (!OVERRIDE_FIELDS.test(k)) return; var c = dominant(T.tconsts[k], T.tn, 3); if (c === null) return; var v = c === 'true' ? true : c === 'false' ? false : c; if (String(getPath(e, k)) !== String(v)) { setPath(e, k, v); taught.push(k); } });
          Object.keys(T.tslots || {}).forEach(function (k) {
            if (TEXT_CONSTS.test(k) || !OVERRIDE_FIELDS.test(k)) return;
            var slot = dominant(T.tslots[k], T.tn, 3); if (!slot) return;
            var v = resolveSlot(doc, k, slot);
            if (v == null || v === '') return;
            if (NAME_FIELDS.test(k)) { v = cleanParty(String(v)); if (!v) return; }
            if (String(getPath(e, k)) !== String(v)) { setPath(e, k, v); taught.push(k); }
          });
          if (taught.length) { e.taught = taught; if (e.doubt) { e.doubt = e.doubt.filter(function (k) { return taught.indexOf(k) < 0; }); if (!e.doubt.length) delete e.doubt; } delete e.unsure; }
        }
        fillFrom(T, e, true);
        // where the reading and the template disagree about the money, say so (the second witness weighs it)
        ['amt', 'total', 'dir'].forEach(function (k) {
          var have = getPath(e, k);
          if (have == null || (e.taught && e.taught.indexOf(k) >= 0)) return;
          // only a template that has never varied on it (three readings or more) can doubt a reading
          var unanimous = function (c) { var ks = Object.keys(c || {}); return ks.length === 1 && c[ks[0]] >= 3 ? ks[0] : null; };
          var want = k === 'dir' ? unanimous((T.consts || {})[k]) : (function () { var sl = unanimous(T.slots[k]); return sl ? resolveSlot(doc, k, sl) : null; })();
          if (want != null && String(want) !== String(have)) (e.doubt = e.doubt || []).push(k);
        });
      });
      if (used.length) main[0].filled = uniq(used);
      return events;
    }
    // nothing read, in a template that is almost always one kind of money mail: read it by the book, every event
    // the template usually carries (an alert's payment and the balance after it)
    if (tkind && tkind !== 'noise') kind = tkind;
    if (!kind || kind === 'noise' || ctx.failed || ctx.promo || !L.types[kind] || L.types[kind].n < 2) return events;
    var made = readByBook(L, doc, ctx, kind, false);
    if (!made.length) return events;
    return made.concat(events.filter(function (e) { return e.type === 'account'; }));
  }
  // fill an event from a template's slots: where each field sits in this mail
  function fillFromBook(doc, T, ev, onlyMissing, used) {
    Object.keys(T.slots).forEach(function (k) {
      if ((onlyMissing || TEXT_CONSTS.test(k)) && getPath(ev, k) != null && getPath(ev, k) !== '') return;
      var slot = dominant(T.slots[k], T.n, 2);
      if (!slot) return;
      var v = resolveSlot(doc, k, slot);
      if (v == null || v === '') return;
      if (NAME_FIELDS.test(k)) { v = cleanParty(String(v)); if (!v) return; }
      setPath(ev, k, v);
      if (used) used.push(k);
    });
  }
  // read a mail by its template alone, every event the template carries; by a teacher's word only, when a teacher taught
  // the template a kind the reading missed
  function readByBook(L, doc, ctx, kind, byTeacher) {
    var made = [];
    Object.keys(L.types).sort(function (a, b) { return (b === kind) - (a === kind) || L.types[b].n - L.types[a].n; }).forEach(function (ty) {
      var T0 = L.types[ty];
      var T = byTeacher ? { n: T0.tn || 0, consts: T0.tconsts || {}, slots: T0.tslots || {} } : T0;
      if (T.n < 2 || T.n / (byTeacher ? L.tn : L.n) < 0.6) return;
      var ev = { type: ty };
      Object.keys(T.consts).forEach(function (k) { var c = dominant(T.consts[k], T.n, 2); if (c !== null) setPath(ev, k, c === 'true' ? true : c === 'false' ? false : c); });
      fillFromBook(doc, T, ev, false, null);
      // the bank of a sender that writes for many (an app that pays every card) is the one this mail names
      if (ev.via && !ev.via.inst && E.issuerIn) {
        var mk = doc.toks.filter(function (x) { return x.t === 'MASK' && ev.via.last4 && String(x.v).slice(-4) === ev.via.last4; })[0];
        var who = (mk && E.issuerIn(doc.flat.slice(Math.max(0, mk.s - 80), mk.e + 20), ev.via.kind === 'card')) || E.issuerIn(doc.flat.slice(0, 1500), ev.via.kind === 'card');
        if (who) ev.via.inst = who.short;
      }
      // who and which reference: the reader's own grammar, around the amount the book found
      // the insurer is the one this mail names (an app sells many)
      if (ty === 'policy') { var ins = insurerIn(doc), m1; if (!ins && (m1 = /\b([A-Z][A-Za-z]+(?: [A-Z][A-Za-z]+)?)\s+(?:policy|insurance)\s+(?:issued|renewed|purchased|bought)\b/.exec(doc.subject))) ins = m1[1]; if (ins) ev.insurer = ins; }
      var at = null;
      if (ty === 'move' && ev.amt > 0) {
        at = doc.toks.filter(function (x) { return x.t === 'AMT' && Math.abs(x.v - ev.amt) < 0.011; });
        at = at.filter(function (x) { return inBody(doc, x); })[0] || at[0];
        // a template that goes both ways (a transfer acknowledged, in or out): the sentence says which
        var dk = Object.keys(T.consts.dir || {});
        if (at && (dk.length !== 1 || !ev.dir)) { var d2 = dirOf(doc, at); if (d2) ev.dir = d2; }
      }
      if (ty === 'move' && ev.amt > 0 && ev.dir && (!ev.party || !ev.ref)) {
        if (at) {
          var who2 = partyFor(doc, at, ev.dir);
          if (!ev.party && who2.party) ev.party = who2.party;
          if (who2.vpa && !ev.vpa) ev.vpa = who2.vpa;
          if (!ev.ref) { var rf = refFor(doc) || (who2.nar && who2.nar.ref); if (rf) ev.ref = rf; }
        }
      }
      var need = ty === 'move' ? ev.amt > 0 && ev.dir : ty === 'statement' ? ev.total != null || ev.due : ty === 'balance' ? ev.amt != null : ty === 'due' ? ev.amt > 0 || ev.due : ty === 'order' ? ev.order || ev.total > 0 : ty === 'expect' ? ev.amt > 0 : ev.amt > 0 || ev.premium > 0 || ev.policyNo || ev.shares > 0 || (ty === 'policy' && ev.action && ev.insurer);
      if (!need) return;
      if (ty === 'move' && !ev.date) ev.date = doc.ref;
      // a balance is the account the payment was on
      if (ty === 'balance' && made[0] && made[0].via && !ev.via) ev.via = { kind: made[0].via.kind === 'card' ? 'account' : made[0].via.kind, inst: made[0].via.inst, last4: made[0].via.last4 };
      ev.learned = Math.round(T.n);
      if (byTeacher) ev.taught = ['type'];
      ev.conf = 'medium';
      made.push(ev);
    });
    return made;
  }
  function newBook() { return { v: 1, layouts: {}, byDom: {} }; }
  // a record (the rules' shape: Claude's reading, a corrected one) as the events it stands for, to teach the book
  function eventsOf(rec) {
    if (!rec || !rec.kind) return [];
    if (rec.kind === 'noise') return [{ type: 'noise' }];
    var via = function (instr) {
      var v = { kind: instr === 'card' ? 'card' : instr === 'account' ? 'account' : instr === 'wallet' ? 'wallet' : instr === 'upi' ? 'upi' : 'other' };
      if (rec.inst && v.kind !== 'other') v.inst = rec.inst;
      if (rec.last4) v.last4 = String(rec.last4).slice(-4);
      return v;
    };
    if ((rec.kind === 'txn' || rec.kind === 'confirm') && rec.amt > 0 && (rec.dir === 'in' || rec.dir === 'out')) {
      var m = { type: 'move', dir: rec.dir, amt: +rec.amt, via: via(rec.instr) };
      if (rec.date) m.date = rec.date;
      if (rec.time) m.time = String(rec.time).slice(0, 5);
      if (rec.party) m.party = rec.party;
      if (rec.mode) m.mode = rec.mode;
      if (rec.ref) m.ref = rec.ref;
      if (rec.purpose) m.purpose = rec.purpose;
      var out = [m];
      if (rec.bal != null && rec.bal !== '') out.push({ type: 'balance', amt: +rec.bal, via: via(rec.instr) });
      return out;
    }
    if (rec.kind === 'statement') return [{ type: 'statement', total: +rec.amt || 0, min: +rec.min || 0, due: rec.due || undefined, via: via('card') }];
    if (rec.kind === 'bill' && (rec.amt > 0 || rec.due)) return [{ type: 'due', what: 'bill', amt: +rec.amt || undefined, due: rec.due || undefined, payee: rec.party || undefined }];
    if (rec.kind === 'policy' && rec.insurer) return [{ type: 'policy', action: 'issued', insurer: rec.insurer, premium: +rec.premium || undefined, policyNo: rec.last4 || undefined }];
    return [];
  }
  // keep the book small: the templates seen most recently, a bounded number per sender
  var SEEN_DESC = function (book) { return function (a, b) { var na = book.layouts[a] && book.layouts[a].no ? 1 : 0, nb = book.layouts[b] && book.layouts[b].no ? 1 : 0; if (na !== nb) return nb - na; return String((book.layouts[b] || {}).seen || '').localeCompare(String((book.layouts[a] || {}).seen || '')); }; };
  function trimBook(book) {
    Object.keys(book.byDom).forEach(function (d) {
      var ids = book.byDom[d];
      if (ids.length <= 60) return;
      ids.sort(SEEN_DESC(book));
      ids.slice(60).forEach(function (id) { delete book.layouts[id]; });
      book.byDom[d] = ids.slice(0, 60);
    });
    // and a bounded number in all (a few years of one person's money mail fits): the ones seen least recently go
    var all = Object.keys(book.layouts);
    if (all.length > 2000) {
      all.sort(SEEN_DESC(book)).slice(1500).forEach(function (id) {
        var L = book.layouts[id], ids = book.byDom[L.dom] || [];
        delete book.layouts[id];
        book.byDom[L.dom] = ids.filter(function (x) { return x !== id; });
        if (!book.byDom[L.dom].length) delete book.byDom[L.dom];
      });
    }
    return book;
  }
  // a reading worth learning from: sure of itself, nothing doubted, nothing filled in by the book
  function teachable(events) {
    var main = events.filter(function (e) { return e.type !== 'account' && e.type !== 'noise'; });
    if (!main.length) return events.length > 0;
    return main.every(function (e) { return !e.learned && !e.doubt && !e.unsure && (e.type !== 'move' || e.conf === 'high' || (e.date && e.via && e.via.kind !== 'other')); });
  }

  /* ------------------------------------------------------------ 11. how sure: a reading's chance of being right
     Each event is described by what backs it in the mail (its amount under a label or in a sentence that says money
     moved, a date of its own, the card's digits, a payee, a reference, a sender kosh knows, how many amounts the mail
     has, a promotion's words, a future tense, the book's word) and a small logistic model turns that into the chance
     the event is right (p). The weights are fitted on labelled mail by reader/calibrate.js, cross-checked on senders
     the fit didn't see, and pasted here; nothing is learnt at run time. An event below the line is marked unsure:
     the engine keeps its money out of the totals until a teacher (Claude, the person) or a second witness says so. */
  var CAL = {"b":0.553,"w":{"t_move":-0.37,"t_statement":0.06,"t_due":0.139,"t_order":-0.265,"t_expect":-1.793,"t_mandate":-0.207,"t_policy":-0.546,"t_fund":0.227,"t_ipo":0.85,"t_balance":0.886,"t_other":1.02,"known":-0.065,"bank":0.539,"rail":0.473,"hasAmt":0.709,"amtLabel":-0.244,"amtSubj":0.302,"amtMany":-0.044,"past":0.535,"future":-0.307,"promo":-0.118,"dated":0.816,"last4":0.141,"viaOther":-0.453,"party":1.174,"ref":0.14,"many":0.465,"html":-0.383,"long":-0.513,"quoted":-0.564,"high":0.365,"subjNot":-1.6,"bare":-0.03},"line":0.7,"n":728};   // reader/calibrate.js, 2026-10-14
  var TYPES_F = ['move', 'statement', 'due', 'order', 'expect', 'mandate', 'policy', 'fund', 'ipo', 'balance'];
  function amtTokOf(doc, ev) {
    var raw = ev.ev && ev.ev.amt, v = ev.amt != null ? ev.amt : ev.total != null ? ev.total : ev.premium != null ? ev.premium : null;
    var list = doc.toks.filter(function (t) { return t.t === 'AMT'; });
    return (raw && list.filter(function (t) { return t.raw === raw; })[0]) || (v != null ? list.filter(function (t) { return Math.abs(t.v - v) < 0.011 && inBody(doc, t); })[0] || list.filter(function (t) { return Math.abs(t.v - v) < 0.011; })[0] : null) || null;
  }
  function featuresOf(doc, ev, main, ctx) {
    var f = {}, t = amtTokOf(doc, ev), k = doc.inst ? doc.inst.kind : '';
    TYPES_F.forEach(function (ty) { f['t_' + ty] = ev.type === ty ? 1 : 0; });
    f.t_other = TYPES_F.indexOf(ev.type) < 0 ? 1 : 0;
    f.known = doc.inst ? 1 : 0;
    f.bank = /^(?:bank|card)$/.test(k) ? 1 : 0;
    f.rail = /^(?:gateway|wallet|app|broker|rta|insurer|lender)$/.test(k) ? 1 : 0;
    f.hasAmt = t ? 1 : 0;
    f.amtLabel = t && t.pair ? 1 : 0;
    f.amtSubj = t && !inBody(doc, t) ? 1 : 0;
    var vals = uniq(doc.toks.filter(function (x) { return x.t === 'AMT' && inBody(doc, x); }).map(function (x) { return x.v; }));
    f.amtMany = Math.min(3, Math.log(1 + vals.length));
    var sen = t ? sentenceAt(doc, t.s) : null, sl = sen ? lc(doc.flat.slice(sen.s, sen.e)) : '';
    f.past = PAST_MONEY.test(sl) ? 1 : 0;
    f.future = new RegExp(FUTURE_VERB.source).test(sl || doc.lead.slice(0, 600)) ? 1 : 0;
    f.promo = ctx && ctx.promo ? 1 : 0;
    var d = ev.date || ev.due || ev.stmtDate || ev.by || ev.on || '';
    f.dated = d && doc.toks.some(function (x) { return x.t === 'DATE' && x.v === d; }) ? 1 : 0;
    f.last4 = ev.via && ev.via.last4 ? 1 : 0;
    f.viaOther = ev.via && ev.via.kind === 'other' ? 1 : 0;
    f.party = ev.party || ev.payee || ev.shop || ev.insurer || ev.company || ev.scheme ? 1 : 0;
    f.ref = ev.ref || ev.order || ev.policyNo || ev.folio ? 1 : 0;
    f.many = main.length > 1 ? 1 : 0;
    f.html = doc.src === 'html' ? 1 : 0;
    f.long = Math.min(3, Math.log(1 + doc.flat.length / 1000));
    f.quoted = /\bwrote:?\s*(?:-+)?\s*$|-{3,}\s*original message/im.test(doc.flat) ? 1 : 0;
    f.learned = ev.learned ? 1 : 0;
    f.doubt = ev.doubt && ev.doubt.length ? 1 : 0;
    f.filled = ev.filled ? 1 : 0;
    f.high = ev.conf === 'high' ? 1 : 0;
    // a subject that says something didn't happen, or is only a notice about it
    f.subjNot = /\bnot\b|\bfailed\b|unable|declined|\breported\b|know the|important information|\bupdate\b|\brequest\b/.test(lc(doc.subject)) ? 1 : 0;
    // an order step with nothing to tie it to: no number, no total
    f.bare = ev.type === 'order' && !ev.order && ev.total == null ? 1 : 0;
    return f;
  }
  function judged(r) {
    var doc = r._doc, ctx = r._ctx || {};
    if (!doc) return r;
    var main = r.events.filter(function (e) { return e.type !== 'noise' && e.type !== 'account'; });
    main.forEach(function (e) {
      var f = featuresOf(doc, e, main, ctx);
      Object.defineProperty(e, '_f', { value: f, enumerable: false, configurable: true });
      if (!CAL) return;
      var z = CAL.b;
      for (var k in CAL.w) if (f[k]) z += CAL.w[k] * f[k];
      e.p = Math.round(1000 / (1 + Math.exp(-z))) / 1000;
      if (e.p < CAL.line) e.unsure = true; else delete e.unsure;
    });
    return r;
  }

  /* ------------------------------------------------------------ 12. Claude reads the mail
     Claude (Haiku) reads every money mail, masked, against the rules below (reader/DESIGN.md › "Claude reads").
     Measured on 428 labelled mails, it reads 97% of them right, on senders this reader was tuned to and on senders it
     never saw; this reader alone reads 69% and 54%. kosh stays the filter (only money mail is sent, never a one-time
     password or a security notice) and the checker: every amount Claude names must be printed in the mail (else the
     event waits, unsure), every id must be in the mail (else it is dropped), every masked value is put back from the
     mail itself. Its reading rides on the record (msg.cl, engine.js › withClaude) and teaches the book.
     GUARDRAIL nothing leaves the phone unmasked: long numbers keep their last four (E.redact), the owner's and the
     family's names become Name1, Name2..., personal email addresses and PANs are blanked, a mail is cut at 6,000
     characters, and Claude is told only the sender, the date, the subject, the attachments' names and the body. */
  var CL = { v: 2, model: 'claude-haiku-5-5', maxBody: 6000 };
  CL.rules = [
    "# Reading money mail for kosh",
    "",
    "You read emails from one person's inbox (in India) and write down what each one says happened with money, as typed",
    "events. Each input mail is {id, from, date (when it was sent), subject, attachments (file names), body}. Long numbers in",
    "the body and subject are masked to their last four digits, written like ••1234 (an account, card, reference or order",
    "number): when a field asks for such a number, copy it exactly as printed, ••1234 included; a `last4` field is just the",
    "four digits.",
    "",
    "Output: for every mail, in the same order, {\"id\": \"<its id>\", \"events\": [ ... ]}. Write the whole answer as one valid",
    "JSON array and nothing else. People's names may be replaced by Name1, Name2...: copy them as written.",
    "",
    "## What an event is",
    "",
    "Label only what THIS mail says. Never infer from other mails or general knowledge. Amounts are numbers (12345.5,",
    "no commas, no currency). Dates are YYYY-MM-DD. Leave a field out when the mail doesn't print it (never guess).",
    "A mail can have several events (a debit alert with a balance: a move and a balance). A mail that is not money",
    "(offer, OTP, KYC, newsletter, password/security notice, marketing that prints amounts, a failed or declined payment,",
    "a request awaiting your consent, a complaint ticket, a survey, a login alert) gets `[{\"type\":\"noise\",\"reason\":\"...\"}]`",
    "with reason one of otp, offer, kyc, info, failed, request, service, security, newsletter, delivery.",
    "",
    "| type | when | fields (only what the mail prints) |",
    "|---|---|---|",
    "| move | money HAS moved (done, past) | dir \"in\"/\"out\" (from the owner's side), amt, date (the day it moved, else omit), time \"HH:MM\" 24h, via {kind: \"card\"/\"account\"/\"wallet\"/\"upi\"/\"other\", inst: short issuer name e.g. \"HDFC\", \"ICICI\", \"SBI Card\", \"Amex\", last4: last 4 digits printed of the card/account}, party (the other side, as written), ref (UPI ref / UTR / transaction id), mode (\"UPI\",\"NEFT\",\"IMPS\",\"RTGS\",\"NACH\",\"ATM\",\"POS\"), purpose (one of purchase, refund, reversal, cashback, interest, dividend, salary, billpay, cardpay, emi, premium, investment, redemption, payout, topup, withdrawal, fee, tax, transfer) |",
    "| balance | an available/ledger balance is printed | amt, via |",
    "| statement | a card or account statement (e-statement mail) | total (total amount due), min (minimum due), due (payment due date), stmtDate, via {last4, inst} |",
    "| due | a bill/EMI/fee to pay by a date, not yet paid | what (\"bill\",\"card\",\"premium\",\"emi\",\"maintenance\",\"subscription\",\"tax\",\"fee\"), payee, amt, due |",
    "| expect | money promised/scheduled but not yet moved | dir, amt, what (\"refund\",\"debit\",\"credit\",\"sip\",\"unblock\",\"maturity\",\"payout\"), by (latest date promised) or on (the exact day), order (order number if a shop refund) |",
    "| order | a shop/app order's step (incl. rides, food, travel/hotel bookings, invoices) | shop, order (order/booking id), status (\"placed\",\"shipped\",\"out\",\"delivered\",\"cancelled\",\"returned\",\"refunded\",\"declined\"), total |",
    "| trade | shares/ETF bought or sold (contract note, trade confirmation) | side \"buy\"/\"sell\", name, isin, qty, price, value, date |",
    "| fund | a mutual fund transaction confirmed | action \"buy\"/\"sip\"/\"redeem\"/\"switch\", scheme, folio, amt, units, nav, date |",
    "| ipo | an IPO application's step | action \"applied\"/\"blocked\"/\"allotted\"/\"not-allotted\"/\"unblocked\", company, amt, shares |",
    "| dividend | a dividend advice | company, amt, date |",
    "| deposit | a fixed/recurring deposit's step (from a bank or deposit-taker) | action \"open\"/\"renew\"/\"close\"/\"mature\"/\"instalment\", inst (bank short name), no (LAST 4 digits of the deposit number), amt (principal), rate (percent number), start, mat (maturity date), matAmt |",
    "| policy | an insurance policy's step | action \"issued\"/\"paid\"/\"due\"/\"renewed\"/\"lapsed\", insurer, policyNo (full, as printed, upper case), plan, premium, cover (sum assured), due |",
    "| mandate | an auto-debit / standing instruction / subscription renewal's step | action \"created\"/\"upcoming\"/\"done\"/\"cancelled\"/\"failed\", party, amt, date, every (\"month\",\"year\") |",
    "| account | a card or account exists / changed (card delivered, activated, limit changed, account opened/closed) | step \"delivered\"/\"activated\"/\"limit\"/\"closed\"/\"seen\", via {kind, inst, last4} |",
    "",
    "## Conventions that matter (the scoreboard compares exactly)",
    "",
    "- Direction is the owner's: a card bill payment received by the card company is `move dir:\"in\"` on the card with",
    "  purpose \"cardpay\"; money credited to the owner's account is \"in\"; NEFT \"credited to beneficiary X\" is \"out\".",
    "- A shop's or app's receipt that says it was paid (\"Payment successful\", \"Paid ₹X\") is a `move dir:\"out\"` with party",
    "  = the shop, plus the `order` if it prints an order id. A refund already credited is `move in purpose:\"refund\"`; a",
    "  refund \"initiated / will be credited in 5-7 days\" is `expect in what:\"refund\"` (no move).",
    "- Future tense (\"will be debited\", \"is due\", \"upcoming\") is never a move. Conditional offers (\"get ₹500 cashback",
    "  when you spend\") are noise/offer. \"Eligible for a reversal\" is noise. \"Declined\", \"failed\", \"unsuccessful\" is",
    "  noise/failed (an IPO not allotted is `ipo not-allotted`; a refund of a failed payment that was credited is a move).",
    "- A bank's \"verify your transaction\" call, a consent request (\"FD initiated by your RM awaiting consent\"), a complaint",
    "  or ticket mail, an \"insurance queries? reach us\" mail: noise.",
    "- An IPO ASBA mail \"application accepted, amount blocked\" is two events: `ipo applied` and `ipo blocked` with amt.",
    "- Hotel/flight/train/bus bookings are `order` (status \"placed\", total = the total paid), never deposits.",
    "- A credit card statement mail: `statement`. A \"payment due reminder\" for a card: `due what:\"card\"`.",
    "- Insurance premium receipt (paid): `policy action:\"paid\"` with premium; a renewal notice before the due date:",
    "  `policy action:\"due\"`; \"has lapsed / expired, renew now\": `policy action:\"lapsed\"`.",
    "- inst short names: HDFC, ICICI, SBI, Axis, Kotak, IndusInd, YES, AU, Federal, IDFC FIRST, RBL, Citi, HSBC, SBI Card,",
    "  Amex, Standard Chartered, Bank of Baroda, PNB, Canara, Union, IDBI, OneCard, Slice, Jupiter, Fi, Paytm, etc.",
    "- `notes`: one short line saying what the mail is (\"HDFC UPI debit alert\", \"Swiggy order delivered\", \"promo\").",
    "",
    "",
    "## Three rules that settle the common doubts",
    "",
    "1. Money that moved always gets its own `move`, even when the mail is mainly about something else. A premium receipt",
    "   is `policy action:\"paid\"` AND `move dir:\"out\" purpose:\"premium\"`; a paid shop or app order is `order` AND",
    "   `move dir:\"out\" purpose:\"purchase\"`; a subscription charged is `mandate action:\"done\"` AND `move dir:\"out\"`; a",
    "   dividend credited is `dividend` AND `move dir:\"in\" purpose:\"dividend\"`; a refund or cashback already credited is",
    "   `move dir:\"in\"` (purpose \"refund\" / \"cashback\"), plus `order status:\"refunded\"` if it names the order.",
    "2. A bill (electricity, gas, water, phone, broadband, DTH, FASTag, insurance, credit card) paid through an app or a",
    "   bank (Amazon Pay, Paytm, PhonePe, CRED, a bank's bill pay) is `move dir:\"out\" purpose:\"billpay\"` with party = the",
    "   biller. It is never an `order`, even when the app calls it an order and prints an order id.",
    "3. Copy ids and references bare: `ref`, `order`, `policyNo` are only the number or code itself (as printed, masked",
    "   ••1234 if it is masked), never the sentence around it.",
    "",
    "## Settled rules (15 Oct): what to do when you could argue either way",
    "",
    "Payments",
    "4. A payment needs an amount: a receipt that prints no amount is never a `move` (an `order` alone if it is an order).",
    "   A shop or ride paid in cash is a `move dir:\"out\"` with via kind \"other\".",
    "5. A shop's or app's own order confirmation that names how it was paid (card, UPI, wallet, net banking, \"paid",
    "   online\") is a paid order: `order status:\"placed\"` AND `move dir:\"out\" purpose:\"purchase\"`, even without the word",
    "   \"paid\". The move's party is the shop, app or broker that charged you (Zomato, Swiggy, Amazon, Policybazaar), not the",
    "   restaurant, seller or insurer behind it. A payment gateway's receipt (\"payment successful for <merchant>\" from Razorpay, PayU, CCAvenue, Paytm)",
    "   and a restaurant bill paid through an app are a `move` only, no `order`: the shop's own mail carries the order.",
    "6. A paid subscription (an app store or a service charging its plan) is `mandate action:\"done\"` AND `move dir:\"out\"`,",
    "   never an `order`; its receipt or order number is the move's `ref`. A bill paid through an app puts the bill",
    "   payment's own reference (the BBPS or biller transaction id) in the move's `ref` when printed, else the app's order",
    "   or transaction number.",
    "7. A bank's NACH / auto-debit alert, or a standing instruction the bank carried out, is a `move` with mode \"NACH\" for",
    "   NACH (and a `balance` if printed), not also a `mandate`, unless the mail is about the mandate itself (set up,",
    "   cancelled, failed). A request to set one up that is only \"received\" or awaits your approval is noise \"request\".",
    "8. A card purchase converted to EMI was already charged: the conversion mail is `due what:\"emi\"` (amt, due) only, no",
    "   new `move`. A debit \"towards FD / RD account\" is a `move purpose:\"investment\"`; it is a `deposit` step only when the",
    "   mail says the deposit was opened, renewed or closed. A credit of a deposit's proceeds (\"FD premat proceeds\",",
    "   \"maturity proceeds\") is a `move dir:\"in\"` AND `deposit action:\"close\"` (closed early) or `\"mature\"`, with `no`.",
    "9. Money that never reached a bank account or wallet is not a move: cashback as store points, coins or app credits, a",
    "   purchase paid only with reward points, a ₹0 order. These are noise \"info\".",
    "10. Adding money to a broker, wallet or app from your bank or card (\"Payment success\", \"funds added\") is a",
    "    `move dir:\"out\"` with via = the account, card or UPI it came from and party = the broker or app.",
    "",
    "Dues, mandates, policies",
    "11. A `due` is a reminder to pay by a date. A card alert that only mentions what is outstanding, with no due date, is",
    "    not a `due`. A card's `due.amt` is the total amount due when printed, else the amount it asks you to pay; a",
    "    \"statement balance\" is the total amount due. A postpaid, utility or pay-later bill is a `due what:\"bill\"`, not a `statement` (statements are for bank, card,",
    "    loan and broker accounts).",
    "12. A mandate's `date` on action \"created\" is the first debit date the mail prints (omit it if none). A bank's notice",
    "    that a bill or premium will be auto-paid on a date is `mandate action:\"upcoming\"` only (no `due`). An insurer's",
    "    premium reminder, auto-debit or not, is `policy action:\"due\"` alone: never also a `due` or a `mandate`.",
    "13. A subscription \"will expire soon, renew to continue\" notice is noise \"info\", not a mandate.",
    "",
    "Orders and refunds",
    "14. A return or refund mail that names the order gets `order status:\"returned\"` (or \"refunded\" once the money is back)",
    "    with total = the refund, beside the `expect` (promised) or `move` (credited). A cancelled booking or order is",
    "    status \"cancelled\", even when its refund is the news. A return only requested (pickup scheduled, not yet picked",
    "    up) is noise \"info\". A return number is not an order id; an order id printed only inside a link still counts.",
    "15. A service already used (a ride's invoice after the trip, a stay that ended) is status \"delivered\". An invoice",
    "    for a shop order that prints no other status is \"placed\".",
    "16. \"Please complete payment\" for an unpaid shop order is noise \"request\". A SIP instalment placed and awaiting payment",
    "    or its mandate debit is `expect dir:\"out\" what:\"sip\"`, one per fund, with amt.",
    "",
    "Investments and accounts",
    "17. An RTA's allotment or unblocking intimation that prints \"Amount Unblocked\" is `ipo action:\"unblocked\"` with amt.",
    "18. A dividend only recommended (not declared), or a TDS communication about one, is noise \"info\".",
    "19. A notice that a deposit will be renewed or will mature on a date is a `deposit` step all the same: action",
    "    \"renew\" (auto-renewal) or \"mature\" (to be paid out), with `no`, and `mat` = that date.",
    "20. A broker's or depository's statement (margin statement, transaction-with-holding statement, retention statement,",
    "    funds and securities balance) is a `statement` with via {inst, last4 of the client or account id}; no total. A",
    "    demat or account maintenance charge is `due what:\"fee\"`.",
    "21. A card's available credit limit is not a `balance`; a prepaid phone, DTH or FASTag balance is not a `balance`",
    "    either (noise \"info\" when the mail has nothing else).",
    "",
    "Reading the mail",
    "22. When the subject and the body disagree about whether money moved, the body decides.",
    "23. A date printed without a year takes the year from the mail's sent date (the following year for a promised date",
    "    that would otherwise fall before the mail was sent). A card or account number printed with fewer than four digits",
    "    (XX12) gives last4 = the digits printed. An order number printed joined to its date and time",
    "    (\"4821|03-02-2024|10:15:00\") is only the leading number.",
    "",
    "More settled cases",
    "24. A mutual fund's purchase, SIP or allotment confirmation (from the fund house, its registrar or the broker) is",
    "    `fund` alone: the money's own `move` comes from the bank's alert.",
    "25. An insurer's \"your policy has matured\" mail that prints no payout amount or date is noise \"info\".",
    "26. A booking that failed to confirm is order status \"declined\" (with the refund's `expect` if one is promised).",
    "27. A wallet's debit alert that names the booking or order it paid for is a `move` (and `balance`) only, no `order`.",
    "    An order paid partly from a wallet balance gets a `move` for the wallet part via that wallet; the rest is a move",
    "    only when the mail names how it was paid.",
    "28. A cheque \"received in clearing\" alert that doesn't say the account was debited is `expect dir:\"out\"",
    "    what:\"debit\"`.",
    "29. A contract note mail is a `trade` (with its date) even when the trades themselves are only in the attachment.",
    "30. An amount in a currency other than rupees (USD 20.00, $20, EUR 15) adds `cur` with its code (USD, EUR, GBP, AED...)",
    "    to the event, with amt in that currency as printed. When the mail prints the rupee amount as well, amt is the rupee",
    "    amount and there is no `cur`.",
  ].join('\n');
  var CL_NOT_NAMES = /^(?:you|mr|mrs|ms|miss|dr|shri|smt|sri|the|and|son|daughter|wife|husband|mother|father|mom|dad|kumar|devi)$/i;
  var CL_PERSONAL_MAIL = /[\w.+-]+@(?:gmail|googlemail|yahoo|ymail|rediffmail|outlook|hotmail|live|msn|icloud|me|proton|protonmail|aol|zoho)\.[a-z.]{2,6}\b/gi;
  function clEsc(s) { return String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }
  /* the masking for one batch: the same name is the same NameN in every mail of it, and what each NameN stood for is
     kept to put it back */
  function clMasker(names, how) {
    var toks = [], seen = {}, raw = !!(how && how.numbers === false);
    function add(w, owner, joined) {
      w = w.replace(/[^A-Za-z'-]/g, '');
      if (w.length < 3 || CL_NOT_NAMES.test(w) || seen[lc(w)]) return;
      seen[lc(w)] = 1;
      // a name of five letters or more is masked inside a word too (a user id, "examplepersona1990"); a shorter one
      // only as a word of its own
      toks.push({ w: w, tag: 'Name' + (toks.length + 1), owner: owner, joined: joined, re: w.length >= 5 ? new RegExp('()(' + clEsc(w) + ')', 'gi') : new RegExp('(^|[^A-Za-z0-9])(' + clEsc(w) + ')(?![A-Za-z0-9])', 'gi') });
    }
    var lists = (names || []).map(function (n) { return String(n || '').split(/[\s.,_]+/).filter(function (w) { return w.replace(/[^A-Za-z]/g, '').length >= 3; }); });
    lists.forEach(function (ws, i) { ws.forEach(function (w) { add(w, i === 0, false); }); });
    // and each whole name run together, as some mail prints it ("EXAMPLEPERSONA")
    lists.forEach(function (ws, i) { if (ws.length > 1) add(ws.join(''), i === 0, true); });
    var byLen = toks.slice().sort(function (a, b) { return b.w.length - a.w.length; });
    var back = {};
    function mask(s) {
      s = String(s == null ? '' : s).replace(CL_PERSONAL_MAIL, '(email)').replace(/\b[A-Z]{5}\d{4}[A-Z]\b/g, '(PAN)');
      byLen.forEach(function (t) { s = s.replace(t.re, function (_, pre, m) { if (!back[t.tag]) back[t.tag] = m; return pre + t.tag; }); });
      // (a paper's pages keep their figures: the caller masks its long numbers one by one)
      return raw || !E.redact ? s : E.redact(s);
    }
    return { mask: mask, back: back, toks: toks };
  }
  function clBatch(mails, opts) {
    var M = clMasker((opts || {}).names);
    var items = (mails || []).map(function (m, i) {
      var b = bodyOf(m);
      var body = M.mask(b.body.replace(/^\s*<!doctype[^>]*>\s*/i, ''));
      if (body.length > CL.maxBody) body = body.slice(0, CL.maxBody) + '\n[cut]';
      var att = (m.attachments || []).map(function (a) { return M.mask(String((a && a.filename) || a || '')); }).filter(Boolean);
      return { id: 'm' + (i + 1), from: M.mask(m.from || ''), date: String(m.date || ''), subject: M.mask(b.subject), attachments: att, body: body };
    });
    return { M: M, items: items };
  }
  /* the request for /v1/messages: the rules as the system prompt (cached: they are the same for every batch), the
     masked mails as one message, a few to a request */
  function clRequest(mails, opts) {
    opts = opts || {};
    var bt = clBatch(mails, opts), M = bt.M;
    var own = M.toks.filter(function (t) { return t.owner && !t.joined; }).map(function (t) { return t.tag; });
    var head = 'Read these mails (' + bt.items.length + ').' +
      (M.toks.length ? ' Names of people are replaced by Name1, Name2...' + (own.length ? ': ' + own.join(' ') + ' is the owner, the others are family.' : '.') : '') +
      ' Answer with the JSON array only.\n\n';
    return {
      model: opts.model || CL.model,
      max_tokens: Math.min(8000, 600 + 500 * bt.items.length),
      system: [{ type: 'text', text: CL.rules, cache_control: { type: 'ephemeral' } }],
      messages: [{ role: 'user', content: head + JSON.stringify(bt.items) }],
    };
  }

  /* ---- the answer, checked */
  var CL_KIND = /^(?:card|account|wallet|upi|other)$/;
  var CL_SCHEMA = {
    move: { dir: /^(?:in|out)$/, amt: 'amt', date: 'date', time: /^\d{1,2}:\d{2}$/, via: 'via', party: 'name', ref: 'id', mode: /^(?:UPI|NEFT|IMPS|RTGS|NACH|ATM|POS)$/,
            purpose: /^(?:purchase|refund|reversal|cashback|interest|dividend|salary|billpay|cardpay|emi|premium|investment|redemption|payout|topup|withdrawal|fee|tax|transfer)$/ },
    balance: { amt: 'amt', via: 'via' },
    statement: { total: 'amt', min: 'amt', due: 'date', stmtDate: 'date', via: 'via' },
    due: { what: /^(?:bill|card|premium|emi|maintenance|subscription|tax|fee)$/, payee: 'name', amt: 'amt', due: 'date' },
    expect: { dir: /^(?:in|out)$/, amt: 'amt', what: /^(?:refund|debit|credit|sip|unblock|maturity|payout)$/, by: 'date', on: 'date', order: 'id' },
    order: { shop: 'name', order: 'id', status: /^(?:placed|shipped|out|delivered|cancelled|returned|refunded|declined)$/, total: 'amt' },
    trade: { side: /^(?:buy|sell)$/, name: 'name', isin: /^[A-Z]{2}[A-Z0-9]{9}\d$/, qty: 'num', price: 'num', value: 'amt', date: 'date' },
    fund: { action: /^(?:buy|sip|redeem|switch)$/, scheme: 'name', folio: 'id', amt: 'amt', units: 'num', nav: 'num', date: 'date' },
    ipo: { action: /^(?:applied|blocked|allotted|not-allotted|unblocked)$/, company: 'name', amt: 'amt', shares: 'num' },
    dividend: { company: 'name', amt: 'amt', date: 'date' },
    deposit: { action: /^(?:open|renew|close|mature|instalment)$/, inst: 'name', no: 'last4', amt: 'amt', rate: 'num', start: 'date', mat: 'date', matAmt: 'amt' },
    policy: { action: /^(?:issued|paid|due|renewed|lapsed)$/, insurer: 'name', policyNo: 'id', plan: 'name', premium: 'amt', cover: 'amt', due: 'date' },
    mandate: { action: /^(?:created|upcoming|done|cancelled|failed)$/, party: 'name', amt: 'amt', date: 'date', every: /^(?:week|month|quarter|year)$/ },
    account: { step: /^(?:delivered|activated|limit|closed|seen)$/, via: 'via' },
    noise: { reason: /^(?:otp|offer|kyc|info|failed|request|service|security|newsletter|delivery)$/ },
  };
  var CL_NEEDS = { move: ['dir', 'amt'], balance: ['amt'], order: ['status'], trade: ['side'], fund: ['action'], ipo: ['action'], deposit: ['action'], policy: ['action'], mandate: ['action'], account: ['step'], expect: ['dir'] };
  // the answer's JSON array, or what of it came back whole when the answer was cut short
  function clParse(text) {
    var s = String(text || '').replace(/```(?:json)?/gi, '');
    var a = s.indexOf('[');
    if (a < 0) return null;
    var b = s.lastIndexOf(']');
    if (b > a) { try { var v = JSON.parse(s.slice(a, b + 1)); if (Array.isArray(v)) return v; } catch (e) { /* cut short: below */ } }
    for (var k = s.lastIndexOf('}'), n = 0; k > a && n < 40; k = s.lastIndexOf('}', k - 1), n++) {
      try { var w = JSON.parse(s.slice(a, k + 1) + ']'); if (Array.isArray(w)) return w; } catch (e) { /* earlier */ }
    }
    return null;
  }
  function clNum(v) {
    if (typeof v === 'number') return isFinite(v) ? v : null;
    if (typeof v !== 'string') return null;
    var s = v.replace(/[₹,\s]|rs\.?|inr/gi, '');
    return /^-?\d+(?:\.\d+)?$/.test(s) ? +s : null;
  }
  function clDay(v) {
    if (typeof v !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(v)) return '';
    var d = new Date(v + 'T00:00:00Z');
    return !isNaN(d) && d.toISOString().slice(0, 10) === v && +v.slice(0, 4) >= 1990 && +v.slice(0, 4) <= 2100 ? v : '';
  }
  function clSquash(s) { return lc(s).replace(/[^a-z0-9]/g, ''); }
  /* what the mail itself holds, to check the answer against and to put masked values back from */
  function clHay(msg, M) {
    var b = bodyOf(msg), raw = String(msg.text || '');
    var files = (msg.attachments || []).map(function (a) { return String((a && a.filename) || a || ''); }).join(' ');
    var text = b.subject + '\n' + b.body + '\n' + raw.slice(0, 30000) + '\n' + files;
    var nums = [];
    (text.match(/\d[\d,]*(?:\.\d+)?/g) || []).forEach(function (t) { var v = +t.replace(/,/g, ''); if (isFinite(v)) nums.push(v); });
    // the tokens masking could have shortened: a word with digits, digits in groups, and every bare run of digits
    var toks = (text.match(/[A-Za-z0-9][A-Za-z0-9\/_-]{5,}|\d[\d -]{6,}\d/g) || []).concat(text.match(/\d{8,}/g) || []).map(function (t) { return t.trim(); });
    return { text: text, sq: clSquash(text), nums: nums, toks: toks, M: M };
  }
  function clBack(v, H) {
    if (typeof v !== 'string') return v;
    var s = v;
    if (/\bName\d{1,2}\b/.test(s)) {
      var word = function (m) { return (H.M.toks.filter(function (t) { return t.tag === m; })[0] || {}).w; };
      // the words as the mail wrote them ("SAMPLE PERSONA"), else each name as it was first seen
      var pat = clEsc(s).replace(/\s+/g, '\\s+').replace(/\bName\d{1,2}\b/g, function (m) { var w = word(m); return w ? clEsc(w) : m; });
      var hit = null;
      try { hit = new RegExp('(?:^|[^A-Za-z0-9])(' + pat + ')(?![A-Za-z0-9])', 'i').exec(H.text); } catch (e) { hit = null; }
      s = hit ? hit[1] : s.replace(/\bName\d{1,2}\b/g, function (m) { return H.M.back[m] || word(m) || m; });
    }
    if (s.indexOf('••') < 0) return s;
    var red = E.redact || function (x) { return x; };
    var exact = H.toks.filter(function (t) { return red(t) === s; })[0];
    if (exact) return exact;
    return s.replace(/[A-Za-z0-9\/_-]*••\d{4}/g, function (piece) { return H.toks.filter(function (t) { return red(t) === piece; })[0] || piece; });
  }
  function clPrinted(v, H) { return H.nums.some(function (x) { return Math.abs(x - v) < 0.011; }); }
  /* one event of the answer, as kosh keeps it: known fields only, of the right shape, put back from the mail;
     null if it isn't an event kosh can use */
  function clEvent(e, H) {
    if (!e || typeof e !== 'object' || !CL_SCHEMA[e.type]) return null;
    var S = CL_SCHEMA[e.type], o = { type: e.type }, doubt = [];
    Object.keys(S).forEach(function (k) {
      var want = S[k], v = e[k];
      if (v == null || v === '') return;
      if (want === 'amt' || want === 'num') {
        var n = clNum(v);
        // (only a statement's total may be below nothing: a credit balance)
        if (n == null || (n < 0 && !(e.type === 'statement' && k === 'total'))) return;
        o[k] = Math.round(n * 100) / 100;
        if (want === 'amt' && n !== 0 && !clPrinted(Math.abs(n), H)) doubt.push(k + ' not in the mail');
      } else if (want === 'date') {
        var d = clDay(v);
        if (d) o[k] = d;
      } else if (want === 'id') {
        var id = trim(clBack(String(v), H)).slice(0, 60);
        // an id is only kept when the mail prints it
        if (id && id.indexOf('••') < 0 && H.sq.indexOf(clSquash(id)) >= 0 && clSquash(id).length >= 3) o[k] = id;
      } else if (want === 'last4') {
        var l4 = String(clBack(String(v), H)).replace(/\D/g, '').slice(-4);
        if (l4.length >= 2 && H.text.indexOf(l4) >= 0) o[k] = l4;
      } else if (want === 'name') {
        var nm = trim(clBack(String(v), H)).slice(0, 80);
        if (nm && !/^\(?(?:email|pan)\)?$/i.test(nm)) o[k] = nm;
      } else if (want === 'via') {
        if (typeof v !== 'object') return;
        var via = {};
        if (CL_KIND.test(v.kind)) via.kind = v.kind;
        if (v.inst) via.inst = trim(clBack(String(v.inst), H)).slice(0, 40);
        if (v.last4 != null) { var vl = String(clBack(String(v.last4), H)).replace(/\D/g, '').slice(-4); if (vl.length >= 2 && H.text.indexOf(vl) >= 0) via.last4 = vl; }
        o[k] = via;
      } else if (want instanceof RegExp) {
        var t = String(v).trim();
        if (k === 'mode') t = t.toUpperCase();
        if (k === 'time') t = t.length === 4 ? '0' + t : t;
        if (want.test(t)) o[k] = t;
      }
    });
    if (e.type === 'noise') return { type: 'noise', reason: o.reason || 'info', cl: 1 };
    if ((CL_NEEDS[e.type] || []).some(function (k) { return o[k] == null; })) return null;
    // a payment needs its amount (rule 4); a move without a way it went went some other way
    if (e.type === 'move') { if (!(o.amt > 0)) return null; o.via = o.via || {}; if (!o.via.kind) o.via.kind = 'other'; }
    if (o.via && !Object.keys(o.via).length) delete o.via;
    // money in another currency keeps its code: the phone works out about what it was in rupees (engine.js › FX)
    if (typeof e.cur === 'string' && /^[A-Z]{3}$/.test(e.cur.trim().toUpperCase()) && e.cur.trim().toUpperCase() !== 'INR' && /^(?:move|order|due|mandate|expect)$/.test(e.type)) o.cur = e.cur.trim().toUpperCase();
    if (typeof e.notes === 'string' && e.notes.trim()) o.notes = trim(clBack(e.notes, H)).slice(0, 120);
    o.cl = 1;
    if (doubt.length) { o.unsure = true; o.doubt = doubt; } else o.conf = 'high';
    return o;
  }
  /* Claude's answer for a batch, checked: one entry per mail, in order, {id, events} (events null when the answer
     left the mail out: it is asked again later) */
  function clAnswer(text, mails, opts) {
    var bt = clBatch(mails, opts), got = clParse(text) || [];
    var byId = {};
    got.forEach(function (x, i) { if (x && typeof x === 'object') byId[String(x.id || ('m' + (i + 1)))] = x; });
    return (mails || []).map(function (m, i) {
      var x = byId['m' + (i + 1)];
      if (!x || !Array.isArray(x.events)) return { id: m.id, events: null };
      var H = clHay(m, bt.M), doc = null;
      var evs = x.events.map(function (e) { return clEvent(e, H); }).filter(Boolean);
      var real = evs.filter(function (e) { return e.type !== 'noise'; });
      if (real.length) evs = real; else evs = evs.slice(0, 1);
      if (!evs.length) evs = [{ type: 'noise', reason: 'info', cl: 1 }];
      // where each was read, to show beside it
      try { doc = docOf(m); } catch (err) { doc = null; }
      if (doc) evs.forEach(function (e) { if (e.type !== 'noise') { var q = quoteOf(doc, e); if (q) e.q = q; } });
      return { id: m.id, events: evs };
    });
  }
  /* which mail is worth Claude's reading: money mail, never a one-time password or a security notice (the reader's
     own judgement, which is right about those nearly always) */
  /* the parcel steps of a mail Claude read (its events replace the reader's, and Claude reads no parcels): the reader's
     own, for mail from a courier or whose subject says a parcel's step; nothing read for any other mail */
  function parcelsOf(msg) {
    var dom = lc((/<([^>]+)>/.exec((msg && msg.from) || '') || [0, (msg && msg.from) || ''])[1]).split('@')[1] || '';
    var courier = COURIERS.some(function (c) { return onDomain(dom, c.domains); });
    if (!courier && !/deliver|ship|dispatch|pick ?-?up|out for|arriv|transit|parcel|package|consignment|\bawb\b|return/i.test(String((msg && msg.subject) || ''))) return [];
    try { return readOnce(msg).parcels || []; } catch (e) { return []; }
  }
  function clWanted(msg) {
    var r;
    try { r = readOnce(msg); } catch (e) { return true; }
    var n = r.kind === 'noise' && r.events[0] ? r.events[0].reason : '';
    return n !== 'otp' && n !== 'security';
  }

  var api = {
    VERSION: VERSION, read: read, toRecord: toRecord, docOf: docOf, parcels: parcelsOf, lex: lex, bodyOf: bodyOf, mailDay: mailDay, narration: narration,
    skeleton: function (msg) { return skeletonOf(docOf(msg)); },
    // for tests and the scoreboard's detail view
    internals: { featuresOf: featuresOf, roleOf: roleOf, dirOf: dirOf, viaFor: viaFor, partyFor: partyFor, kv: kv, amts: amts, sentenceAt: sentenceAt, layoutOf: layoutOf, skeletonOf: skeletonOf },
    readJSON: function (m) { return JSON.stringify(read(JSON.parse(m))); },
    // learning from old mail: a book of templates (kept by the phone between launches)
    newBook: newBook, teach: teach, teachNot: teachNot, teachUndo: teachUndo, eventsOf: eventsOf, fingerprint: function (msg) { return fingerprint(docOf(msg)); },
    learning: { slotFor: slotFor, resolveSlot: resolveSlot, applyBook: applyBook, learnInto: learnInto, bookFind: bookFind },
    // Claude as the reader (section 12)
    claude: { CL: CL, request: clRequest, answer: clAnswer, wanted: clWanted, mask: function (s, names) { return clMasker(names).mask(s); }, masker: clMasker, parse: clParse },
  };
  E.reader = api;
  E.readerReadJSON = api.readJSON;
  // the phone's bridge (LiveSession › Claude reads): a batch's request, its answer checked, and which mail to send
  E.clReadRequestJSON = function (mails, opts) { return JSON.stringify(clRequest(JSON.parse(mails), opts ? JSON.parse(opts) : {})); };
  E.clReadAnswerJSON = function (text, mails, opts) { return JSON.stringify(clAnswer(text, JSON.parse(mails), opts ? JSON.parse(opts) : {})); };
  /* kosh-reader v4 on the phone answers in these same event shapes ({"events":[…]}), so its answer is checked exactly as
     Claude's is (clEvent: known fields only, every amount printed in the mail, a card's digits only if the mail has them)
     and marked lr (the local reader). Rules first: engine.js › withClaude lets a reading marked lr decide nothing the
     rules read, ranks it below yours and Claude's, and never teaches the book from it.
     {events} — no events at all is the model saying "not money"; {unsure} — not an answer, or nothing in it held up */
  function localAnswer(raw, msg) {
    var o;
    try { o = JSON.parse(String(raw || '').trim()); } catch (e) { return { unsure: 'unreadable answer' }; }
    if (!o || !Array.isArray(o.events)) return { unsure: 'not the reader\u2019s shape' };
    if (!o.events.length) return { events: [{ type: 'noise', reason: 'info', lr: 1 }] };
    var H = clHay(msg, { toks: [], back: {} });
    var evs = o.events.map(function (e) { return clEvent(e, H); }).filter(Boolean);
    var real = evs.filter(function (e) { return e.type !== 'noise'; });
    if (real.length) evs = real;
    if (!evs.length) return { unsure: 'nothing kosh keeps' };
    evs.forEach(function (e) { delete e.cl; e.lr = 1; });
    return { events: evs };
  }
  api.localAnswer = localAnswer;
  E.readerAnswerJSON = function (raw, m) { return JSON.stringify(localAnswer(raw, JSON.parse(m))); };
  E.clWantedJSON = function (msg) { return JSON.stringify(clWanted(JSON.parse(msg))); };
  E.clVersion = function () { return String(CL.v); };
  return api;
})(typeof KoshEngine !== 'undefined' ? KoshEngine : require('./engine.js'));
if (typeof module !== 'undefined' && module.exports) module.exports = KoshReader;
