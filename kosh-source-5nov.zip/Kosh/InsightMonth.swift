import SwiftUI

// MARK: - Insights' month (1 Nov, his ask)
//
// One month for the whole Insights page, picked from a pill at its top: any month kosh has, this month to start. It is
// the same month All shows (Store.ledgerMonth: one month for All and Insights), and every section that is about a month
// reads it from here: the pace, how you paid, where you shop (its span ends there), the month in review, where it goes,
// the category table and Up close (their months end there), and the keep rate (its six months end there). Budgets are
// this month's alone, so they show only on this month.

private struct InsightMonthKey: EnvironmentKey {
    static let defaultValue: String = ""
}

extension EnvironmentValues {
    /// the month Insights is looking at (yyyy-MM); "" means this month
    var insightMonth: String {
        get { self[InsightMonthKey.self] }
        set { self[InsightMonthKey.self] = newValue }
    }
}

enum InsightMonths {
    /// the month to look at: the one picked, when kosh has it, else this month
    static func chosen(_ picked: String, all: [String], cm: String) -> String {
        all.contains(picked) ? picked : cm
    }
    /// n months ending at m, oldest first, of those kosh has
    static func ending(_ m: String, n: Int, all: [String]) -> [String] {
        Array(all.filter { $0 <= m }.sorted().suffix(n))
    }
}

/// the pill: "November ⌄" ("March 2025 ⌄" in another year); its menu has every month kosh has, newest first, under its
/// year (1 Nov: no "This month ·", and the year said once as a heading, not on every month). `tint`: drawn inside a
/// card, in the card's colour (the pace card carries it on its right)
struct InsightMonthMenu: View {
    @Binding var month: String
    let months: [String]
    let cm: String
    var tint: Color? = nil
    var body: some View {
        let newest: [String] = months.sorted(by: >)
        let years: [String] = Self.years(newest)
        let title: String = Self.name(month, cm: cm)
        Menu {
            Picker("Month", selection: $month) {
                ForEach(years, id: \.self) { (y: String) in
                    Section(y) {
                        ForEach(newest.filter { $0.hasPrefix(y) }, id: \.self) { (m: String) in
                            Text(Day.monthName(m)).tag(m)
                        }
                    }
                }
            }
        } label: {
            HStack(spacing: 4) {
                Text(title).font(.subheadline.weight(.semibold)).lineLimit(1)
                Image(systemName: "chevron.down").font(.system(size: 10, weight: .bold))
            }
            .foregroundStyle(tint ?? Color.primary)
            .padding(.horizontal, 12).padding(.vertical, 7)
            .background((tint ?? Color.primary).opacity(tint == nil ? 0.06 : 0.12), in: Capsule())
            .contentShape(Capsule())
        }
        .accessibilityLabel("Month")
        .accessibilityValue(Day.fmt(month + "-01", "MMMM yyyy"))
    }
    /// "November" in this year, "March 2025" in another
    static func name(_ m: String, cm: String) -> String {
        m.prefix(4) == cm.prefix(4) ? Day.monthName(m) : Day.fmt(m + "-01", "MMMM yyyy")
    }
    /// the years the months fall in, newest first
    static func years(_ newest: [String]) -> [String] {
        var out: [String] = []
        for m in newest { let y: String = String(m.prefix(4)); if !out.contains(y) { out.append(y) } }
        return out
    }
}
