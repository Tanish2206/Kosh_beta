import SwiftUI

// MARK: - The tab bar: chosen, ordered and drawn
//
// Four to six tabs, Home always first, and kosh draws the bar itself: its own icons (TabIcons.swift) alone in a
// glass capsule, outline until picked, solid when picked. Slide a finger along the bar and the lozenge lifts and
// follows it, ticking past each tab; let go and that tab opens, the old page easing out one way as the new one eases
// in from the other. Scroll down a page and the bar slims; scroll up and it opens out. Tap the tab you're on to go
// back to its top.

/// Settings › Tab bar: a live bar at the top, the tabs you have (drag to reorder), the ones you could add
struct TabBarEditor: View {
    @Environment(Store.self) private var store
    @Namespace private var fly
    @State private var dragging: AppTab? = nil
    @State private var dragY: CGFloat = 0
    @State private var startIndex: Int = 0
    @State private var shakes: [AppTab: Int] = [:]
    @State private var refused: Int = 0
    @State private var note: String = ""

    static let rowH: CGFloat = 64
    static let gap: CGFloat = 8
    static var step: CGFloat { rowH + gap }

    var body: some View {
        let mine: [AppTab] = store.tabs
        let rest: [AppTab] = AppTab.pinnable.filter { !mine.contains($0) }
        ScrollView {
            VStack(alignment: .leading, spacing: 0) {
                TabBarPreview(tabs: mine, iconsOnly: store.glassBar)
                    .padding(.top, 6)
                CountMeter(count: mine.count, iconsOnly: store.glassBar)
                    .padding(.top, 16)

                HStack(alignment: .firstTextBaseline) {
                    Text("In your tab bar").font(.title3.weight(.semibold))
                    Spacer()
                    Text("Drag ≡ to reorder").font(.footnote).foregroundStyle(.secondary)
                }
                .padding(.top, 30)

                inList(mine)
                    .padding(.top, 12)

                if !note.isEmpty {
                    Label(note, systemImage: "info.circle")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                        .padding(.top, 12)
                        .transition(.opacity.combined(with: .move(edge: .top)))
                }

                if !rest.isEmpty {
                    HStack(alignment: .firstTextBaseline) {
                        Text("Add a tab").font(.title3.weight(.semibold))
                        Spacer()
                        Text(store.canAddTab ? "Room for " + String(AppTab.most - mine.count) + " more" : "The bar is full")
                            .font(.footnote).foregroundStyle(.secondary)
                            .contentTransition(.numericText())
                    }
                    .padding(.top, 30)
                    VStack(spacing: Self.gap) {
                        ForEach(rest) { t in
                            OutRow(t: t, can: store.canAddTab) { add(t) }
                                .matchedGeometryEffect(id: t, in: fly)
                                .modifier(Shake(shakes: CGFloat(shakes[t] ?? 0)))
                                .transition(.opacity)
                        }
                    }
                    .padding(.top, 12)
                }

                Text("What isn't a tab stays one tap away on Home. Slide a finger along the bar to move between them, and tap the one you're on to go back to its top.")
                    .font(.footnote).foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
                    .padding(.top, 12)
            }
            .padding(.horizontal, 20)
            .padding(.bottom, 30)
        }
        .scrollDisabled(dragging != nil)
        .background(Color(uiColor: .systemGroupedBackground))
        .navigationTitle("Tab bar")
        .navigationBarTitleDisplayMode(.inline)
        .sensoryFeedback(.selection, trigger: store.tabs)
        .sensoryFeedback(.warning, trigger: refused)
        .animation(Motion.base, value: note)
    }

    /// the tabs you have, placed by hand so the one you hold follows your finger while the rest make room
    func inList(_ mine: [AppTab]) -> some View {
        let count: Int = mine.count
        let h: CGFloat = CGFloat(count) * Self.step - Self.gap
        return GeometryReader { g in
            let w: CGFloat = g.size.width
            ZStack(alignment: .topLeading) {
                ForEach(mine) { t in
                    let held: Bool = dragging == t
                    let i: Int = mine.firstIndex(of: t) ?? 0
                    let y: CGFloat = held ? Self.heldY(start: startIndex, drag: dragY, count: count) : CGFloat(i) * Self.step
                    InRow(t: t, can: store.canRemoveTab, held: held, remove: { remove(t) }, handle: handle(t))
                        .frame(width: w, height: Self.rowH)
                        .matchedGeometryEffect(id: t, in: fly)
                        .modifier(Shake(shakes: CGFloat(shakes[t] ?? 0)))
                        .scaleEffect(held ? 1.03 : 1)
                        .shadow(color: Color.black.opacity(held ? 0.16 : 0), radius: 14, y: 7)
                        .position(x: w / 2, y: y + Self.rowH / 2)
                        .zIndex(held ? 2 : 0)
                        .transition(.opacity)
                }
            }
        }
        .frame(height: h)
    }

    static func heldY(start: Int, drag: CGFloat, count: Int) -> CGFloat {
        let raw: CGFloat = CGFloat(start) * step + drag
        let top: CGFloat = step - 14
        let bottom: CGFloat = CGFloat(count - 1) * step + 14
        return min(bottom, max(top, raw))
    }

    func handle(_ t: AppTab) -> AnyGesture<DragGesture.Value> {
        AnyGesture(DragGesture(minimumDistance: 0, coordinateSpace: .global)
            .onChanged { v in
                if dragging != t {
                    startIndex = store.tabs.firstIndex(of: t) ?? 1
                    withAnimation(Motion.quick) { dragging = t }
                }
                dragY = v.translation.height
                let target: Int = startIndex + Int((v.translation.height / Self.step).rounded())
                let now: Int = store.tabs.firstIndex(of: t) ?? startIndex
                let to: Int = max(1, min(store.tabs.count - 1, target))
                if to != now {
                    withAnimation(Motion.open) { store.moveTab(t, to: to) }
                }
            }
            .onEnded { _ in
                // it settles into its new place from wherever the finger let go
                withAnimation(Motion.open) { dragging = nil }
            })
    }

    func add(_ t: AppTab) {
        if !store.canAddTab {
            nope(t, "Six is the most a tab bar holds. Take one out to make room.")
            return
        }
        note = ""
        withAnimation(Motion.large) { store.addTab(t) }
    }

    func remove(_ t: AppTab) {
        if !store.canRemoveTab {
            nope(t, "Four is the fewest. Add another first, then take this one out.")
            return
        }
        note = ""
        withAnimation(Motion.large) { store.removeTab(t) }
    }

    func nope(_ t: AppTab, _ why: String) {
        note = why
        refused += 1
        withAnimation(.linear(duration: 0.42)) { shakes[t, default: 0] += 1 }
    }
}

/// a little side-to-side shake for what can't be done
struct Shake: GeometryEffect {
    var shakes: CGFloat
    var animatableData: CGFloat {
        get { shakes }
        set { shakes = newValue }
    }
    func effectValue(size: CGSize) -> ProjectionTransform {
        ProjectionTransform(CGAffineTransform(translationX: 6 * sin(shakes * .pi * 6), y: 0))
    }
}

/// a tab in the bar: take it out on the left, hold the lines on the right to move it
struct InRow: View {
    let t: AppTab
    let can: Bool
    let held: Bool
    let remove: () -> Void
    let handle: AnyGesture<DragGesture.Value>

    var body: some View {
        let home: Bool = t == .home
        HStack(spacing: 12) {
            if home {
                Image(systemName: "lock.fill")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundStyle(.tertiary)
                    .frame(width: 26, height: 26)
            } else {
                Button(action: remove) {
                    Image(systemName: "minus.circle.fill")
                        .font(.system(size: 22))
                        .symbolRenderingMode(.palette)
                        .foregroundStyle(Color.white, can ? Color.red : Color.secondary.opacity(0.45))
                        .frame(width: 26, height: 26)
                }
                .buttonStyle(.press)
                .accessibilityLabel("Take " + t.title + " out of the tab bar")
            }
            IconTile(symbol: t.symbol, color: moduleColor(t), size: 36)
            VStack(alignment: .leading, spacing: 2) {
                Text(t.title).font(.body.weight(.semibold)).foregroundStyle(Color.primary)
                Text(home ? "Always first" : t.blurb).font(.caption).foregroundStyle(.secondary).lineLimit(1)
            }
            Spacer(minLength: 6)
            if !home {
                Image(systemName: "line.3.horizontal")
                    .font(.system(size: 17, weight: .semibold))
                    .foregroundStyle(held ? Color.kosh : Color.secondary)
                    .frame(width: 44, height: 52)
                    .contentShape(Rectangle())
                    .gesture(handle)
                    .accessibilityLabel("Move " + t.title)
            }
        }
        .padding(.leading, 14)
        .padding(.trailing, home ? 14 : 2)
        .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).strokeBorder(Color.kosh.opacity(held ? 0.5 : 0), lineWidth: 1.5))
    }
}

/// a tab you could add
struct OutRow: View {
    let t: AppTab
    let can: Bool
    let add: () -> Void
    var body: some View {
        Button(action: add) {
            HStack(spacing: 12) {
                Image(systemName: "plus.circle.fill")
                    .font(.system(size: 22))
                    .symbolRenderingMode(.palette)
                    .foregroundStyle(Color.white, can ? Color.green : Color.secondary.opacity(0.45))
                    .frame(width: 26, height: 26)
                IconTile(symbol: t.symbol, color: moduleColor(t), size: 36)
                    .saturation(can ? 1 : 0.4)
                VStack(alignment: .leading, spacing: 2) {
                    Text(t.title).font(.body.weight(.semibold)).foregroundStyle(Color.primary)
                    Text(t.blurb).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                }
                Spacer(minLength: 6)
            }
            .padding(.horizontal, 14)
            .frame(height: TabBarEditor.rowH)
            .background(Color(uiColor: .secondarySystemGroupedBackground).opacity(can ? 1 : 0.6), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            .contentShape(Rectangle())
        }
        .buttonStyle(PulsePress())
        .accessibilityLabel("Add " + t.title + " to the tab bar")
    }
}

/// the bar as it will look, on a sliver of screen
struct TabBarPreview: View {
    let tabs: [AppTab]
    let iconsOnly: Bool
    @Environment(\.colorScheme) private var scheme

    var body: some View {
        ZStack(alignment: .bottom) {
            RoundedRectangle(cornerRadius: 30, style: .continuous)
                .fill(LinearGradient(colors: scheme == .dark
                                     ? [Color(hex: "#1C1F2A"), Color(hex: "#11131A")]
                                     : [Color(hex: "#EEF1FB"), Color(hex: "#F8F4EE")],
                                     startPoint: .topLeading, endPoint: .bottomTrailing))
            VStack(alignment: .leading, spacing: 9) {
                Capsule().fill(Color.primary.opacity(0.08)).frame(width: 120, height: 10)
                Capsule().fill(Color.primary.opacity(0.06)).frame(width: 190, height: 8)
                Capsule().fill(Color.primary.opacity(0.05)).frame(width: 150, height: 8)
                Spacer(minLength: 0)
            }
            .padding(.top, 22)
            .padding(.horizontal, 24)
            .frame(maxWidth: .infinity, alignment: .leading)
            BarSample(tabs: tabs, iconsOnly: iconsOnly)
                .padding(.horizontal, 14)
                .padding(.bottom, 14)
        }
        .frame(height: 150)
        .clipShape(RoundedRectangle(cornerRadius: 30, style: .continuous))
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("Your tab bar: " + tabs.map(\.title).joined(separator: ", "))
    }
}

/// the bar itself, drawn small: names under the icons up to five, icons alone at six
struct BarSample: View {
    let tabs: [AppTab]
    let iconsOnly: Bool
    var body: some View {
        HStack(spacing: 0) {
            ForEach(tabs) { t in
                let first: Bool = t == .home
                VStack(spacing: 3) {
                    if iconsOnly {
                        KoshGlyph(tab: t, on: first ? 1 : 0, size: 20)
                    } else {
                        Image(systemName: t.symbol).font(.system(size: 17, weight: first ? .semibold : .regular))
                    }
                    if !iconsOnly {
                        Text(t.title).font(.system(size: 9.5, weight: .medium)).lineLimit(1).minimumScaleFactor(0.6)
                            .transition(.opacity.combined(with: .scale(scale: 0.8)))
                    }
                }
                .foregroundStyle(first ? (iconsOnly ? TabTint.current.chosen : Color.kosh) : Color.primary.opacity(0.82))
                .frame(maxWidth: .infinity)
                .frame(height: iconsOnly ? 44 : 50)
                .background {
                    if first && iconsOnly { Capsule().fill(TabTint.current.pill).padding(.horizontal, 3) }
                }
                .transition(.asymmetric(insertion: .scale(scale: 0.4).combined(with: .opacity), removal: .scale(scale: 0.4).combined(with: .opacity)))
            }
        }
        .padding(4)
        .glassEffect(.regular, in: .capsule)
        .animation(Motion.large, value: tabs)
        .animation(Motion.large, value: iconsOnly)
    }
}

/// four, five or six, and what the bar does at each
struct CountMeter: View {
    let count: Int
    let iconsOnly: Bool
    @Namespace private var dot
    var body: some View {
        HStack(spacing: 12) {
            HStack(spacing: 4) {
                ForEach(Array(AppTab.fewest...AppTab.most), id: \.self) { n in
                    Text(String(n))
                        .font(.system(size: 13, weight: .semibold, design: .rounded))
                        .foregroundStyle(n == count ? Color.onKosh : Color.secondary)
                        .frame(width: 30, height: 26)
                        .background {
                            if n == count { Capsule().fill(Color.koshFill).matchedGeometryEffect(id: "n", in: dot) }
                        }
                }
            }
            .padding(3)
            .background(Color(uiColor: .tertiarySystemFill), in: Capsule())
            VStack(alignment: .leading, spacing: 1) {
                Text(String(count) + " tabs").font(.subheadline.weight(.semibold)).contentTransition(.numericText(value: Double(count)))
                Text(iconsOnly ? "Icons only, so each has room" : "Names under the icons").font(.caption).foregroundStyle(.secondary)
                    .contentTransition(.opacity)
            }
            Spacer(minLength: 0)
        }
        .animation(Motion.large, value: count)
        .animation(Motion.open, value: iconsOnly)
    }
}

/// the editor on its own, opened from Home
struct TabBarSheet: View {
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            TabBarEditor()
                .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } } }
        }
    }
}

// MARK: the bar kosh draws

/// every tab you've been to kept alive, the one you're on in front; the glass bar and the month at the bottom.
/// Switching, the old page eases out towards its side of the bar and the new one eases in from its own, softening
/// and sharpening on the way, rather than either one cutting
struct IconTabs: View {
    @Environment(Store.self) private var store
    @Environment(\.accessibilityVoiceOverEnabled) private var voiceOver
    @State private var seen: Set<AppTab> = []
    @State private var keyboard = false
    /// where the bar's top sits on screen, for a page that has to stop short of it
    @State private var barTop: CGFloat?
    /// the bar slims while you scroll down a page and opens out again as soon as you scroll up (or reach the top or
    /// the end); with VoiceOver on it stays full
    @State private var barAway = false
    /// the scroll bookkeeping (how far the page has moved one way, the last place heard of). Kept in a plain box, not
    /// in view state: it changes on every scroll frame, and as @State each frame re-ran this whole view (every tab)
    @State private var track = ScrollTrack()

    var body: some View {
        let order: [AppTab] = store.tabs
        let here: Int = order.firstIndex(of: store.tab) ?? 0
        ZStack {
            ForEach(store.tabs) { t in
                if seen.contains(t) || store.tab == t {
                    let on: Bool = store.tab == t
                    // a page left of the one you're on waits (and leaves) to the left, one right of it to the right
                    let side: CGFloat = (order.firstIndex(of: t) ?? 0) < here ? -1 : 1
                    TabRoot(tab: t)
                        .environment(\.tabActive, on)
                        .environment(\.barTop, keyboard ? nil : barTop)
                        // pages with a sub-tab row hand their own scroll on (barFollows); the rest are read here
                        .environment(\.barFollow, BarFollow(tab: t) { old, new in if store.tab == t { follow(old, new) } })
                        // pages that hand their own scroll on (barFollows) aren't listened to here as well: two listeners
                        // over one page, each finding several scroll views, worked (and logged) on every scroll frame
                        .modifier(PageScrollFollow(on: !Self.followsItself.contains(t)) { old, new in
                            if store.tab == t { follow(old, new) }
                        })
                        // only these move, so nothing inside a page animates along with the switch. Opacity and a
                        // drift only: both are done by the compositor, where a blur or scale over a whole page (charts,
                        // live views) had to redraw it every frame and stuttered. The page you pick glides in from its
                        // side of the bar (350 ms, smooth-out); the one you leave slips the other way and fades in 150
                        .animation(on ? Motion.open : Motion.quick) { v in
                            v.opacity(on ? 1 : 0)
                                .offset(x: on ? 0 : side * 28)
                        }
                        .allowsHitTesting(on)
                        .accessibilityHidden(!on)
                        .transition(.opacity.combined(with: .offset(x: side * 10)))
                }
            }
        }
        .safeAreaInset(edge: .bottom, spacing: 0) {
            if !keyboard {
                GlassEffectContainer(spacing: 8) {
                    VStack(spacing: 8) {
                        // while kosh reads, how far it has got; Chapters keeps its own button just above the bar, so it
                        // steps aside there, and it makes way while the bar is slim
                        // (smooth-5nov) while the bar is slim the pulse fades and drifts down but keeps its room, and the
                        // slim bar sits in the full bar's room: this inset is every page's bottom safe area, and changing it
                        // mid-scroll (bar 56 → 46, pulse ±52) re-laid out the whole page on every frame of the animation
                        if store.tab != .chapters && store.readingShown {
                            MonthPulse()
                                .frame(height: 44)
                                .glassEffect(.regular.interactive(), in: .capsule)
                                .opacity(barAway ? 0 : 1)
                                .offset(y: barAway ? 10 : 0)
                                .allowsHitTesting(!barAway)
                                .transition(.blurReplace)
                        }
                        GlassTabBar(slim: barAway) { bar(away: false) }
                            .frame(height: 56, alignment: .bottom)
                    }
                    .animation(Motion.base, value: store.tab == .chapters)
                    .animation(Motion.base, value: store.readingShown)
                }
                .padding(.horizontal, 18)
                .onGeometryChange(for: CGFloat.self) { g in g.frame(in: .global).minY } action: { y in barTop = y }
                // the Transactions day lens takes the bottom edge while you scroll down: the bar steps out of its way
                .modifier(LensVeilStep())
                .transition(.move(edge: .bottom).combined(with: .opacity))
            }
        }
        .onChange(of: store.tab, initial: true) { _, t in
            seen.insert(t)
            // leaving Transactions, the bar comes straight back
            if LensVeil.shared.up { LensVeil.shared.up = false }
            bar(away: false)
        }
        // every tab in the bar is built once kosh has settled, one at a time, so a tap only ever shows a page that's
        // already there (building one in the same frame as the switch was a visible hitch)
        .task(id: store.tabs) {
            try? await Task.sleep(for: .milliseconds(1200))
            for t in store.tabs where !seen.contains(t) {
                seen.insert(t)
                try? await Task.sleep(for: .milliseconds(350))
            }
        }
        .onReceive(NotificationCenter.default.publisher(for: UIResponder.keyboardWillShowNotification)) { _ in
            withAnimation(Motion.quick) { keyboard = true }
        }
        .onReceive(NotificationCenter.default.publisher(for: UIResponder.keyboardWillHideNotification)) { _ in
            withAnimation(Motion.base) { keyboard = false }
        }
    }
}

/// switching sub-tab: the new page drifts in from the side you moved towards as the old one slips away and fades.
/// Opacity and a drift only, both on the compositor, so a heavy page never stutters through it. Arriving takes 350 ms
/// (smooth-out), leaving 150, never a bounce
struct SubSlide<T: SubTab>: ViewModifier {
    let sub: T
    @State private var last: Int? = nil
    func body(content: Content) -> some View {
        let i: Int = T.allCases.firstIndex(of: sub) ?? 0
        let side: CGFloat = i >= (last ?? i) ? 1 : -1
        ZStack {
            content
                .id(sub)
                .transition(.asymmetric(insertion: .opacity.combined(with: .offset(x: side * 22)).animation(Motion.open),
                                        removal: .opacity.combined(with: .offset(x: -side * 12)).animation(Motion.quick)))
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
        .animation(Motion.open, value: sub)
        .onChange(of: sub, initial: true) { _, s in last = T.allCases.firstIndex(of: s) ?? 0 }
    }
}

extension View {
    func subSlide<T: SubTab>(_ sub: T) -> some View { modifier(SubSlide(sub: sub)) }
}

/// the scroll listener for a page that doesn't hand its own scroll on
struct PageScrollFollow: ViewModifier {
    let on: Bool
    let run: (ScrollSpot, ScrollSpot) -> Void
    func body(content: Content) -> some View {
        if on {
            content.onScrollGeometryChange(for: ScrollSpot.self) { g in ScrollSpot(g) } action: { old, new in run(old, new) }
        } else {
            content
        }
    }
}

extension IconTabs {
    /// the tabs whose pages call barFollows themselves (Home, Transactions, Wealth, Property)
    static let followsItself: Set<AppTab> = [.home, .transactions, .portfolio, .property]

    /// a page moved: down far enough and the bar slims, up a little and it opens out again
    func follow(_ old: ScrollSpot, _ new: ScrollSpot) {
        if new == track.last { return }
        track.last = new
        // (smooth-5nov-b) while the day lens is up the bar is stepped away: the list moving under it changes nothing
        if LensVeil.shared.up { track.run = 0; return }
        // a row scrolled sideways (months, pills) says nothing about the page
        if new.sideways { return }
        guard !voiceOver, new.tall else { bar(away: false); return }
        // at the top, or the end of the page: the bar's there
        if new.y < 40 || new.y > new.room - 24 { track.run = 0; bar(away: false); return }
        let dy: CGFloat = new.y - old.y
        if dy == 0 { return }
        if (dy > 0) != (track.run > 0) { track.run = 0 }
        track.run += dy
        if track.run > 32 { bar(away: true) } else if track.run < -16 { bar(away: false) }
    }

    func bar(away: Bool) {
        guard away != barAway else { return }
        // it slims quickly and opens out a little slower, never bouncing
        withAnimation(away ? Motion.open : Motion.large) { barAway = away }
    }
}

/// where a page is scrolled to, and how far it can go
struct ScrollSpot: Equatable {
    let y: CGFloat
    let room: CGFloat
    /// long enough to be worth hiding the bar for
    let tall: Bool
    /// a row that scrolls sideways, not the page
    let sideways: Bool
    init(_ g: ScrollGeometry) {
        y = g.contentOffset.y + g.contentInsets.top
        room = g.contentSize.height + g.contentInsets.top + g.contentInsets.bottom - g.containerSize.height
        tall = room > 120
        sideways = g.contentSize.width > g.containerSize.width + 1 && room <= 1
    }
}

/// kosh's own tab bar, told where a page has scrolled to. Equal for the same tab, so the bar's every move (and every
/// tab switch) doesn't redraw the pages behind it (the bar's state lives in its own storage: an earlier copy still reaches it)
struct BarFollow: Equatable {
    let tab: AppTab
    let run: (ScrollSpot, ScrollSpot) -> Void
    func callAsFunction(_ old: ScrollSpot, _ new: ScrollSpot) { run(old, new) }
    static func == (a: BarFollow, b: BarFollow) -> Bool { a.tab == b.tab }
}

private struct BarFollowKey: EnvironmentKey {
    static var defaultValue: BarFollow? { nil }
}

extension EnvironmentValues {
    /// kosh's own tab bar, told where a page has scrolled to
    var barFollow: BarFollow? {
        get { self[BarFollowKey.self] }
        set { self[BarFollowKey.self] = newValue }
    }
}

/// a page's scroll moves kosh's own tab bar: away while you scroll down, back as you scroll up
struct BarFollows: ViewModifier {
    @Environment(\.barFollow) private var barFollow
    func body(content: Content) -> some View {
        content.onScrollGeometryChange(for: ScrollSpot.self) { g in ScrollSpot(g) } action: { old, new in
            barFollow?.run(old, new)
        }
    }
}

extension View {
    func barFollows() -> some View { modifier(BarFollows()) }
}

private struct TabActiveKey: EnvironmentKey {
    static var defaultValue: Bool { true }
}

extension EnvironmentValues {
    /// whether the page's tab is the one on screen. kosh keeps every tab you've visited alive behind the one you're on
    /// (so switching back is instant); a page behind another rests its animations and timers on this
    var tabActive: Bool {
        get { self[TabActiveKey.self] }
        set { self[TabActiveKey.self] = newValue }
    }
}

private struct BarTopKey: EnvironmentKey {
    static var defaultValue: CGFloat? { nil }
}

extension EnvironmentValues {
    /// the top of kosh's own tab bar on screen (nil under the system's bar, which pages already clear)
    var barTop: CGFloat? {
        get { self[BarTopKey.self] }
        set { self[BarTopKey.self] = newValue }
    }
}

/// icons alone: outline until chosen, then solid and tinted, over a lozenge. Press and slide along the bar and the
/// lozenge lifts and follows the finger, the icon under it filling in, a tick at each tab; let go and that tab opens
struct GlassTabBar: View {
    @Environment(Store.self) private var store
    let slim: Bool
    /// a touch on the bar opens it out if it was slim
    let wake: () -> Void
    @State private var bumps: [AppTab: Int] = [:]
    @State private var width: CGFloat = 0
    /// where the finger is while it's on the bar, counted in tabs (1.5 is between the second and the third)
    @State private var finger: CGFloat?
    /// the tab under the finger
    @State private var hover: Int?

    var body: some View {
        let tabs: [AppTab] = store.tabs
        let n: Int = max(tabs.count, 1)
        let here: CGFloat = CGFloat(tabs.firstIndex(of: store.tab) ?? 0)
        let p: CGFloat = finger ?? here
        let held: Bool = finger != nil
        HStack(spacing: 0) {
            ForEach(Array(tabs.enumerated()), id: \.element) { i, t in
                let near: CGFloat = max(0, 1 - abs(p - CGFloat(i)))
                // under the finger an icon swells like it's under a lens, its neighbours a little, easing as it passes
                GlassTabItem(t: t, on: near, zoom: held ? 1 + 0.38 * near * near : 1, held: held, bump: bumps[t] ?? 0, slim: slim) { select(t) }
            }
        }
        .background(alignment: .leading) {
            GeometryReader { g in
                let w: CGFloat = g.size.width / CGFloat(n)
                Capsule()
                    .fill(held ? Color.primary.opacity(0.10) : TabTint.current.pill)
                    .overlay(Capsule().strokeBorder(Color.white.opacity(held ? 0.22 : 0), lineWidth: 0.8))
                    .shadow(color: Color.black.opacity(held ? 0.18 : 0), radius: 10, y: 4)
                    .padding(.horizontal, 2)
                    .frame(width: w, height: g.size.height)
                    .scaleEffect(held ? 1.14 : 1)
                    .offset(x: p * w)
            }
        }
        // under the finger it tracks closely; let go and it settles into place
        .animation(held ? .interactiveSpring(response: 0.16, dampingFraction: 0.88) : .spring(response: 0.4, dampingFraction: 0.82), value: p)
        .animation(Motion.base, value: held)
        .onGeometryChange(for: CGFloat.self) { g in g.size.width } action: { w in width = w }
        .contentShape(Capsule())
        .gesture(DragGesture(minimumDistance: 0)
            .onChanged { v in
                guard width > 0 else { return }
                if finger == nil { wake() }
                let w: CGFloat = width / CGFloat(n)
                finger = min(max(v.location.x / w - 0.5, 0), CGFloat(n - 1))
                hover = min(max(Int(v.location.x / w), 0), n - 1)
            }
            .onEnded { _ in
                let i: Int = hover ?? Int(here)
                hover = nil
                finger = nil
                if i >= 0 && i < tabs.count { select(tabs[i]) }
            })
        .padding(slim ? 3 : 4)
        .frame(maxWidth: slim ? 300 : .infinity)
        .glassEffect(.regular.interactive(), in: .capsule)
        .sensoryFeedback(.selection, trigger: hover) { _, new in new != nil }
        .onChange(of: store.tab) { _, t in bumps[t, default: 0] += 1 }
    }

    func select(_ t: AppTab) {
        if store.tab == t {
            if store.pathCount(t) > 0 { withAnimation(Motion.open) { store.setPath(t, []) } }
            bumps[t, default: 0] += 1
        } else {
            // no withAnimation here: the pages animate their own switch (IconTabs), and an app-wide animation made
            // everything that reads the tab move with it
            store.tab = t
        }
    }
}

/// how a chosen tab is marked (5 Nov 2026: the blue accent read as a default; ink is the default now). Change
/// `current` to try another
enum TabTint {
    case ink, solid, gold, accent
    static let current: TabTint = .ink

    /// the chosen icon
    var chosen: Color {
        switch self {
        case .ink: return Color.primary
        case .solid: return Color(uiColor: .systemBackground)
        case .gold: return TabTint.goldInk
        case .accent: return Color.kosh
        }
    }
    /// the lozenge under it
    var pill: Color {
        switch self {
        case .ink: return Color.primary.opacity(0.09)
        case .solid: return Color.primary.opacity(0.92)
        case .gold: return TabTint.goldInk.opacity(0.16)
        case .accent: return Color.kosh.opacity(0.13)
        }
    }
    static let idle: Color = Color.primary.opacity(0.55)
    static let goldInk: Color = Color(uiColor: UIColor { t in
        t.userInterfaceStyle == .dark
            ? UIColor(red: 0.85, green: 0.72, blue: 0.48, alpha: 1)
            : UIColor(red: 0.62, green: 0.47, blue: 0.25, alpha: 1)
    })
}

struct GlassTabItem: View {
    let t: AppTab
    /// 1 on this tab, 0 a tab or more away, between while the finger passes
    let on: CGFloat
    /// how much it swells while the finger is near it
    var zoom: CGFloat = 1
    /// a finger on the bar: the lifted lozenge is light, so the chosen icon is drawn in ink whatever the tint
    var held: Bool = false
    let bump: Int
    let slim: Bool
    let tap: () -> Void
    var body: some View {
        let chosen: Bool = on > 0.5
        KoshGlyph(tab: t, on: on, size: slim ? 21 : 24)
            .foregroundStyle(chosen ? (held ? Color.primary : TabTint.current.chosen) : TabTint.idle)
            .keyframeAnimator(initialValue: CGFloat(1), trigger: bump) { content, s in
                content.scaleEffect(s)
            } keyframes: { _ in
                CubicKeyframe(0.82, duration: 0.08)
                SpringKeyframe(1, duration: 0.4, spring: .bouncy)
            }
            .scaleEffect(zoom)
            .offset(y: (1 - zoom) * 6)
            .frame(maxWidth: .infinity)
            .frame(height: slim ? 40 : 48)
            .contentShape(Rectangle())
            // the bar's own gesture does the touching; VoiceOver gets a button per tab
            .accessibilityElement()
            .accessibilityLabel(t.title)
            .accessibilityAddTraits(chosen ? [.isButton, .isSelected] : [.isButton])
            .accessibilityAction { tap() }
            .accessibilityShowsLargeContentViewer { Label(t.title, systemImage: t.symbol) }
    }
}


/// the bar stepping down out of the day lens's way (compositor-only: an offset and a fade). Its own modifier, so the
/// lens coming and going redraws only the bar, never the pages behind it
struct LensVeilStep: ViewModifier {
    func body(content: Content) -> some View {
        let up: Bool = LensVeil.shared.up
        content
            .offset(y: up ? 140 : 0)
            .opacity(up ? 0 : 1)
            .allowsHitTesting(!up)
            .animation(up ? Motion.base : Motion.open, value: up)
    }
}


/// per-frame scroll bookkeeping for the tab bar: a reference no view observes, so writing it redraws nothing
final class ScrollTrack {
    var run: CGFloat = 0
    var last: ScrollSpot? = nil
}
