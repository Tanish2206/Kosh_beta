import SwiftUI

// MARK: - What kosh knows: your data, where it is, what has left the phone, and how to take it back
//
// India's data protection rules give everyone the right to a summary of the data an app holds about them and of
// whom it went to, to correct or erase it, and to name someone who can act for them. kosh holds everything on this
// phone, so the summary is counts read off the phone itself; the only thing that ever leaves it is what smart reading
// sends (masked), and that's counted too.

struct YourDataView: View {
    @Environment(Store.self) private var store
    @AppStorage("privacy.nominee") private var nominee = ""
    @State private var confirmErase = false
    /// how many people have details typed for them: counted once when the page opens, never per body pass (each
    /// person is a Keychain read, and the Keychain is slow enough to be felt while scrolling)
    @State private var typed: Int = 0

    var body: some View {
        let live: LiveSession? = store.live
        let records: [Reading] = live?.records ?? []
        let people: [PersonInfo] = (live?.people ?? []).filter { $0.id != "me" }
        let smart: Int = records.count(where: { $0.claude != nil || $0.cl != nil })
        let smartOn: Bool = (live?.checkMode ?? "off") != "off"
        List {
            Section {
                row("envelope", .blue, "Emails read", Fmt.inr(Double(records.count(where: { !$0.id.hasPrefix(AlertIntake.prefix) }))))
                row("message", .green, "Payments by SMS or notification", Fmt.inr(Double(records.count(where: { $0.id.hasPrefix(AlertIntake.prefix) }))))
                row("doc.text", .green, "Statements opened", Fmt.inr(Double(live?.statements.count ?? 0)))
                row("person.2", .orange, "Family members", Fmt.inr(Double(people.count)))
                row("person.text.rectangle", .indigo, "People with details you typed", Fmt.inr(Double(typed)))
                row("tray.full", .gray, "Inboxes connected", Fmt.inr(Double(live?.allAccounts.count ?? 0)))
            } header: { Text("On this phone") } footer: {
                Text("All of it is read and stored on this phone, encrypted by iOS. kosh has no server, so none of it is anywhere else.")
            }
            Section {
                row("sparkles", .purple, "Smart reading", smartOn ? "On" : "Off")
                row("arrow.up.right.circle", .purple, "Emails it has read", Fmt.inr(Double(smart)))
            } header: { Text("What has left the phone") } footer: {
                Text(smartOn
                     ? "Smart reading sends the emails the rules can’t read to an AI service, with names and long numbers masked. Turn it off in Settings › Reading."
                     : "Nothing. Smart reading is off; if you turn it on, emails the rules can’t read go to an AI service with names and long numbers masked." + (smart > 0 ? " The count above is from when it was on." : ""))
            }
            Section {
                TextField("Name and phone or email", text: $nominee)
                    .textContentType(.name).autocorrectionDisabled()
            } header: { Text("Someone who can act for you") } footer: {
                Text("If you can’t, they may ask for your data to be erased. Kept on this phone only.")
            }
            Section {
                Button("Erase everything kosh read", role: .destructive) { confirmErase = true }
            } footer: {
                Text("Ends kosh’s access to your Gmail at Google and deletes everything kosh read or you typed, from this phone. To correct something, open it and change it; what you change stands.")
            }
            .confirmationDialog("Erase everything kosh read?", isPresented: $confirmErase, titleVisibility: .visible) {
                Button("Erase", role: .destructive) { nominee = ""; store.erase() }
            } message: {
                Text("Everything read from your mail and everything you added go from this phone, and Google’s access ends. This can’t be undone.")
            }
        }
        .navigationTitle("What kosh knows")
        .navigationBarTitleDisplayMode(.inline)
        .task {
            let ids: [String] = ["me"] + ((store.live?.people ?? []).filter { $0.id != "me" }).map(\.id)
            typed = ids.filter { PasswordProfile.load(for: $0) != nil }.count
        }
    }

    func row(_ sym: String, _ color: Color, _ title: String, _ value: String) -> some View {
        HStack(spacing: 12) {
            IconTile(symbol: sym, color: color, size: 30)
            Text(title)
            Spacer(minLength: 8)
            Text(value).foregroundStyle(.secondary).monospacedDigit()
        }
    }
}
