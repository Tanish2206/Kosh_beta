import SwiftUI

// MARK: - Tenants: the street at dusk on top, lit by this month's rent (islands when your properties are in more than
// one state); under it, the month's rent in and late. Tap a state's island to fly to it, a building to fly in to
// it; under the tile its tenants then open one at a time: this month's rent with Mark received and a nudge ready,
// the year in twelve windows, the lease, the deposit and the agreement.

enum RentInk {
    static let good = Color(hex: "#34C759")
    static let goodDeep = Color(light: "#1A7A43", dark: "#5FD38A")
    static let goodHead = Color(light: "#1E8F4E", dark: "#4CD07D")
    static let late = Color(hex: "#FF6B57")
    static let lateDeep = Color(light: "#C2361F", dark: "#FF8A75")
    static let due = Color(hex: "#FF9F0A")
    static let dueDeep = Color(light: "#A35A00", dark: "#FFB04D")
    static let grey = Color(light: "#6B6B73", dark: "#98989F")
    static let paper = Color.raised
    /// a lit window's gold, deep enough on white by day; and its words
    static let lit = Color(light: "#F2B01E", dark: "#FFD66B")
    static let litDeep = Color(light: "#8A6400", dark: "#FFD66B")
    /// the dusk's peach, for a heading under the tile
    static let peach = Color(light: "#9A5B2E", dark: "#FFD9A8")
    /// a month's rent in words' ink: in, late, due, or anything else
    static func deep(_ st: String) -> Color {
        switch st {
        case "booked": return goodDeep
        case "late": return lateDeep
        case "due": return dueDeep
        default: return grey
        }
    }
}

struct TenantsView: View {
    @Environment(Store.self) private var store
    @Environment(\.accessibilityReduceMotion) private var still

    struct Let: Identifiable { let p: Prop; let u: PropUnit; var id: String { p.pid + "|" + (p.uid ?? "") + "|" + u.id + "|" + String(u.idx ?? 0) } }

    static func lets(_ P: PropertyBook) -> [Let] {
        P.props.flatMap { p in p.units.filter { ($0.status ?? "") == "let" || !$0.tenant.isEmpty }.map { Let(p: p, u: $0) } }
    }
    /// late first (the longest late at the top), then due, then the rest by rent
    static func before(_ a: Let, _ b: Let) -> Bool {
        let ra: Int = rank(a), rb: Int = rank(b)
        if ra != rb { return ra < rb }
        if ra == 0 { return (a.u.now?.late ?? 0) > (b.u.now?.late ?? 0) }
        return a.u.rent > b.u.rent
    }
    static func rank(_ l: Let) -> Int {
        switch l.u.now?.st ?? "" {
        case "late": return 0
        case "due": return 1
        default: return 2
        }
    }

    /// where the camera is: the whole street (or every state), one state's island, or one building
    @State private var level: IsoLevel = .all
    /// the island and the building last flown to: kept while flying back out, so they settle back in place
    @State private var isle: String?
    @State private var house: String?
    /// the building's tenants' tags, up once the flight in has settled
    @State private var tags = false
    /// the tenant whose row is open under the building
    @State private var row: String?

    /// the camera flies in on the motion scale's longest step, and back out a step quicker
    static let flyIn: Animation = Motion.reveal
    static let flyOut: Animation = Motion.large
    /// what's under the tile comes up once the camera is nearly there, and goes at once
    static let arrive: AnyTransition = .asymmetric(
        insertion: AnyTransition.opacity.combined(with: .offset(y: 12)).animation(Motion.large.delay(0.25)),
        removal: AnyTransition.opacity.animation(Motion.quick))

    var body: some View {
        let P: PropertyBook = store.propBook(store.who)
        let lets: [Let] = Self.lets(P).sorted(by: Self.before)
        let houses: [StreetHouse] = Street.houses(P)
        let world: IsoWorld = IsoWorld(houses)
        ScrollViewReader { proxy in
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    if lets.isEmpty {
                        if store.live != nil {
                            let first: Prop? = P.props.first
                            BetaEmpty(sym: "person.2.fill", title: "No tenants yet",
                                      text: "Mark a floor as let out, with the tenant, the rent and the day it’s due. kosh lights it up as the rent comes in.",
                                      add: P.props.isEmpty ? "Add a property" : "Add a tenant") {
                                store.betaSheet = .property(first.map { $0.uid ?? $0.pid })
                            }
                        } else {
                            ContentUnavailableView("No tenants", systemImage: "person.2", description: Text("Floors you let out show here."))
                        }
                    } else {
                        PlanStack(.propTenants, spacing: 18) { id in
                            switch id {
                            case "street": tile(world, tenants: lets.count, proxy: proxy)
                            case "rent": panel(world, lets: lets, proxy: proxy)
                            default: EmptyView()
                            }
                        }
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 14)
                .padding(.bottom, 36)
            }
        }
        .onChange(of: world.isles.map(\.id) + houses.map(\.id)) { _, ids in
            // what was flown to went away (a property removed, or moved to another state): back to the street
            let gone: Bool = (level == .house && !ids.contains(house ?? "")) || (level == .isle && !ids.contains(isle ?? ""))
            if gone { level = .all; tags = false; row = nil }
        }
    }

    func tile(_ world: IsoWorld, tenants: Int, proxy: ScrollViewProxy) -> some View {
        StreetTile(world: world, tenants: tenants, level: level, isle: isle, house: house, tags: tags, still: still,
                   pickIsle: { s in fly(.isle, isle: s) },
                   pickHouse: { h in fly(.house, isle: world.index(house: h).map { world.isles[$0].id }, house: h) },
                   back: { back(world) },
                   open: { l in show(l, proxy) },
                   more: { withAnimation(still ? nil : Motion.reveal) { proxy.scrollTo(BuildingRent.anchor, anchor: .top) } })
    }

    /// under the tile: the month's rent for everything, for a state, or the building's own tenants
    @ViewBuilder func panel(_ world: IsoWorld, lets: [Let], proxy: ScrollViewProxy) -> some View {
        let here: StreetHouse? = level == .house ? world.isles.flatMap(\.houses).first(where: { $0.id == house }) : nil
        let state: IsoWorld.Isle? = level == .isle ? world.isles.first(where: { $0.id == isle }) : nil
        if let here {
            let to: String = world.many ? Street.stateName(isle ?? "") : "the street"
            BuildingRent(house: here, row: $row, backTo: to) { back(world) }
                .id("house|" + here.id)
                .transition(Self.arrive)
        } else if let state {
            StateRent(isle: state) { h in fly(.house, isle: state.id, house: h) } back: { back(world) }
                .id("isle|" + state.id)
                .transition(Self.arrive)
        } else {
            RentSummary(world: world, lets: lets) { s in fly(.isle, isle: s) } late: { firstLate(world, proxy) }
                .transition(Self.arrive)
        }
    }

    /// fly the camera to a level; once in at a building, its tags go up (and a row opens, when asked for)
    func fly(_ to: IsoLevel, isle i: String? = nil, house h: String? = nil, open r: String? = nil, proxy: ScrollViewProxy? = nil) {
        if tags { withAnimation(Motion.quick) { tags = false } }
        if let i { isle = i }
        if let h { house = h }
        row = to == .house ? r : nil
        let settle: () -> Void = {
            guard level == to, to == .house else { return }
            withAnimation(still ? nil : Motion.open) { tags = true }
            if let r, let proxy {
                withAnimation(still ? nil : Motion.reveal) { proxy.scrollTo(TenantRow.anchor(r), anchor: UnitPoint(x: 0.5, y: 0.15)) }
            }
        }
        if still {
            level = to
            settle()
            return
        }
        withAnimation(to.rawValue > level.rawValue ? Self.flyIn : Self.flyOut) { level = to } completion: { settle() }
    }

    /// one level back out: from a building to its state (or the street), from a state to all of them
    func back(_ world: IsoWorld) {
        fly(level == .house && world.many ? .isle : .all)
    }

    /// a tag on the building: its tenant's row opens below, scrolled into view
    func show(_ l: Let, _ proxy: ScrollViewProxy) {
        withAnimation(Motion.large) { row = l.id }
        Task { @MainActor in
            try? await Task.sleep(for: .milliseconds(140))
            withAnimation(still ? nil : Motion.reveal) { proxy.scrollTo(TenantRow.anchor(l.id), anchor: UnitPoint(x: 0.5, y: 0.15)) }
        }
    }

    /// "Glowing red, late": straight to the building with the longest-late rent, its row open
    func firstLate(_ world: IsoWorld, _ proxy: ScrollViewProxy) {
        var best: (isle: String, house: String, l: Let)?
        for s in world.isles {
            for h in s.houses {
                for l in h.lets where l.u.now?.st == "late" && (l.u.now?.late ?? 0) > (best?.l.u.now?.late ?? -1) {
                    best = (s.id, h.id, l)
                }
            }
        }
        if let best { fly(.house, isle: best.isle, house: best.house, open: best.l.id, proxy: proxy) }
    }
}

struct TenantTile: View {
    let cap: String
    let value: String
    var tone: Color = Color.primary
    var money: Bool = false
    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(cap.uppercased()).font(.system(.caption2, weight: .bold)).tracking(0.6).foregroundStyle(RentInk.grey).lineLimit(1)
            Text(value)
                .font(.system(.subheadline, design: money ? Font.Design.rounded : Font.Design.default, weight: .semibold))
                .monospacedDigit()
                .foregroundStyle(tone)
                .lineLimit(1).minimumScaleFactor(0.7)
                .privacySensitive()
        }
        .padding(.vertical, 9)
        .padding(.horizontal, 10)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(RentInk.paper, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
    }
}


/// where this month's rent stands, said plainly, with what you can do about it
struct RentStrip: View {
    @Environment(Store.self) private var store
    let p: Prop
    let u: PropUnit
    let n: RollMonth

    var dueDay: String { (n.due ?? "").count == 10 ? Day.fmt(n.due ?? "", "d MMM") : "" }
    var month: String { Day.monthName(n.m) }
    var marked: Bool { n.got == "marked" }

    var title: String {
        switch n.st {
        case "booked": return marked ? "Received" : "Received " + Day.fmt(n.got ?? "", "d MMM")
        case "late":
            let d: Int = n.late ?? 0
            return d > 0 ? String(d) + (d == 1 ? " day late" : " days late") : "Late"
        case "due": return dueDay.isEmpty ? "Not here yet" : "Due " + dueDay
        case "upcoming": return dueDay.isEmpty ? "Next rent to come" : "Next rent due " + dueDay
        default: return u.start > n.m ? "Lease starts " + Day.fmt(u.start + "-01", "MMM yyyy") : "Nothing to collect"
        }
    }
    var line: String {
        switch n.st {
        case "booked":
            if marked { return month + "’s rent · you marked it" }
            var s: String = "From " + ((n.from ?? "").isEmpty ? "the tenant" : n.from!)
            // (rent you tagged on the payment, or kosh's proposal from your tag)
            if n.tag == "yours" { s += ", tagged by you" } else if n.tag == "learnt" { s += ", learnt from your tag" }
            if let t = n.tx, !t.isEmpty, let x = store.txn(t) {
                let how: String = Self.how(x.md ?? "")
                if !how.isEmpty { s += ", " + how }
            }
            if let a = n.fromAmt, a > 0, abs(a - u.rent) >= 1 { s += " · " + Fmt.rupees(a) }
            return s
        case "late": return dueDay.isEmpty ? month + "’s rent never came" : month + "’s rent was due " + dueDay
        case "due": return month + "’s rent"
        default: return ""
        }
    }
    static func how(_ md: String) -> String {
        switch md {
        case "upi": return "by UPI"
        case "transfer": return "by bank transfer"
        case "cash": return "in cash"
        case "card": return "by card"
        case "wallet": return "from a wallet"
        default: return ""
        }
    }
    var ink: Color {
        switch n.st {
        case "booked": return RentInk.good
        case "late": return RentInk.late
        case "due": return RentInk.due
        default: return Color(hex: "#8E8E93")
        }
    }
    var sym: String {
        switch n.st {
        case "booked": return "checkmark"
        case "late": return "exclamationmark"
        case "due": return "clock"
        default: return "calendar"
        }
    }

    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: sym)
                .font(.system(size: 10.5, weight: .heavy))
                .foregroundStyle(Color.white)
                .frame(width: 22, height: 22)
                .background(ink, in: Circle())
            VStack(alignment: .leading, spacing: 1) {
                Text(title).font(.system(.subheadline, weight: .semibold)).foregroundStyle(RentInk.deep(n.st))
                    .lineLimit(1).minimumScaleFactor(0.85)
                if !line.isEmpty {
                    Text(line).font(.system(.caption)).foregroundStyle(.secondary)
                        .lineLimit(2).fixedSize(horizontal: false, vertical: true).privacySensitive()
                }
            }
            Spacer(minLength: 6)
            // the button keeps its words on one line; the words beside it wrap instead
            if store.live != nil { action.fixedSize().layoutPriority(1) }
        }
        .padding(.vertical, 10)
        .padding(.leading, 12)
        .padding(.trailing, 10)
        .background(RentInk.paper, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        .sensoryFeedback(.success, trigger: n.st)
    }

    @ViewBuilder var action: some View {
        let tx: String = n.tx ?? ""
        if n.st == "booked" {
            if marked {
                Button("Undo") { toggle() }.font(.system(.footnote, weight: .semibold)).padding(.horizontal, 6)
            } else if !tx.isEmpty {
                Menu {
                    Button("That credit wasn’t rent", systemImage: "xmark.circle", role: .destructive) {
                        withAnimation(Motion.open) { store.live?.notRent(property: p.uid ?? p.pid, unit: u.idx ?? 0, tx: tx) }
                    }
                } label: {
                    Text("Not rent?").font(.system(.footnote, weight: .semibold)).padding(.horizontal, 6).frame(minHeight: 34)
                }
            }
        } else if n.st == "late" || n.st == "due" {
            let hot: Bool = n.st == "late"
            Button { toggle() } label: {
                Text("Mark received")
                    .font(.system(.footnote, weight: .semibold))
                    .lineLimit(1)
                    .foregroundStyle(hot ? Color.white : Color.kosh)
                    .padding(.horizontal, 14)
                    .frame(minHeight: 34)
                    .background(hot ? RentInk.late : Color.kosh.opacity(0.12), in: Capsule())
            }
            .buttonStyle(.press)
        }
    }
    func toggle() {
        withAnimation(Motion.open) { store.markRent(property: p.uid ?? p.pid, unit: u.idx ?? 0, month: n.m) }
    }
}


/// how far through the lease: when it began, how long is left (amber when it's time to renew), when it ends
struct LeaseBar: View {
    let start: String
    let end: String
    let now: String
    @State private var grow = false

    static func left(_ n: Int) -> String {
        if n <= 0 { return "Lease ended" }
        if n == 1 { return "Last month" }
        if n < 24 { return String(n) + " months left" }
        return String(n / 12) + (n % 12 >= 6 ? "½" : "") + " years left"
    }

    /// the bar's two inks: red once the lease has run out, amber in its last three months, blue before
    static func colors(left: Int, soon: Bool) -> [Color] {
        if left <= 0 { return [Color(hex: "#FFB2A6"), RentInk.late] }
        if soon { return [Color(hex: "#FFD08A"), RentInk.due] }
        return [Color(hex: "#9DB3FF"), Color.kosh]
    }

    var body: some View {
        let total: Int = max(1, monthsBetween(start, end) + 1)
        let done: Int = min(total, max(0, monthsBetween(start, now) + 1))
        let left: Int = monthsBetween(now, end) + 1
        let soon: Bool = left > 0 && left <= 3
        let tint: Color = left <= 0 ? RentInk.late : soon ? RentInk.due : Color.kosh
        let colors: [Color] = Self.colors(left: left, soon: soon)
        let frac: CGFloat = CGFloat(done) / CGFloat(total)
        VStack(spacing: 7) {
            HStack(alignment: .firstTextBaseline) {
                Text(Day.fmt(start + "-01", "MMM yy"))
                Spacer(minLength: 4)
                Text(Self.left(left) + (soon ? " · renew soon" : ""))
                    .font(.system(.footnote, weight: .semibold))
                    .foregroundStyle(left <= 0 ? RentInk.lateDeep : soon ? RentInk.dueDeep : Color.primary)
                Spacer(minLength: 4)
                Text(Day.fmt(end + "-01", "MMM yy"))
            }
            .font(.system(.caption))
            .foregroundStyle(.secondary)
            GeometryReader { g in
                let w: CGFloat = g.size.width
                let x: CGFloat = w * frac * (grow ? 1 : 0.04)
                ZStack(alignment: .leading) {
                    Capsule().fill(Color.rule.opacity(0.1))
                    Capsule().fill(LinearGradient(colors: colors, startPoint: .leading, endPoint: .trailing)).frame(width: max(8, x))
                    Circle()
                        .fill(Color.white)
                        .frame(width: 14, height: 14)
                        .overlay(Circle().stroke(tint, lineWidth: 2.5))
                        .shadow(color: tint.opacity(0.3), radius: 3, y: 2)
                        .offset(x: min(max(0, x - 7), w - 14))
                }
            }
            .frame(height: 8)
        }
        .onAppear { withAnimation(Motion.reveal.delay(0.1)) { grow = true } }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("Lease " + Day.fmt(start + "-01", "MMMM yyyy") + " to " + Day.fmt(end + "-01", "MMMM yyyy") + ", " + Self.left(left))
    }
}

