import SwiftUI

// MARK: - Wealth › Holdings: one view a kind (1 Nov, his pick from the Holdings mockups)
//
// No "All": the whole picture is Overview's (the map, WealthMap.swift). Holdings is a tab a kind, picked on one black
// segmented row: Deposits, Mutual funds and Retirement always, Stocks, Gold and Other only when something is in them
// (WealthBook.tabs). It opens on the biggest. Each kind is its own view: Deposits (WealthDeposits.swift), Mutual funds
// and Stocks (WealthFunds.swift), Retirement (WealthRetire.swift); Gold and Other keep the plain list of what's held.
// The row and whose money scroll away with the page, so the largest text sizes keep the room.

extension Store {
    /// Holdings, on a kind's tab (Overview's tiles and map blocks open here)
    func openHoldings(_ kind: String) {
        holdKind = kind
        portPath = []
        withAnimation(Motion.open) { portSub = .investments }
    }
    /// what a map block or a thing's ref opens: a deposit's journey, an account's page, the land, or its kind's tab
    func openRef(_ ref: String) {
        if ref.hasPrefix("dep:") { push(.deposit(String(ref.dropFirst(4)))); return }
        if ref.hasPrefix("acct:") { push(.account(String(ref.dropFirst(5)))); return }
        if ref == "prop" { open(.property); return }
        let k: String = ref.hasPrefix("kind:") ? String(ref.dropFirst(5)) : ref
        switch k {
        case "ins": open(.insurance)
        case "dep", "mf", "ret", "stk", "gold": openHoldings(k)
        default: openHoldings("other")
        }
    }
}

struct WealthHoldings: View {
    @Environment(Store.self) private var store
    @Environment(\.accessibilityReduceMotion) private var still

    var body: some View {
        let p: Person = store.who
        let t: (tabs: [String], pick: String) = WealthBook.tabs(store.holdTabValues(p))
        let kind: String = t.tabs.contains(store.holdKind) ? store.holdKind : t.pick
        page(kind, tabs: t.tabs)
            .id(kind)
            .transition(.opacity.combined(with: .offset(y: 6)))
            .animation(still ? nil : Motion.base, value: kind)
    }

    @ViewBuilder func page(_ kind: String, tabs: [String]) -> some View {
        switch kind {
        case "dep": WealthDeposits(embedded: true, tabs: tabs, kind: kind)
        case "mf": WealthFunds(cls: "mf", embedded: true, tabs: tabs, kind: kind)
        case "stk": WealthFunds(cls: "stk", embedded: true, tabs: tabs, kind: kind)
        case "ret": WealthRetire(tabs: tabs, kind: kind)
        default: HoldingsPlain(tabs: tabs, kind: kind)
        }
    }
}

/// the top of every kind's view: whose money, then the kinds, on one black row that scrolls sideways when it must
struct HoldingsTop: View {
    @Environment(Store.self) private var store
    let tabs: [String]
    let kind: String

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            WhoseSwitch()
            ObsidianSegments(items: items, picked: binding)
                .accessibilityLabel("Kind of holding")
        }
    }

    var items: [(id: String, label: String)] {
        tabs.map { (k: String) -> (id: String, label: String) in (id: k, label: Self.title(k)) }
    }
    static func title(_ k: String) -> String {
        switch k {
        case "dep": return "Deposits"
        case "mf": return "Mutual funds"
        case "ret": return "Retirement"
        case "stk": return "Stocks"
        case "gold": return "Gold"
        default: return "Other"
        }
    }
    var binding: Binding<String> {
        let s: Store = store
        let shown: String = kind
        return Binding<String>(get: { shown }, set: { (k: String) in s.holdKind = k })
    }
}

/// Gold and Other: what's held, in the plain list (each holding, its figure, its day), and what you added by hand
struct HoldingsPlain: View {
    @Environment(Store.self) private var store
    let tabs: [String]
    let kind: String

    var body: some View {
        let p: Person = store.who
        let classes: [ClassSum] = Self.classes(store.classes(p), kind: kind)
        let extra: [Capture] = store.captures.filter { $0.kind == (kind == "gold" ? "gold" : "other") }
        ObsidianList {
            Section {
                HoldingsTop(tabs: tabs, kind: kind)
                    .listRowBackground(Color.clear)
                    .listRowInsets(EdgeInsets(top: 4, leading: 0, bottom: 8, trailing: 0))
            }
            ForEach(classes) { (c: ClassSum) in InstrumentPage(c: c) }
            if !extra.isEmpty {
                Section("Added by you") {
                    ForEach(extra) { (x: Capture) in CaptureLine(x: x) }
                }
            }
            Section {
                Button { add() } label: { Label(kind == "gold" ? "Add physical gold" : "Add NPS, post office or anything else", systemImage: "plus.circle") }
            }
        }
        .listStyle(.insetGrouped)
    }

    /// the kinds this tab lists: gold for Gold; for Other, every kind that has no tab of its own (not land)
    static func classes(_ all: [ClassSum], kind: String) -> [ClassSum] {
        let own: Set<String> = ["dep", "mf", "ret", "stk", "gold", "prop"]
        return all.filter { (c: ClassSum) -> Bool in kind == "gold" ? c.key == "gold" : !own.contains(c.key) }
    }

    func add() {
        if kind == "gold" {
            if store.live != nil { store.betaSheet = .holding("new:gold") } else { store.sheet = .capture("gold") }
        } else {
            store.sheet = .capture("other")
        }
    }
}

/// one thing you added by hand: its name, its note, its figure
struct CaptureLine: View {
    let x: Capture
    var body: some View {
        HStack(spacing: 12) {
            IconTile(symbol: x.kind == "gold" ? "seal.fill" : "tray.full.fill", color: x.kind == "gold" ? Obsidian.savings : Obsidian.ink2)
            VStack(alignment: .leading, spacing: 2) {
                Text(x.title).font(.body.weight(.medium))
                Text(x.text.isEmpty ? "Added \(Day.short(x.date))" : x.text).font(.subheadline).foregroundStyle(.secondary).lineLimit(2)
            }
            Spacer()
            if let a = x.amount { Text(Fmt.words(a)).font(.body.weight(.semibold)).privacySensitive() }
        }
    }
}
