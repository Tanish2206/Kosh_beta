import SwiftUI

// MARK: - What kosh has learned
//
// Everything kosh does differently because you (or Claude, when it's set up) told it once: payees it files a
// certain way and "for whom" that follows a payee (a note stays with its one payment), the reading rules written for banks kosh couldn't read,
// the senders whose statement passwords are saved. Each can be forgotten here, and the lot exported. Passwords
// themselves are never shown or exported: only that one is saved, and for which sender.

struct LearnedView: View {
    @Environment(Store.self) private var store
    @State private var rules: [[String: Any]] = LearnedRules.all()
    @State private var senders: [String] = SenderPasswords.all().keys.sorted()

    var body: some View {
        let payees: [LearnedPayee] = store.snap.learned ?? []
        List {
            Section {
                if payees.isEmpty {
                    Text("Nothing yet. When you file a payment for every payment to its payee, or say who they’re for, it shows here. Notes stay with the one payment.")
                        .font(.subheadline).foregroundStyle(.secondary)
                }
                ForEach(payees) { p in
                    VStack(alignment: .leading, spacing: 3) {
                        HStack(spacing: 6) {
                            Text(p.name).font(.body.weight(.medium)).oneLineUnlessLarge()
                            if p.by.hasPrefix("claude") {
                                Text(p.by == "claude" ? "Filed by AI" : "AI’s guess").font(.caption2.weight(.semibold)).foregroundStyle(Color.kosh)
                                    .padding(.horizontal, 6).padding(.vertical, 2)
                                    .background(Color.kosh.opacity(0.12), in: Capsule())
                            }
                        }
                        Text(Self.line(p)).font(.footnote).foregroundStyle(.secondary).lineLimit(2)
                    }
                    .swipeActions {
                        Button("Forget", role: .destructive) { store.forgetLearned(p) }
                    }
                    .accessibilityAction(named: "Forget") { store.forgetLearned(p) }
                }
            } header: { Text("Payees") } footer: {
                if !payees.isEmpty { Text("Swipe to forget one: its payments go back to how kosh reads them on its own.") }
            }
            if !rules.isEmpty {
                Section {
                    ForEach(rules.indices, id: \.self) { i in
                        let r = rules[i]
                        VStack(alignment: .leading, spacing: 3) {
                            Text((r["domain"] as? String) ?? "A sender").font(.body.weight(.medium))
                            Text((r["why"] as? String) ?? (r["subject"] as? String) ?? "A reading rule").font(.footnote).foregroundStyle(.secondary)
                        }
                        .swipeActions {
                            Button("Forget", role: .destructive) {
                                let domain = (r["domain"] as? String) ?? ""
                                LearnedRules.remove((r["id"] as? String) ?? "")
                                store.live?.rereadWithRules(domain: domain)
                                rules = LearnedRules.all()
                            }
                        }
                    }
                } header: { Text("Reading rules") } footer: {
                    Text("Written by smart reading from a few of a bank's emails, used only because they read every one correctly.")
                }
            }
            if !senders.isEmpty {
                Section {
                    ForEach(senders, id: \.self) { d in
                        Label(d, systemImage: "lock.open").swipeActions {
                            Button("Forget", role: .destructive) { SenderPasswords.forget(d); senders = SenderPasswords.all().keys.sorted() }
                        }
                    }
                } header: { Text("Statement passwords saved for") } footer: {
                    Text("The passwords stay in this phone’s Keychain and are never shown or exported.")
                }
            }
            Section {
                ShareLink(item: Self.export(payees: payees, rules: rules, senders: senders), subject: Text("What kosh has learned"), preview: SharePreview("What kosh has learned")) {
                    Label("Export as text", systemImage: "square.and.arrow.up")
                }
            }
        }
        .navigationTitle("What kosh has learned")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear { rules = LearnedRules.all(); senders = SenderPasswords.all().keys.sorted() }
    }

    /// "→ Groceries · Vegetables · note "milk" · for Home · 14 payments"
    static func line(_ p: LearnedPayee) -> String {
        var bits: [String] = []
        if !p.c.isEmpty { bits.append("Filed as " + (p.s.isEmpty ? p.c : p.c + " · " + p.s)) }
        if !p.n.isEmpty { bits.append("named “" + p.n + "”") }
        if !p.f.isEmpty { bits.append("for " + forName(p.f)) }
        bits.append(String(p.count) + (p.count == 1 ? " payment" : " payments"))
        return bits.joined(separator: " · ")
    }

    static func forName(_ f: String) -> String {
        switch f {
        case "me": return "Me"
        case "mom": return "Family"
        case "home": return "Home"
        case "work": return "Work"
        default: return f
        }
    }

    /// everything above, as plain text to keep or send (no passwords, no account numbers)
    static func export(payees: [LearnedPayee], rules: [[String: Any]], senders: [String]) -> String {
        var out = "What kosh has learned\n\nPayees\n"
        for p in payees { out += "- " + p.name + ": " + line(p) + (p.by == "claude" ? " (AI’s guess)" : "") + "\n" }
        if !rules.isEmpty {
            out += "\nReading rules\n"
            for r in rules { out += "- " + ((r["domain"] as? String) ?? "") + ": " + ((r["why"] as? String) ?? (r["subject"] as? String) ?? "") + "\n" }
        }
        if !senders.isEmpty { out += "\nStatement passwords saved for\n" + senders.map { "- " + $0 }.joined(separator: "\n") + "\n" }
        return out
    }
}

extension Store {
    /// forget what kosh learned about a payee: the category, note and "for whom" set on its payments go, and they're
    /// read the way kosh reads them on its own
    func forgetLearned(_ p: LearnedPayee) {
        for id in p.ids {
            live?.override(id) { o in o.c = nil; o.s = nil; o.n = nil; o.f = nil; o.by = nil }
        }
        live?.rebuildSoon()
    }
}
