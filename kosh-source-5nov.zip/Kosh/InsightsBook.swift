import SwiftUI
import Charts

// MARK: - Insights, one question per section
//
// 1. Pace: how this month is running against last month, and where it's heading.
// 2. How you paid (InsightsPaid.swift): this month's spending by UPI, card, wallet, the bank and cash.
// 3. Where it goes: one month's spending by category, each with its last six months and how far it is from usual.
// 4. Category × month (InsightsCompare.swift): every category, month by month, side by side.
// 5. Up close: one category over a year, against its usual, and what's inside it.
// 6. Keep rate: the share of what comes in that stays, month by month.
// Then budgets (Guard.swift), and the few things worth a look. Everything is for whoever is shown, under the Actual/True lens.

// MARK: The page's own pieces

/// the inks the page writes in: deep kosh blue, green and orange that read on their own washes, lighter in the dark
enum InsightInk {
    /// this month, the pace and the line being read: the accent you chose (Appearance), never a fixed blue
    static var blue: Color { Color.kosh }
    static let slate: Color = tone("#4A4F66", "#B6BACB")
    static let axis: Color = tone("#5E6176", "#9EA1B4")
    static let good: Color = tone("#1A7A43", "#5FD38A")
    static let warn: Color = tone("#A35A00", "#FFB04D")

    static func tone(_ light: String, _ dark: String) -> Color {
        let l: UIColor = UIColor(Color(hex: light))
        let d: UIColor = UIColor(Color(hex: dark))
        return Color(uiColor: UIColor { $0.userInterfaceStyle == .dark ? d : l })
    }
    /// a category's own colour, deepened to read as text on its wash
    static func deep(_ c: Color, _ scheme: ColorScheme) -> Color {
        scheme == .dark ? c.mix(with: .white, by: 0.3) : c.mix(with: .black, by: 0.25)
    }
}

/// a section's title, outside its card
struct InsightTitle: View {
    let text: String
    var body: some View {
        Text(text).font(.title2.weight(.bold)).accessibilityAddTraits(.isHeader)
    }
}

/// the hairline between rows in a card
struct InsightDivider: View {
    var inset: CGFloat = 0
    var body: some View {
        Rectangle().fill(Color.primary.opacity(0.12)).frame(height: 0.5).padding(.leading, inset)
    }
}

/// the grow-in every bar and line on the page shares; straight to the end when Reduce Motion is on
enum InsightMotion {
    static func start(_ still: Bool, delay: Double = 0.1, _ change: @escaping () -> Void) {
        if still {
            change()
        } else {
            withAnimation(Motion.reveal.delay(delay)) { change() }
        }
    }
}

/// a 12pt capsule split into its parts with 2pt gaps, in the order given
struct InsightBar: View {
    let parts: [(Color, Double)]
    var grown: Bool = true
    var body: some View {
        let sum: Double = parts.reduce(0) { $0 + max(0, $1.1) }
        GeometryReader { g in
            let gaps: CGFloat = CGFloat(max(0, parts.count - 1)) * 2
            let free: CGFloat = max(0, g.size.width - gaps)
            HStack(spacing: 2) {
                ForEach(Array(parts.enumerated()), id: \.offset) { _, p in
                    RoundedRectangle(cornerRadius: 2, style: .continuous)
                        .fill(p.0)
                        .frame(width: sum > 0 ? max(2, free * CGFloat(max(0, p.1) / sum)) : 0)
                }
            }
            .frame(width: g.size.width, alignment: .leading)
        }
        .frame(height: 12)
        .background(Color.primary.opacity(0.05))
        .clipShape(Capsule())
        .scaleEffect(x: grown ? 1 : 0.001, anchor: .leading)
    }
}

/// a figure against its usual: ↑18% in orange, ↓12% in green, "usual" when it's close, "so far" when there's nothing to go by
struct DeltaTag: View {
    let d: Double?
    /// the running month: the change is where it's heading, not where it is
    var live: Bool = false
    /// said instead when there is no change because the month is set against nothing ("from 17 Jul")
    var quiet: String? = nil
    var body: some View {
        if d == nil, let quiet {
            Text(quiet).font(.footnote).foregroundStyle(.secondary).lineLimit(1).minimumScaleFactor(0.8)
        } else if let d, abs(d) >= 0.08 {
            HStack(spacing: 2) {
                Image(systemName: d > 0 ? "arrow.up" : "arrow.down").font(.caption2.weight(.heavy))
                Text(Fmt.pct(abs(d))).monospacedDigit()
            }
            .font(.system(.footnote, design: .rounded, weight: .semibold))
            .foregroundStyle(d > 0 ? InsightInk.warn : InsightInk.good)
            .lineLimit(1)
            .accessibilityElement(children: .ignore)
            .accessibilityLabel((live ? "on course for " : "") + Fmt.pct(abs(d)) + (d > 0 ? " more" : " less") + " than usual")
        } else {
            Text(d == nil ? "so far" : "usual").font(.footnote).foregroundStyle(.secondary).lineLimit(1)
        }
    }
}

/// a small line through a few months, the last one marked
struct TrendLine: View {
    let pts: [Double]
    let color: Color
    var body: some View {
        Canvas { ctx, size in
            guard pts.count > 1 else { return }
            let lo: Double = pts.min() ?? 0
            let hi: Double = pts.max() ?? 1
            let span: Double = max(hi - lo, max(abs(hi) * 0.02, 1))
            let w: CGFloat = size.width - 6
            let h: CGFloat = size.height - 6
            let xy: [CGPoint] = pts.enumerated().map { i, v in
                CGPoint(x: 3 + w * CGFloat(i) / CGFloat(pts.count - 1), y: 3 + h - h * CGFloat((v - lo) / span))
            }
            var line = Path()
            line.move(to: xy[0])
            for q in xy.dropFirst() { line.addLine(to: q) }
            ctx.stroke(line, with: .color(color), style: StrokeStyle(lineWidth: 2, lineCap: .round, lineJoin: .round))
            if let last = xy.last {
                ctx.fill(Path(ellipseIn: CGRect(x: last.x - 2.4, y: last.y - 2.4, width: 4.8, height: 4.8)), with: .color(color))
            }
        }
        .accessibilityHidden(true)
    }
}

// MARK: 1 · Pace

struct PaceHero: View {
    @Environment(Store.self) private var store
    @Environment(\.colorScheme) private var scheme
    @Environment(\.accessibilityReduceMotion) private var still
    /// the month Insights looks at ("" this month): an earlier one is drawn whole, with no forecast
    @Environment(\.insightMonth) private var pickedMonth
    @State private var grown = false
    /// the page's month picker, carried on the card's right
    var menu: InsightMonthMenu? = nil

    var body: some View {
        let live: Bool = pickedMonth.isEmpty || pickedMonth == store.snap.cm
        if let mo = live ? store.current : store.month(pickedMonth) {
            // whoever is shown: the household's month and where it's heading, or one person's month and line (the
            // forecast is worked out for the household only, so a person's pace has none rather than the household's)
            let family: Bool = store.who == .family
            let act: [DayV] = store.linePoints(mo) ?? []
            let prev: [DayV] = store.prevLinePoints(mo)
            let ahead: [DayV] = family && live ? store.forecastPoints() : []
            let d: Int = live ? store.snap.fc.d : mo.days
            let now: Double = store.total(of: mo)
            let then: Double = d >= 1 && d <= prev.count ? prev[d - 1].v : (prev.last?.v ?? 0)
            let usual: Double = family ? store.snap.fc.usual : 0
            let likely: Double = family && live ? store.likelyNow : 0
            let prevName: String = mo.prev.flatMap { store.month($0)?.name } ?? "last month"
            // (the month itself is on the picker at the right: the line says only where in it, and whose)
            let whose: String = family ? "" : store.who.possessive("spending", family: "")
            let head: String = live ? (whose.isEmpty ? "Day " + String(d) + " so far" : whose + ", day " + String(d))
                                    : (whose.isEmpty ? "The whole month" : whose)
            VStack(alignment: .leading, spacing: 14) {
                VStack(alignment: .leading, spacing: 2) {
                    HStack(alignment: .center, spacing: 8) {
                        Text(head)
                            .font(.footnote.weight(.semibold))
                            .foregroundStyle(InsightInk.blue)
                            .lineLimit(1)
                        Spacer(minLength: 8)
                        if let menu { menu }
                    }
                    Text(Fmt.rupees(now))
                        .scaledFont(size: 40, weight: .bold, design: .rounded, relativeTo: .largeTitle).monospacedDigit()
                        .lineLimit(1).minimumScaleFactor(0.5)
                        .contentTransition(.numericText())
                        .privacySensitive()
                    PacePill(now: now, then: then, prevName: prevName)
                        .padding(.top, 6)
                    if likely > 0 {
                        Text("likely \(Text(Fmt.short(likely)).fontWeight(.bold).foregroundStyle(Color.primary)) by month end")
                            .font(.subheadline)
                            .foregroundStyle(InsightInk.slate)
                            .monospacedDigit()
                            .padding(.top, 8)
                            .privacySensitive()
                    }
                }
                .padding(.horizontal, 4)
                PaceChart(act: act, prev: prev, ahead: ahead, usual: usual, days: mo.days)
                    .frame(height: 150)
                    .mask(alignment: .leading) { Rectangle().scaleEffect(x: grown ? 1 : 0, anchor: .leading) }
                    .accessibilityElement(children: .ignore)
                    .spokenFigures(PaceHero.spoken(now: now, day: d, then: then, prev: prevName, likely: likely, usual: usual),
                                   hidden: "Spending through the month, day by day, against " + prevName)
                    .privacySensitive()
                WrapRow(spacing: 6, lineSpacing: 6) {
                    PaceKey(color: Color.kosh, text: "this month", width: 2.8, dash: [])
                    if !ahead.isEmpty { PaceKey(color: Color.kosh.opacity(0.55), text: "likely", width: 2, dash: [3, 3]) }
                    if !prev.isEmpty { PaceKey(color: Color(hex: "#8E8E93"), text: "last month", width: 1.8, dash: []) }
                    if usual > 0 { PaceKey(color: Color(hex: "#FF9500"), text: "usual month", width: 1.6, dash: [4, 3]) }
                }
                .accessibilityHidden(true)
                if family {
                    PaceBasis()
                } else if store.snap.fc.daily != nil {
                    Text("Where the month is heading is worked out for the household. Pick Family to see it.")
                        .font(.caption)
                        .foregroundStyle(InsightInk.slate)
                        .fixedSize(horizontal: false, vertical: true)
                        .padding(.horizontal, 4)
                }
            }
            .padding(.horizontal, 16)
            .padding(.top, 20)
            .padding(.bottom, 18)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(wash, in: RoundedRectangle(cornerRadius: 28, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 28, style: .continuous).strokeBorder(Color.kosh.opacity(0.16), lineWidth: 0.5))
            .onAppear { InsightMotion.start(still) { grown = true } }
        }
    }

    /// the soft wash of the accent behind the hero
    private var wash: LinearGradient {
        let from = UnitPoint(x: 0.32, y: 0)
        let to = UnitPoint(x: 0.68, y: 1)
        if scheme == .dark {
            return LinearGradient(stops: [.init(color: Color.kosh.opacity(0.30), location: 0),
                                          .init(color: Color.kosh.opacity(0.16), location: 0.55),
                                          .init(color: Color.kosh.opacity(0.08), location: 1)], startPoint: from, endPoint: to)
        }
        return LinearGradient(stops: [.init(color: Color.kosh.opacity(0.13), location: 0),
                                      .init(color: Color.kosh.opacity(0.07), location: 0.55),
                                      .init(color: Color.kosh.opacity(0.01), location: 1)], startPoint: from, endPoint: to)
    }

    /// the chart, read out
    static func spoken(now: Double, day: Int, then: Double, prev: String, likely: Double, usual: Double) -> String {
        var parts: [String] = ["Spending through the month: " + Fmt.rupees(now) + " by day " + String(day)]
        if then > 0 { parts.append(Fmt.rupees(then) + " by the same day in " + prev) }
        if likely > 0 { parts.append("likely " + Fmt.rupees(likely) + " by month end") }
        if usual > 0 { parts.append("a usual month is " + Fmt.rupees(usual)) }
        return parts.joined(separator: "; ") + "."
    }
}

/// how far ahead or behind last month this month is, at the same day
private struct PacePill: View {
    let now: Double
    let then: Double
    let prevName: String
    var body: some View {
        if then > 0 {
            let r: Double = now / then
            let tone: Int = abs(r - 1) < 0.03 ? 0 : (r > 1 ? 1 : -1)
            let ink: Color = tone == 0 ? Color.secondary : (tone > 0 ? InsightInk.warn : InsightInk.good)
            let wash: Color = tone == 0 ? Color.gray.opacity(0.14) : (tone > 0 ? Color.orange.opacity(0.16) : Color.green.opacity(0.16))
            HStack(spacing: 5) {
                Image(systemName: tone == 0 ? "equal" : (tone > 0 ? "arrow.up" : "arrow.down"))
                    .font(.caption2.weight(.heavy))
                Text(PacePill.line(r: r, tone: tone, prev: prevName))
                    .lineLimit(2)
                    .minimumScaleFactor(0.85)
            }
            .font(.footnote.weight(.semibold))
            .foregroundStyle(ink)
            .padding(.horizontal, 10)
            .padding(.vertical, 4)
            .frame(minHeight: 26)
            .background(wash, in: RoundedRectangle(cornerRadius: 13, style: .continuous))
        }
    }
    /// "11% lighter than September by now", "Neck and neck with September by now"
    static func line(r: Double, tone: Int, prev: String) -> String {
        if tone == 0 { return "Neck and neck with " + prev + " by now" }
        if r >= 2 { return Fmt.trim(r, 1) + "× " + prev + " by now" }
        let pct: String = Fmt.pct(abs(r - 1))
        return tone > 0 ? pct + " more than " + prev + " by now" : pct + " lighter than " + prev + " by now"
    }
}

/// the forecast's own working, so it can be checked: so far + a day's everyday spending × days left + bills due.
/// Tap it for how a day's spending is worked out.
struct PaceBasis: View {
    @Environment(Store.self) private var store
    @State private var open = false
    var body: some View {
        let F = store.snap.fc
        if let daily = F.daily, F.left > 0 {
            let ahead: Double = F.ahead ?? 0
            let cap: Double = F.everydayCap ?? 5000
            Button {
                withAnimation(Fold.motion(opening: !open)) { open.toggle() }
            } label: {
                VStack(alignment: .leading, spacing: 6) {
                    HStack(alignment: .firstTextBaseline, spacing: 6) {
                        Text(PaceBasis.sum(likely: store.likelyNow, spent: store.spentNow, daily: daily, days: F.left, ahead: ahead))
                            .font(.system(.caption, design: .monospaced))
                            .foregroundStyle(InsightInk.slate)
                            .multilineTextAlignment(.leading)
                            .fixedSize(horizontal: false, vertical: true)
                        Spacer(minLength: 0)
                        Image(systemName: open ? "chevron.up" : "info.circle")
                            .font(.caption.weight(.semibold))
                            .foregroundStyle(InsightInk.blue)
                    }
                    Unfold(open: open) {
                        Text(PaceBasis.note(cap: cap))
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .multilineTextAlignment(.leading)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                }
                .padding(.top, 12)
                .padding(.horizontal, 4)
                .overlay(alignment: .top) { Rectangle().fill(Color.kosh.opacity(0.2)).frame(height: 0.5) }
                .contentShape(Rectangle())
            }
            .buttonStyle(.press)
            .accessibilityHint(open ? "Hides how a day's spending is worked out" : "Shows how a day's spending is worked out")
            .privacySensitive()
        }
    }
    static func sum(likely: Double, spent: Double, daily: Double, days: Int, ahead: Double) -> String {
        var parts: [String] = []
        parts.append(Fmt.short(spent) + " so far")
        parts.append(Fmt.short(daily) + " a day × " + String(days) + (days == 1 ? " day" : " days"))
        if ahead > 0 { parts.append(Fmt.short(ahead) + " in bills still due") }
        let rhs: String = parts.joined(separator: " + ")
        return "Likely " + Fmt.short(likely) + " = " + rhs
    }
    static func note(cap: Double) -> String {
        let a: String = "A day's everyday spending is the middle of your last three months, counting payments up to "
        let b: String = ". One-offs bigger than that don't repeat, so they're left out."
        return a + Fmt.short(cap) + b
    }
}

/// one line of the chart's key, on a white chip
private struct PaceKey: View {
    let color: Color
    let text: String
    let width: CGFloat
    let dash: [CGFloat]
    var body: some View {
        HStack(spacing: 6) {
            Path { p in
                p.move(to: CGPoint(x: 1, y: 3))
                p.addLine(to: CGPoint(x: 15, y: 3))
            }
            .stroke(color, style: StrokeStyle(lineWidth: width, lineCap: dash.isEmpty ? .round : .butt, dash: dash))
            .frame(width: 16, height: 6)
            Text(text).font(.caption.weight(.semibold)).foregroundStyle(Color.primary.opacity(0.78)).lineLimit(1)
        }
        .padding(.horizontal, 10)
        .frame(minHeight: 26)
        .background(Color.raised.opacity(0.8), in: Capsule())
    }
}

private struct PaceChart: View {
    let act: [DayV]
    let prev: [DayV]
    let ahead: [DayV]
    let usual: Double
    let days: Int
    var body: some View {
        let top: Double = max(1, (act.map(\.v) + prev.map(\.v) + ahead.map(\.v) + [usual]).max() ?? 1) * 1.08
        let today: DayV? = act.last
        let end: DayV? = ahead.last
        let paper: Color = Color.raised
        Chart {
            RuleMark(y: .value("Zero", 0.0))
                .foregroundStyle(Color.primary.opacity(0.2))
                .lineStyle(StrokeStyle(lineWidth: 1))
            if usual > 0 {
                RuleMark(y: .value("Usual", usual))
                    .foregroundStyle(Color(hex: "#FF9500"))
                    .lineStyle(StrokeStyle(lineWidth: 1.6, dash: [5, 4]))
            }
            ForEach(prev) { p in
                LineMark(x: .value("Day", p.day), y: .value("₹", p.v), series: .value("S", "prev"))
                    .foregroundStyle(Color(hex: "#8E8E93"))
                    .lineStyle(StrokeStyle(lineWidth: 1.8, lineCap: .round, lineJoin: .round))
                    .interpolationMethod(.monotone)
            }
            ForEach(ahead) { p in
                LineMark(x: .value("Day", p.day), y: .value("₹", p.v), series: .value("S", "ahead"))
                    .foregroundStyle(Color.kosh.opacity(0.55))
                    .lineStyle(StrokeStyle(lineWidth: 2, lineCap: .round, lineJoin: .round, dash: [4, 4]))
                    .interpolationMethod(.monotone)
            }
            if let today {
                RuleMark(x: .value("Today", today.day))
                    .foregroundStyle(Color.kosh.opacity(0.35))
                    .lineStyle(StrokeStyle(lineWidth: 1, dash: [2, 3]))
            }
            ForEach(act) { p in
                AreaMark(x: .value("Day", p.day), y: .value("₹", p.v), series: .value("S", "now"))
                    .foregroundStyle(LinearGradient(colors: [Color.kosh.opacity(0.30), Color.kosh.opacity(0)], startPoint: .top, endPoint: .bottom))
                    .interpolationMethod(.monotone)
                LineMark(x: .value("Day", p.day), y: .value("₹", p.v), series: .value("S", "now"))
                    .foregroundStyle(Color.kosh)
                    .lineStyle(StrokeStyle(lineWidth: 2.8, lineCap: .round, lineJoin: .round))
                    .interpolationMethod(.monotone)
            }
            if let today {
                PointMark(x: .value("Day", today.day), y: .value("₹", today.v))
                    .symbol {
                        Circle().fill(Color.kosh).frame(width: 10, height: 10)
                            .overlay(Circle().stroke(paper, lineWidth: 2.5))
                    }
            }
            if let end, end.day > (today?.day ?? 0) {
                PointMark(x: .value("Day", end.day), y: .value("₹", end.v))
                    .symbol {
                        Circle().fill(paper).frame(width: 7, height: 7)
                            .overlay(Circle().stroke(Color.kosh.opacity(0.55), lineWidth: 2))
                    }
                    .annotation(position: .bottom, alignment: .trailing, spacing: 6) {
                        Text(Fmt.short(end.v))
                            .font(.system(.caption2, design: .rounded, weight: .bold))
                            .foregroundStyle(InsightInk.blue)
                    }
            }
        }
        .chartXScale(domain: 1...max(2, days))
        .chartYScale(domain: 0...top)
        .chartYAxis {
            AxisMarks(position: .trailing, values: .automatic(desiredCount: 3)) { value in
                AxisGridLine().foregroundStyle(Color.primary.opacity(0.08))
                AxisValueLabel {
                    if let v = value.as(Double.self), v > 0 {
                        Text(Compact.amount(v)).font(.system(.caption2, weight: .medium)).foregroundStyle(InsightInk.axis)
                    }
                }
            }
        }
        .chartXAxis {
            AxisMarks(values: [1, 10, 20, days]) { value in
                AxisValueLabel {
                    if let v = value.as(Int.self) {
                        Text(String(v)).font(.system(.caption2, weight: .medium)).foregroundStyle(InsightInk.axis)
                    }
                }
            }
        }
    }
}

// MARK: 3 · Where it goes

struct WhereItGoes: View {
    @Environment(Store.self) private var store
    @Environment(\.accessibilityReduceMotion) private var still
    let data: CatMonths
    @Binding var month: String
    let open: (String) -> Void
    @State private var all = false
    @State private var grown = false
    @ScaledMetric(relativeTo: .subheadline) private var amtW: CGFloat = 70

    var body: some View {
        let cm: String = store.snap.cm
        let m: String = InsightsMath.month(month, in: data.months, cm: cm)
        let live: Bool = m == cm
        let ranked: [String] = data.cats.filter { data.at($0, m) > 0 }.sorted { data.at($0, m) > data.at($1, m) }
        let monthTotal: Double = data.total[m] ?? 0
        let total: Double = max(1, monthTotal)
        let head: [String] = Array(ranked.prefix(6))
        let shown: [String] = all ? ranked : head
        let rest: Double = max(0, monthTotal - head.reduce(0) { $0 + data.at($1, m) })
        // the running month is measured by where it's heading (the forecast's own category figures, for the family)
        let heading: [String: FcCat] = live && store.who == .family
            ? Dictionary(store.snap.fc.cats.map { ($0.cat, $0) }, uniquingKeysWith: { a, _ in a }) : [:]
        // the part-month the mail starts in is set against nothing: its rows say from when instead
        let from: String? = store.partFrom(m).map { "from " + String($0) + " " + Day.monthShort(m) }
        let parts: [(Color, Double)] = WhereItGoes.mix(head, m: m, data: data, rest: rest, color: store.catColor)
        VStack(alignment: .leading, spacing: 12) {
            InsightTitle(text: "Where it goes")
            InsightMonthChips(months: data.months, picked: Binding(get: { m }, set: { month = $0 }), label: store.monthLabel)
            VStack(alignment: .leading, spacing: 0) {
                HStack(alignment: .firstTextBaseline, spacing: 8) {
                    Text(Fmt.rupees(monthTotal))
                        .font(.system(.title, design: .rounded, weight: .bold)).monospacedDigit()
                        .lineLimit(1).minimumScaleFactor(0.6)
                        .contentTransition(.numericText())
                    Text(ranked.isEmpty ? (live ? "nothing spent yet" : "nothing spent") : "across \(ranked.count) categor\(ranked.count == 1 ? "y" : "ies")")
                        .font(.subheadline).foregroundStyle(.secondary).lineLimit(1)
                }
                if ranked.isEmpty {
                    // a month with nothing in it: said, not drawn as an empty bar
                    let monthName: String = Day.monthName(m)
                    let since: String = from.map { ", " + $0 } ?? ""
                    let none: String = live ? "Nothing has gone out in \(monthName) yet. Each payment shows here as it comes in."
                                            : "Nothing went out in \(monthName)\(since)."
                    Text(none)
                        .font(.footnote).foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                        .padding(.top, 8)
                }
                if !ranked.isEmpty {
                    InsightBar(parts: parts, grown: grown)
                        .padding(.top, 12)
                        .accessibilityElement(children: .ignore)
                        .accessibilityLabel(head.map { $0 + " " + Fmt.pct(data.at($0, m) / total) }.joined(separator: ", "))
                }
                VStack(spacing: 0) {
                    ForEach(Array(shown.enumerated()), id: \.element) { i, c in
                        if i > 0 { InsightDivider() }
                        Button { open(c) } label: {
                            CatRankRow(c: c, sym: store.catSymbol(c), color: store.catColor(c), v: data.at(c, m), share: data.at(c, m) / total,
                                       line: data.months.map { data.at(c, $0) },
                                       delta: WhereItGoes.delta(c, m: m, cm: cm, data: data, heading: heading),
                                       live: live, quiet: from, amtW: amtW)
                        }
                        .buttonStyle(.press)
                        .accessibilityHint("Looks at it up close")
                        // press and hold: straight to its payments that month
                        .contextMenu {
                            Button {
                                var q = FindQuery()
                                q.cats = [c]
                                q.months = [m]
                                q.flow = .out
                                store.findPreset = q
                                store.push(.find)
                            } label: { Label("See its payments", systemImage: "list.bullet") }
                        }
                    }
                }
                .padding(.top, 6)
                if ranked.count > 6 {
                    Button {
                        withAnimation(still ? nil : Motion.open) { all.toggle() }
                    } label: {
                        HStack(spacing: 6) {
                            Text(all ? "Fewer" : "All \(ranked.count)")
                            Image(systemName: all ? "chevron.up" : "chevron.right").font(.caption.weight(.bold))
                        }
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(Color.kosh)
                        .frame(maxWidth: .infinity)
                        .frame(minHeight: 44)
                        .background(Color.raised, in: Capsule())
                        .contentShape(Capsule())
                    }
                    .buttonStyle(.press)
                    .padding(.top, 8)
                }
            }
            .padding(16)
            .frame(maxWidth: .infinity, alignment: .leading)
            .insightCard(26)
            .privacySensitive()
        }
        .onAppear { InsightMotion.start(still) { grown = true } }
    }

    /// the bar's parts: the six biggest in their colours, then everything else in grey
    static func mix(_ head: [String], m: String, data: CatMonths, rest: Double, color: (String) -> Color) -> [(Color, Double)] {
        var out: [(Color, Double)] = head.map { (color($0), data.at($0, m)) }
        if rest > 0.5 { out.append((Color(uiColor: .systemGray4), rest)) }
        return out
    }

    /// how far a category is from its usual: a finished month against the other finished whole months shown
    /// (InsightsMath.delta: never the part-month the mail starts in), the running month by where the forecast has it
    /// heading; nil when there's nothing to go by
    static func delta(_ c: String, m: String, cm: String, data: CatMonths, heading: [String: FcCat]) -> Double? {
        if m == cm {
            guard let f = heading[c], f.usual > 0 else { return nil }
            return f.likely / f.usual - 1
        }
        return InsightsMath.delta(c, m: m, data: data, cm: cm)
    }
}

struct InsightMonthChips: View {
    let months: [String]
    @Binding var picked: String
    let label: (String) -> String
    var body: some View {
        ScrollView(.horizontal) {
            HStack(spacing: 6) {
                ForEach(months.reversed(), id: \.self) { m in
                    let on: Bool = m == picked
                    Button { withAnimation(Motion.open) { picked = m } } label: {
                        Text(label(m))
                            .font(.subheadline.weight(.semibold))
                            .lineLimit(1)
                            .padding(.horizontal, 14)
                            .frame(minHeight: 36)
                            .foregroundStyle(on ? Color(uiColor: .systemBackground) : Color.primary)
                            .background(on ? AnyShapeStyle(Color.primary) : AnyShapeStyle(Color.surface), in: Capsule())
                            .contentShape(Capsule())
                    }
                    .buttonStyle(.press)
                    .accessibilityAddTraits(on ? .isSelected : [])
                }
            }
            .padding(.horizontal, 20)
        }
        .scrollIndicators(.hidden)
        .padding(.horizontal, -20)
        .sensoryFeedback(.selection, trigger: picked)
    }
}

private struct CatRankRow: View {
    let c: String
    let sym: String
    let color: Color
    let v: Double
    let share: Double
    let line: [Double]
    let delta: Double?
    let live: Bool
    /// what the row says in place of a change when the month is set against nothing ("from 17 Jul")
    var quiet: String? = nil
    let amtW: CGFloat
    var body: some View {
        HStack(spacing: 12) {
            IconTile(symbol: sym, color: color, size: 38)
            VStack(alignment: .leading, spacing: 1) {
                Text(c).font(.subheadline.weight(.semibold)).lineLimit(1)
                Text(Fmt.pct(share) + " of the month").font(.footnote).foregroundStyle(.secondary).lineLimit(1)
            }
            Spacer(minLength: 6)
            TrendLine(pts: line, color: color).frame(width: 54, height: 22)
            VStack(alignment: .trailing, spacing: 1) {
                Text(Fmt.rupees(v))
                    .font(.system(.subheadline, design: .rounded, weight: .semibold)).monospacedDigit()
                    .lineLimit(1).minimumScaleFactor(0.7)
                DeltaTag(d: delta, live: live, quiet: quiet)
            }
            .frame(width: amtW, alignment: .trailing)
        }
        .padding(.vertical, 10)
        .contentShape(Rectangle())
        .accessibilityElement(children: .combine)
    }
}

// MARK: 5 · Up close

struct UpClose: View {
    @Environment(Store.self) private var store
    @Environment(\.colorScheme) private var scheme
    @Environment(\.accessibilityReduceMotion) private var still
    @Binding var focus: String
    let month: String
    /// the last twelve months by category, worked out once by the page
    let span: CatMonths
    /// Inside or Places, kept when you go to another sub-tab and come back
    @AppStorage("upclose.lens") private var lens = "subs"
    /// the category list, open
    @State private var picking = false
    @State private var grown = false
    /// how many months the card looks across, up to the page's month: three to start with
    @AppStorage("upclose.range") private var range: Int = 3
    /// a month tapped on the bars; nil: the whole stretch
    @State private var chosen: String?
    struct Pt: Identifiable { let m: String; let v: Double; var id: String { m } }

    static let ranges: [Int] = [3, 6, 12]
    static func tag(_ n: Int) -> String { n == 12 ? "1Y" : String(n) + "M" }

    /// what the card says: one month tapped, or the whole stretch
    struct Look {
        let figure: Double
        let when: String
        let note: String?
        let live: Bool
        let months: Set<String>
    }

    /// `from`: the day the part-month the mail starts in is read from (nil for a whole month); that month is shown as
    /// it is, never set against usual nor counted in "a month"
    static func look(_ pts: [Pt], one: String?, usual: Double, cm: String, from: (String) -> Int? = { _ in nil }) -> Look {
        if let one {
            let v: Double = pts.first(where: { $0.m == one })?.v ?? 0
            let live: Bool = one == cm
            let part: Int? = from(one)
            let tail: String = live ? " so far" : part.map { ", from " + String($0) + " " + Day.monthShort(one) } ?? ""
            return Look(figure: v, when: "in " + Day.monthName(one) + tail,
                        note: part == nil ? against(v, usual: usual, live: live) : nil, live: live, months: [one])
        }
        let total: Double = pts.reduce(0) { $0 + $1.v }
        let full: [Pt] = pts.filter { $0.m != cm && from($0.m) == nil }
        let avg: Double = full.isEmpty ? 0 : full.reduce(0) { $0 + $1.v } / Double(full.count)
        let first: String = pts.first?.m ?? cm
        let last: String = pts.last?.m ?? cm
        let live: Bool = pts.contains(where: { $0.m == cm })
        return Look(figure: total, when: "over " + Day.monthShort(first) + " – " + Day.monthShort(last) + (live ? " so far" : ""),
                    note: avg > 0 ? Fmt.short(Fmt.roundish(avg)) + " a month" : nil, live: live, months: Set(pts.map(\.m)))
    }

    var body: some View {
        let cm: String = store.snap.cm
        let cat: String = InsightsMath.chosen(focus, among: span.cats)
        let color: Color = store.catColor(cat)
        let ink: Color = InsightInk.deep(color, scheme)
        let all: [Pt] = span.months.map { Pt(m: $0, v: span.at(cat, $0)) }
        let usual: Double = InsightsMath.cameUpUsual(cat, span, cm: cm)
        let end: String = InsightsMath.month(month, in: span.months, cm: cm)
        let months: [String] = InsightsMath.window(span.months, end: end, n: range)
        let pts: [Pt] = all.filter { months.contains($0.m) }
        let one: String? = chosen.flatMap { months.contains($0) ? $0 : nil }
        let look: Look = Self.look(pts, one: one, usual: usual, cm: cm, from: { store.partFrom($0) })
        let rows: [Txn] = cat.isEmpty ? [] : store.spends(in: look.months.sorted()).filter { InsightsMath.kind($0.c) == cat }
        let parts0: [CategoryDive.Part] = lens == "subs"
            ? CategoryDive.parts(rows, by: { CategoryDive.kind($0, cat: cat) }, caption: { CategoryDive.place($0) })
            : CategoryDive.parts(rows, by: { CategoryDive.place($0) }, caption: { CategoryDive.kind($0, cat: cat) })
        let parts: [CategoryDive.Part] = cat == "Shopping" && lens == "subs" ? BuyPattern.enrich(parts0, BuyPattern.over(rows, store: store)) : parts0
        let ranked: [UpCloseMenu.Item] = UpCloseMenu.items(span, months: look.months)
        VStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .center) {
                InsightTitle(text: "Up close")
                Spacer(minLength: 8)
                // (its selection is the category on show, always one of its own choices, so the menu ticks it: a
                // category kept from another person or another month that isn't here any more falls to the first)
                if !span.cats.isEmpty {
                    // (a list of its own, biggest first over the months on show, each with what went on it and its share of
                    // everything spent then: 1 Nov, the menu read as a wall of names in no order)
                    Button { picking = true } label: {
                        HStack(spacing: 6) {
                            Image(systemName: IconTile.outline(store.catSymbol(cat))).font(.footnote.weight(.semibold))
                            Text(cat).font(.subheadline.weight(.semibold)).lineLimit(1)
                            Image(systemName: "chevron.up.chevron.down").font(.caption2.weight(.bold))
                        }
                        .foregroundStyle(ink)
                        .padding(.leading, 10)
                        .padding(.trailing, 12)
                        .frame(minHeight: 36)
                        .background(color.opacity(0.15), in: Capsule())
                    }
                    .buttonStyle(.press)
                    .sheet(isPresented: $picking) {
                        UpClosePicker(items: ranked, chosen: cat, when: look.when) { focus = $0 }
                            .presentationDetents([.medium, .large])
                            .presentationDragIndicator(.visible)
                    }
                    .accessibilityLabel("Pick a category, now " + cat)
                    .sensoryFeedback(.selection, trigger: cat)
                }
            }
            if cat.isEmpty {
                Text("Nothing spent yet.").font(.subheadline).foregroundStyle(.secondary)
            } else {
                VStack(alignment: .leading, spacing: 0) {
                    HStack(alignment: .top, spacing: 8) {
                        UpCloseFigure(look: look, ink: ink)
                        Spacer(minLength: 4)
                        RangePills(range: $range, color: color, ink: ink)
                    }
                    YearBars(pts: pts, usual: usual, color: color, ink: ink, picked: one, grown: grown, dark: scheme == .dark) { m in
                        withAnimation(still ? nil : Motion.base) { chosen = chosen == m ? nil : m }
                    }
                        .frame(height: 132)
                        .padding(.top, 14)
                        .accessibilityElement(children: .ignore)
                        .spokenFigures(UpClose.spoken(cat: cat, pts: pts, usual: usual, look: look), hidden: cat + ", month by month")
                        .accessibilityHint("Swipe up or down to look at one month")
                        .accessibilityAdjustableAction { d in
                            let i: Int = one.flatMap { o in pts.firstIndex(where: { $0.m == o }) } ?? (d == .increment ? -1 : pts.count)
                            let j: Int = d == .increment ? min(pts.count - 1, i + 1) : max(0, i - 1)
                            if pts.indices.contains(j) { chosen = pts[j].m }
                        }
                    Text(Self.foot(usual, one: one, n: pts.count))
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                        .padding(.top, 10)
                    Picker("Look at", selection: $lens) {
                        Text("What it was").tag("subs")
                        Text("Where").tag("places")
                    }
                    .pickerStyle(.segmented)
                    .padding(.top, 14)
                    if let lead = UpClose.lead(parts, total: look.figure, lens: lens) {
                        Text(lead)
                            .font(.footnote).foregroundStyle(.secondary)
                            .fixedSize(horizontal: false, vertical: true)
                            .padding(.top, 12)
                            .contentTransition(.opacity)
                    }
                    PartBars(parts: parts, total: max(look.figure, parts.reduce(0) { $0 + $1.v }), color: color, ink: ink, live: look.live,
                             today: store.snap.today, key: cat + "|" + lens + "|" + look.months.sorted().joined(separator: ","))
                        .padding(.top, 6)
                    if let habit = Habits.of(cat, rows: rows, store: store) {
                        HabitCard(h: habit, span: BuyPattern.spanWords(look.months.count), color: color, ink: ink)
                            .padding(.top, 18)
                    }
                    // (how you shop: in each bar's own line above, never a second list of the same kinds)
                    if cat == "Shopping", let buys = store.snap.buys, !buys.isEmpty {
                        HowYouShop(buys: buys, color: color, ink: ink, today: store.snap.today)
                            .padding(.top, 18)
                    }
                    // the payments behind the figure, in Find with the category and the months on
                    if !rows.isEmpty {
                        Button {
                            var q = FindQuery()
                            q.cats = [cat]
                            q.months = look.months
                            q.flow = .out
                            store.findPreset = q
                            store.push(.find)
                        } label: {
                            HStack(spacing: 6) {
                                Text(rows.count == 1 ? "See the payment" : "See the \(rows.count) payments")
                                Image(systemName: "chevron.right").font(.caption.weight(.bold))
                            }
                            .font(.subheadline.weight(.semibold))
                            .foregroundStyle(ink)
                        }
                        .buttonStyle(.press)
                        .padding(.top, 12)
                    }
                    // Miscellaneous up close: what's in it can be sorted from here, a payee at a time (SortSheet)
                    if cat == "Miscellaneous" && store.live != nil {
                        let q: SortQueue = store.sortQueue
                        if q.count > 0 {
                            let n: String = q.count == 1 ? "Sort the 1 payment in it" : "Sort the " + String(q.count) + " payments in it"
                            let span: String = Store.sortSpan(q.from, q.to, today: store.snap.today)
                            Button { store.sheet = .sort } label: {
                                HStack(spacing: 6) {
                                    Image(systemName: "tag").font(.caption.weight(.bold))
                                    Text(n + " · " + span)
                                    Image(systemName: "chevron.right").font(.caption.weight(.bold))
                                }
                                .font(.subheadline.weight(.semibold))
                                .foregroundStyle(ink)
                                .lineLimit(1)
                                .minimumScaleFactor(0.8)
                            }
                            .buttonStyle(.press)
                            .padding(.top, 10)
                        }
                    }
                }
                .padding(16)
                .frame(maxWidth: .infinity, alignment: .leading)
                .insightCard(26)
                .privacySensitive()
            }
        }
        .animation(still ? nil : Motion.open, value: cat)
        .animation(still ? nil : Motion.open, value: lens)
        .animation(still ? nil : Motion.open, value: month)
        .animation(still ? nil : Motion.open, value: range)
        .onAppear { InsightMotion.start(still) { grown = true } }
        // another category, another stretch, or a cell tapped in the table above: back to the whole stretch
        .onChange(of: focus) { _, _ in chosen = nil }
        .onChange(of: month) { _, _ in chosen = nil }
        .onChange(of: range) { _, _ in chosen = nil }
    }

    /// the one line that says where most of it went: "Most of it at Myntra: ₹11,240, 41%." / "Clothing was 54% of it."
    static func lead(_ parts: [CategoryDive.Part], total: Double, lens: String) -> String? {
        guard parts.count > 1, let top = parts.first, total > 0, top.v > 0, top.name != CategoryDive.unknown else { return nil }
        let share: Double = top.v / total
        guard share >= 0.25 else { return nil }
        let pct: String = Fmt.pct(share)
        if lens == "subs" {
            let first: String = top.sub.split(separator: ",").first.map { String($0) } ?? ""
            return top.name + " was " + pct + " of it" + (first.isEmpty ? "." : ", mostly " + first + ".")
        }
        return "Most of it at " + top.name + ": " + Fmt.rupees(top.v) + ", " + pct + (top.n > 1 ? " over " + String(top.n) + " payments." : ".")
    }

    static func spelled(_ n: Int) -> String {
        n == 3 ? "three" : n == 6 ? "six" : n == 12 ? "twelve" : String(n)
    }

    /// "Usually ₹1.6L a month over the months it came up. Tap a month to look inside it."
    static func foot(_ usual: Double, one: String?, n: Int) -> String {
        let tail: String = one.map { "Tap " + Day.monthShort($0) + " again for all " + spelled(n) + " months." } ?? "Tap a month to look inside it."
        guard usual > 0 else { return tail }
        return "Usually " + Fmt.short(Fmt.roundish(usual)) + " a month over the months it came up. " + tail
    }
    /// "32% above usual", "18% below usual", "about usual"; nothing for a month still going or with no usual
    static func against(_ v: Double, usual: Double, live: Bool) -> String? {
        guard usual > 0, v > 0, !live else { return nil }
        let r: Double = v / usual - 1
        if abs(r) < 0.08 { return "about usual" }
        let pct: String = String(Int(safe: (abs(r) * 100).rounded())) + "%"
        return pct + (r > 0 ? " above usual" : " below usual")
    }

    static func spoken(cat: String, pts: [Pt], usual: Double, look: Look) -> String {
        var parts: [String] = [cat + " over " + spelled(pts.count) + " months"]
        if let top = pts.max(by: { $0.v < $1.v }), top.v > 0 {
            parts.append("highest " + Fmt.rupees(top.v) + " in " + Day.monthName(top.m))
        }
        if usual > 0 { parts.append("usually " + Fmt.rupees(Fmt.roundish(usual)) + " a month") }
        parts.append(Fmt.rupees(look.figure) + " " + look.when)
        return parts.joined(separator: "; ") + "."
    }
}

/// the card's figure: what went out, when, and how that sits against usual
private struct UpCloseFigure: View {
    let look: UpClose.Look
    let ink: Color
    var body: some View {
        VStack(alignment: .leading, spacing: 3) {
            Text(Fmt.rupees(look.figure))
                .font(.system(.title, design: .rounded, weight: .bold)).monospacedDigit()
                .lineLimit(1).minimumScaleFactor(0.6)
                .contentTransition(.numericText())
            HStack(spacing: 5) {
                Text(look.when).foregroundStyle(.secondary)
                if let note = look.note {
                    Text("·").foregroundStyle(.tertiary)
                    Text(note).fontWeight(.semibold).foregroundStyle(ink)
                }
            }
            .font(.subheadline)
            .lineLimit(1)
            .minimumScaleFactor(0.8)
        }
    }
}

/// 3M · 6M · 1Y: how far back the card looks
private struct RangePills: View {
    @Binding var range: Int
    let color: Color
    let ink: Color
    @Namespace private var pill
    var body: some View {
        HStack(spacing: 2) {
            ForEach(UpClose.ranges, id: \.self) { n in
                let on: Bool = n == range
                Button { range = n } label: {
                    Text(UpClose.tag(n))
                        .font(.system(size: 12.5, weight: .semibold, design: .rounded))
                        .foregroundStyle(on ? ink : Color.secondary)
                        .frame(width: 36, height: 28)
                        .background {
                            if on { Capsule().fill(color.opacity(0.2)).matchedGeometryEffect(id: "on", in: pill) }
                        }
                        .contentShape(Capsule())
                }
                .buttonStyle(.press)
                .accessibilityLabel("Last " + UpClose.spelled(n) + " months")
                .accessibilityAddTraits(on ? .isSelected : [])
            }
        }
        .padding(2)
        .background(Color.primary.opacity(0.07), in: Capsule())
        .sensoryFeedback(.selection, trigger: range)
    }
}

private struct YearBars: View {
    let pts: [UpClose.Pt]
    let usual: Double
    let color: Color
    let ink: Color
    /// the month tapped; nil: every month on show is lit
    let picked: String?
    let grown: Bool
    /// by night a category's own colour can sit too close to the card: bars are lifted toward white
    var dark: Bool = false
    /// a month tapped
    var pick: ((String) -> Void)? = nil
    var body: some View {
        let top: Double = max(1, (pts.map(\.v) + [usual]).max() ?? 1) * 1.22
        let base: Color = dark ? color.mix(with: .white, by: 0.22) : color
        let lit = LinearGradient(colors: [base.mix(with: .white, by: 0.25), base], startPoint: .top, endPoint: .bottom)
        let rest: Color = base.opacity(dark ? 0.42 : 0.3)
        let few: Bool = pts.count <= 6
        let width: MarkDimension = pts.count <= 3 ? .fixed(34) : (few ? .fixed(24) : .ratio(0.68))
        Chart {
            ForEach(pts) { p in
                bar(p, top: top, lit: lit, rest: rest, width: width, few: few)
            }
            if usual > 0 {
                RuleMark(y: .value("Usual", usual))
                    .foregroundStyle(ink.opacity(0.7))
                    .lineStyle(StrokeStyle(lineWidth: 1.3, dash: [4, 4]))
                    .annotation(position: .top, alignment: .trailing, spacing: 2) {
                        Text("usual " + Fmt.short(Fmt.roundish(usual)))
                            .font(.system(.caption2, weight: .semibold))
                            .foregroundStyle(ink)
                    }
            }
        }
        .chartYScale(domain: 0...top)
        .chartYAxis(.hidden)
        .chartXAxis {
            AxisMarks { value in
                AxisValueLabel {
                    if let m = value.as(String.self) {
                        Text(few || m == picked ? Day.monthShort(m) : String(Day.monthShort(m).prefix(1)))
                            .font(.system(.caption2, weight: m == picked ? .bold : .medium))
                            .foregroundStyle(m == picked ? ink : Color.secondary)
                    }
                }
            }
        }
        // tap a month to look inside it; tap it again for the whole stretch
        .chartOverlay { proxy in
            GeometryReader { g in
                Rectangle().fill(Color.clear).contentShape(Rectangle())
                    .onTapGesture { at in
                        guard let pick, let frame = proxy.plotFrame else { return }
                        let x: CGFloat = at.x - g[frame].origin.x
                        if let m: String = proxy.value(atX: x) { pick(m) }
                    }
            }
        }
        .sensoryFeedback(.selection, trigger: picked)
    }

    /// a month's bar: lit when it's the one tapped (or when none is), with its figure over it when there's room
    @ChartContentBuilder
    func bar(_ p: UpClose.Pt, top: Double, lit: LinearGradient, rest: Color, width: MarkDimension, few: Bool) -> some ChartContent {
        let on: Bool = p.v > 0 && (picked == nil || p.m == picked)
        let told: Bool = on && (picked != nil || few)
        if on {
            BarMark(x: .value("Month", p.m), y: .value("₹", grown ? p.v : 0), width: width)
                .foregroundStyle(lit)
                .cornerRadius(5)
                .annotation(position: .top, spacing: 4) {
                    if told {
                        Text(Fmt.short(p.v))
                            .font(.system(.caption2, design: .rounded, weight: .bold))
                            .foregroundStyle(ink)
                    }
                }
        } else {
            BarMark(x: .value("Month", p.m), y: .value("₹", grown ? max(p.v, top * 0.012) : 0), width: width)
                .foregroundStyle(p.v > 0 ? rest : Color.primary.opacity(0.12))
                .cornerRadius(5)
        }
    }
}

/// what's inside the category that month, each as its share of it
private struct PartBars: View {
    let parts: [CategoryDive.Part]
    let total: Double
    let color: Color
    let ink: Color
    let live: Bool
    let today: String
    /// what's on show (category, lens, months): a line left open closes when it changes
    let key: String
    @Environment(Store.self) private var store
    @Environment(\.accessibilityReduceMotion) private var still
    @State private var open: String?
    @State private var more = false
    static let first: Int = 6
    static let inside: Int = 5

    var body: some View {
        if parts.isEmpty {
            Text(live ? "Nothing here yet this month." : "Nothing here that month.")
                .font(.subheadline).foregroundStyle(.secondary)
                .padding(.vertical, 10)
        } else {
            let shown: [CategoryDive.Part] = more ? parts : Array(parts.prefix(Self.first))
            VStack(spacing: 0) {
                ForEach(Array(shown.enumerated()), id: \.element.id) { i, p in
                    if i > 0 { InsightDivider() }
                    line(p, last: i == shown.count - 1)
                }
                if parts.count > Self.first {
                    InsightDivider()
                    Button {
                        withAnimation(still ? nil : Motion.open) { more.toggle() }
                    } label: {
                        HStack(spacing: 6) {
                            Text(more ? "Fewer" : String(parts.count - Self.first) + " more")
                            Image(systemName: "chevron.down").font(.caption2.weight(.bold)).rotationEffect(.degrees(more ? 180 : 0))
                        }
                        .font(.footnote.weight(.semibold)).foregroundStyle(ink)
                        .frame(maxWidth: .infinity, minHeight: 40)
                        .contentShape(Rectangle())
                    }
                    .buttonStyle(.press)
                }
            }
            .onChange(of: key) { _, _ in open = nil; more = false }
        }
    }

    @ViewBuilder func line(_ p: CategoryDive.Part, last: Bool) -> some View {
        let isOpen: Bool = open == p.id
        let fill: CGFloat = CGFloat(min(1, p.v / max(1, total)))
        VStack(alignment: .leading, spacing: 0) {
            Button {
                withAnimation(still ? nil : (isOpen ? Motion.base : Motion.open)) { open = isOpen ? nil : p.id }
            } label: {
                PartLine(p: p, fill: fill, color: color, open: isOpen)
                    .padding(.top, 10)
                    .padding(.bottom, isOpen ? 8 : (last ? 2 : 10))
                    .contentShape(Rectangle())
            }
            .buttonStyle(.press)
            .accessibilityElement(children: .ignore)
            .spokenFigures(p.name + ", " + String(p.n) + (p.n == 1 ? " payment, " : " payments, ") + Fmt.rupees(p.v),
                           hidden: p.name + ", " + String(p.n) + (p.n == 1 ? " payment" : " payments"))
            .accessibilityHint(isOpen ? "Hides its payments" : "Shows its payments")
            if isOpen {
                VStack(spacing: 0) {
                    if p.name == CategoryDive.unknown {
                        Text("Their mail didn’t say what was in these orders, and the shop sells everything.")
                            .font(.caption).foregroundStyle(.secondary)
                            .frame(maxWidth: .infinity, alignment: .leading).fixedSize(horizontal: false, vertical: true)
                            .padding(.bottom, 4)
                    }
                    ForEach(Array(p.rows.prefix(Self.inside))) { t in payment(t) }
                    if p.rows.count > Self.inside {
                        Text("and " + String(p.rows.count - Self.inside) + " more, under See the payments")
                            .font(.caption).foregroundStyle(.secondary)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.top, 6)
                    }
                }
                .padding(.leading, 12)
                .overlay(alignment: .leading) { Capsule().fill(color.opacity(0.35)).frame(width: 2).padding(.vertical, 4) }
                .padding(.bottom, last ? 4 : 12)
                .transition(.opacity.combined(with: .move(edge: .top)))
            }
        }
    }

    /// what was bought, when the order's mail said: its first item, and how many more
    func bought(_ t: Txn) -> String? {
        if let items = store.payFact(t)?.items, !items.isEmpty {
            let first: String = items[0].n.trimmingCharacters(in: .whitespacesAndNewlines)
            return items.count > 1 ? first + " +" + String(items.count - 1) : first
        }
        guard let o = store.order(t), let line = o.bill?.first(where: { $0.k == "sub" && !$0.n.isEmpty }) else { return nil }
        let n: String = line.n.trimmingCharacters(in: .whitespacesAndNewlines)
        return n.isEmpty || n.lowercased() == "subtotal" || n.lowercased() == "item total" ? nil : n
    }

    func payment(_ t: Txn) -> some View {
        let when: String = Day.fmt(t.d, t.d.prefix(4) == today.prefix(4) ? "d MMM" : "d MMM yy")
        let what: String = bought(t) ?? t.wk ?? (t.s.isEmpty || t.s.lowercased() == "online" ? "" : t.s)
        return HStack(alignment: .firstTextBaseline, spacing: 10) {
            Text(when)
                .font(.system(.caption, design: .rounded)).monospacedDigit().foregroundStyle(.secondary)
                .frame(width: 52, alignment: .leading)
            VStack(alignment: .leading, spacing: 1) {
                Text(CategoryDive.place(t)).font(.footnote.weight(.medium)).lineLimit(1)
                if !what.isEmpty { Text(what).font(.caption2).foregroundStyle(.secondary).lineLimit(1) }
            }
            Spacer(minLength: 6)
            Text(Fmt.rupees(t.a)).font(.system(.footnote, design: .rounded, weight: .medium)).monospacedDigit()
        }
        .padding(.vertical, 6)
        .privacySensitive()
        .accessibilityElement(children: .combine)
    }
}

/// how you shop, over nine months whatever the range above: a line per kind of thing bought (the four biggest, the rest a
/// tap away) — how many times and how often, what it usually costs, where from, the latest thing, and when the next is
/// due when the rhythm is steady
private struct HowYouShop: View {
    let buys: [BuyPattern]
    let color: Color
    let ink: Color
    let today: String
    var span: String = "last 9 months"
    @Environment(\.accessibilityReduceMotion) private var still
    @State private var all = false
    var body: some View {
        let shown: [BuyPattern] = all ? buys : Array(buys.prefix(4))
        VStack(alignment: .leading, spacing: 0) {
            HStack(alignment: .firstTextBaseline) {
                Text("How you shop").font(.subheadline.weight(.semibold))
                Spacer(minLength: 6)
                Text(span).font(.caption).foregroundStyle(.secondary)
            }
            .padding(.bottom, 4)
            ForEach(Array(shown.enumerated()), id: \.element.id) { i, b in
                if i > 0 { InsightDivider() }
                BuyLine(b: b, color: color, ink: ink, today: today)
            }
            if buys.count > 4 {
                Button { withAnimation(still ? nil : Motion.open) { all.toggle() } } label: {
                    Text(all ? "Fewer" : "All " + String(buys.count) + " kinds").font(.footnote.weight(.semibold)).foregroundStyle(ink)
                        .frame(maxWidth: .infinity, minHeight: 36)
                }
                .buttonStyle(.press)
            }
        }
        .padding(14)
        .background(color.opacity(0.07), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
    }
}

private struct BuyLine: View {
    let b: BuyPattern
    let color: Color
    let ink: Color
    let today: String
    var body: some View {
        let times: String = b.n == 1 ? "once" : String(b.n) + " times"
        let head: String = [times, b.rhythm ?? "", "usually " + Fmt.short(b.usual)].filter { !$0.isEmpty }.joined(separator: " · ")
        let from: String = b.places.prefix(2).joined(separator: ", ")
        let latest: String = b.items.first.map { "last: " + $0 } ?? ("last " + Day.fmt(b.last, b.last.prefix(4) == today.prefix(4) ? "d MMM" : "d MMM yy"))
        VStack(alignment: .leading, spacing: 3) {
            HStack(alignment: .firstTextBaseline, spacing: 6) {
                Text(b.k).font(.subheadline.weight(.semibold))
                Spacer(minLength: 6)
                Text(Fmt.pct(b.share)).font(.system(.footnote, design: .rounded, weight: .semibold)).monospacedDigit().foregroundStyle(ink)
            }
            Text(head).font(.footnote).foregroundStyle(.secondary).monospacedDigit().lineLimit(1).minimumScaleFactor(0.85)
            Text((from.isEmpty ? "" : from + " · ") + latest).font(.caption).foregroundStyle(.secondary).lineLimit(1)
            if let nx = b.next {
                Text("Next likely around " + Day.fmt(nx, "d MMM")).font(.caption.weight(.semibold)).foregroundStyle(ink)
            }
        }
        .padding(.vertical, 9)
        .privacySensitive()
        .accessibilityElement(children: .combine)
    }
}

/// one line of the breakdown, closed: name, count, figure, what's in it, and its bar
private struct PartLine: View {
    let p: CategoryDive.Part
    let fill: CGFloat
    let color: Color
    let open: Bool
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(alignment: .firstTextBaseline, spacing: 6) {
                Text(p.name).font(.subheadline.weight(.semibold)).foregroundStyle(Color.primary).oneLineUnlessLarge()
                Text("\(p.n)×").font(.system(.footnote, design: .rounded)).monospacedDigit().foregroundStyle(.secondary)
                Spacer(minLength: 6)
                Text(Fmt.rupees(p.v))
                    .font(.system(.subheadline, design: .rounded, weight: .semibold)).monospacedDigit()
                    .foregroundStyle(Color.primary)
                    .lineLimit(1)
                Image(systemName: "chevron.down").font(.caption2.weight(.bold)).foregroundStyle(.tertiary)
                    .rotationEffect(.degrees(open ? 180 : 0))
            }
            if !p.sub.isEmpty {
                Text(p.sub).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                    .padding(.top, -4)
            }
            GeometryReader { g in
                ZStack(alignment: .leading) {
                    Capsule().fill(color.opacity(0.16))
                    Capsule().fill(color).frame(width: max(4, g.size.width * fill))
                }
            }
            .frame(height: 6)
        }
    }
}

/// Up close's categories, as a list: each with what went on it over the months on show and its share of all the
/// spending then, biggest first, a bar for the share; the one on show ticked
private struct UpClosePicker: View {
    @Environment(Store.self) private var store
    @Environment(\.colorScheme) private var scheme
    @Environment(\.dismiss) private var dismiss
    let items: [UpCloseMenu.Item]
    let chosen: String
    let when: String
    let pick: (String) -> Void
    var body: some View {
        let top: Double = items.first?.share ?? 0
        NavigationStack {
            ScrollView {
                VStack(spacing: 0) {
                    ForEach(Array(items.enumerated()), id: \.element.id) { i, it in
                        Button {
                            pick(it.cat); dismiss()
                        } label: {
                            UpClosePickRow(it: it, on: it.cat == chosen, top: top, color: store.catColor(it.cat), symbol: store.catSymbol(it.cat), scheme: scheme)
                        }
                        .buttonStyle(.press)
                        .accessibilityLabel(UpClosePickRow.spoken(it))
                        .accessibilityAddTraits(it.cat == chosen ? .isSelected : [])
                        if i < items.count - 1 { Divider().padding(.leading, 46) }
                    }
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 24)
            }
            .navigationTitle("Categories")
            .navigationBarTitleDisplayMode(.inline)
            .safeAreaInset(edge: .top, spacing: 0) {
                Text("Spending " + when + ", biggest first").font(.footnote).foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, alignment: .leading).padding(.horizontal, 20).padding(.bottom, 6)
            }
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } } }
        }
        .sensoryFeedback(.selection, trigger: chosen)
    }
}

/// one category in the list: its tile, name, amount, share, and a bar for the share against the biggest
private struct UpClosePickRow: View {
    let it: UpCloseMenu.Item
    let on: Bool
    let top: Double
    let color: Color
    let symbol: String
    let scheme: ColorScheme
    static func spoken(_ it: UpCloseMenu.Item) -> String {
        it.v > 0 ? it.cat + ", " + Fmt.rupees(it.v) + ", " + Fmt.pct(it.share) + " of spending" : it.cat + ", nothing"
    }
    var body: some View {
        let has: Bool = it.v > 0
        let fill: CGFloat = has && top > 0 ? CGFloat(it.share / top) : 0
        HStack(spacing: 12) {
            Image(systemName: symbol).font(.system(size: 15, weight: .semibold))
                .foregroundStyle(color)
                .frame(width: 34, height: 34)
                .background(color.opacity(0.14), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
            VStack(alignment: .leading, spacing: 6) {
                HStack(alignment: .firstTextBaseline, spacing: 6) {
                    Text(it.cat).font(.subheadline.weight(on ? .bold : .semibold)).foregroundStyle(Color.primary).lineLimit(1)
                    Spacer(minLength: 6)
                    Text(has ? Fmt.rupees(it.v) : "—")
                        .font(.system(.subheadline, design: .rounded, weight: .semibold)).monospacedDigit()
                        .foregroundStyle(has ? Color.primary : Color.secondary)
                    Text(has ? Fmt.pct(it.share) : "")
                        .font(.system(.footnote, design: .rounded, weight: .semibold)).monospacedDigit()
                        .foregroundStyle(InsightInk.deep(color, scheme))
                        .frame(minWidth: 38, alignment: .trailing)
                }
                GeometryReader { g in
                    ZStack(alignment: .leading) {
                        Capsule().fill(Color.primary.opacity(0.06))
                        Capsule().fill(color).frame(width: has ? max(3, g.size.width * fill) : 0)
                    }
                }
                .frame(height: 4)
            }
            Image(systemName: "checkmark").font(.footnote.weight(.bold)).foregroundStyle(Color.kosh)
                .opacity(on ? 1 : 0)
                .frame(width: 16)
        }
        .padding(.vertical, 11)
        .contentShape(Rectangle())
    }
}

/// Up close's categories, biggest first over the months on show, each with what went on it and its share of everything
/// spent then
enum UpCloseMenu {
    struct Item: Identifiable { let cat: String; let v: Double; let share: Double; var id: String { cat } }
    static func items(_ span: CatMonths, months: Set<String>) -> [Item] {
        let all: Double = months.reduce(0) { $0 + (span.total[$1] ?? 0) }
        let xs: [Item] = span.cats.map { (c: String) -> Item in
            let v: Double = months.reduce(0) { $0 + span.at(c, $1) }
            return Item(cat: c, v: v, share: all > 0 ? v / all : 0)
        }
        return xs.sorted { $0.v != $1.v ? $0.v > $1.v : $0.cat < $1.cat }
    }
}

// MARK: 6 · Keep rate

struct KeepRate: View {
    @Environment(Store.self) private var store
    @Environment(\.accessibilityReduceMotion) private var still
    @Environment(\.insightMonth) private var pickedMonth
    @State private var grown = false
    struct Bar: Identifiable {
        let m: String; let r: Double; let live: Bool
        var id: String { m }
        /// how tall it's drawn: a month that spent twice what came in still fits the card
        var h: Double { min(100, max(-100, r)) }
    }

    var body: some View {
        // the months with a real income, as InsightsMath.keep sorts them: a month whose salary mail never came, one
        // where next to nothing came in (between jobs, say: the share would read −50,000%) and the part-month the
        // mail starts in (half a month's money) are left out, and said. The six end at the month Insights looks at
        let upTo: String = pickedMonth.isEmpty ? store.snap.cm : pickedMonth
        let recent: [CashMonth] = Array((store.snap.cashflow ?? []).filter { (c: CashMonth) -> Bool in c.m <= upTo }.suffix(6))
        let sorted = InsightsMath.keep(recent.map { InsightsMath.KeepMonth(m: $0.m, inn: $0.inn, kept: $0.kept, live: $0.live, noPay: $0.noPay == true, partial: $0.partial == true) })
        let rows: [InsightsMath.KeepMonth] = sorted.kept
        let noPay: Set<String> = Set(sorted.noPay)
        let left: [String] = recent.map(\.m).filter { sorted.noPay.contains($0) || sorted.thin.contains($0) }
        if rows.count > 1 {
            let bars: [Bar] = rows.map { Bar(m: $0.m, r: $0.kept / $0.inn * 100, live: $0.live) }
            let full: [Bar] = bars.filter { !$0.live }
            let avg: Double = full.isEmpty ? 0 : full.reduce(0) { $0 + $1.r } / Double(full.count)
            let best: Bar? = full.max { $0.r < $1.r }
            let live: Bar? = bars.first { $0.live }
            VStack(alignment: .leading, spacing: 12) {
                InsightTitle(text: "Keep rate")
                VStack(alignment: .leading, spacing: 0) {
                    Text((avg < 0 ? "−" : "") + String(Int(safe: abs(avg).rounded())) + "%")
                        .scaledFont(size: 40, weight: .bold, design: .rounded, relativeTo: .largeTitle).monospacedDigit()
                        .foregroundStyle(avg >= 0 ? InsightInk.good : InsightInk.warn)
                        .lineLimit(1).minimumScaleFactor(0.6)
                    Text(avg >= 0 ? "of what comes in stays, on average" : "more went out than came in, on average")
                        .font(.subheadline).foregroundStyle(.secondary)
                        .padding(.top, 2)
                    KeepBars(bars: bars, avg: avg, best: best?.m, grown: grown)
                        .frame(height: 128)
                        .padding(.top, 14)
                        .accessibilityElement(children: .ignore)
                        .accessibilityLabel(KeepRate.spoken(bars, avg: avg))
                    if let line = KeepRate.caption(best: best, full: full, live: live, left: left, noPay: noPay,
                                                   part: sorted.partial.compactMap { m in store.partFrom(m).map { (m, $0) } }) {
                        Text(line)
                            .font(.footnote).foregroundStyle(.secondary)
                            .fixedSize(horizontal: false, vertical: true)
                            .padding(.top, 10)
                    }
                    // what comes in isn't kept person by person: under one person the card is still the household's
                    if store.who != .family {
                        Label("The household’s, whoever is picked: what comes in isn’t split by person.", systemImage: "person.2")
                            .font(.footnote).foregroundStyle(.secondary)
                            .fixedSize(horizontal: false, vertical: true)
                            .padding(.top, 8)
                    }
                }
                .padding(16)
                .frame(maxWidth: .infinity, alignment: .leading)
                .insightCard(26)
                .privacySensitive()
            }
            .onAppear { InsightMotion.start(still) { grown = true } }
        }
    }

    /// "Best was July, at 41%. October is still going." — or a nod when the latest finished month is the best
    static func caption(best: Bar?, full: [Bar], live: Bar?, left: [String], noPay: Set<String> = [], part: [(String, Int)] = []) -> String? {
        var parts: [String] = []
        if let best, best.r > 0 {
            let pct: String = String(Int(safe: best.r.rounded())) + "%"
            if best.m == full.last?.m && full.count > 2 {
                parts.append(Day.monthName(best.m) + " was your best yet, at " + pct + ". Nicely done.")
            } else {
                parts.append("Best was " + Day.monthName(best.m) + ", at " + pct + ".")
            }
        }
        if let live { parts.append(Day.monthName(live.m) + " is still going.") }
        // (a month whose salary mail never came is left out for that, not because you earned nothing)
        let unpaid: [String] = left.filter { noPay.contains($0) }, thin: [String] = left.filter { !noPay.contains($0) }
        if !unpaid.isEmpty {
            let names: String = Words.list(unpaid.map { Day.monthName($0) })
            parts.append(names + (unpaid.count == 1 ? " is" : " are") + " left out: " + (unpaid.count == 1 ? "its salary isn’t" : "their salary isn’t") + " in your email.")
        }
        if !thin.isEmpty {
            let names: String = thin.map { Day.monthName($0) }.joined(separator: " and ")
            parts.append(names + (thin.count == 1 ? " is" : " are") + " left out: next to nothing came in.")
        }
        // (the month the mail starts in, from a day past the 1st: half a month's money says nothing about a month)
        for (m, day) in part {
            parts.append(Day.monthName(m) + " is left out: your email is read from " + String(day) + " " + Day.monthShort(m) + ".")
        }
        return parts.isEmpty ? nil : parts.joined(separator: " ")
    }

    static func spoken(_ bars: [Bar], avg: Double) -> String {
        let each: [String] = bars.map { Day.monthName($0.m) + ($0.live ? " so far " : " ") + String(Int(safe: $0.r.rounded())) + "%" }
        return "Keep rate by month: " + each.joined(separator: ", ") + ". Average " + String(Int(safe: avg.rounded())) + "%."
    }
}

/// a bar for each month, the best one solid, the running month dashed; the average as a dashed line across
private struct KeepBars: View {
    let bars: [KeepRate.Bar]
    let avg: Double
    let best: String?
    let grown: Bool
    var body: some View {
        let vals: [Double] = bars.map(\.h) + [min(100, max(-100, avg)), 0]
        let hi: Double = max(1, vals.max() ?? 1)
        let lo: Double = min(0, vals.min() ?? 0)
        GeometryReader { g in
            let w: CGFloat = g.size.width
            let top: CGFloat = 20
            let bottom: CGFloat = g.size.height - (lo < 0 ? 40 : 24)
            let span: CGFloat = max(1, bottom - top)
            let y: (Double) -> CGFloat = { v in top + span * CGFloat((hi - v) / max(1, hi - lo)) }
            let zero: CGFloat = y(0)
            let slot: CGFloat = w / CGFloat(max(1, bars.count))
            let bw: CGFloat = min(30, slot * 0.56)
            ZStack(alignment: .topLeading) {
                Rectangle().fill(Color.primary.opacity(0.18)).frame(width: w, height: 0.5).position(x: w / 2, y: zero)
                ForEach(Array(bars.enumerated()), id: \.element.id) { i, b in
                    let cx: CGFloat = slot * (CGFloat(i) + 0.5)
                    let up: Bool = b.r >= 0
                    let h: CGFloat = max(2, abs(y(b.h) - zero) * (grown ? 1 : 0.02))
                    KeepBar(live: b.live, best: b.m == best, up: up)
                        .frame(width: bw, height: h)
                        .position(x: cx, y: up ? zero - h / 2 : zero + h / 2)
                    KeepLabel(bar: b, best: b.m == best)
                        .fixedSize()
                        .position(x: cx, y: up ? zero - h - 9 : zero + h + 9)
                        .opacity(grown ? 1 : 0)
                    Text(Day.monthShort(b.m))
                        .font(.system(.caption2, weight: .medium))
                        .foregroundStyle(.secondary)
                        .fixedSize()
                        .position(x: cx, y: g.size.height - 8)
                }
                Path { p in
                    p.move(to: CGPoint(x: 0, y: y(min(100, max(-100, avg)))))
                    p.addLine(to: CGPoint(x: w, y: y(min(100, max(-100, avg)))))
                }
                .stroke(InsightInk.good.opacity(0.55), style: StrokeStyle(lineWidth: 1.3, dash: [4, 4]))
            }
        }
    }
}

/// the figure over a bar, or "so far" over the running month
private struct KeepLabel: View {
    let bar: KeepRate.Bar
    let best: Bool
    var body: some View {
        if bar.live {
            Text("so far").font(.system(.caption2, weight: .semibold)).foregroundStyle(.secondary)
        } else {
            Text(String(Int(safe: bar.r.rounded())) + "%")
                .font(.system(.caption2, design: .rounded, weight: best ? .bold : .semibold))
                .foregroundStyle(best ? InsightInk.good : Color.primary.opacity(0.75))
        }
    }
}

private struct KeepBar: View {
    let live: Bool
    let best: Bool
    let up: Bool
    var body: some View {
        let base: Color = up ? Color.green : Color.orange
        let ink: Color = up ? InsightInk.good : InsightInk.warn
        let shape = RoundedRectangle(cornerRadius: 8, style: .continuous)
        if live {
            shape.fill(base.opacity(0.12))
                .overlay(shape.strokeBorder(ink.opacity(0.45), style: StrokeStyle(lineWidth: 1.5, dash: [4, 3])))
        } else {
            shape.fill(best ? base : base.opacity(0.42))
        }
    }
}

// MARK: 8 · Worth a look

struct WorthALook: View {
    @Environment(Store.self) private var store
    @Environment(\.accessibilityReduceMotion) private var still
    @State private var all = false
    var body: some View {
        let ps: [Pattern] = store.snap.insights.patterns ?? []
        if !ps.isEmpty {
            let shown: [Pattern] = all ? ps : Array(ps.prefix(4))
            VStack(alignment: .leading, spacing: 12) {
                InsightTitle(text: "Worth a look")
                // what kosh noticed is worked out over the household's spending, whoever is picked
                if store.who != .family {
                    Label("Noticed in the household’s spending.", systemImage: "person.2")
                        .font(.footnote).foregroundStyle(.secondary)
                        .padding(.top, -6)
                }
                VStack(spacing: 0) {
                    ForEach(Array(shown.enumerated()), id: \.element.id) { i, p in
                        if i > 0 { InsightDivider() }
                        HStack(alignment: .top, spacing: 12) {
                            IconTile(symbol: WorthALook.symbol(p), color: WorthALook.tint(p), size: 38)
                            VStack(alignment: .leading, spacing: 2) {
                                Text(p.title)
                                    .font(.subheadline.weight(.semibold))
                                    .fixedSize(horizontal: false, vertical: true)
                                Text(p.detail)
                                    .font(.footnote).foregroundStyle(.secondary)
                                    .fixedSize(horizontal: false, vertical: true)
                            }
                            .padding(.top, 1)
                            Spacer(minLength: 0)
                        }
                        .padding(.vertical, 12)
                        .accessibilityElement(children: .combine)
                    }
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 4)
                .frame(maxWidth: .infinity, alignment: .leading)
                .insightCard(26)
                .privacySensitive()
                if ps.count > 4 {
                    Button(all ? "Fewer" : "\(ps.count - 4) more") { withAnimation(still ? nil : Motion.open) { all.toggle() } }
                        .font(.subheadline.weight(.semibold))
                        .frame(minHeight: 44)
                }
            }
        }
    }
    static func symbol(_ p: Pattern) -> String {
        if !p.sym.isEmpty { return p.sym }
        if p.tone == "up" { return "chart.line.uptrend.xyaxis" }
        if p.tone == "down" { return "chart.line.downtrend.xyaxis" }
        return "sparkle"
    }
    static func tint(_ p: Pattern) -> Color {
        if !p.color.isEmpty { return Color(hex: p.color) }
        if p.tone == "up" { return Color.orange }
        if p.tone == "down" { return Color.green }
        return Color.kosh
    }
}


extension BuyPattern {
    /// "this month", "last 3 months"
    static func spanWords(_ n: Int) -> String { n <= 1 ? "this month" : "last " + String(n) + " months" }
    /// how you shop over these payments: each kind of thing bought (what kosh read it was), how many times, how much in
    /// all and usually, how often (the middle gap between buying days, steady or not), the shops, the latest things
    @MainActor static func over(_ rows: [Txn], store: Store) -> [BuyPattern] {
        let mine: [Txn] = rows.filter { $0.sp && !($0.wk ?? "").isEmpty && $0.wk != "Gift cards" }
        let all: Double = mine.reduce(0) { $0 + $1.a }
        let by: [String: [Txn]] = Dictionary(grouping: mine) { $0.wk ?? "" }
        var out: [BuyPattern] = []
        for (k, group) in by {
            let xs: [Txn] = group.sorted { $0.d < $1.d }
            let total: Double = xs.reduce(0) { $0 + $1.a }
            var days: [String] = []
            for t in xs where !days.contains(t.d) { days.append(t.d) }
            var gaps: [Int] = []
            if days.count > 1 { for i in 1..<days.count { gaps.append(Day.between(days[i - 1], days[i])) } }
            let every: Int = gaps.count >= 2 ? Int(mid(gaps.map(Double.init)).rounded()) : 0
            let steady: Bool = every >= 4 && gaps.filter { Double($0) >= Double(every) * 0.5 && Double($0) <= Double(every) * 1.6 }.count >= Int((Double(gaps.count) * 0.6).rounded(.up))
            var shopSum: [String: Double] = [:]
            for t in xs {
                let s0: String = (t.pf ?? store.payFact(t)?.at ?? t.m).trimmingCharacters(in: .whitespaces)
                if !s0.isEmpty { shopSum[s0, default: 0] += t.a }
            }
            var items: [String] = []
            for t in xs.reversed() {
                for it in store.payFact(t)?.items ?? [] {
                    let n: String = it.n.trimmingCharacters(in: .whitespacesAndNewlines)
                    if !n.isEmpty && items.count < 3 && !items.contains(n) { items.append(n) }
                }
            }
            let last: String = days.last ?? ""
            var b = BuyPattern(k: k, n: xs.count, total: total.rounded(), usual: mid(xs.map { $0.a }).rounded(),
                               share: all > 0 ? total / all : 0,
                               shops: shopSum.keys.sorted { shopSum[$0, default: 0] > shopSum[$1, default: 0] }.prefix(3).map { $0 },
                               last: last, items: items)
            if every > 0 { b.every = every }
            if steady {
                b.steady = true
                let nx: String = Day.add(last, every)
                if nx > store.snap.today { b.next = nx }
            }
            out.append(b)
        }
        return out.sorted { $0.total > $1.total }
    }
    private static func mid(_ v: [Double]) -> Double {
        guard !v.isEmpty else { return 0 }
        let s: [Double] = v.sorted()
        return s.count % 2 == 1 ? s[s.count / 2] : (s[s.count / 2 - 1] + s[s.count / 2]) / 2
    }
}


extension BuyPattern {
    /// each kind's bar line with its rhythm and usual spend: "Myntra, Meesho · every ~7 days · usually ₹1.5k"
    static func enrich(_ parts: [CategoryDive.Part], _ buys: [BuyPattern]) -> [CategoryDive.Part] {
        let by: [String: BuyPattern] = Dictionary(buys.map { ($0.k, $0) }, uniquingKeysWith: { a, _ in a })
        return parts.map { (p: CategoryDive.Part) -> CategoryDive.Part in
            guard let b = by[p.name], b.n > 1 else { return p }
            var q = p
            var bits: [String] = p.sub.isEmpty ? [] : [p.sub]
            if let r = b.rhythm { bits.append(r) }
            bits.append("usually " + Fmt.short(b.usual))
            q.sub = bits.joined(separator: " · ")
            return q
        }
    }
}
