import SwiftUI

// MARK: - Bills by home (Homes.swift; engine/21s-build-homes.js), in the black look (insights-obsidian, 1 Nov)
// Insights' card and its pages: each home's bills across the year, by the home they belong to (never by who paid),
// each bill spread over the days it covers. Every section answers one question, with its dates:
//   the homes page   which home costs more (two homes side by side), what each costs a month, and which connections
//                    kosh couldn't place (a compact card: one tap on a home's chip puts it there)
//   a home's page    what it costs a month (the year as bars, its peak, against a year before); what it goes on (one bar
//                    cut by utility); what's coming (each connection's next bill by its cycle, at last year's cost);
//                    what's worth a look (a jump against the same season, a missed cycle, arrears); electricity's units
//                    and a unit's rate; summer against winter; then its connections and bills
// How kosh spreads a bill over its days sits behind the ⓘ in the bar, not under every page.

/// the colours and bars these pages draw (Homes.swift stays Foundation-only for its test)
enum HomeInk {
    /// a utility's colour: the same in the bar, its row, its icon
    static func kind(_ k: String) -> Color {
        switch k {
        case "Electricity": return Obsidian.savings
        case "Water": return Obsidian.ulip
        case "Gas", "LPG": return Obsidian.motor
        case "Internet": return Obsidian.term
        case "DTH": return Obsidian.property
        case "Maintenance": return Obsidian.health
        default: return Obsidian.ink3
        }
    }
    /// a home's last months as the strip draws them: a month every connection covers is lit, the rest paler
    static func strip(_ h: HomesBook.Home, last n: Int) -> [ObsBarStrip.Bar] {
        let ms: [HomesBook.Month] = Array((h.months ?? []).suffix(n))
        return ms.map { (m: HomesBook.Month) -> ObsBarStrip.Bar in
            ObsBarStrip.Bar(id: m.m, label: HomeWords.monthLetter(m.m), v: m.v, on: m.whole ?? false, faint: !(m.whole ?? false))
        }
    }
    /// "▲ 12% on a year before"
    static func yoyPill(_ h: HomesBook.Home) -> (text: String, tint: Color, sym: String)? {
        guard let c = HomeWords.yoy(h), abs(c) >= 0.03 else { return nil }
        let p: String = String(Int((abs(c) * 100).rounded())) + "%"
        return c > 0 ? (p + " on a year before", InsightsInk.more, "arrow.up.right") : (p + " under a year before", InsightsInk.less, "arrow.down.right")
    }
}

/// the explanation every page used to end with, behind the ⓘ in the bar
struct HomeInfoButton: View {
    @State private var open: Bool = false
    var body: some View {
        Button { open = true } label: { Image(systemName: "info.circle") }
            .accessibilityLabel("How kosh works out a home’s bills")
            .popover(isPresented: $open) {
                VStack(alignment: .leading, spacing: 10) {
                    Text("How kosh counts a home").font(.headline)
                    Text(HomeInfoButton.words).font(.subheadline).fixedSize(horizontal: false, vertical: true)
                }
                .padding(18)
                .frame(maxWidth: 340)
                .presentationCompactAdaptation(.popover)
            }
    }
    static let words: String = "Bills go to the home they belong to, whoever paid them. Each bill is spread over the days it covers (the period it prints, else the days since the bill before), so a two-month bill counts half in each month and homes compare. A paler month isn’t covered by every connection’s bills yet and isn’t in the average. What’s coming is each connection’s own cycle, at what the same bill cost a year before."
}

/// Insights' section: a dark card that previews the page (the first home large, the others as chips)
struct BillsByHomeSection: View {
    @Environment(Store.self) private var store
    var body: some View {
        let homes: [HomesBook.Home] = store.homes
        let loose: Int = store.unplacedAccts.count
        ObsFeatureCard(caption: "Bills by home", title: "What each home costs to run", chips: Self.chips(homes, loose),
                       hint: "Opens each home’s bills across the year", tap: { store.push(.homes) }) {
            if let h = homes.first {
                HomeSectionHero(h: h)
            } else {
                Text(Self.empty(loose)).font(.subheadline).foregroundStyle(Obsidian.ink2).fixedSize(horizontal: false, vertical: true)
            }
        }
        .privacySensitive()
    }
    static func empty(_ loose: Int) -> String {
        loose > 0 ? SpokenWords.count(loose, "connection", "connections") + " kosh couldn’t place yet: tap to say which home"
            : "Electricity, water, gas, broadband and maintenance, put on the home each belongs to and spread over the days each bill covers. It fills in as kosh reads your bills."
    }
    /// the other homes a month each, and the connections not placed yet
    static func chips(_ homes: [HomesBook.Home], _ loose: Int) -> [ObsChip] {
        var out: [ObsChip] = homes.dropFirst().prefix(2).map { (h: HomesBook.Home) -> ObsChip in
            ObsChip(id: h.id, label: h.name, value: (h.perMonth ?? 0) > 0 ? Fmt.rupees(h.perMonth ?? 0) + " a month" : "Too few bills")
        }
        if loose > 0 { out.append(ObsChip(id: "loose", label: "To place", value: SpokenWords.count(loose, "connection", "connections"), tint: Obsidian.savings)) }
        return Array(out.prefix(3))
    }
}

struct HomeSectionHero: View {
    let h: HomesBook.Home
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(h.name).caption(Obsidian.health)
            HomeMonthFigure(h: h, size: 34)
            if let y = HomeInk.yoyPill(h) { ObsPill(text: y.text, tint: y.tint, sym: y.sym) }
        }
    }
}

/// a home's month on average, large, with "a month" beside it
struct HomeMonthFigure: View {
    let h: HomesBook.Home
    var size: CGFloat = 44
    var body: some View {
        if let pm = h.perMonth, pm > 0 {
            HStack(alignment: .firstTextBaseline, spacing: 6) {
                ObsFigure(text: Fmt.rupees(pm), size: size)
                Text("a month").font(.footnote).foregroundStyle(Obsidian.ink2)
            }
        } else {
            Text("Too few bills yet for a month on average: two whole months at least.").font(.subheadline).foregroundStyle(Obsidian.ink2).fixedSize(horizontal: false, vertical: true)
        }
    }
}

// MARK: every home

/// which home costs more, what each costs, and the connections to place
struct HomesPage: View {
    @Environment(Store.self) private var store
    @State private var placing: HomesBook.Acct?
    var body: some View {
        let homes: [HomesBook.Home] = store.homes
        let loose: [HomesBook.Acct] = store.unplacedAccts
        let both: [HomesBook.Home] = homes.filter { ($0.perMonth ?? 0) > 0 }
        ObsScroll(title: "Bills by home", inline: false) {
            if homes.isEmpty && loose.isEmpty && BillKind.all(store).isEmpty {
                ObsEmpty(title: "No home bills yet", sym: "house", text: "Each home’s bills fill in as kosh reads them: electricity, water, gas, broadband, maintenance.")
            }
            BillsMapSection()
            if both.count >= 2 { HomesCompare(a: both[0], b: both[1]) }
            if !loose.isEmpty { HomesTriage(accts: loose) { (a: HomesBook.Acct) in placing = a } }
            if !homes.isEmpty { ObsHead(text: "Each home", trailing: String(homes.count)) }
            ForEach(Array(homes.enumerated()), id: \.element.id) { (pair: EnumeratedSequence<[HomesBook.Home]>.Element) in
                HomeSummaryRow(h: pair.element).obsArrive(pair.offset)
            }
        }
        .toolbar { ToolbarItem(placement: .topBarTrailing) { HomeInfoButton() } }
        .sheet(item: $placing) { a in PlaceConnectionSheet(a: a) }
    }
}

/// two homes side by side: which costs more, by how much, and on what
struct HomesCompare: View {
    let a: HomesBook.Home
    let b: HomesBook.Home
    var body: some View {
        let rows: [HomeWords.Row] = HomeWords.compare(a, b)
        let ratio: Double = (b.perMonth ?? 0) > 0 ? (a.perMonth ?? 0) / (b.perMonth ?? 1) : 0
        ObsHead(text: "Side by side", trailing: "a month on average")
        VStack(alignment: .leading, spacing: 14) {
            HStack(alignment: .firstTextBaseline) {
                Text(a.name).caption(Obsidian.health).lineLimit(2)
                Spacer(minLength: 8)
                Text(b.name).caption(Obsidian.ulip).lineLimit(2).multilineTextAlignment(.trailing)
            }
            ObsSegBar(segs: [ObsSegBar.Seg(id: "a", v: a.perMonth ?? 0, tint: Obsidian.health), ObsSegBar.Seg(id: "b", v: b.perMonth ?? 0, tint: Obsidian.ulip)], height: 12)
            if ratio > 0 { Text(HomesCompare.headline(a, b, ratio)).font(.subheadline.weight(.semibold)).foregroundStyle(Obsidian.ink).fixedSize(horizontal: false, vertical: true) }
            ObsRule()
            ForEach(rows) { (r: HomeWords.Row) in HomesCompareRow(r: r) }
        }
        .obsidianCard(24, padding: 18)
        .privacySensitive()
    }
    static func headline(_ a: HomesBook.Home, _ b: HomesBook.Home, _ r: Double) -> String {
        if r >= 0.95 && r <= 1.05 { return "The two cost about the same to run" }
        return r > 1 ? a.name + " costs " + String(format: "%.1f", r) + "× " + b.name : b.name + " costs " + String(format: "%.1f", 1 / r) + "× " + a.name
    }
}

struct HomesCompareRow: View {
    let r: HomeWords.Row
    var body: some View {
        HStack(alignment: .firstTextBaseline, spacing: 8) {
            Text(r.a > 0 ? Fmt.rupees(r.a) : "None").font(.subheadline.weight(.semibold)).monospacedDigit().foregroundStyle(r.a >= r.b ? Obsidian.ink : Obsidian.ink2)
                .frame(maxWidth: .infinity, alignment: .leading)
            Text(r.label).caption().lineLimit(1)
            Text(r.b > 0 ? Fmt.rupees(r.b) : "None").font(.subheadline.weight(.semibold)).monospacedDigit().foregroundStyle(r.b >= r.a ? Obsidian.ink : Obsidian.ink2)
                .frame(maxWidth: .infinity, alignment: .trailing)
        }
        .accessibilityElement(children: .combine)
    }
}

/// the connections kosh couldn't place: a line each and its homes as chips, one tap to put it there
struct HomesTriage: View {
    @Environment(Store.self) private var store
    let accts: [HomesBook.Acct]
    let more: (HomesBook.Acct) -> Void
    var body: some View {
        let homes: [HomesBook.Home] = store.homes
        ObsHead(text: "Which home?", trailing: String(accts.count) + " to place")
        VStack(alignment: .leading, spacing: 0) {
            ForEach(Array(accts.enumerated()), id: \.element.id) { (pair: EnumeratedSequence<[HomesBook.Acct]>.Element) in
                if pair.offset > 0 { ObsRule().padding(.vertical, 12) }
                HomesTriageRow(a: pair.element, homes: homes, more: { more(pair.element) })
            }
        }
        .obsidianCard(24, padding: 16)
    }
}

struct HomesTriageRow: View {
    @Environment(Store.self) private var store
    let a: HomesBook.Acct
    let homes: [HomesBook.Home]
    let more: () -> Void
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .top, spacing: 12) {
                HomeKindIcon(k: a.k)
                VStack(alignment: .leading, spacing: 2) {
                    Text(HomeWords.acct(a)).font(.subheadline).foregroundStyle(Obsidian.ink).fixedSize(horizontal: false, vertical: true)
                    Text(ConnectionRow.sub(a)).font(.caption).foregroundStyle(Obsidian.ink2).lineLimit(2)
                }
            }
            ScrollView(.horizontal) {
                HStack(spacing: 8) {
                    ForEach(homes.prefix(4)) { (h: HomesBook.Home) in
                        Button { store.placeConnection(a.id, in: h.id) } label: { HomeChipFace(text: h.name, lit: true) }
                            .buttonStyle(.press)
                    }
                    Button(action: more) { HomeChipFace(text: homes.isEmpty ? "Choose a home" : "Another", lit: false) }
                        .buttonStyle(.press)
                    Button { store.placeConnection(a.id, in: "none") } label: { HomeChipFace(text: "Not a home’s bill", lit: false) }
                        .buttonStyle(.press)
                }
            }
            .scrollIndicators(.hidden)
            .padding(.leading, 44)
        }
        .privacySensitive()
    }
}

/// a chip's face: a home lit, the other choices outlined
struct HomeChipFace: View {
    let text: String
    let lit: Bool
    var body: some View {
        Text(text).font(.footnote.weight(.semibold)).lineLimit(1)
            .foregroundStyle(lit ? Obsidian.ink : Obsidian.ink2)
            .padding(.horizontal, 14)
            .frame(minHeight: 36)
            .background(lit ? Color.white.opacity(0.1) : Color.clear, in: Capsule())
            .overlay(Capsule().strokeBorder(Color.white.opacity(lit ? 0.18 : 0.12), lineWidth: 1))
            .contentShape(Capsule())
    }
}

/// one home in a card: its name, its month on average large, against a year before, its last twelve months as bars
struct HomeSummaryRow: View {
    @Environment(Store.self) private var store
    let h: HomesBook.Home
    static func sub(_ h: HomesBook.Home) -> String {
        var bits: [String] = []
        let kinds: [String] = h.kinds ?? []
        if !kinds.isEmpty { bits.append(kinds.joined(separator: ", ")) }
        if let f = h.from, let t = h.to { bits.append(Day.fmt(f, "MMM yyyy") + " – " + Day.fmt(t, "MMM yyyy")) }
        return bits.joined(separator: " · ")
    }
    var body: some View {
        Button { store.push(.home(h.id)) } label: { row }
            .buttonStyle(.press)
            .privacySensitive()
    }
    private var row: some View {
        VStack(alignment: .leading, spacing: 12) {
            ObsCardHead(title: h.name, tint: Obsidian.health, trailing: (h.alerts ?? []).isEmpty ? "" : String((h.alerts ?? []).count) + " to look at")
            HomeMonthFigure(h: h, size: 32)
            if let y = HomeInk.yoyPill(h) { ObsPill(text: y.text, tint: y.tint, sym: y.sym) }
            if !(h.byKind ?? []).isEmpty { HomeKindBar(h: h, height: 8) }
            Text(Self.sub(h)).font(.footnote).foregroundStyle(Obsidian.ink2).multilineTextAlignment(.leading).fixedSize(horizontal: false, vertical: true)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .obsidianCard(24, padding: 18)
        .contentShape(Rectangle())
    }
}

/// the utilities as one bar, each its colour
struct HomeKindBar: View {
    let h: HomesBook.Home
    var height: CGFloat = 12
    var body: some View {
        ObsSegBar(segs: (h.byKind ?? []).map { (k: HomesBook.KindFig) -> ObsSegBar.Seg in ObsSegBar.Seg(id: k.k, v: k.v, tint: HomeInk.kind(k.k)) }, height: height)
    }
}

// MARK: one home

/// one home's year: what it costs, on what, what's coming, what's worth a look, electricity, the seasons, its
/// connections and bills
struct HomePage: View {
    @Environment(Store.self) private var store
    let id: String
    @State private var placing: HomesBook.Acct?
    var body: some View {
        if let h = store.home(id) {
            ObsScroll(title: h.name, inline: false) {
                HomeHero(h: h)
                HomeWhatItGoesOn(h: h)
                HomeComing(h: h)
                HomeWorthALook(h: h)
                HomeElectricity(h: h)
                HomeSeasons(h: h)
                HomeConnections(h: h) { (a: HomesBook.Acct) in placing = a }
                HomeBillsList(h: h)
            }
            .toolbar { ToolbarItem(placement: .topBarTrailing) { HomeInfoButton() } }
            .sheet(item: $placing) { a in PlaceConnectionSheet(a: a) }
        } else {
            ObsScroll(title: "Home") {
                ObsEmpty(title: "This home has no bills now", sym: "house", text: "Its connections may have moved to another home.")
            }
        }
    }
}

/// what it costs a month: the figure, against a year before, a day's cost, the last twelve months as bars, the peak
struct HomeHero: View {
    let h: HomesBook.Home
    var body: some View {
        let ms: [HomesBook.Month] = Array((h.months ?? []).suffix(12))
        VStack(alignment: .leading, spacing: 14) {
            Text("A month on average" + HomeHero.span(h)).caption(Obsidian.health)
            HomeMonthFigure(h: h)
            HomeHeroPills(h: h)
            if ms.count > 1 {
                ObsRule()
                ObsBarStrip(bars: HomeInk.strip(h, last: 12), height: 72, tint: Obsidian.health)
                    .accessibilityElement(children: .ignore)
                    .spokenFigures(HomeHero.spoken(ms, figures: true), hidden: HomeHero.spoken(ms, figures: false))
                if h.peak != nil { Text(HomeHero.peakLine(h)).caption() }
            }
            if !HomeWords.how(h.by).isEmpty { Text(HomeWords.how(h.by)).font(.caption).foregroundStyle(Obsidian.ink3) }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .obsidianCard(24, padding: 18)
        .privacySensitive()
    }
    /// "Peak: ₹4,200 in June 2026 · lowest ₹1,200 in January"
    static func peakLine(_ h: HomesBook.Home) -> String {
        guard let p = h.peak else { return "" }
        var s: String = "Peak: " + Fmt.rupees(p.v) + " in " + Day.fmt(p.m + "-01", "MMMM yyyy")
        if let l = h.low { s += " · lowest " + Fmt.rupees(l.v) + " in " + Day.fmt(l.m + "-01", "MMMM") }
        return s
    }
    static func span(_ h: HomesBook.Home) -> String {
        guard let f = h.from, let t = h.to else { return "" }
        return " · " + Day.fmt(f, "MMM yy") + " – " + Day.fmt(t, "MMM yy")
    }
    static func spoken(_ ms: [HomesBook.Month], figures: Bool) -> String {
        guard let a = ms.first, let b = ms.last else { return "No months yet" }
        let top: HomesBook.Month? = ms.max { $0.v < $1.v }
        let peak: String = figures && top != nil ? ", the most " + Fmt.rupees(top?.v ?? 0) + " in " + Day.monthName(top?.m ?? a.m) : ""
        return "Bills month by month, " + Day.fmt(a.m + "-01", "MMMM yyyy") + " to " + Day.fmt(b.m + "-01", "MMMM yyyy") + peak
    }
}

struct HomeHeroPills: View {
    let h: HomesBook.Home
    var body: some View {
        ViewThatFits(in: .horizontal) {
            HStack(spacing: 8) { pills }
            VStack(alignment: .leading, spacing: 6) { pills }
        }
    }
    @ViewBuilder private var pills: some View {
        if let y = HomeInk.yoyPill(h) { ObsPill(text: y.text, tint: y.tint, sym: y.sym) }
        if let pd = h.perDay, pd > 0 { ObsPill(text: Fmt.rupees(pd) + " a day", tint: Obsidian.ink2) }
    }
}

/// what it goes on: one bar cut by utility, and a row each with its share
struct HomeWhatItGoesOn: View {
    let h: HomesBook.Home
    var body: some View {
        let ks: [HomesBook.KindFig] = h.byKind ?? []
        if !ks.isEmpty {
            let most: Double = max(1, ks.map(\.v).max() ?? 1)
            ObsHead(text: "What it goes on", trailing: "a month")
            VStack(alignment: .leading, spacing: 16) {
                HomeKindBar(h: h, height: 14)
                ForEach(ks, id: \.k) { (k: HomesBook.KindFig) in
                    ObsKindRow(name: k.k, value: Fmt.rupees(k.v), share: k.v / most, tint: HomeInk.kind(k.k),
                               sub: String(Int((HomeWords.share(k, of: h) * 100).rounded())) + "% of the home’s month")
                }
            }
            .obsidianCard(24, padding: 18)
            .privacySensitive()
        }
    }
}

/// what's coming: each connection's next bill by its cycle, at what it cost a year before
struct HomeComing: View {
    @Environment(Store.self) private var store
    let h: HomesBook.Home
    var body: some View {
        let ns: [HomesBook.Next] = h.next ?? []
        if !ns.isEmpty {
            let total: Double = ns.reduce(0) { $0 + $1.amt }
            ObsHead(text: "Coming up", trailing: "about " + Fmt.rupees(total))
            VStack(alignment: .leading, spacing: 0) {
                ForEach(Array(ns.enumerated()), id: \.element.id) { (pair: EnumeratedSequence<[HomesBook.Next]>.Element) in
                    if pair.offset > 0 { ObsRule(inset: 44).padding(.vertical, 12) }
                    HStack(alignment: .top, spacing: 12) {
                        HomeKindIcon(k: pair.element.k)
                        VStack(alignment: .leading, spacing: 2) {
                            Text(pair.element.k + " · about " + Day.fmt(pair.element.on, "d MMM")).font(.subheadline).foregroundStyle(Obsidian.ink)
                            Text(HomeWords.next(pair.element, money: Fmt.rupees)).font(.caption).foregroundStyle(Obsidian.ink2).fixedSize(horizontal: false, vertical: true)
                        }
                        Spacer(minLength: 8)
                        Text(Fmt.rupees(pair.element.amt)).font(.subheadline.weight(.semibold)).monospacedDigit().foregroundStyle(Obsidian.ink)
                    }
                }
            }
            .obsidianCard(22, padding: 16)
            .privacySensitive()
        }
    }
}

/// what's worth a look: a jump against the same season, a missed cycle, arrears
struct HomeWorthALook: View {
    @Environment(Store.self) private var store
    let h: HomesBook.Home
    var body: some View {
        let al: [HomesBook.Alert] = Array((h.alerts ?? []).prefix(5))
        if !al.isEmpty {
            ObsHead(text: "Worth a look", trailing: String(al.count))
            VStack(alignment: .leading, spacing: 0) {
                ForEach(Array(al.enumerated()), id: \.element.id) { (pair: EnumeratedSequence<[HomesBook.Alert]>.Element) in
                    if pair.offset > 0 { ObsRule(inset: 44).padding(.vertical, 12) }
                    HomeAlertRow(a: pair.element, kind: HomeWorthALook.kind(store, pair.element.acct))
                }
            }
            .obsidianCard(22, padding: 16)
            .privacySensitive()
        }
    }
    @MainActor static func kind(_ store: Store, _ acct: String) -> String {
        (store.snap.homes?.accts ?? []).first { $0.id == acct }?.k ?? "Home"
    }
}

struct HomeAlertRow: View {
    let a: HomesBook.Alert
    let kind: String
    var body: some View {
        let w: (title: String, line: String) = HomeWords.alert(a, kind: kind, money: Fmt.rupees, day: { Day.fmt($0, "d MMM yyyy") })
        let tint: Color = a.k == "missed" ? Obsidian.savings : Obsidian.motor
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: a.k == "missed" ? "calendar.badge.exclamationmark" : a.k == "arrears" ? "clock.arrow.circlepath" : "arrow.up.right")
                .font(.subheadline.weight(.semibold)).foregroundStyle(tint)
                .frame(width: 32, height: 32).background(tint.opacity(0.14), in: RoundedRectangle(cornerRadius: 9, style: .continuous))
            VStack(alignment: .leading, spacing: 3) {
                Text(w.title).font(.subheadline.weight(.semibold)).foregroundStyle(Obsidian.ink).fixedSize(horizontal: false, vertical: true)
                Text(w.line).font(.caption).foregroundStyle(Obsidian.ink2).fixedSize(horizontal: false, vertical: true)
            }
        }
        .accessibilityElement(children: .combine)
    }
}

/// electricity: units a month as bars, and what a unit cost, first month against last
struct HomeElectricity: View {
    let h: HomesBook.Home
    var body: some View {
        let el: [HomesBook.ElecMonth] = h.elec ?? []
        if el.count >= 2, let first = el.first, let last = el.last {
            let unit: String = last.unit ?? "units"
            let avgUnits: Double = el.reduce(0) { $0 + $1.units } / Double(el.count)
            ObsHead(text: "Electricity", trailing: Day.fmt(first.m + "-01", "MMM yy") + " – " + Day.fmt(last.m + "-01", "MMM yy"))
            VStack(alignment: .leading, spacing: 14) {
                HStack(alignment: .top, spacing: 12) {
                    ReviewFigure(label: "Used a month", value: String(Int(avgUnits.rounded())) + " " + unit, tint: Obsidian.savings)
                    ReviewFigure(label: "A unit, " + Day.fmt(last.m + "-01", "MMM"), value: HomeElectricity.rate(last.rate), tint: Obsidian.ink)
                }
                ObsBarStrip(bars: el.map { (e: HomesBook.ElecMonth) -> ObsBarStrip.Bar in ObsBarStrip.Bar(id: e.m, label: HomeWords.monthLetter(e.m), v: e.units, on: e.m == last.m) }, height: 56, tint: Obsidian.savings)
                    .accessibilityElement(children: .ignore)
                    .accessibilityLabel("Units used month by month")
                Text(HomeElectricity.trend(first, last)).font(.footnote).foregroundStyle(Obsidian.ink2).fixedSize(horizontal: false, vertical: true)
            }
            .obsidianCard(22, padding: 16)
            .privacySensitive()
        }
    }
    static func rate(_ r: Double) -> String { "₹" + String(format: "%.2f", r) }
    /// "A unit cost ₹7.10 in Nov 2025 and ₹7.50 in Oct 2026: 6% more"
    static func trend(_ a: HomesBook.ElecMonth, _ b: HomesBook.ElecMonth) -> String {
        let head: String = "A unit cost " + rate(a.rate) + " in " + Day.fmt(a.m + "-01", "MMM yyyy") + " and " + rate(b.rate) + " in " + Day.fmt(b.m + "-01", "MMM yyyy")
        guard a.rate > 0 else { return head }
        let c: Double = (b.rate - a.rate) / a.rate
        if abs(c) < 0.03 { return head + ": about the same" }
        return head + ": " + String(Int((abs(c) * 100).rounded())) + "% " + (c > 0 ? "more" : "less") + " (the bill over its units, taxes and fixed charges in it)"
    }
}

/// summer against winter: is this home seasonal?
struct HomeSeasons: View {
    let h: HomesBook.Home
    var body: some View {
        if let s = h.season {
            ObsHead(text: "Summer vs winter")
            VStack(alignment: .leading, spacing: 16) {
                Text(HomeWords.season(s)).font(.subheadline.weight(.semibold)).foregroundStyle(Obsidian.ink).fixedSize(horizontal: false, vertical: true)
                DeepCompareBar(label: "A summer month (Apr–Jun)", v: s.summer, share: s.summer / max(s.summer, s.winter), tint: Obsidian.motor)
                DeepCompareBar(label: "A winter month (Dec–Feb)", v: s.winter, share: s.winter / max(s.summer, s.winter), tint: Obsidian.ulip)
                Text("From " + String(s.sn) + " summer and " + String(s.wn) + " winter months the bills cover whole").caption()
            }
            .obsidianCard(22, padding: 16)
            .privacySensitive()
        }
    }
}

/// the home's connections: the board, the number's last figures, how kosh knows it is this home, and a way to move it
struct HomeConnections: View {
    @Environment(Store.self) private var store
    let h: HomesBook.Home
    let move: (HomesBook.Acct) -> Void
    var body: some View {
        let accts: [HomesBook.Acct] = store.homeAccts(h.id)
        if !accts.isEmpty {
            ObsHead(text: "Connections", trailing: String(accts.count))
            VStack(alignment: .leading, spacing: 0) {
                ForEach(Array(accts.enumerated()), id: \.element.id) { (pair: EnumeratedSequence<[HomesBook.Acct]>.Element) in
                    if pair.offset > 0 { ObsRule(inset: 44).padding(.vertical, 12) }
                    ConnectionRow(a: pair.element) { move(pair.element) }
                }
            }
            .obsidianCard(22, padding: 16)
        }
    }
}

struct ConnectionRow: View {
    let a: HomesBook.Acct
    let tap: () -> Void
    static func sub(_ a: HomesBook.Acct) -> String {
        var bits: [String] = []
        let n: Int = a.n ?? 0
        bits.append(SpokenWords.count(n, "bill", "bills"))
        if let f = a.from, let t = a.to { bits.append(Day.fmt(f, "d MMM yy") + " – " + Day.fmt(t, "d MMM yy")) }
        if let p = a.per, p > 0 { bits.append("about every " + String(p) + " days") }
        let how: String = HomeWords.how(a.by)
        if !how.isEmpty { bits.append(how) }
        return bits.joined(separator: " · ")
    }
    var body: some View {
        Button(action: tap) {
            HStack(alignment: .top, spacing: 12) {
                HomeKindIcon(k: a.k)
                VStack(alignment: .leading, spacing: 3) {
                    Text(HomeWords.acct(a)).font(.subheadline).foregroundStyle(Obsidian.ink).fixedSize(horizontal: false, vertical: true)
                    Text(Self.sub(a)).font(.caption).foregroundStyle(Obsidian.ink2).fixedSize(horizontal: false, vertical: true)
                }
                Spacer(minLength: 8)
                Image(systemName: "arrow.left.arrow.right").font(.footnote.weight(.semibold)).foregroundStyle(Obsidian.ink2)
                    .frame(width: 36, height: 36).background(Color.white.opacity(0.06), in: Circle())
            }
            .contentShape(Rectangle())
        }
        .buttonStyle(.press)
        .privacySensitive()
        .accessibilityHint("Says which home this connection’s bills belong to")
    }
}

/// a utility's icon on a wash of its colour
struct HomeKindIcon: View {
    let k: String
    var body: some View {
        Image(systemName: HomeWords.sym(k)).font(.subheadline.weight(.semibold)).foregroundStyle(HomeInk.kind(k))
            .frame(width: 32, height: 32)
            .background(HomeInk.kind(k).opacity(0.14), in: RoundedRectangle(cornerRadius: 9, style: .continuous))
            .accessibilityHidden(true)
    }
}

/// the home's bills, newest first: the latest six, the rest a tap away
struct HomeBillsList: View {
    @Environment(Store.self) private var store
    let h: HomesBook.Home
    @State private var all: Bool = false
    var body: some View {
        let bills: [HomesBook.Bill] = store.homeBills(h.id)
        let shown: [HomesBook.Bill] = all ? bills : Array(bills.prefix(6))
        if !bills.isEmpty {
            ObsHead(text: "Bills", trailing: String(bills.count))
            VStack(alignment: .leading, spacing: 0) {
                ForEach(Array(shown.enumerated()), id: \.element.id) { (pair: EnumeratedSequence<[HomesBook.Bill]>.Element) in
                    if pair.offset > 0 { ObsRule(inset: 44).padding(.vertical, 12) }
                    HomeBillRow(b: pair.element)
                }
                if bills.count > 6 {
                    ObsRule().padding(.vertical, 12)
                    Button { withAnimation(Motion.fold(!all)) { all.toggle() } } label: {
                        Text(all ? "Show the latest six" : "All " + String(bills.count) + " bills").font(.footnote.weight(.semibold)).foregroundStyle(InsightsInk.voice)
                            .frame(maxWidth: .infinity, minHeight: 32).contentShape(Rectangle())
                    }
                    .buttonStyle(.press)
                }
            }
            .obsidianCard(22, padding: 16)
        }
    }
}

struct HomeBillRow: View {
    @Environment(Store.self) private var store
    let b: HomesBook.Bill
    var body: some View {
        Button { open() } label: { row }
            .buttonStyle(.press)
            .privacySensitive()
    }
    private func open() {
        if let p = b.paid, store.txn(p) != nil { store.sheet = .tx(p); return }
        let mails: [String] = b.src ?? [b.id]
        store.betaSheet = .source(SourceRef(title: b.k + " bill", mails: mails, type: "due", tint: HomeInk.kind(b.k)))
    }
    private var row: some View {
        let day: (String) -> String = { Day.fmt($0, "d MMM yy") }
        let detail: String = HomeWords.detail(b, money: Fmt.rupees)
        let jump: String? = HomeWords.jump(b, money: Fmt.rupees, day: day)
        return HStack(alignment: .top, spacing: 12) {
            HomeKindIcon(k: b.k)
            VStack(alignment: .leading, spacing: 3) {
                HStack(alignment: .firstTextBaseline) {
                    Text(b.k + " · " + Day.fmt(b.d, "d MMM yy")).font(.subheadline.weight(.medium)).foregroundStyle(Obsidian.ink)
                    Spacer(minLength: 8)
                    Text(Fmt.rupees(b.amt)).font(.subheadline.weight(.semibold)).monospacedDigit().foregroundStyle(Obsidian.ink)
                }
                Text(HomeWords.days(b, day: day)).font(.caption).foregroundStyle(Obsidian.ink2).fixedSize(horizontal: false, vertical: true)
                if !detail.isEmpty { Text(detail).font(.caption).foregroundStyle(Obsidian.ink3).fixedSize(horizontal: false, vertical: true) }
                if let jump { Text(jump).font(.caption.weight(.semibold)).foregroundStyle(Obsidian.motor).fixedSize(horizontal: false, vertical: true) }
            }
        }
        .contentShape(Rectangle())
    }
}

/// which home a connection is: a home kosh knows, a property, one you name, or no home's; kosh learns it for good
struct PlaceConnectionSheet: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    let a: HomesBook.Acct
    @State private var name: String = ""
    @FocusState private var naming: Bool
    struct Choice: Identifiable, Hashable { let id: String; let name: String }
    static func choices(_ homes: [HomesBook.Home], _ props: [Prop]) -> [Choice] {
        var out: [Choice] = homes.map { Choice(id: $0.id, name: $0.name) }
        for p in props {
            let id: String = "p:" + (p.uid ?? p.pid)
            if !out.contains(where: { $0.id == id }) { out.append(Choice(id: id, name: p.short.isEmpty ? p.name : p.short)) }
        }
        return out
    }
    /// "25/26, Bhutani Associates Pvt Ltd" → plate "25/26", name "Bhutani Associates Pvt Ltd"; a name without a door
    /// number keeps it whole
    static func split(_ n: String) -> (plate: String?, title: String) {
        let parts: [String] = n.split(separator: ",", maxSplits: 1).map { $0.trimmingCharacters(in: .whitespaces) }
        if parts.count == 2, parts[0].count <= 10, parts[0].contains(where: { $0.isNumber }), !parts[1].isEmpty {
            return (parts[0], parts[1])
        }
        return (nil, n)
    }
    var body: some View {
        let list: [Choice] = Self.choices(store.homes, store.snap.prop.props)
        let tint: Color = HomeInk.kind(a.k)
        let ready: Bool = !name.trimmingCharacters(in: .whitespaces).isEmpty
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                HStack(alignment: .top) {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("Place this connection").caption()
                        Text("Which home?").font(.system(size: 30, weight: .bold)).foregroundStyle(Obsidian.ink)
                    }
                    Spacer(minLength: 8)
                    Button { dismiss() } label: {
                        Image(systemName: "xmark").font(.system(size: 13, weight: .bold)).foregroundStyle(Obsidian.ink2)
                            .frame(width: 32, height: 32).background(Color.white.opacity(0.08), in: Circle())
                    }
                    .buttonStyle(.press)
                    .accessibilityLabel("Close")
                }
                HStack(spacing: 12) {
                    HomeKindIcon(k: a.k)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(HomeWords.acct(a)).font(.subheadline.weight(.medium)).foregroundStyle(Obsidian.ink).fixedSize(horizontal: false, vertical: true)
                        Text(ConnectionRow.sub(a)).font(.caption).foregroundStyle(Obsidian.ink3).lineLimit(2)
                    }
                    Spacer(minLength: 0)
                }
                .padding(14)
                .background(tint.opacity(0.07), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).strokeBorder(tint.opacity(0.22), lineWidth: 1))

                if !list.isEmpty {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Your homes").caption()
                        VStack(spacing: 0) {
                            ForEach(Array(list.enumerated()), id: \.element.id) { i, c in
                                if i > 0 { ObsRule(inset: 58) }
                                let sp = Self.split(c.name)
                                let on: Bool = (a.home ?? "") == c.id
                                Button {
                                    store.placeConnection(a.id, in: c.id)
                                    dismiss()
                                } label: {
                                    HStack(spacing: 14) {
                                        PlacePlate(text: sp.plate, prop: c.id.hasPrefix("p:"), tint: tint, on: on)
                                        Text(sp.title).font(.body.weight(.medium)).foregroundStyle(Obsidian.ink).lineLimit(2)
                                            .multilineTextAlignment(.leading)
                                        Spacer(minLength: 8)
                                        Image(systemName: on ? "checkmark.circle.fill" : "chevron.right")
                                            .font(on ? .title3 : .caption.weight(.bold))
                                            .foregroundStyle(on ? tint : Obsidian.ink3)
                                    }
                                    .padding(.vertical, 12)
                                    .contentShape(Rectangle())
                                }
                                .buttonStyle(.press)
                                .accessibilityLabel(c.name + (on ? ", chosen" : ""))
                            }
                        }
                        .padding(.horizontal, 14)
                        .background(Obsidian.card, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
                        .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).strokeBorder(Obsidian.cardBorder, lineWidth: 1))
                        Text("Every bill of this connection, before and after, goes to the home you pick.")
                            .font(.caption).foregroundStyle(Obsidian.ink3).padding(.horizontal, 4)
                    }
                }

                VStack(alignment: .leading, spacing: 10) {
                    Text("A home of its own").caption()
                    HStack(spacing: 10) {
                        Image(systemName: "house").font(.subheadline.weight(.semibold)).foregroundStyle(Obsidian.ink3).frame(width: 22)
                        TextField("", text: $name, prompt: Text("Name it, like “The Pune flat”").foregroundStyle(Obsidian.ink3))
                            .foregroundStyle(Obsidian.ink)
                            .focused($naming)
                            .submitLabel(.done)
                            .onSubmit { if ready { store.newHome(name, with: a.id); dismiss() } }
                        Button {
                            store.newHome(name, with: a.id)
                            dismiss()
                        } label: {
                            Image(systemName: "arrow.up").font(.system(size: 14, weight: .bold))
                                .foregroundStyle(ready ? Color.black : Obsidian.ink3)
                                .frame(width: 32, height: 32)
                                .background(ready ? tint : Color.white.opacity(0.08), in: Circle())
                        }
                        .buttonStyle(.press)
                        .disabled(!ready)
                        .accessibilityLabel("Add and put it there")
                    }
                    .padding(.leading, 14).padding(.trailing, 8).frame(minHeight: 52)
                    .background(Obsidian.card, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous)
                        .strokeBorder(naming ? tint.opacity(0.5) : Obsidian.cardBorder, lineWidth: 1))
                    .animation(Motion.base, value: naming)
                }

                HStack(spacing: 10) {
                    Button {
                        store.placeConnection(a.id, in: "none")
                        dismiss()
                    } label: { PlaceQuiet(text: "Not a home’s bill", sym: "nosign") }
                    .buttonStyle(.press)
                    if a.by == "you" {
                        Button {
                            store.placeConnection(a.id, in: "")
                            dismiss()
                        } label: { PlaceQuiet(text: "Let kosh decide", sym: "sparkles") }
                        .buttonStyle(.press)
                    }
                }
            }
            .padding(.horizontal, 20)
            .padding(.top, 26)
            .padding(.bottom, 30)
        }
        .scrollDismissesKeyboard(.interactively)
        .background(alignment: .top) { ObsidianAura(tint: tint) }
        .background(Obsidian.bg.ignoresSafeArea())
        .presentationDetents([.medium, .large])
        .presentationDragIndicator(.visible)
        .presentationCornerRadius(32)
        .presentationBackground(Obsidian.bg)
        .environment(\.colorScheme, .dark)
    }
}

/// a home's door number on a small plate, or a house (a property: a building) when it has none
struct PlacePlate: View {
    let text: String?
    let prop: Bool
    let tint: Color
    let on: Bool
    var body: some View {
        Group {
            if let text {
                Text(text).font(.system(size: text.count > 4 ? 10 : 13, weight: .semibold, design: .monospaced))
                    .minimumScaleFactor(0.6).lineLimit(1)
            } else {
                Image(systemName: prop ? "building.2" : "house").font(.subheadline.weight(.semibold))
            }
        }
        .foregroundStyle(on ? Color.black : Obsidian.ink)
        .padding(.horizontal, 4)
        .frame(width: 44, height: 36)
        .background(on ? tint : Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 10, style: .continuous).strokeBorder(Color.white.opacity(on ? 0 : 0.08), lineWidth: 1))
        .accessibilityHidden(true)
    }
}

/// a quiet way out of the sheet, half the width
struct PlaceQuiet: View {
    let text: String
    let sym: String
    var body: some View {
        HStack(spacing: 8) {
            Image(systemName: sym).font(.footnote.weight(.semibold))
            Text(text).font(.subheadline.weight(.medium)).lineLimit(1).minimumScaleFactor(0.85)
        }
        .foregroundStyle(Obsidian.ink2)
        .frame(maxWidth: .infinity, minHeight: 48)
        .background(Color.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).strokeBorder(Obsidian.cardBorder, lineWidth: 1))
        .contentShape(Rectangle())
    }
}
