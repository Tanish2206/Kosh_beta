import Foundation

// MARK: - A change you make, on screen the moment you tap it
//
// Most of what you tell kosh (a bill paid, a repeat cancelled or not one, a card's limit, a policy ended, a draft that
// isn't a trip) is saved and laid out again by the engine, which takes seconds on a phone while kosh reads. The tap
// shouldn't wait for that. LiveSession, where each change is made, also says how the screens change with it, by the
// engine's own rule for that one thing (LiveSession+Shown.swift); the screens change at once, and the build that
// follows confirms it. A build that started before the tap knows nothing of it, so the change is laid over that one
// too, as a payment's own change is (Store.edits) and rent marked received (Store.rentMarks); once a build that started
// after the tap lands, the engine's figure stands and the change is let go. Only the thing tapped changes at once: the
// totals it feeds (what's left to spend, net worth) follow with the build, a moment later.

extension Store {
    /// one change shown before its build: what it changes (a second tap on the same thing replaces the first), the build
    /// that was running when you tapped, and the change itself (it sets a value, never toggles one, so laying it over
    /// a build again is harmless)
    struct Shown {
        var key: String
        var gen: Int
        /// what it adds to the month's spending until its build counts it (a spend added by hand: Store.added)
        var added: Double = 0
        var change: (inout Snapshot) -> Void
    }

    /// show a change on the screens now (LiveSession.showNow hands it here); `feel`: a light tap under your finger;
    /// `rows`: it changes the payments, so the ledger takes them again; `added`: what it adds to the month's spending
    func showNow(_ key: String, feel: Bool = true, rows: Bool = false, added more: Double = 0, _ change: @escaping (inout Snapshot) -> Void) {
        guard let live else { return }
        shown.removeAll { (x: Shown) -> Bool in x.key == key }
        shown.append(Shown(key: key, gen: live.buildGen, added: more, change: change))
        Perf.shared.measure("a change shown at once") {
            var s: Snapshot = snap.value
            change(&s)
            snap.replace(with: s)
            if rows {
                // (the payments as a build hands them over, with the changes on an open sheet still over them)
                var fresh: [Txn] = s.tx.filter { $0.mr != true }
                for (id, t) in edits { if let i = fresh.firstIndex(where: { $0.id == id }) { fresh[i] = t } }
                if fresh != tx { tx = fresh }
            }
            let more: Double = shownAdded
            if more != added { added = more }
        }
        if feel { felt &+= 1 }
    }

    /// what the changes still waiting for their build add to the month's spending
    var shownAdded: Double { shown.reduce(0) { (sum: Double, x: Shown) -> Double in sum + x.added } }

    /// a fresh build with the changes it was laid out without put over it; the ones it already has are let go
    func keepShown(_ s: Snapshot) -> Snapshot {
        guard !shown.isEmpty else { return s }
        let landed: Int = live?.buildGen ?? Int.max
        shown.removeAll { (x: Shown) -> Bool in landed > x.gen }
        guard !shown.isEmpty else { return s }
        var out: Snapshot = s
        for x in shown { x.change(&out) }
        return out
    }
}
