import SwiftUI
import UIKit

// MARK: - The intro: a drawing at one size, and what it needs from the screen each frame
// (split out of KoshIntro.swift, 30 Oct 2026; the beats and what each draws are described there)

// MARK: - A drawing at one size: where everything sits and how each string bends

enum IntroLabelMode {
    case inside
    case below
    case left
    case radial(CGPoint)
}

struct IntroStrand {
    var pts: [CGPoint]
    let edge: Int          // -1 for the butterfly's antennae
    let seed: Double
    let a0: Double         // where it lands on the ring at the end
    let span: Double
    let rj: Double
    let r: Double
    var delay: Double = 0
    var cs: Double = 0     // outer strings reach the ring last
}

struct IntroLogoPlace {
    var tw: CGFloat = 100
    var s: CGFloat = 3
    var tcy: CGFloat = 0
    var coinY: CGFloat = 0
    var fs: CGFloat = 34
    var wordY: CGFloat = 60
    var r0: CGFloat = 60
    var rc: CGFloat = 12
}

final class IntroScene {
    let look: IntroLook
    let size: CGSize
    let origin: CGPoint
    let hu: CGFloat
    var pos: [CGPoint]
    var pill: [Bool]
    var hw: [CGFloat]
    var hh: [CGFloat]
    var tw: [CGFloat]
    var label: [IntroLabelMode]
    var strands: [IntroStrand] = []
    var byEdge: [[Int]]
    var outlines: [[CGPoint]] = []
    var chords: [[CGPoint]] = []
    var chordDelay: [Double] = []
    var guides: [(x: CGFloat, y0: CGFloat, y1: CGFloat)] = []
    var lz: (lx: CGFloat, ly: CGFloat, oy: CGFloat)? = nil
    var logo: IntroLogoPlace = IntroLogoPlace()
    private let g: IntroGraph = IntroGraph.shared

    static let labelFont: UIFont = UIFont.monospacedSystemFont(ofSize: 9.5, weight: .medium)
    static let strandsPerEdge: Int = 3

    init(look: IntroLook, size: CGSize) {
        let h: CGFloat = max(120, size.height - 34)
        let n: Int = IntroGraph.shared.nodes.count
        self.look = look
        self.size = size
        hu = h
        // the wings take the room the width allows; any height left over goes above them, so the drawing sits just over
        // the words instead of floating in the middle with a gap beneath
        let wing: (sx: CGFloat, sy: CGFloat) = IntroScene.wingScale(width: size.width, hu: h)
        let slack: CGFloat = max(0, (h / 2 - 26) - wing.sy)
        origin = CGPoint(x: size.width / 2, y: h / 2 + 4 + slack * 0.8)
        pos = Array(repeating: .zero, count: n)
        pill = Array(repeating: false, count: n)
        hw = Array(repeating: 0, count: n)
        hh = Array(repeating: 8, count: n)
        tw = Array(repeating: 0, count: n)
        label = Array(repeating: .below, count: n)
        byEdge = Array(repeating: [], count: IntroGraph.shared.edges.count)
        for (i, node) in g.nodes.enumerated() {
            let w: CGFloat = (node.name as NSString).size(withAttributes: [.font: IntroScene.labelFont]).width
            tw[i] = w
            hw[i] = w / 2 + 8
            pill[i] = node.tier == .portal
            label[i] = node.tier == .portal ? .inside : .below
        }
        buildWings()
        var maxR: CGFloat = 1
        for st in strands {
            maxR = max(maxR, hypot(st.pts[0].x, st.pts[0].y), hypot(st.pts[st.pts.count - 1].x, st.pts[st.pts.count - 1].y))
        }
        for i in strands.indices {
            let st: IntroStrand = strands[i]
            let dIn: CGFloat = hypot(st.pts[0].x, st.pts[0].y)
            let dOut: CGFloat = hypot(st.pts[st.pts.count - 1].x, st.pts[st.pts.count - 1].y)
            strands[i].delay = 0.12 + Double(dIn / maxR) * 0.9 + st.r * 0.12
            strands[i].cs = IntroMath.clamp(Double(dOut / maxR))
        }
        // the logo's place: the tile and the word beneath it, centred together
        let tile: CGFloat = min(size.width * 0.34, hu * 0.32, 136)
        let gap: CGFloat = tile * 0.17
        let fs: CGFloat = (tile * 0.34).rounded()
        let group: CGFloat = tile + gap + fs
        let s: CGFloat = tile / 30.72
        let tcy: CGFloat = -group / 2 + tile / 2
        logo = IntroLogoPlace(tw: tile, s: s, tcy: tcy, coinY: tcy + 0.85 * s, fs: fs, wordY: -group / 2 + tile + gap + fs * 0.52,
                              r0: tile * 0.66, rc: 3.7 * s)
    }

    /// the butterfly's half-width and half-height for a canvas this wide and this tall
    static func wingScale(width: CGFloat, hu: CGFloat) -> (sx: CGFloat, sy: CGFloat) {
        let sx: CGFloat = max(60, min(width / 2 - 62, (hu / 2 - 26) * 0.8))
        let sy: CGFloat = max(60, min(hu / 2 - 26, sx * 1.6))
        return (sx, sy)
    }

    private func pillEdge(_ n: Int, _ side: CGFloat) -> CGPoint { CGPoint(x: pos[n].x + side * (hw[n] + 1), y: pos[n].y) }

    /// three strings per route segment; `make` returns the polyline from the inner ("to") end outward
    private func eachEdge(_ make: (IntroEdge, Int, inout IntroRNG) -> [CGPoint]) {
        for (ei, e) in g.edges.enumerated() {
            var rng = IntroRNG(key: e.key + look.rawValue)
            for s in 0..<IntroScene.strandsPerEdge {
                let pts: [CGPoint] = make(e, s, &rng)
                byEdge[ei].append(strands.count)
                strands.append(IntroStrand(pts: pts, edge: ei, seed: rng.next() * 100, a0: rng.next() * Double.pi * 2,
                                           span: Double.pi * (0.55 + rng.next() * 0.75), rj: (rng.next() - 0.5) * 16, r: rng.next()))
            }
        }
    }

    // Wings: string art in the shape of a butterfly; where money leaves on the wing edge, what it becomes inside, its papers down the body
    private func buildWings() {
        let wing: (sx: CGFloat, sy: CGFloat) = IntroScene.wingScale(width: size.width, hu: hu)
        let sx: CGFloat = wing.sx
        let sy: CGFloat = wing.sy
        let pillH: CGFloat = max(6, min(9, (0.14 * sy - 6) / 2))
        for (i, node) in g.nodes.enumerated() {
            pos[i] = CGPoint(x: node.wx * sx, y: node.wy * sy)
            if node.tier == .portal || node.head {
                pill[i] = true
                hh[i] = pillH
                label[i] = .inside
            } else {
                label[i] = node.tier == .app ? .radial(.zero) : .below
            }
        }
        eachEdge { (e: IntroEdge, s: Int, rng: inout IntroRNG) -> [CGPoint] in
            let a: CGPoint = pos[e.from]
            let k: CGFloat = 0.72 + CGFloat(s) * 0.2 + CGFloat(rng.next()) * 0.12
            if e.aw {
                let b: CGPoint = pos[e.to]
                let mx: CGFloat = (a.x + b.x) / 2
                let my: CGFloat = (a.y + b.y) / 2
                let ml: CGFloat = max(0.001, hypot(mx, my))
                let ux: CGFloat = mx / ml
                let uy: CGFloat = my / ml
                let dx: CGFloat = a.x - b.x
                let dy: CGFloat = a.y - b.y
                let d: CGFloat = max(0.001, hypot(dx, dy))
                let px: CGFloat = -dy / d
                let py: CGFloat = dx / d
                let off: CGFloat = (CGFloat(s) - 1) * 3.5 + CGFloat(rng.next() - 0.5) * 2
                let bow1: CGFloat = d * 0.26 * k
                let bow2: CGFloat = d * 0.17 * k
                let x1: CGFloat = b.x + dx * 0.32 + ux * bow1 + px * off
                let y1: CGFloat = b.y + dy * 0.32 + uy * bow1 + py * off
                let x2: CGFloat = b.x + dx * 0.74 + ux * bow2 + px * off * 0.6
                let y2: CGFloat = b.y + dy * 0.74 + uy * bow2 + py * off * 0.6
                let c1: CGPoint = CGPoint(x: x1, y: y1)
                let c2: CGPoint = CGPoint(x: x2, y: y2)
                return IntroMath.bez(rng.jig(b, 1.2), c1, c2, rng.jig(a, 1.6), 22)
            }
            let head: Bool = g.nodes[e.from].head
            let side: CGFloat = head ? (g.nodes[e.to].idx % 2 == 1 ? 1 : -1) : CGFloat(g.nodes[e.from].side)
            let b: CGPoint = pillEdge(e.to, side)
            let c1: CGPoint
            let c2: CGPoint
            if head {
                let i: CGFloat = CGFloat(g.nodes[e.to].idx)
                c1 = CGPoint(x: b.x + side * (26 + i * 9) * k, y: b.y - 12 + CGFloat(rng.next() - 0.5) * 6)
                c2 = CGPoint(x: side * (22 + i * 7) * k, y: a.y + 18 + CGFloat(rng.next() - 0.5) * 6)
            } else {
                c1 = CGPoint(x: b.x + side * max(26, abs(a.x - b.x) * 0.55) * k, y: b.y + CGFloat(rng.next() - 0.5) * 5)
                c2 = CGPoint(x: a.x + side * 8 * k, y: a.y + (b.y - a.y) * 0.45 + CGFloat(rng.next() - 0.5) * 6)
            }
            return IntroMath.bez(rng.jig(b, 1.2), c1, c2, rng.jig(a, 1.6), 22)
        }
        // antennae off the head
        if let head = g.nodes.firstIndex(where: { (x: IntroNode) -> Bool in x.head }) {
            var rng = IntroRNG(key: "antennae")
            for sd in [CGFloat(-1), CGFloat(1)] {
                let p0: CGPoint = CGPoint(x: sd * 6, y: pos[head].y - hh[head])
                let p1: CGPoint = CGPoint(x: sd * 0.02 * sx, y: pos[head].y - 0.16 * sy)
                let p2: CGPoint = CGPoint(x: sd * 0.10 * sx, y: -1.01 * sy)
                let p3: CGPoint = CGPoint(x: sd * 0.14 * sx, y: -1.07 * sy)
                strands.append(IntroStrand(pts: IntroMath.bez(p0, p1, p2, p3, 16), edge: -1, seed: rng.next() * 100, a0: rng.next() * Double.pi * 2,
                                           span: Double.pi * (0.55 + rng.next() * 0.75), rj: (rng.next() - 0.5) * 16, r: rng.next()))
            }
        }
        // the wing outline and its string-art chords
        let shape: [CGPoint] = [CGPoint(x: 0.05, y: -0.48), CGPoint(x: 0.14, y: -0.80), CGPoint(x: 0.34, y: -0.92), CGPoint(x: 0.70, y: -1.0),
                                CGPoint(x: 0.98, y: -0.84), CGPoint(x: 1.0, y: -0.60), CGPoint(x: 0.90, y: -0.34), CGPoint(x: 0.70, y: -0.12),
                                CGPoint(x: 0.48, y: -0.02), CGPoint(x: 0.66, y: 0.10), CGPoint(x: 0.84, y: 0.32), CGPoint(x: 0.70, y: 0.66),
                                CGPoint(x: 0.38, y: 0.90), CGPoint(x: 0.16, y: 0.80), CGPoint(x: 0.06, y: 0.46), CGPoint(x: 0.04, y: 0.10)]
        for sd in [CGFloat(-1), CGFloat(1)] {
            let ring: [CGPoint] = IntroMath.loop(shape.map { (p: CGPoint) -> CGPoint in CGPoint(x: sd * p.x * sx, y: p.y * sy) }, per: 6)
            outlines.append(ring + [ring[0]])
            let m: Int = ring.count
            for i in 0..<m {
                chords.append([ring[i], ring[(i + 8) % m]])
                chordDelay.append(0.35 + Double(i) / Double(m) * 1.2)
                if i % 2 == 0 {
                    chords.append([ring[i], ring[(i + 21) % m]])
                    chordDelay.append(0.55 + Double(i) / Double(m) * 1.2)
                }
            }
        }
    }
}

// MARK: - What the drawing needs from the screen each frame

struct IntroInput {
    var beat: Int
    var focus: Int?
    var story: Int
    var look: IntroLook
    var still: Bool
    var dragging: Bool
}

struct IntroRipple {
    let p: CGPoint
    let a: CGFloat
    let t: Double
}

struct IntroSpark {
    let parts: [(strand: Int, rev: Bool)]
    let total: Int
    let tiers: [IntroTier]
    let t0: Double
    let dur: Double
    let end: Int
}
