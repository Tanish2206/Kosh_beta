import Foundation
import CryptoKit
import CommonCrypto
import JavaScriptCore

// MARK: - The phone's own hashes, lent to the engine
//
// Screen-free and app-free (only Foundation, CryptoKit, CommonCrypto and JavaScriptCore), so engine-test/native-hash.js
// compiles it with swiftc on the Mac and holds it to Node's hashes and to unlock.js's own.

/// The two slow steps of opening them, lent to unlock.js: Excel's hash spun 100,000 times (about 12 seconds in the
/// engine, which runs without a JIT on the phone; a twentieth of a second here) and WinZip AES's PBKDF2-SHA1. Each
/// takes and gives base64; an answer of "" sends unlock.js back to its own, slower, code (the same key either way).
enum KoshNative {
    static func install(in ctx: JSContext) {
        let spin: @convention(block) (String, String, Int) -> String = { name, start, count in
            KoshNative.spin(name, start, count)
        }
        let pbkdf2: @convention(block) (String, String, Int, Int) -> String = { password, salt, rounds, length in
            KoshNative.pbkdf2(password, salt, rounds, length)
        }
        guard let native = JSValue(newObjectIn: ctx) else { return }
        // (a block handed to JavaScriptCore as the Objective-C block it is)
        native.setObject(unsafeBitCast(spin, to: AnyObject.self), forKeyedSubscript: "spin" as NSString)
        native.setObject(unsafeBitCast(pbkdf2, to: AnyObject.self), forKeyedSubscript: "pbkdf2" as NSString)
        ctx.setObject(native, forKeyedSubscript: "KoshNative" as NSString)
    }

    static let sizes: [String: Int] = ["SHA1": 20, "SHA256": 32, "SHA384": 48, "SHA512": 64]

    /// the hash of (i as four bytes, little-endian, then the last hash), count times over
    static func spin(_ name: String, _ start: String, _ count: Int) -> String {
        guard let size = sizes[name], let first = Data(base64Encoded: start), first.count == size, count > 0, count <= 10_000_000 else { return "" }
        var h: [UInt8] = Array(first)
        var buf: [UInt8] = [UInt8](repeating: 0, count: 4 + size)
        for i in 0..<count {
            let n: UInt32 = UInt32(truncatingIfNeeded: i)
            buf[0] = UInt8(truncatingIfNeeded: n)
            buf[1] = UInt8(truncatingIfNeeded: n >> 8)
            buf[2] = UInt8(truncatingIfNeeded: n >> 16)
            buf[3] = UInt8(truncatingIfNeeded: n >> 24)
            buf.replaceSubrange(4..<(4 + size), with: h)
            switch name {
            case "SHA1": h = Array(Insecure.SHA1.hash(data: buf))
            case "SHA256": h = Array(SHA256.hash(data: buf))
            case "SHA384": h = Array(SHA384.hash(data: buf))
            default: h = Array(SHA512.hash(data: buf))
            }
        }
        return Data(h).base64EncodedString()
    }

    /// PBKDF2 with HMAC-SHA1 (WinZip AES's key, salt and password verifier)
    static func pbkdf2(_ password: String, _ salt: String, _ rounds: Int, _ length: Int) -> String {
        guard let pw = Data(base64Encoded: password), let s = Data(base64Encoded: salt), !pw.isEmpty, !s.isEmpty,
              rounds > 0, rounds <= 10_000_000, length > 0, length <= 1024 else { return "" }
        var out: [UInt8] = [UInt8](repeating: 0, count: length)
        let status: Int32 = out.withUnsafeMutableBytes { (o: UnsafeMutableRawBufferPointer) -> Int32 in
            pw.withUnsafeBytes { (p: UnsafeRawBufferPointer) -> Int32 in
                s.withUnsafeBytes { (q: UnsafeRawBufferPointer) -> Int32 in
                    CCKeyDerivationPBKDF(CCPBKDFAlgorithm(kCCPBKDF2),
                                         p.bindMemory(to: CChar.self).baseAddress, pw.count,
                                         q.bindMemory(to: UInt8.self).baseAddress, s.count,
                                         CCPseudoRandomAlgorithm(kCCPRFHmacAlgSHA1), UInt32(rounds),
                                         o.bindMemory(to: UInt8.self).baseAddress, length)
                }
            }
        }
        return status == Int32(kCCSuccess) ? Data(out).base64EncodedString() : ""
    }
}
