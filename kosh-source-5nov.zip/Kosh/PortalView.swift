import SwiftUI
import WebKit

// MARK: - A state's property-tax portal, inside kosh
//
// The portal opens here as it would in Safari. You log in yourself (mobile number and OTP; kosh
// never sees or types them). As you open each property's page, kosh reads what the page shows,
// the PID, owner, area and dues, and files it under Property. Nothing is sent anywhere.

struct PortalSheet: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    /// the state ("Maharashtra"), or a property's state and city ("Maharashtra|Pune") for its city's own portal
    let state: String
    @State private var read: [String: String] = [:]     // PID -> one line about it
    @State private var page = ""
    @State private var loading = true
    @State private var reloadTick = 0
    @State private var jump: URL?
    @State private var jumpTick = 0
    @State private var reading = false
    /// property pages kosh opens one after another once the list is read (each PID's details)
    @State private var queue: [URL] = []
    @State private var walked = false
    @State private var walkTotal = 0
    @State private var advancedFor = ""

    /// the page that lists every property on your login, where the portal has one
    static let listPage: [String: URL] = ["Haryana": URL(string: "https://property.ulbharyana.gov.in/SearchProperty/MyProperties")!]
    /// on that list, the links to each property's own details page (opened to read, never to submit)
    static let detailLink: [String: String] = ["Haryana": "/RegisterProperty/NewApplication"]

    var portal: LiveSession.Portal? { LiveSession.portal(key: state) }
    /// the state alone: what the page readers and the properties are filed under
    var stateName: String { state.components(separatedBy: "|").first ?? state }

    var body: some View {
        NavigationStack {
            Group {
                if let p = portal, let url = URL(string: p.url) {
                    PortalWebView(url: url, reload: reloadTick, jump: jump, jumpTick: jumpTick, detailPath: Self.detailLink[stateName],
                                  onPhoto: { pid, data in store.live?.savePropertyPhoto(pid: pid, jpeg: data) }, loading: $loading) { text, pageURL, details in
                        page = pageURL
                        guard let live = store.live else { return }
                        // the list is read: open each property's details in turn, for the full breakdown
                        if !walked, details.count > 0 {
                            walked = true
                            queue = details.compactMap(URL.init(string:))
                            walkTotal = queue.count
                            nextDetail()
                        } else if !queue.isEmpty || walkTotal > 0, Self.detailLink[stateName].map({ pageURL.contains($0) }) == true, advancedFor != pageURL {
                            // once per page, however often its text changes while it settles
                            advancedFor = pageURL
                            DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) { nextDetail() }
                        }
                        let lines = live.applyPortalPage(text, state: stateName, portal: p)
                        for (pid, line) in lines { read[pid] = line }
                        // a layout the rules don't know: kosh-reader has a go at it on the phone
                        if lines.isEmpty {
                            Task { @MainActor in
                                reading = true
                                for (pid, line) in await live.readPortalPageWithModel(text, state: stateName, portal: p) { read[pid] = line + " · kosh-reader" }
                                reading = false
                            }
                        }
                    }
                    .ignoresSafeArea(edges: .bottom)
                } else {
                    ContentUnavailableView("No portal for \(stateName) yet", systemImage: "building.columns", description: Text("kosh knows the portals of 47 places; this one isn’t among them."))
                }
            }
            .safeAreaInset(edge: .bottom, spacing: 0) { tray }
            .navigationTitle(portal?.name ?? "Property tax")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Done") { dismiss() } }
                ToolbarItem(placement: .primaryAction) {
                    Button { reloadTick += 1 } label: { Image(systemName: loading ? "hourglass" : "arrow.clockwise") }
                        .accessibilityLabel(loading ? "Loading" : "Load the page again")
                }
                if let list = Self.listPage[stateName] {
                    ToolbarItem(placement: .bottomBar) {
                        Button { jump = list; jumpTick += 1 } label: { Label("My properties", systemImage: "list.bullet.rectangle") }
                    }
                }
            }
        }
    }

    /// the next property's details, or back to the list when they're all read
    func nextDetail() {
        if let u = queue.first {
            queue.removeFirst()
            jump = u; jumpTick += 1
        } else if walkTotal > 0, let list = Self.listPage[stateName] {
            walkTotal = 0
            jump = list; jumpTick += 1
        }
    }

    var tray: some View {
        VStack(alignment: .leading, spacing: 6) {
            if reading {
                Label("Reading this page…", systemImage: "sparkles")
                    .font(.footnote).foregroundStyle(.secondary)
            }
            if walkTotal > 0 {
                VStack(alignment: .leading, spacing: 6) {
                    Text("Opening each property’s details · \(walkTotal - queue.count) of \(walkTotal)")
                        .font(.footnote.weight(.semibold))
                    GlowBar(value: Double(walkTotal - queue.count) / Double(max(1, walkTotal)), active: true, height: 8)
                }
            }
            if read.isEmpty {
                Label("Log in with your mobile and OTP, then open My Properties. kosh reads every PID on your number and opens each one’s details by itself: owner, area, floors and the dues broken down. It only reads; it never submits or pays.", systemImage: "info.circle")
                    .font(.footnote).foregroundStyle(.secondary)
            } else {
                Label("Read \(read.count) propert\(read.count == 1 ? "y" : "ies") into kosh", systemImage: "checkmark.circle.fill")
                    .font(.subheadline.weight(.semibold)).foregroundStyle(Color.green)
                ForEach(read.keys.sorted(), id: \.self) { pid in
                    Text(read[pid] ?? pid).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                }
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.horizontal, 16)
        .padding(.vertical, 10)
        .background(.bar)
    }
}

/// The portal page itself. Each time a page settles, its visible text comes back to kosh.
struct PortalWebView: UIViewRepresentable {
    let url: URL
    let reload: Int
    var jump: URL? = nil
    var jumpTick = 0
    var detailPath: String? = nil
    /// open the page a menu entry with this label leads to, as a tap on it would (bumped by followTick)
    var follow: String? = nil
    var followTick = 0
    /// a number kosh already knows, put in the box that asks for it, to save typing it again: the UAN on the EPFO's
    /// login (fillLabel says which box). Only ever an identifier a paper already printed — never a password, never a
    /// captcha, never an OTP — and nothing is submitted: the person still fills the rest and presses the button.
    var fill: String? = nil
    var fillLabel = "uan"
    var fillTick = 0
    var onPhoto: ((String, Data) -> Void)? = nil
    /// a page that didn't load after every try (EPFKeep.again), with the system's reason: so a site that is down says
    /// so, instead of an hourglass that never stops
    var onFail: ((String) -> Void)? = nil
    @Binding var loading: Bool
    let onText: (String, String, [String]) -> Void

    func makeCoordinator() -> Coordinator { Coordinator(self) }

    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.websiteDataStore = .default()          // a login lasts as long as the portal allows
        let ucc = WKUserContentController()
        // when the page changes and then sits still for a moment, hand its visible text to kosh
        let path = (detailPath ?? "").replacingOccurrences(of: "'", with: "")
        let js = """
        (function () {
          var t = null, last = '', path = '\(path)';
          function send() {
            var s = document.body ? document.body.innerText : '';
            // figures a page shows in read-only boxes (a balance in a grey field) aren't in its text; add
            // them with their label. Only read-only ones: never what you type (UAN, password, captcha, OTP)
            var shown = [];
            Array.prototype.slice.call(document.querySelectorAll('input, textarea')).forEach(function (el) {
              var ty = (el.type || '').toLowerCase();
              if (/^(password|hidden|checkbox|radio|submit|button|file|image|reset)$/.test(ty)) return;
              if (!(el.readOnly || el.disabled)) return;
              var v = (el.value || '').trim();
              if (!v) return;
              var lab = (el.labels && el.labels[0] && el.labels[0].innerText) || el.getAttribute('aria-label') || el.getAttribute('placeholder') || el.getAttribute('title') || '';
              for (var up = el.parentElement, k = 0; !lab && up && k < 3; up = up.parentElement, k++) {
                var tx = (up.innerText || '').trim();
                if (tx && tx.length < 90) lab = tx;
              }
              shown.push('[field] ' + String(lab).replace(/\\s+/g, ' ').trim() + ': ' + v);
            });
            if (s && shown.length) s += '\\n' + shown.join('\\n');
            // which option each list has chosen (a member ID, a year), which the text alone doesn't say
            var chosen = Array.prototype.slice.call(document.querySelectorAll('select')).map(function (x) {
              var o = x.options[x.selectedIndex]; return o && o.text && o.value ? '[selected] ' + o.text.trim() : '';
            }).filter(function (v) { return v; });
            if (s && chosen.length) s += '\\n' + chosen.join('\\n');
            var links = path ? Array.prototype.slice.call(document.querySelectorAll('a[href*="' + path + '"]')).map(function (a) { return a.href; }) : [];
            links = links.filter(function (h, i) { return links.indexOf(h) === i; });
            if (s && s !== last) { last = s; window.webkit.messageHandlers.kosh.postMessage({ text: s, url: location.href, details: links }); }
            setTimeout(photos, 1200);
          }
          // a property's photo, where the portal shows one: the PID is in the picture's path
          var sent = {};
          function photos() {
            Array.prototype.slice.call(document.images).forEach(function (img) {
              var m = new RegExp('/([0-9][A-Z0-9]{7})/').exec(img.src || '');
              if (!m || sent[m[1]] || !img.complete || img.naturalWidth < 100) return;
              sent[m[1]] = 1;
              var pid = m[1];
              function viaCanvas() {
                try {
                  var c = document.createElement('canvas'); c.width = img.naturalWidth; c.height = img.naturalHeight;
                  c.getContext('2d').drawImage(img, 0, 0);
                  window.webkit.messageHandlers.kosh.postMessage({ photo: pid, data: c.toDataURL('image/jpeg', 0.85) });
                } catch (e) {}
              }
              // the full-size picture if the portal has one, else the thumbnail on the page
              fetch(img.src.replace('/Thumb/', '/'), { credentials: 'include' }).then(function (r) {
                if (!r.ok || !/image/.test(r.headers.get('content-type') || '')) throw 0;
                return r.blob();
              }).then(function (b) {
                var fr = new FileReader();
                fr.onload = function () { window.webkit.messageHandlers.kosh.postMessage({ photo: pid, data: fr.result }); };
                fr.readAsDataURL(b);
              }).catch(viaCanvas);
            });
          }
          function soon() { clearTimeout(t); t = setTimeout(send, 900); }
          new MutationObserver(soon).observe(document.documentElement, { childList: true, subtree: true, characterData: true });
          window.addEventListener('load', soon);
          soon();
        })();
        """
        ucc.addUserScript(WKUserScript(source: js, injectionTime: .atDocumentEnd, forMainFrameOnly: false))
        ucc.add(context.coordinator, name: "kosh")
        config.userContentController = ucc
        let web = WKWebView(frame: .zero, configuration: config)
        web.navigationDelegate = context.coordinator
        web.allowsBackForwardNavigationGestures = true
        web.load(URLRequest(url: url, timeoutInterval: EPFKeep.wait))
        context.coordinator.web = web
        return web
    }

    func updateUIView(_ web: WKWebView, context: Context) {
        context.coordinator.parent = self
        if context.coordinator.lastReload != reload {
            context.coordinator.lastReload = reload
            web.reload()
        }
        if context.coordinator.lastJump != jumpTick, let jump {
            context.coordinator.lastJump = jumpTick
            web.load(URLRequest(url: jump, timeoutInterval: EPFKeep.wait))
        }
        if context.coordinator.lastFollow != followTick, let follow {
            context.coordinator.lastFollow = followTick
            web.evaluateJavaScript(Self.followJS(follow), completionHandler: nil)
        }
        if context.coordinator.lastFill != fillTick, let fill, !fill.isEmpty {
            context.coordinator.lastFill = fillTick
            web.evaluateJavaScript(Self.fillJS(fill, label: fillLabel), completionHandler: nil)
        }
    }

    /// Put a number kosh already knows into the one box that asks for it, and nothing else. A password, captcha, OTP
    /// or PIN box is never touched, a box the person has already typed in is left alone, and no form is submitted.
    static func fillJS(_ value: String, label: String) -> String {
        // (digits only, and only as many as the identifier has: nothing else can reach the page this way)
        let safe = value.filter(\.isNumber)
        let want = label.lowercased().filter { $0.isLetter || $0 == " " }
        return """
        (function () {
          var v = '\(safe)', want = '\(want)';
          if (!v) return 'none';
          var box = Array.prototype.slice.call(document.querySelectorAll('input')).filter(function (el) {
            var ty = (el.type || '').toLowerCase();
            if (/^(password|hidden|checkbox|radio|submit|button|file|image|reset)$/.test(ty)) return false;
            if (el.readOnly || el.disabled || (el.value || '').trim()) return false;
            var hay = ((el.id || '') + ' ' + (el.name || '') + ' ' + (el.getAttribute('placeholder') || '')
                       + ' ' + (el.getAttribute('aria-label') || '') + ' ' + (el.getAttribute('title') || '')).toLowerCase();
            if (/pass|captcha|otp|\\bpin\\b|secret/.test(hay)) return false;
            return hay.indexOf(want) >= 0;
          })[0];
          if (!box) return 'none';
          box.focus();
          box.value = v;
          box.dispatchEvent(new Event('input', { bubbles: true }));
          box.dispatchEvent(new Event('change', { bubbles: true }));
          return 'ok';
        })();
        """
    }

    /// a tap on the menu entry that reads exactly this (links and menu items only; the menu may be folded away)
    static func followJS(_ label: String) -> String {
        let want = label.lowercased().replacingOccurrences(of: "\\", with: "").replacingOccurrences(of: "'", with: "")
        return """
        (function () {
          var want = '\(want)';
          var hits = Array.prototype.slice.call(document.querySelectorAll('a, [data-name], [role=menuitem], [role=tab], nav li')).filter(function (e) {
            return (e.textContent || '').replace(/\\s+/g, ' ').trim().toLowerCase() === want;
          });
          // the innermost of nested matches (the link inside its list item) is what a finger lands on
          var inner = hits.filter(function (e) { return !hits.some(function (o) { return o !== e && e.contains(o); }); });
          if (!inner.length) return 'none';
          inner[0].click();
          return 'ok';
        })();
        """
    }

    static func dismantleUIView(_ web: WKWebView, coordinator: Coordinator) {
        web.configuration.userContentController.removeScriptMessageHandler(forName: "kosh")
    }

    final class Coordinator: NSObject, WKNavigationDelegate, WKScriptMessageHandler {
        var parent: PortalWebView
        weak var web: WKWebView?
        var lastReload = 0
        var lastJump = 0
        var lastFollow = 0
        var lastFill = 0
        /// tries again so far for the page that is failing, whether the page being opened was a GET (only those are
        /// tried again: a form sent twice is a login sent twice), and a server error the page loaded with
        var tries = 0
        var get = true
        var serverError = false
        init(_ p: PortalWebView) { parent = p }

        func webView(_ webView: WKWebView, decidePolicyFor action: WKNavigationAction) async -> WKNavigationActionPolicy {
            if action.targetFrame?.isMainFrame != false { get = (action.request.httpMethod ?? "GET").uppercased() == "GET" }
            return .allow
        }
        func webView(_ webView: WKWebView, decidePolicyFor response: WKNavigationResponse) async -> WKNavigationResponsePolicy {
            if response.isForMainFrame, let http = response.response as? HTTPURLResponse { serverError = http.statusCode >= 500 }
            return .allow
        }
        /// a page that didn't load: tried again a bounded number of times, then said
        func failed(_ webView: WKWebView, _ why: String, url: URL?) {
            if tries < EPFKeep.again.count, get, let u = url ?? webView.url {
                let pause: Double = EPFKeep.again[tries]
                tries += 1
                DispatchQueue.main.asyncAfter(deadline: .now() + pause) { [weak webView] in
                    webView?.load(URLRequest(url: u, timeoutInterval: EPFKeep.wait))
                }
                return
            }
            tries = 0
            DispatchQueue.main.async { self.parent.loading = false; self.parent.onFail?(why) }
        }
        func failed(_ webView: WKWebView, _ error: Error) {
            let e = error as NSError
            // (a page left for another before it finished isn't a failure)
            if e.domain == NSURLErrorDomain && e.code == NSURLErrorCancelled { return }
            failed(webView, e.localizedDescription, url: e.userInfo[NSURLErrorFailingURLErrorKey] as? URL)
        }

        func userContentController(_ ucc: WKUserContentController, didReceive message: WKScriptMessage) {
            guard let body = message.body as? [String: Any] else { return }
            if let pid = body["photo"] as? String, let data = body["data"] as? String,
               let comma = data.firstIndex(of: ","), let bytes = Data(base64Encoded: String(data[data.index(after: comma)...])) {
                DispatchQueue.main.async { self.parent.onPhoto?(pid, bytes) }
                return
            }
            guard let text = body["text"] as? String else { return }
            let url = body["url"] as? String ?? ""
            let details = body["details"] as? [String] ?? []
            DispatchQueue.main.async { self.parent.onText(text, url, details) }
        }
        func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
            DispatchQueue.main.async { self.parent.loading = true }
        }
        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            if serverError { serverError = false; failed(webView, "the server answered with an error", url: webView.url); return }
            tries = 0
            DispatchQueue.main.async { self.parent.loading = false }
        }
        func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
            failed(webView, error)
        }
        // where a site that is down, a timeout and no connection land: before the page has begun
        func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
            failed(webView, error)
        }
    }
}

/// On the Property tab: read your properties straight off the state's portal
struct PortalConnectCard: View {
    @Environment(Store.self) private var store
    let state: String
    var body: some View {
        if let p = LiveSession.portal(for: state) {
            Button { store.betaSheet = .portal(state) } label: {
                HStack(spacing: 12) {
                    IconTile(symbol: "building.columns.fill", color: Color.kosh)
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Read your properties from \(p.name)").font(.body.weight(.semibold))
                        Text("Log in with your mobile and OTP inside kosh. It reads every property on your number, then opens each one’s details for the full breakdown.")
                            .font(.subheadline).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                    }
                    Spacer(minLength: 6)
                    Image(systemName: "chevron.right").font(.footnote.weight(.semibold)).foregroundStyle(.tertiary)
                }
                .padding(14)
                .background(Color.surface, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
            }
            .buttonStyle(.press)
        }
    }
}
