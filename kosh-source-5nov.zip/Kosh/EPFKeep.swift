import Foundation

// MARK: - EPF: what a visit to the EPFO's site may change, and what kosh says when the site lets it down
//
// The EPFO's site is often down a tab at a time: the login works and the passbook doesn't, or a member ID's page
// comes back saying "no transactions" because its server didn't answer. So a visit only ever adds to what kosh
// knows. A figure kosh holds is never cleared by a page that failed, a passbook PDF's figure (which says which day
// it is for) is never replaced by the page's, and when a page fails kosh says what it still holds and from when.
// (The build does the other half: a set of jobs with one unread is never summed as the whole, 21l-build-retirement.js.)
//
// No screens here, so engine-test/epf-keep.js compiles this file with swiftc alone and checks it.

enum EPFKeep {
    /// how long a page may take before it counts as not answering, and the pauses before each try again: twice, then
    /// kosh says so rather than spinning
    static let wait: TimeInterval = 30
    static let again: [Double] = [2, 5]

    /// whether the page's balance for one job may replace the one kosh holds for it
    static func pageMayReplace(held: Double, book: Bool, page: Double) -> Bool {
        // the passbook PDF's figure is dated and checked against its own sum: the page's "now" never overwrites it
        if book && held > 0 { return false }
        // a ₹0 never wipes out money kosh has seen: a passbook tab that didn't load reads as "no transactions"
        // ponytail: a job truly settled to ₹0 keeps its last figure (dated, so it ages) until its passbook PDF says so
        if page <= 0 && held > 0 { return false }
        return true
    }

    /// the EPFO's own words for "this part of the site isn't working", on a page kosh found no figures on
    static func siteDown(_ page: String) -> Bool {
        page.range(of: #"service (?:is )?(?:temporarily )?unavailable|temporarily unavailable|under maintenance|something went wrong|server (?:is )?(?:busy|error|down)|try again later|internal server error|bad gateway|gateway time-?out|unable to (?:process|connect|fetch)|error occurred|request timed out|not responding"#,
                   options: [.regularExpression, .caseInsensitive]) != nil
    }

    /// what kosh still holds, said beside any failure: "kosh still holds ₹4.2L for 2 of 3 jobs, from 31 Mar 2026."
    /// `amount` and `day` come formatted by the caller (₹ and dates are Style.swift's).
    static func heldLine(amount: String, jobs: Int, of: Int, day: String) -> String {
        guard jobs > 0, !amount.isEmpty else { return "kosh holds no EPF figure yet, so nothing is lost." }
        let whose: String = of > jobs ? "for " + String(jobs) + " of " + String(of) + " jobs"
                                      : (jobs == 1 ? "for your one job" : "for all " + String(jobs) + " jobs")
        return "kosh still holds " + amount + " " + whose + (day.isEmpty ? "" : ", from " + day) + ". Nothing was changed."
    }

    /// a page that didn't load after every try
    static func failLine(why: String, held: String) -> String {
        "The EPFO site didn't load" + (why.isEmpty ? "" : " (" + why.trimmingCharacters(in: CharacterSet(charactersIn: ". ")) + ")")
            + ", after " + String(again.count + 1) + " tries. " + held + " Try again later."
    }

    /// a page that loaded but says its own part isn't working
    static func downLine(held: String) -> String {
        "The EPFO says this part of its site isn't working right now. " + held
    }
}
