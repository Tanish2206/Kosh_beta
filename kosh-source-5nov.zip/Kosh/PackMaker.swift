import UIKit
import PDFKit

// MARK: - Making a claim: one PDF (a summary, then each item's invoice) and an Excel sheet
//
// Everything happens on this phone. Each item's proof is, in order: the PDF the site attached (opened with the
// password you saved for that sender, if it's locked), else the mail itself (kosh's sealed copy, or the inbox's)
// laid out as pages with a line saying which item it proves. The mail's pictures and anything else it would fetch
// are left out, so making a claim tells no sender anything. An item with no proof is listed in the summary and
// says so. The files go to kosh's own temporary folder (Erase clears it) and leave the phone only when you send
// or share them.

enum PackMaker {
    struct Output: Equatable {
        var pdf: URL
        var xlsx: URL
        var pages: Int
        /// items with no invoice in the mail
        var missing: Int
        /// what didn't go as it should, in plain words
        var notes: [String]
    }

    static let page = CGRect(x: 0, y: 0, width: 595.2, height: 841.8)   // A4, in points

    @MainActor
    static func make(title: String, period: String, name: String, items: [ClaimDoc], live: LiveSession, progress: (Int, Int) -> Void) async -> Output? {
        let rows: [ClaimDoc] = items.sorted { $0.d == $1.d ? $0.t < $1.t : $0.d < $1.d }
        let packs: URL = FileManager.default.temporaryDirectory.appendingPathComponent("kosh-packs", isDirectory: true)
        try? FileManager.default.removeItem(at: packs)
        var proofs: [PDFDocument?] = []
        var notes: [String] = []
        var unlocked = 0, offline = 0
        for (i, e) in rows.enumerated() {
            progress(i + 1, rows.count)
            let caption: String = "Item \(i + 1) · " + e.m + " · " + Day.fmt(e.d, "d MMM yyyy") + " · " + money(e.a)
            var doc: PDFDocument? = nil
            if !e.ev.isEmpty {
                let acct: String = e.acct.isEmpty ? live.email : e.acct
                let tag: String = live.inboxTag(acct)
                let msg: String = !tag.isEmpty && e.ev.hasPrefix(tag) ? String(e.ev.dropFirst(tag.count)) : e.ev
                if let att = e.att {
                    do {
                        let data: Data = try await live.attachmentBytes(acct: acct, msg: msg, att: att.id)
                        doc = opened(data, sender: e.from)
                        if doc == nil, let raw = PDFDocument(data: data), raw.isLocked { unlocked += 1 }
                    } catch {
                        offline += 1
                    }
                }
                if doc == nil {
                    var mail: MailMsg? = MailVault.get(e.ev)
                    if mail == nil || (mail?.html.count ?? 0) >= 39_000 { mail = (try? await live.fetchOne(msg, acct: acct)) ?? mail }
                    if let mail { doc = render(html: mail.html, text: mail.text, caption: caption) }
                }
            }
            proofs.append(doc)
        }
        if unlocked > 0 { notes.append("\(unlocked) invoice PDF" + (unlocked == 1 ? " is" : "s are") + " locked with a password kosh doesn't have; the mail went in instead.") }
        if offline > 0 { notes.append("\(offline) invoice PDF" + (offline == 1 ? "" : "s") + " couldn't be downloaded just now; the mail went in instead. Make the PDF again online for the original.") }

        // the summary's pages first, so each item can say where its invoice is
        let lines: [SummaryLine] = rows.enumerated().map { i, e in
            SummaryLine(no: i + 1, date: Day.fmt(e.d, "d MMM yyyy"), kind: e.kindName, merchant: e.m, details: detailsLine(e), amount: e.a)
        }
        let summaryPages: Int = layout(lines).pages
        var at: Int = summaryPages + 1
        var pageOf: [Int?] = []
        for d in proofs {
            if let d { pageOf.append(at); at += min(d.pageCount, maxPages) } else { pageOf.append(nil) }
        }
        let totalPages: Int = at - 1
        let total: Double = rows.reduce(0) { $0 + $1.a }
        let missing: Int = rows.filter { $0.ev.isEmpty }.count
        let summary: Data = drawSummary(title: title, period: period, name: name, lines: lines, pageOf: pageOf, total: total, totalPages: totalPages,
                                        noProof: zip(rows, proofs).enumerated().filter { $0.element.1 == nil }.map { $0.offset + 1 })
        guard let out = PDFDocument(data: summary) else { return nil }
        let outline = PDFOutline()
        if let first = out.page(at: 0) {
            let o = PDFOutline(); o.label = "Summary"; o.destination = PDFDestination(page: first, at: CGPoint(x: 0, y: page.height)); outline.insertChild(o, at: outline.numberOfChildren)
        }
        for (i, d) in proofs.enumerated() {
            guard let d else { continue }
            let firstIndex: Int = out.pageCount
            for p in 0..<min(d.pageCount, maxPages) {
                if let pg = d.page(at: p)?.copy() as? PDFPage { out.insert(pg, at: out.pageCount) }
            }
            if let pg = out.page(at: firstIndex) {
                let o = PDFOutline()
                o.label = "Item \(i + 1): " + rows[i].m + ", " + Day.fmt(rows[i].d, "d MMM")
                o.destination = PDFDestination(page: pg, at: CGPoint(x: 0, y: pg.bounds(for: .mediaBox).height))
                outline.insertChild(o, at: outline.numberOfChildren)
            }
        }
        out.outlineRoot = outline
        out.documentAttributes = [PDFDocumentAttribute.titleAttribute: title, PDFDocumentAttribute.creatorAttribute: "kosh"]

        let folder: URL = packs.appendingPathComponent(UUID().uuidString, isDirectory: true)
        try? FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        let base: String = fileName(title)
        let pdfURL: URL = folder.appendingPathComponent(base + ".pdf")
        let xlsxURL: URL = folder.appendingPathComponent(base + ".xlsx")
        guard let pdfData = out.dataRepresentation(), (try? pdfData.write(to: pdfURL, options: [.atomic, .completeFileProtection])) != nil else { return nil }
        let sheet: Data = XLSX.make(sheet: "Claim", header: XLSX.claimHeader, widths: XLSX.claimWidths, rows: rows.enumerated().map { i, e in XLSX.claimRow(i + 1, e, page: pageOf[i]) }, total: total)
        guard (try? sheet.write(to: xlsxURL, options: [.atomic, .completeFileProtection])) != nil else { return nil }
        return Output(pdf: pdfURL, xlsx: xlsxURL, pages: out.pageCount, missing: missing, notes: notes)
    }

    /// pages kept from one item's proof: a hotel's folio whole, a mail's receipt without its newsletter footer
    static let maxPages = 10
    static let maxMailPages = 4
    static func capital(_ s: String) -> String { s.isEmpty ? s : String(s.prefix(1)).uppercased() + String(s.dropFirst()) }

    static func money(_ v: Double) -> String {
        let f = NumberFormatter()
        f.locale = Locale(identifier: "en_IN"); f.numberStyle = .decimal
        f.minimumFractionDigits = 2; f.maximumFractionDigits = 2
        return "₹" + (f.string(from: NSNumber(value: v)) ?? String(format: "%.2f", v))
    }
    static func fileName(_ title: String) -> String {
        let bad = CharacterSet(charactersIn: "/\\:?%*|\"<>")
        return title.components(separatedBy: bad).joined(separator: "-").trimmingCharacters(in: .whitespaces)
    }
    static func detailsLine(_ e: ClaimDoc) -> String {
        var bits: [String] = []
        let d: String = e.details
        if !d.isEmpty { bits.append(d) }
        if !e.ref.isEmpty && !d.contains(e.ref) { bits.append(e.ref) }
        if !e.on.isEmpty && e.on != e.d { bits.append("travel " + Day.fmt(e.on, "d MMM")) }
        if !e.fx.isEmpty { bits.append(e.fx) }
        return bits.joined(separator: " · ")
    }

    // MARK: opening a site's PDF

    /// the PDF as it came, or opened with a password you saved for this sender; nil if it stays locked
    static func opened(_ data: Data, sender: String) -> PDFDocument? {
        guard let doc = PDFDocument(data: data) else { return nil }
        if !doc.isLocked { return doc }
        for pw in SenderPasswords.every(sender) {
            if let d = PDFDocument(data: data), d.unlock(withPassword: pw) { return d }
        }
        return nil
    }

    // MARK: a mail as pages

    /// the mail laid out on A4 with a line at the top saying which item it proves. Its pictures, styles from
    /// elsewhere, scripts and frames are taken out first: nothing is fetched, so no sender learns the mail was opened.
    @MainActor
    static func render(html: String, text: String, caption: String) -> PDFDocument? {
        let head: String = "<div style=\"font:11px -apple-system,Helvetica;color:#555;padding:0 0 6px;margin:0 0 12px;border-bottom:1px solid #ccc\">" + escape(caption) + "</div>"
        let body: String = html.isEmpty
            ? "<pre style=\"white-space:pre-wrap;font:11px -apple-system,Helvetica\">" + escape(String(text.prefix(30_000))) + "</pre>"
            : sanitize(String(html.prefix(400_000)))
        let fmt = UIMarkupTextPrintFormatter(markupText: "<html><body style=\"font:12px -apple-system,Helvetica\">" + head + body + "</body></html>")
        let r = UIPrintPageRenderer()
        r.addPrintFormatter(fmt, startingAtPageAt: 0)
        r.setValue(NSValue(cgRect: page), forKey: "paperRect")
        r.setValue(NSValue(cgRect: page.insetBy(dx: 36, dy: 36)), forKey: "printableRect")
        let data = NSMutableData()
        UIGraphicsBeginPDFContextToData(data, page, [kCGPDFContextCreator as String: "kosh"])
        let n: Int = max(1, min(r.numberOfPages, maxMailPages))
        r.prepare(forDrawingPages: NSRange(location: 0, length: n))
        for i in 0..<n {
            UIGraphicsBeginPDFPage()
            r.drawPage(at: i, in: UIGraphicsGetPDFContextBounds())
        }
        UIGraphicsEndPDFContext()
        return PDFDocument(data: data as Data)
    }

    static func escape(_ s: String) -> String {
        s.replacingOccurrences(of: "&", with: "&amp;").replacingOccurrences(of: "<", with: "&lt;").replacingOccurrences(of: ">", with: "&gt;")
    }
    /// what a mail's HTML would fetch or run, taken out: pictures, linked styles, scripts, frames, objects, media,
    /// backgrounds and url(…) in its styles
    static func sanitize(_ html: String) -> String {
        var s: String = html
        let blocks: [String] = ["script", "iframe", "object", "video", "audio", "svg", "noscript", "form"]
        for t in blocks { s = replace(s, "(?is)<" + t + "\\b.*?</" + t + "\\s*>", "") }
        let singles: [String] = ["img", "link", "meta", "embed", "source", "input", "base", "image", "object", "svg", "video", "audio",
                                 "iframe", "frame", "frameset", "applet", "bgsound", "track", "picture", "use", "portal"]
        for t in singles { s = replace(s, "(?is)</?" + t + "\\b[^>]*>", "") }
        s = replace(s, "(?i)(?:-webkit-)?image-set\\s*\\(", "none(")
        s = replace(s, "(?i)url\\s*\\([^)]*\\)", "none")
        s = replace(s, "(?i)[\\s/\"'](?:background|srcset|src|poster|lowsrc|dynsrc|data|xlink:href|action|formaction|ping|longdesc|archive|codebase|cite)\\s*=\\s*(\"[^\"]*\"|'[^']*'|[^\\s>]+)", " ")
        s = replace(s, "(?i)@import[^;]*;", "")
        return s
    }
    static func replace(_ s: String, _ pattern: String, _ with: String) -> String {
        guard let re = try? NSRegularExpression(pattern: pattern) else { return s }
        return re.stringByReplacingMatches(in: s, range: NSRange(s.startIndex..., in: s), withTemplate: with)
    }

    // MARK: the summary

    struct SummaryLine { let no: Int; let date: String; let kind: String; let merchant: String; let details: String; let amount: Double }

    static let margin: CGFloat = 40
    static let cols: [(String, CGFloat, NSTextAlignment)] = [("No.", 24, .left), ("Date", 66, .left), ("Type", 54, .left), ("Paid to", 110, .left), ("Details", 156, .left), ("Amount", 70, .right), ("Page", 35, .right)]
    static let topFirst: CGFloat = 150
    static let topNext: CGFloat = 70
    static let bottom: CGFloat = 70

    static func rowFont() -> UIFont { .systemFont(ofSize: 9.5) }
    static func rowHeight(_ l: SummaryLine) -> CGFloat {
        let attrs: [NSAttributedString.Key: Any] = [.font: rowFont()]
        let m: CGFloat = (l.merchant as NSString).boundingRect(with: CGSize(width: cols[3].1 - 6, height: 200), options: .usesLineFragmentOrigin, attributes: attrs, context: nil).height
        let d: CGFloat = (l.details as NSString).boundingRect(with: CGSize(width: cols[4].1 - 6, height: 200), options: .usesLineFragmentOrigin, attributes: attrs, context: nil).height
        return max(15, ceil(max(m, d))) + 7
    }
    /// where each row goes: (page, y), and how many pages the summary takes
    static func layout(_ lines: [SummaryLine]) -> (spots: [(Int, CGFloat)], pages: Int) {
        var spots: [(Int, CGFloat)] = []
        var p = 0
        var y: CGFloat = topFirst + 20
        for l in lines {
            let h: CGFloat = rowHeight(l)
            if y + h > page.height - bottom - 40 { p += 1; y = topNext + 20 }
            spots.append((p, y)); y += h
        }
        // the total and the notes after the last row
        if y + 80 > page.height - bottom { p += 1 }
        return (spots, p + 1)
    }

    static func drawSummary(title: String, period: String, name: String, lines: [SummaryLine], pageOf: [Int?], total: Double, totalPages: Int, noProof: [Int]) -> Data {
        let (spots, pages) = layout(lines)
        let fmt = UIGraphicsPDFRendererFormat()
        fmt.documentInfo = [kCGPDFContextTitle as String: title, kCGPDFContextCreator as String: "kosh"]
        let r = UIGraphicsPDFRenderer(bounds: page, format: fmt)
        let ink = UIColor(white: 0.1, alpha: 1), grey = UIColor(white: 0.42, alpha: 1), rule = UIColor(white: 0.85, alpha: 1)
        let width: CGFloat = page.width - 2 * margin
        // a plain export of payments has no invoices behind it, so the Page column isn't drawn at all (the rest of
        // the columns keep their widths, so every row still lines up)
        let shown: [(String, CGFloat, NSTextAlignment)] = pageOf.contains(where: { $0 != nil }) ? cols : Array(cols.dropLast())
        return r.pdfData { ctx in
            for p in 0..<pages {
                ctx.beginPage()
                var top: CGFloat = topNext
                if p == 0 {
                    draw(capital(title), at: CGRect(x: margin, y: 44, width: width, height: 30), font: .systemFont(ofSize: 20, weight: .semibold), color: ink)
                    let who: String = name.isEmpty ? "" : name + " · "
                    draw(who + period + " · \(lines.count) item" + (lines.count == 1 ? "" : "s") + " · " + money(total), at: CGRect(x: margin, y: 76, width: width, height: 16), font: .systemFont(ofSize: 11), color: grey)
                    draw("Made on " + Day.fmt(LiveSession.today, "d MMMM yyyy") + " from the claimant's own mail. Each item's invoice or receipt follows, on the page shown.", at: CGRect(x: margin, y: 94, width: width, height: 30), font: .systemFont(ofSize: 9.5), color: grey)
                    top = topFirst
                }
                // the column heads
                var x: CGFloat = margin
                for c in shown {
                    draw(c.0.uppercased(), at: CGRect(x: x + 3, y: top, width: c.1 - 6, height: 12), font: .systemFont(ofSize: 8, weight: .semibold), color: grey, align: c.2)
                    x += c.1
                }
                line(ctx.cgContext, y: top + 15, color: ink, width: 0.8)
                for (i, l) in lines.enumerated() where spots[i].0 == p {
                    let y: CGFloat = spots[i].1
                    let h: CGFloat = rowHeight(l)
                    let pageText: String = pageOf[i].map { String($0) } ?? "–"
                    let cells: [String] = [String(l.no), l.date, l.kind, l.merchant, l.details, money(l.amount), pageText]
                    let digits: UIFont = UIFont.monospacedDigitSystemFont(ofSize: 9.5, weight: .regular)
                    var cx: CGFloat = margin
                    for (j, c) in shown.enumerated() {
                        let color: UIColor = j == 6 && pageOf[i] == nil ? grey : ink
                        let font: UIFont = j == 5 ? digits : rowFont()
                        draw(cells[j], at: CGRect(x: cx + 3, y: y + 3, width: c.1 - 6, height: h), font: font, color: color, align: c.2)
                        cx += c.1
                    }
                    line(ctx.cgContext, y: y + h, color: rule, width: 0.5)
                }
                if p == pages - 1 {
                    let lastY: CGFloat = lines.indices.last.map { spots[$0].0 == p ? spots[$0].1 + rowHeight(lines[$0]) : top + 20 } ?? top + 20
                    let ty: CGFloat = lastY + 10
                    draw("Total", at: CGRect(x: margin + 3, y: ty, width: 200, height: 16), font: .systemFont(ofSize: 11, weight: .semibold), color: ink)
                    let amtX: CGFloat = margin + cols[0].1 + cols[1].1 + cols[2].1 + cols[3].1 + cols[4].1
                    draw(money(total), at: CGRect(x: amtX + 3, y: ty, width: cols[5].1 - 6, height: 16), font: .monospacedDigitSystemFont(ofSize: 11, weight: .semibold), color: ink, align: .right)
                    if !noProof.isEmpty {
                        let list: String = noProof.map(String.init).joined(separator: ", ")
                        draw("No invoice in the mail yet for item" + (noProof.count == 1 ? " " : "s ") + list + ". The payment is listed for the record.", at: CGRect(x: margin, y: ty + 24, width: width, height: 30), font: .systemFont(ofSize: 9.5), color: grey)
                    }
                }
                draw("Page \(p + 1) of \(totalPages)", at: CGRect(x: margin, y: page.height - 40, width: width, height: 12), font: .systemFont(ofSize: 8), color: grey, align: .right)
            }
        }
    }
    static func draw(_ s: String, at r: CGRect, font: UIFont, color: UIColor, align: NSTextAlignment = .left) {
        let ps = NSMutableParagraphStyle()
        ps.alignment = align
        ps.lineBreakMode = .byWordWrapping
        (s as NSString).draw(with: r, options: .usesLineFragmentOrigin, attributes: [.font: font, .foregroundColor: color, .paragraphStyle: ps], context: nil)
    }
    static func line(_ c: CGContext, y: CGFloat, color: UIColor, width: CGFloat) {
        c.setStrokeColor(color.cgColor)
        c.setLineWidth(width)
        c.move(to: CGPoint(x: margin, y: y))
        c.addLine(to: CGPoint(x: page.width - margin, y: y))
        c.strokePath()
    }
}

// MARK: - An Excel sheet, written by hand: a few XML files in a zip, stored (not compressed)

enum XLSX {
    enum Cell { case text(String), num(Double), day(String), int(Int), blank }

    static let claimHeader: [String] = ["No.", "Date", "Time", "Type", "Paid to", "From", "To", "Travel date", "Stay", "Booking ref", "Amount (₹)", "GST (₹)", "Paid with", "Proof", "Invoice page"]
    static let claimWidths: [Double] = [5, 12, 8, 10, 22, 18, 18, 12, 22, 20, 12, 10, 18, 16, 11]
    static func claimRow(_ no: Int, _ e: ClaimDoc, page: Int?) -> [Cell] {
        let n: Int = e.nights ?? 0
        let nights: String = n == 1 ? " (1 night)" : " (\(n) nights)"
        let stay: String = n > 0 ? e.place + nights : e.place
        let paid: String = e.card.isEmpty ? e.md : e.card
        let time: Cell = e.t.isEmpty ? .blank : .text(e.t)
        let travel: Cell = e.on.isEmpty ? .blank : .day(e.on)
        var tax: Cell = .blank
        if let t = e.tax { tax = .num(t) }
        var pg: Cell = .blank
        if let p = page { pg = .int(p) }
        let cells: [Cell] = [.int(no), .day(e.d), time, .text(e.kindName), .text(e.m), .text(e.fromP), .text(e.toP),
                             travel, .text(stay), .text(e.ref), .num(e.a), tax, .text(paid), .text(e.proof), pg]
        return cells
    }

    static func make(sheet: String, header: [String], widths: [Double], rows: [[Cell]], total: Double) -> Data {
        var xml: String = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetViews><sheetView workbookViewId=\"0\"><pane ySplit=\"1\" topLeftCell=\"A2\" activePane=\"bottomLeft\" state=\"frozen\"/></sheetView></sheetViews><cols>"
        for (i, w) in widths.enumerated() { xml += "<col min=\"\(i + 1)\" max=\"\(i + 1)\" width=\"\(w)\" customWidth=\"1\"/>" }
        xml += "</cols><sheetData>"
        xml += row(1, header.map { Cell.text($0) }, style: 1)
        for (i, r) in rows.enumerated() { xml += row(i + 2, r, style: 0) }
        // the total under the amounts
        let last: Int = rows.count + 1
        var totalRow: [Cell] = Array(repeating: .blank, count: header.count)
        if header.count > 10 { totalRow[4] = .text("Total"); totalRow[10] = .num(total) }
        let sum: (Int, String)? = rows.isEmpty ? nil : (10, "SUM(K2:K\(last))")
        xml += row(last + 2, totalRow, style: 1, formula: sum)
        xml += "</sheetData></worksheet>"
        let files: [(String, String)] = [
            ("[Content_Types].xml", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/><Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/></Types>"),
            ("_rels/.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>"),
            ("xl/workbook.xml", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets><sheet name=\"" + esc(sheet) + "\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>"),
            ("xl/_rels/workbook.xml.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/><Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/></Relationships>"),
            ("xl/styles.xml", styles),
            ("xl/worksheets/sheet1.xml", xml),
        ]
        return Zip.stored(files.map { ($0.0, Data($0.1.utf8)) })
    }

    // 0 plain · 1 bold · 2 amount (#,##0.00) · 3 date (d mmm yyyy) · 4 bold amount
    static let styles: String = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><numFmts count=\"2\"><numFmt numFmtId=\"164\" formatCode=\"#,##0.00\"/><numFmt numFmtId=\"165\" formatCode=\"d mmm yyyy\"/></numFmts><fonts count=\"2\"><font><sz val=\"11\"/><name val=\"Calibri\"/></font><font><b/><sz val=\"11\"/><name val=\"Calibri\"/></font></fonts><fills count=\"2\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill></fills><borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs><cellXfs count=\"5\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/><xf numFmtId=\"0\" fontId=\"1\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyFont=\"1\"/><xf numFmtId=\"164\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyNumberFormat=\"1\"/><xf numFmtId=\"165\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyNumberFormat=\"1\"/><xf numFmtId=\"164\" fontId=\"1\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyFont=\"1\" applyNumberFormat=\"1\"/></cellXfs><cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles></styleSheet>"

    static func col(_ i: Int) -> String {
        var n = i + 1, s = ""
        while n > 0 { let r = (n - 1) % 26; s = String(UnicodeScalar(65 + r)!) + s; n = (n - 1) / 26 }
        return s
    }
    static func row(_ r: Int, _ cells: [Cell], style: Int, formula: (Int, String)? = nil) -> String {
        var out: String = "<row r=\"\(r)\">"
        for (i, c) in cells.enumerated() {
            let ref: String = col(i) + String(r)
            if let f = formula, f.0 == i {
                var cached: String = ""
                if case .num(let v) = c { cached = "<v>" + String(format: "%.2f", v) + "</v>" }
                out += "<c r=\"\(ref)\" s=\"4\"><f>" + esc(f.1) + "</f>" + cached + "</c>"
                continue
            }
            switch c {
            case .text(let t):
                if t.isEmpty { continue }
                out += "<c r=\"\(ref)\" t=\"inlineStr\"" + (style == 1 ? " s=\"1\"" : "") + "><is><t xml:space=\"preserve\">" + esc(t) + "</t></is></c>"
            case .num(let v):
                out += "<c r=\"\(ref)\" s=\"" + (style == 1 ? "4" : "2") + "\"><v>" + String(format: "%.2f", v) + "</v></c>"
            case .int(let v):
                out += "<c r=\"\(ref)\"><v>\(v)</v></c>"
            case .day(let d):
                if let serial = serial(d) { out += "<c r=\"\(ref)\" s=\"3\"><v>\(serial)</v></c>" }
            case .blank:
                continue
            }
        }
        return out + "</row>"
    }
    /// a yyyy-MM-dd day as Excel counts days (from 30 December 1899)
    static func serial(_ d: String) -> Int? {
        guard d.count >= 10, let day = Day.parser.date(from: String(d.prefix(10))) else { return nil }
        var cal = Calendar(identifier: .gregorian); cal.timeZone = Day.zone
        let start = cal.date(from: DateComponents(year: 1899, month: 12, day: 30))!
        return cal.dateComponents([.day], from: start, to: day).day
    }
    static func esc(_ s: String) -> String {
        var out = ""
        for ch in s.unicodeScalars {
            switch ch {
            case "&": out += "&amp;"
            case "<": out += "&lt;"
            case ">": out += "&gt;"
            case "\"": out += "&quot;"
            default:
                // characters XML 1.0 can't carry are left out
                if ch.value < 0x20 && ch != "\t" && ch != "\n" && ch != "\r" { continue }
                out.unicodeScalars.append(ch)
            }
        }
        return out
    }
}

// MARK: - A CSV, for a spreadsheet anywhere

/// a comma-separated file the way every spreadsheet reads one: a mark at the front so Excel knows it is UTF-8, lines
/// ending the way Windows does, and any cell with a comma, a quote or a line break in it put in quotes
enum CSV {
    static func make(header: [String], rows: [[String]]) -> Data {
        var out: String = "\u{FEFF}" + header.map(cell).joined(separator: ",") + "\r\n"
        for r in rows { out += r.map(cell).joined(separator: ",") + "\r\n" }
        return Data(out.utf8)
    }
    static func cell(_ s: String) -> String {
        guard s.contains(",") || s.contains("\"") || s.contains("\n") || s.contains("\r") else { return s }
        return "\"" + s.replacingOccurrences(of: "\"", with: "\"\"") + "\""
    }
}

/// a zip with its files stored as they are (what an .xlsx is, at its simplest)
enum Zip {
    static func stored(_ files: [(String, Data)]) -> Data {
        var out = Data(), central = Data()
        for (name, data) in files {
            let nameData = Data(name.utf8)
            let crc: UInt32 = crc32(data)
            let offset = UInt32(out.count)
            // local header
            out.append(le32(0x04034b50)); out.append(le16(20)); out.append(le16(0x0800)); out.append(le16(0))
            out.append(le16(0)); out.append(le16(0x21))   // a fixed time and day (1 Jan 1980)
            out.append(le32(crc)); out.append(le32(UInt32(data.count))); out.append(le32(UInt32(data.count)))
            out.append(le16(UInt16(nameData.count))); out.append(le16(0))
            out.append(nameData); out.append(data)
            // its entry in the directory at the end
            central.append(le32(0x02014b50)); central.append(le16(20)); central.append(le16(20)); central.append(le16(0x0800)); central.append(le16(0))
            central.append(le16(0)); central.append(le16(0x21))
            central.append(le32(crc)); central.append(le32(UInt32(data.count))); central.append(le32(UInt32(data.count)))
            central.append(le16(UInt16(nameData.count))); central.append(le16(0)); central.append(le16(0)); central.append(le16(0)); central.append(le16(0))
            central.append(le32(0)); central.append(le32(offset))
            central.append(nameData)
        }
        let dirOffset = UInt32(out.count)
        out.append(central)
        out.append(le32(0x06054b50)); out.append(le16(0)); out.append(le16(0))
        out.append(le16(UInt16(files.count))); out.append(le16(UInt16(files.count)))
        out.append(le32(UInt32(central.count))); out.append(le32(dirOffset)); out.append(le16(0))
        return out
    }
    static func le16(_ v: UInt16) -> Data { Data([UInt8(v & 0xff), UInt8(v >> 8)]) }
    static func le32(_ v: UInt32) -> Data { Data([UInt8(v & 0xff), UInt8((v >> 8) & 0xff), UInt8((v >> 16) & 0xff), UInt8(v >> 24)]) }
    static let table: [UInt32] = (0..<256).map { i -> UInt32 in
        var c = UInt32(i)
        for _ in 0..<8 { c = (c & 1) != 0 ? 0xEDB88320 ^ (c >> 1) : c >> 1 }
        return c
    }
    static func crc32(_ data: Data) -> UInt32 {
        var c: UInt32 = 0xFFFFFFFF
        for b in data { c = table[Int((c ^ UInt32(b)) & 0xff)] ^ (c >> 8) }
        return c ^ 0xFFFFFFFF
    }
}
