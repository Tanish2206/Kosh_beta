/* kosh packs: the papers behind what you spent, gathered into what someone else asks you for.

   The first pack is the travel claim. Every cab, flight, train, bus and stay is found in the ledger; beside each,
   the mail that proves it (the site's invoice PDF, its e-ticket, the receipt in the mail's own text) and what a
   claim form asks for (the booking id, from and to, the day travelled). kosh says which look like work and why,
   learns from what you tick, keeps your company's rules (cabs only after 8 pm, weekdays only), and follows each
   claim you make until the money comes back: as its own credit, or inside the next salary.

   Cases: anything kosh is following up for you, with where it stands and what's next (snap.cases). A claim made
   and not sent needs you; one sent is kosh's to watch; a month's claim ready to make needs you.

   Arithmetic on the household's own ledger and mail, on the phone. Loaded after agent.js; Swift calls through
   KoshEngine, and the assistant's `claim` tool (agent.js) calls claimTool here. */

var KoshPacks = (function (E) {
  'use strict';
  var L = E.lib || {};
  var inr = L.inr || function (n) { return '₹' + Math.round(n); };

  /* ------------------------------------------------------------ small things */
  function lc(s) { return String(s == null ? '' : s).toLowerCase(); }
  function r0(n) { return Math.round(+n || 0); }
  function r2(n) { return Math.round((+n || 0) * 100) / 100; }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function dayOf(iso) { var p = String(iso || '').slice(0, 10).split('-'); return Date.UTC(+p[0], +p[1] - 1, +p[2]); }
  function addDays(iso, n) { var d = new Date(dayOf(iso) + n * 864e5); return d.getUTCFullYear() + '-' + pad(d.getUTCMonth() + 1) + '-' + pad(d.getUTCDate()); }
  function daysBetween(a, b) { return Math.round((dayOf(b) - dayOf(a)) / 864e5); }
  function isDay(s) { return /^\d{4}-\d{2}-\d{2}$/.test(String(s || '')); }
  var MON3 = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  var MONF = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  function dShort(iso) { return iso ? +iso.slice(8, 10) + ' ' + MON3[+iso.slice(5, 7) - 1] : ''; }
  function mLong(m) { return MONF[+m.slice(5, 7) - 1] + ' ' + m.slice(0, 4); }
  function monthEnd(m) { var y = +m.slice(0, 4), mo = +m.slice(5, 7); return addDays(mo === 12 ? (y + 1) + '-01-01' : y + '-' + pad(mo + 1) + '-01', -1); }
  function prevMonth(m) { var y = +m.slice(0, 4), mo = +m.slice(5, 7); return mo === 1 ? (y - 1) + '-12' : y + '-' + pad(mo - 1); }
  function weekend(iso) { var w = new Date(dayOf(iso)).getUTCDay(); return w === 0 || w === 6; }
  function median(xs) { if (!xs.length) return 0; var s = xs.slice().sort(function (a, b) { return a - b; }), m = Math.floor(s.length / 2); return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2; }
  function titled(s) {
    s = String(s || '').replace(/\s+/g, ' ').trim();
    if (!s) return '';
    // a station's code stays as it is ("(NDLS)"); the rest in ordinary case when it came in capitals
    if (s === s.toUpperCase()) s = s.toLowerCase().replace(/\b[a-z]/g, function (c) { return c.toUpperCase(); }).replace(/\(([a-z]{2,5})\)/gi, function (x, c) { return '(' + c.toUpperCase() + ')'; });
    return s;
  }

  /* ================================================================ a travel mail, read for a claim
     Done once per mail as it's read (engine.parse → POST_PARSE): the PDFs it carries, and for a travel site's own
     mail what kind of trip it was, its booking id, from and to, the day of travel, the stay's place and nights, the
     amount and its GST, and whether it was cancelled. Nothing here decides money in the ledger: the engine's own
     reading stands; these facts sit beside it for the claim. */
  var KIND_WORDS = [
    ['bus', /\bbus\b|\bbus (?:booking|ticket)|boarding point|drop point|\bseat (?:no|number)\b/i],
    ['train', /\btrain\b|\birctc\b|\brailways?\b|\bberth\b|\bcoach\b/i],
    ['flight', /\bflights?\b|\bairlines?\b|\bairport\b|\bboarding pass\b|\bfare type\b|\be-?ticket\b.*\bpnr\b/i],
    ['stay', /\bhotels?\b|\bcheck-?in\b|\bcheck-?out\b|\broom\b|\bnights?\b|\bstay\b|\bresort\b|\bhomestay\b/i],
    ['cab', /\bride\b|\bcab\b|\bdriver\b|\bpickup\b|\bdrop-?off\b/i],
  ];
  // a mail from a travel site that isn't a trip: offers, surveys, reviews, dues, wallets, log-in codes
  var NOT_TRIP = /\b(?:survey|review|feedback|rate your|how was|otp|one time password|verification|dues?|postpaid|offers?|sale|deals?|membership|newsletter|refer|earn|cashback|reward|points?|coupon|welcome|balance)\b|wallet/i;
  // a subject that names the papers themselves outweighs a marketing word in it
  var STRONG = /\binvoice\b|\breceipt\b|\be-?ticket\b(?! booking)|booking (?:id|confirm)|\bpnr\b|your (?:ride|trip)\b/i;
  var TRIP_CUE = /booking status|trip id|invoice|receipt|e-?ticket|ticket|itinerary|booking (?:id|confirm|confirmation|details|is confirmed)|is confirmed|confirmation|reservation|\bpnr\b|your (?:ride|trip)|ride (?:details|summary)|trip (?:details|summary)|payment summary|thanks for (?:travelling|riding)|total fare|fare (?:details|breakdown)/i;
  var CANCELLED = /booking status\s*[:|]?\s*failed|failed to confirm|(?:has been|was|is) cancel+ed|cancellation (?:confirmed|processed|successful)|refund (?:related|processed|initiated|for your)|booking (?:failed|cancel+ed)/i;
  var SEP = '[\\s|:#.\\-–]*';
  var REF_RES = [
    new RegExp('\\bCRN' + SEP + '(\\d{6,14})', 'i'),
    new RegExp('\\b(?:Ride|Trip|Booking|Order|Reservation|Itinerary|Confirmation)\\s*(?:ID|Id|No\\.?|Number|number|reference|code)' + SEP + '([A-Z0-9][A-Z0-9\\-]{4,24})', 'i'),
    new RegExp('\\bPNR(?:\\s*No\\.?|\\s*Number)?' + SEP + '([A-Z0-9]{5,12})', 'i'),
    new RegExp('\\bConfirmation' + SEP + '([0-9]{6,14})', 'i'),
    new RegExp('\\bbooking id' + SEP + '([A-Z0-9]{6,24})', 'i'),
  ];
  var PLACE = "[A-Za-z][A-Za-z .()'&\\-]{1,40}?";
  // "From : | AMBALA CANT JN (UMB) | … To : | NEW DELHI (NDLS) |", "From: | Pune | Bus Operator: … To: | Hyderabad |"
  var FROM_TO_TABLE = new RegExp('\\bFrom\\s*:?\\s*\\|\\s*(' + PLACE + ')\\s*\\|[\\s\\S]{0,240}?\\bTo\\s*:?\\s*\\|\\s*(' + PLACE + ')\\s*(?:\\||\\n|$)');
  // the same table once its cells are run together: each place ends where the next label begins
  var FROM_TO_LABELS = new RegExp('\\bFrom\\s*:\\s*(' + PLACE + ')\\s+(?=Date of|Boarding|Bus Operator|Departure|Class\\b|Quota|To\\s*:)[\\s\\S]{0,240}?\\bTo\\s*:\\s*(' + PLACE + ')(?=\\s+(?:Date of|Boarding|Total|Bus Type|Passengers?|Class\\b|Quota|Arrival|Distance|Drop)|\\s*$)');
  // "Your flight from New Delhi-Pune booking", "Bus from Pune to Hyderabad"
  var FROM_TO_SUBJ = /\bfrom ([A-Z][A-Za-z .]{1,30}?)\s*(?:-|–|to|→)\s*([A-Z][A-Za-z .]{1,30}?)(?=\s+(?:one-way|round|booking|flight|bus|train|on|is|has|for)\b|\s*[,|]|$)/;
  // "New Delhi → Pune"
  var FROM_TO_ARROW = /([A-Z][A-Za-z .]{1,30}?)\s*(?:→|->)\s*([A-Z][A-Za-z .]{1,30}?)(?=\s+(?:Mon|Tue|Wed|Thu|Fri|Sat|Sun)\b|\s*[,|(]|\s{2}|$)/;
  // an IRCTC subject's station codes: "…, 3A, UMB - NDLS"
  var FROM_TO_CODES = /,\s*([A-Z]{2,5})\s*-\s*([A-Z]{2,5})\s*$/;
  var DATE_TXT = "(\\d{1,2}(?:st|nd|rd|th)?[- ](?:[A-Za-z]{3,9})[-, ]+\\d{2,4}|[A-Za-z]{3,9} \\d{1,2}(?:st|nd|rd|th)?,? \\d{4}|\\d{1,2}[-/]\\d{1,2}[-/]\\d{2,4})";
  var DAY_NAMES = '(?:(?:Mon|Tue|Wed|Thu|Fri|Sat|Sun)[a-z]*,?\\s+)?';
  var ON_RES = [
    new RegExp('\\bDate of (?:Journey|Travel|Boarding)' + SEP + DAY_NAMES + DATE_TXT, 'i'),
    new RegExp('\\bBoarding Date(?: and Time)?' + SEP + DAY_NAMES + DATE_TXT, 'i'),
    new RegExp('\\bTravel Date' + SEP + DAY_NAMES + DATE_TXT, 'i'),
    new RegExp('\\bCheck-?in' + SEP + DAY_NAMES + DATE_TXT, 'i'),
    new RegExp('\\bTime of (?:Ride|Trip)' + SEP + DAY_NAMES + DATE_TXT, 'i'),
    new RegExp('\\bDepart(?:ure|ing|s)?(?: (?:date|on))?' + SEP + DAY_NAMES + DATE_TXT, 'i'),
  ];
  var UNTIL_RE = new RegExp('\\bCheck-?out' + SEP + DAY_NAMES + DATE_TXT, 'i');
  var TOTAL_RE = /\b(?:Total(?: Fare| Amount| Paid| Price| Charged)?|Amount (?:Paid|Charged)|Grand Total)\s*(?:\([^)]{0,40}\))?\s*[:|]?\s*(?:₹|Rs\.?|INR)\s*([\d,]+(?:\.\d{1,2})?)/i;
  var TOTAL_BARE = /\bTotal Fare\s*[:|]\s*([\d,]+(?:\.\d{1,2})?)\b/i;
  var GST_RE = /\b(?:IGST|CGST|SGST|UTGST|GST)\b[^₹\d|\n]{0,24}[|:]?\s*(?:₹|Rs\.?|INR)?\s*([\d,]+\.\d{2})\b/gi;

  function dayIn(s, near) {
    if (!s) return '';
    var t = String(s).replace(/(\d)(st|nd|rd|th)\b/i, '$1').replace(/,/g, ' ').replace(/\s+/g, ' ').trim();
    var iso = L.isoDate ? L.isoDate(t) : '';
    if (!iso && /^[A-Za-z]{3,9} \d{1,2} \d{4}$/.test(t)) { var p = t.split(' '); iso = L.isoDate ? L.isoDate(p[0] + ' ' + p[1] + ', ' + p[2]) : ''; }
    if (!isDay(iso)) return '';
    // a day too far from the mail is a misreading (a date of birth, a card's expiry)
    if (near && Math.abs(daysBetween(near, iso)) > 400) return '';
    return iso;
  }
  function num(s) { var v = parseFloat(String(s || '').replace(/,/g, '')); return isFinite(v) ? v : 0; }
  function fileRank(f) {
    var x = lc(f);
    if (/refund|cancel/.test(x)) return 0;
    if (/invoice|tax|bill|receipt/.test(x)) return 4;
    if (/e-?ticket|ticket|itinerary|boarding|booking|confirm|voucher/.test(x)) return 3;
    return 2;
  }
  // the PDFs a mail carries, best first (an invoice before an e-ticket before anything else); at most four
  function pdfsOf(msg) {
    return (msg.attachments || []).filter(function (a) {
      return a && a.id && (/\.pdf$/i.test(a.filename || '') || /pdf/i.test(a.mime || ''));
    }).map(function (a) { return { id: String(a.id), f: String(a.filename || 'attachment.pdf').slice(0, 90) }; })
      .sort(function (a, b) { return fileRank(b.f) - fileRank(a.f); }).slice(0, 4);
  }
  function kindOf(hay) {
    for (var i = 0; i < KIND_WORDS.length; i++) if (KIND_WORDS[i][1].test(hay)) return KIND_WORDS[i][0];
    return 'travel';
  }
  function docKind(subj, text, pdfs) {
    var s = lc(subj) + ' ' + lc(pdfs.map(function (p) { return p.f; }).join(' '));
    if (/tax invoice|invoice/.test(s)) return 'invoice';
    if (/e-?ticket|ticket|boarding pass/.test(s)) return 'ticket';
    if (/receipt|your (?:ride|trip)|ride (?:details|summary)|payment summary/.test(s) || /payment summary|thanks for (?:travelling|riding)/i.test(String(text || '').slice(0, 600))) return 'receipt';
    return 'booking';
  }

  function tripFacts(msg, sender) {
    var subj = String(msg.subject || '');
    var text = E.normalize ? E.normalize(msg.text || '', msg.html || '') : String(msg.text || '');
    var head = text.slice(0, 6000);
    // tables with their cells apart, as the mail's text part or its HTML lays them out ("From : | Pune |")
    var cells = (String(msg.text || '') + '\n' + (msg.html && L.htmlLines ? L.htmlLines(msg.html) : '')).slice(0, 12000);
    var sent = String(msg.date || '').slice(0, 10);
    if (NOT_TRIP.test(subj) && !STRONG.test(subj)) return null;
    if (!TRIP_CUE.test(subj) && !TRIP_CUE.test(head.slice(0, 1500))) return null;
    var pdfs = pdfsOf(msg);
    var f = { p: sender[1], k: sender[2] || kindOf(subj + ' ' + head.slice(0, 1500)), doc: docKind(subj, head, pdfs) };
    if (CANCELLED.test(subj) || CANCELLED.test(head.slice(0, 1200))) f.off = 'cancelled';
    var i, m;
    for (i = 0; i < REF_RES.length; i++) { m = REF_RES[i].exec(subj) || REF_RES[i].exec(head); if (m && /\d/.test(m[1])) { f.ref = m[1]; break; } }
    // an airline's e-ticket names its PNR in brackets in the subject: "eTicket (AB12CD)"
    if (!f.ref && f.k === 'flight' && (m = /\(([A-Z0-9]{6})\)/.exec(subj))) f.ref = m[1];
    if ((m = FROM_TO_TABLE.exec(cells)) || (m = FROM_TO_LABELS.exec(head))) { f.from = titled(m[1]); f.to = titled(m[2]); }
    else if ((m = FROM_TO_SUBJ.exec(subj))) { f.from = titled(m[1]); f.to = titled(m[2]); }
    else if ((m = FROM_TO_ARROW.exec(head.slice(0, 2500)))) { f.from = titled(m[1]); f.to = titled(m[2]); }
    else if ((m = FROM_TO_CODES.exec(subj))) { f.from = m[1]; f.to = m[2]; }
    // a cab's pickup and drop are home and office addresses: kept out of the claim
    if (f.k === 'cab') { delete f.from; delete f.to; }
    for (i = 0; i < ON_RES.length; i++) { m = ON_RES[i].exec(head); if (m) { var on = dayIn(m[1], sent); if (on) { f.on = on; break; } } }
    if ((m = UNTIL_RE.exec(head))) { var until = dayIn(m[1], sent); if (until && (!f.on || until >= f.on)) f.until = until; }
    if (f.k === 'stay') {
      if ((m = /\b(?:confirmed|booked) at (.{3,60}?)\s*$/i.exec(subj.replace(/[^\x20-\x7E₹]/g, ' ').trim()))) f.place = m[1].trim();
      var city = /\bYour booking in ([A-Z][A-Za-z .\-]{1,30}?) is confirmed/.exec(head);
      if (city) f.place = (f.place ? f.place + ', ' : '') + city[1].trim();
      if (f.on && f.until) f.nights = Math.max(0, daysBetween(f.on, f.until));
    }
    if ((m = TOTAL_RE.exec(head)) || (m = TOTAL_BARE.exec(head))) { var amt = num(m[1]); if (amt > 0 && amt < 1e7) f.amt = r2(amt); }
    if (f.amt) {
      var tax = 0, g;
      GST_RE.lastIndex = 0;
      while ((g = GST_RE.exec(head))) tax += num(g[1]);
      if (tax > 0 && tax < f.amt * 0.3) f.tax = r2(tax);
    }
    return f;
  }

  if (E.postParse) E.postParse.push(function (r, msg) {
    if (!r || !msg || r.kind === 'noise' && !(E.travel && E.travel.senderOf(msg.from))) return;
    var pdfs = pdfsOf(msg);
    var sender = E.travel ? E.travel.senderOf(msg.from) : null;
    var f = sender ? tripFacts(msg, sender) : null;
    if (f) r.trip = f;
    if (pdfs.length && (f || /^(?:txn|confirm|bill|policy|statement)$/.test(r.kind))) r.atts = pdfs;
  });

  /* ================================================================ the claim's rows, and the mail behind each
     snap.docs: one entry per travel payment (a cab, a flight, a train, a bus, a stay) and per travel receipt that
     no payment matched, each with the mail that proves it (ev), the best PDF in it (att), what a claim form asks
     for, and whether kosh thinks it's work (inc) and why. Arithmetic and rules, never a model. */
  var ROW_KIND = {
    Transport: { 'Cabs': 'cab', 'Auto': 'cab', 'Bike taxi': 'cab', 'Car rental': 'car' },
    Travel: { 'Flights': 'flight', 'Trains': 'train', 'Buses': 'bus', 'Stays': 'stay', 'Holidays': 'holiday', 'Tours & activities': 'tour', 'Visa & passport': 'visa', 'Forex': 'forex', '': 'travel' },
  };
  var KIND_NAME = { cab: 'Cab', flight: 'Flight', train: 'Train', bus: 'Bus', stay: 'Stay', car: 'Car rental', holiday: 'Holiday', tour: 'Tour', visa: 'Visa', forex: 'Forex', travel: 'Travel' };
  var DEFAULT_KINDS = ['cab', 'flight', 'train', 'bus', 'stay'];
  function rowKind(t) {
    var g = ROW_KIND[t.c];
    if (!g) return '';
    return g[t.s] || (t.c === 'Travel' ? 'travel' : '');
  }
  // where to get an invoice the mail doesn't have
  function howToGet(k, p) {
    var app = p || 'the app';
    if (k === 'cab') return 'Open ' + app + ', find this ride under your trips, and email yourself its invoice. kosh adds it when it arrives.';
    if (k === 'flight') return 'The airline’s or booking site’s “Manage booking” page has the GST invoice; email it to yourself and kosh adds it.';
    if (k === 'train') return 'IRCTC’s booked-tickets page has the e-ticket; email it to yourself and kosh adds it.';
    if (k === 'stay') return 'Ask the hotel or the booking site for the tax invoice by email; kosh adds it when it arrives.';
    return 'Ask ' + (p || 'the seller') + ' to email you the invoice; kosh adds it when it arrives.';
  }
  function evRank(r) {
    var f = r.trip || {}, att = (r.atts || []).length ? fileRank(r.atts[0].f) : 0;
    var base = f.doc === 'invoice' ? 4 : f.doc === 'ticket' ? 3 : f.doc === 'receipt' ? 2.5 : 1;
    return base + (att >= 3 ? 2 : att > 0 ? 1 : 0);
  }
  function samePlace(t, p) {
    if (!p) return false;
    var w = lc(p).split(/[\s.]+/)[0], m = lc(t.m);
    // the site by its own name ("Ola", "OYO"), or a longer first word inside the payee ("Booking.com" in "BOOKING.COM AMS")
    if (lc(t.pf) === lc(p) || m === lc(p) || m.indexOf(lc(p) + ' ') === 0) return true;
    return (w.length >= 4 && (lc(t.m).indexOf(w) >= 0 || lc(t.m).replace(/\s+/g, '').indexOf(lc(p).replace(/[\s.]+/g, '')) >= 0));
  }

  /* is it work? kosh's guess, and the words for why. Your rules first (the kinds your company pays for, cabs only
     after a time, weekdays only), then what you did with the same payee and kind before, then the day and hour. */
  function prefOf(prefs, key) { var v = prefs[key]; return v && v.length === 2 ? v : [0, 0]; }
  function kindsOf(policy) { return Array.isArray(policy && policy.kinds) ? policy.kinds : DEFAULT_KINDS; }
  function suggest(e, policy, prefs, chapters) {
    var kinds = kindsOf(policy);
    if (e.off) return { inc: false, why: e.off === 'cancelled' ? 'Cancelled' : e.off };
    if (kinds.indexOf(e.k) < 0) return { inc: false, why: (KIND_NAME[e.k] || 'This') + ' isn’t in your claim’s kinds' };
    if (e.refunded) return { inc: false, why: 'Refunded' };
    var we = weekend(e.d);
    if (policy.weekdays && we) return { inc: false, why: 'Weekend (your rules: weekdays only)' };
    if (e.k === 'cab' && policy.cabAfter && e.t && e.t < policy.cabAfter) return { inc: false, why: 'Before ' + hm(policy.cabAfter) + ' (your rules)' };
    var pm = prefOf(prefs, 'm:' + lc(e.m) + '|' + (we ? 'we' : 'wd')), n = pm[0] + pm[1];
    if (n >= 2 && pm[0] !== pm[1]) return pm[0] > pm[1] ? { inc: true, why: 'You claimed ' + e.m + ' before' } : { inc: false, why: 'You left ' + e.m + ' out before' };
    var pk = prefOf(prefs, 'k:' + e.k + '|' + (we ? 'we' : 'wd'));
    if (pk[0] + pk[1] >= 3 && pk[0] !== pk[1]) return pk[0] > pk[1] ? { inc: true, why: 'Like the ' + (KIND_NAME[e.k] || '').toLowerCase() + 's you claimed before' } : { inc: false, why: 'Like the ' + (KIND_NAME[e.k] || '').toLowerCase() + 's you left out before' };
    var ch = e.tr && chapters[e.tr];
    if (ch && !/work|office|client|conference|offsite|off-site|business|meeting|summit|training|visit/i.test(ch)) return { inc: false, why: 'Part of your ' + ch + ' chapter' };
    if (e.k === 'cab' && we) return { inc: false, why: 'A weekend ride' };
    if (e.k === 'stay' && e.nights === 0) return { inc: true, why: 'A stay' };
    return { inc: true, why: we ? 'Travel on a weekend, but booked like work' : 'A weekday ' + (KIND_NAME[e.k] || 'trip').toLowerCase() };
  }
  function hm(t) { var h = +String(t).slice(0, 2), m = String(t).slice(3, 5); return (h % 12 || 12) + (m && m !== '00' ? ':' + m : '') + (h >= 12 ? ' pm' : ' am'); }

  function index(snap, prof, records) {
    prof = prof || {};
    var policy = prof.claimPolicy || {}, prefs = prof.packPrefs || {};
    var byId = {}, base = function (id) { return String(id || '').replace(/#\d+$/, ''); };
    (records || []).forEach(function (r) { if (r && r.id) byId[r.id] = r; });
    var chapters = {};
    (snap.trips || []).forEach(function (t) { if (t && t.id) chapters[t.id] = t.name || ''; });
    // what each claim already took (a payment claimed once isn't offered again)
    var claimedBy = {};
    (prof.claims || []).forEach(function (c) { if (c.st !== 'closed') (c.items || []).forEach(function (id) { claimedBy[id] = c.title || 'a claim'; }); });
    var rows = (snap.tx || []).filter(function (t) { return t && t.k === 'out' && !t.mr && !t.partOf; });
    var evOf = {}, used = {};
    function link(t, r) { (evOf[t.id] = evOf[t.id] || []).push(r); used[r.id] = 1; }
    rows.forEach(function (t) {
      var own = byId[base(t.id)];
      if (own && own.trip) link(t, own);
      if (t.rc && byId[base(t.rc)] && byId[base(t.rc)].trip) link(t, byId[base(t.rc)]);
    });
    // the rest of the travel mail, matched to its payment by the site, the amount and the day
    var travelRows = rows.filter(function (t) { return rowKind(t) || t.pf; });
    // (each row's day worked out once, and the cheap tests, the day and the amount, before the payee's name: it was
    // every travel mail × every travel payment, three lower-casings a pair)
    var rowDay = travelRows.map(function (t) { return dayOf(t.d); });
    // (and kept by that day, so a mail looks only at the payments within its three days, or its one: walking every travel
    // payment for each travel mail grew with the square of the trips. A payment whose day can't be read never matched)
    var rowsOn = Object.create(null);
    rowDay.forEach(function (d, ti) { if (d === d) (rowsOn[d / 864e5] || (rowsOn[d / 864e5] = [])).push(ti); });
    (records || []).forEach(function (r) {
      if (!r.trip || used[r.id] || r.trip.off) return;
      var f = r.trip, when = r.date || r.sent || '';
      var best = null, score = -1;
      if (!isDay(when)) return;
      var whenDay = dayOf(when), w = f.amt ? 3 : 1, near = [];
      for (var k = whenDay / 864e5 - w; k <= whenDay / 864e5 + w; k++) if (rowsOn[k]) near = near.concat(rowsOn[k]);
      if (near.length > 1) near.sort(function (a, b) { return a - b; });
      near.forEach(function (ti) {
        var t = travelRows[ti];
        var gap = Math.abs(Math.round((whenDay - rowDay[ti]) / 864e5));
        // a mail that names its amount can be up to three days from the payment; one that doesn't, a day at most
        if (gap > (f.amt ? 3 : 1)) return;
        var amtOk = f.amt ? Math.abs(t.a - f.amt) <= Math.max(1, f.amt * 0.01) : true;
        if (!amtOk || !samePlace(t, f.p)) return;
        var sc = (f.amt ? 10 : 0) + (3 - gap);
        if (sc > score) { score = sc; best = t; }
      });
      if (best) link(best, r);
    });
    var out = [];
    rows.forEach(function (t) {
      var evs = (evOf[t.id] || []).slice().sort(function (a, b) { return evRank(b) - evRank(a); });
      var k0 = rowKind(t);
      if (!k0 && !evs.length) return;
      var top = evs[0], f = (top && top.trip) || {};
      var k = f.k && f.k !== 'travel' ? f.k : (k0 || f.k || 'travel');
      var e = {
        tx: t.id, d: t.d, t: t.t || '', m: t.m, a: t.a, k: k, tr: t.tr || undefined, fx: t.fx || undefined,
        ev: top ? top.id : '', acct: top ? (top.acct || '') : '', from: top ? (top.from || '') : '',
        att: top && top.atts && top.atts.length && fileRank(top.atts[0].f) > 0 ? top.atts[0] : undefined,
        more: evs.length > 1 ? evs.slice(1, 4).map(function (r) { return r.id; }) : undefined,
        doc: f.doc || undefined, ref: f.ref || undefined, fromP: f.from || undefined, toP: f.to || undefined, on: f.on || undefined,
        until: f.until || undefined, place: f.place || undefined, nights: f.nights, tax: f.tax || undefined, p: f.p || t.pf || undefined,
        md: t.md || undefined, card: t.card || undefined, off: f.off || undefined,
        refunded: t.refunded && t.refunded >= t.a * 0.95 ? true : undefined,
        cl: claimedBy[t.id] || undefined,
      };
      if (!e.ev) e.how = howToGet(k, t.pf || t.m || '');
      var s = suggest(e, policy, prefs, chapters);
      e.inc = !e.cl && s.inc; e.why = e.cl ? 'In ' + e.cl : s.why;
      out.push(e);
    });
    // a trip's receipt with no payment beside it (paid from the site's wallet, in cash, or on a card kosh doesn't read)
    (records || []).forEach(function (r) {
      if (!r.trip || used[r.id] || r.trip.off || !(r.trip.amt > 0) || r.trip.doc === 'booking') return;
      var f = r.trip, d = r.date || r.sent || '';
      if (!isDay(d)) return;
      var e = {
        tx: '', d: d, t: '', m: f.p || r.inst || 'Travel', a: f.amt, k: f.k || 'travel', ev: r.id, acct: r.acct || '', from: r.from || '',
        att: r.atts && r.atts.length && fileRank(r.atts[0].f) > 0 ? r.atts[0] : undefined,
        doc: f.doc, ref: f.ref, fromP: f.from, toP: f.to, on: f.on, until: f.until, place: f.place, nights: f.nights, tax: f.tax, p: f.p,
        cl: claimedBy['ev:' + r.id] || claimedBy[r.id] || undefined, nopay: true,
      };
      var s = suggest(e, policy, prefs, chapters);
      e.inc = !e.cl && s.inc; e.why = e.cl ? 'In ' + e.cl : s.why + ' · no payment found for it';
      out.push(e);
    });
    out.sort(function (a, b) { return a.d !== b.d ? (a.d < b.d ? -1 : 1) : a.t !== b.t ? (a.t < b.t ? -1 : 1) : 0; });
    return out;
  }

  /* ================================================================ a claim's plan for a stretch of days */
  function plan(docs, from, to, policy) {
    policy = policy || {};
    var kinds = kindsOf(policy);
    var inP = (docs || []).filter(function (e) { return e.d >= from && e.d <= to && !e.off && !e.cl && kinds.indexOf(e.k) >= 0; });
    var inc = inP.filter(function (e) { return e.inc; });
    var byKind = {};
    inc.forEach(function (e) { var b = byKind[e.k] = byKind[e.k] || { n: 0, a: 0 }; b.n++; b.a += e.a; });
    return {
      from: from, to: to, items: inP, inc: inc, total: r2(inc.reduce(function (s, e) { return s + e.a; }, 0)),
      byKind: byKind, missing: inc.filter(function (e) { return !e.ev; }).length,
    };
  }
  function kindsLine(byKind) {
    var order = ['cab', 'flight', 'train', 'bus', 'stay', 'car', 'travel'];
    return order.filter(function (k) { return byKind[k]; }).map(function (k) {
      var b = byKind[k], name = { cab: 'ride', flight: 'flight', train: 'train', bus: 'bus', stay: 'stay', car: 'car rental', travel: 'travel payment' }[k] || k;
      return b.n + ' ' + name + (b.n === 1 ? '' : k === 'bus' ? 'es' : 's') + ' ' + inr(b.a);
    }).join(', ');
  }
  function periodName(from, to) {
    if (from.slice(8) === '01' && to === monthEnd(from.slice(0, 7))) return mLong(from.slice(0, 7));
    return dShort(from) + (from.slice(0, 4) !== to.slice(0, 4) ? ' ' + from.slice(0, 4) : '') + ' to ' + dShort(to) + ' ' + to.slice(0, 4);
  }

  /* ================================================================ cases: what kosh is following up for you
     { id, kind, st (needs | handling | done), title, detail, amt, d, sym, act (pack | claim), from, to, claim,
       steps [{ d, t }] }. Most pressing first: what needs you, then what kosh is handling, then what just finished. */
  function claimPaid(c, tx, taken) {
    var after = c.sent || c.made;
    if (!isDay(after)) return null;
    var credits = (tx || []).filter(function (t) { return t.k === 'in' && !taken[t.id] && t.d >= addDays(after, -1) && t.d <= addDays(after, 100); });
    // the same sum, on its own
    var hit = credits.filter(function (t) { return t.c !== 'Refund' && Math.abs(t.a - c.amount) <= Math.max(1, c.amount * 0.005); })[0];
    if (hit) return { tx: hit.id, a: hit.a, d: hit.d, how: 'own' };
    // filed as a reimbursement, maybe less than claimed
    hit = credits.filter(function (t) { return t.c === 'Reimbursement' && t.a >= c.amount * 0.3 && t.a <= c.amount * 1.05; })[0];
    if (hit) return { tx: hit.id, a: hit.a, d: hit.d, how: 'reimb' };
    // paid with the salary: this month's salary above the usual by about the claim
    var sal = (tx || []).filter(function (t) { return t.k === 'in' && t.c === 'Salary'; }).sort(function (a, b) { return a.d < b.d ? -1 : 1; });
    for (var i = 0; i < sal.length; i++) {
      var s = sal[i];
      if (taken[s.id] || s.d < addDays(after, -1) || s.d > addDays(after, 100)) continue;
      var before = sal.filter(function (x) { return x.d < s.d && x.d >= addDays(s.d, -100); }).slice(-3).map(function (x) { return x.a; });
      if (!before.length) continue;
      var extra = s.a - median(before);
      if (Math.abs(extra - c.amount) <= Math.max(50, c.amount * 0.02)) return { tx: s.id, a: r2(extra), d: s.d, how: 'salary' };
    }
    return null;
  }
  function cases(snap, prof, docs) {
    prof = prof || {};
    var today = snap.today || prof.today || '', out = [], marks = prof.caseMarks || {}, policy = prof.claimPolicy || {};
    if (!isDay(today)) return out;
    var taken = {};
    (prof.claims || []).slice().sort(function (a, b) { return (a.made || '') < (b.made || '') ? -1 : 1; }).forEach(function (c) {
      if (!c || c.st === 'closed' || !(c.amount > 0)) return;
      var steps = [{ d: c.made, t: 'Made: ' + (c.items || []).length + ' items, ' + inr(c.amount) }];
      if (c.sent) steps.push({ d: c.sent, t: 'Sent' + (c.sentTo ? ' to ' + c.sentTo : '') });
      var paid = c.st === 'paid' ? { d: c.paidOn || c.sent || c.made, a: c.amount, how: 'you' } : claimPaid(c, snap.tx, taken);
      if (paid && paid.tx) taken[paid.tx] = 1;
      var base0 = { id: 'claim|' + c.id, kind: 'claim', claim: c.id, amt: c.amount, sym: 'doc.text.fill', act: 'claim', from: c.from, to: c.to };
      if (paid) {
        var short = paid.a < c.amount * 0.98;
        steps.push({ d: paid.d, t: paid.how === 'salary' ? 'Paid with your salary' : paid.how === 'you' ? 'Marked paid' : 'Paid: ' + inr(paid.a) });
        if (short) {
          out.push(Object.assign(base0, { st: 'needs', title: inr(c.amount - paid.a) + ' short on your ' + c.title, detail: inr(paid.a) + ' of ' + inr(c.amount) + ' came on ' + dShort(paid.d) + '. Ask finance about the rest, or close it.', d: paid.d, steps: steps, paid: paid }));
        } else if (daysBetween(paid.d, today) <= 10) {
          out.push(Object.assign(base0, { st: 'done', title: c.title + ' paid', detail: inr(paid.a) + (paid.how === 'salary' ? ' with your salary' : '') + ' on ' + dShort(paid.d), d: paid.d, steps: steps, paid: paid, sym: 'checkmark.seal.fill' }));
        }
        return;
      }
      if (!c.sent) {
        out.push(Object.assign(base0, { st: 'needs', title: 'Send your ' + c.title, detail: 'Made on ' + dShort(c.made) + ' · ' + inr(c.amount) + ' · not sent yet', d: c.made, steps: steps }));
        return;
      }
      var waited = daysBetween(c.sent, today);
      steps.push({ d: today, t: 'Waiting for ' + inr(c.amount) });
      if (waited > 45) out.push(Object.assign(base0, { st: 'needs', title: c.title + ' not paid yet', detail: 'Sent on ' + dShort(c.sent) + ', ' + waited + ' days ago. kosh still watches for ' + inr(c.amount) + '.', d: c.sent, steps: steps }));
      else out.push(Object.assign(base0, { st: 'handling', title: c.title + ': waiting for ' + inr(c.amount), detail: 'Sent on ' + dShort(c.sent) + '. kosh closes it when the money comes, on its own or with your salary.', d: c.sent, steps: steps }));
    });
    // last month's claim, ready to make (the first twelve days of a month), for someone who makes claims
    var day = +today.slice(8, 10), pm = prevMonth(today.slice(0, 7));
    if (day <= 12 && marks.ready !== 'off' && !marks['ready|' + pm]) {
      var p = plan(docs, pm + '-01', monthEnd(pm), policy);
      var claimer = (prof.claims || []).length > 0 || policy.on === true;
      if (p.inc.length && (claimer || p.inc.length >= 3)) {
        out.push({ id: 'ready|' + pm, kind: 'ready', st: 'needs', title: 'Your ' + MONF[+pm.slice(5, 7) - 1] + ' travel claim is ready', amt: p.total,
                   detail: p.inc.length + ' item' + (p.inc.length === 1 ? '' : 's') + ', ' + inr(p.total) + (p.missing ? ' · ' + p.missing + ' without an invoice' : ' · every invoice found'),
                   d: monthEnd(pm), sym: 'doc.badge.plus', act: 'pack', from: pm + '-01', to: monthEnd(pm), steps: [] });
      }
    }
    var order = { needs: 0, handling: 1, done: 2 };
    return out.sort(function (a, b) { return order[a.st] - order[b.st] || (a.d < b.d ? 1 : -1); });
  }

  if (E.postBuild) E.postBuild.push(function (snap, prof, records) {
    snap.docs = index(snap, prof, records);
    snap.cases = cases(snap, prof, snap.docs);
  });

  /* ================================================================ the assistant's claim tool
     "Make my October travel claim", "what can I claim for last month": what kosh would put in it, and a card to
     open it. The period: the one the question names, else last month in a month's first twelve days, else this one. */
  function claimTool(a, ctx) {
    a = a || {};
    var today = ctx.today || '', docs = ctx.docs || [], policy = ctx.claimPolicy || {};
    var from = isDay(a.from) ? a.from : '', to = isDay(a.to) ? a.to : '';
    if (!from || !to) {
      var m = +today.slice(8, 10) <= 12 ? prevMonth(today.slice(0, 7)) : today.slice(0, 7);
      from = m + '-01'; to = monthEnd(m);
    }
    if (to > today) to = today;
    var p = plan(docs, from, to, policy), name = periodName(from, to);
    var text, data = {};
    if (!p.items.length) {
      text = 'No cabs, flights, trains, buses or stays in ' + name + ' that kosh can see in your mail and payments.';
      return { text: text, rows: [], data: data };
    }
    var left = p.items.length - p.inc.length;
    text = 'Your travel claim for ' + name + ': ' + p.inc.length + ' item' + (p.inc.length === 1 ? '' : 's') + ', ' + inr(p.total) +
      (p.inc.length ? ' (' + kindsLine(p.byKind) + ')' : '') + '.' +
      (p.missing ? ' ' + p.missing + (p.missing === 1 ? ' has' : ' have') + ' no invoice in your mail yet.' : p.inc.length ? ' Every one has its invoice or receipt.' : '') +
      (left ? ' ' + left + ' more left out (weekend rides, refunds, or your rules); you can tick them in.' : '');
    data.total = p.total; data.count = p.inc.length;
    data.proposal = { action: 'pack', date: from, until: to, amount: r0(p.total), count: p.inc.length,
                      title: 'Make the ' + name + ' travel claim (' + p.inc.length + ' item' + (p.inc.length === 1 ? '' : 's') + ', ' + inr(p.total) + ')',
                      why: 'Opens the claim to tick what’s in it; kosh makes the PDF and the Excel sheet.' };
    return { text: text, rows: p.inc.filter(function (e) { return e.tx; }).map(function (e) { return e.tx; }), data: data };
  }

  var api = {
    tripFacts: tripFacts, pdfsOf: pdfsOf, index: index, plan: plan, cases: cases, claimPaid: claimPaid, claimTool: claimTool, suggest: suggest,
    periodName: periodName, KIND_NAME: KIND_NAME,
  };
  for (var k in api) if (Object.prototype.hasOwnProperty.call(api, k) && /JSON$/.test(k)) E[k] = api[k];
  // the assistant's claim tool finds it here (agent.js), on the phone and in the tests alike
  E.packs = api;
  return api;
})(typeof KoshEngine !== 'undefined' ? KoshEngine : require('./engine.js'));
if (typeof module !== 'undefined' && module.exports) module.exports = KoshPacks;
