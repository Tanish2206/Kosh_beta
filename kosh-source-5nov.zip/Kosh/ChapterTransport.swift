import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

// MARK: - How a shared Chapter's sealed operations travel between phones (CHAPTERS.md)
//
// A shared Chapter is a log of signed operations, each sealed with the chapter's key before it leaves the phone
// (Kosh/chaptersync.js works the chapter out from them). A transport only carries the sealed blobs: it hands ours over
// and brings back everyone's, in the order it got them, by a route (a hash of the chapter's id and key) that says nothing
// about the chapter. Every transport answers the same two calls, so the chapter's logic never knows which one it rides:
//   · MemoryChapterTransport   in memory, for tests and previews
//   · RelayChapterTransport    the chapters relay (relay/ in the repo: a small serverless function, Mickey's to deploy)
// Nothing here knows about screens, keys or what's inside a blob.

/// one sealed operation as it travels: the blob (AES-GCM, base64), and once the relay has it, its number there
struct ChapterBlob: Codable, Hashable, Sendable {
    var x: String
    var n: Int? = nil
}

/// what one pull brings back: the blobs after the number asked for, the number to ask after next time, and whether
/// there are more waiting (pull again at once)
struct ChapterPull: Codable, Hashable, Sendable {
    var items: [ChapterBlob]
    var cursor: Int
    var more: Bool = false
    /// the relay wiped it (its owner deleted it, or nobody wrote to it for 180 days)
    var gone: Bool = false

    init(items: [ChapterBlob], cursor: Int, more: Bool = false, gone: Bool = false) {
        self.items = items; self.cursor = cursor; self.more = more; self.gone = gone
    }
    /// (a key the relay leaves out reads as its default: synthesized decoding would refuse the whole answer)
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        items = try c.decode([ChapterBlob].self, forKey: .items)
        cursor = try c.decode(Int.self, forKey: .cursor)
        more = try c.decodeIfPresent(Bool.self, forKey: .more) ?? false
        gone = try c.decodeIfPresent(Bool.self, forKey: .gone) ?? false
    }
}

enum ChapterTransportError: Error, Equatable {
    /// the relay said no (too big, not a route): never retried as it is
    case refused(Int)
    /// couldn't reach it, or it was busy: try again later; nothing was lost
    case unreachable
}

protocol ChapterTransport: Sendable {
    /// hand our blobs over; how many were new to the transport (the same blob again is kept once). `own` is the hash
    /// of the owner's secret, sent with a chapter's first push so only its owner can delete it later
    func push(route: String, blobs: [ChapterBlob], own: String?) async throws -> Int
    /// everyone's blobs after `after`, in the transport's order
    func pull(route: String, after: Int) async throws -> ChapterPull
}

/// the transport in memory: keeps every blob once, numbers them as they come, pages them out
actor MemoryChapterTransport: ChapterTransport {
    static let page: Int = 500
    private var routes: [String: [(n: Int, x: String)]] = [:]
    private var seen: [String: Set<String>] = [:]

    func push(route: String, blobs: [ChapterBlob], own: String?) async throws -> Int {
        var list: [(n: Int, x: String)] = routes[route] ?? []
        var have: Set<String> = seen[route] ?? []
        var added: Int = 0
        for b in blobs where !have.contains(b.x) {
            have.insert(b.x)
            list.append((n: (list.last?.n ?? 0) + 1, x: b.x))
            added += 1
        }
        routes[route] = list
        seen[route] = have
        return added
    }

    func pull(route: String, after: Int) async throws -> ChapterPull {
        let rest = (routes[route] ?? []).filter { $0.n > after }
        let items: [ChapterBlob] = rest.prefix(Self.page).map { ChapterBlob(x: $0.x, n: $0.n) }
        return ChapterPull(items: items, cursor: items.last?.n ?? after, more: rest.count > Self.page)
    }
}

/// the chapters relay over HTTPS (relay/core.js). `send` is how a request goes out: URLSession on the phone, anything
/// in a test. The relay's address is Mickey's to set once he deploys it; kosh ships with none
struct RelayChapterTransport: ChapterTransport {
    typealias Send = @Sendable (URLRequest) async throws -> (Data, Int)
    let base: URL
    let send: Send

    init(base: URL, send: Send? = nil) {
        self.base = base
        self.send = send ?? { req in
            let (data, resp) = try await URLSession.shared.data(for: req)
            return (data, (resp as? HTTPURLResponse)?.statusCode ?? 0)
        }
    }

    private struct PushBody: Encodable { let items: [Item]; let own: String?; struct Item: Encodable { let x: String } }
    private struct PushAnswer: Decodable { let added: Int }

    func url(_ route: String, after: Int? = nil) -> URL {
        var c = URLComponents(url: base.appendingPathComponent("v1/c/" + route), resolvingAgainstBaseURL: false)
        if let after { c?.queryItems = [URLQueryItem(name: "after", value: String(after))] }
        return c?.url ?? base
    }

    func push(route: String, blobs: [ChapterBlob], own: String?) async throws -> Int {
        var added: Int = 0
        // a hundred to a request, as the relay takes them
        var i: Int = 0
        while i < blobs.count {
            let chunk = Array(blobs[i..<min(i + 100, blobs.count)])
            var req = URLRequest(url: url(route))
            req.httpMethod = "POST"
            req.setValue("application/json", forHTTPHeaderField: "content-type")
            req.httpBody = try JSONEncoder().encode(PushBody(items: chunk.map { .init(x: $0.x) }, own: own))
            req.timeoutInterval = 20
            let (data, status) = try await call(req)
            guard status == 200 else { throw ChapterTransportError.refused(status) }
            added += (try? JSONDecoder().decode(PushAnswer.self, from: data).added) ?? 0
            i += 100
        }
        return added
    }

    func pull(route: String, after: Int) async throws -> ChapterPull {
        var req = URLRequest(url: url(route, after: after))
        req.timeoutInterval = 20
        let (data, status) = try await call(req)
        if status == 410 || status == 404 { return ChapterPull(items: [], cursor: after, more: false, gone: status == 410) }
        guard status == 200 else { throw ChapterTransportError.refused(status) }
        guard let p = try? JSONDecoder().decode(ChapterPull.self, from: data) else { throw ChapterTransportError.unreachable }
        return p
    }

    /// one request; a dropped connection or a busy relay (429, 5xx) is "try later", never a lost blob
    private func call(_ req: URLRequest) async throws -> (Data, Int) {
        let out: (Data, Int)
        do { out = try await send(req) } catch { throw ChapterTransportError.unreachable }
        if out.1 == 429 || out.1 >= 500 || out.1 == 0 { throw ChapterTransportError.unreachable }
        return out
    }
}
