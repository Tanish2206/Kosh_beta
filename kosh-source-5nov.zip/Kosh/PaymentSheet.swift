import SwiftUI

// MARK: - One payment, made quick to fix
//
// A payment's sheet answers three things in the order people ask them, each in a tap or two:
//   1. What was it? Its category as chips: what this payee usually is, what similar names are, what you use most;
//      then the category's own sub-categories, whom it was for, and a note.
//   2. Does it count? One switch, with the reason in plain words when kosh left it out, and the month it counts in.
//   3. Did others share it? Whoever kosh thinks was in on it is already there (the same people as the last payment
//      to this payee, else everyone at home); one tap leaves somebody out of this one, and the parts are worked out
//      equally, by your share on the slider, by shares, or by each person's own amount. Split, and what they owe
//      waits under Owed to you.
// Everything else (its chapter, a refund, its history, Ask kosh) sits below.

extension Store {
    /// the categories this payment most likely is, the likeliest first: what this payee has been before, what you
    /// filed similar names as, what its size and kind suggest, then what you use most; six at most, the current one
    /// always among them
    func quickCategories(for t: Txn) -> [Suggestion] {
        var out: [Suggestion] = []
        func add(_ c: String, _ s: String, label: String? = nil) {
            guard !c.isEmpty, out.count < 6, !out.contains(where: { $0.c == c }) else { return }
            out.append(Suggestion(label: label ?? c, c: c, s: s, card: "", merchant: "", sym: symbol(c)))
        }
        if !t.u && !t.c.isEmpty { add(t.c, t.s) }
        // the payee's own history
        var hist: [String: Int] = [:]
        var sub: [String: String] = [:]
        let key: String = (t.lk ?? "").isEmpty ? t.m.lowercased() : (t.lk ?? "")
        for x in tx where x.id != t.id && !x.u && !x.c.isEmpty {
            let k: String = (x.lk ?? "").isEmpty ? x.m.lowercased() : (x.lk ?? "")
            guard k == key else { continue }
            hist[x.c, default: 0] += 1
            if sub[x.c] == nil { sub[x.c] = x.s }
        }
        for (c, _) in hist.sorted(by: { $0.value > $1.value }) { add(c, sub[c] ?? "") }
        // similar names, then the payee's shape (a person or a shop, and how big)
        if t.k == "out" || t.k == "prepaid" {
            for s in suggestions(for: t) { add(s.c, s.s) }
            let person: Bool = PayeeGroup.looksLikePerson(t.m, vpa: t.vpa)
            if person {
                add("Family Support", "Relatives"); add("People", "Friends"); add("Gift", ""); add("Home", "Domestic help")
            } else if t.a < 300 {
                add("Food & Drinks", "Tea & coffee"); add("Groceries", "Kirana"); add("Transport", "Auto")
            } else if t.a < 2500 {
                add("Groceries", ""); add("Food & Drinks", ""); add("Shopping", "")
            } else {
                add("Shopping", ""); add("Home", ""); add("Travel", "")
            }
            // what you file most, over the last two months
            var used: [String: Int] = [:]
            let from: String = Day.add(snap.today, -60)
            for x in tx where x.sp && !x.u && x.d >= from && !x.c.isEmpty { used[x.c, default: 0] += 1 }
            for (c, _) in used.sorted(by: { $0.value > $1.value }) { add(c, "") }
        } else if t.k == "in" {
            // (rent second: a tenant's monthly credit is the money in people most often have to say what it is)
            for c in ["Salary", "Rent received", "Refund", "Transfer in", "Reimbursement", "Gift received", "Interest", "Business income", "Pension", "Other income"] {
                add(c, "", label: c == "Rent received" ? "Rent" : nil)
            }
        }
        return out
    }

    /// a category's sub-categories, the ones your payments use most first
    func quickSubs(_ c: String) -> [String] {
        let all: [String] = snap.cats[c]?.subs ?? []
        var n: [String: Int] = [:]
        for x in tx where x.c == c && !x.s.isEmpty { n[x.s, default: 0] += 1 }
        return all.sorted { (n[$0] ?? 0) != (n[$1] ?? 0) ? (n[$0] ?? 0) > (n[$1] ?? 0) : (all.firstIndex(of: $0) ?? 0) < (all.firstIndex(of: $1) ?? 0) }
    }

    /// the people a payment is most likely split with: the ones you've split with before (most often first), then
    /// the household
    var splitPeople: [String] {
        var count: [String: Int] = [:]
        // (kosh's own stand-ins for whoever you didn't name, "Someone" and "2 others", are nobody to offer back)
        for o in userOwed where o.dir == "in" && !o.name.isEmpty && o.name != "Someone" && Self.seats(o) == 1 { count[o.name, default: 0] += 1 }
        var out: [String] = count.sorted { $0.value != $1.value ? $0.value > $1.value : $0.key < $1.key }.map(\.key)
        for p in snap.people where p.id != "me" && !out.contains(p.name) { out.append(p.name) }
        return out
    }

    /// who kosh thinks shared this payment, and why, in plain words: the people you split the last payment to this
    /// payee with. Nobody else is put in by kosh, family included: a split with your parents ticked for you was the
    /// confusing part, and the people you split with are one tap away beside it, family or not.
    func splitGuess(for t: Txn) -> (names: [String], why: String) {
        let key: String = (t.lk ?? "").isEmpty ? t.m.lowercased() : (t.lk ?? "")
        // the last payment to this payee that was split: the same people again, most likely
        var lastDay: String = ""
        var lastNames: [String] = []
        for x in tx where x.id != t.id {
            let k: String = (x.lk ?? "").isEmpty ? x.m.lowercased() : (x.lk ?? "")
            guard k == key, x.d > lastDay else { continue }
            let names: [String] = shares(of: x.id).filter { !$0.name.isEmpty && Self.seats($0) == 1 }.map(\.name)
            if !names.isEmpty { lastDay = x.d; lastNames = names }
        }
        if !lastNames.isEmpty { return (lastNames, "The same people as last time at " + t.m + ".") }
        return ([], "")
    }

    /// one change to many payments at once (from Find), with an Undo: their category, whom they're for, or whether
    /// they count. Parts of split charges are left as they are.
    func changeMany(_ rows: [Txn], what: String, _ change: @escaping (inout Override) -> Void) {
        guard let live else { return }
        let ids: [String] = rows.filter { Self.part($0.id) == nil }.map(\.id)
        guard !ids.isEmpty else { return }
        var saved: [String: Override?] = [:]
        for id in ids { saved[id] = live.overrides[id] }
        live.overrideMany(ids, change)
        live.rebuildSoon()
        undoNote = UndoNote(text: what) { [weak self] in self?.restore(saved) }
    }

    /// take a split back: the shares nobody has paid yet go, and the charge is yours again, less the shares already paid
    /// back (by hand or seen coming in): those stay, and stay split off it, since their money did come in. It used to
    /// count the whole charge as yours while their money stayed out of everything: their share spent twice over
    func unshare(_ id: String) {
        let paid = paidShares(id)
        if paid.sum > 0, let t = txn(id) {
            let mine: Double = SplitWays.mine(net: t.a + (t.shared ?? 0), refunded: t.refunded ?? 0, owed: paid.sum)
            let seen: Double = t.refunded ?? 0
            live?.override(id) { $0.mine = mine; $0.sb = seen }
            edit(id) { x in let net = x.a + (x.shared ?? 0); x.shared = paid.sum; x.a = max(0, net - paid.sum) }
        } else {
            live?.override(id) { $0.mine = nil; $0.sb = nil }
            edit(id) { x in if let full = x.full { x.a = full; x.full = nil; x.shared = nil } }
        }
        userOwed.removeAll { $0.tx == id && !paid.ids.contains($0.id) }
        live?.rebuildSoon()
    }
}

/// the top of the sheet, in the colour of what it was: the category's mark, the payee, when and how, and the amount,
/// with what's different about it. Picking another category recolours it.
struct PaymentHeader: View {
    @Environment(Store.self) private var store
    let t: Txn
    @State private var naming = false
    @State private var typed = ""
    /// the payee can be named here: a live payee with a key (its UPI ID or its name), money out or in from a person or shop
    var nameable: Bool { store.live != nil && !(t.lk ?? "").isEmpty && t.partOf == nil }
    var body: some View {
        let way: String = TxSheet.way(t)
        let counted: Bool = CountSection.counted(t)
        let tint: Color = t.u || t.c.isEmpty ? Color.gray : store.color(for: t)
        VStack(spacing: 0) {
            Image(systemName: t.u ? "questionmark" : t.sym)
                .contentTransition(.symbolEffect(.replace))
                .font(.system(size: 30, weight: .semibold))
                .foregroundStyle(Color.black.opacity(0.82))
                .frame(width: 72, height: 72)
                .background(tint.gradient, in: Circle())
                .shadow(color: tint.opacity(0.45), radius: 15, y: 10)
                // room for the grabber and Done above it: the colour runs to the top of the sheet
                .padding(.top, 66)
            // (a tap on the payee's name names it, for a bank that gives only a code: "UPI ••h89k")
            Button {
                typed = store.payeeName(t) ?? (t.m.hasPrefix("UPI ••") ? "" : t.m)
                naming = true
            } label: {
                HStack(spacing: 6) {
                    Text(t.m)
                        .font(.title3.weight(.semibold))
                        .multilineTextAlignment(.center)
                        .lineLimit(2)
                    if nameable {
                        Image(systemName: "pencil").font(.footnote.weight(.semibold)).foregroundStyle(.secondary)
                    }
                }
                .foregroundStyle(Color.primary)
            }
            .buttonStyle(.press)
            .disabled(!nameable)
            .padding(.top, 14)
            .accessibilityHint(nameable ? "Names this payee on every payment to it" : "")
            .alert("Name this payee", isPresented: $naming) {
                TextField("Shop or person", text: $typed)
                    .textInputAutocapitalization(.words)
                Button("Save") { store.setPayeeName(t.id, typed) }
                if store.payeeName(t) != nil {
                    Button("Use the bank’s", role: .destructive) { store.setPayeeName(t.id, "") }
                }
                Button("Cancel", role: .cancel) {}
            } message: {
                Text("Shows on every payment to this payee, now and later.")
            }
            Text(Day.long(t.od ?? t.d) + (t.t.isEmpty ? "" : ", " + Day.time12(t.t)) + " · " + way)
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
                .padding(.top, 3)
            if let bh = t.bh, !bh.isEmpty {
                Label(bh, systemImage: "house.fill").font(.caption).foregroundStyle(.secondary).padding(.top, 4).privacySensitive()
            }
            Text((t.k == "in" ? "+" : "") + Fmt.rupees((t.wu?.isEmpty == false ? t.ot : nil) ?? t.a))
                .scaledFont(size: 54, weight: .bold, design: .rounded, relativeTo: .largeTitle)
                .foregroundStyle(t.k == "in" ? Color.green : Color.primary)
                .contentTransition(.numericText(value: t.a))
                .minimumScaleFactor(0.6)
                .lineLimit(1)
                .privacySensitive()
                .padding(.top, 12)
            if let uses = t.wu, !uses.isEmpty {
                // the order whole, and what paid for it: the shop's wallet and the card
                HStack(spacing: 6) {
                    ForEach(Array(uses.enumerated()), id: \.offset) { (_, u) in PaidPill(sym: "wallet.pass.fill", amt: u.a, what: u.w) }
                    PaidPill(sym: "creditcard.fill", amt: t.a, what: (t.bk ?? "Card") + ((t.l4 ?? "").isEmpty ? "" : " ••" + (t.l4 ?? "")))
                }
                .padding(.top, 6)
            }
            // the chips' row is always there (empty when there's nothing to say), so the hero never changes height
            HStack(spacing: 8) {
                // (full is also set when money came back: a refund is no share, so it says what was charged)
                if let full = t.full, full != t.a {
                    Chip(text: ((t.shared ?? 0) > 0 ? "Your share of " : "Of ") + Fmt.rupees(full) + ((t.shared ?? 0) > 0 ? "" : " charged"), color: Color.green)
                }
                if t.k != "in" && !counted && t.refOf == nil {
                    Chip(text: "Not counted", color: Color.orange)
                        .transition(.opacity)
                }
                if t.o != "me" {
                    Chip(text: store.ownerName(t.o) + "’s money", color: Color.sky)
                }
            }
            .frame(height: 26)
            .padding(.top, 10)
            .animation(Motion.base, value: counted)
        }
        .frame(maxWidth: .infinity)
        .padding(.horizontal, 20)
        .padding(.bottom, 24)
        // the whole top of the sheet in the category's colour, edge to edge, rounded only below
        .background(tint.opacity(0.26), in: UnevenRoundedRectangle(bottomLeadingRadius: 34, bottomTrailingRadius: 34, style: .continuous))
        .animation(Motion.large, value: t.c)
    }
}

/// what it was: the likely categories as round marks in a row (one tap; the chosen one solid, ringed in its colour),
/// then the category's own sub-categories
struct TagChips: View {
    @Environment(Store.self) private var store
    let t: Txn
    /// opens the full list of categories with its search already typing
    var find: (() -> Void)? = nil
    /// opens the full list of categories
    let more: () -> Void
    /// the marks, in the order they first showed: picking one never moves the others
    @State private var order: [Suggestion] = []
    /// each category's sub-categories, worked out once
    @State private var subsOf: [String: [String]] = [:]

    var body: some View {
        let picks: [Suggestion] = order.isEmpty ? store.quickCategories(for: t) : order
        let subs: [String] = t.u || t.c.isEmpty ? [] : (subsOf[t.c] ?? store.quickSubs(t.c))
        VStack(alignment: .leading, spacing: 12) {
            ScrollView(.horizontal) {
                HStack(alignment: .top, spacing: 12) {
                    // search first: type "fuel" or "rent" instead of hunting along the row
                    if let find {
                        Button(action: find) {
                            VStack(spacing: 7) {
                                Image(systemName: "magnifyingglass")
                                    .font(.system(size: 20, weight: .semibold))
                                    .foregroundStyle(Color.kosh)
                                    .frame(width: 56, height: 56)
                                    .background(Color.kosh.opacity(0.12), in: Circle())
                                    .padding(4)
                                Text("Search").font(.caption).foregroundStyle(.secondary).frame(width: 72)
                            }
                            .contentShape(Rectangle())
                        }
                        .buttonStyle(.press)
                        .accessibilityLabel("Search categories")
                    }
                    ForEach(picks) { p in
                        CategoryMark(p: p, on: !t.u && t.c == p.c, color: store.catColor(p.c), symbol: store.symbol(p.c)) {
                            if t.u || t.c != p.c { store.setCategory(t.id, p.c, p.s) }
                        }
                    }
                    Button(action: more) {
                        VStack(spacing: 7) {
                            Image(systemName: "square.grid.2x2")
                                .font(.system(size: 20, weight: .semibold))
                                .foregroundStyle(.secondary)
                                .frame(width: 56, height: 56)
                                .background(Color.primary.opacity(0.07), in: Circle())
                                .padding(4)
                            Text("All").font(.caption).foregroundStyle(.secondary).frame(width: 72)
                        }
                        .contentShape(Rectangle())
                    }
                    .buttonStyle(.press)
                    .accessibilityLabel("All categories")
                }
                .padding(.horizontal, 16)
            }
            .scrollIndicators(.hidden)
            if !subs.isEmpty {
                ScrollView(.horizontal) {
                    HStack(spacing: 6) {
                        ForEach(subs, id: \.self) { s in
                            SubChip(name: s, on: t.s == s, color: store.catColor(t.c)) {
                                store.setCategory(t.id, t.c, t.s == s ? "" : s)
                            }
                        }
                    }
                    .padding(.horizontal, 16)
                }
                .scrollIndicators(.hidden)
                // a new category's sub-categories replace the old ones in place, with no cross-fade
                .id(t.c)
            }
        }
        .sensoryFeedback(.selection, trigger: t.c + t.s)
        .onAppear {
            if order.isEmpty { order = picks }
            if !t.c.isEmpty && subsOf[t.c] == nil { subsOf[t.c] = subs }
        }
        .onChange(of: t.c) { _, c in
            // a category picked from the full list joins the row at the front; the rest stay where they are
            if !c.isEmpty && !order.contains(where: { $0.c == c }) {
                order.insert(Suggestion(label: c, c: c, s: t.s, card: "", merchant: "", sym: store.symbol(c)), at: 0)
            }
            if !c.isEmpty && subsOf[c] == nil { subsOf[c] = store.quickSubs(c) }
        }
    }
}

/// one category as a round mark: solid and ringed in its colour when it's the one
struct CategoryMark: View {
    let p: Suggestion
    let on: Bool
    let color: Color
    let symbol: String
    let pick: () -> Void
    var body: some View {
        Button(action: pick) {
            VStack(spacing: 7) {
                Image(systemName: symbol)
                    .font(.system(size: 22, weight: .semibold))
                    .foregroundStyle(on ? Color.black.opacity(0.82) : color)
                    .frame(width: 56, height: 56)
                    .background(Circle().fill(color.opacity(on ? 1 : 0.16)))
                    .padding(4)
                    .overlay(Circle().strokeBorder(color, lineWidth: 2.5).opacity(on ? 1 : 0))
                    .scaleEffect(on ? 1 : 0.94)
                Text(p.label)
                    .font(.caption.weight(on ? .semibold : .regular))
                    .foregroundStyle(on ? Color.primary : Color.secondary)
                    .multilineTextAlignment(.center)
                    .lineLimit(2, reservesSpace: true)
                    .frame(width: 72)
            }
            .contentShape(Rectangle())
            .animation(Motion.base, value: on)
        }
        .buttonStyle(.press)
        .accessibilityLabel(p.label)
        .accessibilityAddTraits(on ? .isSelected : [])
    }
}

/// a sub-category: tinted and outlined in its category's colour when chosen
struct SubChip: View {
    let name: String
    let on: Bool
    let color: Color
    let pick: () -> Void
    var body: some View {
        Button(action: pick) {
            Text(name)
                .font(.footnote.weight(on ? .bold : .medium))
                .foregroundStyle(on ? color : Color.secondary)
                .padding(.horizontal, 12)
                .frame(height: 32)
                .background(Capsule().fill(on ? color.opacity(0.16) : Color.primary.opacity(0.05)))
                .overlay(Capsule().strokeBorder(color.opacity(on ? 0.5 : 0), lineWidth: 1))
                .animation(Motion.quick, value: on)
        }
        .buttonStyle(.press)
        .accessibilityAddTraits(on ? .isSelected : [])
    }
}

/// does it count: one full-width button (solid when it counts), the reason in plain words, and the month it counts in.
/// Each is its own row, so a change swaps text in place instead of resizing (and cross-fading) one tall row.
struct CountRow: View {
    @Environment(Store.self) private var store
    let t: Txn
    var body: some View {
        let on: Bool = CountSection.counted(t)
        let own: String = String((t.od ?? t.d).prefix(7))
        let counted: String = String(t.d.prefix(7))
        let months: [String] = CountSection.months(own: own, cm: store.snap.cm)
        Group {
            Button {
                store.setCounted(t.id, !CountSection.counted(store.txn(t.id)))
            } label: {
                ZStack {
                    Capsule().fill(Color.primary.opacity(on ? 1 : 0.08))
                    HStack(spacing: 9) {
                        Image(systemName: on ? "checkmark.circle.fill" : "nosign")
                            .font(.body.weight(.bold))
                            .foregroundStyle(on ? Color.green : Color.orange)
                            .contentTransition(.symbolEffect(.replace))
                        Text(on ? "Counts in " + Day.monthName(counted) + "’s spending" : "Left out of spending")
                            .font(.body.weight(.semibold))
                            .foregroundStyle(on ? Color(uiColor: .systemBackground) : Color.primary)
                            .contentTransition(.opacity)
                    }
                }
                .frame(height: 52)
                .contentShape(Capsule())
                .animation(Motion.base, value: on)
            }
            .buttonStyle(.press)
            .accessibilityAddTraits(.isToggle)
            .accessibilityValue(on ? "Counted" : "Left out")
            .accessibilityHint(on ? "Leaves it out of spending" : "Counts it in spending")
            .sensoryFeedback(.selection, trigger: on)
            Text(Self.why(t, on: on))
                .font(.footnote)
                .foregroundStyle(.secondary)
                .lineLimit(3, reservesSpace: false)
                .fixedSize(horizontal: false, vertical: true)
                .padding(.horizontal, 6)
            if on && months.count > 1 {
                Menu {
                    ForEach(months, id: \.self) { m in
                        Button { store.setCountMonth(t.id, m == own ? nil : m) } label: {
                            if m == counted { Label(CountSection.monthLabel(m, own: own), systemImage: "checkmark") } else { Text(CountSection.monthLabel(m, own: own)) }
                        }
                    }
                } label: {
                    Label(counted == own ? "Count it in another month" : "Counted in " + Day.monthName(counted) + " · change", systemImage: "calendar")
                        .font(.footnote.weight(.semibold))
                }
                .padding(.horizontal, 6)
            }
        }
    }

    /// in plain words: why it counts, or why it doesn't and what turning it on does
    static func why(_ t: Txn, on: Bool) -> String {
        if on { return t.od != nil ? "Paid " + Day.fmt(t.od ?? t.d, "d MMM") + ", counted where it belongs." : "In your totals, budgets and patterns." }
        switch t.nc ?? "" {
        case "unnamed": return "A big payment kosh couldn’t name, often to your own account or a person. Name it above, or switch this on to count it as it is."
        case "parked": return "A wallet load or gift card counts when you spend from it. Switch on to count it now."
        case "wallet": return "Paid from a wallet whose top-up already counted. Switch on to count it here too."
        case "chapter": return "Its trip or event is left out of monthly spending. Switch on to count it in its month."
        case "tax": return "Income tax and GST are taxes you owe, not spending: they stay out of spending totals. Switch on to count this one."
        default:
            let ex: String = t.ex ?? ""
            let plain: Bool = ex.isEmpty || ex == Store.leftOut || ex == Store.leftOutBefore
            return plain ? "You left it out. It stays in the list, out of every total." : ex + ": out of every total, still in the list."
        }
    }
}

/// did others share it, kept simple: what's to split (the payment, less any money that came back: the refund kosh
/// saw, or one you type), then who was in on it — you, and one tap for anyone you've split with before or at home, or
/// a new name; family and friends alike, nobody ticked for you but last time's people at this payee. Split equally;
/// tap someone's amount to set it yourself and your share takes the rest. Once split, who owes what.
struct QuickSplit: View {
    @Environment(Store.self) private var store
    let t: Txn
    /// the fuller form: part of it something else, reasons to leave it out
    let more: () -> Void
    /// the seats: you first, then everyone else, named or not
    @State private var seats: [SplitSeat] = [SplitSeat()]
    /// how each part is worked out
    @State private var way: SplitWay = .equal
    /// what's typed in each seat's amount box, seat for seat (Amounts)
    @State private var typed: [String] = [""]
    /// why these people are here, in plain words
    @State private var why: String = ""
    @State private var ready = false
    @State private var naming = false
    @State private var newName = ""
    @FocusState private var nameFocus: Bool
    /// money back kosh saw: taken off what's split, unless you say not to
    @State private var useBack = true
    /// money back you type, when kosh saw none: asked for only on a tap
    @State private var askingBack = false
    @State private var typedBack: String = ""

    var body: some View {
        let owed: [OwedItem] = store.shares(of: t.id)
        if !owed.isEmpty {
            split(owed)
        } else {
            picker
        }
    }

    /// already split: who owes what, settled or not, and a way to take it back
    func split(_ owed: [OwedItem]) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            ForEach(owed) { o in
                HStack(spacing: 10) {
                    Image(systemName: o.settled ? "checkmark.circle.fill" : "person.crop.circle")
                        .foregroundStyle(o.settled ? Color.green : Color.secondary)
                    VStack(alignment: .leading, spacing: 1) {
                        Text(o.name).font(.body.weight(.semibold))
                        // (a line the other way: their part of money that came back after they paid, yours to give back)
                        Text(o.dir == "out" ? (o.settled ? "Given back" : "Yours to give back: their part of the refund")
                             : o.settled ? (o.settledBy != nil ? "Paid back · settled automatically" : "Paid back") : "Owes you").font(.caption).foregroundStyle(.secondary)
                    }
                    Spacer()
                    Text(Fmt.rupees(o.amount)).font(.body.weight(.semibold)).monospacedDigit().privacySensitive()
                        .foregroundStyle(o.settled ? Color.secondary : Color.green)
                    Button(o.settled ? "Undo" : "Paid") { withAnimation(Motion.base) { store.settle(o.id, !o.settled) } }
                        .font(.footnote.weight(.semibold))
                        .buttonStyle(.bordered)
                        .buttonBorderShape(.capsule)
                }
            }
            Button(role: .destructive) { withAnimation(Motion.base) { store.unshare(t.id) } } label: {
                Label("Undo the split", systemImage: "arrow.uturn.backward").font(.subheadline)
            }
            .buttonStyle(.press)
            .foregroundStyle(Color.red)
            .padding(.top, 2)
        }
    }

    /// the people you've split with before and the household, less whoever already has a seat
    var others: [String] {
        let seated: Set<String> = Set(seats.map { $0.name.lowercased() })
        return store.splitPeople.filter { !seated.contains($0.lowercased()) }
    }

    /// money back on this payment kosh has seen (a refund credited, or one you marked)
    var seenBack: Double { min(t.a, max(0, store.refund(t.id)?.back ?? 0)) }
    /// the day it came back, when kosh saw the credit
    var seenBackDay: String? { store.refund(t.id)?.credits.last?.d }
    /// money back you typed (only when kosh saw none)
    var typedBackAmount: Double { min(t.a, max(0, Double(typedBack.replacingOccurrences(of: ",", with: "").replacingOccurrences(of: "₹", with: "")) ?? 0)) }
    /// what's split: the payment, less what came back (a refund kosh saw is already off t.a: SplitWays.toSplit)
    var toSplit: Double { SplitWays.toSplit(net: t.a, refunded: seenBack > 0 ? (t.refunded ?? seenBack) : 0, typedBack: seenBack > 0 ? 0 : typedBackAmount, useBack: useBack) }
    /// what each seat pays, the payer first
    var parts: [Double] { SplitWays.parts(total: toSplit, seats: seats, way: way) }
    /// how many are in this one, you included
    var sharing: Int { seats.filter(\.inIt).count }
    var tint: Color { t.u || t.c.isEmpty ? Color.gray : store.color(for: t) }

    /// each piece is its own row of the form: adding people inserts rows (which iOS animates cleanly) instead of
    /// resizing one tall row (which it cross-fades, the old and new drawn over each other)
    @ViewBuilder var picker: some View {
        let shares: [Double] = parts
        let back: Double = SplitWays.back(shares)
        let bad: Bool = SplitWays.over(shares) || back <= 0.5
        pieRow(shares)
            .padding(.vertical, 6)
            .sensoryFeedback(.selection, trigger: seats.count)
            .onAppear(perform: start)
        Text("Who was in on this?").font(.body.weight(.semibold))
        seatRows(shares)
            .padding(.vertical, 2)
        addRow
            .padding(.vertical, 4)
        Text(line(shares, back: back))
            .font(.subheadline)
            .foregroundStyle(.secondary)
            .lineLimit(2, reservesSpace: true)
            .privacySensitive()
        if seats.count > 1 {
            splitButton(shares, back: back, bad: bad)
        }
        Button(action: more) {
            Label("Not all of it was shared", systemImage: "slider.horizontal.3")
                .font(.footnote.weight(.semibold))
        }
        .buttonStyle(.press)
        .foregroundStyle(Color.kosh)
    }

    /// the one line under it all, in plain words: what comes back, and whatever most needs saying with it — who is
    /// out of this one (and that they are still in your household), why these people are here, or who they are
    func line(_ shares: [Double], back: Double) -> String {
        if SplitWays.over(shares) { return "That’s more than the payment. Take something off." }
        let who: String = SplitWays.names(seats)
        if who.isEmpty { return "Not split. It all counts as yours." }
        if back <= 0.5 { return "All of it is yours, so nothing comes back." }
        let coming: String = Fmt.rupees(back) + " comes back to you"
        let out: String = SplitWays.leftOut(seats)
        if !out.isEmpty { return coming + ". " + out + (leftOutAtHome ? ", and still in your household." : ".") }
        if !why.isEmpty { return coming + ". " + why }
        return coming + ", from " + who + "."
    }

    /// somebody out of this one who lives with you: worth saying they haven't left the household
    var leftOutAtHome: Bool {
        let home: Set<String> = Set(store.snap.people.map { $0.name.lowercased() })
        return seats.dropFirst().contains { !$0.inIt && home.contains($0.name.lowercased()) }
    }

    /// the pie (your slice in the payment's colour), your share in its middle, and beside it what's split: the
    /// payment, any money that came back, and what that leaves to share
    func pieRow(_ shares: [Double]) -> some View {
        HStack(alignment: .center, spacing: 18) {
            SplitPie(shares: shares, total: toSplit, tint: tint)
                .frame(width: 124, height: 124)
                .overlay {
                    VStack(spacing: 0) {
                        Text(Fmt.rupees(shares.first ?? 0))
                            .font(.system(.callout, design: .rounded, weight: .bold))
                            .minimumScaleFactor(0.7)
                            .lineLimit(1)
                            .contentTransition(.numericText(value: shares.first ?? 0))
                        Text("yours").font(.caption2).foregroundStyle(.secondary)
                    }
                    .padding(.horizontal, 30)
                    .privacySensitive()
                }
                .accessibilityElement(children: .ignore)
                .spokenFigures("Your share " + Fmt.rupees(shares.first ?? 0) + " of " + Fmt.rupees(toSplit), hidden: "Your share of it")
            VStack(alignment: .leading, spacing: 6) {
                Text(Fmt.rupees(t.a) + " paid").font(.footnote).foregroundStyle(.secondary).privacySensitive()
                backRow
                Text(Fmt.rupees(toSplit) + " to split")
                    .font(.body.weight(.semibold))
                    .contentTransition(.numericText(value: toSplit))
                    .privacySensitive()
            }
            Spacer(minLength: 0)
        }
    }

    /// money that came back: the refund kosh saw, taken off (a tap puts it back in), or a box to type one
    @ViewBuilder var backRow: some View {
        if seenBack > 0 {
            Button {
                withAnimation(Motion.base) { useBack.toggle(); fillAmounts() }
            } label: {
                HStack(spacing: 6) {
                    Image(systemName: useBack ? "checkmark.circle.fill" : "circle")
                        .foregroundStyle(useBack ? Color.kosh : Color.secondary)
                    Text(Fmt.rupees(seenBack) + " came back" + (seenBackDay.map { " " + Day.fmt($0, "d MMM") } ?? ""))
                        .foregroundStyle(useBack ? Color.primary : Color.secondary)
                        .strikethrough(!useBack)
                }
                .font(.footnote)
            }
            .buttonStyle(.press)
            .privacySensitive()
            .accessibilityValue(useBack ? "taken off before splitting" : "not taken off")
        } else if askingBack {
            HStack(spacing: 2) {
                Text("Came back ₹").font(.footnote).foregroundStyle(.secondary)
                TextField("0", text: $typedBack)
                    .keyboardType(.decimalPad)
                    .font(.footnote.weight(.semibold))
                    .frame(width: 80)
                    .onChange(of: typedBack) { _, _ in fillAmounts() }
            }
            .privacySensitive()
        } else {
            Button {
                withAnimation(Motion.base) { askingBack = true }
            } label: {
                Text("Some of it came back?").font(.footnote.weight(.semibold))
            }
            .buttonStyle(.press)
            .foregroundStyle(Color.kosh)
        }
    }

    /// everyone in on it, one to a row: a tick to leave them out of this one, their shares or their amount, and what
    /// they pay
    func seatRows(_ shares: [Double]) -> some View {
        VStack(alignment: .leading, spacing: 0) {
            ForEach(seats.indices, id: \.self) { i in
                seatRow(i, i < shares.count ? shares[i] : 0)
                    .overlay(alignment: .bottom) { if i < seats.count - 1 { Rule() } }
            }
            if way != .equal && seats.count > 1 {
                Button { withAnimation(Motion.base) { pick(.equal) } } label: {
                    Text("Split it equally again").font(.footnote.weight(.semibold))
                }
                .buttonStyle(.press)
                .foregroundStyle(Color.kosh)
                .padding(.top, 6)
            }
        }
    }

    func seatRow(_ i: Int, _ v: Double) -> some View {
        let on: Bool = seats[i].inIt
        let name: String = seatName(i)
        return HStack(spacing: 8) {
            Button { toggle(i) } label: {
                Image(systemName: on ? "checkmark.circle.fill" : "circle")
                    .font(.title3)
                    .foregroundStyle(on ? Color.kosh : Color.secondary)
                    .frame(width: 32, height: 40)
                    .contentShape(Rectangle())
            }
            .buttonStyle(.press)
            .accessibilityLabel(name)
            .accessibilityValue(on ? "in this one" : "out of this one")
            .accessibilityAddTraits(.isToggle)
            Text(name)
                .font(.system(.callout, weight: .semibold))
                .foregroundStyle(on ? Color.primary : Color.secondary)
                .lineLimit(1)
            Spacer(minLength: 6)
            seatTail(i, v)
        }
        .frame(minHeight: 44)
        .animation(Motion.quick, value: on)
    }

    /// what the row says on its right: left out, their shares and what that comes to, their own amount, or just the
    /// figure
    @ViewBuilder func seatTail(_ i: Int, _ v: Double) -> some View {
        if !seats[i].inIt {
            Text("Out of this one").font(.footnote).foregroundStyle(.secondary)
        } else if way == .shares {
            shareStepper(i)
            Text(Fmt.pct(SplitWays.fraction(total: t.a, part: v)))
                .font(.caption).foregroundStyle(.secondary).monospacedDigit()
                .frame(width: 36, alignment: .trailing)
            figure(v)
        } else if way == .exact && i > 0 {
            amountBox(i)
        } else if i > 0 {
            // (a tap on someone's figure sets their own amount; your share takes the rest)
            Button { withAnimation(Motion.base) { pick(.exact) } } label: { figure(v) }
                .buttonStyle(.press)
                .accessibilityHint("Set what " + seatName(i) + " pays")
        } else {
            figure(v)
        }
    }

    func figure(_ v: Double) -> some View {
        Text(Fmt.rupees(v))
            .font(.system(.callout, design: .rounded, weight: .semibold))
            .monospacedDigit()
            .contentTransition(.numericText(value: v))
            .privacySensitive()
            .frame(minWidth: 58, alignment: .trailing)
    }

    /// how many shares this person counts for: one tap each way
    func shareStepper(_ i: Int) -> some View {
        HStack(spacing: 0) {
            Button { setShares(i, -1) } label: {
                Image(systemName: "minus").frame(width: 30, height: 30).contentShape(Rectangle())
            }
            .disabled(seats[i].shares <= 1)
            Text(String(seats[i].shares))
                .font(.system(.footnote, design: .rounded).weight(.bold))
                .monospacedDigit()
                .frame(minWidth: 14)
            Button { setShares(i, 1) } label: {
                Image(systemName: "plus").frame(width: 30, height: 30).contentShape(Rectangle())
            }
            .disabled(seats[i].shares >= SplitWays.mostShares)
        }
        .font(.footnote.weight(.semibold))
        .buttonStyle(.press)
        .background(Color.primary.opacity(0.08), in: Capsule())
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(seatName(i) + ", shares")
        .accessibilityValue(String(seats[i].shares))
        .accessibilityAdjustableAction { d in setShares(i, d == .increment ? 1 : -1) }
    }

    /// this person's own amount, starting from the share kosh worked out, so nothing is typed from scratch
    func amountBox(_ i: Int) -> some View {
        HStack(spacing: 2) {
            Text("₹").font(.footnote).foregroundStyle(.secondary)
            TextField("0", text: Binding(get: { i < typed.count ? typed[i] : "" }, set: { v in setTyped(i, v) }))
                .keyboardType(.decimalPad)
                .multilineTextAlignment(.trailing)
                .font(.system(.callout, design: .rounded, weight: .semibold))
                .monospacedDigit()
        }
        .padding(.horizontal, 10)
        .frame(width: 104, height: 34)
        .background(Color.primary.opacity(0.07), in: Capsule())
        .privacySensitive()
        .accessibilityLabel(seatName(i) + " pays")
    }

    /// anyone else: the people you've split with before and the household, or a new name
    var addRow: some View {
        VStack(alignment: .leading, spacing: 8) {
            WrapRow(spacing: 8, lineSpacing: 8) {
                ForEach(others, id: \.self) { p in
                    Button {
                        withAnimation(Motion.base) { add(p) }
                    } label: {
                        Label(p, systemImage: "plus")
                            .font(.subheadline.weight(.semibold))
                            .lineLimit(1)
                            .padding(.horizontal, 12)
                            .frame(minHeight: 34)
                            .background(Color.primary.opacity(0.07), in: Capsule())
                    }
                    .buttonStyle(.press)
                }
                if naming {
                    TextField("Name", text: $newName)
                        .textInputAutocapitalization(.words)
                        .focused($nameFocus)
                        .submitLabel(.done)
                        .onSubmit(addName)
                        .font(.subheadline)
                        .padding(.horizontal, 12)
                        .frame(width: 140, height: 34)
                        .background(Color.primary.opacity(0.07), in: Capsule())
                } else {
                    Button {
                        naming = true
                        nameFocus = true
                    } label: {
                        Label("Someone else", systemImage: "plus").font(.subheadline.weight(.semibold))
                            .padding(.horizontal, 12)
                            .frame(height: 34)
                            .overlay(Capsule().strokeBorder(Color.kosh.opacity(0.4), lineWidth: 1))
                    }
                    .buttonStyle(.press)
                    .foregroundStyle(Color.kosh)
                }
            }
        }
    }

    func splitButton(_ shares: [Double], back: Double, bad: Bool) -> some View {
        Button {
            var out: [(name: String, amount: Double)] = []
            var rest: Double = 0
            var unnamed: Int = 0
            for i in seats.indices where i > 0 && i < shares.count && shares[i] > 0 {
                let nm: String = seats[i].name.trimmingCharacters(in: .whitespaces)
                if nm.isEmpty { rest += shares[i]; unnamed += 1 } else { out.append((name: nm, amount: shares[i])) }
            }
            if rest > 0 { out.append((name: unnamed == 1 ? "Someone" : "\(unnamed) others", amount: rest)) }
            // money back you typed is kept as this payment's refund, come back, so every figure takes it off too
            if seenBack <= 0 && typedBackAmount > 0 {
                store.expectRefund(t.id, amount: typedBackAmount, by: nil, note: "")
                store.refundBack(t.id, true)
            }
            withAnimation(Motion.base) { store.shareCharge(t.id, shares: out, title: t.m, typedBack: seenBack <= 0 ? typedBackAmount : 0) }
            // taken back ("Undo the split"), the picker fills itself in again from kosh's guess
            seats = [SplitSeat()]; typed = [""]; way = .equal; why = ""; ready = false; askingBack = false; typedBack = ""; useBack = true
        } label: {
            Text(way == .equal ? "Split \(sharing) ways" : "Split: " + Fmt.rupees(back) + " comes back")
                .font(.body.weight(.semibold))
                .frame(maxWidth: .infinity)
                .padding(.vertical, 4)
        }
        .buttonStyle(.glassProminent).koshFilled()
        .disabled(bad)
    }

    // MARK: setting it up

    /// "You", a name, or a seat nobody has named
    func seatName(_ i: Int) -> String {
        if i == 0 { return "You" }
        let n: String = seats[i].name.trimmingCharacters(in: .whitespaces)
        return n.isEmpty ? "Someone" : n
    }

    /// the split opens on kosh's answer: whoever it thinks was in on it, split equally
    func start() {
        guard !ready else { return }
        ready = true
        let guess: (names: [String], why: String) = store.splitGuess(for: t)
        guard !guess.names.isEmpty else { return }
        var list: [SplitSeat] = [SplitSeat()]
        for n in guess.names.prefix(SplitWays.most - 1) { list.append(SplitSeat(name: n)) }
        seats = list
        typed = Array(repeating: "", count: list.count)
        why = guess.why
    }

    /// in this one, or out of it (out of this payment only: they stay in your household)
    func toggle(_ i: Int) {
        guard i < seats.count else { return }
        why = ""
        seats[i].inIt.toggle()
        fillAmounts()
    }

    func setShares(_ i: Int, _ d: Int) {
        guard i < seats.count else { return }
        why = ""
        withAnimation(Motion.base) { seats[i].shares = min(max(1, seats[i].shares + d), SplitWays.mostShares) }
    }

    /// the way the parts are worked out; each way starts from the figures the last one showed
    func pick(_ w: SplitWay) {
        guard w != way else { return }
        why = ""
        if w == .yours { seats[0].amount = (toSplit / Double(max(1, sharing))).rounded() }
        way = w
        fillAmounts()
    }

    /// the amount boxes always start from an answer: an equal share each, never a blank
    func fillAmounts() {
        guard way == .exact else { return }
        let even: [Double] = SplitWays.parts(total: toSplit, seats: seats, way: .equal)
        seats = SplitWays.filled(seats, parts: even)
        typed = seats.indices.map { i in i == 0 || !seats[i].inIt ? "" : Fmt.trim(seats[i].amount ?? 0, 2) }
    }

    /// what was typed into one seat's amount box
    func setTyped(_ i: Int, _ v: String) {
        guard i < seats.count else { return }
        while typed.count < seats.count { typed.append("") }
        typed[i] = v
        let digits: String = v.replacingOccurrences(of: ",", with: "").replacingOccurrences(of: "₹", with: "")
        seats[i].amount = digits.isEmpty ? nil : TypedAmount.cap(Double(digits) ?? 0)
    }

    /// someone you've split with before, or the household
    func add(_ name: String) {
        guard seats.count < SplitWays.most else { return }
        why = ""
        seats.append(SplitSeat(name: name))
        typed.append("")
        if way == .yours { seats[0].amount = (toSplit / Double(max(1, sharing))).rounded() }
        fillAmounts()
    }

    func addName() {
        let name: String = newName.trimmingCharacters(in: .whitespaces)
        if !name.isEmpty && !seats.contains(where: { $0.name.lowercased() == name.lowercased() }) {
            withAnimation(Motion.base) { add(name) }
        }
        newName = ""
        naming = false
    }
}

/// a split as a ring: your slice in the payment's colour, the others in greys, a hair of space between them
struct SplitPie: View {
    let shares: [Double]
    let total: Double
    let tint: Color

    struct Slice: Identifiable { let id: Int; let from: Double; let to: Double; let color: Color }

    var slices: [Slice] {
        let greys: [Color] = [Color(white: 0.56), Color(white: 0.39), Color(white: 0.68)]
        let sum: Double = max(total, shares.reduce(0, +), 1)
        let gap: Double = shares.count > 1 ? 0.007 : 0
        var out: [Slice] = []
        var at: Double = 0
        for (i, v) in shares.enumerated() {
            let f: Double = max(0, v) / sum
            let end: Double = at + f
            out.append(Slice(id: i, from: at + (f > gap * 2 ? gap : 0), to: max(at, end - (f > gap * 2 ? gap : 0)), color: i == 0 ? tint : greys[(i - 1) % greys.count]))
            at = end
        }
        return out
    }

    var body: some View {
        ZStack {
            Circle().stroke(Color.primary.opacity(0.06), lineWidth: 20)
            ForEach(slices) { s in
                Circle()
                    .trim(from: s.from, to: s.to)
                    .stroke(s.color, style: StrokeStyle(lineWidth: 20, lineCap: .butt))
                    .rotationEffect(.degrees(-90))
            }
        }
        .padding(10)
        .animation(Motion.open, value: shares)
    }
}


/// one share of an order's payment, as a small capsule: "₹3,000 · Myntra Credit"
struct PaidPill: View {
    let sym: String; let amt: Double; let what: String
    var body: some View {
        HStack(spacing: 5) {
            Image(systemName: sym).font(.caption2.weight(.semibold)).foregroundStyle(.secondary)
            Text(Fmt.rupees(amt)).font(.caption.weight(.semibold)).monospacedDigit()
            Text(what).font(.caption).foregroundStyle(.secondary).lineLimit(1)
        }
        .padding(.horizontal, 10).padding(.vertical, 5)
        .background(.white.opacity(0.08), in: Capsule())
        .privacySensitive()
    }
}
