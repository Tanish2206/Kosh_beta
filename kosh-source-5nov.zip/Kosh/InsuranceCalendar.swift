import SwiftUI

// MARK: - Insurance: the renewal calendar, and policies whose papers are locked
//
// Every running policy's next premium or renewal in the next twelve months, month by month: its day, how much, and
// whom it covers (engine.js › insuranceBook › premAhead). A policy whose day the mail gave and whose premium it didn't
// is there too, with no figure: "Paper locked" when its policy paper came locked, "Not known yet" otherwise. A day
// gone by stays only while the policy is past due in its grace period. Worked out once a build (Store.renewalMonths).
//
// A policy whose missing cover or premium is in its locked paper (Policy.paperLocked) says so plainly wherever it
// shows, with what its insurer's mail says opens it and the way to the family's details, which open it on this phone.

/// one premium or renewal on the calendar
struct RenewalItem: Identifiable, Hashable {
    let a: PremAhead
    /// its plan, else its insurer and kind
    let title: String
    /// "covers Papa", "covers you, Asha and Papa"
    let covers: String
    /// cover bought a year at a time renews; a life policy's premium is due
    let renews: Bool
    /// its day has gone by: past due, in its grace period
    let late: Bool
    /// its premium is in its locked paper
    let locked: Bool
    var id: String { a.id }
}

/// one month of the calendar: what falls in it, what the known premiums add up to, and how many have no figure yet
struct RenewalMonth: Identifiable, Hashable {
    let m: String
    let items: [RenewalItem]
    let total: Double
    let unknown: Int
    var id: String { m }
}

enum RenewalCalendar {
    static func make(_ store: Store) -> [RenewalMonth] {
        let today: String = store.snap.today
        let cm: String = String(today.prefix(7))
        var by: [String: [RenewalItem]] = [:]
        for a in store.snap.premAhead ?? [] where store.who.owns(a.owner) {
            let p: Policy? = InsBook.policy(store, a.policy)
            let late: Bool = a.date < today
            // (a day gone by is still owed only while its policy is past due; one paid since has moved on)
            if late && p?.status != "overdue" { continue }
            let title: String = p.map { InsBook.name($0) } ?? (a.name.isEmpty ? a.insurer : a.name)
            let covers: String = p.map { InsBook.covers($0, store.snap) } ?? ("covers " + InsBook.who(a.owner, store.snap))
            let renews: Bool = p.map { PolicyKinds.part($0) != "Life" } ?? true
            let item: RenewalItem = RenewalItem(a: a, title: title, covers: covers, renews: renews, late: late, locked: a.noAmt == "locked")
            // (one past due is this month's to pay)
            by[late ? cm : String(a.date.prefix(7)), default: []].append(item)
        }
        return by.keys.sorted().map { (m: String) -> RenewalMonth in
            let items: [RenewalItem] = by[m] ?? []
            let total: Double = items.reduce(0) { $0 + max(0, $1.a.amt) }
            let unknown: Int = items.filter { $0.a.amt <= 0 }.count
            return RenewalMonth(m: m, items: items, total: total, unknown: unknown)
        }
    }
}

extension Store {
    /// the renewal calendar for whoever's money is showing: worked out again only when a build lands
    var renewalMonths: [RenewalMonth] {
        let key: String = who.id + "|" + snap.today
        if renewalsMemo.gen == txGen && renewalsMemo.key == key { return renewalsMemo.months }
        let months: [RenewalMonth] = RenewalCalendar.make(self)
        renewalsMemo = (txGen, key, months)
        return months
    }
}

/// the calendar, month by month (Insurance › Premiums ahead › By month)
struct RenewalCalendarPage: View {
    @Environment(Store.self) private var store
    var body: some View {
        let months: [RenewalMonth] = store.renewalMonths
        let end: String = Day.addMonths(String(store.snap.today.prefix(7)), 12)
        let total: Double = months.reduce(0) { $0 + $1.total }
        let unknown: Int = months.reduce(0) { $0 + $1.unknown }
        let locked: Int = months.reduce(0) { n, m in n + m.items.filter(\.locked).count }
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Every premium and renewal from today to " + Day.fmt(end + "-01", "MMMM yyyy") + ", from your policies’ mail and payments.")
                        .font(.subheadline).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                    if total > 0 {
                        Text(Fmt.words(total) + " in all" + (unknown > 0 ? ", and " + Words.number(unknown) + " whose premium isn’t known yet" : ""))
                            .font(.subheadline.weight(.semibold)).fixedSize(horizontal: false, vertical: true).privacySensitive()
                    }
                }
                if months.isEmpty {
                    InsNone(text: "No premium or renewal day in your mail for the next twelve months. A renewal notice or a premium receipt brings one here.", add: true)
                }
                ForEach(months) { mo in RenewalMonthCard(mo: mo) }
                if locked > 0 { LockedPapersCard(n: locked) }
            }
            .padding(.horizontal, 20)
            .padding(.top, 8)
            .padding(.bottom, 30)
        }
        .animation(Motion.base, value: store.who)
    }
}

/// one month: its name and what it adds up to, then each premium or renewal in it
struct RenewalMonthCard: View {
    @Environment(Store.self) private var store
    let mo: RenewalMonth
    var body: some View {
        let sum: String = mo.total > 0 ? Fmt.rupees(mo.total) + (mo.unknown > 0 ? " + " + Words.number(mo.unknown) + " not known" : "") : ""
        VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .firstTextBaseline) {
                Text(Day.fmt(mo.m + "-01", "MMMM yyyy")).font(.title3.weight(.bold)).accessibilityAddTraits(.isHeader)
                Spacer(minLength: 8)
                if !sum.isEmpty { Text(sum).font(.subheadline.weight(.semibold)).monospacedDigit().foregroundStyle(.secondary).privacySensitive() }
            }
            VStack(spacing: 0) {
                ForEach(Array(mo.items.enumerated()), id: \.element.id) { i, it in
                    if i > 0 { Divider().padding(.leading, 68) }
                    Button { store.push(.policy(it.a.policy)) } label: { RenewalRow(it: it) }.buttonStyle(.press)
                }
            }
            .background(CardFill(), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        }
    }
}

/// one premium or renewal: its day, the policy, whom it covers, and how much (or why that isn't known)
struct RenewalRow: View {
    @Environment(Store.self) private var store
    let it: RenewalItem
    var body: some View {
        let a: PremAhead = it.a
        let day: String = Day.fmt(a.date, "d MMM")
        let when: String = it.late ? "Was due " + day : (it.renews ? "Renews " : "Premium due ") + day
        let amount: String = a.amt > 0 ? Fmt.rupees(a.amt) : it.locked ? "Paper locked" : "Not known yet"
        HStack(alignment: .top, spacing: 12) {
            DateBadge(date: a.date)
            VStack(alignment: .leading, spacing: 2) {
                Text(it.title).font(.subheadline.weight(.semibold)).foregroundStyle(Color.primary).lineLimit(2)
                Text(when + " · " + Words.cap(it.covers)).font(.caption).foregroundStyle(it.late ? Color.orange : Color.secondary)
                    .fixedSize(horizontal: false, vertical: true)
                if it.locked {
                    Text("The premium shows once its paper opens").font(.caption).foregroundStyle(.secondary)
                } else if a.amt <= 0 {
                    Text("Its mail gave the day, not the premium").font(.caption).foregroundStyle(.secondary)
                }
                if let m = a.perMonth, m > 0 {
                    Text("Put aside " + Fmt.rupees(m) + " a month").font(.caption).foregroundStyle(.secondary).privacySensitive()
                }
            }
            Spacer(minLength: 8)
            Text(amount)
                .font(a.amt > 0 ? Font.subheadline.weight(.semibold) : Font.caption)
                .foregroundStyle(a.amt > 0 ? Color.primary : Color.secondary)
                .monospacedDigit()
                .privacySensitive()
        }
        .padding(.horizontal, 14).padding(.vertical, 11)
        .contentShape(Rectangle())
        .accessibilityElement(children: .combine)
    }
}

/// under the calendar: how many premiums wait on a locked paper, and the way to the details that open them
struct LockedPapersCard: View {
    @Environment(Store.self) private var store
    let n: Int
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Label(n == 1 ? "One premium is in a locked policy paper" : Words.cap(Words.number(n)) + " premiums are in locked policy papers", systemImage: "lock.fill")
                .font(.subheadline.weight(.semibold)).foregroundStyle(Color.orange)
            Text("Insurers lock a policy’s paper with its holder’s details, like a date of birth. Once they’re added, kosh opens the papers on this phone and the premiums and cover show here.")
                .font(.footnote).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            if store.live != nil {
                Button { store.betaSheet = .passwords } label: { Label("Add the details that open them", systemImage: "key.fill").font(.subheadline.weight(.semibold)) }
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(14)
        .background(Color.orange.opacity(0.07), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
    }
}

/// a policy whose missing figures are in its locked paper: said plainly, with what opens it and, where it isn't inside
/// another button, the way to the details that open it
struct LockedPaperNote: View {
    @Environment(Store.self) private var store
    let p: Policy
    var button: Bool = true
    var body: some View {
        let opens: String = InsBook.opens(store, p)
        VStack(alignment: .leading, spacing: 6) {
            Label(InsBook.lockedLine(p) + ".", systemImage: "lock.fill")
                .font(.footnote.weight(.semibold)).foregroundStyle(Color.orange)
                .fixedSize(horizontal: false, vertical: true)
            if !opens.isEmpty {
                Text(opens).font(.footnote).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            }
            if button && store.live != nil {
                Button { store.betaSheet = .passwords } label: { Label("Add the details that open it", systemImage: "key.fill").font(.footnote.weight(.semibold)) }
                    .buttonStyle(.borderless)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}
