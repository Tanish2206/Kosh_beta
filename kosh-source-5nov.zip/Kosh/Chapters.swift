import SwiftUI

// MARK: - Chapters: your trips and life events, as a notebook
//
// A tab of its own. It opens on a notebook (ChaptersOpening.swift): a page for each of your chapters, oldest
// first, the slider under it turning them a chapter at a time; a tap on a page gives the short version, and from
// there the chapter's own page. Until there's one of your own, the notebook holds sample pages instead.
// "All chapters" opens the timeline of them all: the months run left to right along a ruler; each chapter hangs
// from the day it happened by a thread, and its span lies on the ruler, so two in one month sit side by side and
// overlapping ones stack in lanes. Below it: what kosh found in the mail, the year as a shelf of books (one per
// chapter, as thick as it cost), what's coming up. "Start a new chapter" stays pinned over the tab bar on both.

struct ChaptersTabView: View {
    @Environment(Store.self) private var store
    @Namespace private var zoom
    var body: some View {
        @Bindable var store = store
        NavigationStack(path: $store.chapPath) {
            ChaptersHome(zoom: zoom)
                .navigationDestination(for: Route.self) { route in
                    RouteDestination(route: route, zoom: zoom)
                }
        }
        // the timeline of them all is pushed over the notebook: its cards zoom into their pages in the same space
        .environment(\.chaptersZoom, zoom)
    }
}

private struct ChaptersZoomKey: EnvironmentKey {
    static var defaultValue: Namespace.ID? { nil }
}

extension EnvironmentValues {
    /// the namespace the Chapters tab's pages zoom in, for the pages pushed onto it
    var chaptersZoom: Namespace.ID? {
        get { self[ChaptersZoomKey.self] }
        set { self[ChaptersZoomKey.self] = newValue }
    }
}

/// "All chapters": every chapter of yours on the timeline, pushed over the notebook
enum ChaptersAll {
    /// Its route. Chapters' own screens have no Route case of their own, so it rides on .chapter with an id no
    /// trip can have; ChapterPage shows the timeline for it.
    static let id: String = "kosh.chapters.all"
}

extension Store {
    /// your own chapters (one with no dates sits where its payments are), then the samples when they're shown
    func chapterItems(samples: Bool) -> [Chapter] {
        // (with one person picked: the chapters they're in, each at what their own payments in it came to)
        var out: [Chapter] = trips.filter { who == .family || $0.who.contains(who.id) || chapterAmount($0) > 0 }.map { chapterItem($0) }
        if samples { out += ChapterSamples.chapters }
        return out
    }

    /// what a chapter cost whoever is picked: all of it for the family, else that person's own payments in it
    func chapterAmount(_ t: TripInfo) -> Double { who == .family ? t.total : (t.people.first { $0.o == who.id }?.v ?? 0) }

    /// one of your trips or events, as the timeline shows it
    func chapterItem(_ t: TripInfo) -> Chapter {
        let kind: String = ChapterKinds.kind(forSym: t.sym, event: t.isEvent)
        let fam: ChapterFam = t.isEvent ? ChapterKinds.fam(kind) : .journey
        let today: String = snap.today
        // no dates (an event you fill by hand): it runs from its first payment to its last, or sits at today
        let days: [String] = t.from.isEmpty ? tripRows(t.id).map { $0.od ?? $0.d }.sorted() : []
        let start: String = t.from.isEmpty ? (days.first ?? today) : t.from
        var to: String = t.from.isEmpty ? (days.last ?? today) : t.to
        if to.isEmpty { to = start > today ? start : today }
        let extra: String = t.days > 0 ? TripWhen.days(t.days) : (t.n == 1 ? "1 payment" : String(t.n) + " payments")
        var badge: String = ""
        if t.state == "now" { badge = "Under way" } else if t.budget > 0 && t.total > t.budget { badge = "Over budget" }
        // the first payment made before its days: a flight, a deposit
        let lead: String = t.from.isEmpty ? "" : (tripRows(t.id).map { $0.od ?? $0.d }.filter { $0 < t.from }.min() ?? "")
        return Chapter(id: t.id, title: t.name, fam: fam, kind: kind, stamp: "", ink: t.color, tint: "",
                       from: start, to: to, pin: start, dates: t.from.isEmpty ? "No set dates" : TripWhen.range(t.from, t.to, today: today),
                       amount: chapterAmount(t), extra: extra, badge: badge, draft: false, rot: -3, sample: false, lead: lead)
    }
}

/// Chapters' first screen: the notebook, filled with your chapters (or the samples, until you have one)
struct ChaptersHome: View {
    @Environment(Store.self) private var store
    let zoom: Namespace.ID?
    /// pushed from Home rather than its own tab
    var asTab: Bool = true
    @State private var showNew = false
    @State private var showWelcome = false
    @State private var showDemo = false
    /// an idea from over the start button: that kind of chapter starts, its name filled in
    @State private var idea: ChapterIdea?
    /// a trip found in the mail, being looked over
    @State private var draftOpen: TripDraft?

    /// the pill over the postcards: "Goa, 3 – 7 Mar? Found in your mail", or how many were found
    static func foundLine(_ drafts: [TripDraft]) -> String {
        guard let d = drafts.first else { return "" }
        if drafts.count > 1 { return String(drafts.count) + " trips found in your mail" }
        return d.place + ", " + TripDraftCard.span(d) + "? Found in your mail"
    }

    var body: some View {
        let pages: [NotebookChapter] = store.notebookPages()
        let items: [String: Chapter] = Dictionary(store.chapterItems(samples: false).map { ($0.id, $0) }, uniquingKeysWith: { a, _ in a })
        let mine: [ChapterIdea] = pages.map { p in ChapterIdea.mine(p, p.chapterID.flatMap { items[$0] }) }
        // one screen: your chapters and ideas as postcards across the top, what Chapters does, start under them
        ChaptersPostcards(asTab: asTab, mine: mine, start: { showNew = true }, idea: { i in idea = i },
                          open: { id in store.push(.chapter(id)) }, demo: { showDemo = true }, list: { store.push(.chapter(ChaptersAll.id)) })
            // trips found in the mail: one opens straight onto its payments to look over; several, the list of every
            // chapter, where they sit on top
            .safeAreaInset(edge: .top, spacing: 0) {
                let drafts: [TripDraft] = store.snap.tripDrafts ?? []
                if let first = drafts.first {
                    Button {
                        if drafts.count == 1 { draftOpen = first } else { store.push(.chapter(ChaptersAll.id)) }
                    } label: {
                        Label(Self.foundLine(drafts), systemImage: "envelope.badge")
                            .font(.subheadline.weight(.semibold))
                            .lineLimit(1)
                            .padding(.horizontal, 14).padding(.vertical, 8)
                            .background(Color.kosh.opacity(0.12), in: Capsule())
                    }
                    .buttonStyle(.press)
                    .foregroundStyle(Color.kosh)
                    .padding(.top, 4)
                    .padding(.horizontal, 24)
                }
            }
            .modifier(TripDraftPresenter(draft: $draftOpen))
            .modifier(ChapterFlows(showNew: $showNew, showWelcome: $showWelcome, showDemo: $showDemo))
            .sheet(item: $idea) { i in
                if store.live != nil {
                    TripEditor(editing: nil, preset: i.preset, suggested: i.name)
                } else {
                    NewChapterSheet(initial: i.preset.key).presentationDragIndicator(.visible)
                }
            }
    }

    /// the chapters running through a month, or being paid for ahead in it
    static func inView(_ m: String, _ items: [Chapter], _ today: String) -> String {
        let names: [String] = items.filter { String($0.from.prefix(7)) <= m && String($0.to.prefix(7)) >= m }.sorted { $0.from < $1.from }.map(\.title)
        if names.isEmpty {
            let ahead: [String] = items.filter { !$0.lead.isEmpty && String($0.lead.prefix(7)) <= m && String($0.from.prefix(7)) > m }.sorted { $0.from < $1.from }.map(\.title)
            if !ahead.isEmpty { return "Paying ahead for " + ahead.prefix(2).joined(separator: " and ") }
            return m == String(today.prefix(7)) ? "Today" : "A quiet month"
        }
        if names.count > 2 { return names[0] + ", " + names[1] + " and " + String(names.count - 2) + " more" }
        return names.joined(separator: " · ")
    }

    /// each chapter's number, in the order the timeline hangs them
    static func numbers(_ items: [Chapter]) -> [String: Int] {
        var out: [String: Int] = [:]
        for (i, c) in items.sorted(by: { $0.pin < $1.pin }).enumerated() { out[c.id] = i + 1 }
        return out
    }

    /// under way and still to come, soonest first
    static func upcoming(_ items: [Chapter], _ today: String) -> [Chapter] {
        Array(items.filter { $0.to >= today }.sorted { $0.from < $1.from }.prefix(4))
    }
}

/// starting a chapter, how chapters work, and the demo: the same three wherever Chapters is shown
struct ChapterFlows: ViewModifier {
    @Environment(Store.self) private var store
    @Binding var showNew: Bool
    @Binding var showWelcome: Bool
    @Binding var showDemo: Bool
    /// "Next chapter" was tapped in the demo: the new-chapter flow opens once the demo has closed
    @State private var newAfterDemo = false

    func body(content: Content) -> some View {
        content
            .sheet(isPresented: $showNew) {
                NewChapterSheet().presentationDragIndicator(.visible)
            }
            .sheet(isPresented: $showWelcome) {
                ChaptersWelcome(start: { showWelcome = false; showNew = true }, done: { showWelcome = false })
                    .presentationDragIndicator(.visible)
            }
            .fullScreenCover(isPresented: $showDemo, onDismiss: {
                if newAfterDemo {
                    newAfterDemo = false
                    showNew = true
                }
            }) {
                ChaptersDemo(startOwn: { newAfterDemo = true; showDemo = false })
                    .environment(store)
                    .tint(Color.kosh)
            }
    }
}

/// "All chapters": the timeline, what kosh found in the mail, the year's shelf, what's next
struct ChaptersTimeline: View {
    @Environment(Store.self) private var store
    @Environment(\.chaptersZoom) private var zoom
    @State private var month: String = ""
    @State private var back = false
    @State private var jump = 0
    @State private var showNew = false
    @State private var showWelcome = false
    @State private var showDemo = false
    @AppStorage("chapters.samples") private var samples = true
    /// a trip found in the mail, being looked over
    @State private var draftOpen: TripDraft?

    /// the samples show only until there is a chapter of your own: then the timeline is yours alone
    var withSamples: Bool { samples && store.trips.isEmpty }

    var body: some View {
        let showSamples: Bool = withSamples
        let items: [Chapter] = store.chapterItems(samples: showSamples)
        let today: String = store.snap.today
        let shown: String = month.isEmpty ? String(today.prefix(7)) : month
        ScrollView {
            VStack(alignment: .leading, spacing: 0) {
                if items.isEmpty {
                    EmptyChapters { showNew = true }
                        .padding(.horizontal, 24)
                        .padding(.top, 12)
                } else {
                    MonthHeader(month: shown, today: today, back: back, inView: ChaptersHome.inView(shown, items, today)) { jump += 1 }
                        .padding(.horizontal, 24)
                        .padding(.top, 6)
                    ChapterThread(items: items, today: today, zoom: zoom, month: $month, back: $back, jump: jump,
                                  open: { c in store.push(.chapter(c.id)) }, start: { showNew = true })
                        .padding(.top, 10)
                    ThreadKey().padding(.horizontal, 24).padding(.top, 2)
                }

                // trips the bookings in the mail make, offered as chapters (the sample's place when there are some)
                let drafts: [TripDraft] = store.snap.tripDrafts ?? []
                if !drafts.isEmpty {
                    Hairline().padding(.top, 22)
                    VStack(spacing: 12) {
                        ForEach(drafts.prefix(4)) { d in
                            TripDraftCard(draft: d, look: { draftOpen = d }) { id in store.push(.chapter(id)) }
                        }
                    }
                    .padding(.horizontal, 24).padding(.top, 24)
                } else if showSamples {
                    Hairline().padding(.top, 22)
                    MailNotice { store.push(.chapter("bali")) }.padding(.horizontal, 24).padding(.top, 24)
                }
                let shelf: ShelfData = ShelfData.make(items, today: today, store: store)
                if !shelf.books.isEmpty {
                    Hairline().padding(.top, 28)
                    YearShelf(data: shelf, numbers: ChaptersHome.numbers(items)) { c in store.push(.chapter(c.id)) }
                        .padding(.horizontal, 24).padding(.top, 26)
                }
                if store.live != nil {
                    EverydayCard().padding(.horizontal, 24).padding(.top, 22)
                }
                let next: [Chapter] = ChaptersHome.upcoming(items, today)
                if !next.isEmpty {
                    Hairline().padding(.top, 28)
                    ComingUpList(items: next, today: today) { c in store.push(.chapter(c.id)) }
                        .padding(.horizontal, 24).padding(.top, 26)
                }
                Button { showWelcome = true } label: {
                    Text("How chapters work").font(.subheadline.weight(.semibold)).underline()
                        .foregroundStyle(Color.primary)
                }
                .buttonStyle(.press)
                .padding(.horizontal, 24).padding(.top, 28)
                if showSamples {
                    Text("Chapters marked Sample are made up, to show how it reads. Yours come from your own trips and events; hide the samples from the ••• menu.")
                        .font(.footnote).foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                        .padding(.horizontal, 24).padding(.top, 8)
                }
                Color.clear.frame(height: 36)
            }
        }
        .scrollIndicators(.hidden)
        .background(Color(uiColor: .systemBackground))
        // starting another is always a thumb away, over the tab bar
        .safeAreaInset(edge: .bottom, spacing: 0) {
            StartChapterBar { showNew = true }
        }
        .navigationTitle("All chapters")
        .toolbarTitleDisplayMode(.large)
        .toolbar {
            ToolbarItemGroup(placement: .topBarTrailing) {
                Menu {
                    Toggle(isOn: Binding(get: { samples }, set: { v in withAnimation(Motion.open) { samples = v } })) {
                        Label("Sample chapters", systemImage: "theatermasks")
                    }
                    Button { showDemo = true } label: { Label("See a demo", systemImage: "play.rectangle") }
                    Button { showWelcome = true } label: { Label("How chapters work", systemImage: "questionmark.circle") }
                } label: {
                    Image(systemName: "ellipsis")
                }
                .accessibilityLabel("More")
                Button { showNew = true } label: { Image(systemName: "plus") }
                    .accessibilityLabel("Start a chapter")
            }
        }
        .modifier(TripDraftPresenter(draft: $draftOpen))
        .modifier(ChapterFlows(showNew: $showNew, showWelcome: $showWelcome, showDemo: $showDemo))
    }
}

struct Hairline: View {
    var body: some View {
        Rectangle().fill(Color.primary.opacity(0.09)).frame(height: 0.5).padding(.horizontal, 24)
    }
}

/// the month at the middle of the timeline, rolling as you scroll, and what's in it
struct MonthHeader: View {
    let month: String
    let today: String
    let back: Bool
    let inView: String
    let goToday: () -> Void
    var body: some View {
        let away: Bool = month != String(today.prefix(7))
        HStack(alignment: .bottom, spacing: 12) {
            VStack(alignment: .leading, spacing: 3) {
                Text(Day.fmt(month + "-01", "MMMM yyyy"))
                    .font(.system(.title2, design: .serif, weight: .semibold))
                    .contentTransition(.numericText(countsDown: back))
                Text(inView)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
                    .contentTransition(.opacity)
            }
            Spacer(minLength: 8)
            if away {
                Button(action: goToday) {
                    Label("Today", systemImage: "arrow.uturn.backward")
                        .font(.system(.footnote, weight: .semibold))
                        .foregroundStyle(Color.primary)
                        .padding(.horizontal, 12).frame(minHeight: 32)
                }
                .buttonStyle(.glass)
                .transition(.scale(scale: 0.6).combined(with: .opacity))
            }
        }
        .animation(Motion.open, value: month)
    }
}

// MARK: the timeline

struct ThreadMonth: Identifiable {
    let m: String
    let x: CGFloat
    let w: CGFloat
    let days: Int
    var id: String { m }
}
struct ThreadCard: Identifiable {
    let c: Chapter
    let x: CGFloat
    let pinX: CGFloat
    let attach: CGFloat
    let n: Int
    var id: String { c.id }
}
struct ThreadSpan: Identifiable {
    let c: Chapter
    let x0: CGFloat
    let x1: CGFloat
    let lane: Int
    /// where what was paid ahead began, left of its days
    var lead: CGFloat? = nil
    var id: String { c.id }
}

/// where everything sits: months as wide as the chapters that start in them, each card under its own day
struct ThreadLayout {
    var months: [ThreadMonth] = []
    var index: [String: Int] = [:]
    var cards: [ThreadCard] = []
    var spans: [ThreadSpan] = []
    var lanes: Int = 1
    var width: CGFloat = 0
    var todayX: CGFloat = 0
    var endX: CGFloat = 0

    static let card: CGFloat = 172
    static let gap: CGFloat = 14
    static let empty: CGFloat = 56
    static let pad: CGFloat = 14
    static let edge: CGFloat = 20
    static let baseY: CGFloat = 32
    static let laneGap: CGFloat = 8
    static let cardH: CGFloat = 262

    var laneY0: CGFloat { Self.baseY + 10 }
    var cardTop: CGFloat { laneY0 + CGFloat(lanes) * Self.laneGap + 24 }
    var height: CGFloat { cardTop + Self.cardH + 12 }

    func x(_ d: String, _ part: Double) -> CGFloat {
        let m: String = String(d.prefix(7))
        guard let i = index[m] else {
            if let first = months.first, m < first.m { return first.x }
            if let last = months.last { return last.x + last.w }
            return 0
        }
        let mo: ThreadMonth = months[i]
        let day: Double = Double(Day.dayNumber(d))
        return mo.x + CGFloat((day - 1 + part) / Double(mo.days)) * mo.w
    }

    func month(at x: CGFloat) -> String {
        var out: String = months.first?.m ?? ""
        for mo in months where x >= mo.x { out = mo.m }
        return out
    }

    static func make(_ items: [Chapter], today: String) -> ThreadLayout {
        var L = ThreadLayout()
        let sorted: [Chapter] = items.sorted { $0.pin < $1.pin }
        var lo: String = String(today.prefix(7))
        var hi: String = lo
        for c in sorted {
            lo = min(lo, String(c.from.prefix(7)), String(c.pin.prefix(7)))
            if !c.lead.isEmpty { lo = min(lo, String(c.lead.prefix(7))) }
            hi = max(hi, String(c.to.prefix(7)), String(c.pin.prefix(7)))
        }
        let start: String = Day.addMonths(lo, -1)
        let end: String = Day.addMonths(hi, 1)
        var byMonth: [String: [Chapter]] = [:]
        for c in sorted { byMonth[String(c.pin.prefix(7)), default: []].append(c) }

        var x: CGFloat = edge
        var m: String = start
        var guardN: Int = 0
        while m <= end && guardN < 240 {
            let cs: [Chapter] = byMonth[m] ?? []
            let n: CGFloat = CGFloat(cs.count)
            let w: CGFloat = cs.isEmpty ? empty : pad * 2 + n * card + (n - 1) * gap
            L.index[m] = L.months.count
            L.months.append(ThreadMonth(m: m, x: x, w: w, days: Day.dayNumber(Day.monthEnd(m))))
            x += w
            m = Day.addMonths(m, 1)
            guardN += 1
        }
        L.endX = x + 10
        L.width = L.endX + card + edge

        var number: Int = 0
        for mo in L.months {
            let cs: [Chapter] = byMonth[mo.m] ?? []
            for (i, c) in cs.enumerated() {
                number += 1
                let cx: CGFloat = mo.x + pad + CGFloat(i) * (card + gap)
                let pinX: CGFloat = L.x(c.pin, 0.5)
                let attach: CGFloat = min(cx + card - 26, max(cx + 26, pinX))
                L.cards.append(ThreadCard(c: c, x: cx, pinX: pinX, attach: attach, n: number))
            }
        }

        // spans on the ruler; ones that overlap go a lane down
        var ends: [CGFloat] = []
        let bySpan: [Chapter] = items.sorted { $0.from < $1.from }
        for c in bySpan {
            var x0: CGFloat = L.x(c.from, 0)
            var x1: CGFloat = L.x(c.to, 1)
            if x1 - x0 < 10 {
                let mid: CGFloat = (x0 + x1) / 2
                x0 = mid - 5
                x1 = mid + 5
            }
            let leadX: CGFloat? = (!c.lead.isEmpty && c.lead < c.from) ? L.x(c.lead, 0) : nil
            let begin: CGFloat = leadX ?? x0
            var lane: Int = -1
            for (i, e) in ends.enumerated() where e + 6 <= begin {
                lane = i
                break
            }
            if lane < 0 {
                if ends.count < 3 {
                    lane = ends.count
                    ends.append(x1)
                } else {
                    lane = ends.indices.min { ends[$0] < ends[$1] } ?? 0
                    ends[lane] = max(ends[lane], x1)
                }
            } else {
                ends[lane] = x1
            }
            L.spans.append(ThreadSpan(c: c, x0: x0, x1: x1, lane: lane, lead: leadX))
        }
        L.lanes = max(1, ends.count)
        L.todayX = L.x(today, 0.5)
        return L
    }
}

/// a thread from a day on the ruler down to the top of its card
struct ThreadCurve: Shape {
    let a: CGPoint
    let b: CGPoint
    func path(in rect: CGRect) -> Path {
        var p = Path()
        p.move(to: a)
        if abs(a.x - b.x) < 1 {
            p.addLine(to: b)
        } else {
            let mid: CGFloat = (a.y + b.y) / 2
            p.addCurve(to: b, control1: CGPoint(x: a.x, y: mid + 4), control2: CGPoint(x: b.x, y: mid - 4))
        }
        return p
    }
}

struct ChapterThread: View {
    let items: [Chapter]
    let today: String
    let zoom: Namespace.ID?
    @Binding var month: String
    @Binding var back: Bool
    let jump: Int
    let open: (Chapter) -> Void
    let start: () -> Void
    @State private var drawn = false
    @State private var lit: String? = nil
    /// where the timeline is scrolled to, set by offset: Today and a tap on a span move it straight to a point
    @State private var pos = ScrollPosition(edge: .leading)
    @State private var viewW: CGFloat = 393

    /// the offset that puts x at a share of the screen, kept inside the timeline
    static func offset(_ x: CGFloat, at share: CGFloat, viewW: CGFloat, width: CGFloat) -> CGFloat {
        min(max(0, width - viewW), max(0, x - viewW * share))
    }

    var body: some View {
        let L: ThreadLayout = ThreadLayout.make(items, today: today)
        Group {
            ScrollView(.horizontal) {
                ZStack(alignment: .topLeading) {
                    ThreadRuler(L: L, drawn: drawn) { c in
                        if let k = L.cards.first(where: { $0.c.id == c.id }) {
                            let x: CGFloat = Self.offset(k.x + ThreadLayout.card / 2, at: 0.5, viewW: viewW, width: L.width)
                            withAnimation(Motion.reveal) { pos.scrollTo(x: x) }
                        }
                        lit = c.id
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.9) { if lit == c.id { lit = nil } }
                    }
                    ForEach(Array(L.cards.enumerated()), id: \.element.id) { i, k in
                        ThreadCurve(a: CGPoint(x: k.pinX, y: ThreadLayout.baseY), b: CGPoint(x: k.attach, y: L.cardTop))
                            .trim(from: 0, to: drawn ? 1 : 0)
                            .stroke(k.c.inkColor.opacity(0.55), style: StrokeStyle(lineWidth: 1.2, lineCap: .round))
                            .frame(width: L.width, height: L.height)
                            .animation(Motion.reveal.delay(Motion.stagger(i, after: 0.15)), value: drawn)
                            .allowsHitTesting(false)
                        Circle().fill(k.c.inkColor)
                            .frame(width: 9, height: 9)
                            .overlay(Circle().stroke(Color(uiColor: .systemBackground), lineWidth: 2.5))
                            .position(x: k.pinX, y: ThreadLayout.baseY)
                            .scaleEffect(drawn ? 1 : 0.2)
                            .animation(Motion.reveal.delay(Motion.stagger(i, after: 0.1)), value: drawn)
                    }
                    TodayLine(L: L)
                    ForEach(Array(L.cards.enumerated()), id: \.element.id) { i, k in
                        ChapterCard(c: k.c, n: k.n, zoom: zoom, today: today, lit: lit == k.c.id) { open(k.c) }
                            .frame(width: ThreadLayout.card, height: ThreadLayout.cardH, alignment: .top)
                            .opacity(drawn ? 1 : 0)
                            .offset(y: drawn ? 0 : 16)
                            .animation(Motion.reveal.delay(Motion.stagger(i, after: 0.2)), value: drawn)
                            .id(k.c.id)
                            .position(x: k.x + ThreadLayout.card / 2, y: L.cardTop + ThreadLayout.cardH / 2)
                    }
                    NextChapterCard(action: start)
                        .position(x: L.endX + ThreadLayout.card / 2, y: L.cardTop + ThreadLayout.card / 2)
                }
                .frame(width: L.width, height: L.height, alignment: .topLeading)
            }
            .scrollIndicators(.hidden)
            .scrollPosition($pos)
            .onScrollGeometryChange(for: CGFloat.self) { g in
                g.containerSize.width
            } action: { _, w in
                if w > 0 { viewW = w }
            }
            .onScrollGeometryChange(for: CGFloat.self) { g in
                g.contentOffset.x + g.containerSize.width * 0.42
            } action: { _, x in
                let m: String = L.month(at: x)
                if !m.isEmpty && m != month {
                    back = !month.isEmpty && m < month
                    month = m
                }
            }
            .onAppear {
                pos.scrollTo(x: Self.offset(L.todayX, at: 0.42, viewW: viewW, width: L.width))
                if !drawn { drawn = true }
            }
            .onChange(of: jump) { _, _ in
                withAnimation(Motion.reveal) {
                    pos.scrollTo(x: Self.offset(L.todayX, at: 0.42, viewW: viewW, width: L.width))
                }
            }
            .sensoryFeedback(.selection, trigger: month)
        }
    }
}

/// the months, the ruler, and each chapter's days lying on it
struct ThreadRuler: View {
    let L: ThreadLayout
    let drawn: Bool
    let find: (Chapter) -> Void
    var body: some View {
        let first: String = L.months.first?.m ?? ""
        ZStack(alignment: .topLeading) {
            Rectangle().fill(Color.primary.opacity(0.16))
                .frame(width: max(0, L.endX - ThreadLayout.edge), height: 1)
                .offset(x: ThreadLayout.edge, y: ThreadLayout.baseY)
            ForEach(L.months) { mo in
                let jan: Bool = mo.m.hasSuffix("-01") || mo.m == first
                Rectangle().fill(Color.primary.opacity(jan ? 0.4 : 0.2))
                    .frame(width: 1, height: jan ? 12 : 8)
                    .offset(x: mo.x, y: ThreadLayout.baseY - (jan ? 6 : 4))
                Text(jan ? Day.fmt(mo.m + "-01", "MMM yyyy") : Day.monthShort(mo.m))
                    .font(.system(.caption, weight: jan ? .bold : .medium))
                    .foregroundStyle(jan ? Color.primary : Color.secondary)
                    .fixedSize()
                    .offset(x: mo.x + 6, y: ThreadLayout.baseY - 24)
            }
            ForEach(Array(L.spans.enumerated()), id: \.element.id) { i, s in
                if let lx = s.lead {
                    LeadLine(c: s.c, width: s.x0 - lx)
                        .opacity(drawn ? 1 : 0)
                        .animation(Motion.reveal.delay(Motion.stagger(i, after: 0.5)), value: drawn)
                        .offset(x: lx, y: L.laneY0 + CGFloat(s.lane) * ThreadLayout.laneGap - 6)
                        .onTapGesture { find(s.c) }
                }
                SpanBar(c: s.c, width: s.x1 - s.x0)
                    .scaleEffect(x: drawn ? 1 : 0.02, y: 1, anchor: .leading)
                    .animation(Motion.reveal.delay(Motion.stagger(i, after: 0.05)), value: drawn)
                    .offset(x: s.x0, y: L.laneY0 + CGFloat(s.lane) * ThreadLayout.laneGap - 6)
                    .onTapGesture { find(s.c) }
            }
        }
        .frame(width: L.width, height: L.height, alignment: .topLeading)
    }
}

/// a chapter's days on the ruler: a short bar in its ink, dashed while it's only a draft
struct SpanBar: View {
    let c: Chapter
    let width: CGFloat
    var body: some View {
        ZStack {
            if c.draft {
                Capsule().strokeBorder(c.inkColor.opacity(0.8), style: StrokeStyle(lineWidth: 1.2, dash: [3, 2]))
                    .frame(width: max(10, width), height: 5)
            } else {
                Capsule().fill(c.inkColor.opacity(c.sample ? 0.75 : 1))
                    .frame(width: max(10, width), height: 4)
            }
        }
        .frame(width: max(10, width), height: 16)
        .contentShape(Rectangle())
        .accessibilityLabel(c.title + ", " + c.dates)
        .accessibilityAddTraits(.isButton)
    }
}

/// what was paid ahead of a chapter's days: a dotted run from the first such payment up to its days
struct LeadLine: View {
    let c: Chapter
    let width: CGFloat
    var body: some View {
        ZStack(alignment: .leading) {
            Path { p in
                p.move(to: CGPoint(x: 4, y: 8))
                p.addLine(to: CGPoint(x: max(4, width - 2), y: 8))
            }
            .stroke(c.inkColor.opacity(0.35), style: StrokeStyle(lineWidth: 1.2, lineCap: .round, dash: [0.1, 5]))
            Circle().fill(c.inkColor.opacity(0.45)).frame(width: 4, height: 4).padding(.leading, 2)
        }
        .frame(width: max(8, width), height: 16, alignment: .leading)
        .contentShape(Rectangle())
        .accessibilityLabel(c.title + ", paid ahead from " + Day.fmt(c.lead, "d MMM"))
    }
}

/// how to read the ruler, once, under it
struct ThreadKey: View {
    var body: some View {
        HStack(spacing: 14) {
            HStack(spacing: 6) {
                Capsule().fill(Color.secondary).frame(width: 16, height: 4)
                Text("its days")
            }
            HStack(spacing: 6) {
                Path { p in p.move(to: CGPoint(x: 1, y: 2)); p.addLine(to: CGPoint(x: 17, y: 2)) }
                    .stroke(Color.secondary, style: StrokeStyle(lineWidth: 1.4, lineCap: .round, dash: [0.1, 4]))
                    .frame(width: 18, height: 4)
                Text("paid ahead")
            }
            Text("Each hangs from its first day")
                .lineLimit(1)
                .minimumScaleFactor(0.8)
        }
        .font(.caption)
        .foregroundStyle(.secondary)
    }
}

/// today: a small bead on the ruler itself, nothing running down through the cards
struct TodayLine: View {
    let L: ThreadLayout
    @State private var glow = false
    var body: some View {
        ZStack(alignment: .topLeading) {
            Text("Today")
                .font(.system(.caption2, weight: .bold))
                .foregroundStyle(Color.onKosh)
                .padding(.horizontal, 8)
                .frame(minHeight: 19)
                .background(Color.koshFill, in: Capsule())
                .overlay(Capsule().stroke(Color(uiColor: .systemBackground), lineWidth: 2))
                .shadow(color: Color.kosh.opacity(glow ? 0.45 : 0.12), radius: glow ? 6 : 2)
                .fixedSize()
                .position(x: L.todayX, y: ThreadLayout.baseY)
        }
        .frame(width: L.width, height: L.height, alignment: .topLeading)
        .allowsHitTesting(false)
        .onAppear { withAnimation(.easeInOut(duration: 1.6).repeatForever(autoreverses: true)) { glow = true } }
        .accessibilityHidden(true)
    }
}

/// a bookmark ribbon, the mark of a chapter
struct Ribbon: Shape {
    func path(in r: CGRect) -> Path {
        var p = Path()
        p.move(to: CGPoint(x: r.minX, y: r.minY))
        p.addLine(to: CGPoint(x: r.maxX, y: r.minY))
        p.addLine(to: CGPoint(x: r.maxX, y: r.maxY))
        p.addLine(to: CGPoint(x: r.midX, y: r.maxY - r.width * 0.45))
        p.addLine(to: CGPoint(x: r.minX, y: r.maxY))
        p.closeSubpath()
        return p
    }
}

/// a chapter on the timeline: its stamp on its wash, its number, name, when, and what it cost
struct ChapterCard: View {
    let c: Chapter
    let n: Int
    let zoom: Namespace.ID?
    let today: String
    let lit: Bool
    let open: () -> Void
    @Environment(\.colorScheme) private var scheme

    var body: some View {
        let ink: Color = c.inkColor.ink(scheme)
        let badge: String = Self.badge(c, today)
        Button(action: open) {
            VStack(alignment: .leading, spacing: 0) {
                ZStack(alignment: .topLeading) {
                    RoundedRectangle(cornerRadius: 22, style: .continuous).fill(c.wash(scheme))
                    if c.draft {
                        RoundedRectangle(cornerRadius: 22, style: .continuous)
                            .strokeBorder(ink.opacity(0.5), style: StrokeStyle(lineWidth: 1.5, dash: [6, 5]))
                    }
                    StampView(art: c.art, size: 120, rotation: c.rot, dashed: c.draft)
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                    Ribbon().fill(ink.opacity(c.draft ? 0.35 : 0.9))
                        .frame(width: 13, height: 30)
                        .frame(maxWidth: .infinity, alignment: .trailing)
                        .padding(.trailing, 18)
                    if !badge.isEmpty {
                        Text(badge)
                            .font(.system(.caption2, weight: .semibold))
                            .foregroundStyle(Color.primary)
                            .padding(.horizontal, 9).padding(.vertical, 5)
                            .background(.regularMaterial, in: Capsule())
                            .padding(10)
                            .frame(maxHeight: .infinity, alignment: .bottomLeading)
                    }
                }
                .frame(width: ThreadLayout.card, height: ThreadLayout.card)
                .modifier(ZoomSource(id: c.id, ns: zoom))
                Text("CHAPTER \(String(format: "%02d", n))\(c.sample ? " · SAMPLE" : "")")
                    .font(.system(.caption2, weight: .semibold))
                    .tracking(1.1)
                    .foregroundStyle(ink.opacity(0.9))
                    .padding(.top, 11)
                Text(c.title)
                    .font(.system(.callout, design: .serif, weight: .semibold))
                    .foregroundStyle(Color.primary)
                    .lineLimit(1)
                    .padding(.top, 3)
                Text(c.dates).font(.system(.footnote)).foregroundStyle(.secondary).lineLimit(1).padding(.top, 1)
                HStack(spacing: 0) {
                    Text(Fmt.rupees(c.amount)).font(.system(.footnote, weight: .bold)).foregroundStyle(Color.primary)
                    Text(" · " + c.extra).font(.system(.footnote)).foregroundStyle(.secondary)
                }
                .lineLimit(1)
                .padding(.top, 3)
                .privacySensitive()
            }
            .frame(width: ThreadLayout.card, alignment: .leading)
        }
        .buttonStyle(PulsePress())
        .scaleEffect(lit ? 1.05 : 1)
        .animation(Motion.open, value: lit)
        .scrollTransition(.interactive, axis: .horizontal) { content, phase in
            content
                .scaleEffect(phase.isIdentity ? 1 : 0.95)
                .opacity(phase.isIdentity ? 1 : 0.75)
        }
        .spokenFigures(c.title + ", " + c.dates + ", " + Fmt.rupees(c.amount), hidden: c.title + ", " + c.dates)
    }

    /// what's worth a word on the card: coming up soon, a draft, the badge it has
    static func badge(_ c: Chapter, _ today: String) -> String {
        if c.draft { return c.badge.isEmpty ? "Draft" : c.badge }
        if c.from > today {
            let n: Int = Day.between(today, c.from)
            return n == 1 ? "Tomorrow" : "In " + String(n) + " days"
        }
        return c.badge
    }
}

/// the end of the line: the next chapter, still to be written
struct NextChapterCard: View {
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            VStack(spacing: 10) {
                Image(systemName: "plus")
                    .font(.system(size: 20, weight: .semibold))
                    .frame(width: 48, height: 48)
                    .background(Color(uiColor: .tertiarySystemFill), in: Circle())
                Text("Next chapter").font(.system(size: 15, weight: .semibold, design: .serif))
                Text("A trip, an event,\na project").font(.caption).foregroundStyle(.secondary).multilineTextAlignment(.center)
            }
            .foregroundStyle(Color.primary)
            .frame(width: ThreadLayout.card, height: ThreadLayout.card)
            .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous).strokeBorder(Color.primary.opacity(0.2), style: StrokeStyle(lineWidth: 1.2, dash: [6, 5])))
            .contentShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
        }
        .buttonStyle(PulsePress())
        .accessibilityLabel("Start a chapter")
    }
}

// MARK: below the timeline

/// what kosh found in the mail, as a draft to make a chapter of
struct MailNotice: View {
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            HStack(alignment: .center, spacing: 16) {
                VStack(alignment: .leading, spacing: 0) {
                    Text("FOUND IN YOUR MAIL · SAMPLE").font(.system(.caption2, weight: .bold)).tracking(0.4).foregroundStyle(Color.kosh)
                    Text("A trip to Bali, 14 – 19 Dec?").font(.system(.body, design: .serif, weight: .semibold)).foregroundStyle(Color.primary).padding(.top, 5)
                    Text("A flight, a stay and travel insurance. ₹1,12,400 paid ahead.")
                        .font(.subheadline).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true).padding(.top, 3)
                    Text("See the draft").font(.subheadline.weight(.semibold)).underline().foregroundStyle(Color.primary).padding(.top, 10)
                }
                Spacer(minLength: 0)
                StampView(key: "bali", size: 86, rotation: 6, dashed: true)
                    .phaseAnimator([false, true]) { content, on in
                        content.scaleEffect(on ? 1.05 : 1).rotationEffect(.degrees(on ? -3 : 0))
                    } animation: { _ in .easeInOut(duration: 1.8) }
            }
            .padding(18)
            .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).strokeBorder(Color.primary.opacity(0.14), lineWidth: 1))
            .contentShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
        }
        .buttonStyle(PulsePress())
    }
}

/// a trip the bookings in the mail make: where and when, what booked it, what kosh would file in it and over which
/// days; one tap makes it a chapter with all of them, a tap on the words looks them over first (ChapterDrafts.swift)
struct TripDraftCard: View {
    @Environment(Store.self) private var store
    let draft: TripDraft
    /// open its sheet, to untick what wasn't part of it
    let look: () -> Void
    let open: (String) -> Void

    static func span(_ d: TripDraft) -> String {
        if d.from == d.to { return Day.fmt(d.from, "d MMM") }
        return d.from.prefix(7) == d.to.prefix(7) ? Day.fmt(d.from, "d") + " – " + Day.fmt(d.to, "d MMM") : Day.fmt(d.from, "d MMM") + " – " + Day.fmt(d.to, "d MMM")
    }
    static func what(_ d: TripDraft) -> String {
        DraftWords.booked(d) + ". " + DraftWords.offered(d)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            Button(action: look) {
                HStack(alignment: .center, spacing: 14) {
                    VStack(alignment: .leading, spacing: 0) {
                        Text("FOUND IN YOUR MAIL").font(.system(.caption2, weight: .bold)).tracking(0.4).foregroundStyle(Color.kosh)
                        Text(draft.name + ", " + Self.span(draft) + "?").font(.system(.body, design: .serif, weight: .semibold))
                            .foregroundStyle(Color.primary).padding(.top, 5)
                        Text(Self.what(draft)).font(.subheadline).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true).padding(.top, 3)
                            .privacySensitive()
                    }
                    Spacer(minLength: 0)
                    Image(systemName: "chevron.right").font(.footnote.weight(.semibold)).foregroundStyle(.tertiary)
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(.press)
            .accessibilityHint("Shows the payments kosh would put in it")
            HStack(spacing: 10) {
                Button {
                    let id: String = store.startDraft(draft)
                    open(id)
                } label: {
                    Text("Make it a chapter").font(.subheadline.weight(.semibold))
                        .padding(.horizontal, 14).padding(.vertical, 8)
                        .background(Color.kosh, in: Capsule())
                        .foregroundStyle(Color.onKosh)
                }
                .buttonStyle(.press)
                Button("Not a trip") { withAnimation(Motion.open) { store.live?.dropTripDraft(draft.id) } }
                    .font(.subheadline).foregroundStyle(.secondary)
            }
            .padding(.top, 12)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(18)
        .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).strokeBorder(Color.primary.opacity(0.14), lineWidth: 1))
    }
}

/// the year's chapters as books on a shelf: one spine each, as thick as what it cost
struct ShelfData {
    var books: [Chapter] = []
    var total: Double = 0
    var share: Int? = nil
    var foot: String = ""
    /// what everything else came to over the same twelve months; 0 when it can't be told
    var everyday: Double = 0

    @MainActor static func make(_ items: [Chapter], today: String, store: Store) -> ShelfData {
        var d = ShelfData()
        let since: String = Day.add(today, -365)
        d.books = items.filter { !$0.draft && $0.amount > 0 && $0.pin <= today && $0.pin >= since }.sorted { $0.pin < $1.pin }
        d.total = d.books.reduce(0) { $0 + $1.amount }
        if d.books.isEmpty { return d }
        let samples: Bool = d.books.allSatisfy { $0.sample }
        let real: Bool = d.books.allSatisfy { !$0.sample }
        if samples {
            // the sample household's ordinary months come to about ₹63,700 each
            d.everyday = 12 * 63700
            d.share = Int(safe: (d.total / (d.total + d.everyday) * 100).rounded())
            d.foot = "Left out, an ordinary month held steady near ₹63,700."
        } else if real {
            let start: String = String(since.prefix(7))
            var all: Double = 0
            for mo in store.snap.months where mo.m >= start {
                all += store.total(of: mo) + (store.everyday ? store.tripShare(mo.m).out : 0)
            }
            if all > 0 {
                d.share = min(100, Int(safe: (d.total / all * 100).rounded()))
                d.everyday = max(0, all - d.total)
            }
        }
        return d
    }
}

/// the year as a book's contents: one ribbon of what it all came to (each chapter in its ink, ordinary life in grey),
/// then each chapter by its number, a dotted leader running to what it cost
struct YearShelf: View {
    let data: ShelfData
    let numbers: [String: Int]
    let open: (Chapter) -> Void
    @State private var sel: String? = nil
    @State private var shown = false

    var body: some View {
        let books: [Chapter] = data.books
        let whole: Double = max(1, data.total + data.everyday)
        VStack(alignment: .leading, spacing: 0) {
            Text("The year in chapters").font(.system(.title2, design: .serif, weight: .semibold))
            HStack(alignment: .firstTextBaseline, spacing: 8) {
                Text(Fmt.words(shown ? data.total : 0))
                    .font(.system(.largeTitle, design: .serif, weight: .bold))
                    .contentTransition(.numericText(value: shown ? data.total : 0))
                    .privacySensitive()
                Text(Self.sub(data)).font(.subheadline).foregroundStyle(.secondary)
            }
            .padding(.top, 4)

            GeometryReader { g in
                let gap: CGFloat = 2
                let parts: Int = books.count + (data.everyday > 0 ? 1 : 0)
                let avail: CGFloat = g.size.width - gap * CGFloat(max(0, parts - 1))
                HStack(spacing: gap) {
                    ForEach(Array(books.enumerated()), id: \.element.id) { i, c in
                        Rectangle()
                            .fill(c.inkColor.opacity(sel == nil || sel == c.id ? 1 : 0.3))
                            .frame(width: shown ? max(2, avail * CGFloat(c.amount / whole)) : 0)
                            .animation(Motion.reveal.delay(Motion.stagger(i)), value: shown)
                            .contentShape(Rectangle())
                            .onTapGesture { withAnimation(Motion.base) { sel = sel == c.id ? nil : c.id } }
                    }
                    if data.everyday > 0 {
                        Rectangle().fill(Color.primary.opacity(0.08))
                            .frame(width: shown ? avail * CGFloat(data.everyday / whole) : 0)
                            .animation(Motion.reveal.delay(Motion.stagger(books.count)), value: shown)
                    }
                }
                .frame(width: g.size.width, alignment: .leading)
            }
            .frame(height: 12)
            .clipShape(Capsule())
            .padding(.top, 16)
            if data.everyday > 0 {
                HStack {
                    Text("Chapters · " + Self.pct(data.total / whole))
                    Spacer()
                    Text("Everyday · " + Self.pct(data.everyday / whole))
                }
                .font(.caption)
                .foregroundStyle(.secondary)
                .padding(.top, 6)
            }

            Eyebrow(text: "Contents").padding(.top, 24)
            VStack(spacing: 0) {
                ForEach(Array(books.enumerated()), id: \.element.id) { i, c in
                    ContentsRow(c: c, n: numbers[c.id] ?? i + 1, share: c.amount / max(1, data.total), on: sel == c.id) { open(c) }
                        .opacity(shown ? 1 : 0)
                        .offset(y: shown ? 0 : 10)
                        .animation(Motion.reveal.delay(Motion.stagger(i, after: 0.2)), value: shown)
                }
            }
            .padding(.top, 6)
            if !data.foot.isEmpty {
                Text(data.foot).font(.footnote).foregroundStyle(.secondary).padding(.top, 10)
            }
        }
        .sensoryFeedback(.selection, trigger: sel)
        .onScrollVisibilityChange(threshold: 0.3) { v in
            if v && !shown { withAnimation(Motion.reveal) { shown = true } }
        }
    }

    static func sub(_ d: ShelfData) -> String {
        let n: String = d.books.count == 1 ? "1 chapter" : String(d.books.count) + " chapters"
        if let s = d.share { return n + " · " + String(s) + "% of all you spent" }
        return n + ", last 12 months"
    }
    static func pct(_ x: Double) -> String {
        let v: Double = x * 100
        if v > 0 && v < 1 { return "<1%" }
        return String(Int(safe: v.rounded())) + "%"
    }
}

/// one line of the contents: its number in its ink, its name, a dotted leader, what it cost
struct ContentsRow: View {
    let c: Chapter
    let n: Int
    let share: Double
    let on: Bool
    let tap: () -> Void
    var body: some View {
        Button(action: tap) {
            HStack(alignment: .firstTextBaseline, spacing: 10) {
                Text(String(format: "%02d", n))
                    .font(.system(.caption, design: .monospaced, weight: .semibold))
                    .foregroundStyle(c.inkColor)
                    .frame(width: 22, alignment: .leading)
                VStack(alignment: .leading, spacing: 1) {
                    Text(c.title).font(.system(.body, design: .serif)).foregroundStyle(Color.primary).lineLimit(1)
                    Text("\(Day.fmt(c.from, "MMM yyyy"))\(c.sample ? " · sample" : "")").font(.caption).foregroundStyle(.secondary)
                }
                .layoutPriority(1)
                Leader()
                    .stroke(Color.secondary.opacity(0.55), style: StrokeStyle(lineWidth: 1.3, lineCap: .round, dash: [0.1, 4.5]))
                    .frame(minWidth: 14)
                    .frame(height: 2)
                VStack(alignment: .trailing, spacing: 1) {
                    Text(Fmt.words(c.amount)).font(.system(.subheadline, weight: .semibold)).foregroundStyle(Color.primary).privacySensitive()
                    Text(YearShelf.pct(share)).font(.caption).foregroundStyle(.secondary)
                }
            }
            .padding(.vertical, 9)
            .padding(.horizontal, 10)
            .background(on ? c.inkColor.opacity(0.09) : Color.clear, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
            .padding(.horizontal, -10)
            .contentShape(Rectangle())
        }
        .buttonStyle(PulsePress())
        .spokenFigures("Chapter " + String(n) + ", " + c.title + ", " + Fmt.rupees(c.amount), hidden: "Chapter " + String(n) + ", " + c.title)
    }
}

/// a dotted leader, as a book's contents run a name to its page
struct Leader: Shape {
    func path(in r: CGRect) -> Path {
        var p = Path()
        p.move(to: CGPoint(x: r.minX + 2, y: r.midY))
        p.addLine(to: CGPoint(x: r.maxX - 2, y: r.midY))
        return p
    }
}

/// whether chapters count in each month's spending
struct EverydayCard: View {
    @Environment(Store.self) private var store
    var body: some View {
        Toggle(isOn: Binding(get: { !store.everyday }, set: { v in withAnimation(Motion.open) { store.setEveryday(!v) } })) {
            VStack(alignment: .leading, spacing: 3) {
                Text("Count chapters in monthly spending").font(.subheadline.weight(.semibold))
                Text(store.everyday ? "Left out: months, charts and the forecast show ordinary life; each month says what it left out." : "Chapters count in each month like any spending. Turn off to see months without them.")
                    .font(.caption).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            }
        }
        .padding(16)
        .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).strokeBorder(Color.primary.opacity(0.06), lineWidth: 0.5))
    }
}

struct ComingUpList: View {
    let items: [Chapter]
    let today: String
    let open: (Chapter) -> Void
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            Text("Now and next").font(.system(.title2, design: .serif, weight: .semibold))
            VStack(spacing: 14) {
                ForEach(items) { c in
                    Button { open(c) } label: {
                        HStack(spacing: 16) {
                            KindTile(kind: c.draft ? "mail" : c.kind, size: 56)
                            VStack(alignment: .leading, spacing: 2) {
                                Text(c.title).font(.system(.callout, weight: .semibold)).foregroundStyle(Color.primary)
                                Text(Self.when(c, today)).font(.subheadline).foregroundStyle(.secondary).lineLimit(1)
                            }
                            Spacer(minLength: 8)
                            VStack(alignment: .trailing, spacing: 1) {
                                Text(Fmt.rupees(c.amount)).font(.subheadline.weight(.semibold)).foregroundStyle(Color.primary).privacySensitive()
                                Text(c.draft ? "paid ahead" : c.from > today ? (c.extra == "budget" ? "budget" : "so far") : "so far")
                                    .font(.caption).foregroundStyle(.secondary)
                            }
                        }
                        .contentShape(Rectangle())
                    }
                    .buttonStyle(PulsePress())
                }
            }
            .padding(.top, 16)
        }
    }
    static func when(_ c: Chapter, _ today: String) -> String {
        if c.from <= today { return c.dates + " · under way" }
        let n: Int = Day.between(today, c.from)
        return c.dates + " · " + (n == 1 ? "tomorrow" : "in " + String(n) + " days")
    }
}

/// no chapters yet, and the samples hidden
struct EmptyChapters: View {
    let start: () -> Void
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack(spacing: -10) {
                KindTile(kind: "intl", size: 64).rotationEffect(.degrees(-6))
                KindTile(kind: "wedding", size: 64).rotationEffect(.degrees(4)).offset(y: -6)
                KindTile(kind: "festival", size: 64).rotationEffect(.degrees(-3))
            }
            .padding(.top, 10)
            Text("Your first chapter").font(.system(.title, design: .serif, weight: .semibold)).padding(.top, 22)
            Text("A trip, a wedding, a move, a festival. What it cost goes in one place, on top of each payment's category, and your ordinary months stay clean.")
                .font(.subheadline).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true).padding(.top, 6)
            Button(action: start) {
                Text("Start a chapter").font(.system(.callout, weight: .semibold)).foregroundStyle(.white)
                    .frame(maxWidth: .infinity).frame(minHeight: 52)
                    .background(GradientFill())
            }
            .buttonStyle(PulsePress())
            .padding(.top, 20)
        }
    }
}

// MARK: starting a chapter

struct NewChapterSheet: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    @State private var picked: String
    @State private var query: String = ""
    @State private var started = false
    @State private var editing = false
    @State private var saved = false

    /// the kind picked when it opens (an idea from Chapters picks its own)
    init(initial: String = "intl") { _picked = State(initialValue: initial) }

    var body: some View {
        let q: String = query.trimmingCharacters(in: .whitespaces).lowercased()
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 0) {
                    HStack(spacing: 12) {
                        Image(systemName: "magnifyingglass").font(.system(.callout, weight: .semibold))
                        TextField("Wedding, Goa, the kitchen…", text: $query)
                            .font(.system(.subheadline, weight: .semibold))
                            .textInputAutocapitalization(.never)
                    }
                    .padding(.horizontal, 20)
                    .frame(minHeight: 54)
                    .background(Color(uiColor: .secondarySystemGroupedBackground), in: Capsule())
                    .shadow(color: Color.black.opacity(0.08), radius: 8, y: 3)
                    .overlay(Capsule().strokeBorder(Color.primary.opacity(0.08), lineWidth: 0.5))
                    .padding(.top, 6)

                    ForEach(ChapterSamples.kinds, id: \.0) { group in
                        let kinds: [(String, String)] = group.2.filter { q.isEmpty || $0.1.lowercased().contains(q) }
                        if !kinds.isEmpty {
                            KindGroup(fam: group.0, sub: group.1, kinds: kinds, picked: $picked)
                                .transition(.opacity.combined(with: .move(edge: .top)))
                        }
                    }

                    Text("Something else").font(.system(.title2, weight: .semibold)).tracking(-0.4).padding(.top, 34)
                    OwnChapterButton(on: picked == "own") {
                        withAnimation(Motion.open) { picked = "own" }
                    }
                    .padding(.top, 16)
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 30)
                .animation(Motion.base, value: q)
            }
            .scrollIndicators(.hidden)
            .safeAreaInset(edge: .bottom) {
                Button {
                    if store.live != nil {
                        editing = true
                    } else {
                        started.toggle()
                        dismiss()
                    }
                } label: {
                    Text("Continue with " + Self.label(picked).lowercased())
                        .font(.system(.callout, weight: .semibold))
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity)
                        .frame(minHeight: 52)
                        .background(GradientFill())
                        .contentTransition(.opacity)
                }
                .buttonStyle(PulsePress())
                .padding(.horizontal, 24)
                .padding(.vertical, 12)
                .background(.bar)
                .animation(Motion.base, value: picked)
            }
            .navigationTitle("New chapter")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button { dismiss() } label: { Image(systemName: "xmark") }
                        .accessibilityLabel("Close")
                }
            }
            .sensoryFeedback(.selection, trigger: picked)
            .sensoryFeedback(.success, trigger: started)
            .sheet(isPresented: $editing, onDismiss: { if saved { dismiss() } }) {
                TripEditor(editing: nil, preset: ChapterKinds.preset(picked), onSaved: { _ in saved = true })
            }
        }
    }

    static func label(_ key: String) -> String {
        if key == "own" { return "a chapter of your own" }
        for g in ChapterSamples.kinds {
            if let k = g.2.first(where: { $0.0 == key }) { return k.1 }
        }
        return "a chapter"
    }
}

struct KindGroup: View {
    let fam: ChapterFam
    let sub: String
    let kinds: [(String, String)]
    @Binding var picked: String
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack(spacing: 10) {
                FamIcon(fam: fam, size: 26)
                Text(fam.title).font(.system(.title2, weight: .semibold)).tracking(-0.4)
            }
            .padding(.top, 34)
            Text(sub).font(.subheadline).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true).padding(.top, 4)
            LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 8), count: 4), alignment: .center, spacing: 20) {
                ForEach(kinds, id: \.0) { k in
                    KindPick(kind: k.0, label: k.1, on: picked == k.0) {
                        withAnimation(Motion.open) { picked = k.0 }
                    }
                }
            }
            .padding(.top, 18)
        }
    }
}

struct KindPick: View {
    let kind: String
    let label: String
    let on: Bool
    let tap: () -> Void
    var body: some View {
        Button(action: tap) {
            VStack(spacing: 10) {
                KindTile(kind: kind, size: 64)
                    .padding(4)
                    .overlay(
                        RoundedRectangle(cornerRadius: 22, style: .continuous)
                            .strokeBorder(Color.primary, lineWidth: 2)
                            .opacity(on ? 1 : 0)
                            .scaleEffect(on ? 1 : 0.88)
                    )
                    .scaleEffect(on ? 1.04 : 1)
                // a long name goes on two lines at a word, never mid-word: it shrinks a little instead
                Text(Self.lines(label))
                    .font(.system(.footnote, weight: on ? .semibold : .regular))
                    .foregroundStyle(Color.primary)
                    .multilineTextAlignment(.center)
                    .lineLimit(Self.lines(label).contains("\n") ? 2 : 1)
                    .minimumScaleFactor(0.7)
                    .allowsTightening(true)
                    .frame(minHeight: 34, alignment: .top)
            }
            .frame(maxWidth: .infinity)
            .contentShape(Rectangle())
        }
        .buttonStyle(.press)
        .accessibilityLabel(label)
        .accessibilityAddTraits(on ? .isSelected : [])
    }

    /// "International trip" → "International" over "trip"; short names stay on one line
    static func lines(_ s: String) -> String {
        let words: [String] = s.split(separator: " ").map(String.init)
        if words.count < 2 || s.count <= 10 { return s }
        return words.dropLast().joined(separator: " ") + "\n" + (words.last ?? "")
    }
}

struct OwnChapterButton: View {
    let on: Bool
    let tap: () -> Void
    var body: some View {
        Button(action: tap) {
            HStack(spacing: 16) {
                KindTile(kind: "own", size: 56)
                VStack(alignment: .leading, spacing: 3) {
                    Text("A chapter of your own").font(.system(.callout, weight: .semibold)).foregroundStyle(Color.primary)
                    Text("Marathon season, a sabbatical, a clinic: name it and kosh keeps the rest.")
                        .font(.subheadline).foregroundStyle(.secondary).multilineTextAlignment(.leading)
                        .fixedSize(horizontal: false, vertical: true)
                }
                Spacer(minLength: 0)
            }
            .padding(14)
            .overlay(
                RoundedRectangle(cornerRadius: 20, style: .continuous)
                    .strokeBorder(on ? Color.primary : Color.primary.opacity(0.14), lineWidth: on ? 2 : 1)
            )
            .contentShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
        }
        .buttonStyle(PulsePress())
    }
}

// MARK: the first visit

struct ChaptersWelcome: View {
    let start: () -> Void
    let done: () -> Void
    @State private var shown = false

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 0) {
                ZStack(alignment: .topLeading) {
                    RoundedRectangle(cornerRadius: 28, style: .continuous)
                        .fill(RadialGradient(colors: [Color(uiColor: .secondarySystemGroupedBackground), Color(uiColor: .tertiarySystemFill)], center: .top, startRadius: 10, endRadius: 320))
                    GeometryReader { g in
                        let w: CGFloat = g.size.width
                        LandingStamp(key: "kyoto", size: 118, rotation: -10, delay: 0.15).position(x: w * 0.2, y: 92)
                        LandingStamp(key: "wedding", size: 130, rotation: 4, delay: 0.35).position(x: w * 0.5, y: 150)
                        LandingStamp(key: "diwali25", size: 100, rotation: 9, delay: 0.55).position(x: w * 0.8, y: 78)
                        LandingStamp(key: "spiti", size: 96, rotation: -6, delay: 0.75).position(x: w * 0.82, y: 190)
                    }
                }
                .frame(height: 250)
                .padding(.top, 20)

                Text("Every big moment gets its own chapter")
                    .font(.system(.title, design: .serif, weight: .semibold))
                    .padding(.top, 28)
                Text("A trip, a wedding, a move, a festival. kosh puts what each one cost in one place, booked ahead and spent there, and keeps your ordinary months clean.")
                    .font(.system(.callout)).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                    .padding(.top, 10)

                Hairline().padding(.horizontal, -24).padding(.top, 28)
                VStack(alignment: .leading, spacing: 22) {
                    WelcomeRow(kind: "mail", title: "Spotted in your mail", sub: "Flights and stays booked weeks ahead become a draft, dates filled in.", i: 0, shown: shown)
                    WelcomeRow(kind: "vehicle", title: "Categories stay honest", sub: "Fuel on a holiday stays Fuel. It's also the chapter's.", i: 1, shown: shown)
                    WelcomeRow(kind: "home", title: "Everyday months stay clean", sub: "One switch takes chapters out of your monthly figures and forecast.", i: 2, shown: shown)
                    WelcomeRow(kind: "doc", title: "In Transactions too", sub: "Each payment shows its chapter; open a chapter's payments there in one tap.", i: 3, shown: shown)
                    WelcomeRow(kind: "party", title: "Bring your people", sub: "A group pass. Each person's kosh adds their own share; settle up at the end.", i: 4, shown: shown)
                }
                .padding(.top, 26)

                Hairline().padding(.horizontal, -24).padding(.top, 28)
                Text("Kinds of chapters").font(.system(.callout, weight: .semibold)).padding(.top, 24)
                HStack {
                    ForEach([ChapterFam.journey, .life, .occasion, .project]) { f in
                        VStack(spacing: 8) {
                            FamIcon(fam: f, size: 40)
                            Text(f.title).font(.system(.caption, weight: .semibold))
                        }
                        .frame(maxWidth: .infinity)
                    }
                }
                .padding(.top, 16)

                Button(action: start) {
                    Text("Start your first chapter").font(.system(.callout, weight: .semibold)).foregroundStyle(.white)
                        .frame(maxWidth: .infinity).frame(minHeight: 52)
                        .background(GradientFill())
                }
                .buttonStyle(PulsePress())
                .padding(.top, 30)
                Button(action: done) {
                    Text("See the sample chapters").font(.system(.subheadline, weight: .semibold)).underline().foregroundStyle(Color.primary)
                        .frame(maxWidth: .infinity).frame(minHeight: 44)
                }
                .buttonStyle(.press)
                .padding(.top, 8)
            }
            .padding(.horizontal, 24)
            .padding(.bottom, 30)
        }
        .scrollIndicators(.hidden)
        .onAppear { shown = true }
    }
}

struct WelcomeRow: View {
    let kind: String
    let title: String
    let sub: String
    let i: Int
    let shown: Bool
    var body: some View {
        HStack(spacing: 18) {
            KindTile(kind: kind, size: 56)
            VStack(alignment: .leading, spacing: 3) {
                Text(title).font(.system(.callout, weight: .semibold))
                Text(sub).font(.subheadline).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            }
        }
        .opacity(shown ? 1 : 0)
        .offset(x: shown ? 0 : 24)
        .animation(Motion.reveal.delay(Motion.stagger(i, after: 0.5)), value: shown)
    }
}
