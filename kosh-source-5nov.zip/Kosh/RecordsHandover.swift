import Foundation

/// How the records are handed to the engine's buildJSON: screen-free, so engine-test/handover.js compiles it with
/// swiftc and proves the screens come out byte for byte the same.
///
/// Two memory savings, neither changing a figure (NEXT.md §9 item 6):
/// - **a name for the records.** buildJSON keeps no copy of the records' text between builds when the caller names
///   them, and compares the name (with the text's length) instead. A name must never be given to two different lists
///   of records in one run of the app, or the screens built from the records alone (the journey) would be stale. So
///   the name joins a number no other LiveSession in this run ever had (`serial`) to the session's own records
///   version, which counts up on every change to `records`. `recordsVersion` alone is not enough: a fresh LiveSession
///   (sign-out and in) starts it at 0 again, for other records.
/// - **the text in plain ASCII.** Each character beyond ASCII is written as JSON's `\uXXXX` (UTF-16 units, so a pair
///   for an emoji), which JSON reads back as the same character. The engine then holds the text at one byte a
///   character instead of two ('₹' is in most readings): at 100,000 readings, 150 MB less.
enum RecordsHandover {
    private static let lock = NSLock()
    private static var last: UInt64 = 0

    /// a number never handed out twice in one run of the app
    static func serial() -> UInt64 {
        lock.lock(); defer { lock.unlock() }
        last &+= 1
        return last
    }

    /// the name of a session's records at a version: never the same for two different lists in one run
    static func name(serial: UInt64, version: Int) -> String {
        "r" + String(serial) + "." + String(version)
    }

    private static let hex: [UInt8] = Array("0123456789abcdef".utf8)

    /// JSON text with every character beyond ASCII written as `\uXXXX`. Valid on any JSON text: such a character can
    /// only stand inside a string, never as part of an escape. (Walks the UTF-8 bytes: a native Swift string's UTF-16
    /// view is several times slower.)
    static func ascii(_ json: String) -> String {
        if json.utf8.allSatisfy({ $0 < 0x80 }) { return json }
        let run: String? = json.utf8.withContiguousStorageIfAvailable { escape($0) }
        return run ?? escape(Array(json.utf8))
    }

    private static func escape<C: RandomAccessCollection>(_ b: C) -> String where C.Element == UInt8, C.Index == Int {
        // (at most six bytes out for each byte in: a two-byte character becomes one \uXXXX, a four-byte one two)
        let out: [UInt8] = [UInt8](unsafeUninitializedCapacity: b.count * 6) { buf, count in
            var o: Int = 0
            func unit(_ u: UInt32) {
                buf[o] = 0x5C; buf[o + 1] = 0x75
                buf[o + 2] = hex[Int((u >> 12) & 0xF)]
                buf[o + 3] = hex[Int((u >> 8) & 0xF)]
                buf[o + 4] = hex[Int((u >> 4) & 0xF)]
                buf[o + 5] = hex[Int(u & 0xF)]
                o += 6
            }
            var i: Int = b.startIndex
            let end: Int = b.endIndex
            while i < end {
                let c: UInt8 = b[i]
                if c < 0x80 { buf[o] = c; o += 1; i += 1; continue }
                // (a Swift string's UTF-8 is always well formed: a lead byte says how many follow)
                var v: UInt32, n: Int
                if c >= 0xF0 { v = UInt32(c & 0x07); n = 3 } else if c >= 0xE0 { v = UInt32(c & 0x0F); n = 2 } else { v = UInt32(c & 0x1F); n = 1 }
                var k: Int = 1
                while k <= n && i + k < end { v = (v << 6) | UInt32(b[i + k] & 0x3F); k += 1 }
                i += n + 1
                if v >= 0x10000 {
                    let w: UInt32 = v - 0x10000
                    unit(0xD800 + (w >> 10)); unit(0xDC00 + (w & 0x3FF))
                } else {
                    unit(v)
                }
            }
            count = o
        }
        return String(decoding: out, as: UTF8.self)
    }
}
