import SwiftUI
import UIKit

// MARK: - How kosh looks: light or dark, its accent, and the colour of Home's net worth line
//
// Kept in the app group's defaults (WFStore.defaults), so the widgets draw in the accent the app is set to.
// Built into the app and the widgets. The app's own Look (Kosh/Appearance.swift) changes these and redraws.

extension UIColor {
    /// "#3B5BFD" as a UIColor, for the app and the widgets alike
    convenience init(koshHex hex: String) {
        var s: String = hex.trimmingCharacters(in: .whitespaces)
        if s.hasPrefix("#") { s.removeFirst() }
        var v: UInt64 = 0
        Scanner(string: s).scanHexInt64(&v)
        self.init(red: CGFloat((v >> 16) & 0xFF) / 255, green: CGFloat((v >> 8) & 0xFF) / 255, blue: CGFloat(v & 0xFF) / 255, alpha: 1)
    }
}

extension Color {
    /// "#3B5BFD" as a colour: the one hex reader for the app and the widgets
    init(hex: String) {
        var s: String = hex.trimmingCharacters(in: .whitespaces)
        if s.hasPrefix("#") { s.removeFirst() }
        var v: UInt64 = 0
        Scanner(string: s).scanHexInt64(&v)
        let r: Double = Double((v >> 16) & 0xFF) / 255
        let g: Double = Double((v >> 8) & 0xFF) / 255
        let b: Double = Double(v & 0xFF) / 255
        self.init(red: r, green: g, blue: b)
    }
    /// one colour by day, another by night
    init(light: String, dark: String) {
        let l: UIColor = UIColor(koshHex: light)
        let d: UIColor = UIColor(koshHex: dark)
        self.init(uiColor: UIColor { (t: UITraitCollection) -> UIColor in t.userInterfaceStyle == .dark ? d : l })
    }
    /// one colour by day, another by night (opacity kept)
    init(light: Color, dark: Color) {
        let l: UIColor = UIColor(light)
        let d: UIColor = UIColor(dark)
        self.init(uiColor: UIColor { (t: UITraitCollection) -> UIColor in t.userInterfaceStyle == .dark ? d : l })
    }
}

/// light, dark, or whatever the phone is
enum KoshScheme: String, CaseIterable, Identifiable {
    case system, light, dark
    var id: String { rawValue }
    var title: String {
        switch self {
        case .system: return "Match system"
        case .light: return "Light"
        case .dark: return "Dark"
        }
    }
    var style: UIUserInterfaceStyle {
        switch self {
        case .system: return .unspecified
        case .light: return .light
        case .dark: return .dark
        }
    }
}

/// the colour of anything you can tap, links, the tab you're on and (unless another is picked) the net worth line.
/// Money keeps its own colours whatever the accent: green up, red down.
enum KoshAccent: String, CaseIterable, Identifiable {
    case kosh, teal, saffron, rose, graphite
    var id: String { rawValue }

    var name: String {
        switch self {
        case .kosh: return "Blue"
        case .teal: return "Teal"
        case .saffron: return "Saffron"
        case .rose: return "Rose"
        case .graphite: return "Graphite"
        }
    }
    var spoken: String { self == .kosh ? "kosh Blue" : name }

    /// words, icons, lines and links (day, night): deep enough for 4.5:1 on white, lifted to glow on black
    var inkHex: (String, String) {
        switch self {
        case .kosh: return ("#3B5BFD", "#6E8BFF")
        case .teal: return ("#08756C", "#5EEAD4")
        case .saffron: return ("#A04A06", "#FFB066")
        case .rose: return ("#C42F67", "#FF85AD")
        case .graphite: return ("#2C2C2E", "#F2F2F7")
        }
    }
    /// the fill under text: buttons, the selected pill, an avatar (day, night)
    var fillHex: (String, String) {
        switch self {
        case .kosh: return ("#3B5BFD", "#3B5BFD")
        case .teal: return ("#08756C", "#0B7A70")
        case .saffron: return ("#B8590A", "#B8590A")
        case .rose: return ("#C42F67", "#C42F67")
        case .graphite: return ("#2C2C2E", "#E5E5EA")
        }
    }
    /// what's written on that fill: white, except on Graphite's light grey by night
    var onFillHex: (String, String) { self == .graphite ? ("#FFFFFF", "#000000") : ("#FFFFFF", "#FFFFFF") }
    /// the line, and the second colour kosh's gradients run into (sky, for blue): (day from, day to, night from, night to)
    var lineHex: (String, String, String, String) {
        switch self {
        case .kosh: return ("#3B5BFD", "#5AC8FA", "#6E8BFF", "#64D2FF")
        case .teal: return ("#0E9F94", "#4FD1C5", "#2DD4BF", "#99F6E4")
        case .saffron: return ("#E8730C", "#F7B32B", "#FF9F43", "#FFD27A")
        case .rose: return ("#E0457B", "#FF8FB1", "#FF6B9A", "#FFB3C9")
        case .graphite: return ("#3A3A3C", "#AEAEB2", "#E5E5EA", "#8E8E93")
        }
    }
    /// the swatch in Settings (day, night)
    var swatchHex: (String, String) {
        switch self {
        case .graphite: return ("#3A3A3C", "#8E8E93")
        default: return (lineHex.0, lineHex.2)
        }
    }

    // made once each: Color.kosh is read everywhere
    static let inks: [KoshAccent: Color] = Dictionary(uniqueKeysWithValues: allCases.map { ($0, Color(light: $0.inkHex.0, dark: $0.inkHex.1)) })
    static let fills: [KoshAccent: Color] = Dictionary(uniqueKeysWithValues: allCases.map { ($0, Color(light: $0.fillHex.0, dark: $0.fillHex.1)) })
    static let onFills: [KoshAccent: Color] = Dictionary(uniqueKeysWithValues: allCases.map { ($0, Color(light: $0.onFillHex.0, dark: $0.onFillHex.1)) })
    static let skies: [KoshAccent: Color] = Dictionary(uniqueKeysWithValues: allCases.map { ($0, Color(light: $0.lineHex.1, dark: $0.lineHex.3)) })
    static let swatches: [KoshAccent: Color] = Dictionary(uniqueKeysWithValues: allCases.map { ($0, Color(light: $0.swatchHex.0, dark: $0.swatchHex.1)) })

    var ink: Color { Self.inks[self] ?? Color.blue }
    var fill: Color { Self.fills[self] ?? Color.blue }
    var onFill: Color { Self.onFills[self] ?? Color.white }
    var sky: Color { Self.skies[self] ?? Color.cyan }
    var swatch: Color { Self.swatches[self] ?? Color.blue }

    /// the accent saved for the app and its widgets
    static var saved: KoshAccent { KoshAccent(rawValue: KoshLook.defaults.string(forKey: KoshLook.accentKey) ?? "") ?? .kosh }
}

/// the colours the net worth line can run in: the accent's own, or one of eight
enum KoshLine: String, CaseIterable, Identifiable {
    case accent, kosh, aurora, ember, mint, gold, ink, peacock, monsoon
    var id: String { rawValue }

    var name: String {
        switch self {
        case .accent: return "Accent"
        case .kosh: return "kosh"
        case .aurora: return "Aurora"
        case .ember: return "Ember"
        case .mint: return "Mint"
        case .gold: return "Gold"
        case .ink: return "Ink"
        case .peacock: return "Peacock"
        case .monsoon: return "Monsoon"
        }
    }
    var blurb: String {
        switch self {
        case .accent: return "Follows the accent"
        case .kosh: return "kosh blue into sky"
        case .aurora: return "Sky, green and sun"
        case .ember: return "Saffron into pink"
        case .mint: return "Teal into green"
        case .gold: return "Old gold into new"
        case .ink: return "Black into grey"
        case .peacock: return "Teal into cobalt"
        case .monsoon: return "Slate into clear sky"
        }
    }

    /// how a line is painted: the colours it runs through, today's dot, and how strong the wash and glow are
    struct Paint {
        let colors: [String]
        let dot: String
        let area: Double
        let glow: Double

        /// one loop of the flow: the colours there and back, so it repeats without a seam
        var loop: [String] { colors + colors.reversed().dropFirst() }
        /// two loops, evenly spaced, for a gradient twice the loop's width that slides by one loop
        var stops: [Gradient.Stop] {
            let one: [String] = loop
            let all: [String] = one + one.dropFirst()
            let n: Int = max(1, all.count - 1)
            var out: [Gradient.Stop] = []
            for (i, h) in all.enumerated() {
                out.append(Gradient.Stop(color: Color(uiColor: UIColor(koshHex: h)), location: CGFloat(i) / CGFloat(n)))
            }
            return out
        }
        var dotColor: Color { Color(uiColor: UIColor(koshHex: dot)) }
        var first: Color { Color(uiColor: UIColor(koshHex: colors.first ?? dot)) }
        var last: Color { Color(uiColor: UIColor(koshHex: colors.last ?? dot)) }
    }

    func paint(dark: Bool, accent: KoshAccent) -> Paint {
        switch self {
        case .accent:
            let h = accent.lineHex
            let quiet: Bool = accent == .graphite
            return dark ? Paint(colors: [h.2, h.3], dot: h.2, area: quiet ? 0.16 : 0.34, glow: quiet ? 0.32 : 0.62)
                        : Paint(colors: [h.0, h.1], dot: h.0, area: quiet ? 0.14 : 0.26, glow: quiet ? 0.22 : 0.38)
        case .kosh:
            return dark ? Paint(colors: ["#6E8BFF", "#64D2FF"], dot: "#6E8BFF", area: 0.34, glow: 0.62)
                        : Paint(colors: ["#3B5BFD", "#5AC8FA"], dot: "#3B5BFD", area: 0.26, glow: 0.38)
        case .aurora:
            return dark ? Paint(colors: ["#64D2FF", "#32D74B", "#FFD60A"], dot: "#32D74B", area: 0.30, glow: 0.60)
                        : Paint(colors: ["#5AC8FA", "#30D158", "#FFD60A"], dot: "#30D158", area: 0.24, glow: 0.40)
        case .ember:
            return dark ? Paint(colors: ["#FFB340", "#FF4F6E"], dot: "#FF4F6E", area: 0.30, glow: 0.58)
                        : Paint(colors: ["#FF9F0A", "#FF375F"], dot: "#FF375F", area: 0.22, glow: 0.38)
        case .mint:
            return dark ? Paint(colors: ["#66D4CF", "#30D158"], dot: "#66D4CF", area: 0.30, glow: 0.60)
                        : Paint(colors: ["#00C7BE", "#34C759"], dot: "#00B3AA", area: 0.24, glow: 0.38)
        case .gold:
            return dark ? Paint(colors: ["#D4A72C", "#FFE08A"], dot: "#E0B33A", area: 0.28, glow: 0.56)
                        : Paint(colors: ["#B8860B", "#F5D76E"], dot: "#B8860B", area: 0.24, glow: 0.36)
        case .ink:
            return dark ? Paint(colors: ["#F5F5F7", "#8E8E93"], dot: "#F5F5F7", area: 0.16, glow: 0.30)
                        : Paint(colors: ["#0B0B0F", "#8E8E93"], dot: "#0B0B0F", area: 0.12, glow: 0.18)
        case .peacock:
            return dark ? Paint(colors: ["#2BC4C0", "#4C9BFF", "#8F93FF"], dot: "#4C9BFF", area: 0.32, glow: 0.62)
                        : Paint(colors: ["#0A9396", "#1F6FEB", "#5B6CF0"], dot: "#1F6FEB", area: 0.24, glow: 0.40)
        case .monsoon:
            return dark ? Paint(colors: ["#A3B8CC", "#7DD3FC"], dot: "#7DD3FC", area: 0.30, glow: 0.58)
                        : Paint(colors: ["#3F5A73", "#58B4DC"], dot: "#2F7FB0", area: 0.22, glow: 0.36)
        }
    }
}

/// where the choices live, and their names
enum KoshLook {
    static let schemeKey: String = "look.scheme"
    static let accentKey: String = "look.accent"
    static let lineKey: String = "look.line"
    static let shimmerKey: String = "look.shimmer"
    /// the app group's defaults, so the widgets see the accent; the app's own if the group isn't there
    static let defaults: UserDefaults = WFStore.defaults ?? UserDefaults.standard
}
