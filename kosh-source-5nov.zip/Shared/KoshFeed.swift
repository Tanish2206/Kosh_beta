import Foundation

// MARK: - What kosh hands its widgets
//
// One small file in the app group, written by the app each time the ledger is rebuilt and read by the
// widgets when they draw. Built into both the app and the widget extension, so the two always agree on it.

struct WFeed: Codable {
    var v: Int = 1
    /// when the app wrote it
    var made: Date
    /// the ledger's today, yyyy-MM-dd (India time)
    var today: String
    /// nothing read from the mail yet
    var empty: Bool
    var month: WFMonth
    var cats: [WFCat]
    var due: [WFDue]
    /// the household first, then each person
    var worth: [WFWorth]
    var cards: [WFCard]
    var banks: [WFBank]
    var recent: [WFTx]
    var noticed: [WFNote]
    var people: [WFPerson]
    /// money between people: owed to you, and what you owe
    var owedIn: Double
    var owedOut: Double
    /// the chapter under way, about to start, or just back from
    var chapter: WFChapter? = nil
    /// this month's rent from the floors that are let
    var rent: WFRent? = nil
}

/// a trip or event, as a widget shows it
struct WFChapter: Codable, Hashable {
    var id: String; var name: String; var from: String; var to: String
    /// now, soon or done
    var state: String
    var total: Double; var budget: Double; var days: Int
    var sym: String; var color: String; var event: Bool
}

/// this month's rent: what's expected, what's in, and each let floor's state (booked, due, late)
struct WFRent: Codable, Hashable {
    var expected: Double; var received: Double
    var units: [WFRentUnit]
}
struct WFRentUnit: Codable, Hashable { var label: String; var rent: Double; var st: String; var late: Int }

/// the running month
struct WFMonth: Codable {
    var m: String; var name: String; var short: String
    /// today's day of the month, and the month's days
    var d: Int; var dim: Int
    var spent: Double; var likely: Double; var usual: Double; var budget: Double
    /// left to spend: the budget less what's spent and what's still to go out; own when you set the budget
    var left: Double; var own: Bool
    /// spent today, and payments so far this month
    var today: Double; var payments: Int
    /// spent each day so far (day 1 first), and the running total
    var days: [Double]; var cum: [Double]
    /// the forecast's running total from today to the month's end (first value is today's)
    var ahead: [Double]
    /// last month: its name, each day's spending, and its running total
    var prevM: String; var prevName: String; var prevDays: [Double]; var prevCum: [Double]
}

struct WFCat: Codable, Hashable {
    var name: String; var v: Double; var usual: Double; var color: String; var sym: String
}

/// something to pay or to come in; an undated one is "any day this month"
struct WFDue: Codable, Hashable {
    var id: String; var date: String?; var name: String; var sub: String; var amt: Double
    var incoming: Bool; var cat: String; var sym: String; var color: String
}

struct WFWorth: Codable {
    var who: String; var title: String
    var now: Double; var debts: Double
    /// month ends, oldest first; the last is today
    var points: [WFPoint]
    /// what it's made of: bank, dep, stk, mf, ret, gold, prop
    var parts: [WFPart]
}
struct WFPoint: Codable, Hashable { var m: String; var v: Double }
struct WFPart: Codable, Hashable { var key: String; var title: String; var v: Double }

struct WFCard: Codable, Hashable {
    var id: String; var bank: String; var name: String; var last: String; var network: String
    var color: String; var owner: String
    var month: Double; var last30: Double; var lastUsed: String
    /// the newest bill a statement gave: amount, due date, paid
    var bill: Double?; var billDue: String?; var billPaid: Bool
}

struct WFBank: Codable, Hashable {
    var id: String; var bank: String; var name: String; var last: String; var color: String; var owner: String
    /// kosh's best figure for now, and the reading it was carried forward from (when, and from what: alert, stmt, typed)
    var balance: Double?; var asOf: String; var src: String
    var month: Double
}

struct WFTx: Codable, Hashable {
    var id: String; var d: String; var t: String; var name: String; var a: Double
    /// out, in, move…; spend when it counts as spending
    var kind: String; var spend: Bool
    var cat: String; var sym: String; var color: String
    /// how it was paid (card, upi, transfer, auto, atm, wallet, bank, cash) and from which bank
    var way: String; var bank: String
}

struct WFNote: Codable, Hashable {
    var id: String; var title: String; var detail: String; var sym: String; var color: String; var tone: String; var amount: Double
}

struct WFPerson: Codable, Hashable { var id: String; var title: String }

// MARK: - Where it lives

enum WFStore {
    /// the app group: "group." and the app's bundle id (the widgets' id is the app's plus ".widgets")
    static var group: String {
        var id: String = Bundle.main.bundleIdentifier ?? "kosh"
        if id.hasSuffix(".widgets") { id = String(id.dropLast(8)) }
        return "group." + id
    }
    static var folder: URL? { FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: group) }
    static var file: URL? { folder?.appendingPathComponent("widgets.json") }
    static var defaults: UserDefaults? { UserDefaults(suiteName: group) }

    static func read() -> WFeed? {
        guard let url = file, let data = try? Data(contentsOf: url) else { return nil }
        return try? JSONDecoder().decode(WFeed.self, from: data)
    }
    /// readable once the phone has been unlocked after starting, so the Lock Screen widgets can draw
    static func write(_ feed: WFeed) {
        guard let url = file, let data = try? JSONEncoder().encode(feed) else { return }
        try? data.write(to: url, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
    }
    static func clear() {
        guard let url = file else { return }
        try? FileManager.default.removeItem(at: url)
    }

    // what the widgets remember between taps, shared by all of them
    static let hiddenKey = "kosh.widgets.hidden"
    static let rangeKey = "kosh.widgets.range"
    static let lastMonthKey = "kosh.widgets.lastMonth"
    static let noteKey = "kosh.widgets.note"
    /// amounts hidden on every kosh widget (the eye on them, or Settings in the app)
    static var hidden: Bool {
        get { defaults?.bool(forKey: hiddenKey) ?? false }
        set { defaults?.set(newValue, forKey: hiddenKey) }
    }
}

// MARK: - Whole numbers from figures, never a crash (the app and the widgets)

extension Int {
    /// a figure as a whole number. Int(_:) traps on NaN, on ±infinity and past Int's range (an amount typed with twenty
    /// digits, a share of nothing): those give 0 here, and the rest stop at ±10^15, far past any household's rupees.
    init(safe x: Double) {
        if !x.isFinite { self = 0; return }
        let cap: Double = 1_000_000_000_000_000
        self = Int(Swift.min(Swift.max(x, -cap), cap))
    }
}

/// what an amount typed by hand may come to: up to ₹1,000 crore either way (NaN and infinity are nothing)
enum TypedAmount {
    static let most: Double = 10_000_000_000
    static func cap(_ v: Double) -> Double {
        if !v.isFinite { return 0 }
        return Swift.min(Swift.max(v, -most), most)
    }
    /// what a typed amount's digits come to ("1,20,000" → 120000), within bounds; nil when there are none. The
    /// fields are number pads: anything else typed or pasted is dropped, as the fields always did.
    static func whole(_ s: String) -> Double? {
        let digits: String = s.filter { $0.isASCII && $0.isNumber }
        guard let v = Double(digits) else { return nil }
        return cap(v)
    }
}
