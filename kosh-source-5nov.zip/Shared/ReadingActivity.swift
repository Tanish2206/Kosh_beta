import ActivityKit
import Foundation

// MARK: - kosh's own Lock Screen entry while it reads with the phone locked
//
// The app starts it as kosh leaves the screen with reading under way, and keeps it up to date (Kosh/ReadingLive.swift);
// the widget extension draws it (KoshWidgets/ReadingLiveActivity.swift). Built into both, so the two always agree
// on what it carries: the same words the bar above the tab bar says, and how far the reading has got.

struct ReadingAttributes: ActivityAttributes {
    struct ContentState: Codable, Hashable {
        /// "Reading new mail", "Filling in the year", "All caught up"
        var title: String
        /// under the title: now and then a lighter line ("Chasing every chillar"), else the plain one
        var line: String
        /// on the right: "412 of 1,240", "2,340 found", "1,240 read"
        var count: String
        var done: Int
        var total: Int
        /// the SF Symbol for what it's reading (envelope, calendar, wallet...)
        var sym: String
        /// stopped with nothing on its way: a grey bar, "Paused · carries on by itself"
        var paused: Bool
        /// all caught up: a green check, the bar full
        var finished: Bool
        /// still counting what there is to read: no fill yet, a soft band where it will be
        var seeking: Bool
        /// kosh's gradient in the accent you picked (Settings › Appearance): from, a step between, and its sky
        var accentHex: String
        var midHex: String
        var skyHex: String

        /// how far, 0...1
        var fraction: Double {
            if finished { return 1 }
            guard total > 0 else { return 0 }
            return min(1, max(0, Double(done) / Double(total)))
        }
    }
}
