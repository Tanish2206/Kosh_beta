import SwiftUI
import WidgetKit
import Charts

// MARK: - Net worth: everything owned less what's owed, month by month; tap the span to change it
//
// The figure big, the change over the span in green (warm when it fell), the months as one fine line in the accent,
// and on the large size what it's made of as one bar with a legend. (The canvas "kosh widgets", board Net worth.)

struct WorthWidget: Widget {
    let kind: String = "KoshWorth"
    var body: some WidgetConfiguration {
        AppIntentConfiguration(kind: kind, intent: WhoIntent.self, provider: WhoProvider()) { e in
            WorthView(entry: e)
        }
        .configurationDisplayName("Net worth")
        .description("The household's or one person's, month by month. Tap the span to see more or less.")
        .supportedFamilies([.systemSmall, .systemMedium, .systemLarge, .accessoryRectangular])
    }
}

struct WP: Identifiable, Hashable {
    let i: Int
    let m: String
    let v: Double
    /// where it sits on the time line: the month's last day, or today for the running month
    let date: Date
    var id: Int { i }
}

struct WorthMath {
    let w: WFWorth
    let range: Int
    var today: String = WDay.iso(Date())
    static let labels: [String] = ["6M", "1Y", "All", "3M"]
    static let months: [Int] = [6, 12, 0, 3]
    /// the span counted back from today, as the app counts it: 3M on 7 Oct reaches back to 7 Jul, so the line
    /// opens on the last month-end before (30 Jun, what July started with) and runs to today
    var points: [WP] {
        let n: Int = Self.months[min(max(0, range), 3)]
        var first: String = ""
        if n > 0 {
            let back: Date = WDay.cal.date(byAdding: .month, value: -n, to: WDay.date(today)) ?? WDay.date(today)
            let after: String = WDay.add(WDay.iso(back), 1)
            first = Self.monthBefore(String(after.prefix(7)))
        }
        var out: [WP] = []
        let lastM: String = w.points.last?.m ?? ""
        for p in w.points where p.m >= first {
            let day: String = p.m == lastM ? today : Self.monthEnd(p.m)
            out.append(WP(i: out.count, m: p.m, v: p.v, date: WDay.date(day)))
        }
        return out
    }
    static func monthEnd(_ m: String) -> String {
        let start: Date = WDay.date(m + "-01")
        let next: Date = WDay.cal.date(byAdding: .month, value: 1, to: start) ?? start
        return WDay.add(WDay.iso(next), -1)
    }
    static func monthBefore(_ m: String) -> String {
        let start: Date = WDay.date(m + "-01")
        let prev: Date = WDay.cal.date(byAdding: .month, value: -1, to: start) ?? start
        return String(WDay.iso(prev).prefix(7))
    }
    var change: Double {
        let p: [WP] = points
        guard let a = p.first, let b = p.last, p.count > 1 else { return 0 }
        return b.v - a.v
    }
    var up: Bool { change >= 0 }
    /// the change's colour: green up, warm down
    var tint: Color { up ? KInk.good : KInk.warm }
    /// "+₹16.1 L"
    var changeFigure: String { (up ? "+" : "−") + WMoney.tight(change) }
    /// "in a year", "in six months", "since Oct 2025"
    var changeWords: String {
        let p: [WP] = points
        if p.count < 2 { return "grows month by month from here" }
        switch range {
        case 0: return "in six months"
        case 1: return "in a year"
        case 3: return "in three months"
        default: return "since " + opened
        }
    }
    /// the month the span opens on: "Oct 2025"
    var opened: String {
        guard let p = points.first else { return "" }
        return WDay.fmt(WDay.add(Self.monthEnd(p.m), 1), "MMM yyyy")
    }
    var spanWords: String {
        switch range {
        case 0: return "6M"
        case 1: return "1Y"
        case 3: return "3M"
        default: return "All"
        }
    }
    /// whose: "Family", or the person's name
    var who: String { w.who == "family" ? "Family" : w.title }
    /// the months the line covers: "Nov 2025–Oct 2026"
    var monthsLine: String {
        let p: [WP] = points
        guard let a = p.first, let b = p.last, p.count > 1 else { return who + ", today" }
        return WDay.fmt(WDay.iso(a.date), "MMM yyyy") + "–" + WDay.fmt(WDay.iso(b.date), "MMM yyyy")
    }
}

enum WorthPick {
    static func of(_ f: WFeed, who: String) -> WFWorth? {
        if let w = f.worth.first(where: { $0.who == who }) { return w }
        return f.worth.first
    }
}

/// the parts' colours: the accent's family for what's invested, quiet grey for property, teal, gold and sky for the rest
fileprivate enum WorthInk {
    static func part(_ key: String) -> Color {
        switch key {
        case "mf": return Color(hex: "#4C6EF5")
        case "prop": return Color(hex: "#8B9099")
        case "ret": return Color(hex: "#8EA2F8")
        case "dep": return Color(hex: "#B9C5F9")
        case "stk": return Color(hex: "#2F9E8F")
        case "gold": return Color(hex: "#C99A2E")
        case "bank": return Color(hex: "#5DBAD9")
        default: return Color(hex: "#A3A3AA")
        }
    }
}

struct WorthView: View {
    let entry: KEntry
    @Environment(\.widgetFamily) private var family
    var body: some View {
        let pick: WFWorth? = entry.feed.flatMap { WorthPick.of($0, who: entry.who) }
        let m: WorthMath? = pick.map { WorthMath(w: $0, range: entry.range, today: entry.today) }
        KFrame(entry: entry, link: "worth") {
            if let m, entry.feed?.empty == false {
                switch family {
                case .accessoryRectangular: WorthRect(m: m)
                case .systemMedium: WorthMedium(m: m)
                case .systemLarge: WorthLarge(m: m)
                default: WorthSmall(m: m)
                }
            } else if family == .accessoryRectangular {
                Text("Open kosh")
            } else {
                KEmpty(sym: "chart.line.uptrend.xyaxis", title: KCopy.openTitle, line: KCopy.openLine)
            }
        }
    }
}

/// the months as one fine line in the accent, a light where today is, and faint rules across
struct WorthChart: View {
    let pts: [WP]
    var tint: Color = .kosh
    /// how many rules across (0 none, 1 the middle, 3 top, middle and bottom)
    var rules: Int = 0
    var line: CGFloat = 1.75
    var dot: Bool = true
    var body: some View {
        let lo: Double = Self.low(pts)
        let hi: Double = Self.high(pts, lo: lo)
        Chart {
            ForEach(Self.ruleValues(lo: lo, hi: hi, count: rules), id: \.self) { y in
                RuleMark(y: .value("Rule", y)).foregroundStyle(KInk.faint).lineStyle(StrokeStyle(lineWidth: 1))
            }
            ForEach(pts) { p in
                LineMark(x: .value("Day", p.date), y: .value("Worth", p.v))
                    .foregroundStyle(tint)
                    .lineStyle(StrokeStyle(lineWidth: line, lineCap: .round, lineJoin: .round))
                    .interpolationMethod(.monotone)
            }
            if dot, let last = pts.last {
                PointMark(x: .value("Day", last.date), y: .value("Worth", last.v))
                    .foregroundStyle(tint)
                    .symbolSize(36)
            }
        }
        .chartXScale(domain: Self.span(pts))
        .chartYScale(domain: lo...hi)
        .chartXAxis(.hidden)
        .chartYAxis(.hidden)
        .chartLegend(.hidden)
        .widgetAccentable()
    }
    static func ruleValues(lo: Double, hi: Double, count: Int) -> [Double] {
        if count <= 0 { return [] }
        if count == 1 { return [(lo + hi) / 2] }
        return [hi, (lo + hi) / 2, lo]
    }
    static func span(_ pts: [WP]) -> ClosedRange<Date> {
        let start: Date = pts.first?.date ?? Date()
        let end: Date = pts.last?.date ?? start
        return start...max(end, start.addingTimeInterval(86400))
    }
    static func low(_ pts: [WP]) -> Double {
        var lo: Double = pts.first?.v ?? 0
        for p in pts { lo = min(lo, p.v) }
        var hi: Double = lo
        for p in pts { hi = max(hi, p.v) }
        return lo - max((hi - lo) * 0.06, abs(lo) * 0.005, 1)
    }
    static func high(_ pts: [WP], lo: Double) -> Double {
        var hi: Double = lo + 1
        for p in pts { hi = max(hi, p.v) }
        return hi + max((hi - lo) * 0.06, 1)
    }
}

/// the span as a segmented row: 3M 6M 1Y All, the one showing lit; a tap moves to the next
struct SpanButton: View {
    let m: WorthMath
    var compact: Bool = false
    var body: some View {
        Button(intent: CycleRangeIntent()) {
            HStack(spacing: 0) {
                ForEach(compact ? [m.spanWords] : ["3M", "6M", "1Y", "All"], id: \.self) { s in
                    let on: Bool = s == m.spanWords
                    Text(s)
                        .font(.system(size: 11.5, weight: .semibold))
                        .foregroundStyle(on ? KInk.ink : KInk.quiet)
                        .padding(.horizontal, compact ? 9 : 8)
                        .frame(height: 22)
                        .background(on ? KInk.surface : Color.clear, in: RoundedRectangle(cornerRadius: 7, style: .continuous))
                        .overlay(RoundedRectangle(cornerRadius: 7, style: .continuous).strokeBorder(on ? KInk.hair : Color.clear, lineWidth: 1))
                }
            }
            .padding(2)
            .background(KInk.faint, in: RoundedRectangle(cornerRadius: 9, style: .continuous))
        }
        .buttonStyle(.plain)
        .accessibilityLabel("Span: " + m.spanWords + ". Tap to change.")
    }
}

/// the change in green (warm when it fell), its words quiet: "+₹16.1 L in a year"
struct ChangeLine: View {
    let m: WorthMath
    var together: Bool = true
    var body: some View {
        if m.points.count >= 2 {
            let fig: Text = Text(m.changeFigure).font(.system(size: together ? 11.5 : 13, weight: .semibold)).foregroundStyle(m.tint)
            let words: Text = Text(" " + m.changeWords).font(.system(size: 11.5, weight: together ? .semibold : .medium))
                .foregroundStyle(together ? m.tint : KInk.quiet)
            Text("\(fig)\(words)").monospacedDigit().lineLimit(1).minimumScaleFactor(0.8).privacySensitive()
        } else {
            Text("Grows month by month from here").kSub()
        }
    }
}

/// the months under the line: where it opens, the middle (or the quarters), and now in the accent
struct WorthMonths: View {
    let pts: [WP]
    var marks: Int = 3
    var body: some View {
        let picks: [Int] = Self.picks(pts.count, marks: marks)
        HStack(spacing: 0) {
            ForEach(Array(picks.enumerated()), id: \.offset) { k, i in
                let last: Bool = k == picks.count - 1
                Text(WDay.fmt(WDay.iso(pts[i].date), k == 0 ? "MMM yyyy" : "MMM"))
                    .font(.system(size: 10.5, weight: last ? .semibold : .regular))
                    .foregroundStyle(last ? Color.kosh : KInk.quiet)
                if !last { Spacer(minLength: 4) }
            }
        }
        .lineLimit(1)
    }
    static func picks(_ n: Int, marks: Int) -> [Int] {
        if n <= 0 { return [] }
        if n == 1 { return [0] }
        let k: Int = min(max(2, marks), n)
        var out: [Int] = []
        for j in 0..<k {
            let i: Int = Int((Double(j) * Double(n - 1) / Double(k - 1)).rounded())
            if !out.contains(i) { out.append(i) }
        }
        return out
    }
}

struct WorthSmall: View {
    let m: WorthMath
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            KHeader(title: "Net worth", sub: m.who + ", today")
            KAmount(v: m.w.now, size: 30, mode: .words, sign: m.w.now <= -0.5 ? "−" : "").padding(.top, 12)
            Spacer(minLength: 6)
            WorthChart(pts: m.points).frame(height: 40)
            ChangeLine(m: m).padding(.top, 8)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

struct WorthMedium: View {
    let m: WorthMath
    var body: some View {
        HStack(spacing: 14) {
            VStack(alignment: .leading, spacing: 0) {
                KHeader(title: "Net worth", sub: m.who + ", today")
                Spacer(minLength: 4)
                KAmount(v: m.w.now, size: 32, mode: .words, sign: m.w.now <= -0.5 ? "−" : "")
                if m.points.count >= 2 {
                    Text(m.changeFigure).font(.system(size: 13, weight: .semibold)).foregroundStyle(m.tint)
                        .monospacedDigit().lineLimit(1).privacySensitive().padding(.top, 10)
                    Text(m.range == 2 ? "since " + m.opened : m.changeWords).kSub()
                } else {
                    Text("Grows month by month from here").kSub().padding(.top, 10)
                }
            }
            .frame(width: 132, alignment: .leading)
            VStack(alignment: .trailing, spacing: 0) {
                SpanButton(m: m, compact: true)
                WorthChart(pts: m.points, rules: 1, line: 2, dot: false)
                    .frame(maxHeight: .infinity)
                    .padding(.top, 6)
                WorthMonths(pts: m.points).padding(.top, 6)
            }
            .frame(maxWidth: .infinity)
        }
    }
}

/// what it's made of, as one bar of its parts, biggest first
struct PartsBar: View {
    let parts: [WFPart]
    var height: CGFloat = 8
    var body: some View {
        let shown: [WFPart] = parts.filter { $0.v > 0 }.sorted { $0.v > $1.v }
        let total: Double = shown.reduce(0) { $0 + $1.v }
        GeometryReader { g in
            HStack(spacing: 2) {
                ForEach(shown, id: \.key) { p in
                    RoundedRectangle(cornerRadius: 2, style: .continuous)
                        .fill(WorthInk.part(p.key))
                        .frame(width: Self.width(p.v, total: total, count: shown.count, in: g.size.width))
                }
                Spacer(minLength: 0)
            }
        }
        .frame(height: height)
        .widgetAccentable()
    }
    static func width(_ v: Double, total: Double, count: Int, in w: CGFloat) -> CGFloat {
        if total <= 0 || v <= 0 { return 0 }
        let gaps: CGFloat = CGFloat(max(0, count - 1)) * 2
        return max(2, (w - gaps) * CGFloat(v / total))
    }
}

/// a part in the legend: its dot, its name quiet, its figure
struct PartRow: View {
    let title: String
    let v: Double
    let color: Color?
    var body: some View {
        HStack(spacing: 7) {
            if let c = color {
                Circle().fill(c).frame(width: 7, height: 7)
            } else {
                Circle().strokeBorder(KInk.hair, lineWidth: 1).frame(width: 7, height: 7)
            }
            Text(title).font(.system(size: 12)).foregroundStyle(KInk.quiet).lineLimit(1)
            Spacer(minLength: 2)
            Text(WMoney.words(v)).font(.system(size: 12, weight: .semibold)).foregroundStyle(KInk.ink)
                .monospacedDigit().lineLimit(1).privacySensitive()
        }
        .frame(maxWidth: .infinity)
    }
}

/// the legend in two columns: the parts, biggest first, then what's owed
struct PartsLegend: View {
    let w: WFWorth
    var body: some View {
        let parts: [WFPart] = Array(w.parts.filter { $0.v > 0 }.sorted { $0.v > $1.v }.prefix(7))
        let cells: [(String, Double, Color?)] = Self.cells(parts, debts: w.debts)
        let rows: Int = (cells.count + 1) / 2
        VStack(alignment: .leading, spacing: 7) {
            ForEach(0..<rows, id: \.self) { r in
                HStack(spacing: 18) {
                    PartRow(title: cells[r * 2].0, v: cells[r * 2].1, color: cells[r * 2].2)
                    if r * 2 + 1 < cells.count {
                        PartRow(title: cells[r * 2 + 1].0, v: cells[r * 2 + 1].1, color: cells[r * 2 + 1].2)
                    } else {
                        Color.clear.frame(maxWidth: .infinity, maxHeight: 1)
                    }
                }
            }
        }
    }
    static func cells(_ parts: [WFPart], debts: Double) -> [(String, Double, Color?)] {
        var out: [(String, Double, Color?)] = []
        for p in parts { out.append((p.title, p.v, WorthInk.part(p.key))) }
        out.append(("Owed", debts, nil))
        return out
    }
}

struct WorthLarge: View {
    let m: WorthMath
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            KHeader(title: m.w.who == "family" ? "Net worth" : m.who + ", net worth", sub: m.monthsLine) {
                SpanButton(m: m)
            }
            HStack(alignment: .firstTextBaseline, spacing: 10) {
                KAmount(v: m.w.now, size: 38, mode: .words, sign: m.w.now <= -0.5 ? "−" : "")
                ChangeLine(m: m, together: false)
            }
            .padding(.top, 10)
            WorthChart(pts: m.points, rules: 3, line: 2)
                .frame(maxHeight: .infinity)
                .padding(.top, 12)
            WorthMonths(pts: m.points, marks: 5).padding(.top, 6)
            KHairline().padding(.vertical, 12)
            PartsBar(parts: m.w.parts)
            PartsLegend(w: m.w).padding(.top, 12)
        }
    }
}

// MARK: - The Lock Screen

/// "Net worth, family, today", the figure with the line beside it, and the change
struct WorthRect: View {
    let m: WorthMath
    var body: some View {
        VStack(alignment: .leading, spacing: 1) {
            Text("Net worth, " + (m.w.who == "family" ? "family" : m.who) + ", today").font(.system(size: 12, weight: .semibold)).foregroundStyle(.secondary).lineLimit(1)
            HStack(alignment: .bottom, spacing: 6) {
                KAmount(v: m.w.now, size: 20, mode: .words, color: .primary, sign: m.w.now <= -0.5 ? "−" : "")
                Spacer(minLength: 0)
                WorthChart(pts: m.points, tint: .primary, line: 2, dot: false).frame(width: 62, height: 22)
            }
            if m.points.count >= 2 {
                Text(m.changeFigure + " " + m.changeWords).font(.system(size: 11.5)).foregroundStyle(.secondary).lineLimit(1).privacySensitive()
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}
