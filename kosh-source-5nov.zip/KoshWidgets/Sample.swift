import Foundation

/// A made-up household, for the widget gallery and placeholders only: never anyone's real figures.
enum Sample {
    static let feed: WFeed = make()

    static func make() -> WFeed {
        let today: String = WDay.iso(Date())
        let m: String = String(today.prefix(7))
        let d: Int = WDay.dayNumber(today)
        let dim: Int = WDay.cal.range(of: .day, in: .month, for: WDay.date(today))?.count ?? 30
        let pattern: [Double] = [1840, 620, 3150, 0, 980, 4200, 760, 2310, 0, 1450, 590, 6800, 1230, 870, 2990, 410,
                                 1760, 0, 3380, 920, 1510, 2640, 700, 0, 1980, 5100, 860, 1320, 2070, 640, 1190]
        var days: [Double] = []
        var cum: [Double] = []
        var run: Double = 0
        for i in 0..<d {
            let v: Double = pattern[i % pattern.count]
            days.append(v)
            run += v
            cum.append(run)
        }
        let spent: Double = run
        let daily: Double = 1750
        var ahead: [Double] = []
        var f: Double = spent
        for _ in d...dim {
            ahead.append(f)
            f += daily
        }
        let likely: Double = spent + daily * Double(dim - d) + 9000
        let budget: Double = 60000

        let firstOfMonth: Date = WDay.date(m + "-01")
        let prevDate: Date = WDay.cal.date(byAdding: .month, value: -1, to: firstOfMonth) ?? firstOfMonth
        let prevM: String = String(WDay.iso(prevDate).prefix(7))
        let prevDim: Int = WDay.cal.range(of: .day, in: .month, for: prevDate)?.count ?? 30
        var prevDays: [Double] = []
        var prevCum: [Double] = []
        var pr: Double = 0
        for i in 0..<prevDim {
            let v: Double = pattern[(i + 5) % pattern.count] * 1.1
            prevDays.append(v)
            pr += v
            prevCum.append(pr)
        }

        let month = WFMonth(m: m, name: WDay.monthName(m), short: WDay.fmt(m + "-01", "MMM"), d: d, dim: dim,
                            spent: spent, likely: likely, usual: 58000, budget: budget, left: budget - likely + 4000, own: true,
                            today: days.last ?? 0, payments: d * 3,
                            days: days, cum: cum, ahead: ahead,
                            prevM: prevM, prevName: WDay.monthName(prevM), prevDays: prevDays, prevCum: prevCum)

        let shares: [(String, Double, String, String)] = [
            ("Groceries", 0.30, "#34C759", "cart.fill"), ("Eating out", 0.20, "#FF9500", "fork.knife"),
            ("Transport", 0.13, "#5AC8FA", "car.fill"), ("Shopping", 0.12, "#FF2D55", "bag.fill"),
            ("Bills", 0.10, "#FFCC00", "bolt.fill"), ("Health", 0.08, "#FF3B30", "cross.case.fill"),
            ("Other", 0.07, "#8E8E93", "square.grid.2x2.fill"),
        ]
        var cats: [WFCat] = []
        for (name, share, color, sym) in shares {
            cats.append(WFCat(name: name, v: (spent * share).rounded(), usual: (58000 * share).rounded(), color: color, sym: sym))
        }

        let due: [WFDue] = [
            WFDue(id: "s1", date: WDay.add(today, 1), name: "Federal Bank card bill", sub: "Minimum ₹1,170", amt: 23400, incoming: false, cat: "Card Payments", sym: "creditcard.fill", color: "#007AFF"),
            WFDue(id: "s2", date: WDay.add(today, 3), name: "Electricity", sub: "Due, from your mail", amt: 2860, incoming: false, cat: "Bills", sym: "bolt.fill", color: "#FFCC00"),
            WFDue(id: "s3", date: WDay.add(today, 5), name: "Rent · Flat 2B", sub: "Due this month", amt: 32000, incoming: true, cat: "Rent received", sym: "key.fill", color: "#34C759"),
            WFDue(id: "s4", date: WDay.add(today, 6), name: "Car loan EMI", sub: "Auto-pay, from your bank", amt: 18500, incoming: false, cat: "Loans", sym: "car.fill", color: "#FF9500"),
            WFDue(id: "s5", date: WDay.add(today, 12), name: "Health premium", sub: "Health insurance", amt: 14200, incoming: false, cat: "Insurance", sym: "shield.lefthalf.filled", color: "#30B0C7"),
            WFDue(id: "s6", date: WDay.add(today, 19), name: "Music subscription", sub: "monthly, learnt from your spending", amt: 119, incoming: false, cat: "Entertainment", sym: "music.note", color: "#FF2D55"),
            WFDue(id: "s7", date: nil, name: "Committee · Friends circle", sub: "this month's instalment", amt: 10000, incoming: false, cat: "committee", sym: "circle.dotted.circle", color: "#5AC8FA"),
        ]

        func series(_ start: Double, _ end: Double) -> [WFPoint] {
            var out: [WFPoint] = []
            for i in 0..<13 {
                let date: Date = WDay.cal.date(byAdding: .month, value: i - 12, to: firstOfMonth) ?? firstOfMonth
                let mm: String = String(WDay.iso(date).prefix(7))
                let t: Double = Double(i) / 12
                let wobble: Double = (i % 3 == 1 ? -0.012 : 0.006) * start
                out.append(WFPoint(m: mm, v: start + (end - start) * t + wobble))
            }
            return out
        }
        let famParts: [WFPart] = [
            WFPart(key: "bank", title: "In the bank", v: 422000), WFPart(key: "dep", title: "Deposits", v: 2200000),
            WFPart(key: "mf", title: "Mutual funds", v: 4100000), WFPart(key: "stk", title: "Stocks", v: 1850000),
            WFPart(key: "ret", title: "Retirement", v: 3100000), WFPart(key: "gold", title: "Physical gold", v: 620000),
            WFPart(key: "prop", title: "Property (land)", v: 3500000),
        ]
        let meParts: [WFPart] = [
            WFPart(key: "bank", title: "In the bank", v: 284500), WFPart(key: "mf", title: "Mutual funds", v: 2600000),
            WFPart(key: "stk", title: "Stocks", v: 1850000), WFPart(key: "ret", title: "Retirement", v: 1900000),
        ]
        let worth: [WFWorth] = [
            WFWorth(who: "family", title: "Family", now: 15792000, debts: 0, points: series(14100000, 15792000), parts: famParts),
            WFWorth(who: "me", title: "You", now: 6634500, debts: 0, points: series(5700000, 6634500), parts: meParts),
        ]

        let cards: [WFCard] = [
            WFCard(id: "c1", bank: "Federal Bank", name: "Celesta", last: "1234", network: "Visa", color: "#1F4E9C", owner: "me",
                   month: 18450, last30: 21300, lastUsed: today, bill: 23400, billDue: WDay.add(today, 1), billPaid: false),
            WFCard(id: "c2", bank: "Canara Bank", name: "Select", last: "5678", network: "RuPay", color: "#C8372C", owner: "me",
                   month: 6230, last30: 9100, lastUsed: WDay.add(today, -2), bill: 7840, billDue: WDay.add(today, -4), billPaid: true),
            WFCard(id: "c3", bank: "Yes Bank", name: "Marquee", last: "9012", network: "Mastercard", color: "#0A2F6B", owner: "p2",
                   month: 2180, last30: 4400, lastUsed: WDay.add(today, -5), bill: nil, billDue: nil, billPaid: false),
        ]
        let banks: [WFBank] = [
            WFBank(id: "b1", bank: "Federal Bank", name: "Savings", last: "4321", color: "#1F4E9C", owner: "me", balance: 284500, asOf: today + "T09:12", src: "alert", month: 42100),
            WFBank(id: "b2", bank: "Canara Bank", name: "Savings", last: "8765", color: "#C8372C", owner: "p2", balance: 96200, asOf: WDay.add(today, -6), src: "stmt", month: 8800),
            WFBank(id: "b3", bank: "Yes Bank", name: "Current", last: "2109", color: "#0A2F6B", owner: "me", balance: 41300, asOf: WDay.add(today, -2), src: "typed", month: 3100),
        ]
        let y: String = WDay.add(today, -1)
        let y2: String = WDay.add(today, -2)
        let recent: [WFTx] = [
            WFTx(id: "t1", d: today, t: "09:41", name: "Blue Tokai", a: 380, kind: "out", spend: true, cat: "Eating out", sym: "cup.and.saucer.fill", color: "#FF9500", way: "card", bank: "Federal Bank"),
            WFTx(id: "t2", d: today, t: "08:15", name: "Metro card", a: 500, kind: "out", spend: true, cat: "Transport", sym: "tram.fill", color: "#5AC8FA", way: "upi", bank: "Canara Bank"),
            WFTx(id: "t3", d: y, t: "19:02", name: "Corner grocer", a: 1240, kind: "out", spend: true, cat: "Groceries", sym: "cart.fill", color: "#34C759", way: "upi", bank: "Federal Bank"),
            WFTx(id: "t4", d: y, t: "10:00", name: "Salary", a: 145000, kind: "in", spend: false, cat: "Salary", sym: "briefcase.fill", color: "#34C759", way: "transfer", bank: "Federal Bank"),
            WFTx(id: "t5", d: y, t: "08:30", name: "Fuel", a: 2000, kind: "out", spend: true, cat: "Transport", sym: "fuelpump.fill", color: "#5AC8FA", way: "card", bank: "Yes Bank"),
            WFTx(id: "t6", d: y2, t: "21:10", name: "Pharmacy", a: 640, kind: "out", spend: true, cat: "Health", sym: "cross.case.fill", color: "#FF3B30", way: "cash", bank: ""),
            WFTx(id: "t7", d: y2, t: "18:45", name: "Movie tickets", a: 900, kind: "out", spend: true, cat: "Entertainment", sym: "film.fill", color: "#FF2D55", way: "card", bank: "Canara Bank"),
        ]
        let noticed: [WFNote] = [
            WFNote(id: "n1", title: "Eating out is running 32% above your usual month", detail: "Mostly weekday coffees and two dinners. Keeping to the usual leaves ₹2,100 more by month end.", sym: "fork.knife", color: "#FF9500", tone: "warn", amount: 2100),
            WFNote(id: "n2", title: "Your music subscription went up from ₹99 to ₹119", detail: "It has charged the new price for two months now.", sym: "music.note", color: "#FF2D55", tone: "warn", amount: 20),
            WFNote(id: "n3", title: "You saved 31% of what came in last month", detail: "Your best in six months, after the card bill.", sym: "leaf.fill", color: "#34C759", tone: "good", amount: 45000),
        ]
        let people: [WFPerson] = [WFPerson(id: "family", title: "Family"), WFPerson(id: "me", title: "You"), WFPerson(id: "p2", title: "Asha")]
        var feed = WFeed(made: Date(), today: today, empty: false, month: month, cats: cats, due: due, worth: worth,
                         cards: cards, banks: banks, recent: recent, noticed: noticed, people: people, owedIn: 4500, owedOut: 0)
        feed.chapter = WFChapter(id: "ch1", name: "Hill station weekend", from: WDay.add(today, 17), to: WDay.add(today, 20), state: "soon",
                                 total: 21800, budget: 90000, days: 4, sym: "mountain.2.fill", color: "#9A4A1E", event: false)
        feed.rent = WFRent(expected: 118000, received: 91000, units: [
            WFRentUnit(label: "Ground floor", rent: 27000, st: "booked", late: 0),
            WFRentUnit(label: "First floor", rent: 24000, st: "late", late: 3),
            WFRentUnit(label: "Second floor", rent: 32000, st: "booked", late: 0),
            WFRentUnit(label: "Third floor", rent: 3000, st: "late", late: 2),
            WFRentUnit(label: "Shop", rent: 32000, st: "booked", late: 0),
        ])
        return feed
    }
}
