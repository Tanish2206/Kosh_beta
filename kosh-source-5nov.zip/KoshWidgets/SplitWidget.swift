import SwiftUI
import WidgetKit
import Charts

// MARK: - Where it went: this month's spending by what it went on, against a usual month
//
// A thin ring of what the month went on, the total inside, and on the medium size the biggest four with a bar each and
// how each sits against a usual month so far, warm when it runs hot. (The canvas "kosh widgets", board Where it went.)

struct SplitWidget: Widget {
    let kind: String = "KoshSplit"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: KoshProvider()) { e in
            SplitView(entry: e)
        }
        .configurationDisplayName("Where it went")
        .description("This month's spending by category, and how each compares with a usual month so far.")
        .supportedFamilies([.systemSmall, .systemMedium])
    }
}

struct SliceW: Identifiable, Hashable {
    let name: String
    let v: Double
    let usual: Double
    /// its colour on the ring: by its place, biggest first (the categories' own colours are too loud together)
    let color: Color
    var id: String { name }
}

enum SplitPick {
    /// the ring's colours, biggest first: the accent's blue, saffron, plum, teal, gold, sky; the rest in grey
    static let palette: [String] = ["#4C6EF5", "#E8822F", "#C25FA5", "#2F9E8F", "#C99A2E", "#5DBAD9"]
    static let restHex: String = "#8B9099"
    /// the biggest few, the rest together
    static func slices(_ f: WFeed, keep: Int = 6) -> [SliceW] {
        let cats: [WFCat] = f.cats.filter { $0.v > 0 }.sorted { $0.v > $1.v }
        var out: [SliceW] = []
        var rest: Double = 0
        var restUsual: Double = 0
        for (i, c) in cats.enumerated() {
            if i < min(keep, palette.count) {
                out.append(SliceW(name: c.name, v: c.v, usual: c.usual, color: Color(hex: palette[i])))
            } else {
                rest += c.v
                restUsual += c.usual
            }
        }
        if rest > 0 { out.append(SliceW(name: "The rest", v: rest, usual: restUsual, color: Color(hex: restHex))) }
        return out
    }
    static func total(_ xs: [SliceW]) -> Double { xs.reduce(0) { $0 + $1.v } }
    static func top(_ xs: [SliceW]) -> Double { xs.reduce(0) { max($0, $1.v) } }
    /// how far it sits from a usual month by this day, as a share (nil when there's no usual month yet)
    static func gap(_ s: SliceW, pace: Double) -> Double? {
        let by: Double = s.usual * pace
        // (a usual month that hardly spent on it, under ₹500 by now, gives no fair comparison: "103×" says nothing)
        if by < 500 { return nil }
        return (s.v - by) / by
    }
    /// "+32%", "−17%", "usual"; nothing without a usual month
    static func versus(_ s: SliceW, pace: Double) -> String {
        guard let x = gap(s, pace: pace) else { return "" }
        if abs(x) < 0.05 { return "usual" }
        // (twice a usual month or more says it plainer as a multiple: "3×", not "+200%")
        if x >= 9 { return "10×+" }
        if x >= 1 { return WMoney.trim(1 + x, 1) + "×" }
        let n: Int = min(99, Int(safe: (abs(x) * 100).rounded()))
        return (x > 0 ? "+" : "−") + String(n) + "%"
    }
    /// running hot: a fifth or more above a usual month so far
    static func hot(_ s: SliceW, pace: Double) -> Bool { (gap(s, pace: pace) ?? 0) >= 0.2 }
    static func share(_ v: Double, _ total: Double) -> Double { total <= 0 ? 0 : v / total }
    /// the month's days so far: "1–24 Oct"
    static func days(_ f: WFeed) -> String {
        let first: String = f.month.m + "-01"
        let d: Int = max(1, f.month.d)
        if d == 1 { return WDay.fmt(first, "d MMM") }
        return "1–" + String(d) + " " + WDay.fmt(first, "MMM")
    }
}

struct SplitView: View {
    let entry: KEntry
    @Environment(\.widgetFamily) private var family
    var body: some View {
        KFrame(entry: entry, link: "split") {
            if let f = entry.feed, !f.empty, !entry.stale, !f.cats.isEmpty {
                let xs: [SliceW] = SplitPick.slices(f)
                let pace: Double = Double(max(1, f.month.d)) / Double(max(1, f.month.dim))
                if family == .systemMedium {
                    SplitMedium(xs: xs, days: SplitPick.days(f), pace: pace)
                } else {
                    SplitSmall(xs: xs, days: SplitPick.days(f), pace: pace)
                }
            } else {
                KEmpty(sym: "chart.pie", title: entry.stale ? "A new month" : KCopy.openTitle,
                       line: entry.stale ? KCopy.staleLine(entry) : "Categories show once this month has some spending.")
            }
        }
    }
}

/// one slice of the ring, as a fraction of the way round
struct ArcW: Identifiable {
    let id: Int
    let from: Double
    let to: Double
    let color: Color
}

/// the month as a thin ring of what it went on, each part in its colour, a hair's gap between
struct SplitRing: View {
    let xs: [SliceW]
    var line: CGFloat = 7
    var body: some View {
        ZStack {
            Circle().stroke(KInk.faint, lineWidth: line)
            ForEach(Self.arcs(xs)) { a in
                Circle()
                    .trim(from: a.from, to: a.to)
                    .stroke(a.color, style: StrokeStyle(lineWidth: line, lineCap: .butt))
                    .rotationEffect(.degrees(-90))
            }
        }
        .padding(line / 2)
        .widgetAccentable()
    }
    static func arcs(_ xs: [SliceW]) -> [ArcW] {
        let total: Double = SplitPick.total(xs)
        if total <= 0 { return [] }
        var out: [ArcW] = []
        var at: Double = 0
        let gap: Double = xs.count > 1 ? 0.008 : 0
        for (i, s) in xs.enumerated() {
            let span: Double = s.v / total
            let b: Double = max(at + 0.0005, at + span - gap)
            out.append(ArcW(id: i, from: at, to: b, color: s.color))
            at += span
        }
        return out
    }
}

/// the ring with the total inside, and under it the category running hottest (or the biggest, with its share)
struct SplitSmall: View {
    let xs: [SliceW]
    let days: String
    let pace: Double
    var body: some View {
        let total: Double = SplitPick.total(xs)
        let hot: SliceW? = xs.filter { $0.name != "The rest" && SplitPick.hot($0, pace: pace) }
            .max { (SplitPick.gap($0, pace: pace) ?? 0) < (SplitPick.gap($1, pace: pace) ?? 0) }
        VStack(alignment: .leading, spacing: 0) {
            KHeader(title: "Where it went", sub: days)
            ZStack {
                SplitRing(xs: xs, line: 7.5)
                Text(WMoney.full(total)).font(.system(size: 13, weight: .semibold)).kerning(-0.4).monospacedDigit()
                    .foregroundStyle(KInk.ink).lineLimit(1).minimumScaleFactor(0.7).padding(.horizontal, 12).privacySensitive()
            }
            .frame(width: 80, height: 80)
            .frame(maxWidth: .infinity)
            .padding(.top, 6)
            Spacer(minLength: 2)
            Group {
                if let h = hot {
                    Text(h.name + " " + SplitPick.versus(h, pace: pace)).font(.system(size: 11.5, weight: .semibold)).foregroundStyle(KInk.warm)
                } else if let t = xs.first {
                    Text(t.name + " " + String(Int(safe: (SplitPick.share(t.v, total) * 100).rounded())) + "%").kSub()
                }
            }
            .lineLimit(1)
            .minimumScaleFactor(0.8)
            .frame(maxWidth: .infinity)
        }
    }
}

/// a category: its dot, its name, how it sits against a usual month, its figure; then a bar as long as its share of
/// the biggest
struct SplitRow: View {
    let s: SliceW
    let top: Double
    let pace: Double
    var body: some View {
        let vs: String = SplitPick.versus(s, pace: pace)
        let hot: Bool = SplitPick.hot(s, pace: pace)
        // the name and figure on one line, given the room; the bar under them with how it sits against a usual month
        // at its end, so nothing is cut short
        VStack(alignment: .leading, spacing: 5) {
            HStack(spacing: 7) {
                Circle().fill(s.color).frame(width: 7, height: 7)
                Text(s.name).font(.system(size: 12.5, weight: .medium)).foregroundStyle(KInk.ink).lineLimit(1).minimumScaleFactor(0.85)
                    .layoutPriority(1)
                Spacer(minLength: 4)
                Text(WMoney.full(s.v)).font(.system(size: 13, weight: .semibold)).kerning(-0.13).monospacedDigit()
                    .foregroundStyle(KInk.ink).lineLimit(1).fixedSize()
                    .privacySensitive()
            }
            HStack(spacing: 8) {
                ShareLine(share: SplitPick.share(s.v, top), color: s.color)
                if !vs.isEmpty { SplitChip(text: vs, hot: hot).fixedSize() }
            }
            .frame(height: 16)
        }
    }
}

/// "+32%" warm when it runs hot, else quiet on a faint wash
struct SplitChip: View {
    let text: String
    let hot: Bool
    var body: some View {
        Text(text)
            .font(.system(size: 10.5, weight: .semibold))
            .foregroundStyle(hot ? KInk.warm : KInk.quiet)
            .lineLimit(1)
            .padding(.horizontal, 6)
            .frame(height: 16)
            .background(hot ? KInk.warm.opacity(0.13) : KInk.faint, in: Capsule())
            .widgetAccentable(hot)
    }
}

/// a share as a bar in its colour on a faint track
struct ShareLine: View {
    let share: Double
    let color: Color
    var height: CGFloat = 4
    var body: some View {
        GeometryReader { g in
            ZStack(alignment: .leading) {
                Capsule().fill(KInk.faint)
                Capsule().fill(color).frame(width: max(height, g.size.width * CGFloat(min(1, max(0, share)))))
            }
        }
        .frame(height: height)
        .widgetAccentable()
    }
}

/// the ring with the total and the days inside; beside it the biggest four
struct SplitMedium: View {
    let xs: [SliceW]
    let days: String
    let pace: Double
    var body: some View {
        // (three rows: each is a name line and a bar line, and a fourth doesn't fit the medium widget's height)
        let rows: [SliceW] = Array(xs.filter { $0.name != "The rest" }.prefix(3))
        let top: Double = SplitPick.top(rows)
        HStack(spacing: 18) {
            ZStack {
                SplitRing(xs: xs, line: 7.5)
                VStack(spacing: 3) {
                    KAmount(v: SplitPick.total(xs), size: 18)
                    Text(days).kSub()
                }
                .padding(.horizontal, 14)
            }
            .frame(width: 118, height: 118)
            VStack(alignment: .leading, spacing: 0) {
                ForEach(Array(rows.enumerated()), id: \.element.id) { i, s in
                    if i > 0 { Spacer(minLength: 6) }
                    SplitRow(s: s, top: top, pace: pace)
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
    }
}
