import SwiftUI
import WidgetKit

// MARK: - Add: a cash spend in two taps, from the Home Screen or the Lock Screen
//
// The canvas "kosh widgets" › Add a spend is the reference: what it does in two lines, a + in the accent, and what
// today has spent so far beside it. On the Lock Screen, a + with "cash" under it.

struct AddWidget: Widget {
    let kind: String = "KoshAdd"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: KoshProvider()) { e in
            AddView(entry: e)
        }
        .configurationDisplayName("Add a spend")
        .description("Opens kosh straight to adding a cash spend: the amount, what it was, and whose.")
        .supportedFamilies([.systemSmall, .accessoryCircular])
    }
}

struct AddView: View {
    let entry: KEntry
    @Environment(\.widgetFamily) private var family
    var body: some View {
        KFrame(entry: entry, link: "add") {
            if family == .accessoryCircular {
                ZStack {
                    AccessoryWidgetBackground()
                    VStack(spacing: 2) {
                        Image(systemName: "plus").font(.system(size: 22, weight: .medium))
                        Text("cash").font(.system(size: 10, weight: .semibold)).foregroundStyle(.secondary)
                    }
                }
                .accessibilityElement(children: .ignore)
                .accessibilityLabel("Add a cash spend")
            } else {
                AddSmall(entry: entry)
            }
        }
    }
}

/// the + in a circle of the accent
struct AddMark: View {
    var body: some View {
        Image(systemName: "plus")
            .font(.system(size: 20, weight: .semibold))
            .foregroundStyle(Color.dyn("#0E1430", "#FFFFFF"))
            .frame(width: 52, height: 52)
            .background(Color.kosh, in: Circle())
            .widgetAccentable()
    }
}

struct AddSmall: View {
    let entry: KEntry
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            KHeader(title: "Add a spend", sub: "Cash, in two taps")
            Spacer(minLength: 0)
            HStack(alignment: .bottom) {
                AddMark()
                Spacer(minLength: 6)
                if let spent = AddSmall.today(entry) {
                    VStack(alignment: .trailing, spacing: 1) {
                        Text("Today").kSub()
                        Text(WMoney.full(spent))
                            .font(.system(size: 11.5, weight: .semibold)).monospacedDigit()
                            .foregroundStyle(KInk.ink).lineLimit(1)
                            .privacySensitive()
                    }
                }
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
        .accessibilityElement(children: .combine)
        .accessibilityLabel("Add a cash spend")
    }
    /// what today has spent so far, when kosh has today's figures
    static func today(_ e: KEntry) -> Double? {
        guard let f = e.feed, !f.empty, f.today == e.today else { return nil }
        return f.month.today
    }
}
