import SwiftUI
import WidgetKit

// MARK: - This month: what's left to spend, a day at a time, and whether the month is running ahead of a usual one
//
// The canvas "kosh widgets" › This month is the reference. Small: left to spend for the days still to come, what that
// is a day, and the budget as one bar. Medium: the same on the left; on the right what's spent so far against a usual
// month, and the month as a row of daily ticks. Lock Screen: an open dial of what's left, a line with the bar, a line
// of words.

struct MonthWidget: Widget {
    let kind: String = "KoshMonth"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: KoshProvider()) { e in
            MonthView(entry: e)
        }
        .configurationDisplayName("This month")
        .description("Left to spend, today's spending, and whether the month is running ahead of the calendar.")
        .supportedFamilies([.systemSmall, .systemMedium, .accessoryCircular, .accessoryRectangular, .accessoryInline])
    }
}

/// the month's figures as the widget reads them
struct MonthMath {
    let mo: WFMonth
    let day: Int
    init(_ mo: WFMonth, today: String) {
        self.mo = mo
        var d: Int = mo.d
        if String(today.prefix(7)) == mo.m { d = max(d, WDay.dayNumber(today)) }
        self.day = min(max(1, d), max(1, mo.dim))
    }
    /// "Oct"
    var short: String { mo.short.isEmpty ? WDay.fmt(mo.m + "-01", "MMM") : mo.short }
    /// a budget is set (yours, or the usual month kosh set for you)
    var showsLeft: Bool { mo.budget > 0 }
    var over: Bool { showsLeft && mo.left < 0 }
    /// the days still to come after today, and the dates they cover ("25–31 Oct"; the last day, "Today, 31 Oct")
    var daysLeft: Int { max(0, mo.dim - day) }
    var leftRange: String {
        if daysLeft == 0 { return "Today, " + String(day) + " " + short }
        if daysLeft == 1 { return String(mo.dim) + " " + short }
        return String(day + 1) + "–" + String(mo.dim) + " " + short
    }
    /// the days so far ("1–24 Oct"; on the first, "1 Oct")
    var soFarRange: String { day <= 1 ? "1 " + short : "1–" + String(day) + " " + short }
    var wholeRange: String { "1–" + String(mo.dim) + " " + short }
    /// what's left, a day
    var perDay: Double { max(0, mo.left) / Double(max(1, daysLeft)) }
    /// the bar's measure: the budget, else where the month is heading
    var target: Double {
        if mo.budget > 0 { return mo.budget }
        return max(mo.likely, mo.usual, mo.spent)
    }
    var spentShare: Double { target > 0 ? mo.spent / target : 0 }
    /// what's still to go out this month (the budget less what's spent and what's left), as a share of it
    var dueShare: Double {
        guard showsLeft else { return 0 }
        let due: Double = mo.budget - mo.spent - mo.left
        return max(0, due) / mo.budget
    }
    /// how far through the month today is
    var pace: Double { Double(day) / Double(max(1, mo.dim)) }
    /// what's left of the budget, free to spend, as a share of it
    var leftShare: Double { showsLeft ? max(0, mo.left) / mo.budget : 0 }
    /// against a usual month by this day: −10 is 10% below, +32 above (nil when kosh doesn't know a usual month)
    var vsUsual: Int? {
        let soFar: Double = mo.usual * pace
        guard mo.usual > 0, soFar > 0 else { return nil }
        return Int(safe: ((mo.spent / soFar - 1) * 100).rounded())
    }
    /// "10% below a usual October", "32% above a usual October", "Like a usual October"
    var usualLine: (text: String, kind: KPill.Kind)? {
        guard let g = vsUsual else { return nil }
        if abs(g) < 3 { return ("Like a usual " + mo.name, .cool) }
        if g < 0 { return (String(-g) + "% below a usual " + mo.name, .good) }
        return (String(g) + "% above a usual " + mo.name, .warm)
    }
    /// the label and its dates
    var title: String {
        if !showsLeft { return "Spent" }
        return over ? "Over budget" : "Left to spend"
    }
    var titleSub: String {
        if !showsLeft { return soFarRange }
        return over ? wholeRange : leftRange
    }
    /// the big figure, and its colour
    var heroValue: Double {
        if !showsLeft { return mo.spent }
        return abs(mo.left)
    }
    var heroInk: Color { over ? KInk.warm : KInk.ink }
    /// "₹40,250 spent" / "of ₹60k" under the bar
    var axisLead: String { WMoney.full(mo.spent) + (showsLeft ? " spent" : " so far") }
    var axisTail: String { showsLeft ? "of " + WMoney.tight(mo.budget) : WMoney.tight(mo.likely) + " likely" }
    /// the Lock Screen's line of words
    var inlineLine: String {
        if !showsLeft { return WMoney.full(mo.spent) + " spent, " + soFarRange }
        if over { return WMoney.full(-mo.left) + " over budget, " + short }
        return WMoney.full(mo.left) + " left, " + leftRange
    }
}

struct MonthView: View {
    let entry: KEntry
    @Environment(\.widgetFamily) private var family
    var body: some View {
        KFrame(entry: entry, link: "month") {
            content
        }
    }
    @ViewBuilder var content: some View {
        if let f = entry.feed, !f.empty, !entry.stale {
            let m: MonthMath = MonthMath(f.month, today: entry.today)
            switch family {
            case .accessoryCircular: MonthCircular(m: m)
            case .accessoryRectangular: MonthRect(m: m)
            case .accessoryInline: MonthInline(m: m)
            case .systemMedium: MonthMedium(m: m)
            default: MonthSmall(m: m)
            }
        } else {
            MonthWaiting(entry: entry)
        }
    }
}

struct MonthWaiting: View {
    let entry: KEntry
    @Environment(\.widgetFamily) private var family
    var body: some View {
        let line: String = entry.stale ? KCopy.staleLine(entry) : KCopy.openLine
        switch family {
        case .accessoryCircular:
            ZStack {
                AccessoryWidgetBackground()
                Image(systemName: "indianrupeesign").font(.title3.weight(.semibold))
            }
        case .accessoryRectangular, .accessoryInline:
            Text(entry.stale ? "Open kosh for the new month" : "Open kosh")
        default:
            KEmpty(sym: "calendar", title: entry.stale ? "A new month" : KCopy.openTitle, line: line)
        }
    }
}

/// "₹1,535 a day", the figure in the ink and semibold, the words quiet; over budget or without one, what's spent
struct MonthDayLine: View {
    let m: MonthMath
    var long: Bool = false
    var body: some View {
        Group {
            if m.over {
                let figure: Text = Text(WMoney.full(m.mo.spent)).fontWeight(.semibold).foregroundStyle(KInk.ink)
                Text("\(figure) spent of \(WMoney.full(m.mo.budget))")
            } else if !m.showsLeft {
                let figure: Text = Text(WMoney.full(m.mo.likely)).fontWeight(.semibold).foregroundStyle(KInk.ink)
                Text("\(figure) likely by \(m.mo.dim) \(m.short)")
            } else if m.daysLeft == 0 {
                Text("left for today")
            } else {
                let figure: Text = Text(WMoney.full(m.perDay)).fontWeight(.semibold).foregroundStyle(KInk.ink)
                if long {
                    Text("\(figure) a day keeps \(m.mo.name) in budget")
                } else {
                    Text("\(figure) a day")
                }
            }
        }
        .font(.system(size: 11.5))
        .foregroundStyle(KInk.quiet)
        .lineLimit(long ? 2 : 1)
        .minimumScaleFactor(0.85)
        .fixedSize(horizontal: false, vertical: true)
        .privacySensitive()
    }
}

/// the budget as one bar: spent, still to go out, and a tick where the calendar is
struct MonthBar: View {
    let m: MonthMath
    var body: some View {
        KBudgetBar(spent: m.spentShare, due: m.dueShare, calendar: m.pace)
    }
}

/// what's left: the label and its dates, the figure, what that is a day
struct MonthLeft: View {
    let m: MonthMath
    var size: CGFloat = 30
    var long: Bool = false
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            KHeader(title: m.title, sub: m.titleSub)
            KAmount(v: m.heroValue, size: size, color: m.heroInk)
                .padding(.top, size > 31 ? 14 : 12)
            MonthDayLine(m: m, long: long)
                .padding(.top, 5)
        }
    }
}

struct MonthSmall: View {
    let m: MonthMath
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            MonthLeft(m: m)
            Spacer(minLength: 6)
            MonthBar(m: m)
            HStack {
                Text(m.axisLead)
                Spacer(minLength: 4)
                Text(m.axisTail)
            }
            .font(.system(size: 10.5))
            .foregroundStyle(KInk.quiet)
            .monospacedDigit()
            .lineLimit(1)
            .minimumScaleFactor(0.8)
            .padding(.top, 4)
            .privacySensitive()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
    }
}

struct MonthMedium: View {
    let m: MonthMath
    var body: some View {
        HStack(alignment: .top, spacing: 18) {
            VStack(alignment: .leading, spacing: 0) {
                MonthLeft(m: m, size: 34, long: true)
                Spacer(minLength: 6)
                MonthBar(m: m)
            }
            .frame(width: 146)
            .frame(maxHeight: .infinity, alignment: .topLeading)
            MonthSoFar(m: m)
        }
    }
}

/// the right of the medium: what's spent so far against a usual month, then the month in daily ticks
struct MonthSoFar: View {
    let m: MonthMath
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack(alignment: .firstTextBaseline) {
                Text("Spent, " + m.soFarRange).kSub()
                Spacer(minLength: 4)
                KRowAmount(v: m.mo.spent)
            }
            if let u = m.usualLine {
                KPill(text: u.text, kind: u.kind)
                    .padding(.top, 6)
                    .privacySensitive()
            }
            Spacer(minLength: 6)
            KTicks(days: m.mo.days, total: m.mo.dim, height: 60, width: 4)
            MonthAxis(m: m)
                .padding(.top, 6)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
    }
}

/// under the ticks: the month's first day, "Today" under today's tick, its last
struct MonthAxis: View {
    let m: MonthMath
    var body: some View {
        GeometryReader { g in
            let w: CGFloat = g.size.width
            let n: Int = max(1, m.mo.dim)
            // (where today's tick sits: the ticks spread across the row, the first at the left edge, the last at the right)
            let x: CGFloat = n > 1 ? (w - 4) * CGFloat(m.day - 1) / CGFloat(n - 1) + 2 : w / 2
            let mid: CGFloat = min(max(x, 52), w - 34)
            ZStack(alignment: .topLeading) {
                Text("1 " + m.short).foregroundStyle(KInk.quiet)
                Text(String(m.mo.dim)).foregroundStyle(KInk.quiet)
                    .frame(width: w, alignment: .trailing)
                Text("Today").fontWeight(.semibold).foregroundStyle(Color.kosh)
                    .frame(width: 40)
                    .position(x: mid, y: 6)
                    .widgetAccentable()
            }
        }
        .font(.system(size: 10.5))
        .monospacedDigit()
        .lineLimit(1)
        .frame(height: 13)
    }
}

/// a Lock Screen dial: an open arc of what's left of the budget, the share in the middle
struct MonthCircular: View {
    let m: MonthMath
    var body: some View {
        let share: Double = m.showsLeft ? m.leftShare : min(1, m.spentShare)
        let pct: Int = Int(safe: (share * 100).rounded())
        ZStack {
            AccessoryWidgetBackground()
            Circle().trim(from: 0, to: 0.75)
                .stroke(Color.primary.opacity(0.28), style: StrokeStyle(lineWidth: 5, lineCap: .round))
                .rotationEffect(.degrees(135))
                .padding(5)
            Circle().trim(from: 0, to: max(0.001, 0.75 * share))
                .stroke(Color.primary, style: StrokeStyle(lineWidth: 5, lineCap: .round))
                .rotationEffect(.degrees(135))
                .padding(5)
                .widgetAccentable()
            VStack(spacing: 1) {
                Text(m.showsLeft ? String(pct) + "%" : WMoney.tight(m.mo.spent))
                    .font(.system(size: m.showsLeft ? 18 : 13, weight: .semibold))
                    .lineLimit(1).minimumScaleFactor(0.6)
                    .privacySensitive()
                Text(m.showsLeft ? (m.over ? "over" : "left") : "spent")
                    .font(.system(size: 10, weight: .semibold))
                    .foregroundStyle(.secondary)
            }
            .padding(.horizontal, 10)
        }
        .accessibilityElement(children: .combine)
    }
}

/// a Lock Screen line: the label with its dates, the figure, and the bar of what's spent
struct MonthRect: View {
    let m: MonthMath
    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(m.title + ", " + m.titleSub)
                .font(.system(size: 12, weight: .semibold))
                .foregroundStyle(.secondary)
                .lineLimit(1)
            KAmount(v: m.heroValue, size: 22, color: .primary)
            GeometryReader { g in
                ZStack(alignment: .leading) {
                    Capsule().fill(Color.primary.opacity(0.25))
                    Capsule().fill(Color.primary).frame(width: max(4, g.size.width * CGFloat(min(1, m.spentShare))))
                        .widgetAccentable()
                }
            }
            .frame(height: 4)
        }
    }
}

struct MonthInline: View {
    let m: MonthMath
    var body: some View {
        Label(m.inlineLine, systemImage: "clock")
            .privacySensitive()
    }
}
