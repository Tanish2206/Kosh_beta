import SwiftUI
import WidgetKit

// MARK: - A chapter, on paper: the trip or occasion under way, coming up, or just back from

struct ChapterWidget: Widget {
    let kind: String = "KoshChapter"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: KoshProvider()) { e in
            ChapterView(entry: e)
        }
        .configurationDisplayName("Chapter")
        .description("The trip or occasion under way or coming up: how far off it is, and what it has spent against its budget.")
        .supportedFamilies([.systemSmall, .systemMedium, .accessoryCircular, .accessoryRectangular])
    }
}

/// the chapter as the widget reads it on a given day
struct ChapterMath {
    let c: WFChapter
    let today: String
    var dated: Bool { !c.from.isEmpty }
    var end: String { c.to.isEmpty ? c.from : c.to }
    /// soon, now or done, by the day this entry draws (the feed may be a day or two old)
    var state: String {
        if !dated { return c.state }
        if today < c.from { return "soon" }
        if today > end { return "done" }
        return "now"
    }
    var length: Int { dated ? max(1, WDay.between(c.from, end) + 1) : max(1, c.days) }
    var daysTo: Int { dated ? WDay.between(today, c.from) : 0 }
    var dayOf: Int { dated ? min(length, WDay.between(c.from, today) + 1) : 0 }
    var sinceEnd: Int { dated ? WDay.between(end, today) : 0 }
    /// "in 17 days", "day 3 of 5", "just back"
    var when: String {
        switch state {
        case "soon":
            if daysTo <= 0 { return "today" }
            if daysTo == 1 { return "tomorrow" }
            return "in " + String(daysTo) + " days"
        case "now":
            return "day " + String(dayOf) + " of " + String(length)
        case "done":
            if sinceEnd <= 3 { return "just back" }
            return "back " + String(sinceEnd) + " days"
        default:
            return ""
        }
    }
    /// "Chapter", "Occasion"
    var lead: String { c.event ? "Occasion" : "Chapter" }
    /// the pill: "In 17 days", "Day 3 of 5", "Just back"
    var pill: String { when.isEmpty ? lead : when.prefix(1).uppercased() + String(when.dropFirst()) }
    /// "12–16 Nov", "12 Nov"
    var dates: String {
        if !dated { return "" }
        if end == c.from { return WDay.fmt(c.from, "d MMM") }
        let sameMonth: Bool = c.from.prefix(7) == end.prefix(7)
        let a: String = sameMonth ? WDay.fmt(c.from, "d") : WDay.fmt(c.from, "d MMM")
        return a + "–" + WDay.fmt(end, "d MMM")
    }
    var share: Double {
        if c.budget <= 0 { return 0 }
        return min(1, c.total / c.budget)
    }
    var over: Bool { c.budget > 0 && c.total > c.budget }
    /// "12–16 Nov, 4 days"
    var datesAndLength: String {
        let n: String = String(length) + (length == 1 ? " day" : " days")
        return dates.isEmpty ? n : dates + ", " + n
    }
    /// "Tue 10 Nov to Fri 13 Nov, 4 days"
    var longDates: String {
        let n: String = String(length) + (length == 1 ? " day" : " days")
        if !dated { return n }
        if end == c.from { return WDay.fmt(c.from, "EEE d MMM") + ", " + n }
        return WDay.fmt(c.from, "EEE d MMM") + " to " + WDay.fmt(end, "EEE d MMM") + ", " + n
    }
    /// what the figure is: booked ahead of it, spent so far, spent
    var spentWord: String {
        switch state {
        case "soon": return "Booked so far"
        case "now": return "Spent so far"
        default: return "Spent"
        }
    }
    /// the line under the bar: what's left of the budget, or how far over
    var leftLine: String {
        guard c.budget > 0 else { return "" }
        let left: Double = c.budget - c.total
        if left < 0 { return WMoney.full(-left) + " over the budget" }
        switch state {
        case "soon": return WMoney.full(left) + " of the budget still to plan"
        case "now": return WMoney.full(left) + " of the budget left"
        default: return WMoney.full(left) + " under the budget"
        }
    }
    /// the stub's big figure and its words: "17" "days to go", "3" "of 5 days", "back" ""
    var stub: (String, String) {
        switch state {
        case "soon": return daysTo <= 0 ? ("Today", "it starts") : (String(daysTo), daysTo == 1 ? "day to go" : "days to go")
        case "now": return (String(dayOf), "of " + String(length) + (length == 1 ? " day" : " days"))
        default: return (sinceEnd <= 3 ? "Back" : String(sinceEnd), sinceEnd <= 3 ? "just now" : "days back")
        }
    }
    /// the Lock Screen's small word under the count: the first day, or the last
    var tiny: String {
        if !dated { return "" }
        switch state {
        case "soon": return WDay.fmt(c.from, "d MMM")
        case "now": return "of " + String(length)
        default: return WDay.fmt(end, "d MMM")
        }
    }
    /// lock screen: "17d", "3/5", "₹21k"
    var short: String {
        switch state {
        case "soon": return daysTo <= 0 ? "now" : String(daysTo) + "d"
        case "now": return String(dayOf) + "/" + String(length)
        default: return WMoney.tight(c.total)
        }
    }
}

/// the chapter's own colour, softened for the night and deepened for the day: the stamp, the pill, the budget line
fileprivate func chapterInk(_ c: WFChapter) -> Color { Color.soft(c.color.isEmpty ? "#9A4A1E" : c.color) }

struct ChapterView: View {
    let entry: KEntry
    @Environment(\.widgetFamily) private var family
    var body: some View {
        KFrame(entry: entry, link: "chapters") {
            if let c = entry.feed?.chapter {
                let m: ChapterMath = ChapterMath(c: c, today: entry.today)
                switch family {
                case .accessoryCircular: ChapterCircular(m: m)
                case .accessoryRectangular: ChapterRect(m: m)
                case .systemMedium: ChapterMedium(m: m)
                default: ChapterSmall(m: m)
                }
            } else {
                switch family {
                case .accessoryCircular:
                    ZStack {
                        AccessoryWidgetBackground()
                        Image(systemName: "bookmark")
                    }
                case .accessoryRectangular:
                    Text("No chapter coming up")
                default:
                    ChapterNone()
                }
            }
        }
    }
}

/// a passport stamp: a dashed ring, a fine ring inside, the chapter's mark in the middle
struct ChapterStamp: View {
    let sym: String
    let ink: Color
    var size: CGFloat = 46
    var body: some View {
        let k: CGFloat = size / 56
        ZStack {
            Circle()
                .stroke(ink, style: StrokeStyle(lineWidth: 1.5 * k, dash: [3 * k, 3 * k]))
                .padding(2 * k)
            Circle()
                .stroke(ink, lineWidth: 1 * k)
                .padding(7 * k)
            Image(systemName: KGlyph.outline(sym.isEmpty ? "airplane" : sym))
                .font(.system(size: size * 0.3, weight: .regular))
                .foregroundStyle(ink)
        }
        .frame(width: size, height: size)
        .widgetAccentable()
    }
}

/// a fine line of the budget, in the chapter's colour (warm once it's over)
struct ChapterBar: View {
    let m: ChapterMath
    let ink: Color
    var body: some View {
        GeometryReader { g in
            ZStack(alignment: .leading) {
                Capsule().fill(KInk.faint)
                Capsule().fill(m.over ? KInk.warm : ink).frame(width: max(3, g.size.width * CGFloat(m.share)))
                    .widgetAccentable()
            }
        }
        .frame(height: 4)
    }
}

/// "₹21,800 of ₹90,000": the figure in the ink, the budget quiet
struct ChapterOf: View {
    let m: ChapterMath
    var size: CGFloat = 11.5
    var body: some View {
        let spent: Text = Text(WMoney.full(m.c.total)).font(.system(size: size, weight: .semibold)).foregroundStyle(KInk.ink)
        let of: Text = Text(m.c.budget > 0 ? " of " + WMoney.full(m.c.budget) : " spent").font(.system(size: size, weight: .medium)).foregroundStyle(KInk.quiet)
        Text("\(spent)\(of)").monospacedDigit().lineLimit(1).minimumScaleFactor(0.8).privacySensitive()
    }
}

/// the stamp and how far off it is, the chapter's name and days, then what it has spent of its budget
struct ChapterSmall: View {
    let m: ChapterMath
    var body: some View {
        let ink: Color = chapterInk(m.c)
        VStack(alignment: .leading, spacing: 0) {
            HStack(alignment: .top) {
                ChapterStamp(sym: m.c.sym, ink: ink, size: 46)
                Spacer(minLength: 4)
                Text(m.pill)
                    .font(.system(size: 11, weight: .semibold)).foregroundStyle(ink).lineLimit(1)
                    .padding(.horizontal, 8).frame(height: 20)
                    .background(ink.opacity(0.14), in: Capsule())
                    .widgetAccentable()
            }
            Text(m.c.name).kName().lineLimit(2).padding(.top, 10)
            Text(m.datesAndLength).kSub().padding(.top, 2)
            Spacer(minLength: 4)
            if m.c.budget > 0 { ChapterBar(m: m, ink: ink) }
            ChapterOf(m: m).padding(.top, 5)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

/// a ticket: the stub with the stamp and the days to go, a dashed tear, then the chapter, its dates and its budget
struct ChapterMedium: View {
    let m: ChapterMath
    var body: some View {
        let ink: Color = chapterInk(m.c)
        let stub: (String, String) = m.stub
        HStack(spacing: 0) {
            VStack(spacing: 8) {
                ChapterStamp(sym: m.c.sym, ink: ink, size: 62)
                VStack(spacing: 0) {
                    Text(stub.0).font(.system(size: 22, weight: .semibold)).kerning(-0.7).monospacedDigit()
                        .foregroundStyle(ink).lineLimit(1).minimumScaleFactor(0.6).widgetAccentable()
                    Text(stub.1).kSub()
                }
            }
            .frame(width: 96)
            Line()
                .stroke(KInk.hair, style: StrokeStyle(lineWidth: 1.5, dash: [4, 3]))
                .frame(width: 1.5)
                .padding(.vertical, -16)
                .padding(.horizontal, 6)
            VStack(alignment: .leading, spacing: 0) {
                Text(m.lead).kSub()
                Text(m.c.name).font(.system(size: 17, weight: .medium)).foregroundStyle(KInk.ink).lineLimit(1).minimumScaleFactor(0.8).padding(.top, 2)
                Text(m.longDates).kSub().padding(.top, 2)
                Spacer(minLength: 4)
                HStack(alignment: .firstTextBaseline) {
                    Text(m.spentWord).kSub()
                    Spacer(minLength: 4)
                    ChapterOf(m: m, size: 13)
                }
                .padding(.bottom, 6)
                if m.c.budget > 0 {
                    ChapterBar(m: m, ink: ink)
                    Text(m.leftLine).kSub(m.over ? KInk.warm : KInk.quiet).padding(.top, 5).privacySensitive()
                }
            }
            .padding(.leading, 8)
        }
    }
}

/// a straight line down the middle of its frame: the ticket's tear
fileprivate struct Line: Shape {
    func path(in r: CGRect) -> Path {
        var p = Path()
        p.move(to: CGPoint(x: r.midX, y: r.minY))
        p.addLine(to: CGPoint(x: r.midX, y: r.maxY))
        return p
    }
}

struct ChapterNone: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 3) {
            Text("Chapter").kLabel()
            Spacer(minLength: 0)
            Text("Nothing coming up").kName()
            Text("Trips and occasions appear here as they near.").font(.system(size: 11.5)).foregroundStyle(KInk.quiet).lineLimit(3)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .leading)
    }
}

/// the Lock Screen's stamp: a dashed ring, the days to go, the first day under it
struct ChapterCircular: View {
    let m: ChapterMath
    var body: some View {
        ZStack {
            AccessoryWidgetBackground()
            Circle().stroke(style: StrokeStyle(lineWidth: 1.5, dash: [3, 4])).padding(2)
            Circle().stroke(Color.primary.opacity(0.5), lineWidth: 1).padding(7)
            VStack(spacing: 2) {
                Text(m.short).font(.system(size: 18, weight: .semibold)).kerning(-0.5).monospacedDigit().lineLimit(1).minimumScaleFactor(0.6)
                if !m.tiny.isEmpty {
                    Text(m.tiny).font(.system(size: 10, weight: .semibold)).foregroundStyle(.secondary).lineLimit(1).minimumScaleFactor(0.7)
                }
            }
            .padding(.horizontal, 8)
        }
        .widgetAccentable()
    }
}

/// the Lock Screen's line: the chapter, how far off and when, and its budget as a fine bar
struct ChapterRect: View {
    let m: ChapterMath
    var body: some View {
        VStack(alignment: .leading, spacing: 3) {
            Text(m.c.name).font(.system(size: 12, weight: .semibold)).foregroundStyle(.secondary).lineLimit(1)
            Text(m.pill + (m.dates.isEmpty ? "" : ", " + m.dates)).font(.system(size: 13, weight: .semibold)).lineLimit(1).minimumScaleFactor(0.8)
            if m.c.budget > 0 {
                GeometryReader { g in
                    ZStack(alignment: .leading) {
                        Capsule().fill(Color.primary.opacity(0.25))
                        Capsule().fill(Color.primary).frame(width: max(3, g.size.width * CGFloat(m.share))).widgetAccentable()
                    }
                }
                .frame(height: 4)
                .padding(.top, 3)
            } else {
                Text(WMoney.full(m.c.total) + " spent").font(.system(size: 11.5, weight: .medium)).foregroundStyle(.secondary).privacySensitive()
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}
