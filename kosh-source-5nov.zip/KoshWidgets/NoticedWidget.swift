import SwiftUI
import WidgetKit

// MARK: - kosh noticed: one thing at a time about how the money moves, a new one each hour
//
// A small four-point star and "kosh noticed" in the accent, the sentence big with its figures picked out (warm when
// it's a warning, green when it's good news), and a Next button. (The canvas "kosh widgets", board kosh noticed.)

struct NoticedWidget: Widget {
    let kind: String = "KoshNoticed"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: KoshProvider(rotate: true)) { e in
            NoticedView(entry: e)
        }
        .configurationDisplayName("kosh noticed")
        .description("A habit, a price that went up, a category running hot: a new one each hour. Tap the arrow for the next.")
        .supportedFamilies([.systemSmall, .systemMedium])
    }
}

enum NoticedPick {
    /// what kosh noticed, or, before it has noticed anything, what the month itself says
    static func notes(_ f: WFeed) -> [WFNote] {
        if !f.noticed.isEmpty { return f.noticed }
        var out: [WFNote] = []
        if let top = f.cats.first, f.month.spent > 0 {
            let share: Int = Int(safe: (top.v / f.month.spent * 100).rounded())
            out.append(WFNote(id: "top", title: "Most of " + f.month.name + " went on " + top.name.lowercased(),
                              detail: WMoney.full(top.v) + " so far, " + String(share) + "% of the month's spending.",
                              sym: top.sym, color: top.color, tone: "info", amount: top.v))
        }
        if f.owedIn > 0 {
            out.append(WFNote(id: "owed", title: WMoney.full(f.owedIn) + " is owed to you",
                              detail: "From splits and loans to people, not yet back.", sym: "arrow.uturn.backward.circle.fill",
                              color: "#34C759", tone: "good", amount: f.owedIn))
        }
        if let d = f.due.first(where: { !$0.incoming && $0.date != nil }) {
            out.append(WFNote(id: "due", title: d.name + " is next to pay",
                              detail: WMoney.full(d.amt) + ", " + WDay.label(d.date ?? f.today, today: f.today).lowercased() + ".",
                              sym: d.sym, color: d.color, tone: "info", amount: d.amt))
        }
        return out
    }
    /// the days kosh looked at: this month so far, "1–24 Oct"
    static func days(_ f: WFeed) -> String {
        let first: String = f.month.m + "-01"
        let d: Int = max(1, f.month.d)
        if d == 1 { return WDay.fmt(first, "d MMM") }
        return "1–" + String(d) + " " + WDay.fmt(first, "MMM")
    }
    /// a note's figures: warm for a warning (spending up), green for good news (spending down), else the accent
    static func ink(_ n: WFNote) -> Color {
        switch n.tone {
        case "warn", "bad", "hot", "up": return KInk.warm
        case "good", "down": return KInk.good
        default: return Color.kosh
        }
    }
}

struct NoticedView: View {
    let entry: KEntry
    @Environment(\.widgetFamily) private var family
    var body: some View {
        let notes: [WFNote] = entry.feed.map { NoticedPick.notes($0) } ?? []
        let i: Int = notes.isEmpty ? 0 : ((entry.note % notes.count) + notes.count) % notes.count
        let days: String = entry.feed.map { NoticedPick.days($0) } ?? ""
        KFrame(entry: entry, link: "noticed") {
            if notes.isEmpty {
                KEmpty(sym: "sparkles", title: entry.feed == nil ? KCopy.openTitle : "Nothing new yet",
                       line: "kosh points out habits and changes here as it learns your months.")
            } else if family == .systemMedium {
                NoticedMedium(n: notes[i], index: i, count: notes.count, days: days)
            } else {
                NoticedSmall(n: notes[i], count: notes.count, days: days)
            }
        }
    }
}

/// kosh's four-point star
struct NoticedStar: Shape {
    func path(in r: CGRect) -> Path {
        let c: CGPoint = CGPoint(x: r.midX, y: r.midY)
        let a: CGFloat = r.width / 2
        // (pinched toward the middle: the curves meet at 40% of the way out)
        let k: CGFloat = a * 0.18
        var p = Path()
        p.move(to: CGPoint(x: c.x, y: c.y - a))
        p.addQuadCurve(to: CGPoint(x: c.x + a, y: c.y), control: CGPoint(x: c.x + k, y: c.y - k))
        p.addQuadCurve(to: CGPoint(x: c.x, y: c.y + a), control: CGPoint(x: c.x + k, y: c.y + k))
        p.addQuadCurve(to: CGPoint(x: c.x - a, y: c.y), control: CGPoint(x: c.x - k, y: c.y + k))
        p.addQuadCurve(to: CGPoint(x: c.x, y: c.y - a), control: CGPoint(x: c.x - k, y: c.y - k))
        p.closeSubpath()
        return p
    }
}

/// "kosh noticed", with the star, in the accent
struct NoticedLabel: View {
    var body: some View {
        HStack(spacing: 6) {
            NoticedStar().fill(Color.kosh).frame(width: 12, height: 12)
            Text("kosh noticed").font(.system(size: 12, weight: .semibold)).foregroundStyle(Color.kosh).lineLimit(1)
        }
        .widgetAccentable()
    }
}

/// what kosh noticed, set big, the figures in it picked out in the note's colour
struct NoteLine: View {
    let title: String
    let ink: Color
    var size: CGFloat = 15
    var body: some View {
        Self.styled(title, size: size, ink: ink)
            .lineSpacing(size * 0.2)
            .privacySensitive()
    }
    static func styled(_ s: String, size: CGFloat, ink: Color) -> Text {
        var out: Text = Text("")
        let words: [Substring] = s.split(separator: " ", omittingEmptySubsequences: false)
        for (i, w) in words.enumerated() {
            let word: String = String(w) + (i < words.count - 1 ? " " : "")
            let figure: Bool = w.contains(where: { $0.isNumber }) || w.contains("₹") || w.contains("%")
            let piece: Text = Text(word).font(.system(size: size, weight: .semibold)).kerning(-size * 0.015)
                .foregroundStyle(figure ? ink : KInk.ink)
            out = Text("\(out)\(piece)")
        }
        return out
    }
}

/// → : the next thing kosh noticed; "Next →" when there's room for the word
struct NextButton: View {
    var word: Bool = false
    var body: some View {
        Button(intent: NextNoteIntent()) {
            HStack(spacing: 6) {
                if word { Text("Next").font(.system(size: 12, weight: .semibold)) }
                Image(systemName: "arrow.right").font(.system(size: 11, weight: .semibold))
            }
            .foregroundStyle(KInk.ink)
            .padding(.horizontal, word ? 12 : 0)
            .frame(minWidth: 32, minHeight: 32)
            .background(KInk.faint, in: Capsule())
        }
        .buttonStyle(.plain)
        .accessibilityLabel("Next thing kosh noticed")
    }
}

/// which of them this is: a dot each, this one in the accent
struct NoteDots: View {
    let index: Int
    let count: Int
    var body: some View {
        HStack(spacing: 4) {
            ForEach(0..<min(count, 8), id: \.self) { k in
                Circle().fill(k == index ? Color.kosh : KInk.hair).frame(width: 5, height: 5)
            }
        }
        .accessibilityLabel(String(index + 1) + " of " + String(count))
    }
}

struct NoticedSmall: View {
    let n: WFNote
    let count: Int
    let days: String
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            NoticedLabel()
            NoteLine(title: n.title, ink: NoticedPick.ink(n), size: 15)
                .lineLimit(4)
                .minimumScaleFactor(0.85)
                .padding(.top, 9)
            Spacer(minLength: 6)
            HStack {
                Text(days).kSub()
                Spacer(minLength: 4)
                if count > 1 { NextButton() }
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

struct NoticedMedium: View {
    let n: WFNote
    let index: Int
    let count: Int
    let days: String
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack {
                NoticedLabel()
                Spacer(minLength: 4)
                if count > 1 { NoteDots(index: index, count: count) }
            }
            NoteLine(title: n.title, ink: NoticedPick.ink(n), size: 17)
                .lineLimit(2)
                .minimumScaleFactor(0.85)
                .padding(.top, 8)
            Text(n.detail)
                .font(.system(size: 12.5))
                .foregroundStyle(KInk.quiet)
                .lineLimit(2)
                .lineSpacing(1.5)
                .privacySensitive()
                .padding(.top, 5)
            Spacer(minLength: 2)
            HStack {
                Text(days).kSub()
                Spacer(minLength: 4)
                if count > 1 { NextButton(word: true) }
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}
