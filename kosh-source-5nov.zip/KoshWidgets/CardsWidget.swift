import SwiftUI
import WidgetKit

// MARK: - Cards: each card's spending this month and where its bill stands, on flat faces in the bank's colour

struct CardsWidget: Widget {
    let kind: String = "KoshCards"
    var body: some WidgetConfiguration {
        AppIntentConfiguration(kind: kind, intent: WhoIntent.self, provider: WhoProvider()) { e in
            CardsView(entry: e)
        }
        .configurationDisplayName("Cards")
        .description("Each card's spending this month, and when its bill is due.")
        .supportedFamilies([.systemSmall, .systemMedium, .systemLarge])
    }
}

enum CardsPick {
    static func of(_ f: WFeed, who: String) -> [WFCard] {
        if who == "family" { return f.cards }
        return f.cards.filter { $0.owner == who }
    }
    static func total(_ cs: [WFCard]) -> Double {
        var t: Double = 0
        for c in cs { t += c.month }
        return t
    }
    /// the next bill not yet paid, soonest first
    static func nextBill(_ cs: [WFCard], today: String) -> WFCard? {
        var best: WFCard? = nil
        for c in cs where !c.billPaid && (c.bill ?? 0) > 0 {
            guard let d = c.billDue, d >= WDay.add(today, -3) else { continue }
            if best == nil || d < (best?.billDue ?? "9999") { best = c }
        }
        return best
    }
    /// the card in front: the next bill's, else the busiest
    static func front(_ cs: [WFCard], today: String) -> WFCard {
        if let n = nextBill(cs, today: today) { return n }
        return cs[0]
    }
    /// the bill's day in a word: "in 6 days", "tomorrow", "2 Nov", "paid"
    static func billWhen(_ c: WFCard, today: String) -> String {
        guard let d = c.billDue, (c.bill ?? 0) > 0 else { return "" }
        if c.billPaid { return "paid" }
        if d < today { return "was due " + WDay.fmt(d, "d MMM") }
        let n: Int = WDay.between(today, d)
        if n == 0 { return "today" }
        if n == 1 { return "tomorrow" }
        if n <= 10 { return "in " + String(n) + " days" }
        return WDay.fmt(d, "d MMM")
    }
    /// "Bill ₹23,400 tomorrow", "Bill ₹7,840 paid", "No bill yet"
    static func billLine(_ c: WFCard, today: String) -> String {
        guard let b = c.bill, b > 0 else { return "No bill yet" }
        return "Bill " + WMoney.full(b) + " " + billWhen(c, today: today)
    }
    /// how the bill stands, for its pill: due (warm), paid (green), none yet (the accent)
    static func billPill(_ c: WFCard, today: String) -> (String, KPill.Kind) {
        guard let b = c.bill, b > 0 else { return ("No bill yet", .cool) }
        if c.billPaid {
            let day: String = c.billDue.map { " " + WDay.fmt($0, "d MMM") } ?? ""
            return (WMoney.full(b) + " paid" + day, .good)
        }
        return (WMoney.full(b) + " " + billWhen(c, today: today), .warm)
    }
    /// "Federal bill, due 25 Oct", "Canara bill, October", "Yes Bank bill"
    static func billLabel(_ c: WFCard) -> String {
        let short: String = shortBank(c.bank)
        guard let d = c.billDue, (c.bill ?? 0) > 0 else { return short + " bill" }
        if c.billPaid { return short + " bill, " + WDay.fmt(d, "MMMM") }
        return short + " bill, due " + WDay.fmt(d, "d MMM")
    }
    /// "Federal Bank" → "Federal"; a short name stays whole ("Yes Bank", "SBI")
    static func shortBank(_ bank: String) -> String {
        let words: [Substring] = bank.split(separator: " ")
        if words.count >= 2, words.last?.lowercased() == "bank", (words.first?.count ?? 0) > 3 { return String(words[0]) }
        return bank
    }
    /// the face's line: the bank, then the card's own name when it has one
    static func face(_ c: WFCard) -> String {
        c.name.isEmpty || c.name == c.bank ? c.bank : c.bank + " " + c.name
    }
}

/// "1–24 Oct": the month so far, the dates every figure here covers
fileprivate func soFar(_ today: String) -> String {
    let d: Int = WDay.dayNumber(today)
    let mon: String = WDay.fmt(today, "MMM")
    return d == 1 ? "1 " + mon : "1–" + String(d) + " " + mon
}

/// whose a card is, when it's someone else's in the household: "Asha's card"
fileprivate func whose(_ c: WFCard, _ f: WFeed?) -> String {
    guard c.owner != "me", let p = f?.people.first(where: { $0.id == c.owner }) else { return "" }
    return p.title + "'s card"
}

struct CardsView: View {
    let entry: KEntry
    @Environment(\.widgetFamily) private var family
    var body: some View {
        let cs: [WFCard] = entry.feed.map { CardsPick.of($0, who: entry.who) } ?? []
        KFrame(entry: entry, link: "cards") {
            if let f = entry.feed, !f.empty {
                if cs.isEmpty {
                    KEmpty(sym: "creditcard", title: "No cards yet", line: "Cards appear once their alerts reach your mail.")
                } else {
                    switch family {
                    case .systemLarge: CardsLarge(cards: cs, today: entry.today, feed: f)
                    case .systemMedium: CardsMedium(cards: cs, today: entry.today)
                    default: CardsSmall(cards: cs, today: entry.today)
                    }
                }
            } else {
                KEmpty(sym: "creditcard", title: KCopy.openTitle, line: KCopy.openLine)
            }
        }
    }
}

/// a card face, flat as the card itself: the bank's colour, a hairline edge, white type
struct CardFaceW: View {
    let c: WFCard
    var name: Bool = false
    var height: CGFloat = 64
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            VStack(alignment: .leading, spacing: 0) {
                Text(c.bank).font(.system(size: 11.5, weight: .semibold)).lineLimit(1)
                if name && !c.name.isEmpty && c.name != c.bank {
                    Text(c.name).font(.system(size: 11.5, weight: .medium)).opacity(0.86).lineLimit(1)
                }
            }
            Spacer(minLength: 2)
            HStack(alignment: .firstTextBaseline) {
                Text("••" + c.last).font(.system(size: 12, weight: .medium)).monospacedDigit().kerning(0.5).opacity(0.9)
                Spacer(minLength: 4)
                Text(c.network).font(.system(size: 11, weight: .bold)).opacity(0.92).lineLimit(1)
            }
        }
        .foregroundStyle(Color.white)
        .padding(.horizontal, 12).padding(.vertical, 10)
        .frame(height: height)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color(hex: c.color), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).strokeBorder(Color.white.opacity(0.16), lineWidth: 1))
        .widgetAccentable()
    }
}

/// the card in front: its face, what it spent this month, and its bill at the foot
struct CardsSmall: View {
    let cards: [WFCard]
    let today: String
    var body: some View {
        let c: WFCard = CardsPick.front(cards, today: today)
        let due: Bool = !c.billPaid && (c.bill ?? 0) > 0
        VStack(alignment: .leading, spacing: 0) {
            CardFaceW(c: c, height: 64)
            KAmount(v: c.month, size: 22).padding(.top, 10)
            Text("spent, " + soFar(today)).kSub().padding(.top, 3)
            Spacer(minLength: 2)
            Text(CardsPick.billLine(c, today: today))
                .font(.system(size: 11.5, weight: .semibold))
                .foregroundStyle(due ? KInk.warm : KInk.quiet)
                .lineLimit(1).minimumScaleFactor(0.8)
                .privacySensitive()
        }
    }
}

/// a card in the list: a small swatch of its colour, the bank and digits, this month's spending
struct CardRowW: View {
    let c: WFCard
    var body: some View {
        HStack(spacing: 10) {
            RoundedRectangle(cornerRadius: 4, style: .continuous)
                .fill(Color(hex: c.color))
                .overlay(RoundedRectangle(cornerRadius: 4, style: .continuous).strokeBorder(Color.white.opacity(0.16), lineWidth: 1))
                .frame(width: 24, height: 16)
                .widgetAccentable()
            Text(CardsPick.shortBank(c.bank) + " ••" + c.last).kName()
            Spacer(minLength: 4)
            KRowAmount(v: c.month)
        }
        .frame(height: 34)
    }
}

/// the next bill's card on the left, every card's month on the right
struct CardsMedium: View {
    let cards: [WFCard]
    let today: String
    var body: some View {
        let c: WFCard = CardsPick.front(cards, today: today)
        let due: Bool = !c.billPaid && (c.bill ?? 0) > 0
        let when: String = CardsPick.billWhen(c, today: today)
        HStack(alignment: .top, spacing: 16) {
            VStack(alignment: .leading, spacing: 0) {
                CardFaceW(c: c, name: true, height: 88)
                Spacer(minLength: 4)
                Text((c.bill ?? 0) > 0 ? (c.billPaid ? "Bill paid" : "Bill due " + when) : "No bill yet")
                    .font(.system(size: 11.5, weight: .semibold))
                    .foregroundStyle(due ? KInk.warm : KInk.quiet).lineLimit(1)
                if let b = c.bill, b > 0 { KRowAmount(v: b) }
            }
            .frame(width: 140)
            VStack(alignment: .leading, spacing: 0) {
                HStack(alignment: .firstTextBaseline) {
                    Text("Cards").kLabel()
                    Spacer(minLength: 4)
                    Text(soFar(today)).kSub()
                }
                .padding(.bottom, 2)
                ForEach(Array(cards.prefix(3)), id: \.id) { x in CardRowW(c: x) }
                Spacer(minLength: 0)
            }
        }
    }
}

/// a face in the deck: the bank and the card's name, its digits and network, what it spent this month
struct DeckFaceW: View {
    let c: WFCard
    let owner: String
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 2) {
                    Text(CardsPick.face(c)).font(.system(size: 11.5, weight: .semibold)).lineLimit(1)
                    HStack(spacing: 6) {
                        Text("••" + c.last).font(.system(size: 12, weight: .medium)).monospacedDigit().kerning(0.5).opacity(0.9)
                        Text(c.network).font(.system(size: 11, weight: .bold)).opacity(0.92)
                    }
                }
                Spacer(minLength: 6)
                VStack(alignment: .trailing, spacing: 0) {
                    Text(WMoney.full(c.month)).font(.system(size: 15, weight: .semibold)).monospacedDigit().kerning(-0.3).privacySensitive()
                    Text("this month").font(.system(size: 11)).opacity(0.86)
                }
            }
            Spacer(minLength: 0)
            if !owner.isEmpty { Text(owner).font(.system(size: 11)).opacity(0.86) }
        }
        .foregroundStyle(Color.white)
        .padding(.horizontal, 14).padding(.vertical, 12)
        .frame(height: 104)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color(hex: c.color), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).strokeBorder(Color.white.opacity(0.16), lineWidth: 1))
        .widgetAccentable()
    }
}

/// a bill's line under the deck: which card's and when, then where it stands on a pill
struct BillRowW: View {
    let c: WFCard
    let today: String
    var body: some View {
        let p: (String, KPill.Kind) = CardsPick.billPill(c, today: today)
        HStack {
            Text(CardsPick.billLabel(c)).kSub()
            Spacer(minLength: 6)
            KPill(text: p.0, kind: p.1).privacySensitive()
        }
        .frame(height: 28)
    }
}

/// the month's total, the deck of cards fanned like Wallet, then each card's bill
struct CardsLarge: View {
    let cards: [WFCard]
    let today: String
    let feed: WFeed
    var body: some View {
        let deck: [WFCard] = Array(cards.prefix(3))
        VStack(alignment: .leading, spacing: 0) {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 0) {
                    Text("Cards").kLabel()
                    Text("Spent this month, " + soFar(today)).kSub()
                }
                Spacer(minLength: 6)
                KAmount(v: CardsPick.total(cards), size: 22)
            }
            VStack(spacing: -52) {
                ForEach(Array(deck.enumerated()), id: \.element.id) { i, c in
                    DeckFaceW(c: c, owner: whose(c, feed))
                        .zIndex(Double(i))
                }
            }
            .padding(.top, 12)
            KHairline().padding(.top, 12).padding(.bottom, 4)
            ForEach(deck, id: \.id) { c in BillRowW(c: c, today: today) }
            Spacer(minLength: 0)
        }
    }
}
