import SwiftUI
import WidgetKit

// MARK: - The month in days: a calendar where each day is as deep as what it spent
//
// The canvas "kosh widgets" › Month in days is the reference. Sunday first; a day shaded in the accent in four steps
// by what it spent against the month's heaviest, a day with no spending a hairline square, the days to come fainter
// still, today ringed. Medium: what's spent so far, the heaviest day and the days with no spending beside a small
// calendar. Large: the calendar with its numbers, a key, and the three figures under a rule. Tap the month to flip to
// the last one.

struct DaysWidget: Widget {
    let kind: String = "KoshDays"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: KoshProvider()) { e in
            DaysView(entry: e)
        }
        .configurationDisplayName("Month in days")
        .description("Each day shaded by what it spent, so the heavy days stand out. Tap the month to flip to the last one.")
        .supportedFamilies([.systemMedium, .systemLarge, .accessoryCircular])
    }
}

struct DaysMath {
    let m: String
    let name: String
    let dim: Int
    /// spent each day, day 1 first; days still to come are missing
    let days: [Double]
    /// today's day, when this is the running month (0 otherwise)
    let todayDay: Int
    let isLast: Bool
    let canFlip: Bool
    let other: String

    init(_ mo: WFMonth, today: String, last: Bool) {
        let hasPrev: Bool = !mo.prevDays.isEmpty && !mo.prevM.isEmpty
        canFlip = hasPrev
        if last && hasPrev {
            m = mo.prevM
            name = mo.prevName
            dim = mo.prevDays.count
            days = mo.prevDays
            todayDay = 0
            isLast = true
            other = mo.short.isEmpty ? WDay.fmt(mo.m + "-01", "MMM") : mo.short
        } else {
            m = mo.m
            name = mo.name
            dim = mo.dim
            days = mo.days
            todayDay = String(today.prefix(7)) == mo.m ? WDay.dayNumber(today) : mo.d
            isLast = false
            other = mo.prevName.isEmpty ? "" : String(mo.prevName.prefix(3))
        }
    }
    var short: String { WDay.fmt(m + "-01", "MMM") }
    var total: Double {
        var t: Double = 0
        for v in days { t += v }
        return t
    }
    /// blanks before day 1, Sunday first
    var lead: Int { WDay.weekday(m + "-01") - 1 }
    var rows: Int { (lead + dim + 6) / 7 }
    var quiet: Int { days.filter { $0 <= 0 }.count }
    var biggest: (day: Int, v: Double)? {
        var best: (day: Int, v: Double)? = nil
        for (i, v) in days.enumerated() where v > 0 {
            if best == nil || v > (best?.v ?? 0) { best = (i + 1, v) }
        }
        return best
    }
    func value(_ day: Int) -> Double? {
        if day < 1 || day > days.count { return nil }
        return days[day - 1]
    }
    var top: Double {
        var t: Double = 0
        for v in days { t = max(t, v) }
        return t
    }
    /// how deep a day is: 0 nothing spent, then 1 to 4 by its spending against the month's heaviest
    func level(_ v: Double) -> Int {
        let t: Double = top
        if t <= 0 || v <= 0 { return 0 }
        let r: Double = v / t
        if r <= 0.15 { return 1 }
        if r <= 0.3 { return 2 }
        if r <= 0.52 { return 3 }
        return 4
    }
    /// the dates the figures cover: "1–24 Oct", the whole month when it's the last one
    var range: String {
        let upTo: Int = isLast ? dim : max(1, days.count)
        return upTo <= 1 ? "1 " + short : "1–" + String(upTo) + " " + short
    }
    /// "25–31 Oct to come" (nothing when the month is over)
    var toCome: String {
        if isLast || days.count >= dim { return "" }
        let from: Int = days.count + 1
        return (from == dim ? String(dim) : String(from) + "–" + String(dim)) + " " + short + " to come"
    }
    /// "Mon 12 Oct", "Mon 12"
    func dayName(_ d: Int, month: Bool) -> String {
        let pad: String = d < 10 ? "0" : ""
        return WDay.fmt(m + "-" + pad + String(d), month ? "EEE d MMM" : "EEE d")
    }
    var quietLine: String { quiet == 1 ? "1 day with no spend" : String(quiet) + " days with no spend" }
}

struct DaysView: View {
    let entry: KEntry
    @Environment(\.widgetFamily) private var family
    var body: some View {
        KFrame(entry: entry, link: "days") {
            if let f = entry.feed, !f.empty, !entry.stale {
                let m: DaysMath = DaysMath(f.month, today: entry.today, last: entry.lastMonth)
                if family == .accessoryCircular {
                    DaysCircular(m: m)
                } else if family == .systemLarge {
                    DaysLarge(m: m)
                } else {
                    DaysMedium(m: m)
                }
            } else if family == .accessoryCircular {
                ZStack { AccessoryWidgetBackground(); Image(systemName: "calendar") }
            } else {
                KEmpty(sym: "square.grid.3x3", title: entry.stale ? "A new month" : KCopy.openTitle,
                       line: entry.stale ? KCopy.staleLine(entry) : KCopy.openLine)
            }
        }
    }
}

/// the four depths of the accent, and the figure on the deepest
enum DaysInk {
    static func fill(_ level: Int) -> Color {
        switch level {
        case 1: return Color.kosh.opacity(0.14)
        case 2: return Color.kosh.opacity(0.31)
        case 3: return Color.kosh.opacity(0.56)
        case 4: return Color.kosh
        default: return Color.clear
        }
    }
    /// white on the deep accent by day, a deep blue-black on the light accent by night
    static let onDeep: Color = Color.dyn("#0E1430", "#FFFFFF")
}

/// ‹ Sep, or Oct ›: flips between this month and the last
struct FlipButton: View {
    let m: DaysMath
    var body: some View {
        if m.canFlip && !m.other.isEmpty {
            Button(intent: SwitchMonthIntent()) {
                HStack(spacing: 4) {
                    if !m.isLast { Image(systemName: "chevron.left").font(.system(size: 8, weight: .bold)) }
                    Text(m.other).font(.system(size: 11.5, weight: .semibold))
                    if m.isLast { Image(systemName: "chevron.right").font(.system(size: 8, weight: .bold)) }
                }
                .foregroundStyle(KInk.ink)
                .padding(.horizontal, 10)
                .frame(height: 26)
                .background(KInk.faint, in: Capsule())
            }
            .buttonStyle(.plain)
            .accessibilityLabel("Show " + m.other)
        }
    }
}

/// the calendar, Sunday first; the large one numbers its days
struct DaysGrid: View {
    let m: DaysMath
    let cell: CGFloat
    let gap: CGFloat
    var numbers: Bool = false
    var radius: CGFloat = 4
    var body: some View {
        let letters: [String] = ["S", "M", "T", "W", "T", "F", "S"]
        VStack(spacing: gap) {
            HStack(spacing: gap) {
                ForEach(0..<7, id: \.self) { i in
                    Text(letters[i]).font(.system(size: 9.5)).foregroundStyle(KInk.quiet)
                        .frame(maxWidth: .infinity)
                }
            }
            ForEach(0..<m.rows, id: \.self) { r in
                HStack(spacing: gap) {
                    ForEach(0..<7, id: \.self) { col in
                        DayCell(m: m, day: r * 7 + col - m.lead + 1, height: cell, numbers: numbers, radius: radius)
                    }
                }
            }
        }
    }
}

struct DayCell: View {
    let m: DaysMath
    let day: Int
    let height: CGFloat
    let numbers: Bool
    var radius: CGFloat = 4
    var body: some View {
        let inMonth: Bool = day >= 1 && day <= m.dim
        let v: Double? = m.value(day)
        let level: Int = m.level(v ?? 0)
        let isToday: Bool = day == m.todayDay && inMonth
        let shape: RoundedRectangle = RoundedRectangle(cornerRadius: radius, style: .continuous)
        ZStack {
            if !inMonth {
                Color.clear
            } else if v == nil {
                shape.strokeBorder(KInk.faint, lineWidth: 1)
            } else if level == 0 {
                shape.strokeBorder(KInk.hair, lineWidth: 1)
            } else {
                shape.fill(DaysInk.fill(level)).widgetAccentable(level >= 3)
            }
            if isToday {
                RoundedRectangle(cornerRadius: radius + 2.5, style: .continuous)
                    .strokeBorder(KInk.ink, lineWidth: 1.5)
                    .padding(-3.5)
            }
            if numbers && inMonth {
                Text(String(day))
                    .font(.system(size: 12, weight: v == nil ? .medium : .semibold))
                    .monospacedDigit()
                    .foregroundStyle(v == nil ? KInk.quiet : level == 4 ? DaysInk.onDeep : KInk.ink)
            }
        }
        .frame(maxWidth: .infinity)
        .frame(height: height)
    }
}

/// less ▢▢▢▢▢ more
struct HeatKey: View {
    var body: some View {
        HStack(spacing: 4) {
            Text("Less").padding(.trailing, 2)
            RoundedRectangle(cornerRadius: 3).strokeBorder(KInk.hair, lineWidth: 1).frame(width: 12, height: 12)
            ForEach(1..<5, id: \.self) { l in
                RoundedRectangle(cornerRadius: 3).fill(DaysInk.fill(l)).frame(width: 12, height: 12)
            }
            Text("More").padding(.leading, 2)
        }
        .font(.system(size: 11.5))
        .foregroundStyle(KInk.quiet)
    }
}

/// "Mon 12 Oct ₹6,800": the day in the ink, the figure warm
struct Heaviest: View {
    let m: DaysMath
    var body: some View {
        if let b = m.biggest {
            let day: Text = Text(m.dayName(b.day, month: true) + " ").foregroundStyle(KInk.ink)
            let v: Text = Text(WMoney.full(b.v)).foregroundStyle(KInk.warm)
            Text("\(day)\(v)").font(.system(size: 13, weight: .semibold)).monospacedDigit()
                .lineLimit(1).minimumScaleFactor(0.8).privacySensitive()
        } else {
            Text("No spending yet").kSub()
        }
    }
}

struct DaysMedium: View {
    let m: DaysMath
    var body: some View {
        HStack(alignment: .top, spacing: 16) {
            VStack(alignment: .leading, spacing: 0) {
                HStack(alignment: .top, spacing: 6) {
                    KHeader(title: m.name, sub: m.range)
                    FlipButton(m: m)
                }
                KAmount(v: m.total, size: 26)
                    .padding(.top, 10)
                Spacer(minLength: 4)
                Text("Heaviest day").kSub()
                Heaviest(m: m).padding(.top, 1)
                Text(m.quietLine).kSub().padding(.top, 6)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
            DaysGrid(m: m, cell: m.rows > 5 ? 15 : 18, gap: m.rows > 5 ? 3.5 : 5)
                .frame(width: 162)
        }
    }
}

/// a figure under the large calendar: what it is, then the figure
struct DaysFigure: View {
    let title: String
    let value: String
    var ink: Color = KInk.ink
    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(title).kSub()
            Text(value).font(.system(size: 15, weight: .semibold)).kerning(-0.15).monospacedDigit()
                .foregroundStyle(ink).lineLimit(1).minimumScaleFactor(0.8).privacySensitive()
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

struct DaysLarge: View {
    let m: DaysMath
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack(alignment: .top) {
                KHeader(title: m.name, sub: "Each day by what it spent, " + m.range)
                FlipButton(m: m)
            }
            DaysGrid(m: m, cell: m.rows > 5 ? 28 : 35, gap: m.rows > 5 ? 5 : 6, numbers: true, radius: 9)
                .padding(.top, 12)
            HStack {
                HeatKey()
                Spacer(minLength: 4)
                if !m.toCome.isEmpty { Text(m.toCome).kSub() }
            }
            .padding(.top, 12)
            KHairline().padding(.top, 12).padding(.bottom, 10)
            HStack(alignment: .top, spacing: 16) {
                DaysFigure(title: "Spent, " + m.range, value: WMoney.full(m.total))
                if let b = m.biggest {
                    DaysFigure(title: "Heaviest, " + m.dayName(b.day, month: false), value: WMoney.full(b.v), ink: KInk.warm)
                } else {
                    DaysFigure(title: "Heaviest", value: "None yet")
                }
                DaysFigure(title: "No spend", value: m.quiet == 1 ? "1 day" : String(m.quiet) + " days")
            }
            Spacer(minLength: 0)
        }
    }
}

/// a Lock Screen ring: how far through the month today is
struct DaysCircular: View {
    let m: DaysMath
    var body: some View {
        let day: Int = max(1, m.todayDay)
        let share: Double = Double(day) / Double(max(1, m.dim))
        ZStack {
            AccessoryWidgetBackground()
            Circle().stroke(Color.primary.opacity(0.28), lineWidth: 5).padding(5)
            Circle().trim(from: 0, to: share)
                .stroke(Color.primary, style: StrokeStyle(lineWidth: 5, lineCap: .round))
                .rotationEffect(.degrees(-90))
                .padding(5)
                .widgetAccentable()
            VStack(spacing: 1) {
                Text(String(day)).font(.system(size: 18, weight: .semibold)).monospacedDigit()
                Text("of " + String(m.dim)).font(.system(size: 10, weight: .semibold)).foregroundStyle(.secondary)
            }
        }
        .accessibilityElement(children: .combine)
        .accessibilityLabel("Day " + String(day) + " of " + String(m.dim))
    }
}
