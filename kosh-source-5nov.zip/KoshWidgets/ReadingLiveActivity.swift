import ActivityKit
import SwiftUI
import WidgetKit

// MARK: - kosh reading, on the Lock Screen
//
// What the bar above the tab bar says, when kosh is off screen: kosh's mark (the box drawn in white lines on a flat
// square of the accent), what it's reading in semibold, a lighter line under it, the count on the right ("412" bright,
// "of 1,240" quiet), and a slim flat bar of the accent's light as far as the reading has got. Paused: grey and still.
// Finished: a green check on the mark, the bar full. On a dark, slightly see-through ground that reads on any
// wallpaper. The app sends the words and figures (Kosh/ReadingLive.swift); nothing here guesses.

struct ReadingLiveActivity: Widget {
    var body: some WidgetConfiguration {
        ActivityConfiguration(for: ReadingAttributes.self) { context in
            RLLockScreen(s: context.state, stale: context.isStale)
                .activityBackgroundTint(RLInk.ground)
                .activitySystemActionForegroundColor(Color.white.opacity(0.86))
        } dynamicIsland: { context in
            let s: ReadingAttributes.ContentState = context.state
            let stale: Bool = context.isStale
            return DynamicIsland {
                DynamicIslandExpandedRegion(.leading) {
                    RLMark(s: s, size: 38)
                        .padding(.leading, 4)
                        .frame(maxHeight: .infinity, alignment: .center)
                }
                DynamicIslandExpandedRegion(.trailing) {
                    RLCount(s: s, stale: stale, size: 15)
                        .padding(.trailing, 4)
                        .frame(maxHeight: .infinity, alignment: .center)
                }
                DynamicIslandExpandedRegion(.center) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(s.title)
                            .font(.system(size: 15, weight: .semibold))
                            .foregroundStyle(RLInk.title)
                            .lineLimit(1)
                            .minimumScaleFactor(0.8)
                        Text(RLText.line(s, stale: stale))
                            .font(.system(size: 12.5))
                            .foregroundStyle(RLInk.secondary)
                            .lineLimit(1)
                            .minimumScaleFactor(0.8)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
                DynamicIslandExpandedRegion(.bottom) {
                    RLBar(s: s, stale: stale, height: 5)
                        .padding(.horizontal, 6)
                        .padding(.top, 8)
                        .padding(.bottom, 2)
                }
            } compactLeading: {
                RLRing(s: s, width: 2.6)
                    .frame(width: 18, height: 18)
            } compactTrailing: {
                Text(RLText.short(s))
                    .font(.system(size: 13, weight: .semibold))
                    .monospacedDigit()
                    .foregroundStyle(s.finished ? RLInk.good : s.paused ? RLInk.quiet : Color(hex: s.skyHex))
                    .lineLimit(1)
                    .contentTransition(.numericText(value: s.fraction))
            } minimal: {
                RLRing(s: s, width: 2.6)
                    .frame(width: 18, height: 18)
            }
            .keylineTint(Color(hex: s.accentHex))
        }
    }
}

// MARK: The Lock Screen (and the banner, on a phone without the Dynamic Island)

struct RLLockScreen: View {
    let s: ReadingAttributes.ContentState
    let stale: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .center, spacing: 12) {
                RLMark(s: s, size: 36)
                VStack(alignment: .leading, spacing: 0) {
                    Text(s.title)
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundStyle(RLInk.title)
                        .lineLimit(1)
                        .minimumScaleFactor(0.8)
                    Text(RLText.line(s, stale: stale))
                        .font(.system(size: 13))
                        .foregroundStyle(RLInk.secondary)
                        .lineLimit(1)
                        .minimumScaleFactor(0.85)
                        .contentTransition(.opacity)
                }
                .layoutPriority(1)
                Spacer(minLength: 4)
                RLCount(s: s, stale: stale, size: 15)
                    .layoutPriority(2)
            }
            RLBar(s: s, stale: stale, height: 5)
        }
        .padding(.horizontal, 16)
        .padding(.top, 14)
        .padding(.bottom, 16)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(s.title)
        .accessibilityValue(s.count)
    }
}

/// "412 of 1,240": the figure done bright, the rest quiet, the figures rolling as they change; green when it's all
/// read, quiet when paused
struct RLCount: View {
    let s: ReadingAttributes.ContentState
    let stale: Bool
    var size: CGFloat = 15

    var body: some View {
        let lead: Color = s.finished ? RLInk.good : (s.paused || stale) ? RLInk.quiet : RLInk.count
        let parts: [String] = s.count.components(separatedBy: " of ")
        let head: Text = Text(parts.first ?? s.count).font(.system(size: size, weight: .semibold)).foregroundStyle(lead)
        let tail: Text = parts.count > 1
            ? Text(" of " + parts.dropFirst().joined(separator: " of ")).font(.system(size: size, weight: .medium)).foregroundStyle(RLInk.secondary)
            : Text("")
        Text("\(head)\(tail)")
            .kerning(-0.15)
            .monospacedDigit()
            .contentTransition(.numericText(value: Double(s.done)))
            .lineLimit(1)
            .minimumScaleFactor(0.75)
    }
}

// MARK: kosh's mark: the box, in white on a rounded square of the accent

struct RLMark: View {
    let s: ReadingAttributes.ContentState
    var size: CGFloat = 36

    var body: some View {
        let corner: CGFloat = size * 0.28
        RoundedRectangle(cornerRadius: corner, style: .continuous)
            .fill(s.paused ? Color(white: 0.4) : Color(hex: s.accentHex))
            .overlay {
                RLBox()
                    .stroke(Color.white, style: StrokeStyle(lineWidth: 1.7 * size / 36, lineJoin: .round))
                    .frame(width: size * 0.56, height: size * 0.56)
            }
            .frame(width: size, height: size)
            .overlay(alignment: .bottomTrailing) { badge }
    }

    @ViewBuilder private var badge: some View {
        if s.finished {
            Image(systemName: "checkmark.circle.fill")
                .font(.system(size: size * 0.42, weight: .bold))
                .symbolRenderingMode(.palette)
                .foregroundStyle(Color.white, RLInk.good)
                .background(Circle().fill(RLInk.groundSolid).padding(-1.5))
                .offset(x: size * 0.14, y: size * 0.14)
        } else if s.paused {
            Image(systemName: "pause.circle.fill")
                .font(.system(size: size * 0.38, weight: .bold))
                .symbolRenderingMode(.palette)
                .foregroundStyle(Color.white, Color(white: 0.42))
                .background(Circle().fill(RLInk.groundSolid).padding(-1.5))
                .offset(x: size * 0.13, y: size * 0.13)
        }
    }
}

/// kosh's box (the app icon's mark) in lines, on the icon's 24-point grid: a hexagon, the top face's edges, the near
/// edge down the middle
struct RLBox: Shape {
    func path(in r: CGRect) -> Path {
        let k: CGFloat = min(r.width, r.height) / 24
        let ox: CGFloat = r.midX - 12 * k
        let oy: CGFloat = r.midY - 12 * k
        func pt(_ x: CGFloat, _ y: CGFloat) -> CGPoint { CGPoint(x: ox + x * k, y: oy + y * k) }
        var p = Path()
        p.addLines([pt(12, 3), pt(20, 7.5), pt(20, 16.5), pt(12, 21), pt(4, 16.5), pt(4, 7.5)])
        p.closeSubpath()
        p.move(to: pt(4, 7.5)); p.addLine(to: pt(12, 12)); p.addLine(to: pt(20, 7.5))
        p.move(to: pt(12, 12)); p.addLine(to: pt(12, 21))
        return p
    }
}

// MARK: The bar: a slim capsule, filled flat in the accent's light as far as the reading has got

struct RLBar: View {
    let s: ReadingAttributes.ContentState
    let stale: Bool
    var height: CGFloat = 5

    var body: some View {
        let sky: Color = Color(hex: s.skyHex)
        let ink: Color = s.finished ? RLInk.good : s.paused ? RLInk.pausedBar : sky
        GeometryReader { g in
            let w: CGFloat = g.size.width
            let f: CGFloat = CGFloat(s.fraction)
            let fill: CGFloat = s.seeking ? 0 : (f > 0 ? min(w, max(height, w * f)) : 0)
            ZStack(alignment: .leading) {
                Capsule()
                    .fill(Color.white.opacity(0.16))
                if s.seeking {
                    // still counting what there is to read: a short soft band where the fill will start
                    Capsule()
                        .fill(sky.opacity(0.55))
                        .frame(width: w * 0.12, height: height)
                } else if fill > 0 {
                    Capsule()
                        .fill(ink)
                        .frame(width: fill, height: height)
                }
            }
            .frame(width: w, height: height)
        }
        .frame(height: height)
        .accessibilityHidden(true)
    }
}

// MARK: The Dynamic Island's small ring

struct RLRing: View {
    let s: ReadingAttributes.ContentState
    var width: CGFloat = 2.6

    var body: some View {
        let accent: Color = Color(hex: s.accentHex)
        let sky: Color = Color(hex: s.skyHex)
        let to: CGFloat = s.finished ? 1 : s.seeking ? 0.22 : max(0.03, CGFloat(s.fraction))
        ZStack {
            Circle()
                .stroke(Color.white.opacity(0.18), lineWidth: width)
            Circle()
                .trim(from: 0, to: to)
                .stroke(s.finished ? AnyShapeStyle(RLInk.good) : s.paused ? AnyShapeStyle(RLInk.pausedBar)
                        : AnyShapeStyle(LinearGradient(colors: [accent, sky], startPoint: .topLeading, endPoint: .bottomTrailing)),
                        style: StrokeStyle(lineWidth: width, lineCap: .round))
                .rotationEffect(.degrees(-90))
            if s.finished {
                Image(systemName: "checkmark")
                    .font(.system(size: 7.5, weight: .heavy))
                    .foregroundStyle(RLInk.good)
            }
        }
        .padding(width / 2)
    }
}

// MARK: Words and colours

enum RLText {
    /// under the title; once the app hasn't been heard from for a while, the downloads are still at it
    static func line(_ s: ReadingAttributes.ContentState, stale: Bool) -> String {
        if stale && !s.finished && !s.paused { return "Still reading in the background" }
        return s.line
    }
    /// the compact count beside the ring: how far, or how many found while it's counting
    static func short(_ s: ReadingAttributes.ContentState) -> String {
        if s.finished { return "Done" }
        if s.seeking || s.total <= 0 {
            let n: Double = Double(s.done)
            if n >= 1000 { return RLHex.trim(n / 1000) + "k" }
            return String(s.done)
        }
        return String(Int(safe: (s.fraction * 100).rounded(.down))) + "%"
    }
}

enum RLInk {
    /// a dark graphite, a little see-through, so it sits on any wallpaper
    static let ground: Color = Color(red: 18 / 255.0, green: 20 / 255.0, blue: 24 / 255.0).opacity(0.72)
    static let groundSolid: Color = Color(red: 18 / 255.0, green: 20 / 255.0, blue: 24 / 255.0)
    static let title: Color = Color.white
    static let count: Color = Color.white
    static let secondary: Color = Color.white.opacity(0.72)
    static let quiet: Color = Color.white.opacity(0.48)
    static let pausedBar: Color = Color.white.opacity(0.36)
    /// all caught up: the app's night green
    static let good: Color = Color(red: 0x5F / 255.0, green: 0xD3 / 255.0, blue: 0x8A / 255.0)
}

enum RLHex {
    /// a colour part way to another: "#3B5BFD" with 14% white
    static func mix(_ a: String, _ b: String, _ t: Double) -> String {
        let x: (Double, Double, Double) = rgb(a)
        let y: (Double, Double, Double) = rgb(b)
        func ch(_ p: Double, _ q: Double) -> Int { Int((p + (q - p) * t).rounded()) }
        return String(format: "#%02X%02X%02X", ch(x.0, y.0), ch(x.1, y.1), ch(x.2, y.2))
    }
    static func rgb(_ hex: String) -> (Double, Double, Double) {
        var s: String = hex.trimmingCharacters(in: .whitespaces)
        if s.hasPrefix("#") { s.removeFirst() }
        var v: UInt64 = 0
        Scanner(string: s).scanHexInt64(&v)
        return (Double((v >> 16) & 0xFF), Double((v >> 8) & 0xFF), Double(v & 0xFF))
    }
    /// 2.3, 12, not 12.0
    static func trim(_ x: Double) -> String {
        let s: String = String(format: x >= 10 ? "%.0f" : "%.1f", x)
        return s.hasSuffix(".0") ? String(s.dropLast(2)) : s
    }
}
