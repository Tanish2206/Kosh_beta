import SwiftUI
import WidgetKit

/// kosh's widgets: each reads the small file the app writes after every rebuild; and kosh's own Lock Screen entry
/// while it reads with the phone locked (ReadingLiveActivity)
@main
struct KoshWidgetsBundle: WidgetBundle {
    var body: some Widget {
        ReadingLiveActivity()
        MonthWidget()
        DueWidget()
        WorthWidget()
        DaysWidget()
        CardsWidget()
        BanksWidget()
        LatestWidget()
        NoticedWidget()
        SplitWidget()
        ChapterWidget()
        RentWidget()
        AddWidget()
    }
}
