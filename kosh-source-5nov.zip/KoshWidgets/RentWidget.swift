import SwiftUI
import WidgetKit

// MARK: - Rent: the building drawn floor by floor, green where the rent is in and warm where it's late

struct RentWidget: Widget {
    let kind: String = "KoshRent"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: KoshProvider()) { e in
            RentView(entry: e)
        }
        .configurationDisplayName("Rent")
        .description("This month's rent from each let floor: what's in, what's still to come, and who's late.")
        .supportedFamilies([.systemSmall, .systemMedium, .accessoryCircular])
    }
}

struct RentMath {
    let r: WFRent
    /// the column reads like the building: the top floor at the top
    var floors: [WFRentUnit] { Array(r.units.prefix(8).reversed()) }
    var paid: Int { r.units.filter { $0.st == "booked" }.count }
    var late: [WFRentUnit] { r.units.filter { $0.st == "late" } }
    var waiting: Int { r.units.count - paid - late.count }
    var allIn: Bool { paid == r.units.count }
    var paidLine: String { allIn ? "All in" : String(paid) + " paid" }
    /// "2 late", or "2 to come" when nobody's late yet
    var restLine: String {
        if !late.isEmpty { return String(late.count) + " late" }
        if waiting > 0 { return String(waiting) + " to come" }
        return ""
    }
    /// how much of the month's rent is in, 0…1
    var share: Double { r.expected > 0 ? min(1, r.received / r.expected) : 0 }
    static func ink(_ st: String) -> Color {
        switch st {
        case "booked": return KInk.good
        case "late": return KInk.late
        default: return KInk.hair
        }
    }
    static func word(_ u: WFRentUnit) -> String {
        switch u.st {
        case "booked": return "In"
        case "late": return u.late > 0 ? String(u.late) + (u.late == 1 ? " day late" : " days late") : "Late"
        case "due": return "Due"
        default: return "To come"
        }
    }
}

struct RentView: View {
    let entry: KEntry
    @Environment(\.widgetFamily) private var family
    var body: some View {
        KFrame(entry: entry, link: "rent") {
            if let r = entry.feed?.rent, !r.units.isEmpty, !entry.stale {
                let m: RentMath = RentMath(r: r)
                let month: String = WDay.monthName(entry.today)
                switch family {
                case .accessoryCircular: RentCircular(m: m)
                case .systemMedium: RentMedium(m: m, month: month)
                default: RentSmall(m: m, month: month)
                }
            } else if family == .accessoryCircular {
                ZStack {
                    AccessoryWidgetBackground()
                    Image(systemName: "house")
                }
            } else {
                KEmpty(sym: "house", title: entry.stale ? "A new month" : "No rent yet",
                       line: entry.stale ? KCopy.staleLine(entry) : "Let floors with a rent show here, each lit as its rent comes in.")
            }
        }
    }
}

/// a floor: a soft wash of where its rent stands, edged in the same colour (a hairline while it's still to come)
struct FloorW: View {
    let st: String
    var height: CGFloat = 12
    var body: some View {
        let ink: Color = RentMath.ink(st)
        let lit: Bool = st == "booked" || st == "late"
        RoundedRectangle(cornerRadius: 3, style: .continuous)
            .fill(lit ? ink.opacity(0.14) : Color.clear)
            .overlay(RoundedRectangle(cornerRadius: 3, style: .continuous).strokeBorder(ink, lineWidth: 1.5))
            .frame(height: height)
            .widgetAccentable(lit)
    }
}

/// the building: a roof's two slopes, then a floor for each let unit (the top floor at the top), on a ground line
struct FloorColumn: View {
    let m: RentMath
    var width: CGFloat = 50
    var floor: CGFloat = 12
    var body: some View {
        VStack(spacing: 0) {
            Roof().stroke(KInk.ink, style: StrokeStyle(lineWidth: 1.5, lineCap: .round, lineJoin: .round))
                .frame(width: width, height: width * 0.3)
            VStack(spacing: 3) {
                ForEach(Array(m.floors.enumerated()), id: \.offset) { _, u in FloorW(st: u.st, height: floor) }
            }
            .padding(.horizontal, 3)
            .padding(.top, 2)
            Capsule().fill(KInk.hair).frame(height: 1.5).padding(.top, 3)
        }
        .frame(width: width)
    }
}

/// a roof's two slopes
struct Roof: Shape {
    func path(in r: CGRect) -> Path {
        var p = Path()
        p.move(to: CGPoint(x: r.minX + 2, y: r.maxY - 1))
        p.addLine(to: CGPoint(x: r.midX, y: r.minY + 1))
        p.addLine(to: CGPoint(x: r.maxX - 2, y: r.maxY - 1))
        return p
    }
}

/// the month, then the building beside what's in of what's expected and who's late
struct RentSmall: View {
    let m: RentMath
    let month: String
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            KHeader(title: "Rent", sub: month)
            Spacer(minLength: 4)
            HStack(alignment: .bottom, spacing: 14) {
                FloorColumn(m: m, width: 50, floor: m.floors.count > 5 ? 9 : 12)
                VStack(alignment: .leading, spacing: 0) {
                    KAmount(v: m.r.received, size: 22)
                    Text("of " + WMoney.full(m.r.expected)).kSub().padding(.top, 3).privacySensitive()
                    if !m.restLine.isEmpty {
                        Text(m.restLine).font(.system(size: 11.5, weight: .semibold))
                            .foregroundStyle(m.late.isEmpty ? KInk.quiet : KInk.warm).padding(.top, 6)
                    } else if m.allIn {
                        Text("All in").font(.system(size: 11.5, weight: .semibold)).foregroundStyle(KInk.good).padding(.top, 6)
                    }
                }
            }
        }
    }
}

/// a floor in the list: a dot, its name, where its rent stands, the amount
struct RentRow: View {
    let u: WFRentUnit
    var body: some View {
        HStack(spacing: 8) {
            Circle().fill(RentMath.ink(u.st)).frame(width: 6, height: 6)
            Text(u.label).kName()
            Spacer(minLength: 4)
            Text(RentMath.word(u)).kSub(u.st == "late" ? KInk.warm : KInk.quiet)
                .frame(width: 72, alignment: .leading)
            Text(WMoney.full(u.rent)).font(.system(size: 13, weight: .semibold)).monospacedDigit().foregroundStyle(KInk.ink)
                .lineLimit(1).minimumScaleFactor(0.7)
                .frame(width: 56, alignment: .trailing)
                .privacySensitive()
        }
    }
}

/// the building on the left, every floor's rent on the right
struct RentMedium: View {
    let m: RentMath
    let month: String
    var body: some View {
        HStack(alignment: .top, spacing: 18) {
            VStack(alignment: .leading, spacing: 0) {
                KHeader(title: "Rent", sub: month)
                Spacer(minLength: 4)
                FloorColumn(m: m, width: 70, floor: m.floors.count > 5 ? 9 : 13)
            }
            .frame(width: 96, alignment: .leading)
            VStack(alignment: .leading, spacing: 0) {
                HStack(alignment: .firstTextBaseline) {
                    Text(WMoney.full(m.r.received) + " in").font(.system(size: 13, weight: .semibold)).monospacedDigit()
                        .foregroundStyle(KInk.good).privacySensitive()
                    Spacer(minLength: 4)
                    Text("of " + WMoney.full(m.r.expected)).kSub().privacySensitive()
                }
                .padding(.bottom, 4)
                ForEach(Array(m.floors.prefix(5).enumerated()), id: \.offset) { _, u in
                    RentRow(u: u).frame(maxHeight: .infinity)
                }
            }
        }
    }
}

/// the Lock Screen: a ring of how much of the month's rent is in
struct RentCircular: View {
    let m: RentMath
    var body: some View {
        ZStack {
            AccessoryWidgetBackground()
            Circle().stroke(Color.primary.opacity(0.28), lineWidth: 5).padding(4)
            Circle().trim(from: 0, to: CGFloat(m.share))
                .stroke(Color.primary, style: StrokeStyle(lineWidth: 5, lineCap: .round))
                .rotationEffect(.degrees(-90))
                .padding(4)
                .widgetAccentable()
            VStack(spacing: 2) {
                Text(String(Int(safe: (m.share * 100).rounded())) + "%").font(.system(size: 17, weight: .semibold)).kerning(-0.5).monospacedDigit()
                Text("rent in").font(.system(size: 10, weight: .semibold)).foregroundStyle(.secondary)
            }
        }
    }
}
