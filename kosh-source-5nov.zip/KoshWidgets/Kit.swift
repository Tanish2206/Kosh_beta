import SwiftUI
import WidgetKit
import AppIntents

// MARK: - Colour

extension Color {
    // Color(hex:) lives in Shared/KoshLook.swift, one for the app and the widgets
    /// kosh blue
    /// (or the accent picked in the app's Settings › Appearance, read from the app group: Shared/KoshLook.swift),
    /// lifted by night as the app lifts it
    static var kosh: Color { KoshAccent.saved.ink }
}

// MARK: - Money, the way the family reads it

enum WMoney {
    static let grouping: NumberFormatter = {
        let f = NumberFormatter()
        f.locale = Locale(identifier: "en_IN")
        f.numberStyle = .decimal
        f.maximumFractionDigits = 0
        return f
    }()
    /// ₹12,34,567
    static func full(_ v: Double) -> String {
        let n: NSNumber = NSNumber(value: abs(v).rounded())
        return "₹" + (grouping.string(from: n) ?? "0")
    }
    static func trim(_ x: Double, _ dp: Int) -> String {
        var s: String = String(format: "%.\(dp)f", x)
        while s.contains(".") && (s.hasSuffix("0") || s.hasSuffix(".")) { s.removeLast() }
        return s
    }
    /// ₹12.4 L, ₹1.05 Cr; below a lakh, in full
    static func words(_ v: Double) -> String {
        let a: Double = abs(v)
        if a >= 1e7 { return "₹" + trim(a / 1e7, 2) + " Cr" }
        if a >= 1e5 {
            let dp: Int = a >= 1e6 ? 1 : 2
            return "₹" + trim(a / 1e5, dp) + " L"
        }
        return full(a)
    }
    /// ₹840, ₹4.5k, ₹12.3 L, ₹1.2 Cr: for tight spots
    static func tight(_ v: Double) -> String {
        let a: Double = abs(v)
        if a >= 1e7 { return "₹" + trim(a / 1e7, 2) + " Cr" }
        if a >= 1e5 { return "₹" + trim(a / 1e5, 1) + " L" }
        if a >= 1000 {
            let dp: Int = a >= 1e4 ? 0 : 1
            return "₹" + trim(a / 1000, dp) + "k"
        }
        return full(a)
    }
    /// below a lakh in full, above it in words
    static func headline(_ v: Double) -> String { abs(v) >= 1e5 ? words(v) : full(v) }
    static func signed(_ v: Double) -> String { (v < 0 ? "−" : "+") + tight(v) }

    /// how a hero figure is cut: every digit, thousands as k, or lakh and crore as L and Cr
    enum Mode { case full, tight, words }
    struct Parts { let number: String; let unit: String }
    static func parts(_ v: Double, _ mode: Mode) -> Parts {
        let a: Double = abs(v)
        switch mode {
        case .full:
            return Parts(number: String(full(a).dropFirst()), unit: "")
        case .tight:
            if a >= 1e7 { return Parts(number: trim(a / 1e7, 2), unit: "Cr") }
            if a >= 1e5 { return Parts(number: trim(a / 1e5, 1), unit: "L") }
            if a >= 1000 {
                let dp: Int = a >= 1e4 ? 0 : 1
                return Parts(number: trim(a / 1000, dp), unit: "k")
            }
            return Parts(number: String(full(a).dropFirst()), unit: "")
        case .words:
            if a >= 1e7 { return Parts(number: trim(a / 1e7, 2), unit: "Cr") }
            if a >= 1e5 {
                let dp: Int = a >= 1e6 ? 1 : 2
                return Parts(number: trim(a / 1e5, dp), unit: "L")
            }
            return Parts(number: String(full(a).dropFirst()), unit: "")
        }
    }
}

/// payee names as people read them: "gpay 11259812197" becomes "GPay ··2197"
enum WName {
    static let brands: [String: String] = ["gpay": "GPay", "googlepay": "Google Pay", "phonepe": "PhonePe", "paytm": "Paytm",
                                           "bhim": "BHIM", "upi": "UPI", "amazonpay": "Amazon Pay", "cred": "CRED", "mobikwik": "MobiKwik"]
    static func clean(_ raw: String) -> String {
        let name: String = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        if name.isEmpty { return "Payment" }
        var words: [String] = []
        for w in name.split(separator: " ") {
            let word: String = String(w)
            let digits: Int = word.filter { $0.isNumber }.count
            if digits >= 7 && digits * 10 >= word.count * 7 {
                words.append("··" + String(word.filter { $0.isNumber }.suffix(4)))
            } else if let b = brands[word.lowercased()] {
                words.append(b)
            } else if word == word.lowercased() && word.count > 2 {
                words.append(word.prefix(1).uppercased() + String(word.dropFirst()))
            } else {
                words.append(word)
            }
        }
        return words.joined(separator: " ")
    }
}

// MARK: - Days (kosh dates are yyyy-MM-dd, India time)

enum WDay {
    static let zone: TimeZone = TimeZone(identifier: "Asia/Kolkata") ?? .current
    static let cal: Calendar = {
        var c = Calendar(identifier: .gregorian)
        c.timeZone = zone
        return c
    }()
    static let parser: DateFormatter = {
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX")
        f.timeZone = zone
        f.dateFormat = "yyyy-MM-dd"
        return f
    }()
    static func date(_ s: String) -> Date { parser.date(from: String(s.prefix(10))) ?? Date() }
    static func iso(_ d: Date) -> String { parser.string(from: d) }
    static func fmt(_ s: String, _ format: String) -> String {
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_GB")
        f.timeZone = zone
        f.dateFormat = format
        return f.string(from: date(s))
    }
    static func add(_ s: String, _ n: Int) -> String {
        let d: Date = cal.date(byAdding: .day, value: n, to: date(s)) ?? date(s)
        return parser.string(from: d)
    }
    static func dayNumber(_ s: String) -> Int { cal.component(.day, from: date(s)) }
    /// 1 Sunday … 7 Saturday
    static func weekday(_ s: String) -> Int { cal.component(.weekday, from: date(s)) }
    /// days from a to b
    static func between(_ a: String, _ b: String) -> Int {
        cal.dateComponents([.day], from: date(a), to: date(b)).day ?? 0
    }
    static func label(_ s: String, today: String) -> String {
        if s == today { return "Today" }
        if s == add(today, 1) { return "Tomorrow" }
        if s == add(today, -1) { return "Yesterday" }
        let n: Int = between(today, s)
        if n > 0 && n < 7 { return fmt(s, "EEEE") }
        return fmt(s, "EEE d MMM")
    }
    /// "today", "yesterday", "3 days ago", "12 Sep"
    static func ago(_ s: String, today: String) -> String {
        let n: Int = between(String(s.prefix(10)), today)
        if n <= 0 { return "today" }
        if n == 1 { return "yesterday" }
        if n < 7 { return String(n) + " days ago" }
        return fmt(s, "d MMM")
    }
    static func nextMidnight(after d: Date) -> Date {
        let start: Date = cal.startOfDay(for: d)
        return cal.date(byAdding: .day, value: 1, to: start) ?? d.addingTimeInterval(86400)
    }
    static func monthName(_ m: String) -> String { fmt(String(m.prefix(7)) + "-01", "MMMM") }
    static func time12(_ t: String) -> String {
        let p: [Int] = t.split(separator: ":").compactMap { Int($0) }
        guard p.count >= 2 else { return "" }
        let h: Int = p[0] % 12 == 0 ? 12 : p[0] % 12
        let tail: String = p[0] >= 12 ? " pm" : " am"
        return String(h) + ":" + String(format: "%02d", p[1]) + tail
    }
}

// MARK: - How a payment was paid

enum WWay {
    static func symbol(_ md: String) -> String {
        switch md {
        case "card": return "creditcard.fill"
        case "upi": return "qrcode"
        case "auto": return "arrow.triangle.2.circlepath"
        case "atm", "cash": return "banknote.fill"
        case "wallet": return "wallet.bifold.fill"
        default: return "building.columns.fill"
        }
    }
    static func word(_ md: String) -> String {
        switch md {
        case "card": return "Card"
        case "upi": return "UPI"
        case "transfer": return "Transfer"
        case "auto": return "Auto-debit"
        case "atm": return "ATM"
        case "cash": return "Cash"
        case "wallet": return "Wallet"
        default: return ""
        }
    }
    /// "UPI, HDFC Bank", "Card", "Cash"
    static func line(_ t: WFTx) -> String {
        let w: String = word(t.way)
        if t.way == "cash" { return "Cash" }
        if t.bank.isEmpty { return w }
        if w.isEmpty { return t.bank }
        return w + ", " + t.bank
    }
}

/// a bank's initials, the way the app marks it when there's no icon
enum WMark {
    static func of(_ bank: String) -> String {
        if bank.count <= 4 && bank == bank.uppercased() { return bank }
        let caps: String = bank.filter { $0.isUppercase }
        if caps.count >= 2 { return String(caps.prefix(3)) }
        return String(bank.prefix(2)).uppercased()
    }
}

// MARK: - The entry every kosh widget draws

struct KEntry: TimelineEntry {
    let date: Date
    let feed: WFeed?
    var hidden: Bool = false
    /// whose money: "family", "me", or a person's id
    var who: String = "family"
    /// net worth's span: 0 six months, 1 a year, 2 all, 3 three months
    var range: Int = 0
    /// the month in days: last month instead of this one
    var lastMonth: Bool = false
    /// which thing kosh noticed is showing
    var note: Int = 0
    var relevance: TimelineEntryRelevance? = nil
    /// the day this entry draws
    var today: String { WDay.iso(date) }
    /// the feed is from an earlier month than this entry's
    var stale: Bool {
        guard let f = feed else { return false }
        return String(today.prefix(7)) != f.month.m
    }
}

enum KLoad {
    struct Settings { var hidden: Bool; var range: Int; var lastMonth: Bool; var note: Int }
    static func settings() -> Settings {
        let d: UserDefaults? = WFStore.defaults
        return Settings(hidden: d?.bool(forKey: WFStore.hiddenKey) ?? false,
                        range: d?.integer(forKey: WFStore.rangeKey) ?? 0,
                        lastMonth: d?.bool(forKey: WFStore.lastMonthKey) ?? false,
                        note: d?.integer(forKey: WFStore.noteKey) ?? 0)
    }
    static func entry(_ date: Date, feed: WFeed?, _ s: Settings, who: String) -> KEntry {
        KEntry(date: date, feed: feed, hidden: s.hidden, who: who, range: s.range, lastMonth: s.lastMonth, note: s.note)
    }
    /// the gallery shows a made-up household; the real thing draws what the app last wrote
    static func now(preview: Bool, who: String) -> KEntry {
        if preview { return KEntry(date: Date(), feed: Sample.feed, who: who) }
        return entry(Date(), feed: WFStore.read(), settings(), who: who)
    }
    /// now, then each midnight for three days (so "tomorrow" turns into "today"); hourly when it rotates
    static func timeline(who: String, rotate: Bool = false, due: Bool = false) -> Timeline<KEntry> {
        let feed: WFeed? = WFStore.read()
        let s: Settings = settings()
        let now: Date = Date()
        var dates: [Date] = [now]
        if rotate {
            for h in 1...11 { dates.append(now.addingTimeInterval(Double(h) * 3600)) }
        } else {
            var m: Date = WDay.nextMidnight(after: now)
            for _ in 0..<3 {
                dates.append(m)
                m = WDay.nextMidnight(after: m.addingTimeInterval(60))
            }
        }
        var out: [KEntry] = []
        for (i, d) in dates.enumerated() {
            var e: KEntry = entry(d, feed: feed, s, who: who)
            if rotate { e.note = s.note + i }
            if due { e.relevance = dueRelevance(e) }
            out.append(e)
        }
        return Timeline(entries: out, policy: .atEnd)
    }
    /// the Smart Stack brings Coming up forward when something is due today or tomorrow
    static func dueRelevance(_ e: KEntry) -> TimelineEntryRelevance? {
        guard let f = e.feed else { return nil }
        let soon: String = WDay.add(e.today, 1)
        for d in f.due where !d.incoming {
            guard let day = d.date else { continue }
            if day >= e.today && day <= soon {
                let score: Float = day == e.today ? 1.0 : 0.7
                return TimelineEntryRelevance(score: score, duration: 86400)
            }
        }
        return TimelineEntryRelevance(score: 0.1)
    }
}

struct KoshProvider: TimelineProvider {
    var rotate: Bool = false
    var due: Bool = false
    func placeholder(in context: Context) -> KEntry { KEntry(date: Date(), feed: Sample.feed) }
    func getSnapshot(in context: Context, completion: @escaping (KEntry) -> Void) {
        completion(KLoad.now(preview: context.isPreview, who: "family"))
    }
    func getTimeline(in context: Context, completion: @escaping (Timeline<KEntry>) -> Void) {
        completion(KLoad.timeline(who: "family", rotate: rotate, due: due))
    }
}

// MARK: - Whose money: the household's, or one person's

struct PersonEntity: AppEntity {
    static let typeDisplayRepresentation: TypeDisplayRepresentation = "Person"
    static let defaultQuery = PersonQuery()
    var id: String
    var title: String
    var displayRepresentation: DisplayRepresentation { DisplayRepresentation(title: "\(title)") }
}

struct PersonQuery: EntityQuery {
    func all() -> [PersonEntity] {
        var out: [PersonEntity] = []
        for p in WFStore.read()?.people ?? [] { out.append(PersonEntity(id: p.id, title: p.title)) }
        if out.isEmpty { out.append(PersonEntity(id: "family", title: "Family")) }
        return out
    }
    func entities(for identifiers: [String]) async throws -> [PersonEntity] {
        all().filter { identifiers.contains($0.id) }
    }
    func suggestedEntities() async throws -> [PersonEntity] { all() }
    func defaultResult() async -> PersonEntity? { all().first }
}

struct WhoIntent: WidgetConfigurationIntent {
    static let title: LocalizedStringResource = "Whose money"
    static let description = IntentDescription("The household's, or one person's.")
    @Parameter(title: "Whose") var person: PersonEntity?
    init() {}
}

struct WhoProvider: AppIntentTimelineProvider {
    func placeholder(in context: Context) -> KEntry { KEntry(date: Date(), feed: Sample.feed) }
    func snapshot(for configuration: WhoIntent, in context: Context) async -> KEntry {
        KLoad.now(preview: context.isPreview, who: configuration.person?.id ?? "family")
    }
    func timeline(for configuration: WhoIntent, in context: Context) async -> Timeline<KEntry> {
        KLoad.timeline(who: configuration.person?.id ?? "family")
    }
}

// MARK: - Taps that change a widget in place

struct CycleRangeIntent: AppIntent {
    static let title: LocalizedStringResource = "Change the span"
    static let isDiscoverable: Bool = false
    init() {}
    func perform() async throws -> some IntentResult {
        let d: UserDefaults? = WFStore.defaults
        let i: Int = d?.integer(forKey: WFStore.rangeKey) ?? 0
        d?.set((i + 1) % 4, forKey: WFStore.rangeKey)
        return .result()
    }
}

struct SwitchMonthIntent: AppIntent {
    static let title: LocalizedStringResource = "This month or last"
    static let isDiscoverable: Bool = false
    init() {}
    func perform() async throws -> some IntentResult {
        let d: UserDefaults? = WFStore.defaults
        let on: Bool = d?.bool(forKey: WFStore.lastMonthKey) ?? false
        d?.set(!on, forKey: WFStore.lastMonthKey)
        return .result()
    }
}

struct NextNoteIntent: AppIntent {
    static let title: LocalizedStringResource = "Next thing kosh noticed"
    static let isDiscoverable: Bool = false
    init() {}
    func perform() async throws -> some IntentResult {
        let d: UserDefaults? = WFStore.defaults
        let i: Int = d?.integer(forKey: WFStore.noteKey) ?? 0
        d?.set(i + 1, forKey: WFStore.noteKey)
        return .result()
    }
}

// MARK: - The look (24 Oct 2026): a plain surface, white by day and the system's graphite by night, no glows; one
// accent (the app's) for the marks that matter, green for money in, warm orange for what's due or running hot;
// sentence-case labels with their dates; figures set like a statement, the ₹ small and quiet; the month as a row of
// daily ticks. The canvas "kosh widgets" is the reference for every widget

extension Color {
    /// one colour by night, another by day
    static func dyn(_ dark: String, _ light: String) -> Color {
        let d: UIColor = UIColor(koshHex: dark)
        let l: UIColor = UIColor(koshHex: light)
        return Color(uiColor: UIColor { tc in tc.userInterfaceStyle == .dark ? d : l })
    }
    /// a category's colour, softened but still itself: lighter and a little less saturated by night, deeper by day
    static func soft(_ hex: String) -> Color {
        let base: UIColor = UIColor(koshHex: hex)
        var h: CGFloat = 0, sat: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        base.getHue(&h, saturation: &sat, brightness: &b, alpha: &a)
        let night: UIColor = UIColor(hue: h, saturation: min(sat, 1) * 0.62, brightness: max(b, 0.88), alpha: 1)
        let day: UIColor = UIColor(hue: h, saturation: min(sat, 1) * 0.8, brightness: min(b, 0.72), alpha: 1)
        return Color(uiColor: UIColor { tc in tc.userInterfaceStyle == .dark ? night : day })
    }
}

/// a soft light on a widget's surface: its colour and strength, where it sits, and how far it reaches
/// (a fraction of the widget's own width and height, so it spreads the same on every size)
struct KGlow {
    let hex: String
    let opacity: Double
    let at: UnitPoint
    var reach: CGFloat = 0.62
}

/// each widget's surface and accent: a deep jewel tone by night with one soft light in a corner, porcelain with
/// the same light by day
enum KTone {
    case violet, warm, blue, teal, slate, ember, plum, green, graphite, paper, royal
    case card(String)

    /// top and bottom of the surface, by night then by day
    var surface: (String, String, String, String) {
        switch self {
        case .violet: return ("#2D2856", "#16142D", "#F7F6FC", "#ECEAF6")
        case .warm: return ("#3A2A1F", "#1A130E", "#FBF7F2", "#F2EAE1")
        case .blue: return ("#222D4A", "#10152A", "#F5F8FD", "#E9EEF7")
        case .teal: return ("#1B3D39", "#0D1E1C", "#F3F9F7", "#E5F0ED")
        case .slate: return ("#19352F", "#0B1716", "#F3F8F6", "#E5EFEB")
        case .ember: return ("#37241E", "#170F0D", "#FBF6F2", "#F2E8E1")
        case .plum: return ("#34243F", "#170F1E", "#F9F6FB", "#EEE8F3")
        case .green: return ("#1E3B2B", "#0D1B14", "#F3F9F5", "#E5F0E9")
        case .graphite: return ("#2A2A2D", "#121214", "#F7F7F8", "#EBEBED")
        case .paper: return ("#FAF3E6", "#EEE0CA", "#FAF3E6", "#EEE0CA")
        case .royal: return ("#2C49C6", "#18266E", "#2C49C6", "#18266E")
        case .card(let hex):
            let (h, sat, _) = Self.hsb(hex)
            let top: UIColor = UIColor(hue: h, saturation: min(1, sat * 0.85), brightness: 0.5, alpha: 1)
            let bottom: UIColor = UIColor(hue: h, saturation: min(1, sat * 0.75), brightness: 0.23, alpha: 1)
            return (Self.hex(top), Self.hex(bottom), Self.hex(top), Self.hex(bottom))
        }
    }
    /// the soft light each surface carries
    var glows: [KGlow] {
        switch self {
        case .violet: return [KGlow(hex: "#9684FF", opacity: 0.34, at: .topTrailing)]
        case .warm: return [KGlow(hex: "#F5A855", opacity: 0.28, at: .topLeading)]
        case .blue: return [KGlow(hex: "#6E96FF", opacity: 0.26, at: .topTrailing)]
        case .teal: return [KGlow(hex: "#4FD1B5", opacity: 0.3, at: .bottomLeading, reach: 0.7)]
        case .slate: return [KGlow(hex: "#5ED1B0", opacity: 0.26, at: .topTrailing, reach: 0.7)]
        case .ember: return [KGlow(hex: "#F4A57E", opacity: 0.22, at: .topTrailing, reach: 0.7)]
        case .plum: return [KGlow(hex: "#C8A0F5", opacity: 0.24, at: .topTrailing)]
        case .green: return [KGlow(hex: "#8EE0A8", opacity: 0.22, at: .bottomLeading, reach: 0.7)]
        case .graphite: return []
        case .paper: return [KGlow(hex: "#FFFDF8", opacity: 1, at: .topLeading, reach: 0.75)]
        case .royal: return [KGlow(hex: "#8CAAFF", opacity: 0.4, at: .topTrailing, reach: 0.7)]
        case .card(let hex):
            let (h, sat, _) = Self.hsb(hex)
            let glow: UIColor = UIColor(hue: h, saturation: min(1, sat * 0.45), brightness: 1, alpha: 1)
            return [KGlow(hex: Self.hex(glow), opacity: 0.3, at: .topTrailing)]
        }
    }
    /// the one colour kept for the marks that matter: the app's accent, on every widget
    var accent: Color { .kosh }
    /// (the jewel tones the widgets wore before the plain surfaces, kept for reference)
    var oldAccent: Color {
        switch self {
        case .violet: return Color.dyn("#C9C0FF", "#5B4BD6")
        case .warm: return Color.dyn("#F7B871", "#B36A1E")
        case .blue: return Color.dyn("#A9C4FF", "#3B5BFD")
        case .teal: return Color.dyn("#A5EED9", "#1F7A63")
        case .slate: return Color.dyn("#A6E8D4", "#2C7A68")
        case .ember: return Color.dyn("#F4A57E", "#B4602E")
        case .plum: return Color.dyn("#D7B8F5", "#6A4DB8")
        case .green: return Color.dyn("#8EE0A8", "#2E8A55")
        case .graphite: return Color.dyn("#E6E6EB", "#3A3A3F")
        case .paper: return Color(hex: "#A3461F")
        case .royal: return Color.white
        case .card(let hex):
            let (h, sat, _) = Self.hsb(hex)
            return Color(uiColor: UIColor(hue: h, saturation: sat * 0.35, brightness: 0.92, alpha: 1))
        }
    }
    /// (no ribbons, bands or fixed light any more: every surface follows the phone, day or night)
    var ribbon: Bool { false }
    var band: Bool { false }
    var fixedScheme: ColorScheme? { nil }
    static func hsb(_ hex: String) -> (CGFloat, CGFloat, CGFloat) {
        let c: UIColor = UIColor(koshHex: hex)
        var h: CGFloat = 0, sat: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        c.getHue(&h, saturation: &sat, brightness: &b, alpha: &a)
        return (h, sat, b)
    }
    static func hex(_ c: UIColor) -> String {
        var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        c.getRed(&r, green: &g, blue: &b, alpha: &a)
        return String(format: "#%02X%02X%02X", Int(r * 255), Int(g * 255), Int(b * 255))
    }
}

/// the few colours besides the accent, each readable on both surfaces (4.5:1 or better): money in, due or running
/// hot (late is the same warm), gone stale, and the surfaces' own inks
enum KInk {
    static let good: Color = Color.dyn("#5ED492", "#1B7C46")
    static let warm: Color = Color.dyn("#FF9F66", "#B4501A")
    static let late: Color = warm
    /// the surface: white by day, the system's graphite by night
    static let surface: Color = Color.dyn("#1C1C1E", "#FFFFFF")
    static let ink: Color = Color.dyn("#F5F5F7", "#111214")
    static let quiet: Color = Color.dyn("#A3A3AA", "#565A62")
    /// a hairline, and a fainter one for rules and empty tracks
    static let hair: Color = Color.dyn("#FFFFFF", "#111214").opacity(0.13)
    static let faint: Color = Color.dyn("#FFFFFF", "#111214").opacity(0.07)
}

/// every kosh widget: amounts hidden when asked, where a tap goes, and its surface (with its own lights, if given)
struct KFrame<Content: View>: View {
    let entry: KEntry
    let link: String
    var accent: Color = .kosh
    var tone: KTone = .graphite
    var glows: [KGlow]? = nil
    @ViewBuilder let content: Content
    @Environment(\.widgetFamily) private var family
    var body: some View {
        let url: URL? = URL(string: "kosh://" + link)
        let reasons: RedactionReasons = entry.hidden ? RedactionReasons.privacy : RedactionReasons()
        if let fixed = tone.fixedScheme, !KCanvas.accessory(family) {
            content
                .redacted(reason: reasons)
                .environment(\.colorScheme, fixed)
                .widgetURL(url)
                .containerBackground(for: .widget) { KCanvas(tone: tone, family: family, glows: glows) }
        } else {
            content
                .redacted(reason: reasons)
                .widgetURL(url)
                .containerBackground(for: .widget) { KCanvas(tone: tone, family: family, glows: glows) }
        }
    }
}

/// the surface: plain, white by day and graphite by night (iOS takes it away for the tinted and clear looks)
struct KCanvas: View {
    let tone: KTone
    let family: WidgetFamily
    var glows: [KGlow]? = nil
    var body: some View {
        if Self.accessory(family) { Color.clear } else { KInk.surface }
    }
    static let band: [Gradient.Stop] = [
        Gradient.Stop(color: Color.white.opacity(0), location: 0.32),
        Gradient.Stop(color: Color.white.opacity(0.08), location: 0.48),
        Gradient.Stop(color: Color.white.opacity(0), location: 0.62)
    ]
    static func accessory(_ f: WidgetFamily) -> Bool {
        f == .accessoryCircular || f == .accessoryRectangular || f == .accessoryInline
    }
}

/// a bookmark ribbon: straight across the top, a notch cut into its tail
struct Ribbon: Shape {
    func path(in r: CGRect) -> Path {
        var p = Path()
        p.move(to: CGPoint(x: r.minX, y: r.minY))
        p.addLine(to: CGPoint(x: r.maxX, y: r.minY))
        p.addLine(to: CGPoint(x: r.maxX, y: r.maxY))
        p.addLine(to: CGPoint(x: r.midX, y: r.minY + r.height * 0.76))
        p.addLine(to: CGPoint(x: r.minX, y: r.maxY))
        p.closeSubpath()
        return p
    }
}

/// a widget's label: what it is in sentence case, and under it the dates its figures cover ("Spent", "1–24 Oct"),
/// with an optional figure or control on the right
struct KHeader<Trailing: View>: View {
    let title: String
    var sub: String = ""
    var sym: String = ""
    var color: Color = .kosh
    @ViewBuilder let trailing: Trailing
    var body: some View {
        HStack(alignment: .top, spacing: 6) {
            VStack(alignment: .leading, spacing: 0) {
                Text(title).kLabel()
                if !sub.isEmpty { Text(sub).kSub() }
            }
            Spacer(minLength: 4)
            trailing
        }
    }
}

extension KHeader where Trailing == EmptyView {
    init(title: String, sub: String = "", sym: String = "", color: Color = .kosh) {
        self.title = title
        self.sub = sub
        self.sym = sym
        self.color = color
        self.trailing = EmptyView()
    }
}

extension Text {
    /// a widget's label: 13 pt semibold, the ink
    func kLabel() -> some View {
        self.font(.system(size: 13, weight: .semibold)).kerning(-0.13).foregroundStyle(KInk.ink).lineLimit(1)
    }
    /// the quiet line under it: dates, how it was paid, what a figure means
    func kSub(_ color: Color = KInk.quiet) -> some View {
        self.font(.system(size: 11.5)).foregroundStyle(color).lineLimit(1)
    }
    /// a row's name
    func kName() -> some View {
        self.font(.system(size: 13, weight: .medium)).foregroundStyle(KInk.ink).lineLimit(1)
    }
}

/// a figure the way a good statement sets it: the ₹ small, quiet and raised, the digits big, even and tight, the
/// unit (L, Cr) quiet again
struct KAmount: View {
    let v: Double
    var size: CGFloat = 30
    var mode: WMoney.Mode = .full
    var color: Color = KInk.ink
    var weight: Font.Weight = .semibold
    var sign: String = ""
    var body: some View {
        let p: WMoney.Parts = WMoney.parts(v, mode)
        // (the ₹ a little smaller than the figure and lifted only slightly, sitting with the digits, not above them like
        // a footnote; the unit as large as the ₹, on the line, after a thin space)
        let small: CGFloat = size * 0.66
        let symbol: Text = Text(sign + "₹").font(.system(size: small, weight: .medium)).foregroundStyle(KInk.quiet).baselineOffset(size * 0.1)
        let figure: Text = Text(p.number).font(.system(size: size, weight: weight)).kerning(-size * 0.03)
        let unit: Text = Text(p.unit.isEmpty ? "" : "\u{2009}" + p.unit).font(.system(size: small, weight: .medium)).foregroundStyle(KInk.quiet)
        Text("\(symbol)\(figure)\(unit)")
            .foregroundStyle(color)
            .monospacedDigit()
            .lineLimit(1)
            .minimumScaleFactor(0.5)
            .privacySensitive()
    }
}

/// a row's amount: 13 pt semibold, even digits; "+" and green when it's money in
struct KRowAmount: View {
    let v: Double
    var incoming: Bool = false
    var mode: WMoney.Mode = .full
    var body: some View {
        let p: WMoney.Parts = WMoney.parts(v, mode)
        Text((incoming ? "+₹" : "₹") + p.number + (p.unit.isEmpty ? "" : "\u{2009}" + p.unit))
            .font(.system(size: 13, weight: .semibold)).kerning(-0.13).monospacedDigit()
            .foregroundStyle(incoming ? KInk.good : KInk.ink)
            .lineLimit(1)
            .privacySensitive()
    }
}

/// a short verdict on a soft wash of its own colour: "10% below a usual October", "+32%"
struct KPill: View {
    enum Kind { case good, warm, cool }
    let text: String
    var kind: Kind = .cool
    var body: some View {
        let ink: Color = kind == .good ? KInk.good : kind == .warm ? KInk.warm : Color.kosh
        Text(text)
            .font(.system(size: 11, weight: .semibold))
            .foregroundStyle(ink)
            .lineLimit(1)
            .padding(.horizontal, 8)
            .frame(height: 20)
            .background(ink.opacity(0.13), in: Capsule())
            .widgetAccentable()
    }
}

/// the month as a row of daily ticks, kosh's mark: each day spent a tick as tall as its spending, a day without any a
/// low stub, today's in the accent, the days to come as dots
struct KTicks: View {
    /// what each day so far spent, day 1 first (the last is today)
    let days: [Double]
    /// how many days the row has room for (the month's)
    var total: Int = 0
    var height: CGFloat = 60
    var width: CGFloat = 4
    /// the ticks spread across the row, or sit close with a gap between
    var gap: CGFloat? = nil
    var body: some View {
        let n: Int = max(total, days.count)
        let top: Double = max(days.max() ?? 0, 1)
        let tick = { (i: Int) -> AnyView in
            if i >= days.count {
                return AnyView(Capsule().fill(KInk.hair).frame(width: width, height: width))
            }
            let v: Double = days[i]
            let isToday: Bool = i == days.count - 1
            if v <= 0 { return AnyView(Capsule().fill(isToday ? Color.kosh : KInk.hair).frame(width: width, height: 2)) }
            let h: CGFloat = max(3, CGFloat(v / top) * height)
            return AnyView(Capsule().fill(isToday ? Color.kosh : KInk.ink).frame(width: width, height: h).widgetAccentable(isToday))
        }
        if let g = gap {
            HStack(alignment: .bottom, spacing: g) { ForEach(0..<n, id: \.self) { tick($0) } }
                .frame(height: height, alignment: .bottom)
        } else {
            HStack(alignment: .bottom, spacing: 0) {
                ForEach(0..<n, id: \.self) { i in
                    tick(i)
                    if i < n - 1 { Spacer(minLength: 0) }
                }
            }
            .frame(height: height, alignment: .bottom)
        }
    }
}

/// a budget as one bar: what's spent in the ink, what's still to go out in the accent's light, and a tick where the
/// calendar is
struct KBudgetBar: View {
    /// shares of the budget, 0…1
    let spent: Double
    var due: Double = 0
    /// how far through the month today is, 0…1 (no tick when nil)
    var calendar: Double? = nil
    var height: CGFloat = 6
    var body: some View {
        GeometryReader { g in
            let w: CGFloat = g.size.width
            let s: CGFloat = w * CGFloat(min(max(spent, 0), 1))
            let d: CGFloat = min(w - s, w * CGFloat(max(due, 0)))
            ZStack(alignment: .leading) {
                Capsule().fill(KInk.faint)
                HStack(spacing: 0) {
                    Rectangle().fill(spent > 1 ? KInk.warm : KInk.ink).frame(width: s)
                    Rectangle().fill(Color.kosh.opacity(0.45)).frame(width: d)
                }
                .clipShape(Capsule())
                if let c = calendar {
                    Capsule().fill(Color.kosh).frame(width: 2, height: height + 8)
                        .offset(x: max(0, min(w - 2, w * CGFloat(c) - 1)))
                        .widgetAccentable()
                }
            }
            .frame(height: height)
            .frame(maxHeight: .infinity)
        }
        .frame(height: height + 8)
    }
}

/// a fine rule across a widget
struct KHairline: View {
    var body: some View { Rectangle().fill(KInk.faint).frame(height: 1) }
}

/// a symbol drawn fine in a hairline circle: one ink for all of them, so a list reads calm
struct KGlyph: View {
    let sym: String
    let color: Color
    var size: CGFloat = 28
    var body: some View {
        Image(systemName: KGlyph.outline(sym))
            .font(.system(size: size * 0.42, weight: .regular))
            .foregroundStyle(KInk.ink)
            .frame(width: size, height: size)
            .overlay(Circle().strokeBorder(KInk.hair, lineWidth: 1))
            .widgetAccentable()
    }
    /// "cart.fill" → "cart" when the outline exists
    static func outline(_ s: String) -> String {
        if s.hasSuffix(".fill") {
            let o: String = String(s.dropLast(5))
            if UIImage(systemName: o) != nil { return o }
        }
        return s
    }
}

/// when there's nothing to draw yet
struct KEmpty: View {
    let sym: String
    let title: String
    let line: String
    var color: Color = .kosh
    var body: some View {
        VStack(alignment: .leading, spacing: 3) {
            KGlyph(sym: sym, color: color, size: 30)
            Spacer(minLength: 0)
            Text(title).font(.system(size: 15, weight: .semibold)).lineLimit(2)
            Text(line).font(.system(size: 12)).foregroundStyle(.secondary).lineLimit(3)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .leading)
    }
}

enum KCopy {
    static let openTitle = "Open kosh"
    static let openLine = "Your figures appear here once kosh has read your mail."
    static func staleLine(_ e: KEntry) -> String {
        "Open kosh to start " + WDay.monthName(e.today) + "."
    }
}
