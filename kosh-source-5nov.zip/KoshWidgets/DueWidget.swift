import SwiftUI
import WidgetKit

// MARK: - Coming up: bills, EMIs, card bills, premiums, committee instalments and rent, in date order
//
// The next thing to pay with its day in the warm colour; the next two weeks as what goes out and what comes in; each
// payment with its date in the margin. (The canvas "kosh widgets", board Coming up.)

struct DueWidget: Widget {
    let kind: String = "KoshDue"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: KoshProvider(due: true)) { e in
            DueView(entry: e)
        }
        .configurationDisplayName("Coming up")
        .description("What's due to go out and come in over the next weeks: card bills, EMIs, premiums, rent.")
        .supportedFamilies([.systemSmall, .systemMedium, .systemLarge, .accessoryCircular, .accessoryRectangular, .accessoryInline])
    }
}

struct DueMath {
    let today: String
    /// dated from today on, then this month's any-day ones
    let dated: [WFDue]
    let anyDay: [WFDue]
    init(_ f: WFeed, today: String) {
        self.today = today
        var a: [WFDue] = []
        var b: [WFDue] = []
        let sameMonth: Bool = String(today.prefix(7)) == f.month.m
        for d in f.due {
            if let day = d.date {
                if day >= today { a.append(d) }
            } else if sameMonth {
                b.append(d)
            }
        }
        dated = a
        anyDay = b
    }
    var next: WFDue? { dated.first { !$0.incoming } }
    func within(_ days: Int) -> [WFDue] {
        let end: String = WDay.add(today, days)
        return dated.filter { ($0.date ?? "") <= end }
    }
    func sum(_ days: Int, incoming: Bool) -> Double {
        var s: Double = 0
        for d in within(days) where d.incoming == incoming { s += d.amt }
        return s
    }
    var weekOut: Double { sum(6, incoming: false) }
    var weekIn: Double { sum(6, incoming: true) }
    var weekCount: Int { within(6).filter { !$0.incoming }.count }
    /// what goes out and comes in over the next two weeks
    var soonOut: Double { sum(13, incoming: false) }
    var soonIn: Double { sum(13, incoming: true) }
    /// the next two weeks as dates: "24 Oct–6 Nov", "1–14 Nov"
    var fortnight: String { DueText.span(today, WDay.add(today, 13)) }
    /// what the small widget says under the next payment: "3 more this week"
    var moreLine: String {
        let n: Int = within(6).count - (next.map { within(6).contains($0) ? 1 : 0 } ?? 0)
        if n <= 0 {
            if anyDay.isEmpty { return "Nothing else this week" }
            return String(anyDay.count) + " due any day this month"
        }
        return String(n) + " more this week"
    }
    /// "Today", "Tomorrow", "Tuesday", "Wed 12 Nov", or any day this month
    func when(_ d: WFDue) -> String {
        guard let day = d.date else { return "Any day in " + WDay.monthName(today) }
        return WDay.label(day, today: today)
    }
    /// due today or tomorrow: said in the warm colour
    func soon(_ d: WFDue) -> Bool {
        guard let day = d.date, !d.incoming else { return false }
        return WDay.between(today, day) <= 1
    }
    /// a medium row's line: when, or that it's coming in
    func shortLine(_ d: WFDue) -> String {
        if d.incoming { return "Coming in" }
        return d.date == nil ? WDay.monthName(today) + "'s" : when(d)
    }
    /// a large row's line: "Tomorrow, minimum ₹1,170" when it's close; else what the payment is ("Auto-pay, from your bank")
    func longLine(_ d: WFDue) -> String {
        if d.sub.isEmpty { return d.incoming ? "Coming in" : when(d) }
        if soon(d) { return when(d) + ", " + DueText.lowerFirst(d.sub) }
        return d.sub
    }
}

enum DueText {
    static func color(_ d: WFDue) -> Color { d.incoming ? KInk.good : KInk.ink }
    static func lowerFirst(_ s: String) -> String {
        guard let c = s.first else { return s }
        // ("Minimum ₹1,170" reads on after a comma; "EMI" and "SIP" keep their capitals)
        let second: Character? = s.dropFirst().first
        if let n = second, n.isUppercase { return s }
        return c.lowercased() + s.dropFirst()
    }
    /// two days as one span: "24 Oct–6 Nov", or "24–31 Oct" in one month
    static func span(_ a: String, _ b: String) -> String {
        if a.prefix(7) == b.prefix(7) { return String(WDay.dayNumber(a)) + "–" + WDay.fmt(b, "d MMM") }
        return WDay.fmt(a, "d MMM") + "–" + WDay.fmt(b, "d MMM")
    }
}

struct DueView: View {
    let entry: KEntry
    @Environment(\.widgetFamily) private var family
    var body: some View {
        KFrame(entry: entry, link: "due") {
            if let f = entry.feed, !f.empty {
                let m: DueMath = DueMath(f, today: entry.today)
                switch family {
                case .accessoryCircular: DueCircular(m: m)
                case .accessoryRectangular: DueRect(m: m)
                case .accessoryInline: DueInline(m: m)
                case .systemMedium: DueMedium(m: m)
                case .systemLarge: DueLarge(m: m)
                default: DueSmall(m: m)
                }
            } else {
                switch family {
                case .accessoryCircular: ZStack { AccessoryWidgetBackground(); Image(systemName: "calendar") }
                case .accessoryRectangular, .accessoryInline: Text("Open kosh")
                default: KEmpty(sym: "calendar", title: KCopy.openTitle, line: KCopy.openLine)
                }
            }
        }
    }
}

struct DueClear: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            KHeader(title: "Coming up", sub: "Next six weeks")
            Spacer(minLength: 0)
            Image(systemName: "checkmark.circle").font(.system(size: 22, weight: .regular)).foregroundStyle(KInk.good).widgetAccentable()
            Text("Nothing to pay").kLabel().padding(.top, 4)
            Text("in the next six weeks").kSub()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .leading)
    }
}

/// the next payment: when (warm when it's today or tomorrow), what, how much; then how many more this week
struct DueSmall: View {
    let m: DueMath
    var body: some View {
        if let n = m.next {
            let inWeek: Bool = m.within(6).contains(n)
            VStack(alignment: .leading, spacing: 0) {
                KHeader(title: "Coming up", sub: inWeek ? "Next 7 days" : "Next to pay")
                Spacer(minLength: 6)
                Text(m.when(n))
                    .font(.system(size: 11.5, weight: .semibold))
                    .foregroundStyle(m.soon(n) ? KInk.warm : KInk.quiet)
                    .lineLimit(1)
                    .widgetAccentable()
                Text(n.name).font(.system(size: 13, weight: .medium)).foregroundStyle(KInk.ink).lineLimit(1).minimumScaleFactor(0.85).padding(.top, 2)
                KAmount(v: n.amt, size: 26).padding(.top, 5)
                KHairline().padding(.top, 10).padding(.bottom, 8)
                Text(m.moreLine).kSub().minimumScaleFactor(0.85)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        } else {
            DueClear()
        }
    }
}

/// a date in the margin: the day, the month small under it ("Any day" when it has no date)
struct DueMargin: View {
    let d: WFDue
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            if let day = d.date {
                Text(String(WDay.dayNumber(day))).font(.system(size: 15, weight: .semibold)).kerning(-0.3).monospacedDigit()
                    .foregroundStyle(KInk.ink)
                Text(WDay.fmt(day, "MMM")).font(.system(size: 10)).foregroundStyle(KInk.quiet)
            } else {
                Text("Any").font(.system(size: 12, weight: .semibold)).foregroundStyle(KInk.ink)
                Text("day").font(.system(size: 10)).foregroundStyle(KInk.quiet)
            }
        }
        .frame(width: 28, alignment: .leading)
    }
}

/// the date in the margin, a hairline, what it is and when, then the amount
struct DueRow: View {
    let d: WFDue
    let m: DueMath
    var long: Bool = false
    var body: some View {
        let line: String = long ? m.longLine(d) : m.shortLine(d)
        HStack(spacing: 10) {
            DueMargin(d: d)
            Rectangle().fill(KInk.hair).frame(width: 1).padding(.vertical, 5)
            VStack(alignment: .leading, spacing: 0) {
                Text(d.name).kName()
                Text(line).kSub(m.soon(d) ? KInk.warm : KInk.quiet).privacySensitive()
            }
            Spacer(minLength: 6)
            KRowAmount(v: d.amt, incoming: d.incoming)
        }
        .fixedSize(horizontal: false, vertical: true)
    }
}

/// the next two weeks: what goes out, large; what comes in, green; then the first three payments
struct DueMedium: View {
    let m: DueMath
    var body: some View {
        let rows: [WFDue] = Array((m.dated + m.anyDay).prefix(3))
        if rows.isEmpty {
            DueClear()
        } else {
            HStack(spacing: 16) {
                VStack(alignment: .leading, spacing: 0) {
                    KHeader(title: "Coming up", sub: m.fortnight)
                    Spacer(minLength: 4)
                    KAmount(v: m.soonOut, size: 24)
                    Text("going out").kSub().padding(.top, 4)
                    if m.soonIn > 0 {
                        DueIn(v: m.soonIn).padding(.top, 8)
                    }
                }
                .frame(width: 118, alignment: .leading)
                VStack(spacing: 0) {
                    ForEach(rows, id: \.id) { d in
                        DueRow(d: d, m: m).frame(maxHeight: .infinity)
                    }
                }
                .frame(maxWidth: .infinity)
            }
        }
    }
}

/// "+₹32,000 in": the figure green, the word lighter
struct DueIn: View {
    let v: Double
    var body: some View {
        let p: WMoney.Parts = WMoney.parts(v, .full)
        let fig: Text = Text("+₹" + p.number).font(.system(size: 13, weight: .semibold))
        let word: Text = Text(" in").font(.system(size: 13, weight: .medium))
        Text("\(fig)\(word)").foregroundStyle(KInk.good).monospacedDigit().lineLimit(1).minimumScaleFactor(0.8).privacySensitive()
    }
}

/// "₹58,960 out": the figure in the ink, the word quiet
struct DueOut: View {
    let v: Double
    var body: some View {
        let p: WMoney.Parts = WMoney.parts(v, .full)
        let fig: Text = Text("₹" + p.number).font(.system(size: 13, weight: .semibold)).foregroundStyle(KInk.ink)
        let word: Text = Text(" out").font(.system(size: 11.5, weight: .medium)).foregroundStyle(KInk.quiet)
        Text("\(fig)\(word)").monospacedDigit().lineLimit(1).minimumScaleFactor(0.8).privacySensitive()
    }
}

/// two weeks as a strip of days: the weekday, the date, and a dot under each day something is due (warm going out,
/// green coming in); today on a wash of the accent
struct TwoWeeks: View {
    let m: DueMath
    var body: some View {
        let days: [String] = (0..<14).map { WDay.add(m.today, $0) }
        HStack(spacing: 2) {
            ForEach(days, id: \.self) { d in TwoWeeksCell(day: d, m: m) }
        }
    }
}

struct TwoWeeksCell: View {
    let day: String
    let m: DueMath
    var body: some View {
        let items: [WFDue] = m.dated.filter { $0.date == day }
        let isToday: Bool = day == m.today
        let out: Bool = items.contains { !$0.incoming }
        let inn: Bool = items.contains { $0.incoming }
        let dot: Color = out ? KInk.warm : inn ? KInk.good : Color.clear
        VStack(spacing: 3) {
            Text(WDay.fmt(day, "EEEEE")).font(.system(size: 9.5)).foregroundStyle(isToday ? Color.kosh : KInk.quiet)
            Text(String(WDay.dayNumber(day))).font(.system(size: 12.5, weight: .semibold)).monospacedDigit()
                .foregroundStyle(isToday ? Color.kosh : KInk.ink)
            Circle().fill(dot).frame(width: 5, height: 5).widgetAccentable(out)
        }
        .padding(.top, 5).padding(.bottom, 6)
        .frame(maxWidth: .infinity)
        .background(isToday ? Color.kosh.opacity(0.12) : Color.clear, in: RoundedRectangle(cornerRadius: 9, style: .continuous))
    }
}

/// the next 14 days: out and in at the top right, the strip of days, then the payments in date order
struct DueLarge: View {
    let m: DueMath
    var body: some View {
        let rows: [WFDue] = Array((m.dated.filter { ($0.date ?? "") <= WDay.add(m.today, 41) } + m.anyDay).prefix(6))
        VStack(alignment: .leading, spacing: 0) {
            KHeader(title: "Coming up", sub: "Next 14 days, " + m.fortnight) {
                VStack(alignment: .trailing, spacing: 1) {
                    DueOut(v: m.soonOut)
                    if m.soonIn > 0 { DueIn(v: m.soonIn) }
                }
            }
            TwoWeeks(m: m).padding(.top, 12)
            KHairline().padding(.top, 10).padding(.bottom, 4)
            if rows.isEmpty {
                Spacer(minLength: 0)
                Text("Nothing due in the next six weeks").kSub()
                Spacer(minLength: 0)
            } else {
                ForEach(rows, id: \.id) { d in
                    DueRow(d: d, m: m, long: true).frame(maxHeight: .infinity)
                }
            }
        }
    }
}

// MARK: - The Lock Screen

/// "Tomorrow, 25 Oct", the name, the amount
struct DueRect: View {
    let m: DueMath
    var body: some View {
        if let n = m.next {
            VStack(alignment: .leading, spacing: 1) {
                Text(Self.when(n, m)).font(.system(size: 12, weight: .semibold)).foregroundStyle(.secondary).lineLimit(1)
                Text(n.name).font(.system(size: 13, weight: .medium)).lineLimit(1)
                KAmount(v: n.amt, size: 18, color: .primary)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        } else {
            Label("Nothing due soon", systemImage: "checkmark.circle")
        }
    }
    static func when(_ n: WFDue, _ m: DueMath) -> String {
        guard let day = n.date else { return m.when(n) }
        let w: String = m.when(n)
        let date: String = WDay.fmt(day, "d MMM")
        return w.contains(date) ? w : w + ", " + date
    }
}

/// "Card bill ₹23,400 tomorrow"
struct DueInline: View {
    let m: DueMath
    var body: some View {
        if let n = m.next {
            Label(n.name + " " + WMoney.full(n.amt) + " " + m.when(n).lowercased(), systemImage: "clock")
                .privacySensitive()
        } else {
            Label("Nothing due soon", systemImage: "calendar")
        }
    }
}

/// the next thing to pay as days to go: its mark, "1d", and the amount
struct DueCircular: View {
    let m: DueMath
    var body: some View {
        ZStack {
            AccessoryWidgetBackground()
            if let n = m.next, let day = n.date {
                let days: Int = WDay.between(m.today, day)
                VStack(spacing: 0) {
                    Image(systemName: KGlyph.outline(n.sym)).font(.system(size: 13, weight: .regular))
                    Text(days <= 0 ? "Today" : String(days) + "d").font(.system(size: 17, weight: .semibold))
                        .lineLimit(1).minimumScaleFactor(0.6)
                    Text(WMoney.tight(n.amt)).font(.system(size: 9.5, weight: .medium)).foregroundStyle(.secondary)
                        .lineLimit(1).minimumScaleFactor(0.7).privacySensitive()
                }
                .padding(.horizontal, 6)
                .widgetAccentable()
            } else {
                Image(systemName: "checkmark")
            }
        }
    }
}
