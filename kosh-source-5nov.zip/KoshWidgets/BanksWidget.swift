import SwiftUI
import WidgetKit

// MARK: - Bank balances: what's in each account, and how fresh that figure is, said plainly

struct BanksWidget: Widget {
    let kind: String = "KoshBanks"
    var body: some WidgetConfiguration {
        AppIntentConfiguration(kind: kind, intent: WhoIntent.self, provider: WhoProvider()) { e in
            BanksView(entry: e)
        }
        .configurationDisplayName("Bank balances")
        .description("What's in each account, carried forward from the bank's last word, and how fresh it is.")
        .supportedFamilies([.systemSmall, .systemMedium, .systemLarge, .accessoryRectangular])
    }
}

enum BanksPick {
    static func of(_ f: WFeed, who: String) -> [WFBank] {
        var out: [WFBank] = []
        for b in f.banks where b.balance != nil {
            if who == "family" || b.owner == who { out.append(b) }
        }
        return out
    }
    static func total(_ bs: [WFBank]) -> Double {
        var t: Double = 0
        for b in bs { t += b.balance ?? 0 }
        return t
    }
    /// where the figure came from, as a person says it
    static func source(_ src: String) -> String {
        switch src {
        case "alert": return "from an alert"
        case "stmt": return "from a statement"
        case "typed": return "typed by you"
        default: return ""
        }
    }
    /// the reading's day and, when kosh has it, its time: "Today 9:12", "Yesterday", "18 Oct"
    static func when(_ b: WFBank, today: String) -> String {
        if b.asOf.isEmpty { return "" }
        let day: String = String(b.asOf.prefix(10))
        let n: Int = WDay.between(day, today)
        var time: String = ""
        if b.asOf.count >= 16 {
            let hm: [Substring] = b.asOf.dropFirst(11).prefix(5).split(separator: ":")
            if hm.count == 2, let h = Int(hm[0]) { time = " " + String(h) + ":" + String(hm[1]) }
        }
        if n <= 0 { return "Today" + time }
        if n == 1 { return "Yesterday" + time }
        return WDay.fmt(day, "d MMM")
    }
    /// how old the reading is, in days
    static func days(_ b: WFBank, today: String) -> Int {
        if b.asOf.isEmpty { return 0 }
        return max(0, WDay.between(String(b.asOf.prefix(10)), today))
    }
    /// a reading five days old or more is worth a second look
    static func stale(_ b: WFBank, today: String) -> Bool {
        if b.asOf.isEmpty { return false }
        return days(b, today: today) >= 5
    }
    /// "Today 9:12, from an alert"; a stale one says its age on the large size: "6 days old, from a statement"
    static func fresh(_ b: WFBank, today: String, age: Bool = false) -> String {
        let src: String = source(b.src)
        var w: String = when(b, today: today)
        if age && stale(b, today: today) { w = String(days(b, today: today)) + " days old" }
        if w.isEmpty { return src.prefix(1).uppercased() + String(src.dropFirst()) }
        return src.isEmpty ? w : w + ", " + src
    }
    /// the dot beside it: green fresh from the bank, quiet when you typed it, warm when it's gone stale
    static func dot(_ b: WFBank, today: String) -> Color {
        if stale(b, today: today) { return KInk.warm }
        if b.src == "typed" { return KInk.quiet }
        return KInk.good
    }
    static func count(_ bs: [WFBank]) -> String {
        bs.count == 1 ? "1 account" : String(bs.count) + " accounts"
    }
    /// "Federal Bank ••4321", with the account's own name on the large size ("Federal Bank Savings ••4321")
    static func title(_ b: WFBank, named: Bool = false) -> String {
        let name: String = named && !b.name.isEmpty ? b.bank + " " + b.name : b.bank
        if b.last.isEmpty { return name }
        return name + " ••" + b.last
    }
    /// "Federal Bank" → "Federal"; a short name stays whole ("Yes Bank" → "Yes", "SBI")
    static func short(_ bank: String) -> String {
        let words: [Substring] = bank.split(separator: " ")
        if words.count >= 2, words.last?.lowercased() == "bank" { return String(words[0]) }
        return bank
    }
    /// the freshest reading's time, for the Lock Screen: "Freshest today 9:12"
    static func freshest(_ bs: [WFBank], today: String) -> String {
        var best: WFBank? = nil
        for b in bs where !b.asOf.isEmpty {
            if best == nil || b.asOf > (best?.asOf ?? "") { best = b }
        }
        guard let b = best else { return "" }
        return "Freshest " + when(b, today: today).lowercased()
    }
    /// the oldest reading that's gone stale, for the large size's note
    static func stalest(_ bs: [WFBank], today: String) -> WFBank? {
        var worst: WFBank? = nil
        for b in bs where stale(b, today: today) {
            if worst == nil || b.asOf < (worst?.asOf ?? "") { worst = b }
        }
        return worst
    }
    /// whose an account is: "Yours", "Asha's"
    static func whose(_ b: WFBank, _ f: WFeed) -> String {
        if b.owner == "me" { return "Yours" }
        if let p = f.people.first(where: { $0.id == b.owner }) { return p.title + "'s" }
        return ""
    }
}

struct BanksView: View {
    let entry: KEntry
    @Environment(\.widgetFamily) private var family
    var body: some View {
        KFrame(entry: entry, link: "banks") {
            if let f = entry.feed, !f.empty {
                let bs: [WFBank] = BanksPick.of(f, who: entry.who)
                if bs.isEmpty {
                    if family == .accessoryRectangular {
                        Text("No balances yet")
                    } else {
                        KEmpty(sym: "building.columns", title: "No balances yet", line: "Balances appear with your bank's alerts and statements, or type one in kosh.")
                    }
                } else {
                    switch family {
                    case .accessoryRectangular: BanksRect(banks: bs, today: entry.today)
                    case .systemMedium: BanksMedium(banks: bs, today: entry.today)
                    case .systemLarge: BanksLarge(banks: bs, today: entry.today, feed: f)
                    default: BanksSmall(banks: bs, today: entry.today)
                    }
                }
            } else if family == .accessoryRectangular {
                Text("Open kosh")
            } else {
                KEmpty(sym: "building.columns", title: KCopy.openTitle, line: KCopy.openLine)
            }
        }
    }
}

/// a bank's initials on a rounded square of the bank's own colour
struct BankMarkW: View {
    let b: WFBank
    var size: CGFloat = 30
    var body: some View {
        let mark: String = WMark.of(b.bank)
        Text(mark)
            .font(.system(size: size * (mark.count > 2 ? 0.3 : 0.36), weight: .bold))
            .foregroundStyle(Color.white)
            .frame(width: size, height: size)
            .background(Color(hex: b.color), in: RoundedRectangle(cornerRadius: size * 0.3, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: size * 0.3, style: .continuous).strokeBorder(Color.white.opacity(0.14), lineWidth: 1))
            .widgetAccentable()
    }
}

/// the total, then each account in a line: its mark, its bank (warm when the figure's gone stale), its balance
struct BanksSmall: View {
    let banks: [WFBank]
    let today: String
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            KHeader(title: "In the bank", sub: BanksPick.count(banks) + ", " + WDay.fmt(today, "d MMM"))
            KAmount(v: BanksPick.total(banks), size: 26).padding(.top, 10)
            Spacer(minLength: 4)
            VStack(spacing: 5) {
                ForEach(Array(banks.prefix(3)), id: \.id) { b in
                    HStack(spacing: 7) {
                        BankMarkW(b: b, size: 18)
                        Text(BanksPick.short(b.bank)).kSub(BanksPick.stale(b, today: today) ? KInk.warm : KInk.quiet)
                        Spacer(minLength: 4)
                        Text(WMoney.full(b.balance ?? 0))
                            .font(.system(size: 12, weight: .semibold)).monospacedDigit().foregroundStyle(KInk.ink)
                            .lineLimit(1).privacySensitive()
                    }
                }
            }
        }
    }
}

/// how fresh a figure is: a dot, then the words
struct FreshLineW: View {
    let b: WFBank
    let today: String
    var age: Bool = false
    var body: some View {
        let stale: Bool = BanksPick.stale(b, today: today)
        HStack(spacing: 5) {
            Circle().fill(BanksPick.dot(b, today: today)).frame(width: 6, height: 6)
            Text(BanksPick.fresh(b, today: today, age: age)).kSub(stale ? KInk.warm : KInk.quiet)
        }
    }
}

/// an account: its mark, its name and how fresh the figure is, the balance
struct BankRowW: View {
    let b: WFBank
    let today: String
    var body: some View {
        HStack(spacing: 10) {
            BankMarkW(b: b, size: 30)
            VStack(alignment: .leading, spacing: 0) {
                Text(BanksPick.title(b)).kName()
                FreshLineW(b: b, today: today)
            }
            Spacer(minLength: 4)
            KRowAmount(v: b.balance ?? 0)
        }
    }
}

struct BanksMedium: View {
    let banks: [WFBank]
    let today: String
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack(alignment: .firstTextBaseline) {
                Text("In the bank").kLabel()
                Spacer(minLength: 4)
                KRowAmount(v: BanksPick.total(banks))
            }
            .padding(.bottom, 4)
            ForEach(Array(banks.prefix(3)), id: \.id) { b in
                BankRowW(b: b, today: today).frame(maxHeight: .infinity)
            }
        }
    }
}

/// a larger account row: whose it is, and how old its figure is
struct BankRowLargeW: View {
    let b: WFBank
    let today: String
    let owner: String
    var body: some View {
        HStack(spacing: 10) {
            BankMarkW(b: b, size: 36)
            VStack(alignment: .leading, spacing: 0) {
                Text(BanksPick.title(b, named: true)).kName()
                if !owner.isEmpty { Text(owner).kSub() }
                FreshLineW(b: b, today: today, age: true).padding(.top, 2)
            }
            Spacer(minLength: 4)
            Text(WMoney.full(b.balance ?? 0))
                .font(.system(size: 15, weight: .semibold)).kerning(-0.2).monospacedDigit().foregroundStyle(KInk.ink)
                .lineLimit(1).privacySensitive()
        }
        .frame(height: 60)
    }
}

struct BanksLarge: View {
    let banks: [WFBank]
    let today: String
    let feed: WFeed
    var body: some View {
        let rows: [WFBank] = Array(banks.prefix(4))
        let old: WFBank? = BanksPick.stalest(banks, today: today)
        VStack(alignment: .leading, spacing: 0) {
            KHeader(title: "In the bank", sub: BanksPick.count(banks) + ", as of each bank's last word")
            KAmount(v: BanksPick.total(banks), size: 36).padding(.top, 12)
            KHairline().padding(.top, 14).padding(.bottom, 6)
            ForEach(rows, id: \.id) { b in
                BankRowLargeW(b: b, today: today, owner: BanksPick.whose(b, feed))
            }
            Spacer(minLength: 0)
            if let o = old {
                KHairline().padding(.top, 6).padding(.bottom, 10)
                HStack(spacing: 10) {
                    Text(BanksPick.short(o.bank) + " has sent no alert since " + WDay.fmt(String(o.asOf.prefix(10)), "d MMM") + ". Tap to type today's balance.")
                        .font(.system(size: 11.5)).foregroundStyle(KInk.quiet).lineLimit(2)
                    Spacer(minLength: 4)
                    KPill(text: "Update", kind: .warm)
                }
            }
        }
    }
}

/// the Lock Screen: the total, how many accounts, and how fresh the newest figure is
struct BanksRect: View {
    let banks: [WFBank]
    let today: String
    var body: some View {
        VStack(alignment: .leading, spacing: 1) {
            Text("In the bank, " + BanksPick.count(banks)).font(.system(size: 12, weight: .semibold)).foregroundStyle(.secondary).lineLimit(1)
            Text(WMoney.full(BanksPick.total(banks))).font(.system(size: 22, weight: .semibold)).kerning(-0.6).monospacedDigit()
                .lineLimit(1).minimumScaleFactor(0.7).privacySensitive().widgetAccentable()
            Text(BanksPick.freshest(banks, today: today)).font(.system(size: 11.5, weight: .medium)).foregroundStyle(.secondary).lineLimit(1)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}
