import SwiftUI
import WidgetKit

// MARK: - Latest: the newest payments out and in, how each was paid, and a quick way to add one
//
// The canvas "kosh widgets" › Latest payments is the reference. Small: what today has spent and the last eight days
// as small bars. Medium: the same beside the three newest payments and +. Large: today's figure and the bars, then
// the newest payments grouped by day ("Yesterday, 23 Oct"), each with its mark in a hairline circle, its time and how
// it was paid, money in in green.

struct LatestWidget: Widget {
    let kind: String = "KoshLatest"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: KoshProvider()) { e in
            LatestView(entry: e)
        }
        .configurationDisplayName("Latest payments")
        .description("Today's spending and the newest payments, with the bank and how each was paid. Tap + to add a cash spend.")
        .supportedFamilies([.systemSmall, .systemMedium, .systemLarge, .accessoryRectangular])
    }
}

enum LatestText {
    static func incoming(_ t: WFTx) -> Bool { t.kind == "in" }
    /// "9:41 am", "7:02 pm": the time as the app writes it (Day.time12), not the mail's 24-hour clock
    static func time(_ t: WFTx) -> String {
        let p: [String] = t.t.split(separator: ":").map(String.init)
        guard p.count >= 2, let h = Int(p[0]), let m = Int(p[1].prefix(2)) else { return "" }
        return String(h % 12 == 0 ? 12 : h % 12) + ":" + String(format: "%02d", m) + (h >= 12 ? " pm" : " am")
    }
    /// "9:41, card, Federal Bank"; the medium leaves the bank out ("9:41, card")
    static func line(_ t: WFTx, bank: Bool) -> String {
        var parts: [String] = []
        let tm: String = time(t)
        if !tm.isEmpty { parts.append(tm) }
        let w: String = WWay.word(t.way)
        if !w.isEmpty { parts.append(w == "UPI" || w == "ATM" ? w : w.lowercased()) }
        if bank && !t.bank.isEmpty && t.way != "cash" { parts.append(t.bank) }
        return parts.joined(separator: ", ")
    }
    static func todaySpend(_ f: WFeed, today: String) -> Double {
        if f.today != today { return 0 }
        return f.month.today
    }
    static func todayCount(_ f: WFeed, today: String) -> Int {
        f.recent.filter { $0.d == today && $0.spend }.count
    }
    static func payments(_ n: Int) -> String { n == 1 ? "1 payment" : String(n) + " payments" }
    /// "Today, 24 Oct"
    static func todayLine(_ today: String) -> String { "Today, " + WDay.fmt(today, "d MMM") }
    /// "Yesterday, 23 Oct", "Thursday, 22 Oct", "Today, 24 Oct"
    static func dayLine(_ d: String, today: String) -> String {
        if d == today { return todayLine(today) }
        if d == WDay.add(today, -1) { return "Yesterday, " + WDay.fmt(d, "d MMM") }
        let n: Int = WDay.between(d, today)
        if n > 0 && n < 7 { return WDay.fmt(d, "EEEE") + ", " + WDay.fmt(d, "d MMM") }
        return WDay.fmt(d, "EEE d MMM")
    }
    /// the dates a list of payments covers: "22–24 Oct", "30 Sep – 2 Oct"
    static func span(_ rows: [WFTx], today: String) -> String {
        let days: [String] = rows.map { $0.d }.sorted()
        guard let a = days.first, let b = days.last else { return todayLine(today) }
        if a == b { return a == today ? todayLine(today) : WDay.fmt(a, "d MMM") }
        if a.prefix(7) == b.prefix(7) { return String(WDay.dayNumber(a)) + "–" + WDay.fmt(b, "d MMM") }
        return WDay.fmt(a, "d MMM") + " – " + WDay.fmt(b, "d MMM")
    }
    /// the last eight days' spending, today last (reaching back into last month at the start of one)
    static func week(_ f: WFeed, today: String) -> [Double] {
        var all: [Double] = f.month.days
        if all.count < 8 { all = f.month.prevDays + all }
        // (a feed written yesterday: the days since have spent nothing kosh knows of yet)
        if f.today != today {
            let gap: Int = max(0, min(8, WDay.between(f.today, today)))
            all += Array(repeating: 0, count: gap)
        }
        return Array(all.suffix(8))
    }
    /// the weekday letters under those eight days
    static func letters(_ n: Int, today: String) -> [String] {
        var out: [String] = []
        for i in stride(from: n - 1, through: 0, by: -1) {
            out.append(String(WDay.fmt(WDay.add(today, -i), "EEEEE")))
        }
        return out
    }
}

struct LatestView: View {
    let entry: KEntry
    @Environment(\.widgetFamily) private var family
    var body: some View {
        KFrame(entry: entry, link: "latest") {
            if let f = entry.feed, !f.empty {
                switch family {
                case .accessoryRectangular: LatestRect(f: f, today: entry.today)
                case .systemMedium: LatestMedium(f: f, today: entry.today)
                case .systemLarge: LatestLarge(f: f, today: entry.today)
                default: LatestSmall(f: f, today: entry.today)
                }
            } else if family == .accessoryRectangular {
                Text("Open kosh")
            } else {
                KEmpty(sym: "list.bullet", title: KCopy.openTitle, line: KCopy.openLine)
            }
        }
    }
}

/// + : opens kosh's Add a spend, a quiet circle with a hairline edge
struct AddButton: View {
    var size: CGFloat = 32
    var body: some View {
        Link(destination: URL(string: "kosh://add") ?? URL(fileURLWithPath: "/")) {
            Image(systemName: "plus")
                .font(.system(size: size * 0.42, weight: .medium))
                .foregroundStyle(KInk.ink)
                .frame(width: size, height: size)
                .overlay(Circle().strokeBorder(KInk.hair, lineWidth: 1))
                .contentShape(Circle())
                .widgetAccentable()
        }
        .accessibilityLabel("Add a cash spend")
    }
}

/// a payment: its mark in a hairline circle (green when it's money in), its name, its time and how it was paid, the amount
struct TxRowW: View {
    let t: WFTx
    var bank: Bool = true
    var body: some View {
        let inn: Bool = LatestText.incoming(t)
        HStack(spacing: 10) {
            Image(systemName: KGlyph.outline(t.sym))
                .font(.system(size: 12, weight: .regular))
                .foregroundStyle(inn ? KInk.good : KInk.ink)
                .frame(width: 26, height: 26)
                .overlay(Circle().strokeBorder(KInk.hair, lineWidth: 1))
                .widgetAccentable(inn)
            VStack(alignment: .leading, spacing: 0) {
                Text(WName.clean(t.name)).kName().minimumScaleFactor(0.85)
                Text(LatestText.line(t, bank: bank)).kSub()
            }
            Spacer(minLength: 6)
            KRowAmount(v: t.a, incoming: inn)
        }
    }
}

/// the last eight days as small bars, today's in the accent, the weekday letters under them
struct WeekBars: View {
    let days: [Double]
    let letters: [String]
    var showLetters: Bool = true
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(alignment: .bottom, spacing: 5) {
                ForEach(Array(days.enumerated()), id: \.offset) { i, v in
                    WeekBar(v: v, top: days.max() ?? 0, today: i == days.count - 1)
                }
            }
            .frame(height: 30, alignment: .bottom)
            if showLetters {
                HStack(spacing: 5) {
                    ForEach(Array(letters.enumerated()), id: \.offset) { _, l in
                        Text(l).font(.system(size: 10.5)).foregroundStyle(KInk.quiet).frame(width: 9)
                    }
                }
            }
        }
        .fixedSize()
    }
}

struct WeekBar: View {
    let v: Double
    let top: Double
    let today: Bool
    var body: some View {
        let h: CGFloat = v <= 0 || top <= 0 ? 2 : max(3, CGFloat(v / top) * 30)
        RoundedRectangle(cornerRadius: 2.5, style: .continuous)
            .fill(today ? Color.kosh : (v <= 0 ? KInk.hair : KInk.ink.opacity(0.32)))
            .frame(width: 9, height: h)
            .widgetAccentable(today)
    }
}

/// today's figure and the words under it
struct LatestToday: View {
    let f: WFeed
    let today: String
    var size: CGFloat = 28
    var words: String
    var body: some View {
        let spent: Double = LatestText.todaySpend(f, today: today)
        // (a quiet day says so in words, with yesterday's figure under it, rather than a big ₹0)
        let week: [Double] = LatestText.week(f, today: today)
        let yesterday: Double = week.count >= 2 ? week[week.count - 2] : 0
        VStack(alignment: .leading, spacing: 0) {
            if spent > 0 {
                KAmount(v: spent, size: size)
                Text(words).kSub().padding(.top, 4)
            } else {
                Text("Nothing yet").font(.system(size: size * 0.68, weight: .semibold)).kerning(-0.3).foregroundStyle(KInk.ink).lineLimit(1)
                Text(yesterday > 0 ? "today; yesterday " + WMoney.full(yesterday) : "spent today").kSub().padding(.top, 4).privacySensitive()
            }
        }
    }
}

struct LatestSmall: View {
    let f: WFeed
    let today: String
    var body: some View {
        let n: Int = LatestText.todayCount(f, today: today)
        let week: [Double] = LatestText.week(f, today: today)
        VStack(alignment: .leading, spacing: 0) {
            KHeader(title: "Latest", sub: LatestText.todayLine(today))
            LatestToday(f: f, today: today, words: n == 0 ? "nothing spent yet" : "spent, " + LatestText.payments(n))
                .padding(.top, 10)
            Spacer(minLength: 4)
            WeekBars(days: week, letters: LatestText.letters(week.count, today: today))
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
    }
}

struct LatestMedium: View {
    let f: WFeed
    let today: String
    var body: some View {
        let rows: [WFTx] = Array(f.recent.prefix(3))
        let week: [Double] = LatestText.week(f, today: today)
        HStack(alignment: .top, spacing: 16) {
            VStack(alignment: .leading, spacing: 0) {
                KHeader(title: "Latest", sub: LatestText.todayLine(today))
                LatestToday(f: f, today: today, words: "spent today").padding(.top, 10)
                Spacer(minLength: 4)
                WeekBars(days: week, letters: [], showLetters: false)
            }
            .frame(width: 118, alignment: .leading)
            .frame(maxHeight: .infinity, alignment: .topLeading)
            VStack(alignment: .leading, spacing: 0) {
                HStack {
                    Text("Newest").kSub()
                    Spacer(minLength: 4)
                    AddButton(size: 30)
                }
                .frame(height: 30)
                if rows.isEmpty {
                    Spacer(minLength: 0)
                    Text("No payments yet").kSub()
                    Spacer(minLength: 0)
                } else {
                    ForEach(rows, id: \.id) { t in
                        TxRowW(t: t, bank: false).frame(maxHeight: .infinity)
                    }
                }
            }
            .frame(maxWidth: .infinity)
        }
    }
}

/// the newest payments, a heading for each day but today's (today's figure is above them)
struct LatestList: View {
    let rows: [WFTx]
    let today: String
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            ForEach(Array(rows.enumerated()), id: \.element.id) { i, t in
                if (i == 0 && t.d != today) || (i > 0 && rows[i - 1].d != t.d) {
                    Text(LatestText.dayLine(t.d, today: today))
                        .font(.system(size: 11.5, weight: .semibold))
                        .foregroundStyle(KInk.quiet)
                        .lineLimit(1)
                        .padding(.top, 5)
                }
                TxRowW(t: t).frame(height: 34)
            }
        }
    }
}

struct LatestLarge: View {
    let f: WFeed
    let today: String
    var body: some View {
        let rows: [WFTx] = LatestLarge.fit(Array(f.recent.prefix(7)), today: today)
        let n: Int = LatestText.todayCount(f, today: today)
        let week: [Double] = LatestText.week(f, today: today)
        VStack(alignment: .leading, spacing: 0) {
            KHeader(title: "Latest", sub: LatestText.span(rows, today: today)) {
                AddButton()
            }
            HStack(alignment: .bottom) {
                LatestToday(f: f, today: today, words: n == 0 ? "nothing spent today" : "spent today, " + LatestText.payments(n))
                Spacer(minLength: 6)
                WeekBars(days: week, letters: LatestText.letters(week.count, today: today))
            }
            .padding(.top, 8)
            KHairline().padding(.top, 10)
            if rows.isEmpty {
                Spacer(minLength: 0)
                Text("No payments yet").kSub()
            } else {
                LatestList(rows: rows, today: today)
            }
            Spacer(minLength: 0)
        }
    }
    /// as many rows as the large has room for: 34 points each, a day's heading another 20, about 245 points in all
    static func fit(_ rows: [WFTx], today: String) -> [WFTx] {
        var out: [WFTx] = []
        var used: CGFloat = 0
        for (i, t) in rows.enumerated() {
            let heading: Bool = (i == 0 && t.d != today) || (i > 0 && rows[i - 1].d != t.d)
            let need: CGFloat = 34 + (heading ? 20 : 0)
            if used + need > 245 { break }
            used += need
            out.append(t)
        }
        return out
    }
}

/// a Lock Screen line: today's spending, and the newest payment
struct LatestRect: View {
    let f: WFeed
    let today: String
    var body: some View {
        VStack(alignment: .leading, spacing: 1) {
            Text("Spent today, " + WDay.fmt(today, "d MMM"))
                .font(.system(size: 12, weight: .semibold)).foregroundStyle(.secondary).lineLimit(1)
            KAmount(v: LatestText.todaySpend(f, today: today), size: 22, color: .primary)
            if let t = f.recent.first {
                let tm: String = LatestText.time(t)
                Text(WName.clean(t.name) + " " + WMoney.full(t.a) + (tm.isEmpty || t.d != today ? "" : ", " + tm))
                    .font(.system(size: 11.5, weight: .medium)).foregroundStyle(.secondary).lineLimit(1)
                    .privacySensitive()
            }
        }
    }
}
