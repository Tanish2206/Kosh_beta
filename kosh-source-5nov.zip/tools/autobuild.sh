#!/bin/bash
# kosh auto-build. Watches .build/request in the project folder (the folder above this one). When its content changes,
# it builds kosh for iOS with xcodebuild, installs it on the iPhone paired with this Mac (devicectl) and opens it.
# What happened is written to .build/status (one line), .build/log (the errors, or the install's last words) and
# .build/history, so whoever asked for the build can read the result from the folder.
# Runs as a LaunchAgent in your login session (install-autobuild.sh), so signing uses your own keychain.
set -u
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
B="$ROOT/.build"
mkdir -p "$B"
export PATH="/usr/bin:/bin:/usr/sbin:/sbin:/usr/local/bin:/opt/homebrew/bin"
APP="$ROOT/DerivedData/Kosh/Build/Products/Debug-iphoneos/Kosh.app"

say() { echo "$(date '+%H:%M:%S') $*" > "$B/status"; echo "$(date '+%F %T') $*" >> "$B/history"; }

# this script, as it was when it started: when a newer one is copied over it, it starts again as the new one (so a
# change to the auto-build reaches the Mac without anyone turning it off and on)
SELF="$ROOT/tools/autobuild.sh"
SELF_SUM="$(md5 -q "$SELF" 2>/dev/null)"
renewed() { [ -n "$SELF_SUM" ] && [ "$(md5 -q "$SELF" 2>/dev/null)" != "$SELF_SUM" ]; }
again() { say "restarting: the auto-build was updated"; exec /bin/bash "$SELF"; }

# Swift that is slow to type-check (one build broke on it on 19 Oct): each build lists the expressions over 200 ms
# and the functions over 400 ms in .build/slow, slowest first, so they're split before they break a build
SLOW_FLAGS='$(inherited) -Xfrontend -warn-long-expression-type-checking=200 -Xfrontend -warn-long-function-bodies=400'

# the iPhone paired with this Mac, connected ones first (devicectl's identifier)
device() {
  xcrun devicectl list devices --json-output "$B/devices.json" >/dev/null 2>&1 || return 1
  osascript -l JavaScript -e '
    const f = $.NSString.stringWithContentsOfFileEncodingError("'"$B"'/devices.json", $.NSUTF8StringEncoding, null);
    const j = JSON.parse(ObjC.unwrap(f));
    const all = ((j.result || {}).devices || []).filter(x => (x.hardwareProperties || {}).platform === "iOS" && (x.connectionProperties || {}).pairingState === "paired");
    const on = all.filter(x => (x.connectionProperties || {}).tunnelState === "connected").concat(all);
    on.length ? on[0].identifier : ""' 2>/dev/null
}

build() {
  local req="$1"
  say "building $req"
  cd "$ROOT" || return
  if ! xcodebuild -project Kosh.xcodeproj -scheme Kosh -configuration Debug -destination 'generic/platform=iOS' \
       -derivedDataPath "$ROOT/DerivedData/Kosh" -allowProvisioningUpdates OTHER_SWIFT_FLAGS="$SLOW_FLAGS" build > "$B/log.full" 2>&1; then
    grep -E "error:|BUILD FAILED|Signing|provisioning" "$B/log.full" | sed "s|$ROOT/||" | sort -u | head -40 > "$B/log"
    say "failed $req (build: $(grep -c 'error:' "$B/log") errors)"
    return
  fi
  slow
  local dev; dev="$(device)"
  if [ -z "$dev" ]; then echo "No paired iPhone found (connect it, or turn on its Wi-Fi sync)" > "$B/log"; say "built $req, no iPhone"; return; fi
  local bid; bid=$(/usr/libexec/PlistBuddy -c 'Print CFBundleIdentifier' "$APP/Info.plist" 2>/dev/null)
  # a locked, asleep or away phone: tried again every 20 s for up to 12 hours, until a newer request comes in
  # (an app the phone can't open any more is put right the moment the phone is back near the Mac)
  local n=0
  until xcrun devicectl device install app --device "$dev" "$APP" > "$B/log" 2>&1; do
    n=$((n + 1))
    if [ $n -ge 2160 ]; then say "built $req, install failed"; return; fi
    if [ -f "$B/request" ] && [ "$(cat "$B/request")" != "$req" ]; then say "built $req, a newer build was asked for"; return; fi
    say "built $req, waiting for the iPhone (unlock it, keep it near the Mac)"
    # (a diagnostics pull asked for meanwhile is tried too: the phone may be near enough to copy from)
    pending_pull
    pending_shots
    sleep 20
  done
  if xcrun devicectl device process launch --device "$dev" --terminate-existing "$bid" >> "$B/log" 2>&1; then
    say "installed $req, opened"
  else
    say "installed $req (unlock the iPhone to open it)"
  fi
}

# the app keeps its diagnostics in its own Documents (LiveSession.keepDiagnosticsSoon): a change to .build/pull copies the
# latest of them here, to _scratch/diag/latest.json, with what happened in .build/pullstatus
pull() {
  local req="$1"
  local dev; dev="$(device)"
  if [ -z "$dev" ]; then echo "$(date '+%H:%M:%S') no paired iPhone ($req)" > "$B/pullstatus"; return; fi
  local bid; bid=$(/usr/libexec/PlistBuddy -c 'Print CFBundleIdentifier' "$APP/Info.plist" 2>/dev/null)
  mkdir -p "$ROOT/_scratch/diag"
  # "settings-…": the app's saved settings and their backups (profile*.json in Application Support/kosh-beta), read
  # only, to _scratch/diag/settings/, with the folder's listing beside them
  # "crashes-…": kosh's crash reports from the phone (systemCrashLogs, read only), to _scratch/diag/crashes/
  case "$req" in crashes*)
    local cd="$ROOT/_scratch/diag/crashes"; mkdir -p "$cd"
    xcrun devicectl device info files --device "$dev" --domain-type systemCrashLogs > "$cd/listing.txt" 2>&1
    local m=0 g
    for g in $(grep -oE '[A-Za-z0-9._/-]*Kosh[A-Za-z0-9._-]*\.ips' "$cd/listing.txt" | sort -u | tail -8); do
      xcrun devicectl device copy from --device "$dev" --domain-type systemCrashLogs --source "$g" --destination "$cd/$(basename "$g")" >> "$B/pull.log" 2>&1 && m=$((m+1))
    done
    echo "$(date '+%H:%M:%S') pulled $req ($m crash reports)" > "$B/pullstatus"; return ;;
  esac
  # "stmts-…": the statements kosh exported for the Mac test bench (Documents/stmt-export: the PDFs, their passwords and
  # what kosh kept from them, LiveSession+StmtExport.swift), to _corpus/stmts/phone/ (private: never the repo)
  case "$req" in stmts*)
    local xd="$ROOT/_corpus/stmts/phone"; mkdir -p "$xd"
    xcrun devicectl device info files --device "$dev" --domain-type appDataContainer --domain-identifier "$bid" \
      --subdirectory "Documents/stmt-export" > "$xd/listing.txt" 2>&1
    local k=0 x
    for x in $(grep -oE '[A-Za-z0-9._-]+\.(pdf|zip|json)' "$xd/listing.txt" | sort -u); do
      xcrun devicectl device copy from --device "$dev" --domain-type appDataContainer --domain-identifier "$bid" \
        --source "Documents/stmt-export/$x" --destination "$xd/$x" >> "$B/pull.log" 2>&1 && k=$((k+1))
    done
    echo "$(date '+%H:%M:%S') pulled $req ($k statement files)" > "$B/pullstatus"; return ;;
  esac
  case "$req" in settings*)
    local sd="$ROOT/_scratch/diag/settings"; mkdir -p "$sd"
    xcrun devicectl device info files --device "$dev" --domain-type appDataContainer --domain-identifier "$bid" \
      --subdirectory "Library/Application Support/kosh-beta" > "$sd/listing.txt" 2>&1
    local n=0 f
    for f in $(grep -oE 'profile[A-Za-z0-9._-]*\.json' "$sd/listing.txt" | sort -u); do
      xcrun devicectl device copy from --device "$dev" --domain-type appDataContainer --domain-identifier "$bid" \
        --source "Library/Application Support/kosh-beta/$f" --destination "$sd/$f" >> "$B/pull.log" 2>&1 && n=$((n+1))
    done
    echo "$(date '+%H:%M:%S') pulled $req ($n settings files)" > "$B/pullstatus"; return ;;
  esac
  if xcrun devicectl device copy from --device "$dev" --domain-type appDataContainer --domain-identifier "$bid" \
       --source Documents/kosh-diagnostics.json --destination "$ROOT/_scratch/diag/latest.json" > "$B/pull.log" 2>&1; then
    echo "$(date '+%H:%M:%S') pulled $req ($(wc -c < "$ROOT/_scratch/diag/latest.json") bytes)" > "$B/pullstatus"
  else
    echo "$(date '+%H:%M:%S') pull failed $req (see .build/pull.log)" > "$B/pullstatus"
  fi
}

pending_pull() {
  if [ -f "$B/pull" ]; then
    local preq; preq="$(cat "$B/pull")"
    if [ "$preq" != "$(cat "$B/pulled" 2>/dev/null)" ]; then echo "$preq" > "$B/pulled"; pull "$preq"; fi
  fi
}

# the slow Swift of the last build, from its full log: "<ms> <file>:<line> <what>", slowest first
slow() {
  grep -E "warning: .* took [0-9]+ms to type-check" "$B/log.full" 2>/dev/null \
    | sed -E "s|$ROOT/||; s|^([^:]+:[0-9]+):[0-9]+: warning: (.*) took ([0-9]+)ms.*|\3 \1 \2|" | sort -rn -u | head -60 > "$B/slow"
}

# kosh's widgets as pictures (tools/shots): a change to .build/shots copies the widget sources into the Shots package
# (every "\.widgetFamily" read as "\.shotFamily", so each size can be set), runs its one test in the iOS Simulator, and
# leaves a PNG of each widget at each size, by day and by night, in _scratch/shots, with what happened in .build/shotstatus
shots() {
  local req="$1" P="$ROOT/tools/shots" out="$ROOT/_scratch/shots"
  echo "$(date '+%H:%M:%S') drawing $req" > "$B/shotstatus"
  rm -rf "$P/Sources/ShotsKit" "$out"; mkdir -p "$P/Sources/ShotsKit" "$out"
  for f in "$ROOT"/KoshWidgets/*.swift "$ROOT"/Shared/*.swift; do
    [ "$(basename "$f")" = KoshWidgetsBundle.swift ] && continue
    sed 's/\\\.widgetFamily/\\.shotFamily/g' "$f" > "$P/Sources/ShotsKit/$(basename "$f")"
  done
  cp "$P/Render.swift" "$P/Sources/ShotsKit/ShotsRender.swift"
  local sim; sim=$(xcrun simctl list devices available 2>/dev/null | grep -E "iPhone 1[5-9] Pro|iPhone 1[5-9]|iPhone" | head -1 | grep -oE "[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}")
  if [ -z "$sim" ]; then
    xcrun simctl list runtimes > "$B/shots.log" 2>&1
    echo "$(date '+%H:%M:%S') no iPhone simulator on this Mac ($req): see .build/shots.log" > "$B/shotstatus"; return
  fi
  local scheme
  for scheme in Shots-Package Shots ShotsKit; do
    if (cd "$P" && TEST_RUNNER_SHOTS_DIR="$out" xcodebuild test -scheme "$scheme" -destination "platform=iOS Simulator,id=$sim" \
         -derivedDataPath "$ROOT/DerivedData/Shots" > "$B/shots.log" 2>&1); then
      echo "$(date '+%H:%M:%S') drew $req: $(ls "$out" | wc -l | tr -d ' ') pictures in _scratch/shots" > "$B/shotstatus"; return
    fi
    grep -q "does not contain a scheme\|scheme named" "$B/shots.log" || break
  done
  grep -E "error:|failed|Failing" "$B/shots.log" | sed "s|$ROOT/||" | sort -u | head -40 > "$B/shots.err"
  echo "$(date '+%H:%M:%S') drawing failed $req (see .build/shots.err)" > "$B/shotstatus"
}

pending_shots() {
  if [ -f "$B/shots" ]; then
    local sreq; sreq="$(cat "$B/shots")"
    if [ "$sreq" != "$(cat "$B/shotsdone" 2>/dev/null)" ]; then echo "$sreq" > "$B/shotsdone"; shots "$sreq"; fi
  fi
}

say "watching"
# kosh's SMS shortcut, signed so an iPhone will import it (tools/make-shortcut.js writes it unsigned to share/): a change
# to .build/sign signs "share/<name> unsigned.shortcut" into "share/<name>.shortcut", with what happened in .build/signstatus
sign() {
  local req="$1" name; name="$(cat "$B/sign" | head -1)"
  local in="$ROOT/share/$name unsigned.shortcut" out="$ROOT/share/$name.shortcut"
  if [ ! -f "$in" ]; then echo "$(date '+%H:%M:%S') nothing to sign: no share/$name unsigned.shortcut" > "$B/signstatus"; return; fi
  rm -f "$out"
  if shortcuts sign --mode anyone --input "$in" --output "$out" > "$B/sign.log" 2>&1 && [ -s "$out" ]; then
    echo "$(date '+%H:%M:%S') signed share/$name.shortcut ($(wc -c < "$out" | tr -d ' ') bytes)" > "$B/signstatus"
  else
    echo "$(date '+%H:%M:%S') signing failed (see .build/sign.log)" > "$B/signstatus"
  fi
}
pending_sign() {
  if [ -f "$B/sign" ]; then
    local sreq; sreq="$(cat "$B/sign")$(stat -f %m "$B/sign" 2>/dev/null)"
    if [ "$sreq" != "$(cat "$B/signdone" 2>/dev/null)" ]; then echo "$sreq" > "$B/signdone"; sign "$sreq"; fi
  fi
}

while true; do
  renewed && again
  pending_pull
  pending_shots
  pending_sign
  if [ -f "$B/request" ]; then
    req="$(cat "$B/request")"
    if [ "$req" != "$(cat "$B/done" 2>/dev/null)" ]; then
      echo "$req" > "$B/done"
      build "$req"
    fi
  fi
  sleep 3
done
# (4 Nov) touched so the running auto-build restarts with the stmts-/settings- pulls
