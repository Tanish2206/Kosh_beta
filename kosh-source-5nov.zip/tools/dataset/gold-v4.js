/* the hand-checked gold mails as the v4 exam: node tools/dataset/gold-v4.js <outfile> <dir>... (pairs <name>.json + <name>.gold.json) */
'use strict';
const fs = require('fs'), vm = require('vm'), path = require('path');
const K = path.join(__dirname, '..', '..', 'Kosh') + '/';
const c = vm.createContext({ console });
vm.runInContext('var KoshDirectory = ' + fs.readFileSync(K + 'directory.json', 'utf8') + ';', c);
vm.runInContext(fs.readFileSync(K + 'engine.js', 'utf8'), c);
const E = vm.runInContext('KoshEngine', c), DROP = new Set(['q', 'p', 'ev', 'guessed', 'conf', 'unsure', 'to', 'quote', 'note']);
const slim = (e) => Object.fromEntries(Object.entries(e).filter(([k, v]) => !DROP.has(k) && v !== '' && v != null));
const out = [], [, , file, ...dirs] = process.argv;
for (const d of dirs) for (const f of fs.readdirSync(d).filter((x) => x.endsWith('.gold.json'))) {
  const mails = JSON.parse(fs.readFileSync(path.join(d, f.replace('.gold.json', '.json')), 'utf8')), by = {};
  mails.forEach((m) => (by[m.id] = m));
  for (const g of JSON.parse(fs.readFileSync(path.join(d, f), 'utf8'))) {
    const m = by[g.id]; if (!m) continue;
    const lp = JSON.parse(E.localPromptJSON(JSON.stringify(m), 0));
    out.push({ id: g.id, src: 'gold:' + path.basename(d) + '/' + f, from: String(m.from || ''), input: typeof lp === 'string' ? lp : lp.prompt || lp.text || '',
      output: JSON.stringify({ events: (g.events || []).filter((e) => e.type !== 'noise').map(slim) }) });
  }
}
fs.writeFileSync(file, out.map((x) => JSON.stringify(x)).join('\n')); console.log(out.length, 'gold rows');
