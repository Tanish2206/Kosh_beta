/* Make every v4 row honest to what the phone shows the model: synthetic inputs go through engine.localPrompt (long
   numbers cut to their last four, the same cleaning as real mail), and any text value in an answer that the input
   doesn't show (a full policy or reference number the phone cut) is dropped; digits are cut to what's printed.
   node tools/dataset/normalize-v4.js <in.jsonl> <out.jsonl> [--synth] */
'use strict';
const fs = require('fs'), vm = require('vm'), path = require('path');
const K = path.join(__dirname, '..', '..', 'Kosh') + '/';
const c = vm.createContext({ console });
vm.runInContext('var KoshDirectory = ' + fs.readFileSync(K + 'directory.json', 'utf8') + ';', c);
vm.runInContext(fs.readFileSync(K + 'engine.js', 'utf8'), c);
const E = vm.runInContext('KoshEngine', c);
const [, , inF, outF, flag] = process.argv;
const KEEP = new Set(['type', 'dir', 'kind', 'purpose', 'mode', 'status', 'what', 'action', 'side', 'k', 'doc', 'date', 'due', 'on', 'time', 'by', 'from', 'asOf', 'mat', 'every', 'frequency', 'cur', 'step']);
let dropped = 0, rows = 0;
function honest(v, key, text, low) {
  if (typeof v === 'number' || typeof v === 'boolean') return v;
  if (Array.isArray(v)) return v.map((x) => honest(x, key, text, low)).filter((x) => x !== undefined);
  if (v && typeof v === 'object') { const o = {}; for (const [k, x] of Object.entries(v)) { const y = honest(x, k, text, low); if (y !== undefined) o[k] = y; } return o; }
  const s = String(v);
  if (KEEP.has(key) || /^\d{4}-\d\d-\d\d/.test(s)) return s;
  if (low.includes(s.toLowerCase())) return s;
  const d = s.replace(/\D/g, '');            // a long number the phone cut: keep the last four, as printed ("••4019")
  if (d.length >= 6 && text.includes('••' + d.slice(-4))) return d.slice(-4);
  // names and words: kept when every word is in the input (a person or shop said differently in case)
  const words = s.toLowerCase().split(/[^a-z0-9]+/).filter((w) => w.length > 2);
  if (words.length && words.every((w) => low.includes(w))) return s;
  dropped++; return undefined;
}
const out = [];
for (const l of fs.readFileSync(inF, 'utf8').split('\n')) {
  if (!l.trim()) continue; const x = JSON.parse(l); rows++;
  if (flag === '--synth') {
    const [head, ...body] = x.input.split('\n\n'), h = {};
    head.split('\n').forEach((ln) => { const m = /^(\w+): (.*)$/.exec(ln); if (m) h[m[1].toLowerCase()] = m[2]; });
    const lp = JSON.parse(E.localPromptJSON(JSON.stringify({ id: x.id, from: h.from, date: (h.date || '') + 'T10:00:00Z', subject: h.subject || '', text: body.join('\n\n') }), 0));
    x.input = typeof lp === 'string' ? lp : lp.prompt || lp.text || x.input;
  }
  const low = x.input.toLowerCase();
  const ev = JSON.parse(x.output).events.map((e) => honest(e, '', x.input, low));
  x.output = JSON.stringify({ events: ev }); out.push(x);
}
fs.writeFileSync(outF, out.map((x) => JSON.stringify(x)).join('\n'));
console.log(path.basename(inF), rows, 'rows,', dropped, 'unseen values dropped');
