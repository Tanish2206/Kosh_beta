/* kosh-reader v4 training set: one email (or SMS, or document page) in, a list of events out.
   node tools/dataset/build-v4.js <mails.json> <outdir>
   Writes <outdir>/auto.jsonl (events the readers are sure of: the answer as they read it) and <outdir>/queue.jsonl
   (anything unsure, for Claude to label). Each row: {id, src, from, input, output, why}. input is exactly what the
   phone hands the model (engine.localPrompt); output is {"events":[...]} in reader v2's shapes (reader/DESIGN.md),
   plus "booking" from trips.js. Mail stays outside the repo: point <outdir> at _corpus/. */
'use strict';
const fs = require('fs'), vm = require('vm'), path = require('path');
const K = path.join(__dirname, '..', '..', 'Kosh') + '/';
const c = vm.createContext({ console });
vm.runInContext('var KoshDirectory = ' + fs.readFileSync(K + 'directory.json', 'utf8') + ';', c);
for (const n of ['engine', 'mailwire', 'knowledge', 'reader', 'journey', 'docread', 'agent', 'assist', 'viewplan', 'plan', 'brief', 'decide', 'packs', 'trips', 'checks', 'unlock'])
  vm.runInContext(fs.readFileSync(K + n + '.js', 'utf8'), c);
const R = vm.runInContext('KoshReader', c), E = vm.runInContext('KoshEngine', c);
const DROP = new Set(['q', 'p', 'ev', 'guessed', 'conf', 'unsure', 'to', 'quote']);
function slim(e) { const o = {}; for (const k of Object.keys(e)) if (!DROP.has(k) && e[k] !== '' && e[k] != null) o[k] = e[k]; return o; }
const [, , inFile, outDir] = process.argv;
const M = JSON.parse(fs.readFileSync(inFile, 'utf8'));
const auto = [], queue = [], tally = {};
for (const m of M) {
  const ms = JSON.stringify(m), r = R.read(m), rec = JSON.parse(E.parseJSON(ms));
  const lp = JSON.parse(E.localPromptJSON(ms, 0)), input = typeof lp === 'string' ? lp : (lp.text || lp.prompt || '');
  let ev = (r.events || []).filter((e) => e.type !== 'noise');
  const unsure = (r.events || []).some((e) => e.unsure || e.conf === 'low' || (e.p != null && e.p < 0.75));
  const out = ev.map(slim);
  if (rec.trip) out.push(Object.assign({ type: 'booking' }, rec.trip));
  const row = { id: m.id, src: 'mail', from: String(m.from || '').split('<').pop().replace('>', ''), input,
    output: JSON.stringify({ events: out }), rules: rec.kind + '/' + (rec.sure || '') };
  ev.forEach((e) => (tally[e.type] = (tally[e.type] || 0) + 1));
  (unsure || rec.sure === 'low' || rec.kind === 'unknown' ? queue : auto).push(row);
}
fs.mkdirSync(outDir, { recursive: true });
fs.writeFileSync(path.join(outDir, 'auto.jsonl'), auto.map((x) => JSON.stringify(x)).join('\n'));
fs.writeFileSync(path.join(outDir, 'queue.jsonl'), queue.map((x) => JSON.stringify(x)).join('\n'));
console.log(`${M.length} mails → auto ${auto.length}, queue ${queue.length}`); console.log('events', JSON.stringify(tally));
