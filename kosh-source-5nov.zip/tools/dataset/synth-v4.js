/* kosh-reader v4 practice set: invented SMS and emails across India's money senders, each with its answer.
   node tools/dataset/synth-v4.js <n> <outdir> [seed]
   People, merchants, numbers and references are random; layouts follow what these senders really send.
   Writes train.jsonl and test-unseen.jsonl (whole templates held back, so the score says how it does on a layout it
   never saw). Rows: {id, src, from, input, output} like build-v4.js; input mirrors engine.localPrompt
   ("From: …\nDate: …\nSubject: …\n\n<body>"). */
'use strict';
const fs = require('fs'), path = require('path');
const [, , N = '6000', OUT = '_corpus/v4/synth', SEED = '11'] = process.argv;
let s = +SEED >>> 0; const rnd = () => ((s = (s * 1664525 + 1013904223) >>> 0) / 4294967296);
const pick = (a) => a[Math.floor(rnd() * a.length)], int = (a, b) => a + Math.floor(rnd() * (b - a + 1));
const d4 = () => String(int(0, 9999)).padStart(4, '0'), digits = (n) => Array.from({ length: n }, () => int(0, 9)).join('');
const inr = (n) => { const [w, f] = n.toFixed(2).split('.'); let x = w.slice(-3), r = w.slice(0, -3); while (r.length > 2) { x = r.slice(-2) + ',' + x; r = r.slice(0, -2); } return (r ? r + ',' : '') + x + '.' + f; };
const amt = (lo, hi) => { const v = lo + rnd() * (hi - lo); return rnd() < 0.45 ? Math.round(v) : Math.round(v * 100) / 100; };
const pad = (n) => String(n).padStart(2, '0'), MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
function day() { const y = pick([2025, 2026]), m = int(1, 12), d = int(1, 28); return { iso: `${y}-${pad(m)}-${pad(d)}`, dmy: `${pad(d)}-${pad(m)}-${y}`, dmy2: `${pad(d)}/${pad(m)}/${String(y).slice(2)}`, dMy: `${pad(d)}-${MON[m - 1]}-${y}`, dmon: `${pad(d)} ${MON[m - 1]} ${y}` }; }
const tm = () => `${pad(int(0, 23))}:${pad(int(0, 59))}`;
const title = (s) => s.toLowerCase().replace(/\b\w/g, (c) => c.toUpperCase());
const BANKS = [['HDFC Bank', 'HDFC', 'HDFCBK'], ['ICICI Bank', 'ICICI', 'ICICIB'], ['State Bank of India', 'SBI', 'SBIINB'], ['Axis Bank', 'Axis', 'AXISBK'], ['Kotak Mahindra Bank', 'Kotak', 'KOTAKB'],
  ['IndusInd Bank', 'IndusInd', 'INDUSB'], ['Yes Bank', 'Yes', 'YESBNK'], ['IDFC FIRST Bank', 'IDFC', 'IDFCFB'], ['Bank of Baroda', 'BOB', 'BOBTXN'], ['Punjab National Bank', 'PNB', 'PNBSMS'],
  ['Canara Bank', 'Canara', 'CANBNK'], ['Union Bank of India', 'Union', 'UNIONB'], ['Federal Bank', 'Federal', 'FEDBNK'], ['AU Small Finance Bank', 'AU Bank', 'AUBANK'], ['RBL Bank', 'RBL', 'RBLBNK']];
const SHOPS = ['Swiggy', 'Zomato', 'Amazon', 'Flipkart', 'Myntra', 'BigBasket', 'Blinkit', 'Zepto', 'DMart', 'Reliance Digital', 'Uber', 'Ola', 'Indian Oil', 'HP Petrol Pump', 'Apollo Pharmacy',
  'Netflix', 'Spotify', 'Airtel', 'Jio', 'Tata Power', 'Croma', 'Starbucks', 'PVR Cinemas', 'Nykaa', 'Decathlon', 'IKEA'];
const PEOPLE = ['Rahul Sharma', 'Priya Verma', 'Amit Kumar', 'Sneha Iyer', 'Rohit Gupta', 'Anjali Singh', 'Vikram Rao', 'Neha Joshi', 'Karan Mehta', 'Pooja Nair', 'Arjun Reddy', 'Kavya Menon'];
const VPA = () => pick(['paytmqr', 'q', 'gpay-', 'phonepe', 'bharatpe']) + digits(int(6, 10)) + '@' + pick(['ptys', 'ybl', 'okaxis', 'okhdfcbank', 'ibl', 'axl', 'paytm']);
const REF = () => Array.from({ length: 6 }, () => pick('ABCDEFGHJKLMNPQRSTUVWXYZ'.split(''))).join('') + digits(4);
const T = [];
const add = (name, test, make) => T.push({ name, test, make });

/* ---------------- SMS: bank, card, UPI, ATM, wallet, dues, refunds; and what isn't money */
add('sms-acct-debit-upi', 0, () => { const [bn, bs, id] = pick(BANKS), D = day(), a = amt(20, 9000), l = d4(), v = VPA(), r = digits(12);
  return { from: id + '-S', body: pick([
    `Rs.${inr(a)} debited from A/c XX${l} on ${D.dmy2} to VPA ${v} (UPI Ref No ${r}). Not you? Call 1800XXXXXX -${bs}`,
    `Sent Rs.${a.toFixed(2)} From ${bn} A/C *${l} To ${v} On ${D.dmy2} Ref ${r} Not You? Call 18002586161/SMS BLOCK UPI to 7308080808`,
    `Dear Customer, Your A/c no. XX${l} is debited for Rs.${inr(a)} on ${D.dMy} and credited to ${v} (UPI Ref no ${r}) -${bs}`]),
    events: [{ type: 'move', dir: 'out', amt: a, date: D.iso, via: { kind: 'account', inst: bs, last4: l }, vpa: v, ref: r, mode: 'UPI' }] }; });
add('sms-acct-credit', 0, () => { const [bn, bs, id] = pick(BANKS), D = day(), a = amt(100, 90000), l = d4(), who = pick(PEOPLE), bal = amt(1000, 900000);
  return { from: id + '-S', body: pick([
    `Your A/c XX${l} is credited by Rs.${inr(a)} on ${D.dmy2} by ${who.toUpperCase()} (IMPS Ref ${digits(12)}). Avl Bal Rs.${inr(bal)} -${bs}`,
    `Rs ${inr(a)} credited to a/c XXXXXX${l} on ${D.dmy2} by NEFT from ${who.toUpperCase()}. Avl bal: INR ${inr(bal)}. ${bn}`]),
    events: [{ type: 'move', dir: 'in', amt: a, date: D.iso, via: { kind: 'account', inst: bs, last4: l }, party: who }, { type: 'balance', amt: bal, via: { kind: 'account', inst: bs, last4: l } }] }; });
add('sms-card-spend', 0, () => { const [bn, bs, id] = pick(BANKS), D = day(), shop = pick(SHOPS), a = amt(50, 25000), l = d4(), t = tm();
  return { from: id + '-T', body: pick([
    `Rs.${inr(a)} spent on ${bn} Credit Card XX${l} at ${shop.toUpperCase()} on ${D.dmy2} ${t}. Avl Lmt: Rs.${inr(amt(5000, 500000))}. Not you? Call 1800XXXX`,
    `Thank you for using your ${bs} Card ending ${l} for INR ${inr(a)} at ${shop} on ${D.dMy} at ${t}. If not done by you, call 1860XXXXXXX`]),
    events: [{ type: 'move', dir: 'out', amt: a, date: D.iso, time: t, via: { kind: 'card', inst: bs, last4: l }, party: shop, purpose: 'purchase' }] }; });
add('sms-atm', 0, () => { const [, bs, id] = pick(BANKS), D = day(), a = int(1, 20) * 500, l = d4(), bal = amt(1000, 300000), city = pick(['PUNE', 'MUMBAI', 'DELHI', 'AMBALA', 'BENGALURU', 'HYDERABAD']);
  return { from: id + '-S', body: `Rs.${inr(a)} withdrawn at ATM ${city} from A/c XX${l} on ${D.dmy2}. Avl Bal Rs.${inr(bal)} -${bs}`,
    events: [{ type: 'move', dir: 'out', amt: a, date: D.iso, via: { kind: 'account', inst: bs, last4: l }, mode: 'ATM', purpose: 'withdrawal' }, { type: 'balance', amt: bal, via: { kind: 'account', inst: bs, last4: l } }] }; });
add('sms-card-due', 1, () => { const [bn, bs, id] = pick(BANKS), D = day(), a = amt(500, 150000), l = d4(), mn = Math.round(a * 5) / 100;
  return { from: id + '-S', body: `Statement for ${bn} Credit Card XX${l}: Total Due Rs.${inr(a)}, Min Due Rs.${inr(mn)}, Due Date ${D.dmon}. Pay via app to avoid charges.`,
    events: [{ type: 'due', what: 'card', amt: a, min: mn, due: D.iso, via: { kind: 'card', inst: bs, last4: l } }] }; });
add('sms-wallet', 0, () => { const D = day(), a = amt(10, 3000), shop = pick(SHOPS), w = pick([['Paytm', 'PYTMBK'], ['Amazon Pay', 'AMZPAY'], ['MobiKwik', 'MOBIKW'], ['PhonePe', 'PHONPE']]);
  return { from: w[1] + '-S', body: `Paid Rs.${a} to ${shop} from ${w[0]} Wallet on ${D.dmon}. Txn ID ${digits(11)}`,
    events: [{ type: 'move', dir: 'out', amt: a, date: D.iso, via: { kind: 'wallet', inst: w[0] }, party: shop, purpose: 'purchase' }] }; });
add('sms-refund', 1, () => { const [, bs, id] = pick(BANKS), D = day(), a = amt(100, 8000), shop = pick(SHOPS), l = d4();
  return { from: id + '-S', body: `Refund of Rs.${inr(a)} from ${shop.toUpperCase()} credited to your Card XX${l} on ${D.dmy2} -${bs}`,
    events: [{ type: 'move', dir: 'in', amt: a, date: D.iso, via: { kind: 'card', inst: bs, last4: l }, party: shop, purpose: 'refund' }] }; });
add('sms-otp', 0, () => { const [, bs, id] = pick(BANKS);
  return { from: id + '-S', body: `${digits(6)} is your OTP for transaction of Rs.${inr(amt(100, 9000))} at ${pick(SHOPS)}. Valid 10 mins. Do not share with anyone -${bs}`, events: [] }; });
add('sms-promo', 0, () => { const [bn, , id] = pick(BANKS);
  return { from: id + '-P', body: `Pre-approved Personal Loan of up to Rs.${inr(int(1, 40) * 50000)} at ${int(10, 16)}.${int(0, 9)}% p.a. Apply now in ${bn} app. T&C`, events: [] }; });

/* ---------------- emails: tickets and events, travel, insurance, investments, bills, salary */
add('mail-event-ticket', 0, () => { const p = pick([['BookMyShow', 'bookmyshow.email'], ['District', 'district.in'], ['Paytm Insider', 'insider.in'], ['Zomato Live', 'zomato.com']]), D = day(), a = amt(300, 12000), ref = REF();
  const name = pick(['Arijit Singh Live', 'Zakir Khan Live', 'Coldplay: Music of the Spheres', 'Sunburn Arena', 'Prateek Kuhad Tour', 'IPL: MI vs CSK', 'Kaun Banega Comedian']);
  const venue = pick(['DY Patil Stadium, Navi Mumbai', 'Jio World Garden, Mumbai', 'NSCI Dome, Mumbai', 'JLN Stadium, Delhi', 'Phoenix Marketcity, Pune']);
  return { from: 'tickets@' + p[1], subject: `Booking Confirmation For ${name}`, body: `Your booking is confirmed! BOOKING ID: ${ref}. ${name}. Venue: ${venue}. Date & Time: ${D.dmon}, ${tm()}. Tickets: ${int(1, 4)}. Total amount paid: Rs. ${inr(a)}`,
    events: [{ type: 'order', shop: p[0], status: 'placed', order: ref, total: a }, { type: 'booking', p: p[0], k: 'event', doc: 'ticket', ref, name, on: D.iso, place: venue }] }; });
add('mail-hotel', 1, () => { const p = pick([['MakeMyTrip', 'makemytrip.com'], ['Booking.com', 'booking.com'], ['Agoda', 'agoda.com'], ['Goibibo', 'goibibo.com']]), D = day(), a = amt(1500, 40000), ref = digits(10), city = pick(['Goa', 'Jaipur', 'Manali', 'Udaipur', 'Rishikesh', 'Coorg']);
  return { from: 'noreply@' + p[1], subject: `Your booking is confirmed - ${city}`, body: `Booking ID ${ref}. ${pick(['Taj', 'Zostel', 'Lemon Tree', 'Treebo', 'Radisson'])} ${city}. Check-in: ${D.dmon}. Nights: ${int(1, 5)}. Amount paid: INR ${inr(a)}.`,
    events: [{ type: 'order', shop: p[0], status: 'placed', order: ref, total: a }, { type: 'booking', p: p[0], k: 'stay', doc: 'booking', ref, to: city, on: D.iso }] }; });
add('mail-train', 0, () => { const D = day(), a = amt(200, 4000), pnr = digits(10), [f, t] = pick([['New Delhi (NDLS)', 'Mumbai Central (MMCT)'], ['Pune Jn (PUNE)', 'Secunderabad (SC)'], ['Chandigarh (CDG)', 'Delhi (DLI)'], ['Howrah (HWH)', 'Patna (PNBE)']]);
  return { from: 'ticketadmin@irctc.co.in', subject: `Booking Confirmation on IRCTC, Train: ${int(12000, 22999)}`, body: `PNR No: ${pnr}. From: ${f} To: ${t}. Date of Journey: ${D.dmy}. Class: ${pick(['3A', '2A', 'SL', 'CC'])}. Total Fare: Rs. ${inr(a)}`,
    events: [{ type: 'order', shop: 'IRCTC', status: 'placed', order: pnr, total: a }, { type: 'booking', p: 'IRCTC', k: 'train', doc: 'ticket', ref: pnr, from: f, to: t, on: D.iso }] }; });
add('mail-flight', 1, () => { const p = pick(['IndiGo', 'Air India', 'Akasa Air', 'SpiceJet']), D = day(), a = amt(2500, 25000), pnr = REF().slice(0, 6), [f, t] = pick([['Delhi', 'Pune'], ['Mumbai', 'Bengaluru'], ['Chandigarh', 'Pune'], ['Hyderabad', 'Goa']]);
  return { from: 'noreply@' + p.toLowerCase().replace(/\W/g, '') + '.in', subject: `Your ${p} booking ${pnr} is confirmed`, body: `PNR: ${pnr}. ${f} to ${t} on ${D.dmon}, departs ${tm()}. Total paid: INR ${inr(a)}.`,
    events: [{ type: 'order', shop: p, status: 'placed', order: pnr, total: a }, { type: 'booking', p, k: 'flight', doc: 'ticket', ref: pnr, from: f, to: t, on: D.iso }] }; });
add('mail-cab', 0, () => { const D = day(), a = amt(80, 1800), p = pick(['Uber', 'Ola', 'Rapido']);
  return { from: 'receipts@' + p.toLowerCase() + '.com', subject: `Your trip with ${p}`, body: `Thanks for riding. Total ₹${inr(a)}. Trip on ${D.dmon}. Paid by ${pick(['UPI', 'Cash', 'Card'])}.`,
    events: [{ type: 'move', dir: 'out', amt: a, date: D.iso, party: p, purpose: 'purchase' }, { type: 'booking', p, k: 'cab', doc: 'receipt', on: D.iso }] }; });
const INS = [['HDFC Life', 'life'], ['LIC', 'life'], ['ICICI Prudential Life', 'life'], ['Max Life', 'life'], ['Tata AIA', 'life'], ['Star Health', 'health'], ['Niva Bupa', 'health'], ['Care Health', 'health'], ['HDFC ERGO', 'health'], ['ICICI Lombard', 'motor'], ['Bajaj Allianz', 'motor'], ['Digit', 'motor']];
const dom = (s) => s.toLowerCase().replace(/\W/g, '') + '.com';
add('mail-premium-due', 0, () => { const [ins, ty] = pick(INS), D = day(), p = amt(5000, 150000), no = digits(int(8, 12));
  return { from: 'renewals@' + dom(ins), subject: `Your ${ins} premium is due`, body: `Dear Customer, premium of Rs. ${inr(p)} for Policy No. ${no} (${ty} insurance) is due on ${D.dmon}. Pay before the due date to keep your cover active.`,
    events: [{ type: 'policy', action: 'due', insurer: ins, policyNo: no, premium: p, due: D.iso }] }; });
add('mail-premium-paid', 1, () => { const [ins] = pick(INS), D = day(), p = amt(5000, 150000), no = digits(int(8, 12)), c = int(3, 100) * 100000;
  return { from: 'service@' + dom(ins), subject: `Premium receipt for Policy ${no}`, body: `We have received Rs. ${inr(p)} on ${D.dmon} towards Policy No. ${no}. Sum assured Rs. ${inr(c)}.`,
    events: [{ type: 'policy', action: 'paid', insurer: ins, policyNo: no, premium: p, cover: c, date: D.iso }] }; });
add('mail-sip', 0, () => { const amc = pick(['HDFC Mutual Fund', 'SBI Mutual Fund', 'Axis Mutual Fund', 'Mirae Asset', 'Parag Parikh', 'Nippon India MF']), D = day(), a = int(5, 200) * 100, nav = amt(10, 900), u = +(a / nav).toFixed(3);
  return { from: 'donotreply@' + pick(['camsonline.com', 'kfintech.com']), subject: `Transaction confirmation - ${amc}`, body: `Your SIP purchase of Rs. ${inr(a)} in ${amc} ${pick(['Flexi Cap', 'Nifty 50 Index', 'Small Cap', 'ELSS Tax Saver'])} Fund - Direct Growth has been processed on ${D.dmy} at NAV ${nav}. Units allotted: ${u}. Folio: ${digits(8)}/${int(10, 99)}`,
    events: [{ type: 'trade', side: 'buy', what: 'fund', amt: a, units: u, date: D.iso, party: amc }] }; });
add('mail-dividend', 1, () => { const co = pick(['Infosys Limited', 'ITC Limited', 'Tata Consultancy Services', 'HDFC Bank Limited', 'Coal India Limited']), D = day(), a = amt(10, 5000);
  return { from: 'einward@' + pick(['kfintech.com', 'linkintime.co.in']), subject: `${co} - Dividend Credit Intimation`, body: `Dear Shareholder, ${co} has paid dividend. Net amount of Rs. ${inr(a)} has been credited to your bank account on ${D.dmon} via NACH.`,
    events: [{ type: 'dividend', company: co, amt: a, date: D.iso }] }; });
add('mail-utility', 0, () => { const b = pick(['Tata Power', 'MSEDCL', 'BESCOM', 'Adani Electricity', 'UHBVN', 'Mahanagar Gas', 'BSNL Broadband', 'ACT Fibernet']), D = day(), a = amt(200, 9000);
  return { from: 'billing@' + b.toLowerCase().replace(/\W/g, '') + '.in', subject: `Your ${b} bill`, body: `Consumer No. ${digits(10)}. Bill amount Rs. ${inr(a)}. Due date ${D.dmon}. Pay online to avoid late fee.`,
    events: [{ type: 'due', what: 'bill', amt: a, due: D.iso, party: b }] }; });
add('mail-salary', 1, () => { const [, bs] = pick(BANKS), D = day(), a = amt(30000, 400000), co = pick(['Infosys', 'Tech Mahindra', 'Deloitte', 'Wipro', 'Accenture']), l = d4();
  return { from: 'alerts@' + bs.toLowerCase().replace(/\W/g, '') + 'bank.in', subject: 'Credit alert', body: `Your A/c XX${l} is credited with INR ${inr(a)} on ${D.dmy} towards SALARY ${co.toUpperCase()}.`,
    events: [{ type: 'move', dir: 'in', amt: a, date: D.iso, via: { kind: 'account', inst: bs, last4: l }, party: co, purpose: 'salary' }] }; });
add('mail-promo', 0, () => { const shop = pick(SHOPS);
  return { from: 'offers@' + dom(shop), subject: `Flat ${int(10, 70)}% off this weekend`, body: `Big savings at ${shop}! Use code ${REF()} for up to Rs. ${int(1, 20) * 100} off on orders above Rs. ${int(5, 50) * 100}. Hurry, ends Sunday.`, events: [] }; });

/* ---------------- write */
const tr = [], te = [];
for (let i = 0; i < +N; i++) {
  const t = T[i % T.length], x = t.make(), D = day();
  const input = `From: ${x.from}\nDate: ${D.iso}\n` + (x.subject ? `Subject: ${x.subject}\n` : '') + `\n${x.body}`;
  (t.test ? te : tr).push({ id: 'syn-' + t.name + '-' + i, src: 'synth:' + t.name, from: x.from, input, output: JSON.stringify({ events: x.events }) });
}
fs.mkdirSync(OUT, { recursive: true });
fs.writeFileSync(path.join(OUT, 'train.jsonl'), tr.map((x) => JSON.stringify(x)).join('\n'));
fs.writeFileSync(path.join(OUT, 'test-unseen.jsonl'), te.map((x) => JSON.stringify(x)).join('\n'));
console.log(`${T.length} templates → train ${tr.length}, held-back templates ${te.length}`);
