const fs=require('fs'),vm=require('vm'),path=require('path');const K=path.join(__dirname,'..','..','Kosh')+'/';const c=vm.createContext({console});
vm.runInContext('var KoshDirectory = '+fs.readFileSync(K+'directory.json','utf8')+';',c);
for(const n of ['engine','docread'])vm.runInContext(fs.readFileSync(K+n+'.js','utf8'),c,{filename:n+'.js'});
const E=vm.runInContext('KoshEngine',c);
const txt=fs.readFileSync(process.argv[2],'utf8').replace(/[ \t]{3,}/g,'   ').replace(/\f/g,'\n');
const o=JSON.parse(E.parseDocJSON(txt,process.argv[3]||'cardstmt','','','',''));
(o.rows||[]).forEach(r=>console.log(r.date,r.dir,r.amt,r.desc.slice(0,60)));console.log(JSON.stringify(o.check));
