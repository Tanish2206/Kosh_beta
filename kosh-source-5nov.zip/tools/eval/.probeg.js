const fs=require('fs'),vm=require('vm'),path=require('path');const K=path.join(__dirname,'..','..','Kosh')+'/';const c=vm.createContext({console});
vm.runInContext('var KoshDirectory = '+fs.readFileSync(K+'directory.json','utf8')+';',c);
for(const n of ['engine','docread'])vm.runInContext(fs.readFileSync(K+n+'.js','utf8'),c,{filename:n+'.js'});
const E=vm.runInContext('KoshEngine',c);const t=fs.readFileSync(process.argv[2],'utf8'),g=fs.readFileSync(process.argv[3],'utf8');
const o=JSON.parse(E.parseDocJSON(t,process.argv[4]||'stmt',process.argv[5]||'','',g,''));
const keep=['kind','instr','last4','from','to','opening','closing','close','closeDate','check','byColumns'];const x={};keep.forEach(k=>{if(o[k]!==undefined)x[k]=o[k]});x.rows=(o.rows||[]).length;console.log(JSON.stringify(x).slice(0,600));
