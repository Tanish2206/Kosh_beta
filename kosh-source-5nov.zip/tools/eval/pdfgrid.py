#!/usr/bin/env python3
"""A PDF's words with where they sit, as the phone sends them (DocText.grid): "grid1", then one line per printed line,
"page,y<TAB>x0,x1,word<TAB>...". From pdftotext -bbox, so the Mac bench can read a statement the way the phone does.
python3 tools/eval/pdfgrid.py file.pdf [password] > out.grid"""
import subprocess, sys, re, html
f = sys.argv[1]; pw = sys.argv[2] if len(sys.argv) > 2 else ''
args = ['pdftotext', '-bbox'] + (['-upw', pw] if pw else []) + [f, '-']
r = subprocess.run(args, capture_output=True)
if r.returncode and pw: r = subprocess.run(['pdftotext', '-bbox', '-opw', pw, f, '-'], capture_output=True)
out = ['grid1']; page = 0
for line in r.stdout.decode('utf-8', 'ignore').split('\n'):
    if '<page ' in line:
        page += 1; rows = {}
        mw = re.search(r'width="([\d.]+)" height="([\d.]+)"', line); W, H = (float(mw[1]), float(mw[2])) if mw else (1000.0, 1000.0)
        continue
    m = re.search(r'<word xMin="([\d.]+)" yMin="([\d.]+)" xMax="([\d.]+)" yMax="([\d.]+)">(.*?)</word>', line)
    if m:
        x0, y0, x1, y1, w = float(m[1]), float(m[2]), float(m[3]), float(m[4]), html.unescape(m[5])
        key = round((y0 + y1) / 2 / 2.5)   # same baseline within ~2.5pt
        # in thousandths of the page, as the phone's grid is
        rows.setdefault(key, []).append((x0 * 1000 / W, x1 * 1000 / W, w, (y0 + y1) / 2 * 1000 / H))
    if '</page>' in line:
        # words whose middles are within ~3pt of each other are one printed line (not fixed buckets: a label and its
        # figure set a hair apart stay together, as the phone's DocLayout keeps them)
        allw = sorted((w for k in rows for w in rows[k]), key=lambda w: w[3])
        lines, cur = [], []
        for w in allw:
            if cur and w[3] - cur[-1][3] > 3.0 * 1000 / H: lines.append(cur); cur = []
            cur.append(w)
        if cur: lines.append(cur)
        for ws0 in lines:
            ws = sorted(ws0)
            out.append(str(page) + ',' + str(int(sum(x[3] for x in ws) / len(ws))) + '\t' + '\t'.join('%d,%d,%s' % (a, b, w) for a, b, w, _ in ws))
print('\n'.join(out))
