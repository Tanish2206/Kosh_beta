/* cardbill-4nov: every card statement PDF in the Gmail corpus read as the phone reads it (plain text + grid), and its own
   bill (total due, minimum, due day) checked. node tools/eval/bill-bench.js _corpus/stmts/gmail/files [--ratchet]
   Fails when a sender reads fewer bills than the ratchet holds, or a known bill (TRUTH, figures off the PDFs themselves)
   reads wrong. A card's bill on the Cards page comes from here first, so this is what keeps it right. */
'use strict';
const fs = require('fs'), vm = require('vm'), path = require('path');
const K = path.join(__dirname, '..', '..', 'Kosh') + '/';
const c = vm.createContext({ console });
vm.runInContext('var KoshDirectory = ' + fs.readFileSync(K + 'directory.json', 'utf8') + ';', c);
for (const n of ['engine', 'mailwire', 'knowledge', 'reader', 'journey', 'docread', 'agent', 'assist', 'viewplan', 'plan', 'brief', 'decide', 'packs', 'trips', 'checks', 'unlock'])
  vm.runInContext(fs.readFileSync(K + n + '.js', 'utf8'), c, { filename: n + '.js' });
const E = vm.runInContext('KoshEngine', c);
const D = process.argv[2];
const TRUTH = {   // file id → [total, minimum, due] as printed on the PDF
  '1a19e0c4c9549785': [21388, 1070, '2026-11-21'], '1a19d72bcbe028b7': [7533, 380, '2026-11-21'],
  '1a0fde5b81a85146': [10165, 510, '2026-10-21'], '1a0fd64b89272cb5': [7110, 360, '2026-10-21'],
  '1a19d8e4c1036d9d': [10911, 218, '2026-11-21'], '1a19c98e5b08c620': [164396.43, 3288, '2026-11-21'],
  '1a1992e51dbc0f61': [11005, 110.05, '2026-11-16'], '1a0dd771651d3494': [400, 100, '2026-10-15'],
  '19dc9fdb179aef6f': [13665.15, 13665.15, '2026-05-13'], '19c65fe3d9abf485': [4156, 200, '2026-03-07'],
};
const T = fs.readFileSync(path.join(D, 'truth.jsonl'), 'utf8').trim().split('\n').map(JSON.parse)
  .filter((r) => r.kind === 'cardstmt' && fs.existsSync(path.join(D, r.file + '.plain.txt')) && fs.existsSync(path.join(D, r.file + '.grid')));
const by = {}; let bad = 0;
for (const r of T) {
  const sent = (() => { const d = new Date(r.date); return isNaN(d) ? '' : d.toISOString().slice(0, 10); })();
  const o = JSON.parse(E.parseDocJSON(fs.readFileSync(path.join(D, r.file + '.plain.txt'), 'utf8').replace(/\f/g, '\n'), 'cardstmt', r.from, r.orig || '', fs.readFileSync(path.join(D, r.file + '.grid'), 'utf8'), sent));
  const k = String(r.from).split('@').pop().toLowerCase(), x = by[k] || (by[k] = { n: 0, bill: 0 });
  x.n++; if (o.bill) x.bill++;
  const t = TRUTH[r.mid];
  if (t) {
    const b = o.bill || {}, ok = Math.abs((b.amt || -1) - t[0]) < 1 && Math.abs((b.min || 0) - t[1]) < 1 && b.due === t[2];
    if (!ok) { bad++; console.log('WRONG', k, r.mid, JSON.stringify(b), 'should be', JSON.stringify(t)); }
  }
}
Object.keys(by).sort().forEach((k) => console.log(k.padEnd(26), by[k].n, 'statements,', by[k].bill, 'bills read'));
// the texts the PHONE kept (diag stmtTexts): each reading of the pages tried, the one that checks out kept, and the
// bill taken from any reading when the winner printed none (as LiveSession+Statements applyDoc does)
const PHONE = path.join(D, '..', '..', 'phone-texts', 'texts-cardbill-4nov.json');
const PHONE_TRUTH = {   // msg → [total, minimum, due, last4]
  '1a19d8e4c1036d9d': [10911, 218, '2026-11-21', '28'], '1a19e0c4c9549785': [21388, 1070, '2026-11-21', '4545'],
  '1a19a1e7367aa9b6': [26338.07, 263.38, '2026-11-19', '0719'], '1a19c98e5b08c620': [164396.43, 3288, '2026-11-21', '2363'],
  '1a17798c61e6137b': [0, 0, '2026-11-14', '0107'], '19e4ac943f5b147a': [0, 0, '2026-06-07', '0011'],
  '19d0a9b8db4695a7': [1352, 200, '2026-04-08', '5192'],
  '1a19d72bcbe028b7': [7533, 380, '2026-11-21', '5192'],   // the card caught on 4 Nov: read as its previous dues (7,110.32) before cardbill3
};
if (fs.existsSync(PHONE)) {
  const sc = (x) => { const k = x.check || {}; return (k.ok === true ? 3e12 : k.ok == null ? 1e12 : 0) + (x.rows || []).length; };
  let seen = 0;
  for (const t of JSON.parse(fs.readFileSync(PHONE, 'utf8'))) {
    const want = PHONE_TRUTH[t.msg]; if (!want) continue;
    const gi = t.text.indexOf('\n\u001F\n'), body = gi >= 0 ? t.text.slice(0, gi) : t.text, grid = gi >= 0 ? t.text.slice(gi + 3) : '';
    const outs = body.split('\n\u001E\n').map((v) => { try { return JSON.parse(E.parseDocJSON(v, t.kind, t.from, '', grid, t.sent)); } catch (e) { return null; } }).filter(Boolean);
    // no reading of the pages may give a wrong bill, even one that loses (a jumbled reading can win on another day)
    outs.forEach((o, n) => { const x = o.bill; if (x && !(Math.abs(x.amt - want[0]) < 1 && Math.abs((x.min || 0) - want[1]) < 1 && x.due === want[2])) { bad++; console.log('PHONE WRONG (reading ' + n + ')', t.msg, JSON.stringify(x), 'should be', JSON.stringify(want)); } });
    let best = outs.reduce((a, o) => (!a || sc(o) > sc(a) ? o : a), null);
    let b = best && best.bill;
    if (!b) { const bs = outs.map((o) => o.bill).filter(Boolean); b = bs.find((x) => x.eq) || bs[0]; }
    let l4 = best && best.last4 || '';
    if (!l4) { const ls = [...new Set(outs.map((o) => o.last4).filter(Boolean))]; if (ls.length === 1) l4 = ls[0]; }
    const ok = b && Math.abs(b.amt - want[0]) < 1 && Math.abs((b.min || 0) - want[1]) < 1 && b.due === want[2] && l4 === want[3];
    seen++;
    if (!ok) { bad++; console.log('PHONE WRONG', t.msg, String(t.from).slice(-30), JSON.stringify(b || null), 'card', l4, 'should be', JSON.stringify(want)); }
  }
  console.log('phone texts: ' + seen + ' known bills checked');
}
// the statement, never a leaflet riding with it (HSBC sent its terms first, and kosh read those as the statement)
[[['Most Important Terms & Conditions.pdf', '20261101.pdf'], 'creditcardstatement@mail.hsbc.bank.in', 'Your HSBC Credit Card statement (HSBC LIVE+ CREDIT CARD)', '20261101.pdf'],
 [['Important_Notes.pdf', '09OCT2026.pdf'], 'HSBC@notification.hsbc.bank.in', 'Statements for Accounts under Customer ID 255-XXXXXX', '09OCT2026.pdf'],
 [['weekly-securities-statement_CF5294.pdf', 'weekly-account-statement_CF5294.pdf'], 'x@reportsmailer.zerodha.net', 'Weekly statement', null],
].forEach(([files, from, subject, want]) => {
  const got = JSON.parse(E.docWantedJSON(JSON.stringify({ from, subject, attachments: files.map((f) => ({ filename: f })) })));
  if (want !== null && got.file !== want) { bad++; console.log('PICKED WRONG FILE', from, got.file, 'should be', want); }
});
const rp = path.join(D, '..', 'bill-ratchet.json');
const was = fs.existsSync(rp) ? JSON.parse(fs.readFileSync(rp, 'utf8')) : {};
let drop = 0;
Object.keys(was).forEach((k) => { if ((by[k] ? by[k].bill : 0) < was[k]) { drop++; console.log('DROPPED', k, was[k], '→', by[k] ? by[k].bill : 0); } });
if (process.argv.includes('--ratchet') && !drop && !bad) { Object.keys(by).forEach((k) => { was[k] = Math.max(was[k] || 0, by[k].bill); }); fs.writeFileSync(rp, JSON.stringify(was, null, 1)); }
console.log(bad || drop ? 'bill bench FAILED' : 'bill bench ok: ' + Object.keys(TRUTH).length + ' known bills right, no sender dropped');
process.exit(bad || drop ? 1 : 0);
