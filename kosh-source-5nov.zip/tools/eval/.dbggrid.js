const fs=require('fs'),vm=require('vm'),path=require('path');const K=path.join(__dirname,'..','..','Kosh')+'/';const c=vm.createContext({console});
vm.runInContext('var KoshDirectory = '+fs.readFileSync(K+'directory.json','utf8')+';',c);
let src=fs.readFileSync(K+'engine.js','utf8').replace('function parseDoc(text, kind, from, title, grid, sent) {','function parseDoc(text, kind, from, title, grid, sent) { if (typeof __dbg!==\"undefined\") __dbg.gridOf=gridOf, __dbg.gridStatement=gridStatement, __dbg.parseStmtLines=parseStmtLines, __dbg.stmtCheck=stmtCheck;');
vm.runInContext('var __dbg={};',c);vm.runInContext(src,c);vm.runInContext(fs.readFileSync(K+'docread.js','utf8'),c);
const E=vm.runInContext('KoshEngine',c);const D=vm.runInContext('__dbg',c);
const f=process.argv[2],kind=process.argv[3]||'stmt';const t=fs.readFileSync(f+'.txt','utf8').replace(/[ \t]{3,}/g,'   '),g=fs.readFileSync(f+'.grid','utf8');E.parseDocJSON(t,kind,'','',g,'');
const x=D.gridStatement(D.gridOf(g),kind,t);console.log('grid rows',x&&x.rows.length,x&&JSON.stringify({o:x.opening,c:x.closing,close:x.close}));if(x)console.log(JSON.stringify(D.stmtCheck(x,kind==='cardstmt',x.text+'\n'+t)));
if(x)x.rows.slice(0,process.env.N?+process.env.N:6).forEach(r=>console.log(' ',JSON.stringify(r).slice(0,140)));
