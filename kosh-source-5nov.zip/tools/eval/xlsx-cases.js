/* Spreadsheet statements: bank exports in the layouts HDFC and SBI give (tools/eval/xlsx-cases/*.xlsx, made by mk.py),
   unzipped as the phone does (first sheet + shared strings → xlsxDocJSON) and read by parseDocJSON. Each must give its
   account's digits, every line with its direction and sum, the closing balance, and lines that check out.
   node tools/eval/xlsx-cases.js   Exit 1 on any failure. Needs python3 for the unzip. */
'use strict';
const fs = require('fs'), vm = require('vm'), path = require('path'), cp = require('child_process');
const K = path.join(__dirname, '..', '..', 'Kosh') + '/', D = path.join(__dirname, 'xlsx-cases');
const c = vm.createContext({ console });
vm.runInContext('var KoshDirectory = ' + fs.readFileSync(K + 'directory.json', 'utf8') + ';', c);
for (const n of ['engine', 'mailwire', 'knowledge', 'reader', 'journey', 'docread', 'agent', 'assist', 'viewplan', 'plan', 'brief', 'decide', 'packs', 'trips', 'checks', 'unlock'])
  vm.runInContext(fs.readFileSync(K + n + '.js', 'utf8'), c, { filename: n + '.js' });
const E = vm.runInContext('KoshEngine', c);
const part = (f, n) => cp.execFileSync('python3', ['-I', '-c', 'import zipfile,sys;z=zipfile.ZipFile(sys.argv[1]);n=sys.argv[2];print(z.read(n).decode("utf-8") if n in z.namelist() else "",end="")', f, n], { maxBuffer: 1e8 }).toString();
const CASES = [
  ['hdfc.xlsx', 'hdfcbanksmartstatement@hdfcbank.bank.in', '6150', 166750, [['out', 1250], ['in', 150000], ['out', 12000], ['out', 20000]]],
  ['sbi.xlsx', 'cbssbi.cas@alerts.sbi.bank.in', '4669', 24812, [['out', 250], ['in', 20000], ['in', 62]]],
];
let bad = 0;
for (const [file, from, l4, close, lines] of CASES) {
  const f = path.join(D, file);
  const doc = JSON.parse(E.xlsxDocJSON(part(f, 'xl/worksheets/sheet1.xml'), part(f, 'xl/sharedStrings.xml')));
  const txt = typeof doc === 'string' ? doc : (doc.text || '');
  const o = JSON.parse(E.parseDocJSON(txt, 'stmt', from, file, doc.grid || '', ''));
  const rows = o.rows || [];
  const ok = o.last4 === l4 && Math.abs((o.close ?? o.closing) - close) < 0.01 && (o.check || {}).ok === true &&
    rows.length === lines.length && lines.every(([d, a], i) => rows[i] && rows[i].dir === d && Math.abs(rows[i].amt - a) < 0.01);
  if (!ok) bad++;
  console.log((ok ? 'ok    ' : 'FAIL  ') + file + '  (••' + o.last4 + ', ' + rows.length + ' lines, closing ' + (o.close ?? o.closing) + ', checks ' + (o.check || {}).ok + ')');
}
console.log(bad ? bad + ' failed' : 'all passed'); process.exit(bad ? 1 : 0);
