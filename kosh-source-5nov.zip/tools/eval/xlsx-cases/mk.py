import zipfile,sys
from xml.sax.saxutils import escape
def col(i):
    s=''
    while True:
        s=chr(65+i%26)+s; i=i//26-1
        if i<0: return s
def make(path, rows):
    strs=[];idx={}
    def si(v):
        if v not in idx: idx[v]=len(strs); strs.append(v)
        return idx[v]
    out=[]
    for r,row in enumerate(rows,1):
        cells=[]
        for c,v in enumerate(row):
            ref=col(c)+str(r)
            if v is None or v=='': continue
            if isinstance(v,(int,float)): cells.append('<c r="%s"><v>%s</v></c>'%(ref,v))
            else: cells.append('<c r="%s" t="s"><v>%d</v></c>'%(ref,si(str(v))))
        out.append('<row r="%d">%s</row>'%(r,''.join(cells)))
    sheet='<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>%s</sheetData></worksheet>'%''.join(out)
    sst='<?xml version="1.0" encoding="UTF-8"?><sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="%d" uniqueCount="%d">%s</sst>'%(len(strs),len(strs),''.join('<si><t>%s</t></si>'%escape(s) for s in strs))
    z=zipfile.ZipFile(path,'w'); z.writestr('xl/worksheets/sheet1.xml',sheet); z.writestr('xl/sharedStrings.xml',sst); z.close()
# HDFC-style export
make('hdfc.xlsx',[['HDFC BANK Ltd.'],['Account Statement'],['Account No :','50100123456150'],['Statement From :','01/10/2026','To :','31/10/2026'],[],
 ['Date','Narration','Chq./Ref.No.','Value Dt','Withdrawal Amt.','Deposit Amt.','Closing Balance'],
 ['01/10/26','UPI-BLUE TOKAI-bluetokai@okaxis-UTIB0000114-612345678901-UPI','0000612345678901','01/10/26',1250.00,'',48750.00],
 ['05/10/26','NEFT CR-HSBC0110002-DELOITTE SHARED SERVICES-SALARY OCT','HSBCN26278123456','05/10/26','',150000.00,198750.00],
 ['12/10/26','ACH D- HDFC LIFE-0012345678','0000001234567','12/10/26',12000.00,'',186750.00],
 ['31/10/26','IMPS-630412345678-SUNIL BHUTANI-INDB-XXXXXX7772-mom','0000630412345678','31/10/26',20000.00,'',166750.00],
 [],['STATEMENT SUMMARY :-'],['Opening Balance','Dr Count','Cr Count','Debits','Credits','Closing Bal'],[50000.00,3,1,33250.00,150000.00,166750.00]])
# SBI-style export
make('sbi.xlsx',[['Account Name','MRIDUL BHUTANI'],['Account Number','00000031234564669'],['Balance as on 1 Oct 2026','5,000.00'],[],
 ['Txn Date','Value Date','Description','Ref No./Cheque No.','Debit','Credit','Balance'],
 ['2 Oct 2026','2 Oct 2026','TO TRANSFER-UPI/DR/612345678911/RAMESH STORE/YESB/ramesh@ybl/UPI','TRANSFER TO 4897691162091',250,'',4750],
 ['15 Oct 2026','15 Oct 2026','BY TRANSFER-NEFT*HDFC0000001*N28812345*MRIDUL BHUTANI','TRANSFER FROM 4897694162092','',20000,24750],
 ['31 Oct 2026','31 Oct 2026','CREDIT INTEREST','','',62,24812]])
