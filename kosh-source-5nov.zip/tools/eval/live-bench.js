/* Live-balance bench: a time machine over the real year. On each replay day D kosh sees only the mail and the
   statements that had ARRIVED by D (prof.today = D), and each bank account's balance for D is compared with the truth
   for the end of D, rebuilt from the statements' own lines (opening + every line up to D, statements that add up).
   node tools/eval/live-bench.js [--mails=_corpus/2026-10-18-full/all.json] [--step=3] [--engine=path] [--json=out]
   [--ratchet] (fail when any bank is worse than _corpus/stmts/live-ratchet.json) [--save] (write that ratchet)
   Prints per account: days scored, exact (within ₹1), within ₹100, worst miss, and the same for the "late window"
   (days after a statement closed but before it arrived). Nothing from the mail is printed. */
'use strict';
const fs = require('fs'), vm = require('vm'), path = require('path');
const arg = (k, d) => { const a = process.argv.find((x) => x.startsWith('--' + k + '=')); return a ? a.slice(k.length + 3) : d; };
const ROOT = path.join(__dirname, '..', '..'), K = path.join(ROOT, 'Kosh') + '/';
const c = vm.createContext({ console });
vm.runInContext('var KoshDirectory = ' + fs.readFileSync(K + 'directory.json', 'utf8') + ';', c);
for (const n of ['engine', 'mailwire', 'knowledge', 'reader', 'journey', 'docread', 'agent', 'assist', 'viewplan', 'plan', 'brief', 'decide', 'packs', 'trips', 'checks', 'unlock']) {
  const f = n === 'engine' && arg('engine') ? arg('engine') : K + n + '.js';
  vm.runInContext(fs.readFileSync(f, 'utf8'), c, { filename: n + '.js' });
}
const E = vm.runInContext('KoshEngine', c);
const day = (s) => { const d = new Date(String(s || '').replace(' at ', ' ')); return isNaN(d) ? '' : d.toISOString().slice(0, 10); };
const addD = (d, n) => new Date(Date.parse(d + 'T00:00:00Z') + n * 864e5).toISOString().slice(0, 10);
const short = (from) => { const i = E.institution ? E.institution(from || '') : null; return i ? i.short : ''; };

// --- mail, read once; each record keeps the day its mail arrived
const mails = JSON.parse(fs.readFileSync(path.join(ROOT, arg('mails', '_corpus/2026-10-18-full/all.json')), 'utf8'));
const recs = mails.map((m) => { const r = JSON.parse(E.parseJSON(JSON.stringify(m))); return { r, at: day(m.date) }; });
const mailTo = recs.reduce((x, y) => (y.at > x ? y.at : x), '');

// --- statements, read the way the phone keeps them (StmtDoc), each with the day it arrived
const SD = path.join(ROOT, '_corpus/stmts/gmail/files');
const T = fs.readFileSync(path.join(SD, 'truth.jsonl'), 'utf8').trim().split('\n').map(JSON.parse);
const stmts = [];
for (const t of T) {
  if (t.kind !== 'stmt') continue;
  const f = path.join(SD, t.file + '.txt');
  if (!fs.existsSync(f)) continue;
  const g = path.join(SD, t.file + '.grid'), sent = day(t.date);
  let o; try { o = JSON.parse(E.parseDocJSON(fs.readFileSync(f, 'utf8').replace(/[ \t]{3,}/g, '   ').replace(/\f/g, '\n'), 'stmt', t.from, t.orig || '', fs.existsSync(g) ? fs.readFileSync(g, 'utf8') : '', sent)); } catch (e) { continue; }
  if ((o.instr || 'account') !== 'account') continue;
  const parts = (o.parts && o.parts.length) ? o.parts : [{ rows: o.rows || [], last4: o.last4, from: o.from, to: o.to, close: o.close, closeDate: o.closeDate, check: o.check, opening: o.opening }];
  parts.forEach((p, n) => {
    if (!(p.rows || []).length && p.close == null) return;
    stmts.push({ src: 'doc:' + t.mid + (parts.length > 1 ? '#' + n : ''), from: t.from, instr: 'account', last4: p.last4 || '',
      rows: (p.rows || []).map((r) => ({ date: r.date, desc: r.desc, amt: r.amt, dir: r.dir, chk: r.chk })), sent, owner: 'me',
      periodFrom: p.from || '', periodTo: p.to || '', close: p.close, closeDate: p.closeDate, ok: (p.check || {}).ok, note: (p.check || {}).note,
      open: p.opening, _inst: short(t.from) });
  });
}

if (arg('list')) stmts.filter((S) => S._inst === arg('list')).sort((x, y) => (x.periodTo < y.periodTo ? -1 : 1)).forEach((S) => console.log('STMT', S.src.slice(4, 12), S.last4, S.periodFrom, S.periodTo, 'open', S.open, 'close', S.close, S.closeDate, 'ok', S.ok, 'rows', S.rows.length, 'sent', S.sent));
if (arg('list')) process.exit(0);
// --- truth: the end-of-day balance on every day a statement that adds up covers
const truth = {};   // 'HDFC|6150' -> { 'YYYY-MM-DD': v }
const closeOf = {}; // 'HDFC|6150' -> [{ close day, arrived day }]
// (a statement that printed no digits is its bank's only account's, as the engine reads it)
const digitsOf = {};
stmts.forEach((S) => { const d = String(S.last4 || '').replace(/\D/g, '').slice(-4); if (S._inst && d.length === 4) (digitsOf[S._inst] = digitsOf[S._inst] || new Set()).add(d); });
for (const S of stmts) {
  let l4 = String(S.last4 || '').replace(/\D/g, '').slice(-4);
  if (!l4 && S._inst && digitsOf[S._inst] && digitsOf[S._inst].size === 1) l4 = [...digitsOf[S._inst]][0];
  if (!S._inst || l4.length !== 4) continue;
  const k = S._inst + '|' + l4;
  if (S.closeDate || S.periodTo) (closeOf[k] = closeOf[k] || []).push({ close: S.closeDate || S.periodTo, arrived: S.sent });
  if (S.ok !== true || S.open == null || !S.periodFrom || !S.periodTo) continue;
  const tk = truth[k] || (truth[k] = {});
  let v = +S.open; const by = {};
  S.rows.forEach((r) => { by[r.date] = (by[r.date] || 0) + (r.dir === 'in' ? +r.amt : -r.amt); });
  for (let d = S.periodFrom; d <= S.periodTo; d = addD(d, 1)) { v = Math.round((v + (by[d] || 0)) * 100) / 100; tk[d] = v; }
}

if (arg('lines')) {
  const P = { name: 'Mridul Bhutani', today: mailTo, statements: stmts.map((s) => { const o = Object.assign({}, s); delete o._inst; return o; }) };
  const snap = JSON.parse(E.buildJSON(JSON.stringify(recs.map((x) => x.r)), JSON.stringify(P)));
  const re = new RegExp(arg('lines'), 'i');
  if (arg('lines') === 'accounts') { (snap.accounts || []).forEach((a) => console.log('ACCT', a.bank, a.last, 'sweep', a.sweep || false, 'bal', a.balance)); process.exit(0); }
  (snap.tx || []).filter((t) => re.test((t.m || '') + ' ' + (t.n || ''))).forEach((t) => console.log('LINE', t.d, t.dr, t.a, (t.card || '').padEnd(18), (t.c + '/' + (t.s || '') + '/' + t.k).padEnd(34), String(t.m).slice(0, 50)));
  process.exit(0);
}
// --- replay
const step = +arg('step', '3');
const allDays = Object.values(truth).flatMap((x) => Object.keys(x)).sort();
const from = arg('from', allDays[0] < '2025-11-01' ? '2025-11-01' : allDays[0]), to = arg('to', mailTo);
const score = {};
const late = (k, d) => (closeOf[k] || []).some((s) => s.close < d && s.arrived >= d);
for (let D = from; D <= to; D = addD(D, step)) {
  const R = recs.filter((x) => x.at && x.at <= D).map((x) => x.r);
  const P = { name: 'Mridul Bhutani', today: D, statements: stmts.filter((s) => s.sent && s.sent <= D).map((s) => { const o = Object.assign({}, s); delete o._inst; return o; }) };
  let snap; try { snap = JSON.parse(E.buildJSON(JSON.stringify(R), JSON.stringify(P))); } catch (e) { console.error(D, String(e).slice(0, 120)); continue; }
  (snap.accounts || []).forEach((a) => {
    const k = a.bank + '|' + String(a.last || '').slice(-4), tv = (truth[k] || {})[D];
    if (arg('debug') === k && tv === undefined) console.log('DBG', D, 'truth none', 'kosh', a.balance, JSON.stringify(a.bal || null));
    if (tv === undefined) return;
    const s = score[k] || (score[k] = { n: 0, exact: 0, near: 0, worst: 0, worstDay: '', none: 0, ln: 0, lexact: 0, lworst: 0, offs: [] });
    s.n++;
    if (arg('debug') === k) console.log('DBG', D, 'truth', tv, 'kosh', a.balance, JSON.stringify(a.bal || null));
    if (arg('debug') === k && arg('tx')) (snap.tx || []).filter((t) => t.card === a.id && (t.od || t.d) > String(a.asOf) && !t.partOf).forEach((t) => console.log('  TX', t.od || t.d, t.dirRaw, t.full !== undefined ? t.full : t.a, String(t.n || t.party || t.m || '').slice(0, 28), t.c || '', t.id.slice(0, 10)));
    if (a.balance === null || a.balance === undefined) { s.none++; return; }
    const off = Math.round((a.balance - tv) * 100) / 100, ab = Math.abs(off);
    s.offs.push(ab); if (ab <= 1) s.exact++; if (ab <= 100) s.near++;
    if (ab > Math.abs(s.worst)) { s.worst = off; s.worstDay = D; }
    if (late(k, D)) { s.ln++; if (ab <= 1) s.lexact++; if (ab > Math.abs(s.lworst)) s.lworst = off; }
  });
}
const rows = Object.keys(score).sort();
let tn = 0, te = 0;
console.log('account'.padEnd(16) + 'days  exact  ≤₹100  none   worst (day)            late: days exact worst');
rows.forEach((k) => {
  const s = score[k]; tn += s.n; te += s.exact;
  console.log(k.padEnd(16) + String(s.n).padStart(4) + String(s.exact).padStart(7) + String(s.near).padStart(7) + String(s.none).padStart(6) + '   ' +
    (s.worst ? (s.worst > 0 ? '+' : '') + s.worst.toFixed(2) + ' (' + s.worstDay + ')' : '0').padEnd(22) + '  ' + String(s.ln).padStart(4) + String(s.lexact).padStart(6) + '  ' + (s.lworst || 0).toFixed(2));
});
const med = (a) => { const x = a.slice().sort((p, q) => p - q); return x.length ? x[x.length >> 1] : 0; };
console.log('median miss per account: ' + rows.map((k) => k + ' ₹' + Math.round(med(score[k].offs)).toLocaleString('en-IN')).join(' · '));
const allOffs = rows.flatMap((k) => score[k].offs);
console.log('ALL median miss ₹' + Math.round(med(allOffs)).toLocaleString('en-IN') + ' · mean ₹' + Math.round(allOffs.reduce((x, y) => x + y, 0) / Math.max(1, allOffs.length)).toLocaleString('en-IN'));
console.log('ALL exact', te + '/' + tn, '(' + (tn ? Math.round(1000 * te / tn) / 10 : 0) + '%)', '· statements', stmts.length, '· accounts with truth', Object.keys(truth).length, '· days', from, '→', to, 'step', step);
const RP = path.join(ROOT, '_corpus/stmts/live-ratchet.json');
if (arg('json')) fs.writeFileSync(arg('json'), JSON.stringify(score, null, 1));
if (process.argv.includes('--save')) { fs.writeFileSync(RP, JSON.stringify(score, null, 1)); console.log('ratchet saved'); }
if (process.argv.includes('--ratchet') && fs.existsSync(RP)) {
  const old = JSON.parse(fs.readFileSync(RP, 'utf8')); let bad = 0;
  Object.keys(old).forEach((k) => { const o = old[k], n = score[k] || { exact: 0 }; if (n.exact < o.exact) { bad++; console.log('WORSE', k, o.exact, '→', n.exact); } });
  if (bad) process.exit(1); console.log('ratchet ok');
}
