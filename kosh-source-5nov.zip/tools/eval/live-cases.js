/* Live-balance cases: small made-up accounts built through the real engine (buildJSON), each a situation the balance
   must get right whatever order the news arrives in. node tools/eval/live-cases.js   Exit 1 on any failure. */
'use strict';
const fs = require('fs'), vm = require('vm'), path = require('path');
const arg = (k, d) => { const a = process.argv.find((x) => x.startsWith('--' + k + '=')); return a ? a.slice(k.length + 3) : d; };
const K = path.join(__dirname, '..', '..', 'Kosh') + '/';
const c = vm.createContext({ console });
vm.runInContext('var KoshDirectory = ' + fs.readFileSync(K + 'directory.json', 'utf8') + ';', c);
for (const n of ['engine', 'mailwire', 'knowledge', 'reader', 'journey', 'docread', 'agent', 'assist', 'viewplan', 'plan', 'brief', 'decide', 'packs', 'trips', 'checks', 'unlock'])
  vm.runInContext(fs.readFileSync(n === 'engine' && arg('engine') ? arg('engine') : K + n + '.js', 'utf8'), c, { filename: n + '.js' });
const E = vm.runInContext('KoshEngine', c);
let id = 0;
const pay = (date, time, dir, amt, o) => Object.assign({ id: 'c' + (++id).toString(16).padStart(15, '0'), sent: date, from: 'alerts@hdfcbank.bank.in', inst: 'HDFC', instKind: 'bank',
  subject: 'alert', src: 'rule', kind: 'txn', rule: 'acct-dir-with', dir, amt, date, time, instr: 'account', last4: '6150', party: 'Shop ' + id, mode: 'UPI', conf: 'high', sure: 'high' }, o || {});
const stmt = (from, to, open, close, rows, sent) => ({ src: 'doc:s' + (++id), from: 'hdfcbanksmartstatement@hdfcbank.bank.in', instr: 'account', last4: '6150', rows, sent, owner: 'me',
  periodFrom: from, periodTo: to, close, closeDate: to, ok: true, open });
const bal = (recs, statements, today) => {
  const s = JSON.parse(E.buildJSON(JSON.stringify(recs), JSON.stringify({ name: 'Test Person', today, statements })));
  const a = (s.accounts || []).find((x) => x.bank === 'HDFC' && String(x.last).slice(-4) === '6150');
  return a ? a.balance : null;
};
let bad = 0;
const check = (name, got, want) => { const ok = got !== null && Math.abs(got - want) <= 0.5; if (!ok) bad++; console.log((ok ? 'ok    ' : 'FAIL  ') + name + '  (kosh ' + got + ', truth ' + want + ')'); };

// 1. a late statement: Oct closes 50,000 on the 31st, arrives 5 Nov; Nov payments since must all be on top
{ const R = [pay('2026-10-20', '10:00', 'out', 2000), pay('2026-11-01', '09:00', 'out', 1000), pay('2026-11-03', '18:00', 'in', 300), pay('2026-11-04', '12:00', 'out', 450)];
  const S = [stmt('2026-10-01', '2026-10-31', 52000, 50000, [{ date: '2026-10-20', desc: 'UPI-SHOP', amt: 2000, dir: 'out', chk: true }], '2026-11-05')];
  check('late statement + payments after it', bal(R, S, '2026-11-05'), 50000 - 1000 + 300 - 450); }
// 2. the same day the statement arrives, before any payment: the statement's closing
{ const S = [stmt('2026-10-01', '2026-10-31', 1000, 1000, [], '2026-11-02')];
  check('statement alone', bal([], S, '2026-11-02'), 1000); }
// 3. a spend on the last evening, booked the next day: NOT in the statement, so it comes off after it
{ const R = [pay('2026-10-31', '23:40', 'out', 700)];
  const S = [stmt('2026-10-01', '2026-10-31', 10500, 10000, [{ date: '2026-10-12', desc: 'UPI-OTHER', amt: 500, dir: 'out', chk: true }], '2026-11-03')];
  check('last-evening spend booked next day', bal(R, S, '2026-11-03'), 10000 - 700); }
// 4. a spend on the last day that IS in the statement: not taken off twice
{ const R = [pay('2026-10-31', '11:00', 'out', 700)];
  const S = [stmt('2026-10-01', '2026-10-31', 10700, 10000, [{ date: '2026-10-31', desc: 'UPI-SHOP', amt: 700, dir: 'out', chk: true }], '2026-11-03')];
  check('last-day spend the statement lists', bal(R, S, '2026-11-03'), 10000); }
// 5. an alert with a balance on 3 Nov, then the Oct statement arrives on the 5th: the newer alert wins
{ const R = [pay('2026-11-02', '10:00', 'out', 500), pay('2026-11-03', '10:00', 'out', 200, { bal: 8800 }), pay('2026-11-04', '10:00', 'out', 100)];
  const S = [stmt('2026-10-01', '2026-10-31', 9500, 9500, [], '2026-11-05')];
  check('newer alert balance beats a later-arriving statement', bal(R, S, '2026-11-05'), 8800 - 100); }
// 6. a stretch that doesn't add up (₹2,206 the mail never told) before the anchor: the anchor still rolls forward
{ const R = [pay('2026-10-10', '10:00', 'out', 1000), pay('2026-11-02', '10:00', 'out', 1000)];
  const S = [stmt('2026-09-01', '2026-09-30', 80000, 80000, [], '2026-10-03'), stmt('2026-10-01', '2026-10-31', 80000, 81206, [], '2026-11-03')];
  check('gap before the anchor never freezes it', bal(R, S, '2026-11-04'), 81206 - 1000); }
// 7. one payment told twice (alert + a second copy of the alert): counted once
{ const a = pay('2026-11-02', '10:00', 'out', 640, { ref: '612345678901' }); const b = Object.assign({}, a, { id: 'c' + (++id).toString(16).padStart(15, '0') });
  const S = [stmt('2026-10-01', '2026-10-31', 5000, 5000, [], '2026-11-02')];
  check('a payment told twice counts once', bal([a, b], S, '2026-11-03'), 5000 - 640); }
// 8. statements arriving out of order (Oct before Sep): the latest close is the anchor
{ const R = [pay('2026-11-02', '10:00', 'in', 100)];
  const S = [stmt('2026-10-01', '2026-10-31', 4000, 6000, [{ date: '2026-10-05', desc: 'CR', amt: 2000, dir: 'in', chk: true }], '2026-11-01'), stmt('2026-09-01', '2026-09-30', 3000, 4000, [{ date: '2026-09-05', desc: 'CR', amt: 1000, dir: 'in', chk: true }], '2026-11-04')];
  check('statements arriving out of order', bal(R, S, '2026-11-05'), 6100); }
// 9. a card bill paid through CRED that never says which bank paid: kosh's guess moves no balance
{ const R = [pay('2026-10-05', '10:00', 'out', 300), pay('2026-10-06', '10:00', 'out', 200), pay('2026-10-07', '10:00', 'out', 100),
    { id: 'c' + (++id).toString(16).padStart(15, '0'), sent: '2026-11-02', from: 'protect@cred.club', inst: 'CRED', instKind: 'app', subject: 'your credit card bill payment was successful', src: 'rule', kind: 'confirm', rule: 'card-bill-paid', dir: 'out', amt: 9000, date: '2026-11-02', time: '', instr: 'card', last4: '2363', party: 'Axis card bill', mode: 'UPI', cat: 'Card Payments', conf: 'high', issuer: 'Axis', sure: 'high' }];
  const S = [stmt('2026-10-01', '2026-10-31', 20600, 20000, [{ date: '2026-10-05', desc: 'UPI', amt: 300, dir: 'out', chk: true }, { date: '2026-10-06', desc: 'UPI', amt: 200, dir: 'out', chk: true }, { date: '2026-10-07', desc: 'UPI', amt: 100, dir: 'out', chk: true }], '2026-11-01')];
  check('a bill paid from an account kosh only guessed', bal(R, S, '2026-11-03'), 20000); }
// 10. your own transfer from Kotak to this account, with no credit alert from HDFC: the money is in
{ const R = [pay('2026-11-02', '10:00', 'out', 25000, { from: 'bankalerts@kotak.bank.in', inst: 'Kotak', last4: '5032', party: 'TEST PERSON', mode: 'IMPS', toLast4: '6150' })];
  const S = [stmt('2026-10-01', '2026-10-31', 1000, 1000, [], '2026-11-01')];
  check('own transfer in, its credit never alerted', bal(R, S, '2026-11-03'), 26000);
  const R2 = R.concat([pay('2026-11-02', '10:05', 'in', 25000, { party: 'TEST PERSON', mode: 'IMPS' })]);
  check('own transfer in, its credit alerted too (once)', bal(R2, S, '2026-11-03'), 26000); }
// 11. SMS: the balance an SMS prints resets the account to the bank's own figure, whatever kosh missed before it
const sms = (from, text, date) => JSON.parse(E.parseJSON(JSON.stringify({ id: 's' + (++id).toString(16).padStart(15, '0'), from, date, subject: '', text, html: '', chan: 'sms' })));
{ const S = [stmt('2026-10-01', '2026-10-31', 50000, 50000, [], '2026-11-01')];
  // (a ₹5,000 transfer in on 2 Nov that sent nothing, then an SMS debit on the 3rd printing the true balance)
  const R = [sms('JM-HDFCBK-S', 'Rs.1000.00 has been debited from account **6150 to account **1234 on 03-11-26. Info: IMPS-630212345684-SUNIL.Avl bal:INR 54,000.00', '2026-11-03T05:00:00Z'),
    pay('2026-11-04', '10:00', 'out', 400)];
  check('SMS balance resets it, payments after it on top', bal(R, S, '2026-11-04'), 54000 - 400);
  const R2 = [sms('JM-HDFCBK-S', 'Update! INR 20,000.00 deposited in HDFC Bank A/c XX6150 on 02-NOV-26 for NEFT Cr-HSBC0110002-TEST PERSON-HSBCN26304123456.Avl bal INR 70,000.00. Cheque deposits in A/C are subject to clearing', '2026-11-02T06:00:00Z')];
  check('SMS credit with no mail at all', bal(R2, S, '2026-11-04'), 70000);
  const R3 = [sms('AD-KOTAKB-S', 'INR 2,500.00 spent on Kotak Credit Card x0719 on 01/11/2026 at AMAZON. Avl limit INR 97,500.00. Not you? Call 18602662666', '2026-11-02T06:00:00Z')];
  check('a card SMS\'s limit is never an account balance', bal(R3, S, '2026-11-04'), 50000); }
// 12. a statement whose closing was misread (its lines don't add up) and contradicts the month before + payments: passed over
{ const R = [pay('2026-10-10', '10:00', 'in', 400000), pay('2026-10-20', '10:00', 'out', 1000), pay('2026-11-02', '10:00', 'out', 500)];
  const S = [stmt('2026-09-01', '2026-09-30', 900, 794, [{ date: '2026-09-12', desc: 'UPI', amt: 106, dir: 'out', chk: true }], '2026-10-02'),
    Object.assign(stmt('2026-10-01', '2026-10-31', 794, 1287, [{ date: '2026-10-10', desc: 'NEFT CR', amt: 400000, dir: 'in', chk: true }], '2026-11-02'), { ok: false })];
  check('misread statement closing is passed over', bal(R, S, '2026-11-03'), 794 + 400000 - 1000 - 500);
  // and a statement that didn't check out but agrees with what came before is used
  const S2 = [S[0], Object.assign(stmt('2026-10-01', '2026-10-31', 794, 399794, [], '2026-11-02'), { ok: false })];
  check('unchecked statement that agrees is used', bal(R, S2, '2026-11-03'), 399794 - 500); }
console.log(bad ? bad + ' failed' : 'all passed'); process.exit(bad ? 1 : 0);
