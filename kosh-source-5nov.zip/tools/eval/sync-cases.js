/* Sync cases: one payment told by several sources (bank SMS, bank email alert, the statement's line, the shop's own
   receipt) must be ONE row, keep what each source added (time, UPI ID, reference, shop's name, items), say every
   source it was told by, and move the balance once. node tools/eval/sync-cases.js   Exit 1 on any failure. */
'use strict';
const fs = require('fs'), vm = require('vm'), path = require('path');
const arg = (k, d) => { const a = process.argv.find((x) => x.startsWith('--' + k + '=')); return a ? a.slice(k.length + 3) : d; };
const K = path.join(__dirname, '..', '..', 'Kosh') + '/';
const c = vm.createContext({ console });
vm.runInContext('var KoshDirectory = ' + fs.readFileSync(K + 'directory.json', 'utf8') + ';', c);
for (const n of ['engine', 'mailwire', 'knowledge', 'reader', 'journey', 'docread', 'agent', 'assist', 'viewplan', 'plan', 'brief', 'decide', 'packs', 'trips', 'checks', 'unlock'])
  vm.runInContext(fs.readFileSync(n === 'engine' && arg('engine') ? arg('engine') : K + n + '.js', 'utf8'), c, { filename: n + '.js' });
const E = vm.runInContext('KoshEngine', c);
let n = 0; const id = () => 'x' + (++n).toString(16).padStart(15, '0');
const parse = (m) => JSON.parse(E.parseJSON(JSON.stringify(Object.assign({ id: id(), subject: '', html: '' }, m))));
const sms = parse({ from: 'JM-HDFCBK-S', date: '2026-11-02T08:41:00Z', chan: 'sms',
  text: 'Sent Rs.1250.00\nFrom HDFC Bank A/C *6150\nTo BLUE TOKAI COFFEE\nOn 02/11/26\nRef 612345678921\nNot You?\nCall 18002586161/SMS BLOCK UPI to 7308080808' });
const mail = parse({ from: 'HDFC Bank InstaAlerts <alerts@hdfcbank.bank.in>', date: '2026-11-02T08:42:30Z', subject: 'You have done a UPI txn. Check details!',
  text: 'Dear Customer, Rs.1250.00 has been debited from account 6150 to VPA bluetokai.store@okaxis BLUE TOKAI COFFEE ROASTERS on 02-11-26. Your UPI transaction reference number is 612345678921. If you did not authorize this transaction, please report it immediately.' });
const shop = parse({ from: 'Blue Tokai <orders@bluetokaicoffee.com>', date: '2026-11-02T08:43:00Z', subject: 'Your Blue Tokai order #BT10293 is confirmed',
  text: 'Hi, thanks for your order #BT10293. Items: Attikan Estate Coffee 250g x 2 Rs.1,100.00; Delivery Rs.150.00. Order total Rs.1,250.00. Paid via UPI.' });
const stmts = [{ src: 'doc:st1', from: 'hdfcbanksmartstatement@hdfcbank.bank.in', instr: 'account', last4: '6150', sent: '2026-12-02', owner: 'me',
  periodFrom: '2026-11-01', periodTo: '2026-11-30', open: 10000, close: 8750, closeDate: '2026-11-30', ok: true,
  rows: [{ date: '2026-11-02', desc: 'UPI-BLUE TOKAI COFFEE R-bluetokai.store@okaxis-UTIB0000114-612345678921-UPI', amt: 1250, dir: 'out', chk: true }] }];
const build = (recs, st, today) => JSON.parse(E.buildJSON(JSON.stringify(recs), JSON.stringify({ name: 'Test Person', today, statements: st })));
let bad = 0;
const check = (name, ok, got) => { if (!ok) bad++; console.log((ok ? 'ok    ' : 'FAIL  ') + name + (got !== undefined ? '  (' + got + ')' : '')); };
for (const [label, recs, st] of [['sms + mail', [sms, mail], []], ['sms + mail + receipt', [sms, mail, shop], []], ['all four', [sms, mail, shop], stmts], ['statement first, then sms', [sms], stmts]]) {
  const s = build(recs, st, '2026-12-03');
  const rows = (s.tx || []).filter((t) => Math.abs(t.a - 1250) < 0.01 && !t.partOf && !t.mr);
  check(label + ': one row', rows.length === 1, rows.length + ' rows');
  const t = rows[0] || {};
  if (recs.length > 1) check(label + ': kept the UPI ID from the mail', /bluetokai/i.test(t.vpa || ''), t.vpa);
  check(label + ': on HDFC ••6150', /6150/.test(t.card || ''), t.card);
  if (recs.length > 1 && recs[0] === sms) check(label + ': kept the time from the SMS', t.t === '14:11', t.t);
  if (recs.length > 1) check(label + ': remembers every source', [sms.id, mail.id].concat(recs.indexOf(shop) >= 0 ? [shop.id] : []).every((x) => x === t.id || (t.told || []).indexOf(x) >= 0 || t.rc === x), JSON.stringify([t.id].concat(t.told || [])));
  if (st.length && recs.length > 1) check(label + ': names the statement that confirmed it', (t.sm || []).indexOf('st1') >= 0, JSON.stringify(t.sm));
  const a = (s.accounts || []).find((x) => x.bank === 'HDFC');
  if (st.length) check(label + ': balance moved once', a && Math.abs(a.balance - 8750) < 0.5, a && a.balance);
}
if (process.argv.includes('--peek')) { const s = build([sms, mail, shop], stmts, '2026-12-03'); console.log(JSON.stringify((s.tx || []).filter((t) => Math.abs(t.a - 1250) < 0.01), null, 1)); }
console.log(bad ? bad + ' failed' : 'all passed'); process.exit(bad ? 1 : 0);
