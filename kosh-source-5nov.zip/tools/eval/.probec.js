const fs=require('fs'),vm=require('vm'),path=require('path');const K=path.join(__dirname,'..','..','Kosh')+'/';const c=vm.createContext({console});
vm.runInContext('var KoshDirectory = '+fs.readFileSync(K+'directory.json','utf8')+';',c);
for(const n of ['engine','mailwire','knowledge','reader','journey','docread','agent','assist','viewplan','plan','brief','decide','packs','trips','checks','unlock'])vm.runInContext(fs.readFileSync(K+n+'.js','utf8'),c,{filename:n+'.js'});
const E=vm.runInContext('KoshEngine',c);
const txt=fs.readFileSync(process.argv[2],'utf8').replace(/[ \t]{3,}/g,'   ').replace(/\f/g,'\n');
const o=JSON.parse(E.parseDocJSON(txt,process.env.KIND||'contract','','','',''));
(o.trades||[]).forEach(t=>console.log(JSON.stringify(t)));console.log(o.charges,o.net,JSON.stringify(o.check));
