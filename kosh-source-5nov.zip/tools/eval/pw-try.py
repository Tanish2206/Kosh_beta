#!/usr/bin/env python3
"""Open locked statements from the household's details, the way any bank writes its rule (name letters, date of birth
in its formats, PAN, customer IDs, account and card digits, and their pairings). Private: reads
_corpus/stmts/details.json, writes _corpus/stmts/found-passwords.json (file -> password, and sender -> the pattern
that worked, so the next statement from that sender is tried with it first). Never prints a password.
python3 tools/eval/pw-try.py <folder of PDFs>"""
import sys, os, json, glob, itertools, datetime, pikepdf, collections
D = sys.argv[1]
root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
det = json.load(open(os.path.join(root, '_corpus/stmts/details.json')))
outp = os.path.join(root, '_corpus/stmts/found-passwords.json')
found = json.load(open(outp)) if os.path.exists(outp) else {'files': {}, 'senders': {}}
man = {r['file']: r for r in json.load(open(os.path.join(D, 'kgm__manifest.json')))}
MON = ['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']
def dob_forms(iso):
    d = datetime.date.fromisoformat(iso); dd, mm, yy, yyyy = f'{d.day:02d}', f'{d.month:02d}', f'{d.year%100:02d}', f'{d.year}'
    return {'DDMM': dd+mm, 'DDMMYY': dd+mm+yy, 'DDMMYYYY': dd+mm+yyyy, 'YYYY': yyyy, 'MMDD': mm+dd, 'YYYYMMDD': yyyy+mm+dd,
            'DDMONYYYY': dd+MON[d.month-1]+yyyy, 'DDMON': dd+MON[d.month-1], 'YYMMDD': yy+mm+dd, 'DD-MM-YYYY': f'{dd}-{mm}-{yyyy}'}
def name_forms(n):
    first = n.split()[0]; last = n.split()[-1]
    out = {}
    for tag, s in (('F4', first[:4]), ('L4', last[:4]), ('F', first)):
        out[tag+'u'] = s.upper(); out[tag+'l'] = s.lower(); out[tag+'t'] = s.title()
    return out
def digits_tails(s, ns=(4, 5, 6)):
    d = ''.join(c for c in s if c.isdigit()); return {f'L{n}': d[-n:] for n in ns if len(d) >= n}
cands = []   # (pattern, password)
for p in det['people']:
    for n in p['names']:
        nf = name_forms(n)
        for iso in p['dobs']:
            df = dob_forms(iso)
            for a, x in nf.items():
                for b, y in df.items(): cands.append((p['who']+':'+a+'+'+b, x+y)); cands.append((p['who']+':'+b+'+'+a, y+x))
            for b, y in df.items(): cands.append((p['who']+':'+b, y))
            for pan in p.get('pan', []):
                cands += [(p['who']+':PAN', pan), (p['who']+':pan', pan.lower()), (p['who']+':PAN+DDMMYYYY', pan+df['DDMMYYYY']), (p['who']+':pan+DDMMYYYY', pan.lower()+df['DDMMYYYY']),
                          (p['who']+':DDMMYYYY+PAN', df['DDMMYYYY']+pan), (p['who']+':PAN4+DDMM', pan[:4]+df['DDMM']), (p['who']+':pan4+DDMM', pan[:4].lower()+df['DDMM'])]
            for idv in det['ids'] + det['accounts']:
                dig = ''.join(c for c in idv if c.isdigit())
                cands += [('id', idv), ('id:'+'DDMMYY+'+'mid6', df['DDMMYY']+dig[3:9]), ('id+DDMM', dig+df['DDMM']), ('DDMM+id', df['DDMM']+dig),
                          ('id+DDMMYY', dig+df['DDMMYY']), ('DDMMYY+id', df['DDMMYY']+dig), ('DDMMYY+L6id', df['DDMMYY']+dig[-6:]), ('F4+L4id', nf['F4u']+dig[-4:]), ('f4+L4id', nf['F4l']+dig[-4:])]
                for t, v in digits_tails(idv).items(): cands += [('acct'+t, v), ('DDMM+acct'+t, df['DDMM']+v), ('acct'+t+'+DDMM', v+df['DDMM'])]
            for c in det['cards']:
                cands += [('card+DDMM', c+df['DDMM']), ('DDMM+card', df['DDMM']+c), ('DDMMYY+card', df['DDMMYY']+c), ('F4+card', nf['F4u']+c), ('f4+card', nf['F4l']+c), ('card', c), ('DDMMYYYY+card', df['DDMMYYYY']+c), ('card+DDMMYYYY', c+df['DDMMYYYY']), ('card+DDMMYY', c+df['DDMMYY'])]
for mo in det.get('mobiles', []):
    for p in det['people']:
        for iso in p['dobs']:
            df = dob_forms(iso)
            for n in (4, 5, 6, 10):
                cands += [('mob'+str(n), mo[-n:]), ('DDMMYY+mob'+str(n), df['DDMMYY']+mo[-n:]), ('DDMM+mob'+str(n), df['DDMM']+mo[-n:]), ('mob'+str(n)+'+DDMM', mo[-n:]+df['DDMM']), ('DDMMYYYY+mob'+str(n), df['DDMMYYYY']+mo[-n:]), ('mob'+str(n)+'+DDMMYY', mo[-n:]+df['DDMMYY']), ('mob'+str(n)+'+DDMMYYYY', mo[-n:]+df['DDMMYYYY'])]
cands = list(dict.fromkeys(cands))
pwset = list(dict.fromkeys(p for _, p in cands))
patof = {}
for pat, pw in cands: patof.setdefault(pw, pat)
def opens(path, pw):
    try: pikepdf.open(path, password=pw).close(); return True
    except pikepdf.PasswordError: return False
    except Exception: return None
stats = collections.Counter()
failed = collections.Counter()
files = sorted(glob.glob(os.path.join(D, '*.pdf')))
def work(args):
    f, first = args
    import pypdf, logging; logging.getLogger('pypdf').setLevel(logging.ERROR)
    try:
        rd = pypdf.PdfReader(f)
        if not rd.is_encrypted: return f, 'open', None
        for pw in dict.fromkeys(list(first) + pwset):
            try:
                if rd.decrypt(pw) != pypdf.PasswordType.NOT_DECRYPTED: return f, 'ok', pw
            except Exception: continue
        return f, 'locked', None
    except Exception as e: return f, 'err', None
todo = []
for f in files:
    base = os.path.basename(f)
    if base in found['files'] or found.setdefault('tried', {}).get(base) == len(pwset): continue
    if not man.get(base, {}).get('enc'): continue
    dom = (man.get(base, {}).get('from') or '').split('@')[-1].lower()
    todo.append((f, found['senders'].get(dom, [])))
# a sender's first statement first: once it opens, its others open with the first try
seen = set(); front = []; back = []
for t in todo:
    dom = (man[os.path.basename(t[0])].get('from') or '').split('@')[-1].lower()
    (back if dom in seen else front).append(t); seen.add(dom)
import multiprocessing as mp, time
t0 = time.time()
with mp.Pool(4) as pool:
    for batch in (front, back):
        if batch is back:
            back = [(f, found['senders'].get((man[os.path.basename(f)].get('from') or '').split('@')[-1].lower(), [])) for f, _ in back]; batch = back
        for f, st, pw in pool.imap_unordered(work, batch):
            base = os.path.basename(f); dom = (man.get(base, {}).get('from') or '').split('@')[-1].lower()
            if st == 'ok':
                found['files'][base] = pw; s_ = found['senders'].setdefault(dom, [])
                if pw not in s_: s_.insert(0, pw)
            elif st == 'locked': found['tried'][base] = len(pwset)
            stats[st] += 1
            json.dump(found, open(outp, 'w'))
            if time.time() - t0 > 160: break
        if time.time() - t0 > 160: break
json.dump(found, open(outp, 'w'))
pats = collections.Counter(patof.get(p, '?').split(':')[-1] + ' @' + d for d, ps in found['senders'].items() for p in ps)
print(dict(stats)); print('candidates per file:', len(pwset))
for k, v in pats.most_common(40): print(' ', k)
