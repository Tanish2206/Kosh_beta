const fs=require('fs'),vm=require('vm'),path=require('path');const K=path.join(__dirname,'..','..','Kosh')+'/';const c=vm.createContext({console});
vm.runInContext('var KoshDirectory = '+fs.readFileSync(K+'directory.json','utf8')+';',c);
for(const n of ['engine','docread'])vm.runInContext(fs.readFileSync(K+n+'.js','utf8'),c,{filename:n+'.js'});
const E=vm.runInContext('KoshEngine',c);let t=fs.readFileSync(process.argv[2],'utf8');
if(process.env.MODE==='c')t=t.replace(/[ \t]{3,}/g,'   ');if(process.env.MODE==='s')t=t.replace(/[ \t]+/g,' ');
const o=JSON.parse(E.parseDocJSON(t,process.argv[3]||'stmt',process.argv[4]||'','','',''));
const keep=['kind','instr','last4','from','to','opening','closing','close','closeDate','check','parts','status'];const x={};keep.forEach(k=>{if(o[k]!==undefined)x[k]=o[k]});console.log(JSON.stringify(x).slice(0,700));
