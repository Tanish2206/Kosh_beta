/* What kosh's mail missed, statement by statement: every bank account statement's lines (the bank's own record) set
   against the payments kosh had for that account from mail alone (no statements given), matched by direction, amount
   (within ₹1) and day (within 3). Unmatched statement lines are payments the balance would have missed before the
   statement arrived; unmatched mail payments are ones kosh filed to the account that the bank never booked there.
   node tools/eval/live-diff.js [--acct=HDFC|6150] [--show=20]   Counts by account and kind; examples only with --show. */
'use strict';
const fs = require('fs'), vm = require('vm'), path = require('path');
const arg = (k, d) => { const a = process.argv.find((x) => x.startsWith('--' + k + '=')); return a ? a.slice(k.length + 3) : d; };
const ROOT = path.join(__dirname, '..', '..'), K = path.join(ROOT, 'Kosh') + '/';
const c = vm.createContext({ console });
vm.runInContext('var KoshDirectory = ' + fs.readFileSync(K + 'directory.json', 'utf8') + ';', c);
for (const n of ['engine', 'mailwire', 'knowledge', 'reader', 'journey', 'docread', 'agent', 'assist', 'viewplan', 'plan', 'brief', 'decide', 'packs', 'trips', 'checks', 'unlock'])
  vm.runInContext(fs.readFileSync(K + n + '.js', 'utf8'), c, { filename: n + '.js' });
const E = vm.runInContext('KoshEngine', c);
const day = (s) => { const d = new Date(String(s || '').replace(' at ', ' ')); return isNaN(d) ? '' : d.toISOString().slice(0, 10); };
const short = (from) => { const i = E.institution ? E.institution(from || '') : null; return i ? i.short : ''; };
const mails = JSON.parse(fs.readFileSync(path.join(ROOT, arg('mails', '_corpus/2026-10-18-full/all.json')), 'utf8'));
const recs = mails.map((m) => JSON.parse(E.parseJSON(JSON.stringify(m))));
const mailFrom = mails.map((m) => day(m.date)).sort()[0], mailTo = mails.map((m) => day(m.date)).sort().pop();
const snap = JSON.parse(E.buildJSON(JSON.stringify(recs), JSON.stringify({ name: 'Mridul Bhutani', today: mailTo })));
if (arg('peek')) { console.log(JSON.stringify((snap.accounts||[]).map(a=>[a.id,a.bank,a.last])).slice(0,600)); console.log(JSON.stringify((snap.tx||[]).slice(0,2))); process.exit(0); }
const acctOf = {}; (snap.accounts || []).forEach((a) => { acctOf[a.id] = a.bank + '|' + String(a.last || '').slice(-4); });
const flows = {};
(snap.tx || []).forEach((t) => {
  const dr = t.dr || t.dirRaw, k = acctOf[t.card]; if (!k || t.partOf || !(dr === 'in' || dr === 'out')) return;
  (flows[k] = flows[k] || []).push({ d: t.od || t.d, dir: dr, amt: t.full !== undefined ? t.full : t.a, n: String(t.m || '').slice(0, 30), c: t.c || '', used: false });
});
const SD = path.join(ROOT, '_corpus/stmts/gmail/files');
const T = fs.readFileSync(path.join(SD, 'truth.jsonl'), 'utf8').trim().split('\n').map(JSON.parse);
const out = {}, ex = {}, show = +arg('show', '0'), only = arg('acct');
const dd = (a, b) => Math.abs((Date.parse(a) - Date.parse(b)) / 864e5);
for (const t of T) {
  if (t.kind !== 'stmt' || !fs.existsSync(path.join(SD, t.file + '.txt'))) continue;
  const g = path.join(SD, t.file + '.grid');
  let o; try { o = JSON.parse(E.parseDocJSON(fs.readFileSync(path.join(SD, t.file + '.txt'), 'utf8').replace(/[ \t]{3,}/g, '   ').replace(/\f/g, '\n'), 'stmt', t.from, t.orig || '', fs.existsSync(g) ? fs.readFileSync(g, 'utf8') : '', day(t.date))); } catch (e) { continue; }
  if ((o.instr || 'account') !== 'account') continue;
  const parts = (o.parts && o.parts.length) ? o.parts : [{ rows: o.rows || [], last4: o.last4, from: o.from, to: o.to, check: o.check }];
  for (const p of parts) {
    const k = short(t.from) + '|' + String(p.last4 || '').replace(/\D/g, '').slice(-4);
    if (only && k !== only) continue;
    if (!p.from || !p.to || p.from < mailFrom || p.to > mailTo || (p.check || {}).ok !== true) continue;
    const F = flows[k] || [], s = out[k] || (out[k] = { stmts: 0, lines: 0, matched: 0, missed: 0, missedRs: 0, extra: 0, extraRs: 0 });
    s.stmts++;
    (p.rows || []).forEach((r) => {
      s.lines++;
      const m = F.filter((f) => !f.used && f.dir === r.dir && Math.abs(f.amt - r.amt) <= 1 && dd(f.d, r.date) <= 3).sort((x, y) => dd(x.d, r.date) - dd(y.d, r.date))[0];
      if (m) { m.used = true; s.matched++; return; }
      s.missed++; s.missedRs += r.dir === 'in' ? r.amt : -r.amt;
      (ex[k] = ex[k] || []).push('MISSED ' + r.date + ' ' + r.dir + ' ' + r.amt + ' ' + String(r.desc).slice(0, 55));
    });
    F.filter((f) => !f.used && f.d >= p.from && f.d <= p.to).forEach((f) => {
      f.used = true; s.extra++; s.extraRs += f.dir === 'in' ? f.amt : -f.amt;
      (ex[k] = ex[k] || []).push('EXTRA  ' + f.d + ' ' + f.dir + ' ' + f.amt + ' ' + f.n + ' [' + f.c + ']');
    });
  }
}
console.log('account'.padEnd(16) + 'stmts lines matched missed  missed ₹net   extra  extra ₹net');
Object.keys(out).sort().forEach((k) => { const s = out[k];
  console.log(k.padEnd(16) + String(s.stmts).padStart(5) + String(s.lines).padStart(6) + String(s.matched).padStart(8) + String(s.missed).padStart(7) + String(Math.round(s.missedRs)).padStart(13) + String(s.extra).padStart(7) + String(Math.round(s.extraRs)).padStart(12));
  if (show) (ex[k] || []).slice(0, show).forEach((x) => console.log('   ' + x)); });
