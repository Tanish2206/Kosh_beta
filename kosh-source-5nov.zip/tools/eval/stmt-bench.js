/* Statement bench: every opened statement from the Gmail corpus read by kosh's own engine (parseDoc), scored by the
   paper's own arithmetic. node tools/eval/stmt-bench.js _corpus/stmts/gmail/files [--show=domain]
   Text is pdftotext -layout (close to the phone's row reading; the phone's grid reading is not reproduced here). */
'use strict';
const fs = require('fs'), vm = require('vm'), path = require('path');
const K = path.join(__dirname, '..', '..', 'Kosh') + '/';
const c = vm.createContext({ console });
vm.runInContext('var KoshDirectory = ' + fs.readFileSync(K + 'directory.json', 'utf8') + ';', c);
for (const n of ['engine', 'mailwire', 'knowledge', 'reader', 'journey', 'docread', 'agent', 'assist', 'viewplan', 'plan', 'brief', 'decide', 'packs', 'trips', 'checks', 'unlock'])
  vm.runInContext(fs.readFileSync(K + n + '.js', 'utf8'), c, { filename: n + '.js' });
const E = vm.runInContext('KoshEngine', c);
const D = process.argv[2], show = (process.argv.find((a) => a.startsWith('--show=')) || '').slice(7);
const T = fs.readFileSync(path.join(D, 'truth.jsonl'), 'utf8').trim().split('\n').map(JSON.parse);
const by = {}, out = [];
for (const r of T) {
  if (!/^(stmt|cardstmt)$/.test(r.kind || '') || !fs.existsSync(path.join(D, r.file + '.txt'))) continue;
  // --phone: as the phone reads it, the plain text and the words with where they sit (tools/eval/mkgrids.py)
  const PH = process.argv.includes('--phone'), gp = path.join(D, r.file + '.grid');
  if (PH && !fs.existsSync(gp)) continue;
  const txt = PH ? fs.readFileSync(path.join(D, r.file + '.plain.txt'), 'utf8').replace(/\f/g, '\n') : fs.readFileSync(path.join(D, r.file + '.txt'), 'utf8').replace(/[ \t]{3,}/g, '   ').replace(/\f/g, '\n');
  const grid = PH ? fs.readFileSync(gp, 'utf8') : '';
  const sent = (() => { const d = new Date(r.date); return isNaN(d) ? '' : d.toISOString().slice(0, 10); })();
  let o; try { o = JSON.parse(E.parseDocJSON(txt, r.kind, r.from, r.orig || '', grid, sent)); } catch (e) { o = { err: String(e).slice(0, 80) }; }
  // --phone: the phone reads both its texts (the rows rebuilt from where letters sit, and PDFKit's own) and keeps the
  // one that checks out (LiveSession+Statements score): the layout text stands in for the rebuilt rows
  if (PH) {
    try {
      const lay = fs.readFileSync(path.join(D, r.file + '.txt'), 'utf8').replace(/[ \t]{3,}/g, '   ').replace(/\f/g, '\n');
      const o2 = JSON.parse(E.parseDocJSON(lay, r.kind, r.from, r.orig || '', grid, sent));
      const sc = (x) => { const c = x.check || {}; return (c.ok === true ? 3e12 : c.ok === null || c.ok === undefined ? 1e12 : 0) + (x.rows || []).length; };
      if (sc(o2) > sc(o)) o = o2;
    } catch (e) { /* the plain reading stands */ }
  }
  const ck = o.check || {};
  const res = { file: r.file, from: r.from, kind: r.kind, sent, rows: (o.rows || []).length, last4: o.last4 || '', from_: o.from || '', to: o.to || '',
    opening: o.opening, closing: o.closing, ok: ck.ok, note: (ck.note || o.err || '').slice(0, 110), kosh: r.kosh ? r.kosh.note : null };
  out.push(res);
  const dom = String(r.from).split('@').pop().toLowerCase(), k = dom + ' ' + r.kind;
  const x = by[k] || (by[k] = { n: 0, ok: 0, bad: 0, none: 0, zero: 0, l4: 0 });
  x.n++; if (ck.ok === true) x.ok++; else if (ck.ok === false) x.bad++; else x.none++;
  if (!res.rows) x.zero++; if (res.last4) x.l4++;
  if (show && dom.indexOf(show) >= 0) console.log(res.sent, res.kind, 'rows', res.rows, 'l4', res.last4, res.from_, '→', res.to, 'ok', res.ok, '|', res.note);
}
fs.writeFileSync(path.join(D, 'bench.json'), JSON.stringify(out, null, 1));
let t = { n: 0, ok: 0, bad: 0, none: 0, zero: 0 };
console.log('sender kind'.padEnd(36) + ' n  adds-up  wrong  unchecked  0-rows  digits');
Object.keys(by).sort((a, b) => by[b].n - by[a].n).forEach((k) => { const x = by[k]; ['n', 'ok', 'bad', 'none', 'zero'].forEach((f) => (t[f] += x[f]));
  console.log(k.padEnd(36) + String(x.n).padStart(3) + String(x.ok).padStart(8) + String(x.bad).padStart(7) + String(x.none).padStart(10) + String(x.zero).padStart(8) + String(x.l4).padStart(8)); });
console.log('TOTAL'.padEnd(36) + String(t.n).padStart(3) + String(t.ok).padStart(8) + String(t.bad).padStart(7) + String(t.none).padStart(10) + String(t.zero).padStart(8));

// --ratchet: no sender's "adds up" count may fall below the last accepted run (_corpus/stmts/bench-ratchet.json)
if (process.argv.includes('--ratchet')) {
  const rp = path.join(__dirname, '..', '..', '_corpus', 'stmts', process.argv.includes('--phone') ? 'bench-phone-ratchet.json' : 'bench-ratchet.json');
  const now = {}; Object.keys(by).forEach((k) => (now[k] = by[k].ok));
  const was = fs.existsSync(rp) ? JSON.parse(fs.readFileSync(rp, 'utf8')) : {};
  const drops = Object.keys(was).filter((k) => (now[k] || 0) < was[k]);
  if (drops.length) { console.log('BENCH RATCHET FAILED: ' + drops.map((k) => k + ' ' + was[k] + '→' + (now[k] || 0)).join(', ')); process.exit(1); }
  Object.keys(now).forEach((k) => (was[k] = Math.max(was[k] || 0, now[k])));
  fs.writeFileSync(rp, JSON.stringify(was, null, 1));
  console.log('bench ratchet ok: ' + Object.values(now).reduce((a, b) => a + b, 0) + ' statements add up');
}
