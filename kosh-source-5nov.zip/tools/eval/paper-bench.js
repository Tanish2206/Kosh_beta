/* Paper bench: holdings statements (CAS, demat, broker) and policy papers from the Gmail corpus, read by kosh's own
   engine and scored by their own figures. node tools/eval/paper-bench.js _corpus/stmts/gmail/files [--show=domain] [--ratchet] */
'use strict';
const fs = require('fs'), vm = require('vm'), path = require('path');
const K = path.join(__dirname, '..', '..', 'Kosh') + '/';
const c = vm.createContext({ console });
vm.runInContext('var KoshDirectory = ' + fs.readFileSync(K + 'directory.json', 'utf8') + ';', c);
for (const n of ['engine', 'mailwire', 'knowledge', 'reader', 'journey', 'docread', 'agent', 'assist', 'viewplan', 'plan', 'brief', 'decide', 'packs', 'trips', 'checks', 'unlock'])
  vm.runInContext(fs.readFileSync(K + n + '.js', 'utf8'), c, { filename: n + '.js' });
const E = vm.runInContext('KoshEngine', c);
const D = process.argv[2], show = (process.argv.find((a) => a.startsWith('--show=')) || '').slice(7);
const T = fs.readFileSync(path.join(D, 'truth.jsonl'), 'utf8').trim().split('\n').map(JSON.parse);
const by = {};
for (const r of T) {
  if (!/^(cas|demat|funds|insurance|contract|tax)$/.test(r.kind || '') || !fs.existsSync(path.join(D, r.file + '.txt'))) continue;
  const txt = fs.readFileSync(path.join(D, r.file + '.txt'), 'utf8').replace(/[ \t]{3,}/g, '   ').replace(/\f/g, '\n');
  const sent = (() => { const d = new Date(r.date); return isNaN(d) ? '' : d.toISOString().slice(0, 10); })();
  const kind = r.kind === 'insurance' ? 'policy' : /^(?:demat|funds)$/.test(r.kind) ? 'cas' : r.kind === 'tax' ? 'unknown' : r.kind;
  let o; try { o = JSON.parse(E.parseDocJSON(txt, kind, r.from, r.orig || '', '', sent)); } catch (e) { o = { err: String(e).slice(0, 80) }; }
  const h = o.holdings || [], p = o.policies || [], t = o.total || {}, ck = o.check || {};
  const ok = kind === 'cas' && o.paper ? true : kind === 'cas' ? (t.reconciled === true ? true : t.trusted === false ? false : null) : kind === 'policy' ? (p.length ? (p.every((x) => x.policyNo) ? true : null) : (o.role && !/^(?:policy|schedule|renewal|receipt)$/.test(o.role) ? true : null)) : (ck.ok === undefined ? null : ck.ok);
  const read = kind === 'cas' && o.paper ? 1 : kind === 'cas' ? h.length : kind === 'policy' ? p.length : (o.trades || o.facts || []).length;
  const k = String(r.from).split('@').pop().toLowerCase() + ' ' + kind;
  const x = by[k] || (by[k] = { n: 0, ok: 0, bad: 0, none: 0, zero: 0, cost: 0 });
  x.n++; if (ok === true) x.ok++; else if (ok === false) x.bad++; else x.none++; if (!read) x.zero++;
  if (h.some((y) => y.cost > 0)) x.cost++;
  if (show && k.indexOf(show) >= 0) console.log(sent, kind, 'read', read, 'ok', ok, kind === 'cas' ? (o.paper ? o.paper + ' ' + JSON.stringify(o.funds || {}) : JSON.stringify(t).slice(0, 120)) : (o.role || '') + ' ' + JSON.stringify(p.map((y) => [y.insurer, y.policyNo, y.premium, y.cover])).slice(0, 160), '|', (o.err || ck.note || '').slice(0, 80));
}
console.log('sender kind'.padEnd(40) + '  n  ok  wrong  unchecked  0-read  with-cost');
let tot = { n: 0, ok: 0 };
Object.keys(by).sort((a, b) => by[b].n - by[a].n).forEach((k) => { const x = by[k]; tot.n += x.n; tot.ok += x.ok;
  console.log(k.padEnd(40) + String(x.n).padStart(3) + String(x.ok).padStart(4) + String(x.bad).padStart(7) + String(x.none).padStart(11) + String(x.zero).padStart(8) + String(x.cost).padStart(11)); });
console.log('TOTAL ' + tot.ok + ' of ' + tot.n + ' check out');
if (process.argv.includes('--ratchet')) {
  const rp = path.join(__dirname, '..', '..', '_corpus', 'stmts', 'paper-ratchet.json');
  const now = {}; Object.keys(by).forEach((k) => (now[k] = by[k].ok));
  const was = fs.existsSync(rp) ? JSON.parse(fs.readFileSync(rp, 'utf8')) : {};
  const drops = Object.keys(was).filter((k) => (now[k] || 0) < was[k]);
  if (drops.length) { console.log('PAPER RATCHET FAILED: ' + drops.join(', ')); process.exit(1); }
  Object.keys(now).forEach((k) => (was[k] = Math.max(was[k] || 0, now[k]))); fs.writeFileSync(rp, JSON.stringify(was, null, 1));
  console.log('paper ratchet ok');
}
