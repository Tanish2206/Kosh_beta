const fs=require('fs'),vm=require('vm'),path=require('path');const K=require('path').join(__dirname,'..','..','Kosh')+'/';const c=vm.createContext({console});
vm.runInContext('var KoshDirectory = '+fs.readFileSync(K+'directory.json','utf8')+';',c);
for(const n of ['engine','mailwire','knowledge','reader','journey','docread','agent','assist','viewplan','plan','brief','decide','packs','trips','checks','unlock'])vm.runInContext(fs.readFileSync(K+n+'.js','utf8'),c,{filename:n+'.js'});
const E=vm.runInContext('KoshEngine',c);
const f=process.argv[2],kind=process.argv[3]||'cas',from=process.argv[4]||'';
const txt=fs.readFileSync(f,'utf8').replace(/[ \t]{3,}/g,'   ').replace(/\f/g,'\n');
const o=JSON.parse(E.parseDocJSON(txt,kind,from,'','',''));
console.log(o.kind,JSON.stringify(o.total),o.asOf,(o.holdings||[]).length);(o.holdings||[]).slice(0,40).forEach(h=>console.log(' ',h.isin,h.bank,h.units,h.price,h.amt,h.cost));
if(o.err||o.note)console.log(o.err,o.note);
