// moved: the scorer is reader/eval.js (the repo's own copy). Run: node reader/eval.js _corpus/<dir> --ratchet
console.error('moved to reader/eval.js'); process.exit(2);
