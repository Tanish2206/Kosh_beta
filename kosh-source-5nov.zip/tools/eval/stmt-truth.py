#!/usr/bin/env python3
"""Independent picture of every financial PDF in the inbox, built from Gmail itself (not from kosh's readings).
python3 tools/eval/stmt-truth.py <folder with kgm_*.pdf + kgm__manifest.json> [--diag=_scratch/diag/latest.json]
For each file: who sent it, whether it is locked and whether a known password opens it, what kind of paper it is
(bank statement, card statement, holdings statement, contract note, insurance, tax, other), the account/card digits
and period it prints, and the paper's own arithmetic (opening + credits - debits = closing; previous - payments +
spends = due). Then, by the Gmail message id, what kosh did with the same mail (found / opened / read / note).
Writes truth.jsonl and truth.md beside the files. Passwords: passwords.json (sender domain or file -> password, or
"*" -> [list]) and the phone export's manifest (_corpus/stmts/phone/manifest.json) when present."""
import sys, os, re, json, subprocess, glob, collections
D = sys.argv[1]
diagp = next((a.split('=',1)[1] for a in sys.argv if a.startswith('--diag=')), None)
root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
man = json.load(open(os.path.join(D, 'kgm__manifest.json')))
pw = {}
for p in [os.path.join(root, '_corpus/stmts/passwords.json')]:
    try: pw.update({k: v for k, v in json.load(open(p)).items() if not k.startswith('_') and not k.startswith('example')})
    except Exception: pass
phone = {}
try:
    for r in json.load(open(os.path.join(root, '_corpus/stmts/phone/manifest.json'))):
        if r.get('password'): phone.setdefault(r['from'].split('@')[-1].lower(), set()).add(r['password'])
except Exception: pass
allpw = set(v for v in pw.values() if isinstance(v, str)) | set(x for v in pw.values() if isinstance(v, list) for x in v) | set(x for s in phone.values() for x in s)
fpw = {}
try: fpw = json.load(open(os.path.join(root, '_corpus/stmts/found-passwords.json'))).get('files', {})
except Exception: pass
kosh = {}
if diagp:
    d = json.load(open(diagp))
    for x in d.get('statementDocs', []): kosh[x['id']] = x
AMT = r'(-?[\d,]+\.\d{2})'
def num(s):
    try: return float(s.replace(',', ''))
    except Exception: return None
def text_of(path, password=None):
    args = ['pdftotext', '-layout'] + (['-upw', password] if password else []) + [path, '-']
    r = subprocess.run(args, capture_output=True, timeout=60)
    if r.returncode != 0 and password:
        r = subprocess.run(['pdftotext', '-layout', '-opw', password, path, '-'], capture_output=True, timeout=60)
    return r.returncode, r.stdout.decode('utf-8', 'ignore'), r.stderr.decode('utf-8', 'ignore')
def kind_of(t, subj):
    T = t.lower(); s = (subj or '').lower()
    if re.search(r'most important terms|schedule of (?:fees|charges)|key fact statement', T[:4000]): return 'terms'
    if re.search(r'consolidated account statement|\bnsdl\b.*\bcas\b|cdsl.*consolidated|statement of holdings', T): return 'cas'
    if re.search(r'contract note', T[:3000]): return 'contract'
    if re.search(r'relationship statement|relationship summary|one glance', T[:3000]): return 'stmt'   # a bank's combined statement lists its cards too
    if re.search(r'credit card', T) and re.search(r'total (?:amount )?due|minimum (?:amount )?due|payment due date', T): return 'cardstmt'
    if re.search(r'statement of accounts? of (?:funds|securities)|retention statement|combined ledger view|funds balance and securities balance|end of day fund', T[:4000]): return 'funds'
    if re.search(r'policy schedule|sum (?:insured|assured)|premium (?:paid )?receipt|unit statement|certificate of insurance|policy (?:no|number)', T): return 'insurance'
    if re.search(r'opening balance|closing balance|statement of account|account statement|statement from', T[:1500]) and re.search(r'withdrawal|debit|\bdr\b', T[:2500]): return 'stmt'
    if re.search(r'form\s*16|tds certificate|26as|interest certificate|capital gains?|annual tax statement', T[:2500]): return 'tax'   # its head names it; a bank statement mentions these further down
    if re.search(r'opening balance|closing balance|statement of account|account statement', T) and re.search(r'withdrawal|debit|dr\b', T): return 'stmt'
    if re.search(r'demat|holding statement|transaction with holding', T): return 'demat'
    return 'other'
def figs(t, k):
    T = re.sub(r'[ \t]+', ' ', t)
    def f(pat):
        m = re.search(pat + r'[^\d\n-]{0,40}' + AMT, T, re.I)
        return num(m.group(1)) if m else None
    o = {}
    if k == 'stmt':
        o['opening'] = f(r'opening balance'); o['closing'] = f(r'closing balance')
        o['debits'] = f(r'total (?:debits?|withdrawals?)|debits? total|withdrawals? total'); o['credits'] = f(r'total (?:credits?|deposits?)|credits? total|deposits? total')
        if None not in (o['opening'], o['closing'], o['debits'], o['credits']): o['adds_up'] = abs(o['opening'] + o['credits'] - o['debits'] - o['closing']) < 1.01
    if k == 'cardstmt':
        o['previous'] = f(r'previous (?:statement )?balance|opening balance'); o['due'] = f(r'total (?:amount )?due|total dues')
        o['payments'] = f(r'payments?(?: and| &| /)? (?:other )?credits?|payments? received'); o['spends'] = f(r'purchases?(?: and| &| /)? (?:other )?(?:debits?|charges)|new (?:charges|debits)')
        if None not in (o['previous'], o['due'], o['payments'], o['spends']): o['adds_up'] = abs(o['previous'] - o['payments'] + o['spends'] - o['due']) < 1.01
    l4 = sorted(set(re.findall(r'(?:a/?c|account|card)(?: no\.?| number)?\s*[:#-]?\s*[x*•X]{2,}[\dx*•X-]*?(\d{4})\b', T, re.I)))
    o['digits'] = l4[:6]
    pm = re.search(r'(?:statement period|period|from)\s*[:\-]?\s*(\d{1,2}[-/ ][A-Za-z0-9]{2,9}[-/ ]\d{2,4})\s*(?:to|-)\s*(\d{1,2}[-/ ][A-Za-z0-9]{2,9}[-/ ]\d{2,4})', T, re.I)
    if pm: o['period'] = pm.group(1) + ' to ' + pm.group(2)
    return o
rows = []
for x in man:
    p = os.path.join(D, x['file'])
    r = {k: x.get(k) for k in ('mid', 'th', 'from', 'date', 'subj', 'orig', 'size', 'enc')}
    r['file'] = x['file']
    kx = kosh.get(x['mid']) or kosh.get(x['th'])
    r['kosh'] = {'state': kx.get('state'), 'kind': kx.get('kind'), 'note': (kx.get('note') or '')[:120]} if kx else None
    if not os.path.exists(p): r['state'] = 'missing-file'; rows.append(r); continue
    if not x['file'].lower().endswith('.pdf') and not open(p, 'rb').read(4).startswith(b'%PDF'):
        r['state'] = 'not-pdf'; rows.append(r); continue
    used = None
    if os.path.exists(p + '.txt'): rc, t, err = 0, open(p + '.txt').read(), ''
    else: rc, t, err = text_of(p)
    if rc != 0 and ('password' in err.lower() or 'encrypt' in err.lower()):
        dom = (x.get('from') or '').split('@')[-1].lower()
        tries = ([fpw[x['file']]] if x['file'] in fpw else []) + list(phone.get(dom, [])) + [v for k, v in pw.items() if isinstance(v, str) and (k in dom or k in x['file'])] + list(allpw)
        for cand in dict.fromkeys(tries):
            rc, t, err = text_of(p, cand)
            if rc == 0: used = cand; break
        if rc != 0: r['state'] = 'locked'; rows.append(r); continue
    if rc != 0: r['state'] = 'unreadable'; r['err'] = err[:120]; rows.append(r); continue
    r['state'] = 'opened' + (' (password)' if used else '')
    r['chars'] = len(t.strip())
    if r['chars'] < 50: r['state'] = 'opened-no-text (scan?)'
    k = kind_of(t, x.get('subj')); r['kind'] = k
    r.update(figs(t, k))
    with open(p + '.txt', 'w') as fh: fh.write(t)
    rows.append(r)
with open(os.path.join(D, 'truth.jsonl'), 'w') as fh:
    for r in rows: fh.write(json.dumps(r) + '\n')
by = collections.defaultdict(lambda: collections.Counter())
for r in rows:
    dom = (r.get('from') or '?').split('@')[-1].lower()
    c = by[(dom, r.get('kind') or r.get('state'))]
    c['files'] += 1; c[r['state'].split(' ')[0]] += 1
    if r.get('adds_up') is True: c['adds_up'] += 1
    if r.get('adds_up') is False: c['no_add'] += 1
    if r.get('kosh'): c['kosh_found'] += 1
    if r.get('kosh') and r['kosh'].get('state') == 'read': c['kosh_read'] += 1
    if r.get('kosh') and 'nothing kosh tracks' in (r['kosh'].get('note') or '').lower(): c['kosh_nothing'] += 1
L = ['| sender | kind | files | opened | locked | adds up | kosh found | kosh read | kosh "nothing" |', '|---|---|---|---|---|---|---|---|---|']
for (dom, k), c in sorted(by.items(), key=lambda kv: (-kv[1]['files'])):
    L.append(f"| {dom} | {k} | {c['files']} | {c['opened']} | {c['locked']} | {c['adds_up']}/{c['adds_up']+c['no_add']} | {c['kosh_found']} | {c['kosh_read']} | {c['kosh_nothing']} |")
open(os.path.join(D, 'truth.md'), 'w').write('\n'.join(L) + '\n')
print('\n'.join(L))
