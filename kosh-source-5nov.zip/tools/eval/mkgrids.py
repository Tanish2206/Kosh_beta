#!/usr/bin/env python3
"""For the phone-like bench: each statement in truth.jsonl as the phone reads it — its plain text (no layout) as
<file>.plain.txt and its words with where they sit as <file>.grid (tools/eval/pdfgrid.py). python3 tools/eval/mkgrids.py <dir>"""
import json, os, subprocess, sys
D = sys.argv[1]; here = os.path.dirname(os.path.abspath(__file__))
pw = json.load(open(os.path.join(D, '..', '..', 'found-passwords.json'))).get('files', {})
n = 0
for l in open(os.path.join(D, 'truth.jsonl')):
    r = json.loads(l)
    if r.get('kind') not in ('stmt', 'cardstmt'): continue
    f = os.path.join(D, r['file'])
    if not os.path.exists(f) or (os.path.exists(f + '.grid') and '--force' not in sys.argv): continue
    p = pw.get(r['file'], '')
    a = ['pdftotext'] + (['-upw', p] if p else []) + [f, f + '.plain.txt']
    if subprocess.run(a, capture_output=True).returncode and p: subprocess.run(['pdftotext', '-opw', p, f, f + '.plain.txt'], capture_output=True)
    g = subprocess.run(['python3', os.path.join(here, 'pdfgrid.py'), f, p], capture_output=True).stdout
    open(f + '.grid', 'wb').write(g); n += 1
print('made', n)
