/* The texts the phone itself kept (diagnostics' stmtTexts, dev builds), read as the phone reads them: each reading of
   the pages (split on \u001E) with the grid (after \u001F), the one that checks out kept. node tools/eval/phone-bench.js [file] */
'use strict';
const fs = require('fs'), vm = require('vm'), path = require('path');
const K = path.join(__dirname, '..', '..', 'Kosh') + '/';
const c = vm.createContext({ console });
vm.runInContext('var KoshDirectory = ' + fs.readFileSync(K + 'directory.json', 'utf8') + ';', c);
for (const n of ['engine', 'mailwire', 'knowledge', 'reader', 'journey', 'docread', 'agent', 'assist', 'viewplan', 'plan', 'brief', 'decide', 'packs', 'trips', 'checks', 'unlock'])
  vm.runInContext(fs.readFileSync(K + n + '.js', 'utf8'), c, { filename: n + '.js' });
const E = vm.runInContext('KoshEngine', c);
const F = process.argv[2] || path.join(__dirname, '..', '..', '_corpus', 'stmts', 'phone-texts', 'texts.json');
const T = JSON.parse(fs.readFileSync(F, 'utf8'));
const sc = (x) => { const k = x.check || {}; return (k.ok === true ? 3e12 : k.ok == null ? 1e12 : 0) + (x.rows || []).length; };
let ok = 0, bad = 0, none = 0;
for (const t of T) {
  const files = t.text.split('\n\u001D\n');
  let best = null;
  for (const file of files) {
    const gi = file.indexOf('\n\u001F\n'), body = gi >= 0 ? file.slice(0, gi) : file, grid = gi >= 0 ? file.slice(gi + 3) : '';
    for (const v of body.split('\n\u001E\n')) {
      let o; try { o = JSON.parse(E.parseDocJSON(v, t.kind, t.from, '', grid, t.sent)); } catch (e) { continue; }
      if (!best || sc(o) > sc(best)) best = o;
    }
  }
  const k = (best && best.check) || {};
  if (k.ok === true) ok++; else if (k.ok === false) bad++; else none++;
  const P = best && best.parts ? ' parts ' + best.parts.map((p) => p.last4 + ':' + p.close).join(',') : '';
  console.log((k.ok === true ? 'OK  ' : k.ok === false ? 'BAD ' : '--  ') + t.sent + ' ' + t.kind.padEnd(8) + ' ' + String(t.from).replace(/.*</, '').replace('>', '').slice(0, 34).padEnd(34) +
    ' l4 ' + (best && best.last4 || '').padEnd(4) + ' rows ' + String(best ? (best.rows || []).length : 0).padStart(3) + ' close ' + (best && best.close != null ? best.close : '-') + P + ' | ' + String(k.note || '').slice(0, 70));
}
console.log('phone texts: ' + ok + ' add up, ' + bad + ' wrong, ' + none + ' unchecked of ' + T.length);
