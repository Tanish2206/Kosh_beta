// swift-tools-version:5.9
// kosh's widget pictures: the widgets drawn at their real sizes in the iOS Simulator, by day and by night, as PNGs
// (tools/autobuild.sh › shots copies the widget sources in, then runs the one test that draws them)
import PackageDescription

let package = Package(
    name: "Shots",
    platforms: [.iOS(.v18)],
    targets: [
        .target(name: "ShotsKit", path: "Sources/ShotsKit"),
        .testTarget(name: "ShotsTests", dependencies: ["ShotsKit"], path: "Tests/ShotsTests"),
    ]
)
