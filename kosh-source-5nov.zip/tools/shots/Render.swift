import SwiftUI
import WidgetKit
import UIKit
import ActivityKit

// MARK: - kosh's widgets, drawn as pictures
//
// Copied in beside the widgets' own sources (tools/autobuild.sh › shots), where every "\.widgetFamily" is read as
// "\.shotFamily": a family set here, since a widget's own family is the system's to give. Each widget at each of its
// sizes, by day and by night, on a wallpaper of the mockups' colour, at 3x, from the made-up household (Sample.feed).

private struct ShotFamilyKey: EnvironmentKey {
    static let defaultValue: WidgetFamily = .systemSmall
}

extension EnvironmentValues {
    var shotFamily: WidgetFamily {
        get { self[ShotFamilyKey.self] }
        set { self[ShotFamilyKey.self] = newValue }
    }
}

@MainActor
enum Shots {
    /// the sizes on an iPhone 16 Pro's Home Screen and Lock Screen, in points
    static func size(_ f: WidgetFamily) -> CGSize {
        switch f {
        case .systemSmall: return CGSize(width: 170, height: 170)
        case .systemMedium: return CGSize(width: 364, height: 170)
        case .systemLarge: return CGSize(width: 364, height: 382)
        case .accessoryCircular: return CGSize(width: 76, height: 76)
        case .accessoryRectangular: return CGSize(width: 172, height: 76)
        case .accessoryInline: return CGSize(width: 260, height: 24)
        default: return CGSize(width: 170, height: 170)
        }
    }
    static func name(_ f: WidgetFamily) -> String {
        switch f {
        case .systemSmall: return "small"
        case .systemMedium: return "medium"
        case .systemLarge: return "large"
        case .accessoryCircular: return "circular"
        case .accessoryRectangular: return "rectangular"
        case .accessoryInline: return "inline"
        default: return "other"
        }
    }
    static func accessory(_ f: WidgetFamily) -> Bool {
        f == .accessoryCircular || f == .accessoryRectangular || f == .accessoryInline
    }

    static func renderAll(to dir: URL) throws -> Int {
        try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        let e: KEntry = KEntry(date: Date(), feed: Sample.feed, who: "family")
        let all: [(String, [WidgetFamily], (KEntry) -> AnyView)] = [
            ("Month", [.systemSmall, .systemMedium, .accessoryCircular, .accessoryRectangular, .accessoryInline], { AnyView(MonthView(entry: $0)) }),
            ("Due", [.systemSmall, .systemMedium, .systemLarge, .accessoryCircular, .accessoryRectangular, .accessoryInline], { AnyView(DueView(entry: $0)) }),
            ("Worth", [.systemSmall, .systemMedium, .systemLarge, .accessoryRectangular], { AnyView(WorthView(entry: $0)) }),
            ("Days", [.systemMedium, .systemLarge, .accessoryCircular], { AnyView(DaysView(entry: $0)) }),
            ("Cards", [.systemSmall, .systemMedium, .systemLarge], { AnyView(CardsView(entry: $0)) }),
            ("Banks", [.systemSmall, .systemMedium, .systemLarge, .accessoryRectangular], { AnyView(BanksView(entry: $0)) }),
            ("Latest", [.systemSmall, .systemMedium, .systemLarge, .accessoryRectangular], { AnyView(LatestView(entry: $0)) }),
            ("Split", [.systemSmall, .systemMedium], { AnyView(SplitView(entry: $0)) }),
            ("Noticed", [.systemSmall, .systemMedium], { AnyView(NoticedView(entry: $0)) }),
            ("Chapter", [.systemSmall, .systemMedium, .accessoryCircular, .accessoryRectangular], { AnyView(ChapterView(entry: $0)) }),
            ("Rent", [.systemSmall, .systemMedium, .accessoryCircular], { AnyView(RentView(entry: $0)) }),
            ("Add", [.systemSmall, .accessoryCircular], { AnyView(AddView(entry: $0)) }),
        ]
        var n: Int = 0
        for (title, families, make) in all {
            for f in families {
                for dark in [false, true] {
                    if accessory(f) && !dark { continue }
                    let url: URL = dir.appendingPathComponent(title + "-" + name(f) + "-" + (dark ? "night" : "day") + ".png")
                    if draw(make(e), family: f, dark: dark, to: url) { n += 1 }
                }
            }
        }
        // the reading bar on the Lock Screen
        let s = ReadingAttributes.ContentState(title: "Reading new mail", line: "Filling in the year", count: "412 of 1,240", done: 412, total: 1240,
                                               sym: "envelope", paused: false, finished: false, seeking: false,
                                               accentHex: "#3B5BFD", midHex: "#5AC8FA", skyHex: "#6E8BFF")
        let live: some View = RLLockScreen(s: s, stale: false)
            .frame(width: 370)
            .background(RLInk.ground, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
            .padding(20)
            .background(Color(hex: "#26292F"))
            .environment(\.colorScheme, .dark)
        if save(live, to: dir.appendingPathComponent("Live-lockscreen-night.png")) { n += 1 }
        return n
    }

    static func draw(_ v: AnyView, family f: WidgetFamily, dark: Bool, to url: URL) -> Bool {
        let sz: CGSize = size(f)
        let system: Bool = !accessory(f)
        let face: some View = v
            .environment(\.shotFamily, f)
            .padding(system ? 16 : 0)
            .frame(width: sz.width, height: sz.height)
            .background(system ? (dark ? Color(hex: "#1C1C1E") : Color.white) : Color.clear)
            .clipShape(RoundedRectangle(cornerRadius: system ? 24 : 0, style: .continuous))
            .padding(20)
            .background(dark ? Color(hex: "#26292F") : Color(hex: "#DCDFE5"))
            .environment(\.colorScheme, dark ? .dark : .light)
        return save(face, to: url)
    }

    static func save<V: View>(_ v: V, to url: URL) -> Bool {
        let r = ImageRenderer(content: v)
        r.scale = 3
        guard let img = r.uiImage, let png = img.pngData() else { return false }
        return (try? png.write(to: url)) != nil
    }
}
