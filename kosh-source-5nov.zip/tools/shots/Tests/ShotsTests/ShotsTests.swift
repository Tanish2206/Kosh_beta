import XCTest
@testable import ShotsKit

/// draws every kosh widget into the folder the auto-build names (SHOTS_DIR)
final class ShotsTests: XCTestCase {
    @MainActor
    func testDrawEveryWidget() throws {
        let dir: String = ProcessInfo.processInfo.environment["SHOTS_DIR"] ?? NSTemporaryDirectory()
        let n: Int = try Shots.renderAll(to: URL(fileURLWithPath: dir))
        XCTAssertGreaterThan(n, 0)
    }
}
