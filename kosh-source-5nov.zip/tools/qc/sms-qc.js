/* kosh SMS QC: every case in sms-cases.js through the three gates (the shortcut filter and the action check, both
   read out of Alerts.swift, then the engine). node tools/qc/sms-qc.js. Exit 1 on any failure. */
const fs=require('fs'),vm=require('vm');const K=__dirname+'/../../Kosh/';
const c=vm.createContext({console});
vm.runInContext('var KoshDirectory = '+fs.readFileSync(K+'directory.json','utf8')+';',c);
for(const n of ['engine','mailwire','knowledge','reader','journey','docread','agent','assist','viewplan','plan','brief','decide','packs','trips','checks','unlock']) vm.runInContext(fs.readFileSync(K+n+'.js','utf8'),c,{filename:n+'.js'});
const E=vm.runInContext('KoshEngine',c);
// gate 1 + 2 from Alerts.swift, as written
const sw=fs.readFileSync(K+'Alerts.swift','utf8');
const raw=n=>{const m=new RegExp('static let '+n+' = #"([\\s\\S]*?)"#').exec(sw);return m[1];};
const money=raw('money'),never=raw('never');
const filt=new RegExp('^(?!.*(?:'+never+')).*(?:'+money+').*$','si');
const mon=new RegExp('(?:'+money+')','i'),cod=new RegExp('(?:'+never+')','i');
const why=s=>cod.test(s)?'code':(!mon.test(s)||!/\d/.test(s))?'no-money':null;
const cases=require(__dirname+'/sms-cases.js');
let bad=0;
cases.forEach(([from,text,exp,note],i)=>{
  let got,detail='';
  if(!filt.test(text)) got='drop',detail='gate1';
  else if(why(text)) got='drop',detail='gate2:'+why(text);
  else { const r=JSON.parse(E.parseJSON(JSON.stringify({id:'sms-'+i,from,date:'2026-11-03T10:00:00Z',subject:'',text,html:'',chan:'sms'})));
    if(r.kind==='txn'||r.kind==='confirm'){got=r.dir;detail=`${r.rule} ₹${r.amt} ${r.inst||''}${r.last4?' ••'+r.last4:''} ${r.party||''} ${r.date} ${r.time||''}`;}
    else {got='drop';detail=r.rule;} }
  const ok=got===exp; if(!ok)bad++;
  console.log((ok?'ok  ':'FAIL')+' '+note.padEnd(28)+' want '+exp.padEnd(4)+' got '+got.padEnd(4)+' '+detail);
});
console.log('failures',bad,'of',cases.length);
process.exitCode = bad ? 1 : 0;
