/* kosh ledger QC: every mail of a corpus read and built into the snapshot the screens draw, then checked for money
   counted twice, own transfers counted as spend or income, refunds, odd amounts and dates, and what's uncategorised.
   node tools/qc/ledger-qc.js <mails.json> [--name="Your Name"] [--json=out.json]
   (--name: the owner, as the app's profile has it; without it own transfers can't be told from payments to people)
   Prints counts and a few examples (date, amount, payee): nothing else from the mail. Exit 1 when a hard check fails. */
'use strict';
const fs = require('fs'), vm = require('vm'), path = require('path');
const K = path.join(__dirname, '..', '..', 'Kosh') + '/';
const c = vm.createContext({ console });
vm.runInContext('var KoshDirectory = ' + fs.readFileSync(K + 'directory.json', 'utf8') + ';', c);
for (const n of ['engine', 'mailwire', 'knowledge', 'reader', 'journey', 'docread', 'agent', 'assist', 'viewplan', 'plan', 'brief', 'decide', 'packs', 'trips', 'checks', 'unlock'])
  vm.runInContext(fs.readFileSync(K + n + '.js', 'utf8'), c, { filename: n + '.js' });
const E = vm.runInContext('KoshEngine', c);
const mails = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
const recs = mails.map((m) => JSON.parse(E.parseJSON(JSON.stringify(m))));
const nm0 = (process.argv.find((a) => a.startsWith('--name=')) || '').slice(7);
const prof = nm0 ? { name: nm0, people: [{ id: 'me', name: nm0.split(' ')[0], full: nm0, rel: 'You', color: '#007AFF' }] } : {};
const snap = JSON.parse(E.buildJSON(JSON.stringify(recs), JSON.stringify(prof)));
// (a payment's mirror, the card's own "payment received" paired with the bank's debit (mr), is shown once: not counted)
const tx = (snap.tx || []).filter((t) => !t.mr);
const day = (d) => Date.parse(d + 'T00:00:00Z') / 864e5;
const ex = (t) => `${t.d} ₹${t.a} ${String(t.m).slice(0, 22)} (${t.k}/${t.c || '-'})`;
const R = [];
function check(name, hard, rows, show) { R.push({ name, hard, n: rows.length, ex: rows.slice(0, 6).map(show) }); }

// 1. the same card bill payment from both sides (the bank's debit or an app's receipt, and the card's "payment received")
const cp = tx.filter((t) => t.k === 'cardpay');
const cpDup = [];
cp.forEach((a, i) => cp.slice(i + 1).forEach((b) => { if (Math.abs(a.a - b.a) < 0.01 && Math.abs(day(a.d) - day(b.d)) <= 1) cpDup.push([a, b]); }));
check('card bill payment counted twice', true, cpDup, ([a, b]) => ex(a) + ' = ' + ex(b));

// 2. one alert counted twice (a bank's old and new domain, or the same alert resent): same amount, kind, day and time
const twin = [], nm = tx.filter((t) => t.k !== 'move');
nm.forEach((a, i) => nm.slice(i + 1).forEach((b) => { if (a.k === b.k && a.a === b.a && a.d === b.d && a.m === b.m && (!a.t || !b.t || a.t === b.t)) twin.push([a, b]); }));
check('same payment counted twice', true, twin, ([a, b]) => ex(a) + ' = ' + ex(b));

// 3. money between your own accounts left as spend and income (an out and an in of the same amount, same day or next)
const outs = tx.filter((t) => t.k === 'out'), ins = tx.filter((t) => t.k === 'in');
const own = [];
// (both sides name you: a same-amount pair between two other people is a coincidence, not a transfer)
const me = (nm0.split(' ')[0] || '\u0000').toLowerCase(), mine = (t) => String(t.m || '').toLowerCase().indexOf(me) >= 0;
outs.forEach((o) => { const i = ins.find((x) => Math.abs(x.a - o.a) < 0.01 && Math.abs(day(x.d) - day(o.d)) <= 1 && o.a >= 1000 && mine(o) && mine(x)); if (i) own.push([o, i]); });
check('own transfer counted as spend + income', true, own, ([o, i]) => ex(o) + ' / ' + ex(i));

// 4. refunds: more than one ledger line for one refund, and refunds kosh couldn't tie to a payment
const rf = tx.filter((t) => t.c === 'Refund'), rfDup = [];
rf.forEach((a, i) => rf.slice(i + 1).forEach((b) => { if (Math.abs(a.a - b.a) < 0.01 && Math.abs(day(a.d) - day(b.d)) <= 7 && a.m === b.m) rfDup.push([a, b]); }));
check('refund counted twice (same shop, amount, within a week)', false, rfDup, ([a, b]) => ex(a) + ' = ' + ex(b));
const waits = (snap.refunds || []).filter((r) => r.state === 'waiting' && day(r.by || r.d) < day(snap.today || '2026-10-18') - 14);
check('refund still waiting 2+ weeks past its date', false, waits, (r) => `${r.d} ₹${r.a} ${r.m} by ${r.by}`);

// 5. odd amounts and dates
check('zero or negative amount on a ledger line', false, tx.filter((t) => !(t.a > 0)), ex);
check('date after the newest mail', true, tx.filter((t) => t.d > (snap.today || '9999')), ex);
check('very large one-off spend (≥ ₹1,00,000, not a transfer/investment/card bill)', false,
  tx.filter((t) => t.k === 'out' && t.a >= 100000), ex);

// 6. uncategorised spend
const spend = tx.filter((t) => t.k === 'out'), unc = spend.filter((t) => !t.c || t.c === 'Other' || t.u);
const share = spend.length ? Math.round((unc.length / spend.length) * 100) : 0;
check(`uncategorised spend lines (${share}% of ${spend.length})`, false, unc, ex);

// 7. balance notices the rules call "not money" (Amex balance update, HSBC excess balance, SBI credit balance)
const balMiss = mails.filter((m, i) => recs[i].kind === 'noise' && /balance update|excess balance|credit balance/i.test(m.subject || ''));
check('balance notices read as not money', false, balMiss, (m) => `${String(m.date).slice(0, 10)} ${String(m.subject).slice(0, 50)}`);

let fail = 0;
console.log(`kosh ledger QC: ${mails.length} mails → ${tx.length} ledger lines, ${(snap.refunds || []).length} refunds tracked\n`);
for (const r of R) {
  const mark = r.n === 0 ? 'PASS' : r.hard ? 'FAIL' : 'LOOK';
  if (r.n && r.hard) fail++;
  console.log(`${mark}  ${r.name}: ${r.n}`);
  r.ex.forEach((e) => console.log('      ' + e));
}
const j = process.argv.find((a) => a.startsWith('--json='));
if (j) fs.writeFileSync(j.slice(7), JSON.stringify(R.map(({ name, hard, n }) => ({ name, hard, n }))));
process.exit(fail ? 1 : 0);
