/* kosh accounts QC: does every bank, card issuer and wallet that writes to you as a customer have a tile?
   node tools/qc/accounts-qc.js <mails.json> [--name="Your Name"] [--show=HSBC]
   For each institution kosh recognises as a sender (institution(from)), counts its mail, the records it read from it,
   and the account/card tiles the snapshot has for it. An institution with own-customer mail (statements, alerts,
   card/account life events) and no tile is a miss. Exit 1 on any miss. */
'use strict';
const fs = require('fs'), vm = require('vm'), path = require('path');
const K = path.join(__dirname, '..', '..', 'Kosh') + '/';
const c = vm.createContext({ console });
vm.runInContext('var KoshDirectory = ' + fs.readFileSync(K + 'directory.json', 'utf8') + ';', c);
for (const n of ['engine', 'mailwire', 'knowledge', 'reader', 'journey', 'docread', 'agent', 'assist', 'viewplan', 'plan', 'brief', 'decide', 'packs', 'trips', 'checks', 'unlock'])
  vm.runInContext(fs.readFileSync(K + n + '.js', 'utf8'), c, { filename: n + '.js' });
const E = vm.runInContext('KoshEngine', c);
const mails = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
const nm0 = (process.argv.find((a) => a.startsWith('--name=')) || '').slice(7);
const show = (process.argv.find((a) => a.startsWith('--show=')) || '').slice(7);
const recs = mails.map((m) => JSON.parse(E.parseJSON(JSON.stringify(m))));
const prof = nm0 ? { name: nm0, people: [{ id: 'me', name: nm0.split(' ')[0], full: nm0, rel: 'You', color: '#007AFF' }] } : {};
const snap = JSON.parse(E.buildJSON(JSON.stringify(recs), JSON.stringify(prof)));
const tiles = {};
(snap.accounts || []).forEach((a) => (tiles[a.bank] = tiles[a.bank] || []).push('A ' + (a.last || '?') + (a.dcard ? ' (debit card)' : '')));
(snap.cards || []).forEach((a) => (tiles[a.bank] = tiles[a.bank] || []).push('C ' + (a.last || '?') + (a.product ? ' ' + a.product : '')));
const by = {};
mails.forEach((m, i) => {
  const ins = E.institution ? E.institution(m.from || '') : null;
  if (!ins || !/^(?:bank|card|wallet)$/.test(ins.kind || '')) return;
  const k = ins.short, x = by[k] || (by[k] = { mails: 0, read: 0, kinds: {} });
  x.mails++;
  const r = recs[i];
  if (r && r.kind && r.kind !== 'noise' && r.kind !== 'unknown') { x.read++; x.kinds[r.kind] = (x.kinds[r.kind] || 0) + 1; }
  if (show && k.toLowerCase().indexOf(show.toLowerCase()) >= 0 && /card|account|statement|pin|kyc|ifsc|welcome/i.test(m.subject || ''))
    console.log('  ', String(m.date).slice(0, 10), (r && r.kind) || '-', (r && r.instr) || '', (r && r.last4) || '', '|', String(m.subject).slice(0, 70));
});
let miss = 0;
Object.keys(by).sort().forEach((k) => {
  const t = tiles[k] || [], x = by[k];
  const bad = !t.length && x.read > 0;
  if (bad) miss++;
  console.log((bad ? 'MISS ' : 'ok   ') + k.padEnd(18) + String(x.mails).padStart(5) + ' mails ' + String(x.read).padStart(4) + ' read  tiles: ' + (t.join(', ') || '—'));
});
console.log(miss ? `\n${miss} institution(s) write to you with no tile` : '\nevery institution has a tile');
process.exit(miss ? 1 : 0);
