# kosh-reader v4 on the phone: its own grammar ({"events":[…]}), room for its longer answers, and its answers read
# through engine › readerAnswerJSON + parse (rules first). 3 Nov 2026.
import sys
K = sys.argv[1] if len(sys.argv) > 1 else 'Kosh/'
def sub(path, old, new, count=1):
    s = open(K + path).read(); n = s.count(old)
    assert n == count, (path, n, old[:90]); open(K + path, 'w').write(s.replace(old, new))

R = 'KoshReader.swift'
sub(R, '''    static let grammar = #"""''', '''    static let kindGrammar = #"""''')
sub(R, '''    ws     ::= [ ]?
    """#
''', '''    ws     ::= [ ]?
    """#

    /// kosh-reader v4 and later answer in the reader's events ({"events":[…]}, nothing when the mail moves no money).
    /// The grammar has to be the shape the model was trained on: with the old one, nearly every token the model wanted
    /// was refused, each refusal cost a pass over the whole 248k-token vocabulary, and the answer ran to the limit.
    static let eventsGrammar = #"""
    root   ::= "{" ws "\\"events\\":" ws "[" ws ( event ( "," ws event )* )? ws "]" ws "}"
    event  ::= "{" ws "\\"type\\":" ws type ( "," ws pair )* ws "}"
    type   ::= "\\"move\\"" | "\\"balance\\"" | "\\"statement\\"" | "\\"due\\"" | "\\"expect\\"" | "\\"order\\"" | "\\"trade\\"" | "\\"fund\\"" | "\\"ipo\\"" | "\\"dividend\\"" | "\\"deposit\\"" | "\\"policy\\"" | "\\"mandate\\"" | "\\"account\\"" | "\\"booking\\"" | "\\"loan\\"" | "\\"noise\\""
    pair   ::= string ":" ws value
    value  ::= string | number | object | array | "true" | "false" | "null"
    object ::= "{" ws ( pair ( "," ws pair )* )? ws "}"
    array  ::= "[" ws ( value ( "," ws value )* )? ws "]"
    string ::= "\\"" ( [^"\\\\\\x7F\\x00-\\x1F] | "\\\\" ["\\\\/bfnrt] )* "\\""
    number ::= "-"? [0-9]+ ( "." [0-9]+ )?
    ws     ::= [ ]?
    """#

    /// the loaded model answers in events (v4 on): its .prompt.json says so ("format": "events", or "run": "v4" and on),
    /// else its file name does ("…-v4.q4_k_m")
    private(set) var speaksEvents = false
    private static func eventsFormat(name: String, side: [String: String]?) -> Bool {
        if side?["format"] == "events" { return true }
        func ver(_ s: String) -> Int? {
            guard let r = s.range(of: #"(?:^|[-_ ])v(\\d+)"#, options: .regularExpression) else { return nil }
            return Int(s[r].filter(\\.isNumber))
        }
        if let run = side?["run"], let v = ver(run) { return v >= 4 }
        return (ver(name.lowercased()) ?? 0) >= 4
    }
''')
sub(R, '''        cp.n_ctx = 1536
        cp.n_batch = 1536''', '''        // (an email's text is cut to about 1,800 characters, ~600 tokens; v4's answers run to ~300 tokens on a busy mail)
        cp.n_ctx = 2048
        cp.n_batch = 2048''')
sub(R, '''        if let d = try? Data(contentsOf: side), let o = try? JSONSerialization.jsonObject(with: d) as? [String: String],
           let b = o["before"], let a = o["after"] { turns = (b, a) } else { turns = nil }''',
'''        let sideJSON = (try? Data(contentsOf: side)).flatMap { try? JSONSerialization.jsonObject(with: $0) as? [String: String] }
        if let o = sideJSON, let b = o["before"], let a = o["after"] { turns = (b, a) } else { turns = nil }
        speaksEvents = Self.eventsFormat(name: modelName, side: sideJSON)''')
sub(R, '''        speaksEvents = false
''', '''        speaksEvents = false
''', 0)
sub(R, '''        modelName = ""
        onGPU = false''', '''        modelName = ""
        onGPU = false
        speaksEvents = false''')
sub(R, '''    func read(_ input: String, maxTokens: Int = 220) throws -> String {''', '''    func read(_ input: String, maxTokens: Int = 400) throws -> String {''')
sub(R, '''        let grammar = llama_sampler_init_grammar(vocab, Self.grammar, "root")''', '''        let grammar = llama_sampler_init_grammar(vocab, speaksEvents ? Self.eventsGrammar : Self.kindGrammar, "root")''')
sub(R, '''        var all = [llama_token_data]()
''', '''        var all = fullVocab
        defer { fullVocab = all }
''')
sub(R, '''    /// the text around the email the model was trained on''', '''    /// the whole vocabulary's scores, kept between emails (only needed when the grammar refuses the model's first choice)
    private var fullVocab = [llama_token_data]()
    /// the text around the email the model was trained on''')

A = 'LiveSession+AIPass.swift'
sub(A, '''            guard let checked = try? Engine.shared.call("readerCheckJSON", [input, raw]),
                  let out = try? Engine.shared.call("fromClaudeJSON", [JSONText.encode(msg), checked, apple ? "apple" : "reader"]),
                  let cl = Reading.fromEngine(out) else { continue }''',
'''            var cl: Reading? = nil
            // kosh-reader v4 answers in events: checked as Claude's answers are (every amount printed in the mail), then the
            // mail read again with them beside the rules (engine › withClaude, marked lr: the rules' reading stands)
            if !apple, raw.hasPrefix("{\\"events\\""),
               let aj = try? Engine.shared.call("readerAnswerJSON", [raw, JSONText.encode(msg)]),
               let ad = aj.data(using: .utf8), let ao = try? JSONSerialization.jsonObject(with: ad) as? [String: Any] {
                if let evs = ao["events"] as? [Any], JSONSerialization.isValidJSONObject(evs),
                   let ed = try? JSONSerialization.data(withJSONObject: evs), let es = String(data: ed, encoding: .utf8) {
                    var withEv = msg
                    withEv.cl = es
                    if let out = try? Engine.shared.call("parseJSON", [JSONText.encode(withEv)]), var rd = Reading.fromEngine(out) {
                        rd.id = msg.id
                        cl = rd
                    }
                } else if let out = try? Engine.shared.call("fromClaudeJSON", [JSONText.encode(msg), #"{"kind":"unsure"}"#, "reader"]) {
                    cl = Reading.fromEngine(out)
                }
            } else if let checked = try? Engine.shared.call("readerCheckJSON", [input, raw]),
                      let out = try? Engine.shared.call("fromClaudeJSON", [JSONText.encode(msg), checked, apple ? "apple" : "reader"]) {
                cl = Reading.fromEngine(out)
            }
            guard let cl else { continue }''')

sub('LiveCore.swift', '''"clReadAnswerJSON", "readerCheckJSON",''', '''"clReadAnswerJSON", "readerCheckJSON", "readerAnswerJSON",''')
print('ok')
