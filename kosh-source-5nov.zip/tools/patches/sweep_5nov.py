#!/usr/bin/env python3
"""sweep-5nov (kosh ios app chat): money moving between an account and its own deposit, for any bank's wording.
User: "if somebody has opted in sweep or any other word — will have this feature".
- Sweep / auto-sweep / reverse sweep / "Sweep Transfer To" / "Sweep Trf From" / MOD (SBI multi option deposit) /
  flexi, auto, smart or linked deposit: Self Transfer, both ways (was: People › Every month as SPENDING, and income).
- A deposit booked from the account ("FD Booked", "TD booking", "opened FD"): Investments › FD (was Miscellaneous).
- A deposit's money coming back or closed ("FD Premat Proceeds", "Pre Matu Clos FD", "Closure of TD", maturity
  proceeds, "Brn-Td"): Self Transfer (your own money back, never income).
- The account is marked sweep (a.sweep) once a sweep move is seen, so the app can say so.
- A statement whose lines start with their serial number (Kotak's "Sl. No." column: "12 Sweep Transfer To"):
  the numbers are dropped from the names, only when most lines carry them and they run upward.
Only the bank's own lines (no UPI ID). Your own category choice still wins. Idempotent."""
import sys
def patch(p, pairs, marker):
    s = open(p, encoding='utf-8').read()
    if marker in s: print(p, 'already'); return
    for a, b in pairs:
        if s.count(a) != 1: sys.exit('%s anchor %d: %r' % (p, s.count(a), a[:60]))
        s = s.replace(a, b)
    open(p, 'w', encoding='utf-8').write(s); print(p, 'patched')
patch('Kosh/engine.js', [
 ("""    var tx = merged.map(function (r) {
      var card =r.instr === 'card' && railInst(r.inst) ? railCard(r, cardDigits) : (instrKey(r) || (r.inst || ''));""",
  """    // (sweep-5nov) money between an account and its own deposit, in any bank's words
    var SWEEP_RE = /\\b(?:swept (?:out|in)|auto[- ]?sweep|reverse[- ]?sweep|sweep)\\b|\\b(?:mod|multi option deposit)\\s*(?:trf|tfr|transfer|cr|dr|creation|created|closure|break|renewal)\\b|\\b(?:trf|tfr|transfer)\\s*(?:to|from)\\s*mod\\b|\\b(?:flexi|auto|smart|linked)[- ]?(?:fixed\\s+)?(?:deposit|fd)\\b/i;
    var DEP_WORD = '(?:fd|td|term deposit|fixed deposit|deposit)';
    var DEP_BOOK_RE = new RegExp('\\\\b' + DEP_WORD + '\\\\s*(?:a\\\\/c\\\\s*)?(?:booked|booking|book|opened|opening|open|created|creation|placed)\\\\b|\\\\b(?:booked|opened|opening of)\\\\s+(?:an?\\\\s+|new\\\\s+)?' + DEP_WORD + '\\\\b', 'i');
    var DEP_BACK_RE = new RegExp('\\\\b(?:pre[\\\\s.]*mat\\\\w*|premat\\\\w*|maturity|matured|closure|closed|clos|proceeds|redeem\\\\w*|break)\\\\b[^|]{0,20}\\\\b' + DEP_WORD + '\\\\b|\\\\b' + DEP_WORD + '\\\\s*(?:pre[\\\\s.]*mat\\\\w*|premat\\\\w*|maturity|matured|closure|closed|clos\\\\w*|proceeds|redeem\\\\w*|break)|\\\\bbrn[- ]?td\\\\b', 'i');
    var sweepSeen = {};
    var tx = merged.map(function (r) {
      var card =r.instr === 'card' && railInst(r.inst) ? railCard(r, cardDigits) : (instrKey(r) || (r.inst || ''));"""),
 ("""      var sweep = r.instr === 'account' && /\\b(?:swept (?:out|in)|auto[- ]?sweep|reverse sweep|sweep[- ]?(?:out|in|fd|deposit))\\b/i.test((r.subject || '') + ' ' + (r.party || '') + ' ' + (r.info || ''));
      var cl = sweep || closedMove(r) || toOwnAcct(r) ? { c: 'Self Transfer', s: '', k: 'move' } : ck ? { c: 'Investments', s: 'Chit fund', k: kindFor('Investments', 'out') } : classify(r, ctx);""",
  """      var said5 = (r.subject || '') + ' ' + (r.party || '') + ' ' + (r.info || '');
      var bankLine = r.instr === 'account' && !r.vpa;
      var sweep = bankLine && SWEEP_RE.test(said5);
      if (sweep) sweepSeen[card] = 1;
      var depBook = bankLine && !sweep && r.dir === 'out' && DEP_BOOK_RE.test(said5);
      var depBack = bankLine && !sweep && !depBook && DEP_BACK_RE.test(said5);
      var cl = sweep || depBack || closedMove(r) || toOwnAcct(r) ? { c: 'Self Transfer', s: '', k: 'move' } : depBook ? { c: 'Investments', s: 'FD', k: kindFor('Investments', 'out') } : ck ? { c: 'Investments', s: 'Chit fund', k: kindFor('Investments', 'out') } : classify(r, ctx);"""),
 ("""    accounts.forEach(function (a) {
      if (a.dcard) return;
      typedPt(a.id);""",
  """    accounts.forEach(function (a) {
      if (a.dcard) return;
      if (sweepSeen[a.id]) a.sweep = true;   // (sweep-5nov)
      typedPt(a.id);"""),
 ("""        d0 = stmtFurniture(d0);""",
  """        d0 = stmtFurniture(d0);
        if (stSerial) d0 = d0.replace(/^\\s*\\d{1,3}\\s+(?=[A-Za-z])/, '');   // (sweep-5nov) a serial number is no part of the name"""),
 ("""      /* what each line of it says, read once: its narration as the payee's words""",
  """      // (sweep-5nov) lines that open with their serial number, running upward, on most of the statement's lines
      var stSerial = (function () {
        var rs = S.rows || [], n = 0, up = 0, prev = -1;
        rs.forEach(function (r) { var m = /^\\s*(\\d{1,3})\\s+[A-Za-z]/.exec(String(r.desc || '')); if (m) { n++; if (+m[1] > prev) up++; prev = +m[1]; } });
        return rs.length >= 3 && n >= rs.length * 0.6 && up >= n * 0.8;
      })();
      /* what each line of it says, read once: its narration as the payee's words"""),
], 'sweep-5nov')
# Swift: the account knows its sweep is on, and its balance card says what that means
patch('Kosh/Snapshot.swift', [
 ("""    /// (quiet-4nov) no money has moved through it in six months: the day it last did ("long ago" when never seen)
    var quiet: String? = nil""",
  """    /// (quiet-4nov) no money has moved through it in six months: the day it last did ("long ago" when never seen)
    var quiet: String? = nil
    /// (sweep-5nov) money over a limit moves from it into a linked deposit and back (its statements show the sweeps)
    var sweep: Bool? = nil"""),
], 'sweep-5nov')
patch('Kosh/AccountPage.swift', [
 ("""            // (smsstop-5nov) the live balance leans on SMS: when they've stopped reaching kosh, say so here""",
  """            // (sweep-5nov) a sweep account: what its moves are, and what keeps the figure right between statements
            if a.sweep == true {
                Rectangle().fill(Color.primary.opacity(0.08)).frame(height: 0.5)
                HStack(alignment: .firstTextBaseline, spacing: 8) {
                    Image(systemName: "arrow.left.arrow.right.circle").font(.system(.footnote, weight: .semibold)).foregroundStyle(Color.secondary)
                    Text("Sweep is on: money over the limit moves into a linked deposit and back. kosh counts those as your own money moving, never spending or income. Banks don’t alert a sweep, so between statements your bank’s SMS balance is what keeps this right.")
                        .font(.footnote).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                    Spacer(minLength: 0)
                }
                .padding(.horizontal, 14).padding(.vertical, 10)
            }
            // (smsstop-5nov) the live balance leans on SMS: when they've stopped reaching kosh, say so here"""),
], 'sweep-5nov-swift')
