#!/usr/bin/env python3
"""Every payment carries what kosh knows of its purchase; filing asks again (3 Nov 2026, later). Idempotent.
1. payFacts: an order whose mails printed its lines' prices but no total (Amazon Prime's "Ordered:" mail) is matched
   by the lines' sum, so a ₹1,499 Amazon Pay charge finds "Amazon Prime (Yearly Membership)".
2. ordersBook: every spend gets an entry, even with one mail and no order: who told of it (by: "Amazon Pay"),
   whether the shop itself mailed anything (nm: 1, shop: "Zepto"), and a kosh tag from a known shop's kind
   (Groceries, Food, Fashion, Beauty, Electronics, Books). The sheet's order card (tags, Tag button) shows on every spend.
3. Learning: "just this one" is just that one again. The 3 Nov look-alike carry (a "just this one" payment filing its
   payee's guessed payments of about the same sum, tx.ls) is off: kosh asks instead (Store+Edits)."""
import pathlib, sys
ROOT = pathlib.Path(__file__).resolve().parents[2]
p = ROOT / 'Kosh' / 'engine.js'
s = p.read_text()
if 'details-3nov' in s:
    print('details_3nov_engine: already in'); sys.exit(0)
def rep(a, b):
    global s
    if s.count(a) != 1: sys.exit('details_3nov_engine: anchor not unique/missing: ' + a[:90])
    s = s.replace(a, b, 1)

# 1. an order with priced lines and no printed total: its lines' sum is a total
rep("""        Object.keys(byNo).forEach(function (k) { var O = byNo[k]; if (O.totals.length && O.items.length) (ordersByShop[O.shop] = ordersByShop[O.shop] || []).push(O); });""",
"""        Object.keys(byNo).forEach(function (k) {
          var O = byNo[k];
          // (details-3nov: no total printed, every line priced: the lines' sum is what it came to)
          if (!O.totals.length && O.amt && O.items.length && O.items.every(function (n) { return O.amt[String(n).trim()] > 0; })) {
            var ls = O.items.reduce(function (s0, n) { return s0 + O.amt[String(n).trim()]; }, 0);
            if (ls > 0) O.totals.push(Math.round(ls * 100) / 100);
          }
          if (O.totals.length && O.items.length) (ordersByShop[O.shop] = ordersByShop[O.shop] || []).push(O);
        });""")

# 2. every spend: who told of it, whether the shop mailed, a known shop's kind as a tag
rep("""    var KIND_TAGS = { Beauty: 1, Electronics: 1, Fashion: 1, Books: 1, Food: 1 };""",
"""    var KIND_TAGS = { Beauty: 1, Electronics: 1, Fashion: 1, Books: 1, Food: 1, Groceries: 1 };
    // (details-3nov) a shop kosh knows by its brand: what it sells, by the payment's category, as a tag
    var CAT_TAG = { Groceries: 'Groceries', 'Food & Drinks': 'Food' };""")
rep("""        if (tags.length) O.tags = tags;
        if (Object.keys(src).length) O.src = src;
        if (Object.keys(O).length && (O.mails || O.bill || O.show || O.trip || O.gift || O.tags || O.to)) { pay[t.id] = O; tagged.push(t); }""",
"""        // (details-3nov) a known shop's kind, when the mail named nothing: Zepto is Groceries, Swiggy's food Food
        var shopRow = fact.sh && /^b:/.test(fact.sh) && shopsOf[fact.sh];
        if (shopRow && !NOT_PURCHASE.test(t.c || '')) { var kt = SUB_TAG[t.s] || CAT_TAG[t.c] || ''; if (kt) tag(kt); }
        if (tags.length) O.tags = tags;
        if (Object.keys(src).length) O.src = src;
        /* every spend says what kosh read it from, even one mail and no order (details-3nov): the senders (by), and when
           none of them is the shop, that the shop mailed nothing (nm) and its name, so the sheet says why no items show */
        var by = [];
        recs.forEach(function (r) { var n = String(r.inst || '').trim(); if (n && by.indexOf(n) < 0 && by.length < 3) by.push(n); });
        if (by.length) O.by = by;
        var shopMailed = evs.length || recs.some(function (r) { return r.instKind === 'merchant' || r.rule === 'order-receipt' || r.rule === 'order-wallet' || r.rule === 'order-invoice'; });
        if (!shopMailed && shopRow && !NOT_PURCHASE.test(t.c || '')) { O.nm = 1; O.shop = String(shopRow.brand || shopRow.name || '').slice(0, 40); }
        if (Object.keys(O).length) { pay[t.id] = O; tagged.push(t); }""")
rep("""      var pay = {}, tagged = [];
      // (each mail a payment holds as its own,""", """      var pay = {}, tagged = [];
      var shopsOf = {};
      ((snapOut.payFacts && snapOut.payFacts.shops) || []).forEach(function (x) { if (x && x.id) shopsOf[x.id] = x; });
      // (each mail a payment holds as its own,""")

# 3. "just this one" is just that one: the look-alike carry is off (kosh asks: Store+Edits)
rep("""      if (!L.c && !ck && !o.c && r.dir === 'out' && (cl.u || cl.g || cl.slp || cl.c === 'Miscellaneous')) { LS = softFor(r, lk, nameKey(r)); if (LS) L = { c: LS.c, s: LS.s, by: '' }; }""",
"""      // (details-3nov: off. Filing asks "all of them, or just this one?" again, and "just this one" carries nowhere)
      if (SOFT_CARRY && !L.c && !ck && !o.c && r.dir === 'out' && (cl.u || cl.g || cl.slp || cl.c === 'Miscellaneous')) { LS = softFor(r, lk, nameKey(r)); if (LS) L = { c: LS.c, s: LS.s, by: '' }; }""")
rep("""    function softFor(r, lk, nk) {""", """    var SOFT_CARRY = false;
    function softFor(r, lk, nk) {""")
p.write_text(s)
print('details_3nov_engine: done')
