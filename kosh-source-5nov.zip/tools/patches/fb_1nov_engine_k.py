# kosh feedback 2 Nov (01:30) — engine, part K: money back finds its payment whatever the wallet is called. Amazon Pay
# took ₹5,095 three times for one electricity bill; two failed and came straight back as refund gift cards. The debits
# say "Amazon Pay Balance", the refunds "Amazon Pay wallet", so no refund found its payment and the two failed tries
# counted as ₹10,190 spent. One wallet, one key: its name without "balance", "wallet", "money", "cash" or "gift card".
# And a bill's own word that it was paid (its confirm) belongs to the try that went through, not one given back.
p = 'Kosh/engine.js'; s = open(p).read()
def sub(old, new, mark):
    global s
    if mark in s: return
    assert s.count(old) == 1, ('engine K anchor', old[:70], s.count(old))
    s = s.replace(old, new)
sub("""      var spendsOn = {};
      if (backs.length) tx.forEach(function (p) {
        var o = over[p.id] || {};
        if (p.dirRaw === 'out' && !p.partOf && (p.k === 'out' || p.k === 'prepaid') && !(+o.rf > 0) && !o.rfDone) (spendsOn[p.card] = spendsOn[p.card] || []).push(p);
      });""", """      var spendsOn = {};
      // (one wallet, one key: "Amazon Pay Balance" and "Amazon Pay wallet" are the same money)
      var cardKey = function (k) { k = String(k || '').toLowerCase(); return /(?:balance|wallet|money|cash|gift ?cards?)\\b/.test(k) ? k.replace(/\\b(?:balance|wallet|money|cash|gift ?cards?)\\b/g, ' ').replace(/\\s+/g, ' ').trim() : k; };
      if (backs.length) tx.forEach(function (p) {
        var o = over[p.id] || {};
        if (p.dirRaw === 'out' && !p.partOf && (p.k === 'out' || p.k === 'prepaid') && !(+o.rf > 0) && !o.rfDone) (spendsOn[cardKey(p.card)] = spendsOn[cardKey(p.card)] || []).push(p);
      });""", "var cardKey = function (k)")
sub("""          (own ? (mine && (spendsOn[mine.card] || []).indexOf(mine) >= 0 ? [mine] : []) : (spendsOn[c.card] || [])).forEach(function (p) {""",
    """          (own ? (mine && (spendsOn[cardKey(mine.card)] || []).indexOf(mine) >= 0 ? [mine] : []) : (spendsOn[cardKey(c.card)] || [])).forEach(function (p) {""", "spendsOn[cardKey(mine.card)]")
open(p, 'w').write(s)
print('engine K patched')
sub("""        refunds.push(row);
      });
      // the refunds that found no payment: money back off that kind of spending (nt), in the month they land""",
    """        refunds.push(row);
      });
      /* GUARDRAIL a bill's word that it was paid belongs to the try that went through: when the payment that took the
         bill's name came straight back in full and another try of the same sum from the same wallet or card, in the
         three days after, stayed, that one is the bill (Electricity, not "Amazon · Shopping") and the given-back try
         keeps only its merchant */
      tx.forEach(function (t) {
        if (t.partOf || t.dirRaw !== 'out' || !(t.refunded > 0) || Math.abs((t.full || t.a) - t.refunded) > 1 || !t.rc) return;
        var w = (t.full || t.a), k0 = cardKey(t.card);
        var p = tx.filter(function (x) { return x !== t && !x.partOf && x.dirRaw === 'out' && !x.rc && !(x.refunded > 0) && cardKey(x.card) === k0 && Math.abs(x.a - w) <= 1 && x.d >= t.d && daysBetween(t.d, x.d) <= 3; })
          .sort(function (a, b) { return String(a.d + (a.t || '')).localeCompare(String(b.d + (b.t || ''))); })[0];
        if (!p) return;
        ['c', 's', 'm', 'sym', 'k', 'rc', 'told'].forEach(function (f) { var v = p[f]; p[f] = t[f]; t[f] = v; });
      });
      // the refunds that found no payment: money back off that kind of spending (nt), in the month they land""", "GUARDRAIL a bill's word that it was paid belongs to the try that went through")
open(p, 'w').write(s)
print('engine K bill to its try')
