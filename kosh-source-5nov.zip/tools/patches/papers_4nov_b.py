#!/usr/bin/env python3
"""papers-4nov-funds (statements chat): a broker's funds / securities papers and a depository's meeting notices are
not holdings statements. When a paper filed as a CAS holds no securities, kosh says what it is instead:
 paper:'funds' with funds:{bal, asOf, owed} (broker ledger: weekly funds statement, retention statement, exchange's
 "Funds / Securities Balance" mail; negative = you owe the broker), or paper:'notice' (e-voting, postal ballot,
 AGM/EGM). Idempotent: marker 'papers-4nov-funds'."""
import pathlib, sys
K = pathlib.Path(__file__).resolve().parents[2] / 'Kosh'
p = K / 'engine.js'; s = p.read_text()
if 'papers-4nov-funds' in s: print('already'); sys.exit()
old = """    else if (kind === 'cas') out = parseCAS(text);
    else if (kind === 'policy')"""
new = """    else if (kind === 'cas') {
      out = parseCAS(text);
      // papers-4nov-funds: a paper with no securities in it, that is a broker's ledger or a meeting notice
      if (!out.holdings.length) {
        var bf = brokerFunds(text, flat);
        if (bf) { out.paper = 'funds'; out.funds = bf; if (!out.asOf && bf.asOf) out.asOf = bf.asOf; }
        else if (/\\be-?voting\\b|\\bpostal\\s+ballot\\b|\\b(?:annual|extra-?ordinary)\\s+general\\s+meeting\\b|\\b[AE]GM\\b|\\bremote\\s+e-?voting\\b/i.test(flat.slice(0, 4000))) out.paper = 'notice';
      }
    }
    else if (kind === 'policy')"""
if s.count(old) != 1: sys.exit('anchor')
s = s.replace(old, new)
old2 = """  function parseCAS(text) {"""
new2 = """  /* papers-4nov-funds: what a broker holds of yours in money, as its own ledger papers print it. Negative: you owe it. */
  function brokerFunds(text, flat) {
    if (!/\\bfunds?\\b[^\\n]{0,40}\\b(?:balance|statement|available)|statement\\s+of\\s+accounts?\\s+of\\s+(?:funds|securities)|retention\\s+(?:account\\s+)?statement|\\bclient\\s+ledger\\b|\\bledger\\s+code\\b/i.test(flat)) return null;
    var N = '(-?(?:\\\\d{1,3}(?:,\\\\d{2,3})+|\\\\d+)\\\\.\\\\d{1,3})', m, bal = null;
    if ((m = flat.match(new RegExp('Total\\\\s+Funds\\\\s+available\\\\s*(?:\\\\([a-z]\\\\))?\\\\s*' + N, 'i')))) bal = num(m[1]) * (m[1].charAt(0) === '-' ? -1 : 1);
    else if ((m = flat.match(new RegExp('Closing\\\\s+Balance\\\\s*:?\\\\s*' + N + '\\\\s+' + N + '(?:\\\\s+' + N + ')?\\\\s*(Dr|Cr)?', 'i')))) {
      var dr = num(m[1]), cr = num(m[2]);
      bal = m[4] ? (/dr/i.test(m[4]) ? -num(m[3] || m[1]) : num(m[3] || m[2])) : cr - dr;
    }
    else if ((m = flat.match(new RegExp('Unique\\\\s+Client\\\\s+Code[\\\\s\\\\S]{0,240}?\\\\b[A-Z]{1,4}\\\\d{3,}\\\\s+' + N + '\\\\s+\\\\d', 'i')))) bal = num(m[1]) * (m[1].charAt(0) === '-' ? -1 : 1);
    else {
      var L = text.split('\\n'), at = -1;
      for (var i = 0; i < L.length; i++) if (/clear\\s+balance\\s+as\\s+on/i.test(L[i])) { at = i; break; }
      for (var j = at + 1; at >= 0 && j < Math.min(L.length, at + 12); j++) {
        if (/pending\\s+obligations/i.test(L[j])) break;
        var t = L[j].match(/(-?(?:\\d{1,3}(?:,\\d{2,3})+|\\d+)\\.\\d{2})\\s*$/);
        if (t && /^\\s*(?:NA\\s+)+/.test(L[j])) { bal = num(t[1]) * (t[1].charAt(0) === '-' ? -1 : 1); break; }
      }
    }
    var d = flat.match(/\\bTo\\s+Date\\s*:?\\s*(\\d{4}-\\d{2}-\\d{2})/i), asOf = d ? d[1] : casAsOf(flat);
    if (!asOf) { var pd = flat.match(/\\bPrint\\s+Date\\s*:?\\s*(\\d{1,2}[-\\/]\\d{1,2}[-\\/]\\d{4})/i); if (pd) asOf = isoDate(pd[1], ''); }
    return { bal: bal == null ? null : Math.round(bal * 100) / 100, asOf: asOf || '', owed: bal != null && bal < 0 };
  }
  function parseCAS(text) {"""
if s.count(old2) != 1: sys.exit('anchor2')
s = s.replace(old2, new2)
p.write_text(s); print('patched papers-4nov-funds')
