#!/usr/bin/env python3
"""accttype-4nov (statements chat), Swift side: a statement's status (closed / dormant) is kept on its StmtDoc for the
engine; a bank statement that also lists a PPF or deposit stays a statement (its holdings are added, its kind isn't
turned into a holdings paper). Idempotent. Run from kosh-beta/."""
import sys
def patch(p, pairs, marker):
    s = open(p, encoding='utf-8').read()
    if marker in s: print(p, 'already'); return
    for a, b in pairs:
        if s.count(a) != 1: sys.exit('%s anchor %d: %r' % (p, s.count(a), a[:60]))
        s = s.replace(a, b)
    open(p, 'w', encoding='utf-8').write(s); print(p, 'patched')
patch('Kosh/LiveSession.swift', [
 ("""        var limit: Double? = nil; var avail: Double? = nil
    }
    var statements: [StmtDoc] = []""",
  """        var limit: Double? = nil; var avail: Double? = nil
        /// (accttype-4nov) what the statement says of the account itself: "closed", "dormant"
        var status: String? = nil
    }
    var statements: [StmtDoc] = []"""),
], 'accttype-4nov')
patch('Kosh/LiveSession+Statements.swift', [
 ("""        lastDocKind = paper == "epf" ? "epf" : (parsed.holdings.isEmpty ? (parsed.policies.isEmpty ? paper : "policy") : "cas")""",
  """        // (accttype-4nov: a bank statement that also lists a PPF or a deposit is still a bank statement)
        lastDocKind = paper == "epf" ? "epf" : (paper == "stmt" ? "stmt" : (parsed.holdings.isEmpty ? (parsed.policies.isEmpty ? paper : "policy") : "cas"))"""),
 ("""                                  avail: kind == "cardstmt" && parts.count == 1 ? parsed.avail : nil)""",
  """                                  avail: kind == "cardstmt" && parts.count == 1 ? parsed.avail : nil,
                                  status: parts.count == 1 ? parsed.status : nil)"""),
 ("""        var parts: [Part]? = nil""", """        var parts: [Part]? = nil
        /// (accttype-4nov) the statement says the account is "closed" or "dormant"
        var status: String? = nil"""),
], 'accttype-4nov')
