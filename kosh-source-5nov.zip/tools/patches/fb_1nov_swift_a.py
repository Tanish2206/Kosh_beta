# kosh feedback 1 Nov — Swift, part A: the black look's aura, the source sheet, insurance, cards, snapshot fields. Idempotent.
import os
def patch(F, pairs):
    p = os.path.join('Kosh', F); s = open(p).read()
    for a, b, mark in pairs:
        if mark in s: continue
        # (a later source drop moved this code: the change is left out, said, and the rest go on)
        if s.count(a) == 0: print('  skipped (moved):', F, a[:60].replace('\n', ' ')); continue
        assert s.count(a) == 1, (F, a[:90], s.count(a))
        s = s.replace(a, b)
    open(p, 'w').write(s)

patch('Obsidian.swift', [
("""    /// a page in the black look: drawn dark whatever the app's look, on black, its bars dark too
    func obsidianPage() -> some View {
        self.background(Obsidian.bg.ignoresSafeArea())""",
"""    /// a page in the black look: drawn dark whatever the app's look, on black, its bars dark too; `aura`, the page's
    /// colour, glows from its top left (ObsidianAura) — one strength for every black page
    func obsidianPage(aura: Color? = nil) -> some View {
        self.background(alignment: .top) { if let aura { ObsidianAura(tint: aura) } }
            .background(Obsidian.bg.ignoresSafeArea())""", "func obsidianPage(aura: Color? = nil)"),
("""/// a caption in capitals""", """/// the warm light at the top of a black page, in its colour (1 Nov: the first one, at 16%, was barely there on the
/// phone). A wide wash with a brighter core, off to the left, under the bars; fixed while the page scrolls
struct ObsidianAura: View {
    let tint: Color
    /// how strong a card's own corner light is
    static let card: Double = 0.42
    var body: some View {
        ZStack {
            RadialGradient(stops: [.init(color: tint.opacity(0.30), location: 0), .init(color: tint.opacity(0.11), location: 0.45),
                                   .init(color: .clear, location: 1)], center: .center, startRadius: 0, endRadius: 330)
                .frame(width: 560, height: 640).offset(x: -70, y: -250)
            RadialGradient(colors: [tint.opacity(0.10), .clear], center: .center, startRadius: 0, endRadius: 180)
                .frame(width: 360, height: 360).offset(x: 150, y: -140)
        }
        .frame(maxWidth: .infinity, alignment: .top)
        .ignoresSafeArea()
        .allowsHitTesting(false)
        .accessibilityHidden(true)
    }
}

/// a caption in capitals""", "struct ObsidianAura: View"),
])
patch('InsurancePolicy.swift', [
("""            .background(alignment: .top) {
                RadialGradient(colors: [tint.opacity(0.16), tint.opacity(0.04), Color.clear], center: .center, startRadius: 0, endRadius: 310)
                    .frame(width: 510, height: 620).offset(x: -60, y: -220).allowsHitTesting(false).accessibilityHidden(true)
            }
            .navigationTitle("")
            .navigationBarTitleDisplayMode(.inline)
            .obsidianPage()""", """            .navigationTitle("")
            .navigationBarTitleDisplayMode(.inline)
            .obsidianPage(aura: tint)""", ".obsidianPage(aura: tint)"),
("""        if p.premium > 0 { r.append(("Premium", InsBook.premiumLine(p))) }""", """        if p.premium > 0 { r.append(("Premium", InsBook.premiumLine(p))) }
        if let g = p.gross, g > p.premium { r.append(("Last paid, with GST", Fmt.rupees(g))) }""", "Last paid, with GST"),
("""                    InsPeopleOn(p: p).padding(.top, 36)""", """                    InsPeopleOn(p: p, ask: { details = true }).padding(.top, 36)""", "InsPeopleOn(p: p, ask:"),
("""struct InsPeopleOn: View {
    @Environment(Store.self) private var store
    let p: Policy""", """struct InsPeopleOn: View {
    @Environment(Store.self) private var store
    let p: Policy
    /// opens the policy's details, where what its papers didn't say is filled in once
    var ask: (() -> Void)? = nil""", "var ask: (() -> Void)? = nil"),
("""                .obsidianCard(24, padding: 18)
                .accessibilityElement(children: .combine)
            }
            LazyVGrid""", """                .obsidianCard(24, padding: 18)
                .accessibilityElement(children: .combine)
            } else if InsKind.of(p).life, store.live != nil, let ask {
                // (a nominee its papers didn't print plainly: said so, and asked once, rather than a form's label shown)
                Button(action: ask) {
                    HStack(spacing: 16) {
                        Image(systemName: "person.badge.plus").font(.system(size: 18, weight: .medium)).foregroundStyle(tint)
                            .frame(width: 50, height: 50)
                            .overlay(Circle().strokeBorder(tint.opacity(0.55), style: StrokeStyle(lineWidth: 1.5, dash: [3, 4])))
                            .padding(7)
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Nominee").caption(tint)
                            Text("Not printed plainly in its papers").font(.system(size: 15.5, weight: .semibold)).foregroundStyle(Obsidian.ink)
                            Text("Add it once — kosh keeps it").font(.system(size: 12.5)).foregroundStyle(Obsidian.ink3)
                        }
                        Spacer(minLength: 0)
                        Image(systemName: "chevron.right").font(.system(size: 12, weight: .semibold)).foregroundStyle(Obsidian.ink3)
                    }
                    .obsidianCard(24, padding: 18)
                }
                .buttonStyle(.press)
            }
            LazyVGrid""", "Not printed plainly in its papers"),
("""                        if store.live != nil { store.betaSheet = .source(SourceRef(title: InsBook.name(p), mails: [m.id], type: "policy")) }""",
 """                        if store.live != nil { store.betaSheet = .source(SourceRef(title: InsBook.name(p), mails: [m.id], type: "policy", tint: InsLook.color(InsKind.of(p)))) }""", "type: \"policy\", tint:"),
("""                            Image(systemName: m.k.hasPrefix("paper") ? "doc.text" : "envelope").font(.system(size: 19)).foregroundStyle(Obsidian.ink2)""",
 """                            Image(systemName: m.k.hasPrefix("paper") ? "doc.text" : m.pdf == true ? "doc.richtext" : "envelope").font(.system(size: 19)).foregroundStyle(Obsidian.ink2)""", "m.pdf == true ? \"doc.richtext\""),
("""                                Text((m.k.hasPrefix("paper") ? "PDF" : "Mail")""", """                                Text((m.k.hasPrefix("paper") || m.pdf == true ? "PDF" : "Mail")""", "|| m.pdf == true ? \"PDF\""),
])
patch('WealthDeposits.swift', [("""        .navigationTitle("Deposits")
        .navigationBarTitleDisplayMode(.inline)
        .obsidianPage()""", """        .navigationTitle("Deposits")
        .navigationBarTitleDisplayMode(.inline)
        .obsidianPage(aura: Obsidian.health)""", "obsidianPage(aura: Obsidian.health)")])
patch('WealthFunds.swift', [("""        .obsidianPage()""", """        .obsidianPage(aura: Obsidian.term)""", "obsidianPage(aura: Obsidian.term)")])
patch('InsuranceBook.swift', [("""        .animation(Motion.base, value: store.who)
        .obsidianPage()""", """        .animation(Motion.base, value: store.who)
        .obsidianPage(aura: Obsidian.savings)""", "obsidianPage(aura: Obsidian.savings)")])
patch('InsurancePayments.swift', [("""        .toolbarTitleDisplayMode(.large)
        .obsidianPage()""", """        .toolbarTitleDisplayMode(.large)
        .obsidianPage(aura: Obsidian.savings)""", "obsidianPage(aura: Obsidian.savings)")])
patch('InsurancePages.swift', [
("""            }
            .obsidianPage()""", """            }
            .obsidianPage(aura: InsurancePart.aura(part))""", "InsurancePart.aura(part)"),
("""struct InsurancePart: View {
    let part: String
""", """struct InsurancePart: View {
    let part: String
    /// the page's light: its kind's colour, the warm gold elsewhere
    static func aura(_ part: String) -> Color {
        switch part {
        case "Health": return Obsidian.health
        case "Motor": return Obsidian.motor
        case "Life": return Obsidian.term
        default: return Obsidian.savings
        }
    }
""", "static func aura(_ part: String)"),
])
patch('WealthView.swift', [
("""        .tabHeader("Wealth", add: adds, ownTitle: true)
        .obsidianPage()""", """        .tabHeader("Wealth", add: adds, ownTitle: true)
        .obsidianPage(aura: Obsidian.health)""", ".tabHeader(\"Wealth\", add: adds, ownTitle: true)\n        .obsidianPage(aura"),
("""                // (the black look: its top row too)
                .obsidianPage()""", """                // (the black look: its top row too)
                .obsidianPage(aura: Obsidian.savings)""", "its top row too)\n                .obsidianPage(aura"),
("""store.betaSheet = .source(SourceRef(title: h.bank, mails: src, type: "deposit"))""", """store.betaSheet = .source(SourceRef(title: h.bank, mails: src, type: "deposit", tint: Obsidian.health))""", "type: \"deposit\", tint: Obsidian.health"),
])
patch('InsuranceObsidian.swift', [
("RadialGradient(colors: [Obsidian.savings.opacity(0.10), Obsidian.ulip.opacity(0.05), Color.clear]", "RadialGradient(colors: [Obsidian.savings.opacity(0.22), Obsidian.ulip.opacity(0.08), Color.clear]", "Obsidian.savings.opacity(0.22)"),
("RadialGradient(colors: [tint.opacity(0.30), Color.clear]", "RadialGradient(colors: [tint.opacity(ObsidianAura.card), Color.clear]", "tint.opacity(ObsidianAura.card)"),
("RadialGradient(colors: [InsLook.wash(k.kind), Color.clear]", "RadialGradient(colors: [InsLook.color(k.kind).opacity(0.26), Color.clear]", "InsLook.color(k.kind).opacity(0.26)"),
])
patch('WealthHome.swift', [
("RadialGradient(colors: [color.opacity(0.22), Color.clear]", "RadialGradient(colors: [color.opacity(0.32), Color.clear]", "color.opacity(0.32)"),
("RadialGradient(colors: [Obsidian.health.opacity(0.28), Color.clear]", "RadialGradient(colors: [Obsidian.health.opacity(ObsidianAura.card), Color.clear]", "Obsidian.health.opacity(ObsidianAura.card)"),
])
patch('Snapshot.swift', [
("""    struct Mail: Decodable, Hashable { var id: String; var on: String; var k: String }""", """    struct Mail: Decodable, Hashable { var id: String; var on: String; var k: String; var pdf: Bool? = nil }
    /// what its latest receipt says left the account, tax and all, when that is more than the premium
    var gross: Double? = nil""", "var pdf: Bool? = nil }"),
("""    /// the app or store it went to ("Blinkit", "Amazon", "MakeMyTrip"), for Where you shop
    var pf: String? = nil""", """    /// the app or store it went to ("Blinkit", "Amazon", "MakeMyTrip"), for Where you shop
    var pf: String? = nil
    /// a shopping payment's kind, what was bought (engine.js › whatWasBought): Clothing, Footwear, Accessories…; nil when
    /// nothing says. wkb: what said it (items, you, sub, shop)
    var wk: String? = nil; var wkb: String? = nil""", "var wk: String? = nil"),
])
patch('CardShelf.swift', [("""    /// a statement that asks something of you""", """    /// how long an old card stays in the list before it is retired: a rolling year from its last mail
    static let retireDays: Int = 365

    /// the old cards still worth seeing (quiet under a year) and the retired ones, folded further away
    static func retire(_ old: [CardInfo], today: String) -> (quiet: [CardInfo], retired: [CardInfo]) {
        let since: String = isoAdd(today, -retireDays)
        var quiet: [CardInfo] = [], retired: [CardInfo] = []
        for c in old { if String((c.old ?? "").prefix(10)) < since { retired.append(c) } else { quiet.append(c) } }
        return (quiet, retired)
    }

    /// a statement that asks something of you""", "static let retireDays")])
patch('Cards.swift', [
("""    let cards: [CardInfo]
    @State private var open = false
    var body: some View {
        let today: String = store.snap.today
        let title: String = "Old cards · " + String(cards.count)
        let hint: String = "Nothing from them in 90 days\"""", """    let cards: [CardInfo]
    @State private var open = false
    @State private var retiredOpen = false
    var body: some View {
        let today: String = store.snap.today
        let parts = CardShelf.retire(cards, today: today)
        let onlyRetired: Bool = parts.quiet.isEmpty
        let title: String = onlyRetired ? "Retired cards · " + String(parts.retired.count) : "Old cards · " + String(parts.quiet.count)
        let hint: String = onlyRetired ? "Nothing from them in over a year" : "Nothing from them in 90 days\"""", "@State private var retiredOpen"),
("""            Unfold(open: open) {
                VStack(spacing: 0) {
                    ForEach(cards) { (c: CardInfo) in
                        RowRule(inset: 0)
                        row(c, today: today)
                    }
                }
                .padding(.horizontal, 14)
            }""", """            Unfold(open: open) {
                VStack(spacing: 0) {
                    ForEach(parts.quiet) { (c: CardInfo) in
                        RowRule(inset: 0)
                        row(c, today: today)
                    }
                    if onlyRetired {
                        ForEach(parts.retired) { (c: CardInfo) in
                            RowRule(inset: 0)
                            row(c, today: today).opacity(0.6)
                        }
                    } else if !parts.retired.isEmpty {
                        RowRule(inset: 0)
                        Button { withAnimation(Fold.motion(opening: !retiredOpen)) { retiredOpen.toggle() } } label: {
                            HStack(spacing: 8) {
                                Text(String(parts.retired.count) + " retired · quiet for over a year")
                                    .font(.system(.footnote, weight: .medium)).foregroundStyle(.secondary)
                                Spacer(minLength: 6)
                                Image(systemName: "chevron.down").font(.system(.caption2, weight: .bold)).foregroundStyle(.tertiary).foldTurn(retiredOpen)
                            }
                            .frame(minHeight: 40)
                            .contentShape(Rectangle())
                        }
                        .buttonStyle(.press)
                        Unfold(open: retiredOpen) {
                            VStack(spacing: 0) {
                                ForEach(parts.retired) { (c: CardInfo) in row(c, today: today).opacity(0.6) }
                            }
                        }
                    }
                }
                .padding(.horizontal, 14)
            }""", "quiet for over a year\")"),
])
print('swift A patched')
