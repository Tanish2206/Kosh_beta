# kosh feedback 1 Nov (21:28) — Swift, part K: "Which home?" sheet in the black look instead of a stock grey List with
# blue links: the connection on top in its kind colour, each home a row with its door number on a plate and the
# rest as its name, the current one ticked, "A home of its own" as one field with its add button inside, and the quiet
# ways out last. Idempotent.
p = 'Kosh/HomeBillsViews.swift'; s = open(p).read()
if 'PlacePlate(' not in s:
    a = s.index('struct PlaceConnectionSheet: View {')
    b = s.index('\n}\n', a) + 3
    s = s[:a] + r'''struct PlaceConnectionSheet: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    let a: HomesBook.Acct
    @State private var name: String = ""
    @FocusState private var naming: Bool
    struct Choice: Identifiable, Hashable { let id: String; let name: String }
    static func choices(_ homes: [HomesBook.Home], _ props: [Prop]) -> [Choice] {
        var out: [Choice] = homes.map { Choice(id: $0.id, name: $0.name) }
        for p in props {
            let id: String = "p:" + (p.uid ?? p.pid)
            if !out.contains(where: { $0.id == id }) { out.append(Choice(id: id, name: p.short.isEmpty ? p.name : p.short)) }
        }
        return out
    }
    /// "25/26, Bhutani Associates Pvt Ltd" → plate "25/26", name "Bhutani Associates Pvt Ltd"; a name without a door
    /// number keeps it whole
    static func split(_ n: String) -> (plate: String?, title: String) {
        let parts: [String] = n.split(separator: ",", maxSplits: 1).map { $0.trimmingCharacters(in: .whitespaces) }
        if parts.count == 2, parts[0].count <= 10, parts[0].contains(where: { $0.isNumber }), !parts[1].isEmpty {
            return (parts[0], parts[1])
        }
        return (nil, n)
    }
    var body: some View {
        let list: [Choice] = Self.choices(store.homes, store.snap.prop.props)
        let tint: Color = HomeInk.kind(a.k)
        let ready: Bool = !name.trimmingCharacters(in: .whitespaces).isEmpty
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                HStack(alignment: .top) {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("Place this connection").caption()
                        Text("Which home?").font(.system(size: 30, weight: .bold)).foregroundStyle(Obsidian.ink)
                    }
                    Spacer(minLength: 8)
                    Button { dismiss() } label: {
                        Image(systemName: "xmark").font(.system(size: 13, weight: .bold)).foregroundStyle(Obsidian.ink2)
                            .frame(width: 32, height: 32).background(Color.white.opacity(0.08), in: Circle())
                    }
                    .buttonStyle(.press)
                    .accessibilityLabel("Close")
                }
                HStack(spacing: 12) {
                    HomeKindIcon(k: a.k)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(HomeWords.acct(a)).font(.subheadline.weight(.medium)).foregroundStyle(Obsidian.ink).fixedSize(horizontal: false, vertical: true)
                        Text(ConnectionRow.sub(a)).font(.caption).foregroundStyle(Obsidian.ink3).lineLimit(2)
                    }
                    Spacer(minLength: 0)
                }
                .padding(14)
                .background(tint.opacity(0.07), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).strokeBorder(tint.opacity(0.22), lineWidth: 1))

                if !list.isEmpty {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Your homes").caption()
                        VStack(spacing: 0) {
                            ForEach(Array(list.enumerated()), id: \.element.id) { i, c in
                                if i > 0 { ObsRule(inset: 58) }
                                let sp = Self.split(c.name)
                                let on: Bool = (a.home ?? "") == c.id
                                Button {
                                    store.placeConnection(a.id, in: c.id)
                                    dismiss()
                                } label: {
                                    HStack(spacing: 14) {
                                        PlacePlate(text: sp.plate, prop: c.id.hasPrefix("p:"), tint: tint, on: on)
                                        Text(sp.title).font(.body.weight(.medium)).foregroundStyle(Obsidian.ink).lineLimit(2)
                                            .multilineTextAlignment(.leading)
                                        Spacer(minLength: 8)
                                        Image(systemName: on ? "checkmark.circle.fill" : "chevron.right")
                                            .font(on ? .title3 : .caption.weight(.bold))
                                            .foregroundStyle(on ? tint : Obsidian.ink3)
                                    }
                                    .padding(.vertical, 12)
                                    .contentShape(Rectangle())
                                }
                                .buttonStyle(.press)
                                .accessibilityLabel(c.name + (on ? ", chosen" : ""))
                            }
                        }
                        .padding(.horizontal, 14)
                        .background(Obsidian.card, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
                        .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).strokeBorder(Obsidian.cardBorder, lineWidth: 1))
                        Text("Every bill of this connection, before and after, goes to the home you pick.")
                            .font(.caption).foregroundStyle(Obsidian.ink3).padding(.horizontal, 4)
                    }
                }

                VStack(alignment: .leading, spacing: 10) {
                    Text("A home of its own").caption()
                    HStack(spacing: 10) {
                        Image(systemName: "house").font(.subheadline.weight(.semibold)).foregroundStyle(Obsidian.ink3).frame(width: 22)
                        TextField("", text: $name, prompt: Text("Name it, like “The Pune flat”").foregroundStyle(Obsidian.ink3))
                            .foregroundStyle(Obsidian.ink)
                            .focused($naming)
                            .submitLabel(.done)
                            .onSubmit { if ready { store.newHome(name, with: a.id); dismiss() } }
                        Button {
                            store.newHome(name, with: a.id)
                            dismiss()
                        } label: {
                            Image(systemName: "arrow.up").font(.system(size: 14, weight: .bold))
                                .foregroundStyle(ready ? Color.black : Obsidian.ink3)
                                .frame(width: 32, height: 32)
                                .background(ready ? tint : Color.white.opacity(0.08), in: Circle())
                        }
                        .buttonStyle(.press)
                        .disabled(!ready)
                        .accessibilityLabel("Add and put it there")
                    }
                    .padding(.leading, 14).padding(.trailing, 8).frame(minHeight: 52)
                    .background(Obsidian.card, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous)
                        .strokeBorder(naming ? tint.opacity(0.5) : Obsidian.cardBorder, lineWidth: 1))
                    .animation(Motion.base, value: naming)
                }

                HStack(spacing: 10) {
                    Button {
                        store.placeConnection(a.id, in: "none")
                        dismiss()
                    } label: { PlaceQuiet(text: "Not a home’s bill", sym: "nosign") }
                    .buttonStyle(.press)
                    if a.by == "you" {
                        Button {
                            store.placeConnection(a.id, in: "")
                            dismiss()
                        } label: { PlaceQuiet(text: "Let kosh decide", sym: "sparkles") }
                        .buttonStyle(.press)
                    }
                }
            }
            .padding(.horizontal, 20)
            .padding(.top, 26)
            .padding(.bottom, 30)
        }
        .scrollDismissesKeyboard(.interactively)
        .background(alignment: .top) { ObsidianAura(tint: tint) }
        .background(Obsidian.bg.ignoresSafeArea())
        .presentationDetents([.medium, .large])
        .presentationDragIndicator(.visible)
        .presentationCornerRadius(32)
        .presentationBackground(Obsidian.bg)
        .environment(\.colorScheme, .dark)
    }
}

/// a home's door number on a small plate, or a house (a property: a building) when it has none
struct PlacePlate: View {
    let text: String?
    let prop: Bool
    let tint: Color
    let on: Bool
    var body: some View {
        Group {
            if let text {
                Text(text).font(.system(size: text.count > 4 ? 10 : 13, weight: .semibold, design: .monospaced))
                    .minimumScaleFactor(0.6).lineLimit(1)
            } else {
                Image(systemName: prop ? "building.2" : "house").font(.subheadline.weight(.semibold))
            }
        }
        .foregroundStyle(on ? Color.black : Obsidian.ink)
        .padding(.horizontal, 4)
        .frame(width: 44, height: 36)
        .background(on ? tint : Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 10, style: .continuous).strokeBorder(Color.white.opacity(on ? 0 : 0.08), lineWidth: 1))
        .accessibilityHidden(true)
    }
}

/// a quiet way out of the sheet, half the width
struct PlaceQuiet: View {
    let text: String
    let sym: String
    var body: some View {
        HStack(spacing: 8) {
            Image(systemName: sym).font(.footnote.weight(.semibold))
            Text(text).font(.subheadline.weight(.medium)).lineLimit(1).minimumScaleFactor(0.85)
        }
        .foregroundStyle(Obsidian.ink2)
        .frame(maxWidth: .infinity, minHeight: 48)
        .background(Color.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).strokeBorder(Obsidian.cardBorder, lineWidth: 1))
        .contentShape(Rectangle())
    }
}
''' + s[b:]
open(p, 'w').write(s)
print('swift K patched')
