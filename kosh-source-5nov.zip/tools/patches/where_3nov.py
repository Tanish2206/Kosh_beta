#!/usr/bin/env python3
"""where-3nov (statements chat, 3 Nov): where to find a detail a statement password needs, per institution, shown on the
locked statement's card ("HSBC: your Customer Number is in the HSBC India app, under Statements, at the top of any
statement"). Data, not code: PW_WHERE grows one line per institution and detail. Idempotent. Run from kosh-beta/."""
import sys
def patch(p, pairs, marker):
    s = open(p, encoding='utf-8').read()
    if marker in s: print(p, 'already has', marker); return
    for old, new in pairs:
        if s.count(old) != 1: sys.exit('%s anchor %d: %r' % (p, s.count(old), old[:60]))
        s = s.replace(old, new)
    open(p, 'w', encoding='utf-8').write(s); print(p, 'patched')
patch('Kosh/engine.js', [
 ("""  function pwWhere(s) {""",
  """  /* (where-3nov) where each institution prints a detail its statement password needs, for the locked card to say.
     Keyed by the sender's domain fragment and the detail's kind (cid, crn, card, acct, mobile, dob, pan) */
  var PW_WHERE = [
    ['hsbc', 'cid', 'HSBC prints your Customer Number (like 255-XXXXXX) at the top of every statement: open the HSBC India app › Statements, or any earlier statement. The password uses its 4th to 9th digits.'],
    ['hsbc', 'card', 'The last 6 digits of your HSBC card are on the card itself, and on the HSBC India app › Cards.'],
    ['hdfc', 'cid', 'HDFC prints your Customer ID on your cheque book and passbook, and in the HDFC Bank app › Profile.'],
    ['kotak', 'crn', 'Kotak prints your CRN on the welcome letter and in the Kotak app › Profile.'],
    ['axis', 'cid', 'Axis prints your Customer ID on your welcome letter and in the Axis Mobile app › Profile.'],
    ['sbi', 'mobile', 'SBI uses the mobile number registered with the account (YONO › Profile).'],
  ];
  function pwWhereFor(domain, parts) {
    var d = String(domain || '').toLowerCase(), out = [];
    (parts || []).forEach(function (p) { PW_WHERE.forEach(function (w) { if (d.indexOf(w[0]) >= 0 && w[1] === p.k && out.indexOf(w[2]) < 0) out.push(w[2]); }); });
    return out.join(' ');
  }
  function pwWhere(s) {"""),
 ("""               hint: d.hint || '', parts: rec.parts, example: rec.example, domain: emailOf(d.from || x.r.from || '').split('@')[1] || '',""",
  """               hint: d.hint || '', parts: rec.parts, example: rec.example, domain: emailOf(d.from || x.r.from || '').split('@')[1] || '',
               findAt: pwWhereFor(emailOf(d.from || x.r.from || '').split('@')[1] || '', rec.parts) || undefined,"""),
], 'where-3nov')
patch('Kosh/Snapshot.swift', [
 ("""    var nothingDue: Bool? = nil""", """    var nothingDue: Bool? = nil
    /// (where-3nov) where this institution prints the detail its password needs ("in the HSBC India app › Statements")
    var findAt: String? = nil"""),
], 'where-3nov')
patch('Kosh/Banking.swift', [
 ("""                if !s.example.isEmpty {
                    Text("Their example:""", """                if let at = s.findAt, !at.isEmpty {
                    // (where-3nov) where to find the detail it needs
                    Label(at, systemImage: "lightbulb").font(.footnote).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                }
                if !s.example.isEmpty {
                    Text("Their example:"""),
], 'where-3nov')
