#!/usr/bin/env python3
"""stmttrust-5nov (kosh ios app chat): a statement whose own figures didn't check out (its lines don't take its opening
to its closing, ok !== true) gives a WEAK balance point. A weak point is the live anchor only when it agrees with what
came before it (the link into it adds up). When it contradicts a trusted earlier point plus every payment since — a
closing misread off the PDF (Axis read ₹9.07L, then ₹1,287, for ₹4.10L) — it is passed over: the trusted point and the
payments since stay live. Alerts, SMS, balance mails and a balance you typed are never weak. Idempotent."""
import sys
def patch(p, pairs, marker):
    s = open(p, encoding='utf-8').read()
    if marker in s: print(p, 'already'); return
    for a, b in pairs:
        if s.count(a) != 1: sys.exit('%s anchor %d: %r' % (p, s.count(a), a[:60]))
        s = s.replace(a, b)
    open(p, 'w', encoding='utf-8').write(s); print(p, 'patched')
patch('Kosh/engine.js', [
 ("""addPt(key, { v: +S.close, day: day, at: day + 'T23:59:59', timed: true, rid: '', src: 'statement', edge: 'end', month: (validDay(S.periodTo || '') ? S.periodTo : day).slice(0, 7) });""",
  """addPt(key, { v: +S.close, day: day, at: day + 'T23:59:59', timed: true, rid: '', src: 'statement', edge: 'end', month: (validDay(S.periodTo || '') ? S.periodTo : day).slice(0, 7), weak: S.ok !== true });   // (stmttrust-5nov)"""),
 ("""addPt(key, { v: +S.open, day: S.periodFrom, at: S.periodFrom + 'T00:00:00', timed: true, rid: '', src: 'opening', edge: 'start' });""",
  """addPt(key, { v: +S.open, day: S.periodFrom, at: S.periodFrom + 'T00:00:00', timed: true, rid: '', src: 'opening', edge: 'start', weak: S.ok !== true });"""),
 ("""    var last = P[P.length - 1] || null;
    var judged = links.filter(function (l) { return !l.unsure; });""",
  """    var last = P[P.length - 1] || null;
    /* (stmttrust-5nov) a weak point (a statement whose own figures didn't check out) that contradicts what came before it
       is passed over: back to the latest trusted point, carried forward by every payment since */
    var lastI = P.length - 1;
    while (lastI > 0 && P[lastI].weak && !links[lastI - 1].ok && !links[lastI - 1].unsure) {
      var tI = lastI - 1;
      while (tI >= 0 && P[tI].weak) tI--;
      if (tI < 0) break;
      lastI = tI;
    }
    if (lastI !== P.length - 1) { last = P[lastI]; links = links.slice(0, Math.max(0, lastI)); }
    var judged = links.filter(function (l) { return !l.unsure; });"""),
], 'stmttrust-5nov')
