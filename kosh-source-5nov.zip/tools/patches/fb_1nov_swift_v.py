# kosh feedback 2 Nov (01:53) — Swift, part V: an order paid from a wallet and a card says so. The card's row: "Order
# ₹3,414 · ₹3,000 Myntra Credit + ₹414 card"; the wallet's row: "From Myntra Credit · the rest on the card". Idempotent.
def sub(path, old, new, mark):
    s = open(path).read()
    if mark in s: return
    assert s.count(old) == 1, (path, old[:70], s.count(old))
    open(path, 'w').write(s.replace(old, new))
sub('Kosh/Snapshot.swift', """    struct Mix: Decodable, Hashable {""", """    /// an order paid partly from a wallet or a shop's credit: the wallets and their shares, the order's whole; on the
    /// wallet's own row, the card payment it went with
    struct WalletUse: Decodable, Hashable { let w: String; let a: Double }
    var wu: [WalletUse]? = nil; var ot: Double? = nil; var wf: String? = nil
    struct Mix: Decodable, Hashable {""", 'struct WalletUse: Decodable, Hashable')
sub('Kosh/Style.swift', """                } else if let gone = SplitWords.returned(t, store) {""", """                } else if let paid = SplitWords.paidHow(t, store) {
                    HintLine(sym: "creditcard.and.123", text: paid)
                        .font(.caption).foregroundStyle(.secondary)
                        .padding(.leading, 48)
                        .privacySensitive()
                } else if let gone = SplitWords.returned(t, store) {""", 'SplitWords.paidHow(t, store)')
p = 'tools/patches/fb_1nov_swift_u.py'
s = open(p).read()
if 'static func paidHow(' not in s:
    s = s.replace("""    /// what of a payment went back:""", """    /// an order paid from a wallet and a card: "Order ₹3,414 · ₹3,000 Myntra Credit + ₹414 card"
    static func paidHow(_ t: Txn, _ store: Store) -> String? {
        if let uses = t.wu, !uses.isEmpty, let whole = t.ot {
            let parts: [String] = uses.map { Fmt.rupees($0.a) + " " + $0.w } + [Fmt.rupees(t.a) + " card"]
            return "Order " + Fmt.rupees(whole) + " · " + parts.joined(separator: " + ")
        }
        if let from = t.wf, let card = store.txn(from) {
            return "From " + t.card + " · " + Fmt.rupees(card.a) + " of the order on the card"
        }
        return nil
    }
    /// what of a payment went back:""")
    open(p, 'w').write(s)
print('swift V patched')
