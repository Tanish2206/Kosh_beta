# kosh feedback 1 Nov (22:26) — engine, part C: a bill paid through an app (Amazon Pay's "Your Electricity bill payment
# … is successful") names the board and the connection only in its HTML ("Paid to UHBVN … Subscriber Id 6223430000");
# its text part is a stale "has failed" template. Bill facts read the HTML when the text gives no number, keep the
# biller it was paid to, and Bills by home finds its connection and its state by that biller (UHBVN → Haryana,
# MSEDCL / MNGL → Maharashtra), so Ambala's and Pune's bills fall to their own homes. Idempotent.
p = 'Kosh/engine.js'; s = open(p).read()
def sub(old, new, mark):
    global s
    if mark in s: return
    assert s.count(old) == 1, ('engine C anchor', old[:80], s.count(old))
    s = s.replace(old, new)
sub("""    var inst = institution(msg.from || ''), bankish = !!(inst && /^(?:bank|card)$/.test(inst.kind));
    var n = bfNumber(flat, BF_NO, bankish) || (!bankish ? bfNumber(flat, [BF_ACCT], false) : null) || (k === 'Maintenance' ? bfNumber(flat, [BF_FLAT], false) : null);
    if (n) { o.no = n.no; o.nol = n.nol; }""", """    var inst = institution(msg.from || ''), bankish = !!(inst && /^(?:bank|card)$/.test(inst.kind));
    var n = bfNumber(flat, BF_NO, bankish) || (!bankish ? bfNumber(flat, [BF_ACCT], false) : null) || (k === 'Maintenance' ? bfNumber(flat, [BF_FLAT], false) : null);
    // (a payment app's receipt whose text part is a template: the HTML says the connection)
    if (!n && msg.html && msg.text) {
      var hlines = mailLines({ text: '', html: msg.html }).slice(0, 200), hflat = subj + '\\n' + hlines.join('\\n');
      n = bfNumber(hflat, BF_NO, bankish);
      if (n) { lines = hlines; flat = hflat; }
    }
    if (n) { o.no = n.no; o.nol = n.nol; }
    // the biller it was paid to, as the receipt names it ("Paid to UHBVN", "Paid to Maharashtra Natural Gas Limited (MNGL)")
    var pt = /\\bpaid to\\s*:?\\s*([A-Za-z][A-Za-z0-9&().,'\\- ﹙﹚]{1,70}?)\\s*(?:\\n|payment details|amount\\b|₹|rs\\.?\\s|$)/i.exec(flat);
    if (pt) { var to = pt[1].replace(/[﹙]/g, '(').replace(/[﹚]/g, ')').replace(/\\s+/g, ' ').trim(); if (to.length >= 2 && !/^(?:amount|you|your)$/i.test(to)) o.to = to.slice(0, 60); }""", '(a payment app\'s receipt whose text part is a template')
sub("""        var b = billerOf(from, [py, nm]);
        var said = nm + ' ' + py + ' ' + String(t.vpa || '');""", """        // (the biller its receipt says it was paid to, before the payee's own words: "Electricity bill" on Amazon)
        var b = billerOf(from, [bf.to || '', py, nm]);
        if (!b && bf.to) nm = hbClean(bf.to);
        var said = nm + ' ' + py + ' ' + String(t.vpa || '');""", "billerOf(from, [bf.to || '', py, nm])")
open(p, 'w').write(s)
# the reading changed: mail is read again
import json
RP = 'Kosh/engine-read.json'
j = json.load(open(RP))
if not str(j.get('read', '')).endswith('-fb1nov11'):
    j['read'] = str(j.get('read', '')).split('-fb1nov')[0] + '-fb1nov11'
    open(RP, 'w').write(json.dumps(j))
print('engine C patched')

# which home: a board kosh calls "national" (HP Oil Gas, a society) has no state; a home you named for its town ("Pune
# Godrej") is in that town's state, and takes the connections of that state's boards (MSEDCL, MNGL) rather than a new
# "Home in Maharashtra"; and with several properties in the board's state, the one you already put a connection in
s = open(p).read()
sub("""        a.state = bit.biller && bit.biller.state && bit.biller.state !== 'unspecified' ? bit.biller.state : '';""",
    """        a.state = bit.biller && bit.biller.state && !/^(?:unspecified|national|all india|pan india)$/i.test(bit.biller.state) ? bit.biller.state : '';""",
    "!/^(?:unspecified|national|all india|pan india)$/i.test(bit.biller.state)")
sub("""      var userHomes = {};
      (prof.homes || []).forEach(function (h) { if (h && h.id && h.name) userHomes[h.id] = h; });""",
    """      var userHomes = {};
      (prof.homes || []).forEach(function (h) { if (h && h.id && h.name) userHomes[h.id] = h; });
      // (the state a home you named is in, by the town in its name or place: "Pune Godrej" → Maharashtra)
      var HB_TOWNS = [[/\\b(?:pune|mumbai|bombay|thane|navi mumbai|nagpur|nashik|aurangabad|kolhapur|pimpri|chinchwad|hinjewadi|wakad|baner|kharadi|hadapsar)\\b/i, 'Maharashtra'],
        [/\\b(?:ambala|gurgaon|gurugram|faridabad|panchkula|karnal|kurukshetra|yamunanagar|panipat|sonipat|rohtak|hisar|jagadhri)\\b/i, 'Haryana'],
        [/\\b(?:delhi|new delhi)\\b/i, 'Delhi'], [/\\b(?:noida|ghaziabad|lucknow|kanpur|agra|varanasi|meerut)\\b/i, 'Uttar Pradesh'],
        [/\\b(?:bengaluru|bangalore|mysuru|mysore)\\b/i, 'Karnataka'], [/\\b(?:hyderabad|secunderabad)\\b/i, 'Telangana'],
        [/\\b(?:chennai|coimbatore)\\b/i, 'Tamil Nadu'], [/\\b(?:kolkata|calcutta)\\b/i, 'West Bengal'], [/\\b(?:mohali|ludhiana|amritsar|jalandhar|patiala)\\b/i, 'Punjab'],
        [/\\bchandigarh\\b/i, 'Chandigarh'], [/\\b(?:jaipur|udaipur|jodhpur)\\b/i, 'Rajasthan'], [/\\b(?:ahmedabad|surat|vadodara)\\b/i, 'Gujarat'],
        [/\\b(?:kochi|cochin|trivandrum|thiruvananthapuram)\\b/i, 'Kerala'], [/\\b(?:shimla|dharamshala)\\b/i, 'Himachal Pradesh'], [/\\b(?:dehradun)\\b/i, 'Uttarakhand']];
      function hbStateOfName(s) { s = String(s || ''); for (var i = 0; i < HB_TOWNS.length; i++) if (HB_TOWNS[i][0].test(s)) return HB_TOWNS[i][1]; return ''; }
      var youPicks = Object.keys(homeOf).map(function (k) { return homeOf[k]; });""", "function hbStateOfName(s)")
sub("""          if (there.length === 1) { a.home = propHome(there[0]).id; a.by = 'property'; return; }
          if (there.length > 1) { a.home = ''; return; }""",
    """          if (there.length === 1) { a.home = propHome(there[0]).id; a.by = 'property'; return; }
          if (there.length > 1) {
            // (several: the one you already put a connection in, when it is one)
            var used = there.filter(function (p) { return youPicks.indexOf('p:' + p.id) >= 0; });
            if (used.length === 1) { a.home = propHome(used[0]).id; a.by = 'property'; return; }
            a.home = ''; return;
          }""", "(several: the one you already put a connection in")
sub("""        // (a town home already in that state, found by an address, takes them: the state's one home)
        var towns = homes.filter(function (h) { return /^t:/.test(h.id) && h.state === st; });""",
    """        // (a home you named for a town in that state takes them: "Pune Godrej" for MSEDCL and MNGL)
        var mine = Object.keys(userHomes).filter(function (id) { return hbStateOfName(userHomes[id].name + ' ' + (userHomes[id].place || '')).toLowerCase() === st.toLowerCase(); });
        if (mine.length === 1) {
          list.forEach(function (a) {
            if (kinds[a.k] > 1) return;
            var uh = userHomes[mine[0]];
            a.home = homeFor(mine[0], function () { return { name: uh.name, place: uh.place || '', state: st, pin: '' }; }).id; a.by = 'state';
          });
          return;
        }
        // (a town home already in that state, found by an address, takes them: the state's one home)
        var towns = homes.filter(function (h) { return /^t:/.test(h.id) && h.state === st; });""", "(a home you named for a town in that state takes them")
open(p, 'w').write(s)
print('engine C homes')
