import Foundation

/// an order's mixed share filed by itself (fb 2 Nov): once per payment, past and new
@MainActor
enum AutoSplit {
    static let key: String = "autosplit.done"
    static func apply(_ store: Store) {
        guard let live = store.live else { return }
        var done: Set<String> = Set(UserDefaults.standard.stringArray(forKey: key) ?? [])
        var changed: Bool = false
        for t in store.snap.tx {
            guard let m = t.mix, t.partOf == nil, t.full == nil, !done.contains(t.id), m.c != t.c else { continue }
            // (a payment you filed or split yourself is yours)
            if let o = live.overrides[t.id], o.c == m.c || !(o.parts ?? []).isEmpty { done.insert(t.id); changed = true; continue }
            done.insert(t.id); changed = true
            let s: String = m.s ?? ""
            if m.all == true {
                live.override(t.id) { o in o.c = m.c; o.s = s; o.by = "kosh"; o.only = Store.with(o.only, "c") }
            } else if m.g > 0 && m.g < t.a {
                store.splitOut(t.id, amount: (m.g * 100).rounded() / 100, c: m.c, s: s, refunded: false)
            }
        }
        if changed {
            UserDefaults.standard.set(Array(done), forKey: key)
            live.rebuildSoon()
        }
    }
}

/// what a split's rows are, in words
@MainActor
enum SplitWords {
    /// "Yogabar 26% High Protein Oats 1kg, Pack of 3" → "Yogabar 26% High Protein Oats 1kg"
    static func short(_ n: String) -> String {
        var s: String = n.components(separatedBy: CharacterSet(charactersIn: ",(|")).first ?? n
        s = s.trimmingCharacters(in: .whitespaces)
        return s.count > 34 ? String(s.prefix(32)).trimmingCharacters(in: .whitespaces) + "…" : s
    }
    static func key(_ n: String) -> String { String(n.lowercased().filter { $0.isLetter || $0.isNumber }.prefix(20)) }
    /// the part: "Split from ₹2,619 · Yogabar oats, rice paper sheets"
    static func part(_ t: Txn, _ store: Store) -> String {
        guard let pid = t.partOf, let p = store.txn(pid) else { return "Split out of a bigger charge" }
        let whole: Double = p.full ?? (p.a + t.a)
        var s: String = "Split from " + Fmt.rupees(whole)
        if let names = p.mix?.n, !names.isEmpty, p.mix?.c == t.c { s += " · " + names.map { short($0) }.joined(separator: ", ") }
        return s
    }
    /// the rest of a split order: what else it held
    static func rest(_ t: Txn, _ store: Store) -> String? {
        guard let names = t.mix?.n, !names.isEmpty, let items = store.payFact(t)?.items, !items.isEmpty else { return nil }
        let out: Set<String> = Set(names.map { key($0) })
        let rest: [String] = items.map { $0.n }.filter { !out.contains(key($0)) }.map { short($0) }
        guard !rest.isEmpty else { return nil }
        return "With it: " + rest.prefix(3).joined(separator: ", ") + (rest.count > 3 ? " +" + String(rest.count - 3) : "")
    }
}
