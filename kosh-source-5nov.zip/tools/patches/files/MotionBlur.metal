// smooth-5nov-c: the day lens's motion blur. A horizontal streak, `length` points long, as the days rush past:
// nine taps along x weighted to the middle. Used on the day strip alone (DayLens.swift, LensStrip), and only while it
// moves fast enough to need it; at rest it's off and the strip draws as before.
#include <metal_stdlib>
#include <SwiftUI/SwiftUI_Metal.h>
using namespace metal;

[[ stitchable ]] half4 kMotionBlur(float2 position, SwiftUI::Layer layer, float length) {
    half4 sum = half4(0.0h);
    float wsum = 0.0;
    for (int i = -4; i <= 4; i++) {
        float t = float(i) / 4.0;
        float w = 1.0 - abs(t) * 0.55;
        sum += layer.sample(position + float2(t * length * 0.5, 0.0)) * half(w);
        wsum += w;
    }
    return sum / half(wsum);
}
