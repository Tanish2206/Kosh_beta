#!/usr/bin/env python3
"""smsbal-5nov (kosh ios app chat): a bank SMS that prints the account's balance ("Avl bal INR 1,23,456.78",
"Bal: Rs.1,234.56", "Available bal: INR 2,345.00") is a live balance point for that account, as a bank's alert mail
already is (withBalance): the moment the SMS says, after its own payment. With it the live balance resets to the bank's
own figure on every SMS, so a payment kosh never heard of (a transfer in with no credit mail) can't leave it wrong past
the next SMS. A card's available LIMIT is never a balance; an account named by no digits gets none. Idempotent."""
import sys
def patch(p, pairs, marker):
    s = open(p, encoding='utf-8').read()
    if marker in s: print(p, 'already'); return
    for a, b in pairs:
        if s.count(a) != 1: sys.exit('%s anchor %d: %r' % (p, s.count(a), a[:60]))
        s = s.replace(a, b)
    open(p, 'w', encoding='utf-8').write(s); print(p, 'patched')
patch('Kosh/engine.js', [
 ("""      Object.assign(out, { rule: 'sms-acct-' + dir, instr: 'account', last4: last4(am[1]) || am[1], mode: mode });
    } else {""",
  """      Object.assign(out, { rule: 'sms-acct-' + dir, instr: 'account', last4: last4(am[1]) || am[1], mode: mode });
      // (smsbal-5nov) the balance the SMS prints is the account's, right after this payment
      if (out.instKind === 'bank' && out.last4) {
        var bm5 = BAL_RE.exec(flat) || BAL_BARE.exec(flat);
        if (bm5 && !/(?:limit|lmt)\\s*$/i.test(flat.slice(Math.max(0, bm5.index - 12), bm5.index))) {
          var bv5 = num(bm5[1]);
          if (bm5[2] && /dr/i.test(bm5[2])) bv5 = -bv5;
          if (isFinite(bv5) && !(bv5 === 0 && /\\bcombined available balance\\s*:?\\s*(?:inr|rs\\.?|\\u20b9)\\s*[1-9]/i.test(flat))) { out.bal = bv5; out.balAt = date + (time ? 'T' + time : ''); }
        }
      }
    } else {"""),
], 'smsbal-5nov')
# (b) the payer as a name, not the rail's words: "NEFT from SUNIL BHUTANI" -> "SUNIL BHUTANI", never a bare "UPI"
patch('Kosh/engine.js', [
 ("""    s = String(s || '').replace(/\\s+/g, ' ').trim();
    // never a sentence's start, the user's own account or a bank's own words""",
  """    s = String(s || '').replace(/\\s+/g, ' ').trim();
    s = s.replace(/^(?:(?:by|via|thru|through)\\s+)?(?:(?:neft|imps|rtgs|upi)\\s+)?(?:(?:transfer|trf)\\s+)?(?:from|by)\\s+/i, '').trim();   // (smsbal-5nov-b)
    if (/^(?:upi|neft|imps|rtgs|transfer|trf|interest|deposit)$/i.test(s)) s = '';
    // never a sentence's start, the user's own account or a bank's own words"""),
], 'smsbal-5nov-b')
