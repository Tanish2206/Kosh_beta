# kosh feedback 1 Nov (22:42) — engine, part E: a motor policy's vehicle. Acko's "Your Bike Insurance Policy for
# Triumph Scrambler 400 X" prints "Make/Model: Triumph Scrambler 400 X" and its registration nowhere: the reader keeps
# the make and model (a "Make/Model", "Vehicle", "Model" field, else the subject's "Policy for <vehicle>"), the policy
# keeps it as `model`, and its vehicle carries it. Idempotent.
def sub(path, old, new, mark):
    s = open(path).read()
    if mark in s: return
    assert s.count(old) == 1, (path, old[:70], s.count(old))
    open(path, 'w').write(s.replace(old, new))
sub('Kosh/reader.js', """    // (LIC's "Plan | 914" is the plan's number, not its name)""",
    """    // a motor policy's vehicle, by its make and model ("Make/Model: Triumph Scrambler 400 X"), else the subject's
    // "Policy for <vehicle>"
    var mm = kv(doc, /^(?:make\\s*(?:\\/|&|and)\\s*model|vehicle(?: make(?:\\s*(?:\\/|&|and)\\s*model)?| model| name)?|model|make)$/);
    if (mm && /[a-z]{2}/i.test(mm.value) && !/^\\s*(?:no|number|registration)\\b/i.test(mm.value)) ev.model = trim(String(mm.value).replace(/\\s*\\|.*$/, '')).slice(0, 50);
    else if ((m = /\\b(?:bike|car|two[- ]wheeler|motor|vehicle|auto)\\s+insurance(?:\\s+policy)?\\s+for\\s+(?:your\\s+)?([A-Z][A-Za-z0-9 .+\\-]{2,40}?)\\s*(?:[-|:]|$)/i.exec(doc.subject || ''))) ev.model = trim(m[1]);
    // (LIC's "Plan | 914" is the plan's number, not its name)""", 'a motor policy\'s vehicle, by its make and model')
sub('Kosh/engine.js', """        var vh = regOf(pe.vehicle) || regOf(pe.plan);
        if (vh && !hit.vehicle) hit.vehicle = vh;""", """        var vh = regOf(pe.vehicle) || regOf(pe.plan);
        if (vh && !hit.vehicle) hit.vehicle = vh;
        // (its make and model, as its mail names it)
        if (pe.model && !hit.model) hit.model = String(pe.model).slice(0, 50);""", '(its make and model, as its mail names it)')
sub('Kosh/engine.js', """      if (cur.cover > 0) v.idv = cur.cover;""", """      if (cur.cover > 0) v.idv = cur.cover;
      var vm = g.map(function (p) { return p.model; }).filter(Boolean)[0];
      if (vm) v.model = vm;""", "if (vm) v.model = vm;")
print('engine E patched')
sub('Kosh/engine.js', """      plist = plist.filter(function (q) { return !q.gone; });
    })();""", """      plist = plist.filter(function (q) { return !q.gone; });
      // (a motor policy's vehicle, from any of its mails' readings: "Make/Model: Triumph Scrambler 400 X")
      plist.forEach(function (q) {
        if (q.model) return;
        (q.mails || []).some(function (m) {
          var r = recOf[m.id], evs = [];
          try { evs = r && typeof r.evs === 'string' ? JSON.parse(r.evs) : []; } catch (e) { evs = []; }
          var hit = evs.filter(function (e) { return e && e.type === 'policy' && e.model; })[0];
          if (hit) q.model = String(hit.model).slice(0, 50);
          return !!hit;
        });
      });
    })();""", "(a motor policy's vehicle, from any of its mails' readings")
sub('Kosh/engine.js', """        maturity: q.maturity || 0, fundValue: q.fundValue || 0, fundAsOf: q.fundAsOf || '',
        paidN: sch.paidN,""", """        maturity: q.maturity || 0, fundValue: q.fundValue || 0, fundAsOf: q.fundAsOf || '', model: q.model || undefined,
        paidN: sch.paidN,""", "model: q.model || undefined,")
