# kosh feedback 2 Nov (02:21) — Swift, part Z: Up close says each thing once. "How you shop" repeated the bars above it
# (the same kinds, the same shops, the same shares); what it added (how often, the usual spend, the last thing bought)
# now sits in each bar's own line ("Myntra, Meesho · every ~7 days · usually ₹1.5k"), the last thing bought in the
# row opened, and the separate card is gone. Idempotent.
p = 'Kosh/InsightsBook.swift'; s = open(p).read()
old = """        let parts: [CategoryDive.Part] = lens == "subs"
            ? CategoryDive.parts(rows, by: { CategoryDive.kind($0, cat: cat) }, caption: { CategoryDive.place($0) })
            : CategoryDive.parts(rows, by: { CategoryDive.place($0) }, caption: { CategoryDive.kind($0, cat: cat) })"""
new = """        let parts0: [CategoryDive.Part] = lens == "subs"
            ? CategoryDive.parts(rows, by: { CategoryDive.kind($0, cat: cat) }, caption: { CategoryDive.place($0) })
            : CategoryDive.parts(rows, by: { CategoryDive.place($0) }, caption: { CategoryDive.kind($0, cat: cat) })
        let parts: [CategoryDive.Part] = cat == "Shopping" && lens == "subs" ? BuyPattern.enrich(parts0, BuyPattern.over(rows, store: store)) : parts0"""
if 'BuyPattern.enrich(parts0' not in s:
    assert s.count(old) == 1, 'parts anchor'
    s = s.replace(old, new)
old = """                    if cat == "Shopping" {
                        let buys: [BuyPattern] = BuyPattern.over(rows, store: store)
                        if !buys.isEmpty {
                            HowYouShop(buys: buys, color: color, ink: ink, today: store.snap.today, span: BuyPattern.spanWords(look.months.count))
                                .padding(.top, 18)
                        }
                    }"""
if old in s:
    s = s.replace(old, """                    // (how you shop: in each bar's own line above, never a second list of the same kinds)""")
if 'static func enrich(' not in s:
    s += '''

extension BuyPattern {
    /// each kind's bar line with its rhythm and usual spend: "Myntra, Meesho · every ~7 days · usually ₹1.5k"
    static func enrich(_ parts: [CategoryDive.Part], _ buys: [BuyPattern]) -> [CategoryDive.Part] {
        let by: [String: BuyPattern] = Dictionary(buys.map { ($0.k, $0) }, uniquingKeysWith: { a, _ in a })
        return parts.map { (p: CategoryDive.Part) -> CategoryDive.Part in
            guard let b = by[p.name], b.n > 1 else { return p }
            var q = p
            var bits: [String] = p.sub.isEmpty ? [] : [p.sub]
            if let r = b.rhythm { bits.append(r) }
            bits.append("usually " + Fmt.short(b.usual))
            q.sub = bits.joined(separator: " · ")
            return q
        }
    }
}
'''
open(p, 'w').write(s)
print('swift Z patched')
