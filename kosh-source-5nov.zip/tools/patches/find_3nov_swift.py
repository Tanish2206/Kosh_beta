#!/usr/bin/env python3
"""Find rebuilt + crash reports (3 Nov 2026). Idempotent.
- FindPremium.swift (tools/patches/files): Find as one scrolling page instead of a List (the List crashed when a
  payment's sheet opened over "cred" results): filter bar with a Filters count, recent / shortcuts / payees you pay most /
  this month by category; results as a summary card with six months of bars, the payees found, payments by month under
  sticky headers, sort, long-press actions; nothing found says which filter to take off. LedgerFind.swift keeps the
  query, filters and chips; its old LedgerFind view is taken out.
- CrashWatch.swift: MetricKit crash reports kept (latest 5) and put in the diagnostics file ("crashes")."""
import pathlib, shutil, sys
ROOT = pathlib.Path(__file__).resolve().parents[2]; K = ROOT / 'Kosh'
for f in ['FindPremium.swift', 'CrashWatch.swift']: shutil.copyfile(ROOT / 'tools/patches/files' / f, K / f)
p = K / 'LedgerFind.swift'; s = p.read_text()
if 'struct LedgerFind: View {' in s:
    a = s.index('struct LedgerFind: View {'); b = s.index('/// "34 payments · ₹12,340 out · +₹2,000 in"')
    p.write_text(s[:a] + '// (LedgerFind itself: FindPremium.swift, 3 Nov)\n\n' + s[b:])
p = K / 'LiveSession+Extras.swift'; s = p.read_text()
a = '                x.head["autonote"] = UserDefaults.standard.string(forKey: "autonote.debug") ?? "none"\n'
if 'CrashWatch.reports()' not in s:
    if s.count(a) != 1: sys.exit('find_3nov_swift: anchor missing (LiveSession+Extras)')
    p.write_text(s.replace(a, a + '                x.head["crashes"] = CrashWatch.reports()\n'))
p = K / 'KoshApp.swift'; s = p.read_text()
a = '        Notify.shared.store = s\n'
if 'CrashWatch.shared.start()' not in s:
    if s.count(a) != 1: sys.exit('find_3nov_swift: anchor missing (KoshApp)')
    p.write_text(s.replace(a, a + "        // kosh's own crash reports, from iOS on the next launch, for the diagnostics (CrashWatch.swift)\n        CrashWatch.shared.start()\n", 1))
print('find_3nov_swift: applied')
