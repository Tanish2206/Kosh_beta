# kosh feedback 2 Nov (02:00) — engine, part O: an order that won't arrive is money to come back. A shop's or courier's
# mail that a delivery failed and the parcel is going back, that it was returned to the seller (RTO), or that the order
# was cancelled, is the shop's word that its money comes back, even when it names no sum: a promise for the order's
# total (its mail's, else the payment that bought it), so it waits under Expected back, is set against the payment
# when the credit comes, and is said late as any promise is. Idempotent.
p = 'Kosh/engine.js'; s = open(p).read()
def sub(old, new, mark):
    global s
    if mark in s: return
    assert s.count(old) == 1, ('engine O anchor', old[:70], s.count(old))
    s = s.replace(old, new)
sub("""              out.orderOn.push({ id: r.id, oid: k });
              if (e.status === 'refunded' && !out.sent[k]) out.sent[k] = { d: d, mail: r.id };
              return;""", """              out.orderOn.push({ id: r.id, oid: k });
              if (+e.total > 0) (out.totals = out.totals || {})[k] = +e.total;
              if (e.status === 'refunded' && !out.sent[k]) out.sent[k] = { d: d, mail: r.id };
              // (it won't arrive: cancelled, returned to the seller, a delivery that failed for good)
              var sj0 = String(r.subject || '');
              var gone0 = /^(?:cancelled|canceled|rto|returned)$/.test(String(e.status || '')) ||
                /\\b(?:order (?:has been |was |is )?cancel(?:l)?ed|cancel(?:l)?ation (?:confirmed|successful)|returned to (?:the )?(?:seller|origin|sender)|\\brto\\b|could not be delivered|undelivered|delivery (?:has )?failed|unable to deliver|being returned)\\b/i.test(sj0);
              if (gone0 && !out.promises.some(function (q) { return q.oid === k; })) {
                out.promises.push({ mail: r.id, d: d, amt: +e.total > 0 ? money(+e.total) : 0, by: '', oid: k, order: String(e.order), party: e.shop || '', from: r.from || '',
                  q: sj0.slice(0, 160), sent: false, to: null, other: false, owner: inboxOf(r), wontArrive: true });
              }
              return;""", "(it won't arrive: cancelled, returned to the seller")
sub("""        out.promises.sort(function (a, b) { return a.d.localeCompare(b.d) || String(a.mail).localeCompare(String(b.mail)); });
        return out;""", """        // (an order that won't arrive with no sum in its mail: what the payment of that order cost)
        out.promises.forEach(function (q) {
          if (q.amt > 0 || !q.wontArrive) return;
          if (out.totals && out.totals[q.oid] > 0) { q.amt = money(out.totals[q.oid]); return; }
          var t = tx.filter(function (x) { return x.dirRaw === 'out' && !x.partOf && orderKey(x.orderId) === q.oid; })[0];
          if (t) q.amt = money(t.full !== undefined ? t.full : t.a);
        });
        out.promises = out.promises.filter(function (q) { return q.amt > 0; });
        out.promises.sort(function (a, b) { return a.d.localeCompare(b.d) || String(a.mail).localeCompare(String(b.mail)); });
        return out;""", "(an order that won't arrive with no sum in its mail")
open(p, 'w').write(s)
print('engine O patched')
