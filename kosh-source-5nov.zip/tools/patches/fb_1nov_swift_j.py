# kosh feedback 1 Nov (21:06) — Swift, part J: "Whose rent is it?" as a proper list, not ragged grey pills: one row per
# tenant (their initial in the rent colour, name, floor · property), kosh's likely tenant first and marked (the payer's
# name carries the tenant's), and "Someone else" as the list's last row. Idempotent.
p = 'Kosh/RentTag.swift'; s = open(p).read()
OLD = """                    Text("Whose rent is it?").font(.body.weight(.semibold))
                    if !places.isEmpty {
                        WrapRow(spacing: 8, lineSpacing: 8) {
                            ForEach(places) { p in
                                Button { withAnimation(Motion.base) { store.tagRent(t.id, p) } } label: { chip(p.title, sub: p.detail) }
                                    .buttonStyle(.press)
                                    .accessibilityLabel("Rent from " + p.title + ", " + p.detail)
                            }
                        }
                    }
                    if adding { addForm } else {
                        Button {
                            rentText = Fmt.trim(t.a, 2); propId = store.live?.properties.first?.id
                            withAnimation(Motion.open) { adding = true }
                            nameFocus = true
                        } label: {
                            Label(places.isEmpty ? "Add the tenant" : "Someone else", systemImage: "plus")
                                .font(.subheadline.weight(.semibold))
                                .padding(.horizontal, 12)
                                .frame(minHeight: 34)
                                .overlay(Capsule().strokeBorder(Color.kosh.opacity(0.4), lineWidth: 1))
                        }
                        .buttonStyle(.press)
                        .foregroundStyle(Color.kosh)
                    }"""
NEW = """                    VStack(alignment: .leading, spacing: 2) {
                        Text("Whose rent is it?").font(.body.weight(.semibold))
                        Text(Fmt.rupees(t.a) + " from " + t.m).font(.footnote).foregroundStyle(.secondary).lineLimit(1).privacySensitive()
                    }
                    let ranked: [RentPlace] = RentFrom.ranked(places, payer: t.m)
                    let likely: String? = RentFrom.likely(places, payer: t.m)?.key
                    VStack(spacing: 0) {
                        ForEach(Array(ranked.enumerated()), id: \\.element.id) { i, p in
                            if i > 0 { Divider().padding(.leading, 58) }
                            Button { withAnimation(Motion.base) { store.tagRent(t.id, p) } } label: {
                                RentPlaceRow(p: p, tint: store.catColor("Rent received"), likely: p.key == likely)
                            }
                            .buttonStyle(.press)
                            .accessibilityLabel("Rent from " + p.title + ", " + p.detail + (p.key == likely ? ", likely" : ""))
                        }
                        if !adding {
                            if !ranked.isEmpty { Divider().padding(.leading, 58) }
                            Button {
                                rentText = Fmt.trim(t.a, 2); propId = store.live?.properties.first?.id
                                withAnimation(Motion.open) { adding = true }
                                nameFocus = true
                            } label: {
                                HStack(spacing: 14) {
                                    Image(systemName: "plus").font(.system(size: 14, weight: .bold)).foregroundStyle(Color.kosh)
                                        .frame(width: 36, height: 36)
                                        .background(Color.kosh.opacity(0.12), in: Circle())
                                    Text(places.isEmpty ? "Add the tenant" : "Someone else").font(.body.weight(.medium)).foregroundStyle(Color.kosh)
                                    Spacer(minLength: 0)
                                }
                                .padding(.vertical, 10)
                                .contentShape(Rectangle())
                            }
                            .buttonStyle(.press)
                        }
                    }
                    .padding(.horizontal, 12)
                    .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                    if adding { addForm }"""
if 'RentPlaceRow(p: p' not in s:
    assert s.count(OLD) == 1, 'RentFrom anchor'
    s = s.replace(OLD, NEW)
if 'struct RentPlaceRow' not in s:
    s += '''

extension RentFrom {
    /// the tenant the payer's own name points to: a word of the tenant's name (four letters or more) in the payer's
    /// ("MAGELLAN TELESERVIC" → Magellan); none when it points to two
    static func likely(_ places: [RentPlace], payer: String) -> RentPlace? {
        let pay: Set<String> = Set(payer.lowercased().split(whereSeparator: { !$0.isLetter }).map(String.init).filter { $0.count >= 4 })
        let hits: [RentPlace] = places.filter { p in
            p.tenant.lowercased().split(whereSeparator: { !$0.isLetter }).map(String.init).contains { $0.count >= 4 && pay.contains($0) }
        }
        return hits.count == 1 ? hits[0] : nil
    }
    /// the likely one first, the rest as they are
    static func ranked(_ places: [RentPlace], payer: String) -> [RentPlace] {
        guard let l = likely(places, payer: payer) else { return places }
        return [l] + places.filter { $0.key != l.key }
    }
}

/// one tenant to pick: their initial in the rent colour, their name, the floor and property; kosh's likely one marked
struct RentPlaceRow: View {
    let p: RentPlace
    let tint: Color
    let likely: Bool
    var body: some View {
        HStack(spacing: 14) {
            Text(String(p.title.prefix(1)).uppercased())
                .font(.system(size: 15, weight: .semibold, design: .rounded))
                .foregroundStyle(Color.black.opacity(0.75))
                .frame(width: 36, height: 36)
                .background(tint.opacity(likely ? 1 : 0.55), in: Circle())
            VStack(alignment: .leading, spacing: 2) {
                HStack(spacing: 6) {
                    Text(p.title).font(.body.weight(.semibold)).foregroundStyle(Color.primary).lineLimit(1)
                    if likely {
                        Text("Likely").font(.caption2.weight(.bold)).foregroundStyle(Color.kosh)
                            .padding(.horizontal, 7).padding(.vertical, 2)
                            .background(Color.kosh.opacity(0.12), in: Capsule())
                    }
                }
                Text(p.detail).font(.footnote).foregroundStyle(.secondary).lineLimit(1)
            }
            Spacer(minLength: 6)
            Image(systemName: "chevron.right").font(.caption.weight(.bold)).foregroundStyle(.tertiary)
        }
        .padding(.vertical, 10)
        .contentShape(Rectangle())
        .privacySensitive()
    }
}
'''
open(p, 'w').write(s)
print('swift J patched')
