#!/usr/bin/env python3
"""Speed (2 Nov 2026): engine.js factsOf compiles each fact's pattern once (was once per cell per fact) and marks
the password lines once per mail (was a 9-line rescan per line). Same output on all 3,416 corpus mails. Idempotent."""
import pathlib, sys
p = pathlib.Path(__file__).resolve().parents[2] / 'Kosh' / 'engine.js'
s = p.read_text()
R = [
 ("""      if (lines.slice(Math.max(0, li - 4), li + 5).some(function (l) { return /(?:^|\\|)\\s*(?:your\\s+)?password\\s*:?\\s*(?:\\||$)/i.test(String(l || '')); })) continue;""",
  """      if (pwNear(li)) continue;"""),
 ("""    var out = [], seen = {}, exampleTill = -1;
    function put(def, label, raw, li, ctx) {""",
  """    var out = [], seen = {}, exampleTill = -1;
    // (the lines that show a password, marked once: a line within four of one is skipped)
    var pwAt = [];
    for (var pi = 0; pi < lines.length; pi++) if (/(?:^|\\|)\\s*(?:your\\s+)?password\\s*:?\\s*(?:\\||$)/i.test(String(lines[pi] || ''))) pwAt.push(pi);
    function pwNear(i) { for (var k = 0; k < pwAt.length; k++) if (pwAt[k] >= i - 4 && pwAt[k] <= i + 4) return true; return false; }
    function put(def, label, raw, li, ctx) {"""),
 ("""          var def = FACT_DEFS[di], re = new RegExp(def.l.source, 'gi'), m;""",
  """          var def = FACT_DEFS[di], re = def._re || (def._re = new RegExp(def.l.source, 'gi')), m;
          re.lastIndex = 0;"""),
]
n = 0
for a, b in R:
    if b in s: continue
    if a not in s: sys.exit('perf_2nov_engine: anchor missing: ' + a[:60])
    s = s.replace(a, b, 1); n += 1
p.write_text(s); print('perf_2nov_engine:', n, 'applied')

# 2: style rules stripped by one pass over the "{"s (the pattern tried up to 80 characters at every position of the
# text); the same matches: a run of up to 80 selector characters right before a "{", whose body has a ":" before
# its "}" and no "{" in between
s = p.read_text()
a = """    if (s.indexOf('{') >= 0) s = s.replace(/[\\w.#@:,>*\\- ]{1,80}\\{[^{}:]*:[^{}]*\\}/g, ' ');"""
b = """    if (s.indexOf('{') >= 0) s = stripStyleRules(s);"""
f = """  function normalizeOnce(text, html) {"""
fn = """  var STYLE_SEL = /[\\w.#@:,>*\\- ]/;
  function stripStyleRules(s) {
    var out = '', from = 0, b = s.indexOf('{');
    while (b >= 0) {
      var p = b;
      while (p > from && b - p < 80 && STYLE_SEL.test(s.charAt(p - 1))) p--;
      var j = b + 1, colon = false;
      while (j < s.length && s.charAt(j) !== '{' && s.charAt(j) !== '}') { if (s.charAt(j) === ':') colon = true; j++; }
      if (p < b && colon && s.charAt(j) === '}') { out += s.slice(from, p) + ' '; from = j + 1; b = s.indexOf('{', from); }
      else b = s.indexOf('{', b + 1);
    }
    return out + s.slice(from);
  }
  function normalizeOnce(text, html) {"""
if b not in s:
    if a not in s: sys.exit('perf_2nov_engine: style anchor missing')
    s = s.replace(a, b, 1).replace(f, fn, 1); p.write_text(s); print('perf_2nov_engine: style rules applied')
