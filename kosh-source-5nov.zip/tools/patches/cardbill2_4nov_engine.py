#!/usr/bin/env python3
"""cardbill2-4nov, on top of cardbill-4nov: card bills read right off the texts the PHONE keeps (diag stmtTexts), and the
statement picked, not a leaflet riding with it.
 - stmtpick: a mail with several PDFs opens the statement, never "Most Important Terms & Conditions.pdf" (HSBC cards,
   every month since Oct 2025) or "Important_Notes.pdf" (HSBC savings): docLeaflet(file); docLeafletJSON for the app.
 - a label inside a sentence is not a label ("Nil if total payment due is upto Rs 500": Axis read a ₹500 bill).
 - a row of labels over a row of figures, matched in order by kind (PDFKit's text of Axis's box: no columns).
 - the total by its label, checked against the summary's equation: a label figure the equation doesn't carry gives way.
 - the grid first, then the text (a garbled grid never hides the text's reading).
Idempotent."""
import sys, io
P = sys.argv[1] if len(sys.argv) > 1 else 'Kosh/engine.js'
s = io.open(P, encoding='utf-8').read()
if 'cardbill2-4nov' in s:
    print('already applied'); sys.exit(0)
assert 'cardbill-4nov' in s, 'cardbill_4nov_engine.py first'
def rep(old, new, n=1):
    global s
    assert s.count(old) == n, (s.count(old), old[:80])
    s = s.replace(old, new)

# 1. prose, labels in a row, values in a row
rep("  function cbCells(line) {",
r'''  /* cardbill2-4nov: a label inside a sentence is the terms talking, not the summary box ("Nil if total payment due is
     upto Rs 500", "MISSED PAYMENT OF MINIMUM AMOUNT DUE WITHIN 3 GRACE DAYS") */
  function cbProse(line) {
    var s = String(line || '');
    // (the summary's own equation, "Previous Balance - Payments ... =Total Payment Due", is not a label either)
    if (/=/.test(s) && /\s[+\-]\s/.test(s)) return true;
    return s.trim().split(/\s+/).length > 8 && /\b(?:if|is|are|was|upto|up to|than|between|will|would|shall|should|reach(?:es)?|within|not|may|must|ensure|please|avoid|levied|charged|reported|applicable)\b/i.test(s);
  }
  /* a reading whose letters came out jumbled (the phone's rows rebuilt from glyph boxes, and its grid, on many bank PDFs
     as of 4 Nov: "MRIDUL BHUTA   L.COMCredit C   od"): one word in eleven or more a lone letter. No bill is read off it */
  function cbGarbled(text) {
    // (a line of a barcode's or QR code's glyphs, "ë­ÉÉÉ­ëláÏpª ÒÕ®×", is no reading at all: left out)
    var ws = String(text || '').split('\n').slice(0, 150).filter(function (l) { return (l.match(/[^\x00-\x7f₹’‘“”–—•`]/g) || []).length <= l.length * 0.2; }).join('\n').match(/[A-Za-z]+/g) || [];
    return ws.length >= 40 && ws.filter(function (w) { return w.length === 1; }).length / ws.length > 0.08;
  }
  function cbGridGarbled(G) {
    var n = 0, one = 0;
    (G || []).slice(0, 300).forEach(function (l) { l.w.forEach(function (w) { if (/^[\x20-\x7e₹]+$/.test(w.t) && /[A-Za-z]/.test(w.t)) { n++; if (/^[A-Za-z]$/.test(w.t)) one++; } }); });
    return n >= 40 && one / n > 0.08;
  }
  // the labels a line prints, in order, each with the kind of figure it takes
  var CB_PERIOD = /\b(?:statement|billing)\s+(?:period|cycle)\b/i;
  function cbLabels(ln) {
    var found = [];
    [['total', CB_TOTAL, 'amt'], ['min', CB_MIN, 'amt'], ['due', CB_DUE, 'day'], ['on', CB_STMT, 'day'], ['period', CB_PERIOD, 'period']].forEach(function (L) {
      var re = new RegExp(L[1].source, 'gi'), m;
      while ((m = re.exec(ln))) { found.push({ k: L[0], t: L[2], a: m.index, b: m.index + m[0].length }); if (!m[0].length) re.lastIndex++; }
    });
    found.sort(function (x, y) { return x.a - y.a || (y.b - y.a) - (x.b - x.a); });
    var out = [];
    found.forEach(function (f) { if (!out.length || f.a >= out[out.length - 1].b) out.push(f); });
    return out;
  }
  // the figures a line prints, in order: a period (a day, a dash, a day), a day, an amount
  function cbValues(line) {
    var out = [], rest = String(line || ''), m;
    var PR = new RegExp(CB_DAY.source + '\\s*(?:-|to|till)\\s*' + CB_DAY.source, 'gi');
    while ((m = PR.exec(line))) {
      var d2 = stmtDate(m[2], null);
      if (stmtDate(m[1], null) && d2) { out.push({ t: 'period', v: d2, a: m.index }); rest = rest.slice(0, m.index) + m[0].replace(/./g, ' ') + rest.slice(m.index + m[0].length); }
    }
    cbTokens(rest, 'day').forEach(function (t) { out.push({ t: 'day', v: t.v, a: t.a }); });
    cbTokens(rest, 'amt').forEach(function (t) { out.push({ t: 'amt', v: t.v, cr: t.cr, a: t.a }); });
    return out.sort(function (x, y) { return x.a - y.a; });
  }
  // a row of labels over the row of figures under them (a summary box, its columns lost: "Total Payment Due Minimum
  // Payment Due Statement Period Payment Due Date Statement Generation Date" over "164,396.43 Dr 3,288.00 Dr" and
  // "03/10/2026 - 01/11/2026 21/11/2026 01/11/2026"): taken only when every figure is the kind its label takes
  function cbRowMap(lines) {
    for (var i = 0; i < lines.length; i++) {
      if (cbProse(lines[i])) continue;
      var L = cbLabels(lines[i]);
      if (L.length < 2 || cbValues(lines[i]).length) continue;
      var vals = [], used = 0;
      for (var j = i + 1; j < lines.length && j <= i + 4 && used < 3; j++) {
        var v = cbValues(lines[j]);
        if (!v.length) { if (vals.length) break; continue; }
        vals = vals.concat(v); used++;
        if (vals.length === L.length) {
          if (vals.every(function (x, n) { return x.t === L[n].t; })) { var o = {}; L.forEach(function (l, n) { if (!o[l.k]) o[l.k] = vals[n]; }); return o; }
          break;
        }
        if (vals.length > L.length) break;
      }
    }
    return null;
  }
  function cbCells(line) {''')

# 2. prose skip in the text finder (both passes) and the grid finder
rep('''      var ln = lines[i], m = label.exec(ln);
      if (!m) continue;
      var a = m.index, b = m.index + m[0].length, got;''',
'''      var ln = lines[i], m = label.exec(ln);
      if (!m || cbProse(ln)) continue;
      var a = m.index, b = m.index + m[0].length, got;''')
rep('''      if (!label.exec(lines[q])) continue;
      for (var n = q + 1; n <= q + 12 && n < lines.length; n++) { var tk = pick(cbTokens(lines[n], what)); if (tk) return tk; }''',
'''      if (!label.exec(lines[q]) || cbProse(lines[q])) continue;
      // (cardbill2-4nov) labels stacked one a line over their figures ("TOTAL AMOUNT DUE / MINIMUM DUE / DUE DATE /
      // C1,070.00 / 21 Nov"): another label taking the same kind of figure before one comes means the order is not
      // the labels', so nothing is taken this way
      var same = what === 'day' ? [CB_DUE, CB_STMT] : [CB_TOTAL, CB_MIN];
      for (var n = q + 1; n <= q + 12 && n < lines.length; n++) {
        var tk = pick(cbTokens(lines[n], what)); if (tk) return tk;
        if (same.some(function (re) { return re.test(lines[n]); })) break;
      }''')
rep('''        var cell = R[i].c[k], m = label.exec(cell.t), got;
        if (!m) continue;''', '''        var cell = R[i].c[k], m = label.exec(cell.t), got;
        if (!m || cbProse(R[i].c.map(function (c) { return c.t; }).join(' '))) continue;''')

# 3. cardBillOf: the row map first; grid then text; the label's total checked against the equation
rep('''    var head = lines.slice(0, 60), st = (G ?''', '''    if (cbGarbled(text)) return null;   // cardbill2-4nov
    if (G && cbGridGarbled(G)) G = null;
    var rm = cbRowMap(lines);
    var head = lines.slice(0, 60), stOk = function (t) { return !to || Math.abs(daysBetween(to, t.v)) <= 10; };
    var st = (rm && rm.on && stOk(rm.on) ? rm.on : null) || cbFind(head, CB_STMT, 'day', stOk) || (G ?''')
rep('''    var find = function (label, what, ok) { return (R && cbGridFind(R, label, what, ok)) || (R ? null : cbFind(lines, label, what, ok)); };''',
'''    // (cardbill2-4nov) by position when the grid is whole, else by the labels in the text (a grid whose letters came out
    // jumbled was set aside above); a row of labels over a row of figures (rm) before a label's nearest figure
    var find = function (label, what, ok) { return (R && cbGridFind(R, label, what, ok)) || cbFind(lines, label, what, ok); };''')
rep('''    var tt = find(CB_TOTAL, 'amt', function (t) { return t.v >= 0; });
    if (tt) { total = tt.cr ? 0 : tt.v; cr = !!tt.cr; byLabel = true; }
    if (total === null) total = eqT;
    else if (!R && eqT !== null && Math.abs(eqT - total) > 1) return null;''',
'''    var tPos = function (t) { return t.v >= 0; };
    var tt = (R && cbGridFind(R, CB_TOTAL, 'amt', tPos)) || (rm && rm.total) || cbFind(lines, CB_TOTAL, 'amt', tPos);
    if (tt) { total = tt.cr ? 0 : tt.v; cr = !!tt.cr; byLabel = true; }
    if (total === null) total = eqT;
    else if (eqT !== null && Math.abs(eqT - total) > 1) {
      // the label's figure gives way to the equation's total when the equation doesn't carry it at all (a figure from
      // somewhere else on the page); one it carries (ICICI's "0.00 = 3,163 + 0 + 0 − 3,163") stands
      var figs = [S.total, S.prev, S.credits, S.debits, S.fees].filter(function (x) { return typeof x === 'number'; });
      if (!figs.some(function (x) { return Math.abs(x - total) <= 1; })) total = eqT;
    }''')
rep('''    var due = find(CB_DUE, 'day', function (t) { var g = daysBetween(on, t.v); return g >= 1 && g <= 40; });''',
'''    var dueOk = function (t) { var g = daysBetween(on, t.v); return g >= 1 && g <= 40; };
    var due = (R && cbGridFind(R, CB_DUE, 'day', dueOk)) || (rm && rm.due && dueOk(rm.due) ? rm.due : null) || cbFind(lines, CB_DUE, 'day', dueOk);''')
rep('''    var mn = find(CB_MIN, 'amt', function (t) { return t.v <= total + 1; });''',
'''    var mOk = function (t) { return t.v <= total + 1; };
    var mn = (R && cbGridFind(R, CB_MIN, 'amt', mOk)) || (rm && rm.min && mOk(rm.min) ? rm.min : null) || cbFind(lines, CB_MIN, 'amt', mOk);
    var eqOk = eqT !== null && Math.abs(eqT - total) <= 1;''')
rep('''    return { amt: r2(total), min: mn ? r2(mn.v) : 0, due: due.v, on: on };''',
'''    // eq: its own summary's equation comes to this total (the app trusts such a bill over another reading's)
    return eqOk ? { amt: r2(total), min: mn ? r2(mn.v) : 0, due: due.v, on: on, eq: true } : { amt: r2(total), min: mn ? r2(mn.v) : 0, due: due.v, on: on };''')

# 4. the statement, not the leaflet riding with it
rep('''    var best = files.filter(function (f) { return /statement|cas|schedule|policy|certificate|holding|contract|bill|invoice|receipt|pay ?slip|salary|form ?-?16|advice|deposit|loan|pran|nps|gain/i.test(f); })[0] || files[0];''',
'''    // (stmtpick-4nov) never a leaflet riding with it: HSBC mails "Most Important Terms & Conditions.pdf" ahead of the
    // card statement "20261101.pdf", and "Important_Notes.pdf" ahead of the savings statement; kosh read the leaflet
    var papers = files.filter(function (f) { return !docLeaflet(f); });
    if (!papers.length) papers = files;
    var best = papers.filter(function (f) { return /statement|cas|schedule|policy|certificate|holding|contract|bill|invoice|receipt|pay ?slip|salary|form ?-?16|advice|deposit|loan|pran|nps|gain/i.test(f); })[0] || papers[0];''')
rep('''  function docWanted(m) {''', '''  /* cardbill2-4nov (stmtpick): a file that is a leaflet, terms or notes, by its name: never read as the statement */
  function docLeaflet(f) {
    var s = ' ' + String(f || '').toLowerCase().replace(/\\.[a-z0-9]{2,4}$/, '').replace(/[_\\-.+&]+/g, ' ') + ' ';
    if (/statement|\\bstmt\\b|contract|invoice|receipt|certificate|advice|\\bcas\\b|holding|pay ?slip|form ?16/.test(s)) return false;
    return /\\b(?:terms|conditions|t ?c|tnc|mitc|key fact|kfs|tariff|schedule of charges|fees? (?:and )?charges|brochure|faq|guide|leaflet|important (?:notes?|information|info)|notes?|annexure|disclosures?|welcome|benefits?|features|nomination|application form|kyc|privacy)\\b/.test(s);
  }
  function docWanted(m) {''')
rep('''    docWantedJSON: function (m) { return JSON.stringify(docWanted(JSON.parse(m))); },''',
'''    docWantedJSON: function (m) { return JSON.stringify(docWanted(JSON.parse(m))); },
    docLeafletJSON: function (f) { return JSON.stringify(docLeaflet(String(f || ''))); },''')

# 5. a card statement's card from the masked card number it prints, when neither its lines nor docFacts named one
#    (PDFKit's text of HDFC's "00361011XXXX4545", ICICI's "4035XXXXXXXX0011", SBI's "XXXX XXXX XXXX XX28", Kotak's "Air+
#    Credit Card X0719")
rep("""        if (cno) out.last4 = cno.last4;
      }
""", """        if (cno) out.last4 = cno.last4;
      }
      if (kind === 'cardstmt' && !out.last4 && !(out.parts || []).length) { var pan = cbCardDigits(text); if (pan) out.last4 = pan; }   // cardbill2-4nov
""")
rep("  function cbCells(line) {", """  function cbCardDigits(text) {
    var head = String(text || '').split('\\n').slice(0, 150).join('\\n'), m;
    if ((m = /\\b\\d{4,8}[X*•x]{4,8}(\\d{4})\\b/.exec(head))) return m[1];
    if ((m = /\\b\\d{2,4}[xX*•]{0,2}[\\s-][xX*•]{4}[\\s-][xX*•]{4}[\\s-](\\d{4})\\b/.exec(head))) return m[1];   // \"4147 XXXX XXXX 5011\", HSBC's \"43xx xxxx xxxx 5731\\\"
    if ((m = /(?:[X*•]{4}[\\s-]){3}[X*•]{0,2}(\\d{2,4})\\b/.exec(head))) return m[1];
    if ((m = /credit\\s+card\\s+[X*•]{1,4}(\\d{4})\\b/i.exec(head))) return m[1];
    if ((m = /\\b(?:rupay|visa|mastercard|card)\\s+transactions\\s*[-–]\\s*(\\d{4})\\b/i.exec(head))) return m[1];
    return '';
  }
  function cbCells(line) {""")
io.open(P, 'w', encoding='utf-8').write(s)
print('applied')
