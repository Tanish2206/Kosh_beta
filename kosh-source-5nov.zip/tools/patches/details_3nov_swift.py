#!/usr/bin/env python3
"""Every payment's details card + filing asks again (3 Nov 2026, later), the Swift side. Idempotent.
- Store+Edits.swift: filing a payment asks "all of them, or just this one?" again (the 3 Nov morning change filed all
  at once with an Undo). Nothing changes on other payments until you say so.
- Sheets.swift: the question reads as kosh asking ("File the other N payments to X too?"); ApplyAskOutside asks it
  where no payment sheet is open (Find's "Set category").
- KoshApp.swift: ApplyAskOutside at the root.
- Orders.swift: Order.by / nm / shop (engine details-3nov). OrderViews.swift: with nothing bought in the mail, the card
  says why ("Zepto doesn't email its orders: kosh read this from HSBC's alert"); Groceries tag symbol."""
import pathlib, sys
K = pathlib.Path(__file__).resolve().parents[2] / 'Kosh'
def edit(f, a, b, mark):
    p = K / f; s = p.read_text()
    if mark in s: return
    if s.count(a) != 1: sys.exit('details_3nov_swift: anchor missing in ' + f + ': ' + a[:70])
    p.write_text(s.replace(a, b, 1))

edit('Store+Edits.swift', """            if !others.isEmpty {
                // (3 Nov: kosh learns at once, before and after; Undo keeps it to this one payment)
                applyToAll(ApplyAsk(tx: id, field: "c", payee: cur.m, others: others.count, label: s.isEmpty ? c : c + " · " + s))
            }""", """            if !others.isEmpty {
                // (details-3nov: kosh asks first. Only this payment is filed until you say "all"; the earlier and later
                // payments to the payee are never changed without asking)
                applyAsk = ApplyAsk(tx: id, field: "c", payee: cur.m, others: others.count, label: s.isEmpty ? c : c + " · " + s)
            }""", 'details-3nov: kosh asks first')

edit('Sheets.swift', """        .confirmationDialog(store.applyAsk.map { "You’ve paid \\($0.payee) \\($0.others) other time\\($0.others == 1 ? "" : "s")" } ?? "",
                            isPresented: $asking, titleVisibility: .visible, presenting: store.applyAsk) { a in
            Button("All \\(a.others + 1) payments to \\(a.payee)") { answered[a.field] = true; store.applyToAll(a) }
            Button("Just this one", role: .cancel) { answered[a.field] = false; store.applyAsk = nil }
        } message: { a in
            Text(a.field == "c" ? "File them all as \\(a.label)?" : "Mark them all as for \\(a.label)?")
        }""", """        .confirmationDialog(store.applyAsk.map(ApplyAskWords.title) ?? "",
                            isPresented: $asking, titleVisibility: .visible, presenting: store.applyAsk) { a in
            Button(ApplyAskWords.all(a)) { answered[a.field] = true; store.applyToAll(a) }
            Button("Just this one", role: .cancel) { answered[a.field] = false; store.applyAsk = nil }
        } message: { a in
            Text(ApplyAskWords.message(a))
        }""", 'ApplyAskWords.title')

edit('Sheets.swift', """// MARK: - Undo, for a few seconds after a change
""", """// MARK: - "All of them, or just this one?"

/// kosh's question after a payment is filed, in one place (TxSheet, ApplyAskOutside)
enum ApplyAskWords {
    static func title(_ a: ApplyAsk) -> String {
        let n: String = a.others == 1 ? "the other payment" : "the other \\(a.others) payments"
        return a.field == "c" ? "File \\(n) to \\(a.payee) too?" : "Mark \\(n) to \\(a.payee) too?"
    }
    static func message(_ a: ApplyAsk) -> String {
        a.field == "c" ? "kosh can file every earlier and later payment to \\(a.payee) as \\(a.label). Nothing else changes unless you say so."
            : "kosh can mark every earlier and later payment to \\(a.payee) as for \\(a.label). Nothing else changes unless you say so."
    }
    static func all(_ a: ApplyAsk) -> String { "Yes, all \\(a.others + 1) payments" }
}

/// the same question where no payment sheet is open (a category set from Find's results): a sheet open asks its own
struct ApplyAskOutside: ViewModifier {
    @Environment(Store.self) private var store
    @State private var asking: Bool = false
    func body(content: Content) -> some View {
        content
            .task(id: store.applyAsk?.id) {
                guard store.applyAsk != nil, store.sheet == nil else { return }
                try? await Task.sleep(for: .milliseconds(250))
                if store.applyAsk != nil && store.sheet == nil { asking = true }
            }
            .confirmationDialog(store.applyAsk.map(ApplyAskWords.title) ?? "", isPresented: $asking, titleVisibility: .visible, presenting: store.applyAsk) { a in
                Button(ApplyAskWords.all(a)) { store.applyToAll(a) }
                Button("Just this one", role: .cancel) { store.applyAsk = nil }
            } message: { a in
                Text(ApplyAskWords.message(a))
            }
            .onChange(of: asking) { _, on in if !on && store.sheet == nil { store.applyAsk = nil } }
    }
}

// MARK: - Undo, for a few seconds after a change
""", 'struct ApplyAskOutside')

edit('KoshApp.swift', """        .modifier(UndoBar(lift: 96))
""", """        .modifier(UndoBar(lift: 96))
        // (filing a payment outside its sheet still asks before the payee's other payments follow)
        .modifier(ApplyAskOutside())
""", 'ApplyAskOutside()')

edit('Orders.swift', """        /// the mail each fact came from: bill, paper, show, gift → mail id
        var src: [String: String]? = nil
    }""", """        /// the mail each fact came from: bill, paper, show, gift → mail id
        var src: [String: String]? = nil
        /// who told kosh of the payment ("HSBC", "Amazon Pay"), and when none of them is the shop, that the shop mailed
        /// nothing (nm 1) and its name: why no items show (engine details-3nov)
        var by: [String]? = nil
        var nm: Int? = nil
        var shop: String? = nil
    }""", 'var nm: Int?')

edit('Orders.swift', """        case "Food": return "fork.knife"
""", """        case "Food": return "fork.knife"
        case "Groceries": return "basket"
""", '"Groceries": return')

edit('OrderViews.swift', """            if o.gift != nil {
                let whom: String? = o.gift?.to""", """            // (nothing bought in the mail: say why, and where kosh read the payment)
            if items.isEmpty && o.show == nil && o.trip == nil && (o.bill ?? []).isEmpty, let why = OrderWords.noItems(o, payee: t.m) {
                Label(why, systemImage: "envelope").font(.footnote).foregroundStyle(.secondary)
            }
            if o.gift != nil {
                let whom: String? = o.gift?.to""", 'OrderWords.noItems')

edit('Orders.swift', """    static func sym(_ tag: String) -> String {""", """    /// why a payment's card lists nothing bought: "Zepto doesn't email its orders, so what was bought isn't in your mail.
    /// kosh read this payment from HSBC."
    static func noItems(_ o: OrdersBook.Order, payee: String) -> String? {
        let by: [String] = o.by ?? []
        let from: String = by.isEmpty ? "" : " kosh read this payment from " + by.joined(separator: " and ") + "."
        if o.nm == 1 {
            let shop: String = o.shop ?? payee
            return shop + " didn’t email this order, so what was bought isn’t in your mail." + from
        }
        return nil
    }
    static func sym(_ tag: String) -> String {""", 'static func noItems')

edit('OrderViews.swift', """            Text("A tag you add stays with this payment. A kind of thing (Beauty, Electronics, Fashion, Books, Food) is learnt for this payee too.")""",
"""            Text("A tag you add stays with this payment. A kind of thing (Beauty, Electronics, Fashion, Books, Food, Groceries) is learnt for this payee too.")""", 'Books, Food, Groceries)')
print('details_3nov_swift: done')
