# kosh feedback 1 Nov (22:09) — Swift, part O: every bill mapped (electricity, internet, phone, gas, water, DTH,
# maintenance, insurance) above Bills by home's homes, each with its own page: a month on average, the year as bars,
# the recap, by home, by connection, and the journey of every payment. The views live in BillsMap.swift (kept in
# tools/patches/files, put back when a source drop removes it). Idempotent.
import shutil, os
if not os.path.exists('Kosh/BillsMap.swift') or open('Kosh/BillsMap.swift').read() != open('tools/patches/files/BillsMap.swift').read():
    shutil.copy('tools/patches/files/BillsMap.swift', 'Kosh/BillsMap.swift')
def sub(path, old, new, mark):
    s = open(path).read()
    if mark in s: return
    assert s.count(old) == 1, (path, old[:60])
    open(path, 'w').write(s.replace(old, new))
sub('Kosh/Navigation.swift', """    case homes
    case home(String)
}""", """    case homes
    case home(String)
    /// one kind of bill across every home (BillsMap.swift)
    case billKind(String)
}""", 'case billKind(String)')
sub('Kosh/MonthDetail.swift', """        case .home(let id): HomePage(id: id).toolbarTitleDisplayMode(.large)
""", """        case .home(let id): HomePage(id: id).toolbarTitleDisplayMode(.large)
        case .billKind(let k): BillKindPage(k: k).toolbarTitleDisplayMode(.large)
""", 'case .billKind(let k)')
sub('Kosh/HomeBillsViews.swift', """            if both.count >= 2 { HomesCompare(a: both[0], b: both[1]) }""", """            BillsMapSection()
            if both.count >= 2 { HomesCompare(a: both[0], b: both[1]) }""", 'BillsMapSection()')
sub('Kosh/HomeBillsViews.swift', """            if homes.isEmpty && loose.isEmpty {
                ObsEmpty(""", """            if homes.isEmpty && loose.isEmpty && BillKind.all(store).isEmpty {
                ObsEmpty(""", 'BillKind.all(store).isEmpty')
sub('Kosh/Store.swift', """            case .home: s += " › a home's bills"
""", """            case .home: s += " › a home's bills"
            case .billKind(let k): s += " › " + k.lowercased() + " bills"
""", 'case .billKind(let k): s +=')
print('swift O patched')
