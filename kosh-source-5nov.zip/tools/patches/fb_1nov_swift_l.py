# kosh feedback 1 Nov (21:33) — Swift, part L: "Where kosh read this" is always the designed black sheet, never the grey
# system form ("Internet bill · Read from this mail · Not a bill: leave it out" in red), from every screen: a sheet
# opened without a page colour takes kosh's own; a home's bill opens in its kind's colour. Idempotent.
p = 'Kosh/SourceSheet.swift'; s = open(p).read()
OLD = """        if let tint = ref.tint {
            ObsidianSourceSheet(ref: ref, tint: tint, left: $left)
                .onAppear { left = Self.isLeft(store, ref) }
        } else {
            plain
        }"""
NEW = """        // one design everywhere (1 Nov): the black sheet, in the page's colour or kosh's own
        ObsidianSourceSheet(ref: ref, tint: ref.tint ?? Obsidian.motor, left: $left)
            .onAppear { left = Self.isLeft(store, ref) }"""
if 'tint: ref.tint ?? Obsidian.motor' not in s:
    assert s.count(OLD) == 1, 'SourceSheet anchor'
    s = s.replace(OLD, NEW)
open(p, 'w').write(s)
p = 'Kosh/HomeBillsViews.swift'; s = open(p).read()
OLD = 'store.betaSheet = .source(SourceRef(title: b.k + " bill", mails: mails, type: "due"))'
NEW = 'store.betaSheet = .source(SourceRef(title: b.k + " bill", mails: mails, type: "due", tint: HomeInk.kind(b.k)))'
if NEW not in s:
    assert s.count(OLD) == 1, 'HomeBillRow anchor'
    s = s.replace(OLD, NEW)
open(p, 'w').write(s)
print('swift L patched')
