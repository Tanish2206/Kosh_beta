#!/usr/bin/env python3
"""story-5nov (kosh ios app chat): one payment, its whole story. When the same payment is told twice (the bank's SMS
and its mail, two of its mail templates, a refund told by two mails, a standing instruction told twice) the one kept
takes what the other knew and it lacked: the time, the payee, the UPI ID, the reference, the narration, the receiving
account, the balance after. Every source that told it is kept on it (told), and the statement mails whose lines
answered for it (sm). The snapshot carries both, so "Where kosh read this" lists every mail, SMS aside, and the statement.
Idempotent. Run from kosh-beta/."""
import sys
def patch(p, pairs, marker):
    s = open(p, encoding='utf-8').read()
    if marker in s: print(p, 'already'); return
    for a, b in pairs:
        if s.count(a) != 1: sys.exit('%s anchor %d: %r' % (p, s.count(a), a[:60]))
        s = s.replace(a, b)
    open(p, 'w', encoding='utf-8').write(s); print(p, 'patched')
patch('Kosh/engine.js', [
 ("""  function tell(t, c, also) {
    if (!t || !c || t === c) return;""",
  """  /* (story-5nov) the one kept takes what its twin knew and it lacked, and remembers that it told it */
  function absorb(k, d) {
    if (!k || !d || k === d) return;
    ['time', 'party', 'ref', 'vpa', 'info', 'toLast4', 'acct', 'mode'].forEach(function (f) { if (!k[f] && d[f]) k[f] = d[f]; });
    if ((k.after === undefined || k.after === null) && d.after !== undefined && d.after !== null) k.after = d.after;
    tell(k, d);
  }
  function tell(t, c, also) {
    if (!t || !c || t === c) return;"""),
 ("""      if (twin) { if (!twin.party && t.party) twin.party = t.party; if (!twin.ref && t.ref) twin.ref = t.ref; tell(twin, t); return; }""",
  """      if (twin) { absorb(twin, t); return; }"""),
 ("""      if (near) { if (!near.party && t.party) near.party = t.party; if (!near.ref && t.ref) near.ref = t.ref; tell(near, t); return; }""",
  """      if (near) { absorb(near, t); return; }"""),
 ("""        if (twinR) { if (!twinR.party && t.party) twinR.party = t.party; if (!twinR.info && t.info) twinR.info = t.info; return; }""",
  """        if (twinR) { absorb(twinR, t); return; }"""),
 ("""          if (!twinB.time && t.time) twinB.time = t.time;
          return;""",
  """          if (!twinB.time && t.time) twinB.time = t.time;
          absorb(twinB, t);
          return;"""),
 ("""        if (twinS) { if (!twinS.ref && t.ref) twinS.ref = t.ref; if (!twinS.toLast4 && t.toLast4) twinS.toLast4 = t.toLast4; return; }""",
  """        if (twinS) { absorb(twinS, t); return; }"""),
 ("""        rc: r.confirmed || undefined, told: r.told && r.told.length ? r.told.slice() : undefined, bd: r.bookDate || undefined,""",
  """        rc: r.confirmed || undefined, told: r.told && r.told.length ? r.told.slice() : undefined, bd: r.bookDate || undefined,
        // (story-5nov) the statement mails whose lines answered for it
        sm: r.stSeen && r.stSeen.length ? r.stSeen.map(function (x) { return String(x.src || '').replace(/^doc:/, '').split('#')[0]; }).filter(function (x, i, a) { return x && a.indexOf(x) === i; }) : undefined,"""),
 ("""mr: t.mirror ? true : undefined, rc: t.rc || undefined, uc: t.uc || undefined }; }),""",
  """mr: t.mirror ? true : undefined, rc: t.rc || undefined, uc: t.uc || undefined, told: t.told || undefined, sm: t.sm || undefined }; }),"""),
], 'story-5nov')
# Swift: the payment knows every source, and "Where kosh read this" lists them all
patch('Kosh/Snapshot.swift', [
 ("""    var via: String? = nil; var fg: Bool? = nil; var pl4: String? = nil""",
  """    var via: String? = nil; var fg: Bool? = nil; var pl4: String? = nil
    /// (story-5nov) every other mail or SMS that told this payment (its twins, its receipt), the shop's own receipt (rc),
    /// and the statement mails whose lines answered for it (sm)
    var told: [String]? = nil; var rc: String? = nil; var sm: [String]? = nil"""),
], 'story-5nov')
patch('Kosh/Store+Orders.swift', [
 ("""        let ids: [String] = (order(t)?.mails ?? []).map(\\.id)
        return ids.isEmpty ? [own] : ids""",
  """        let ids: [String] = (order(t)?.mails ?? []).map(\\.id)
        // (story-5nov-swift) and every source that told it, the receipt and the statement, each once, the payment's own first
        var all: [String] = ids.isEmpty ? [own] : ids
        for x in (t.told ?? []) + [t.rc ?? ""] + (t.sm ?? []) where !x.isEmpty && !all.contains(x) { all.append(x) }
        return all"""),
], 'story-5nov-swift')
