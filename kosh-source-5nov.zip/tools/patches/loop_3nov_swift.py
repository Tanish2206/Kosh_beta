#!/usr/bin/env python3
"""Bills paid + group split + learning default (3 Nov 2026), the Swift side. Idempotent.
- BillLoop.swift (from tools/patches/files): a bill paid on its sheet (loop steps, biller, connection, references,
  copy), a card's bills paid on its page (CardPaysBlock), and kosh's note for a bill paid (LoopWords.note).
- GroupSplit.swift: Transactions › select › Split together: several payments shared at once (equally, by shares, or
  your share %), anyone left out of a payment, one message per person, an event chapter, one Undo.
- Snapshot.swift: Txn.bl / Txn.lp / Txn.ls, CardInfo.pays. Sheets.swift: BillLoopCard; "filed like" footnote.
  Cards.swift: CardPaysBlock. AutoNote.swift: bill notes (card bills too). Store+Edits.swift: filing a payment files every
  payment to its payee at once, with Undo (was a question that "Just this one" or a swipe answered). LedgerView.swift:
  the Split together item and its sheet."""
import pathlib, shutil, sys
ROOT = pathlib.Path(__file__).resolve().parents[2]
K = ROOT / 'Kosh'
for f in ['BillLoop.swift', 'GroupSplit.swift']:
    shutil.copyfile(ROOT / 'tools/patches/files' / f, K / f)
def edit(f, a, b, mark):
    p = K / f; s = p.read_text()
    if mark in s: return
    if s.count(a) != 1: sys.exit('loop_3nov_swift: anchor missing in ' + f + ': ' + a[:70])
    p.write_text(s.replace(a, b, 1))
E = []
E.append(('Snapshot.swift', """    var paysBack: [String]? = nil
}""", """    var paysBack: [String]? = nil
    /// a bill paid: what it paid (engine billLoopBook, 3 Nov): biller, connection number and what it's called, the
    /// Bharat Connect and operator's references, the app's order, the UTR, the fee, the days it covers, the units used
    struct BillLine: Decodable, Hashable {
        var k: String? = nil; var bn: String? = nil; var no: String? = nil; var nol: String? = nil
        var ref: String? = nil; var oref: String? = nil; var ord: String? = nil; var utr: String? = nil; var fee: Double? = nil
        var from: String? = nil; var to: String? = nil; var units: Double? = nil; var unit: String? = nil
    }
    var bl: BillLine? = nil
    /// a bill paid, its loop: the app it went through, the card (its row in the stack, and last four) or biller it paid,
    /// the money it left, and whether the bank said so: st done (on, by; cid the bank's own line), wait (within two
    /// days), open (past two days, nothing yet), old (older, nothing in the mail); the app's order, UTR, ref, the day
    /// the app says the card was credited
    struct PayLoop: Decodable, Hashable {
        var pt: String? = nil; var card: String? = nil; var l4: String? = nil; var src: String? = nil
        var st: String = "old"; var on: String? = nil; var by: String? = nil; var cid: String? = nil
        var ord: String? = nil; var utr: String? = nil; var ref: String? = nil; var cr: String? = nil
    }
    var lp: PayLoop? = nil
    /// filed like the payment to the same payee you filed "just this one" (about the same sum): that payment's day
    var ls: String? = nil
}""", 'struct PayLoop: Decodable'))
E.append(('Snapshot.swift', """    var avail: Double? = nil; var availOn: String? = nil; var limitAll: Bool? = nil
}""", """    var avail: Double? = nil; var availOn: String? = nil; var limitAll: Bool? = nil
    /// its latest bill payments, newest first, and whether the bank confirmed each (Txn.PayLoop's st, on)
    struct Pay: Decodable, Hashable { let id: String; let d: String; let a: Double; let st: String; var pt: String? = nil; var src: String? = nil; var on: String? = nil }
    var pays: [Pay]? = nil
}""", 'var pays: [Pay]?'))
E.append(('Sheets.swift', """                    if let o = store.order(t) {
                        OrderCard(t: t, o: o)
                    }
""", """                    if let o = store.order(t) {
                        OrderCard(t: t, o: o)
                    }
                    // a bill paid: where, for what, from where, and whether the bank confirmed it (BillLoop.swift)
                    BillLoopSlot(t: t)
""", 'BillLoopSlot(t: t)'))
# (the sheet's page type-erased: as one generic type it overflowed the main thread's stack in Debug, SIGSEGV on any payment)
E.append(('Sheets.swift', """                    form(t)
                } else {""", """                    // (type-erased: the sheet's whole page as one generic type overflowed the stack in Debug builds)
                    AnyView(form(t))
                } else {""", 'AnyView(form(t))'))
E.append(('Sheets.swift', """                PaymentHeader(t: t)
                VStack(alignment: .leading, spacing: 20) {""", """                PaymentHeader(t: t)
                AnyView(VStack(alignment: .leading, spacing: 20) {""", 'AnyView(VStack(alignment: .leading, spacing: 20)'))
E.append(('Sheets.swift', """                .padding(.bottom, 36)
            }
        }
        .scrollIndicators(.hidden)""", """                .padding(.bottom, 36))
            }
        }
        .scrollIndicators(.hidden)""", '.padding(.bottom, 36))'))
E.append(('Sheets.swift', """        if t.lr == true { how = " Tagged the way you tagged earlier payments to this payee." }""",
"""        if let ls = t.ls, ls.count == 10 { how = " Filed like the payment to this payee you filed on " + Day.fmt(ls, "d MMM") + ", about the same sum." }
        else if t.lr == true { how = " Tagged the way you tagged earlier payments to this payee." }""", 'Filed like the payment to this payee'))
E.append(('Cards.swift', """            CardLimitBlock(c: s.c, bill: s.bill)
""", """            CardLimitBlock(c: s.c, bill: s.bill)
            if let pays = s.c.pays, !pays.isEmpty {
                CardPaysBlock(pays: pays)
            }
""", 'CardPaysBlock(pays: pays)'))
E.append(('AutoNote.swift', """        guard let f = store.payFact(t) else { return nil }""", """        // a bill paid through an app: where, for which card or connection, from where, its references (BillLoop.swift)
        if t.lp != nil, let n = LoopWords.note(t, store) { return n }
        guard let f = store.payFact(t) else { return nil }""", 'LoopWords.note(t, store)'))
E.append(('AutoNote.swift', """        for t in store.snap.tx where t.k == "out" && t.partOf == nil && t.wf == nil {""",
"""        for t in store.snap.tx where (t.k == "out" || (t.k == "cardpay" && t.dr != "in" && t.mr != true)) && t.partOf == nil && t.wf == nil {""", 't.k == "cardpay" && t.dr != "in"'))
E.append(('Store+Edits.swift', """            if !others.isEmpty {
                applyAsk = ApplyAsk(tx: id, field: "c", payee: cur.m, others: others.count, label: s.isEmpty ? c : c + " · " + s)
            }""", """            if !others.isEmpty {
                // (3 Nov: kosh learns at once, before and after; Undo keeps it to this one payment)
                applyToAll(ApplyAsk(tx: id, field: "c", payee: cur.m, others: others.count, label: s.isEmpty ? c : c + " · " + s))
            }""", 'kosh learns at once, before and after'))
E.append(('LedgerView.swift', """struct SelectBar: View {
    @Environment(Store.self) private var store
    var body: some View {""", """struct SelectBar: View {
    @Environment(Store.self) private var store
    /// Split together (GroupSplit.swift): the ticked payments shared out in one go
    @State private var splitting = false
    var body: some View {""", '@State private var splitting = false'))
E.append(('LedgerView.swift', """                    if store.live != nil { RefileItems(rows: rows) }
                    Menu {""", """                    if store.live != nil { RefileItems(rows: rows) }
                    if store.live != nil && rows.contains(where: { $0.k == "out" }) {
                        Button { splitting = true } label: {
                            Label(n == 1 ? "Split it…" : "Split together…", systemImage: "person.3")
                        }
                    }
                    Menu {""", '"Split together…"'))
E.append(('LedgerView.swift', """        .padding(.horizontal, 20).padding(.vertical, 12)
        .background(.bar)
        .animation(Motion.base, value: n)
    }
}""", """        .padding(.horizontal, 20).padding(.vertical, 12)
        .background(.bar)
        .animation(Motion.base, value: n)
        .sheet(isPresented: $splitting) {
            GroupSplitSheet(ids: Array(store.ledgerSelected))
                .presentationDetents([.large])
        }
    }
}""", 'GroupSplitSheet(ids:'))
for e in E: edit(*e)
print('loop_3nov_swift: applied')
