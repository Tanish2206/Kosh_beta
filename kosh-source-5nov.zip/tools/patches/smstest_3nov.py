#!/usr/bin/env python3
"""smstest-3nov: from a 54-case SMS test of every bank/card/app Mickey uses (tools/qc/sms-qc.js):
 engine — "Transaction of INR 1,500 … is successful" (IndusInd, SBI Card) had no direction and was dropped; a shop's
 6-letter DLT header ("BLINKT") never matched its name; HSBC's "A/c 001-XXXXXX-006" read as ••001.
 Swift — an arrivals log (every message the shortcut hands kosh: when, business sender, passed or why not; never the
 words), so a payment the bank mailed but kosh never got by SMS can be told from one kosh dropped; and the drop log
 names a business sender of any length, not only a 5-6 letter one. Run from kosh-beta/."""
import sys, json, hashlib
def patch(p, pairs):
    s = open(p, encoding='utf-8').read()
    for old, new in pairs:
        if new in s: continue
        if s.count(old) != 1: sys.exit('%s: anchor %d times: %r' % (p, s.count(old), old[:70]))
        s = s.replace(old, new)
    open(p, 'w', encoding='utf-8').write(s)

patch('Kosh/engine.js', [
 ("""|txn of|txn\\s*(?:rs\\.?|inr)|""", """|txn of|trxn of|transaction of|txn\\s*(?:rs\\.?|inr)|"""),
 ("""      for (var p = 0; p < PLATFORMS.length; p++) if (PLATFORMS[p][2].test(h)) return PLATFORMS[p];
    }
    return null;
  }""", """      for (var p = 0; p < PLATFORMS.length; p++) if (PLATFORMS[p][2].test(h)) return PLATFORMS[p];
      // (a header is six letters, so a longer name is cut: "BLINKT" Blinkit, "BGBSKT" BigBasket. Its letters in order
      // within the shop's name, the same first letter, five letters at least)
      if (h.length >= 5 && /^[a-z]+$/.test(h)) for (var q = 0; q < PLATFORMS.length; q++) {
        var nm = String(PLATFORMS[q][0]).toLowerCase().replace(/[^a-z]/g, ''), at = 0;
        if (nm[0] !== h[0]) continue;
        for (var k = 0; k < nm.length && at < h.length; k++) if (nm[k] === h[at]) at++;
        if (at === h.length) return PLATFORMS[q];
      }
    }
    return null;
  }"""),
 ("""    var cm = SMS_CARD.exec(flat), am = SMS_ACCT.exec(flat);""",
  """    var cm = SMS_CARD.exec(flat), am = SMS_ACCT.exec(flat);
    // (HSBC writes its account as branch-number-suffix, "A/c 001-XXXXXX-006": the last group, never the branch)
    var hs = /\\b(?:a\\/c|ac|acct|account)\\s*(?:no\\.?)?\\s*\\d{3}-[x*\\d]{4,8}-(\\d{3})\\b/i.exec(flat);
    if (hs && am) am = [am[0], hs[1]];"""),
  ("""    var dir = SMS_IN_SELF.test(flat) ? 'in' : SMS_OUT.test(flat) ? 'out' : SMS_IN.test(flat) ? 'in' : '';""",
   """    // (money that came back: a charge "has been reversed" or refunded names the charge, and is money in. 3 Nov)
    var back = /\\b(?:has been|is|was|been)\\s+(?:reversed|refunded)\\b|^\\s*refund (?:of|for)\\b/i.test(flat) && !/\\b(?:debited|spent|sent|withdrawn)\\b/i.test(flat);
    var dir = SMS_IN_SELF.test(flat) || back ? 'in' : SMS_OUT.test(flat) ? 'out' : SMS_IN.test(flat) ? 'in' : '';"""),
])
j = 'Kosh/engine-sms.json'
fp = hashlib.sha256(('smstest-3nov|' + open(j).read()).encode()).hexdigest()[:16]
open(j, 'w').write(json.dumps({'sms': fp}, separators=(',', ':')))

patch('Kosh/Alerts.swift', [
 ("""    static let noSenderKey = "alerts.noSender\"""", """    static let noSenderKey = "alerts.noSender"
    /// every message the shortcut handed kosh, newest last: when, who (a business's sender, never a person's number) and
    /// "in" or why not; never the words. Beside the bank's own mail it tells a payment kosh never got from one it dropped
    static let arrivalsKey = "alerts.arrivals\""""),
 ("""        ud.set(at.timeIntervalSince1970, forKey: lastKey)
        ud.set(ud.integer(forKey: reachedKey) + 1, forKey: reachedKey)
        if let why = whyNot(title + " " + text) { noteDrop(why, from: from, notification: notification, at: at); return }""",
  """        ud.set(at.timeIntervalSince1970, forKey: lastKey)
        ud.set(ud.integer(forKey: reachedKey) + 1, forKey: reachedKey)
        let why0: String? = whyNot(title + " " + text)
        noteArrival(why0 ?? "in", from: from, notification: notification, at: at)
        if let why = why0 { noteDrop(why, from: from, notification: notification, at: at); return }"""),
 ("""    static func noteDrop(_ why: String, from: String, notification: Bool, at: Date = Date()) {
        lock.lock(); defer { lock.unlock() }
        let ud = UserDefaults.standard
        ud.set(ud.integer(forKey: droppedKey) + 1, forKey: droppedKey)
        // (a bank's sender ID as the phone shows it: "AX-HDFCBK-S", or without the operator's prefix, "HDFCBK-S")
        let who: String = from.range(of: #"^([A-Z]{2}-)?[A-Z0-9]{5,6}(-[A-Z])?$"#, options: .regularExpression) != nil || notification ? from : (from.isEmpty ? "no sender" : "a person or number")
""", """    /// who sent it, as the logs may name it: a business's sender ID or app as the phone shows it ("AX-HDFCBK-S",
    /// "HDFCBANK": capitals and digits, as iOS shows a sender ID), or the app's name for a notification; else only what kind
    /// of sender (never a person's number or a contact's name)
    static func whoOf(_ from: String, notification: Bool) -> String {
        if notification { return from }
        if from.isEmpty { return "no sender" }
        if from.range(of: #"^[A-Z0-9]{2,9}(-[A-Z0-9]{1,9}){0,2}$"#, options: .regularExpression) != nil,
           from.range(of: #"\\d{5,}"#, options: .regularExpression) == nil, from.range(of: #"[A-Z]{4,}"#, options: .regularExpression) != nil { return from }
        let digits: Int = from.filter(\\.isNumber).count
        return digits >= 5 ? "a number (\\(digits) digits)" : "a contact"
    }
    static func noteArrival(_ what: String, from: String, notification: Bool, at: Date) {
        lock.lock(); defer { lock.unlock() }
        let ud = UserDefaults.standard
        var log = ud.stringArray(forKey: arrivalsKey) ?? []
        log.append(Gmail.isoStamp.string(from: at) + " · " + whoOf(from, notification: notification) + " · " + what)
        ud.set(Array(log.suffix(120)), forKey: arrivalsKey)
    }
    static func noteDrop(_ why: String, from: String, notification: Bool, at: Date = Date()) {
        lock.lock(); defer { lock.unlock() }
        let ud = UserDefaults.standard
        ud.set(ud.integer(forKey: droppedKey) + 1, forKey: droppedKey)
        let who: String = whoOf(from, notification: notification)
"""),
])
patch('Kosh/LiveSession+Extras.swift', [
 ("""                             "drops": ud.stringArray(forKey: AlertIntake.dropLogKey) ?? [],""",
  """                             "drops": ud.stringArray(forKey: AlertIntake.dropLogKey) ?? [],
                             "arrivals": ud.stringArray(forKey: AlertIntake.arrivalsKey) ?? [],"""),
])
print('ok')
