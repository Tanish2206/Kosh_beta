# kosh feedback 2 Nov (02:13) — engine, part P: an event booked is an event to track. A ticketing mail ("Here are your
# tickets!", "Booking confirmed", "You have tickets") that the rules left unread is read for its event: the name
# ("Sonu Nigam - The Revolution India Tour"), the city, the day and time, the tickets and their tier, the venue (or
# that it's to be announced), the booking code and what was paid. It is the receipt of the payment it goes with (one
# purchase, one row: never a second payment), so the payment's order carries the event. Idempotent.
p = 'Kosh/engine.js'; s = open(p).read()
def sub(old, new, mark):
    global s
    if mark in s: return
    assert s.count(old) == 1, ('engine P anchor', old[:70], s.count(old))
    s = s.replace(old, new)
sub("""  function parse(msg) { return walletUse(returnWords(giftCardBought(parseMail0(msg), msg), msg), msg); }""",
    """  function parse(msg) { return eventTickets(walletUse(returnWords(giftCardBought(parseMail0(msg), msg), msg), msg), msg); }
  var TICKETS_SUBJ = /\\b(?:here are your tickets|your tickets?(?: are| is)? (?:confirmed|ready|here)|you have tickets|booking (?:is )?confirmed|tickets? (?:booked|confirmed)|e-?tickets?)\\b/i;
  function eventTickets(r, msg) {
    if (!r || !msg || !/^(?:unknown|noise)$/.test(r.kind || '')) return r;
    var sj = String(msg.subject || '');
    var text = normalize(msg.text || '', '') || normalize('', msg.html || '');
    if (!TICKETS_SUBJ.test(sj) && !/\\byou have tickets\\b/i.test(text.slice(0, 600))) return r;
    if (/\\b(?:flight|train|bus|pnr|boarding|hotel|check-?in|cab|ride)\\b/i.test(sj + ' ' + text.slice(0, 400))) return r;
    var raw = String(msg.text || '').trim() ? String(msg.text) : String(msg.html || '').replace(/<(?:br|\\/p|\\/div|\\/tr|\\/td|\\/h\\d)[^>]*>/gi, '\\n').replace(/<[^>]+>/g, ' ').replace(/&nbsp;/g, ' ');
    var lines = raw.split(/\\n+/).map(function (l) { return l.replace(/^[|\\s*]+|[|\\s*]+$/g, '').trim(); }).filter(Boolean);
    var nameLine = lines.filter(function (l) { return /\\b(?:tour|live|concert|show|festival|fest|comedy|stand ?-?up|unplugged|night|match|musical|play)\\b/i.test(l) && l.length <= 140 && !/\\b(?:terms|entry|ticket grants|qr code|refund)\\b/i.test(l); })[0];
    if (!nameLine) return r;
    var bits = nameLine.split(/\\s*\\|\\s*/).filter(Boolean);
    var name = bits[0].replace(/^(?:all|home|events?|music|concerts?|comedy)\\s+(?=[A-Z])/i, '').trim();
    var city = bits[1] || '';
    var m, show = { name: name.slice(0, 80), k: /\\b(?:concert|tour|live|unplugged|music)\\b/i.test(name) ? 'concert' : /\\bfilm|movie\\b/i.test(name) ? 'movie' : 'event' };
    var pm = /^(.{2,40}?)\\s+[-–:]\\s+/.exec(name); if (pm && pm[1].split(/\\s+/).length <= 4) show.perf = pm[1].trim();
    if (city && city.length <= 40) show.at = city;
    if ((m = /\\bdate\\b\\s*:?\\s*(\\d{1,2}(?:st|nd|rd|th)?\\s+[A-Za-z]{3,9},?\\s+\\d{4}|\\d{1,2}[\\/\\-]\\d{1,2}[\\/\\-]\\d{2,4})/i.exec(text))) { var dd = isoDate(m[1], ''); if (dd) show.on = dd; }
    if ((m = /\\btime\\b\\s*:?\\s*(\\d{1,2}(?::\\d{2})?\\s*[ap]\\.?m\\.?)(?:\\s*[-–]\\s*(\\d{1,2}(?::\\d{2})?\\s*[ap]\\.?m\\.?))?/i.exec(text))) { show.time = m[1].replace(/\\s+/g, ' ').trim(); if (m[2]) show.till = m[2].replace(/\\s+/g, ' ').trim(); }
    if ((m = /\\b(\\d{1,2})\\s+tickets?\\b/i.exec(text))) show.n = +m[1];
    var tierLine = lines.filter(function (l) { return /\\b(?:gold|silver|platinum|vip|fan ?pit|general|early bird|phase|tier|balcony|lounge|zone|seat)\\b/i.test(l) && l.length < 160; })[0];
    if (tierLine) show.tier = tierLine.split(/\\s*\\*\\s*|\\.\\s/)[0].replace(/\\s*\\|\\s*/g, ' · ').slice(0, 50);
    var vi = lines.findIndex(function (l) { return /^venue\\b/i.test(l); });
    if (vi >= 0) { var vl = lines[vi].replace(/^venue\\s*:?\\s*/i, '') || lines[vi + 1] || ''; vl = vl.split(/\\s*\\|\\s*/)[0].trim(); if (vl && !/get directions/i.test(vl)) show.venue = vl.slice(0, 90); }
    var code = (/\\b(?:booking (?:id|code|ref(?:erence)?)|order (?:id|no)|confirmation (?:code|no))\\s*[:#]?\\s*([A-Z0-9\\-]{5,})/i.exec(text) || [])[1] || (/^([A-Z0-9]{5,10})$/.exec(lines[0] || '') || [])[1] || '';
    var paid = (/\\b(?:paid|total(?: amount)?|amount paid|grand total)\\s*:?\\s*(?:₹|rs\\.?|inr)\\s*([\\d,]+(?:\\.\\d{1,2})?)/i.exec(text) || [])[1];
    var amt = paid ? +paid.replace(/,/g, '') : 0;
    var shop = r.inst || (String(msg.from || '').toLowerCase().replace(/^.*@/, '').replace(/[>\\s].*$/, '').split('.').slice(-2, -1)[0] || '');
    shop = shop ? shop.charAt(0).toUpperCase() + shop.slice(1) : '';
    var ev = { type: 'order', shop: shop, status: 'placed', booking: true, show: show, conf: 'high' };
    if (code) ev.order = code;
    if (amt > 0) ev.total = amt;
    var evs = []; try { evs = typeof r.evs === 'string' ? JSON.parse(r.evs) || [] : []; } catch (e) { evs = []; }
    evs = evs.filter(function (e) { return !(e && e.type === 'move' && e.unsure); }).concat([ev]);
    r.evs = JSON.stringify(evs);
    if (amt > 0) { r.kind = 'confirm'; r.rule = 'event-tickets'; r.amt = amt; r.dir = 'out'; r.party = shop; r.cat = 'Entertainment'; r.sub = show.k === 'concert' ? 'Concerts' : show.k === 'movie' ? 'Movies' : 'Events'; if (!r.date) r.date = String(msg.date || '').slice(0, 10); if (code) r.orderId = code; }
    else { r.kind = 'noise'; r.rule = 'event-tickets'; }
    return r;
  }""", "function eventTickets(r, msg)")
open(p, 'w').write(s)
print('engine P patched')
# (the order keeps the event's time and the tickets' tier too)
s = open(p).read()
sub("""          if (s0.on) show.on = s0.on;
          if (ticketsOk(s0.n, t.a)) show.n = s0.n;""", """          if (s0.on) show.on = s0.on;
          if (s0.time) show.time = String(s0.time).slice(0, 12);
          if (s0.till) show.till = String(s0.till).slice(0, 12);
          if (s0.tier) show.tier = String(s0.tier).slice(0, 50);
          if (ticketsOk(s0.n, t.a)) show.n = s0.n;""", "if (s0.time) show.time = String(s0.time).slice(0, 12);")
open(p, 'w').write(s)
# (an event's tickets mail is read after the payment's own mails: the app's or bank's word of the payment stays the
# row, the tickets tell it what it was for)
s = open(p).read()
sub("""  function partPaper(c) {
    if (c.dir !== 'out' || !/^(?:order-invoice|order-receipt|reader-receipt)$/.test(c.rule || '')) return '';""",
    """  function partPaper(c) {
    if (c.dir === 'out' && c.rule === 'event-tickets') return 'late';
    if (c.dir !== 'out' || !/^(?:order-invoice|order-receipt|reader-receipt)$/.test(c.rule || '')) return '';""", "c.rule === 'event-tickets') return 'late';")
open(p, 'w').write(s)
