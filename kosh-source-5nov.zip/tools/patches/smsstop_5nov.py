#!/usr/bin/env python3
"""smsstop-5nov (kosh ios app chat): SMS that worked and then stopped is said, not hidden. Health gains .stopped:
the automation delivered before, but nothing has reached kosh for four days (an iOS update or a Focus can turn a
Shortcuts automation off without a word). Settings › Payments by SMS says since when and how to mend it, and every
bank account's balance card says the balance may miss payments since then: the live balance leans on SMS, so a quiet
SMS rail is something the person must see where they read the balance. Idempotent."""
import sys
def patch(p, pairs, marker):
    s = open(p, encoding='utf-8').read()
    if marker in s: print(p, 'already'); return
    for a, b in pairs:
        if s.count(a) != 1: sys.exit('%s anchor %d: %r' % (p, s.count(a), a[:60]))
        s = s.replace(a, b)
    open(p, 'w', encoding='utf-8').write(s); print(p, 'patched')
patch('Kosh/Alerts.swift', [
 ("""    enum Health { case off, working, silent, unwired }""",
  """    enum Health { case off, working, silent, unwired, stopped }   // (smsstop-5nov) stopped: worked, then nothing for 4 days"""),
 ("""        if let s = setUp, (last ?? .distantPast) < s { return .silent }
        return last == nil ? (setUp == nil ? .off : .silent) : .working""",
  """        if let s = setUp, (last ?? .distantPast) < s { return .silent }
        if let l = last, Date().timeIntervalSince(l) > 4 * 86400 { return .stopped }
        return last == nil ? (setUp == nil ? .off : .silent) : .working"""),
 ("""        case .unwired:
            VStack(alignment: .leading, spacing: 6) {
                Label("The shortcut ran \\(s.empty) time""",
  """        case .stopped:
            VStack(alignment: .leading, spacing: 6) {
                Label("No message has reached kosh since " + (s.last.map { AlertsTurnOn.when($0) } ?? "a while"), systemImage: "exclamationmark.triangle.fill")
                    .font(.subheadline.weight(.semibold)).foregroundStyle(.orange)
                Text("It worked before, so the automation has likely been turned off (an iOS update or a Focus can do that). In Shortcuts › Automation, check the Message one is on and set to Run Immediately. Until then, balances may miss payments your bank only texted.")
                    .font(.footnote).foregroundStyle(.secondary)
            }
        case .unwired:
            VStack(alignment: .leading, spacing: 6) {
                Label("The shortcut ran \\(s.empty) time"""),
], 'smsstop-5nov')
patch('Kosh/AccountPage.swift', [
 ("""            if let proof {
                Rectangle().fill(Color.primary.opacity(0.08)).frame(height: 0.5)""",
  """            // (smsstop-5nov) the live balance leans on SMS: when they've stopped reaching kosh, say so here
            if a.kind == "bank", AlertsState.now(kept: 0).health == .stopped, let l = AlertIntake.lastAt {
                Rectangle().fill(Color.primary.opacity(0.08)).frame(height: 0.5)
                HStack(alignment: .firstTextBaseline, spacing: 8) {
                    Image(systemName: "message.badge.waveform").font(.system(.footnote, weight: .semibold)).foregroundStyle(Color(light: "#A35A00", dark: "#FFB04D"))
                    Text("Your bank’s SMS haven’t reached kosh since " + AlertsTurnOn.when(l) + ", so this may miss payments since. Settings › Payments by SMS shows how to fix it.")
                        .font(.footnote).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                    Spacer(minLength: 0)
                }
                .padding(.horizontal, 14).padding(.vertical, 10)
            }
            if let proof {
                Rectangle().fill(Color.primary.opacity(0.08)).frame(height: 0.5)"""),
], 'smsstop-5nov')
