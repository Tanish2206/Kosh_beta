#!/usr/bin/env python3
"""kosh-reader v3 (2 Nov 2026): the reader's balance, voucher and deposit answers become records (fromClaude made
them "unknown"); training labels carry a balance's figure; KoshReader.swift writes Qwen3's turns (thinking off) for a
Qwen model and allows the three kinds in its grammar. Idempotent."""
import pathlib, sys
K = pathlib.Path(__file__).resolve().parents[2] / 'Kosh'
def patch(name, pairs):
    p = K / name; s = p.read_text(); n = 0
    for a, b in pairs:
        if b in s: continue
        if a not in s: sys.exit(f'reader_2nov: anchor missing in {name}: {a[:70]}')
        s = s.replace(a, b, 1); n += 1
    p.write_text(s); print(f'reader_2nov: {name} {n} applied')
patch('engine.js', [
 ("""    if (k === 'confirm') o.dir = 'out';
    if (k === 'policy') {""",
  """    if (k === 'confirm') o.dir = 'out';
    // (a balance's figure is what it says: "Available Balance: INR 9,89,361.58")
    if (k === 'balance') { o.amount = r.bal || r.amt; o.dir = ''; }
    if (k === 'policy') {"""),
 ("""    if (k === 'bill') return Object.assign(rec, { kind: 'bill', amt: money(+r.due_amount || +r.amount || 0), due: isoDate(r.due_date, '') || '', party: r.party || r.institution || '', date: sent, cat: CAT[r.category] ? r.category : 'Bills', sub: r.sub || '' });
    return Object.assign(rec, { kind: 'unknown', reason: 'Smart reading could not tell' });""",
  """    if (k === 'bill') return Object.assign(rec, { kind: 'bill', amt: money(+r.due_amount || +r.amount || 0), due: isoDate(r.due_date, '') || '', party: r.party || r.institution || '', date: sent, cat: CAT[r.category] ? r.category : 'Bills', sub: r.sub || '' });
    // (a balance, a gift card or points, a fixed deposit's step: the same records the rules make of them)
    if (k === 'balance') {
      var bd = isoDate(r.date, sent) || sent, bt = time24(r.time);
      return Object.assign(rec, { kind: 'balance', instr: r.instrument || 'account', last4: (r.last4 || '').replace(/\\D/g, '').slice(-4), date: bd, time: bt,
        bal: money(+r.amount || 0), balAt: bd + (bt ? 'T' + bt : '') });
    }
    if (k === 'voucher') return Object.assign(rec, { kind: 'voucher', dir: '', amt: money(+r.amount || 0), date: isoDate(r.date, sent) || sent, party: r.party || '' });
    if (k === 'deposit') return Object.assign(rec, { kind: 'deposit', amt: money(+r.amount || 0), date: isoDate(r.date, sent) || sent, depNo: (r.last4 || '').replace(/\\D/g, '').slice(-4) });
    return Object.assign(rec, { kind: 'unknown', reason: 'Smart reading could not tell' });"""),
])
patch('KoshReader.swift', [
 ('''| "\\"investment\\"" | "\\"property\\"" | "\\"not_money\\"" | "\\"unsure\\""''',
  '''| "\\"investment\\"" | "\\"property\\"" | "\\"balance\\"" | "\\"voucher\\"" | "\\"deposit\\"" | "\\"not_money\\"" | "\\"unsure\\""'''),
 ('''        let prompt = "<start_of_turn>user\\n" + content + "<end_of_turn>\\n<start_of_turn>model\\n"''',
  '''        // each model reads in the turns it was trained in: Qwen3's (thinking off, as the training notebook writes them)
        // or Gemma's
        let prompt = modelName.lowercased().contains("qwen")
            ? "<|im_start|>user\\n" + content + "<|im_end|>\\n<|im_start|>assistant\\n<think>\\n\\n</think>\\n\\n"
            : "<start_of_turn>user\\n" + content + "<end_of_turn>\\n<start_of_turn>model\\n"'''),
])
