# kosh feedback 1 Nov (19:10) — Swift, part D: Insights' month picker inside the pace card, on its right; names without
# "This month", years as sections. Idempotent.
def patch(F, pairs):
    p = 'Kosh/' + F; s = open(p).read()
    for a, b, mark in pairs:
        if mark in s: continue
        assert s.count(a) == 1, (F, a[:90], s.count(a)); s = s.replace(a, b)
    open(p, 'w').write(s)
patch('InsightMonth.swift', [
("""/// the pill: "October 2026 ⌄", a menu of every month kosh has, newest first
struct InsightMonthMenu: View {
    @Binding var month: String
    let months: [String]
    let cm: String
    var body: some View {
        let newest: [String] = months.sorted(by: >)
        let title: String = Self.name(month, cm: cm)
        Menu {
            Picker("Month", selection: $month) {
                ForEach(newest, id: \\.self) { (m: String) in
                    Text(Self.name(m, cm: cm)).tag(m)
                }
            }
        } label: {
            HStack(spacing: 4) {
                Text(title).font(.subheadline.weight(.semibold))
                Image(systemName: "chevron.down").font(.system(size: 10, weight: .bold))
            }
            .foregroundStyle(Color.primary)
            .padding(.horizontal, 12).padding(.vertical, 7)
            .background(Color.primary.opacity(0.06), in: Capsule())
        }
        .accessibilityLabel("Month")
        .accessibilityValue(title)
    }
    /// "October 2026", "This month · November"
    static func name(_ m: String, cm: String) -> String {
        let full: String = Day.fmt(m + "-01", "MMMM yyyy")
        return m == cm ? "This month · " + Day.monthName(m) : full
    }
}""", """/// the pill: "November ⌄" ("March 2025 ⌄" in another year); its menu has every month kosh has, newest first, under its
/// year (1 Nov: no "This month ·", and the year said once as a heading, not on every month). `tint`: drawn inside a
/// card, in the card's colour (the pace card carries it on its right)
struct InsightMonthMenu: View {
    @Binding var month: String
    let months: [String]
    let cm: String
    var tint: Color? = nil
    var body: some View {
        let newest: [String] = months.sorted(by: >)
        let years: [String] = Self.years(newest)
        let title: String = Self.name(month, cm: cm)
        Menu {
            Picker("Month", selection: $month) {
                ForEach(years, id: \\.self) { (y: String) in
                    Section(y) {
                        ForEach(newest.filter { $0.hasPrefix(y) }, id: \\.self) { (m: String) in
                            Text(Day.monthName(m)).tag(m)
                        }
                    }
                }
            }
        } label: {
            HStack(spacing: 4) {
                Text(title).font(.subheadline.weight(.semibold)).lineLimit(1)
                Image(systemName: "chevron.down").font(.system(size: 10, weight: .bold))
            }
            .foregroundStyle(tint ?? Color.primary)
            .padding(.horizontal, 12).padding(.vertical, 7)
            .background((tint ?? Color.primary).opacity(tint == nil ? 0.06 : 0.12), in: Capsule())
            .contentShape(Capsule())
        }
        .accessibilityLabel("Month")
        .accessibilityValue(Day.fmt(month + "-01", "MMMM yyyy"))
    }
    /// "November" in this year, "March 2025" in another
    static func name(_ m: String, cm: String) -> String {
        m.prefix(4) == cm.prefix(4) ? Day.monthName(m) : Day.fmt(m + "-01", "MMMM yyyy")
    }
    /// the years the months fall in, newest first
    static func years(_ newest: [String]) -> [String] {
        var out: [String] = []
        for m in newest { let y: String = String(m.prefix(4)); if !out.contains(y) { out.append(y) } }
        return out
    }
}""", "static func years(_ newest: [String])"),
])
patch('MoneyViews.swift', [
("""                HStack {
                    InsightMonthMenu(month: Binding(get: { chosen }, set: { store.ledgerMonth = $0 }), months: allMonths, cm: cm)
                    Spacer(minLength: 0)
                }
                .padding(.bottom, -12)""", """                // (the month is picked on the pace card's right, 1 Nov; at the top only when that card is hidden)
                if !SectionPlan.shown(.txInsights, raw: plan).contains("pace") {
                    HStack {
                        InsightMonthMenu(month: Binding(get: { chosen }, set: { store.ledgerMonth = $0 }), months: allMonths, cm: cm)
                        Spacer(minLength: 0)
                    }
                    .padding(.bottom, -12)
                }""", "contains(\"pace\") {"),
("""                    case "pace": PaceHero()""", """                    case "pace":
                        PaceHero(menu: InsightMonthMenu(month: Binding(get: { chosen }, set: { store.ledgerMonth = $0 }),
                                                        months: allMonths, cm: cm, tint: InsightInk.blue))""", "PaceHero(menu: InsightMonthMenu("),
])
patch('InsightsBook.swift', [
("""    @Environment(\\.insightMonth) private var pickedMonth
    @State private var grown = false

    var body: some View {
        let live: Bool = pickedMonth.isEmpty || pickedMonth == store.snap.cm""", """    @Environment(\\.insightMonth) private var pickedMonth
    @State private var grown = false
    /// the page's month picker, carried on the card's right
    var menu: InsightMonthMenu? = nil

    var body: some View {
        let live: Bool = pickedMonth.isEmpty || pickedMonth == store.snap.cm""", "var menu: InsightMonthMenu? = nil"),
("""            let head: String = store.who.possessive(mo.name, family: mo.name) + (live ? ", day " + String(d) : "")
            VStack(alignment: .leading, spacing: 14) {
                VStack(alignment: .leading, spacing: 2) {
                    Text(head)
                        .font(.footnote.weight(.semibold))
                        .foregroundStyle(InsightInk.blue)""", """            // (the month itself is on the picker at the right: the line says only where in it, and whose)
            let whose: String = family ? "" : store.who.possessive("spending", family: "")
            let head: String = live ? (whose.isEmpty ? "Day " + String(d) + " so far" : whose + ", day " + String(d))
                                    : (whose.isEmpty ? "The whole month" : whose)
            VStack(alignment: .leading, spacing: 14) {
                VStack(alignment: .leading, spacing: 2) {
                    HStack(alignment: .center, spacing: 8) {
                        Text(head)
                            .font(.footnote.weight(.semibold))
                            .foregroundStyle(InsightInk.blue)
                            .lineLimit(1)
                        Spacer(minLength: 8)
                        if let menu { menu }
                    }""", "if let menu { menu }"),
])
print('swift D patched')
