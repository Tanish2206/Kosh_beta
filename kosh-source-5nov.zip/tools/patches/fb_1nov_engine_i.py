# kosh feedback 2 Nov (01:23) — engine, part I: one purchase, one row. Myntra's "There is A Slight Delay In Your Order"
# reprints "Total paid ₹1797.30 · HDFC Credit Card XX 4545" for one package of an order the card was charged ₹6,435
# for on 25 Oct; no charge of ₹1,797 answered it, so it became a payment of its own. Now a shop's mail about an order
# already on its way (shipped, delayed, out for delivery, delivered, a rating, an invoice) is never a payment by itself,
# and a shop's receipt paid on a card that carries a bigger charge to the same shop in the three weeks before (an order
# told in part) is told to that charge, not added. Idempotent.
p = 'Kosh/engine.js'; s = open(p).read()
def sub(old, new, mark):
    global s
    if mark in s: return
    assert s.count(old) == 1, ('engine I anchor', old[:70], s.count(old))
    s = s.replace(old, new)
sub("""    if (c.shipStep || LATER_SUBJ.test(subj)) return true;""",
    """    if (c.shipStep || LATER_SUBJ.test(subj) || /\\bdelay(?:ed)?\\b|\\bslight delay\\b|\\bdelivery (?:update|status)\\b|\\btrack(?:ing)? (?:your|my) order\\b/i.test(subj)) return true;""",
    "slight delay")
sub("""      // money onto a card stays on the card (the card's side of its bill paid); anything else went out some other way
      else keep({ ...c, kind: 'txn', instr: c.dir === 'in' && c.instr === 'card' ? 'card' : 'other', fromReceipt: true });""",
    """      /* GUARDRAIL one purchase, one row. A shop's mail about an order already on its way (shipped, delayed, out for
         delivery, delivered, a rating, an invoice) that no payment answered is that order told again, never a payment;
         and a receipt paid on a card or account that carries a bigger charge to the same shop in the three weeks before
         is part of that charge (an order of several packages, each mail reprinting its own share) */
      else if (c.dir === 'out' && laterStep(c) && (c.shipStep || /\b(?:shipped|dispatched|out for delivery|in transit|on (?:its|the) way|arriving|delay(?:ed)?|slight delay|delivered|track(?:ing)? (?:your|my) order)\b/i.test(String(c.subject || '')))) { (function () {
        var sw = brandWords(receiptNames(c).all);
        var whole = sw.length ? days.first(c.date, -21, 1, c.amt - 1, c.amt * 50, function (t) {
          var gap = daysBetween(t.date, c.date);
          if (t.dir !== 'out' || gap < -1 || gap > 21 || t.amt < c.amt - 1) return false;
          if (c.last4 && t.last4 && String(t.last4) !== String(c.last4)) return false;
          return brandWords((t.party || '') + ' ' + (t.inst || '') + ' ' + (t.info || '')).some(function (w) { return sw.indexOf(w) >= 0; });
        }) : null;
        if (whole) { if (c.orderId && !whole.orderId) whole.orderId = c.orderId; noteOrder(whole); tell(whole, c, alsoOf); }
      })(); }
      else if (c.dir === 'out' && c.last4 && /^(?:card|account)$/.test(c.instr || '') && (function () {
        var sw = brandWords(receiptNames(c).all);
        var whole = sw.length ? days.first(c.date, -21, 1, c.amt + 1, c.amt * 50, function (t) {
          var gap = daysBetween(t.date, c.date);
          return t.dir === 'out' && gap >= -1 && gap <= 21 && t.amt > c.amt + 1 && String(t.last4 || '') === String(c.last4) &&
            brandWords((t.party || '') + ' ' + (t.inst || '') + ' ' + (t.info || '')).some(function (w) { return sw.indexOf(w) >= 0; });
        }) : null;
        if (whole) { if (c.orderId && !whole.orderId) whole.orderId = c.orderId; noteOrder(whole); tell(whole, c, alsoOf); return true; }
        return false;
      })()) { /* told to its whole charge */ }
      // money onto a card stays on the card (the card's side of its bill paid); anything else went out some other way
      else keep({ ...c, kind: 'txn', instr: c.dir === 'in' && c.instr === 'card' ? 'card' : 'other', fromReceipt: true });""",
    "GUARDRAIL one purchase, one row.")
open(p, 'w').write(s)
print('engine I patched')
