#!/usr/bin/env python3
"""egdigits-4nov (statements chat): digits a mail prints only inside its password example ("for example if mobile
number is XXXXX12345 … the password will be 12345160982", SBI's e-statement mail) are no account. kosh made an SBI
account ••2345 from it, a blank tile every month. Any sender. Idempotent. Run from kosh-beta/."""
import sys
p = 'Kosh/engine.js'; s = open(p, encoding='utf-8').read()
if 'egdigits-4nov' in s: print('egdigits-4nov already applied'); sys.exit(0)
a = """    // an account or card being born, changed or closed, as its own bank writes of it (withLife, 3 Nov)
    try { out = withLife(out, msg); } catch (e) { /* the reading stands */ }"""
b = a + """
    // (egdigits-4nov) digits printed only in the mail's password example are no account or card
    try {
      if (out && out.kind !== 'txn' && out.kind !== 'confirm' && String(out.last4 || '').length >= 3) {
        var egTxt = (msg.subject || '') + ' \\n ' + normalize(msg.text || '', msg.html || ''), egL4 = String(out.last4), egAt = [], egI = egTxt.indexOf(egL4);
        while (egI >= 0) { egAt.push(egI); egI = egTxt.indexOf(egL4, egI + 1); }
        if (egAt.length && egAt.every(function (k) { return /\\b(?:for\\s+example|e\\.\\s?g\\.|example|for\\s+instance|sample)\\b/i.test(egTxt.slice(Math.max(0, k - 220), k)) && /password|passcode/i.test(egTxt.slice(Math.max(0, k - 300), k + 120)); })) {
          out.last4 = ''; if (out.instr === 'account' || out.instr === 'card') out.instr = '';
        }
      }
    } catch (e) { /* the reading stands */ }"""
if s.count(a) != 1: sys.exit('anchor %d' % s.count(a))
s = s.replace(a, b); open(p, 'w', encoding='utf-8').write(s); print('egdigits-4nov applied')
