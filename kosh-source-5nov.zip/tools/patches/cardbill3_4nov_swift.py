#!/usr/bin/env python3
"""cardbill3-4nov (Swift): statementReader +1 so kept card statements are read again with cbLinesTotal. Idempotent."""
import io, sys, re, hashlib
root = sys.argv[1] if len(sys.argv) > 1 else 'Kosh'
P = root + '/LiveSession+Statements.swift'
raw = io.open(P, 'rb').read(); h0 = hashlib.md5(raw).hexdigest(); s = raw.decode('utf-8')
if 'cardbill3-4nov' in s: print('already applied'); sys.exit(0)
m = re.search(r'static let statementReader = (\d+)\s+// \1 ', s); cur = int(m.group(1))
s = s.replace(m.group(0), "static let statementReader = %d   // %d (4 Nov, cardbill3-4nov): a card statement's total due proven by its own lines (HDFC Tata Neu read as its previous dues).\n    // %d " % (cur + 1, cur + 1, cur), 1)
assert hashlib.md5(io.open(P, 'rb').read()).hexdigest() == h0, 'changed underneath'
io.open(P, 'w', encoding='utf-8').write(s); print('applied; statementReader', cur + 1)
