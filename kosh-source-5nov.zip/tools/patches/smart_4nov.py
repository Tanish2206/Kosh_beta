#!/usr/bin/env python3
"""smart-4nov (statements chat, 4 Nov) - applied in place, tagged in the source. Phone-mode bench (stmt-bench --phone,
both texts + grid as the phone sends): 114 -> 136 of 158 add up, 0 wrong.
 engine.js heads-4nov: "Transaction" alone heads the narration (Axis), "Other Information" skipped; a "Date and Time"
   column's time is no part of its date (IDFC); "null" words in a label (SBI's "Your null Opening null Balance").
 engine.js sections-4nov: a second "Opening Balance" after the first table closed is another account's table: stop.
 engine.js bestof-4nov: parseDoc = parseDocOnce by columns, and by lines when the columns' reading contradicts itself
   and the lines' adds up.
 engine.js below-4nov: card summary figures printed under their labels (YES Bank), kept only when the sum holds.
 engine.js cover-4nov: out.cover {dated, read}; Swift understood() sends a partial, unconfirmed reading to the next
   reader (Claude reads it when that is on) instead of keeping it.
 tools/eval/pdfgrid.py: words within ~3pt make one printed line (as DocLayout).
 Swift: LiveSession+Statements.swift DocParsed.cover, understood(), statementReader 12."""
