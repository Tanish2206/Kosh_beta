# kosh-reader v4 ({"events":[…]}) wired in, rules first. 3 Nov 2026.
import re, sys
K = sys.argv[1] if len(sys.argv) > 1 else 'Kosh/'
def sub(path, old, new, count=1):
    s = open(K + path).read()
    n = s.count(old)
    assert n == count, (path, n, old[:80])
    open(K + path, 'w').write(s.replace(old, new))

# 1. reader.js: the local model's answer checked exactly as Claude's is, marked lr
sub('reader.js', "  E.clWantedJSON = function (msg) {",
"""  /* kosh-reader v4 on the phone answers in these same event shapes ({"events":[…]}), so its answer is checked exactly as
     Claude's is (clEvent: known fields only, every amount printed in the mail, a card's digits only if the mail has them)
     and marked lr (the local reader). Rules first: engine.js › withClaude lets a reading marked lr decide nothing the
     rules read, ranks it below yours and Claude's, and never teaches the book from it.
     {events} — no events at all is the model saying "not money"; {unsure} — not an answer, or nothing in it held up */
  function localAnswer(raw, msg) {
    var o;
    try { o = JSON.parse(String(raw || '').trim()); } catch (e) { return { unsure: 'unreadable answer' }; }
    if (!o || !Array.isArray(o.events)) return { unsure: 'not the reader\\u2019s shape' };
    if (!o.events.length) return { events: [{ type: 'noise', reason: 'info', lr: 1 }] };
    var H = clHay(msg, { toks: [], back: {} });
    var evs = o.events.map(function (e) { return clEvent(e, H); }).filter(Boolean);
    var real = evs.filter(function (e) { return e.type !== 'noise'; });
    if (real.length) evs = real;
    if (!evs.length) return { unsure: 'nothing kosh keeps' };
    evs.forEach(function (e) { delete e.cl; e.lr = 1; });
    return { events: evs };
  }
  api.localAnswer = localAnswer;
  E.readerAnswerJSON = function (raw, m) { return JSON.stringify(localAnswer(raw, JSON.parse(m))); };
  E.clWantedJSON = function (msg) {""")

# 2. engine.js › withClaude: whose reading it is (Claude's, or the phone's own model's)
sub('engine.js', """    var evs = cl.map(function (e) { var o = {}; for (var k in e) o[k] = e[k]; return o; });
    var by = { by: 'claude' };""",
"""    var evs = cl.map(function (e) { var o = {}; for (var k in e) o[k] = e[k]; return o; });
    // (kosh-reader on the phone answers in Claude's shapes, marked lr: its record says so, ranks below Claude's, and
    // never teaches the book: a guess is not a teacher)
    var who = evs.some(function (e) { return e && e.lr; }) ? 'reader' : 'claude', pre = who === 'claude' ? 'claude-' : 'model-';
    var by = { by: who };""")
sub('engine.js', """      rec.evs = r.evs; rec.src = 'claude'; rec.by = 'claude';
      rec.rule = String(rec.rule || '').replace(/^reader-/, 'claude-');""",
"""      rec.evs = r.evs; rec.src = who; rec.by = who;
      rec.rule = String(rec.rule || '').replace(/^reader-/, pre);""")
sub('engine.js', """{ kind: 'noise', rule: 'claude-' + why, src: 'claude', dir:""", """{ kind: 'noise', rule: pre + why, src: who, dir:""")
sub('engine.js', """{ rec.kind = 'confirm'; rec.rule = 'claude-receipt'; if (mv.purpose === 'investment') rec.purpose = mv.purpose; } else rec.rule = 'claude-' + (mv.purpose || mv.dir);""",
"""{ rec.kind = 'confirm'; rec.rule = pre + 'receipt'; if (mv.purpose === 'investment') rec.purpose = mv.purpose; } else rec.rule = pre + (mv.purpose || mv.dir);""")
sub('engine.js', """    if (BOOK && evs.every(function (e) { return !e.unsure; })) { try { RD.teach(""", """    if (who === 'claude' && BOOK && evs.every(function (e) { return !e.unsure; })) { try { RD.teach(""")

# 3. engine.js › readerDoc: a v4 answer on a document page, in the old shape readerDoc reads
sub('engine.js', """  function readerDoc(input, raw, original) {
    var r = checkReader(input, raw);""",
"""  /* kosh-reader v4 answers a page in events; readerDoc reads a policy (and a portal's property) in the old shape */
  function legacyOfEvents(raw) {
    var o; try { o = JSON.parse(String(raw || '').trim()); } catch (e) { return null; }
    if (!o || !Array.isArray(o.events)) return null;
    var p = o.events.filter(function (e) { return e && e.type === 'policy' && e.policyNo; })[0];
    if (!p) return { kind: o.events.length ? 'unsure' : 'not_money' };
    return { kind: 'policy', policy: { number: p.policyNo, insurer: p.insurer || '', plan: p.plan || '', premium: p.premium || 0, cover: p.cover || 0,
      frequency: p.frequency || '', start: p.start || '', next_due: p.due || '', term: p.term || 0, ppt: p.ppt || 0, insured: p.insured || '' } };
  }
  function readerDoc(input, raw, original) {
    var lg = legacyOfEvents(raw);
    if (lg) raw = JSON.stringify(lg);
    var r = checkReader(input, raw);""")
print('ok')
