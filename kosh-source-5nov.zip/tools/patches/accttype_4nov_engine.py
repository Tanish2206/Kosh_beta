#!/usr/bin/env python3
"""accttype-4nov (statements chat): what each account in a bank's statement IS, whatever the bank.
 1. A statement that lists a PPF, Sukanya, fixed, term or recurring deposit beside the savings account (SBI's e-account
    statement: savings ••4669 ₹1,234 and PPF ••0323 ₹14,37,084) gives that account as a HOLDING (wealth, cls ret/dep,
    with its rate, open and maturity dates), never a bank balance; its number is then no bank account anywhere (the PPF
    showed as an SBI bank account worth ₹12.5L, from a PPF deposit alert).
 2. "Account status: CLOSE" printed on a statement closes that account from that day (IDFC ••8242, closed Jul 2026).
 3. A statement that prints only "As on 30-09-26" is as of that day (SBI read as 25 Sep).
 4. Accounts with no money moving for 6 months and no statement saying otherwise are marked quiet (SBM).
Idempotent. Run from kosh-beta/."""
import sys
p = 'Kosh/engine.js'; s = open(p, encoding='utf-8').read()
if 'accttype-4nov' in s: print('accttype-4nov already applied'); sys.exit(0)
pairs = [
 # 1 + 2 + 3: in parseDoc's statement branch, after its dates are made sane
 ("""      stmtDatesSane(out, stmtMonthHint(title, sent), sent);""",
  """      stmtDatesSane(out, stmtMonthHint(title, sent), sent);
      // (accttype-4nov) what else the statement lists, by the bank's own word for each account
      if (!card) {
        var ty = stmtAccountTypes(text, from);
        if (ty.holdings.length) out.holdings = (out.holdings || []).concat(ty.holdings);
        if (ty.status) out.status = ty.status;
        if (ty.asOn && !out.to) { out.to = ty.asOn; if (out.close !== null && out.close !== undefined && !out.closeDate) out.closeDate = ty.asOn; }
        if (ty.asOn && out.closeDate && ty.asOn > out.closeDate && !(out.rows || []).length) out.closeDate = ty.asOn;
      }"""),
 ("""  function parseStmtDoc(flat) {""",
  """  /* (accttype-4nov) a statement's other accounts by the bank's own word for each (PPF, Sukanya, fixed / term / recurring
     deposit), as holdings; whether it says the account is closed; the day it is "as on" */
  var AT_TYPES = [
    [/\\b(?:ppf|public provident fund)\\b/i, 'PPF', 'ret'], [/\\b(?:sukanya(?:\\s+samriddhi)?|ssy)\\b/i, 'SSY', 'ret'],
    [/\\b(?:fixed deposits?|term deposits?|\\bfd\\b|\\btdr?\\b|mod\\s+deposit)\\b/i, 'FD', 'dep'], [/\\b(?:recurring deposits?|\\brd\\b)\\b/i, 'RD', 'dep'],
  ];
  function stmtAccountTypes(text, from) {
    var ins = institution(from || ''), inst = ins ? ins.short : '', out = { holdings: [], status: '', asOn: '' };
    var lines = String(text || '').split('\\n'), seen = {};
    lines.forEach(function (ln) {
      if (ST_DATE.test(ln.trim())) return;                      // a dated line is a payment, not an account
      var t = AT_TYPES.filter(function (x) { return x[0].test(ln); })[0];
      if (!t) return;
      var nm = /(?:[xX*•]{2,}[\\dxX*•\\- ]{0,10}?(\\d{3,6})|\\b(\\d{9,18}))\\b/.exec(ln);
      if (!nm) return;
      var l4 = (nm[1] || nm[2]).slice(-4);
      var amts = (ln.match(/(?:\\d{1,3}(?:,\\d{2,3})+|\\d+)\\.\\d{2}\\b/g) || []).map(function (x) { return +x.replace(/,/g, ''); });
      var bal = amts.filter(function (v) { return v >= 1; })[0];
      if (!(bal > 0) || seen[t[1] + l4]) return;
      seen[t[1] + l4] = 1;
      var rate = amts.filter(function (v) { return v > 0 && v < 20 && v !== bal; })[0] || 0;
      var ds = (ln.match(/\\b\\d{1,2}[\\-\\/.]\\d{1,2}[\\-\\/.]\\d{2,4}\\b/g) || []).map(function (x) { return stmtDate(x, null); }).filter(Boolean);
      var h = { bank: (inst ? inst + ' ' : '') + t[1] + ' ••' + l4, type: t[1], cls: t[2], amt: Math.round(bal * 100) / 100, rate: rate, rem: 'Its bank statement’s balance', depNo: l4 };
      if (ds.length) h.start = ds[0];
      if (ds.length > 1) h.mat = ds[ds.length - 1].slice(0, 7);
      out.holdings.push(h);
    });
    var st = /\\baccount\\s+status\\s*[:\\-]?\\s*(close[d]?|inactive|dormant)\\b/i.exec(text);
    if (st) out.status = /close/i.test(st[1]) ? 'closed' : 'dormant';
    var ao = /\\bas\\s+on\\s*[:\\-]?\\s*(\\d{1,2}[\\-\\/.]\\d{1,2}[\\-\\/.]\\d{2,4})\\b/i.exec(text);
    if (ao) { var dd = stmtDate(ao[1], null); if (dd) out.asOn = dd; }
    return out;
  }
  function parseStmtDoc(flat) {"""),
 # 1: a holding's number is no bank account; 2: a statement that says closed closes it
 ("""    var loanNos = loanNumbers(records);""",
  """    var loanNos = loanNumbers(records);
    // (accttype-4nov) a PPF / deposit a statement listed as such is no bank account
    (prof.holdings || []).forEach(function (h) {
      var m = /••(\\d{4})\\b/.exec(String(h.bank || '')); if (!m || !/^(?:ret|dep)$/.test(h.cls || '')) return;
      var ib = String(h.bank).split(' ')[0]; loanNos[canonInst(ib) + '|' + m[1]] = 1; loanNos[ib + '|' + m[1]] = 1;
    });"""),
 ("""    var closedAcct = {};
    records.forEach(function (r) {""",
  """    var closedAcct = {};
    // (accttype-4nov) a statement that prints the account closed
    (prof.statements || []).forEach(function (S) {
      if (S.status !== 'closed' || !S.last4) return;
      var ins0 = institution(S.from || ''), k0 = (S.inst || (ins0 ? ins0.short : '')) + '|' + String(S.last4).slice(-4), d0 = S.periodTo || S.sent || '';
      if (!closedAcct[k0] || (d0 && d0 < closedAcct[k0])) closedAcct[k0] = d0 || '0000';
    });
    records.forEach(function (r) {"""),
]
for a, b in pairs:
    if s.count(a) != 1: sys.exit('anchor %d: %r' % (s.count(a), a[:70]))
    s = s.replace(a, b)
open(p, 'w', encoding='utf-8').write(s); print('accttype-4nov applied')
