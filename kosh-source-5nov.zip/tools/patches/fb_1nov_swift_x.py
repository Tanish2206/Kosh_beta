# kosh feedback 2 Nov (02:14) — Swift, part X: "Paid from" as a clear route instead of a crowded row: the app it went
# through → the account it came from, each its own tile (the account a menu to pick from, "Choose the account" while
# kosh is still matching it), and one short line under it. Idempotent.
p = 'Kosh/Twice.swift'; s = open(p).read()
if 'PaidNode(' not in s:
    a = s.index("""        VStack(alignment: .leading, spacing: 8) {
            SheetCard {
                Menu {
                    ForEach(banks) { a in
                        Button { store.setPaidFrom(t.id, a) } label: {""")
    b = s.index("""            SheetFootnote(Self.why(t, app: app, known: known, likely: likely))
        }""", a) + len("""            SheetFootnote(Self.why(t, app: app, known: known, likely: likely))
        }""")
    s = s[:a] + """        let acct: String = (t.bk ?? "") + ((t.l4 ?? "").isEmpty ? "" : " ••" + (t.l4 ?? ""))
        let choices: [Account] = banks + store.snap.wallets
        VStack(alignment: .leading, spacing: 8) {
            SheetCard {
                VStack(alignment: .leading, spacing: 12) {
                    Text("Paid from").font(.footnote.weight(.semibold)).foregroundStyle(.secondary).textCase(.uppercase).tracking(0.6)
                    HStack(spacing: 8) {
                        PaidNode(sym: "app.badge", title: app, sub: "the app", lit: false)
                        Image(systemName: "arrow.right").font(.caption.weight(.bold)).foregroundStyle(.tertiary).accessibilityHidden(true)
                        Menu {
                            ForEach(choices) { a in
                                Button { store.setPaidFrom(t.id, a) } label: {
                                    if known && t.bk == a.bank && (t.l4 ?? "") == a.last {
                                        Label(a.bank + (a.last.isEmpty ? "" : " ••" + a.last), systemImage: "checkmark")
                                    } else {
                                        Text(a.bank + (a.last.isEmpty ? "" : " ••" + a.last))
                                    }
                                }
                            }
                        } label: {
                            PaidNode(sym: "building.columns", title: known ? acct + (likely ? "?" : "") : "Choose the account",
                                     sub: known ? (likely ? "a guess · tap to confirm" : "your account · change") : "not known yet", lit: !known || likely)
                        }
                        .disabled(choices.isEmpty)
                    }
                }
                .padding(16)
            }
            SheetFootnote(known && !likely ? "Matched from your bank’s alerts or statement."
                          : known ? "A guess: a debit of the same sum that day. " + app + "’s mail doesn’t say where the money came from, so pick it above to be sure."
                          : app + "’s mail doesn’t say where the money came from (a bank, a card or its own balance). kosh fills it in when your bank’s alert or statement shows it, or pick it above.")
        }""" + s[b:]
    s += '''

/// one end of a payment's route: the app it went through, or the account it came from
struct PaidNode: View {
    let sym: String
    let title: String
    let sub: String
    let lit: Bool
    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: sym).font(.subheadline.weight(.semibold)).foregroundStyle(Color.kosh)
                .frame(width: 30, height: 30).background(Color.kosh.opacity(0.12), in: Circle())
            VStack(alignment: .leading, spacing: 1) {
                Text(title).font(.subheadline.weight(.semibold)).foregroundStyle(lit ? Color.kosh : Color.primary).lineLimit(1).minimumScaleFactor(0.8)
                Text(sub).font(.caption).foregroundStyle(.secondary).lineLimit(1)
            }
            Spacer(minLength: 0)
        }
        .multilineTextAlignment(.leading)
        .padding(10)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color(.tertiarySystemFill), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous).strokeBorder(lit ? Color.kosh.opacity(0.5) : Color.clear, lineWidth: 1))
    }
}
'''
    open(p, 'w').write(s)
print('swift X patched')
