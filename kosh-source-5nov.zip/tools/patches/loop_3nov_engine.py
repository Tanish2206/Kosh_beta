#!/usr/bin/env python3
"""Bill payments, closed loop + payee learning (3 Nov 2026). Idempotent.
1. portalFacts: a bill or card bill paid through an app (Amazon Pay, CRED, PhonePe, Paytm, a bank's BillPay...) keeps
   the app, the biller, its order id, the Bharat Connect reference, the operator's reference, the UTR, the fee, how it was
   paid and the day the card was credited (reading.pp).
2. billLoopBook: each bill payment's details (tx.bl: biller, connection number, references) and its loop (tx.lp: the
   app it went through, the card or biller it paid, the money it left, and whether the bank confirmed it within 2 days);
   each card's recent bill payments (cards[].pays). A bill with a connection number says it even with no home placed.
3. Learning: a payee told without its UPI ID (an SMS, "To MADHAVRAJ") is the payee of the one UPI ID that goes by that
   name; one-word names of 7+ letters are names too; a payment you filed "just this one" teaches its payee's
   payments kosh only guessed at, of about the same sum (tx.ls)."""
import pathlib, sys
ROOT = pathlib.Path(__file__).resolve().parents[2]
p = ROOT / 'Kosh' / 'engine.js'
s = p.read_text()
if 'function portalFacts(' in s:
    print('loop_3nov_engine: already in'); sys.exit(0)

def put(anchor, new, before=False):
    global s
    if s.count(anchor) != 1: sys.exit('loop_3nov_engine: anchor not unique/missing: ' + anchor[:80])
    s = s.replace(anchor, (new + anchor) if before else (anchor + new), 1)

# 1. reading: the app a bill was paid through, and its references
put("""  /* ------------------------------------------------------------ Claude: the check and the backup */""", r"""  /* ------------------------------------------------------------ a bill paid through an app: where, and its references
     (3 Nov) A bill-payment receipt (Amazon Pay, CRED, PhonePe, Paytm, Google Pay, a bank's BillPay...) and a card bill
     paid through an app (CRED's "your credit card bill payment was successful") print what ties the payment to the
     biller or the card: the app, the biller it was paid to, the app's order id, the Bharat Connect (BBPS) reference,
     the operator's reference, the UTR, the convenience fee, how it was paid, the day the card was credited.
     portalFacts(msg, r) → { pt, bn, ord, ref, oref, utr, fee, how, cr } or null; each only under its own label. A
     receipt whose text part is a template (Amazon Pay's says "failed" on a success) is read from its HTML first */
  var BILL_APPS = [
    [/amazonpay|amazon pay|@amazon\./i, 'Amazon Pay'], [/cred\.club/i, 'CRED'], [/phonepe/i, 'PhonePe'], [/paytm/i, 'Paytm'],
    [/hdfcbankbillpay|hdfc bank bill ?pay/i, 'HDFC BillPay'], [/billdesk/i, 'BillDesk'], [/mobikwik/i, 'MobiKwik'], [/freecharge/i, 'Freecharge'],
    [/googlepay|google pay|gpay|payments-noreply@google/i, 'Google Pay'], [/airtel/i, 'Airtel Thanks'], [/bajaj ?pay|bajajfinserv/i, 'Bajaj Pay'],
    [/tataneu|tata neu/i, 'Tata Neu'], [/super\.money|supermoney/i, 'super.money'], [/\bnavi\b|navi\.com/i, 'Navi'], [/bhim/i, 'BHIM'],
    [/jiofinance|jio ?pay/i, 'JioFinance'], [/onecard|getonecard/i, 'OneCard'], [/icicibank.*bill|bill.*icici/i, 'ICICI BillPay'], [/axis.*bill ?pay/i, 'Axis BillPay']
  ];
  function portalOf(from, subject) {
    var hay = String(from || '') + ' ' + String(subject || '');
    for (var i = 0; i < BILL_APPS.length; i++) if (BILL_APPS[i][0].test(hay)) return BILL_APPS[i][1];
    return '';
  }
  var PP_VAL = '([A-Z0-9][A-Z0-9\\-\\/]{5,44})';
  function ppGet(flat, label) {
    var re = new RegExp('(?:' + label + ')\\s*(?:no\\.?|number|num|id|#)?\\s*[:\\-|#.]?\\s*' + PP_VAL + '(?![\\w])', 'i');
    var m = re.exec(flat);
    return m && /\d/.test(m[1]) && !/^(?:19|20)\d{2}$/.test(m[1]) ? m[1].replace(/[\-\/]+$/, '') : '';
  }
  function portalFacts(msg, r) {
    if (!r || !msg || !/^(?:bill|txn|confirm)$/.test(r.kind || '')) return null;
    var pt = portalOf(msg.from, '');
    var billish = r.rule === 'bill-paid' || r.rule === 'card-bill-paid' || !!r.bf || r.cat === 'Bills' || r.cat === 'Card Payments';
    if (!billish || (!pt && r.rule !== 'bill-paid' && r.rule !== 'card-bill-paid')) return null;
    var subj = String(msg.subject || '');
    var flats = [];
    if (msg.html) flats.push(subj + '\n' + mailLines({ text: '', html: msg.html }).slice(0, 220).join('\n'));
    if (msg.text) flats.push(subj + '\n' + mailLines({ text: msg.text, html: '' }).slice(0, 220).join('\n'));
    var o = {};
    if (pt) o.pt = pt;
    var get = function (k, label) { for (var i = 0; i < flats.length && !o[k]; i++) { var v = ppGet(flats[i], label); if (v) o[k] = v; } };
    get('ref', 'bharat\\s*connect(?:\\s*(?:reference|ref\\.?|transaction|txn))?|bbps\\s*(?:reference|ref\\.?|transaction|txn)(?:\\s*id)?|b-connect\\s*(?:reference|ref\\.?)');
    get('oref', 'operator\\s*(?:reference|ref\\.?|transaction|txn)(?:\\s*id)?|biller\\s*(?:reference|ref\\.?|transaction)\\s*(?:id|no\\.?|number)?');
    get('ord', 'order\\s*(?:id|no\\.?|number|#)');
    get('utr', 'utr(?:\\s*(?:no\\.?|number|ref\\.?))?|rrn|upi\\s*(?:ref|reference|transaction)\\s*(?:no\\.?|number|id)?');
    for (var i = 0; i < flats.length; i++) {
      var f = flats[i], m;
      if (o.fee === undefined && (m = /convenience\s*fee\s*[:|\-\n]*\s*(?:₹|rs\.?|inr)?\s*([\d,]+(?:\.\d{1,2})?)/i.exec(f))) o.fee = +m[1].replace(/,/g, '');
      if (!o.how && (m = /payment\s*(?:method|mode)\s*[:|\-\n]*\s*([A-Za-z][A-Za-z ]{1,24})/i.exec(f))) o.how = m[1].trim().split(/\s{2,}|\s+(?:utr|ref|reference|order|txn|transaction)\b/i)[0];
      if (!o.cr && (m = /credited\s*to\s*(?:your\s*)?card\s*(?:on)?\s*[:|\-\n]*\s*([A-Za-z]{3,9}\s+\d{1,2},?\s+\d{4}|\d{1,2}[\s\-\/][A-Za-z]{3,9}[\s\-\/,]+\d{2,4}|\d{1,2}[\-\/]\d{1,2}[\-\/]\d{2,4})/i.exec(f))) { var cd = isoDate(m[1], ''); if (cd && validDay(cd)) o.cr = cd; }
      if (!o.bn && (m = /\bpaid to\s*[:|\-\n]*\s*([A-Za-z][A-Za-z0-9&().,'\- ]{1,70}?)\s*(?:\n|payment details|amount\b|₹|rs\.?\s|$)/i.exec(f))) { var bn = m[1].replace(/\s+/g, ' ').trim(); if (bn.length >= 2 && !/^(?:amount|you|your)$/i.test(bn)) o.bn = bn.slice(0, 60); }
    }
    if (!o.bn && r.bf && r.bf.to && !/^\d{4}-\d{2}-\d{2}$/.test(r.bf.to)) o.bn = String(r.bf.to).slice(0, 60);
    if (o.fee === 0) delete o.fee;
    // (a template's sample figure is no reference: "AB123456")
    ['ref', 'oref', 'ord', 'utr'].forEach(function (k) { if (o[k] && /^(?:AB)?123456(?:7890?)?$|^X{4,}$/i.test(o[k])) delete o[k]; });
    return Object.keys(o).length ? o : null;
  }
""", before=True)
put("""    try { var bfx = billFacts(msg, out); if (bfx) out.bf = bfx; } catch (e) { /* the reading stands */ }""", """
    // the app a bill was paid through, and the references that tie it to the biller or the card (portalFacts, 3 Nov)
    try { var ppx = portalFacts(msg, out); if (ppx) out.pp = ppx; } catch (e) { /* the reading stands */ }""")

# 2. build: bill details, the loop, each card's bill payments
put("""  var homesBook = (function () {""", r"""  /* ------------------------------------------------------------ bills paid: details and the closed loop (3 Nov)
     Every payment of a bill says what it paid: tx.bl { k, bn (biller), nol, no (its connection number), ref (Bharat
     Connect), oref (operator's), ord (the app's order), utr, fee, from, to (the days it covers) }, from the payment's own
     mail and every mail that told it (its receipt, the bank's alert). A card's bill paid (k cardpay, money out) and a
     home's bill paid carry their loop: tx.lp { pt (the app it went through, or the bank), card (the card's row) and l4,
     src (the money it left: "HDFC ••6150", "Amazon Pay balance"), st, on, cid, ord, utr }. st: "done" (the bank said the
     card was paid: its "payment received", the payment's pair; for a home's bill, the bank's or wallet's own word of the
     money leaving beside the app's receipt), "wait" (within two days of paying: banks take up to 48 hours), "open" (past
     two days, in the last 45, nothing from the bank), "old" (older, nothing in the mail). Each card keeps its latest
     six bill payments (cards[].pays), newest first. A bill with a connection number says it on its row (bh) even
     when kosh can't place its home, and a row the app named only "Gas bill" takes the biller's name. */
  function billLoopBook(snapOut, ctx) {
    var rows = snapOut.tx || [], today = ctx.today || '';
    var recById = {}, inner = {}, rowById = {};
    (ctx.records || []).forEach(function (r) { if (r && r.id) recById[r.id] = r; });
    (ctx.tx || []).forEach(function (t) { inner[t.id] = t; });
    rows.forEach(function (t) { rowById[t.id] = t; });
    var cards = snapOut.cards || [];
    function cardOf(l4, bank) {
      if (!l4) return null;
      var hit = cards.filter(function (c) { return String(c.last || '') === String(l4); });
      if (hit.length > 1 && bank) { var b = String(bank).toLowerCase().split(/\s+/)[0]; var nb = hit.filter(function (c) { return String(c.bank || '').toLowerCase().indexOf(b) === 0; }); if (nb.length) hit = nb; }
      return hit[0] || null;
    }
    var GENERIC_BILL = /^(?:gas|electricity|water|broadband|internet|dth|mobile|postpaid|landline|lpg|piped gas|fastag|cable|insurance premium|maintenance)(?: bill)?(?: payment)?$/i;
    var isDay = function (x) { return /^\d{4}-\d{2}-\d{2}$/.test(String(x || '')); };
    rows.forEach(function (R) {
      if (R.partOf || R.mr) return;
      var T = inner[R.id] || {};
      var ids = [R.id].concat(T.rc ? [T.rc] : [], T.told || []);
      var recs = ids.filter(function (x, i, a) { return x && a.indexOf(x) === i; }).map(function (x) { return recById[x]; }).filter(Boolean);
      var bfR = recs.filter(function (r) { return r.bf; })[0], ppR = recs.filter(function (r) { return r.pp; })[0];
      var bf = bfR ? bfR.bf : null, pp = ppR ? ppR.pp : null;
      var out = R.dr === 'out' || (R.dr === undefined && R.k !== 'in');
      if (!out) return;
      // the bill's details
      if (bf || (pp && R.c === 'Bills')) {
        var bl = {};
        if (bf && bf.k) bl.k = bf.k;
        var bn = (pp && pp.bn) || (bf && bf.to && !isDay(bf.to) ? bf.to : '');
        if (bn) bl.bn = bn;
        if (bf && bf.no) { bl.no = bf.no; bl.nol = bf.nol || 'Account'; }
        if (pp) ['ref', 'oref', 'ord', 'utr', 'fee'].forEach(function (k) { if (pp[k] !== undefined && pp[k] !== '') bl[k] = pp[k]; });
        if (bf && isDay(bf.from) && isDay(bf.to)) { bl.from = bf.from; bl.to = bf.to; }
        if (bf && bf.units > 0) { bl.units = bf.units; bl.unit = bf.unit || ''; }
        if (Object.keys(bl).length) R.bl = bl;
        if (bl.no && !R.bh) R.bh = [bl.bn || '', bl.nol + ' ' + bl.no].filter(Boolean).join(' · ');
        if (bl.bn && GENERIC_BILL.test(String(R.m || '').trim())) {
          // (its short name when it prints one: "Maharashtra Natural Gas Limited (MNGL)" is MNGL)
          var ac = /\(([A-Z][A-Za-z&]{1,9})\)\s*$/.exec(bl.bn);
          R.m = ac ? ac[1] : bl.bn.replace(/\s+(?:private|pvt\.?)?\s*(?:limited|ltd\.?)$/i, '').trim();
        }
      }
      // the loop
      var md = R.md || '', funded = '';
      if (R.bk && !(R.via && R.bk === R.via)) {
        var w = /wallet/.test(md) || /balance|wallet|pay$/i.test(R.bk);
        funded = R.bk + (R.l4 && !w ? ' ••' + R.l4 : '');
        if (R.fg) funded += ' (likely)';
      }
      if (R.k === 'cardpay') {
        // (the card the app's receipt names: CRED's "HDFC Bank •••• 5192", even when the bank's debit is the row)
        var appR = recs.filter(function (r) { return r.rule === 'card-bill-paid' && r.instr === 'card' && String(r.last4 || '').length >= 3; })[0];
        var l4 = R.pl4 || T.cd || (appR ? String(appR.last4) : '') || (T.instKind === 'app' ? R.l4 : '') || '';
        var paidFrom = R.via ? funded : funded;
        var cardRow = cardOf(l4, T.issuer || (appR && appR.issuer) || '');
        // (a bank's debit that names the card's bank only, "American Express", "SBI Card": its one card with that bank)
        if (!cardRow && !l4) {
          var said = String(R.m || '').toLowerCase();
          var byBank = cards.filter(function (c) { var b = String(c.bank || '').toLowerCase(); return b.length >= 3 && !c.old && (said.indexOf(b) >= 0 || (b === 'amex' && /american express|aexp/.test(said))); });
          if (byBank.length === 1) { cardRow = byBank[0]; l4 = String(cardRow.last || ''); }
        }
        var lp = { pt: R.via || (pp && pp.pt) || '', l4: l4 || '' };
        if (cardRow) lp.card = cardRow.id;
        if (paidFrom) lp.src = paidFrom;
        if (pp && pp.ord) lp.ord = pp.ord;
        if (pp && pp.utr) lp.utr = pp.utr;
        if (pp && pp.cr) lp.cr = pp.cr;
        var P = R.pair ? rowById[R.pair] : null;
        var age = isDay(R.d) && isDay(today) ? daysBetween(R.d, today) : 99;
        if (P) { lp.st = 'done'; lp.on = P.d; lp.cid = P.id; lp.by = cardRow ? cardRow.bank : (P.bk || ''); }
        else lp.st = age <= 2 ? 'wait' : age <= 45 ? 'open' : 'old';
        if (!lp.by && cardRow) lp.by = cardRow.bank;
        R.lp = lp;
      } else if (R.bl) {
        // a home's bill: the app's receipt beside the bank's (or the wallet's) own word of the money leaving
        var receipt = recs.some(function (r) { return r.kind === 'confirm' || r.pp; });
        var alert = recs.some(function (r) { return r.kind === 'txn' && !r.fromReceipt && !r.pp; });
        var pt2 = (pp && pp.pt) || R.via || '';
        var lp2 = { pt: pt2 };
        if (funded) lp2.src = funded;
        if (pp && pp.ord) lp2.ord = pp.ord;
        if (R.bl.ref) lp2.ref = R.bl.ref;
        var age2 = isDay(R.d) && isDay(today) ? daysBetween(R.d, today) : 99;
        if (alert) { lp2.st = 'done'; lp2.on = R.d; lp2.by = R.bk || ''; }
        else lp2.st = !receipt ? 'done' : age2 <= 2 ? 'wait' : age2 <= 45 ? 'open' : 'old';
        R.lp = lp2;
      }
    });
    // each card's latest bill payments, newest first
    var byCard = {};
    rows.forEach(function (R) { if (R.lp && R.lp.card) (byCard[R.lp.card] = byCard[R.lp.card] || []).push(R); });
    cards.forEach(function (c) {
      var l = (byCard[c.id] || []).sort(function (a, b) { return String(b.d).localeCompare(String(a.d)); }).slice(0, 6);
      if (l.length) c.pays = l.map(function (R) { var x = { id: R.id, d: R.d, a: R.a, st: R.lp.st }; if (R.lp.pt) x.pt = R.lp.pt; if (R.lp.src) x.src = R.lp.src; if (R.lp.on) x.on = R.lp.on; return x; });
    });
  }
""", before=True)
put("""    try { homesBook(snapOut, { tx: tx, records: records, prof: prof, today: today }); } catch (e) { snapOut.postError = (snapOut.postError ? snapOut.postError + '; ' : '') + 'homes: ' + String(e && e.message || e).slice(0, 120); }""", """
    try { billLoopBook(snapOut, { tx: tx, records: records, today: today }); } catch (e) { snapOut.postError = (snapOut.postError ? snapOut.postError + '; ' : '') + 'bill loop: ' + String(e && e.message || e).slice(0, 120); }""")

# 3. learning
put("""        if (g) { r.lkAs = k; r.party = g; r.shownAs = g; }
      });
    })();""", r"""
    /* GUARDRAIL one payee told two ways is one payee (3 Nov): the bank's SMS prints the name only ("Sent Rs.1000.00 ...
       To MADHAVRAJ"), its mail the UPI ID and the name ("VPA madhavarajayadavyadav@okhdfcbank (MADHAVRAJ)"). A payment
       with no UPI ID whose payee's name is the name of exactly one UPI ID kosh has seen learns as that UPI ID's payee,
       so what you file on either carries to the other, before and after. Two UPI IDs by one name: neither */
    (function bridgeKeys() {
      var vBy = {};
      merged.forEach(function (r) {
        var v = String(r.vpa || '').toLowerCase().trim();
        if (!v || v.indexOf('@') < 1) return;
        var nk = learnKey(Object.assign({}, r, { vpa: '' }));
        if (nk) (vBy[nk] = vBy[nk] || {})[(r.dir === 'in' ? 'in' : 'out') + '|v:' + v] = 1;
      });
      merged.forEach(function (r) {
        if (r.lkAs || String(r.vpa || '').indexOf('@') > 0) return;
        var k = learnKey(r), vs = k && vBy[k] ? Object.keys(vBy[k]) : [];
        if (vs.length === 1) r.lkAs = vs[0];
      });
    })();""")
put("""    function nameKey(r) {
      var n = niceName(r).toLowerCase().replace(/[^a-z ]/g, ' ').replace(/\\s+/g, ' ').trim();
      return n.split(' ').length >= 2 && n.replace(/ /g, '').length >= 8""", "", before=False)
s = s.replace("""    function nameKey(r) {
      var n = niceName(r).toLowerCase().replace(/[^a-z ]/g, ' ').replace(/\\s+/g, ' ').trim();
      return n.split(' ').length >= 2 && n.replace(/ /g, '').length >= 8""", """    function nameKey(r) {
      var n = niceName(r).toLowerCase().replace(/[^a-z ]/g, ' ').replace(/\\s+/g, ' ').trim();
      // (one long word is a name too, 3 Nov: "madhavraj")
      return (n.split(' ').length >= 2 ? n.replace(/ /g, '').length >= 8 : n.length >= 7 && !/^(?:payment|transfer|account|unknown|merchant|deposit|cashback|reversal|interest|charges|purchase|withdrawal)$/.test(n))""", 1)
put("""      if (nk && nk !== lk) learn(byName, nk, r, o, lc_, lf_, lr_);
    });""", r"""
    /* a payment you filed "just this one" still says what its payee usually is (3 Nov): its payee's other payments that
       kosh only guessed at (no category of yours, kosh unsure) of about the same sum (within a quarter, or ₹50) are
       filed so too, before and after: a monthly car wash tagged in November files September's. What you file yourself
       on any of them wins; so does a payee you filed for all */
    var soft = {};
    merged.forEach(function (r) {
      var o = over[r.id];
      if (!o || !o.c || o.by || String(o.only || '').indexOf('c') < 0 || r.dir !== 'out') return;
      [r.lkAs || learnKey(r), nameKey(r)].forEach(function (k) {
        if (!k) return;
        var S = soft[k] || (soft[k] = { amts: [], d: '' });
        S.amts.push(money(r.amt));
        if ((r.date || '') >= S.d) { S.d = r.date || ''; S.c = o.c; S.s = o.s || ''; S.id = r.id; }
      });
    });
    function softFor(r, lk, nk) {
      var S = (lk && soft[lk]) || (nk && soft[nk]);
      if (!S || !S.c || S.id === r.id) return null;
      return S.amts.some(function (a) { return Math.abs(a - r.amt) <= Math.max(50, a * 0.25); }) ? S : null;
    }""")
put("""      var L = ck ? {} : lk && learned[lk] ? learned[lk] : nk0 && byName[nk0] && byName[nk0].c ? byName[nk0] : {};""", r"""
      var LS = null;
      if (!L.c && !ck && !o.c && r.dir === 'out' && (cl.u || cl.g || cl.slp || cl.c === 'Miscellaneous')) { LS = softFor(r, lk, nameKey(r)); if (LS) L = { c: LS.c, s: LS.s, by: '' }; }""")
s = s.replace("""        lr: !mineC && !!L.c, uc: oc""", """        lr: !mineC && !!L.c, ls: LS ? (LS.d || 'y') : undefined, uc: oc""", 1)
s = s.replace("""lr: t.lr || undefined, rt: t.rt || undefined,""", """lr: t.lr || undefined, ls: t.ls || undefined, rt: t.rt || undefined,""", 1)
p.write_text(s)
# the phone reads every mail again with the new reading (the app's own fingerprint, engine-read.json)
rp = ROOT / 'Kosh' / 'engine-read.json'
import json
j = json.loads(rp.read_text())
if not j['read'].endswith('-loop3nov'):
    j['read'] = j['read'].split('-')[0] + '-loop3nov'
    rp.write_text(json.dumps(j))
print('loop_3nov_engine: applied')
