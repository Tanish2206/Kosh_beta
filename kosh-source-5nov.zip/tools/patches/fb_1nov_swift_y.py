# kosh feedback 2 Nov (02:13) — Swift, part Y: an event booked is followed to the day. Its order says the event, its
# day and time, the tickets and a countdown ("in 96 days"); kosh's note says it all; and kosh reminds you a week
# before, the evening before and on the day (local notifications, once each, moved if the day changes, gone when it
# has passed). Idempotent.
def sub(path, old, new, mark):
    s = open(path).read()
    if mark in s: return
    assert s.count(old) == 1, (path, old[:70], s.count(old))
    open(path, 'w').write(s.replace(old, new))
sub('Kosh/Orders.swift', """        var venue: String? = nil
        var city: String? = nil
    }
    /// a journey or a stay booked (the phone's trip pass)""", """        var venue: String? = nil
        var city: String? = nil
        var time: String? = nil
        var till: String? = nil
        var tier: String? = nil
    }
    /// a journey or a stay booked (the phone's trip pass)""", 'var tier: String? = nil')
sub('Kosh/Orders.swift', """        var parts: [String] = [s.name]
        if let n = s.n, n > 0 { parts.append(n == 1 ? "1 ticket" : String(n) + " tickets") }
        if let on = s.on, !on.isEmpty { parts.append(day(on)) }""", """        var parts: [String] = [s.name]
        if let n = s.n, n > 0 { parts.append(n == 1 ? "1 ticket" : String(n) + " tickets") }
        if let on = s.on, !on.isEmpty { parts.append(day(on) + (s.time.map { ", " + $0 } ?? "") + EventWords.countdown(on)) }""", 'EventWords.countdown(on)')
code = '''import Foundation
import UserNotifications

/// an event booked, followed to its day (fb 2 Nov)
enum EventWords {
    static func today() -> String { Day.iso(Date()) }
    /// " · in 96 days", " · tomorrow", " · today"; "" once it has passed
    static func countdown(_ on: String) -> String {
        let n: Int = Day.between(today(), on)
        if n < 0 { return "" }
        if n == 0 { return " · today" }
        if n == 1 { return " · tomorrow" }
        return " · in " + String(n) + " days"
    }
    /// kosh's note for an event: name, day and time, tickets and tier, venue, booking
    static func note(_ s: OrdersBook.Show, booking: String?) -> String {
        var lines: [String] = [s.name + (s.city.map { " · " + $0 } ?? "")]
        if let on = s.on { lines.append(Day.fmt(on, "EEE d MMM yyyy") + (s.time.map { ", " + $0 } ?? "") + (s.till.map { " – " + $0 } ?? "")) }
        var t: [String] = []
        if let n = s.n, n > 0 { t.append(n == 1 ? "1 ticket" : String(n) + " tickets") }
        if let tier = s.tier, !tier.isEmpty { t.append(tier) }
        if !t.isEmpty { lines.append(t.joined(separator: " · ")) }
        if let v = s.venue, !v.isEmpty { lines.append(v) }
        if let b = booking, !b.isEmpty { lines.append("Booking " + b) }
        return lines.joined(separator: "\\n")
    }
}

/// reminders for the events booked: a week before (10 am), the evening before (7 pm), the morning of (9 am)
@MainActor
enum EventReminders {
    static func schedule(_ store: Store) {
        let center = UNUserNotificationCenter.current()
        let today: String = EventWords.today()
        var wanted: [UNNotificationRequest] = []
        for t in store.snap.tx where t.k == "out" && t.partOf == nil {
            guard let o = store.order(t), let s = o.show, let on = s.on, on >= today else { continue }
            let when: String = Day.fmt(on, "EEE d MMM") + (s.time.map { ", " + $0 } ?? "")
            let tickets: String = s.n.map { $0 == 1 ? " · 1 ticket" : " · " + String($0) + " tickets" } ?? ""
            let plan: [(String, Int, Int, String)] = [("week", -7, 10, "In a week: " + s.name),
                                                      ("eve", -1, 19, "Tomorrow: " + s.name),
                                                      ("day", 0, 9, "Today: " + s.name)]
            for (k, back, hour, title) in plan {
                let d: String = Day.add(on, back)
                if d < today { continue }
                var dc = Calendar.current.dateComponents([.year, .month, .day], from: Day.date(d))
                dc.hour = hour; dc.minute = 0
                let c = UNMutableNotificationContent()
                c.title = title
                c.body = when + tickets + (s.venue.map { " · " + $0 } ?? "") + (o.o.map { " · booking " + $0 } ?? "")
                c.sound = .default
                wanted.append(UNNotificationRequest(identifier: "kosh.event." + t.id + "." + k + "." + on, content: c, trigger: UNCalendarNotificationTrigger(dateMatching: dc, repeats: false)))
            }
        }
        center.getPendingNotificationRequests { pending in
            let mine: [String] = pending.map(\\.identifier).filter { $0.hasPrefix("kosh.event.") }
            let keep: Set<String> = Set(wanted.map(\\.identifier))
            center.removePendingNotificationRequests(withIdentifiers: mine.filter { !keep.contains($0) })
            for r in wanted where !mine.contains(r.identifier) { center.add(r) }
        }
    }
}
'''
import os
open('tools/patches/files/Events.swift', 'w').write(code)
if not os.path.exists('Kosh/Events.swift') or open('Kosh/Events.swift').read() != code:
    open('Kosh/Events.swift', 'w').write(code)
sub('Kosh/Store.swift', """        AutoNote.apply(self)""", """        AutoNote.apply(self)
        EventReminders.schedule(self)""", 'EventReminders.schedule(self)')
# kosh's note for an event booking
p = 'tools/patches/files/AutoNote.swift'
s = open(p).read()
if 'EventWords.note(' not in s:
    s = s.replace("""        guard let f = store.payFact(t) else { return nil }""", """        if let o = store.order(t), let show = o.show { return EventWords.note(show, booking: o.o) }
        guard let f = store.payFact(t) else { return nil }""")
    open(p, 'w').write(s)
    open('Kosh/AutoNote.swift', 'w').write(s)
print('swift Y patched')
