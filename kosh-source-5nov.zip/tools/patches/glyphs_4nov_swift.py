#!/usr/bin/env python3
"""glyphs-4nov (kosh ios app chat, 4 Nov): a statement's letters that PDFKit gives no box for are no longer dropped.
DocText.read rebuilds each line from where its characters sit, and skipped any character whose characterBounds came back
empty; AU Small Finance Bank's statements have such glyphs, so their lines read "Portf li S mmary as o n 31" (the letter
gone, its gap read as a space). Now a run of such letters between two that do have boxes, on one line, is placed in the
gap between them. A statement's text kept from before this (vault, beta) is fetched and read once more with it: marked
by DocText.extractor beside the kept text; kept text stays in use when the file can't be fetched again. Idempotent.
Run from kosh-beta/: python3 tools/patches/glyphs_4nov_swift.py"""
import sys
done = []
def patch(path, pairs):
    s = open(path, encoding='utf-8').read()
    for old, new, marker in pairs:
        if marker in s: continue
        c = s.count(old)
        if c != 1: sys.exit('%s: anchor %d times (want 1): %r' % (path, c, old[:90]))
        s = s.replace(old, new); done.append(path.split('/')[-1] + ':' + marker[:30])
    open(path, 'w', encoding='utf-8').write(s)

patch('Kosh/Documents.swift', [
("""            for j in 0..<ns.length {
                let c = ns.character(at: j)
                if c == 10 || c == 13 { continue }
                let r = page.characterBounds(at: j)
                if r.isNull || r.isEmpty || !r.minX.isFinite || !r.minY.isFinite { continue }
                chars.append(DocLayout.Glyph(c: c, r: r))
            }""",
"""            // (glyphs-4nov: letters PDFKit gives no box for, AU's "Portf li S mmary", are placed in the gap their
            // neighbours on the line leave for them, never dropped and read as a space)
            var lost: [UInt16] = []
            for j in 0..<ns.length {
                let c = ns.character(at: j)
                if c == 10 || c == 13 { lost.removeAll(); continue }
                let r = page.characterBounds(at: j)
                if r.isNull || r.isEmpty || !r.minX.isFinite || !r.minY.isFinite {
                    if c != 32 && c != 9 && c != 160 && !chars.isEmpty && lost.count < 4 { lost.append(c) } else if c == 32 || c == 9 { lost.removeAll() }
                    continue
                }
                if !lost.isEmpty, let prev = chars.last {
                    DocText.place(lost, after: prev.r, before: r, into: &chars)
                    lost.removeAll()
                }
                chars.append(DocLayout.Glyph(c: c, r: r))
            }""",
"DocText.place(lost, after: prev.r"),
("""    static let gridSep = "\\n\\u{1F}\\n\"""",
"""    static let gridSep = "\\n\\u{1F}\\n"
    /// which way of reading a PDF's letters a kept text came from (glyphs-4nov: "2", letters without a box placed)
    static let extractor = "2"

    /// letters with no box of their own between two that have one, on one line, set across the gap between them (each
    /// a share of it): only when the gap is about as wide as that many letters, never on a turned line
    static func place(_ lost: [UInt16], after a: CGRect, before b: CGRect, into chars: inout [DocLayout.Glyph]) {
        let n = CGFloat(lost.count)
        let gap: CGFloat = b.minX - a.maxX
        let cw: CGFloat = max(a.width, b.width, 1)
        let line: Bool = abs(b.midY - a.midY) < max(a.height, b.height) * 0.6
        guard line, gap >= cw * 0.25 * n, gap <= cw * 2.5 * n else { return }
        let w: CGFloat = gap / n
        for (k, c) in lost.enumerated() {
            chars.append(DocLayout.Glyph(c: c, r: CGRect(x: a.maxX + w * CGFloat(k), y: a.minY, width: w, height: a.height)))
        }
    }""",
"static let extractor = \"2\""),
])

patch('Kosh/LiveSession+Statements.swift', [
("""    static func keptReads(_ kept: String, kind: String) -> Bool {""",
"""    /// (glyphs-4nov) a statement's kept text came from today's way of reading a PDF's letters: else it is fetched once more
    static func keptExtractedNow(_ key: String, file: String, kind: String) -> Bool {
        guard kind == "stmt" || kind == "cardstmt" || kind == "cas", file.lowercased().hasSuffix(".pdf") else { return true }
        return MailVault.getText(key + "|x") == DocText.extractor
    }

    static func keptReads(_ kept: String, kind: String) -> Bool {""",
"static func keptExtractedNow("),
("""            let oldKey = d.msg + "|" + d.att
            let result: DocUnlock.Result""",
"""            let oldKey = d.msg + "|" + d.att
            // (glyphs-4nov) a statement kept from before letters without a box were placed: fetched again, once; when it
            // can't be fetched, what was kept is read as it was
            let keptNow: String? = typed == nil && opened == nil ? (MailVault.getText(textKey) ?? MailVault.getText(oldKey)) : nil
            var useKept: Bool = keptNow.map { Self.keptReads($0, kind: d.kind) } ?? false
            var prefetched: Data? = nil
            if useKept && d.att != "body" && !Self.keptExtractedNow(textKey, file: d.file, kind: d.kind) {
                if let got = try? await docBytes(&d) { prefetched = got; useKept = false }
            }
            let result: DocUnlock.Result""",
"var prefetched: Data? = nil"),
("""                result = .opened(opened)
                MailVault.putText(opened, key: textKey)""",
"""                result = .opened(opened)
                MailVault.putText(opened, key: textKey)
                MailVault.putText(DocText.extractor, key: textKey + "|x")""",
"MailVault.putText(DocText.extractor, key: textKey + \"|x\")\n            } else if"),
("""            } else if typed == nil, let kept = MailVault.getText(textKey) ?? MailVault.getText(oldKey), Self.keptReads(kept, kind: d.kind) {
                result = .opened(kept)""",
"""            } else if useKept, let kept = keptNow {
                result = .opened(kept)""",
"} else if useKept, let kept = keptNow {"),
("""                let bytes = try await docBytes(&d)
                let from = d.from
                let fresh = await Task.detached(priority: .utility) { await DocUnlock.open(bytes, sender: from, typed: typed) }.value""",
"""                let bytes: Data
                if let got = prefetched { bytes = got } else { bytes = try await docBytes(&d) }
                let from = d.from
                let fresh = await Task.detached(priority: .utility) { await DocUnlock.open(bytes, sender: from, typed: typed) }.value""",
"if let got = prefetched { bytes = got } else"),
("""                if case .opened(let text) = fresh { MailVault.putText(text, key: textKey) }""",
"""                if case .opened(let text) = fresh { MailVault.putText(text, key: textKey); MailVault.putText(DocText.extractor, key: textKey + "|x") }""",
"MailVault.putText(text, key: textKey); MailVault.putText(DocText.extractor"),
("""                if case .locked = fresh, typed == nil, let kept = MailVault.getText(textKey) ?? MailVault.getText(oldKey) { result = .opened(kept) } else { result = fresh }""",
"""                let refetchedBad: Bool = { if prefetched == nil { return false }; if case .unreadable = fresh { return true }; return false }()
                if case .locked = fresh, typed == nil, let kept = MailVault.getText(textKey) ?? MailVault.getText(oldKey) { result = .opened(kept) } else if refetchedBad, let kept = keptNow { result = .opened(kept) } else { result = fresh }""",
"let refetchedBad: Bool = {"),
])
print('glyphs-4nov patched:', done or 'already in')
