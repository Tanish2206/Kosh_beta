# kosh feedback 1 Nov (21:49) — Swift, part N: locked statements. One sender that mails from two addresses (Axis:
# axisbank.com, then axis.bank.in) asked for the same Customer ID twice; now one ask per bank, detail and person, and
# the detail typed once is kept for every address. Each ask says what it would open ("Account statements 40 · Atlas
# card ••88 12"), so the ID asked for is plain. And the row is compact: the icon, the name and what it needs on two
# lines, the count as a small pill, one field with its button inside, the ways out as one quiet line. Idempotent.
import re
p = 'Kosh/Papers.swift'; s = open(p).read()
OLD = """        var holder: String = "me"
    }"""
NEW = """        var holder: String = "me"
        /// the same bank's other addresses this one ask stands for (its detail is kept under each)
        var also: [String] = []
        var ids: [String] { [id] + also }
    }"""
if 'var also: [String] = []' not in s:
    assert s.count(OLD) == 1, 'LockedNeed anchor'
    s = s.replace(OLD, NEW)
open(p, 'w').write(s)

p = 'Kosh/StatementsSettings.swift'; s = open(p).read()
for OLD, NEW in [
    ("ForEach(sorted) { (n: LiveSession.LockedNeed) in LockedNeedRow(need: n, home: homes[n.id] ?? PaperShelf.other) { refresh() } }",
     "ForEach(LockedMerge.of(sorted, home: { homes[$0.id] ?? PaperShelf.other })) { (n: LiveSession.LockedNeed) in LockedNeedRow(need: n, home: homes[n.id] ?? PaperShelf.other) { refresh() } }"),
    ("ForEach(locked) { (n: LiveSession.LockedNeed) in LockedNeedRow(need: n, home: b.name) { refresh() } }",
     "ForEach(LockedMerge.of(locked, home: { _ in b.name })) { (n: LiveSession.LockedNeed) in LockedNeedRow(need: n, home: b.name) { refresh() } }"),
]:
    if NEW not in s and 'LockedMerge.of(' + OLD.split('ForEach(')[1].split(')')[0] not in s:
        assert s.count(OLD) == 1, ('locked list anchor', OLD[:40])
        s = s.replace(OLD, NEW)

if 'LockedCover.of(' not in s:
    a = s.index('    var body: some View {\n        let mark: String = home.isEmpty')
    b = s.index('        .padding(.vertical, 10)\n    }\n', a) + len('        .padding(.vertical, 10)\n    }\n')
    s = s[:a] + r'''    @State private var why: Bool = false
    @FocusState private var typing: Bool

    var body: some View {
        let mark: String = home.isEmpty || home == PaperShelf.other ? need.sender : home
        let covers: [LockedCover] = LockedCover.of(store.live, ids: need.ids)
        VStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .center, spacing: 12) {
                InstIcon(name: mark, color: StatementsSettings.color(mark, store), size: 36, hint: need.sender)
                    .cornerMark("lock.fill", color: Color.orange, size: 36)
                VStack(alignment: .leading, spacing: 2) {
                    Text(need.sender).font(.body.weight(.semibold)).lineLimit(1)
                    Text(PaperShelf.need(need.need, whose: who == "me" ? "" : Details.personName(who, store)))
                        .font(.footnote).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                }
                Spacer(minLength: 6)
                Text(String(need.count)).font(.footnote.weight(.bold)).monospacedDigit().foregroundStyle(Color.orange)
                    .padding(.horizontal, 9).padding(.vertical, 3)
                    .background(Color.orange.opacity(0.14), in: Capsule())
                    .accessibilityLabel(String(need.count) + " locked")
            }
            // what it would open: which account's detail this is
            if !covers.isEmpty {
                WrapRow(spacing: 6, lineSpacing: 6) {
                    ForEach(covers) { c in
                        HStack(spacing: 5) {
                            Image(systemName: c.sym).font(.caption2.weight(.semibold))
                            Text(c.label).font(.caption.weight(.medium))
                            Text(String(c.n)).font(.caption).foregroundStyle(.tertiary).monospacedDigit()
                        }
                        .foregroundStyle(.secondary)
                        .padding(.horizontal, 9).frame(minHeight: 26)
                        .background(Color(.tertiarySystemFill), in: Capsule())
                    }
                }
                .accessibilityElement(children: .combine)
                .accessibilityLabel("Opens " + covers.map { $0.label + ", " + String($0.n) }.joined(separator: "; "))
            }
            // one field, its button inside it
            let f: String? = usePassword ? nil : field
            let ok: Bool = f.map { PaperShelf.typed($0, fieldText) != nil } ?? !pw.isEmpty
            let busy: Bool = saving || trying
            HStack(spacing: 8) {
                Group {
                    if let f {
                        TextField(label(f), text: $fieldText)
                            .keyboardType(keyboard(f))
                            .textInputAutocapitalization(f == "pan" || f == "crn" || f == "cid" ? .characters : .never)
                    } else {
                        SecureField(field == nil ? "The statement’s password" : "Password", text: $pw)
                            .textContentType(.password)
                    }
                }
                .font(.body).monospacedDigit()
                .autocorrectionDisabled()
                .focused($typing)
                .submitLabel(.go)
                .onSubmit { if ok && !busy { if let f { save(f) } else { unlock() } } }
                Button { if let f { save(f) } else { unlock() } } label: {
                    ZStack {
                        Image(systemName: "lock.open.fill").font(.system(size: 13, weight: .bold)).opacity(busy ? 0 : 1)
                        if busy { ProgressView().controlSize(.small).tint(Color.onKosh) }
                    }
                    .foregroundStyle(ok ? Color.onKosh : Color.secondary)
                    .frame(width: 34, height: 34)
                    .background(ok ? Color.koshFill : Color(.quaternarySystemFill), in: Circle())
                }
                .buttonStyle(.press)
                .disabled(!ok || busy)
                .accessibilityLabel("Unlock")
            }
            .padding(.leading, 12).padding(.trailing, 5)
            .frame(minHeight: 44)
            .background(Color(.tertiarySystemFill), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).strokeBorder(typing ? Color.kosh.opacity(0.5) : Color.clear, lineWidth: 1))
            .animation(Motion.base, value: typing)
            // the ways out, one quiet line
            let links: [(String, () -> Void)] = linkList()
            if !links.isEmpty {
                HStack(spacing: 0) {
                    ForEach(Array(links.enumerated()), id: \.offset) { i, l in
                        if i > 0 { Text("·").foregroundStyle(.tertiary).padding(.horizontal, 8) }
                        Button(l.0, action: l.1).buttonStyle(.press)
                    }
                }
                .font(.caption.weight(.medium))
                .foregroundStyle(Color.kosh)
            }
            if why && !need.hint.isEmpty {
                Text("The email says: “" + need.hint + "”").font(.caption).foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
                    .transition(.opacity)
            }
            if let result {
                Label(result, systemImage: result.hasPrefix("Opened") ? "checkmark.circle.fill" : "exclamationmark.circle")
                    .font(.caption)
                    .foregroundStyle(result.hasPrefix("Opened") ? Color.green : Color.orange)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .padding(.vertical, 6)
    }

    func linkList() -> [(String, () -> Void)] {
        var out: [(String, () -> Void)] = []
        if field != nil {
            out.append((usePassword ? "Type the " + PaperShelf.fieldWord(field ?? "") : "Use the password", { withAnimation(Motion.base) { usePassword.toggle() } }))
        }
        if PasswordProfile.anySaved && !(saving || trying) { out.append(("Try saved details", { retrySaved() })) }
        if !need.hint.isEmpty { out.append((why ? "Hide the email’s words" : "Why?", { withAnimation(Motion.base) { why.toggle() } })) }
        return out
    }
''' + s[b:]

OLD = """            let n: Int = await store.live?.unlockSender(need.id, password: pw) ?? 0"""
NEW = """            var n: Int = 0
            for id in need.ids { n += await store.live?.unlockSender(id, password: pw) ?? 0 }"""
if 'for id in need.ids { n += await' not in s:
    assert s.count(OLD) == 1, 'unlock anchor'
    s = s.replace(OLD, NEW)
OLD = """            p.ids[need.id] = v
            p.ids["bank:" + need.sender.lowercased()] = v"""
NEW = """            for id in need.ids { p.ids[id] = v }
            p.ids["bank:" + need.sender.lowercased()] = v"""
if 'for id in need.ids { p.ids[id] = v }' not in s:
    assert s.count(OLD) == 1, 'save anchor'
    s = s.replace(OLD, NEW)

if 'enum LockedMerge' not in s:
    s += r'''

/// one ask per bank, detail and person: a sender that mails from two addresses (axisbank.com, then axis.bank.in) asking
/// for the same Customer ID is one ask, its counts added
enum LockedMerge {
    static func of(_ ns: [LiveSession.LockedNeed], home: (LiveSession.LockedNeed) -> String) -> [LiveSession.LockedNeed] {
        var out: [LiveSession.LockedNeed] = []
        var at: [String: Int] = [:]
        for n in ns {
            let h: String = home(n)
            let bank: String = (h.isEmpty || h == PaperShelf.other ? n.sender : h).lowercased()
            let key: String = bank + "|" + n.need.lowercased() + "|" + n.holder
            if let i = at[key] {
                let o = out[i]
                var m = LiveSession.LockedNeed(id: o.id, sender: o.sender, count: o.count + n.count, hint: o.hint.isEmpty ? n.hint : o.hint,
                                               need: o.need, details: o.details || n.details, holder: o.holder)
                m.also = o.also + n.ids
                out[i] = m
            } else {
                at[key] = out.count
                out.append(n)
            }
        }
        return out
    }
}

/// what a locked ask would open, by the account it is about: "Account statements 40", "Atlas card ••88 12"
struct LockedCover: Identifiable, Hashable {
    let label: String
    let sym: String
    let n: Int
    var id: String { label }
    @MainActor static func of(_ live: LiveSession?, ids: [String]) -> [LockedCover] {
        guard let live else { return [] }
        let keys: Set<String> = Set(ids)
        var count: [String: Int] = [:], sym: [String: String] = [:], order: [String] = []
        for r in live.lockedDocs {
            guard let d = r.doc, keys.contains(d.from) else { continue }
            let (l, s) = name(r, kind: d.kind)
            if count[l] == nil { order.append(l) }
            count[l, default: 0] += 1
            sym[l] = s
        }
        return order.map { LockedCover(label: $0, sym: sym[$0] ?? "doc.text", n: count[$0] ?? 0) }.sorted { $0.n > $1.n }
    }
    static func name(_ r: Reading, kind: String) -> (String, String) {
        let subj: String = r.subject ?? ""
        let digits: String = {
            if let m = subj.range(of: #"(?i)(?:ending|xx+|••|\*{2,})\s*(\d{2,4})\b"#, options: .regularExpression) {
                return String(subj[m]).filter(\.isNumber)
            }
            return r.last4 ?? ""
        }()
        let tail: String = digits.isEmpty ? "" : " ••" + String(digits.suffix(4))
        let low: String = subj.lowercased()
        if kind == "cardstmt" || low.contains("credit card") {
            // the card's own name from the subject: "Your Axis Bank Atlas Credit Card ending XX88" → "Atlas"
            var nm: String = ""
            if let m = subj.range(of: #"(?i)bank\s+([A-Za-z0-9+ ]{2,24}?)\s+credit card"#, options: .regularExpression) {
                nm = String(subj[m]).replacingOccurrences(of: #"(?i)^bank\s+|\s+credit card$"#, with: "", options: .regularExpression)
            }
            return ((nm.isEmpty ? "Credit card" : nm + " card") + tail, "creditcard")
        }
        if kind == "fd" || low.contains("deposit") { return ("Deposits", "banknote") }
        if kind == "tax" || low.contains("tds") || low.contains("form 16") { return ("Tax papers", "doc.text") }
        if kind == "loan" || low.contains("loan") { return ("Loan" + tail, "house") }
        if kind == "policy" { return ("Policies", "shield") }
        if kind == "cas" { return ("Holdings", "chart.pie") }
        if kind == "stmt" || low.contains("statement") { return ("Account statements" + tail, "building.columns") }
        return ("Other papers", "doc")
    }
}
'''
open(p, 'w').write(s)
print('swift N patched')
