#!/usr/bin/env python3
"""unknown-3nov (kosh ios app chat, 3 Nov): payments that showed as "Needs a name" in Miscellaneous, and an order whose
card charge didn't match its total. Idempotent: each piece skips itself once in. Run from kosh-beta/:
    python3 tools/patches/unknown_3nov_engine.py

1. HDFC's new card statements print a line as "16/10/2026| 09:48 BPPY CC PAYMENT ... + C 10,165.00": the "| 09:48" is the
   line's time and the "C" is the PDF's rupee sign. kosh read "+" only when it sat right against the figure, so money IN
   (a bill paid) read as a spend, named "| 09:48 bppy pymt + c". Now: a sign or the "C"/"₹" glyph before the figure is
   read as the mark it is, the time is kept as the line's time, and a rewards count before the glyph is no part of the shop.
2. A card's bill paid, on the card's own statement (BPPY, CC PYMT, PAYMENT RECEIVED), is never a charge: the payment is
   the paying side's row (CRED's or the bank's mail, with its UTR and method; portalFacts). Skipped whatever its sign.
3. A statement's summary heading ("Portfolio Summary as on 31-Oct-2026", letters lost in AU's PDF font: "Portf li S mmary
   as o n 31") is never a payment.
4. An order paid with less than its total and no wallet named: the rest is a discount at payment, never a wallet's share.
   The order's bill says Order total / Discount at payment / Charged to <card>; a named wallet's share says From <wallet>.
5. Orders matched by total keep each line's count and each-price (the "3 x" was lost on that path).
8. An order's placing mail is its 'placed' step, whatever its progress bar prints.
7. The order matched by total joins the payment's order story, so its total and bill show.
6. A card's bill paid is titled by the card it paid ("HDFC ••4545 bill", the card's own name when kosh knows it).
"""
import sys, json
F = 'Kosh/engine.js'
s = open(F, encoding='utf-8').read()
done = []
def rep(old, new, marker):
    global s
    if marker in s: return
    c = s.count(old)
    if c != 1: sys.exit('engine anchor %d times (want 1): %r' % (c, old[:90]))
    s = s.replace(old, new); done.append(marker[:40])

# 1a. the sign or the rupee glyph before a figure
rep(r"""else if ((sm = /(?:^|\s)[-–]\s*$/.exec(between))) { x.neg = true; x.lead = sm[0].length; }""",
    r"""else if ((sm = /(?:^|\s)[-–]\s*(?:₹|C|Rs\.?|INR)?\s*$/.exec(between))) { x.neg = true; x.lead = sm[0].length; x.glyph = /[₹C]|Rs|INR/.test(sm[0]); }""",
    "x.glyph = /[₹C]|Rs|INR/.test(sm[0]); }")
rep(r"""else if ((sm = /(?:^|\s)\+\s*$/.exec(between))) { x.plus = true; x.lead = sm[0].length; }""",
    r"""else if ((sm = /(?:^|\s)\+\s*(?:₹|C|Rs\.?|INR)?\s*$/.exec(between))) { x.plus = true; x.lead = sm[0].length; x.glyph = /[₹C]|Rs|INR/.test(sm[0]); }
      // (a rupee sign the PDF's font gives as a "C", "SWIGGY BANGALORE 12 C 452.00": the mark of a figure, never the shop's)
      else if ((sm = /(?:^|\s)(?:₹|C|Rs\.?|INR)\s*$/.exec(between))) { x.lead = sm[0].length; x.glyph = true; }""",
    "x.lead = sm[0].length; x.glyph = true; }")

# 1b / 3. the line's time, the glyph's rewards count, a summary heading
rep(r"""      if (card && points) desc = desc.replace(/\s+\d{1,5}$/, '');""",
    r"""      if (card && points) desc = desc.replace(/\s+\d{1,5}$/, '');
      // (unknown-3nov: a line that opens with its time, "| 09:48 SWIGGY": the time is the line's; a count before the
      // rupee glyph is the rewards column; a summary's heading is no line)
      var lineTime = '', tmm = /^[\s|]*(\d{1,2}:\d{2})(?::\d{2})?\s+/.exec(desc);
      if (tmm) { lineTime = tmm[1]; desc = desc.slice(tmm[0].length); }
      desc = desc.replace(/^[\s|]+/, '').replace(/[\s|]+$/, '');
      if (card && amts.some(function (x) { return x.glyph; })) desc = desc.replace(/(?<!\bof)\s+\+?\s*\d{1,5}$/i, '');
      if (stmtHeading(desc)) return false;""",
    "var lineTime = '', tmm = ")
rep(r"""      cur = { date: date, desc: desc, amt: amt, dir: dir, extra: 0, bal: bal };""",
    r"""      cur = { date: date, desc: desc, amt: amt, dir: dir, extra: 0, bal: bal };
      if (lineTime) cur.time = lineTime;""",
    "if (lineTime) cur.time = lineTime;")
rep(r"""  function stmtFigures(rest) {""",
    r"""  /* (unknown-3nov) a statement's summary heading, however its PDF's font lost letters ("Portf li S mmary as o n 31"):
     its letters alone, squashed, say summary-as-on, or a portfolio's, account's or statement's summary */
  function stmtHeading(desc) {
    var sq = String(desc || '').toLowerCase().replace(/[^a-z]/g, '');
    if (sq.length < 6) return false;
    return /s?u?m{1,2}a?ry(?:as)?on/.test(sq) || /(?:portf\w{0,4}|acc?o?u?nts?|statement|relationship|holdings?)s?u?m{1,2}a?ry/.test(sq);
  }
  /* (unknown-3nov) a card's bill paid, as its own statement prints the payment (never a bill paid WITH the card, "BBPS
     ELECTRICITY", nor CRED's store: those are spends) */
  var CARD_PAY_LINE = /\bbppy\s*(?:cc\s*)?(?:payment|pymt|pmt)\b|\b(?:cc|credit\s*card|card)\s*(?:bill\s*)?(?:payment|pymt|pmt)\b|\bpayment\s*(?:received|recd|thank)|thank\s*you\s*for\s*(?:the\s*|your\s*)?payment|\bautopay\s*(?:payment|debit)\b/i;
  function stmtFigures(rest) {""",
    "function stmtHeading(desc) {")

# 2 / 3. at the statement's lines against kosh's payments
rep(r"""        var d0 = String(row.desc || '');
        var info = fromInfo(""",
    r"""        var d0 = String(row.desc || '');
        // (unknown-3nov) a summary's heading is no payment; the time and the rupee glyph are no part of the name
        if (stmtHeading(d0)) { R0.skipped++; return; }
        d0 = d0.replace(/^[\s|]*\d{1,2}:\d{2}(?::\d{2})?\s+/, '').replace(/^[\s|]+/, '').replace(/\s+[+\-]?\s*C$/, '');
        /* GUARDRAIL a card's bill paid, on the card's own statement ("BPPY CC PAYMENT", "BPPY PYMT", "PAYMENT RECEIVED"):
           the payment is the paying side's row (CRED's or the bank's mail, its UTR and how it was paid), never a charge,
           whichever way the PDF's sign came out (3 Nov: two HDFC bills paid read as spends, "| 09:48 bppy pymt + c") */
        if (S.instr === 'card' && CARD_PAY_LINE.test(d0) && !/\b(?:revers|return|bounce|dishono|fail|charges?\b|fee\b)/i.test(d0)) { R0.skipped++; return; }
        var info = fromInfo(""",
    "if (stmtHeading(d0)) { R0.skipped++; return; }")
rep(r"""kind: 'txn', rule: 'statement-line', dir: row.dir, amt: row.amt, date: row.date, time: '',""",
    r"""kind: 'txn', rule: 'statement-line', dir: row.dir, amt: row.amt, date: row.date, time: row.time || '',""",
    "date: row.date, time: row.time || '',")

# 4a. what an order's mail takes off between its total and what was paid, line by line as it prints them ("Total
#     Amount • ₹8316 • Myntra Credit • - ₹3982 • Bank CashBack • - ₹433 • Net Paid • ₹3901"): a wallet's or a shop's
#     credit is a wallet's share at its own figure; a bank's cashback, a discount or an offer is a discount; no line at
#     all is a discount too, never a wallet. (Before: "Bank Credit" was taken from "Paid by AXIS Bank Credit Card",
#     "India Credit" from "State Bank of India Credit Card", and cashback and credit were lumped into one wallet spend)
rep(r"""      var nm = (new RegExp('\\b((?:' + String(e.shop || '').replace(/[^A-Za-z]/g, '') + '|[A-Z][a-z]+)\\s(?:Credit|Wallet|Cash|Balance|Money|Points|SuperCoins|Gift Card))\\b').exec(body) || [])[1];
      out.push({ type: 'walletUse', w: nm || ((e.shop || 'Shop') + ' wallet'), amt: Math.round((tot.amt - net.amt) * 100) / 100, gap: true });""",
    r"""      // (unknown-3nov) each line the mail takes off between its total and what was paid, by its own label
      var gapAmt = Math.round((tot.amt - net.amt) * 100) / 100, seg = body, ti = body.search(/total\s*(?:amount|payable)?\b/i), ni = body.search(/net\s*(?:paid|payable|amount)|amount\s*paid|you\s*paid/i);
      if (ti >= 0 && ni > ti) seg = body.slice(ti, ni + 40);
      var glre = /([A-Za-z][A-Za-z' ]{1,30}?)(?:\s*[*:|•·]\s*){0,4}\s*[-–−]\s*(?:₹|rs\.?|inr)\s*([\d,]+(?:\.\d{1,2})?)/gi, gm, offs = [];
      while ((gm = glre.exec(seg)) && offs.length < 6) {
        var gl = gm[1].replace(/\s+/g, ' ').trim(), gv = +gm[2].replace(/,/g, '');
        if (!(gv > 0)) continue;
        var isOff = /cash ?back|discount|coupon|offer|instant|saving|promo|voucher|deal/i.test(gl);
        var isWal = !isOff && /cash|credit|wallet|balance|points|coins|money|gift ?card/i.test(gl) && !/\b(?:card|bank)\b/i.test(gl);
        if (isOff || isWal) offs.push({ w: gl, amt: gv, wal: isWal });
      }
      var offSum = offs.reduce(function (s0, o) { return s0 + o.amt; }, 0);
      var wals = Math.abs(offSum - gapAmt) <= 1 ? offs.filter(function (o) { return o.wal; }) : offs.filter(function (o) { return o.wal && Math.abs(o.amt - gapAmt) <= 0.5; }).slice(0, 1);
      wals.forEach(function (o) { if (!out.some(function (x) { return x.w.toLowerCase() === o.w.toLowerCase() && x.amt === o.amt; })) out.push({ type: 'walletUse', w: o.w, amt: o.amt, gap: true }); });""",
    "each line the mail takes off between its total and what was paid, by its own label")

# 4b. the order's bill says what was charged, what was taken off, and what a wallet paid
rep(r"""        if (bill.length) {
          O.bill = bill.slice(0, 16);""",
    r"""        /* (unknown-3nov) what was charged against what the order came to: the payment's own charge is what counts. Paid
           less than the order's total with no wallet named, the rest was taken off at payment (a bank's instant discount,
           an offer): said as a discount, never as money from elsewhere. A wallet's share (t.wu) is said as paid from it */
        (function () {
          if (t.wf) return;
          var tots = evs.map(function (x) { return +x.e.total || 0; }).filter(function (v) { return v > 0; });
          var tot = tots.length ? Math.max.apply(null, tots) : 0, paidHere = money(t.full > t.a ? t.full : t.a);
          if (!(tot > 0) || !(paidHere > 0)) return;
          var wsum = (t.wu || []).reduce(function (s0, u) { return s0 + (+u.a || 0); }, 0);
          var gap = money(tot - paidHere - wsum), how = String(t.card || '').replace(/\s+CC\s+/, ' ').trim();
          var off = gap >= 1 && gap < tot * 0.6;
          if (off) {
            if (!bill.some(function (l) { return l.k === 'sub'; }) && !bill.some(function (l) { return l.k === 'paid' && Math.abs(l.amt - tot) <= 1; })) bill.push({ k: 'sub', n: 'Order total', amt: money(tot) });
            if (!bill.some(function (l) { return l.k === 'disc' && Math.abs(l.amt - gap) <= 1; })) bill.push({ k: 'disc', n: 'Discount at payment', amt: gap });
          }
          (t.wu || []).forEach(function (u) { if (!bill.some(function (l) { return Math.abs(l.amt - u.a) <= 0.5 && /wallet|credit|balance|cash|money/i.test(l.n); })) bill.push({ k: 'paid', n: 'From ' + u.w, amt: money(u.a) }); });
          if ((off || wsum > 0) && !bill.some(function (l) { return l.k === 'paid' && Math.abs(l.amt - t.a) <= 0.5; })) bill.push({ k: 'paid', n: how ? 'Charged to ' + how : 'Charged', amt: money(t.a) });
        })();
        if (bill.length) {
          O.bill = bill.slice(0, 16);""",
    "if (t.wf) return;\n          var tots = evs.map(")

# 5. the count and each-price ride on the order matched by its total
rep(r"""if (Array.isArray(e.lines)) e.lines.forEach(function (l) { if (l && l.n && +l.amt > 0) (O.amt = O.amt || {})[String(l.n).trim()] = +l.amt; });""",
    r"""if (Array.isArray(e.lines)) e.lines.forEach(function (l) { if (l && l.n && +l.amt > 0) (O.amt = O.amt || {})[String(l.n).trim()] = +l.amt; });
            if (Array.isArray(e.lines)) e.lines.forEach(function (l) { if (!l || !l.n) return; var nk = String(l.n).trim(); if (+l.q > 0) (O.q = O.q || {})[nk] = +l.q; if (+l.unit > 0) (O.unit = O.unit || {})[nk] = +l.unit; });""",
    "(O.q = O.q || {})[nk] = +l.q;")
rep(r"""if (byTotal.amt && byTotal.amt[n] > 0) o.amt = byTotal.amt[n];""",
    r"""if (byTotal.amt && byTotal.amt[n] > 0) o.amt = byTotal.amt[n]; if (byTotal.q && byTotal.q[n] > 0) o.q = byTotal.q[n]; if (byTotal.unit && byTotal.unit[n] > 0) o.unit = byTotal.unit[n];""",
    "if (byTotal.q && byTotal.q[n] > 0) o.q = byTotal.q[n];")
# 6. a card's bill paid is titled by the card it paid, never "HDFC card bill" or a statement's misread line: "HDFC Diners
#    Black ••4545 bill" (the route beside it, lp, already says the app, how, its UTR and the day the card was credited)
rep(r"""        if (!lp.by && cardRow) lp.by = cardRow.bank;
        R.lp = lp;""",
    r"""        if (!lp.by && cardRow) lp.by = cardRow.bank;
        R.lp = lp;
        // (unknown-3nov) titled by the card it paid, when kosh's title was only generic; never a name you gave it
        if (!R.n && (cardRow || l4) && (/^(?:[a-z .&]{2,30} )?card bill$|^card payments?$|^credit card (?:bill )?payment$/i.test(String(R.m || '').trim()) || /^\W*\d{1,2}:\d{2}\b|\bbppy\b|\bpymt\b/i.test(String(R.m || '')) || (lp.pt && String(R.m || '').toLowerCase().replace(/\s+(?:club|app|pay)$/, '') === String(lp.pt).toLowerCase()))) {
          var cbank = cardRow ? String(cardRow.bank || '') : String(lp.by || '');
          var cprod = cardRow && cardRow.product && String(cardRow.product).toLowerCase().indexOf(cbank.toLowerCase()) < 0 ? ' ' + cardRow.product : (cardRow && cardRow.product ? '' : '');
          var ctitle = (cardRow && cardRow.product && !cprod ? String(cardRow.product) : cbank + cprod).trim();
          R.m = (ctitle ? ctitle + ' ' : '') + (l4 ? '••' + String(l4).slice(-4) + ' ' : '') + 'bill';
        }""",
    "titled by the card it paid, when kosh's title")
# 7. the order kosh matched a payment to by its total (payFacts' items, from that order's mail) is the payment's order:
#    its mails join the order's story and its total is the bill's (3 Nov: the whey order's card charge had no order number)
rep(r"""        // (the order's other mails: every mail that names one of its numbers)
        var keys = [];""",
    r"""        // (unknown-3nov) the order its items were matched from by total, when no number tied the payment to it
        var pfx = snapOut.payFacts && snapOut.payFacts.pay ? snapOut.payFacts.pay[t.id] : null, im = pfx && pfx.src ? pfx.src.items : '';
        if (im && recById[im] && ids.indexOf(im) < 0 && (!claim[im] || claim[im] === t.id)) ids.push(im);
        // (the order's other mails: every mail that names one of its numbers)
        var keys = [];""",
    "the order its items were matched from by total")
# 8. an order's placing mail is "placed" whatever its progress bar prints ("Ordered · Shipped · Out for delivery ·
#    Delivered" in every Amazon mail): the subject that names the step wins over the bar's words
rep(r"""      if (parcel) return PARCEL_STEP[parcel.step];
      if (OUTW.test(subj)) return 'out for delivery';""",
    r"""      // (unknown-3nov) the mail that placed it says so in its subject, whatever its progress bar prints
      if (ord && ord.status === 'placed' && /^\s*(?:ordered\b|order (?:placed|confirmed|received)\b|thank(?:s| you) for (?:your )?order|your order (?:has been |is )?(?:placed|confirmed))/i.test(subj)) return 'placed';
      if (parcel) return PARCEL_STEP[parcel.step];
      if (OUTW.test(subj)) return 'out for delivery';""",
    "the mail that placed it says so in its subject")
# 9. a wallet's share of an order (t.wf) and the gift card that loaded the wallet (t.loadFor) are two sides of the money,
#    never one purchase told twice: "one purchase, one row" leaves both (4 Nov: Myntra Credit ₹3,000 folded into its
#    GyFTR gift card's ₹3,000 by shop and sum, so the order counted ₹414 of its ₹3,414)
rep(r"""      var outs = tx.filter(function (t) { return t.dirRaw === 'out' && !t.partOf && t.a > 0; });
      var gone = {};""",
    r"""      var outs = tx.filter(function (t) { return t.dirRaw === 'out' && !t.partOf && t.a > 0 && !t.wf && !t.loadFor; });
      var gone = {};""",
    "!t.partOf && t.a > 0 && !t.wf && !t.loadFor; });")
open(F, 'w', encoding='utf-8').write(s)

# reader: each one's price under its count; a long name cut at its own seams
F2 = 'Kosh/reader.js'
r = open(F2, encoding='utf-8').read()
def rep2(old, new, marker):
    global r
    if marker in r: return
    c = r.count(old)
    if c != 1: sys.exit('reader anchor %d times (want 1): %r' % (c, old[:90]))
    r = r.replace(old, new); done.append(marker[:40])
rep2(r"""      if (!booking) { var lines = lineItems(doc, groups.length === 1 ? doc.bodyAt : start, end); if (lines.length) ev.lines = lines; }""",
     r"""      if (!booking) { var lines = lineItems(doc, groups.length === 1 ? doc.bodyAt : start, end); if (lines.length) ev.lines = lines; }
      /* (unknown-3nov) a marketplace prints each one's price under its count ("Quantity: 3", "4499 INR", Total 13161.09):
         when the counts times the figures come near the total and the figures alone don't, the figures are each one's */
      if (ev.lines && ev.total > 0 && ev.lines.every(function (l) { return l.amt > 0 && !(l.unit > 0); }) && ev.lines.some(function (l) { return l.q > 1; })) {
        var sA = 0, sQ = 0;
        ev.lines.forEach(function (l) { sA += l.amt; sQ += l.amt * (l.q || 1); });
        if (Math.abs(sA - ev.total) > ev.total * 0.05 && sQ >= ev.total * 0.8 && sQ <= ev.total * 1.3)
          ev.lines.forEach(function (l) { if (l.q > 1) { l.unit = l.amt; delete l.amt; } });
      }""",
     "(unknown-3nov) a marketplace prints each one's price")
rep2(r"""    return n.slice(0, 80);
  }
  function lineItems""",
     r"""    // (unknown-3nov: a long name cut at its own seam, " | ", or a word's end: never "… 1kg (2.2 lbs) | 2")
    if (n.length <= 80) return n;
    var cut = n.slice(0, 80), bar = cut.lastIndexOf(' | ');
    return (bar >= 24 ? cut.slice(0, bar) : cut.replace(/\s+\S*$/, '')).replace(/[\s|,(\-]+$/, '');
  }
  function lineItems""",
     "a long name cut at its own seam")
open(F2, 'w', encoding='utf-8').write(r)

# the reading's fingerprint: statements and order mail read again with these rules
RP = 'Kosh/engine-read.json'
j = json.load(open(RP))
if not str(j.get('read', '')).endswith('-unk3nov'):
    j['read'] = str(j.get('read', '')) + '-unk3nov'
    open(RP, 'w').write(json.dumps(j))
print('unknown-3nov patched:', done or 'already in')
