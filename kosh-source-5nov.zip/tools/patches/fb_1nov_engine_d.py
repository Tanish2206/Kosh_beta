# kosh feedback 1 Nov (22:34) — engine, part D: the searches. Amazon's "Ordered: "Native Lock Pro…" and 3 more items"
# (what was bought, with each line's price) matched no search, and Amazon Pay's bill receipts ("Paid to UHBVN …
# Subscriber Id …") sit in Gmail's Promotions, which every search left out. Now: "ordered" in the order search, and
# one more search per run of known senders, inside Promotions, for receipts only (order, bill, payment, recharge,
# receipt, invoice words in the subject). Idempotent.
p = 'Kosh/engine.js'; s = open(p).read()
old = """subject:("order confirmed" OR "order confirmation" OR "thank you for your order" OR "thanks for your order" OR "order placed" OR "order received" OR "your order" OR "order #" OR "order no") -subject:"""
new = """subject:("order confirmed" OR "order confirmation" OR "thank you for your order" OR "thanks for your order" OR "order placed" OR "order received" OR "your order" OR "order #" OR "order no" OR "ordered") -subject:"""
if '"order no" OR "ordered")' not in s:
    assert s.count(old) == 1, 'order query anchor'
    s = s.replace(old, new)
old = """    var out = domainRuns(senderDomains(), room - 22).map(function (run) { return when + ' from:(' + run.join(' OR ') + ') -category:promotions' + tail; });"""
new = old + """
    // (receipts Gmail filed under Promotions, from the same senders: an order, a bill paid, a recharge, an invoice)
    var RECEIPT_SUBJ = ' subject:(ordered OR order OR "bill payment" OR paid OR payment OR recharge OR receipt OR invoice OR successful)';
    domainRuns(senderDomains(), room - 22 - RECEIPT_SUBJ.length - 20).forEach(function (run) { out.push(when + ' category:promotions from:(' + run.join(' OR ') + ')' + RECEIPT_SUBJ + tail); });"""
if '(receipts Gmail filed under Promotions' not in s:
    assert s.count(old) == 1, 'domain runs anchor'
    s = s.replace(old, new)
open(p, 'w').write(s)
print('engine D patched')
