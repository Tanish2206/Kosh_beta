#!/usr/bin/env python3
"""stmtacct-3nov (statements chat, 3 Nov): an account statement whose number is printed in the bank's own grouping
("SAVINGS ACCOUNT-RES  057-495103-006", HSBC's composite statement) gets its digits; and a period with no payments whose
opening and closing balances are both printed and equal is a statement that adds up (HSBC's 9 Oct: opened, ₹0, no
lines — kosh said "nothing kosh tracks" and kept no balance). Any bank: nothing here names one.
Idempotent: skips when the marker is already in engine.js. Run from kosh-beta/."""
import sys
p = 'Kosh/engine.js'
s = open(p, encoding='utf-8').read()
if 'stmtacct-3nov' in s: print('stmtacct-3nov already applied'); sys.exit(0)
def rep(old, new):
    global s
    if s.count(old) != 1: sys.exit('anchor %d times: %r' % (s.count(old), old[:70]))
    s = s.replace(old, new)
rep("""    if (!m) return '';
    var digits = m[1].replace(/\\D/g, '');
    return digits.length >= 4 ? digits.slice(-4) : '';
  }""", """    // (stmtacct-3nov) an account's number in the bank's own grouping on a line that names the account
    // ("SAVINGS ACCOUNT-RES   057-495103-006", "Savings Account   INR   057-495103-006"): 9 to 18 digits in groups
    if (!m && !card) {
      var lines = String(text || '').split('\\n');
      for (var li = 0; li < lines.length && !m; li++) {
        if (!/\\b(?:savings|current|salary|nre|nro|sb)\\b[^\\n]{0,20}\\b(?:account|a\\/c)\\b|\\b(?:account|a\\/c)\\b[^\\n]{0,6}\\b(?:res|nre|nro|savings|current)\\b/i.test(lines[li])) continue;
        var am = /(?:^|\\s)(\\d{2,6}(?:[ \\-]\\d{2,8}){1,3})(?=\\s|$)/.exec(lines[li].replace(/\\b\\d{1,3}(?:,\\d{2,3})*\\.\\d{2}\\b/g, ' '));
        if (am) { var dg = am[1].replace(/\\D/g, ''); if (dg.length >= 9 && dg.length <= 18) m = [am[0], am[1]]; }
      }
    }
    if (!m) return '';
    var digits = m[1].replace(/\\D/g, '');
    return digits.length >= 4 ? digits.slice(-4) : '';
  }""")
rep("""      out.check = stmtRepair(L, card, Lt);""", """      out.check = stmtRepair(L, card, Lt);
      // (stmtacct-3nov) no payments in the period, and the opening and closing balances it prints agree: it adds up
      if (!card && !(L.rows || []).length && L.opening !== null && L.opening !== undefined && L.closing !== null && L.closing !== undefined && Math.abs(L.opening - L.closing) < 0.01 && out.check.ok !== false)
        out.check = { ok: true, read: 0, stated: 0, note: 'No payments in the period; the balance stayed at ' + (L.closing < 0 ? '−' : '') + '₹' + Math.abs(L.closing).toFixed(2) };""")
open(p, 'w', encoding='utf-8').write(s)
print('stmtacct-3nov applied')
