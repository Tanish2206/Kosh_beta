# kosh feedback 2 Nov (00:14) — Swift, part T: an order's mixed share filed by itself. The engine tells a payment's
# mix (Txn.mix: the food in a shop's order, the non-groceries in a grocery app's); kosh files it once, for every
# payment past and new, the way a split by hand does: the share becomes a row of its own under its category (the
# oats ₹1,249 under Groceries, the rest of the ₹2,619 under Home goods), or the whole payment is refiled when every
# item was of the other kind. Each payment only once: undone, it stays undone. Idempotent.
def sub(path, old, new, mark):
    s = open(path).read()
    if mark in s: return
    assert s.count(old) == 1, (path, old[:70], s.count(old))
    open(path, 'w').write(s.replace(old, new))
sub('Kosh/Snapshot.swift', """    /// the charge this part was split out of
    var partOf: String? = nil""", """    /// the charge this part was split out of
    var partOf: String? = nil
    /// what part of an order was something else (engine › whatWasBought): its share, where it goes, what it was
    struct Mix: Decodable, Hashable { let c: String; let g: Double; var s: String? = nil; var n: [String]? = nil; var all: Bool? = nil }
    var mix: Mix? = nil""", 'struct Mix: Decodable, Hashable { let c: String')
sub('Kosh/Store.swift', """        Reminders.reschedule(self)
        PlanNotes.reschedule(self)""", """        Reminders.reschedule(self)
        AutoSplit.apply(self)
        PlanNotes.reschedule(self)""", 'AutoSplit.apply(self)')
import os
P = 'Kosh/AutoSplit.swift'
code = '''import Foundation

/// an order's mixed share filed by itself (fb 2 Nov): once per payment, past and new
@MainActor
enum AutoSplit {
    static let key: String = "autosplit.done"
    static func apply(_ store: Store) {
        guard let live = store.live else { return }
        var done: Set<String> = Set(UserDefaults.standard.stringArray(forKey: key) ?? [])
        var changed: Bool = false
        for t in store.snap.tx {
            guard let m = t.mix, t.partOf == nil, t.full == nil, !done.contains(t.id), m.c != t.c else { continue }
            // (a payment you filed or split yourself is yours)
            if let o = live.overrides[t.id], o.c == m.c || !(o.parts ?? []).isEmpty { done.insert(t.id); changed = true; continue }
            done.insert(t.id); changed = true
            let s: String = m.s ?? ""
            if m.all == true {
                live.override(t.id) { o in o.c = m.c; o.s = s; o.by = "kosh"; o.only = Store.with(o.only, "c") }
            } else if m.g > 0 && m.g < t.a {
                store.splitOut(t.id, amount: (m.g * 100).rounded() / 100, c: m.c, s: s, refunded: false)
            }
        }
        if changed {
            UserDefaults.standard.set(Array(done), forKey: key)
            live.rebuildSoon()
        }
    }
}
'''
if not os.path.exists(P) or open(P).read() != code:
    open('tools/patches/files/AutoSplit.swift', 'w').write(code)
    open(P, 'w').write(code)
print('swift T patched')
# (diagnostics: the payments with a mix and whether each was filed, figures only)
sub('Kosh/LiveSession+Extras.swift', """                x.head["lockedNeedsAre"] = are""", """                x.head["lockedNeedsAre"] = are
                x.head["autonote"] = UserDefaults.standard.string(forKey: "autonote.debug") ?? "none"
                if let st = Notify.shared.store {
                    let done: Set<String> = Set(UserDefaults.standard.stringArray(forKey: AutoSplit.key) ?? [])
                    x.head["mixes"] = st.snap.tx.filter { $0.mix != nil || $0.d >= "2026-11-01" && $0.c == "Shopping" }.prefix(30).map { (t: Txn) -> [String: Any] in
                        ["d": t.d, "a": t.a, "c": t.c, "s": t.s, "wk": t.wk ?? "", "mix": t.mix.map { [$0.c, String($0.g), $0.all == true ? "all" : ""] } ?? [], "done": done.contains(t.id), "full": t.full ?? 0, "items": (st.payFact(t)?.items ?? []).prefix(8).map { String($0.n.prefix(24)) + "=" + String($0.amt ?? -1) }]
                    }
                }""", 'x.head["mixes"]')

# a split's rows say what they are: the part "Split from ₹2,619 · Yogabar oats, rice paper", the rest "With it:
# knife bar, sealant tape…" under its "of ₹2,619"; the payment's sheet says the same
P = 'Kosh/Style.swift'
sub(P, """                } else if let part = t.partOf, !part.isEmpty {
                    HintLine(sym: "scissors", text: "Split out of a bigger charge")
                        .font(.caption).foregroundStyle(.secondary)
                        .padding(.leading, 48)
                }""", """                } else if let part = t.partOf, !part.isEmpty {
                    HintLine(sym: "scissors", text: SplitWords.part(t, store))
                        .font(.caption).foregroundStyle(.secondary)
                        .padding(.leading, 48)
                        .privacySensitive()
                } else if t.full != nil, let rest = SplitWords.rest(t, store) {
                    HintLine(sym: "shippingbox", text: rest)
                        .font(.caption).foregroundStyle(.secondary)
                        .padding(.leading, 48)
                        .privacySensitive()
                }""", 'SplitWords.part(t, store)')
sub('Kosh/Sheets.swift', """                            Label("Split out of a bigger charge on the same card", systemImage: "square.split.2x1")""",
    """                            Label(SplitWords.part(t, store), systemImage: "square.split.2x1")""", 'Label(SplitWords.part(t, store)')
code = open('Kosh/AutoSplit.swift').read()
if 'enum SplitWords' not in code:
    code += '''
/// what a split's rows are, in words
@MainActor
enum SplitWords {
    /// "Yogabar 26% High Protein Oats 1kg, Pack of 3" → "Yogabar 26% High Protein Oats 1kg"
    static func short(_ n: String) -> String {
        var s: String = n.components(separatedBy: CharacterSet(charactersIn: ",(|")).first ?? n
        s = s.trimmingCharacters(in: .whitespaces)
        return s.count > 34 ? String(s.prefix(32)).trimmingCharacters(in: .whitespaces) + "…" : s
    }
    static func key(_ n: String) -> String { String(n.lowercased().filter { $0.isLetter || $0.isNumber }.prefix(20)) }
    /// the part: "Split from ₹2,619 · Yogabar oats, rice paper sheets"
    static func part(_ t: Txn, _ store: Store) -> String {
        guard let pid = t.partOf, let p = store.txn(pid) else { return "Split out of a bigger charge" }
        let whole: Double = p.full ?? (p.a + t.a)
        var s: String = "Split from " + Fmt.rupees(whole)
        if let names = p.mix?.n, !names.isEmpty, p.mix?.c == t.c { s += " · " + names.map { short($0) }.joined(separator: ", ") }
        return s
    }
    /// the rest of a split order: what else it held
    static func rest(_ t: Txn, _ store: Store) -> String? {
        guard let names = t.mix?.n, !names.isEmpty, let items = store.payFact(t)?.items, !items.isEmpty else { return nil }
        let out: Set<String> = Set(names.map { key($0) })
        let rest: [String] = items.map { $0.n }.filter { !out.contains(key($0)) }.map { short($0) }
        guard !rest.isEmpty else { return nil }
        return "With it: " + rest.prefix(3).joined(separator: ", ") + (rest.count > 3 ? " +" + String(rest.count - 3) : "")
    }
}
'''
    open('Kosh/AutoSplit.swift', 'w').write(code)
    open('tools/patches/files/AutoSplit.swift', 'w').write(code)
print('swift T words')
# (the split-out part says its whole too, under its amount: "of ₹2,619", as the rest does)
sub('Kosh/Style.swift', """                        if let full = t.full, full > t.a + 0.5 {""",
    """                        if let full = t.full ?? t.partOf.flatMap({ store.txn($0) }).flatMap({ $0.full }), full > t.a + 0.5 {""", "t.full ?? t.partOf.flatMap({ store.txn($0) })")
print('swift T part total')
# (diagnostics: pairs of payments that may be one purchase told twice: the same shop, a week apart at most, one of
# them from a shop's own mail; figures, shop and the mails' kinds only)
sub('Kosh/LiveSession+Extras.swift', """                if let st = Notify.shared.store {
                    let done: Set<String> = Set(UserDefaults.standard.stringArray(forKey: AutoSplit.key) ?? [])""",
"""                if let st = Notify.shared.store {
                    var kindOf: [String: String] = [:]
                    for r in self.records { kindOf[r.id] = r.kind + ":" + (r.rule ?? "") + ":" + String((r.subject ?? "").prefix(36)) }
                    let outs: [Txn] = st.snap.tx.filter { $0.k == "out" && $0.partOf == nil }
                    func shopKey(_ t: Txn) -> String { String(t.m.lowercased().filter { $0.isLetter }.prefix(5)) }
                    var sus: [[String: Any]] = []
                    let byShop: [String: [Txn]] = Dictionary(grouping: outs.filter { shopKey($0).count >= 4 }) { shopKey($0) }
                    for (_, g) in byShop where g.count > 1 {
                        let xs: [Txn] = g.sorted { $0.d < $1.d }
                        for i in 0..<xs.count { for j in (i + 1)..<xs.count where Day.between(xs[i].d, xs[j].d) <= 7 {
                            let ka: String = kindOf[xs[i].id] ?? "?", kb: String = kindOf[xs[j].id] ?? "?"
                            if !(ka.hasPrefix("confirm") || kb.hasPrefix("confirm")) { continue }
                            sus.append(["a": [xs[i].d, String(xs[i].a), xs[i].m, ka], "b": [xs[j].d, String(xs[j].a), xs[j].m, kb]])
                        } }
                    }
                    x.head["dupSuspects"] = Array(sus.prefix(60))
                    x.head["probe"] = st.snap.tx.filter { $0.d == "2026-10-25" || $0.d == "2026-10-26" }.map { (t: Txn) -> [String: Any] in
                        let o = self.overrides[t.id]
                        return ["id": t.id, "a": t.a, "m": t.m, "c": t.c, "n": String(t.n.prefix(40)), "items": (st.payFact(t)?.items ?? []).count, "wu": t.wu?.count ?? 0,
                                "oc": o?.c ?? "", "on": o?.n.map { String($0.prefix(20)) } ?? "-", "rule": self.records.first { $0.id == t.id }?.rule ?? ""]
                    }
                    let done: Set<String> = Set(UserDefaults.standard.stringArray(forKey: AutoSplit.key) ?? [])""", 'x.head["dupSuspects"]')
