#!/usr/bin/env python3
"""zerocol-4nov (statements chat): a bank statement that prints 0.00 in the column a line doesn't use ("5,00,000.00
0.00 4,06,794.17": withdrawal, deposit, balance) lost every such line — kosh took the figure before the balance, the
0.00, and dropped the line. Axis's October statement kept only its deposits and kosh showed ₹9,06,794 against the
₹4,10,158.63 printed. Now: the line's own figure is the one that isn't nothing, the one whose balance follows from the
line before when two could be. And the balance a statement ends on is the closing balance it prints, when it prints
one, never a figure worked out from lines kosh read. Any bank. Idempotent. Run from kosh-beta/."""
import sys
p = 'Kosh/engine.js'; s = open(p, encoding='utf-8').read()
if 'zerocol-4nov' in s: print('zerocol-4nov already applied'); sys.exit(0)
pairs = [
 ("""        if (amts.length >= 2) {
          a = amts[amts.length - 2];
          var B = amts[amts.length - 1];
          bal = B.mark === 'dr' || B.mark === 'd' || (B.neg && B.v > 0) ? -Math.abs(B.v) : B.v;
        } else a = amts[0];""",
  """        if (amts.length >= 2) {
          a = amts[amts.length - 2];
          var B = amts[amts.length - 1];
          bal = B.mark === 'dr' || B.mark === 'd' || (B.neg && B.v > 0) ? -Math.abs(B.v) : B.v;
          // (zerocol-4nov) the column the line doesn't use prints 0.00: the line's figure is the one that isn't nothing,
          // and of two, the one its balance follows from
          var live = amts.slice(0, -1).filter(function (x) { return x.v !== 0 && !x.fx; });
          if (live.length && a.v === 0) a = live[live.length - 1];
          if (live.length > 1 && prevBal !== null) {
            var fit = live.filter(function (x) { var w = Math.abs(x.v); return Math.abs(prevBal - w - bal) < 0.5 || Math.abs(prevBal + w - bal) < 0.5; });
            if (fit.length) a = fit[fit.length - 1];
          }
        } else a = amts[0];"""),
 ("""      if (withBal.length) close = rows[0].date <= rows[rows.length - 1].date ? withBal[withBal.length - 1].bal : withBal[0].bal;
      if (close === null && closing !== null) close = closing;""",
  """      if (withBal.length) close = rows[0].date <= rows[rows.length - 1].date ? withBal[withBal.length - 1].bal : withBal[0].bal;
      // (zerocol-4nov) the closing balance it prints is the balance it ends on, whatever the lines read say
      if (closing !== null) close = closing;"""),
]
for a, b in pairs:
    if s.count(a) != 1: sys.exit('anchor %d: %r' % (s.count(a), a[:70]))
    s = s.replace(a, b)
open(p, 'w', encoding='utf-8').write(s); print('zerocol-4nov applied')
