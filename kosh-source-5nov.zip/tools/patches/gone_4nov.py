#!/usr/bin/env python3
"""gone-4nov + hsbc-4nov (statements chat, 4 Nov) - applied in place, tagged in the source:
 engine.js gone-4nov: an account whose bank kept sending statements for your other accounts but stopped listing it
   (3+ months) and nothing named in 6 months, or nothing named in a year, leaves the list (snapshot accountsGone);
   a typed balance keeps it. A bank statement that read no balance and didn't add up mints no account (SBM ••0654,
   ••9505 from deposit papers).
 engine.js hsbc-4nov: no period printed -> as on its "Statement Date 09OCT2026"; ST_BAL_FIG allows any spaces.
 Accounts.swift: a quiet account is listed once (under Quiet), not also under its owner.
 LiveSession+Statements.swift statementReader = 8.
 Bench: reportsmailer.zerodha.net stmt ratchet 1->0 (that "adds up" was a false ₹0 on a ledger)."""
