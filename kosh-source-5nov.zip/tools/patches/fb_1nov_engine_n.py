# kosh feedback 2 Nov (01:53) — engine, part N: wallet money and card money in one order. Myntra's ₹3,414 order was
# paid ₹3,000 from Myntra Credit and ₹414 on the Axis card; the ₹3,000 gift cards loaded into Myntra Credit that night
# (₹2,000 + ₹1,000, on the HDFC card) are money moved into a wallet, not spending. (1) A shop's own mail that says part
# was paid from its credit, wallet, balance, money, points or a gift card ("Myntra Credit - ₹3000.00") tells it as a
# walletUse; the build adds that share as a row of its own paid from that wallet (counted as the spending it is), and
# the card's row says the order's whole and how it was paid. (2) A charge the same day as gift cards the shop said it
# loaded, adding up to it (one card or several), is that load: Wallet & Gift Cards, counted when spent, whatever the
# payee's usual category; and a charge whose payee says "gift card" is one. Idempotent.
p = 'Kosh/engine.js'; s = open(p).read()
def sub(old, new, mark):
    global s
    if mark in s: return
    assert s.count(old) == 1, ('engine N anchor', old[:70], s.count(old))
    s = s.replace(old, new)
# (1a) parse: what a shop's mail says was paid from its own wallet or credit
sub("""  function parse(msg) { return returnWords(giftCardBought(parseMail0(msg), msg), msg); }""",
    """  function parse(msg) { return walletUse(returnWords(giftCardBought(parseMail0(msg), msg), msg), msg); }
  function walletUse(r, msg) {
    if (!r || !msg || !/^(?:confirm|txn|noise)$/.test(r.kind || '')) return r;
    var body = (normalize(msg.text || '', '') + ' ' + normalize('', msg.html || '')).replace(/https?:\\S+/g, ' ').slice(0, 8000);
    var re = /\\b((?:[A-Za-z]+\\s){0,2}(?:credit|wallet|balance|money|cash|points|supercoins|gift ?card(?: balance)?))\\s*\\*?\\s*[:|]?\\s*[-–−]\\s*(?:₹|rs\\.?|inr)\\s*([\\d,]+(?:\\.\\d{1,2})?)/gi, m, out = [];
    while ((m = re.exec(body)) && out.length < 3) {
      var w = m[1].replace(/\\s+/g, ' ').trim().replace(/^(?:(?:total|amount|paid|by|from|via|using|net|and|the|of|order)\\s+)+/i, ''), v = +m[2].replace(/,/g, '');
      if (!(v > 0) || /\\b(?:coupon|bank|card discount|instant|cashback earned|discount)\\b/i.test(w) || /^(?:credit|money|cash|balance|wallet)$/i.test(w)) continue;
      if (!out.some(function (o) { return o.w.toLowerCase() === w.toLowerCase() && o.amt === v; })) out.push({ type: 'walletUse', w: w, amt: v });
    }
    if (!out.length) return r;
    var evs = []; try { evs = typeof r.evs === 'string' ? JSON.parse(r.evs) || [] : []; } catch (e) { evs = []; }
    r.evs = JSON.stringify(evs.concat(out));
    return r;
  }""", "function walletUse(r, msg)")
# gift cards added to a shop's own credit or balance are gift cards bought: "Rs. 2000.0 Gift Card has been added to your Myntra Credit"
sub("""  var GIFT_BOUGHT = /gift card is ready|""", """  var GIFT_BOUGHT = /gift card (?:has been |was )?added to your [a-z ]*(?:credit|balance|wallet)|gift card is ready|""", "gift card (?:has been |was )?added to your")
# (2) gift cards loaded: one charge for several cards that day; a payee that says gift card; over a payee's usual category
sub("""      if (r.dir !== 'out' || !(r.amt > 0) || !giftsSeen.length) return false;
      var g = giftsSeen.filter(function (x) { return !x.used && Math.abs(x.a - r.amt) <= 0.5 && x.d && r.date && Math.abs(daysBetween(x.d, r.date)) <= 1; })[0];
      if (!g) return false; g.used = true; return true;""",
    """      if (r.dir !== 'out' || !(r.amt > 0)) return false;
      if (/\\bgift ?cards?\\b|\\bgift ?voucher\\b|\\begift\\b/i.test(String(r.party || '') + ' ' + String(r.info || ''))) return true;
      if (!giftsSeen.length) return false;
      var g = giftsSeen.filter(function (x) { return !x.used && Math.abs(x.a - r.amt) <= 0.5 && x.d && r.date && Math.abs(daysBetween(x.d, r.date)) <= 1; })[0];
      if (g) { g.used = true; return true; }
      // (several cards that day, one charge for them all)
      var day = giftsSeen.filter(function (x) { return !x.used && x.d && r.date && Math.abs(daysBetween(x.d, r.date)) <= 1; });
      if (day.length >= 2 && day.length <= 4) {
        var sum = day.reduce(function (a, x) { return a + x.a; }, 0);
        if (Math.abs(sum - r.amt) <= 1) { day.forEach(function (x) { x.used = true; }); return true; }
      }
      return false;""", "(several cards that day, one charge for them all)")
sub("""      if (!oc && /^(?:Shopping|Miscellaneous)$/.test(c) && giftCharge(r)) { c = 'Wallet & Gift Cards'; s = 'Gift cards'; k = kindFor(c, r.dir); }""",
    """      if (!mineC && /^(?:Shopping|Miscellaneous)$/.test(c) && giftCharge(r)) { c = 'Wallet & Gift Cards'; s = 'Gift cards'; k = kindFor(c, r.dir); }""", "if (!mineC && /^(?:Shopping|Miscellaneous)$/.test(c) && giftCharge(r))")
# (1b) build: the wallet's share of an order, a row of its own
sub("""    /* GUARDRAIL one purchase, one row, whoever told it:""", """    /* an order paid partly from a shop's own wallet or credit (its mail: "Myntra Credit - ₹3000.00 · Net Paid ₹414"): the
       wallet's share is a row of its own, paid from that wallet, the same kind of spending; the card's row keeps what
       the card was charged and says the order's whole (wu: the wallet and its share; ot: the order's total). Never when
       the wallet's own payment is already a row (a wallet's alert of the same sum that day) */
    (function () {
      var recOf = {};
      (records || []).concat(merged).forEach(function (r) { if (r && r.id) recOf[r.id] = r; });
      var evsOf = function (r) { try { return r && typeof r.evs === 'string' ? JSON.parse(r.evs) || [] : []; } catch (e) { return []; } };
      var add = [];
      var walletRecs = (records || []).filter(function (r) { return r && typeof r.evs === 'string' && r.evs.indexOf('"walletUse"') >= 0; });
      tx.forEach(function (t) {
        if (t.dirRaw !== 'out' || t.partOf || t.wu) return;
        var ids = [String(t.id).split('#')[0]].concat(t.rc ? [t.rc] : []).concat(t.told || []);
        // (and the shop's own mail of the same sum that day that says part came from its wallet, linked or not)
        var tw = String(t.m || '').toLowerCase().replace(/[^a-z ]/g, ' ').split(/\s+/).filter(function (x) { return x.length >= 4; });
        walletRecs.forEach(function (r) {
          if (ids.indexOf(r.id) >= 0 || Math.abs((+r.amt || 0) - t.a) > 1) return;
          var d0 = String(r.date || r.sent || '').slice(0, 10);
          if (!d0 || Math.abs(daysBetween(d0, t.d)) > 1) return;
          var rw = String((r.party || '') + ' ' + (r.inst || '') + ' ' + (r.from || '')).toLowerCase();
          if (tw.some(function (x) { return rw.indexOf(x) >= 0; })) ids.push(r.id);
        });
        var uses = [];
        ids.forEach(function (id) { evsOf(recOf[id]).forEach(function (e) { if (e && e.type === 'walletUse' && e.amt > 0 && !uses.some(function (u) { return u.w === e.w && u.amt === e.amt; })) uses.push(e); }); });
        if (!uses.length) return;
        uses.forEach(function (u) {
          var w = String(u.w).replace(/\\b([a-z])/g, function (a) { return a.toUpperCase(); });
          var there = tx.some(function (x) { return x !== t && x.dirRaw === 'out' && Math.abs(x.a - u.amt) <= 1 && x.d === t.d && /wallet|balance|credit|money|gift/i.test(String(x.card || '') + ' ' + String(x.md || '')); });
          t.wu = (t.wu || []).concat([{ w: w, a: money(u.amt) }]);
          if (there) return;
          add.push(Object.assign({}, t, { id: t.id + '#w' + add.length, a: money(u.amt), card: w, md: 'wallet', instr: 'wallet', inst: w, last4: '', wf: t.id, full: undefined, wu: undefined, n: '', told: undefined, rc: undefined }));
        });
        t.ot = money(t.a + t.wu.reduce(function (a, u) { return a + u.a; }, 0));
      });
      if (add.length) tx = tx.concat(add);
    })();
    /* GUARDRAIL one purchase, one row, whoever told it:""", "an order paid partly from a shop's own wallet or credit")
open(p, 'w').write(s)
print('engine N patched')
s = open(p).read()
sub("""partOf: t.partOf, lr: t.lr || undefined,""", """partOf: t.partOf, wu: t.wu || undefined, ot: t.ot || undefined, wf: t.wf || undefined, lr: t.lr || undefined,""", "wu: t.wu || undefined, ot: t.ot")
open(p, 'w').write(s)
