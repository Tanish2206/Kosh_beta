#!/usr/bin/env python3
"""papers-4nov (statements chat): investment papers read by their own figures.
 - docread.js contract notes printed one row per ISIN with a Buy block and a Sell block (Zerodha's
   new contract note, no B/S cell): each side with a quantity is a trade, kept when quantity x rate
   is the side's own total.
 - engine.js parseCAS: a Total line printing several figures (units, then value) is checked against
   each of them, so a demat holding statement whose rows add to its printed value reconciles.
Idempotent: marker 'papers-4nov'."""
import pathlib, sys
K = pathlib.Path(__file__).resolve().parents[2] / 'Kosh'

def patch(f, old, new, marker):
    p = K / f; s = p.read_text()
    if marker in s: print(f, 'already has', marker); return
    if s.count(old) != 1: sys.exit(f + ': anchor not found once for ' + marker)
    p.write_text(s.replace(old, new)); print(f, 'patched', marker)

patch('docread.js', """  function tradeRow(cs) {
    var si = -1;""", """  /* papers-4nov: one row per ISIN, a Buy block then a Sell block (quantity, average price, brokerage a share,
     price after brokerage, the side's total), then the net quantity and obligation, and no B/S cell. A side with
     a quantity is a trade when quantity x either price is that side's total. */
  function isinBlockTrades(cs) {
    var ii = -1;
    for (var k = 0; k < cs.length; k++) if (ISIN.test(cs[k])) { ii = k; break; }
    if (ii < 0) return null;
    var ns = numbersOf(cs, ii + 1);
    if (ns.length < 10) return null;
    var name = '';
    for (var c = ii; c < cs.length; c++) { if (/[a-z]{3,}/i.test(cs[c])) { var nm = cleanSec(cs[c]); if (nm.length > name.length) name = nm; } }
    var isin = ISIN.exec(cs[ii])[0], out = [];
    for (var s = 0; s < 2; s++) {
      var b = ns.slice(s * 5, s * 5 + 5).map(function (n) { return n.abs; });
      if (b.length < 5) return null;
      if (!(b[0] > 0)) { if (b[4] > 0.005) return null; continue; }
      if (b[0] !== Math.round(b[0] * 1000) / 1000) return null;
      var okp = [b[1], b[3]].some(function (p) { return p > 0 && Math.abs(b[0] * p - b[4]) <= Math.max(0.5, b[4] * 0.0005); });
      if (!okp) return null;
      out.push({ date: '', isin: isin, name: name, side: s === 0 ? 'buy' : 'sell', qty: b[0], price: r4(b[1]), value: r2(b[0] * b[1]), exch: '' });
    }
    return out.length ? out : null;
  }
  function tradeRow(cs) {
    var si = -1;""", 'papers-4nov: one row per ISIN')

patch('docread.js', """      var t = tradeRow(cs);
      if (!t) return;
      used[li] = 1;""", """      var t = tradeRow(cs);
      if (!t) {   // papers-4nov
        var tb = isinBlockTrades(cs);
        if (!tb) return;
        used[li] = 1;
        tb.forEach(function (x) { x.date = td ? td.v : ''; x.exch = sectExch || (ex0 ? ex0[1].toUpperCase() : ''); trades.push(x); });
        return;
      }
      used[li] = 1;""", 'papers-4nov\n')

patch('engine.js', """    while ((tm = tre.exec(flat))) totals.push(num(tm[1]));
    var match = totals.filter(""", """    while ((tm = tre.exec(flat))) totals.push(num(tm[1]));
    // papers-4nov: a Total line printing several figures (units, then value): each of them
    lines.forEach(function (ln) {
      if (!/^\\s*(?:grand\\s+)?total\\b|\\btotal\\s*:/i.test(ln)) return;
      (ln.match(/(?:\\d{1,3}(?:,\\d{2,3})+|\\d+)\\.\\d{2,3}/g) || []).forEach(function (x) { var v = num(x); if (v > 0 && totals.indexOf(v) < 0) totals.push(v); });
    });
    var match = totals.filter(""", 'papers-4nov: a Total line')

# papers-4nov-b (applied in place, same chat): a levy line's footnote digit after "(₹)" is no amount.
# papers-4nov-c (in place): when a note has the per-ISIN summary, its annexure order rows are not trades too.
# Swift by hand (in place): LiveSession+Statements.swift statementReader = 6, and its reopen also takes "cas" and "contract" papers.
