#!/usr/bin/env python3
"""daymon-3nov (statements chat): a statement line dated day and month run together with no year ("09SEP   BBPS PMT …",
HSBC's card statement) is a dated line; its year is the one that puts it in the statement's period. HSBC's card
statements read 0 lines before this. Idempotent. Run from kosh-beta/."""
import sys
p = 'Kosh/engine.js'; s = open(p, encoding='utf-8').read()
if 'daymon-3nov' in s: print('daymon-3nov already applied'); sys.exit(0)
pairs = [
 ("""    MONW + '\\\\.?[ \\\\-]\\\\d{1,2}(?:st|nd|rd|th)?(?:,?[ \\\\-]\\\\d{4})?|\\\\d{1,2}[ \\\\-]' + MONW + ')';""",
  """    MONW + '\\\\.?[ \\\\-]\\\\d{1,2}(?:st|nd|rd|th)?(?:,?[ \\\\-]\\\\d{4})?|\\\\d{1,2}[ \\\\-]' + MONW + '|\\\\d{1,2}(?:' + MON + ')(?![a-z\\\\d]))';   // (daymon-3nov) "09SEP\""""),
 ("""    else if ((m = /^(\\d{1,2})[ \\-]([a-z]{3})[a-z]*$/.exec(t)) && MONTHS[m[2]]) t = yearless(+m[1], m[2], ctx);""",
  """    else if ((m = /^(\\d{1,2})[ \\-]?([a-z]{3})[a-z]*$/.exec(t)) && MONTHS[m[2]]) t = yearless(+m[1], m[2], ctx);   // (daymon-3nov) "09sep\""""),
]
for a, b in pairs:
    if s.count(a) != 1: sys.exit('anchor %d: %r' % (s.count(a), a[:70]))
    s = s.replace(a, b)
open(p, 'w', encoding='utf-8').write(s); print('daymon-3nov applied')
