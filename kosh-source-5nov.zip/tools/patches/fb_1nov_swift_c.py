# kosh feedback 1 Nov — Swift, part C: Insights › Up close (what was bought, where, the category list). Idempotent.
def load(p): return open(p).read()
# --- InsightsCompare: CategoryDive and ShopName
p = 'Kosh/InsightsCompare.swift'; s = load(p)
if 'enum ShopName' not in s:
    a = s.index('enum CategoryDive {')
    b = s.index('\n}\n', a) + 3
    s = s[:a] + r'''enum CategoryDive {
    /// one line of the breakdown: its name, a caption of what is in it (the shops in a kind, the kinds at a shop), and
    /// the payments behind it (newest first) so it can open into them
    struct Part: Identifiable { let name: String; let v: Double; let n: Int; var sub: String = ""; var rows: [Txn] = []; var id: String { name } }

    static func parts(_ rows: [Txn], by key: (Txn) -> String, caption: (Txn) -> String = { _ in "" }) -> [Part] {
        var v: [String: Double] = [:], n: [String: Int] = [:], r: [String: [Txn]] = [:]
        for t in rows { let k = key(t); v[k, default: 0] += t.a; n[k, default: 0] += 1; r[k, default: []].append(t) }
        return v.keys.map { (k: String) -> Part in
            let xs: [Txn] = r[k] ?? []
            // the caption: the top three of what's inside, by money, each once
            var by: [String: Double] = [:]
            for t in xs { let c: String = caption(t); if !c.isEmpty && c != k { by[c, default: 0] += t.a } }
            let ranked: [(key: String, value: Double)] = by.sorted { $0.value != $1.value ? $0.value > $1.value : $0.key < $1.key }
            let top: [String] = ranked.prefix(3).map { $0.key }
            let more: Int = max(0, ranked.count - 3)
            let line: String = top.joined(separator: ", ") + (more > 0 ? " +" + String(more) : "")
            return Part(name: k, v: v[k] ?? 0, n: n[k] ?? 0, sub: line, rows: xs.sorted { ($0.d, $0.t) > ($1.d, $1.t) })
        }.sorted { (a: Part, b: Part) -> Bool in
            // (what kosh couldn't tell goes last, whatever its size: the known kinds lead)
            let ua: Bool = a.name == unknown, ub: Bool = b.name == unknown
            if ua != ub { return ub }
            return a.v != b.v ? a.v > b.v : a.name < b.name
        }
    }

    /// where a payment went, as a person says it: the app or store kosh knows it by ("Myntra"), else its payee cleaned
    /// of what the bank's alert cut short or added ("Uniqlo Indi" → Uniqlo, "Flipkart Pa" → Flipkart)
    static func place(_ t: Txn) -> String {
        let p: String = (t.pf ?? "").trimmingCharacters(in: .whitespaces)
        return ShopName.clean(p.isEmpty ? t.m : p)
    }

    /// a sub-category that says nothing about what was bought
    static func vague(_ s: String, cat: String) -> Bool {
        let k: String = s.trimmingCharacters(in: .whitespaces).lowercased()
        return k.isEmpty || k == cat.lowercased() || ["other", "others", "general", "misc", "miscellaneous", "uncategorised", "uncategorized", "not split further"].contains(k)
    }
    /// what it was. Shopping: what was bought, as kosh worked it out from the order's items, your word, its kind or its
    /// shop (engine.js › whatWasBought), where it was bought never being a kind; else its sub-category
    static func kind(_ t: Txn, cat: String) -> String {
        if cat == "Shopping" { return t.wk ?? unknown }
        let s: String = t.s.trimmingCharacters(in: .whitespaces)
        return vague(s, cat: cat) ? "Other " + cat.lowercased() : s
    }
    /// the shopping kosh couldn't tell the kind of: its mail named no items and its shop sells everything
    static let unknown: String = "Not known yet"
}

/// a shop's name from a payee as the bank printed it: corporate words and the alert's cut-off tail dropped, a few known
/// legal names said the way people say them, capitals evened out
enum ShopName {
    static let known: [String: String] = [
        "hennes n mauritz": "H&M", "hennes & mauritz": "H&M", "hennes and mauritz": "H&M",
        "amazonsellerservices": "Amazon", "amazon seller services": "Amazon", "amazon pay": "Amazon", "amazon india": "Amazon",
        "myntradesignsprivatelim": "Myntra", "myntradesignspvtltd": "Myntra", "flipkart internet": "Flipkart",
        "bundl technologies": "Swiggy", "zomato media": "Zomato", "avenue supermarts": "DMart",
    ]
    /// words a payee's legal name ends in, and that a cut-off alert leaves a piece of ("Indi", "Pvt", "Ap", "Desi")
    static let tails: [String] = ["india", "private", "pvt", "limited", "ltd", "llp", "apparels", "apparel", "app", "pay", "payments",
                                  "designs", "design", "sports", "services", "service", "technologies", "technology", "tech",
                                  "retail", "retails", "works", "shop", "shoppe", "store", "stores", "beauty", "online",
                                  "internet", "enterprises", "enterprise", "ventures", "solutions", "industries", "corporation", "co"]
    static let joins: Set<String> = ["and", "&", "n", "of", "the"]

    static func clean(_ raw: String) -> String {
        var s: String = raw.replacingOccurrences(of: "_", with: " ").trimmingCharacters(in: .whitespacesAndNewlines)
        if s.isEmpty { return "Unnamed" }
        let low0: String = s.lowercased()
        for (k, v) in known where low0 == k || low0.hasPrefix(k + " ") { return v }
        // one word run together: cut at the first legal word inside it ("Ampletechnologiesp" → Ample)
        if !s.contains(" ") {
            let low: String = s.lowercased()
            for w in ["technologies", "designs", "private", "pvt", "india", "retail", "services", "solutions", "enterprises"] {
                if let r = low.range(of: w) {
                    let cut: Int = low.distance(from: low.startIndex, to: r.lowerBound)
                    if cut >= 3 { s = String(s.prefix(cut)); break }
                }
            }
        }
        var words: [String] = s.split(separator: " ").map(String.init)
        while words.count > 1 {
            let last: String = words[words.count - 1].lowercased().trimmingCharacters(in: CharacterSet(charactersIn: ".,"))
            let digits: Bool = !last.isEmpty && last.allSatisfy { $0.isNumber }
            let cutTail: Bool = last.count >= 2 && last.count <= 5 && tails.contains { $0.count > last.count && $0.hasPrefix(last) }
            if digits || tails.contains(last) || cutTail || joins.contains(last) { words.removeLast() } else { break }
        }
        let joined: String = words.joined(separator: " ")
        for (k, v) in known where joined.lowercased() == k { return v }
        if (joined == joined.uppercased() && joined.count > 4) || joined == joined.lowercased() {
            return words.map { (w: String) -> String in
                (w.count <= 3 && w == w.uppercased()) ? w : w.prefix(1).uppercased() + w.dropFirst().lowercased()
            }.joined(separator: " ")
        }
        return joined
    }
}
''' + s[b:]
    open(p, 'w').write(s)

# --- InsightsBook: Up close
p = 'Kosh/InsightsBook.swift'; s = load(p)
def sub(a, b, mark):
    global s
    if mark in s: return
    assert s.count(a) == 1, (a[:90], s.count(a)); s = s.replace(a, b)
sub("""    @AppStorage("upclose.lens") private var lens = "subs\"""", """    @AppStorage("upclose.lens") private var lens = "subs"
    /// the category list, open
    @State private var picking = false""", "@State private var picking = false")
sub("""        let parts: [CategoryDive.Part] = lens == "subs"
            ? CategoryDive.parts(rows, by: { $0.s.isEmpty ? "Not split further" : $0.s })
            : Array(CategoryDive.parts(rows, by: { $0.m }).prefix(6))""", """        let parts: [CategoryDive.Part] = lens == "subs"
            ? CategoryDive.parts(rows, by: { CategoryDive.kind($0, cat: cat) }, caption: { CategoryDive.place($0) })
            : CategoryDive.parts(rows, by: { CategoryDive.place($0) }, caption: { CategoryDive.kind($0, cat: cat) })
        let ranked: [UpCloseMenu.Item] = UpCloseMenu.items(span, months: look.months)""", "let ranked: [UpCloseMenu.Item]")
a = s.find("""                    Menu {
                        Picker("Category", selection: Binding(get: { cat }, set: { focus = $0 })) {""")
if a >= 0:
    b = s.index("""                    .accessibilityLabel("Pick a category, now " + cat)""", a)
    s = s[:a] + """                    // (a list of its own, biggest first over the months on show, each with what went on it and its share of
                    // everything spent then: 1 Nov, the menu read as a wall of names in no order)
                    Button { picking = true } label: {
                        HStack(spacing: 6) {
                            Image(systemName: IconTile.outline(store.catSymbol(cat))).font(.footnote.weight(.semibold))
                            Text(cat).font(.subheadline.weight(.semibold)).lineLimit(1)
                            Image(systemName: "chevron.up.chevron.down").font(.caption2.weight(.bold))
                        }
                        .foregroundStyle(ink)
                        .padding(.leading, 10)
                        .padding(.trailing, 12)
                        .frame(minHeight: 36)
                        .background(color.opacity(0.15), in: Capsule())
                    }
                    .buttonStyle(.press)
                    .sheet(isPresented: $picking) {
                        UpClosePicker(items: ranked, chosen: cat, when: look.when) { focus = $0 }
                            .presentationDetents([.medium, .large])
                            .presentationDragIndicator(.visible)
                    }
""" + s[b:]
sub("""                    Picker("Look at", selection: $lens) {
                        Text("Inside").tag("subs")
                        Text("Places").tag("places")
                    }
                    .pickerStyle(.segmented)
                    .padding(.top, 14)
                    PartBars(parts: parts, total: max(look.figure, parts.reduce(0) { $0 + $1.v }), color: color, live: look.live)
                        .padding(.top, 6)""", """                    Picker("Look at", selection: $lens) {
                        Text("What it was").tag("subs")
                        Text("Where").tag("places")
                    }
                    .pickerStyle(.segmented)
                    .padding(.top, 14)
                    if let lead = UpClose.lead(parts, total: look.figure, lens: lens) {
                        Text(lead)
                            .font(.footnote).foregroundStyle(.secondary)
                            .fixedSize(horizontal: false, vertical: true)
                            .padding(.top, 12)
                            .contentTransition(.opacity)
                    }
                    PartBars(parts: parts, total: max(look.figure, parts.reduce(0) { $0 + $1.v }), color: color, ink: ink, live: look.live,
                             today: store.snap.today, key: cat + "|" + lens + "|" + look.months.sorted().joined(separator: ","))
                        .padding(.top, 6)""", "Text(\"What it was\").tag(\"subs\")")
sub("""    static func spelled(_ n: Int) -> String {""", """    /// the one line that says where most of it went: "Most of it at Myntra: ₹11,240, 41%." / "Clothing was 54% of it."
    static func lead(_ parts: [CategoryDive.Part], total: Double, lens: String) -> String? {
        guard parts.count > 1, let top = parts.first, total > 0, top.v > 0, top.name != CategoryDive.unknown else { return nil }
        let share: Double = top.v / total
        guard share >= 0.25 else { return nil }
        let pct: String = Fmt.pct(share)
        if lens == "subs" {
            let first: String = top.sub.split(separator: ",").first.map { String($0) } ?? ""
            return top.name + " was " + pct + " of it" + (first.isEmpty ? "." : ", mostly " + first + ".")
        }
        return "Most of it at " + top.name + ": " + Fmt.rupees(top.v) + ", " + pct + (top.n > 1 ? " over " + String(top.n) + " payments." : ".")
    }

    static func spelled(_ n: Int) -> String {""", "static func lead(_ parts: [CategoryDive.Part]")
if 'struct UpClosePicker' not in s:
    a = s.index('private struct PartBars: View {')
    b = s.index('// MARK: 6 · Keep rate')
    s = s[:a] + r'''private struct PartBars: View {
    let parts: [CategoryDive.Part]
    let total: Double
    let color: Color
    let ink: Color
    let live: Bool
    let today: String
    /// what's on show (category, lens, months): a line left open closes when it changes
    let key: String
    @Environment(Store.self) private var store
    @Environment(\.accessibilityReduceMotion) private var still
    @State private var open: String?
    @State private var more = false
    static let first: Int = 6
    static let inside: Int = 5

    var body: some View {
        if parts.isEmpty {
            Text(live ? "Nothing here yet this month." : "Nothing here that month.")
                .font(.subheadline).foregroundStyle(.secondary)
                .padding(.vertical, 10)
        } else {
            let shown: [CategoryDive.Part] = more ? parts : Array(parts.prefix(Self.first))
            VStack(spacing: 0) {
                ForEach(Array(shown.enumerated()), id: \.element.id) { i, p in
                    if i > 0 { InsightDivider() }
                    line(p, last: i == shown.count - 1)
                }
                if parts.count > Self.first {
                    InsightDivider()
                    Button {
                        withAnimation(still ? nil : Motion.open) { more.toggle() }
                    } label: {
                        HStack(spacing: 6) {
                            Text(more ? "Fewer" : String(parts.count - Self.first) + " more")
                            Image(systemName: "chevron.down").font(.caption2.weight(.bold)).rotationEffect(.degrees(more ? 180 : 0))
                        }
                        .font(.footnote.weight(.semibold)).foregroundStyle(ink)
                        .frame(maxWidth: .infinity, minHeight: 40)
                        .contentShape(Rectangle())
                    }
                    .buttonStyle(.press)
                }
            }
            .onChange(of: key) { _, _ in open = nil; more = false }
        }
    }

    @ViewBuilder func line(_ p: CategoryDive.Part, last: Bool) -> some View {
        let isOpen: Bool = open == p.id
        let fill: CGFloat = CGFloat(min(1, p.v / max(1, total)))
        VStack(alignment: .leading, spacing: 0) {
            Button {
                withAnimation(still ? nil : (isOpen ? Motion.base : Motion.open)) { open = isOpen ? nil : p.id }
            } label: {
                PartLine(p: p, fill: fill, color: color, open: isOpen)
                    .padding(.top, 10)
                    .padding(.bottom, isOpen ? 8 : (last ? 2 : 10))
                    .contentShape(Rectangle())
            }
            .buttonStyle(.press)
            .accessibilityElement(children: .ignore)
            .spokenFigures(p.name + ", " + String(p.n) + (p.n == 1 ? " payment, " : " payments, ") + Fmt.rupees(p.v),
                           hidden: p.name + ", " + String(p.n) + (p.n == 1 ? " payment" : " payments"))
            .accessibilityHint(isOpen ? "Hides its payments" : "Shows its payments")
            if isOpen {
                VStack(spacing: 0) {
                    if p.name == CategoryDive.unknown {
                        Text("Their mail didn’t say what was in these orders, and the shop sells everything.")
                            .font(.caption).foregroundStyle(.secondary)
                            .frame(maxWidth: .infinity, alignment: .leading).fixedSize(horizontal: false, vertical: true)
                            .padding(.bottom, 4)
                    }
                    ForEach(Array(p.rows.prefix(Self.inside))) { t in payment(t) }
                    if p.rows.count > Self.inside {
                        Text("and " + String(p.rows.count - Self.inside) + " more, under See the payments")
                            .font(.caption).foregroundStyle(.secondary)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.top, 6)
                    }
                }
                .padding(.leading, 12)
                .overlay(alignment: .leading) { Capsule().fill(color.opacity(0.35)).frame(width: 2).padding(.vertical, 4) }
                .padding(.bottom, last ? 4 : 12)
                .transition(.opacity.combined(with: .move(edge: .top)))
            }
        }
    }

    /// what was bought, when the order's mail said: its first item, and how many more
    func bought(_ t: Txn) -> String? {
        if let items = store.payFact(t)?.items, !items.isEmpty {
            let first: String = items[0].n.trimmingCharacters(in: .whitespacesAndNewlines)
            return items.count > 1 ? first + " +" + String(items.count - 1) : first
        }
        guard let o = store.order(t), let line = o.bill?.first(where: { $0.k == "sub" && !$0.n.isEmpty }) else { return nil }
        let n: String = line.n.trimmingCharacters(in: .whitespacesAndNewlines)
        return n.isEmpty || n.lowercased() == "subtotal" || n.lowercased() == "item total" ? nil : n
    }

    func payment(_ t: Txn) -> some View {
        let when: String = Day.fmt(t.d, t.d.prefix(4) == today.prefix(4) ? "d MMM" : "d MMM yy")
        let what: String = bought(t) ?? t.wk ?? (t.s.isEmpty || t.s.lowercased() == "online" ? "" : t.s)
        return HStack(alignment: .firstTextBaseline, spacing: 10) {
            Text(when)
                .font(.system(.caption, design: .rounded)).monospacedDigit().foregroundStyle(.secondary)
                .frame(width: 52, alignment: .leading)
            VStack(alignment: .leading, spacing: 1) {
                Text(CategoryDive.place(t)).font(.footnote.weight(.medium)).lineLimit(1)
                if !what.isEmpty { Text(what).font(.caption2).foregroundStyle(.secondary).lineLimit(1) }
            }
            Spacer(minLength: 6)
            Text(Fmt.rupees(t.a)).font(.system(.footnote, design: .rounded, weight: .medium)).monospacedDigit()
        }
        .padding(.vertical, 6)
        .privacySensitive()
        .accessibilityElement(children: .combine)
    }
}

/// one line of the breakdown, closed: name, count, figure, what's in it, and its bar
private struct PartLine: View {
    let p: CategoryDive.Part
    let fill: CGFloat
    let color: Color
    let open: Bool
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(alignment: .firstTextBaseline, spacing: 6) {
                Text(p.name).font(.subheadline.weight(.semibold)).foregroundStyle(Color.primary).oneLineUnlessLarge()
                Text("\(p.n)×").font(.system(.footnote, design: .rounded)).monospacedDigit().foregroundStyle(.secondary)
                Spacer(minLength: 6)
                Text(Fmt.rupees(p.v))
                    .font(.system(.subheadline, design: .rounded, weight: .semibold)).monospacedDigit()
                    .foregroundStyle(Color.primary)
                    .lineLimit(1)
                Image(systemName: "chevron.down").font(.caption2.weight(.bold)).foregroundStyle(.tertiary)
                    .rotationEffect(.degrees(open ? 180 : 0))
            }
            if !p.sub.isEmpty {
                Text(p.sub).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                    .padding(.top, -4)
            }
            GeometryReader { g in
                ZStack(alignment: .leading) {
                    Capsule().fill(color.opacity(0.16))
                    Capsule().fill(color).frame(width: max(4, g.size.width * fill))
                }
            }
            .frame(height: 6)
        }
    }
}

/// Up close's categories, as a list: each with what went on it over the months on show and its share of all the
/// spending then, biggest first, a bar for the share; the one on show ticked
private struct UpClosePicker: View {
    @Environment(Store.self) private var store
    @Environment(\.colorScheme) private var scheme
    @Environment(\.dismiss) private var dismiss
    let items: [UpCloseMenu.Item]
    let chosen: String
    let when: String
    let pick: (String) -> Void
    var body: some View {
        let top: Double = items.first?.share ?? 0
        NavigationStack {
            ScrollView {
                VStack(spacing: 0) {
                    ForEach(Array(items.enumerated()), id: \.element.id) { i, it in
                        Button {
                            pick(it.cat); dismiss()
                        } label: {
                            UpClosePickRow(it: it, on: it.cat == chosen, top: top, color: store.catColor(it.cat), symbol: store.catSymbol(it.cat), scheme: scheme)
                        }
                        .buttonStyle(.press)
                        .accessibilityLabel(UpClosePickRow.spoken(it))
                        .accessibilityAddTraits(it.cat == chosen ? .isSelected : [])
                        if i < items.count - 1 { Divider().padding(.leading, 46) }
                    }
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 24)
            }
            .navigationTitle("Categories")
            .navigationBarTitleDisplayMode(.inline)
            .safeAreaInset(edge: .top, spacing: 0) {
                Text("Spending " + when + ", biggest first").font(.footnote).foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, alignment: .leading).padding(.horizontal, 20).padding(.bottom, 6)
            }
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } } }
        }
        .sensoryFeedback(.selection, trigger: chosen)
    }
}

/// one category in the list: its tile, name, amount, share, and a bar for the share against the biggest
private struct UpClosePickRow: View {
    let it: UpCloseMenu.Item
    let on: Bool
    let top: Double
    let color: Color
    let symbol: String
    let scheme: ColorScheme
    static func spoken(_ it: UpCloseMenu.Item) -> String {
        it.v > 0 ? it.cat + ", " + Fmt.rupees(it.v) + ", " + Fmt.pct(it.share) + " of spending" : it.cat + ", nothing"
    }
    var body: some View {
        let has: Bool = it.v > 0
        let fill: CGFloat = has && top > 0 ? CGFloat(it.share / top) : 0
        HStack(spacing: 12) {
            Image(systemName: symbol).font(.system(size: 15, weight: .semibold))
                .foregroundStyle(color)
                .frame(width: 34, height: 34)
                .background(color.opacity(0.14), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
            VStack(alignment: .leading, spacing: 6) {
                HStack(alignment: .firstTextBaseline, spacing: 6) {
                    Text(it.cat).font(.subheadline.weight(on ? .bold : .semibold)).foregroundStyle(Color.primary).lineLimit(1)
                    Spacer(minLength: 6)
                    Text(has ? Fmt.rupees(it.v) : "—")
                        .font(.system(.subheadline, design: .rounded, weight: .semibold)).monospacedDigit()
                        .foregroundStyle(has ? Color.primary : Color.secondary)
                    Text(has ? Fmt.pct(it.share) : "")
                        .font(.system(.footnote, design: .rounded, weight: .semibold)).monospacedDigit()
                        .foregroundStyle(InsightInk.deep(color, scheme))
                        .frame(minWidth: 38, alignment: .trailing)
                }
                GeometryReader { g in
                    ZStack(alignment: .leading) {
                        Capsule().fill(Color.primary.opacity(0.06))
                        Capsule().fill(color).frame(width: has ? max(3, g.size.width * fill) : 0)
                    }
                }
                .frame(height: 4)
            }
            Image(systemName: "checkmark").font(.footnote.weight(.bold)).foregroundStyle(Color.kosh)
                .opacity(on ? 1 : 0)
                .frame(width: 16)
        }
        .padding(.vertical, 11)
        .contentShape(Rectangle())
    }
}

/// Up close's categories, biggest first over the months on show, each with what went on it and its share of everything
/// spent then
enum UpCloseMenu {
    struct Item: Identifiable { let cat: String; let v: Double; let share: Double; var id: String { cat } }
    static func items(_ span: CatMonths, months: Set<String>) -> [Item] {
        let all: Double = months.reduce(0) { $0 + (span.total[$1] ?? 0) }
        let xs: [Item] = span.cats.map { (c: String) -> Item in
            let v: Double = months.reduce(0) { $0 + span.at(c, $1) }
            return Item(cat: c, v: v, share: all > 0 ? v / all : 0)
        }
        return xs.sorted { $0.v != $1.v ? $0.v > $1.v : $0.cat < $1.cat }
    }
}

''' + s[b:]
open(p, 'w').write(s)
print('swift C patched')
