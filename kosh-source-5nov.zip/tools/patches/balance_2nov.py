#!/usr/bin/env python3
"""Card balance notices (2 Nov 2026): Amex "Your balance update", HSBC "excess balance on your credit card", SBI Card
"Credit Balance in your account" are read as the card's balance (kind balance, instr card), not as noise. Card
balances aren't counted in any account's balance or net worth (acctLedger takes accounts only). Idempotent."""
import pathlib, sys
p = pathlib.Path(__file__).resolve().parents[2] / 'Kosh' / 'engine.js'
s = p.read_text()
a = """    // a past card payment turned into EMIs ("has been successfully converted to EasyEMI"): no new money moved, the"""
b = """    // a card's balance notice: what the card owes, or what it holds for you ("excess balance", "credit balance"), as
    // of a day. Nothing moved; the card's balance is kept (Amex's monthly "balance update", HSBC's and SBI Card's notes
    // of a credit balance to be refunded)
    var cbal = cardBalanceNote(hay);
    if (cbal && inst && /^(?:card|bank)$/.test(inst.kind)) {
      var cbd = isoDate(cbal.on, '') || sent;
      return Object.assign(base, { kind: 'balance', rule: 'balance-card', instr: 'card', last4: cbal.l4, date: cbd, time: '', bal: cbal.v, balAt: cbd,
        credit: cbal.credit, conf: 'high' });
    }
""" + a
fn_a = """  function normalizeOnce(text, html) {"""
fn_b = """  function cardBalanceNote(h) {
    var m, num2 = function (x) { return +String(x).replace(/,/g, ''); };
    var dmy = function (x) { var q = /(\\d{1,2})[\\/-](\\d{1,2})[\\/-](\\d{4})/.exec(x); return q ? q[3] + '-' + ('0' + q[2]).slice(-2) + '-' + ('0' + q[1]).slice(-2) : x; };
    if ((m = /latest balance on your american express\\S*\\s+card as of\\s+([\\w\\/-]+).{0,400}?current balance\\s*(?:rs\\.?|inr|₹)\\s*([\\d,]+(?:\\.\\d{1,2})?)/i.exec(h))) {
      var ae = /account ending\\s*:?\\s*\\d*(\\d{4})\\b/i.exec(h);
      return { v: num2(m[2]), on: dmy(m[1].replace(/-([a-z]{3})-/i, '-$1-')), l4: ae ? ae[1] : '', credit: false };
    }
    if ((m = /excess balance of\\s*(?:₹|rs\\.?|inr)\\s*([\\d,]+(?:\\.\\d{1,2})?) on your [\\w ]{0,20}credit card ending (?:with\\s*)?(\\d{4}) as on (\\d{1,2}\\/\\d{1,2}\\/\\d{4})/i.exec(h)))
      return { v: num2(m[1]), on: dmy(m[3]), l4: m[2], credit: true };
    if ((m = /credit balance of\\s*(?:rs\\.?|inr|₹)\\s*([\\d,]+(?:\\.\\d{1,2})?) on your card account/i.exec(h))) {
      var sc = /credit card[x\\s*•]*?(\\d{2,4})\\b/i.exec(h);
      return { v: num2(m[1]), on: '', l4: sc ? sc[1] : '', credit: true };
    }
    return null;
  }
""" + fn_a
if 'function cardBalanceNote' not in s:
    if a not in s or fn_a not in s: sys.exit('balance_2nov: anchor missing')
    s = s.replace(a, b, 1).replace(fn_a, fn_b, 1); p.write_text(s); print('balance_2nov: applied')
