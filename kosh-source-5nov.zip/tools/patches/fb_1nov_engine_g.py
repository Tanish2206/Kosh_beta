# kosh feedback 1 Nov (23:46) — engine, part G: no sender is boxed into one job ("everyone does everything"). A PDF
# kosh has no rule for is no longer left shut: when the mail or the file reads as money of any kind (an invoice, a
# receipt, a bill, a policy, a statement, a booking, a premium, a fee, an order, a payment, a certificate, a challan,
# an advice, a schedule…), it is opened as "unknown" and the paper's own words say what it is (docClass), whoever
# sent it. Never a brochure, terms, a newsletter, a menu, a catalogue, an e-voting notice or a résumé. Idempotent.
p = 'Kosh/engine.js'; s = open(p).read()
old = """    else if (!inst && /\\.(?:pdf|zip)$/i.test(m.filename || '') && !(m.attachments || []).length) kind = 'unknown';   // added by hand: read it and see
    return { kind: kind, file: kind ? best : '' };"""
new = """    else if (!inst && /\\.(?:pdf|zip)$/i.test(m.filename || '') && !(m.attachments || []).length) kind = 'unknown';   // added by hand: read it and see
    // (any sender's paper about money: opened, and its own words say what it is)
    if (!kind && (m.attachments || []).length && !/^(?:broker|exchange|depository|rta|amc)$/.test(k)) {
      var fin = (sj + ' ' + files.join(' ')).toLowerCase().replace(/[_\\-]+/g, ' ');
      var head = normalize(m.text || '', m.html || '').slice(0, 1500).toLowerCase();
      var money = /\\b(?:invoice|receipt|bill|statement|polic(?:y|ies)|insurance|premium|booking|ticket|itinerary|order|payment|paid|fees?|challan|advice|certificate|schedule|confirmation|contract|deposit|loan|emi|salary|tax|gst|refund|purchase|subscription|renewal|recharge|e ?stamp|allotment|dividend)\\b/;
      var notMoney = /\\b(?:brochure|terms|t ?& ?c|tnc|newsletter|menu|catalog(?:ue)?|flyer|webinar|agenda|resume|cv|e ?voting|postal ballot|annual general meeting|agm|book closure|margin (?:statement|obligation)|retention|proposal|illustration|quot(?:e|ation)|offer letter|report card)\\b/;
      if (money.test(fin) && !notMoney.test(fin) && !/unsubscribe[\\s\\S]{0,40}offers|limited period offer|% off/.test(head)) kind = 'unknown';
    }
    return { kind: kind, file: kind ? best : '' };"""
if "(any sender's paper about money: opened" not in s:
    assert s.count(old) == 1, 'docWanted tail anchor'
    s = s.replace(old, new)
open(p, 'w').write(s)
print('engine G patched')
