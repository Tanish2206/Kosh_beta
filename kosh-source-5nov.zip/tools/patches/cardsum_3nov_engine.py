#!/usr/bin/env python3
"""cardsum-3nov (statements chat, 3 Nov): a card statement's summary read as the equation it prints, whatever its
labels ("Previous Balance - Payments - Credits + Purchase + Cash Advance + Other Debit&Charges = Total Payment Due" over
a row of figures; "Total Amount due = Previous Balance + Purchases + Cash Advances - Payments" with its "= + + -" row;
"Rs. 0.00 - Rs. 0.00 + Rs. 14,022.26 = Rs. 14,022.26"). The figures are taken only when the equation holds, so a misread
can't pass: then prev, payments (the − terms), spends (the + terms) and the total due are known, and every card
statement has something to check its lines against. Any issuer. Idempotent. Run from kosh-beta/."""
import sys
p = 'Kosh/engine.js'
s = open(p, encoding='utf-8').read()
if 'cardsum-3nov' in s: print('cardsum-3nov already applied'); sys.exit(0)
old = """  function cardSummaryOf(text) {
    var lines = String(text || '').split('\\n'), got = {};"""
new = """  /* (cardsum-3nov) the summary as the equation it prints: figures with their operators, from one line ("Rs. 0.00 - Rs. 0.00
     + Rs. 14,022.26 = Rs. 14,022.26"), or a line of operators (between labels, "Previous Balance - Payments + Purchase =
     Total Due", or on their own, "=  +  +  -") over the next line's figures in the same order. Kept only when it holds */
  var EQ_AMT = /(?:rs\\.?|inr|₹|`)?\\s*(-?(?:\\d{1,3}(?:,\\d{2,3})+|\\d+)\\.\\d{2})\\s*(cr\\b|dr\\b)?/gi;
  function eqSolve(vals, ops) {
    if (vals.length < 3 || ops.length !== vals.length - 1 || ops.filter(function (o) { return o === '='; }).length !== 1) return null;
    var at = ops.indexOf('='), L = [], R = [];
    vals.forEach(function (v, i) { var op = i === 0 || i - 1 === at ? '+' : ops[i - 1]; (i <= at ? L : R).push({ v: v, op: op }); });
    function sum(side) { return side.reduce(function (a, t) { return a + (t.op === '-' ? -t.v : t.v); }, 0); }
    if (Math.abs(sum(L) - sum(R)) > 1.01) return null;
    var one = L.length === 1 ? L : R.length === 1 ? R : null, many = one === L ? R : L;
    if (!one || many.length < 2) return null;
    var got = { total: Math.abs(one[0].v), prev: Math.abs(many[0].v), credits: 0, debits: 0, eq: true };
    many.slice(1).forEach(function (t) { if (t.op === '-') got.credits += Math.abs(t.v); else got.debits += Math.abs(t.v); });
    got.credits = Math.round(got.credits * 100) / 100; got.debits = Math.round(got.debits * 100) / 100;
    return got;
  }
  function eqFigures(line) {
    var vals = [], m; EQ_AMT.lastIndex = 0;
    while ((m = EQ_AMT.exec(line))) vals.push((m[2] || '').toLowerCase() === 'cr' ? -num(m[1]) : num(m[1]));
    return vals;
  }
  function cardEquation(lines) {
    for (var i = 0; i < lines.length; i++) {
      var ln = lines[i];
      // figures and operators on one line
      var toks = ln.match(/(?:rs\\.?|inr|₹|`)?\\s*-?(?:\\d{1,3}(?:,\\d{2,3})+|\\d+)\\.\\d{2}(?:\\s*(?:cr|dr)\\b)?|(?:^|\\s)[+\\-=](?=\\s)/gi);
      if (toks && toks.length >= 5) {
        var vals = [], ops = [];
        toks.forEach(function (t) { var tt = t.trim(); if (/^[+\\-=]$/.test(tt)) { if (vals.length > ops.length) ops.push(tt); } else if (vals.length === ops.length) vals.push(eqFigures(tt)[0]); });
        if (vals.length > ops.length + 1) vals = vals.slice(0, ops.length + 1);
        var g = eqSolve(vals, ops); if (g) return g;
      }
      // operators between labels, or alone, over the next lines' figures
      if (eqFigures(ln).length) continue;
      var opsOnly = ln.replace(/[A-Za-z&\\/(),.`'’]+/g, ' ').match(/(?:^|\\s)[+\\-=](?=\\s|[A-Za-z]|$)/g) || ln.match(/[+=]|\\s-\\s/g);
      if (!opsOnly || opsOnly.length < 2) continue;
      var ops2 = opsOnly.map(function (o) { return o.trim(); }).filter(function (o) { return /^[+\\-=]$/.test(o); });
      if (ops2.indexOf('=') < 0) continue;
      for (var j = i + 1; j <= i + 3 && j < lines.length; j++) {
        var v2 = eqFigures(lines[j]);
        if (v2.length < ops2.length + 1) continue;
        var g2 = eqSolve(v2.slice(0, ops2.length + 1), ops2); if (g2) return g2;
        break;
      }
    }
    return null;
  }
  function cardSummaryOf(text) {
    var lines = String(text || '').split('\\n'), got = {};
    var eq = cardEquation(lines);
    if (eq) return eq;"""
if s.count(old) != 1: sys.exit('anchor %d' % s.count(old))
s = s.replace(old, new)
open(p, 'w', encoding='utf-8').write(s)
print('cardsum-3nov applied')

# NOTE: cardsum-3nov-b (rupee glyph "C", "_" minus, a line opening with its operator, the no-operator 4–6 figure row)
# was applied in place on 3–4 Nov; engine.js carries the marker "cardsum-3nov-b". Re-derive from engine.js if needed.
