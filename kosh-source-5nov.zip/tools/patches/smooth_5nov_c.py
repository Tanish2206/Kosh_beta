#!/usr/bin/env python3
# smooth-5nov-c: motion blur on the day strip (Kosh/MotionBlur.metal), builds never land mid-scroll, frame meter.
# Idempotent; re-run after a full source drop (after smooth_5nov.py and _b). Needs MotionBlur.metal + LedgerGlide.swift.
import os, sys, shutil
R = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."); K = os.path.join(R, "Kosh"); H = os.path.join(R, "_handoff")
def patch(name, pairs, mark):
    path = os.path.join(K, name); s = open(path, encoding="utf-8").read()
    if mark in s: print(name, "already patched"); return
    m0 = os.path.getmtime(path)
    for old, new in pairs:
        n = s.count(old)
        if n != 1: sys.exit(f"{name}: expected 1 match, found {n}: {old[:90]!r}")
        s = s.replace(old, new)
    b = os.path.join(H, name + ".before-smooth5novc")
    if not os.path.exists(b): shutil.copy2(path, b)
    if os.path.getmtime(path) != m0: sys.exit(name + " changed while patching; run again")
    open(path, "w", encoding="utf-8").write(s); print(name, "patched")

patch("DayLens.swift", [
("""    let mood: LensMood
    let budget: Double

    var body: some View {
        let n: Int = days.count
        // oldest on the left, so the day `pos` from the newest sits at column n-1-pos
        let pos: Double = live ? drag.pos : (fixed ?? tracker.pos)
        let whole: Bool = (live || fixed != nil) && pos == pos.rounded()
        let col: CGFloat = CGFloat(Double(n - 1) - pos)
        let cw: CGFloat = DayLens.cell
        let calm: Bool = still
        GeometryReader { g in
""",
"""    let mood: LensMood
    let budget: Double
    /// (smooth-5nov-c) how fast the strip moves, for its motion blur: a box, so measuring it redraws nothing
    @State private var speed = StripSpeed()

    var body: some View {
        // while it moves (a finger on it, or following the list) it's drawn every frame, so the streak fades the moment
        // it slows or rests; at rest the timeline is paused and the strip draws only when something changes
        TimelineView(.animation(minimumInterval: nil, paused: still || !(live || fixed == nil))) { _ in strip }
    }

    var strip: some View {
        let n: Int = days.count
        // oldest on the left, so the day `pos` from the newest sits at column n-1-pos
        let pos: Double = live ? drag.pos : (fixed ?? tracker.pos)
        let whole: Bool = (live || fixed != nil) && pos == pos.rounded()
        let col: CGFloat = CGFloat(Double(n - 1) - pos)
        let cw: CGFloat = DayLens.cell
        let calm: Bool = still
        // the streak's length in points: none at rest, settling, or with Reduce Motion on
        let streak: CGFloat = speed.measure(pos, CACurrentMediaTime(), rest: whole || calm || (!live && fixed != nil))
        return GeometryReader { g in
"""),
("""            .frame(width: g.size.width, height: DayLens.stripH, alignment: .leading)
            .coordinateSpace(.named("lens.strip"))
""",
"""            .frame(width: g.size.width, height: DayLens.stripH, alignment: .leading)
            .coordinateSpace(.named("lens.strip"))
            // the days streak sideways as they rush past, and sharpen as they slow (Metal, this strip alone)
            .layerEffect(ShaderLibrary.kMotionBlur(.float(streak)), maxSampleOffset: CGSize(width: 8, height: 0), isEnabled: streak > 0)
"""),
("""/// where a finger has the strip, in days from the newest; observed by the strip alone
""",
"""/// (smooth-5nov-c) the strip's speed, smoothed over a few frames, as a motion-blur length
final class StripSpeed {
    private var p: Double = .nan
    private var t: CFTimeInterval = 0
    private var v: Double = 0
    func measure(_ pos: Double, _ now: CFTimeInterval, rest: Bool) -> CGFloat {
        defer { p = pos; t = now }
        if rest || p.isNaN { v = 0; return 0 }
        let dt: Double = now - t
        if dt <= 0.0005 { return blur }
        if dt > 0.1 { v = 0; return 0 }
        let inst: Double = (pos - p) / dt
        v += (inst - v) * min(1, dt / 0.03)
        return blur
    }
    /// days a second → points: about a frame and a half of travel, never more than 14 pt, nothing under 0.6
    private var blur: CGFloat {
        let x: Double = min(14, abs(v) * Double(DayLens.cell) * 0.012)
        return x < 0.6 ? 0 : CGFloat(x)
    }
}

/// where a finger has the strip, in days from the newest; observed by the strip alone
"""),
], "(smooth-5nov-c)")

patch("LedgerView.swift", [
("""                let moving: Bool = phase.isScrolling
                if moving != lens.scrolling { lens.scrolling = moving }
""",
"""                let moving: Bool = phase.isScrolling
                if moving != lens.scrolling { lens.scrolling = moving }
                // (smooth-5nov-c) every frame of the scroll timed, into the diagnostics
                FrameMeter.shared.run(moving, "ledger scroll")
"""),
], "(smooth-5nov-c)")

patch("LedgerGlide.swift", [
("""        link = l
        last = 0
        tracker?.gliding = true
""",
"""        link = l
        last = 0
        tracker?.gliding = true
        FrameMeter.shared.run(true, "lens glide")   // (smooth-5nov-c)
"""),
("""        link = nil
        tracker?.gliding = false
""",
"""        link = nil
        tracker?.gliding = false
        FrameMeter.shared.run(false, "lens glide")
"""),
], "FrameMeter.shared.run(true, \"lens glide\")")

patch("Interaction.swift", [
("""    /// watch every window kosh has: one recognizer each that sees every touch and takes none
""",
"""    /// (smooth-5nov-c) run on the main thread once nobody is using the screen, waiting at most `upTo` seconds: a build
    /// landing swaps every screen's data, and under a moving finger (or a flick still coasting) that re-laid out the
    /// list mid-scroll
    static func whenStill(upTo: Double, _ work: @escaping @MainActor () -> Void) {
        let until: CFAbsoluteTime = CFAbsoluteTimeGetCurrent() + upTo
        func check() {
            if shared.busy && CFAbsoluteTimeGetCurrent() < until {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) { check() }
            } else {
                MainActor.assumeIsolated { work() }
            }
        }
        DispatchQueue.main.async { check() }
    }

    /// watch every window kosh has: one recognizer each that sees every touch and takes none
"""),
], "(smooth-5nov-c)")

patch("LiveSession.swift", [
("""            DispatchQueue.main.async {
                self.buildRunning = false
""",
"""            // (smooth-5nov-c) the build lands between touches, never under a moving finger (4 s at most)
            Interaction.whenStill(upTo: 4) {
                self.buildRunning = false
"""),
], "(smooth-5nov-c)")

# the blur stays off until the Mac's Xcode has the Metal Toolchain (MotionBlur.metal kept in tools/patches/files/)
patch("DayLens.swift", [
("TimelineView(.animation(minimumInterval: nil, paused: still || !(live || fixed == nil))) { _ in strip }",
 "TimelineView(.animation(minimumInterval: nil, paused: !LensBlur.on || still || !(live || fixed == nil))) { _ in strip }"),
("isEnabled: streak > 0)", "isEnabled: LensBlur.on && streak > 0)"),
("/// (smooth-5nov-c) the strip's speed, smoothed over a few frames, as a motion-blur length\n",
 "/// (smooth-5nov-c) the strip's motion blur needs Kosh/MotionBlur.metal, which needs Xcode's Metal Toolchain on the\n/// Mac that builds (xcodebuild -downloadComponent MetalToolchain). Until then it's off: copy\n/// tools/patches/files/MotionBlur.metal into Kosh/ and set this true\nenum LensBlur { static let on: Bool = false }\n\n/// (smooth-5nov-c) the strip's speed, smoothed over a few frames, as a motion-blur length\n"),
], "enum LensBlur")
