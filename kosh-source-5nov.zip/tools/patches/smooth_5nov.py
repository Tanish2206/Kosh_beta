#!/usr/bin/env python3
# smooth-5nov: Transactions › All scrolls without stutter. Idempotent; re-run after a full source drop.
# (1) the tab bar's slimming no longer changes every page's bottom safe-area inset mid-scroll (fixed room, visual-only slim)
# (2) the day lens follows the 2-4 day headings, not every payment row, worked out in the same frame (no run-loop hop)
# (3) a payment's name is a plain Text unless Find has words to light
import os, sys, shutil, time
K = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "Kosh")
H = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "_handoff")

def patch(name, pairs, mark):
    p = os.path.join(K, name)
    s = open(p, encoding="utf-8").read()
    if mark in s:
        print(name, "already patched"); return
    m0 = os.path.getmtime(p)
    for old, new in pairs:
        n = s.count(old)
        if n != 1: sys.exit(f"{name}: expected 1 match, found {n}: {old[:90]!r}")
        s = s.replace(old, new)
    b = os.path.join(H, name + ".before-smooth5nov")
    if not os.path.exists(b): shutil.copy2(p, b)
    if os.path.getmtime(p) != m0: sys.exit(name + " changed while patching; run again")
    open(p, "w", encoding="utf-8").write(s)
    print(name, "patched")

# ---------- (1) TabBar.swift
patch("TabBar.swift", [(
"""                        if store.tab != .chapters && store.readingShown && !barAway {
                            MonthPulse()
                                .frame(height: 44)
                                .glassEffect(.regular.interactive(), in: .capsule)
                                .transition(.blurReplace)
                        }
                        GlassTabBar(slim: barAway) { bar(away: false) }
""",
"""                        // (smooth-5nov) while the bar is slim the pulse fades and drifts down but keeps its room, and the
                        // slim bar sits in the full bar's room: this inset is every page's bottom safe area, and changing it
                        // mid-scroll (bar 56 → 46, pulse ±52) re-laid out the whole page on every frame of the animation
                        if store.tab != .chapters && store.readingShown {
                            MonthPulse()
                                .frame(height: 44)
                                .glassEffect(.regular.interactive(), in: .capsule)
                                .opacity(barAway ? 0 : 1)
                                .offset(y: barAway ? 10 : 0)
                                .allowsHitTesting(!barAway)
                                .transition(.blurReplace)
                        }
                        GlassTabBar(slim: barAway) { bar(away: false) }
                            .frame(height: 56, alignment: .bottom)
""")], "(smooth-5nov)")

# ---------- (2a) LedgerView.swift: headings report, rows don't
patch("LedgerView.swift", [(
"""                    // tells the day lens where this payment is on screen (no view update, just two numbers)
                    .onGeometryChange(for: CGRect.self) { p in p.frame(in: .global) } action: { r in
                        lens.row(t.id, day: g.day, i: g.items.firstIndex(where: { $0.id == t.id }) ?? 0, minY: r.minY, maxY: r.maxY)
                    }
                    .onDisappear { lens.gone(t.id) }
""", ""), (
"""                    .id("lens." + g.day)
            }
        }
    }
""",
"""                    .id("lens." + g.day)
                    // (smooth-5nov) the day lens follows the day headings alone: two to four on screen, where every
                    // payment row used to report its frame on every scroll frame
                    .onGeometryChange(for: CGFloat.self) { p in p.frame(in: .global).minY } action: { y in lens.head(g.day, minY: y) }
                    .onDisappear { lens.headGone(g.day) }
            }
        }
    }
""")], "(smooth-5nov)")

# ---------- (2b) DayLens.swift: LensTracker
NEW_TRACKER = '''@Observable final class LensTracker {
    /// the day at the top of the list, as an index from the newest (0) — changes once per day
    var top: Int = 0
    /// the same, with how far through that day the list has scrolled (12.4) — changes every frame
    var pos: Double = 0
    var scrolling: Bool = false
    /// which way the list last moved: down (into older days) hides the tab bar, up brings it back
    var down: Bool = false

    /* (smooth-5nov) Only the day headings report where they are: two to four on screen, where every payment row used
       to (twenty-odd geometry callbacks a scroll frame, then a hop to the next run loop, so the strip drew a frame
       behind the list and every frame drew twice). The place is worked out on the spot from the headings either side
       of the top edge; inside a day taller than the screen it carries on from the scroll offset. */
    @ObservationIgnored private var index: [String: Int] = [:]
    @ObservationIgnored private var counts: [Int] = []
    /// the headings in view (or just outside it): day → global minY
    @ObservationIgnored private var heads: [Int: CGFloat] = [:]
    /// each day's height, heading to next heading, measured whenever both were in view
    @ObservationIgnored private var heights: [Int: CGFloat] = [:]
    /// the global y of the top of what's visible in the list (under the sub-tab row)
    @ObservationIgnored private var listTop: CGFloat = 0
    @ObservationIgnored private var inset: CGFloat = 0
    @ObservationIgnored private var lastY: CGFloat = 0
    @ObservationIgnored private var run: CGFloat = 0
    /// the last place a heading gave, and the scroll offset then, to carry on from inside a long day
    @ObservationIgnored private var anchor: (k: Int, f: CGFloat, y: CGFloat)? = nil

    func set(_ groups: [DayGroup]) {
        var ix: [String: Int] = [:]
        for (k, g) in groups.enumerated() { ix[g.day] = k }
        if ix != index {
            index = ix
            counts = groups.map { $0.items.count }
            heads = [:]; heights = [:]; anchor = nil
            recompute()
        }
    }

    func listFrame(top: CGFloat) {
        if abs(top - listTop) > 0.5 { listTop = top; recompute() }
    }
    func listInset(_ v: CGFloat) {
        if abs(v - inset) > 0.5 { inset = v; recompute() }
    }

    /// the list's scroll offset, every frame: the direction (it flips only past a few points), and the place when no
    /// heading is near enough to say
    func moved(_ y: CGFloat) {
        let dy: CGFloat = y - lastY
        lastY = y
        if heads.isEmpty { recompute() }
        if y < 40 { run = 0; if down { down = false }; return }
        if dy == 0 { return }
        if (dy > 0) != (run > 0) { run = 0 }
        run += dy
        if run > 24 { if !down { down = true } } else if run < -16 { if down { down = false } }
    }

    /// a day heading's place on screen (global minY)
    func head(_ day: String, minY: CGFloat) {
        guard let k = index[day] else { return }
        if let old = heads[k], abs(old - minY) < 0.25 { return }
        heads[k] = minY
        recompute()
    }
    func headGone(_ day: String) {
        guard let k = index[day] else { return }
        heads[k] = nil
    }

    /// a day's height: measured if it has been, else its rows at a typical height
    private func height(_ k: Int) -> CGFloat {
        if let h = heights[k] { return h }
        let n: Int = k >= 0 && k < counts.count ? counts[k] : 1
        return 44 + CGFloat(max(1, n)) * 64 + 14
    }

    private func recompute() {
        let last: Int = counts.count - 1
        guard last >= 0 else { return }
        let line: CGFloat = listTop + inset + 2
        // the lowest heading at or above the top edge (the day being read) and the highest one under it
        var above: (k: Int, y: CGFloat)? = nil
        var below: (k: Int, y: CGFloat)? = nil
        for (k, y) in heads {
            if y <= line {
                if above == nil || y > above!.y { above = (k, y) }
            } else if below == nil || y < below!.y {
                below = (k, y)
            }
        }
        var k: Int
        var f: CGFloat
        if let a = above {
            k = a.k
            if let b = below, b.k == a.k + 1 {
                let h: CGFloat = max(1, b.y - a.y)
                heights[a.k] = h
                f = (line - a.y) / h
            } else {
                f = (line - a.y) / height(a.k)
            }
        } else if let b = below {
            k = b.k - 1
            if k < 0 { k = 0; f = 0 } else { f = 1 - (b.y - line) / height(k) }
        } else if let an = anchor {
            // no heading near: a long day, carried on by the scroll offset
            k = an.k
            f = an.f + (lastY - an.y) / height(k)
            while f >= 1 && k < last { let over: CGFloat = (f - 1) * height(k); k += 1; f = over / height(k) }
            while f < 0 && k > 0 { let under: CGFloat = f * height(k); k -= 1; f = 1 + under / height(k) }
        } else {
            return
        }
        k = min(last, max(0, k))
        if above != nil || below != nil { anchor = (k, f, lastY) }
        let p: Double = Double(k) + Double(min(0.999, max(0, f)))
        if abs(p - pos) > 0.002 { pos = p }
        if k != top { top = k }
    }
}
'''
p = os.path.join(K, "DayLens.swift")
s = open(p, encoding="utf-8").read()
if "(smooth-5nov)" in s:
    print("DayLens.swift already patched")
else:
    a = s.index("@Observable final class LensTracker {")
    b = s.index("/// one day, worked out once per month rather than on every frame")
    old = s[a:b]
    assert "func row(_ id: String" in old, "LensTracker not as expected"
    s2 = s[:a] + NEW_TRACKER + "\n" + s[b:]
    s2 = s2.replace("// - each payment row reports where it is on screen (one CGFloat pair, no view update) into LensTracker;",
                    "// - each day heading reports where it is on screen (one CGFloat, no view update) into LensTracker (smooth-5nov);")
    m0 = os.path.getmtime(p)
    bk = os.path.join(H, "DayLens.swift.before-smooth5nov")
    if not os.path.exists(bk): shutil.copy2(p, bk)
    if os.path.getmtime(p) != m0: sys.exit("DayLens.swift changed while patching; run again")
    open(p, "w", encoding="utf-8").write(s2)
    print("DayLens.swift patched")

# ---------- (3) Style.swift: TxRow name
patch("Style.swift", [(
"""                        Text(mark.isEmpty ? AttributedString(t.m) : TxMark.lit(t.m, mark))
""",
"""                        // (smooth-5nov) a plain Text unless Find has words to light: no AttributedString per row
                        (mark.isEmpty ? Text(t.m) : Text(TxMark.lit(t.m, mark)))
""")], "(smooth-5nov) a plain Text")
