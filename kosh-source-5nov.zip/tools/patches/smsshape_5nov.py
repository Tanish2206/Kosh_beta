#!/usr/bin/env python3
"""smsshape-5nov (kosh ios app chat): a bank's SMS that kosh drops leaves its SHAPE in the drop log, never its words:
a fixed list of markers (a sum, an account's digits, a card's, a balance, which money words from kosh's own list:
credited, debited, due, failed...). Kosh's promise "keeps no words of a message it drops" holds: only kosh's own
vocabulary is written. Lets a dropped credit be seen and its bank's wording fixed. Only for a business sender ID.
Idempotent."""
import sys
def patch(p, pairs, marker):
    s = open(p, encoding='utf-8').read()
    if marker in s: print(p, 'already'); return
    for a, b in pairs:
        if s.count(a) != 1: sys.exit('%s anchor %d: %r' % (p, s.count(a), a[:60]))
        s = s.replace(a, b)
    open(p, 'w', encoding='utf-8').write(s); print(p, 'patched')
patch('Kosh/engine.js', [
 ("    csvDocJSON: function (text) { return JSON.stringify(tableDoc(csvRows(text))); },",
  """    csvDocJSON: function (text) { return JSON.stringify(tableDoc(csvRows(text))); },
    // (smsshape-5nov) a dropped SMS's shape: kosh's own words only, never the message's
    smsShapeJSON: function (text) {
      var t = String(text || '').toLowerCase(), out = [];
      if (/(?:rs\\.?|inr|\\u20b9)\\s*[\\d,]+/.test(t)) out.push('sum');
      if (/(?:a\\/c|acct|account|ac)\\s*(?:no\\.?)?\\s*[x*\\u2022.]*\\d{3,}/.test(t)) out.push('acct');
      if (/card/.test(t)) out.push('card');
      if (/\\bbal(?:ance)?\\b|avl|avail/.test(t)) out.push('bal');
      if (/limit|lmt/.test(t)) out.push('limit');
      ['credited', 'credit', 'deposited', 'received', 'debited', 'debit', 'sent', 'spent', 'withdrawn', 'paid', 'transferred', 'refund', 'reversed',
       'due', 'reminder', 'overdue', 'failed', 'declined', 'request', 'collect', 'mandate', 'autopay', 'blocked', 'hold', 'lien', 'emi', 'loan', 'offer',
       'upi', 'neft', 'imps', 'rtgs', 'nach', 'ach', 'cheque', 'atm', 'interest', 'salary', 'fd', 'deposit', 'statement', 'otp']
        .forEach(function (w) { if (new RegExp('\\\\b' + w + '\\\\b').test(t)) out.push(w); });
      return JSON.stringify(out.join(' '));
    },"""),
], 'smsshape-5nov')
patch('Kosh/Alerts.swift', [
 ("""                if isNew { AlertIntake.noteDrop(r.rule ?? "not-payment", from: m.from, notification: m.chan == "notif") }
            } else {""",
  """                // (smsshape-5nov) a business sender's dropped SMS: its shape in kosh's own words, never its words
                var why: String = r.rule ?? "not-payment"
                if m.chan != "notif", AlertIntake.whoOf(m.from, notification: false) == m.from,
                   let out = try? Engine.shared.call("smsShapeJSON", [m.text]), let shape = try? JSONText.decode(String.self, out), !shape.isEmpty {
                    why += " [" + shape + "]"
                }
                if isNew { AlertIntake.noteDrop(why, from: m.from, notification: m.chan == "notif") }
            } else {"""),
], 'smsshape-5nov')
patch('Kosh/Alerts.swift', [('        let w = why.replacingOccurrences(of: "sms-", with: "").replacingOccurrences(of: "notif-", with: "")\n        switch w {', '        // (smsshape-5nov-b) the shape kept beside a reason isn\'t part of it\n        let w0: String = why.components(separatedBy: " [").first ?? why\n        let w = w0.replacingOccurrences(of: "sms-", with: "").replacingOccurrences(of: "notif-", with: "")\n        switch w {')], 'smsshape-5nov-b')
