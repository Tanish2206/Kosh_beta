#!/usr/bin/env python3
# smooth-5nov-b: the ledger glides with the day strip, frame for frame (Kosh/LedgerGlide.swift); 120 Hz animations.
# Idempotent; re-run after a full source drop (after smooth_5nov.py). Needs Kosh/LedgerGlide.swift.
import os, sys, shutil
R = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..")
K = os.path.join(R, "Kosh"); H = os.path.join(R, "_handoff")
def patch(path, pairs, mark):
    s = open(path, encoding="utf-8").read()
    if mark in s: print(os.path.basename(path), "already patched"); return
    m0 = os.path.getmtime(path)
    for old, new in pairs:
        n = s.count(old)
        if n != 1: sys.exit(f"{os.path.basename(path)}: expected 1 match, found {n}: {old[:90]!r}")
        s = s.replace(old, new)
    b = os.path.join(H, os.path.basename(path) + ".before-smooth5novb")
    if not os.path.exists(b): shutil.copy2(path, b)
    if os.path.getmtime(path) != m0: sys.exit(path + " changed while patching; run again")
    open(path, "w", encoding="utf-8").write(s); print(os.path.basename(path), "patched")

patch(os.path.join(K, "DayLens.swift"), [
("""    /// the last place a heading gave, and the scroll offset then, to carry on from inside a long day
    @ObservationIgnored private var anchor: (k: Int, f: CGFloat, y: CGFloat)? = nil
""",
"""    /// the last place a heading gave, and the scroll offset then, to carry on from inside a long day
    @ObservationIgnored private var anchor: (k: Int, f: CGFloat, y: CGFloat)? = nil
    /// (smooth-5nov-b) the glide that moves the list with the strip (LedgerGlide.swift), set by the ledger
    @ObservationIgnored weak var glide: LedgerGlide?
    /// the glide has the list's scroll now (set by LedgerGlide)
    @ObservationIgnored var gliding: Bool = false
    var dayCount: Int { counts.count }
    func rows(_ k: Int) -> Int { k >= 0 && k < counts.count ? counts[k] : 0 }
    func dayIndex(_ day: String) -> Int? { index[day] }
    func headGlobal(_ k: Int) -> CGFloat? { heads[k] }
"""),
("""        if heads.isEmpty { recompute() }
        if y < 40 { run = 0; if down { down = false }; return }
""",
"""        if heads.isEmpty { recompute() }
        // the strip moving the list isn't the person scrolling: the way it went says nothing about the tab bar
        if gliding { run = 0; return }
        if y < 40 { run = 0; if down { down = false }; return }
"""),
("""                    start = scrubbing ? drag.pos : (stripFixed ?? tracker.pos)
                    picked = Int(start.rounded())
                    reveal()
                }
""",
"""                    start = scrubbing ? drag.pos : (stripFixed ?? tracker.pos)
                    picked = Int(start.rounded())
                    reveal()
                    // caught again while coasting: the list goes on following the finger
                    if scrubbing { tracker.glide?.hold(drag) }
                }
"""),
("""                if !scrubbing { drag.pos = start; scrubbing = true }
""",
"""                // (smooth-5nov-b) the list behind follows the strip frame for frame (LedgerGlide), not a day at a time
                if !scrubbing { drag.pos = start; scrubbing = true; tracker.glide?.hold(drag) }
"""),
("""                    // the list stays put while your finger is on the strip and moves once, when you let go: a jump per
                    // day made the whole list lay out under the finger, and the strip stuttered
""",
"""                    // (the list moves with the strip through LedgerGlide; a scrollTo per day made it lay out under the
                    // finger and stutter, so no jump here)
"""),
("""            .onEnded { v in
                touching = false
""",
"""            .onEnded { v in
                touching = false
                tracker.glide?.release()
"""),
], "(smooth-5nov-b)")

patch(os.path.join(K, "LedgerView.swift"), [
("""    @State private var lens = LensTracker()
""",
"""    @State private var lens = LensTracker()
    /// (smooth-5nov-b) moves the list with the day strip, frame for frame
    @State private var glide = LedgerGlide()
"""),
("""                    DayLens(groups: groups, tracker: lens) { day in proxy.scrollTo("lens." + day, anchor: .top) }
""",
"""                    DayLens(groups: groups, tracker: lens) { day in
                        // glides there; jumps only when the list can't be moved directly
                        if !glide.go(day) { proxy.scrollTo("lens." + day, anchor: .top) }
                    }
"""),
("""            .onGeometryChange(for: CGFloat.self) { g in g.frame(in: .global).minY } action: { y in lens.listFrame(top: y) }
""",
"""            .onGeometryChange(for: CGFloat.self) { g in g.frame(in: .global).minY } action: { y in lens.listFrame(top: y) }
            .onAppear { glide.tracker = lens; lens.glide = glide }
            .onDisappear { glide.stop() }
"""),
("""            MonthChips(selection: chips)
                .listRowInsets(EdgeInsets())
""",
"""            MonthChips(selection: chips)
                // (finds the List's scroll view for the glide; draws nothing)
                .background(GlideHook(glide: glide))
                .listRowInsets(EdgeInsets())
"""),
], "(smooth-5nov-b)")

patch(os.path.join(K, "TabBar.swift"), [
("""        if new == track.last { return }
        track.last = new
""",
"""        if new == track.last { return }
        track.last = new
        // (smooth-5nov-b) while the day lens is up the bar is stepped away: the list moving under it changes nothing
        if LensVeil.shared.up { track.run = 0; return }
"""),
], "(smooth-5nov-b)")

patch(os.path.join(R, "KoshInfo.plist"), [
("""	<key>NSSupportsLiveActivitiesFrequentUpdates</key>
	<true/>
</dict>""",
"""	<key>NSSupportsLiveActivitiesFrequentUpdates</key>
	<true/>
	<!-- (smooth-5nov-b) ProMotion: kosh's own animations (the day lens, the tab bar, sheets) and the ledger's glide run
	     at up to 120 Hz, as scrolling does. Without this key an iPhone holds them to 60 while the list scrolls at 120 -->
	<key>CADisableMinimumFrameDurationOnPhone</key>
	<true/>
</dict>"""),
], "(smooth-5nov-b)")
