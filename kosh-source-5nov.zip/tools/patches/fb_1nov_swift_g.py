# kosh feedback 1 Nov (20:12) — Swift, part G: Wealth › Net worth: whose money is a dropdown on the title's line (right),
# not a row of segments under it. Idempotent.
def patch(F, pairs):
    p = 'Kosh/' + F; s = open(p).read()
    for a, b, mark in pairs:
        if mark in s: continue
        assert s.count(a) == 1, (F, a[:90], s.count(a)); s = s.replace(a, b)
    open(p, 'w').write(s)
_k = 'Kosh/WealthKit.swift'; _t = open(_k).read()
if 'let sw: WhoseSwitch = WhoseSwitch()' in _t:
    a = _t.index('/// whose money, as a dropdown for a title')
    b = _t.index('/// a section\'s head: its title, and something quiet or a way on at the right')
    open(_k, 'w').write(_t[:a] + _t[b:])
patch('WealthKit.swift', [("""/// a section's head: its title, and something quiet or a way on at the right""", """/// whose money, as a dropdown for a title's line: "All ⌄" in a dark capsule; its menu lists each person and everyone,
/// the one on show ticked (1 Nov: the row of segments under the title took a line of its own)
struct WhoseMenu: View {
    @Environment(Store.self) private var store
    var body: some View {
        if store.whoOptions.count > 2 {
            // (worked out here, from this view's own store: a WhoseSwitch made inside a body has no environment, and
            // reading its store there stops the app — 1 Nov, the Wealth tab)
            let items: [(id: String, label: String)] = Self.items(store)
            let now: String = items.first { $0.id == store.who.id }?.label ?? "All"
            let s: Store = store
            let pick: Binding<String> = Binding<String>(get: { s.who.id }, set: { (id: String) in s.who = s.personFor(id) })
            Menu {
                Picker("Whose money", selection: pick) {
                    ForEach(items, id: \\.id) { it in Text(it.label).tag(it.id) }
                }
            } label: {
                HStack(spacing: 6) {
                    Image(systemName: store.who == .family ? "person.2.fill" : "person.fill").font(.system(size: 11, weight: .semibold))
                    Text(now).font(.system(size: 14, weight: .semibold)).lineLimit(1)
                    Image(systemName: "chevron.down").font(.system(size: 10, weight: .bold))
                }
                .foregroundStyle(Obsidian.ink)
                .padding(.horizontal, 13).frame(minHeight: 34)
                .background(Color.white.opacity(0.08), in: Capsule())
                .overlay(Capsule().strokeBorder(Color.white.opacity(0.10), lineWidth: 1))
                .contentShape(Capsule())
            }
            .accessibilityLabel("Whose money")
            .accessibilityValue(now)
            .sensoryFeedback(.selection, trigger: store.who.id)
        }
    }
    static func items(_ store: Store) -> [(id: String, label: String)] {
        let people: [Person] = store.whoOptions.filter { $0 != .family }
        let firsts: [String] = people.map { (p: Person) -> String in WhoseSwitch.first(p.title) }
        var out: [(id: String, label: String)] = []
        for (i, p) in people.enumerated() {
            let shared: Bool = firsts.filter { $0 == firsts[i] }.count > 1
            out.append((id: p.id, label: shared ? p.title : firsts[i]))
        }
        out.append((id: Person.family.id, label: people.count == 2 ? "Both" : "All"))
        return out
    }
}

/// a section's head: its title, and something quiet or a way on at the right""", "struct WhoseMenu: View")])
patch('WealthHome.swift', [("""            Text("Net worth")
                .font(.system(size: 30, weight: .semibold))
                .tracking(-0.7)
                .foregroundStyle(Obsidian.ink)
                .accessibilityAddTraits(.isHeader)
            // whose money, on its own line under the title so every name fits (it scrolls past four or five)
            WhoseSwitch()
                .padding(.top, 12)
            Text("Today · " + Day.fmt(store.snap.today, "d MMM yyyy"))
                .caption()
                .padding(.top, 14)""", """            // whose money, a dropdown on the title's line (1 Nov: the segments under it took a line of their own)
            HStack(alignment: .center, spacing: 12) {
                Text("Net worth")
                    .font(.system(size: 30, weight: .semibold))
                    .tracking(-0.7)
                    .foregroundStyle(Obsidian.ink)
                    .accessibilityAddTraits(.isHeader)
                Spacer(minLength: 8)
                WhoseMenu()
            }
            Text("Today · " + Day.fmt(store.snap.today, "d MMM yyyy"))
                .caption()
                .padding(.top, 12)""", "WhoseMenu()\n            }")])
print('swift G patched')
