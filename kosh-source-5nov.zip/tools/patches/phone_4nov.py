#!/usr/bin/env python3
"""phone-4nov (statements chat, 4 Nov) - applied in place, tagged in the source. Notes:
 The Mac bench read statements from pdftotext -layout; the phone reads two texts (rows rebuilt from where letters sit,
 and PDFKit's own) with the grid. tools/eval/pdfgrid.py + mkgrids.py make the phone's grid on the Mac, and
 stmt-bench.js --phone reads as the phone does (both texts + grid, best kept): 114 of 158 add up
 (_corpus/stmts/bench-phone-ratchet.json).
 engine.js gridopen-4nov: a statement read by its columns takes the opening balance printed by its label when the
   columns took another figure on that line (HDFC: 48 lines, closes Rs 2,37,179.83; the phone had kept 1 line).
 engine.js custid-4nov: a Customer ID / CIF / CRN / UCIC is never an account number (stmtLast4, and the account
   registry drops a bank's customer-number tail: HDFC Customer ID 47172882 is no account 2882).
 engine.js dcard-4nov: a debit card goes with its bank's account (the one in use, of its holder); never its own row.
 engine.js: paperBrokerFunds (papers-4nov's brokerFunds shadowed the mail reader's brokerFunds — fixed).
 Swift: Snapshot.swift Account.debitGuess; AccountPage.swift AccountCards (debit cards + same bank's credit cards);
 LiveSession+Statements.swift statementReader = 9."""
