# kosh feedback 1 Nov — engine.js part. Idempotent: run from the project folder: python3 tools/patches/fb_1nov_engine.py
import sys
F = 'Kosh/engine.js'
s = open(F).read()
def sub(a, b, mark):
    global s
    if mark in s: return
    assert s.count(a) == 1, ('engine anchor', a[:90], s.count(a))
    s = s.replace(a, b)

# 1. card names: Kotak Air+, HSBC's
sub("""[/tata neu/i, 'Tata Neu', 'hdfc'],
  ];""", """[/tata neu/i, 'Tata Neu', 'hdfc'],
    [/\\bair ?\\+ (?:visa )?credit card|\\bkotak air ?\\+|\\bair plus credit card/i, 'Air+', 'kotak'],
    [/\\bhsbc live ?\\+|\\blive ?\\+ credit card|\\bhsbc live plus\\b/i, 'Live+', 'hsbc'], [/\\bhsbc (?:visa )?platinum\\b/i, 'Platinum', 'hsbc'], [/\\btravel ?one\\b/i, 'TravelOne', 'hsbc'],
    [/\\bhsbc premier (?:mastercard |world elite )?credit card\\b/i, 'Premier', 'hsbc'], [/\\bhsbc rupay cashback\\b/i, 'RuPay Cashback', 'hsbc'],
  ];""", "'Air+', 'kotak'")

# 2. a statement PDF carries the card's name its own mail's subject printed
sub("""    // a statement PDF the phone read: its bank is its sender's when the reading names none
    (extra || []).forEach(function (S) {
      if (S.instr !== 'card') return;
      var ins = S.inst ? null : institution(S.from || ''), inst = S.inst || (ins ? ins.short : '');
      if (inst) add(inst, S.last4, { date: S.periodTo || S.sent || '', sent: S.sent || '', kind: 'doc', credit: +S.credit || 0, limit: +S.limit || 0, avail: S.avail >= 0 ? +S.avail : null }, 'statement');
    });""", """    // a statement PDF the phone read: its bank is its sender's when the reading names none. The card's own name rides
    // with it from its mail, the same mail: the subject names the card ("Your HDFC Bank - Diners Black Credit Card
    // Statement", "(HSBC LIVE+ CREDIT CARD)") and the PDF prints its digits, so the two together say which card is which
    // (1 Nov: ••4545 showed as "HDFC Bank" beside a year of Diners Black statements)
    var mailById = {};
    recs.forEach(function (r) { if (r && r.id) mailById[r.id] = r; });
    (extra || []).forEach(function (S) {
      if (S.instr !== 'card') return;
      var ins = S.inst ? null : institution(S.from || ''), inst = S.inst || (ins ? ins.short : '');
      var m = mailById[String(S.src || '').split('#')[0]] || null;
      var cn = m && m.cardName ? m.cardName : '';
      if (cn) { var whose = productIssuers(cn), mine = issuerIdOf(inst); if (whose && whose.length && mine && whose.indexOf(mine) < 0) cn = ''; }
      if (inst) add(inst, S.last4, { date: S.periodTo || S.sent || '', sent: S.sent || '', kind: 'doc', credit: +S.credit || 0, limit: +S.limit || 0, avail: S.avail >= 0 ? +S.avail : null, cardName: cn || undefined, id: m ? m.id : undefined }, 'statement');
    });""", "var mailById = {};\n    recs.forEach")
sub("""          if (byAmt.length === 1) hits = byAmt;
        }
        if (hits.length === 1) cards[hits[0]].push(e);""", """          if (byAmt.length === 1) hits = byAmt;
        }
        // the same statement, its PDF read on the phone: the mail without digits goes with the card its own PDF named
        if (hits.length > 1 && e.r.id) {
          var bySame = hits.filter(function (k) { return cards[k].some(function (x) { return x.r.kind === 'doc' && x.r.id === e.r.id; }); });
          if (bySame.length === 1) hits = bySame;
        }
        if (hits.length === 1) cards[hits[0]].push(e);""", "var bySame = hits.filter")

# 3. people on a policy: a label read as a name is no one
sub("""  function textOf(m) { return m ? trim(m[1]).replace(/[.,;]+$/, '').slice(0, 60) : ''; }""", """  function textOf(m) { return m ? trim(m[1]).replace(/[.,;]+$/, '').slice(0, 60) : ''; }
  /* GUARDRAIL a person's name on a policy (its holder, the life assured, the nominee) is a name, never the form around
     it. A schedule's table prints its labels beside the cells ("Nominee(s) (If Life Assured is a minor) Name of the
     Appointee(s)"), and a reading that took the next words took a label: 1 Nov, his Tata AIA page showed the nominee
     as "is a minor) Name of the Appoint e (s) R" and "Held by" as "(If Life As". A name is one to five words of
     letters (initials and a dot allowed), with none of a form's words in it; anything else is nothing, and the page
     asks rather than show a label. "MRIDUL BHUTANI" reads "Mridul Bhutani" */
  var PERSON_JUNK = /[()\\[\\]{}:;|\\/\\\\@#%*=<>_0-9₹,?!"“”]|\\b(?:if|is|are|of|the|to|or|and|only|name|names|minor|appoint\\w*|nominee\\w*|guardian|assured|life|insured|proposer|policy\\w*|holder|relation\\w*|age|date|birth|dob|gender|male|female|share|percent\\w*|address|details?|applicable|na|nil|none|same|above|below|self|spouse|father|mother|son|daughter|wife|husband|brother|sister|plan|premium|sum|cover|benefit|amount|rs|inr|bank|account|customer|member|person|signature|place|declaration|not)\\b/i;
  /* the nominee as a schedule's table prints it: a "Nominee(s)" heading, a row of column names (Name, Relationship,
     Share, the appointee's), then the row of values. The first cell of the next rows that is a name (nameOnPolicy) */
  function nomineeFromTable(t) {
    var lines = String(t || '').split('\\n');
    for (var i = 0; i < lines.length; i++) {
      if (!/\\bnominee/i.test(lines[i])) continue;
      for (var j = i; j < Math.min(lines.length, i + 4); j++) {
        if (!/\\brelation/i.test(lines[j])) continue;
        for (var k = j + 1; k < Math.min(lines.length, j + 4); k++) {
          var cells = lines[k].split(/\\t|\\s{2,}|\\|/).map(function (x) { return x.trim(); }).filter(Boolean);
          for (var c = 0; c < cells.length; c++) { var nm = nameOnPolicy(cells[c]); if (nm) return nm; }
        }
        break;
      }
    }
    return '';
  }
  function nameOnPolicy(v) {
    var s = String(v || '').replace(/\\s+/g, ' ').trim().replace(/^(?:mr|mrs|ms|miss|dr|shri|smt|sri|kumari|master)\\.?\\s+/i, '');
    // ("Sunil Bhutani (Mother)": the relation beside the name is the cell's, not the name's)
    s = s.replace(/\\s*\\((?:[A-Za-z ]{2,20})\\)\\s*$/, '');
    if (s.length < 3 || s.length > 50 || PERSON_JUNK.test(s)) return '';
    var w = s.split(' ');
    if (w.length > 5 || w.length < 1) return '';
    if (!w.every(function (x) { return /^[A-Za-z][A-Za-z.'\\-]*$/.test(x); })) return '';
    if (!w.some(function (x) { return x.replace(/[^A-Za-z]/g, '').length >= 3; })) return '';
    // a single word is a name only when it is a proper one ("Ritu"), never a lone word a cell cut off ("Appoint")
    if (w.length === 1 && !/^[A-Z][a-z]{2,}$|^[A-Z]{3,}$/.test(w[0])) return '';
    if (s === s.toUpperCase() || s === s.toLowerCase()) s = w.map(function (x) { return x.charAt(0).toUpperCase() + x.slice(1).toLowerCase(); }).join(' ');
    return s;
  }""", "function nameOnPolicy(v)")
sub("""    var holder = textOf(field(t, ['name of (?:the )?(?:policy ?holder|proposer)', 'policy ?holder(?:\\'s)?(?: name)?', 'proposer(?:\\'s)?(?: name)?'], V_TEXT));""",
    """    var holder = nameOnPolicy(textOf(field(t, ['name of (?:the )?(?:policy ?holder|proposer)', 'policy ?holder(?:\\'s)?(?: name)?', 'proposer(?:\\'s)?(?: name)?'], V_TEXT)));""", "var holder = nameOnPolicy(")
sub("""    var insured = textOf(field(t, ['name of (?:the )?life (?:to be )?assured', 'life assured(?: name)?', 'insured (?:person|member)?\\\\s*name', 'name of (?:the )?insured'], V_TEXT));
    var nominee = textOf(field(t, ['nominee(?:\\'s)?(?: name)?(?:\\\\(s\\\\))?', 'name of (?:the )?nominee'], V_TEXT));""",
    """    var insured = nameOnPolicy(textOf(field(t, ['name of (?:the )?life (?:to be )?assured', 'life assured(?: name)?', 'insured (?:person|member)?\\\\s*name', 'name of (?:the )?insured'], V_TEXT)));
    var nominee = nameOnPolicy(textOf(field(t, ['nominee(?:\\'s)?(?: name)?(?:\\\\(s\\\\))?', 'name of (?:the )?nominee'], V_TEXT))) || nomineeFromTable(t);""", "var insured = nameOnPolicy(")
sub("""policyNo: unmask(p.number), holder: p.holder || '', insured: p.insured || '',
        nominee: p.nominee || '',""", """policyNo: unmask(p.number), holder: nameOnPolicy(p.holder), insured: nameOnPolicy(p.insured),
        nominee: nameOnPolicy(p.nominee),""", "holder: nameOnPolicy(p.holder)")
sub("""        ['holder', 'insured', 'nominee', 'to'].forEach(function (k) { if (pe[k] && String(pe[k]).length > String(hit[k] || '').length) hit[k] = String(pe[k]); });""",
    """        ['holder', 'insured', 'nominee', 'to'].forEach(function (k) { var nm = nameOnPolicy(pe[k]); if (nm && (!nameOnPolicy(hit[k]) || nm.length > String(hit[k] || '').length)) hit[k] = nm; });""", "var nm = nameOnPolicy(pe[k])")
sub("""      var fill = (prof.policyFill || {})[q.key] || {}, filled = [];""", """      var fill = (prof.policyFill || {})[q.key] || {}, filled = [];
      // (a label read as a person is no one: the nominee is then asked for, as missing, rather than shown wrong)
      q.nominee = nameOnPolicy(q.nominee); q.holder = nameOnPolicy(q.holder);
      if (!(q.members && q.members.length >= 2)) q.insured = nameOnPolicy(q.insured);""", "q.nominee = nameOnPolicy(q.nominee)")
sub("""holder: q.holder || '', addressee: q.to || undefined, insured: (q.members && q.members.length >= 2 ? q.members.join(', ') : q.insured) || '', nominee: q.nominee || '',""",
    """holder: nameOnPolicy(q.holder), addressee: nameOnPolicy(q.to) || undefined, insured: (q.members && q.members.length >= 2 ? q.members.join(', ') : nameOnPolicy(q.insured)) || '', nominee: filled.indexOf('nominee') >= 0 ? q.nominee : nameOnPolicy(q.nominee),
        gross: q.gross > q.premium * 1.001 && q.gross <= q.premium * 1.25 ? Math.round(q.gross) : undefined,""", "gross: q.gross > q.premium")
# 4. what a receipt says left the account, tax and all
sub("""      if (!hit.policyNo && no) hit.policyNo = no;
      // (a paper's number cut short""", """      /* what a receipt says was paid: the premium with its GST ("received premium of ₹2,04,500" on a ₹2,00,000
         premium). The premium stays the plan's; the page shows what left the account beside it */
      var paidMail = pe ? /^(?:paid|renewed)$/.test(pe.action || '') : r.rule === 'policy-paid';
      if (paidMail && r.premium > 0 && (r.date || '') >= (hit.grossOn || '')) { hit.gross = r.premium; hit.grossOn = r.date || ''; }
      if (!hit.policyNo && no) hit.policyNo = no;
      // (a paper's number cut short""", "var paidMail = pe ?")
# 5. a receipt's PDF is a receipt, not the policy paper
sub("""      var have = {}, list = [];
      papers.sort(""", """      var have = {}, list = [], known = {};
      (p.mails || []).forEach(function (m) { known[m.id] = m.k; });
      // (what each paper is: its mail's own kind when the mail was read as a receipt or a notice, else its subject's)
      var paperKind = function (r) {
        var k = known[r.id] || '';
        if (k && !/^(?:mail|paper)/.test(k)) return k;
        var s = String(r.subject || '').toLowerCase();
        if (/receipt|acknowledg|premium (?:paid|received)|payment (?:received|confirmation)/.test(s)) return 'receipt';
        if (/renewal (?:notice|reminder)|premium (?:due|reminder)|due for/.test(s)) return 'notice';
        if (/statement|bonus/.test(s)) return 'statement';
        return 'paper';
      };
      papers.sort(""", "var paperKind = function (r)")
sub("""        list.push({ id: r.id, on: String(r.date || r.sent || '').slice(0, 10), k: r.doc.state === 'locked' ? 'paper-locked' : 'paper' });""",
    """        var pk = paperKind(r);
        list.push({ id: r.id, on: String(r.date || r.sent || '').slice(0, 10), k: r.doc.state === 'locked' ? (pk === 'paper' ? 'paper-locked' : pk) : pk, pdf: true });""", "var pk = paperKind(r);")

# 6. shopping: the order a payment was, and what was bought
sub("""        lr: !mineC && !!L.c,
        sym: symFor(c, s),""", """        lr: !mineC && !!L.c, uc: oc && !(mineC ? o.by === 'claude-guess' : L.by === 'claude-guess') ? true : undefined,
        sym: symFor(c, s),""", "uc: oc && !(mineC")
sub("""pf: t.pf || undefined, mr: t.mirror ? true : undefined, rc: t.rc || undefined }; }),""", """pf: t.pf || undefined, mr: t.mirror ? true : undefined, rc: t.rc || undefined, uc: t.uc || undefined }; }),""", "uc: t.uc || undefined }")
sub("""      var acctDebit = {};
      (snapOut.accounts || []).forEach(function (a) { (a.debit || []).forEach(function (d) { acctDebit[String(d).slice(-4)] = 1; }); });
""", """      /* every order a shop's mail told (Amazon's "Ordered: …", "Shipped: …"), by shop: its number, every total its
         mails printed, the day it was placed and what was in it. A payment that names no order (a card alert, "Rs 299
         was paid on Amazon.in") is that order when exactly one order of the same shop, for the same total, was placed
         within two days of it: how a ₹299 Amazon charge becomes "Black Replacement Side…" (1 Nov) */
      var ordersByShop = {}, orderTaken = {};
      (function () {
        var byNo = {};
        Object.keys(mailOrders).forEach(function (mid) {
          var r = recById[mid] || {};
          var day = String(r.date || r.sent || '').slice(0, 10);
          mailOrders[mid].forEach(function (e) {
            if (!e || !e.order || !e.shop || e.status === 'declined' || e.status === 'cancelled') return;
            var k = String(e.order).toUpperCase().replace(/[^A-Z0-9]/g, '');
            var O = byNo[k] || (byNo[k] = { no: k, shop: pfKey(e.shop), totals: [], day: day, items: [], mail: mid });
            if (+e.total > 0 && O.totals.indexOf(+e.total) < 0) O.totals.push(+e.total);
            if (day && day < O.day) O.day = day;
            var names = Array.isArray(e.lines) && e.lines.length ? e.lines.map(function (l) { return l && l.n; }) : (Array.isArray(e.items) ? e.items : []);
            // (else the item its mail's subject names: Ordered: "Black Replacement Side…")
            if (!names.length) { var sq = /^(?:ordered|shipped|out for delivery|delivered|arriving[^:]*)\\s*:\\s*(?:\\d+\\s*)?["“‘']([^"”’']{4,}?)(?:\\.{3}|…)?["”’']/i.exec(String(r.subject || '')); if (sq) names = [sq[1].trim()]; }
            names.forEach(function (n) { n = String(n || '').trim(); if (n && O.items.indexOf(n) < 0) { O.items.push(n); if (O.mail !== mid && O.items.length === 1) O.mail = mid; } });
          });
        });
        Object.keys(byNo).forEach(function (k) { var O = byNo[k]; if (O.totals.length && O.items.length) (ordersByShop[O.shop] = ordersByShop[O.shop] || []).push(O); });
      })();
      function orderFor(t, shopName) {
        var list = ordersByShop[pfKey(shopName)] || [];
        var d = pfN(t.d), tol = Math.max(1, t.a * 0.005);
        var hit = list.filter(function (O) { return !orderTaken[O.no] && O.totals.some(function (v) { return Math.abs(v - t.a) <= tol; }) && Math.abs(pfN(O.day) - d) <= 2; });
        return hit.length === 1 ? hit[0] : null;
      }
      var acctDebit = {};
      (snapOut.accounts || []).forEach(function (a) { (a.debit || []).forEach(function (d) { acctDebit[String(d).slice(-4)] = 1; }); });
""", "var ordersByShop = {}, orderTaken = {};")
sub("""        if (lines) { f.items = lines.map(function (x) { var o = { n: x.n }; if (x.q > 0) o.q = x.q; if (x.amt > 0) o.amt = x.amt; if (x.unit > 0) o.unit = x.unit; return o; }); if (linesMail !== t.id) src.items = linesMail; cover.items++; }""",
    """        if (lines) { f.items = lines.map(function (x) { var o = { n: x.n }; if (x.q > 0) o.q = x.q; if (x.amt > 0) o.amt = x.amt; if (x.unit > 0) o.unit = x.unit; return o; }); if (linesMail !== t.id) src.items = linesMail; cover.items++; }
        else if (!noShop) {
          // (no order named: the shop's one order of this total, placed within two days)
          var byTotal = orderFor(t, (b && b.s.name) || t.pf || t.m);
          if (byTotal) { orderTaken[byTotal.no] = 1; f.items = byTotal.items.slice(0, 12).map(function (n) { return { n: n }; }); src.items = byTotal.mail; cf.items = 'medium'; cover.items++; }
        }""", "var byTotal = orderFor(")
sub("""        if (Object.keys(cf).length) f.cf = cf;
        pay[t.id] = f;
      });
""", """        if (Object.keys(cf).length) f.cf = cf;
        pay[t.id] = f;
      });
      whatWasBought(snapOut.tx || [], pay);
""", "whatWasBought(snapOut.tx || [], pay);")
BUY = r"""    /* WHAT WAS BOUGHT (1 Nov, his Up close: "Clothing", "Fashion", "Marketplaces" and "Other shopping" all held the same
       Myntra, AJIO and Meesho buys; a watch band from Amazon sat under "Marketplaces"). Shopping's kind says WHAT a buy
       was, never HOW it was bought: Amazon, Flipkart and Meesho are where, not what. Each shopping payment gets one kind
       (t.wk; t.wkb says what said it), from the strongest evidence it has, in this order:
         1. what the order's mail says was in it (its items; a payment matched to its order by total and day), each item
            read by the words of its kind, the same product told again by its first words; most items' kind wins
         2. what you said it was (a sub-category you set, or taught kosh for its payee)
         3. the sub-category it carries when that is a kind (Clothing, Footwear…), never "Online"
         4. the shop: what a known shop sells (Myntra, AJIO, Uniqlo, Meesho → Clothing; Nykaa → Beauty; Croma → Electronics)
         5. the shop's other buys: the kind four in five of your other payments there were
       With none of these it has no kind, and the screens say "Not known yet": never guessed */
    var BUY_KINDS = [
      ['Subscriptions', /\b(?:prime (?:membership|video)|amazon prime|membership|subscription|yearly plan|annual plan)\b/i],
      ['Games & toys', /\b(?:ps[45]|playstation|xbox|nintendo|switch game|video ?games?|board ?games?|toys?|lego|puzzles?|action figures?|plush)\b|\bgames\b/i],
      ['Sports gear', /\b(?:resistance bands?|yoga mat|dumbbells?|kettlebells?|skipping rope|gym (?:gloves|bag)|cricket bat|football|badminton|racquet|racket|cycling|bicycle|protein|whey|shaker)\b/i],
      ['Accessories', /\b(?:straps?|watch ?bands?|band for|bands? (?:compatible|for)|watchbands?|cases?|covers?|screen (?:guard|protector)|tempered glass|wallets?|card holder|holders?|belts?|bags?|backpacks?|duffel|sling|sunglasses|spectacles|eyewear|caps?|hats?|keychains?|suspenders|ties?|cufflinks|mounts?|stands?|helmets?|replacement (?:parts?|side|pads?|tips?)|ear ?tips|umbrella)\b/i],
      ['Footwear', /\b(?:shoes?|sneakers?|sandals?|slippers?|sliders?|slides|flip ?flops?|heels|boots|loafers|moccasins|clogs|crocs|floaters|juttis?|kolhapuris?)\b/i],
      ['Clothing', /\b(?:t-?shirts?|tees?|shirts?|tops?|jeans|trousers|pants|chinos|shorts|joggers|track ?pants|kurtas?|kurtis?|sarees?|lehengas?|dupattas?|dress(?:es)?|skirts?|jackets?|hoodies?|sweatshirts?|sweaters?|cardigans?|blazers?|coats?|innerwear|briefs?|trunks?|boxers?|vests?|bras?|panties|socks|night ?suits?|pyjamas?|co-?ords?|polo|half zip|shapewear|leggings|ethnic wear|activewear|athleisure)\b/i],
      ['Beauty', /\b(?:mascara|lipsticks?|kajal|eyeliner|foundation|concealer|serum|moisturi[sz]er|sunscreen|perfume|fragrance|eau de|deodorant|deo|roll-?on|shampoo|conditioner|hair (?:oil|colou?r|mask|dye)|henna|indigo powder|face ?wash|cleanser|body ?wash|soap|lotion|trimmer|razor|shaving|beard|nail (?:paint|polish)|skincare|makeup)\b/i],
      ['Electronics', /\b(?:smartphones?|phones?|iphone|ipad|tablets?|laptops?|macbook|earbuds|airpods|headphones?|earphones?|neckband|speakers?|chargers?|cables?|adapters?|power ?bank|smart ?watch|fitness band|television|tv|monitors?|keyboards?|mouse|webcam|cameras?|ssd|hard ?drive|pen ?drive|routers?|kindle|console|remote)\b/i],
      ['Home goods', /\b(?:bedsheets?|bed ?sheets?|pillows?|cushions?|curtains?|towels?|mattress|blankets?|quilts?|comforters?|rugs?|carpets?|lamps?|bulbs?|decor|vases?|frames?|mugs?|cups?|bottles?|containers?|lunch ?box|cookware|kadai|pans?|tawa|pressure cooker|knives|cutlery|plates?|bowls?|crockery|storage|organi[sz]ers?|hangers?|cleaning|mops?|brooms?|detergent|furniture|chairs?|tables?|shelf|shelves)\b/i],
      ['Books & stationery', /\b(?:books?|paperback|hardcover|novel|notebooks?|diary|diaries|pens?|pencils?|stationery|planner|markers?)\b/i],
      ['Jewellery', /\b(?:rings?|earrings?|necklaces?|pendants?|bracelets?|bangles?|chains?|jewell?ery|anklets?)\b/i],
      ['Kids', /\b(?:diapers?|baby|infant|toddler|kids?)\b/i],
    ];
    // a sub-category that is a kind, as it is; and the words some shops' knowledge uses for the same kind
    var BUY_SUB = { Clothing: 'Clothing', Fashion: 'Clothing', Apparel: 'Clothing', Footwear: 'Footwear', Electronics: 'Electronics', Appliances: 'Electronics',
      Gadgets: 'Electronics', 'Home goods': 'Home goods', Furniture: 'Home goods', Beauty: 'Beauty', 'Personal care': 'Beauty', Jewellery: 'Jewellery',
      Kids: 'Kids', 'Baby & kids': 'Kids', 'Books & stationery': 'Books & stationery', Books: 'Books & stationery', 'Sports gear': 'Sports gear', Sports: 'Sports gear',
      Eyewear: 'Accessories', Accessories: 'Accessories' };
    // what a shop sells, when that is one kind (a marketplace that sells everything is never here)
    var BUY_SHOP = [
      ['Clothing', /\b(?:myntra|ajio|uniqlo|h ?& ?m|hennes|zara|damensch|march ?tee|cava|westside|pantaloons|lifestyle|max fashion|fabindia|snitch|bewakoof|souled store|levi'?s?|jack ?& ?jones|allen solly|van heusen|peter england|louis philippe|manyavar|biba|zudio|trends|marks ?& ?spencer|gap|tommy hilfiger|u\.?s\.? polo|bear house|rare rabbit|bonkers|xyxx|jockey|meesho|nykaa fashion|akal fashions)\b/i],
      ['Footwear', /\b(?:bata|metro shoes|mochi|crocs|skechers|woodland|red tape|campus shoes)\b/i],
      ['Sports gear', /\bdecathlon\b/i],
      ['Beauty', /\b(?:nykaa|purplle|sephora|mamaearth|body shop|minimalist|plum goodness|bombay shaving|beardo)\b/i],
      ['Electronics', /\b(?:croma|reliance digital|vijay sales|apple|samsung|oneplus|boat|noise|ample|imagine|unicorn infosolutions|aptronix)\b/i],
      ['Home goods', /\b(?:ikea|home ?centre|pepperfry|urban ladder|ddecor|borosil|home ?town|wakefit|sleepycat)\b/i],
      ['Accessories', /\b(?:lenskart|titan eye|fastrack|titan)\b/i],
      ['Books & stationery', /\b(?:crossword|sapna book|bookswagon)\b/i],
      ['Kids', /\bfirstcry\b/i],
    ];
    function kindOfItem(n) {
      var s = String(n || '');
      for (var i = 0; i < BUY_KINDS.length; i++) if (BUY_KINDS[i][1].test(s)) return BUY_KINDS[i][0];
      return '';
    }
    // an item's first three words: the same product told again ("WonderBuddy Divine Mantra…") is the same kind
    function itemKey(n) { return String(n || '').toLowerCase().replace(/[^a-z0-9 ]+/g, ' ').trim().split(/\s+/).slice(0, 3).join(' '); }
    var itemKinds = {};
    function kindOfItems(items) {
      var by = {}, first = '';
      (items || []).forEach(function (it) { var k = kindOfItem(it && it.n) || itemKinds[itemKey(it && it.n)] || ''; if (k) { by[k] = (by[k] || 0) + 1; if (!first) first = k; } });
      var ks = Object.keys(by);
      if (!ks.length) return '';
      return ks.sort(function (a, b) { return by[b] - by[a] || (a === first ? -1 : b === first ? 1 : 0); })[0];
    }
    function kindOfShop(name) {
      var s = String(name || '').toLowerCase();
      for (var i = 0; i < BUY_SHOP.length; i++) if (BUY_SHOP[i][1].test(s)) return BUY_SHOP[i][0];
      return '';
    }
    function whatWasBought(tx, pay) {
      var mine = tx.filter(function (t) { return t && t.c === 'Shopping' && t.sp; });
      var shopOf = function (t) { var f = pay[t.id] || {}; return f.at || t.pf || t.m || ''; };
      var said = {};
      itemKinds = {};
      mine.forEach(function (t) { ((pay[t.id] || {}).items || []).forEach(function (it) { var k = kindOfItem(it && it.n); if (k) itemKinds[itemKey(it.n)] = k; }); });
      mine.forEach(function (t) {
        var f = pay[t.id] || {}, k = '', how = '';
        var sub = BUY_SUB[t.s] || '';
        if ((k = kindOfItems(f.items))) how = 'items';
        else if (t.uc && sub) { k = sub; how = 'you'; }
        else if (sub) { k = sub; how = 'sub'; }
        else if ((k = kindOfShop(shopOf(t)) || kindOfShop(t.m))) how = 'shop';
        if (k) { t.wk = k; t.wkb = how; var sk = pfKey(shopOf(t)); (said[sk] = said[sk] || {})[k] = ((said[sk] || {})[k] || 0) + 1; }
      });
      mine.forEach(function (t) {
        if (t.wk) return;
        var by = said[pfKey(shopOf(t))] || {}, ks = Object.keys(by), n = ks.reduce(function (s, k) { return s + by[k]; }, 0);
        var top = ks.sort(function (a, b) { return by[b] - by[a]; })[0];
        if (top && by[top] >= 2 && by[top] / n >= 0.8) { t.wk = top; t.wkb = 'shop'; }
      });
    }
    function pfKey(s) {"""
sub("""    function pfKey(s) {""", BUY, "    var BUY_KINDS = [")
open(F, 'w').write(s)
print('engine patched')

# --- 19:20 round: card names from the mail alone, no PDF needed
s = open(F).read()
# 7. a card statement the bank's mail sends locked is a CARD's statement when its subject says credit card: then its
#    file name's digits ("0036XXXXXXXXXX45_….pdf") and its subject's name ("Diners Black") both count
sub("""      return Object.assign(base, who, { kind: 'unknown', rule: 'statement-unread', reason: 'A statement, probably locked with a password', instr: l4 || inst.kind === 'card' ? 'card' : '', last4: l4 });""",
    """      return Object.assign(base, who, { kind: 'unknown', rule: 'statement-unread', reason: 'A statement, probably locked with a password', instr: l4 || inst.kind === 'card' || /credit card|card statement|card e-?statement/i.test(subj + ' ' + text.slice(0, 400)) ? 'card' : '', last4: l4 });""",
    "card statement|card e-?statement/i.test(subj")
# 8. Yes Bank's names ("Your YES_BANK_RESERV Credit Card E-Statement")
sub("""    [/\\bair ?\\+ (?:visa )?credit card""", """    [/\\byes[_ ]?bank[_ ]?reserve?\\b/i, 'Reserv', 'yes'], [/\\byes[_ ]?(?:bank[_ ]?)?prosperity\\b/i, 'Prosperity', 'yes'], [/\\byes[_ ]?(?:bank[_ ]?)?elite ?\\+/i, 'Elite+', 'yes'],
    [/\\bair ?\\+ (?:visa )?credit card""", "'Reserv', 'yes'")
# 9. a named statement series with no digits ("(HSBC LIVE+ CREDIT CARD)" every month) belongs to the one card of that
#    bank whose own payments ran through the same months: each statement covers the month before it, so a card active in
#    the statement's month or the one before scores it. The card that scores most, at least twice and more than any
#    other, is that card; each card takes one name, the longest series first
sub("""        else loose.push(e);
      });""", """        else loose.push(e);
      });
      (function () {
        var series = {};
        loose.forEach(function (e) { if (!e.l4 && e.r.cardName && e.at) (series[e.r.cardName] = series[e.r.cardName] || []).push(e); });
        var names = Object.keys(series).filter(function (n) { return !named[n]; });
        if (!names.length || full.length < 2) return;
        var ym = function (d) { return String(d || '').slice(0, 7); };
        var prevM = function (m) { var y = +m.slice(0, 4), mo = +m.slice(5, 7) - 1; if (mo < 1) { mo = 12; y--; } return y + '-' + (mo < 10 ? '0' : '') + mo; };
        var nextM = function (m) { var y = +m.slice(0, 4), mo = +m.slice(5, 7) + 1; if (mo > 12) { mo = 1; y++; } return y + '-' + (mo < 10 ? '0' : '') + mo; };
        var active = {};
        full.forEach(function (k) { active[k] = {}; cards[k].forEach(function (x) { if (x.r.kind !== 'doc' && x.at) active[k][ym(x.at)] = 1; }); });
        var taken = {};
        full.forEach(function (k) { if (cards[k].some(function (x) { return x.r.cardName; })) taken[k] = 1; });
        names.sort(function (a, b) { return series[b].length - series[a].length; }).forEach(function (n) {
          var months = {};
          series[n].forEach(function (e) { months[ym(e.at)] = 1; });
          // (two cards alive in the same months: the one used far more then, twice as often at least, is the one the
          // statements are for; a card barely touched beside it is the other)
          var score = full.filter(function (k) { return !taken[k]; }).map(function (k) {
            var s = 0, w = 0; Object.keys(months).forEach(function (m) { if (active[k][m] || active[k][prevM(m)]) s++; });
            cards[k].forEach(function (x) { var m = ym(x.at); if (x.r.kind !== 'doc' && (months[m] || months[nextM(m)])) w++; });
            return { k: k, s: s, w: w };
          }).sort(function (a, b) { return b.s - a.s || b.w - a.w; });
          if (!score.length || score[0].s < 2) return;
          if (score[1] && score[1].s >= score[0].s && !(score[0].w >= 2 * score[1].w && score[0].w >= 3)) return;
          var win = score[0].k; taken[win] = 1;
          series[n].forEach(function (e) { cards[win].push(e); loose.splice(loose.indexOf(e), 1); });
        });
      })();""", "var series = {};\n        loose.forEach")
open(F, 'w').write(s)
print('engine 19:20 rules patched')
s = open(F).read()
# 10. SBI Card's BPCL card ("Transaction Alert from BPCL SBI Card", "Your SBI Card BPCL Monthly Statement")
sub("""    [/\\byes[_ ]?bank[_ ]?reserve?\\b/i, 'Reserv', 'yes'],""", """    [/\\bbpcl sbi card\\b|\\bsbi card bpcl\\b|\\bbpcl sbi credit card\\b/i, 'BPCL', 'sbicard'],
    [/\\byes[_ ]?bank[_ ]?reserve?\\b/i, 'Reserv', 'yes'],""", "'BPCL', 'sbicard'")
open(F, 'w').write(s)
s = open(F).read()
# 11. any shop's own order confirmation, not only the shops kosh knows (1 Nov: Lynk Crafts' "Order #774064
#     confirmed", a Shopify store's mail that lists "Helio Strap Wrist Sport Knit", was never read, so its ₹899 card
#     charge stayed "Not known yet"). The reader already reads such a mail's lines; the searches never asked for it
sub("""    var shop = shopQuery(when);
    if (shop) out.push(shop);
    travelQueries(when)""", """    var shop = shopQuery(when);
    if (shop) out.push(shop);
    out.push(when + ' subject:("order confirmed" OR "order confirmation" OR "thank you for your order" OR "thanks for your order" OR "order placed" OR "order received" OR "your order" OR "order #" OR "order no") -subject:(cancelled OR canceled OR survey OR review OR feedback OR rate)' + VOCAB_TAIL);
    travelQueries(when)""", "\"thank you for your order\" OR \"thanks for your order\"")
open(F, 'w').write(s)
s = open(F).read()
# 12. one bill paid, told twice (1 Nov: ₹229.59 to Jio paid through Amazon Pay showed as two ₹230 rows, "Reliance
#     Postpaid via Amazon Pay" and "Jio · Jio wallet"). The biller's own "payment received" and the paying app's
#     "payment successful" are one payment when they are the same sum on the same day (minutes apart where both print
#     a time) and either share a reference (Jio's "Transaction ID PT0000CUB5GN" is Amazon Pay's "Reliance Postpaid Id")
#     or name the same company (Jio is Reliance's; "Reliance Postpaid" is Jio). The app's row stays (it says how it was
#     paid), named by the biller, with the biller's reference; the biller's mail is told on it, never a second row
sub("""    confirms.forEach(function (c) {
      /* GUARDRAIL a receipt for an order whose payment kosh already holds""", """    (function () {
      var ALIAS = { jio: 'reliance', reliancejio: 'reliance', reliancepostpaid: 'reliance', relianceprepaid: 'reliance', jiofiber: 'reliance',
        vi: 'vodafoneidea', vodafone: 'vodafoneidea', idea: 'vodafoneidea', airtelpostpaid: 'airtel', airtelprepaid: 'airtel', bsnlmobile: 'bsnl' };
      var CO_NOT = /\\b(?:postpaid|prepaid|limited|ltd|pvt|private|india|telecom|infocomm|digital|payments?|bill|recharge|mobile|services?|wallet|the)\\b/g;
      var co = function (s) {
        var raw = String(s || '').toLowerCase().replace(/[^a-z ]+/g, ' ').replace(/\\s+/g, ' ').trim();
        var joined = raw.replace(/\\s+/g, '');
        if (ALIAS[joined]) return ALIAS[joined];
        var w = raw.replace(CO_NOT, ' ').replace(/\\s+/g, ' ').trim().split(' ')[0] || '';
        return ALIAS[w] || w;
      };
      var tokens = function (x) { return [x.ref, x.orderId, x.utr, x.txnId].concat(String(x.subject || '') + ' ' + String(x.info || '') + ' ' + String(x.q || '')).join(' ').toUpperCase(); };
      var mins = function (t) { var m = /^(\\d{1,2}):(\\d{2})/.exec(String(t || '')); return m ? +m[1] * 60 + +m[2] : null; };
      var gone = {};
      confirms.forEach(function (a, i) {
        if (gone[a.id] || a.dir !== 'out' || !(a.amt > 0)) return;
        for (var j = i + 1; j < confirms.length; j++) {
          var b = confirms[j];
          if (gone[b.id] || b.dir !== 'out' || Math.abs(a.amt - b.amt) > 0.5 || a.date !== b.date) continue;
          var ta = mins(a.time), tb = mins(b.time);
          if (ta !== null && tb !== null && Math.abs(ta - tb) > 15) continue;
          // the biller's own mail (it is the payee) and the app's (it paid someone else)
          var biller = co(a.inst) && co(a.inst) === co(a.party || a.inst) ? a : co(b.inst) && co(b.inst) === co(b.party || b.inst) ? b : null;
          if (!biller) continue;
          var app = biller === a ? b : a;
          var sameCo = co(app.party) && co(app.party) === co(biller.inst);
          var ref = String(biller.ref || '').toUpperCase();
          var sameRef = ref.length >= 8 && tokens(app).indexOf(ref) >= 0;
          if (!sameCo && !sameRef) continue;
          if (biller.inst) app.party = biller.inst;
          if (biller.ref && !app.ref) app.ref = biller.ref;
          tell(app, biller);
          gone[biller.id] = 1;
          if (biller === a) return;
        }
      });
      if (Object.keys(gone).length) confirms = confirms.filter(function (c) { return !gone[c.id]; });
    })();
    confirms.forEach(function (c) {
      /* GUARDRAIL a receipt for an order whose payment kosh already holds""", "var ALIAS = { jio: 'reliance'")
open(F, 'w').write(s)
s = open(F).read()
# 13. an Amazon Pay gift card bought is a gift card, not shopping kosh can't name (1 Nov: ₹400 on 16 Sep and ₹301 on
#     21 Sep sat under "Not known yet"; their mails were "Mridul sent you an Amazon Pay Gift Card!" and "Your Amazon Pay
#     Gift Card is ready!", ₹400.00 and ₹301.00). The mail is kept as no payment (the card's charge is the payment) but
#     with its sum, so the charge it matches says what it bought
sub("""  function parse(msg) {
    // (a mail written in an Indian script is read in the English its money words gloss to: glossMail)""", """  function parse(msg) { return giftCardBought(parseMail0(msg), msg); }
  var GIFT_BOUGHT = /gift card is ready|sent you an? (?:amazon pay |amazon )?gift card|gift card (?:purchase|order) (?:is )?(?:confirmed|successful)|e-?gift card (?:is )?(?:on its way|ready|delivered)/i;
  function giftCardBought(r, msg) {
    if (!r || r.kind !== 'noise' || !msg) return r;
    var subj = String(msg.subject || ''), from = String(msg.from || '').toLowerCase();
    if (!GIFT_BOUGHT.test(subj) || !/amazon|flipkart|myntra|gyftr|woohoo|qwikcilver|giftcard/.test(from)) return r;
    var text = subj + ' ' + (normalize(msg.text || '', '') + ' ' + normalize('', msg.html || '')).slice(0, 4000);
    var m = /(?:₹|rs\\.?|inr)\\s?([\\d,]+(?:\\.\\d{1,2})?)\\s*(?:[a-z ]{0,20})?gift card/i.exec(text) || /gift card[^₹\\d]{0,40}(?:₹|rs\\.?|inr)\\s?([\\d,]+(?:\\.\\d{1,2})?)/i.exec(text);
    if (!m) return r;
    var v = +String(m[1]).replace(/,/g, '');
    if (!(v > 0)) return r;
    r.rule = 'giftcard-bought'; r.amt = v;
    if (!r.date) r.date = String(msg.date || '').slice(0, 10);
    return r;
  }
  function parseMail0(msg) {
    // (a mail written in an Indian script is read in the English its money words gloss to: glossMail)""", "function giftCardBought(r, msg)")
sub("""      whatWasBought(snapOut.tx || [], pay);""", """      var giftsBought = (ctx.records || []).filter(function (r) { return r && r.rule === 'giftcard-bought' && r.amt > 0; })
        .map(function (r) { return { a: +r.amt, d: String(r.date || r.sent || '').slice(0, 10) }; });
      whatWasBought(snapOut.tx || [], pay, giftsBought);""", "var giftsBought = (ctx.records")
sub("""    function whatWasBought(tx, pay) {
      var mine = tx.filter(function (t) { return t && t.c === 'Shopping' && t.sp; });""", """    function whatWasBought(tx, pay, gifts) {
      var mine = tx.filter(function (t) { return t && t.c === 'Shopping' && t.sp; });
      // a gift card the shop's own mail says was bought, for the same sum within a day: what this charge was
      var giftTaken = {};
      var giftFor = function (t) {
        var i = (gifts || []).findIndex(function (g, k) { return !giftTaken[k] && Math.abs(g.a - t.a) <= 0.5 && g.d && Math.abs(pfN(g.d) - pfN(t.d)) <= 1; });
        if (i < 0) return false; giftTaken[i] = 1; return true;
      };""", "var giftFor = function (t)")
sub("""        if ((k = kindOfItems(f.items))) how = 'items';
        else if (t.uc && sub) { k = sub; how = 'you'; }""", """        if ((k = kindOfItems(f.items))) how = 'items';
        else if (!(f.items || []).length && giftFor(t)) { k = 'Gift cards'; how = 'mail'; }
        else if (t.uc && sub) { k = sub; how = 'you'; }""", "k = 'Gift cards'; how = 'mail';")
open(F, 'w').write(s)

# 14. the reading's fingerprint (engine-read.json) names what reads mail: parse() changed here (statement mail marked
#     as a card's, card names, gift cards), so the phone reads its mail again, from its sealed copies
import json
RP = 'Kosh/engine-read.json'
j = json.load(open(RP))
if not str(j.get('read', '')).endswith('-fb1nov11'):
    j['read'] = str(j.get('read', '')).split('-fb1nov')[0] + '-fb1nov11'
    open(RP, 'w').write(json.dumps(j))
print('engine 20:25 rules patched')
s = open(F).read()
# 15. how you shop (1 Nov: "make patterns of purchasing and understand the user"): over the last nine months, each kind
#     of thing bought (what whatWasBought said), how many times, how much in all and usually, how often (the middle gap
#     between buying days, and whether it is steady), the shops it comes from, the latest items, and when the next is
#     likely when the rhythm is steady. snap.buys, biggest first. Screens read it; nothing is guessed past what was bought
sub("""      whatWasBought(snapOut.tx || [], pay, giftsBought);""", """      whatWasBought(snapOut.tx || [], pay, giftsBought);
      try { snapOut.buys = buyPatterns(snapOut.tx || [], pay, ctx.today || ''); } catch (e) { /* the screens do without */ }""", "snapOut.buys = buyPatterns(")
sub("""    function whatWasBought(tx, pay, gifts) {""", """    function buyPatterns(tx, pay, today) {
      if (!/^\\d{4}-\\d{2}-\\d{2}$/.test(today)) today = tx.reduce(function (m, t) { return t.d > m ? t.d : m; }, '');
      if (!today) return [];
      var from = pfIso(pfN(today) - 270);
      var mine = tx.filter(function (t) { return t && t.c === 'Shopping' && t.sp && t.wk && t.wk !== 'Gift cards' && t.d >= from && t.d <= today; });
      var all = mine.reduce(function (s, t) { return s + t.a; }, 0);
      var by = {};
      mine.forEach(function (t) { (by[t.wk] = by[t.wk] || []).push(t); });
      return Object.keys(by).map(function (k) {
        var xs = by[k].slice().sort(function (a, b) { return a.d < b.d ? -1 : a.d > b.d ? 1 : 0; });
        var total = xs.reduce(function (s, t) { return s + t.a; }, 0);
        var days = []; xs.forEach(function (t) { if (days.indexOf(t.d) < 0) days.push(t.d); });
        var gaps = []; for (var i = 1; i < days.length; i++) gaps.push(pfN(days[i]) - pfN(days[i - 1]));
        var every = gaps.length >= 2 ? Math.round(pfMid(gaps)) : 0;
        var steady = every >= 4 && gaps.filter(function (g) { return g >= every * 0.5 && g <= every * 1.6; }).length >= Math.ceil(gaps.length * 0.6);
        var shops = {}; xs.forEach(function (t) { var f = pay[t.id] || {}; var s0 = String(t.pf || f.at || t.m || '').trim(); if (s0) shops[s0] = (shops[s0] || 0) + t.a; });
        var items = [];
        xs.slice().reverse().forEach(function (t) { ((pay[t.id] || {}).items || []).forEach(function (it) { var n = String(it && it.n || '').trim(); if (n && items.length < 3 && items.indexOf(n) < 0) items.push(n); }); });
        var last = days[days.length - 1];
        var o = { k: k, n: xs.length, total: Math.round(total), usual: Math.round(pfMid(xs.map(function (t) { return t.a; }))), share: all > 0 ? Math.round(total / all * 1000) / 1000 : 0,
          shops: Object.keys(shops).sort(function (a, b) { return shops[b] - shops[a]; }).slice(0, 3), last: last, items: items };
        if (every) o.every = every;
        if (steady) { o.steady = true; var nx = pfIso(pfN(last) + every); if (nx > today) o.next = nx; }
        return o;
      }).sort(function (a, b) { return b.total - a.total; });
    }
    function whatWasBought(tx, pay, gifts) {""", "function buyPatterns(tx, pay, today)")
open(F, 'w').write(s)
print('engine buys patched')
s = open(F).read()
# 16. one credit told by two alert templates (1 Nov: ₹12,600 rent from Magellan into IndusInd ••7772 showed twice, 6:14
#     and 6:30 pm — IndusInd sent "credited for INR 12600 towards N/IN22626020147099/…" and, sixteen minutes later,
#     "Credited for INR 12600.00 towards N/IN22626020147099/…"). Neither read a reference, both printed no time, and the
#     two mails' arrival times sat further apart than one alert's. The narration's own reference (a NEFT/IMPS/UPI number:
#     ten or more letters and digits, digits in it) is the payment's: the same one on both is one payment however far
#     apart they came; two different ones are two payments
sub("""  function samePayment(o, t) {
    if (o.ref && t.ref && oneRef(o.ref) && oneRef(t.ref)) return oneRef(o.ref) === oneRef(t.ref);""", """  function narrRef(x) {
    var hay = String(x.info || '') + ' ' + String(x.party || '');
    var best = '';
    (hay.toUpperCase().match(/[A-Z0-9]{10,24}/g) || []).forEach(function (w) { if (/\\d{6,}/.test(w) && !/^\\d{10}$/.test(w) && w.length > best.length) best = w; });
    return best;
  }
  function samePayment(o, t) {
    if (o.ref && t.ref && oneRef(o.ref) && oneRef(t.ref)) return oneRef(o.ref) === oneRef(t.ref);
    // (the reference the narration carries: the same on both, one payment; two different ones, two)
    var no = narrRef(o), nt = narrRef(t);
    if (no && nt) return no === nt;""", "function narrRef(x)")
open(F, 'w').write(s)
print('engine 20:48 rules patched')
s = open(F).read()
# 17. categories from what the mail says was bought (1 Nov: "make sure categories are tagged correctly from the mail").
#   a) a charge the shop's own gift-card mail matches (same sum, within a day) is a gift card bought: Wallet & Gift Cards
#      › Gift cards, decided where every category is (so every total agrees), unless you filed it yourself
#   b) a shopping payment's sub-category is what was bought (whatWasBought's kind) when its items, its gift mail or its
#      shop said so and you didn't file it yourself: Clothing, Footwear, Accessories, Electronics… never "Online"
sub("""    var tx = merged.map(function (r) {""", """    var giftsSeen = (records || []).filter(function (x) { return x && x.rule === 'giftcard-bought' && x.amt > 0; })
      .map(function (x) { return { a: +x.amt, d: String(x.date || x.sent || '').slice(0, 10), used: false }; });
    var giftCharge = function (r) {
      if (r.dir !== 'out' || !(r.amt > 0) || !giftsSeen.length) return false;
      var g = giftsSeen.filter(function (x) { return !x.used && Math.abs(x.a - r.amt) <= 0.5 && x.d && r.date && Math.abs(daysBetween(x.d, r.date)) <= 1; })[0];
      if (!g) return false; g.used = true; return true;
    };
    var tx = merged.map(function (r) {""", "var giftsSeen = (records || [])")
sub("""      var c = oc || cl.c, s = mineC ? (o.s || '') : !o.c && o.s !== undefined ? o.s : L.c ? L.s : cl.s;
      var k = cl.k;""", """      var c = oc || cl.c, s = mineC ? (o.s || '') : !o.c && o.s !== undefined ? o.s : L.c ? L.s : cl.s;
      var k = cl.k;
      if (!oc && /^(?:Shopping|Miscellaneous)$/.test(c) && giftCharge(r)) { c = 'Wallet & Gift Cards'; s = 'Gift cards'; k = kindFor(c, r.dir); }""", "giftCharge(r)) { c = 'Wallet & Gift Cards'")
sub("""    ['Shopping', 'spend', '#FF2D55', 'bag.fill', ['Online', 'Clothing', 'Electronics', 'Footwear', 'Home goods', 'Beauty', 'Jewellery', 'Kids', 'Books & stationery', 'Appliances', 'Sports gear']],""",
    """    ['Shopping', 'spend', '#FF2D55', 'bag.fill', ['Online', 'Clothing', 'Footwear', 'Accessories', 'Electronics', 'Home goods', 'Beauty', 'Jewellery', 'Kids', 'Games & toys', 'Books & stationery', 'Appliances', 'Sports gear']],""", "'Accessories', 'Electronics', 'Home goods', 'Beauty', 'Jewellery'")
sub("""      whatWasBought(snapOut.tx || [], pay, giftsBought);""", """      whatWasBought(snapOut.tx || [], pay, giftsBought);
      (snapOut.tx || []).forEach(function (t) {
        if (t.c !== 'Shopping' || !t.wk || t.uc || !/^(?:items|mail|shop)$/.test(t.wkb || '')) return;
        if (/^(?:Gift cards|Subscriptions)$/.test(t.wk)) return;
        t.s = t.wk;
      });""", "if (/^(?:Gift cards|Subscriptions)$/.test(t.wk)) return;")
open(F, 'w').write(s)
print('engine 20:50 categories patched')
# 18. cleanup: an earlier run of this script could leave the WHAT WAS BOUGHT block twice (its marker changed under it);
#     the later, older copy (whatWasBought(tx, pay) without gift cards) would win. Keep the newest, drop the other
s = open(F).read()
_starts = []
_i = s.find('    /* WHAT WAS BOUGHT')
while _i >= 0:
    _starts.append(_i); _i = s.find('    /* WHAT WAS BOUGHT', _i + 10)
if len(_starts) > 1:
    _blocks = []
    for _n, _st in enumerate(_starts):
        _en = _starts[_n + 1] if _n + 1 < len(_starts) else s.index('    function pfKey(s) {', _st)
        _blocks.append((_st, _en))
    _old = [b for b in _blocks if 'function whatWasBought(tx, pay) {' in s[b[0]:b[1]]]
    for _st, _en in sorted(_old, reverse=True):
        if len(_blocks) - len(_old) >= 1: s = s[:_st] + s[_en:]
    open(F, 'w').write(s)
    print('engine: duplicate WHAT WAS BOUGHT block removed')
s = open(F).read()
# 19. one policy, two rows (1 Nov: Bajaj Life's term plan showed twice, ₹2.5CR and ₹24,346 a year each — once from
#     Policybazaar's "Payment received! Your Bajaj Life Term Insurance has been booked" on 12 Jul, numbered by its
#     application, once from Bajaj's own "Policy issued" and policy document, number 0661880593, on 21 Jul). A policy
#     booked through an aggregator and the one the insurer then issued are one: the same insurer, the same premium (2%),
#     the same cover where both say it, first seen within 60 days of each other, and not both carrying a number the
#     insurer's own mail or paper printed. The issued one stays (its number, its dates); the booking's mails join it
SUB_ANCHOR = """    var policies = plist.filter(function (q) {
      if (!q.insurer || AGGREGATOR.test(q.insurer)) return false;"""
sub(SUB_ANCHOR, """    (function () {
      var recOf = {};
      (pols || []).forEach(function (r) { if (r && r.id) recOf[r.id] = r; });
      var fromInsurer = function (q) {
        if (q.source === 'document') return true;
        return (q.mails || []).some(function (m) { var r = recOf[m.id]; return /^paper|^issued/.test(m.k || '') || (r && r.inst && !AGGREGATOR.test(r.inst) && /issued|policy (?:document|bond|number|no)/i.test(String(r.subject || ''))); });
      };
      var firstDay = function (q) { return [q.start, q.noOn].concat((q.mails || []).map(function (m) { return m.on; })).filter(function (x) { return /^\\d{4}-\\d{2}-\\d{2}/.test(x || ''); }).sort()[0] || ''; };
      for (var i = 0; i < plist.length; i++) {
        var a = plist[i];
        if (!a || a.gone || !(a.premium > 0)) continue;
        for (var j = i + 1; j < plist.length; j++) {
          var b = plist[j];
          if (!b || b.gone || b.insurer !== a.insurer || !(b.premium > 0)) continue;
          if (Math.abs(a.premium - b.premium) > Math.max(50, a.premium * 0.02)) continue;
          if (a.cover > 0 && b.cover > 0 && Math.abs(a.cover - b.cover) > 1) continue;
          var da = firstDay(a), db = firstDay(b);
          if (!da || !db || Math.abs(daysBetween(da.slice(0, 10), db.slice(0, 10))) > 60) continue;
          var oa = fromInsurer(a) && !!a.policyNo, ob = fromInsurer(b) && !!b.policyNo;
          if (oa && ob && digits(a.policyNo) !== digits(b.policyNo)) continue;
          var keep = ob && !oa ? b : oa && !ob ? a : (b.policyNo && !a.policyNo ? b : a), drop = keep === a ? b : a;
          ['cover', 'plan', 'holder', 'insured', 'nominee', 'frequency', 'start', 'end', 'term', 'ppt', 'nextDue', 'lastPaid', 'uin'].forEach(function (k) { if (!keep[k] && drop[k]) keep[k] = drop[k]; });
          (drop.mails || []).forEach(function (m) { var ml = keep.mails || (keep.mails = []); if (!ml.some(function (x) { return x.id === m.id; })) ml.push(m); });
          drop.gone = true;
          if (drop === a) break;
        }
      }
      plist = plist.filter(function (q) { return !q.gone; });
    })();
""" + SUB_ANCHOR, "var fromInsurer = function (q)")
open(F, 'w').write(s)
print('engine 21:05 policies patched')
