# kosh feedback 2 Nov (00:14) — engine, part H: what an order was, item by item. A shop's order can hold groceries and
# things for the house at once (₹2,619 on Amazon: oats and rice paper beside sealant tape and a knife bar). Food in an
# order is never a shopping kind: an order's kind is read from its other things, and its food's share is told on the
# payment as `mix` { g: the food's share of the charge, s: its groceries sub, n: what it was, all: every item food },
# so the app files that share under Groceries (a part of its own, as a split by hand would). Idempotent.
p = 'Kosh/engine.js'; s = open(p).read()
def sub(old, new, mark):
    global s
    if mark in s: return
    assert s.count(old) == 1, ('engine H anchor', old[:70], s.count(old))
    s = s.replace(old, new)
sub("""    function kindOfItems(items) {""", """    // food in an order: groceries, never a shopping kind (by the item's own name, its first words; a cooker, a jar or a
    // knife for the kitchen is no food, nor is a gym supplement)
    var FOOD = /\\b(?:oats|muesli|granola|cereals?|cornflakes|atta|flour|maida|rice|basmati|dal|daal|lentils?|pulses|chana|rajma|besan|sooji|rava|poha|quinoa|millets?|ghee|sugar|jaggery|salt|masalas?|spices?|jeera|turmeric|haldi|tea|coffee|biscuits?|cookies|chocolates?|chips|namkeen|bhujia|snacks?|nuts|almonds?|cashews?|walnuts?|pistachios?|raisins?|dates|makhana|seeds|honey|jam|spread|peanut butter|sauce|ketchup|mayonnaise|pickle|noodles|pasta|vermicelli|bread|milk|curd|paneer|butter|cheese|yogh?urt|juice|soda|soft drink|cold drink|squash|syrup|eggs?|vegetables?|fruits?|coconut|olive oil|cooking oil|mustard oil|sunflower oil|dry fruits?|rice paper|protein bar|energy bar)\\b/i;
    var NOT_FOOD = /\\b(?:cooker|maker|grinder|mixer|kettle|bottle|container|jar|box|storage|dispenser|organi[sz]er|holder|rack|bowl|plate|mug|cup|spoon|knife|knives|pan|tawa|kadai|tray|machine|cleaner|whey (?:protein )?(?:isolate|concentrate)|creatine|mass gainer|bcaa|pre-?workout|shampoo|soap|lotion|cream|face ?wash|scrub|serum|candle|toy|book|pet|dog|cat food)\\b/i;
    var FOOD_SUB = [['Dairy', /\\b(?:milk|curd|paneer|butter|cheese|yogh?urt|ghee)\\b/i], ['Fruits & veggies', /\\b(?:vegetables?|fruits?|coconut)\\b/i]];
    function isFood(n) { var h = String(n || '').slice(0, 70); return FOOD.test(h) && !NOT_FOOD.test(h); }
    function kindOfItems(items) {""", 'function isFood(n)')
sub("""        var sub = BUY_SUB[t.s] || '';
        if ((k = kindOfItems(f.items))) how = 'items';""", """        var sub = BUY_SUB[t.s] || '';
        // (its food apart: told as the payment's mix, and the kind read from the rest)
        var its = f.items || [], food = its.filter(function (it) { return it && isFood(it.n); });
        if (food.length && !t.partOf) {
          var priced = its.filter(function (it) { return +it.amt > 0; }), all = priced.reduce(function (s0, it) { return s0 + +it.amt; }, 0);
          var fAmt = food.reduce(function (s0, it) { return s0 + (+it.amt || 0); }, 0);
          var fsub = ''; FOOD_SUB.some(function (x) { if (food.every(function (it) { return x[1].test(it.n); })) { fsub = x[0]; return true; } return false; });
          var names = food.map(function (it) { return String(it.n).split(/[,(|]/)[0].trim().slice(0, 40); });
          if (food.length === its.length) t.mix = { g: t.a, s: fsub, n: names, all: true };
          else if (fAmt > 0 && priced.length === its.length && all > 0) {
            var g = Math.round(fAmt * (t.full || t.a) / all);
            if (g >= 50 && g < t.a) t.mix = { g: g, s: fsub, n: names };
          }
        }
        var rest = food.length && food.length < its.length ? its.filter(function (it) { return !isFood(it && it.n); }) : its;
        if ((k = kindOfItems(rest))) how = 'items';""", "(its food apart: told as the payment's mix")
open(p, 'w').write(s)
print('engine H patched')
# home goods: the house's fixing and fitting too (tape for a leak, a knife bar, hooks, a shelf, a tool kit)
sub("""      ['Home goods', /\\b(?:bedsheets?|""", """      ['Home goods', /\\b(?:knife bar|knives?|tapes?|sealant|caulk|adhesive|hooks?|hangers?|shel(?:f|ves)|racks?|tool ?kit|screwdrivers?|drill|bedsheets?|""", "knife bar|knives?|tapes?|sealant")
open(p, 'w').write(s)
print('engine H home goods')
# every mix says where its share goes (c); and the other way round: a grocery app's order with things that aren't
# groceries (a charger, a T-shirt, a toy from Blinkit) tells their share as Shopping, by their kind
s = open(p).read()
sub("""          if (food.length === its.length) t.mix = { g: t.a, s: fsub, n: names, all: true };""",
    """          if (food.length === its.length) t.mix = { c: 'Groceries', g: t.a, s: fsub, n: names, all: true };""", "t.mix = { c: 'Groceries', g: t.a")
sub("""            if (g >= 50 && g < t.a) t.mix = { g: g, s: fsub, n: names };""",
    """            if (g >= 50 && g < t.a) t.mix = { c: 'Groceries', g: g, s: fsub, n: names };""", "t.mix = { c: 'Groceries', g: g")
sub("""      mine.forEach(function (t) {
        if (t.wk) return;""", """      // (a grocery order's things that aren't groceries: their share as Shopping, by their kind)
      tx.filter(function (t) { return t && t.c === 'Groceries' && t.sp && !t.partOf; }).forEach(function (t) {
        var its = (pay[t.id] || {}).items || [];
        if (its.length < 2 || !its.every(function (it) { return +it.amt > 0; })) return;
        var other = its.filter(function (it) { var k0 = kindOfItem(it.n); return k0 && !/^(?:Home goods|Gift cards|Beauty)$/.test(k0) && !isFood(it.n); });
        if (!other.length || other.length === its.length) return;
        var all = its.reduce(function (s0, it) { return s0 + +it.amt; }, 0), oAmt = other.reduce(function (s0, it) { return s0 + +it.amt; }, 0);
        var g = Math.round(oAmt * (t.full || t.a) / all);
        if (g >= 50 && g < t.a) t.mix = { c: 'Shopping', s: kindOfItems(other) || 'Online', g: g, n: other.map(function (it) { return String(it.n).split(/[,(|]/)[0].trim().slice(0, 40); }) };
      });
      mine.forEach(function (t) {
        if (t.wk) return;""", "(a grocery order's things that aren't groceries")
open(p, 'w').write(s)
print('engine H both ways')
# the same item told twice (an order mail's text and HTML: once with its price, once without, its name cut or spaced
# differently) is one item, the priced one; and the split goes by the priced items when they make up most of the
# charge, so one unpriced line doesn't stop it
s = open(p).read()
sub("""        var its = f.items || [], food = its.filter(function (it) { return it && isFood(it.n); });""",
    """        var its = (function (xs) {
          var keyOf = function (n) { return String(n || '').toLowerCase().replace(/[^a-z0-9]+/g, '').slice(0, 28); }, by = {}, out = [];
          (xs || []).forEach(function (it) { if (!it || !it.n) return; var k0 = keyOf(it.n); if (!(k0 in by)) { by[k0] = out.length; out.push(it); } else if (!(+out[by[k0]].amt > 0) && +it.amt > 0) out[by[k0]] = it; });
          return out;
        })(f.items), food = its.filter(function (it) { return it && isFood(it.n); });""", "var keyOf = function (n) { return String(n || '').toLowerCase().replace(/[^a-z0-9]+/g, '').slice(0, 28); }")
sub("""          else if (fAmt > 0 && priced.length === its.length && all > 0) {""",
    """          else if (fAmt > 0 && all > 0 && (priced.length === its.length || all >= (t.full || t.a) * 0.8)) {""", "all >= (t.full || t.a) * 0.8)")
open(p, 'w').write(s)
print('engine H dedupe')
