# kosh feedback 1 Nov (21:43) — Swift, part M: "How you shop" follows the months Up close is showing (3 months picked →
# three months read), worked out on the phone from those payments the way the engine reads nine. Idempotent.
p = 'Kosh/InsightsBook.swift'; s = open(p).read()
OLD = """                    if cat == "Shopping", let buys = store.snap.buys, !buys.isEmpty {
                        HowYouShop(buys: buys, color: color, ink: ink, today: store.snap.today)
                            .padding(.top, 18)
                    }"""
NEW = """                    if cat == "Shopping" {
                        let buys: [BuyPattern] = BuyPattern.over(rows, store: store)
                        if !buys.isEmpty {
                            HowYouShop(buys: buys, color: color, ink: ink, today: store.snap.today, span: BuyPattern.spanWords(look.months.count))
                                .padding(.top, 18)
                        }
                    }"""
if 'BuyPattern.over(rows' not in s:
    assert s.count(OLD) == 1, 'HowYouShop call anchor'
    s = s.replace(OLD, NEW)
OLD = """    let today: String
    @Environment(\\.accessibilityReduceMotion) private var still
    @State private var all = false
    var body: some View {
        let shown: [BuyPattern] = all ? buys : Array(buys.prefix(4))"""
NEW = """    let today: String
    var span: String = "last 9 months"
    @Environment(\\.accessibilityReduceMotion) private var still
    @State private var all = false
    var body: some View {
        let shown: [BuyPattern] = all ? buys : Array(buys.prefix(4))"""
if 'var span: String = "last 9 months"' not in s:
    assert s.count(OLD) == 1, 'HowYouShop struct anchor'
    s = s.replace(OLD, NEW)
OLD = 'Text("last 9 months").font(.caption).foregroundStyle(.secondary)'
if OLD in s: s = s.replace(OLD, 'Text(span).font(.caption).foregroundStyle(.secondary)')
if 'static func over(_ rows: [Txn]' not in s:
    s += '''

extension BuyPattern {
    /// "this month", "last 3 months"
    static func spanWords(_ n: Int) -> String { n <= 1 ? "this month" : "last " + String(n) + " months" }
    /// how you shop over these payments: each kind of thing bought (what kosh read it was), how many times, how much in
    /// all and usually, how often (the middle gap between buying days, steady or not), the shops, the latest things
    @MainActor static func over(_ rows: [Txn], store: Store) -> [BuyPattern] {
        let mine: [Txn] = rows.filter { $0.sp && !($0.wk ?? "").isEmpty && $0.wk != "Gift cards" }
        let all: Double = mine.reduce(0) { $0 + $1.a }
        let by: [String: [Txn]] = Dictionary(grouping: mine) { $0.wk ?? "" }
        var out: [BuyPattern] = []
        for (k, group) in by {
            let xs: [Txn] = group.sorted { $0.d < $1.d }
            let total: Double = xs.reduce(0) { $0 + $1.a }
            var days: [String] = []
            for t in xs where !days.contains(t.d) { days.append(t.d) }
            var gaps: [Int] = []
            if days.count > 1 { for i in 1..<days.count { gaps.append(Day.between(days[i - 1], days[i])) } }
            let every: Int = gaps.count >= 2 ? Int(mid(gaps.map(Double.init)).rounded()) : 0
            let steady: Bool = every >= 4 && gaps.filter { Double($0) >= Double(every) * 0.5 && Double($0) <= Double(every) * 1.6 }.count >= Int((Double(gaps.count) * 0.6).rounded(.up))
            var shopSum: [String: Double] = [:]
            for t in xs {
                let s0: String = (t.pf ?? store.payFact(t)?.at ?? t.m).trimmingCharacters(in: .whitespaces)
                if !s0.isEmpty { shopSum[s0, default: 0] += t.a }
            }
            var items: [String] = []
            for t in xs.reversed() {
                for it in store.payFact(t)?.items ?? [] {
                    let n: String = it.n.trimmingCharacters(in: .whitespacesAndNewlines)
                    if !n.isEmpty && items.count < 3 && !items.contains(n) { items.append(n) }
                }
            }
            let last: String = days.last ?? ""
            var b = BuyPattern(k: k, n: xs.count, total: total.rounded(), usual: mid(xs.map { $0.a }).rounded(),
                               share: all > 0 ? total / all : 0,
                               shops: shopSum.keys.sorted { shopSum[$0, default: 0] > shopSum[$1, default: 0] }.prefix(3).map { $0 },
                               last: last, items: items)
            if every > 0 { b.every = every }
            if steady {
                b.steady = true
                let nx: String = Day.add(last, every)
                if nx > store.snap.today { b.next = nx }
            }
            out.append(b)
        }
        return out.sorted { $0.total > $1.total }
    }
    private static func mid(_ v: [Double]) -> Double {
        guard !v.isEmpty else { return 0 }
        let s: [Double] = v.sorted()
        return s.count % 2 == 1 ? s[s.count / 2] : (s[s.count / 2 - 1] + s[s.count / 2]) / 2
    }
}
'''
open(p, 'w').write(s)
print('swift M patched')
