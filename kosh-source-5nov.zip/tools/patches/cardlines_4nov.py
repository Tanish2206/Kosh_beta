#!/usr/bin/env python3
"""cardlines-4nov + polno-4nov + gains-4nov + period-4nov (statements chat, 4 Nov). Applied in place to Kosh/engine.js
and Kosh/docread.js by this chat's scripts (each marked in the source with its tag; re-run = check the tags):
 engine.js  cardlines-4nov  stmtFigures skips a rate ("1.75% on all DCC"); a card line of only its time and figure takes
                            the words printed above it (HDFC "BPPY CC PAYMENT…" over "06/08/2026| 09:24 + C 2,08,054.00",
                            "IGST-…" over "03/10/2026 | 00:00 C 32.03"); an undated GST line under a dated one (SBI Card
                            "CGST DB @ 09.00% 44.91 D"); EMI snapshot / instant-discount / rewards tables skipped (Kotak);
                            NET/TOTAL OUTSTANDING lines are no lines; a 4-figure summary row with no labels counts when it
                            opens on the printed opening balance and ends on the net outstanding (HSBC); a purchase turned
                            into EMI or refunded nets against purchases; EXCESS CREDIT REFUND is money out, not in.
 engine.js  period-4nov     an unlabelled "19 MAY 2026 To 18 JUN 2026" at the head is the period (not a worked example).
 engine.js  polno-4nov      a policy number has digits ("Policy Number   Issuance Date" is a table head); else the
                            "Policy No." followed by 6+ digits on its line or the next; a CIS is a proposal, not a schedule.
 docread.js gains-4nov      gains rows: figures a single space apart split; a nameless sale row in a gains section; the gain
                            is sale − cost on the row wherever its column is; interest/salary sections end the gains section.
Swift: LiveSession+Statements.swift statementReader = 7."""
