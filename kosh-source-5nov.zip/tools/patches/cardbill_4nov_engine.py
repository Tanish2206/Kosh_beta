#!/usr/bin/env python3
"""cardbill-4nov: a card statement PDF's own bill (total amount due, minimum due, due date) is read and becomes the
card's bill. Before, a card's bill came only from MAIL that printed it (the issuer's alert or CRED's "New smart
statement" mail); HDFC's statement mail prints no figures, so its cards showed whatever CRED last mailed (Diners
••4545 stuck on October's Rs 10,165 while the PDF said Rs 21,388 due 21 Nov). Idempotent."""
import sys, io
P = sys.argv[1] if len(sys.argv) > 1 else 'Kosh/engine.js'
s = io.open(P, encoding='utf-8').read()
if 'cardbill-4nov' in s:
    print('already applied'); sys.exit(0)

# 1. the reader: after cardLimits
A = "  /* (accttype-4nov) a statement's other accounts by the bank's own word"
assert s.count(A) == 1
READER = r'''  /* cardbill-4nov: the bill a card statement prints for itself: its total amount due, its minimum and the day it is due.
     Read by the label and the figure under it in the same column (a summary box: "TOTAL AMOUNT DUE   MINIMUM DUE   DUE
     DATE" over "21,388.00   1,070.00   21 Nov, 2026"), or beside it, or (a text with no columns) the first such figure after
     it. The total is the summary's own equation when it holds (cardSummary), else its label's. Kept only when it is
     sane: a due day 1-40 days after the statement's day, a minimum no bigger than the total. Every issuer, not HDFC's. */
  var CB_TOTAL = /\btotal\s+(?:amount|payment)\s+due\b|\btotal\s+due\b|\btotal\s+bill\s+amount\b|\btotal\s+(?:amount\s+)?payable\b|\btotal\s+dues\b|\btotal\s+outstanding\b|\bamount\s+payable\b|\bnet\s+outstanding\s+balance\b|\bclosing\s+balance\b|\bnew\s+balance\b/i;
  var CB_MIN = /\bmin(?:imum|imal)?\.?\s+(?:amount\s+|payment\s+)?(?:due|payable)\b|\bminimum\s+dues\b/i;
  var CB_DUE = /\b(?:payment\s+)?due\s+(?:date|by|on)\b|\bpay\s+by(?:\s+date)?\b/i;
  var CB_STMT = /\bstatement\s+(?:date|generation\s+date)\b/i;
  var CB_AMT = /(?:rs\.?|inr|₹|`|\bC(?=\d))?\s*((?:\d{1,3}(?:,\d{2,3})+|\d+)(?:\.\d{2})?)\s*(cr\b|dr\b)?/gi;
  var CB_DAY = new RegExp('\\b(\\d{1,2}[-/.]\\d{1,2}[-/.]\\d{2,4}|\\d{1,2}(?:st|nd|rd|th)?[- ](?:' + MON + ')[a-z]*[-, ]+\\d{2,4}|(?:' + MON + ')[a-z]* \\d{1,2}(?:st|nd|rd|th)?,? \\d{4})\\b', 'gi');
  function cbTokens(line, what) {
    var re = what === 'day' ? CB_DAY : CB_AMT, out = [], m; re.lastIndex = 0;
    var masked = what === 'day' ? line : line.replace(CB_DAY, function (x) { return x.replace(/./g, ' '); });
    while ((m = re.exec(masked))) {
      if (what === 'day') { var d = stmtDate(m[1], null); if (d) out.push({ v: d, a: m.index, b: m.index + m[0].length }); continue; }
      // an amount here is money: with paise, or a rupee mark before it (never a bare year, a page or a count)
      if (!/\./.test(m[1]) && !/(?:rs|inr|₹|`|C)\s*$/i.test(m[0].slice(0, m[0].indexOf(m[1])))) continue;
      if (/^\s*(?:%|p\.?\s?a\b|p\.?\s?m\b)/i.test(masked.slice(m.index + m[0].length))) continue;
      out.push({ v: num(m[1]), cr: (m[2] || '').toLowerCase() === 'cr', a: m.index + m[0].indexOf(m[1]), b: m.index + m[0].length });
    }
    return out;
  }
  function cbCells(line) { return cellsOf(line).filter(function (c) { return /[A-Za-z0-9]/.test(c); }); }
  function cbFind(lines, label, what, ok) {
    function pick(tk) { tk = tk.filter(ok); return tk.length ? tk[0] : null; }
    for (var i = 0; i < lines.length; i++) {
      var ln = lines[i], m = label.exec(ln);
      if (!m) continue;
      var a = m.index, b = m.index + m[0].length, got;
      // beside it on its line ("Payment Due Date: 21/11/2026", "Total Amount Due (TAD)   ₹ 13,665.15")
      if ((got = pick(cbTokens(ln.slice(b), what).filter(function (t) { return t.a <= 60; })))) return got;
      // a row of labels over a row of figures: the figure in the label's cell. Same number of cells, or (a box whose
      // first columns print nothing under them) the figures under its last columns, read from the right
      var hc = cbCells(ln), ci = hc.findIndex(function (c) { return label.test(c); });
      if (ci >= 0 && hc.length >= 2) {
        for (var j = i + 1; j <= i + 3 && j < lines.length; j++) {
          var vc = cbCells(lines[j]);
          if (!vc.length) continue;
          var allV = vc.every(function (c) { return cbTokens(c, 'amt').length || cbTokens(c, 'day').length || /^[_+\-=]$/.test(c); });
          if (!allV) { if (/[a-z]{3,}/i.test(lines[j]) && !cbTokens(lines[j], what).length) continue; break; }
          var cell = vc.length === hc.length ? vc[ci] : vc.length < hc.length && ci >= hc.length - vc.length ? vc[vc.length - (hc.length - ci)] : null;
          if (cell && (got = pick(cbTokens(cell, what)))) return got;
          break;
        }
      }
      // under it in its column, where the text keeps its columns (wide runs of spaces)
      for (var k = i + 1; k <= i + 4 && k < lines.length; k++) {
        if (!/ {6,}/.test(lines[k])) continue;
        var col = cbTokens(lines[k], what).filter(function (t) { return t.b >= a - 12 && t.a <= b + 12 && ok(t); });
        if (col.length) return col.sort(function (x, y) { return Math.abs((x.a + x.b) / 2 - (a + b) / 2) - Math.abs((y.a + y.b) / 2 - (a + b) / 2); })[0];
      }
    }
    // a text with no columns (one word or figure a line): the first such figure after the label within a few lines
    for (var q = 0; q < lines.length; q++) {
      if (!label.exec(lines[q])) continue;
      for (var n = q + 1; n <= q + 12 && n < lines.length; n++) { var tk = pick(cbTokens(lines[n], what)); if (tk) return tk; }
    }
    return null;
  }
  // the page as the phone sees it (each word with where it sits): a line's cells, words closer than a column's gap
  function cbGridRows(G) {
    // words printed on one visual line a few points apart (a figure set a hair above its label) are one line
    var merged = [];
    (G || []).slice(0, 400).forEach(function (l) {
      var last = merged[merged.length - 1];
      if (last && last.p === l.p && Math.abs(l.y - last.y) <= 4) { last.w = last.w.concat(l.w).sort(function (a, b) { return a.x0 - b.x0; }); return; }
      merged.push({ p: l.p, y: l.y, w: l.w.slice() });
    });
    return merged.map(function (l) {
      var cw = gridCw(l), cells = [], cur = null;
      l.w.forEach(function (w) { if (cur && w.x0 - cur.x1 <= cw * 1.6) { cur.t += ' ' + w.t; cur.x1 = w.x1; } else { cur = { t: w.t, x0: w.x0, x1: w.x1 }; cells.push(cur); } });
      return { p: l.p, y: l.y, c: cells };
    });
  }
  // a cell that is words, not a figure: another label, or "NO PAYMENT REQUIRED". A label's own second line ("(Including
  // Cash)") is not one
  function cbWords(t) { return /[A-Za-z]{3,}/.test(t) && !/^\s*\(/.test(t) && !cbTokens(t, 'amt').length && !cbTokens(t, 'day').length; }
  function cbGridFind(R, label, what, ok) {
    function pick(tk) { tk = tk.filter(ok); return tk.length ? tk[0] : null; }
    for (var i = 0; i < R.length; i++) {
      for (var k = 0; k < R[i].c.length; k++) {
        var cell = R[i].c[k], m = label.exec(cell.t), got;
        if (!m) continue;
        // in its own cell, after the label ("Payment due date 14 Nov 2026")
        if ((got = pick(cbTokens(cell.t.slice(m.index + m[0].length), what)))) return got;
        // under it, in its column, before any other words in that column
        var stop = false;
        for (var j = i + 1; j < R.length && j <= i + 8 && !stop; j++) {
          if (R[j].p !== R[i].p || R[j].y - R[i].y > 90) break;
          var ov = R[j].c.filter(function (c) { return c.x1 >= cell.x0 - 15 && c.x0 <= cell.x1 + 15; });
          for (var q = 0; q < ov.length; q++) {
            if ((got = pick(cbTokens(ov[q].t, what)))) return got;
            if (cbWords(ov[q].t)) { stop = true; break; }
          }
        }
        // else beside it: the next cell on its line ("Total Amount Due (TAD)      ₹ 13,665.15")
        var nx = R[i].c[k + 1];
        if (nx && (got = pick(cbTokens(nx.t, what)))) return got;
      }
    }
    return null;
  }
  function cardBillOf(text, to, G) {
    var lines = String(text || '').split('\n').slice(0, 160);
    var on = to || '';
    // the day of the statement: the one it prints as its date in its head, else the period's end the lines name
    var head = lines.slice(0, 60), st = (G ? cbGridFind(cbGridRows(G.slice(0, 60)), CB_STMT, 'day', function (t) { return !to || Math.abs(daysBetween(to, t.v)) <= 10; }) : null) || cbFind(head, CB_STMT, 'day', function (t) { return !to || (daysBetween(to, t.v) >= -10 && daysBetween(to, t.v) <= 10); });
    if (st) on = st.v;
    // (a period whose first day prints no year: "26 Sep - 25 Oct 2026")
    if (!on) { var pm = new RegExp('\\b\\d{1,2}(?:st|nd|rd|th)?[- ](?:' + MON + ')[a-z]*(?:[-, ]+\\d{2,4})?\\s*(?:-|to|till)\\s*' + CB_DAY.source, 'i').exec(head.join('\n')); if (pm) on = stmtDate(pm[1], null) || ''; }
    if (!on) return null;
    // read off the page by where each figure sits when the phone has it, else off the text
    var R = G ? cbGridRows(G) : null;
    var find = function (label, what, ok) { return (R && cbGridFind(R, label, what, ok)) || (R ? null : cbFind(lines, label, what, ok)); };
    // the total: the figure under its own label; the summary's equation stands in where none is found, and where the two
    // disagree on a text without positions nothing is taken (a wrong bill is worse than the mail's)
    var S = cardSummary(text), eqT = S && S.eq && S.total >= 0 ? S.total : null, total = null, cr = false, byLabel = false;
    var tt = find(CB_TOTAL, 'amt', function (t) { return t.v >= 0; });
    if (tt) { total = tt.cr ? 0 : tt.v; cr = !!tt.cr; byLabel = true; }
    if (total === null) total = eqT;
    else if (!R && eqT !== null && Math.abs(eqT - total) > 1) return null;
    if (total === null || !isFinite(total)) return null;
    var due = find(CB_DUE, 'day', function (t) { var g = daysBetween(on, t.v); return g >= 1 && g <= 40; });
    // nothing to pay ("Payment Due Date  NO PAYMENT REQUIRED", a total due of 0.00): the statement's own word that this
    // cycle owes nothing, as of its day
    if (!due) return total === 0 && (byLabel || S.eq) ? { amt: 0, min: 0, due: on, on: on, none: true } : null;
    var mn = find(CB_MIN, 'amt', function (t) { return t.v <= total + 1; });
    return { amt: r2(total), min: mn ? r2(mn.v) : 0, due: due.v, on: on };
  }

'''
s = s.replace(A, READER + A, 1)

# 2. parseDoc: a card statement carries its bill
B = "      if (card) { var lim = cardLimits(flat); if (lim.limit) out.limit = lim.limit; if (lim.avail !== null) out.avail = lim.avail; }\n"
assert s.count(B) == 1
s = s.replace(B, B + "      // cardbill-4nov: the bill it prints for itself, read off the text the lines were read from, else the page as it is\n"
  "      if (card) { var bill = (Gs.length ? cardBillOf(text, L.to, Gs[0]) : null) || cardBillOf(Lt, L.to) || (Lt !== text ? cardBillOf(text, L.to) : null); if (bill) out.bill = bill; }\n", 1)

# 3. cardsSeen: the statement PDF's bill is the card's statement, as a mail's would be
C = "      if (inst) add(inst, S.last4, { date: S.periodTo || S.sent || '', sent: S.sent || '', kind: 'doc', credit: +S.credit || 0, limit: +S.limit || 0, avail: S.avail >= 0 ? +S.avail : null, cardName: cn || undefined, id: m ? m.id : undefined }, 'statement');\n"
assert s.count(C) == 1
s = s.replace(C, C + "      // cardbill-4nov: the bill its PDF prints (total, minimum, due day) is the card's bill for that cycle, the issuer's own word\n"
  "      if (inst && S.billDue && S.billAmt >= 0) add(inst, S.last4, { date: S.billOn || S.periodTo || S.sent || '', sent: S.sent || '', kind: 'statement', amt: +S.billAmt, min: +S.billMin || 0, due: S.billDue, pdf: true, cardName: cn || undefined, id: m ? m.id : undefined }, 'statement');\n", 1)

# 4. picking the card's statement: the issuer's PDF for a cycle is not replaced by a later mail of the same cycle that
#    prints less (no due day: CRED's "New smart statement", a reminder)
D = "          if (!was || (sameBill ? e.at < wasAt : e.at > wasAt)) c.stmt = e.r;\n"
assert s.count(D) == 1
s = s.replace(D, "          // cardbill-4nov: the issuer's own statement PDF wins its cycle: a mail within 20 days after it that names no due\n"
  "          // day (CRED's \"New smart statement\", a reminder) is the same bill told again, never a newer one\n"
  "          var pdfHolds = was && was.pdf && !e.r.pdf && !e.r.due && e.at > wasAt && daysBetween(wasAt.slice(0, 10), e.at.slice(0, 10)) <= 20;\n"
  "          var pdfTakes = was && !was.pdf && e.r.pdf && !was.due && e.at < wasAt && daysBetween(e.at.slice(0, 10), wasAt.slice(0, 10)) <= 20;\n"
  "          if (pdfTakes || (!pdfHolds && (!was || (sameBill ? e.at < wasAt : e.at > wasAt)))) c.stmt = e.r;\n", 1)

# 5. a card statement whose lines name no card: the card number its head prints ("652926XXXXXX5192", masked) is whose
#    it is. Without it the phone's reading of HDFC's Tata Neu statement was tied to no card, so nothing it said reached ••5192
E = "      try { var dfx = docFacts(text, from || '', title || ''); if (dfx.length) out.ids = dfx; } catch (e) { /* the paper's reading stands */ }\n"
assert s.count(E) == 1
s = s.replace(E, E + "      // cardbill-4nov: a card statement's card, from the masked card number it prints, when its lines named none\n"
  "      if (kind === 'cardstmt' && !out.last4 && !(out.parts || []).length && out.ids) {\n"
  "        var cno = out.ids.filter(function (x) { return x.k === 'cardNo' && x.last4; })[0] || out.ids.filter(function (x) { return x.masked && x.last4 && /^[\\dX*]{12,19}$/i.test(String(x.v || '').replace(/[\\s-]/g, '')); })[0];\n"
  "        if (cno) out.last4 = cno.last4;\n"
  "      }\n", 1)

# 6. the PDF's bill is the paper, as its 'doc' evidence is: never counted as the card being used that month when mail
#    that names only the card is placed by which card was busy (without this, Tata Neu's statement mails went loose)
for old6 in ["        full.forEach(function (k) { active[k] = {}; cards[k].forEach(function (x) { if (x.r.kind !== 'doc' && x.at) active[k][ym(x.at)] = 1; }); });\n",
             "            cards[k].forEach(function (x) { var m = ym(x.at); if (x.r.kind !== 'doc' && (months[m] || months[nextM(m)])) w++; });\n"]:
    assert s.count(old6) == 1, old6[:50]
    s = s.replace(old6, old6.replace("x.r.kind !== 'doc'", "x.r.kind !== 'doc' && !x.r.pdf"), 1)

# 7. a card already known by a name is closed to a series of a DIFFERENT name only: a statement mail placed on ••5192 by
#    its bill's amount ("Tata Neu Infinity") must not shut the rest of the Tata Neu mail out of ••5192
o7a = "        full.forEach(function (k) { if (cards[k].some(function (x) { return x.r.cardName; })) taken[k] = 1; });\n"
o7b = "          var score = full.filter(function (k) { return !taken[k]; }).map(function (k) {\n"
assert s.count(o7a) == 1 and s.count(o7b) == 1
s = s.replace(o7a, "        full.forEach(function (k) { cards[k].forEach(function (x) { if (x.r.cardName) (taken[k] = taken[k] || {})[x.r.cardName] = 1; }); });\n", 1)
o7c = "          var win = score[0].k; taken[win] = 1;\n"
assert s.count(o7c) == 1
s = s.replace(o7c, "          var win = score[0].k; (taken[win] = taken[win] || {})[n] = 1;\n", 1)
s = s.replace(o7b, "          var score = full.filter(function (k) { return !taken[k] || (Object.keys(taken[k]).length === 1 && taken[k][n]); }).map(function (k) {\n", 1)

# 8. a kept statement's src is "doc:<mail id>" (applyDoc): its mail is found by the id without that prefix. The lookup
#    used the whole src, so a statement PDF never found its own mail (its card's name, its id for tying mail to card)
o8 = "      var m = mailById[String(S.src || '').split('#')[0]] || null;\n"
assert s.count(o8) == 1
s = s.replace(o8, "      var m = mailById[String(S.src || '').split('#')[0].replace(/^doc:/, '')] || null;\n", 1)
io.open(P, 'w', encoding='utf-8').write(s)
print('applied')
