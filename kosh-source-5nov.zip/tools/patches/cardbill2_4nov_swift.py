#!/usr/bin/env python3
"""cardbill2-4nov (Swift): (1) a paper read from a leaflet that rode with the statement (HSBC's "Most Important Terms &
Conditions.pdf", "Important_Notes.pdf") is pointed at the statement in the same mail and read again, once; (2) a card
statement keeps the bill any reading of its pages printed when the winning reading printed none; (3) statementReader
+1 so kept statements are read again with the engine's cardbill2 readers. Idempotent; writes only if the file did not
change while it was being patched (another chat works on these files)."""
import io, sys, re, hashlib
root = sys.argv[1] if len(sys.argv) > 1 else 'Kosh'
P = root + '/LiveSession+Statements.swift'
raw = io.open(P, 'rb').read(); h0 = hashlib.md5(raw).hexdigest(); s = raw.decode('utf-8')
if 'cardbill2-4nov' in s:
    print('already applied'); sys.exit(0)
def rep(old, new):
    global s
    assert s.count(old) == 1, (s.count(old), old[:90])
    s = s.replace(old, new, 1)

# (1) repick before the docs pass
rep("""        if ud.integer(forKey: "pw.guessV") < 3 {""",
"""        // (cardbill2-4nov) papers once read from a leaflet riding with the statement: pointed at the statement, read again
        await repickLeafletDocs()
        if ud.integer(forKey: "pw.guessV") < 3 {""")
rep("""    static func docTextKey(_ d: DocRef) -> String {""",
"""    /// (cardbill2-4nov, stmtpick) A mail with several PDFs: kosh once took the first, and HSBC sends its "Most Important
    /// Terms & Conditions.pdf" ahead of the card statement (and "Important_Notes.pdf" ahead of the savings statement), so
    /// every HSBC statement was read from the leaflet. The engine now passes leaflets over (docLeaflet); each paper read
    /// from one is pointed at the statement its mail carries and read again, once. A mail that can't be fetched now is
    /// tried on the next pass.
    @MainActor
    func repickLeafletDocs() async {
        guard ud.integer(forKey: "beta.stmtPick") < 1 else { return }
        var done = true
        for i in records.indices {
            guard i < records.count, let d = records[i].doc, d.file != "(mail)",
                  (try? Engine.shared.call("docLeafletJSON", [d.file])) == "true" else { continue }
            if halted { done = false; break }
            guard let m = try? await fetchOne(d.msg, acct: d.acct) else { done = false; continue }
            guard i < records.count, records[i].doc?.msg == d.msg,
                  let out = try? Readers.engine(for: m.from).call("docWantedJSON", [JSONText.encode(m)]),
                  let want = try? JSONText.decode(DocWant.self, out), !want.kind.isEmpty, want.file != d.file,
                  let att = m.attachments.first(where: { $0.filename == want.file }) else { continue }
            var nd: DocRef = d
            nd.att = att.id; nd.file = att.filename; nd.kind = want.kind
            nd.state = ""; nd.note = nil; nd.unread = nil; nd.tried = nil; nd.auto = nil
            records[i].doc = nd
            // what the leaflet was read as goes with it (its "lines" were the terms' worked examples)
            statements.removeAll { $0.src == "doc:" + d.msg || $0.src.hasPrefix("doc:" + d.msg + "#") }
        }
        if done { ud.set(1, forKey: "beta.stmtPick") }
        save()
    }

    static func docTextKey(_ d: DocRef) -> String {""")

# (2) the bill from any reading of the pages
rep("""            if let best { bests.append(best) }""",
"""            // (cardbill2-4nov) a card statement's bill as any reading of these pages printed it, when the reading that won
            // printed none (the phone's rebuilt rows can come out jumbled where PDFKit's text reads the box whole): one
            // backed by the statement's own equation first
            // (and its card's digits, when every other reading that names them names the same ones)
            if kind == "cardstmt", let b0 = best, let d0 = b0.data(using: .utf8),
               var o0 = (try? JSONSerialization.jsonObject(with: d0)) as? [String: Any],
               o0["bill"] == nil || ((o0["last4"] as? String) ?? "").isEmpty {
                let all: [[String: Any]] = outs.compactMap { str -> [String: Any]? in
                    guard let dd = str.data(using: .utf8) else { return nil }
                    return (try? JSONSerialization.jsonObject(with: dd)) as? [String: Any]
                }
                var changed = false
                let bills: [[String: Any]] = all.compactMap { $0["bill"] as? [String: Any] }
                if o0["bill"] == nil, let pick = bills.first(where: { ($0["eq"] as? Bool) == true }) ?? bills.first { o0["bill"] = pick; changed = true }
                let l4s: Set<String> = Set(all.compactMap { $0["last4"] as? String }.filter { !$0.isEmpty })
                if ((o0["last4"] as? String) ?? "").isEmpty, l4s.count == 1, let l4 = l4s.first { o0["last4"] = l4; changed = true }
                if changed, let nd = try? JSONSerialization.data(withJSONObject: o0), let ns = String(data: nd, encoding: .utf8) { best = ns }
            }
            if let best { bests.append(best) }""")

# (3) statementReader +1
m = re.search(r'static let statementReader = (\d+)', s); cur = int(m.group(1))
old_l = re.search(r'static let statementReader = %d\s+// %d ' % (cur, cur), s).group(0)
rep(old_l, "static let statementReader = %d   // %d (4 Nov, cardbill2-4nov): card bills off PDFKit's text when the rebuilt rows are jumbled, labels in sentences passed over, card digits from the masked number.\n    // %d " % (cur + 1, cur + 1, cur))
if hashlib.md5(io.open(P, 'rb').read()).hexdigest() != h0: sys.exit('changed underneath, run again')
io.open(P, 'w', encoding='utf-8').write(s)
print('applied; statementReader', cur + 1)
# (4) the diag's statementsRead carries each card statement's bill (dev check from the Mac)
E = root + '/LiveSession+Extras.swift'
t = io.open(E, encoding='utf-8').read()
if 'cardbill2-4nov' not in t:
    o = '''            if let v = S.ok { o["addsUp"] = v }'''
    assert t.count(o) == 1
    t = t.replace(o, o + '''
            // (cardbill2-4nov) a card statement's own bill, so the Mac can check it against the issuer's figures
            if let v = S.billAmt { o["bill"] = [v, S.billMin ?? 0, S.billDue ?? ""] as [Any] }''')
    io.open(E, 'w', encoding='utf-8').write(t)
