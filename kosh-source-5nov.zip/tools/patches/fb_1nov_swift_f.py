# kosh feedback 1 Nov (19:50) — Swift, part F: the searches' version goes to 5, so the new order-confirmation search
# (engine › gmailQueries) reads the past year's order mail once, nothing read twice. Idempotent.
p = 'Kosh/LiveSession+Reading.swift'; s = open(p).read()
a = """    static let queriesVersion = 4"""
b = """    /// 5 (1 Nov): any shop's own order confirmation ("Order #774064 confirmed", "Thank you for your order"), so a small
    /// store's items are read and the card charge they match says what was bought (engine › whatWasBought)
    static let queriesVersion = 5"""
if 'static let queriesVersion = 5' not in s and 'static let queriesVersion = 6' not in s:
    assert s.count(a) == 1, 'queriesVersion anchor'
    s = s.replace(a, b)
    open(p, 'w').write(s)
print('swift F patched')

# 6 (1 Nov 22:34): marketplaces' "Ordered: …" mails and receipts Gmail filed under Promotions (Amazon Pay's "Your
# Electricity bill payment … is successful"), from the senders kosh already reads
s = open(p).read()
a = """    static let queriesVersion = 5"""
b = """    /// 6 (1 Nov): "Ordered: …" and receipts Gmail filed under Promotions, from senders kosh reads (engine › gmailQueries)
    static let queriesVersion = 6"""
if 'static let queriesVersion = 6' not in s:
    assert s.count(a) == 1, 'queriesVersion 6 anchor'
    s = s.replace(a, b)
    open(p, 'w').write(s)
print('swift F 6')
