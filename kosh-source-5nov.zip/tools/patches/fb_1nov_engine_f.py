# kosh feedback 1 Nov (23:40) — engine, part F: papers kosh left unopened because of who sent them. CRED garage's
# "from CRED garage: ICICI policy issued" carries "MH12WW1380_insurance_policy.pdf"; CRED is an app, not an insurer,
# so the policy was never opened. Any sender's PDF is a policy paper when the mail or the file says a policy was
# issued or is attached (an aggregator's, an app's, a bank's), never a quote, a proposal or a brochure; and a payment
# app's or wallet's mail with an invoice or receipt and no amount in its words is opened like a shop's. Idempotent.
p = 'Kosh/engine.js'; s = open(p).read()
old = """    // the statement itself, not a terms leaflet or a tax form riding along"""
new = """    // a policy paper from anyone: an aggregator's, an app's (CRED garage, Policybazaar, Ditto), a bank's
    var polBoth = (sj + ' ' + files.join(' ')).toLowerCase().replace(/[_\\-]+/g, ' ');
    if (k !== 'insurer' && /\\b(?:policy (?:is )?issued|insurance policy|policy (?:schedule|document|bond|copy|certificate|pdf)|certificate of insurance|policy wording|your policy)\\b/.test(polBoth) &&
        /\\binsur|\\bpolicy\\b/.test(polBoth) && !/illustration|quot(?:e|ation)|proposal|application form|brochure|newsletter|kyc|claim form|claims? (?:support|assistance|program)|support program|renewal (?:quote|reminder)/.test(polBoth)) {
      var pf = files.filter(function (f) { return /polic|insur|schedule|certificate/i.test(f); })[0] || files[0];
      return { kind: 'policy', file: pf };
    }
    // a payment app's or wallet's invoice or receipt, its amount only in the PDF: opened as a shop's order
    if ((k === 'app' || k === 'wallet') && !zipped.length && /invoice|receipt|tax invoice/.test(sj + ' ' + files.join(' ').toLowerCase()) && !/statement|refund/.test(sj)) {
      var body2 = normalize(m.text || '', m.html || '');
      if (!/(?:₹|rs\\.?|inr)\\s?\\d/i.test(sj + ' ' + body2)) return { kind: 'order', file: files[0], files: files };
    }
    // the statement itself, not a terms leaflet or a tax form riding along"""
if '// a policy paper from anyone:' not in s:
    assert s.count(old) == 1, 'docWanted anchor'
    s = s.replace(old, new)
open(p, 'w').write(s)
print('engine F patched')
