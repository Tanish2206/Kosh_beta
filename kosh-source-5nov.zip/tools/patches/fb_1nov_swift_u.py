# kosh feedback 2 Nov (01:32) — Swift, part U: an order item by item. Each item keeps its order number and, when a shop
# said it went back, the day (struck through, "Returned 19 Apr", what came back when its mail said); the order card
# lists the order numbers; a payment row says which of its things went back. Idempotent.
def sub(path, old, new, mark):
    s = open(path).read()
    if mark in s: return
    assert s.count(old) == 1, (path, old[:70], s.count(old))
    open(path, 'w').write(s.replace(old, new))
sub('Kosh/PayFacts.swift', """        var amt: Double? = nil
        var unit: Double? = nil
    }""", """        var amt: Double? = nil
        var unit: Double? = nil
        /// the order it was in, the day a shop said it went back, and what its mail said came back
        var o: String? = nil
        var ret: String? = nil
        var back: Double? = nil
    }""", 'var ret: String? = nil')
sub('Kosh/OrderViews.swift', """            ForEach(Array(items.prefix(5).enumerated()), id: \\.offset) { _, it in
                ItemRow(it: it)
            }""", """            ForEach(Array(items.prefix(5).enumerated()), id: \\.offset) { _, it in
                ItemRow(it: it, food: t.c == "Food & Drinks" || t.c == "Groceries")
            }
            // (the order numbers the items came in)
            if let line = SplitWords.orders(items) {
                Text(line).font(.caption.monospaced()).foregroundStyle(.secondary).textSelection(.enabled).privacySensitive()
            }""", 'ItemRow(it: it, food:')
sub('Kosh/OrderViews.swift', """struct ItemRow: View {
    let it: PayFacts.Item
    var body: some View {
        let count: String = (it.q ?? 1) > 1 ? String(it.q ?? 1) + " × " : ""
        let fig: Double? = it.amt ?? it.unit
        HStack(alignment: .firstTextBaseline, spacing: 8) {
            Text(count + it.n).font(.subheadline).lineLimit(2)
            Spacer(minLength: 8)
            if let fig { Text(Fmt.rupees(fig) + (it.amt == nil ? " each" : "")).font(.subheadline).foregroundStyle(.secondary).monospacedDigit() }
        }
    }
}""", """struct ItemRow: View {
    let it: PayFacts.Item
    var food: Bool = false
    var body: some View {
        let count: String = (it.q ?? 1) > 1 ? String(it.q ?? 1) + " × " : ""
        let fig: Double? = it.amt ?? it.unit
        let back: Bool = it.ret != nil
        VStack(alignment: .leading, spacing: 2) {
            HStack(alignment: .firstTextBaseline, spacing: 8) {
                Text(count + it.n).font(.subheadline).lineLimit(2).strikethrough(back, color: .secondary).foregroundStyle(back ? Color.secondary : Color.primary)
                Spacer(minLength: 8)
                if let fig { Text(Fmt.rupees(fig) + (it.amt == nil ? " each" : "")).font(.subheadline).foregroundStyle(.secondary).monospacedDigit().strikethrough(back, color: .secondary) }
            }
            if let r = it.ret {
                Label((food ? "Refunded " : "Returned ") + Day.fmt(r, "d MMM") + (it.back.map { " · " + Fmt.rupees($0) + " back" } ?? ""), systemImage: "arrow.uturn.backward")
                    .font(.caption.weight(.semibold)).foregroundStyle(Color.green)
            }
        }
    }
}""", 'let back: Bool = it.ret != nil')
# the row in the ledger: what went back
sub('Kosh/Style.swift', """                } else if t.full != nil, let rest = SplitWords.rest(t, store) {""",
    """                } else if let gone = SplitWords.returned(t, store) {
                    HintLine(sym: "arrow.uturn.backward", text: gone)
                        .font(.caption).foregroundStyle(Color.green)
                        .padding(.leading, 48)
                        .privacySensitive()
                } else if t.full != nil, let rest = SplitWords.rest(t, store) {""", 'SplitWords.returned(t, store)')
code = open('Kosh/AutoSplit.swift').read()
if 'static func orders(_ items' not in code:
    code = code.rstrip()
    assert code.endswith('}')
    code = code[:-1] + '''    /// "Order 407-…" or "5 orders: 407-…, 407-…, 407-… +2"
    static func orders(_ items: [PayFacts.Item]) -> String? {
        var nos: [String] = []
        for it in items { if let o = it.o, !o.isEmpty, !nos.contains(o) { nos.append(o) } }
        guard !nos.isEmpty else { return nil }
        let head: String = nos.count == 1 ? "Order " : String(nos.count) + " orders: "
        let tail: String = nos.count > 3 ? " +" + String(nos.count - 3) : ""
        return head + nos.prefix(3).joined(separator: ", ") + tail
    }
    /// an order paid from a wallet and a card: "Order ₹3,414 · ₹3,000 Myntra Credit + ₹414 card"
    static func paidHow(_ t: Txn, _ store: Store) -> String? {
        if let uses = t.wu, !uses.isEmpty, let whole = t.ot {
            let parts: [String] = uses.map { Fmt.rupees($0.a) + " " + $0.w } + [Fmt.rupees(t.a) + " card"]
            return "Order " + Fmt.rupees(whole) + " · " + parts.joined(separator: " + ")
        }
        if let from = t.wf, let card = store.txn(from) {
            return "From " + t.card + " · " + Fmt.rupees(card.a) + " of the order on the card"
        }
        return nil
    }
    /// what of a payment went back: "Returned: RupeeRise 3 Pcs Mi Band 8 Strap"
    static func returned(_ t: Txn, _ store: Store) -> String? {
        let items: [PayFacts.Item] = (store.payFact(t)?.items ?? []).filter { $0.ret != nil }
        guard !items.isEmpty else { return nil }
        let food: Bool = t.c == "Food & Drinks" || t.c == "Groceries"
        return (food ? "Refunded: " : "Returned: ") + items.prefix(2).map { short($0.n) }.joined(separator: ", ") + (items.count > 2 ? " +" + String(items.count - 2) : "")
    }
}
'''
    open('Kosh/AutoSplit.swift', 'w').write(code)
print('swift U patched')
