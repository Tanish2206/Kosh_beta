#!/usr/bin/env python3
"""livebal-5nov (kosh ios app chat): what moves an account's live balance, found with tools/eval/live-bench.js and
live-diff.js against a year of real statements.
1. A payment whose paying account kosh only GUESSED (a CRED / app bill payment that never says which bank paid:
   "HDFC ••6150 (likely)") never moves a balance. The guess still shows on the payment; the account's own alert or
   statement line is what moves the balance. (HDFC carried 6 such card bills it never booked: −₹97,778.)
2. Your own transfer whose other end sent no alert: a debit that names the receiving account ("Beneficiary Account
   XX6150") on another account of the household puts the money into that account's balance, unless that account
   already has the credit (alert or statement line) within 3 days. Only the balance: no second row anywhere.
Idempotent. Run from kosh-beta/."""
import sys
def patch(p, pairs, marker):
    s = open(p, encoding='utf-8').read()
    if marker in s: print(p, 'already'); return
    for a, b in pairs:
        if s.count(a) != 1: sys.exit('%s anchor %d: %r' % (p, s.count(a), a[:60]))
        s = s.replace(a, b)
    open(p, 'w', encoding='utf-8').write(s); print(p, 'patched')
patch('Kosh/engine.js', [
 ("""    tx.forEach(function (t) {
      if (!t.card || t.partOf || !(t.dirRaw === 'in' || t.dirRaw === 'out')) return;
      var amt = t.full !== undefined ? t.full : t.a, vday = t.od || t.d;""",
  """    tx.forEach(function (t) {
      // (livebal-5nov) an account kosh only guessed paid it moves no balance
      if (!t.card || t.partOf || t.fromGuess || !(t.dirRaw === 'in' || t.dirRaw === 'out')) return;
      var amt = t.full !== undefined ? t.full : t.a, vday = t.od || t.d;"""),
 ("""    function settleBal(a, L) {""",
  """    /* (livebal-5nov) your own transfer whose other end told nothing: the debit names the receiving account, which is
       one of the household's (one account with those digits, not the sending one) and has no credit of that sum
       within 3 days: the money is in that account's balance. Only the ledger; no row is added */
    (function () {
      var txById = {};
      tx.forEach(function (t) { if (!(t.id in txById)) txById[t.id] = t; });
      used.forEach(function (r) {
        if (r.kind !== 'txn' || r.instr !== 'account' || r.dir !== 'out' || !(r.amt > 0) || !/^\\d{4}$/.test(String(r.toLast4 || ''))) return;
        var t = txById[r.id];
        if (!t || t.partOf || !t.card) return;
        var dest = accounts.filter(function (a) { return !a.dcard && !a.ccy && a.id !== t.card && String(a.last || '').slice(-4) === String(r.toLast4); });
        if (dest.length !== 1) return;
        var amt = t.full !== undefined ? t.full : t.a, vday = t.od || t.d, F = flowsOf[dest[0].id] || (flowsOf[dest[0].id] = []);
        if (F.some(function (f) { return f.s > 0 && Math.abs(f.s - amt) <= 1 && Math.abs(daysBetween(f.vday, vday)) <= 3; })) return;
        F.push({ id: 'mirror|' + t.id, s: amt, vday: vday, vat: vday + 'T' + (t.t || '00:00'), timed: !!t.t && !!printedTime[t.id], book: '' });
      });
    })();
    function settleBal(a, L) {"""),
], 'livebal-5nov')
