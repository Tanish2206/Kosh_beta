# kosh feedback 1 Nov (20:39) — Swift, part I: "How you shop" in Up close for Shopping — each kind of thing bought over
# the last nine months (engine snap.buys): how often, how much usually, from where, the latest items, the next one when
# the rhythm is steady. Idempotent.
def patch(F, pairs):
    p = 'Kosh/' + F; s = open(p).read()
    for a, b, mark in pairs:
        if mark in s: continue
        assert s.count(a) == 1, (F, a[:90], s.count(a)); s = s.replace(a, b)
    open(p, 'w').write(s)
patch('Snapshot.swift', [("""    var payFacts: PayFacts? = nil""", """    var payFacts: PayFacts? = nil
    /// how you shop: each kind of thing bought over the last nine months (engine.js › buyPatterns)
    var buys: [BuyPattern]? = nil""", "var buys: [BuyPattern]? = nil")])
patch('InsightsCompare.swift', [("""/// a shop's name from a payee as the bank printed it""", """/// one kind of thing you buy, over the last nine months: how many times, in all and usually, how often (every: the middle
/// gap in days; steady: most gaps near it), the shops, the latest items, the next one when steady
struct BuyPattern: Decodable, Hashable, Identifiable {
    let k: String; let n: Int; let total: Double; let usual: Double; let share: Double
    let shops: [String]; let last: String; let items: [String]
    var every: Int? = nil; var steady: Bool? = nil; var next: String? = nil
    var id: String { k }
    /// "every ~3 weeks", "about monthly", "every ~10 days"; nil with too few to tell
    var rhythm: String? {
        guard let e = every, e > 0 else { return nil }
        let pre: String = steady == true ? "every " : "roughly every "
        if e < 11 { return pre + String(e) + " days" }
        if e < 25 { return pre + String(Int((Double(e) / 7).rounded())) + " weeks" }
        if e < 45 { return steady == true ? "about monthly" : "roughly monthly" }
        return pre + String(Int((Double(e) / 30).rounded())) + " months"
    }
    /// the shops as people say them, each once
    var places: [String] {
        var out: [String] = []
        for s in shops { let c: String = ShopName.clean(s); if !out.contains(c) { out.append(c) } }
        return out
    }
}

/// a shop's name from a payee as the bank printed it""", "struct BuyPattern: Decodable")])
patch('InsightsBook.swift', [
("""                    // the payments behind the figure, in Find with the category and the months on""", """                    if cat == "Shopping", let buys = store.snap.buys, !buys.isEmpty {
                        HowYouShop(buys: buys, color: color, ink: ink, today: store.snap.today)
                            .padding(.top, 18)
                    }
                    // the payments behind the figure, in Find with the category and the months on""", "HowYouShop(buys: buys"),
("""/// one line of the breakdown, closed: name, count, figure, what's in it, and its bar""", """/// how you shop, over nine months whatever the range above: a line per kind of thing bought (the four biggest, the rest a
/// tap away) — how many times and how often, what it usually costs, where from, the latest thing, and when the next is
/// due when the rhythm is steady
private struct HowYouShop: View {
    let buys: [BuyPattern]
    let color: Color
    let ink: Color
    let today: String
    @Environment(\\.accessibilityReduceMotion) private var still
    @State private var all = false
    var body: some View {
        let shown: [BuyPattern] = all ? buys : Array(buys.prefix(4))
        VStack(alignment: .leading, spacing: 0) {
            HStack(alignment: .firstTextBaseline) {
                Text("How you shop").font(.subheadline.weight(.semibold))
                Spacer(minLength: 6)
                Text("last 9 months").font(.caption).foregroundStyle(.secondary)
            }
            .padding(.bottom, 4)
            ForEach(Array(shown.enumerated()), id: \\.element.id) { i, b in
                if i > 0 { InsightDivider() }
                BuyLine(b: b, color: color, ink: ink, today: today)
            }
            if buys.count > 4 {
                Button { withAnimation(still ? nil : Motion.open) { all.toggle() } } label: {
                    Text(all ? "Fewer" : "All " + String(buys.count) + " kinds").font(.footnote.weight(.semibold)).foregroundStyle(ink)
                        .frame(maxWidth: .infinity, minHeight: 36)
                }
                .buttonStyle(.press)
            }
        }
        .padding(14)
        .background(color.opacity(0.07), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
    }
}

private struct BuyLine: View {
    let b: BuyPattern
    let color: Color
    let ink: Color
    let today: String
    var body: some View {
        let times: String = b.n == 1 ? "once" : String(b.n) + " times"
        let head: String = [times, b.rhythm ?? "", "usually " + Fmt.short(b.usual)].filter { !$0.isEmpty }.joined(separator: " · ")
        let from: String = b.places.prefix(2).joined(separator: ", ")
        let latest: String = b.items.first.map { "last: " + $0 } ?? ("last " + Day.fmt(b.last, b.last.prefix(4) == today.prefix(4) ? "d MMM" : "d MMM yy"))
        VStack(alignment: .leading, spacing: 3) {
            HStack(alignment: .firstTextBaseline, spacing: 6) {
                Text(b.k).font(.subheadline.weight(.semibold))
                Spacer(minLength: 6)
                Text(Fmt.pct(b.share)).font(.system(.footnote, design: .rounded, weight: .semibold)).monospacedDigit().foregroundStyle(ink)
            }
            Text(head).font(.footnote).foregroundStyle(.secondary).monospacedDigit().lineLimit(1).minimumScaleFactor(0.85)
            Text((from.isEmpty ? "" : from + " · ") + latest).font(.caption).foregroundStyle(.secondary).lineLimit(1)
            if let nx = b.next {
                Text("Next likely around " + Day.fmt(nx, "d MMM")).font(.caption.weight(.semibold)).foregroundStyle(ink)
            }
        }
        .padding(.vertical, 9)
        .privacySensitive()
        .accessibilityElement(children: .combine)
    }
}

/// one line of the breakdown, closed: name, count, figure, what's in it, and its bar""", "private struct HowYouShop: View"),
])
print('swift I patched')
