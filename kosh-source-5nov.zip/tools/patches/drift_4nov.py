#!/usr/bin/env python3
"""drift-4nov + punct-4nov + texts (statements chat, 4 Nov) - Swift, in place:
 Documents.swift drift-4nov: on this iOS, PDFKit's letter boxes are counted without the page text's line breaks for
   many PDFs, so every line's last letters landed on the next line ("MRIDUL BHUTAN" | "I") on the phone: per page,
   DocText.countsWithoutBreaks picks the counting that keeps words whole. extractor 3 -> 4.
 DocLayout.swift punct-4nov: lines are made of letters and figures; commas, full stops and small marks join the line
   they sit within (", ." under "3 690 10"), lines output top to bottom.
 LiveSession+Extras.swift (DEBUG only): diagnostics' stmtTexts = each sender's newest statement's kept text, so
   tools/eval/phone-bench.js reads exactly what the phone reads (_corpus/stmts/phone-texts/texts.json, private).
 LiveSession+Statements.swift statementReader 13."""
