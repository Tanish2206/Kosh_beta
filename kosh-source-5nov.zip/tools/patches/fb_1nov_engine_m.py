# kosh feedback 2 Nov (01:42) — engine, part M: one purchase, one row, for every shop. Whatever the shop and however
# its mail is worded, a payment told by two sources is one: (1) two rows naming the same order number are one order;
# (2) the same shop, the same sum, within two days, where one of them is a shop's or an app's own mail (a receipt, a
# booking, an invoice) or a statement's line rather than the bank's or card's own alert, is one payment (MakeMyTrip's
# ₹8,259 booking and the card's line for it). The bank's or card's own row stays, and takes the other's order number
# and name; two of the bank's own alerts for the same sum stay two (two real purchases). Idempotent.
p = 'Kosh/engine.js'; s = open(p).read()
old = """    tx = tx.concat(extra);
"""
new = """    tx = tx.concat(extra);
    /* GUARDRAIL one purchase, one row, whoever told it: rows of the same order number are one; the same shop and sum
       within two days, one of them not the bank's or card's own alert (a shop's or app's mail, a statement's line), are
       one. The alert's row stays */
    (function () {
      var recOf = {};
      merged.forEach(function (r) { if (r && r.id) recOf[r.id] = r; });
      var own = function (t) { var r = recOf[t.id] || {}; return r.kind === 'txn' && !r.fromReceipt && !r.fromStmt && /^(?:bank|card|wallet)$/.test(r.instKind || '') && r.src !== 'statement'; };
      var shopKey = function (t) {
        var w = String((t.py || '') + ' ' + (t.m || '')).toLowerCase().replace(/[^a-z ]+/g, ' ').split(/\\s+/)
          .filter(function (x) { return x.length >= 4 && !/^(?:bank|card|credit|debit|payment|paid|limited|private|india|online|services?|technologies|retail|pvt|ltd|upi|money|transfer|amount|spent|towards|newdelhi|mumbai|bangalore|gurgaon|delhi)$/.test(x); });
        return w[0] || '';
      };
      var oidOf = function (t) { var r = recOf[t.id] || {}; return String(t.orderId || r.orderId || '').toUpperCase().replace(/[^A-Z0-9]/g, ''); };
      var outs = tx.filter(function (t) { return t.dirRaw === 'out' && !t.partOf && t.a > 0; });
      var gone = {};
      var fold = function (keep, drop) {
        gone[drop.id] = 1;
        keep.told = (keep.told || []).concat([drop.id]).concat(drop.told || []);
        var oid = oidOf(drop); if (oid && !keep.orderId) keep.orderId = oid;
        if (!keep.rc && drop.rc) keep.rc = drop.rc;
      };
      // (1) the same order number
      var byOid = {};
      outs.forEach(function (t) { var k = oidOf(t); if (k.length >= 5) (byOid[k] = byOid[k] || []).push(t); });
      Object.keys(byOid).forEach(function (k) {
        var g = byOid[k].filter(function (t) { return !gone[t.id]; });
        if (g.length < 2) return;
        g.sort(function (a, b) { return (own(b) ? 1 : 0) - (own(a) ? 1 : 0) || b.a - a.a; });
        g.slice(1).forEach(function (t) { if (!own(t) || !own(g[0])) fold(g[0], t); });
      });
      // (2) the same shop and sum within two days, one of them not the bank's own alert
      var byShop = {};
      outs.forEach(function (t) { if (gone[t.id]) return; var k = shopKey(t); if (k) (byShop[k] = byShop[k] || []).push(t); });
      Object.keys(byShop).forEach(function (k) {
        var g = byShop[k].sort(function (a, b) { return a.d < b.d ? -1 : a.d > b.d ? 1 : 0; });
        for (var i = 0; i < g.length; i++) for (var j = i + 1; j < g.length; j++) {
          var a = g[i], b = g[j];
          if (gone[a.id] || gone[b.id]) continue;
          if (daysBetween(a.d, b.d) > 2) break;
          if (Math.abs(a.a - b.a) > 1) continue;
          var oa = own(a), ob = own(b);
          if (oa && ob) continue;
          var oa1 = oidOf(a), ob1 = oidOf(b);
          if (oa1 && ob1 && oa1 !== ob1) continue;
          // (neither the bank's own: the one that says how it was paid stays: a payment app's or wallet's receipt over a
          // statement line over a shop's booking or invoice)
          var rank = function (t) { var r = recOf[t.id] || {}; return own(t) ? 4 : (/^(?:paid-to-shop|wallet-paid|bill-paid)$/.test(r.rule || '') || r.instr === 'wallet' || t.via) ? 3 : r.src === 'statement' ? 2 : 1; };
          var ra = rank(a), rb = rank(b);
          if (ra > rb || (ra === rb && a.d <= b.d)) fold(a, b); else fold(b, a);
        }
      });
      if (Object.keys(gone).length) tx = tx.filter(function (t) { return !gone[t.id]; });
    })();
"""
if 'GUARDRAIL one purchase, one row, whoever told it' not in s:
    assert s.count(old) == 1, 'engine M anchor'
    s = s.replace(old, new)
open(p, 'w').write(s)
print('engine M patched')
