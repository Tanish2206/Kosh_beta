# kosh feedback 1 Nov (21:43) — engine, part B: an order paid in part from a balance (Amazon Pay balance / gift card)
# is still that order: the ₹13,039.71 card charge of 5 Jul is the ₹15,760.72 order with the Native Lock Pro in it,
# ₹2,721 of it from the balance. When no order matches the charge exactly, the one order of the same shop, placed
# within a day, whose total is above the charge and the charge at least 40% of it. Idempotent.
p = 'Kosh/engine.js'; s = open(p).read()
OLD = """        return hit.length === 1 ? hit[0] : null;
      }"""
NEW = """        if (hit.length === 1) return hit[0];
        if (hit.length) return null;
        // (part-paid from a balance: the shop's one order that day whose total the charge is most of)
        var part = list.filter(function (O) { return !orderTaken[O.no] && Math.abs(pfN(O.day) - d) <= 1 && O.totals.some(function (v) { return v > t.a + tol && t.a >= v * 0.4; }); });
        return part.length === 1 ? part[0] : null;
      }"""
if '(part-paid from a balance' not in s:
    assert s.count(OLD) == 1, 'orderFor anchor'
    s = s.replace(OLD, NEW)
open(p, 'w').write(s)
print('engine B patched')

# a smart lock, a video doorbell, a camera for the home: Smart home, a kind of its own (ahead of Electronics, whose
# "camera" would take it); and an order's kind goes by where the money went when its lines carry amounts (a ₹14,999
# lock beats a ₹286 remote and a ₹399 cord)
s = open(p).read()
OLD = "    var BUY_KINDS = [\n"
NEW = "    var BUY_KINDS = [\n      ['Smart home', /\\b(?:smart (?:door )?locks?|door locks?|digital locks?|video door ?bells?|door ?bells?|cctv|security cameras?|home cameras?|smart plugs?|smart bulbs?|smart switch(?:es)?|alexa|echo dot|google (?:home|nest)|robot (?:vacuum|cleaner)|robotic vacuum)\\b/i],\n"
if "['Smart home', /" not in s:
    assert s.count(OLD) == 1, 'BUY_KINDS anchor'
    s = s.replace(OLD, NEW)
OLD = "'Kids', 'Games & toys', 'Books & stationery', 'Appliances', 'Sports gear']]"
if "'Smart home', 'Kids', 'Games & toys'" not in s:
    assert s.count(OLD) == 1, 'taxonomy anchor'
    s = s.replace(OLD, "'Smart home', 'Kids', 'Games & toys', 'Books & stationery', 'Appliances', 'Sports gear']]")
OLD = """      var by = {}, first = '';
      (items || []).forEach(function (it) { var k = kindOfItem(it && it.n) || itemKinds[itemKey(it && it.n)] || ''; if (k) { by[k] = (by[k] || 0) + 1; if (!first) first = k; } });"""
NEW = """      var by = {}, first = '';
      var priced = (items || []).length > 1 && (items || []).every(function (it) { return it && +it.amt > 0; });
      (items || []).forEach(function (it) { var k = kindOfItem(it && it.n) || itemKinds[itemKey(it && it.n)] || ''; if (k) { by[k] = (by[k] || 0) + (priced ? +it.amt : 1); if (!first) first = k; } });"""
if 'var priced = (items' not in s:
    assert s.count(OLD) == 1, 'kindOfItems anchor'
    s = s.replace(OLD, NEW)
# an order's lines keep their amounts, so the payment matched to it by total carries them
OLD = """            names.forEach(function (n) { n = String(n || '').trim(); if (n && O.items.indexOf(n) < 0) { O.items.push(n); if (O.mail !== mid && O.items.length === 1) O.mail = mid; } });"""
NEW = """            names.forEach(function (n) { n = String(n || '').trim(); if (n && O.items.indexOf(n) < 0) { O.items.push(n); if (O.mail !== mid && O.items.length === 1) O.mail = mid; } });
            if (Array.isArray(e.lines)) e.lines.forEach(function (l) { if (l && l.n && +l.amt > 0) (O.amt = O.amt || {})[String(l.n).trim()] = +l.amt; });"""
if '(O.amt = O.amt || {})' not in s:
    assert s.count(OLD) == 1, 'order lines anchor'
    s = s.replace(OLD, NEW)
OLD = "f.items = byTotal.items.slice(0, 12).map(function (n) { return { n: n }; });"
NEW = "f.items = byTotal.items.slice(0, 12).map(function (n) { var o = { n: n }; if (byTotal.amt && byTotal.amt[n] > 0) o.amt = byTotal.amt[n]; return o; });"
if 'if (byTotal.amt && byTotal.amt[n] > 0)' not in s:
    assert s.count(OLD) == 1, 'byTotal items anchor'
    s = s.replace(OLD, NEW)
open(p, 'w').write(s)
print('engine B smart home')

# reader: a marketplace's item whose name is itself split by bars ("Native Lock Pro by Urban Company | Smart Door Lock
# with … | Free Installation") over "Quantity: 1", and the line's figure printed after it as "14999 INR"
p = 'Kosh/reader.js'; s = open(p).read()
OLD = """      if (cells.length <= 2 && qm && lineName(cells[0]) && !lineName(nx.slice(0, qm.index).replace(/[|\\s]+$/, ''))) {"""
NEW = """      // (a name with bars of its own and no figure on its line is one name: "Native Lock Pro | Smart Door Lock | …")
      if (cells.length > 2 && qm && !/\\d[\\d,]*(?:\\.\\d{1,2})?\\s*(?:₹|rs\\.?|inr)?\\s*$/i.test(cells[cells.length - 1]) && !lineAmt(line) && lineName(cells[0])) cells = [cells.join(' | ')];
      // (a marketplace's long product name over its count is still its name: the first 118 letters of it)
      if (cells.length <= 2 && qm && cells[0].length > 120 && !lineAmt(cells[0])) cells[0] = cells[0].slice(0, 118);
      if (cells.length <= 2 && qm && lineName(cells[0]) && !lineName(nx.slice(0, qm.index).replace(/[|\\s]+$/, ''))) {"""
if '(a name with bars of its own' not in s:
    assert s.count(OLD) == 1, 'reader name-line anchor'
    s = s.replace(OLD, NEW)
OLD = """        if (!unitP && !rest && /^(?:unit price|price|selling price|rate)\\b/i.test(nx2)) unitP = lineAmt(nx2);"""
NEW = OLD + """
        // ("286 INR" on the line after the count: the line's figure)
        var sfx = /^(\\d[\\d,]*(?:\\.\\d{1,2})?)\\s*(?:inr|₹|rs\\.?)$/i.exec(nx2);
        if (!unitP && !rest && sfx) rest = num(sfx[1]);"""
if '("286 INR" on the line after' not in s:
    assert s.count(OLD) == 1, 'reader suffix anchor'
    s = s.replace(OLD, NEW)
open(p, 'w').write(s)
print('reader lines patched')

# an order's kind by where the money went once two or more of its lines carry amounts; and a later mail's shortened
# name of an item already listed ("Original Remote Control Compatible for...") is that item, not another
p = 'Kosh/engine.js'; s = open(p).read()
OLD = "      var priced = (items || []).length > 1 && (items || []).every(function (it) { return it && +it.amt > 0; });"
NEW = "      var priced = (items || []).filter(function (it) { return it && +it.amt > 0; }).length >= 2;"
if NEW not in s:
    assert s.count(OLD) == 1, 'priced anchor'
    s = s.replace(OLD, NEW)
OLD = "by[k] = (by[k] || 0) + (priced ? +it.amt : 1);"
NEW = "by[k] = (by[k] || 0) + (priced ? (+it.amt || 0) : 1);"
if NEW not in s:
    assert s.count(OLD) == 1, 'weight anchor'
    s = s.replace(OLD, NEW)
OLD = "names.forEach(function (n) { n = String(n || '').trim(); if (n && O.items.indexOf(n) < 0) {"
NEW = "names.forEach(function (n) { n = String(n || '').trim(); var cut = n.replace(/(?:\\.{3}|…)$/, '').trim(); if (cut !== n && O.items.some(function (x) { return x.indexOf(cut) === 0; })) return; if (n && O.items.indexOf(n) < 0) {"
if 'var cut = n.replace(' not in s:
    assert s.count(OLD) == 1, 'names anchor'
    s = s.replace(OLD, NEW)
open(p, 'w').write(s)
print('engine B weights')

# (the order's dearest thing first: "Native Lock Pro…", not the ₹286 remote that came with it)
s = open(p).read()
OLD = "f.items = byTotal.items.slice(0, 12).map(function (n) { var o = { n: n }; if (byTotal.amt && byTotal.amt[n] > 0) o.amt = byTotal.amt[n]; return o; });"
NEW = "f.items = byTotal.items.slice(0, 12).map(function (n) { var o = { n: n }; if (byTotal.amt && byTotal.amt[n] > 0) o.amt = byTotal.amt[n]; return o; }).sort(function (x, y) { return (y.amt || 0) - (x.amt || 0); });"
if NEW not in s:
    assert s.count(OLD) == 1, 'sort anchor'
    s = s.replace(OLD, NEW)
open(p, 'w').write(s)

# one charge for several orders of one mail (Amazon's "Ordered: … and 4 more items": five orders, one card charge of
# ₹2,619 against their ₹2,909, the rest from a balance): those orders together, every item with its price
s = open(p).read()
OLD = """        var part = list.filter(function (O) { return !orderTaken[O.no] && Math.abs(pfN(O.day) - d) <= 1 && O.totals.some(function (v) { return v > t.a + tol && t.a >= v * 0.4; }); });
        return part.length === 1 ? part[0] : null;"""
NEW = """        var part = list.filter(function (O) { return !orderTaken[O.no] && Math.abs(pfN(O.day) - d) <= 1 && O.totals.some(function (v) { return v > t.a + tol && t.a >= v * 0.4; }); });
        if (part.length === 1) return part[0];
        // (a mail's orders together: their totals add up to the charge, or a balance paid a little of them)
        var byMail = {};
        list.forEach(function (O) { if (!orderTaken[O.no] && Math.abs(pfN(O.day) - d) <= 1 && O.totals.length) (byMail[O.mail] = byMail[O.mail] || []).push(O); });
        var groups = Object.keys(byMail).map(function (k) { return byMail[k]; }).filter(function (os) {
          if (os.length < 2) return false;
          var sum = os.reduce(function (s0, O) { return s0 + Math.max.apply(null, O.totals); }, 0);
          return t.a <= sum + tol && t.a >= sum * 0.75;
        });
        if (groups.length !== 1) return null;
        var os = groups[0], G = { no: os.map(function (O) { return O.no; }).join('+'), shop: os[0].shop, totals: [t.a], day: os[0].day, items: [], mail: os[0].mail, amt: {}, nos: os.map(function (O) { return O.no; }) };
        os.forEach(function (O) { O.items.forEach(function (n) { if (G.items.indexOf(n) < 0) G.items.push(n); }); Object.keys(O.amt || {}).forEach(function (n) { G.amt[n] = O.amt[n]; }); });
        return G;"""
if "(a mail's orders together" not in s:
    assert s.count(OLD) == 1, 'orderFor group anchor'
    s = s.replace(OLD, NEW)
OLD = "if (byTotal) { orderTaken[byTotal.no] = 1;"
NEW = "if (byTotal) { orderTaken[byTotal.no] = 1; (byTotal.nos || []).forEach(function (no) { orderTaken[no] = 1; });"
if '(byTotal.nos || []).forEach' not in s:
    assert s.count(OLD) == 1, 'orderTaken anchor'
    s = s.replace(OLD, NEW)
open(p, 'w').write(s)
print('engine B grouped orders')

# (a payment split by its items is matched to its order by the whole charge, not its rest)
s = open(p).read()
OLD = """      function orderFor(t, shopName) {
        var list = ordersByShop[pfKey(shopName)] || [];"""
NEW = """      function orderFor(t, shopName) {
        if (t.full > t.a) t = { d: t.d, a: t.full };
        var list = ordersByShop[pfKey(shopName)] || [];"""
if 'if (t.full > t.a) t = { d: t.d, a: t.full };' not in s:
    assert s.count(OLD) == 1, 'orderFor full anchor'
    s = s.replace(OLD, NEW)
open(p, 'w').write(s)
print('engine B full')

# (an order another payment pays to the rupee, within two days, is that payment's: never a part-paid match of this one)
s = open(p).read()
OLD = """        var part = list.filter(function (O) { return !orderTaken[O.no] && Math.abs(pfN(O.day) - d) <= 1 && O.totals.some(function (v) { return v > t.a + tol && t.a >= v * 0.4; }); });"""
NEW = """        var exactly = function (O) { return (ctx.tx || []).some(function (x) { var xa = x.full > x.a ? x.full : x.a; return x.dirRaw === 'out' && !x.partOf && x.d !== t.d0 && Math.abs(pfN(x.d) - pfN(O.day)) <= 2 && O.totals.some(function (v) { return Math.abs(v - xa) <= Math.max(1, v * 0.005); }); }); };
        var part = list.filter(function (O) { return !orderTaken[O.no] && Math.abs(pfN(O.day) - d) <= 1 && O.totals.some(function (v) { return v > t.a + tol && t.a >= v * 0.4; }) && !exactly(O); });"""
if 'var exactly = function (O)' not in s:
    assert s.count(OLD) == 1, 'part exact anchor'
    s = s.replace(OLD, NEW)
open(p, 'w').write(s)
print('engine B exact first')
