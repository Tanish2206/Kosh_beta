# kosh feedback 1 Nov (19:10) — Swift, part E: Chapters' list button and found-in-mail pill open the timeline of them
# all (it was the plain list, TripsPage, so a live chapter never showed on a timeline); with a chapter of your own the
# samples stay off the timeline. Idempotent.
p = 'Kosh/Chapters.swift'; s = open(p).read()
def sub(a, b, mark):
    global s
    if mark in s: return
    assert s.count(a) == 1, (a[:90], s.count(a)); s = s.replace(a, b)
sub("""open: { id in store.push(.chapter(id)) }, demo: { showDemo = true }, list: { store.push(.trips) })""",
    """open: { id in store.push(.chapter(id)) }, demo: { showDemo = true }, list: { store.push(.chapter(ChaptersAll.id)) })""",
    "list: { store.push(.chapter(ChaptersAll.id)) })")
sub("""                        if drafts.count == 1 { draftOpen = first } else { store.push(.trips) }""",
    """                        if drafts.count == 1 { draftOpen = first } else { store.push(.chapter(ChaptersAll.id)) }""",
    "else { store.push(.chapter(ChaptersAll.id)) }")
sub("""    var body: some View {
        let items: [Chapter] = store.chapterItems(samples: samples)
        let today: String = store.snap.today""", """    /// the samples show only until there is a chapter of your own: then the timeline is yours alone
    var withSamples: Bool { samples && store.trips.isEmpty }

    var body: some View {
        let showSamples: Bool = withSamples
        let items: [Chapter] = store.chapterItems(samples: showSamples)
        let today: String = store.snap.today""", "var withSamples: Bool")
sub('''                } else if samples {
                    Hairline().padding(.top, 22)
                    MailNotice''', '''                } else if showSamples {
                    Hairline().padding(.top, 22)
                    MailNotice''', "} else if showSamples {")
sub('''                if samples {
                    Text("Chapters marked Sample''', '''                if showSamples {
                    Text("Chapters marked Sample''', "if showSamples {\n                    Text(")
open(p, 'w').write(s)
print('swift E patched')
