# kosh feedback 1 Nov (22:42) — Swift, part R: Insurance. (1) "By kind" tiles open their own kind: Savings plans,
# Term life and ULIP each a page of their own policies (they all opened the same Life page). (2) A policy with no plan
# name is "Bajaj Life policy", never "Bajaj Life life". (3) A motor policy is called by its vehicle ("Triumph
# Scrambler 400 X") when kosh read it, the plan beneath. Idempotent.
def sub(path, old, new, mark):
    s = open(path).read()
    if mark in s: return
    assert s.count(old) == 1, (path, old[:70], s.count(old))
    open(path, 'w').write(s.replace(old, new))
P = 'Kosh/InsuranceObsidian.swift'
sub(P, "Button { store.push(.cover(InsLook.part(k.kind))) } label: {",
       "Button { store.push(.cover(InsLook.part(k.kind) == \"Life\" ? \"Life:\" + k.kind.rawValue : InsLook.part(k.kind))) } label: {",
       '"Life:" + k.kind.rawValue')
P = 'Kosh/InsurancePages.swift'
sub(P, """                case "Life": LifePage().navigationTitle("Life")""",
       """                case "Life": LifePage().navigationTitle("Life")
                case "Life:term": LifePage(only: .term).navigationTitle("Term life")
                case "Life:savings": LifePage(only: .savings).navigationTitle("Savings plans")
                case "Life:ulip": LifePage(only: .ulip).navigationTitle("ULIP")""", 'case "Life:term"')
sub(P, """        case "Life": return Obsidian.term
        default: return Obsidian.savings""", """        case "Life", "Life:term": return Obsidian.term
        case "Life:ulip": return Obsidian.ulip
        default: return Obsidian.savings""", 'case "Life", "Life:term"')
sub(P, """struct LifePage: View {
    @Environment(Store.self) private var store
    var body: some View {
        let pols: [Policy] = InsBook.rows(store.policies, "Life")""", """struct LifePage: View {
    @Environment(Store.self) private var store
    /// one kind of life cover only (a tile of By kind): term, savings or ULIP
    var only: InsKind? = nil
    var body: some View {
        let all: [Policy] = InsBook.rows(store.policies, "Life")
        let pols: [Policy] = only.map { k in all.filter { InsKind.of($0) == k } } ?? all""", 'var only: InsKind? = nil')
P = 'Kosh/InsuranceBook.swift'
sub(P, """        let plan: String = p.plan ?? ""
        return plan.isEmpty ? p.insurer + " " + PolicyKinds.title(PolicyKinds.of(p)).lowercased() : plan""",
       """        let plan: String = p.plan ?? ""
        // (a motor policy by its vehicle, when kosh read it: "Triumph Scrambler 400 X")
        if let m = p.model, !m.isEmpty, InsKind.of(p) == .motor { return m }
        if !plan.isEmpty { return plan }
        // (no plan named: "Bajaj Life policy", never "Bajaj Life life")
        let kind: String = PolicyKinds.title(PolicyKinds.of(p)).lowercased()
        return p.insurer.lowercased().contains(kind) || kind.isEmpty ? p.insurer + " policy" : p.insurer + " " + kind""", '(no plan named: "Bajaj Life policy"')
P = 'Kosh/Snapshot.swift'
s = open(P).read()
if 'var model: String? = nil   // a motor policy' not in s:
    import re
    i = s.index('struct Policy:')
    j = s.index('{', i) + 1
    s = s[:j] + '\n    var model: String? = nil   // a motor policy\'s vehicle, as its mail names it (fb 1 Nov)' + s[j:]
    open(P, 'w').write(s)
print('swift R patched')

# 34: a policy's mail kosh read before it opened policy papers (Acko's 2024 "Your Bike Insurance Policy for …" with
# its PDF) has no paper on it and no sealed copy, so no re-read ever looked for one: every insurer's or policy mail
# without a paper is read again, from the inbox when it isn't sealed, so its PDF is found and opened (IDV, vehicle,
# number, nominee). And a vehicle carries its make and model.
P = 'Kosh/LiveSession+Reread.swift'
s = open(P).read()
if 'if was < 34 {' not in s:
    import re
    m = re.search(r'static let rulesVersion = (\d+)', s)
    if m and int(m.group(1)) < 34:
        s = s.replace(m.group(0), 'static let rulesVersion = 34')
    old = """        do {
            // every time the rules learn a new way of writing an alert:"""
    assert s.count(old) == 1, 'reread anchor'
    s = s.replace(old, """        if was < 34 {
            idx += records.indices.filter { i in
                let r = records[i]
                return r.doc == nil && (r.kind == "policy" || (r.instKind ?? "") == "insurer")
            }
        }
""" + old)
    open(P, 'w').write(s)
sub('Kosh/Snapshot.swift', """    var why: String? = nil; var coverType: String? = nil; var addOns: [String]? = nil
}""", """    var why: String? = nil; var coverType: String? = nil; var addOns: [String]? = nil
    /// its make and model, as its policy's mail names it ("Triumph Scrambler 400 X")
    var model: String? = nil
}""", 'as its policy\'s mail names it ("Triumph Scrambler 400 X")')
print('swift R 34')
sub('Kosh/InsurancePages.swift', """                    if v.reg.isEmpty {
                        Text("A vehicle kosh can't name yet").font(.title3.weight(.bold)).fixedSize(horizontal: false, vertical: true)
                    } else {""", """                    if v.reg.isEmpty, let model = v.model, !model.isEmpty {
                        Text(model).font(.title3.weight(.bold)).fixedSize(horizontal: false, vertical: true)
                    } else if v.reg.isEmpty {
                        Text("A vehicle kosh can't name yet").font(.title3.weight(.bold)).fixedSize(horizontal: false, vertical: true)
                    } else {""", 'if v.reg.isEmpty, let model = v.model, !model.isEmpty {')
print('swift R vehicle name')
# a policy's life in years, rounded: 08 Jun 2024 – 07 Jun 2029 is 5 years, not 4 (the day before the anniversary)
sub('Kosh/InsurancePolicy.swift', """        let years: Int = InsDay.span(page.lifeFrom, page.lifeTo).years""",
    """        let sp = InsDay.span(page.lifeFrom, page.lifeTo.count >= 10 ? Day.add(page.lifeTo, 1) : page.lifeTo)
        let years: Int = sp.years + (sp.months >= 6 ? 1 : 0)""", 'let sp = InsDay.span(page.lifeFrom, page.lifeTo.count')
print('swift R years')

# 35: any sender's mail whose subject says a policy, an invoice, a receipt or a statement and has no paper opened
# (CRED garage's "ICICI policy issued", a payment app's invoice): read again, from the inbox when not sealed, so the
# wider paper rules (engine › docWanted) find and open its PDF
P = 'Kosh/LiveSession+Reread.swift'
s = open(P).read()
if 'if was < 35 {' not in s:
    s = s.replace('static let rulesVersion = 34', 'static let rulesVersion = 35')
    old = """        if was < 34 {"""
    assert s.count(old) == 1, 'reread 35 anchor'
    s = s.replace(old, """        if was < 35 {
            let paperish = #"(?i)polic(?:y|ies)|insurance|invoice|receipt|statement|certificate|schedule"#
            idx += records.indices.filter { i in
                let r = records[i]
                return r.doc == nil && (r.subject ?? "").range(of: paperish, options: .regularExpression) != nil
            }
        }
""" + old)
    open(P, 'w').write(s)
print('swift R 35')
