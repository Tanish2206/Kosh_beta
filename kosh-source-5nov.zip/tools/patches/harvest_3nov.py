#!/usr/bin/env python3
"""harvest-3nov: kosh gathers the details a statement password is made of from EVERY money mail and EVERY paper it
opens (an insurer's policy prints the date of birth, a CAS prints the PAN, a bank statement prints the Customer ID and
mobile), per the person the paper names, and gives every still-locked paper another try when it learns something.
Before: only the mail of a statement that was already locked was read for them, once. Run from kosh-beta/."""
import sys
def patch(p, pairs):
    s = open(p, encoding='utf-8').read()
    for old, new in pairs:
        c = s.count(old)
        if c != 1: sys.exit('%s: anchor %d times: %r' % (p, c, old[:70]))
        s = s.replace(old, new)
    open(p, 'w', encoding='utf-8').write(s)

patch('Kosh/engine.js', [
 # a CRN is a number: "CRN to log in", "CRN as …" was read as the CRN ("enter", "as")
 ("""    if ((m = /\\bcrn\\s*(?:number|no\\.?)?\\s*[:#\\-]?\\s*([A-Za-z0-9]{6,20})\\b/i.exec(flat))) {""",
  """    if ((m = /\\bcrn\\s*(?:number|no\\.?)?\\s*[:#\\-]?\\s*(\\d{6,20})\\b/i.exec(flat))) {"""),
 # a mobile number printed in full beside its label (a masked one is not a fact), the paper's holder's
 ("""    if ((m = /\\b(?:pin\\s*code|postal\\s+code)\\s*[:\\-]?\\s*(\\d{6})\\b/i.exec(flat))) out.pin = m[1];
    return out;""",
  """    if ((m = /\\b(?:pin\\s*code|postal\\s+code)\\s*[:\\-]?\\s*(\\d{6})\\b/i.exec(flat))) out.pin = m[1];
    var mobRe = /\\b(?:registered\\s+)?mobile(?:\\s+(?:no\\.?|number))?(?:\\s+for\\s+sms)?\\s*[:#\\-]?\\s*(?:\\+?91[\\s-]?)?([6-9]\\d{9})\\b/gi;
    while ((m = mobRe.exec(flat))) { if (theirs(m.index)) { out.mobile = m[1]; break; } }
    return out;"""),
])

patch('Kosh/Papers.swift', [
 ("""var dob: String? = nil; var pin: String? = nil }""", """var dob: String? = nil; var pin: String? = nil; var mobile: String? = nil }"""),
 ("""        if p.pin.isEmpty, let v = f.pin, !v.isEmpty { p.pin = v; changed = true }""",
  """        if p.pin.isEmpty, let v = f.pin, !v.isEmpty { p.pin = v; changed = true }
        if p.mobile.isEmpty, let v = f.mobile, v.count == 10 { p.mobile = v; changed = true }"""),
 ("""    /// a first name and a surname at least""",
  """    /// HARVEST (3 Nov): every money mail kosh keeps and every paper it has opened, read once per version for the details
    /// a password is made of (harvestPasswordFacts decides whose each is, by the name it prints). An insurer's policy
    /// prints the date of birth, a CAS the PAN, a bank's statement the Customer ID and the mobile: any one of them opens
    /// the rest. Before, only a locked statement's own mail was read, once. Returns true when anything new was learnt.
    static let harvestV = 1
    @MainActor
    func harvestFromEverything() -> Bool {
        guard ud.integer(forKey: "pw.harvestV") < Self.harvestV else { return false }
        var learnt = false
        let moneyKinds: Set<String> = ["bank", "card", "wallet", "insurer", "amc", "broker", "depository", "fund", "investment", "insurance", "lender"]
        for r in records {
            let domain: String = SenderPasswords.domain(r.from ?? "")
            let money: Bool = r.doc != nil || moneyKinds.contains((r.instKind ?? "").lowercased()) || r.kind == "policy" || r.kind == "investment" || r.kind == "statement"
            guard money, !domain.isEmpty else { continue }
            if let m = MailVault.get(r.id), harvestPasswordFacts(text: m.text, html: m.html, inbox: r.acct ?? "", domain: domain) { learnt = true }
            if let d = r.doc, d.state == "read", let kept = MailVault.getText(Self.docTextKey(d)) {
                if harvestPasswordFacts(text: String(DocText.split(kept).body.prefix(20000)), html: "", inbox: d.acct, domain: domain) { learnt = true }
            }
        }
        ud.set(Self.harvestV, forKey: "pw.harvestV")
        if learnt { note("harvest: new details learnt from the mail and papers") }
        return learnt
    }

    /// a first name and a surname at least"""),
])

patch('Kosh/LiveSession+Statements.swift', [
 # every paper opened is read for the details too, and what it teaches opens the papers still locked
 ("""            case .opened(let text):
                let part: Bool""",
  """            case .opened(let text):
                if harvestPasswordFacts(text: String(DocText.split(text).body.prefix(20000)), html: "", inbox: d.acct, domain: SenderPasswords.domain(d.from)) { harvestedNew = true }
                let part: Bool"""),
 ("""        defer { readingDocs = false; KeepGoing.shared.end(); Task { @MainActor in await self.exportStatementsOnce() } }""",
  """        defer {
            readingDocs = false; KeepGoing.shared.end()
            // details learnt from what was read (a policy's date of birth, a statement's Customer ID): the locked ones get another try
            let again: Bool = harvestedNew
            harvestedNew = false
            Task { @MainActor in
                if again, !self.unlocking { _ = await self.openLockedWithProfile() }
                await self.exportStatementsOnce()
            }
        }
        if harvestFromEverything() { harvestedNew = true }"""),
])
# (LiveSession.swift: `@ObservationIgnored var harvestedNew = false` after unlockAgain — applied by hand on 3 Nov)
