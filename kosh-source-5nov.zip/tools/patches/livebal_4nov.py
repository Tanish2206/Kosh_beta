#!/usr/bin/env python3
"""livebal-4nov (kosh ios app chat): every account's balance is LIVE — for every bank and wallet alike, the latest
balance kosh was told (a statement's closing, an alert's, a balance mail's, one typed) is carried forward by every
payment after it, whether or not an earlier stretch added up. User: "kosh should calibrate from the statement and adjust
all spends after it to show the most real-time balance" (HDFC showed the Oct closing 82,917 instead of 81,917.14
because the Oct stretch had a gap, which froze the figure); "remove where it didn't add up, user won't care". Only a
balance older than 45 days is still shown as told. The gap check stays inside the engine but is never shown: no
"Where it didn't add up" list, no "doesn't add up" warning, no agent nudge. Idempotent. Run from kosh-beta/."""
import sys
def patch(p, pairs, marker):
    s = open(p, encoding='utf-8').read()
    if marker in s: print(p, 'already'); return
    for a, b in pairs:
        if s.count(a) != 1: sys.exit('%s anchor %d: %r' % (p, s.count(a), a[:60]))
        s = s.replace(a, b)
    open(p, 'w', encoding='utf-8').write(s); print(p, 'patched')
patch('Kosh/engine.js', [
 ("    if (last && (st !== 'gap' || last.src === 'typed') && !stale) F.forEach(",
  "    // (livebal-4nov) always carried forward from the latest balance, every bank: a gap before it never freezes it\n"
  "    if (last && !stale) F.forEach("),
], 'livebal-4nov')
patch('Kosh/agent.js', [
 ("      if (!b || b.check !== 'gap' || !g || String(g.to).slice(0, 10) < since(45)) return;",
  "      if (true) return; // (livebal-4nov) gaps are never raised to the user\n"
  "      if (!b || b.check !== 'gap' || !g || String(g.to).slice(0, 10) < since(45)) return;"),
], 'livebal-4nov')
patch('Kosh/AccountPage.swift', [
 ("                if let gaps = a.gaps, !gaps.isEmpty { GapList(gaps: gaps) }\n",
  "                // (livebal-4nov) no 'Where it didn’t add up' list\n"),
 ('        let warn: Bool = b.check == "gap" || b.stale == true',
  '        let warn: Bool = b.stale == true'),
 ('                        .privacySensitive(b.check == "gap")\n', ''),
], 'livebal-4nov')
patch('Kosh/Banking.swift', [
 ('        if b.check == "gap" { return base + " · doesn’t add up" }\n',
  '        // (livebal-4nov) a gap is never said\n'),
 ('        if b.check == "gap" || b.behind != nil { age = max(age, 1) }',
  '        if b.behind != nil { age = max(age, 1) }'),
 ('''        case "gap":
            if let g = a.gaps?.last {''',
  '''        case "gap":
            return nil
            if let g = a.gaps?.last {'''),
], 'livebal-4nov')
patch('Kosh/Banking.swift', [
 ('return gaps == 0 ? "Checked: it adds up with " + pairs + " and every payment between." : "Checked: the latest balances add up. " + (gaps == 1 ? "One earlier stretch didn’t." : String(gaps) + " earlier stretches didn’t.")',
  'return "Checked: it adds up with " + pairs + " and every payment between." // (livebal-4nov-b)'),
], 'livebal-4nov-b')
