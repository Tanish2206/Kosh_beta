# kosh feedback 1 Nov (22:19) — Swift, part P: locked statements asked per account holder and per password rule, not
# per sender. Axis mails Sanjiv's combined statement (his date of birth + the first 4 letters of his name) to the same
# inbox as yours: one "kosh made the password from your saved details" for all 54 was wrong for most of them. Now one
# ask per (sender, whose statement it is, the rule its mail gives); each says whose it is, what it would open, and the
# password's recipe, so the detail asked for is plain. Idempotent.
p = 'Kosh/Papers.swift'; s = open(p).read()
def sub(old, new, mark):
    global s
    if mark in s: return
    assert s.count(old) == 1, ('papers anchor', old[:70])
    s = s.replace(old, new)
sub("""        var holder: String = "me"
        /// the same bank's other addresses""", """        var holder: String = "me"
        /// one ask per sender, holder and rule (several can share a sender)
        var key: String { id + "|" + holder + "|" + hint }
        /// the same bank's other addresses""", 'var key: String { id + "|" + holder')
sub("""        var bySender: [String: [Int]] = [:]
        for i in records.indices where records[i].doc?.state == "locked" {
            bySender[SenderPasswords.domain(records[i].doc?.from ?? ""), default: []].append(i)
        }""", """        var bySender: [String: [Int]] = [:]
        // (by sender, whose statement it is and the rule its mail gives: a father's statement mailed to your inbox
        // asks for his details, by its own rule, apart from yours)
        for i in records.indices where records[i].doc?.state == "locked" {
            let dom0: String = SenderPasswords.domain(records[i].doc?.from ?? "")
            let who0: String = likelyHolders(records[i]).first ?? "me"
            bySender[dom0 + "\\u{1}" + who0 + "\\u{1}" + (records[i].doc?.hint ?? ""), default: []].append(i)
        }""", 'likelyHolders(records[i]).first ?? "me"')
sub("""        for (dom, idx0) in bySender {""", """        for (gk, idx0) in bySender {
            let dom: String = String(gk.split(separator: "\\u{1}", omittingEmptySubsequences: false).first ?? Substring(gk))""", 'for (gk, idx0) in bySender')
open(p, 'w').write(s)

p = 'Kosh/StatementsSettings.swift'; s = open(p).read()
for old, new in [
    ("ForEach(LockedMerge.of(sorted, home: { homes[$0.id] ?? PaperShelf.other })) { (n: LiveSession.LockedNeed) in",
     "ForEach(LockedMerge.of(sorted, home: { homes[$0.id] ?? PaperShelf.other }), id: \\.key) { (n: LiveSession.LockedNeed) in"),
    ("ForEach(LockedMerge.of(locked, home: { _ in b.name })) { (n: LiveSession.LockedNeed) in",
     "ForEach(LockedMerge.of(locked, home: { _ in b.name }), id: \\.key) { (n: LiveSession.LockedNeed) in"),
    # what it would open: only this holder's papers
    ("let covers: [LockedCover] = LockedCover.of(store.live, ids: need.ids)",
     "let covers: [LockedCover] = LockedCover.of(store.live, ids: need.ids, holder: need.holder)"),
    ("    @MainActor static func of(_ live: LiveSession?, ids: [String]) -> [LockedCover] {",
     "    @MainActor static func of(_ live: LiveSession?, ids: [String], holder: String = \"\") -> [LockedCover] {"),
    ("            guard let d = r.doc, keys.contains(d.from) else { continue }",
     "            guard let d = r.doc, keys.contains(SenderPasswords.domain(d.from)) || keys.contains(d.from) else { continue }\n            if !holder.isEmpty && (live.likelyHolders(r).first ?? \"me\") != holder { continue }"),
    # whose and the recipe, under the name
    ("""                    Text(need.sender).font(.body.weight(.semibold)).lineLimit(1)
                    Text(PaperShelf.need(""",
     """                    HStack(spacing: 6) {
                        Text(need.sender).font(.body.weight(.semibold)).lineLimit(1)
                        if who != "me" {
                            Text(Details.personName(who, store) + "’s").font(.caption.weight(.semibold)).foregroundStyle(Color.kosh)
                                .padding(.horizontal, 7).padding(.vertical, 2).background(Color.kosh.opacity(0.12), in: Capsule())
                        }
                    }
                    if let r = LockedRecipe.of(need.hint) {
                        Text("Password: " + r).font(.caption).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                    }
                    Text(PaperShelf.need("""),
]:
    if new not in s:
        assert s.count(old) == 1, ('settings anchor', old[:60])
        s = s.replace(old, new)
if 'enum LockedRecipe' not in s:
    s += r'''

/// the password's recipe as its mail tells it, in short: "first 4 letters of name (CAPITALS) + date of birth (DDMM)"
@MainActor
enum LockedRecipe {
    static var memo: [String: String] = [:]
    static func of(_ hint: String) -> String? {
        guard !hint.isEmpty else { return nil }
        if let m = memo[hint] { return m.isEmpty ? nil : m }
        var out: [String] = []
        if let s = try? Engine.shared.call("pwPartsJSON", [hint]), let d = s.data(using: .utf8),
           let parts = try? JSONSerialization.jsonObject(with: d) as? [[String]] {
            for alt in parts { for p in alt {
                let w: String = p.replacingOccurrences(of: "Your ", with: "").replacingOccurrences(of: "your ", with: "")
                if !w.isEmpty && !out.contains(w) { out.append(w) }
            } }
        }
        let r: String = out.joined(separator: " + ")
        memo[hint] = r
        return r.isEmpty ? nil : r
    }
}
'''
open(p, 'w').write(s)
print('swift P patched')
