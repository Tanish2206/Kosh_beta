#!/usr/bin/env python3
"""cardbill3-4nov: a card statement's total due proven by its own lines. The phone reads HDFC's summary box out of order
(Tata Neu ••5192 came out as ₹7,110.32 due, its PREVIOUS dues; CRED and the PDF say ₹7,533). The lines it reads add up to
the box's purchases and payments; the previous dues that, less the payments and with the purchases, come to a figure the
box prints, make that figure the total. Taken only when exactly one figure does. Idempotent."""
import sys, io
P = sys.argv[1] if len(sys.argv) > 1 else 'Kosh/engine.js'
s = io.open(P, encoding='utf-8').read()
if 'cardbill3-4nov' in s:
    print('already applied'); sys.exit(0)
assert 'cardbill2-4nov' in s, 'cardbill2 first'
def rep(old, new):
    global s
    assert s.count(old) == 1, (s.count(old), old[:80])
    s = s.replace(old, new, 1)
rep("  function cardBillOf(text, to, G) {", r'''  /* cardbill3-4nov: the total due its own lines prove. The lines come to the purchases and the payments the box prints
     (each a figure on the page, within a rupee); the previous dues, less the payments, plus the purchases, land on one more
     figure (the total; HDFC prints it rounded down). The previous dues are whichever figure does that: exactly one total
     may come out, or none is taken */
  function cbLinesTotal(text, rows) {
    rows = rows || [];
    if (!rows.length) return null;
    var out = 0, inn = 0;
    rows.forEach(function (r) { if (r.dir === 'in') inn += r.amt; else out += r.amt; });
    out = r2(out); inn = r2(inn);
    if (out <= 0) return null;
    var figs = [];
    String(text || '').split('\n').slice(0, 120).forEach(function (l) { if (!cbProse(l)) cbTokens(l, 'amt').forEach(function (t) { if (!t.cr) figs.push(t.v); }); });
    var near = function (v) { var o = []; figs.forEach(function (f, i) { if (Math.abs(f - v) <= 1) o.push(i); }); return o; };
    var dI = near(out), cI = near(inn);
    if (!dI.length || !cI.length) return null;
    var Ts = {};
    figs.forEach(function (p, pi) {
      if (dI.length === 1 && dI[0] === pi) return;           // the purchases' own figure is not the previous dues
      if (inn > 0 && cI.length === 1 && cI[0] === pi) return; // nor the payments'
      var t = p - inn + out;
      if (t < 0) return;
      figs.forEach(function (f, ti) { if (ti !== pi && t - f > -0.011 && t - f < 1) Ts[r2(f)] = 1; });
    });
    var ks = Object.keys(Ts).map(Number);
    return ks.length === 1 ? ks[0] : null;
  }
  function cardBillOf(text, to, G) {''')
rep("""      if (card) { var bill = (Gs.length ? cardBillOf(text, L.to, Gs[0]) : null) || cardBillOf(Lt, L.to) || (Lt !== text ? cardBillOf(text, L.to) : null); if (bill) out.bill = bill; }""",
"""      if (card) { var bill = (Gs.length ? cardBillOf(text, L.to, Gs[0]) : null) || cardBillOf(Lt, L.to) || (Lt !== text ? cardBillOf(text, L.to) : null); if (bill) out.bill = bill; }
      // cardbill3-4nov: the total its lines prove wins over a label's figure that isn't it (one backed by its equation stands)
      if (card && out.bill && !out.bill.eq) {
        var lt = cbLinesTotal(Lt, L.rows);
        if (lt === null && Lt !== text) lt = cbLinesTotal(text, L.rows);
        if (lt !== null && Math.abs(lt - out.bill.amt) > 1) { out.bill.amt = lt; out.bill.lines = true; if (out.bill.min > lt + 1) out.bill.min = 0; }
        else if (lt !== null) out.bill.lines = true;
      }""")
io.open(P, 'w', encoding='utf-8').write(s)
print('applied')
