#!/usr/bin/env python3
"""Speed (2 Nov 2026): reader.js billerNamed looks the name up in an index of knowledge.js's billers made once
(it normalised every biller's every name on every call). Same output on all 3,416 corpus mails. Idempotent."""
import pathlib, sys
p = pathlib.Path(__file__).resolve().parents[2] / 'Kosh' / 'reader.js'
s = p.read_text()
a = """    var n = norm(name);
    if (n.length < 4) return null;
    var list = K.billers || [];
    for (var i = 0; i < list.length; i++) {
      var b = list[i];
      if ([b.short, b.name].concat(b.aliases || []).some(function (x) { return x && norm(x) === n; })) return b;
    }
    return null;
  }"""
b = """    var n = norm(name);
    if (n.length < 4) return null;
    var list = K.billers || [];
    // (every biller's names, normalised once: the first biller in the list that has the name wins, as before)
    if (BILLER_IX.list !== list || BILLER_IX.n !== list.length) {
      var ix = Object.create(null);
      list.forEach(function (b) { [b.short, b.name].concat(b.aliases || []).forEach(function (x) { if (x) { var k = norm(x); if (!(k in ix)) ix[k] = b; } }); });
      BILLER_IX = { list: list, n: list.length, ix: ix };
    }
    return BILLER_IX.ix[n] || null;
  }
  var BILLER_IX = {};"""
if b not in s:
    if a not in s: sys.exit('perf_2nov_reader: anchor missing')
    s = s.replace(a, b, 1); p.write_text(s); print('perf_2nov_reader: applied')
