#!/usr/bin/env python3
"""shopsms-3nov: a shop's own SMS (ZOMATO-S, SWIGGY-S…) read as the order it took, so it lands in the ledger the moment
kosh opens instead of being dropped as "unknown-sender" (3 Nov: a Zomato order's SMS reached kosh at 20:33 IST and was
dropped; no bank SMS or mail told it). Until now only a shop's NOTIFICATION was read; an SMS had to be a bank's.
Also three bank headers seen on the phone that the list lacked: HSBCIM (HSBC), MYSBIC (SBI Card), MYAMEX (Amex).
The order's mail, when it comes, folds into the same row (dedupe: the shop's receipt takes the line paid to that shop)
and AutoNote writes its items into the row's note. Run from kosh-beta/: python3 tools/patches/shopsms_3nov_engine.py"""
import sys, json, hashlib
p = 'Kosh/engine.js'
s = open(p, encoding='utf-8').read()
def rep(old, new, n=1):
    global s
    c = s.count(old)
    if c != n: sys.exit('anchor %d times (want %d): %r' % (c, n, old[:80]))
    s = s.replace(old, new)

rep("""YESBNK: 'yes', YESBKK: 'yes', IDFCFB: 'idfc', IDFCBK: 'idfc', AUBANK: 'au', AUSFBL: 'au', HSBCIN: 'hsbc', HSBCBK: 'hsbc',""",
    """YESBNK: 'yes', YESBKK: 'yes', IDFCFB: 'idfc', IDFCBK: 'idfc', AUBANK: 'au', AUSFBL: 'au', HSBCIN: 'hsbc', HSBCBK: 'hsbc', HSBCIM: 'hsbc',""")
rep("""AMEXIN: 'amex', AMEXCC: 'amex', ONECRD: 'onecard', OCARDS: 'onecard',""",
    """AMEXIN: 'amex', AMEXCC: 'amex', MYAMEX: 'amex', MYSBIC: 'sbicard', ONECRD: 'onecard', OCARDS: 'onecard',""")

rep("""  function istParts(iso) {""", """  /* a shop's own SMS header ("JD-ZOMATO-S", "SWIGGY-T"): the shop, by the same names PLATFORMS knows it by. Never a
     promotional header (-P), never a number (a person), never a header a bank's list already claims (3 Nov) */
  function smsShop(msg) {
    var from = String(msg.from || '').toUpperCase().replace(/[^A-Z0-9-]/g, '');
    if (!from || /\\d{6,}/.test(from) || /-P$/.test(from)) return null;
    var parts = from.split('-').filter(function (x) { return x.length >= 4; });
    for (var i = 0; i < parts.length; i++) {
      if (SMS_HEADERS[parts[i]]) return null;
      var h = parts[i].toLowerCase();
      for (var p = 0; p < PLATFORMS.length; p++) if (PLATFORMS[p][2].test(h)) return PLATFORMS[p];
    }
    return null;
  }

  function istParts(iso) {""")

rep("""      for (var p = 0; p < PLATFORMS.length; p++) if (PLATFORMS[p][2].test(hay)) { shop = PLATFORMS[p]; break; }
    }
""", """      for (var p = 0; p < PLATFORMS.length; p++) if (PLATFORMS[p][2].test(hay)) { shop = PLATFORMS[p]; break; }
    }
    // (a shop's own SMS, by its header: an order it took, read like its notification. 3 Nov)
    if (!app && !bank && !shop && chan === 'sms') shop = smsShop(msg);
""")

rep("""      if (dir === 'in' && !/\\brefund/i.test(flat)) return noise('shop-not-order');
      return Object.assign(base, { kind: 'confirm', rule: 'notif-order', dir: dir === 'in' ? 'in' : 'out', amt: amt, date: date, time: time, instr: '', inst: '', instKind: '',
        party: shop[0], vpa: '', mode: '', info: shop[0], conf: 'medium', from: 'app:' + shop[0] });""",
"""      if (dir === 'in' && !/\\brefund/i.test(flat)) return noise('shop-not-order');
      /* (an SMS of an order already on its way, delivered or to rate repeats the sum it took: never a second order. A
         shop's SMS is a purchase receipt, so a second one of the same sum that day rides with the first: dedupe's told) */
      if (chan === 'sms' && /\\b(?:out for delivery|on (?:its|the) way|picked up|arriving|has been delivered|was delivered|delivered|rate (?:your|the|us)|how was)\\b/i.test(flat) && !/\\b(?:placed|paid|payment (?:of|received|successful))\\b/i.test(flat)) return noise('shop-not-order');
      return Object.assign(base, { kind: 'confirm', rule: chan + '-order', dir: dir === 'in' ? 'in' : 'out', amt: amt, date: date, time: time, instr: '', inst: '', instKind: '',
        party: shop[0], vpa: '', mode: '', info: shop[0], conf: 'medium', from: (chan === 'sms' ? 'sms:' : 'app:') + shop[0], purpose: chan === 'sms' && dir !== 'in' ? 'purchase' : undefined });""")

# a change made on the shop's SMS row stays when its order mail takes the row's place: the SMS names the shop
# ("Zomato"), the mail the restaurant ("Sethi Snacks Corner"), so the twin is found by the shop the mail went through too
rep("""          if (!sameRef && !sameName(g.party, r.party)) return;""",
    """          if (!sameRef && !sameName(g.party, r.party) && !(/-order$/.test(g.rule || '') && g.party && (sameName(g.party, r.inst) || sameName(g.party, r.info)) && flat(r.inst || r.info))) return;""")

open(p, 'w', encoding='utf-8').write(s)
# the SMS part's fingerprint: a change here reads the phone's SMS again (ReadingPrint.sms), never the year of mail
j = 'Kosh/engine-sms.json'
fp = hashlib.sha256(('shopsms-3nov|' + open(j).read()).encode()).hexdigest()[:16]
open(j, 'w').write(json.dumps({'sms': fp}, separators=(',', ':')))
print('ok', fp)
