# kosh feedback 1 Nov (23:46) — Swift, part S: habits under Up close. Food & Drinks: how you eat (ordered in against
# out, the usual order, the day it happens most, late nights, the places you go back to, the dishes ordered most);
# Groceries: what you stock (runs, how often, quick commerce against stores, the shops, what by group, the items
# bought most); Transport: how you fuel (fill-ups, how often, a month on fuel, the brand, the usual pumps). Each from
# the months Up close shows. The views live in Habits.swift (tools/patches/files). Idempotent.
import shutil, os
src = 'tools/patches/files/Habits.swift'
if not os.path.exists('Kosh/Habits.swift') or open('Kosh/Habits.swift').read() != open(src).read():
    shutil.copy(src, 'Kosh/Habits.swift')
p = 'Kosh/InsightsBook.swift'; s = open(p).read()
old = """                    if cat == "Shopping" {
                        let buys: [BuyPattern] = BuyPattern.over(rows, store: store)"""
new = """                    if let habit = Habits.of(cat, rows: rows, store: store) {
                        HabitCard(h: habit, span: BuyPattern.spanWords(look.months.count), color: color, ink: ink)
                            .padding(.top, 18)
                    }
                    if cat == "Shopping" {
                        let buys: [BuyPattern] = BuyPattern.over(rows, store: store)"""
if 'Habits.of(cat, rows: rows' not in s:
    assert s.count(old) == 1, 'habits anchor'
    s = s.replace(old, new)
open(p, 'w').write(s)
print('swift S patched')
