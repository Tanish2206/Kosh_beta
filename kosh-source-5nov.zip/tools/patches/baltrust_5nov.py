#!/usr/bin/env python3
"""baltrust-5nov (kosh ios app chat): the diagnostics carry, per account, how its balances checked out against each
other on the phone's REAL feed (mail + SMS): pairs that agreed (ok), pairs that didn't (bad), and the last five
stretches that didn't (from, to, amount). The Mac bench can't see SMS; this is the score of the live balance on the
phone itself. Idempotent."""
import sys
def patch(p, pairs, marker):
    s = open(p, encoding='utf-8').read()
    if marker in s: print(p, 'already'); return
    for a, b in pairs:
        if s.count(a) != 1: sys.exit('%s anchor %d: %r' % (p, s.count(a), a[:60]))
        s = s.replace(a, b)
    open(p, 'w', encoding='utf-8').write(s); print(p, 'patched')
patch('Kosh/LiveSession+Extras.swift', [
 ("""                    if let b = a["bal"] as? [String: Any] { for k in ["src", "at", "n", "net", "check", "stale"] { if let v = b[k] { o["bal." + k] = v } } }
                    return o""",
  """                    if let b = a["bal"] as? [String: Any] { for k in ["src", "at", "n", "net", "check", "stale", "ok", "bad", "v"] { if let v = b[k] { o["bal." + k] = v } } }
                    if let g = a["gaps"] { o["gaps"] = g }   // (baltrust-5nov)
                    return o"""),
], 'baltrust-5nov')
