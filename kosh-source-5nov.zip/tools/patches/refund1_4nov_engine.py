#!/usr/bin/env python3
"""4 Nov ("kosh ios app" chat) - one refund, one row, one effect on its purchase.
Found on the 26 Oct Meesho order (Rs 5,251 on Axis CC 2363, Rs 1,107 back the same day): the card statement's credit line
came in as "MEESHO,BANGALORE DEPT STORES End of Stat", filed Transfer in (income), never tied to the purchase, while
other tellings of the same money could stand beside it. Fixes, generic for any shop / bank / card / account:
  1. a statement line's page furniture ("**** End of Statement ****", "Page 2 of 3") is no part of its narration
  2. a credit on a card or account naming the shop of an earlier purchase on that same card/account is a Refund, not income
  3. one refund told by several sources (bank SMS, bank mail, the statement line, the shop's own mail) is ONE row: the
     best-told copy stays, the others fold into it (their user edits carried), so it comes off its purchase once
  4. a refund tied to its purchase takes the purchase's clean name, and both carry a note combining every source
     (refund row: kosh's note unless you wrote one; purchase: `rfn`, used as the note only when it has none and no items)
Idempotent (marker REFUND1-4NOV). Re-run after a full source drop."""
import sys, pathlib
P = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else pathlib.Path(__file__).resolve().parents[2] / 'Kosh' / 'engine.js')
s = P.read_text(encoding='utf-8')
DONE = 'REFUND1-4NOV)' in s   # (steps 1-4 in; the later steps carry their own markers)
if DONE: print('refund1_4nov: steps 1-4 already in')

def rep(old, new, n=1):
    global s
    if DONE: return
    c = s.count(old)
    assert c == n, (c, old[:80])
    s = s.replace(old, new)

# 1. page furniture off a statement line's words
rep("""        if (stmtHeading(d0)) { R0.skipped++; return; }
""", """        if (stmtHeading(d0)) { R0.skipped++; return; }
        // (REFUND1-4NOV) a page's furniture caught on the last line ("**** End of Statement ****", "Page 2 of 3") is no
        // part of its narration: "MEESHO,BANGALORE DEPT STORES End of Stat" was a shop called that
        d0 = stmtFurniture(d0);
""")
rep("""mode: info.mode || '', info: String(row.desc || '').slice(0, 120), conf: 'high',""",
    """mode: info.mode || '', info: stmtFurniture(String(row.desc || '')).slice(0, 120), conf: 'high',""")
rep("""  function squash(s) { return (s || '').toLowerCase().replace(/[^a-z]/g, ''); }
""", """  function squash(s) { return (s || '').toLowerCase().replace(/[^a-z]/g, ''); }
  // (REFUND1-4NOV) a statement page's furniture that a line's narration can swallow when it is the page's last line
  function stmtFurniture(s) {
    return String(s || '').replace(/\\*{2,}\\s*end\\s+of\\s+(?:the\\s+)?statement\\s*\\*{0,}/ig, ' ').replace(/\\bend\\s+of\\s+(?:the\\s+)?statement\\b/ig, ' ')
      .replace(/\\bpage\\s+\\d+\\s+of\\s+\\d+\\b/ig, ' ').replace(/\\*{3,}/g, ' ').replace(/\\s{2,}/g, ' ').trim();
  }
""")

rep("""          (best._by = best._by || {})[S.src || ''] = 1; R0.matched++; stMark(best, S.src || '');
""", """          (best._by = best._by || {})[S.src || ''] = 1; R0.matched++; stMark(best, S.src || '');
          // (REFUND1-4NOV) what the statement's line said, kept on the payment it answered for (for its note)
          (best.stSeen = best.stSeen || []).push({ src: S.src || '', d: row.date, said: d0.slice(0, 120) });
""")

# 2 + 3. before the refunds are tied: a shop's credit is a refund, and one refund told twice is one row
rep("""      var shopWord = {}, shopOf = {};
""", """      /* GUARDRAIL (REFUND1-4NOV) one refund, one row. (a) A credit on a card or account that names the shop of an earlier
         purchase on that same card or account (a statement's "MEESHO,BANGALORE ... Cr", an alert's "refund from EXAMPLESHOP")
         is that shop's money coming back: a Refund, never income, unless you filed it yourself. (b) The same refund told by
         more than one source (the bank's SMS, its mail, the statement's line, the shop's own mail) is one row: same sum
         within a rupee, within a week, from different sources, on the same card or account (or one source names no card),
         and the same shop (or the same card with one of them already a refund). The best-told copy stays (an alert's,
         with its time and card, over a statement's line, over the shop's word), the others fold into it with your
         changes, and what each source said is kept for the note, so it comes off its purchase once and only once. Two
         refunds from ONE source are two refunds (two items returned for the same sum), never folded */
      (function () {
        var recR = {};
        merged.forEach(function (r) { if (r && r.id) recR[r.id] = r; });
        var ckey = function (k) { k = String(k || '').toLowerCase(); return /(?:balance|wallet|money|cash|gift ?cards?)\\b/.test(k) ? k.replace(/\\b(?:balance|wallet|money|cash|gift ?cards?)\\b/g, ' ').replace(/\\s+/g, ' ').trim() : k; };
        var NOT_SHOP_IN = /\\b(?:cash ?back|reward|points?|interest|salary|dividend|payment|thank|autopay|auto ?debit|bbps|bill ?desk|neft|imps|rtgs|cred\\b)/i;
        function chOf(t) {
          var r = recR[t.id] || {};
          if (t.src === 'statement' || r.src === 'statement') return 'stmt';
          if (/^sms[-:]/.test(String(r.rule || t.rule || '')) || /^sms:/.test(String(r.from || ''))) return 'sms';
          if (r.byShop || r.refundOf) return 'shop';
          return 'mail';
        }
        var RANK = { sms: 3, mail: 3, stmt: 2, shop: 1 };
        function own0(r) { return r.src === 'statement' ? stmtFurniture(String(r.info || '')).slice(0, 120) : ''; }
        function seenOf(t) {
          if (t._seen) return t._seen;
          var r = recR[t.id] || {};
          var own = { ch: chOf(t), d: t.d, t: t.t || '', inst: t.inst || r.inst || '', last4: String(t.last4 || r.last4 || '').slice(-4), card: t.card || '',
            from: String(r.from || ''), said: own0(r), ref: r.ref || t.ref || '', order: r.orderId || '' };
          var out = [own];
          // (the statements whose lines this one answered for: they told it too, in their own words)
          (r.stSeen || []).forEach(function (x) { out.push({ ch: 'stmt', d: x.d || t.d, inst: own.inst, last4: own.last4, said: x.said || '' }); });
          return (t._seen = out);
        }
        var outs = tx.filter(function (p) { return p.dirRaw === 'out' && !p.partOf && (p.k === 'out' || p.k === 'prepaid'); });
        var ins = tx.filter(function (c) { return c.dirRaw === 'in' && !c.partOf && !c.pair && !c.mirror && (c.k === 'in' || c.c === 'Refund'); });
        // (a) a shop's credit on the card or account the shop was paid from
        ins.forEach(function (c) {
          if (c.c === 'Refund' || c.c === 'Reimbursement' || (over[c.id] || {}).c) return;
          if (!(c.c === 'Transfer in' || !c.c || c.c === 'Other income' || c.c === 'Miscellaneous')) return;
          var told = (c.m || '') + ' ' + (c.py || '') + ' ' + ((recR[c.id] || {}).info || '') + ' ' + ((recR[c.id] || {}).subject || '');
          if (NOT_SHOP_IN.test(told)) return;
          // (on a card a credit from a shop's name is the shop's money coming back; on a bank account a credit from a name
          // is far more often a person paying you back, so there only the bank's own words "refund"/"reversal" say so)
          if (c.instr !== 'card' && !/\b(?:refund|refunded|reversal|reversed|rev|chargeback|return(?:ed)?)\b/i.test(told)) return;
          var hit = outs.filter(function (p) {
            if (p.c === 'People' || p.c === 'Transfer out' || ckey(p.card) !== ckey(c.card) || p.d > c.d || daysBetween(p.d, c.d) > 180) return false;
            if (c.a > (p.full !== undefined ? p.full : p.a) + 1) return false;
            return sameShop(p, c);
          })[0];
          if (!hit) return;
          c.c = 'Refund'; c.s = ''; c.k = kindFor('Refund', 'in'); c.sym = symFor('Refund', ''); c.u = false; c.sp = false;
        });
        // (b) one refund told twice
        var cand = ins.filter(function (c) { return c.c === 'Refund' || c.c === 'Transfer in' || !c.c; }).sort(function (a, b) { return a.d.localeCompare(b.d) || String(a.id).localeCompare(String(b.id)); });
        var gone = {};
        cand.forEach(function (a, i) {
          if (gone[a.id]) return;
          cand.slice(i + 1).forEach(function (b) {
            if (gone[b.id] || gone[a.id] || Math.abs(a.a - b.a) > 1 || Math.abs(daysBetween(a.d, b.d)) > 7) return;
            if (a.c !== 'Refund' && b.c !== 'Refund') return;
            var ca = chOf(a), cb = chOf(b);
            if (ca === cb) return;
            var noCard = function (x) { return !x.last4 || x.instr === 'other'; };
            var sameCard = ckey(a.card) === ckey(b.card) || (a.last4 && b.last4 && sameEnd(a.last4, b.last4) && (a.inst || '') === (b.inst || ''));
            if (!sameCard && !noCard(a) && !noCard(b)) return;
            if (!sameShop(a, b) && !sameShop(b, a) && !(sameCard && (a.c === 'Refund' || b.c === 'Refund'))) return;
            var keep = (RANK[cb] || 0) > (RANK[ca] || 0) ? b : a, drop = keep === a ? b : a;
            if (noCard(keep) && !noCard(drop)) { keep = drop; drop = keep === a ? b : a; }
            keep._seen = seenOf(keep).concat(seenOf(drop));
            if (keep.c !== 'Refund' && drop.c === 'Refund') { keep.c = 'Refund'; keep.s = ''; keep.k = kindFor('Refund', 'in'); keep.sym = symFor('Refund', ''); keep.sp = false; }
            if (!keep.t && drop.t) keep.t = drop.t;
            // your changes made on the copy that folds stay with the refund (as carryChanges does for a payment's twins)
            if (over[drop.id] && !over[keep.id]) over[keep.id] = over[drop.id];
            if (!keep.n && drop.n) keep.n = drop.n;
            // the shop's word and its order's number stay with the copy that stays, so the refund still finds its purchase
            var rk = recR[keep.id], rd = recR[drop.id];
            if (rk && rd) ['refundFor', 'refundByOrder', 'byShop', 'refundOf', 'orderId', 'evs'].forEach(function (f) { if (rd[f] !== undefined && rk[f] === undefined) rk[f] = rd[f]; });
            gone[drop.id] = keep.id;
          });
        });
        if (Object.keys(gone).length) {
          for (var gi = tx.length - 1; gi >= 0; gi--) if (gone[tx[gi].id]) tx.splice(gi, 1);
          Object.keys(gone).forEach(function (id) { byId[id] = byId[gone[id]]; });
        }
        tx.forEach(function (c) { if (c.dirRaw === 'in' && c.c === 'Refund' && !c._seen) seenOf(c); });
      })();
      // (REFUND1-4NOV) what the shops' own mails said about a refund (its order, its reference, the item), whichever
      // way those mails were folded into the ledger: for the refund's note only, never a figure
      var shopToldIdx = null;
      var shopTold = function (t, credits) {
        if (!shopToldIdx) shopToldIdx = (records || []).filter(function (r) {
          return r && r.dir === 'in' && +r.amt > 0 && (r.shopRefund || /refund/i.test(String(r.rule || '') + ' ' + String(r.subject || ''))) && !/^sms/i.test(String(r.rule || ''));
        });
        var tn = squash(t.m).slice(0, 8), out = [];
        if (tn.length < 4) return out;
        shopToldIdx.forEach(function (r) {
          // (the shop's own mail: from the shop's address, or one kosh read as a shop's refund; a bank's alert is the bank's)
          if (!(squash(String(r.from || '').split('@').pop()).indexOf(tn) >= 0 || (r.shopRefund && squash((r.party || '') + ' ' + (r.evs || '')).indexOf(tn) >= 0))) return;
          if (r.instKind === 'bank') return;
          var c = credits.filter(function (x) { return Math.abs(x.a - r.amt) <= 1 && Math.abs(daysBetween(x.d, r.date || r.sent)) <= 12; })[0];
          if (!c) return;
          var ev = []; try { ev = JSON.parse(r.evs || '[]') || []; } catch (e) { ev = []; }
          var ref = '', q = '';
          ev.forEach(function (e) { if (e && e.ref && !ref) ref = String(e.ref); if (e && e.q && !q) q = String(e.q); });
          out.push({ cid: c.id, d: r.date || r.sent, a: +r.amt, order: r.orderId || '', ref: ref, subject: String(r.subject || '').slice(0, 90), q: q.slice(0, 140) });
        });
        return out;
      };
      var shopWord = {}, shopOf = {};
""")

# 4. the tied refund takes the purchase's name; both carry the whole story
rep("""        credits.forEach(function (c) { c.ex = c.ex || ('Refund for ' + t.m); c.refOf = t.id; });
""", """        credits.forEach(function (c) { c.ex = c.ex || ('Refund for ' + t.m); c.refOf = t.id; });
        // (REFUND1-4NOV) a refund tied to its purchase is called what the purchase is ("Meesho", not the statement's
        // "MEESHO,BANGALORE DEPT STORES"), and both rows say, in one note, everything every source told about it
        refundStory(t, credits, charged, pg, shopTold(t, credits));
""")
rep("""  function squash(s) { return (s || '').toLowerCase().replace(/[^a-z]/g, ''); }
""", """  function squash(s) { return (s || '').toLowerCase().replace(/[^a-z]/g, ''); }
  // (REFUND1-4NOV) one refund's story, from every source that told it
  function refundStory(t, credits, charged, pg, told) {
    if (!credits || !credits.length) return;
    var MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    var day = function (d) { d = String(d || ''); return /^\\d{4}-\\d{2}-\\d{2}/.test(d) ? (+d.slice(8, 10)) + ' ' + MON[+d.slice(5, 7) - 1] + ' ' + d.slice(0, 4) : d; };
    var rs = function (n) { n = Math.round(n * 100) / 100; var w = Math.floor(n), f = Math.round((n - w) * 100); var x = String(w), l = x.slice(-3), r = x.slice(0, -3); if (r) l = r.replace(/\\B(?=(\\d{2})+(?!\\d))/g, ',') + ',' + l; return '\\u20b9' + l + (f ? '.' + (f < 10 ? '0' : '') + f : ''); };
    var CH = { stmt: 'statement', sms: 'SMS', mail: 'email', shop: 'shop\\u2019s email' };
    var back = 0, lines = [], shortL = [];
    credits.forEach(function (c) {
      back += c.a;
      if (c.src === 'statement' || /,|\\b(?:dept|stores?|retail|pvt|ltd)\\b/i.test(c.m || '') || /^(?:money in|refund|credit|upi|neft|imps|transfer|reversal)\\b/i.test(c.m || '')) c.m = t.m;
      var seen = c._seen || [{ ch: c.src === 'statement' ? 'stmt' : 'mail', d: c.d, inst: c.inst || '', last4: String(c.last4 || '').slice(-4), card: c.card }];
      var srcs = [], said = [], refs = [];
      seen.forEach(function (x) {
        var who = x.ch === 'shop' ? t.m + ' email' : (x.inst ? x.inst + ' ' : '') + (CH[x.ch] || 'email');
        if (srcs.indexOf(who) < 0) srcs.push(who);
        if (x.ch === 'stmt' && x.said && said.indexOf(x.said) < 0) said.push(x.said);
        if (x.ref && refs.indexOf(String(x.ref)) < 0) refs.push(String(x.ref));
        if (x.order && refs.indexOf('order ' + x.order) < 0) refs.push('order ' + x.order);
      });
      var to = c.card || t.card;
      var note = ['Refund of ' + rs(c.a) + ' for ' + t.m + ' \\u2014 ' + rs(charged) + ' paid ' + day(t.d) + (t.card ? ' on ' + t.card : ''),
        'Credited ' + day(c.d) + (c.t ? ' ' + c.t : '') + (to ? ' to ' + to : ''),
        'Seen in: ' + srcs.join(' \\u00b7 ')];
      if (said.length) note.push('Statement says: ' + said.join(' / '));
      // (what the shop's own mail said about it: the refund it promised or credited, the order, its reference, the item)
      var mine = (told || []).filter(function (x) { return x.cid === c.id; });
      if (mine.length) {
        var shopT = t.m;
        var saidS = {};
        mine.forEach(function (x) {
          var sk = squash(x.subject).slice(0, 40);
          if (sk && saidS[sk]) return;
          saidS[sk] = 1;
          var item = /\(([^()]{3,60})\)/.exec(x.q || '');
          note.push(shopT + '\u2019s email ' + day(x.d) + ': ' + (x.subject || 'refund of ' + rs(x.a)) + (x.order ? ' \u00b7 order ' + x.order : '') + (item ? ' \u00b7 ' + item[1] : '') + (x.ref ? ' \u00b7 ref ' + x.ref : ''));
        });
        if (srcs.indexOf(shopT + ' email') < 0) srcs.push(shopT + ' email');
        note[2] = 'Seen in: ' + srcs.join(' \u00b7 ');
      } else if (pg && pg.mails && pg.mails.length) {
        var sm = pg.mails.filter(function (m) { return Math.abs((+m.a || 0) - c.a) <= 1; })[0] || pg.mails[0];
        var shopN = pg.party || t.m;
        note.push(shopN + '\u2019s email ' + day(sm.d) + ': refund of ' + rs(+sm.a || c.a) + (sm.order || pg.order ? ' for order ' + (sm.order || pg.order) : '') + (sm.q ? ' \u2014 ' + String(sm.q).slice(0, 80) : ''));
        if (srcs.indexOf(shopN + ' email') < 0) srcs.push(shopN + ' email');
        note[2] = 'Seen in: ' + srcs.join(' \u00b7 ');
      }
      if (refs.length) note.push('Ref: ' + refs.join(' \\u00b7 '));
      if (!c.n) c.n = note.join('\\n');
      c.rfn = note.join('\\n');
      shortL.push(rs(c.a) + ' back ' + day(c.d) + ' (' + srcs.join(', ') + ')');
    });
    var left = Math.max(0, charged - back);
    t.rfn = 'Refund: ' + shortL.join('; ') + '\\nSpent after refund: ' + rs(left) + ' of ' + rs(charged);
  }
""")
rep("""refunded: t.refunded || undefined, refOf: t.refOf || undefined,""",
    """refunded: t.refunded || undefined, refOf: t.refOf || undefined, rfn: t.rfn || undefined,""")
# a purchase's own note says its refund when it has no note and no items for kosh's item note (AutoNote) to write
rep("""      snapOut.payFacts = { v: 1, pay: pay, shops: shops, rhythms: rhythms, cover: cover };
""", """      snapOut.payFacts = { v: 1, pay: pay, shops: shops, rhythms: rhythms, cover: cover };
      // (REFUND1-4NOV) a refunded purchase with nothing else to say says what came back
      (snapOut.tx || []).forEach(function (x) { if (x.rfn && x.k !== 'in' && !x.n && !((pay[x.id] || {}).items || []).length) x.n = x.rfn; });
""")
if not DONE:
    P.write_text(s, encoding='utf-8')
    print('refund1_4nov: applied to', P)

# 5. (same marker run) a shop's refund for PART of an order (one item of five sent back: Rs 1,107 of Rs 5,251) belongs to
#    that order's payment: the promise looked only for a payment of its own sum, found none, and the bank's credit was
#    then held for a "loose" promise and never came off the purchase. Exact sum first, as before; else the same shop's
#    payment it could be part of (the most recent within 60 days, on or before the promise)
s = P.read_text(encoding='utf-8')
if 'REFUND1-4NOV-PART' not in s:
    old = """          }).sort(function (a, b) { return b.d.localeCompare(a.d) || String(a.id).localeCompare(String(b.id)); })[0] || null;
        }
"""
    assert s.count(old) == 1, 'purchaseFor anchor'
    s = s.replace(old, """          }).sort(function (a, b) { return b.d.localeCompare(a.d) || String(a.id).localeCompare(String(b.id)); })[0] || partFor(p, names);
        }
        // (REFUND1-4NOV-PART) a refund of part of an order: the same shop's payment it fits inside, nearest first
        function partFor(p, names) {
          return tx.filter(function (t) {
            if (t.dirRaw !== 'out' || t.partOf || !(t.k === 'out' || t.k === 'prepaid')) return false;
            var whole = t.full !== undefined ? t.full : t.a, g = daysBetween(t.d, p.d);
            if (!(whole > p.amt + 1) || !(g >= 0 && g <= 60)) return false;
            var said = squash((t.m || '') + ' ' + (t.py || ''));
            return names.some(function (n) { return said.indexOf(n) >= 0; });
          }).sort(function (a, b) { return b.d.localeCompare(a.d) || String(a.id).localeCompare(String(b.id)); })[0] || null;
        }
""")
    P.write_text(s, encoding='utf-8')
    print('refund1_4nov: part-refund step applied')

# 6. (marker REFUND1-4NOV-SPLIT) a part you split out of the purchase as "Refunded" and the bank's credit for it are the
#    same money: on the 26 Oct Meesho order the Rs 1,107 split part AND the statement's Rs 1,107 credit both stood, so the
#    purchase came off twice (or the credit counted as income). When a credit tied to the purchase covers a Refunded part,
#    the credit IS that refund: the part folds back into the purchase and the credit takes it off, once, with the note
s = P.read_text(encoding='utf-8')
if 'REFUND1-4NOV-SPLIT' not in s:
    old = """        if (got > 0) {
          if (t.full === undefined) t.full = t.a;
"""
    assert s.count(old) == 1, 'got anchor'
    s = s.replace(old, """        // (REFUND1-4NOV-SPLIT) your "refunded" split of this purchase, now that the money it meant is here, is that money
        if (got > 0) {
          var rparts = tx.filter(function (x) { return x.partOf === t.id && !x._absorbed && (/refund/i.test(String(x.ex || '')) || x.c === 'Refund' || (over[x.id] || {}).c === 'Refund' || /refund/i.test(String((over[x.id] || {}).ex || ''))); });
          var absorbed = 0;
          rparts.forEach(function (pt) {
            if (absorbed + pt.a > got + 1) return;
            absorbed = money(absorbed + pt.a); pt._absorbed = true; t.a = money(t.a + pt.a);
          });
          if (absorbed > 0) credits.forEach(function (c) { if (c.n === c.rfn && c.n) c.n += '\\nReplaces the ' + rsOf(absorbed) + ' you split out of the purchase as refunded'; });
        }
        if (got > 0) {
          if (t.full === undefined) t.full = t.a;
""")
    old2 = """        refunds.push(row);
      });
"""
    assert s.count(old2) == 1, 'refunds.push anchor'
    s = s.replace(old2, """        refunds.push(row);
      });
      // (REFUND1-4NOV-SPLIT) the split parts a refund's credit now answers for are gone: the credit is the refund
      for (var ai = tx.length - 1; ai >= 0; ai--) if (tx[ai]._absorbed) tx.splice(ai, 1);
""")
    old3 = """  // (REFUND1-4NOV) one refund's story, from every source that told it
"""
    assert s.count(old3) == 1
    s = s.replace(old3, """  function rsOf(n) { n = Math.round(n * 100) / 100; var w = Math.floor(n), f = Math.round((n - w) * 100); var x = String(w), l = x.slice(-3), r = x.slice(0, -3); if (r) l = r.replace(/\\B(?=(\\d{2})+(?!\\d))/g, ',') + ',' + l; return '\\u20b9' + l + (f ? '.' + (f < 10 ? '0' : '') + f : ''); }
""" + old3)
    P.write_text(s, encoding='utf-8')
    print('refund1_4nov: split step applied')
