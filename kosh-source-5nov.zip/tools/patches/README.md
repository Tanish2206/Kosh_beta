# Fixes kept as patch scripts (1 Nov 2026, from the "kosh feedback" chat)

Another chat ships kosh as a full source drop (kosh-src.tgz → Kosh/), which replaces these fixes each time.
**Before building from a new source drop, run them** (each is idempotent and skips what is already in):

    for p in tools/patches/fb_1nov_*.py; do python3 "$p"; done

Better still: fold them into that chat's own source so its next drop carries them.

- `fb_1nov_engine.py` — card names from mail (Diners Black ••4545 via the statement file's digits, Kotak Air+, HSBC
  Live+/Platinum by statement months, Yes Reserv, SBI BPCL); policy people never a form's label (nominee/holder/insured);
  receipt GST; receipt PDFs labelled as receipts; Shopping "what was bought" (t.wk) from order items matched by
  shop+total+date, your word, sub-category, shop.
- `fb_1nov_swift_a.py` — Obsidian aura (stronger, every black page), policy page (nominee ask, GST row, PDF tiles),
  old cards retired after a year, Txn.wk / Policy.gross / Mail.pdf fields.
- `fb_1nov_swift_b.py` — "Where it came from" sheet in the black look on Insurance/Wealth.
- `fb_1nov_swift_c.py` — Insights › Up close: What it was / Where, clean shop names, tap a row for its payments,
  category list with amount and share.
- `fb_1nov_swift_d.py` — Insights month picker on the pace card's right, "November", years as sections.
- `fb_1nov_swift_e.py` — Chapters' list opens the timeline; samples hidden once you have a chapter.
- `fb_1nov_engine.py` (19:50 add) — searches also ask for any shop's own order confirmation ("Order #… confirmed",
  "Thank you for your order"), so a small store's items get read.
- `fb_1nov_swift_f.py` — queriesVersion 5: that search runs once over the past year, nothing read twice.
- `fb_1nov_swift_g.py` — Wealth › Net worth: whose money as a dropdown on the title's line.
- `fb_1nov_swift_h.py` — Insights: picking an older month keeps every later month on offer.
- `fb_1nov_engine.py` (20:15 add) — one bill told twice (biller's receipt + paying app's) is one payment: same sum and day, shared reference or same company (Jio = Reliance).
- `fb_1nov_engine.py` (20:30 add) — Amazon Pay gift cards bought are 'Gift cards', not unknown shopping; engine-read.json fingerprint bumped so the phone re-reads mail with the new reading rules.
- `fb_1nov_swift_g.py` (fix) — WhoseMenu builds its list from its own store (the first version crashed the Wealth tab).
- `fb_1nov_engine.py` (20:40 add) + `fb_1nov_swift_i.py` — 'How you shop' (snap.buys): each kind bought over 9 months, rhythm, usual spend, shops, latest item, next likely.
- `fb_1nov_engine.py` (20:50 add) — one credit told by two alert templates is one (the narration's NEFT/IMPS/UPI reference); categories from the mail: gift-card charges → Wallet & Gift Cards › Gift cards, shopping sub-category = what was bought (Accessories, Games & toys added to Shopping's list). Also fixed a duplicated block the patch had inserted twice (marker now `var BUY_KINDS = [`).
- `fb_1nov_engine.py` (21:05 add) — one policy booked through an aggregator and then issued by the insurer is one row (same insurer, premium, cover, within 60 days).
- `fb_1nov_swift_j.py` — 'Whose rent is it?' as a clean list with kosh's likely tenant first.
- `fb_1nov_swift_k.py` — 'Which home?' sheet in the black look (plates, kind colour, inline add).
- `fb_1nov_swift_l.py` — 'Where kosh read this' always the black designed sheet (no grey system form).
- `fb_1nov_engine_b.py` — part-paid orders (balance + card), Smart home kind, long product names / 'INR' suffix lines in reader.js.
- `fb_1nov_swift_m.py` — How you shop follows Up close's months.
- `fb_1nov_swift_n.py` — locked statements: one ask per bank (merged addresses), what it opens, compact row.
- `fb_1nov_swift_o.py` — Every bill map (BillsMap.swift from tools/patches/files) + bill-kind pages.
- `fb_1nov_swift_p.py` — locked asks per holder and password rule; recipe + whose shown.
- `fb_1nov_engine_c.py` — bill receipts' HTML connection + biller; homes by board state / named-town homes / used property.
- `fb_1nov_engine_d.py` — searches: 'ordered' + receipts in Promotions from known senders (queriesVersion 6 in swift_f).
- `fb_1nov_swift_r.py` — insurance: kind tiles open own kind, 'X policy' title, vehicle model, years rounding, rules 34 re-read of policy mail without paper.
- `fb_1nov_engine_e.py` — motor policy make/model from mail (reader ev.model → policy.model, vehicle.model).
- `fb_1nov_engine_f.py` — policy PDFs from any sender (CRED garage, aggregators), app/wallet invoices; rules 35 re-read in swift_r.
- `fb_1nov_engine_g.py` — any sender's money PDF opened as 'unknown' (docClass decides).
- `fb_1nov_swift_s.py` — habit cards (food, groceries, fuel) under Up close; Habits.swift in tools/patches/files.
- `fb_1nov_engine_h.py` — food apart in shop orders / non-groceries in grocery orders → Txn.mix; Home goods words.
- `fb_1nov_swift_t.py` — AutoSplit: files each payment's mix once (split part or refile).
- `fb_1nov_engine_i.py` — one purchase one row: shipping/delay mails never a payment; card receipts folded into the bigger same-shop charge.
- `fb_1nov_engine_k.py` — refunds find payments across wallet names; a bill's confirm moves to the try that went through.
- `fb_1nov_engine_l.py` — item order numbers and returns marked item by item.
- `fb_1nov_swift_u.py` — order card: order numbers, returned items struck, row hint.
- `fb_1nov_engine_m.py` — universal one-purchase-one-row: same order number, or same shop+sum within 2 days with one non-alert source.
- `fb_1nov_engine_n.py` — wallet/credit share of an order as its own row (walletUse), gift-card loads (several cards one charge, over payee rules).
- `fb_1nov_swift_v.py` — rows say how an order was paid (wallet + card).
- `fb_1nov_engine_o.py` — cancelled / RTO / failed-delivery orders become an expected refund for the order total.
- `fb_1nov_swift_w.py` — AutoNote: kosh writes item/price/order-number notes once (AutoNote.swift in tools/patches/files).
- `fb_1nov_swift_x.py` — Paid from as a route (app → account).
- `fb_1nov_engine_p.py` — event tickets read (name, day, time, tickets, tier, venue, booking) as the payment's receipt.
- `fb_1nov_swift_y.py` — events: countdown, note, reminders (Events.swift in tools/patches/files).
- `fb_1nov_swift_z.py` — Up close: How you shop folded into the bars (rhythm, usual) — no duplicate card.
- `unknown_3nov_engine.py` (3 Nov, "kosh ios app" chat) — engine.js + reader.js + engine-read.json, idempotent:
  HDFC's new statement lines ("| 09:48 … + C 10,165.00": time, and the PDF's ₹ as "C") read right — money in as in,
  the time kept, names clean; a card's own bill-payment line (BPPY / CC PYMT / PAYMENT RECEIVED) is never a charge;
  a statement's summary heading ("Portfolio Summary as on…", AU's font drops letters) is never a payment; card-bill
  rows titled by the card paid ("HDFC Diners Club Black ••4545 bill"); an order's deductions read line by line —
  a named wallet (Myntra Credit, MynCash) is a wallet leg at its own figure, a bank cashback / discount / no line is a
  discount (no more fake "Bank Credit"/"India Credit"/"Myntra Wallet" spends); the order bill shows Order total /
  Discount at payment / Charged to <card> / From <wallet>; items keep count × each-price on orders matched by total;
  an order's placing mail is "placed" whatever its progress bar prints. **Re-run after any full source drop.**
- `life_3nov_engine.py` (3 Nov, statements chat) — engine.js: account/card life events (withLife), pending account row, debit cards join it. Swift by hand: Snapshot.swift `Account.pending`, Accounts.swift BankRow "number not seen yet".
- `harvest_3nov.py` (3 Nov, statements chat) — engine.js pwFacts (CRN digits only, mobile), Papers.swift harvestFromEverything + PwFacts.mobile, LiveSession+Statements.swift harvest on every opened paper and retry the locked; LiveSession.swift `harvestedNew` by hand.
- `stmtacct_3nov_engine.py` (3 Nov, statements chat, idempotent) — engine.js: account number in the bank's own grouping; a no-payment period whose opening = closing adds up (HSBC composite statement).
- `where_3nov.py` (3 Nov, statements chat, idempotent) — engine.js PW_WHERE table + StmtStatus.findAt; Snapshot.swift findAt; Banking.swift shows it on the locked card (HSBC Customer Number: HSBC India app › Statements).
- `cardsum_3nov_engine.py` (+ in-place cardsum-3nov-b, statements chat) — engine.js card summary read as its printed equation (Axis, ICICI, Kotak, HDFC "C" rupee + "_" minus, SBI Card's no-operator row, HSBC); kept only when it holds.
- `daymon_3nov_engine.py` (statements chat, idempotent) — engine.js: "09SEP" day+month lines (HSBC cards) are dated lines.
- `zerocol_4nov_engine.py` (statements chat) — a 0.00 in the unused column no longer drops the line; the printed closing balance is the balance (Axis ₹9.07L → ₹4.10L).
- `accttype_4nov_engine.py` + `accttype_4nov_swift.py` (statements chat) — PPF/SSY/FD/RD listed in a bank statement → holdings (wealth), never a bank tile; "Account status: CLOSE" closes the account; "As on" date; StmtDoc.status.
- `egdigits_4nov_engine.py` (statements chat) — digits only in a password example are no account (SBI ••2345).
- `quiet_4nov.py` (statements chat) — accounts with no money moving for 6 months listed apart as "Quiet accounts".
- `papers_4nov.py` (+ in-place -b, -c) + `papers_4nov_b.py` (statements chat) — investment papers by their own figures: a holding statement's Total line with units and value reconciles (Zerodha demat 9/9); contract notes printed one row per ISIN with Buy/Sell blocks read (Zerodha 10/10), footnote digits after "(₹)" no levy, annexure order rows not double-counted; a broker's funds/retention ledger is `paper:'funds'` with `funds:{bal, asOf, owed}`, an annual report / e-voting / postal ballot is `paper:'notice'` (no stray holdings); ₹2 reconcile slack only on sums ≥ ₹1,000. Swift: statementReader 6 re-reads cas + contract papers.
- `cardlines_4nov.py` (statements chat, notes only; edits applied in place, tagged cardlines-4nov / period-4nov / polno-4nov / gains-4nov) — card statements 83→113 add up of 158 (HDFC 25/25, SBI Card 12/12, HSBC, Kotak EMI); HDFC Ergo policy number; gains computation; statementReader 7.
- `gone_4nov.py` (statements chat, notes; in place) — old/closed accounts leave the list, deposit papers mint no accounts, quiet accounts listed once, HSBC composite as on its statement date; statementReader 8.
- `phone_4nov.py` (statements chat, notes; in place) — phone-mode bench (pdfgrid/mkgrids, stmt-bench --phone), HDFC by columns with its printed opening, Customer ID never an account, debit cards on their account + Cards section, brokerFunds shadow fixed; statementReader 9.
- `itemfigs_4nov.py` (kosh ios app chat, 4 Nov) — a row of figures is never an item: one itemNameOk() test in reader.js lineName, engine.js invoiceLines and the payFacts build, so a GST summary Total row ("0.00 0 00 0 0.00 1.10 Total 2 530.00") never becomes a Bought most chip; stored readings cleaned on the next build.
- `smart_4nov.py` (statements chat, notes; in place) — phone-mode statements 114→136/158 add up, 0 wrong: headers, Date-and-Time, null words, account sections, best-of columns/lines, card figures under labels, partial readings to the next reader; statementReader 12.

- `cardbill_4nov_engine.py`, `cardbill_4nov_swift.py` (4 Nov): a card statement PDF's own bill (total, minimum, due day) becomes
  the card's bill; card last4 from the masked number; statement ↔ mail lookup by id. Idempotent. Guard:
  `node tools/eval/bill-bench.js _corpus/stmts/gmail/files` (must print "bill bench ok").
- `drift_4nov.py` (statements chat, notes; Swift in place) — phone letters no longer shift a line (PDFKit boxes counted without line breaks), punctuation joins its line, dev diagnostics carry the kept statement texts for tools/eval/phone-bench.js; extractor 4, statementReader 13.
- `cardbill2_4nov_engine.py`, `cardbill2_4nov_swift.py` (4 Nov, after cardbill_4nov_*): leaflets never opened as the statement
  (HSBC), bills read off the phone's own texts (jumbled readings ignored, labels in sentences skipped, label rows), card
  digits from masked numbers, app re-points leaflet papers once. Guard: `node tools/eval/bill-bench.js _corpus/stmts/gmail/files`
  (also checks the phone texts and the file pick).
- `cardbill3_4nov_engine.py`, `cardbill3_4nov_swift.py` (4 Nov, after cardbill2): total due proven by the statement's own lines
  (cbLinesTotal); statementReader +1. The cardbill2 Swift patch also adds the bill to the diag's statementsRead.
