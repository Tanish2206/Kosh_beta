#!/usr/bin/env python3
"""life-3nov: accounts and cards found from their own bank's word of them (opened, card activated, PIN set,
dispatched, delivered, closed), not only from a payment or a balance. HSBC's salary account (debit card ••9291,
activated 7 Oct, statements from 10 Oct) had no tile because no mail of it carried money with account digits.
Run from kosh-beta/: python3 tools/patches/life_3nov_engine.py"""
import sys
p = 'Kosh/engine.js'
s = open(p, encoding='utf-8').read()
def rep(old, new, n=1):
    global s
    c = s.count(old)
    if c != n: sys.exit('anchor %d times (want %d): %r' % (c, n, old[:80]))
    s = s.replace(old, new)

# 1. the reader: withLife, applied last in parseMail
rep("""    try { var ppx = portalFacts(msg, out); if (ppx) out.pp = ppx; } catch (e) { /* the reading stands */ }
    return out;
  }""", """    try { var ppx = portalFacts(msg, out); if (ppx) out.pp = ppx; } catch (e) { /* the reading stands */ }
    // an account or card being born, changed or closed, as its own bank writes of it (withLife, 3 Nov)
    try { out = withLife(out, msg); } catch (e) { /* the reading stands */ }
    return out;
  }
  /* LIFE (3 Nov): an account or a card as its own bank tells of it outside its money: opened, a debit or credit card
     issued, dispatched, delivered, activated, its PIN set, replaced, blocked or closed. A mail like that proves the
     account or card exists even when no payment or balance of it has come yet (HSBC's salary account, debit card
     ••9291 activated on 7 Oct, had no tile: none of its mail carried money with the account's digits). It never makes
     money: the reading keeps its kind (noise stays noise for the ledger) and gains `life` { ev, what, l4 } with the
     instrument and its digits, so the registry and the cards list (cardsSeen) count it as the bank's own word.
     Only the institution's own mail (a bank or card issuer by its sender), never an offer, an OTP or an application
     still being made (an application can be refused). Any bank, any card: nothing here names one. */
  var LIFE_SKIP = /\\b(?:offer|cashback|voucher|reward|earn|emi\\b|processing fee|forex|% off|discount|otp|one[ -]time password|verification code|application|apply|acknowledg|eligible|pre-?approved|invite|upgrade|statement|transaction alert|used your|spent|debited|credited|beneficiar\\w*|payee|standing instruction|fund transfer|mandate|easy access|time to|deposit)\\b/i;
  var LIFE_EVS = [
    ['closed', /\\b(?:has been|is|was|have been)\\s+(?:permanently\\s+)?(?:closed|blocked|hotlisted|cancell?ed|deactivated|terminated)\\b|\\bclosure of\\b/i],
    ['replaced', /\\breplace(?:d|ment)\\b|\\bre-?issued\\b/i],
    ['activated', /\\b(?:has been|is now|is|successfully|been)\\s+activated\\b|\\bcard activation\\b|\\bactivated successfully\\b/i],
    ['pin', /\\bpin\\b.{0,40}?\\b(?:set|reset|generated|changed|created)\\b|\\b(?:set|reset|generated|changed|created)\\b.{0,30}?\\bpin\\b|\\bgreen pin\\b/i],
    ['delivered', /\\b(?:has been|was|is|successfully)\\s+delivered\\b/i],
    ['dispatched', /\\bdispatched\\b|\\bhas been shipped\\b|\\bon (?:its|the) way\\b/i],
    ['issued', /\\b(?:has been|is|was)\\s+(?:issued|approved)\\b|\\bvirtual card\\b|\\bcard is ready\\b|\\bwelcome kit\\b/i],
  ];
  var LIFE_OPEN = /\\b(?:account|a\\/c)\\b.{0,60}?\\b(?:has been|is now|is|successfully|been)\\s+(?:opened|activated|created)\\b|\\bwelcome to\\b.{0,40}\\bbank\\b|\\bwelcome kit\\b/i;
  function withLife(r, msg) {
    if (!r || r.kind === 'txn' || r.kind === 'confirm' || r.kind === 'statement' || r.life) return r;
    var ins = institution(msg.from || '');
    if (!ins || !/^(?:bank|card)$/.test(ins.kind || '')) return r;
    var subj = String(msg.subject || '');
    var body = normalize(msg.text || '', msg.html || '').slice(0, 2500);
    if (LIFE_SKIP.test(subj)) return r;
    var hay = subj + ' \\n ' + body;
    var cm = /\\b(debit|credit)\\s*card\\b/i.exec(hay);
    var dm = /\\bcard\\b[^.\\n]{0,40}?(?:ending(?:\\s+(?:with|in))?|no\\.?|number|x{2,}|[*•]{2,})\\s*[:#-]?\\s*(?:[x*•]+\\s?)?(\\d{4})\\b/i.exec(hay);
    var ev = '';
    for (var i = 0; i < LIFE_EVS.length && !ev; i++) if (LIFE_EVS[i][1].test(subj) || LIFE_EVS[i][1].test(body.slice(0, 900))) ev = LIFE_EVS[i][0];
    if (cm && dm && ev) {
      var debit = cm[1].toLowerCase() === 'debit';
      // a credit card's word comes from its issuer (a bank or a card company); a debit card's only from a bank
      if (debit && ins.kind !== 'bank') return r;
      r.life = { ev: ev, what: debit ? 'debit' : 'credit', l4: dm[1] };
      if (!r.instr || r.instr === 'card') { r.instr = 'card'; if (!r.last4) r.last4 = dm[1]; if (debit) r.debit = true; }
      if (!r.inst) r.inst = ins.short;
      if (!r.instKind) r.instKind = ins.kind;
      return r;
    }
    if (ins.kind === 'bank' && LIFE_OPEN.test(hay) && !/\\bcard\\b/i.test(subj)) {
      var am = /\\b(?:a\\/c|account)\\s*(?:no\\.?|number)?\\s*[:#-]?\\s*[x*•]*\\d{0,14}?(\\d{4})\\b/i.exec(hay);
      r.life = { ev: 'opened', what: 'account', l4: am ? am[1] : '' };
      if (!r.instr) { r.instr = 'account'; if (am && !r.last4) r.last4 = am[1]; }
      if (!r.inst) r.inst = ins.short;
      if (!r.instKind) r.instKind = ins.kind;
    }
    return r;
  }""")

# 2. the registry: a life mail is an observation of the account; a bank whose own mail proves an account (opened, a
#    debit card of it) but never printed its digits gets one row, its number not seen yet
rep("""      obs.push({ inst: r.inst, d: d, own: own, kind: r.kind || '', src: src, at: w.at, acct: r.acct || '', id: r.id });""",
    """      obs.push({ inst: r.inst, d: d, own: own, kind: r.kind || '', src: src, at: w.at, acct: r.acct || '', id: r.id, life: !!r.life });""")
rep("""      var tab = mapTab[inst] = {};
      list.forEach(function (o) { if (o.d) tab[o.d] = o.l4 || ''; });""",
    """      /* LIFE (3 Nov): the bank's own word that an account of yours exists (it was opened, or a debit card of it was
         issued, activated or had its PIN set) with no digits of it anywhere yet: one row for the bank, its number not
         seen yet (l4 ''), until a statement, alert or balance prints the digits and that account's row takes over */
      if (!mine.length && list.some(function (o) { return o.own && (o.life || o.card); })) {
        var P = accts[inst + '|'] = { inst: inst, l4: '', own: 0, n: 0, kinds: {}, seen: {}, inbox: {}, alias: {}, first: '', last: '', closed: false, pending: true };
        list.forEach(function (o) {
          if (!o.own || o.l4) return;
          P.own++; P.n++; P.kinds[o.kind || 'life'] = (P.kinds[o.kind || 'life'] || 0) + 1; if (o.src) P.seen[o.src] = 1;
          if (o.acct) P.inbox[o.acct] = (P.inbox[o.acct] || 0) + 1;
          var day = o.at.slice(0, 10);
          if (day && (!P.first || day < P.first)) P.first = day;
          if (day && day > P.last) P.last = day;
        });
        if (unplaced[inst]) delete unplaced[inst];
      }
      var tab = mapTab[inst] = {};
      list.forEach(function (o) { if (o.d) tab[o.d] = o.l4 || ''; });""")
# (a debit card's observation says it is one)
rep("""      obs.push({ inst: r.inst, d: d, own: own, kind: r.kind || '', src: src, at: w.at, acct: r.acct || '', id: r.id, life: !!r.life });""",
    """      obs.push({ inst: r.inst, d: d, own: own, kind: r.kind || '', src: src, at: w.at, acct: r.acct || '', id: r.id, life: !!r.life, card: !!card });""")
rep("""               confirmed: A.own > 0 || !!(fix.confirm || {})[key], split: !!(fix.split || {})[key] };""",
    """               confirmed: A.own > 0 || !!(fix.confirm || {})[key], split: !!(fix.split || {})[key], pending: !!A.pending };""")
# 3. the tile says its number isn't known yet
rep("""        if (R.alias.length) a.alias = R.alias;
        if (tag) a.tag = tag;""", """        if (R.alias.length) a.alias = R.alias;
        if (R.pending) a.pending = true;
        if (tag) a.tag = tag;""")
open(p, 'w', encoding='utf-8').write(s)
print('life-3nov applied')

# 4. a debit card whose account's number isn't known yet is that pending account's card (one row, not two)
s = open(p, encoding='utf-8').read()
rep("""      accounts.forEach(function (a) {
        (a.keys || [a.id]).forEach(function (k) { (dc[k] || []).forEach(function (d) { a.debit = a.debit || []; if (a.debit.indexOf(d) < 0) a.debit.push(d); }); });
      });""", """      accounts.forEach(function (a) {
        (a.keys || [a.id]).forEach(function (k) { (dc[k] || []).forEach(function (d) { a.debit = a.debit || []; if (a.debit.indexOf(d) < 0) a.debit.push(d); }); });
        // (the bank's account whose number isn't known yet: its debit cards are filed by the card until then)
        if (a.pending) Object.keys(dc).forEach(function (k) { if (k.indexOf(a.bank + ' Debit card ••') === 0) dc[k].forEach(function (d) { a.debit = a.debit || []; if (a.debit.indexOf(d) < 0) a.debit.push(d); }); });
      });""")
rep("""      if (!m || t.instr !== 'account' || hidden[key]) return;
      var meta = instMeta[t.inst] || {};""", """      if (!m || t.instr !== 'account' || hidden[key]) return;
      // (its bank's account whose number isn't known yet takes the card and its payments: one row)
      var pend = accounts.filter(function (a) { return a.pending && a.bank === t.inst; })[0];
      if (pend) { pend.keys.push(key); pend.count += x.count; pend.month += Math.round(x.month); pend.last30 += Math.round(x.last30); if (x.lastUsed > (pend.lastUsed || '')) pend.lastUsed = x.lastUsed; return; }
      var meta = instMeta[t.inst] || {};""")
open(p, 'w', encoding='utf-8').write(s)
print('life-3nov part 4 applied')
