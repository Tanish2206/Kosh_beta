#!/usr/bin/env python3
"""stmtname-4nov (names chat, 4 Nov). Applied in place to Kosh/engine.js; re-run = no-op (checks the tag).
 A statement line kosh adds on its own (no alert told it) was named by lower-casing its narration and then title-casing
 it -- titleCase() leaves lower-case text alone, so every such name stayed lower-case -- and "(Ref# ST2627...)" lost its
 number but kept "(ref". A bank's own charges kept their raw narration and fell uncategorised:
   "1.75% on all dcc transaction (ref"   HDFC DCC markup, monthly on a USD subscription  -> Forex markup
   "IGST" / "IGST-VPS...-RATE 18.0"      the GST on that charge                           -> GST on charges
   "OFFUS EMI,PROCNG FEE, (Ref# )" etc.  an EMI's fee, principal, interest, foreclosure   -> EMI processing fee, ...
 Now: stmtLineName() names a bank's charge for what it is (the same words for every bank), drops a reference and
 its number from any name, closes off a bracket the cut left open, and title-cases what is left. Two KW rules file
 the charge names under Hidden Charges (Forex markup, GST on fees). Exported as lib.stmtLineName for the bench."""
import hashlib, os, sys
P = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'Kosh', 'engine.js')
TAG = 'stmtname-4nov'
src = open(P, encoding='utf-8').read()
if TAG in src:
    print('already applied'); sys.exit(0)
st0 = os.stat(P).st_mtime_ns

FN_ANCHOR = "  // (REFUND1-4NOV) a statement page's furniture that a line's narration can swallow when it is the page's last line\n  function stmtFurniture(s) {"
FN = r'''  /* (stmtname-4nov) the name of a statement line kosh adds on its own (no alert told it). A bank's own charge is named
     for what it is, in the same words whichever bank prints it ("1.75% on all DCC Transaction (Ref# ST2627...)" is a
     forex markup, "IGST-VPS...-RATE 18.0" the GST on a charge); a reference and its number are no part of a name
     ("(Ref# )"); a bracket the cut left open is dropped; the rest is title-cased, never left lower-case */
  var STMT_CHARGE = [
    [/^(?:[\d.]+\s*%\s*(?:on\s+)?(?:all\s+)?)?(?:dcc\b|dynamic\s+currency|cross[- ]?currency|foreign\s+(?:currency\s+)?(?:transaction|txn)s?\s+(?:fee|charge|mark-?up)|forex\s+mark-?up|fcy\s+mark-?up|mark-?up\s+(?:fee|charges?))/i, 'Forex markup'],
    [/^(?:[icsu]gst|gst|goods\s*(?:&|and)\s*services?\s*tax|service\s+tax)\b/i, 'GST on charges'],
    [/^(?:offus\s+emi\W*)?(?:procng|processing)\s+fee/i, 'EMI processing fee'],
    [/^(?:offus\s+emi\W*)?preclo\w*\s+fee|^foreclosure\s+(?:fee|charges?)/i, 'EMI foreclosure fee'],
    [/^offus\s+emi\W*preclo\w*\s+int/i, 'EMI foreclosure interest'],
    [/^offus\s+emi\W*loan\s+precl/i, 'EMI closed early'],
    [/^offus\s+emi\W*prin/i, 'EMI principal'],
    [/^offus\s+emi\W*int/i, 'EMI interest'],
    [/^\d{0,2}\s*late\s+(?:payment\s+)?(?:fee|charges?)/i, 'Late payment fee'],
    [/^(?:card\s+)?(?:membership|annual|renewal|joining)\s+fee/i, 'Annual fee'],
    [/^re-?issu\w*\s+fee/i, 'Card reissue fee'],
    [/^finance\s+charges?|^interest\s+on\s+(?:card|purchases|cash)/i, 'Finance charges'],
    [/^fuel\s+surcharge(?!\s+waiver)/i, 'Fuel surcharge']
  ];
  function stmtRefless(s) {
    return String(s || '').replace(/\(?\s*\bref(?:erence)?\s*(?:#|no\.?|number)\s*:?\s*[A-Za-z0-9]*\s*\)?/ig, ' ')
      .replace(/\[\s*ckyc[^\]]*\]?/ig, ' ').replace(/[(\[]\s*[)\]]/g, ' ').replace(/\s+/g, ' ').trim();
  }
  function stmtLineName(d0, info, dir) {
    var s = String(d0 || '').trim();
    for (var i = 0; i < STMT_CHARGE.length; i++) if (STMT_CHARGE[i][0].test(s)) return STMT_CHARGE[i][1] + (dir === 'in' ? ' reversed' : '');
    if (info && info.party) return stmtRefless(info.party).replace(/[\s,;:+]+$/, '') || info.party;
    var t = stmtRefless(s).replace(/\b(?:upi|imps|neft|rtgs|pos|ecom|nach|ach|mmt|ib|mb|atm|wdl|cr|dr)\b/ig, ' ').replace(/[\/\-_*#]+/g, ' ')
      .replace(/\S*\d{4,}\S*/g, ' ').replace(/\b[A-Z]{4}0[A-Z0-9]{6}\b/g, '').replace(/\s+/g, ' ').trim().slice(0, 40);
    // (a time and the table's rule printed beside the words, "| 08:04"; a payee's handle cut from its bank, "setuverify@")
    t = t.replace(/\|\s*\d{1,2}:\d{2}(?::\d{2})?/g, ' ').replace(/\|/g, ' ').replace(/\S+@\S*/g, ' ').replace(/,(?=\S)/g, ', ').replace(/\s+/g, ' ').trim();
    var o = t.lastIndexOf('('), c = t.lastIndexOf(')');
    if (o >= 0 && o > c) t = t.slice(0, o);
    t = t.replace(/[\s,;:+.(\[]+$/, '').replace(/^[\s,;:+.)\]]+/, '').trim();
    // mostly capitals ("BHAIROLAL GUPTA fbpe Pay To"): title-cased whole, so one name reads one way; a bank's and a
    // charge's short forms stay capitals
    var up = (t.match(/[A-Z]/g) || []).length, lo = (t.match(/[a-z]/g) || []).length;
    if (up >= lo) t = t.toUpperCase();
    return titleCase(t).replace(/\b(?:Emi|[ICSU]?gst|Atm|Upi|Neft|Imps|Rtgs|Hdfc|Icici|Sbi|Hsbc|Idfc|Lic|Uidai|Irctc|Nps|Ppf|Fd|Asba|Cc)\b/g, function (w) { return w.toUpperCase(); });
  }
'''
OLD_NAME = """        var party = info.party || titleCase(d0.replace(/\\b(?:upi|imps|neft|rtgs|pos|ecom|nach|ach|mmt|ib|mb|atm|wdl|cr|dr)\\b/ig, ' ').replace(/[\\/\\-_*#]+/g, ' ')
          .replace(/\\S*\\d{4,}\\S*/g, ' ').replace(/\\b[A-Z]{4}0[A-Z0-9]{6}\\b/g, '').replace(/\\s+/g, ' ').trim().toLowerCase()).slice(0, 40);"""
NEW_NAME = """        var party = stmtLineName(d0, info, row.dir);   // stmtname-4nov"""
KW_ANCHOR = "    [/late (payment )?fee|finance charge|annual fee|gst on|markup|penal|charges?\\b|sms charges/, 'Hidden Charges', 'Bank charges'],"
KW_NEW = """    // stmtname-4nov: a bank's charge as stmtLineName names it, filed under what it is
    [/\\bforex mark-?up\\b|\\bdcc mark-?up\\b|\\bdcc transaction|cross[- ]?currency mark-?up/, 'Hidden Charges', 'Forex markup'],
    [/\\bgst on (?:charges|fees?|forex)\\b/, 'Hidden Charges', 'GST on fees'],
    [/\\blate payment fee\\b/, 'Hidden Charges', 'Late fee'],
    [/\\b(?:card reissue|emi processing|emi foreclosure) fee\\b|\\bfuel surcharge\\b|\\bfinance charges\\b/, 'Hidden Charges', 'Bank charges'],
    [/\\bannual fee\\b|\\bmembership fee\\b/, 'Hidden Charges', 'Annual fee'],
"""
EXP_ANCHOR = "parseStmtLines: parseStmtLines, gridOf: gridOf,"
EXP_NEW = "parseStmtLines: parseStmtLines, stmtLineName: stmtLineName, gridOf: gridOf,"

for a, n in ((FN_ANCHOR, 'fn'), (OLD_NAME, 'name'), (KW_ANCHOR, 'kw'), (EXP_ANCHOR, 'export')):
    k = src.count(a)
    if k != 1: sys.exit('anchor %s found %d times -- engine.js moved on; not applied' % (n, k))
src = src.replace(FN_ANCHOR, FN + FN_ANCHOR).replace(OLD_NAME, NEW_NAME).replace(KW_ANCHOR, KW_NEW + KW_ANCHOR).replace(EXP_ANCHOR, EXP_NEW)
if os.stat(P).st_mtime_ns != st0: sys.exit('engine.js changed while patching; re-run')
tmp = P + '.stmtname.tmp'
open(tmp, 'w', encoding='utf-8').write(src); os.replace(tmp, P)
print('applied', hashlib.sha1(src.encode()).hexdigest()[:10])
