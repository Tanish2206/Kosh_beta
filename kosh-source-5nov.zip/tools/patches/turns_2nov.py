#!/usr/bin/env python3
"""kosh-reader turns (2 Nov 2026): the training notebook writes <model>.prompt.json beside the .gguf ({"before","after"}:
the exact text around the email it was trained on). KoshReader reads with it when it's beside the model, else falls
back to Qwen/Gemma turns; Settings › kosh-reader takes the .gguf and its .prompt.json in one pick. Idempotent."""
import pathlib, sys
K = pathlib.Path(__file__).resolve().parents[2] / 'Kosh'
def patch(name, pairs):
    p = K / name; s = p.read_text(); n = 0
    for a, b in pairs:
        if b in s: continue
        if a not in s: sys.exit(f'turns_2nov: anchor missing in {name}: {a[:70]}')
        s = s.replace(a, b, 1); n += 1
    p.write_text(s); print(f'turns_2nov: {name} {n} applied')
patch('KoshReader.swift', [
 ("""    private(set) var modelName = \"\"""",
  """    private(set) var modelName = \"\"
    /// the text around the email the model was trained on, from the notebook's <model>.prompt.json beside it
    private var turns: (before: String, after: String)? = nil"""),
 ("""        modelName = url.deletingPathExtension().lastPathComponent""",
  """        modelName = url.deletingPathExtension().lastPathComponent
        let side = url.deletingPathExtension().appendingPathExtension("prompt.json")
        if let d = try? Data(contentsOf: side), let o = try? JSONSerialization.jsonObject(with: d) as? [String: String],
           let b = o["before"], let a = o["after"] { turns = (b, a) } else { turns = nil }"""),
 ("""        let prompt = modelName.lowercased().contains("qwen")""",
  """        let prompt = turns.map { $0.before + content + $0.after } ?? (modelName.lowercased().contains("qwen")"""),
 ("""            : "<start_of_turn>user\\n" + content + "<end_of_turn>\\n<start_of_turn>model\\n\"""",
  """            : "<start_of_turn>user\\n" + content + "<end_of_turn>\\n<start_of_turn>model\\n")"""),
 ("""        let dest = folder.appendingPathComponent(url.lastPathComponent)""",
  """        // (a model's .prompt.json goes beside it; only a .gguf replaces the reader)
        let dest = folder.appendingPathComponent(url.lastPathComponent)"""),
])
patch('LiveViews.swift', [
 ("""            .fileImporter(isPresented: $picking, allowedContentTypes: [UTType(filenameExtension: "gguf") ?? .data, .data]) { result in
                switch result {
                case .success(let u):
                    do { _ = try KoshReader.importModel(from: u); note = "Added. kosh-reader reads new mail from now on."; Task { await live.aiPass() } }
                    catch { note = error.localizedDescription }""",
  """            .fileImporter(isPresented: $picking, allowedContentTypes: [UTType(filenameExtension: "gguf") ?? .data, .data], allowsMultipleSelection: true) { result in
                switch result {
                case .success(let us):
                    // (the model and its .prompt.json together: the format file first, so the model reads with it)
                    do { for u in us.sorted(by: { $0.pathExtension == "json" && $1.pathExtension != "json" }) { _ = try KoshReader.importModel(from: u) }
                         note = "Added. kosh-reader reads new mail from now on."; Task { await live.aiPass() } }
                    catch { note = error.localizedDescription }"""),
])
