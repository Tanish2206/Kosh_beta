#!/usr/bin/env python3
"""quiet-4nov (statements chat): a bank account where no money has moved for six months (only balance mails, or
nothing) is a quiet account (SBM ••9779, ₹15.11: "very old, I don't use it"): kept, never counted out, but listed apart
under "Quiet accounts" at the end, not with the accounts in use. A new account (first seen in the last six months) is
never quiet. Idempotent. Run from kosh-beta/."""
import sys
def patch(p, pairs, marker):
    s = open(p, encoding='utf-8').read()
    if marker in s: print(p, 'already'); return
    for a, b in pairs:
        if s.count(a) != 1: sys.exit('%s anchor %d: %r' % (p, s.count(a), a[:60]))
        s = s.replace(a, b)
    open(p, 'w', encoding='utf-8').write(s); print(p, 'patched')
patch('Kosh/engine.js', [
 ("""        if (R.pending) a.pending = true;""", """        if (R.pending) a.pending = true;
        if (R.first) a.since = R.first;   // (quiet-4nov)"""),
 ("""    /* GUARDRAIL an NRI's NRE or NRO account (FCNR too) is labelled so""",
  """    // (quiet-4nov) no money through it in six months, and not new: a quiet account, listed apart
    (function () {
      var qBefore = addDays(today, -183);
      accounts.forEach(function (a) {
        if (a.pending || a.ccy) return;
        var since = String(a.since || '').slice(0, 10);
        if (since && since > qBefore) return;
        var used = String(a.lastUsed || '').slice(0, 10);
        if (!used || used < qBefore) a.quiet = used || String(a.lastSeen || '').slice(0, 10) || 'long ago';
      });
    })();
    /* GUARDRAIL an NRI's NRE or NRO account (FCNR too) is labelled so"""),
], 'quiet-4nov')
patch('Kosh/Snapshot.swift', [
 ("""    var findAt: String? = nil""", """    var findAt: String? = nil"""),
], 'quiet-4nov-noop')
patch('Kosh/Snapshot.swift', [
 ("""    /// a debit card whose account kosh can't tell yet: the row is the card's (debit has its digits)
    var dcard: Bool? = nil""", """    /// a debit card whose account kosh can't tell yet: the row is the card's (debit has its digits)
    var dcard: Bool? = nil
    /// (quiet-4nov) no money has moved through it in six months: the day it last did ("long ago" when never seen)
    var quiet: String? = nil"""),
], 'quiet-4nov')
patch('Kosh/Accounts.swift', [
 ("""        var out: [Holder] = []
        var placed = Set<String>()
        func add(_ id: String, _ title: String, _ mine: [Account]) {""",
  """        var out: [Holder] = []
        var placed = Set<String>()
        // (quiet-4nov) accounts nothing has moved through in six months go last, apart, under "Quiet accounts"
        let quiet: [Account] = accs.filter { ($0.quiet ?? "").isEmpty == false }
        for a in quiet { placed.insert(a.id) }
        func add(_ id: String, _ title: String, _ mine: [Account]) {"""),
 ("""        if !rest.isEmpty { out.append(Holder(id: "~rest", title: "Others", accs: rest, sum: rest.compactMap(\\.balance).reduce(0, +))) }
        return out""",
  """        if !rest.isEmpty { out.append(Holder(id: "~rest", title: "Others", accs: rest, sum: rest.compactMap(\\.balance).reduce(0, +))) }
        if !quiet.isEmpty { out.append(Holder(id: "~quiet", title: "Quiet accounts", accs: quiet, sum: quiet.compactMap(\\.balance).reduce(0, +))) }
        return out"""),
], 'quiet-4nov')
