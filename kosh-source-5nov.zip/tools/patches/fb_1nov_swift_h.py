# kosh feedback 1 Nov (20:13) — Swift, part H: Insights with an older month picked (June) still offers every month up to
# this one: the page's year of months always ends at this month (reaching back far enough to hold the one picked);
# the category table's months end at the one picked. Idempotent.
def patch(F, pairs):
    p = 'Kosh/' + F; s = open(p).read()
    for a, b, mark in pairs:
        if mark in s: continue
        assert s.count(a) == 1, (F, a[:90], s.count(a)); s = s.replace(a, b)
    open(p, 'w').write(s)
patch('InsightsMath.swift', [("""    func window(_ n: Int) -> CatMonths {
        let ms: [String] = Array(months.suffix(max(0, n)))""", """    /// the last n of these months that end at `ending` (the newest when it isn't one of them)
    func window(_ n: Int, ending: String) -> CatMonths {
        let upTo: [String] = months.filter { $0 <= ending }
        let take: [String] = upTo.isEmpty ? months : upTo
        return window(n, months: Array(take.suffix(max(0, n))))
    }
    func window(_ n: Int) -> CatMonths { window(n, months: Array(months.suffix(max(0, n)))) }
    private func window(_ n: Int, months ms: [String]) -> CatMonths {""", "func window(_ n: Int, ending: String)")])
patch('MoneyViews.swift', [
("""        let year: CatMonths = store.catMonths(InsightMonths.ending(chosen, n: 12, all: allMonths))
        let data: CatMonths = year.window(6)""", """        // (the year of months always runs to this month, reaching back far enough to hold the one picked, so picking
        // June never hides July to now: 1 Nov; the category table's six end at the month picked)
        let back: Int = max(12, allMonths.filter { $0 >= chosen && $0 <= cm }.count + 5)
        let year: CatMonths = store.catMonths(InsightMonths.ending(cm, n: back, all: allMonths))
        let data: CatMonths = year.window(6, ending: chosen)""", "let back: Int = max(12"),
("""                        WhereItGoes(data: data, month: month) { c in""", """                        WhereItGoes(data: year, month: month) { c in""", "WhereItGoes(data: year, month: month)"),
])
print('swift H patched')
