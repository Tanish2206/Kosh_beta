# kosh feedback 2 Nov (01:32) — engine, part L: orders tracked item by item. Each item a payment bought carries the
# order it was in (o: "407-1971701-6067505"), and a shop's return or refund mail ("Your return of RupeeRise 3 Pcs Mi
# Band 8 Strap...", "Refund Initiated - Lithen Injex Men's Slides", a return mail's own order lines or number) marks
# the item it names as returned on that payment (ret: the day; back: the sum its mail says, when it says one). The
# money itself is set against the payment by the refund rules (the bank's or wallet's credit); this says which thing
# it was for. Idempotent.
p = 'Kosh/engine.js'; s = open(p).read()
def sub(old, new, mark):
    global s
    if mark in s: return
    assert s.count(old) == 1, ('engine L anchor', old[:70], s.count(old))
    s = s.replace(old, new)
# which order each item was in
sub("""      var ordersByShop = {}, orderTaken = {};""", """      var ordersByShop = {}, orderTaken = {}, itemOrder = {};
      var itemKey0 = function (n) { return String(n || '').toLowerCase().replace(/[^a-z0-9]+/g, '').slice(0, 24); };""", "itemOrder = {};")
sub("""            names.forEach(function (n) { n = String(n || '').trim(); var cut = n.replace(""",
    """            names.forEach(function (n) { if (n && e.order) itemOrder[itemKey0(n)] = String(e.order); });
            names.forEach(function (n) { n = String(n || '').trim(); var cut = n.replace(""", "if (n && e.order) itemOrder[itemKey0(n)] = String(e.order);")
sub("""        pay[t.id] = f;
      });
      whatWasBought(snapOut.tx || [], pay);""", """        // (each item's order, when its mail said)
        if (f.items) f.items.forEach(function (it) { var on = itemOrder[itemKey0(it.n)]; if (on) it.o = on; else if (oid && orderLines[oid]) it.o = String(r.orderId || (rc && rc.orderId) || ''); });
        pay[t.id] = f;
      });
      /* returns, item by item: a shop's return or refund mail names the item (its subject, its order's lines) or the
         order; the payment that bought it, in the six months before, has that item marked returned */
      (function () {
        var subjName = function (sj) {
          var m = /\\breturn (?:of|for)\\s+["“'‘]?(.+?)(?:\\.{3}|…|["”'’]|\\s+(?:has|is|was|been)\\b|$)/i.exec(sj) ||
                  /\\brefund (?:initiated|processed|credited|issued|completed|successful|for)\\s*[-:–|]\\s*(.+)$/i.exec(sj) ||
                  /\\b(?:returned|return (?:picked|received|accepted|approved|initiated|processed))\\s*[-:–|]\\s*(.+)$/i.exec(sj);
          return m ? m[1].trim() : '';
        };
        (ctx.records || []).forEach(function (r) {
          if (!r) return;
          var sj = String(r.subject || '');
          if (!/\\breturn(?:ed)?\\b|\\brefund/i.test(sj) || /\\b(?:policy|tax|itr|income tax|gst)\\b/i.test(sj)) return;
          var day = String(r.date || r.sent || '').slice(0, 10);
          if (!day) return;
          var names = [], orders = [];
          var sn = subjName(sj); if (sn && sn.length >= 4) names.push(sn);
          pfEvs(r).forEach(function (e) {
            if (!e || e.type !== 'order') return;
            if (e.order) orders.push(String(e.order).toUpperCase().replace(/[^A-Z0-9]/g, ''));
            (Array.isArray(e.lines) ? e.lines.map(function (l) { return l && l.n; }) : (e.items || [])).forEach(function (n) { if (n) names.push(String(n)); });
          });
          if (!names.length && !orders.length) return;
          var keys = names.map(itemKey0).filter(function (k) { return k.length >= 8; });
          var sum = +r.amt > 0 ? +r.amt : 0;
          // (one return, one purchase: the one its money came back to, else its order's, else the latest before it)
          var cands = [];
          Object.keys(pay).forEach(function (id) {
            var f = pay[id], its = f.items || [];
            if (!its.length) return;
            var t = (ctx.tx || []).filter(function (x) { return x.id === id; })[0];
            if (!t || t.d > day || pfN(day) - pfN(t.d) > 183) return;
            // (more back than it cost: another purchase's return)
            if (+r.amt > 0 && +r.amt > (t.full || t.a) + 1) return;
            its.forEach(function (it) {
              var k = itemKey0(it.n), on = String(it.o || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
              var byName = keys.some(function (q) { var a = q.slice(0, 16), b = k.slice(0, 16); return a.length >= 8 && b.length >= 8 && (a === b || k.indexOf(q.slice(0, 14)) === 0 || q.indexOf(k.slice(0, 14)) === 0); });
              var byOrder = on && orders.indexOf(on) >= 0 && (!keys.length || byName || its.length === 1);
              if (!byName && !byOrder) return;
              cands.push({ f: f, it: it, t: t, sc: (t.refunded > 0 ? 4 : 0) + (byOrder ? 2 : 0) + (byName ? 1 : 0) - (pfN(day) - pfN(t.d)) / 1000 });
            });
          });
          var best = cands.sort(function (a, b) { return b.sc - a.sc; })[0];
          if (best) {
            if (!best.it.ret || day < best.it.ret) best.it.ret = day;
            if (sum > 0 && (best.f.items || []).length === 1 && !best.it.back) best.it.back = sum;
            best.f.returned = true;
          }
        });
      })();
      whatWasBought(snapOut.tx || [], pay);""", "returns, item by item:")
open(p, 'w').write(s)
print('engine L patched')
# money back says which thing it was for: each refund set against a payment (the refund rules' refOf) is the item of
# that price in its order (₹1,031 back on a ₹3,403 Myntra order of two: the one that cost ₹1,031), or all of them
# when all came back; the item takes the day the money came back and the sum
s = open(p).read()
sub("""      whatWasBought(snapOut.tx || [], pay);""", """      (function () {
        var backsOf = {};
        (ctx.tx || []).forEach(function (c) { if (c && c.refOf && c.a > 0) (backsOf[c.refOf] = backsOf[c.refOf] || []).push(c); });
        Object.keys(backsOf).forEach(function (id) {
          var f = pay[id], its = f && f.items || [];
          if (!its.length) return;
          var t = (ctx.tx || []).filter(function (x) { return x.id === id; })[0] || {};
          var full = t.full || t.a || 0;
          backsOf[id].sort(function (a, b) { return a.d < b.d ? -1 : 1; }).forEach(function (c) {
            // (all of it back: every item went back)
            if (full > 0 && Math.abs(c.a - full) <= Math.max(2, full * 0.01)) { its.forEach(function (it) { if (!it.ret) it.ret = c.d; }); f.returned = true; return; }
            // (one item's price)
            var hit = its.filter(function (it) { return !it.back && +it.amt > 0 && Math.abs(+it.amt * (it.q || 1) - c.a) <= Math.max(2, c.a * 0.03); })[0];
            // (else the item a return mail named, still without its sum)
            if (!hit) hit = its.filter(function (it) { return it.ret && !it.back; })[0];
            if (hit) { if (!hit.ret) hit.ret = c.d; hit.back = c.a; f.returned = true; }
          });
        });
      })();
      whatWasBought(snapOut.tx || [], pay);""", "var backsOf = {};")
open(p, 'w').write(s)
print('engine L money to item')
# a return or refund mail, any shop's: the words of its body kept with its reading (a return event: its words, the
# sum it says came back, its order and return numbers), so the build finds which bought item it names whatever the
# shop's template ("RETURNED | Puma | Shibui Cat Men's Slip-on Slides" in Myntra's HTML)
s = open(p).read()
sub("""  function parse(msg) { return giftCardBought(parseMail0(msg), msg); }""",
    """  function parse(msg) { return returnWords(giftCardBought(parseMail0(msg), msg), msg); }
  var RET_STOP = { your: 1, with: 1, that: 1, this: 1, from: 1, have: 1, will: 1, been: 1, order: 1, return: 1, returned: 1, refund: 1, amount: 1, total: 1, size: 1, sold: 1, details: 1, need: 1, help: 1, contact: 1, please: 1, share: 1, experience: 1, rate: 1, very: 1, good: 1, poor: 1, bank: 1, card: 1, credit: 1, debit: 1, ending: 1, initiated: 1, processed: 1, request: 1, accepted: 1, estimated: 1, time: 1, saved: 1, discount: 1, offer: 1, valid: 1, only: 1, orders: 1, above: 1, value: 1, falls: 1, below: 1, eligible: 1, might: 1, recovered: 1, deducted: 1, breakup: 1, paid: 1, item: 1, items: 1, qty: 1, hello: 1, successfully: 1, completed: 1, process: 1, queries: 1, assistance: 1, cancel: 1, exchange: 1, instant: 1, availed: 1 };
  function returnWords(r, msg) {
    if (!r || !msg) return r;
    var sj = String(msg.subject || '');
    if (!/\\breturn(?:ed)?\\b|\\brefund/i.test(sj) || /\\b(?:policy|tax|itr|income tax|gst)\\b/i.test(sj)) return r;
    var body = (normalize(msg.text || '', '') + ' ' + normalize('', msg.html || '')).toLowerCase().slice(0, 6000);
    var seen = {}, words = [];
    body.replace(/https?:\\S+/g, ' ').split(/[^a-z0-9]+/).forEach(function (w) { if (w.length >= 4 && !/^\\d+$/.test(w) && !RET_STOP[w] && !seen[w] && words.length < 160) { seen[w] = 1; words.push(w); } });
    if (!words.length) return r;
    var ev = { type: 'return', words: words };
    var am = /(?:refund amount|total refund amount|refund of|refunded)\\s*[:|]?\\s*(?:₹|rs\\.?|inr)?\\s*([\\d,]+(?:\\.\\d{1,2})?)/i.exec(body);
    if (am) ev.amt = +am[1].replace(/,/g, '');
    var on = /\\border (?:id|no\\.?|number|#)\\s*[:#|]?\\s*([a-z0-9][a-z0-9\\-]{5,})/i.exec(body); if (on) ev.order = on[1].toUpperCase();
    var evs = []; try { evs = typeof r.evs === 'string' ? JSON.parse(r.evs) || [] : []; } catch (e) { evs = []; }
    evs.push(ev);
    r.evs = JSON.stringify(evs);
    return r;
  }""", "function returnWords(r, msg)")
# the build: an item whose own words (two at least, or one rare long word) are in a return mail's words is the item
# that went back
sub("""          pfEvs(r).forEach(function (e) {
            if (!e || e.type !== 'order') return;""", """          var rwords = {};
          pfEvs(r).forEach(function (e) { if (e && e.type === 'return' && Array.isArray(e.words)) { e.words.forEach(function (w) { rwords[w] = 1; }); if (e.order) orders.push(String(e.order).replace(/[^A-Z0-9]/gi, '').toUpperCase()); if (+e.amt > 0 && !(+r.amt > 0)) r = Object.assign({}, r, { amt: +e.amt }); } });
          pfEvs(r).forEach(function (e) {
            if (!e || e.type !== 'order') return;""", "var rwords = {};")
sub("""          if (!names.length && !orders.length) return;""", """          var hasWords = Object.keys(rwords).length > 0;
          if (!names.length && !orders.length && !hasWords) return;""", "var hasWords = Object.keys(rwords).length > 0;")
sub("""              var byOrder = on && orders.indexOf(on) >= 0 && (!keys.length || byName || its.length === 1);
              if (!byName && !byOrder) return;""", """              var byOrder = on && orders.indexOf(on) >= 0 && (!keys.length || byName || its.length === 1);
              // (its own words in the mail's: two of them, or one long rare one)
              var iw = String(it.n || '').toLowerCase().split(/[^a-z0-9]+/).filter(function (w) { return w.length >= 4 && !RET_STOP[w] && !/^(?:women|mens?|unisex|pack|black|white|blue|grey|gray|green|regular|cotton|with|kids|size|free)$/.test(w); });
              var inMail = iw.filter(function (w) { return rwords[w]; });
              var byWords = hasWords && (inMail.length >= 2 || inMail.some(function (w) { return w.length >= 8; }));
              if (!byName && !byOrder && !byWords) return;
              byName = byName || byWords;""", "var byWords = hasWords &&")
open(p, 'w').write(s)
print('engine L words')
