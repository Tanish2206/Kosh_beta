#!/usr/bin/env python3
"""itemfigs-4nov (kosh ios app chat): a row of figures is never a thing bought. A shop invoice's tax summary
("0.00 0 00 0 0.00 1.10 Total 2 530.00", the GST table's Total row) was read as an item because the item table's
last serial-numbered row swallowed it, and it showed as a 'Bought most' chip. One test, every shop, used by both
readers (reader.js lineName for mails and invoice tables, engine.js invoiceLines for PDFs) and again when payFacts
are built, so readings already stored are cleaned on the next build too. Idempotent. Run from kosh-beta/."""
import sys
TAG = 'itemfigs-4nov'

def patch(p, pairs):
    s = open(p, encoding='utf-8').read()
    if TAG in s:
        print(p, 'already has', TAG); return
    for a, b in pairs:
        if s.count(a) != 1: sys.exit('%s: anchor found %d times: %r' % (p, s.count(a), a[:70]))
        s = s.replace(a, b)
    open(p, 'w', encoding='utf-8').write(s); print(p, TAG, 'applied')

FN = r"""
  /* (itemfigs-4nov) a thing bought has a name, never a row of a table's figures: more figures than words, two figures or
     more before its first word, or a summary's own label (Total, Taxable, CGST, Round off) is the bill's, not an item */
  function itemNameOk(n) {
    n = String(n || '').replace(/\s+/g, ' ').trim();
    if (n.length < 3 || !/[a-z]{2}/i.test(n)) return false;
    var toks = n.split(' ');
    var fig = function (t) { return /^[(\-₹]*(?:rs\.?)?\d[\d,]*(?:\.\d+)?%?\)*$/i.test(t); };
    var figs = toks.filter(fig).length, words = toks.filter(function (t) { return /[a-z]{2}/i.test(t); }).length;
    if (figs > words) return false;
    var lead = 0;
    while (lead < toks.length && fig(toks[lead])) lead++;
    if (lead >= 2) return false;
    var rest = toks.slice(lead).join(' ');
    if (/^(?:sub ?-?total|grand total|total|taxable|(?:c|s|i|ut)?gst|cess|tax(?:es)?|round(?:ing)? ?off|amount in words|net (?:amount|payable))\b/i.test(rest)) return false;
    if (figs >= 2 && /\b(?:sub ?-?total|grand total|total|taxable|cgst|sgst|igst|utgst|round(?:ing)? ?off)\b/i.test(n)) return false;
    return true;
  }
"""

# reader.js: lineName refuses it
patch('Kosh/reader.js', [(
    "  function lineName(s) {\n",
    FN.lstrip('\n') + "  function lineName(s) {\n"),
  ("    if (n.length < 3 || n.length > 120 || !/[a-z]{2}/i.test(n) || LINE_NOT_ITEM.test(n)) return '';",
   "    if (n.length < 3 || n.length > 120 || !/[a-z]{2}/i.test(n) || LINE_NOT_ITEM.test(n)) return '';\n    if (!itemNameOk(n)) return '';"),
])

# engine.js: the PDF item table refuses it, and payFacts drop it from readings already stored
patch('Kosh/engine.js', [(
    "  function invoiceLines(text) {\n",
    FN.lstrip('\n') + "  function invoiceLines(text) {\n"),
  ("      if (!n || n.length < 3 || /^(?:-\\s*)?(?:delivery",
   "      if (!itemNameOk(n)) return;\n      if (!n || n.length < 3 || /^(?:-\\s*)?(?:delivery"),
  ("        if (lines) { f.items = lines.map(function (x) { var o = { n: x.n };",
   "        if (lines) lines = lines.filter(function (x) { return x && itemNameOk(x.n); });\n        if (lines && !lines.length) lines = null;\n        if (lines) { f.items = lines.map(function (x) { var o = { n: x.n };"),
  ("f.items = byTotal.items.slice(0, 12).map(",
   "f.items = byTotal.items.filter(itemNameOk).slice(0, 12).map("),
])
