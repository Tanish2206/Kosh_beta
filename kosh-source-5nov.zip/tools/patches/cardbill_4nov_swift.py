#!/usr/bin/env python3
"""cardbill-4nov (Swift): the bill a card statement PDF prints (engine parseDoc .bill) is kept on its StmtDoc as
billAmt/billMin/billDue/billOn, so the engine's cardsSeen makes it the card's bill; statementReader bumped so every kept
card statement is read again once. Idempotent."""
import io, sys, re
root = sys.argv[1] if len(sys.argv) > 1 else 'Kosh'
def patch(path, pairs):
    s = io.open(path, encoding='utf-8').read()
    if 'cardbill-4nov' in s: print(path, 'already'); return
    for old, new in pairs:
        assert s.count(old) == 1, (path, old[:60])
        s = s.replace(old, new, 1)
    io.open(path, 'w', encoding='utf-8').write(s); print(path, 'applied')

patch(root + '/LiveSession.swift', [(
"""        /// (accttype-4nov) what the statement says of the account itself: "closed", "dormant"
        var status: String? = nil
    }
    var statements: [StmtDoc] = []""",
"""        /// (accttype-4nov) what the statement says of the account itself: "closed", "dormant"
        var status: String? = nil
        /// (cardbill-4nov) the bill a card statement prints for itself: its total amount due, minimum, due day and the
        /// statement's own day. The card's bill comes from here first, the issuer's word, before any mail that retells it
        var billAmt: Double? = nil; var billMin: Double? = nil; var billDue: String? = nil; var billOn: String? = nil
    }
    var statements: [StmtDoc] = []""")])

s = io.open(root + '/LiveSession+Statements.swift', encoding='utf-8').read()
m = re.search(r'static let statementReader = (\d+)', s)
cur = int(m.group(1))
pairs = [
 ("""        /// a card statement's credit limit, and its available credit limit on the statement's day
        var limit: Double? = nil; var avail: Double? = nil
        struct Part:""",
  """        /// a card statement's credit limit, and its available credit limit on the statement's day
        var limit: Double? = nil; var avail: Double? = nil
        /// (cardbill-4nov) the bill it prints for itself: total amount due, minimum, due day, the statement's day
        struct Bill: Decodable { let amt: Double; let min: Double?; let due: String; let on: String? }
        var bill: Bill? = nil
        struct Part:"""),
 ("""                                  status: parts.count == 1 ? parsed.status : nil)
""",
  """                                  status: parts.count == 1 ? parsed.status : nil)
                var docB: StmtDoc = doc
                // cardbill-4nov: the card's bill as its statement prints it (a combined statement's parts have none)
                if kind == "cardstmt", parts.count == 1, let b = parsed.bill, b.due.count == 10 {
                    docB.billAmt = b.amt; docB.billMin = b.min; docB.billDue = b.due; docB.billOn = b.on
                }
"""),
 ("""                statements.append(doc)
                if part.check?.ok == false {""",
  """                statements.append(docB)
                if part.check?.ok == false {"""),
 ("static let statementReader = %d " % cur,
  "static let statementReader = %d   // %d (4 Nov, cardbill-4nov): a card statement's own bill (total due, minimum, due day) and its card from the masked number it prints.\n    // %d" % (cur + 1, cur + 1, cur)),
]
if 'cardbill-4nov' in s: print('Statements already')
else:
    for old, new in pairs:
        assert s.count(old) == 1, old[:70]
        s = s.replace(old, new, 1)
    io.open(root + '/LiveSession+Statements.swift', 'w', encoding='utf-8').write(s); print('Statements applied, reader', cur + 1)
