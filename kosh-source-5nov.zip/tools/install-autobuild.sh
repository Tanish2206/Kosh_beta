#!/bin/bash
# Turns on kosh's auto-build on this Mac (once): a LaunchAgent that runs tools/autobuild.sh in your login session, now
# and after every restart. Off again: launchctl bootout gui/$(id -u)/app.kosh.autobuild
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
mkdir -p "$ROOT/.build" "$HOME/Library/LaunchAgents"
P="$HOME/Library/LaunchAgents/app.kosh.autobuild.plist"
cat > "$P" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key><string>app.kosh.autobuild</string>
  <key>ProgramArguments</key><array><string>/bin/bash</string><string>$ROOT/tools/autobuild.sh</string></array>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><true/>
  <key>StandardOutPath</key><string>$ROOT/.build/agent.out</string>
  <key>StandardErrorPath</key><string>$ROOT/.build/agent.err</string>
</dict></plist>
EOF
launchctl bootout "gui/$(id -u)/app.kosh.autobuild" 2>/dev/null || true
launchctl bootstrap "gui/$(id -u)" "$P"
sleep 2
echo "kosh auto-build is on: $(cat "$ROOT/.build/status" 2>/dev/null)"
